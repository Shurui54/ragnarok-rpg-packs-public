# Ragnarok RPG Toolkit: Project Guide

Your whole RPG lives in this folder as a handful of JavaScript files: stats, races, transformations, ki attacks, quests, NPCs, shops, mobs, bosses and even dimensions. You don't need Java, a mod workspace or a restart. Edit a file, type `/rpg reload`, and you'll see the change straight away.

This starter project is **Dragon Block Ragnarok**, a faithful DragonMine Z-style game built on the bundled DMZ art pack: six races drawn with DMZ's own layered, colourable body models; 30+ transformations with auras and transformation animations; ~50 techniques (Kamehameha, Final Flash, Special Beam Cannon, Spirit Bomb, Dragon Fist...) fired as real beams, balls and disks with DMZ's cast/fire animations and sounds; DMZ controls (hold C to charge ki, V to fly, R to dash, Z to lock on, Alt/Ctrl+1-4 for techniques); 47 outfits; Dragon Balls (Earth and Namek) with Shenron and Porunga; 25 masters who teach; four sagas from Raditz to Kid Buu; world bosses; and the Time Chamber, Namek and the Other World as dimensions.

None of it is built into the engine. The engine knows "stats", "skills", "effects", "projectiles", "avatars" and "keys"; these scripts fill them with Dragon Ball. Point the same fields at other art and you get Zelda, Sonic or a shooter ([section 15](#15-make-a-different-game)). Treat the starter as a playable example: copy pieces of it, change them, or delete what you don't need.

> This file is refreshed every time the game starts (so is `api.d.ts`). If you want to keep notes, write them in a different file.

---

## Contents

1. [Quick start](#1-quick-start)
2. [The project folder](#2-the-project-folder)
3. [How scripts run (and reload)](#3-how-scripts-run-and-reload)
4. [A tour of the starter project](#4-a-tour-of-the-starter-project)
5. [Recipes: common changes](#5-recipes-common-changes)
6. [Art: textures, models, skins](#6-art-textures-models-skins)
7. [Packs: sharing your project](#7-packs-sharing-your-project)
8. [Commands](#8-commands)
9. [API reference](#9-api-reference)
10. [Events](#10-events)
11. [Overrides](#11-overrides)
12. [Player and entity methods](#12-player-and-entity-methods)
13. [JavaScript tips and gotchas](#13-javascript-tips-and-gotchas)
14. [Troubleshooting](#14-troubleshooting)
15. [Make a different game](#15-make-a-different-game)

---

## 1. Quick start

1. Open this folder in **VS Code** (File > Open Folder). Thanks to `api.d.ts` and `jsconfig.json`, you get autocomplete and hover help for everything under `RPG.`.
2. Open `scripts/50_items.js` and find the Senzu Bean. Change `name: "Senzu Bean"` to `name: "Magic Bean"`.
3. Save the file. In game, type **`/rpg reload`** (you must be an operator).
4. Type `/rpg give @s senzu_bean`. The bean now has its new name.
5. If something breaks, the error appears in chat with the file and line number. You can list errors again with **`/rpg errors`**.

In-game keys (DMZ layout, rebind in Options > Controls > "Ragnarok RPG"): **K** opens the menu (Status, Techniques, Sagas, Options). **Alt+1..4** and **Ctrl+1..4** cast skill-bar slots 1-8. **C** (hold) charges ki, **V** flies, **R** dashes, **G** (hold) descends or meditates, **H** rises or super-jumps, **Z** locks on. Two more keys (Guard, Power Strike) are defined but unbound.

---

## 2. The project folder

```
ragnarok_rpg/                 <- this folder (inside your game / server folder)
├── scripts/                  <- your game, in JavaScript (runs in name order)
│   ├── 00_project.js         project info, leveling, TP, Zeni, combat rules
│   ├── 05_ui.js              HUD, menus, colours
│   ├── ...
│   └── 90_hooks.js           events, overrides, /rpgc commands
├── resources/                <- a resource pack that is always on (textures, models, sounds)
│   ├── assets/dmzpack/       the DMZ art (GPL-3.0, see CREDITS.txt)
│   └── dmzpack_catalog.json  every DMZ model name you can use, plus English names
├── datapack/                 <- a data pack that is always on (structures, dimensions, recipes...)
├── examples/                 <- a fresh copy of the starter, refreshed every launch (for reference)
├── item_ids.json             <- remembers which placeholder slot each named item/block uses. Don't delete!
├── README.md                 <- this guide
├── api.d.ts, jsconfig.json   <- editor autocomplete (the game ignores them)
├── packs/                    <- packs downloaded from the pack browser
└── exports/                  <- zips made by /rpg export
```

The starter is copied here only the first time. After that the folder is yours, and the toolkit never overwrites your scripts. If you want to start over, delete `scripts/` and restart: the starter is copied again. `examples/` always holds the latest version so you can compare against it.

---

## 3. How scripts run (and reload)

- Every `.js` file under `scripts/` (including sub-folders) runs **in sorted path order**. That's why the files are numbered: `10_stats.js` runs before `40_skills.js`. Name your own files to fit in, for example `45_my_skills.js`.
- **All files share one global scope.** A function or `var` declared at the top of one file can be used by any file that runs later. The starter makes good use of this: `powerLevel()` is defined in `10_stats.js` and used in `50_items.js` and `90_hooks.js`.
- **Defining the same id twice replaces the first definition.** So a later file can override an earlier one, for example `RPG.items.define("senzu_bean", {...})` again in `99_my_changes.js`.
- **`/rpg reload`** throws away every definition, event handler, override and timer, runs all scripts again, and sends the result to every player. Nobody needs to relog.
- A reload only switches over once **every** script has run. If one file has an error, the others still load and the error is listed by `/rpg errors`.
- **Safety:** scripts can only touch the `RPG` API. They can't read files or reach Java. A single script call that runs longer than **2 seconds** (an infinite loop, for example) is stopped, so it can't freeze the server.
- **Dimensions and structures** are the exception. Minecraft only reads them when a world loads, so after you add or change one, restart the world or server once.
- Logging: `RPG.log("hello")` and `console.log("hello")` write to the server log.

---

## 4. A tour of the starter project

| File | What's in it |
|---|---|
| `00_project.js` | Project id/name, leveling mode **"both"** (levels give skill points, TP buys stats), XP curve, TP earning and prices, Zeni, combat formulas |
| `06_hud_dmz.js` | The DMZ HUD as a script-defined layout (players can move/resize it) |
| `07_creator_dmz.js` | The DMZ character creator: race, body, skin, hair, eyes, nose, mouth, class |
| `01_toolbox.js` | Shared helpers: `sfx()` (pack sounds), `act()` (play an avatar animation, then return to flying/charging), damage formulas, `lookPoint()`, lock-on, `times()` |
| `05_ui.js` | Ragnarok theme, HUD (ki/stamina bars, portrait), race + class picker, DMZ menu tab names, colours |
| `10_stats.js` | STR, SKP, RES, VIT, PWR, ENE, three hidden "marker" stats for gear, and `powerLevel()` |
| `15_resources.js` | Ki (grows with Energy) and Stamina (grows with Vitality) |
| `20_races.js` | The six races with **avatars** built from DMZ's layered textures, their default colours, the `raceChange` hook that applies them, and `/rpgc color` |
| `25_classes.js` | Warrior and Spiritualist (each with a starting gi and technique) |
| `30_forms.js` | `defineForm()` and 30+ forms: Kaioken x2-x20, Oozaru, Super Saiyan 1/G2/G3/2/3/4/God/Blue, Golden Oozaru, Giant/Super/Orange Namekian, the Frost Demon forms up to Golden and Metal, Semi-Perfect to Xeno, Super/Evil/Kid Majin, Super Janemba. Each swaps the avatar, adds an aura and plays a DMZ transformation animation |
| `35_projectiles.js` | Every ball, beam, laser, disk, sprite and thrown item (30 projectiles) |
| `40_skills.js` | `kiTechnique()` / `strikeTechnique()` recipes and ~50 techniques: beams, volleys, disks, DMZ "skp" strikes, Zanzoken, Instant Transmission, Solar Flare, barriers, Absorb, Fusion Dance, passives |
| `45_keys.js` | The DMZ controls: charge ki, flight, dash, descend/meditate, lock-on, ascend, guard, power strike |
| `50_items.js` | Senzu beans (and farmable coloured beans), food, medicine, capsules, Gete stat capsules, scouters, three Dragon Ball sets and radars, weapons and guns, weights, Potara earrings, Nimbus, 40 music discs |
| `52_armor.js` | 47 DMZ outfits (skin64 armour model) and a sewing pattern for each |
| `55_blocks.js` | Namek terrain, ores and trees, Earth/Hell/Demon Realm blocks, flowers, herbs, growing Senzu crops, the Time Chamber floor, a Dragon Altar |
| `60_npcs_dialogue.js` | `teacher()` and 25 DMZ masters who teach techniques, townsfolk, Namekian villagers, vehicle props, the punch machine, Shenron and Porunga |
| `65_shops.js` | Kame House, Korin, Capsule Corp., Namek, Frieza Force, Babidi, Yajirobe, Toribot's jukebox |
| `70_quests.js` | Tutorial, the Saiyan / Namek / Android / Buu sagas (21 chained quests) and side quests (tournaments, Baba, Old Kai's ritual...) |
| `75_mobs_bosses.js` | ~100 mobs (Saibamen, soldiers, robots, dinosaurs, frogs, ogres, the training shadow, the dragons) and 57 bosses, including Frieza's four forms in a row and DMZ's world bosses with their music |
| `80_spawns_events.js` | Natural spawns on Earth, Namek, the Other World and in the Time Chamber; random events (invasions, radar pings, Double TP, world bosses) |
| `85_world.js` | The Time Chamber, Namek and Other World dimensions, travel helpers and `/rpgc leave` |
| `90_hooks.js` | Welcome, level-ups, kill streaks, regeneration, Zenkai, barrier/guard damage reduction, hurt animations, TP multipliers, overrides, and `/rpgc power`, `help`, `arena`, `setup` |

**To try it:** join, pick a race and a class, and type `/rpgc setup` (op) to place Roshi, Korin, Bulma, Mr. Popo, King Yemma and other masters around you. Talk to Roshi to start the saga. Quick tests: `/rpg learn @s kamehameha`, `/rpg learn @s super_saiyan`, `/rpg mob saibaman`, `/rpg boss frieza_first`, `/rpg event start world_boss`, `/rpgc color hair #FF0000`. After the first start, **restart once** so the three dimensions load.

---

## 5. Recipes: common changes

**Make an item.** Add this to any script:
```js
RPG.items.define("power_drink", {
    name: "Power Drink",
    model: "dmzpack:rpg/item/senzu_bean_blue",   // any name from dmzpack_catalog.json "items"
    type: "consumable",
    useTime: 20, useAnim: "drink",
    onUse(player) { player.addResource("ki", 50); }
});
```

**Make a skill.** It shows up in K > Techniques:
```js
RPG.skills.define("big_bang", {
    name: "Big Bang Attack",
    icon: "minecraft:fire_charge",
    requires: { level: 25 },
    cost: { ki: 40 },
    cooldown: 200,                       // 10 seconds
    onCast(ctx) {
        if (!ctx.target) return false;   // no target: no cost, no cooldown
        ctx.target.damageFrom(30 + ctx.player.stat("kipower"), ctx.player);
    }
});
```

**Make a transformation.** One `defineForm(...)` call in `30_forms.js` makes both the effect (stats, ki drain, avatar, aura) and the skill that toggles it. Kaioken at the top of the file is written out by hand so you can see the two halves.

**Make a beam.** Define the projectile in `35_projectiles.js`, then one `kiTechnique(...)` in `40_skills.js` with a cast and fire animation from the catalog (`ki.kameha_cast` / `ki.kameha_fire`...) and two sounds.

**Give a race a new starting skill.** Add the skill id to `skills: [...]` in `20_races.js`.

**Change how fast players grow.** In `00_project.js`, change `tp.perHit`, `tp.perKill`, `tp.costGrowth` or `xpExponent`.

**Add an NPC with dialogue.**
```js
RPG.npcs.define("goku", {
    name: "&6Goku",
    dialogue: "goku_talk",
    geo: { model: "dmzpack:geo/entity/master/master_goku.geo.json",
           texture: "dmzpack:textures/entity/master/master_goku.png",
           animation: "dmzpack:animations/entity/master/masters.animation.json",
           idle: "idle", walk: "walk" }
});
RPG.dialogues.define("goku_talk", {
    nodes: { start: { text: "Hey! Wanna spar?", options: [{ text: "Sure!" }] } }
});
```
Then use `/rpg npc goku` where you want it.

**Continue the saga.** Copy a quest in `70_quests.js`, point its `kill` objective at a new `defineBoss(...)` from `75_mobs_bosses.js` (any `saga_*` model in the catalog), and chain it with `next:`.

**Remove something.** Delete or comment out its `define(...)`. Players keep any items they already have, but those items stop working until they're defined again.

---

## 6. Art: textures, models, skins

### The resources folder
`resources/` is a normal resource pack that is always switched on. Anything you put in `resources/assets/<namespace>/...` can be used by your scripts. The toolkit watches the folder, so when you save a texture in your image editor the game reloads it about a second later. You don't need to press F3+T.

### Edit menu art (no files needed)
Open the menu (K), then **Settings > Edit menu art**:
1. **Export** copies every built-in texture (menus, HUD, placeholder icons) into `resources/` and a shareable zip.
2. Edit the PNGs in any image editor.
3. **Drag and drop** your edited files (or a zip) onto that screen. Files are matched by name and put in the right place. A new PNG goes to `assets/ragnarok_rpg/textures/custom/`, and a new model JSON goes to `models/rpg/`.

**Settings > Open project folder** opens this folder for you.

### Item and block models: `model:`
Any model JSON under `assets/<namespace>/models/rpg/` in a resource pack can be used. It replaces the placeholder look completely.
```js
RPG.items.define("senzu_bean", { name: "Senzu Bean", model: "dmzpack:rpg/item/senzu_bean" });
RPG.blocks.define("namek_stone", { model: "dmzpack:rpg/block/namek_stone" });
```
- `"dmzpack:rpg/item/senzu_bean"` points to the file `assets/dmzpack/models/rpg/item/senzu_bean.json`.
- `resources/dmzpack_catalog.json` lists every ready-made name: `items` work as `dmzpack:rpg/item/<name>` and `blocks` as `dmzpack:rpg/block/<name>`.
- **Your own art:** put `assets/mymod/textures/item/sword.png` in `resources/`, then add `assets/mymod/models/rpg/item/sword.json`:
  ```json
  { "parent": "minecraft:item/handheld", "textures": { "layer0": "mymod:item/sword" } }
  ```
  and use `model: "mymod:rpg/item/sword"`. For a block, use `"parent": "minecraft:block/cube_all"` with `"textures": { "all": "mymod:block/stone" }`.
- Without a `model`, items use a placeholder shape (`icon`) tinted with `iconColor`/`color`. The shapes are `gem sword axe bow staff dagger shield potion food scroll book ring amulet coin key orb ore ingot bag helmet chestplate leggings boots capsule feather bone crystal star`. Placeholder blocks are tinted with `color`.

### Armour: `armorTexture:` and `armorModel:`
- `{n}` in the path is replaced by `1` for head/chest/feet and `2` for legs (Minecraft's two armour layers): `armorTexture: "dmzpack:textures/armor/goku_gi_layer{n}.png"`.
- A full path ending in `.png` without `{n}` is used as-is. A short name like `"mymod:knight"` becomes `mymod:textures/models/armor/knight_layer_1.png` / `_layer_2.png` (vanilla naming).
- **`armorModel: "skin64"`** draws the armour with a 64x64 player-skin layout (separate left arm/leg regions, outer layer rows). That's how DMZ armour is painted; on vanilla's 64x32 model those textures come out scrambled. Leave it out for vanilla-style textures.
- On a player with an **avatar**, worn armour is drawn on the model's own `armorHead`, `armorBody`, `armorRightArm`... bones, so it follows the race's proportions and animations. `armorBones` in the avatar changes which bones; `armor: false` hides armour on that avatar.
- There are 50 armour slots per piece (head, chest, legs, feet). `52_armor.js` uses 47 chest/legs/feet and 5 head slots.

### Creatures and NPCs: `geo:` (GeckoLib)
NPCs, mobs and bosses (through their `mob`) can use any GeckoLib model:
```js
geo: {
    model: "dmzpack:geo/entity/master/master_roshi.geo.json",
    texture: "dmzpack:textures/entity/master/master_roshi.png",
    animation: "dmzpack:animations/entity/master/masters.animation.json",  // optional
    idle: "roshi_idle", walk: "walk", attack: "attack",                    // optional names
    scale: 1.0
}
```
- The paths are relative to `assets/<namespace>/`. The DMZ ones are listed under `geo` in `dmzpack_catalog.json`.
- Animation names are the keys of the `"animations"` object inside the `.animation.json` file. Open it to see them. The DMZ saga characters all share `animations/entity/sagas/saga_base.animation.json` (`idle`, `walk`, `attack1_1`, `ki_blast`, `transformation_1`...), and the masters share `animations/entity/master/masters.animation.json`.
- If a model has no animation file, leave out `animation`. It will just stand still.
- Scripts can play an animation once: `mob.playAnimation("explode")`.

### Changing the player's look
Three ways, on **races, classes and effects**. When more than one applies, **effect > class > race**: that's how transformations change the body and powering down changes it back.
- `skin: "mymod:textures/skins/saiyan.png"`: a normal 64x64 skin on the vanilla player model.
- `avatar: {...}`: a GeckoLib model with tinted layers, per-player colours and full animation states (below). This is what the DMZ races use.
- `playerModel: { model, texture, animation, idle, walk, scale }`: the older, simpler GeckoLib look.

### Avatars (player models)
```js
avatar: {
    model: "dmzpack:geo/entity/races/human.geo.json",
    // no texture: the base pass is invisible, the layers draw everything
    layers: [
        { texture: "dmzpack:textures/entity/races/humansaiyan/bodytype_male_1_layer1.png", color: "body1" },
        { texture: "dmzpack:textures/entity/races/humansaiyan/faces/humansaiyan_eye_0_1.png", color: "eyes", bones: ["head"] },
        { texture: "dmzpack:textures/entity/races/hair_base.png", color: "hair", bones: ["head"] }
    ],
    colors: { body1: "#FFD3C9", eyes: "#222629", hair: "#222629" },     // defaults
    animation: "dmzpack:animations/entity/races/movement.animation.json",
    animations: ["dmzpack:animations/entity/races/ki.animation.json"],   // more files to play from
    states: { idle: "base.idle", walk: "base.walk", run: "base.run", sneak: "base.crouching",
              sneakWalk: "base.crouching_walk", jump: "base.jump", swim: "base.swimming",
              fly: "base.fly_idle", flyFast: "base.fly_fast", attack: "base.attack1", mine: "base.mining1", sit: "base.sit" },
    scale: 0.9375, headLook: true, hideBones: ["armor*", "tail*"],
    rightHand: "right_hand_item", leftHand: "left_hand_item"
}
```
- **Layers** re-draw the model (or only `bones`, with their children) with their own texture, tinted by `color`. A sibling file `<texture>_shadow.png` is drawn on top automatically as shading, the way DMZ shades skin (`shadow: false` turns it off). Greyscale textures tint best.
- **Colours**: a layer's `color` is `"#RRGGBB"` or a name. Names look in the player's own colours first (`player.setColor("hair", "#FFE34D")`, saved with the player), then the avatar's `colors`. The starter applies each race's defaults on first selection (the `raceChange` hook in `20_races.js`) and lets players change them with `/rpgc color <name> <#hex>`. Forms use their own names (`ssjHair`, `ssj4Fur`...) so a player's black hair doesn't override Super Saiyan gold.
- **Animations**: `states` play by themselves. Scripts play anything from the avatar's files: `player.playAnimationFor("ki.kameha_cast", 40)` (ticks; `0` loops until `player.stopAnimation()`), or `player.playAnimation(name)` for 20 ticks. `resources/dmzpack_catalog.json` lists every animation name per file.
- **Look values and templates**: besides colours, players carry look values (also set with `player.setColor(key, value)`, or by a character creator). `{key}` inside `model` or a layer `texture` is replaced by that value (the avatar's `colors` hold the defaults), and a layer with `when: "hairStyle!=bald"` (or `"key=value"`, `"key"`, `"!key"`) only draws when it matches. Missing files are skipped, so a body type without a fourth layer simply has none. The starter's races use `bodyType`, `bodyModel` (set automatically from `bodyType`), `eyeStyle`, `nose`, `mouth` and `hairStyle`: `/rpgc color eyeStyle 7` or the creator in `07_creator_dmz.js` changes them.
- **Held items** render on the `rightHand` / `leftHand` bones and **armour** on the armour bones (see above). The head follows the camera unless an animation is playing.
- `hideBones` defaults to `["armor*"]` (the armour reference cubes). A `*` at the end matches by prefix.
- The six DMZ race builders (`humanAvatar`, `namekianAvatar`, `frostAvatar`, `bioAvatar`, `majinAvatar`) in `20_races.js` are a good template for your own.

### Character creator: `RPG.creators`
`RPG.creators.define(id, { title, steps: [...], onFinish(player, choices), closeable, allowRedo })` builds a step-by-step screen. Steps are `{ id, label, description, type, key, options, palette, custom, default, showIf, required }`: `type: "race"` / `"class"` pick one of your races/classes, `"choice"` stores `options[].value` as the look value `key`, `"color"` offers a `palette` (and any colour with `custom: true`). `showIf: "race=human|saiyan"` hides steps or options based on earlier picks. With `RPG.ui.configure({ creator: id })` it opens on first join instead of the race/class pickers; `RPG.creators.open(player, id)` opens it any time and `RPG.creators.done(player, id)` tells you if it was finished. The starter's DMZ creator is `07_creator_dmz.js`.

### Script-defined HUD
`RPG.ui.configure({ hud: { layout: [groups] } })` replaces the built-in HUD with groups of `image`, `bar`, `text` and `portrait` elements cut from any texture; `06_hud_dmz.js` builds DMZ's HUD this way and documents every element field at the top. Players move, resize or hide each group with Menu > Options > "Move / resize HUD"; those changes stay on their own computer.

### Auras
Effects can have a glowing aura while active:
```js
aura: { texture: "dmzpack:textures/entity/races/aura/kakarot_aura.png", frames: 4, speed: 10,
        color: "#FFE34D", scale: 1.0, alpha: 0.8, height: 2.6, aspect: 1.0 }
```
`texture` is a horizontal strip of `frames` (DMZ has `kakarot_aura`, `kakarot_cross`, `god_aura` and `god_cross`). `color` can be a player colour name: the starter's charging aura uses `"aura"`, so every player charges in their own colour. When several active effects have auras, the first one applied is drawn.

### Menu textures
In `05_ui.js`, set `RPG.ui.configure({ textures: { panel: "mymod:textures/gui/panel.png" } })`. The replacement must be the same pixel size as the original. You can also override `ragnarok_rpg:textures/gui/...` directly in `resources/`.

### Credits
The DMZ art (the `dmzpack` asset pack, downloaded on first join) comes from **DragonMine Z** and is licensed GPL-3.0. Keep `CREDITS.txt` when you share your project.

---

## 7. Packs: sharing your project

- **Name your project** in `00_project.js`:
  ```js
  RPG.project.configure({ id: "my-game", name: "My Game", version: "1.0.0", author: "You", description: "..." });
  ```
- **`/rpg export`** zips your scripts, resources, datapack and `item_ids.json` into `exports/<id>-<version>.zip`. It also writes the matching pack-index entry (with size and sha256) next to the zip, ready to submit.
- **Pack browser** (K > Settings > **Browse packs**): download projects other people have shared and switch which one you play in singleplayer. Use "Submit pack" to share your own.
- **Servers offering art:** when a server's project has an `id` and `version` that match a pack in the index, joining players are offered that pack's art (textures and models). Scripts never come from the server this way. The server already sends everything else. Players control this with the `serverAssets` client setting: `ask`, `always` or `never`.
- Bump `version` every time you publish new art, so players download the update.

---

## 8. Commands

**Everyone:**
| Command | What it does |
|---|---|
| `/rpg menu` | Open the RPG menu |
| `/rpg party invite <player>` / `accept` / `leave` / `kick <player>` / `list` | Parties share kill XP (`partyShare`, `partyRange`) |
| `/rpgc <name> [args...]` | Run a script command (`RPG.commands.register`) |

**Operators (permission level 2):**
| Command | What it does |
|---|---|
| `/rpg reload` | Re-run every script |
| `/rpg errors` | List load and runtime errors |
| `/rpg info` | Count definitions of each kind |
| `/rpg run <javascript>` | Run code right now (level 4). `me` is you: `/rpg run me.addTp(500)` |
| `/rpg xp\|level\|tp\|money\|statpoints\|skillpoints <players> <amount>` | Give XP, set the level, add TP / Zeni / points (negative amounts remove them) |
| `/rpg class\|race <players> <id>` | Set class or race |
| `/rpg learn\|forget <players> <skill>` | Teach or remove a skill |
| `/rpg effect\|cleareffect <players> <effect>` | Add an effect (30 seconds) or remove it |
| `/rpg quest start\|complete\|abandon\|reset <players> <quest>` | Manage quests |
| `/rpg give <players> <item> [count]` | Give an item by script name. Put namespaced ids in quotes: `"minecraft:diamond"` |
| `/rpg npc <id>` / `/rpg mob <id>` / `/rpg boss <id>` | Spawn at your position |
| `/rpg event start\|stop <id>` | Control random events |
| `/rpg stats <player>` | Show a player's level, TP, money and stats |
| `/rpg reset <players>` | Wipe a player's RPG data |
| `/rpg export` | Export the project as a pack |

**Starter commands** (from the scripts): `/rpgc help`, `/rpgc power`, `/rpgc color [part #hex | reset]`, `/rpgc leave` (back from another world), and for ops `/rpgc setup` (place the core NPCs) and `/rpgc arena [n]`.

---

## 9. API reference

Everything is reached through the global **`RPG`** object. In the tables, "fn" means a function, "ticks" means 20 per second, and colours are `"#RRGGBB"` or `0xRRGGBB`. Text supports `&` colour codes (`&a` green, `&c` red, `&e` yellow, `&6` gold, `&b` aqua, `&7` grey, `&l` bold).

### 9.1 Utilities on `RPG`
| Member | Description |
|---|---|
| `RPG.on(event, fn)` | Hook a game event ([section 10](#10-events)) |
| `RPG.override(name, fn)` | Replace a core formula ([section 11](#11-overrides)). Pass `null` to restore the built-in |
| `RPG.schedule(ticks, fn)` | Run once later. Returns an id |
| `RPG.every(ticks, fn)` | Run repeatedly. Returns an id. Timers are cleared on reload |
| `RPG.cancel(id)` | Stop a timer |
| `RPG.log(msg)` | Write to the server log (`console.log` works too) |
| `RPG.random(min, max)` | Random decimal in [min, max) |
| `RPG.randomInt(min, max)` | Random whole number, both ends included |
| `RPG.chance(p)` | `true` with probability p (0-1) |
| `RPG.clamp(v, min, max)` | Limit a number to a range |
| `RPG.player(name)` | An online player, or `null` |
| `RPG.broadcast(msg)` | Chat message to everyone |
| `RPG.version` | The toolkit version |

### 9.2 Content namespaces
Every content kind has the same functions: **`define(id, {...})`** (returns the id), `get(id)` (plain data without functions, or `null`), `exists(id)`, `list()` (all ids), and `name(id)` (the display name).

`RPG.stats` · `RPG.resources` · `RPG.races` · `RPG.classes` · `RPG.items` · `RPG.blocks` · `RPG.skills` · `RPG.effects` · `RPG.quests` · `RPG.npcs` · `RPG.dialogues` · `RPG.shops` · `RPG.mobs` · `RPG.bosses` · `RPG.spawns` · `RPG.randomEvents` · `RPG.projectiles` · `RPG.keys` · `RPG.creators` · `RPG.dimensions` · `RPG.structures`

Plus `RPG.loot`, `RPG.commands`, `RPG.server`, `RPG.world`, and the settings blocks `RPG.project`, `RPG.leveling`, `RPG.currency`, `RPG.combat`, `RPG.ui`. Each settings block has `configure({...})`, which **merges**, so several files can each set a few keys, and `get()`.

#### The PerLevel / PerStat convention
Many numbers (resource `max` and `regen`, for example) can grow with the player:
```js
max: 50,                      // a number, or a function (player) => number
maxPerLevel: 2,               // + 2 for every level after the first
maxPerStat: { energy: 10 },   // + 10 per point of Energy
```

### 9.3 Settings

**`RPG.project.configure`**: `id`, `name`, `version`, `author`, `description`.

**`RPG.leveling.configure`**
| Key | Default | Meaning |
|---|---|---|
| `mode` | `"levels"` | `"levels"`: levels give stat points. `"tp"`: TP buys stats, levels give nothing. `"both"`: levels give skill points, TP buys stats |
| `maxLevel` | 100 | |
| `xpBase`, `xpExponent` | 100, 1.5 | XP for the next level = `xpBase × level^xpExponent` |
| `xpForLevel(level)` | | Your own curve (replaces the two above) |
| `statPointsPerLevel` | 3 (0 in tp/both) | |
| `skillPointsPerLevel` | 1 | |
| `startingStatPoints`, `startingSkillPoints` | 0 | |
| `startingItems` | | Given on first join |
| `defaultRace`, `defaultClass` | | Set automatically on first join |
| `refillOnLevelUp` | true | Full health and resources on level up |
| `levelUpMessage` | | `{level}` is replaced. `""` = silent |
| `showXpGain` | true | "+12 XP" on the action bar |
| `xpPerHealth` | 1 | Kill XP = victim max health × this |
| `killXp(player, victim)` | | Your own kill XP formula |
| `pvpXp` | 0 | XP for killing a player |
| `deathXpLoss` | 0 | Fraction of the current XP bar lost on death |
| `partyShare`, `partyRange`, `partyMaxSize` | 0.5, 48, 6 | |
| `skillMastery` | true | Multi-level skills level up with use |
| `allowRaceChange`, `allowClassChange` | false | Let players re-pick in the menu |
| `tp.perHit`, `tp.perDamage` | 0 | TP per hit, plus TP per damage dealt |
| `tp.perKill`, `tp.perKillHealth` | 0 | TP per kill, plus TP per victim max health |
| `tp.perMinute` | 0 | TP for being online |
| `tp.multiplier` | 1 | Global TP multiplier (races/classes also have `tpMultiplier`) |
| `tp.costBase`, `tp.costGrowth` | 10, 0.05 | Stat price = `ceil(costBase × (1 + totalBought × costGrowth))` |

**`RPG.currency.configure`**: `name` ("Zeni"), `symbol` ("Z"), `starting` (money on first join).

**`RPG.combat.configure`**
| Key | Meaning |
|---|---|
| `damageStat`, `damageScale` (0.5) | Melee hits get `+stat × scale` |
| `rangedStat`, `rangedScale` (0.5) | The same for projectiles |
| `unarmedDamage`, `unarmedStat`, `unarmedScale` (0.5) | Bare-fist base damage (replaces 1) and stat bonus |
| `critChance` (number or `fn(player)`), `critStat`, `critPerStat`, `critMultiplier` (1.5) | Critical hits |
| `defenseStat`, `defenseScale` (0.25), `minDamageFraction` (0.2) | Damage taken minus `stat × scale`, never below the fraction |
| `damageFormula(event)`, `defenseFormula(event)` | Replace the built-in damage dealt/taken math. Return the new amount |
| `tpPerDamageTaken` | TP for taking damage |

Damage from skills (`damageFrom(amount, player)`) counts as a player hit too, so `damageStat`, crits and the `attack` event apply to it.

**`RPG.ui.configure`**
| Key | Meaning |
|---|---|
| `theme` | `"ragnarok"` or `"vanilla"` (players can override this in Settings) |
| `showLogo` | Show the logo on menus |
| `chooseRaceOnJoin`, `chooseClassOnJoin` | Open the picker for players who have none |
| `creator` | A `RPG.creators` id to show on first join instead of the pickers |
| `damageNumbers` | Floating damage numbers |
| `hud.enabled`, `hud.primary`, `hud.secondary`, `hud.tertiary` | HUD bars (resource ids) |
| `hud.showXp`, `showMoney`, `showTp`, `showSkillBar`, `showEffects`, `scale`, `x`, `y` | HUD parts and position |
| `hud.portrait` | The player's live portrait in the scouter orb (default true) |
| `hud.layout` | A fully script-defined HUD (see `06_hud_dmz.js`) |
| `tabs`, `tabLabels` | Menu tabs (`character`, `skills`, `quests`, `settings`) and their labels |
| `colors.title/text/muted/accent/good/bad` | Ragnarok theme colours |
| `textures.panel/buttons/field/slot/scrollbar/scrollbarThumb/tab/logo` | Replacement menu textures |

**`RPG.randomEvents.configure`**: `interval` (ticks between rolls, default 12000), `chance` (0.35), `maxActive` (1), `enabled` (true).

### 9.4 Stats: `RPG.stats.define(id, {...})`
| Field | Meaning |
|---|---|
| `name`, `description`, `color`, `hidden` | Display |
| `base`, `min`, `max` | Starting value and limits |
| `attributes` | Per point: `{ "minecraft:generic.max_health": 1 }` or `{ attr: { amount, operation: "multiply_total" } }` |
| `formula(player, value)` | Final say over the value |
| `allocatable` (true), `maxAllocated` | Whether players can buy it, and the cap |
| `pointCost` | Stat points per point in "levels" mode |
| `tpCost(player, bought)`, `tpCostBase`, `tpCostGrowth` | Price in TP modes |

Final value = base + race + class (+ PerLevel) + bought points + worn gear + effects.

Useful attributes: `minecraft:generic.max_health`, `generic.attack_damage`, `generic.armor`, `generic.armor_toughness`, `generic.movement_speed` (base 0.1), `generic.attack_speed`, `generic.knockback_resistance` (0-1), `generic.luck`.

### 9.5 Resources: `RPG.resources.define(id, {...})`
`name`, `color`, `max` / `maxPerLevel` / `maxPerStat`, `regen` (per second) / `regenPerLevel` / `regenPerStat`, `regenInterval` (ticks, default 20), `startFull` (true), `refillOnRespawn` (true), `hud` (`"primary"`, `"secondary"`, `"tertiary"`, `"none"`), `hudTint` (tint the secondary bar's own art with `color`).

### 9.6 Races and classes: `RPG.races` / `RPG.classes`
| Field | Meaning |
|---|---|
| `name`, `description` | Shown on the picker |
| `stats`, `statsPerLevel` | Stat bonuses |
| `attributes` | Direct attribute bonuses |
| `skills` | Skills granted when chosen |
| `tpMultiplier` | TP multiplier |
| `selectable` (true), `levelReq`, `canSelect(player)` | Who can pick it |
| `onSelect(player)` | Runs when chosen |
| `startingItems` | Classes only. Given the first time |
| `avatar`, `skin`, `playerModel` | Change the look ([section 6](#avatars-player-models)) |

### 9.7 Items: `RPG.items.define(ref, {...})`
`ref` is your own name (`"senzu_bean"`), a number 1-1000, or `"item_0042"`. Names get a permanent placeholder slot, saved in `item_ids.json`. Slots 1-800 are general items and 801-1000 are real armour (801-850 head, 851-900 chest, 901-950 legs, 951-1000 feet). A name with `type: "armor"` and a `slot` is put in the right range automatically. `RPG.items.id(ref)` returns the placeholder id.

| Field | Meaning |
|---|---|
| `name`, `color`, `rarity` (`common` `uncommon` `rare` `epic` `legendary`), `rarityLabel`, `lore` | Display |
| `model` | `"ns:rpg/item/name"`: any model under `models/rpg/` |
| `icon`, `iconColor` | Placeholder shape and tint when there's no model |
| `type` | `weapon`, `armor`, `accessory`, `tool`, `consumable`, `material`, or anything else (shown in the tooltip) |
| `slot` | `head` `chest` `legs` `feet` `mainhand` `offhand`: where stats count (and lets it be worn on the head/chest/...) |
| `damage`, `attackSpeed` | Like vanilla (diamond sword: 7, 1.6) |
| `armor`, `toughness`, `knockbackResistance`, `attributes` | Attribute bonuses in its slot |
| `stats` | Stat bonuses while held/worn |
| `durability`, `maxStack`, `glint` | |
| `levelReq`, `classReq` | Below the requirement, weapons hit for 1, stats don't count and it can't be used |
| `useTime`, `useAnim` (`eat` `drink` `bow` `block` `spear` `none`) | Hold-to-use (consumables default to 32) |
| `consume` | Shrink on use (default true for consumables) |
| `cooldown` | Item cooldown in ticks |
| `skill` | Cast this skill on use |
| `value` | Shown as the price in the tooltip |
| `armorTexture`, `armorModel` | Armour only ([section 6](#armour-armortexture-and-armormodel)) |
| `onUse(player, itemId)` | Return `false` to cancel (no cooldown, not consumed) |
| `onHit(player, target)` | After a melee hit |

### 9.8 Blocks: `RPG.blocks.define(ref, {...})`
`ref` is a name, 1-200, or `"block_0007"`. Blocks 1-150 are solid and 151-200 are see-through decor. A name with `decor: true`, a non-full `shape` or `collision: false` goes to the decor range. `define` returns the id (`"block_0007"`), so `"ragnarok_rpg:" + id` works in `setBlock` and in dimension layers. The block's item has the same name.

| Field | Meaning |
|---|---|
| `name`, `model` (`"ns:rpg/block/name"`), `color` | Look |
| `hardness` (-1 = unbreakable), `requiresTool`, `light` (0-15) | |
| `shape` | `full` `slab` `carpet` `cross` `pillar` `pane` `table`, or `[x1,y1,z1,x2,y2,z2]` in pixels |
| `collision` | `false` = walk through |
| `drops` | `[{ item, count, chance }]` or `"none"` |
| `slipperiness` (0.6), `speed` (1.0), `jump` (1.0) | |
| `onUse(player,x,y,z)`, `onStep(entity,x,y,z)`, `onBreak(player,x,y,z)`, `onPlace(player,x,y,z)`, `onRandomTick(dimension,x,y,z)` | |

### 9.9 Skills: `RPG.skills.define(id, {...})`
| Field | Meaning |
|---|---|
| `name`, `description`, `icon` (an item ref) | Display |
| `maxLevel` (1), `skillPointCost` (1, or `fn(player, nextLevel)`) | Learning |
| `passive` | Never cast, never on the bar |
| `hidden`, `noLearn` | Hide until learned / can't buy with points |
| `requires` | `{ level, race, class, skills: { id: level } }` |
| `cost` | `{ ki: 10 }`. Each amount may be `fn(player, level)` |
| `cooldown` | Ticks, or `fn(player, level)` |
| `range` (24) | How far `ctx.target` looks |
| `mastery`, `xpPerUse` (1), `masteryXp` (20 × level, or `fn(level)`) | Level up with use |
| `canCast(player, level)` | Return `false` or a message to block the cast |
| `onCast(ctx)` | `ctx.player`, `ctx.level`, `ctx.target`, `ctx.skill`, `ctx.range`. Return `false` = fizzled (no cost, no cooldown) |
| `onLearn(player, level)`, `onLevelUp(player, level)` | |

### 9.10 Effects: `RPG.effects.define(id, {...})`
Buffs, debuffs and transformations. Add them with `player.addEffect(id, ticks)` (-1 = until removed).

| Field | Meaning |
|---|---|
| `name`, `color`, `beneficial` (true), `hidden` | HUD display |
| `stats`, `attributes` | Bonuses (× stacks) |
| `maxStacks` (1) | |
| `tickInterval` (20) | How often `onTick` runs |
| `keepOnDeath` | Otherwise removed on death |
| `avatar`, `skin`, `playerModel` | Change the look while active (wins over class and race) |
| `aura` | A glowing aura while active ([section 6](#auras)) |
| `onApply(player, stacks)`, `onTick(player, stacks)`, `onRemove(player, stacks)` | |

> An effect can end itself from its own `onTick` (`player.removeEffect(id)`), for example when ki runs out. See `drainForm()` in `30_forms.js`.

### 9.11 Quests: `RPG.quests.define(id, {...})`
| Field | Meaning |
|---|---|
| `name`, `description` | Quest log |
| `objectives` | A list ([below](#objectives)) |
| `turnIn` | NPC id. The quest waits for the player to talk to them. Without it, the quest completes as soon as the objectives are done |
| `next` | Quest id(s) started automatically afterwards. This is how a chain works |
| `repeatable`, `abandonable` (true) | |
| `requires` | `{ level, quests: [...], class }` |
| `rewards` | `{ xp, money, statPoints, skillPoints, items, skills, effects: [{id, duration}], commands }`. Commands run as the player with op rights, and `{player}` is replaced by their name |
| `canStart(player)` | Return `false` or a message |
| `onStart(player)`, `onComplete(player)` | |

#### Objectives
| Type | Fields |
|---|---|
| `kill` | `target`: entity id (`"minecraft:zombie"`), `"#tag"`, `"*"`, a list, or a mob/boss/NPC id. Plus `count` |
| `collect` | `item`, `count`, `consume` (taken on completion) |
| `talk` | `npc` |
| `level` | `level` |
| `skill` | `skill`, `level` |
| `location` | `x`, `y`, `z`, `radius` (5), `dimension` |
| `custom` | `key`, `count`. Advance with `player.progressQuest(key, amount)` |

Any objective can have a `description` that replaces the automatic text.

### 9.12 NPCs and dialogue
**`RPG.npcs.define(id, {...})`**: `name`, `dialogue`, `shop`, `geo` (GeckoLib) or `skin` + `slim` (player model), `wander`, `invulnerable` (true), `scale`, `showName`, `onInteract(player, npc)` (return `false` to stop the dialogue/shop). Place one with `/rpg npc <id>` or `RPG.world.spawnNpc(...)`.

When a player right-clicks an NPC, these steps run in order:
1. `talk` objectives for this NPC advance.
2. Any finished quest with `turnIn` set to this NPC is handed in. If one was, that click stops here.
3. The `npcInteract` event runs, then `onInteract`.
4. The dialogue (or the shop) opens.

Turning in happens first and the NPC's dialogue still opens afterwards, so the NPC can congratulate the player. An `ifQuestReady` + `completeQuest` option is for quests with no `turnIn` NPC (or a different one).

**`RPG.dialogues.define(id, {...})`**: `{ start: "start", speaker, nodes: { id: node } }`
- A node is `{ text, speaker, options: [...], onEnter(player) }`. `text` can be `fn(player)`.
- An option is `{ text, next, action(player), startQuest, completeQuest, openShop, openDialogue }`, plus visibility filters `ifQuestAvailable`, `ifQuestActive`, `ifQuestReady`, `ifQuestDone`, `ifQuestNotDone`, `minLevel`, `condition(player)`.
- An option without `next` closes the dialogue. `action` may return a node id to jump to.
- Open a dialogue from code with `player.openDialogue(id)`.

### 9.13 Shops: `RPG.shops.define(id, {...})`
`{ name, items: [{ item, count, buy, sell, levelReq, onBuy(player, qty) }] }`. Leave out `buy` or `sell` (or set it to 0) to disable that direction. Open a shop with an NPC's `shop`, a dialogue option's `openShop`, or `player.openShop(id)`.

### 9.14 Loot: `RPG.loot`
- `RPG.loot.add(entity, { item, count, chance, money, xp, condition(killer, victim), onDrop(killer, victim) })`. `entity` can be `"minecraft:zombie"`, `"#minecraft:undead"`, `"*"` or an NPC id. `count` and `money` can be `[min, max]`.
- `RPG.loot.xp(entity, amount)` sets a fixed kill XP for that entity type.

### 9.15 Mobs: `RPG.mobs.define(id, {...})`
New creatures drawn with a GeckoLib model.
| Field | Meaning |
|---|---|
| `name`, `geo`, `scale` | Look |
| `health`, `damage`, `armor`, `speed`, `followRange` | Stats |
| `hostile` (true) | `false` = only fights back |
| `attackRange` | Melee reach |
| `xp` | Kill XP |
| `loot` | `[{ item, count, chance }]` |
| `persistent` | Never despawns |
| `onTick(mob, seconds)`, `onHurt(mob, attacker)`, `onDeath(mob, killer)` | |

Spawn with `/rpg mob <id>`, `RPG.world.spawnMob(dim, id, x, y, z)`, a spawn rule (`mob:`), or a boss (`mob:`).

### 9.16 Bosses: `RPG.bosses.define(id, {...})`
| Field | Meaning |
|---|---|
| `mob` or `entity` | The body: one of your mobs, or any entity id |
| `name`, `showName`, `health`, `damage`, `armor`, `speed`, `knockbackResistance`, `followRange`, `equipment` (`{ mainhand, offhand, head, chest, legs, feet }`), `tags` | |
| `showBossBar` (true), `bossBar: { color, style, darkenScreen, music }`, `range` (64) | Boss bar. Colours: pink blue red green yellow purple white. Styles: progress notched_6 notched_10 notched_12 notched_20 |
| `announce`, `deathMessage` | Broadcasts |
| `xp`, `money` (a number), `tp`, `statPoints`, `skillPoints`, `items`, `skills`, `effects`, `commands` | Rewards for **every** player who hurt it |
| `loot` | `[{ item, count, chance }]` per player |
| `phases` | `[{ at: 0.5, message, onEnter(boss) }]`. Each one triggers once when health drops to that fraction |
| `onSpawn(boss)`, `onTick(boss, seconds, phase)`, `onDeath(boss, killer)` | |

Bosses survive restarts. Spawn one with `/rpg boss <id>`, `entity.spawnBoss(id)`, or a spawn rule (`boss:`).

### 9.17 Spawns: `RPG.spawns.define(id, {...})`
| Field | Meaning |
|---|---|
| `mob` / `entity` / `boss` / `npc` | What to spawn |
| `name`, `health`, `damage`, `armor`, `speed`, `equipment`, `tags`... | Overrides (like bosses) |
| `dimensions`, `biomes` | Lists of ids or `#tags` |
| `interval` (200), `chance` (0.25) | Checked every interval, per player |
| `group` (`[min, max]`), `maxNearby` (6), `countRange` (64) | |
| `minDistance` (24), `maxDistance` (48), `placement` (`surface` / `near_player`) | |
| `time` (`day` `night` `any`), `light` (`dark` `bright` `any`) | |
| `minLevel`, `maxLevel` | Player level range |
| `levelScaling` | +x health/damage per player level |
| `persistent`, `enabled` | |
| `condition(player)`, `onSpawn(entity, player)` | |

### 9.18 Random events: `RPG.randomEvents`
`define(id, { name, weight, duration, cooldown, minPlayers, announce, endMessage, condition(), onStart(players), onTick(players, tick), onPlayerTick(player, tick), onEnd(players) })`, plus `start(id)`, `stop(id)`, `isActive(id)` and `configure({...})`. `onTick` runs once a second, and `tick` counts ticks since the start.

### 9.19 Commands: `RPG.commands.register(name, ...)`
```js
RPG.commands.register("hello", (player, args) => player.tell("Hi " + args.join(" ")));
RPG.commands.register("heal", { description: "Heal someone", permission: 2,
    run(player, args) { let p = RPG.player(args[0]); if (p) p.heal(100); } });
```
Players type `/rpgc hello world`. `args` is a list of words. `player` is `null` when the command comes from the console. `permission` is the vanilla op level (0 = everyone).

### 9.20 Dimensions: `RPG.dimensions.define(id, {...})`

> **Dimensions: one warning.** Minecraft stores the list of dimensions inside each world. If you delete or rename a dimension's files in `datapack/` (or the whole project folder) after a world has used it, that world will refuse to open until the files are back. Removing `RPG.dimensions.define(...)` from a script is safe: the files stay. Opening a world with custom dimensions also shows Minecraft's one-time "experimental settings" notice; that is normal.

Creates `ragnarok_rpg:<id>`. **Restart the world once** after a change.
| Field | Meaning |
|---|---|
| `generator` | `normal` `nether` `end` `caves` `floating_islands` `flat` `void` |
| `layers` | Flat only: `[{ block, height }]` from the bottom up |
| `biome` | One biome everywhere |
| `effects` | Sky: `minecraft:overworld`, `minecraft:the_nether`, `minecraft:the_end` |
| `fixedTime` (6000 = noon), `ambientLight` (0-1), `hasSkylight`, `hasCeiling`, `ultrawarm`, `bedWorks`, `respawnAnchorWorks`, `piglinSafe`, `hasRaids`, `natural`, `coordinateScale`, `monsterSpawnLight` | Dimension type |
| `minY`, `height`, `logicalHeight` | World height |
| `features`, `noiseSettings` | Advanced |

Travel there with `player.teleportTo("ragnarok_rpg:<id>", x, y, z)`.

### 9.21 Structures: `RPG.structures`
1. Save a build with a structure block.
2. Copy the `.nbt` file to `datapack/data/<namespace>/structures/`.
3. Then use either:
   - `RPG.structures.place(dimension, "ns:name", x, y, z, rotation)` to place it now (rotation 0/90/180/270), or
   - `RPG.structures.define(id, { template, biomes, spacing (32), separation (8), step, terrainAdaptation, heightmap, yOffset })` to make it generate in **new** chunks after one restart.

### 9.22 Projectiles: `RPG.projectiles.define(id, {...})`
Fire one with **`entity.shoot(id, overrides)`** from any player, mob or boss: it leaves the eyes along the look direction.
| Field | Meaning |
|---|---|
| `shape` | `ball`, `beam` (thick, from the hands), `laser` (thin beam), `disk` (spinning), `sprite` (a picture facing the camera), `item` (an item model) |
| `colors: { core, border, outline }` (or `color`) | Three glowing shells, inside to outside. Sprites are tinted with `core` |
| `size`, `speed` (blocks/tick), `gravity`, `lifetime` (100) | Flight |
| `damage` (number or `fn(owner, target)`), `pierce`, `knockback`, `explode: { power, breakBlocks }` | Hits |
| `particles` | A vanilla particle id as a trail |
| `texture`, `spin` / `item` | For the `sprite` / `item` shapes |
| `length` (30), `charge`, `duration` (60), `hitInterval` (5) | Beams and lasers: they stay in the caster's hands and follow their aim; `charge` shows a growing orb first |
| `onHit(owner, target, x, y, z)`, `onTick(owner, age)` | `target` is `null` on a block hit; `onTick` runs every 5 ticks |

`overrides` change any field for one shot: `player.shoot("ki_blast", { damage: 12, size: 0.8, colors: { border: "#FF0000" } })`. Pass `null` for none. The starter computes damage from stats and passes it this way.

### 9.23 Keys: `RPG.keys.define(n, {...})`
Every player has 20 action keys (Options > Controls > "Ragnarok RPG"). Keys 1-8 cast skill-bar slots 1-8 unless you define them.
| Field | Meaning |
|---|---|
| `name` | Shown in Controls |
| `onPress(player)`, `onRelease(player, heldTicks)` | Key down / up |
| `onHold(player, ticks)`, `holdInterval` (1) | Repeats while held |

Default bindings follow DMZ: Alt+1..4 (1-4), Ctrl+1..4 (5-8), C (9), V (10), R (11), G (12), Z (13), H (14), 15-20 unbound. The `keyPress` / `keyRelease` events fire for every key.

**Flight note:** the engine has no flight switch. The starter's V key builds flight from vanilla potions (Levitation 255 hovers, Slow Falling lands softly) with G/H to descend/rise and R to dash. It works anywhere, but you can't hold Space to climb.

### 9.24 `RPG.server` and `RPG.world`
**`RPG.server`**: `players()`, `player(name)`, `broadcast(msg)`, `runCommand(cmd)` (runs as the console), `getTick()`, `getData(key, fallback)` / `setData(key, value)` (project-wide values saved with the world).

**`RPG.world`**: every method takes the dimension first. Pass `player.dimension`, or `""` for the overworld.
| Method | |
|---|---|
| `particle(dim, type, x, y, z, count, spread, speed)` | Simple particles: `minecraft:flame`, `end_rod`, `cloud`, `crit`, `heart`, `explosion`, `soul_fire_flame`, `electric_spark`, `happy_villager`... |
| `particleLine(dim, type, x1, y1, z1, x2, y2, z2, step)` | Beams |
| `sound(dim, id, x, y, z, volume, pitch)` | |
| `explode(dim, x, y, z, power, breakBlocks)` | |
| `lightning(dim, x, y, z, visualOnly)` | |
| `spawn(dim, type, x, y, z)` / `spawnNpc(dim, id, ...)` / `spawnMob(dim, id, ...)` | Each returns the entity |
| `setBlock(dim, x, y, z, blockId)` / `getBlock(dim, x, y, z)` | |
| `getTime(dim)` | Day time |

---

## 10. Events

`RPG.on(name, fn)`. Several handlers can hook the same event, and they run in the order they were added. Where an event can change a value, return the new value, or return nothing to leave it unchanged.

| Event | Arguments | Notes |
|---|---|---|
| `playerJoin` | `(player)` | Every login |
| `firstJoin` | `(player)` | The first time this player is seen in this project |
| `playerLeave` | `(player)` | |
| `respawn` | `(player)` | |
| `playerTick` | `(player)` | Once a second per player |
| `serverTick` | `()` | Once a second |
| `levelUp` | `(player, level)` | |
| `xpGain` | `(player, amount, source)` | Return a number to change it |
| `tpGain` | `(player, amount, source)` | Return a number to change it. Sources: `hit`, `kill`, `time`, `hurt`, `boss`, `script`. Only the first handler that returns a number counts, so keep multipliers in one handler |
| `kill` | `(player, victim)` | The player killed something (bosses: every damager) |
| `death` | `(player, killer)` | `killer` may be `null` |
| `attack` | `(event)` | The player deals damage. Set `event.amount`, `event.crit`, or call `event.cancel()` |
| `hurt` | `(event)` | The player takes damage. Same as `attack` |
| `skillCast` | `(player, skillId, level)` | Return `false` to block |
| `skillLevelUp` | `(player, skillId, level)` | Mastery level up |
| `itemUse` | `(player, itemId)` | Return `false` to block. `itemId` is the placeholder id (`item_0042`); compare with `RPG.items.id("senzu_bean")` |
| `questStart`, `questComplete` | `(player, questId)` | |
| `classChange`, `raceChange` | `(player, newId, oldId)` | |
| `statAllocate` | `(player, statId, points)` | Stats bought in the menu |
| `npcInteract` | `(player, npc, npcId)` | Return `false` to block the dialogue/shop |
| `shopBuy` | `(player, shopId, item, count, price)` | Return `false` to block |
| `shopSell` | `(player, shopId, item, count, price)` | |
| `chat` | `(player, message)` | Return `false` to hide the message |
| `bossSpawn`, `bossDeath` | `(boss, bossId)` | |
| `enemySpawn` | `(entity, spawnId, player)` | From spawn rules |
| `randomEventStart`, `randomEventEnd` | `(eventId)` | |
| `keyPress` | `(player, key)` | An action key (1-20) went down. Return `false` to stop its `onPress` / skill-bar cast |
| `keyRelease` | `(player, key, heldTicks)` | |
| `reload` | `()` | After every load |

---

## 11. Overrides

`RPG.override(name, fn)` replaces a built-in formula. Your function gets the normal arguments **plus the built-in result as the last argument**, and returns the value to use. Only one override per name is allowed: the last one set wins. Pass `null` to restore the built-in.

```js
// Double XP on weekends... or always:
RPG.override("killXp", (player, victim, builtIn) => builtIn * 2);
```

| Name | Arguments | Return |
|---|---|---|
| `killXp` | `(player, victim, builtIn)` | Kill XP |
| `killTp` | `(player, victim, builtIn)` | Kill TP (before multipliers) |
| `tpGain` | `(player, rawAmount, source, builtIn)` | TP after multipliers (the `tpGain` event runs after this) |
| `statCost` | `(player, statId, alreadyBought, builtIn)` | Price of the next stat point |
| `xpForLevel` | `(level, builtIn)` | XP needed for the next level |
| `statPointsPerLevel`, `skillPointsPerLevel` | `(player, level, builtIn)` | Points per level up |
| `levelUp` | `(player, level)` | Replaces what a level up gives. Return `false` to let the built-in run too |
| `damage` | `(event, builtIn)` | Damage a player deals |
| `damageTaken` | `(event, builtIn)` | Damage a player takes |
| `critChance` | `(player, builtIn)` | 0-1 |
| `regen` | `(player, resourceId, builtIn)` | Resource regen per tick interval |
| `skillCooldown` | `(player, skillId, level, builtIn)` | Ticks |
| `skillXp` | `(player, skillId, level, builtIn)` | Mastery XP per cast |
| `lootChance` | `(player, victim, item, builtIn)` | 0-1 |
| `pickRandomEvent` | `(players)` | An event id to start, or nothing. Replaces the whole roll |
| `appearance` | `(player, builtIn)` | Which definition gives the look: `"effect:id"`, `"class:id"`, `"race:id"` or `""` |

---

## 12. Player and entity methods

Getters also work as properties: `player.name`, `player.level`, `entity.health`, `player.x`.

### Every living entity (mobs, NPCs, bosses, players)
| Method | |
|---|---|
| `name`, `type`, `uuid`, `x`, `y`, `z`, `yaw`, `pitch`, `dimension`, `rpgId` | Read-only info (`rpgId` = the mob/NPC/boss script id) |
| `health` / `setHealth(v)`, `maxHealth` | |
| `isPlayer()`, `asPlayer()`, `isAlive()` | |
| `heal(n)`, `damage(n)`, `damageFrom(n, attacker)`, `kill()` | `damageFrom` credits the attacker |
| `teleport(x, y, z)`, `teleportTo(dimension, x, y, z)` | |
| `push(x, y, z)`, `dash(strength)` | Movement |
| `setFire(seconds)`, `addPotion(id, ticks, amplifier)`, `removePotion(id)` | |
| `nearby(radius)`, `distanceTo(other)` | |
| `hasTag(t)`, `addTag(t)`, `removeTag(t)` | Remember things about one entity |
| `spawnBoss(bossId)` | Spawn a boss here |
| `playAnimation(name)` | Mobs/NPCs: once, from their geo animation file. Players: from their avatar, for 20 ticks |
| `shoot(projectileId, overrides)` | Fire one of `RPG.projectiles` (section 9.22) |

### Players (everything above, plus)
| Group | Methods |
|---|---|
| Level | `getLevel()`, `setLevel(n)`, `getXp()`, `getXpToNext()`, `addXp(n)`, `getStatPoints()`/`setStatPoints(n)`, `getSkillPoints()`/`setSkillPoints(n)` |
| Stats | `stat(id)` (final value), `allocated(id)` (bought), `addStat(id, n)` (free, permanent) |
| Resources | `resource(id)`, `maxResource(id)`, `setResource(id, v)`, `addResource(id, n)`, `consume(id, n)` (false if not enough) |
| Money | `getMoney()`, `setMoney(n)`, `addMoney(n)`, `takeMoney(n)` (false if not enough) |
| TP | `getTp()`, `setTp(n)`, `addTp(n)` (uses multipliers and hooks), `statCost(statId)` |
| Class/race | `getPlayerClass()`, `setPlayerClass(id)`, `getRace()`, `setRace(id)` |
| Skills | `hasSkill(id)`, `skillLevel(id)`, `learnSkill(id)`, `setSkillLevel(id, n)`, `forgetSkill(id)`, `castSkill(id)`, `resetCooldown(id)`, `cooldownLeft(id)`, `skillXp(id)`, `addSkillXp(id, n)` |
| Effects | `addEffect(id, ticks)` (-1 = forever), `addEffectStacks(id, ticks, stacks)`, `removeEffect(id)`, `hasEffect(id)`, `effectStacks(id)` |
| Quests | `startQuest(id)`, `completeQuest(id)`, `abandonQuest(id)`, `isQuestActive(id)`, `isQuestDone(id)`, `progressQuest(key, n)` |
| Items | `giveItem(ref, count)`, `countItem(ref)`, `hasItem(ref, count)`, `takeItem(ref, count)`, `getHeldItem()` |
| Messages | `tell(msg)`, `actionbar(msg)`, `title(title, subtitle)`, `playSound(id, volume, pitch)` (registered sounds only, see section 13), `sendMessage(msg)` (no colours) |
| UI | `openDialogue(id)`, `openShop(id)`, `hudText(id, text, x, y, anchor, color)`, `clearHudText(id)` |
| Look | `setColor(name, "#hex")` / `getColor(name)` (avatar colours, saved), `playAnimationFor(name, ticks)` (0 = loop), `stopAnimation()` |
| Targeting | `target(range)` (entity under the crosshair), `lookBlock(range)` (`[x, y, z]`) |
| Other | `runCommand(cmd)` (with op rights), `partyMembers()`, `isOp()`, `getVar(key, fallback)` / `setVar(key, value)` (saved per player) |

---

## 13. JavaScript tips and gotchas

The scripts run in **Mozilla Rhino**, which supports most of modern JavaScript, with some gaps:

| Works | Doesn't work |
|---|---|
| `let`, `var`, top-level `const` | `const` **inside functions**. Use `let` (Rhino treats it as one function-wide constant) |
| Arrow functions `(x) => x * 2` | Default parameters `function f(a, b = 1)`. Write `b = b === undefined ? 1 : b` instead |
| Template strings `` `Hi ${name}` `` | Spread `...args`, destructuring in parameters |
| Method shorthand `onCast(ctx) { }` | `?.` and `??` |
| `for (let x of list)`, `forEach`, `map`, `filter`, `includes` | `for (const x of list)`, `class`, `import`/`export`, `async`/`await` |

More things to watch for:
- **Loops and timers:** inside a `for (let i...)` loop, every scheduled function sees the *last* `i`. Use `list.forEach((x) => RPG.schedule(...))` instead.
- **Lists in definitions:** write every entry the same way, either all `"names"` or all `{ item, count }` objects. A list that mixes the two is turned into text and stops working.
- **Saving data:** plain JS variables are lost on `/rpg reload` and on restart. Use `player.setVar` / `getVar` for per-player data and `RPG.server.setData` / `getData` for project-wide data.
- **Resource-pack sounds:** `playSound` and `RPG.world.sound` only find sounds a mod registered. Sounds that exist only in a resource pack (all of `dmzpack`) are played by id with `/playsound`; the starter's `sfx(where, "ki_kame_fire", volume, pitch)` in `01_toolbox.js` does that for you.
- **Wearing gear:** scripts can't read armour slots directly. Give the item a hidden "marker" stat (`stats: { weight: 1 }`) and check `player.stat("weight") > 0`; stats only count while the item is in its slot.
- **Ticks vs seconds:** `cooldown`, `duration`, `RPG.schedule` and `addEffect` all use ticks. 20 ticks = 1 second.

---

## 14. Troubleshooting

| Problem | Fix |
|---|---|
| "My change didn't show up" | Did you save and run `/rpg reload`? Check `/rpg errors` |
| An item shows as "Unconfigured placeholder" | Its `define` failed or was removed. Check `/rpg errors` |
| An item or block looks like a purple/black cube | The `model` path is wrong. `"dmzpack:rpg/item/x"` needs `assets/dmzpack/models/rpg/item/x.json` |
| An NPC or mob is invisible or broken | Check the `geo` paths. Animation names must exist in the animation file |
| The dimension doesn't exist | Restart the world/server once after defining it |
| A skill does nothing | `onCast` returned `false`, or the player lacks the resource. Look at the action bar message |
| Items got swapped around | Never delete `item_ids.json`. It remembers which slot each name uses |
| "Script ran longer than 2000 ms" | An infinite loop. Check your `while`/`for` loops |
| A pack sound doesn't play | `player.playSound` only knows registered sounds. Use `sfx()` from `01_toolbox.js` (a `/playsound` command) for resource-pack sounds |
| A player is invisible | Their avatar's `model` path is wrong, or every layer texture is missing. Check the paths against `dmzpack_catalog.json` |
| An avatar animation doesn't play | The name must exist in the avatar's `animation` or `animations` files |

---

## 15. Make a different game

Nothing above is Dragon Ball specific. "Ki" is a resource, "Super Saiyan" is an effect with an avatar, a Kamehameha is a projectile with an animation. Two sketches (the `zelda:` / `fps:` art would be yours, in `resources/`):

**A Zelda-style adventure:**
```js
RPG.leveling.configure({ mode: "levels", maxLevel: 1, defaultRace: "hylian" });   // no levels: hearts and gear
RPG.ui.configure({ chooseRaceOnJoin: false, chooseClassOnJoin: false, hud: { primary: "stamina", showXp: false, showTp: false } });
RPG.resources.define("stamina", { name: "Stamina", color: "#7CFC00", max: 100, regen: 25, hud: "primary" });
RPG.races.define("hylian", { name: "Hylian", selectable: false,
    avatar: { model: "zelda:geo/link.geo.json",
              layers: [{ texture: "zelda:textures/link_tunic.png", color: "tunic" }, { texture: "zelda:textures/link_skin.png" }],
              colors: { tunic: "#2E8B57" },             // the Blue Ring: player.setColor("tunic", "#3050C0")
              animation: "zelda:animations/link.animation.json",
              states: { idle: "idle", walk: "walk", run: "run", attack: "slash" } } });
RPG.items.define("heart_container", { name: "Heart Container", model: "zelda:rpg/item/heart", type: "consumable",
    onUse(p) { p.addStat("vitality", 2); p.heal(4); } });       // +1 heart per container
RPG.projectiles.define("sword_beam", { shape: "sprite", texture: "zelda:textures/beam.png", size: 1, speed: 1.6, damage: 6 });
RPG.items.define("master_sword", { name: "Master Sword", model: "zelda:rpg/item/master_sword", type: "weapon", damage: 8,
    onHit(p, t) { if (p.health >= p.maxHealth) p.shoot("sword_beam", null); } });   // full hearts: sword beams
RPG.effects.define("shielding", { hidden: true });            // the hurt hook halves damage while it's on
RPG.keys.define(9, { name: "Shield", onPress(p) { p.addEffect("shielding", -1); p.playAnimationFor("shield", 0); },
    onRelease(p) { p.removeEffect("shielding"); p.stopAnimation(); } });
RPG.keys.define(13, { name: "Z-Target", onPress(p) { let t = p.target(24); if (t) p.setVar("lock", t.uuid); } });
```

**A shooter:**
```js
RPG.resources.define("ammo", { name: "Ammo", color: "#FFD27F", max: 30, regen: 0, hud: "primary" });
RPG.projectiles.define("rifle_round", { shape: "ball", size: 0.12, speed: 4, lifetime: 30, damage: 6,
    colors: { core: "#FFFFE0", border: "#FFB000", outline: "#804000" } });
RPG.projectiles.define("grenade", { shape: "item", item: "minecraft:fire_charge", speed: 0.8, gravity: 0.05, damage: 2,
    explode: { power: 2.5, breakBlocks: false } });
RPG.items.define("rifle", { name: "Rifle", model: "fps:rpg/item/rifle", type: "weapon", cooldown: 3,
    onUse(p) { if (!p.consume("ammo", 1)) { p.actionbar("&cReload! (R)"); return false; } p.shoot("rifle_round", null); } });
RPG.keys.define(11, { name: "Reload", onPress(p) {
    p.playAnimationFor("reload", 30);
    RPG.schedule(30, () => p.setResource("ammo", p.maxResource("ammo")));
} });
RPG.keys.define(12, { name: "Grenade", onPress(p) { p.shoot("grenade", null); } });
RPG.keys.define(10, { name: "Sprint", onHold(p) { p.addPotion("minecraft:speed", 5, 1); } });
```

Have fun, and happy training! Ho ho!
