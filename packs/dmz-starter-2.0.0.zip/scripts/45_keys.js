// =====================================================================================
//  45_keys.js - DMZ controls: charge ki, fly, dash, lock on
// =====================================================================================
//  Every player has 20 action keys (Options > Controls > "Ragnarok RPG"). Keys 1-8 cast
//  the skill bar unless you define them. The defaults follow DMZ:
//      1-4 Alt+1..4   5-8 Ctrl+1..4   9 C   10 V   11 R   12 G   13 Z   14 H   15-20 unbound
//
//  RPG.keys.define(n, {
//      name: "Charge Ki",                     shown in Controls and on the HUD
//      onPress(player)                        key went down
//      onHold(player, ticksHeld)              every holdInterval ticks while held
//      holdInterval: 5,
//      onRelease(player, ticksHeld)           key came up
//  })
//  Events keyPress(player, key) / keyRelease(player, key, ticks) fire for every key too.
//
//  A shooter would make key 9 "Reload" and key 11 "Sprint"; Zelda would make key 9
//  "Shield" and key 13 "Z-target". Nothing below is special to the engine.
// =====================================================================================

// ---- C: Charge Ki (hold) ---------------------------------------------------------------
// While held: the charge pose, your aura (in your own "aura" colour) and fast ki refill.
RPG.effects.define("ki_charge", {
    name: "&bCharging",
    color: "#7FFFFF",
    hidden: true,                                   // not listed on the HUD
    // color "aura" = the player's own aura colour (/rpgc color aura #FF0000)
    aura: { texture: AURA_KAKAROT, frames: 4, speed: 10, color: "aura", scale: 1.0, alpha: 0.75 },
    attributes: { "minecraft:generic.movement_speed": { amount: -0.6, operation: "multiply_total" } }
});

RPG.keys.define(9, {
    name: "Charge Ki",
    holdInterval: 5,
    onPress(player) {
        player.addEffect("ki_charge", -1);
        player.playAnimationFor(chargeAnimation(player), 0);      // loop until release
        sfx(player, "aura_start", 1, 1);
    },
    onHold(player, ticks) {
        // +4% of max ki every 5 ticks (about a full bar in 6 seconds), plus Energy
        player.addResource("ki", player.maxResource("ki") * 0.04 + player.stat("energy") * 0.05);
        if (ticks % 45 === 0) sfx(player, "ki_charge_loop", 0.7, 1);
        if (ticks % 10 === 0) burst(player, "minecraft:electric_spark", 4, 0.5, 0.05);
        if (ticks % 100 === 0) player.addTp(1);                     // charging is training too
        let pct = Math.floor(player.resource("ki") / Math.max(1, player.maxResource("ki")) * 100);
        player.actionbar("&bKi " + pct + "%" + (pct >= 100 ? " &e&lMAX" : ""));
        if (pct >= 100 && ticks % 20 === 0) { act(player, "base.ki_overcharge", 20); player.progressQuest("charge_ki", 1); }
    },
    onRelease(player, ticks) {
        player.removeEffect("ki_charge");
        resumeHeld(player);
    }
});

// ---- V: Fly (toggle) -------------------------------------------------------------------
// The engine has no flight switch, so flight is built from vanilla potions:
//   Levitation 255 = hover in place (a well-known Minecraft trick), Slow Falling = safe landing.
// G descends, H rises, R dashes forward. It costs stamina, then ki.
// (Honest note: it's an approximation - you can't hold Space to climb like DMZ.)
RPG.effects.define("flight", {
    name: "&fFlying",
    color: "#E0F0FF",
    tickInterval: 5,
    attributes: { "minecraft:generic.movement_speed": { amount: 0.5, operation: "multiply_total" } },
    onApply(player, stacks) {
        player.playAnimationFor("base.fly_idle", 0);
        sfx(player, "aura_start", 0.6, 1.3);
    },
    onTick(player, stacks) {
        let mode = player.getVar("fly_mode", "hover");          // hover | up | down
        if (mode === "down") {
            player.removePotion("minecraft:levitation");
            player.addPotion("minecraft:slow_falling", 10, 0);
        } else {
            player.addPotion("minecraft:levitation", 10, mode === "up" ? 3 : 255);
        }
        player.addPotion("minecraft:slow_falling", 10, 0);
        // drain: stamina first, then ki; land when both run out
        if (RPG.server.getTick() % 20 < 5 && !player.consume("stamina", 2) && !player.consume("ki", 2)) {
            player.removeEffect("flight");
            player.actionbar("&cToo tired to fly!");
        }
    },
    onRemove(player, stacks) {
        player.removePotion("minecraft:levitation");
        player.addPotion("minecraft:slow_falling", 80, 0);       // float down gently
        player.setVar("fly_mode", "hover");
        player.setVar("fly_fast", 0);
        resumeHeld(player);
    }
});

RPG.keys.define(10, {
    name: "Fly",
    onPress(player) {
        if (player.hasEffect("flight")) {
            player.removeEffect("flight");
            player.actionbar("&7You land.");
            return;
        }
        if (player.getLevel() < 3) { player.actionbar("&7Reach level 3 to learn to fly (Bukujutsu)."); return; }
        player.push(0, 0.6, 0);                                  // take off
        player.addEffect("flight", -1);
        player.progressQuest("fly", 1);
        player.actionbar("&fFlying &7- G down, H up, R dash, V land");
    }
});

// ---- R: Dash ---------------------------------------------------------------------------
// On the ground: a dash in the direction you look. Flying: a burst of full-speed flight.
// Locked on (Z): dash straight at your target.
RPG.keys.define(11, {
    name: "Dash",
    onPress(player) {
        if (!player.consume("stamina", 10)) { player.actionbar("&cNo stamina!"); return; }
        let target = lockedTarget(player);
        if (target) pushToward(player, target, 2.2);
        else player.dash(player.hasEffect("flight") ? 2.4 : 1.6);
        if (player.hasEffect("flight")) {
            player.setVar("fly_fast", 1);
            act(player, "base.fly_fast", 20);
            RPG.schedule(20, () => player.setVar("fly_fast", 0));
        } else {
            act(player, "base.dash_front", 10);
        }
        sfx(player, "evasion1", 0.8, 1.1);
        burst(player, "minecraft:cloud", 10, 0.3, 0.05);
    }
});

// ---- G: Descend (flying) / Meditate (on the ground) -----------------------------------
RPG.effects.define("meditating", {
    name: "&3Meditating",
    color: "#5FA8D3",
    hidden: true,
    attributes: { "minecraft:generic.movement_speed": { amount: -0.9, operation: "multiply_total" } }
});

RPG.keys.define(12, {
    name: "Descend / Meditate",
    holdInterval: 20,
    onPress(player) {
        if (player.hasEffect("flight")) { player.setVar("fly_mode", "down"); return; }
        player.addEffect("meditating", -1);
        player.playAnimationFor("base.meditation", 0);
    },
    onHold(player, ticks) {
        if (!player.hasEffect("meditating") || ticks === 0) return;
        player.addResource("ki", player.maxResource("ki") * 0.02);
        player.addResource("stamina", player.maxResource("stamina") * 0.05);
        if (ticks % 100 === 0) { player.addTp(2 + Math.floor(player.getLevel() / 10)); player.progressQuest("meditate", 1); }
        burst(player, "minecraft:enchant", 6, 0.6, 0.3);
    },
    onRelease(player, ticks) {
        if (player.hasEffect("flight")) { player.setVar("fly_mode", "hover"); return; }
        player.removeEffect("meditating");
        resumeHeld(player);
    }
});

// ---- Z: Lock on ------------------------------------------------------------------------
// Press while looking at something: remember it (techniques aim at it, R dashes to it).
// Press again to release. The HUD shows the target's power level (10_stats.js).
RPG.keys.define(13, {
    name: "Lock On",
    onPress(player) {
        if (player.getVar("lock_uuid", "")) {
            player.setVar("lock_uuid", null);
            player.clearHudText("lock");
            player.actionbar("&7Lock released.");
            return;
        }
        let t = player.target(40);
        if (!t) { player.actionbar("&7Nothing to lock on to."); return; }
        player.setVar("lock_uuid", t.uuid);
        sfx(player, "lockon", 0.8, 1);
        showLock(player, t);
    }
});

function showLock(player, t) {
    player.hudText("lock", "&c◎ &f" + t.name + " &7PL &e" + grouped(powerLevel(t)), 0, 40, "top", 0xFFFFFF);
}

// Refresh the lock-on readout once a second, and drop it when the target is gone.
RPG.on("playerTick", (player) => {
    if (!player.getVar("lock_uuid", "")) return;
    let t = lockedTarget(player);
    if (!t || !t.isAlive()) {
        player.setVar("lock_uuid", null);
        player.clearHudText("lock");
        return;
    }
    showLock(player, t);
});

// ---- H: Ascend (flying) / Super Jump ---------------------------------------------------
RPG.keys.define(14, {
    name: "Ascend / Super Jump",
    onPress(player) {
        if (player.hasEffect("flight")) { player.setVar("fly_mode", "up"); return; }
        if (!player.consume("stamina", 8)) return;
        player.push(0, 1.1, 0);
        act(player, "base.jump", 15);
        sfx(player, "evasion2", 0.7, 1);
    },
    onRelease(player, ticks) {
        if (player.hasEffect("flight")) player.setVar("fly_mode", "hover");
    }
});

// ---- 15 (unbound): Guard (hold) ----------------------------------------------------------
// Bind it in Controls. While held you block: 60% less damage, but you can't move much.
RPG.effects.define("guarding", {
    name: "&7Guard",
    color: "#AAAAAA",
    hidden: true,
    attributes: { "minecraft:generic.movement_speed": { amount: -0.7, operation: "multiply_total" } }
});

RPG.keys.define(15, {
    name: "Guard",
    onPress(player) {
        player.addEffect("guarding", -1);
        player.playAnimationFor("base.block", 0);
        sfx(player, "block1", 0.6, 1);
    },
    onRelease(player, ticks) {
        player.removeEffect("guarding");
        sfx(player, "unblock", 0.5, 1);
        resumeHeld(player);
    }
});

// ---- 16 (unbound): Power Strike (hold to charge, release to hit) -------------------------
RPG.keys.define(16, {
    name: "Power Strike",
    onPress(player) {
        player.playAnimationFor("base.charge_heavy_punch", 0);
    },
    onRelease(player, ticks) {
        let power = Math.min(3, ticks / 20);                     // up to 3 seconds of charge
        act(player, "base.charge_heavy_punch_fire", 12);
        let t = player.target(4);
        if (!t || !player.consume("stamina", 5 + power * 5)) return;
        t.damageFrom(strikeDamage(player, 4, 0.4, 1, 0) * (1 + power), player);
        knockAway(player, t, 0.6 + power * 0.6, 0.3);
        sfx(t, power >= 2 ? "critic_punch2" : "fist_punch", 1, 1);
        burst(t, "minecraft:crit", 10 + power * 5, 0.3, 0.2);
    }
});
