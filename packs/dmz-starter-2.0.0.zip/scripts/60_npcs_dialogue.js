// =====================================================================================
//  60_npcs_dialogue.js - the masters, the townsfolk, the dragons
// =====================================================================================
//  Place an NPC where you stand:  /rpg npc master_roshi     (remove it: kill it in creative)
//  NPC fields: name, dialogue, shop, geo (a GeckoLib model) or skin (a player skin),
//  wander, invulnerable (default true), scale, showName, onInteract(player, npc).
//  Talking to an NPC first hands in any finished quest whose turnIn is that NPC.
//
//  Dialogue = nodes; each node has text and options. An option can:
//    next: "node"           go to another node (no next = close)
//    startQuest / completeQuest / openShop / openDialogue
//    action(player)         run code (return a node id to jump there)
//  and only show up when:   ifQuestAvailable / ifQuestActive / ifQuestReady / ifQuestDone /
//                           ifQuestNotDone / minLevel / condition(player)
//  "&" colour codes work everywhere: &a green, &e yellow, &c red, &l bold...
//
//  In DMZ the masters teach techniques. teacher() below builds a master's whole dialogue
//  from a list of lessons, so adding a master is one short block.
// =====================================================================================

// ---- Looks ---------------------------------------------------------------------------
// Every DMZ master shares one animation file (idle, walk, and a few personal idles).
function masterLook(name, idle) {
    return {
        model: DMZ_GEO + "master/master_" + name + ".geo.json",
        texture: DMZ_TEX + "master/master_" + name + ".png",
        animation: DMZ_ANIM + "master/masters.animation.json",
        idle: idle || "idle",
        walk: "walk"
    };
}

// The saga characters share saga_base.animation.json (63 animations: idle, walk, attack1_1...).
function sagaLook(model, texture, scale) {
    return {
        model: DMZ_GEO + "sagas/" + model + ".geo.json",
        texture: DMZ_TEX + "sagas/" + (texture || model) + ".png",
        animation: DMZ_ANIM + "sagas/saga_base.animation.json",
        idle: "idle", walk: "walk", attack: "attack1_1",
        scale: scale || 1.0
    };
}

// ---- teacher(npcId, {...}) --------------------------------------------------------------
//   name, look, greeting (text or fn(player)), lessons: [{ skill, price, level, race }],
//   options: extra dialogue options shown before the lessons, nodes: extra nodes, shop.
function teacher(npcId, spec) {
    let options = (spec.options || []).slice();
    spec.lessons.forEach((l) => {
        options.push({
            text: "Teach me " + RPG.skills.name(l.skill) + (l.price > 0 ? " (" + grouped(l.price) + " Zeni)" : "") + (l.race ? " &7[" + RPG.races.name(l.race) + "]" : ""),
            minLevel: l.level || 1,
            condition: (p) => !p.hasSkill(l.skill) && (!l.race || p.getRace() === l.race),
            action: (p) => teach(p, l.skill, l.price)
        });
    });
    if (spec.shop) options.push({ text: "Show me what you sell.", openShop: spec.shop });
    options.push({ text: "Goodbye." });

    let nodes = {
        start: { text: spec.greeting, options: options },
        learned: { text: spec.learned || "Put it on your skill bar (K > Techniques) and practise. It grows stronger every time you use it!", options: [{ text: "Thank you, Master!" }] },
        broke: { text: spec.broke || "Training isn't free. Come back when you have the Zeni.", options: [{ text: "...", next: "start" }] }
    };
    for (let k in (spec.nodes || {})) nodes[k] = spec.nodes[k];
    RPG.dialogues.define(npcId, { start: "start", nodes: nodes });
    RPG.npcs.define(npcId, { name: spec.name, dialogue: npcId, geo: spec.look, wander: !!spec.wander });
}

// Pay, learn, celebrate. Returns the next dialogue node.
function teach(player, skill, price) {
    if (price > 0 && !player.takeMoney(price)) return "broke";
    player.learnSkill(skill);
    player.title("&b" + RPG.skills.name(skill), "&7learned!");
    sfx(player, "confirm_menu", 1, 1);
    act(player, "base.flex", 30);
    player.progressQuest("learn_technique", 1);
    return "learned";
}

// =====================================================================================
//  Earth's masters
// =====================================================================================
teacher("master_roshi", {
    name: "&6Master Roshi",
    look: masterLook("roshi", "roshi_idle"),
    greeting: (player) => "Ho ho! Young " + player.name + ", you have the eyes of a fighter. What brings you to Kame House?",
    options: [
        { text: "I want to become stronger!", ifQuestAvailable: "saiyan_1_arrival", startQuest: "saiyan_1_arrival", next: "train" },
        { text: "What should I do now?", next: "hint" },
        { text: "How do I get stronger?", next: "howto" }
    ],
    lessons: [{ skill: "kamehameha", price: 1000, level: 10 }],
    shop: "roshi_shop",
    nodes: {
        train: { text: "Then climb Korin's Tower! Reach level 5 and speak with Korin. Come back to me when you're done.", options: [{ text: "I'm on my way!" }] },
        hint: {
            text: (player) => {
                if (player.isQuestActive("saiyan_2_saibamen")) return "Saibamen sprout at night. Defeat them!";
                if (player.isQuestActive("saiyan_3_dragon_ball")) return "A 4-Star Dragon Ball... bandits on the plains might carry one.";
                if (player.isQuestActive("saiyan_4_raditz")) return "Raditz is near! Use everything you have learned.";
                if (player.isQuestActive("namek_1_arrival")) return "Namek! Go see Mr. Popo about a ship... er, a portal. Ho ho.";
                return "Train hard, eat well, and nap often. And hold C to charge your ki! Ho ho!";
            },
            options: [{ text: "Thanks, Master.", next: "start" }]
        },
        howto: {
            text: "Fight to earn TP, then spend it on your stats in the menu (K). Levels give skill points for new techniques. Masters like me teach the rest.",
            options: [{ text: "Got it.", next: "start" }]
        }
    }
});

teacher("korin", {
    name: "&fKorin",
    look: masterLook("karin"),
    greeting: "You climbed all the way up here? Impressive. I grow Senzu Beans, you know.",
    options: [
        { text: "Need any help?", ifQuestAvailable: "korin_dino_meat", startQuest: "korin_dino_meat" },
        { text: "About that dino meat...", ifQuestActive: "korin_dino_meat", next: "meat" },
        { text: "I want to drink the Sacred Water.", minLevel: 30, ifQuestAvailable: "korin_sacred_water", startQuest: "korin_sacred_water" }
    ],
    lessons: [{ skill: "senzu_toss", price: 500, level: 5 }],
    shop: "korin_shop",
    nodes: { meat: { text: "Bring me 3 Raw Dino Meat. Dinosaurs roam the jungles and savannas.", options: [{ text: "OK." }] } }
});

teacher("master_krillin", {
    name: "&6Krillin",
    look: masterLook("krillin"),
    greeting: "Hey! Roshi sent you? I know a few tricks that work even on guys way stronger than me.",
    lessons: [
        { skill: "solar_flare", price: 600, level: 5 },
        { skill: "destructo_disk", price: 1500, level: 15 },
        { skill: "double_destructo_disk", price: 6000, level: 35 }
    ]
});

teacher("master_tien", {
    name: "&2Tien Shinhan",
    look: masterLook("tien"),
    greeting: "The Crane School and the Turtle School... I've learned from both. Focus.",
    lessons: [
        { skill: "dodonpa", price: 500, level: 8 },
        { skill: "tri_beam", price: 2500, level: 20 },
        { skill: "neo_tri_beam", price: 9000, level: 45 }
    ]
});

teacher("master_yamcha", {
    name: "&6Yamcha",
    look: masterLook("yamcha"),
    greeting: "You want to learn from ME? Finally, someone with taste! Here's my Wolf Fang Fist!",
    lessons: [{ skill: "wolf_fang_fist", price: 600, level: 8 }]
});

teacher("master_goku", {
    name: "&6&lGoku",
    look: masterLook("goku"),
    greeting: (player) => "Oh, hey! You look strong, " + player.name + "! Wanna spar? ...No? Then I'll teach you something!",
    lessons: [
        { skill: "meteor_combo", price: 2500, level: 20 },
        { skill: "fusion_dance", price: 5000, level: 30 },
        { skill: "instant_transmission", price: 12000, level: 35 },
        { skill: "meteor_burst", price: 9000, level: 45 },
        { skill: "dragon_fist", price: 25000, level: 60 },
        { skill: "super_god_fist", price: 40000, level: 70 }
    ]
});

teacher("master_gohan", {
    name: "&3Gohan",
    look: masterLook("gohan"),
    greeting: "Mr. Piccolo taught me everything. I'll pass it on - but study hard too!",
    lessons: [
        { skill: "masenko", price: 800, level: 12 },
        { skill: "spirit_breaker", price: 3000, level: 30 },
        { skill: "spirit_breaking_cannon", price: 9000, level: 50 }
    ]
});

teacher("master_piccolo", {
    name: "&5Piccolo",
    look: masterLook("piccolo"),
    greeting: "Hmph. Stop wasting my time. If you want to train, survive.",
    lessons: [
        { skill: "masenko", price: 800, level: 12 },
        { skill: "special_beam_cannon", price: 4000, level: 25 },
        { skill: "hellzone_grenade", price: 9000, level: 45 }
    ]
});

teacher("master_vegeta", {
    name: "&b&lVegeta",
    look: masterLook("vegeta"),
    greeting: "You dare ask the Prince of all Saiyans for lessons? ...Fine. Try not to embarrass me.",
    lessons: [
        { skill: "final_flash", price: 12000, level: 40 },
        { skill: "big_bang_attack", price: 15000, level: 50 }
    ],
    broke: "No Zeni? Pathetic. Even Kakarot earns money now."
});

teacher("master_trunks", {
    name: "&dTrunks",
    look: masterLook("trunks"),
    greeting: "I came from a ruined future. I won't let it happen again - let me help you train.",
    lessons: [
        { skill: "burning_attack", price: 5000, level: 30 },
        { skill: "shining_sword_attack", price: 8000, level: 35 }
    ]
});

teacher("master_gero", {
    name: "&7Dr. Gero",
    look: masterLook("gero"),
    greeting: "Ah, a test subject. My androids' programming can be... shared. For a price.",
    lessons: [
        { skill: "eye_laser", price: 1500, level: 18 },
        { skill: "android_combo", price: 3000, level: 20 },
        { skill: "ki_barrier", price: 5000, level: 30 }
    ]
});

teacher("master_cell", {
    name: "&2Cell",
    look: masterLook("cell"),
    greeting: "Perfection recognises potential. Enter my tournament - if you dare.",
    options: [{ text: "I'll fight in the Cell Games!", minLevel: 35, ifQuestAvailable: "cell_games", startQuest: "cell_games" }],
    lessons: [{ skill: "absorb", price: 2000, level: 10, race: "bio_android" }, { skill: "self_destruct", price: 8000, level: 45, race: "bio_android" }]
});

teacher("master_frieza", {
    name: "&5Frieza",
    look: masterLook("frieza"),
    greeting: "Ohohoho! A monkey wants to learn from the Emperor of the Universe? How amusing.",
    lessons: [{ skill: "death_chaser", price: 6000, level: 30, race: "frost_demon" }, { skill: "supernova", price: 20000, level: 50, race: "frost_demon" }],
    shop: "frieza_shop"
});

teacher("master_babidi", {
    name: "&5Babidi",
    look: masterLook("babidi"),
    greeting: "Papparapaa! A strong heart full of darkness... I could use someone like you.",
    options: [{ text: "Accept the Majin mark (+power, 10 minutes)", minLevel: 25, action: (p) => { p.addEffect("majin_mark", 12000); sfx(p, "majin_absorb", 1, 0.7); return "marked"; } }],
    lessons: [{ skill: "gum_bind", price: 3000, level: 20, race: "majin" }, { skill: "candy_beam", price: 1500, level: 15, race: "majin" }],
    shop: "babidi_shop",
    nodes: { marked: { text: "Hehehe... now you belong to me. The 'M' on your forehead suits you!", options: [{ text: "..." }] } }
});

// Babidi's mark: a temporary boost with a price (it slowly drains your health).
RPG.effects.define("majin_mark", {
    name: "&5Majin Mark",
    color: "#8A2BE2",
    stats: { strength: 20, kipower: 20, strike: 10 },
    aura: { texture: AURA_SPIKY, frames: 4, speed: 10, color: "#8A2BE2", scale: 1.0, alpha: 0.6 },
    tickInterval: 100,
    onTick(player, stacks) { if (player.health > 6) player.damage(1); }
});

// =====================================================================================
//  The Otherworld & the gods
// =====================================================================================
teacher("king_kai", {
    name: "&9King Kai",
    look: masterLook("kaiosama"),
    greeting: "Heh heh! Want to hear a joke? No? Fine. You came all the way down Snake Way, so I'll teach you.",
    options: [
        { text: "Teach me the Kaioken!", ifQuestDone: "saiyan_4_raditz", condition: (p) => !p.hasSkill("kaioken"),
          action: (p) => teach(p, "kaioken", 0) },
        { text: "Teach me the Kaioken!", ifQuestNotDone: "saiyan_4_raditz", next: "not_yet" }
    ],
    lessons: [
        { skill: "kaioken_attack", price: 3000, level: 12 },
        { skill: "spirit_bomb", price: 20000, level: 60 }
    ],
    nodes: { not_yet: { text: "You're not ready. Defeat Raditz first, then we'll talk.", options: [{ text: "Fine..." }] } }
});

teacher("grand_kai", {
    name: "&6Grand Kai",
    look: masterLook("grandkai"),
    greeting: "Yo! Welcome to my planet! The Other World Tournament is the hottest ticket in the afterlife.",
    options: [{ text: "Sign me up for the tournament!", minLevel: 50, ifQuestAvailable: "otherworld_tournament", startQuest: "otherworld_tournament" }],
    lessons: [{ skill: "soul_punisher", price: 30000, level: 75 }]
});

teacher("old_kai", {
    name: "&dOld Kai",
    look: masterLook("oldkai"),
    greeting: "Bah! Young people. I can unlock your potential, but the ritual takes... a while. Five hours of dancing, twenty of chanting.",
    options: [
        { text: "Unlock my potential! [Human]", minLevel: 60, ifQuestAvailable: "old_kai_ritual", condition: (p) => p.getRace() === "human", startQuest: "old_kai_ritual" },
        { text: "How's the ritual going?", ifQuestActive: "old_kai_ritual", next: "ritual" }
    ],
    lessons: [{ skill: "dimensional_slash", price: 15000, level: 55 }],
    nodes: { ritual: { text: "Meditate! Hold G and keep still. Ten sessions, then come back.", options: [{ text: "Yes, Elder." }] } }
});

RPG.npcs.define("enma", {
    name: "&4King Yemma",
    geo: masterLook("enma"),
    scale: 2.0,
    dialogue: "enma"
});
RPG.dialogues.define("enma", {
    start: "start",
    nodes: {
        start: {
            text: "NEXT! Hmm, you're not even dead. What do you want in the Other World?",
            options: [
                { text: "Let me walk Snake Way to King Kai. (level 20)", minLevel: 20, action: (p) => { enterOtherworld(p); } },   // 85_world.js
                { text: "Never mind." }
            ]
        }
    }
});

RPG.npcs.define("otherworld_announcer", { name: "&eOther World Announcer", geo: masterLook("otherworld_announcer"), dialogue: "otherworld_announcer" });
RPG.dialogues.define("otherworld_announcer", {
    start: "start",
    nodes: { start: { text: "The greatest warriors who ever lived compete here! Talk to Grand Kai to enter.", options: [{ text: "Cool." }] } }
});

RPG.npcs.define("supreme_kai", { name: "&dSupreme Kai", geo: sagaLook("saga_shin"), dialogue: "supreme_kai" });
RPG.dialogues.define("supreme_kai", {
    start: "start",
    nodes: {
        start: {
            text: "You defeated Majin Buu. The universe owes you everything. Please, take these.",
            options: [
                { text: "Accept the Potara earrings", ifQuestDone: "buu_6_kid_buu", condition: (p) => p.getVar("got_potara", 0) === 0,
                  action: (p) => { p.giveItem("potara_pair", 2); p.setVar("got_potara", 1); return "given"; } },
                { text: "Goodbye." }
            ]
        },
        given: { text: "Wear one each, and two become one. The fusion is temporary here - be careful.", options: [{ text: "Thank you!" }] }
    }
});
RPG.npcs.define("kibito", { name: "&dKibito", geo: sagaLook("saga_kibito"), dialogue: "kibito" });
RPG.dialogues.define("kibito", {
    start: "start",
    nodes: { start: { text: "The Supreme Kai is watching. Grow strong enough to face Majin Buu.", options: [{ text: "I will." }] } }
});

// =====================================================================================
//  The Lookout, Namek, and helpers
// =====================================================================================
RPG.npcs.define("mr_popo", { name: "&8Mr. Popo", dialogue: "popo", geo: masterLook("popo") });
RPG.dialogues.define("popo", {
    start: "start",
    nodes: {
        start: {
            text: "Mr. Popo guards the Hyperbolic Time Chamber. Inside, you train twice as fast.",
            options: [
                { text: "Let me in! (level 15)", minLevel: 15, action: (player) => { enterTimeChamber(player); } },   // 85_world.js
                { text: "Take me to Namek! (level 25)", minLevel: 25, action: (player) => { enterNamek(player); } },
                { text: "Not today." }
            ]
        }
    }
});

RPG.npcs.define("kami", { name: "&2Kami", geo: sagaLook("saga_piccolo_kami"), dialogue: "kami" });
RPG.dialogues.define("kami", {
    start: "start",
    nodes: { start: { text: "The Dragon Balls are my creation. Use them wisely... or Shenron will refuse you.", options: [{ text: "Understood." }] } }
});

RPG.npcs.define("dende", { name: "&aDende", geo: masterLook("dende"), dialogue: "dende" });
RPG.dialogues.define("dende", {
    start: "start",
    nodes: {
        start: {
            text: "Are you hurt? I can heal you! It's the least I can do.",
            options: [
                { text: "Please heal me.", action: (p) => { p.heal(1000); p.setResource("stamina", p.maxResource("stamina")); sfx(p, "senzu", 1, 1.4); return "healed"; } },
                { text: "Teach me to rest properly. (500 Zeni)", condition: (p) => !p.hasSkill("sleep_recovery"), action: (p) => { teach(p, "sleep_recovery", 500); return "healed"; } },
                { text: "Bye, Dende." }
            ]
        },
        healed: { text: "All better! Be careful out there.", options: [{ text: "Thanks!" }] }
    }
});

RPG.npcs.define("guru", { name: "&aGrand Elder Guru", geo: masterLook("guru", "guru_idle"), scale: 1.5, dialogue: "guru" });
RPG.dialogues.define("guru", {
    start: "start",
    nodes: {
        start: {
            text: "Come closer, child... I sense great sleeping power within you.",
            options: [
                { text: "Please unlock my potential. (once, level 20)", minLevel: 20, condition: (p) => p.getVar("guru_blessed", 0) === 0, action: (p) => {
                    RPG.stats.list().forEach((s) => { if (COMBAT_STATS.indexOf(s) >= 0) p.addStat(s, 3); });
                    p.setVar("guru_blessed", 1);
                    act(p, "base.transformation", 40);
                    p.title("&aPotential Unlocked", "&7+3 to every stat");
                    return "done";
                } },
                { text: "Goodbye, Elder." }
            ]
        },
        done: { text: "There... Use this power to protect others.", options: [{ text: "I will." }] }
    }
});

RPG.npcs.define("fortune_teller_baba", { name: "&5Fortune Teller Baba", geo: masterLook("uranai", "uranai_idle"), dialogue: "baba" });
RPG.dialogues.define("baba", {
    start: "start",
    nodes: {
        start: {
            text: "For 1000 Zeni, I'll tell you the future. Or beat my five fighters and I'll do it for free!",
            options: [
                { text: "Read my fortune (1000 Zeni)", action: (p) => p.takeMoney(1000) ? "fortune" : "broke" },
                { text: "I'll fight your warriors!", minLevel: 15, ifQuestAvailable: "baba_fighters", startQuest: "baba_fighters" },
                { text: "No thanks." }
            ]
        },
        fortune: {
            text: (p) => ["I see... a Dragon Ball in the belly of a dinosaur.", "A Saiyan pod will fall from the sky. Be ready.",
                "Your future holds a great deal of Zeni... if you open capsules.", "Someone at the Lookout will teach you patience.",
                "A golden-haired warrior... is that YOU?"][RPG.randomInt(0, 4)],
            options: [{ text: "Hmm, thanks." }]
        },
        broke: { text: "No Zeni, no fortune!", options: [{ text: "..." }] }
    }
});

// Namekian villagers: a geo model with four texture variants, one NPC id per look.
["namek_villager_0", "namek_villager_1", "namek_villager_2", "namek_villager_3"].forEach((id, i) => {
    RPG.npcs.define(id, {
        name: "&aNamekian Villager",
        geo: { model: DMZ_GEO + "enemies/namekian.geo.json", texture: DMZ_TEX + "enemies/namek_trader_" + i + ".png",
               animation: DMZ_ANIM + "enemies/namekian.animation.json", idle: "idle", walk: "walk" },
        wander: true,
        shop: "namek_shop",
        onInteract(player, npc) { sfx(npc, "entity.namekian.vill.ambient", 1, 1); }
    });
});

// =====================================================================================
//  Townsfolk
// =====================================================================================
RPG.npcs.define("bulma", {
    name: "&bBulma",
    dialogue: "bulma",
    wander: true,
    geo: sagaLook("saga_bulma")
});
RPG.dialogues.define("bulma", {
    start: "start",
    nodes: {
        start: {
            text: "Capsule Corp. has everything! Even a Dragon Radar - if you bring me the parts.",
            options: [
                { text: "Let me see the shop.", openShop: "capsule_shop" },
                { text: "Build me a Dragon Radar (casing + Earth chip + Earth CPU)", action: (p) => buildRadar(p, "dragon_radar", "t1") },
                { text: "Build me a Namekian Radar (casing + Namek chip + Namek CPU)", action: (p) => buildRadar(p, "namek_dragon_radar", "t2") },
                { text: "Bye, Bulma." }
            ]
        },
        built: { text: "Ta-da! Genius at work. Don't break it!", options: [{ text: "Thanks!" }] },
        missing: { text: "You're missing parts. Radar Casing, a Chip and a CPU - bandits and robots drop them.", options: [{ text: "OK." }] }
    }
});

function buildRadar(player, radar, tier) {
    let parts = ["radar_piece", tier + "_radar_chip", tier + "_radar_cpu"];
    if (!parts.every((p) => player.hasItem(p, 1))) return "missing";
    parts.forEach((p) => player.takeItem(p, 1));
    player.giveItem(radar, 1);
    sfx(player, "switch_on", 1, 1);
    return "built";
}

RPG.npcs.define("mr_satan", { name: "&6Mr. Satan", geo: sagaLook("saga_mr_satan"), dialogue: "mr_satan" });
RPG.dialogues.define("mr_satan", {
    start: "start",
    nodes: {
        start: {
            text: "HAHAHA! I am the World Champion! Win the World Tournament and maybe I'll give you an autograph!",
            options: [
                { text: "I won the tournament.", ifQuestDone: "world_tournament", condition: (p) => p.getVar("satan_badge", 0) === 0,
                  action: (p) => { p.giveItem("satan_badge", 1); p.setVar("satan_badge", 1); return "badge"; } },
                { text: "Sure, champ." }
            ]
        },
        badge: { text: "W-well! Take my badge! Just... don't tell anyone how it happened.", options: [{ text: "Hehe." }] }
    }
});

RPG.npcs.define("videl", { name: "&dVidel", geo: sagaLook("saga_videl"), wander: true, dialogue: "videl" });
RPG.dialogues.define("videl", {
    start: "start",
    nodes: { start: { text: "Can you teach me to fly? ...What do you mean 'hold V'?", options: [{ text: "It's easy!" }] } }
});

RPG.npcs.define("oolong", { name: "&dOolong", geo: sagaLook("saga_oolong"), wander: true, dialogue: "oolong" });
RPG.dialogues.define("oolong", {
    start: "start",
    nodes: { start: { text: "If you find all seven Dragon Balls, wish for something useful. Trust me on this one.", options: [{ text: "Like what?" }] } }
});

RPG.npcs.define("yajirobe", { name: "&6Yajirobe", geo: sagaLook("saga_yajirobe"), shop: "yajirobe_shop" });

RPG.npcs.define("world_tournament_announcer", { name: "&eTournament Announcer", geo: masterLook("world_tournament_announcer"), dialogue: "announcer" });
RPG.dialogues.define("announcer", {
    start: "start",
    nodes: {
        start: {
            text: "Welcome to the World Martial Arts Tournament! Ready to show the world what you've got?",
            options: [
                { text: "Enter the tournament! (level 15)", minLevel: 15, ifQuestAvailable: "world_tournament", startQuest: "world_tournament" },
                { text: "Just watching." }
            ]
        }
    }
});

RPG.npcs.define("toribot", { name: "&eToribot", geo: masterLook("toribot", "tori_idle"), shop: "toribot_shop" });

// =====================================================================================
//  Props: vehicles, the punch machine, the Saiyan pod, Nimbus
// =====================================================================================
// A prop is an invulnerable NPC that just stands there looking good.
// Vehicles: right-click packs them back into a capsule (50_items.js pops them out).
function vehicleProp(id, name, model, texture, capsuleItem, sound) {
    RPG.npcs.define(id, {
        name: name, showName: false,
        geo: { model: DMZ_GEO + model, texture: DMZ_TEX + texture },
        onInteract(player, npc) {
            sfx(npc, sound, 1, 1);
            npc.kill();
            player.giveItem(capsuleItem, 1);
            RPG.world.particle(npc.dimension, "minecraft:poof", npc.x, npc.y + 1, npc.z, 30, 1, 0.05);
            return false;
        }
    });
}
vehicleProp("capsule_car_red", "Capsule Car", "vehicles/car.geo.json", "vehicles/car_red.png", "car_red", "vehicle.car.engine");
vehicleProp("capsule_car_yellow", "Capsule Car", "vehicles/car.geo.json", "vehicles/car_yellow.png", "car_yellow", "vehicle.car.engine");
vehicleProp("capsule_plane", "Capsule Plane", "vehicles/cc576.geo.json", "vehicles/cc576.png", "cc576", "vehicle.cc576.engine");
vehicleProp("frieza_pod", "Hover Pod", "vehicles/frieza_capsule.geo.json", "vehicles/frieza_capsule.png", "frieza_capsule", "vehicle.frieza_capsule.engine");

// The Saiyan space pod opens with DMZ's own "open" animation and sound.
RPG.npcs.define("saiyan_pod", {
    name: "Saiyan Pod", showName: false,
    geo: { model: DMZ_GEO + "spacepod.geo.json", texture: DMZ_TEX + "spacepod.png", animation: DMZ_ANIM + "spacepod.animation.json", idle: "close" },
    onInteract(player, npc) {
        npc.playAnimation("open");
        sfx(npc, "ship_open", 1, 1);
        if (player.isQuestActive("saiyan_4_raditz") || player.isQuestDone("saiyan_4_raditz")) player.tell("&7A scouter blinks inside: '...Kakarot...'");
        return false;
    }
});

// Hit the punch machine (right-click) to measure your power, Tournament style.
RPG.npcs.define("punch_machine", {
    name: "&ePunch Machine",
    geo: { model: DMZ_GEO + "punchstation.geo.json", texture: DMZ_TEX + "punchmachine.png",
           animation: DMZ_ANIM + "punchmachine.animation.json", idle: "idle" },
    onInteract(player, npc) {
        let score = Math.floor(player.stat("strike") * 8 + player.stat("strength") * 6 + RPG.randomInt(0, 50));
        act(player, "base.jab_right", 10);
        npc.playAnimation("punch");
        sfx(npc, "critic_punch1", 1, 1);
        player.title("&e" + score, "&7Punch Machine score");
        if (score > player.getVar("best_punch", 0)) { player.setVar("best_punch", score); player.tell("&6New personal best: " + score + "!"); }
        return false;
    }
});

RPG.npcs.define("nimbus_cloud", {
    name: "&eFlying Nimbus", showName: false,
    geo: { model: DMZ_GEO + "kinton.geo.json", texture: DMZ_TEX + "kinton.png", animation: DMZ_ANIM + "kinton.animation.json", idle: "idle" },
    onInteract(player, npc) {
        if (player.getVar("streak", 0) > 0) { player.actionbar("&7You fall right through. Not pure enough."); return false; }
        if (!player.hasItem("flying_nimbus", 1)) { player.giveItem("flying_nimbus", 1); player.tell("&eThe Nimbus chose you! (Right-click it to fly.)"); }
        sfx(npc, "nube", 1, 1);
        return false;
    }
});

// =====================================================================================
//  The Eternal Dragons
// =====================================================================================
// summonShenron is called by the Dragon Radar and the Dragon Altar.
function summonShenron(player) {
    for (let star = 1; star <= 7; star++) player.takeItem("dragon_ball_" + star, 1);
    RPG.world.lightning(player.dimension, player.x + 6, player.y, player.z, true);
    let dragon = RPG.world.spawnMob(player.dimension, "shenron", player.x + 6, player.y, player.z);  // 75_mobs_bosses.js
    sfx(player, "shenron", 2, 1);
    sfx(player, "dragonballssound", 1.5, 1);
    RPG.broadcast("&6&l" + player.name + " has summoned the Eternal Dragon!");
    player.openDialogue("shenron_wish");
    RPG.schedule(600, () => { if (dragon && dragon.isAlive()) dragon.kill(); });       // leaves after 30 seconds
    // The balls scatter: one random ball goes to a random online player in 10 minutes.
    RPG.schedule(12000, () => scatterDragonBall("dragon_ball_"));
}

function scatterDragonBall(prefix) {
    let players = RPG.server.players();
    if (players.length === 0) return;
    let lucky = players[RPG.randomInt(0, players.length - 1)];
    lucky.giveItem(prefix + RPG.randomInt(1, 7), 1);
    lucky.tell("&6Something round and shiny fell from the sky next to you...");
}

RPG.dialogues.define("shenron_wish", {
    start: "start",
    speaker: "&a&lShenron",
    nodes: {
        start: {
            text: "I AM THE ETERNAL DRAGON. STATE YOUR WISH. I SHALL GRANT ONE.",
            options: [
                { text: "I wish for great power! (+3000 TP)", action: (p) => { p.addTp(3000); return "granted"; } },
                { text: "I wish for riches! (+50,000 Zeni)", action: (p) => { p.addMoney(50000); return "granted"; } },
                { text: "I wish to be stronger! (+5 levels)", action: (p) => { p.setLevel(p.getLevel() + 5); return "granted"; } },
                { text: "I wish for a new look! (reset my colours)", action: (p) => { applyRaceColors(p, p.getRace(), true); return "granted"; } },
                { text: "I wish for... immortality? (Senzu Bag x3)", action: (p) => { p.giveItem("senzu_bean_bag", 3); return "granted"; } }
            ]
        },
        granted: { text: "YOUR WISH HAS BEEN GRANTED. FAREWELL.", options: [{ text: "Thank you, Shenron!" }] }
    }
});

// Porunga grants three wishes (one dialogue, re-opened three times).
function summonPorunga(player) {
    for (let star = 1; star <= 7; star++) player.takeItem("namek_dragon_ball_" + star, 1);
    RPG.world.lightning(player.dimension, player.x + 8, player.y, player.z, true);
    let dragon = RPG.world.spawnMob(player.dimension, "porunga", player.x + 8, player.y, player.z);
    sfx(player, "shenron", 2, 0.8);
    RPG.broadcast("&a&l" + player.name + " has summoned Porunga on Namek!");
    player.setVar("porunga_wishes", 3);
    player.openDialogue("porunga_wish");
    RPG.schedule(1200, () => { if (dragon && dragon.isAlive()) dragon.kill(); });
    RPG.schedule(18000, () => scatterDragonBall("namek_dragon_ball_"));
}

function porungaGrant(player, fn) {
    fn(player);
    let left = player.getVar("porunga_wishes", 1) - 1;
    player.setVar("porunga_wishes", left);
    return left > 0 ? "start" : "done";
}

RPG.dialogues.define("porunga_wish", {
    start: "start",
    speaker: "&a&lPorunga",
    nodes: {
        start: {
            text: (p) => "TAKKARAPTO POPPORUNGA PUPIRITTO PARO! SPEAK YOUR WISH. (" + p.getVar("porunga_wishes", 1) + " left)",
            options: [
                { text: "Power! (+2000 TP)", action: (p) => porungaGrant(p, (x) => x.addTp(2000)) },
                { text: "Wealth! (+30,000 Zeni)", action: (p) => porungaGrant(p, (x) => x.addMoney(30000)) },
                { text: "A Kaioshin Fruit!", action: (p) => porungaGrant(p, (x) => x.giveItem("kaioshin_fruit", 1)) },
                { text: "Skill points! (+3)", action: (p) => porungaGrant(p, (x) => x.setSkillPoints(x.getSkillPoints() + 3)) }
            ]
        },
        done: { text: "ALL WISHES HAVE BEEN GRANTED.", options: [{ text: "Thank you, Porunga!" }] }
    }
});
