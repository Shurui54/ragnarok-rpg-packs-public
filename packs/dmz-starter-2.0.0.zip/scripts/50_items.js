// =====================================================================================
//  50_items.js - Senzu Beans, Dragon Balls, capsules, scouters, weapons, food, music
// =====================================================================================
//  RPG.items.define("my_name", {...}) gives the item a free placeholder slot the first
//  time and keeps it forever (saved in item_ids.json), so you can rename and reorder
//  scripts freely. Give it with:  /rpg give @s senzu_bean 5
//
//  The look:  model: "dmzpack:rpg/item/senzu_bean"  uses any model JSON found under
//  assets/<namespace>/models/rpg/ in a resource pack (the project's resources/ folder
//  counts). Every name in resources/dmzpack_catalog.json works. Without a model the item
//  uses a placeholder icon:  icon: "sword", iconColor: "#FFAA00"  (see README for the list).
//
//  Common fields: name, model, type ("consumable" | "material" | "tool" | "weapon" |
//  "accessory" | "armor"), rarity, lore, maxStack, useTime, useAnim, cooldown, value,
//  stats, slot, damage, attackSpeed, durability, levelReq, classReq, glint,
//  onUse(player, itemId) (return false = not used), onHit(player, target).
//  Armour lives in 52_armor.js.
// =====================================================================================

// A shortcut: every DMZ item model has the same prefix.
function dmzItem(model) { return DMZ + "rpg/item/" + model; }

// Plays the "eating" animation on the avatar after a consumable is used.
function eat(player, sound) {
    act(player, "base.eat", 20);
    sfx(player, sound || "senzu", 0.8, 1);
}

// =====================================================================================
//  Senzu Beans
// =====================================================================================
RPG.items.define("senzu_bean", {
    name: "&aSenzu Bean",
    model: dmzItem("senzu_bean"),
    type: "consumable",            // right-click to use, consumed after use
    rarity: "rare",
    lore: ["A magic bean from Korin's tower.", "Fully restores health, ki and stamina."],
    maxStack: 16,
    useTime: 16,                   // ticks of eating animation
    useAnim: "eat",
    cooldown: 100,                 // item cooldown in ticks
    value: 500,                    // shown in the tooltip
    onUse(player, itemId) {
        player.heal(1000);
        player.setResource("ki", player.maxResource("ki"));
        player.setResource("stamina", player.maxResource("stamina"));
        player.addEffect("well_fed", 600);
        eat(player);
    }
});

// The three coloured beans each restore one bar (DMZ's farmable senzu).
[
    { id: "senzu_bean_red", name: "&cRed Senzu Bean", lore: "Restores all health.", fn: (p) => p.heal(1000) },
    { id: "senzu_bean_blue", name: "&bBlue Senzu Bean", lore: "Restores all ki.", fn: (p) => p.setResource("ki", p.maxResource("ki")) },
    { id: "senzu_bean_yellow", name: "&eYellow Senzu Bean", lore: "Restores all stamina.", fn: (p) => p.setResource("stamina", p.maxResource("stamina")) }
].forEach((b) => {
    RPG.items.define(b.id, {
        name: b.name, model: dmzItem(b.id), type: "consumable", rarity: "uncommon",
        lore: [b.lore, "Grown from Senzu seeds (55_blocks.js)."], maxStack: 32, useTime: 12, cooldown: 60, value: 150,
        onUse(player) { b.fn(player); eat(player); }
    });
});

RPG.items.define("senzu_bean_bag", {
    name: "&aSenzu Bag", model: dmzItem("senzu_bean_bag"), type: "consumable", rarity: "epic",
    lore: ["Korin's own pouch. Holds 5 beans."], value: 2500,
    onUse(player) { player.giveItem("senzu_bean", 5); sfx(player, "senzu", 1, 0.8); }
});

// Seeds plant a Senzu crop on the block you look at (the crops are in 55_blocks.js).
["red", "blue", "yellow"].forEach((color) => {
    RPG.items.define("senzu_bean_seeds_" + color, {
        name: "Senzu Seeds (" + color + ")", model: dmzItem("senzu_bean_seeds_" + color), type: "tool",
        lore: ["Right-click the top of grass or dirt to plant."], maxStack: 64, value: 40,
        onUse(player) { return plantCrop(player, "senzu_" + color + "_crop_0"); }      // 55_blocks.js
    });
});

// =====================================================================================
//  Food & medicine
// =====================================================================================
// [id, display name, health, stamina, raw?]
[
    ["raw_dino_meat", "Raw Dino Meat", 2, 5, true], ["cooked_dino_meat", "Cooked Dino Meat", 8, 30, false],
    ["raw_baby_dino_meat", "Raw Baby Dino Meat", 1, 3, true], ["cooked_baby_dino_meat", "Cooked Baby Dino Meat", 5, 20, false],
    ["dino_tail_raw", "Raw Dino Tail", 2, 5, true], ["dino_tail_cooked", "Roasted Dino Tail", 10, 35, false],
    ["frog_legs_raw", "Raw Frog Legs", 1, 2, true], ["frog_legs_cooked", "Fried Frog Legs", 4, 15, false],
    ["giant_fish_raw", "Raw Giant Fish", 2, 5, true], ["giant_fish_cooked", "Grilled Giant Fish", 9, 30, false],
    ["giant_turtle_raw", "Raw Giant Turtle", 2, 5, true], ["giant_turtle_cooked", "Turtle Soup", 12, 40, false]
].forEach((f) => {
    RPG.items.define(f[0], {
        name: f[1], model: dmzItem(f[0]), type: "consumable", maxStack: 64, useTime: 32, value: f[4] ? 8 : 25,
        lore: [f[4] ? "Cook it in a furnace? No - sell it, or eat it raw if you're desperate." : "A hearty meal for a hungry fighter."],
        onUse(player) {
            player.heal(f[2]);
            player.addResource("stamina", f[3]);
            if (f[4] && RPG.chance(0.3)) player.addPotion("minecraft:hunger", 200, 0);
            eat(player, "senzu");
        }
    });
});

RPG.items.define("heart_medicine", {
    name: "&dHeart Medicine", model: dmzItem("heart_medicine"), type: "consumable", rarity: "rare",
    lore: ["Future Trunks' cure for the heart virus.", "Clears all bad potion effects and heals 10."], value: 600,
    useTime: 20, useAnim: "drink",
    onUse(player) {
        ["minecraft:poison", "minecraft:wither", "minecraft:weakness", "minecraft:slowness", "minecraft:blindness", "minecraft:hunger"]
            .forEach((e) => player.removePotion(e));
        player.heal(10);
        eat(player);
    }
});

// Medi-bugs: little living medkits from the Namek jungle.
[["medi_bug_worm", 4], ["medi_bug_ant", 6], ["medi_bug_beetle", 8], ["medi_bug_rhino", 12], ["medi_bug_beetle_pair", 18]].forEach((m) => {
    RPG.items.define(m[0], {
        name: "Medi-Bug (" + m[0].replace("medi_bug_", "").replace("_", " ") + ")", model: dmzItem(m[0]),
        type: "consumable", maxStack: 16, useTime: 10, value: m[1] * 10,
        lore: ["Heals " + m[1] + " health."],
        onUse(player) { player.heal(m[1]); burst(player, "minecraft:happy_villager", 6, 0.4, 0); }
    });
});

RPG.items.define("healing_liquid_bucket", {
    name: "&bHealing Liquid", model: dmzItem("healing_liquid_bucket"), type: "consumable", rarity: "rare",
    lore: ["From a Frieza Force medical pod.", "Regeneration III for 10 seconds."], useAnim: "drink", useTime: 32, value: 400,
    onUse(player) { player.addPotion("minecraft:regeneration", 200, 2); }
});

RPG.items.define("namek_water_bucket", {
    name: "&aNamekian Water", model: dmzItem("namek_water_bucket"), type: "consumable",
    lore: ["Namekians live on water alone.", "Namekians: full health. Others: +4."], useAnim: "drink", useTime: 32, value: 60,
    onUse(player) { player.heal(player.getRace() === "namekian" ? 1000 : 4); }
});

RPG.items.define("sacred_water", {
    name: "&b&lSacred Water", model: dmzItem("sacred_water"), type: "consumable", rarity: "epic",
    lore: ["Korin's 'Ultra Divine Water'.", "Survive it and gain +500 TP. (It hurts.)"], useAnim: "drink", useTime: 40, value: 5000,
    onUse(player) {
        player.damage(Math.max(0, player.health - 1));
        player.addTp(500);
        player.title("&b&lULTRA DIVINE WATER", "&7Your hidden power stirs... +500 TP");
    }
});

// Fruits that permanently raise stats.
RPG.items.define("kaioshin_fruit", {
    name: "&d&lKaioshin Fruit", model: dmzItem("kaioshin_fruit"), type: "consumable", rarity: "epic", glint: true,
    lore: ["Grows only on the Sacred World of the Kai.", "+2 to every stat, forever."], useTime: 32, value: 8000,
    onUse(player) {
        RPG.stats.list().forEach((s) => player.addStat(s, 2));
        eat(player);
        player.title("&dKaioshin Fruit", "&7+2 to every stat");
    }
});

RPG.items.define("might_tree_fruit", {
    name: "&c&lFruit of the Tree of Might", model: dmzItem("might_tree_fruit"), type: "consumable", rarity: "legendary", glint: true,
    lore: ["Reserved for the gods. Turles' favourite snack.", "+1500 TP and Zenkai for 5 minutes."], useTime: 32, value: 20000,
    onUse(player) { player.addTp(1500); player.addEffect("zenkai_boost", 6000); eat(player); }
});

// Herbs from 55_blocks.js crops. [id, name, effect]
[
    ["aura_lily", "Aura Lily", "Charges 50% ki.", (p) => p.addResource("ki", p.maxResource("ki") * 0.5)],
    ["hermit_fern", "Hermit Fern", "Speed II for 30s.", (p) => p.addPotion("minecraft:speed", 600, 1)],
    ["katchin_sprout", "Katchin Sprout", "Resistance II for 30s.", (p) => p.addPotion("minecraft:resistance", 600, 1)],
    ["meteor_flower", "Meteor Flower", "Strength II for 30s.", (p) => p.addPotion("minecraft:strength", 600, 1)],
    ["oozaru_root", "Oozaru Root", "Saiyans: full stamina. Smells of moonlight.", (p) => p.setResource("stamina", p.maxResource("stamina"))],
    ["zenkai_lotus", "Zenkai Lotus", "Zenkai for 2 minutes.", (p) => p.addEffect("zenkai_boost", 2400)],
    ["namek_moss", "Namekian Moss", "Heals 6.", (p) => p.heal(6)]
].forEach((h) => {
    RPG.items.define(h[0], {
        name: h[1], model: dmzItem(h[0]), type: "consumable", rarity: "uncommon", lore: [h[2]],
        maxStack: 64, useTime: 16, value: 30, onUse(player) { h[3](player); eat(player); }
    });
});

// Flowers: decoration and shop fodder (the placeable versions are in 55_blocks.js).
["amaryllis_flower", "catharanthus_roseus_flower", "chrysanthemum_flower", "marigold_flower", "trillium_flower"].forEach((f) => {
    let label = f.replace("_flower", "").replace("_", " ");
    RPG.items.define(f + "_bouquet", { name: "Bouquet (" + label + ")", model: dmzItem(f), type: "material", maxStack: 64, value: 5 });
    RPG.items.define("sacred_" + f + "_bouquet", { name: "&bSacred " + label, model: dmzItem("sacred_" + f), type: "material", rarity: "uncommon", maxStack: 64, value: 25 });
});

// =====================================================================================
//  Capsules (Capsule Corp.)
// =====================================================================================
// Coloured capsules: right-click to "pop" them open. [id, name, what's inside]
[
    ["yellow_capsule", "Supply Capsule", "Food and a little Zeni.", (p) => { p.giveItem("cooked_dino_meat", RPG.randomInt(2, 4)); p.addMoney(RPG.randomInt(20, 80)); }],
    ["blue_capsule", "Medical Capsule", "Medi-Bugs and sometimes a Senzu.", (p) => { p.giveItem("medi_bug_beetle", 2); if (RPG.chance(0.2)) p.giveItem("senzu_bean", 1); }],
    ["green_capsule", "Garden Capsule", "Seeds and herbs.", (p) => { p.giveItem("senzu_bean_seeds_" + ["red", "blue", "yellow"][RPG.randomInt(0, 2)], 2); p.giveItem("aura_lily", 1); }],
    ["orange_capsule", "Treasure Capsule", "Zeni! Lots of Zeni.", (p) => p.addMoney(RPG.randomInt(200, 600))],
    ["purple_capsule", "Training Capsule", "A burst of TP.", (p) => p.addTp(RPG.randomInt(60, 160))],
    ["red_capsule", "Battle Capsule", "A random weapon or armour pattern.", (p) => p.giveItem(["power_pole", "yajirobe_katana", "pattern_turtle_gi", "pattern_saiyan_armor"][RPG.randomInt(0, 3)], 1)]
].forEach((c) => {
    RPG.items.define(c[0], {
        name: c[1], model: dmzItem(c[0]), type: "consumable", rarity: "uncommon", maxStack: 16, value: 150,
        lore: ["Capsule Corp. Right-click to open.", c[2]],
        onUse(player) {
            c[3](player);
            RPG.world.particle(player.dimension, "minecraft:poof", player.x, player.y + 1, player.z, 15, 0.4, 0.05);
            sfx(player, "minecraft:entity.chicken.egg", 1, 0.8);
            player.giveItem("empty_capsule", 1);
        }
    });
});

RPG.items.define("empty_capsule", { name: "Empty Capsule", model: dmzItem("empty_capsule"), type: "material", maxStack: 64, value: 10, lore: ["Bulma buys these back."] });

RPG.items.define("mastery_capsule", {
    name: "&bMastery Capsule", model: dmzItem("mastery_capsule"), type: "consumable", rarity: "epic",
    lore: ["Grants 250 TP."], value: 4000,
    onUse(player) { player.addTp(250); player.actionbar("&b+250 TP"); sfx(player, "confirm_menu", 1, 1); }
});

// Gete Star capsules: each permanently raises one stat (DMZ's stat capsules).
[["gete_red_capsule", "strength"], ["gete_orange_capsule", "strike"], ["gete_yellow_capsule", "resistance"],
 ["gete_green_capsule", "vitality"], ["gete_blue_capsule", "kipower"], ["gete_purple_capsule", "energy"]].forEach((g) => {
    RPG.items.define(g[0], {
        name: "&5Gete Capsule (" + RPG.stats.name(g[1]) + ")", model: dmzItem(g[0]), type: "consumable", rarity: "epic",
        lore: ["Salvaged from the Big Gete Star.", "+3 " + RPG.stats.name(g[1]) + ", permanently."], maxStack: 16, value: 3000,
        onUse(player) { player.addStat(g[1], 3); player.actionbar("&d+3 " + RPG.stats.name(g[1])); sfx(player, "switch_on", 1, 1.2); }
    });
});

// Vehicles as capsules: pop one to drop a parked vehicle (an NPC prop, 60_npcs_dialogue.js).
[["car_red", "Red Capsule Car", "capsule_car_red"], ["car_yellow", "Yellow Capsule Car", "capsule_car_yellow"],
 ["cc576", "Capsule Corp. Plane", "capsule_plane"], ["frieza_capsule", "&5Frieza's Hover Pod", "frieza_pod"],
 ["saiyan_ship", "Saiyan Space Pod", "saiyan_pod"]].forEach((v) => {
    RPG.items.define(v[0], {
        name: v[1], model: dmzItem(v[0]), type: "tool", rarity: "rare", value: 3000,
        lore: ["Right-click to pop it open here.", "Right-click the vehicle to pack it again."],
        onUse(player) {
            let at = lookPoint(player, 4);
            RPG.world.spawnNpc(player.dimension, v[2], at.x, player.y, at.z);
            RPG.world.particle(player.dimension, "minecraft:poof", at.x, player.y + 1, at.z, 30, 1, 0.05);
            sfx(player, "vehicle.door", 1, 1);
        }
    });
});

// =====================================================================================
//  Scouters (wear on your head: Right-click to read power levels)
// =====================================================================================
[["red_scouter", "Scouter (Red)", 2, "uncommon"], ["green_scouter", "Scouter (Green)", 3, "uncommon"],
 ["blue_scouter", "Scouter (Blue)", 4, "rare"], ["purple_scouter", "Scouter (Purple)", 6, "epic"]].forEach((s) => {
    RPG.items.define(s[0], {
        name: s[1], model: dmzItem(s[0]), type: "accessory", slot: "head", rarity: s[3],
        lore: ["Right-click while looking at someone", "to read their power level."],
        stats: { kipower: s[2] }, value: 400 * s[2],
        onUse(player) {
            let target = player.target(64);
            if (!target) { player.actionbar("&7Scouter: &8no target"); return false; }   // false = not used
            let pl = powerLevel(target);
            player.actionbar("&a" + target.name + "&7 - Power level: &e" + grouped(pl));
            sfx(player, "pip_menu", 0.7, 2);
            if (pl > 9000 && RPG.chance(0.3)) player.tell("&c&lIT'S OVER 9000!");
        }
    });
});

// =====================================================================================
//  Dragon Balls (Earth, Namek and Demon Realm sets)
// =====================================================================================
for (let star = 1; star <= 7; star++) {
    RPG.items.define("dragon_ball_" + star, {
        name: "&6" + star + "-Star Dragon Ball",
        model: dmzItem("dball" + star),
        type: "material", rarity: "epic", maxStack: 1, glint: true, value: 2500,
        lore: ["Gather all seven and use the", "Dragon Radar to summon Shenron."]
    });
    RPG.items.define("namek_dragon_ball_" + star, {
        name: "&a" + star + "-Star Namekian Dragon Ball",
        model: dmzItem("dball" + star + "_namek"),
        type: "material", rarity: "epic", maxStack: 1, glint: true, value: 4000,
        lore: ["Huge and heavy. Seven summon Porunga,", "who grants THREE wishes."]
    });
}
for (let star = 1; star <= 3; star++) {
    RPG.items.define("demon_dragon_ball_" + star, {
        name: "&5Demon Realm Dragon Ball (" + star + ")", model: dmzItem("dball" + star + "_demon"),
        type: "material", rarity: "legendary", maxStack: 1, glint: true, value: 10000,
        lore: ["From the Demon Realm. Their power is unknown...", "Sell them to Babidi."]
    });
}

// Radars: right-click to count, and with all seven, summon the dragon (60_npcs_dialogue.js).
function radarUse(player, prefix, dragon) {
    let found = 0;
    for (let star = 1; star <= 7; star++) if (player.hasItem(prefix + star, 1)) found++;
    sfx(player, "dragonradar", 0.6, 1);
    if (found < 7) {
        player.actionbar("&eDragon Radar: &f" + found + "/7 &7collected. Bandits, dinosaurs and events carry them...");
        return;
    }
    if (dragon === "porunga") summonPorunga(player); else summonShenron(player);
}

RPG.items.define("dragon_radar", {
    name: "&eDragon Radar", model: dmzItem("dball_radar"), type: "tool", rarity: "rare", value: 5000,
    lore: ["Beeps near Dragon Balls.", "Right-click with all seven to make a wish."], cooldown: 40,
    onUse(player) { radarUse(player, "dragon_ball_", "shenron"); }
});

RPG.items.define("namek_dragon_radar", {
    name: "&aNamekian Dragon Radar", model: dmzItem("namekdball_radar"), type: "tool", rarity: "rare", value: 8000,
    lore: ["Tuned to Namek's Dragon Balls."], cooldown: 40,
    onUse(player) { radarUse(player, "namek_dragon_ball_", "porunga"); }
});

RPG.items.define("fused_dragon_radar", {
    name: "&bBi-Dimensional Radar", model: dmzItem("fused_dball_radar"), type: "tool", rarity: "epic", value: 15000,
    lore: ["Tracks both sets. Right-click: Earth first, then Namek."], cooldown: 40,
    onUse(player) {
        if (player.hasItem("dragon_ball_7", 1)) radarUse(player, "dragon_ball_", "shenron");
        else radarUse(player, "namek_dragon_ball_", "porunga");
    }
});

// Radar parts: Bulma builds a radar from them (65_shops.js / 60_npcs_dialogue.js).
[["radar_piece", "Radar Casing"], ["t1_radar_chip", "Radar Chip (Earth)"], ["t1_radar_cpu", "Radar CPU (Earth)"],
 ["t2_radar_chip", "Radar Chip (Namek)"], ["t2_radar_cpu", "Radar CPU (Namek)"]].forEach((r) => {
    RPG.items.define(r[0], { name: r[1], model: dmzItem(r[0]), type: "material", maxStack: 16, value: 300, lore: ["Bring the parts to Bulma."] });
});

// =====================================================================================
//  Weapons
// =====================================================================================
// damage / attackSpeed work like vanilla swords (a diamond sword is 7 damage, 1.6 speed).
// Under levelReq (or wrong classReq) a weapon only hits for 1.
RPG.items.define("power_pole", {
    name: "&6Power Pole", model: dmzItem("power_pole"), type: "weapon", rarity: "rare",
    damage: 6, attackSpeed: 1.8, durability: 1500, levelReq: 5, stats: { strike: 3 },
    lore: ["Extend! Knocks enemies far away."],
    onHit(player, target) { knockAway(player, target, 1.2, 0.3); sfx(target, "staff_slam", 0.6, 1.2); }
});

RPG.items.define("yajirobe_katana", {
    name: "Yajirobe's Katana", model: dmzItem("yajirobe_katana"), type: "weapon", rarity: "uncommon",
    damage: 7, attackSpeed: 1.6, durability: 1200, levelReq: 10, stats: { strength: 3 },
    onHit(player, target) { sfx(target, "katana_slash", 0.6, 1); }
});

RPG.items.define("brave_sword", {
    name: "&bBrave Sword", model: dmzItem("brave_sword"), type: "weapon", rarity: "rare",
    damage: 9, attackSpeed: 1.6, durability: 2000, levelReq: 20, classReq: "warrior",
    stats: { strength: 6, resistance: 2 }, lore: ["Future Trunks' blade.", "Unlocks the Shining Sword Attack."],
    onHit(player, target) { sfx(target, "sword_slash", 0.6, 1); }
});

RPG.items.define("trunks_sword", {
    name: "Trunks' Sword (Super)", model: dmzItem("trunks_sword"), type: "weapon", rarity: "rare",
    damage: 10, attackSpeed: 1.6, durability: 2200, levelReq: 35, stats: { strength: 8, strike: 3 },
    onHit(player, target) { sfx(target, "sword_slash", 0.6, 0.9); }
});

RPG.items.define("z_sword", {
    name: "&6&lZ Sword", model: dmzItem("z_sword"), type: "weapon", rarity: "legendary",
    damage: 14, attackSpeed: 1.0, levelReq: 40, stats: { strength: 15 },
    attributes: { "minecraft:generic.movement_speed": { amount: -0.1, operation: "multiply_total" } },
    lore: ["Legendary and impossibly heavy.", "Swinging it is training: +TP on hit."],
    onHit(player, target) { player.addTp(1); sfx(target, "claymore_swing", 0.7, 0.8); }
});

RPG.items.define("dimensional_sword", {
    name: "&5Dimensional Sword", model: dmzItem("dimensional_sword"), type: "weapon", rarity: "epic",
    damage: 12, attackSpeed: 1.4, durability: 3000, levelReq: 50, stats: { strength: 10, kipower: 5 },
    lore: ["Cuts the space between worlds.", "Unlocks the Dimensional Slash."],
    onHit(player, target) { burst(target, "minecraft:reverse_portal", 10, 0.3, 0.05); }
});

// Tamagami weapons: dropped by the three Tamagami guardians (75_mobs_bosses.js).
[["tamagami_sword", "Tamagami Sword", 13, 1.6, "katana_slash"], ["tamagami_hammer", "Tamagami Hammer", 16, 0.9, "hammer_slam"],
 ["tamagami_trident", "Tamagami Trident", 14, 1.2, "spear_stab"]].forEach((w) => {
    RPG.items.define(w[0], {
        name: "&5&l" + w[1], model: dmzItem(w[0]), type: "weapon", rarity: "legendary",
        damage: w[2], attackSpeed: w[3], durability: 4000, levelReq: 60, stats: { strength: 12, resistance: 6 },
        lore: ["Wielded by a guardian of the Dragon Balls."],
        onHit(player, target) { sfx(target, w[4], 0.7, 1); }
    });
});

// Guns: right-click fires a projectile (35_projectiles.js).
RPG.items.define("blaster_cannon", {
    name: "Blaster Cannon", model: dmzItem("blaster_cannon"), type: "weapon", rarity: "rare",
    damage: 3, attackSpeed: 1.2, durability: 800, cooldown: 12, levelReq: 8,
    lore: ["Red Ribbon Army surplus. Right-click to fire."],
    onUse(player) { player.shoot("blaster_shot", { damage: 6 + player.getLevel() * 0.2 }); sfx(player, "kiblast_shoot", 0.7, 0.6); }
});

RPG.items.define("laser_merus", {
    name: "&bMerus' Laser", model: dmzItem("laser_merus"), type: "weapon", rarity: "epic",
    damage: 4, attackSpeed: 1.2, durability: 1500, cooldown: 20, levelReq: 30,
    lore: ["Galactic Patrol issue. Right-click to fire."],
    onUse(player) { player.shoot("merus_laser", { damage: 10 + player.getLevel() * 0.3 }); sfx(player, "laserbeam", 0.7, 1.6); }
});

// Gete tools (real tools: they mine fast because they're "tools" with high damage stats).
[["gete_pickaxe", "Gete Pickaxe"], ["gete_axe", "Gete Axe"], ["gete_shovel", "Gete Shovel"], ["gete_hoe", "Gete Hoe"]].forEach((t) => {
    RPG.items.define(t[0], {
        name: t[1], model: dmzItem(t[0]), type: "tool", rarity: "rare", damage: 5, attackSpeed: 1.2, durability: 2500,
        lore: ["Forged from Gete metal. Practically indestructible."]
    });
});

// =====================================================================================
//  Training gear
// =====================================================================================
// Weighted clothes: wear them (chest slot) to train harder: slower, but +50% TP (90_hooks.js).
[["weight_turtle_shell", "Turtle Shell", "Roshi's 20 kg shell."], ["weight_piccolo_cape", "Weighted Cape", "Piccolo's 100 kg cape."],
 ["workout_weights", "Workout Weights", "Old-fashioned iron."]].forEach((w) => {
    RPG.items.define(w[0], {
        name: w[1], model: dmzItem(w[0]), type: "accessory", slot: "chest", rarity: "uncommon", value: 800,
        lore: [w[2], "Wear it: slower, but +50% TP."],
        stats: { vitality: 2, weight: 1 },          // "weight" is a hidden marker stat (10_stats.js)
        attributes: { "minecraft:generic.movement_speed": { amount: -0.15, operation: "multiply_total" } }
    });
});

RPG.items.define("anti_ki_cloak", {
    name: "&8Anti-Ki Cloaking Device", model: dmzItem("anti_ki_cloak"), type: "accessory", slot: "chest", rarity: "epic", value: 6000,
    lore: ["Hides your power level from scouters.", "Scouters read you as 5."], stats: { resistance: 4, ki_cloak: 1 }
});

RPG.items.define("satan_badge", {
    name: "&6Mr. Satan's Badge", model: dmzItem("satan_badge"), type: "accessory", slot: "offhand", rarity: "rare", value: 1000,
    lore: ["World Martial Arts Champion!", "Hold in your offhand: +25% Zeni from kills."],
    stats: { fame: 1 }
});

// =====================================================================================
//  Materials
// =====================================================================================
[
    ["gete_scrap", "Gete Scrap", 30], ["gete_ingot", "Gete Ingot", 200], ["majilite", "Majilite", 150],
    ["kikono_shard", "Kikono Shard", 60], ["kikono_cloth", "Kikono Cloth", 80], ["kikono_string", "Kikono String", 20],
    ["kikono_stick", "Kikono Stick", 15], ["turtle_scale", "Giant Turtle Scale", 40], ["demon_eye", "&5Demon Eye", 500],
    ["energy_cable", "Energy Cable", 50], ["fuel_generator", "Fuel Generator", 400], ["vehicle_engine", "Vehicle Engine", 600],
    ["vehicle_plating", "Vehicle Plating", 250], ["vehicle_propeller", "Vehicle Propeller", 300], ["vehicle_seat", "Vehicle Seat", 100],
    ["armor_crafting_kit", "Armour Crafting Kit", 500], ["blank_pattern_z", "Blank Pattern (Z)", 50], ["blank_pattern_super", "Blank Pattern (Super)", 80],
    ["punch_machine_item", "Punch Machine (boxed)", 1500], ["kikono_station", "Dr. Kikono's Station", 2000],
    ["namek_grass_tuft", "Namekian Grass", 2], ["namek_sacred_grass_tuft", "Sacred Grass", 5], ["namek_moss_clump", "Namek Moss Clump", 3]
].forEach((m) => {
    let model = { namek_grass_tuft: "namek_grass", namek_sacred_grass_tuft: "namek_sacred_grass", namek_moss_clump: "namek_moss" }[m[0]] || m[0];
    RPG.items.define(m[0], { name: m[1], model: dmzItem(model), type: "material", maxStack: 64, value: m[2] });
});

// Potara earrings: use a pair while looking at another player to fuse for 5 minutes.
function potaraUse(player) {
    let t = player.target(6);
    let partner = t ? t.asPlayer() : null;
    if (!partner) { player.actionbar("&7Look at the player wearing the other earring."); return false; }
    act(player, "base.fusion_pothala_left", 30);
    act(partner, "base.fusion_pothala_right", 30);
    sfx(player, "fusion", 1.2, 1.1);
    [player, partner].forEach((who) => who.addEffect("potara_fusion", 6000));
}

RPG.items.define("potara_pair", {
    name: "&e&lPotara Earrings", model: dmzItem("pothala_pair"), type: "consumable", rarity: "legendary", glint: true, value: 25000,
    lore: ["A gift from the Supreme Kai.", "Right-click while looking at a friend: fuse for 5 minutes."],
    onUse(player) { return potaraUse(player); }
});
RPG.items.define("green_potara_pair", {
    name: "&a&lGreen Potara Earrings", model: dmzItem("green_pothala_pair"), type: "consumable", rarity: "legendary", glint: true, value: 25000,
    lore: ["Zamasu's earrings. The fusion is the same; the attitude is not."],
    onUse(player) { return potaraUse(player); }
});
["pothala_left", "pothala_right", "green_pothala_left", "green_pothala_right"].forEach((e) => {
    RPG.items.define(e.replace("pothala", "potara"), { name: "Potara Earring (" + e.replace(/_/g, " ").replace("pothala", "") + ")", model: dmzItem(e), type: "material", rarity: "epic", value: 10000 });
});

// Nimbus: only the pure of heart can ride it. Here: a fast flight for players without a kill streak.
RPG.items.define("flying_nimbus", {
    name: "&eFlying Nimbus", model: dmzItem("flying_nimbus"), type: "tool", rarity: "epic", value: 9000,
    lore: ["Right-click to call it. Pure hearts only:", "players who killed nothing in their current life."],
    onUse(player) {
        if (player.getVar("streak", 0) > 0) { player.actionbar("&7The Nimbus won't hold you. Your heart isn't pure."); sfx(player, "nube", 0.8, 0.6); return false; }
        player.push(0, 0.6, 0);
        player.addEffect("flight", -1);
        sfx(player, "nube", 1, 1);
    }
});
RPG.items.define("black_nimbus", {
    name: "&8Black Nimbus", model: dmzItem("black_nimbus"), type: "tool", rarity: "epic", value: 9000,
    lore: ["Anyone can ride this one."],
    onUse(player) { player.push(0, 0.6, 0); player.addEffect("flight", -1); sfx(player, "nube", 1, 0.8); }
});

RPG.items.define("invisible_ladder", {
    name: "Invisible Ladder", model: dmzItem("invisible_ladder_block"), type: "material", maxStack: 64, value: 20,
    lore: ["Korin's tower is climbed the honest way."]
});

// =====================================================================================
//  Music discs: right-click to play a track from the asset pack
// =====================================================================================
// There are 39 tracks (menu_music_1 .. 39) plus the DMZ theme. The names come from DMZ.
var DISC_NAMES = [
    "Bulma is Happy", "Away on the Bike!", "Goku's Dinner Bird", "Goku Leaves With Umigame", "The Joys Of Travel",
    "Kame Sennin Prepares The Kamehameha", "Kuririn Arrives by Boat", "Milk Delivery", "Climbing The Tower", "Yajirobe in Action",
    "Prologue & Subtitle I", "Cha-La Head Cha-La (Variations)", "Bridge Collection", "Gohan's Theme", "Alas, the Days of Training",
    "Planet Namek and Hope Vanish", "Dragon Ball Z", "The Strongest In This World", "One More Conclusion", "Son Goku the Super Saiyajin",
    "Goodbye Warriors", "Angel", "Enter A New Hero", "Son Goku is the Strongest After All", "The Super Warrior Can't Rest",
    "Beerus' Tea Time", "Under the Blue Sky", "Pleasant Days", "Limit-Break x Survivor", "Like That Cloud",
    "Call for a Miracle", "Goku's Father-Son Victory", "Vegeta's Sacrifice", "Dearly Beloved", "in the pool",
    "Sad Brothers", "we will finish this game", "Styx Helix", "Stay Alive ~Regain~"
];

function discDef(name, sound, model) {
    return {
        name: "&bMusic Disc &7- " + name, model: dmzItem(model), type: "tool", rarity: "rare", value: 300,
        lore: ["Right-click to play for everyone nearby."], cooldown: 200,
        onUse(player) { sfx(player, sound, 2, 1); player.actionbar("&bNow playing: &f" + name); }
    };
}

RPG.items.define("music_disc_dmz", discDef("DragonMine Z", "menu_music", "music_disc_dmz"));
DISC_NAMES.forEach((title, i) => {
    RPG.items.define("music_disc_" + (i + 1), discDef(title, "menu_music_" + (i + 1), "music_disc_menu_music_" + (i + 1)));
});
