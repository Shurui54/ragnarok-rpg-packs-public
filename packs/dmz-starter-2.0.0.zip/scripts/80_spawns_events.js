// =====================================================================================
//  80_spawns_events.js - where enemies appear, and random world events
// =====================================================================================
//  Spawns are checked every `interval` ticks per player and appear minDistance-maxDistance
//  blocks away. Pick the body with mob: (RPG.mobs), entity: (vanilla), boss: or npc:.
//    dimensions: ["minecraft:overworld", "ragnarok_rpg:namek"]
//    biomes: ["minecraft:plains", "#minecraft:is_forest"]   ids or #tags
//    time: "day" | "night" | "any"     light: "dark" | "bright" | "any"
//    group: [min, max]   maxNearby   minLevel / maxLevel (player level)
//    levelScaling: 0.05  -> +5% health & damage per player level
//    condition(player) / onSpawn(entity, player)
// =====================================================================================

var OVERWORLD = ["minecraft:overworld"];

// ---- Earth --------------------------------------------------------------------------------
RPG.spawns.define("plains_bandits", {
    mob: "bandit", dimensions: OVERWORLD,
    biomes: ["minecraft:plains", "minecraft:sunflower_plains", "#minecraft:is_savanna", "minecraft:desert"],
    time: "night", interval: 200, chance: 0.3, group: [1, 3], maxNearby: 6, minDistance: 24, maxDistance: 48, levelScaling: 0.03
});

RPG.spawns.define("red_ribbon_patrol", {
    mob: "red_ribbon_soldier", dimensions: OVERWORLD, biomes: ["#minecraft:is_forest", "#minecraft:is_taiga"],
    minLevel: 10, interval: 300, chance: 0.25, group: [2, 4], maxNearby: 6, levelScaling: 0.05
});

RPG.spawns.define("red_ribbon_robots", {
    mob: "rr_robot_1", dimensions: OVERWORLD, biomes: ["#minecraft:is_mountain", "#minecraft:is_badlands"],
    minLevel: 15, interval: 400, chance: 0.2, group: [1, 2], maxNearby: 3, levelScaling: 0.05
});

RPG.spawns.define("desert_pilaf", {
    mob: "pilaf_robot", dimensions: OVERWORLD, biomes: ["minecraft:desert", "#minecraft:is_badlands"],
    minLevel: 8, interval: 500, chance: 0.2, group: [1, 1], maxNearby: 2
});

RPG.spawns.define("battle_jackets", {
    mob: "battle_jacket", dimensions: OVERWORLD, minLevel: 25, interval: 600, chance: 0.15, group: [1, 1], maxNearby: 2, levelScaling: 0.04
});

RPG.spawns.define("night_saibamen", {
    mob: "saibaman", dimensions: OVERWORLD, time: "night", light: "dark", minLevel: 3,
    interval: 240, chance: 0.2, group: [2, 3], maxNearby: 8, levelScaling: 0.04,
    onSpawn(entity, player) {
        RPG.world.particle(entity.dimension, "minecraft:composter", entity.x, entity.y, entity.z, 10, 0.3, 0.1);
    }
});

RPG.spawns.define("majin_night", {
    mob: "majin_soldier", dimensions: OVERWORLD, time: "night", minLevel: 55, interval: 600, chance: 0.15, group: [1, 2], maxNearby: 3
});

RPG.spawns.define("gete_drones", {
    mob: "gete_robot", dimensions: OVERWORLD, minLevel: 60, interval: 900, chance: 0.12, group: [1, 2], maxNearby: 2
});

RPG.spawns.define("demon_soldiers", {
    mob: "gomah_soldier", dimensions: OVERWORLD, time: "night", minLevel: 70, interval: 900, chance: 0.12, group: [1, 2], maxNearby: 2
});

// ---- Animals --------------------------------------------------------------------------------
RPG.spawns.define("jungle_dinosaurs", {
    mob: "dinosaur", biomes: ["#minecraft:is_jungle", "#minecraft:is_savanna"], time: "day",
    interval: 400, chance: 0.3, group: [1, 2], maxNearby: 4
});
RPG.spawns.define("triceratops_herds", {
    mob: "triceratops", biomes: ["#minecraft:is_savanna", "minecraft:plains"], time: "day",
    interval: 500, chance: 0.2, group: [1, 3], maxNearby: 4
});
RPG.spawns.define("tyrannosaurus", {
    mob: "tyrannosaurus", biomes: ["#minecraft:is_jungle"], minLevel: 10, interval: 900, chance: 0.15, group: [1, 1], maxNearby: 1
});
RPG.spawns.define("baby_dinos", {
    mob: "baby_dino", biomes: ["#minecraft:is_jungle", "#minecraft:is_savanna"], time: "day", interval: 400, chance: 0.2, group: [1, 3], maxNearby: 4
});
RPG.spawns.define("mountain_sabertooths", {
    mob: "sabertooth", biomes: ["#minecraft:is_mountain", "minecraft:snowy_plains"], interval: 400, chance: 0.2, group: [1, 2], maxNearby: 3
});
RPG.spawns.define("taiga_sabertooths", {
    mob: "sabertooth_1", biomes: ["#minecraft:is_taiga"], interval: 500, chance: 0.15, group: [1, 2], maxNearby: 3
});
RPG.spawns.define("beach_turtles", {
    mob: "giant_turtle", biomes: ["#minecraft:is_beach"], time: "day", interval: 600, chance: 0.2, group: [1, 2], maxNearby: 3
});

// ---- Namek, the Other World and the Time Chamber (85_world.js) --------------------------
RPG.spawns.define("namek_frieza_force", {
    mob: "frieza_soldier", dimensions: ["ragnarok_rpg:namek"], interval: 240, chance: 0.35, group: [2, 4], maxNearby: 8, levelScaling: 0.03
});
RPG.spawns.define("namek_frieza_elites", {
    mob: "frieza_soldier_elite", dimensions: ["ragnarok_rpg:namek"], minLevel: 35, interval: 500, chance: 0.2, group: [1, 2], maxNearby: 3
});
RPG.spawns.define("namek_frogs", {
    mob: "namek_frog", dimensions: ["ragnarok_rpg:namek"], interval: 300, chance: 0.3, group: [1, 3], maxNearby: 5
});
RPG.spawns.define("namek_warriors", {
    mob: "namek_warrior", dimensions: ["ragnarok_rpg:namek"], interval: 600, chance: 0.2, group: [1, 2], maxNearby: 3
});
RPG.spawns.define("otherworld_ogres", {
    mob: "ogre", dimensions: ["ragnarok_rpg:otherworld"], interval: 300, chance: 0.3, group: [1, 2], maxNearby: 4
});
RPG.spawns.define("time_chamber_shadows", {
    mob: "shadow_dummy", dimensions: ["ragnarok_rpg:time_chamber"], interval: 200, chance: 0.5, group: [1, 2], maxNearby: 4,
    minDistance: 8, maxDistance: 20, levelScaling: 0.06
});

// =====================================================================================
//  Random events: the server rolls every `interval` ticks and may start one.
//  Test one now:  /rpg event start saibamen_invasion
// =====================================================================================
RPG.randomEvents.configure({
    enabled: true,
    interval: 12000,               // roll every 10 minutes...
    chance: 0.35,                  // ...35% chance that something happens
    maxActive: 1
});

// Spawns `count` mobs in a ring around a player.
function spawnAround(player, mobId, count) {
    for (let i = 0; i < count; i++) {
        let angle = Math.random() * Math.PI * 2;
        let dist = RPG.random(6, 12);
        RPG.world.spawnMob(player.dimension, mobId, player.x + Math.cos(angle) * dist, player.y, player.z + Math.sin(angle) * dist);
    }
}

RPG.randomEvents.define("saibamen_invasion", {
    name: "Saibamen Invasion",
    weight: 3,                     // picked 3x as often as a weight-1 event
    duration: 2400,                // 2 minutes
    cooldown: 24000,
    announce: "&a&l[Event] &2Saibamen are sprouting everywhere! &7(2 minutes)",
    endMessage: "&7The Saibamen have withered away.",
    // Runs when the event starts, with every online player.
    onStart(players) { players.forEach((p) => spawnAround(p, "saibaman_" + RPG.randomInt(2, 6), 3)); },
    // Runs once a second while active; tick counts up.
    onTick(players, tick) {
        if (tick % 600 === 0) players.forEach((p) => spawnAround(p, "saibaman", 2));  // a new wave every 30s
    }
});

RPG.randomEvents.define("frieza_force_raid", {
    name: "Frieza Force Raid",
    weight: 2, duration: 2400, cooldown: 36000,
    announce: "&d&l[Event] &5Frieza Force pods are landing! &7(2 minutes)",
    endMessage: "&7The surviving soldiers flee to their ships.",
    onStart(players) {
        players.forEach((p) => {
            if (p.getLevel() < 15) return;
            RPG.world.spawnNpc(p.dimension, "frieza_pod", p.x + 10, p.y, p.z);
            spawnAround(p, "frieza_soldier", 3);
            spawnAround(p, "frieza_soldier_heavy", 1);
            sfx(p, "vehicle.frieza_capsule.land", 1.5, 1);
        });
    }
});

RPG.randomEvents.define("red_ribbon_raid", {
    name: "Red Ribbon Raid",
    weight: 2, duration: 1800, cooldown: 24000,
    announce: "&c&l[Event] &4The Red Ribbon Army is attacking! &7(90 seconds)",
    endMessage: "&7The Red Ribbon Army retreats.",
    onStart(players) { players.forEach((p) => { spawnAround(p, "red_ribbon_soldier", 3); if (p.getLevel() >= 15) spawnAround(p, "rr_robot_" + RPG.randomInt(1, 3), 1); }); }
});

RPG.randomEvents.define("radar_ping", {
    name: "Dragon Radar Ping",
    weight: 2, duration: 200,
    announce: "&6&l[Event] &eEvery radar on Earth just pinged...",
    endMessage: "",
    onStart(players) {
        players.forEach((p) => {
            sfx(p, "dragonradar", 1, 1);
            if (RPG.chance(0.2)) {
                let star = RPG.randomInt(1, 7);
                p.giveItem("dragon_ball_" + star, 1);
                p.title("&6Lucky!", "&eYou found the " + star + "-Star Dragon Ball");
                sfx(p, "dragonballssound", 1, 1);
            } else {
                p.tell("&7The signal was too weak. Maybe next time.");
            }
        });
    }
});

RPG.randomEvents.define("namek_radar_ping", {
    name: "Namekian Dragon Ball Signal",
    weight: 1, duration: 200,
    announce: "&a&l[Event] &2A Namekian Dragon Ball signal flickers on Namek...",
    endMessage: "",
    onStart(players) {
        players.forEach((p) => {
            if (p.dimension === "ragnarok_rpg:namek" && RPG.chance(0.35)) {
                p.giveItem("namek_dragon_ball_" + RPG.randomInt(1, 7), 1);
                p.title("&aFound one!", "&2A Namekian Dragon Ball");
            }
        });
    }
});

// No callbacks at all: the TP doubling is a "tpGain" hook (90_hooks.js) that checks isActive.
RPG.randomEvents.define("double_tp", {
    name: "Double TP Hour",
    weight: 1,
    duration: 72000,               // one real hour
    cooldown: 72000,
    announce: "&b&l[Event] &3Double TP for the next hour!",
    endMessage: "&7Double TP is over."
});

// A world boss lands next to a random player who is strong enough for it.
var WORLD_BOSSES = [
    { id: "turles", level: 45 }, { id: "lord_slug", level: 45 }, { id: "cooler", level: 55 }, { id: "bojack", level: 55 },
    { id: "metal_cooler", level: 65 }, { id: "broly", level: 70 }, { id: "janemba", level: 75 }, { id: "hirudegarn", level: 75 },
    { id: "baby_vegeta", level: 75 }, { id: "super_17", level: 78 }, { id: "tamagami_1", level: 70 }, { id: "tamagami_2", level: 80 },
    { id: "tamagami_3", level: 90 }, { id: "gomah", level: 85 }, { id: "omega_shenron", level: 95 }
];

RPG.randomEvents.define("world_boss", {
    name: "World Boss",
    weight: 1, duration: 6000, cooldown: 48000,
    announce: "&4&l[World Boss] &cA terrifying power level appears...",
    endMessage: "",
    onStart(players) {
        if (players.length === 0) return;
        let p = players[RPG.randomInt(0, players.length - 1)];
        let fitting = WORLD_BOSSES.filter((b) => p.getLevel() >= b.level);
        if (fitting.length === 0) { p.tell("&7...but it passes you by. (World bosses start at level 45.)"); return; }
        let pick = fitting[RPG.randomInt(0, fitting.length - 1)];
        bossArrives(p, pick.id, "&c&l" + RPG.bosses.name(pick.id), null, null);       // 70_quests.js
    }
});
