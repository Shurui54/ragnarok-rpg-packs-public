// =====================================================================================
//  55_blocks.js - Namek, the Otherworld, the Demon Realm, crops and special blocks
// =====================================================================================
//  Like items: a name of your own gets a permanent placeholder slot. Blocks 1-150 are
//  solid cubes; a block with decor: true (or a non-full shape, or collision: false) goes
//  in the see-through range 151-200 (plants, glass, leaves...). This file uses about 80
//  solid and 44 decor slots.
//    model: "dmzpack:rpg/block/namek_stone"    any model under assets/<ns>/models/rpg/
//    hardness (-1 = unbreakable), light (0-15), shape ("full" | "slab" | "carpet" | "cross" |
//    "pillar" | "pane" | "table" | [x1,y1,z1,x2,y2,z2]), collision, drops, speed, jump,
//    slipperiness, requiresTool
//    onUse / onStep / onBreak / onPlace (player or entity, x, y, z) / onRandomTick(x, y, z)
//  RPG.blocks.define returns the block's id ("block_0003"), so other scripts can place it
//  with RPG.world.setBlock(dim, x, y, z, "ragnarok_rpg:" + id).
// =====================================================================================

function dmzBlock(model) { return DMZ + "rpg/block/" + model; }

// Remember every block's real id by its script name, for setBlock and dimensions.
var BLOCK_IDS = {};
function block(name, def) {
    BLOCK_IDS[name] = RPG.blocks.define(name, def);
    return BLOCK_IDS[name];
}
function blockRef(name) { return "ragnarok_rpg:" + BLOCK_IDS[name]; }

// =====================================================================================
//  Planet Namek
// =====================================================================================
[
    ["namek_stone", "Namekian Stone", 1.5], ["namek_cobblestone", "Namekian Cobblestone", 2], ["namek_deepslate", "Namekian Deepslate", 3],
    ["namek_dirt", "Namekian Dirt", 0.5], ["namek_block", "Namekian Bricks", 2], ["lilac_sand", "Lilac Sand", 0.5],
    ["turquoise_rock", "Turquoise Rock", 1.5]
].forEach((b) => block(b[0], { name: b[1], model: dmzBlock(b[0]), hardness: b[2] }));

// Grass blocks: these DMZ block models are single-texture cubes, so we use the top face.
block("namek_grass_block", { name: "Namekian Grass Block", model: dmzBlock("namek_grass_block_top"), hardness: 0.6, drops: [{ item: "namek_dirt" }] });
block("namek_sacred_grass_block", { name: "Sacred Namekian Grass", model: dmzBlock("namek_sacred_grass_block_top"), hardness: 0.6, drops: [{ item: "namek_dirt" }] });
block("sacred_planet_grass_block", { name: "Sacred World Grass", model: dmzBlock("sacred_planet_grass_block_top"), hardness: 0.6, light: 3 });

// Ores: [block, display name, what it drops]
[
    ["namek_coal_ore", "Namekian Coal Ore", "minecraft:coal"], ["namek_copper_ore", "Namekian Copper Ore", "minecraft:raw_copper"],
    ["namek_iron_ore", "Namekian Iron Ore", "minecraft:raw_iron"], ["namek_gold_ore", "Namekian Gold Ore", "minecraft:raw_gold"],
    ["namek_diamond_ore", "Namekian Diamond Ore", "minecraft:diamond"], ["namek_emerald_ore", "Namekian Emerald Ore", "minecraft:emerald"],
    ["namek_lapis_ore", "Namekian Lapis Ore", "minecraft:lapis_lazuli"], ["namek_redstone_ore", "Namekian Redstone Ore", "minecraft:redstone"],
    ["namek_kikono_ore", "Kikono Ore", "kikono_shard"],
    ["namek_deepslate_coal_ore", "Deep Namekian Coal Ore", "minecraft:coal"], ["namek_deepslate_copper_ore", "Deep Namekian Copper Ore", "minecraft:raw_copper"],
    ["namek_deepslate_iron_ore", "Deep Namekian Iron Ore", "minecraft:raw_iron"], ["namek_deepslate_gold_ore", "Deep Namekian Gold Ore", "minecraft:raw_gold"],
    ["namek_deepslate_diamond_ore", "Deep Namekian Diamond Ore", "minecraft:diamond"], ["namek_deepslate_emerald_ore", "Deep Namekian Emerald Ore", "minecraft:emerald"],
    ["namek_deepslate_lapis_ore", "Deep Namekian Lapis Ore", "minecraft:lapis_lazuli"], ["namek_deepslate_redstone_ore", "Deep Namekian Redstone Ore", "minecraft:redstone"],
    ["majilite_ore", "Majilite Ore", "majilite"], ["gete_debris_ore", "Gete Debris", "gete_scrap"]
].forEach((o) => block(o[0], {
    name: o[1], model: dmzBlock(o[0]), hardness: o[0].indexOf("deepslate") >= 0 ? 4.5 : 3, requiresTool: true,
    drops: [{ item: o[2], count: 1 }, { item: o[2], count: 1, chance: 0.3 }],
    onBreak(player, x, y, z) { player.addTp(1); }             // mining is training too
}));

// Ajissa (blue Namekian trees) and Sacred trees.
[
    ["namek_ajissa_log", "Ajissa Log"], ["namek_ajissa_wood", "Ajissa Wood"], ["namek_ajissa_planks", "Ajissa Planks"],
    ["namek_stripped_ajissa_log", "Stripped Ajissa Log"], ["namek_stripped_ajissa_wood", "Stripped Ajissa Wood"],
    ["namek_sacred_log", "Sacred Log"], ["namek_sacred_wood", "Sacred Wood"], ["namek_sacred_planks", "Sacred Planks"],
    ["namek_stripped_sacred_log", "Stripped Sacred Log"], ["namek_stripped_sacred_wood", "Stripped Sacred Wood"],
    ["might_tree_wood", "Tree of Might Bark"], ["might_tree_root", "Tree of Might Root"]
].forEach((w) => block(w[0], { name: w[1], model: dmzBlock(w[0]), hardness: 2 }));

block("might_tree_fruit_block", {
    name: "&cFruit of the Tree of Might", model: dmzBlock("might_tree_fruit_block"), hardness: 0.5, light: 8,
    drops: [{ item: "might_tree_fruit", count: 1 }]
});

// =====================================================================================
//  Earth, the Otherworld, Hell and the Demon Realm
// =====================================================================================
[
    ["adobe", "Adobe", 1.2], ["adobe_bricks", "Adobe Bricks", 1.5], ["rocky_stone", "Rocky Stone", 1.5],
    ["rocky_cobblestone", "Rocky Cobblestone", 2], ["rocky_dirt", "Rocky Dirt", 0.6], ["red_ash", "Red Ash", 0.5],
    ["hell_ground", "Hell Ground", 0.8], ["hell_stone", "Hell Stone", 1.5], ["hell_deepstone", "Hell Deepstone", 3],
    ["makai_stone", "Makai Stone", 1.5], ["makai_strata_stone", "Makai Strata Stone", 1.5], ["makai_dirt", "Makai Dirt", 0.6],
    ["makai_sand", "Makai Sand", 0.5], ["demon_bricks", "Demon Bricks", 2], ["demon_rock", "Demon Rock", 2],
    ["demon_realm_crust", "Demon Realm Crust", 1.5], ["demon_horn", "Demon Horn", 2],
    ["gete_block", "Gete Block", 5], ["gete_star_hull", "Big Gete Star Hull", 6], ["gete_star_circuit", "Big Gete Star Circuit", 6],
    ["kikono_block", "Kikono Block", 3], ["dark_sea_cloud", "Dark Sea Cloud", 0.3]
].forEach((b) => block(b[0], { name: b[1], model: dmzBlock(b[0]), hardness: b[2] }));

block("makai_grass_block", { name: "Makai Grass Block", model: dmzBlock("makai_grass_block_top"), hardness: 0.6, drops: [{ item: "makai_dirt" }] });
block("demon_horn_glow", { name: "Glowing Demon Horn", model: dmzBlock("demon_horn_glow"), hardness: 2, light: 12 });

// Magma rock burns whoever walks on it.
block("demon_magma_rock", {
    name: "Demon Magma Rock", model: dmzBlock("demon_magma_rock"), hardness: 2, light: 6,
    onStep(entity, x, y, z) { entity.setFire(2); }
});

// Gas vents launch you into the air.
block("gas_vent", {
    name: "Gas Vent", model: dmzBlock("gas_vent_top"), hardness: 2,
    onStep(entity, x, y, z) {
        entity.push(0, 1.4, 0);
        RPG.world.particle(entity.dimension, "minecraft:campfire_cosy_smoke", x + 0.5, y + 1.1, z + 0.5, 5, 0.2, 0.05);
    }
});

// Otherworld clouds: walk faster, jump higher (the Snake Way floor).
block("otherworld_cloud", {
    name: "Otherworld Cloud", model: dmzBlock("otherworld_cloud"), hardness: 0.3,
    speed: 1.3,                    // walk 30% faster on it
    jump: 1.5                      // and jump higher
});

block("crimson_crystal", {
    name: "Crimson Crystal", model: dmzBlock("crimson_crystal"), hardness: 3, light: 10,
    drops: [{ item: "majilite", count: 1 }, { item: "yellow_capsule", count: 1, chance: 0.1 }]
});

// The Hyperbolic Time Chamber floor (85_world.js builds a dimension out of it).
block("time_chamber_block", {
    name: "Time Chamber Floor", model: dmzBlock("time_chamber_block"),
    hardness: -1,                  // unbreakable
    light: 15
});

// A block you can right-click: meditate for TP once a minute.
block("meditation_mat", {
    name: "Meditation Mat", model: dmzBlock("kikono_block"), hardness: 1,
    onUse(player, x, y, z) {
        let now = RPG.server.getTick();
        let last = player.getVar("meditate_tick", 0);   // per-player saved number
        if (now - last < 1200) {
            player.actionbar("&7Your mind needs rest. (" + Math.ceil((1200 - (now - last)) / 20) + "s)");
            return;
        }
        player.setVar("meditate_tick", now);
        player.addTp(20 + player.getLevel());
        act(player, "base.meditation", 60);
        player.progressQuest("meditate", 1);
        player.actionbar("&bYou meditate... &3+TP");
        RPG.world.particle(player.dimension, "minecraft:enchant", x + 0.5, y + 1.5, z + 0.5, 30, 0.5, 0.5);
    }
});

// The Dragon Ball altar: place all seven Earth balls on it... by right-clicking with a radar.
block("dragon_altar", {
    name: "&6Dragon Altar", model: dmzBlock("dball4"), hardness: -1, light: 10,
    onUse(player, x, y, z) { radarUse(player, "dragon_ball_", "shenron"); }          // 50_items.js
});

// =====================================================================================
//  Decor: plants, leaves and flowers (see-through placeholders 151-200)
// =====================================================================================
[
    ["namek_grass", "Namekian Grass"], ["namek_sacred_grass", "Sacred Grass"], ["namek_fern", "Namekian Fern"], ["sacred_fern", "Sacred Fern"],
    ["makai_bush", "Makai Bush"], ["makai_shrub", "Makai Agave"], ["lotus_flower0", "Lotus"], ["lilypad_namek", "Namekian Lily Pad"],
    ["namek_ajissa_sapling", "Ajissa Sapling"], ["namek_sacred_sapling", "Sacred Sapling"],
    ["potted_namek_fern", "Potted Namekian Fern"], ["potted_sacred_fern", "Potted Sacred Fern"]
].forEach((p) => block(p[0], { name: p[1], model: dmzBlock(p[0]), shape: "cross", collision: false, hardness: 0, drops: "none" }));

["amaryllis_flower", "catharanthus_roseus_flower", "chrysanthemum_flower", "marigold_flower", "trillium_flower"].forEach((f) => {
    let label = f.replace("_flower", "").replace("_", " ");
    block(f, { name: "Flower (" + label + ")", model: dmzBlock(f), shape: "cross", collision: false, hardness: 0, drops: [{ item: f + "_bouquet" }] });
    block("sacred_" + f, { name: "&bSacred Flower (" + label + ")", model: dmzBlock("sacred_" + f), shape: "cross", collision: false, hardness: 0, light: 4,
        drops: [{ item: "sacred_" + f + "_bouquet" }] });
});

[["namek_ajissa_leaves", "Ajissa Leaves"], ["namek_sacred_leaves", "Sacred Leaves"], ["might_tree_leaves", "Tree of Might Leaves"]].forEach((l) => {
    block(l[0], { name: l[1], model: dmzBlock(l[0]), decor: true, hardness: 0.2, drops: "none" });
});

block("light_shield", { name: "Light Shield", model: dmzBlock("light_shield"), decor: true, hardness: 1, light: 12 });

// Wild herbs: the grown DMZ crops. Break one to harvest it.
[["aura_lily", "aura_lily"], ["hermit_fern", "hermit_fern"], ["katchin_sprout", "katchin_sprout"], ["meteor_flower", "meteor_flower"],
 ["oozaru_root", "oozaru_root"], ["zenkai_lotus", "zenkai_lotus"], ["namek_moss", "namek_moss"], ["kaioshin_fruit", "kaioshin_fruit"]].forEach((h) => {
    block("wild_" + h[0], {
        name: "Wild " + h[0].replace("_", " "), model: dmzBlock(h[0] + "_crop_stage2"), shape: "cross", collision: false, hardness: 0,
        drops: h[0] === "kaioshin_fruit" ? [{ item: h[1], count: 1, chance: 0.2 }] : [{ item: h[1], count: 1 }, { item: h[1], count: 1, chance: 0.5 }]
    });
});

// ---- Senzu crops: plant seeds (50_items.js), they grow through three stages ----------------
// onRandomTick runs now and then (like vanilla crop growth): swap in the next stage block.
["red", "blue", "yellow"].forEach((color) => {
    for (let stage = 0; stage <= 2; stage++) {
        let name = "senzu_" + color + "_crop_" + stage;
        let next = stage < 2 ? "senzu_" + color + "_crop_" + (stage + 1) : null;
        block(name, {
            name: "Senzu Crop (" + color + ", stage " + (stage + 1) + ")",
            model: dmzBlock("senzu_" + color + "_crop_stage" + stage),
            shape: "cross", collision: false, hardness: 0,
            drops: stage < 2 ? [{ item: "senzu_bean_seeds_" + color }] :
                [{ item: "senzu_bean_" + color, count: 2 }, { item: "senzu_bean_seeds_" + color, count: 1 }, { item: "senzu_bean", count: 1, chance: 0.05 }],
            onRandomTick: next ? growTo(next) : undefined
        });
    }
});

// growTo("x") returns a function, so each crop stage remembers its own next stage.
function growTo(nextName) {
    return (dimension, x, y, z) => {
        if (RPG.chance(0.35)) RPG.world.setBlock(dimension, x, y, z, blockRef(nextName));
    };
}

// Used by Senzu seeds: plant on top of the block the player looks at.
function plantCrop(player, cropName) {
    let at = player.lookBlock(5);
    if (!at) { player.actionbar("&7Look at the ground."); return false; }
    let ground = RPG.world.getBlock(player.dimension, at[0], at[1], at[2]);
    if (ground.indexOf("dirt") < 0 && ground.indexOf("grass") < 0 && ground.indexOf("farmland") < 0 && ground.indexOf("ragnarok_rpg:") < 0) {
        player.actionbar("&7Plant it in dirt or grass."); return false;
    }
    if (RPG.world.getBlock(player.dimension, at[0], at[1] + 1, at[2]) !== "minecraft:air") { player.actionbar("&7There's no room."); return false; }
    RPG.world.setBlock(player.dimension, at[0], at[1] + 1, at[2], blockRef(cropName));
    sfx(player, "minecraft:item.crop.plant", 1, 1);
}
