// =====================================================================================
//  00_project.js - who made this project, and the big game rules
// =====================================================================================
//  Welcome! This folder is a complete DragonMine Z recreation written in JavaScript:
//  layered, colourable race models, transformations with auras, ki beams, flight,
//  Dragon Balls, sagas, masters, bosses and the Hyperbolic Time Chamber.
//
//  None of that is built into the engine. The engine only knows "stats", "skills",
//  "effects", "projectiles", "avatars"... and this folder fills them with Dragon Ball.
//  Swap the data and the same engine makes Zelda, Sonic or a shooter (README > 15).
//
//  Every file in scripts/ runs in name order (00, 01, 05, 10, ...) and they all share
//  the same variables, so a helper made in 01_toolbox.js can be used in 90_hooks.js.
//
//  Change something, save, then type  /rpg reload  in game. Errors show in chat
//  (for operators) and with  /rpg errors.  Full guide: README.md in this folder.
//
//  Tip: open this folder in VS Code. api.d.ts gives you autocomplete for RPG.*
// =====================================================================================

// ---- Project info -------------------------------------------------------------------
// "id" + "version" let servers offer their art to players who join (see README > Packs).
RPG.project.configure({
    id: "dmz-starter",
    name: "DragonMine Z (Ragnarok edition)",
    version: "2.0.0",
    author: "Ragnarok Studios",
    description: "A DragonMine Z recreation: six layered races, 30+ transformations, 40+ techniques, flight, ki charging, Dragon Balls, four sagas, masters, world bosses and the Hyperbolic Time Chamber."
});

// ---- Leveling & training (DMZ style) ------------------------------------------------
// mode "both": killing things gives XP -> levels -> SKILL points.
//              fighting & training gives TP -> spend TP on STATS in the menu (K).
// Other modes: "levels" (classic RPG: levels give stat points) or "tp" (TP only).
RPG.leveling.configure({
    mode: "both",
    maxLevel: 150,

    // XP needed for the next level = xpBase * level ^ xpExponent  (level 1 -> 100, level 10 -> ~4000)
    xpBase: 100,
    xpExponent: 1.6,
    // Or write your own curve instead:  xpForLevel: (level) => 50 * level * level,

    skillPointsPerLevel: 1,
    startingSkillPoints: 1,
    refillOnLevelUp: true,                 // full health and ki when you level up
    levelUpMessage: "&6&lPOWER UP! &eYou reached level {level}.",
    showXpGain: true,                      // "+12 XP" on the action bar

    xpPerHealth: 1,                        // kill XP = the victim's max health x this
    pvpXp: 50,                             // XP for killing another player
    deathXpLoss: 0.1,                      // lose 10% of your current XP bar on death

    partyShare: 0.5,                       // party members nearby get 50% of your kill XP
    partyRange: 48,
    partyMaxSize: 6,

    skillMastery: true,                    // multi-level skills improve the more you use them
    allowRaceChange: false,                // ops can always change with /rpg race <player> <id>
    allowClassChange: false,

    // TP (Training Points): how players earn them and what stats cost.
    tp: {
        perHit: 1,                         // every melee/skill hit
        perDamage: 0.2,                    // + 0.2 TP per point of damage dealt
        perKill: 5,                        // every kill...
        perKillHealth: 0.25,               // ...+ 0.25 TP per point of the victim's max health
        perMinute: 10,                     // just for being online
        multiplier: 1,                     // global multiplier (races/classes have their own)
        costBase: 10,                      // the first stat point costs 10 TP...
        costGrowth: 0.04                   // ...and every point you own makes the next 4% pricier
    }
});

// ---- Money --------------------------------------------------------------------------
// Zeni: the HUD shows it in the scouter frame. Shops, quests and bosses pay it out.
RPG.currency.configure({
    name: "Zeni",
    symbol: "Z",
    starting: 100
});

// ---- Combat -------------------------------------------------------------------------
// The stat names here are the ids from 10_stats.js.
RPG.combat.configure({
    damageStat: "strength", damageScale: 0.5,       // melee hits: +0.5 damage per Strength
    rangedStat: "kipower", rangedScale: 0.2,        // arrows/projectiles: +0.2 per Ki Power
    unarmedDamage: 2,                               // bare fists hit for 2 instead of vanilla's 1...
    unarmedStat: "strike", unarmedScale: 0.6,       // ...+0.6 per Strike
    critChance: 0.05, critStat: "strike", critPerStat: 0.001, critMultiplier: 1.75,
    defenseStat: "resistance", defenseScale: 0.25,  // each Resistance point blocks 0.25 damage...
    minDamageFraction: 0.2,                         // ...but you always take at least 20%
    tpPerDamageTaken: 0.1                           // getting beaten up is training too
    // Full control instead:  damageFormula: (e) => e.amount * 2,   defenseFormula: (e) => e.amount
});
