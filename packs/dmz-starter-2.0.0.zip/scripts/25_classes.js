// =====================================================================================
//  25_classes.js - fighting styles
// =====================================================================================
//  Same fields as races, plus startingItems (given once, the first time the class is
//  chosen). A player has one race AND one class, so their bonuses stack.
//  DMZ has exactly these two styles. The gi pieces are defined in 52_armor.js.
//  A class can also have an avatar (it beats the race's, loses to a form's):
//      avatar: humanAvatar("human", { colors: { hair: "#FFFFFF" } })
// =====================================================================================

RPG.classes.define("warrior", {
    name: "Warrior",
    description: "Fists and blades first. Stronger melee, tougher body, more stamina.",
    stats: { strength: 3, strike: 3, resistance: 2 },
    statsPerLevel: { strength: 0.2, strike: 0.2 },
    skills: ["dragon_rush"],
    // Write every entry the same way: all "names", or all { item, count } (mixing breaks the list).
    startingItems: [
        { item: "turtle_gi_chest" }, { item: "turtle_gi_legs" }, { item: "turtle_gi_boots" },
        { item: "senzu_bean", count: 1 }
    ],
    onSelect(player) {
        player.tell("&cWarrior: &7your punches hit harder (Strike) and weapons scale with Strength.");
    }
});

RPG.classes.define("spiritualist", {
    name: "Spiritualist",
    description: "Masters of ki. Bigger ki pool, stronger blasts and cheaper techniques.",
    stats: { kipower: 4, energy: 4 },
    statsPerLevel: { kipower: 0.3 },
    tpMultiplier: 1.05,
    skills: ["ki_barrage"],
    startingItems: [
        { item: "demon_gi_head" }, { item: "demon_gi_chest" }, { item: "demon_gi_legs" }, { item: "demon_gi_boots" },
        { item: "senzu_bean", count: 1 }
    ],
    onSelect(player) {
        player.tell("&bSpiritualist: &7your ki attacks scale with Ki Power, your ki pool with Energy.");
    }
});
