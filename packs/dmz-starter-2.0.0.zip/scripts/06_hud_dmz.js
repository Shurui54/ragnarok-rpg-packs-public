// =====================================================================================
//  06_hud_dmz.js - the DMZ-style HUD, built from script data
// =====================================================================================
//  The whole HUD below is just data: groups of images, bars, text and a portrait, all
//  cut from textures in the resource pack (here DMZ's own hud_default.png). Change any
//  number, swap the texture, add bars for new resources, or delete this file to get the
//  built-in Ragnarok scouter HUD back.
//
//  Players can move / resize / hide each group themselves: Menu (K) > Options >
//  "Move / resize HUD" (or bind "Move / resize HUD" in Controls). Their changes are
//  saved only on their own computer.
//
//  Element types:
//    image    { texture, x, y, w, h, u, v, uw, vh, texW, texH, color, alpha, z }  (z: draw above portraits)
//    bar      { value, x, y, w, h, texture?, u, v, uw, vh, texW, texH, color, trail,
//               lowAt, lowColor, direction: "right"|"left"|"up"|"down", background }
//             value: "health", "xp", "food", "armor", "air", "resource:<id>",
//                    "stat:<id>" (+ max), "var:<name>" (+ max).  color "auto" = resource colour
//    text     { text, x, y, color, scale, align: "left"|"center"|"right",
//               style: "outline"|"shadow"|"plain" }
//             tokens: {level} {xp} {xpMax} {money} {tp} {health} {maxHealth} {name} {race}
//                     {class} {statPoints} {skillPoints} {res:ki} {resMax:ki} {pct:ki}
//                     {stat:strength} {var:name}
//    portrait { x, y, w, h, zoom, offsetY }  - the live player model, clipped to the box
//  Any element: showIf: "resource:<id>" | "tp" | "money" | "var:<name>"
//  Group anchors: top_left, top, top_right, left, center, right, bottom_left, bottom, bottom_right
// =====================================================================================

const DMZ_HUD = "dmzpack:textures/gui/hud/hud_default.png";

// One DMZ bar: dark frame, then the white fill tinted with a colour, then a value readout.
// (frame and fill regions are measured from hud_default.png; the fill sits 3px inside.)
function dmzBar(y, frameV, frameH, fillV, fillH, value, color, extra) {
    return [
        { type: "image", texture: DMZ_HUD, texW: 512, texH: 512, x: 78, y: y, w: 256, h: frameH, u: 0, v: frameV },
        Object.assign({ type: "bar", value: value, texture: DMZ_HUD, texW: 512, texH: 512,
            x: 81, y: y + 3, w: 250, h: fillH, u: 0, v: fillV, color: color, trail: "#FFFFFF" }, extra || {}),
    ];
}

function readout(y, text) {
    return { type: "text", text: text, x: 206, y: y, align: "center", scale: 1.5, color: "#FFFFFF", style: "outline" };
}

RPG.ui.configure({
    hud: {
        layout: [
            {
                id: "status", label: "Status bars",
                anchor: "top_left", x: 4, y: 4, scale: 0.5,
                elements: [].concat([
                    // portrait box: backdrop, the live player, border on top
                    { type: "image", texture: DMZ_HUD, texW: 512, texH: 512, x: 0, y: 0, w: 74, h: 74, u: 260, v: 0 },
                    { type: "portrait", x: 4, y: 4, w: 66, h: 66, zoom: 70, offsetY: 150 },
                    { type: "image", texture: DMZ_HUD, texW: 512, texH: 512, x: 3, y: 3, w: 68, h: 68, u: 263, v: 78, z: 200 },
                    { type: "text", text: "Lv {level}", x: 37, y: 78, align: "center", scale: 1.6, color: "#FFD34D" },

                ],
                    // health, ki, stamina
                    dmzBar(0, 0, 32, 66, 26, "health", "#E8323C", { lowAt: 0.25, lowColor: "#FF1E1E" }), [
                    readout(9, "{health} / {maxHealth}"),
                ],
                    dmzBar(34, 120, 26, 147, 20, "resource:ki", "auto", { showIf: "resource:ki" }), [
                    Object.assign(readout(40, "{res:ki} / {resMax:ki}"), { showIf: "resource:ki" }),
                ],
                    dmzBar(62, 189, 22, 212, 16, "resource:stamina", "#F5A623", { showIf: "resource:stamina" }), [
                    Object.assign(readout(67, "{res:stamina} / {resMax:stamina}"), { showIf: "resource:stamina" }),

                    // thin XP strip under the bars
                    { type: "bar", value: "xp", x: 81, y: 86, w: 250, h: 4, color: "#7FD8FF", background: "#0B1430" },
                ]),
            },
            {
                id: "wallet", label: "Zeni & TP",
                anchor: "top_left", x: 4, y: 52, scale: 0.75,
                elements: [
                    { type: "text", text: "&6{money} &eZeni", x: 0, y: 0, style: "shadow" },
                    { type: "text", text: "&b{tp} TP", x: 0, y: 11, style: "shadow", showIf: "tp" },
                ],
            },
        ],
    },
});
