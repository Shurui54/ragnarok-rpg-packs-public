// =====================================================================================
//  15_resources.js - Ki and Stamina bars
// =====================================================================================
//  A resource is a bar that skills spend (cost: { ki: 10 }) and that refills over time.
//  Any number can grow with level or stats:
//      max: 50            the starting value
//      maxPerLevel: 2     +2 for every level after the first
//      maxPerStat: { energy: 10 }   +10 for every point of Energy
//  The same trick works for regen (regenPerLevel, regenPerStat). regen is per second.
// =====================================================================================

RPG.resources.define("ki", {
    name: "Ki",
    color: "#3FA9FF",
    max: 50,
    maxPerLevel: 2,
    maxPerStat: { energy: 10 },
    regen: 1,                      // 1 ki per second...
    regenPerStat: { energy: 0.2 }, // ...+0.2 per Energy point
    regenInterval: 20,             // apply regen every 20 ticks (1 second)
    startFull: true,
    refillOnRespawn: true,
    hud: "primary"                 // or set ui.hud.primary in 05_ui.js
});

RPG.resources.define("stamina", {
    name: "Stamina",
    color: "#FF9A2E",
    max: 50,
    maxPerStat: { vitality: 4 },
    regen: 4,
    regenInterval: 10,             // twice a second, feels snappier
    startFull: true,
    refillOnRespawn: true,
    hud: "secondary"
    // The stamina bar keeps its own orange art. hudTint: true would paint it with `color` instead.
});

// Charging ki (hold C, 45_keys.js) refills this bar much faster than regen. Flying, dashing
// and transformations drain it. Out of ki = forms drop and techniques fail.
