// =====================================================================================
//  07_creator_dmz.js - a DMZ-style character creator, made entirely in script
// =====================================================================================
//  New players see this on first join (RPG.ui.configure({ creator: "dmz" }) below).
//  Every step is plain data: change the order, add steps, remove them, or write a
//  completely different creator (a Zelda hero picker, a CoD loadout screen...).
//
//  How picks reach the model: a "choice" or "color" step stores its value as the
//  player's look value `key`. Avatar layers (20_races.js) read look values as
//  colours (color: "hair"), inside texture paths ("bodytype_{bodyType}_layer1.png")
//  and in conditions (when: "hairStyle!=bald"). The preview updates live.
//
//  Step fields: id, label, description, type ("race" | "class" | "choice" | "color"),
//  key (defaults to the id), options [{ value, name, description, showIf }],
//  palette ["#hex"...], names [...], custom (any colour allowed), default,
//  showIf ("race=human|saiyan", "race!=majin", "hairStyle"), required (default true),
//  target: "var" (store in player vars instead of the look).
//  Open it again later with RPG.creators.open(player, "dmz") (needs allowRedo: true).
// =====================================================================================

const HUMANLIKE = "race=human|saiyan";

function numbered(count, label) {
    let out = [];
    for (let i = 0; i < count; i++) out.push({ value: String(i), name: label + " " + (i + 1) });
    return out;
}

const SKIN_TONES = ["#FFE0D0", "#FFD3C9", "#F2C2A0", "#E0A97E", "#C68A5E", "#9C6B45", "#6E4A30", "#4A3020"];
const HAIR_COLORS = ["#222629", "#4A2E1C", "#8A5A2B", "#E8C468", "#F5F0E6", "#B23A3A", "#3A6BC2", "#7A3FA8"];
const EYE_COLORS = ["#222629", "#3B2A1A", "#2E6FD8", "#2E9E4F", "#8A2BE2", "#C9302C", "#E5C100", "#7FD8FF"];

RPG.creators.define("dmz", {
    title: "Create your warrior",
    allowRedo: false,      // set true to let players re-open it (RPG.creators.open)
    closeable: false,      // first-join creator can't be skipped
    steps: [
        { id: "race", label: "Race", type: "race",
          description: "Your race sets your body, your forms and your starting stats." },

        { id: "bodyType", label: "Body", type: "choice", showIf: HUMANLIKE,
          options: [
              { value: "male_1", name: "Male" },
              { value: "male_2", name: "Male (buff)" },
              { value: "male_2_slim", name: "Male (slim)" },
              { value: "female_1", name: "Female" },
              { value: "female_2", name: "Female (alt)" },
          ] },
        { id: "bodyTypeNamek", key: "bodyType", label: "Body", type: "choice", showIf: "race=namekian|frost_demon|bio_android",
          options: numbered(3, "Type") },
        { id: "bodyTypeMajin", key: "bodyType", label: "Body", type: "choice", showIf: "race=majin",
          options: [
              { value: "male_0", name: "Male" }, { value: "male_1", name: "Male (big)" },
              { value: "female_0", name: "Female" }, { value: "female_1", name: "Female (alt)" },
          ] },

        { id: "skin", key: "body1", label: "Skin", type: "color", showIf: HUMANLIKE, palette: SKIN_TONES, custom: true },
        { id: "skinNamek", key: "body1", label: "Skin", type: "color", showIf: "race=namekian",
          palette: ["#5DB85C", "#4CAF50", "#7CC576", "#3E8E41", "#9ED89A"] },
        { id: "skinFrost", key: "body1", label: "Main colour", type: "color", showIf: "race=frost_demon",
          palette: ["#F5F5F5", "#E0D8F0", "#C9C9C9", "#FFE7F0", "#D0E8FF"] },
        { id: "skinMajin", key: "body1", label: "Skin", type: "color", showIf: "race=majin",
          palette: ["#FFB6D9", "#F49AC2", "#E57EB0", "#C8A2C8", "#9EC9FF"] },

        { id: "hairStyle", label: "Hair", type: "choice", showIf: HUMANLIKE,
          options: [{ value: "base", name: "Spiky" }, { value: "bald", name: "Bald" }] },
        { id: "hair", label: "Hair colour", type: "color", showIf: HUMANLIKE + " && hairStyle!=bald", palette: HAIR_COLORS, custom: true },

        { id: "eyeStyle", label: "Eyes", type: "choice", showIf: HUMANLIKE, options: numbered(13, "Eyes") },
        { id: "eyes", label: "Eye colour", type: "color", palette: EYE_COLORS, custom: true },
        { id: "nose", label: "Nose", type: "choice", showIf: HUMANLIKE, options: numbered(6, "Nose") },
        { id: "mouth", label: "Mouth", type: "choice", showIf: HUMANLIKE, options: numbered(9, "Mouth") },

        { id: "class", label: "Fighting style", type: "class", required: false,
          description: "How you fight. You can train other styles later." },
    ],

    // Runs on the server once the player presses Finish (picks are already applied).
    onFinish(player, choices) {
        player.sendMessage("&6Welcome, " + player.name + "! &7Press &eK &7for your status and techniques.");
        RPG.log(player.name + " created a " + choices.race + " (" + choices.bodyType + ")");
    },
});

RPG.ui.configure({ creator: "dmz" });
