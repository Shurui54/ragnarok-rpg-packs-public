// =====================================================================================
//  85_world.js - custom dimensions (Time Chamber, Namek, Other World) and structures
// =====================================================================================
//  RPG.dimensions.define("id", {...}) creates "ragnarok_rpg:id". Minecraft only loads
//  dimensions when a world starts, so restart the world/server ONCE after adding or
//  changing one (the load report tells you).
//    generator: "normal" | "nether" | "end" | "caves" | "floating_islands" | "flat" | "void"
//    layers (flat only), biome, effects (sky), fixedTime, ambientLight, hasSkylight, minY, height
//  The floors are this project's own blocks (55_blocks.js): blockRef("name") gives their id.
// =====================================================================================

// ---- The Hyperbolic Time Chamber: an endless white floor, always bright ----------------
RPG.dimensions.define("time_chamber", {
    generator: "flat",
    biome: "minecraft:the_void",           // no vanilla mobs, no trees
    layers: [
        { block: "minecraft:bedrock", height: 1 },
        { block: blockRef("time_chamber_block"), height: 2 }
    ],
    minY: 0,
    height: 256,                           // so the floor surface is at y = 3
    effects: "minecraft:overworld",
    fixedTime: 6000,                       // always noon
    ambientLight: 1.0,                     // fully bright, like the real chamber
    bedWorks: false
});

// ---- Planet Namek: green grass, blue water... well, green grass at least -----------------
RPG.dimensions.define("namek", {
    generator: "flat",
    biome: "minecraft:plains",
    layers: [
        { block: "minecraft:bedrock", height: 1 },
        { block: blockRef("namek_deepslate"), height: 24 },
        { block: blockRef("namek_stone"), height: 26 },
        { block: blockRef("namek_dirt"), height: 3 },
        { block: blockRef("namek_grass_block"), height: 1 }
    ],
    minY: 0,
    height: 256,                           // surface at y = 55
    effects: "minecraft:overworld",
    fixedTime: 6000                        // Namek has three suns: it's always day
});

// ---- The Other World: Snake Way's clouds ---------------------------------------------------
RPG.dimensions.define("otherworld", {
    generator: "flat",
    biome: "minecraft:the_void",
    layers: [
        { block: "minecraft:bedrock", height: 1 },
        { block: blockRef("otherworld_cloud"), height: 3 }
    ],
    minY: 0,
    height: 256,                           // surface at y = 4
    effects: "minecraft:overworld",
    fixedTime: 6000,
    ambientLight: 0.4
});

var TIME_CHAMBER = "ragnarok_rpg:time_chamber";
var NAMEK = "ragnarok_rpg:namek";
var OTHERWORLD = "ragnarok_rpg:otherworld";

// Remember where the player came from, then go.
function travel(player, dimension, x, y, z, title, subtitle) {
    if (player.dimension.indexOf("ragnarok_rpg:") !== 0) {
        player.setVar("travel_return", player.dimension + " " + player.x + " " + player.y + " " + player.z);
    }
    player.teleportTo(dimension, x, y, z);
    sfx(player, "tp", 1, 0.8);
    player.title(title, subtitle);
}

// The first visitor to a world finds its residents waiting (spawned once per server).
function populateOnce(key, dimension, npcs) {
    if (RPG.server.getData(key, 0)) return;
    RPG.server.setData(key, 1);
    npcs.forEach((n) => RPG.world.spawnNpc(dimension, n[0], n[1], n[2], n[3]));
}

// Called by Mr. Popo's dialogue (60_npcs_dialogue.js).
function enterTimeChamber(player) {
    travel(player, TIME_CHAMBER, 0.5, 4, 0.5, "&fHyperbolic Time Chamber", "&7TP x2 while inside. Leave with /rpgc leave");
}

function enterNamek(player) {
    travel(player, NAMEK, 0.5, 56, 0.5, "&aPlanet Namek", "&7Frieza's soldiers are everywhere. Leave with /rpgc leave");
    populateOnce("namek_populated", NAMEK, [
        ["guru", 12, 56, 12], ["namek_villager_0", -10, 56, 6], ["namek_villager_1", -14, 56, 2], ["namek_villager_2", -8, 56, -6],
        ["namek_villager_3", -12, 56, -10], ["dende", 16, 56, 8]
    ]);
}

function enterOtherworld(player) {
    travel(player, OTHERWORLD, 0.5, 5, 0.5, "&eThe Other World", "&7Follow Snake Way to King Kai. Leave with /rpgc leave");
    populateOnce("otherworld_populated", OTHERWORLD, [
        ["king_kai", 0, 5, 200], ["grand_kai", 40, 5, 220], ["old_kai", -40, 5, 220], ["otherworld_announcer", 44, 5, 214],
        ["supreme_kai", -44, 5, 214], ["kibito", -46, 5, 210]
    ]);
}

// /rpgc leave - back to where you entered.
RPG.commands.register("leave", {
    description: "Leave the Time Chamber, Namek or the Other World",
    run(player, args) {
        if (!player || player.dimension.indexOf("ragnarok_rpg:") !== 0) return;
        let saved = String(player.getVar("travel_return", "minecraft:overworld 0 100 0")).split(" ");
        player.teleportTo(saved[0], Number(saved[1]), Number(saved[2]), Number(saved[3]));
        sfx(player, "tp", 1, 1.2);
    }
});

// =====================================================================================
//  Structures
// =====================================================================================
//  1. Build something, save it with a structure block (e.g. name "ragnarok_rpg:kame_house").
//  2. Copy the .nbt from the world's generated/ folder into
//     datapack/data/ragnarok_rpg/structures/kame_house.nbt in this project.
//  3. Either place it from code, or let it generate in new chunks:
//
// RPG.structures.place("minecraft:overworld", "ragnarok_rpg:kame_house", 100, 64, 200, 0);
//
// RPG.structures.define("kame_house", {
//     template: "ragnarok_rpg:kame_house",
//     biomes: ["minecraft:beach", "minecraft:warm_ocean"],   // or a tag: "#minecraft:is_beach"
//     spacing: 48,                // about one every 48 chunks...
//     separation: 16,             // ...and never closer than 16
//     terrainAdaptation: "beard_thin"
// });
//  Worldgen is read when a world loads too: restart once, and only NEW chunks get it.
