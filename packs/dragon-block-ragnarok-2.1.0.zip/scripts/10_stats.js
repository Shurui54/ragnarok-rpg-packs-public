// =====================================================================================
//  10_stats.js - the six DMZ stats (STR SKP RES VIT PWR ENE)
// =====================================================================================
//  A stat is just a number every player has. Its final value =
//      base + race bonus + class bonus + points bought with TP + gear + forms/effects
//  "attributes" turn stat points into real Minecraft attributes (health, armor, speed...).
//  Combat and skills read stats too (see 00_project.js and 40_skills.js).
// =====================================================================================

RPG.stats.define("strength", {
    name: "Strength",
    description: "STR - melee damage with weapons (+0.5 per point).",
    color: "#FF5555",
    base: 5,
    max: 10000
});

RPG.stats.define("strike", {
    name: "Strike",
    description: "SKP - bare-fist damage, critical hits and a little speed.",
    color: "#FFAA00",
    base: 5,
    max: 10000,
    attributes: {
        // +0.0005 walk speed per point (vanilla walk speed is 0.1, so 100 Strike = +50%).
        "minecraft:generic.movement_speed": 0.0005
    }
});

RPG.stats.define("resistance", {
    name: "Resistance",
    description: "RES - blocks incoming damage and adds armor.",
    color: "#AAAAAA",
    base: 5,
    max: 10000,
    attributes: {
        "minecraft:generic.armor": 0.1             // 10 Resistance = 1 armor point
    }
});

// Health per Vitality point. Players start with 20 health + this x Vitality (a new character has about 40).
var HP_PER_VITALITY = 4;

RPG.stats.define("vitality", {
    name: "Vitality",
    description: "VIT - maximum health and stamina.",
    color: "#55FF55",
    base: 5,
    max: 10000,
    attributes: {
        "minecraft:generic.max_health": HP_PER_VITALITY
    }
});

RPG.stats.define("kipower", {
    name: "Ki Power",
    description: "PWR - damage of ki attacks like Ki Blast and Kamehameha.",
    color: "#55FFFF",
    base: 5,
    max: 10000
});

RPG.stats.define("energy", {
    name: "Energy",
    description: "ENE - maximum ki and ki regeneration.",
    color: "#5599FF",
    base: 5,
    max: 10000
    // Make one stat pricier than the rest:  tpCostBase: 15, tpCostGrowth: 0.05,
    // Stop players buying it:               allocatable: false,
    // Cap bought points:                    maxAllocated: 500,
});

// ---- Marker stats ----------------------------------------------------------------------
// Hidden stats nobody can buy. Gear gives them only while worn in its slot, so scripts can
// ask "is this player wearing weights?" with player.stat("weight") > 0.
RPG.stats.define("weight", { name: "Training Weight", hidden: true, allocatable: false, base: 0 });
RPG.stats.define("ki_cloak", { name: "Ki Cloak", hidden: true, allocatable: false, base: 0 });
RPG.stats.define("fame", { name: "Fame", hidden: true, allocatable: false, base: 0 });

var COMBAT_STATS = ["strength", "strike", "resistance", "vitality", "kipower", "energy"];

// ---- A shared helper ----------------------------------------------------------------
// Functions written at the top level can be used by every later file.
// powerLevel(...) is used by scouters (50_items.js), lock-on (45_keys.js) and /rpgc power.
function powerLevel(entity) {
    if (!entity) return 0;
    let player = entity.asPlayer();                // null for mobs
    if (player) {
        if (player.stat("ki_cloak") > 0) return 5;  // the Anti-Ki Cloaking Device
        let total = 0;
        COMBAT_STATS.forEach((id) => { total += player.stat(id); });
        return Math.floor(total * 10 * (1 + player.getLevel() / 20));
    }
    return Math.floor(entity.maxHealth * 25);      // mobs: based on their health
}
