# Dragon Block Ragnarok

Dragon Block Ragnarok is an addon for the Ragnarok RPG Toolkit. Its gameplay systems are a port of
**DragonMine Z** (https://github.com/DragonMineZ/dragonminez), rewritten as toolkit scripts.

- DragonMine Z is Copyright (c) DragonMine Z 2025 and is licensed under the GNU General Public License v3.0.
- This addon is a modified version of that work and is likewise licensed under the **GNU General Public
  License v3.0** (see `LICENSE`). Its scripts are its complete source code.
- Models, textures, animations and sounds come from DragonMine Z through the separate `dmzpack` asset pack,
  which carries its own credits, including CC-BY attributions for third-party sounds.
- Changes: DragonMine Z's Java systems were reimplemented as JavaScript for the Ragnarok RPG Toolkit's script
  engine; content and balance are adapted to that engine.
- The structure templates in `datapack/data/dbr/structures/dmz/` and their descriptions in `data/dmz_structures/`
  are converted from DragonMine Z's structure files, Other World region files and tournament schematic
  (split into 32x32 pieces, DMZ blocks mapped to this addon's blocks or vanilla stand-ins). The chest loot
  tables in `datapack/data/dbr/loot_tables/chests/` are DragonMine Z's.

- The hair system (`shared/11_dmz_hair.js`) ports DragonMine Z's strand hair (hair codes, presets, per-form styles,
  physics profiles); `client/data/dmz_hair_presets/` (one file per preset) and `shared/10_dmz_hair_presets.js` are DragonMine Z's
  hair preset codes, decoded with that file's decoder.

- The in-game form editor (`scripts/32_dbr_form_editor.js`, `client/scripts/70_form_editor.js`) ports the form
  editor screens and form data workflow of DMZ Ragnarok, a GPL-3.0 Forge addon for DragonMine Z.

- The rgnpc NPC cast (`scripts/62_rg_npcs.js`, `shared/14_rg_npc_data.js`, `client/scripts/71_rg_npc_picker.js`,
  `resources/assets/dbr/geo|textures/entity/rgnpc/`) is DMZ Ragnarok's
  rgnpc display NPC table, models and sizes (GPL-3.0). The `saga_*` and `master_*` models and their textures are
  derived from NinjinEntities (kaixi, Vidal1sHere, Phoenix_II) under the MIT License; its notice is
  `ninjin_license.txt` in those folders. The shadow dragon models (`2stars` .. `7starstrue`, `omega`, `omega2`) are
  DMZ Ragnarok's own art. The `dmzpack` asset pack also carries DMZ Ragnarok's RagnaPack textures (see its credits).

- The space system (`scripts/86_dbr_space.js`, `client/scripts/61_dbr_space.js`, the `ragnarok_rpg:space` dimension in
  `datapack/`) ports the behaviour of DMZ Ragnarok's Space module (GPL-3.0): the sun-centred planet rings and their
  wall-clock orbits (Orbits / PlanetPositions), entering space above the entry altitude and leaving below the return
  altitude, landing on planets, the star map with autopilot, the planet info overlay and the radar. The planet, sun,
  ring and cloud textures in `resources/assets/dbr/textures/space/` are DMZ Ragnarok's (its solar system pack and
  planet sheets, and the solar-system pack's block models in `resources/assets/dbr/models/space/`, with their animated
  sun and flare sheets) plus its dragon-ball star sprites. The generated universe (`shared/16_dbr_space_gen.js`,
  `shared/17_dbr_space_bodies.js`) reproduces DMZ Ragnarok's GeneratedSystems, StarPositions, BlackHolePositions,
  MoonBody, SuperPlanetPositions, SurfaceDimension cells, SurfaceStamp themes and PlanetWeather bit for bit where they
  are hashes. Planet Vegeta's worldgen (`datapack/data/ragnarok_rpg/dimension*/planet_vegeta.json`,
  `datapack/data/dbr/worldgen/*/vegeta*`, `noise_settings/planet_vegeta.json`) is DMZ Ragnarok's, with its blocks mapped
  to this addon's. Its Saiyan settlement and Saibaman hut structures (`datapack/data/dbr/structures/saiyan_settlement/`,
  `worldgen/{structure,structure_set,template_pool}/saiyan_settlement*`, `saibaman_hut.json`) are DMZ Ragnarok's
  templates, pools and placement, with Rocky blocks mapped to this addon's. The asteroid fields, planet destruction
  (planet buster, the planet clash, the doom sequence, salvage) and Vegeta's garrisons, citizens and traders
  (`shared/18_dbr_space_clash.js`, `scripts/87_dbr_space_buster.js`, `scripts/88_dbr_space_vegeta.js`) port DMZ
  Ragnarok's AsteroidPositions/AsteroidStamp, PlanetBusterModule/PlanetClash/PlanetDestruction/PlanetSalvage and
  PlanetGarrison/SaiyanTraderEntity; the clash meter is DragonMine Z's ClashMeter/BeamClash, drawn on DMZ's ki bar art.

- The dungeons (`scripts/90_dbr_dungeons*.js`, `shared/20_dbr_dungeons_data.js`, `client/scripts/80_dbr_dungeons.js`, the
  `dbr:dungeon_*` dimensions in `datapack/`, `data/dbr_dungeons/`, `client/data/dbr_dungeons/`) port DMZ Ragnarok's
  Dungeons module (GPL-3.0): its floor, rule, spawner and crate models, configuration options, screens and strings.
  The room templates, jigsaw pools and theme palettes in `data/dbr_dungeons/` are converted from DMZ Ragnarok's own
  rooms (built by Ragnarok Studios from DMZ's block palette); the crate models,
  animations and textures and the TP gem icons in `resources/assets/dbr/*/dungeons/` are DMZ Ragnarok's.

- **NBArmors** by **Naruke** (a Dragon Block C addon for Minecraft 1.7.10, version 3.1): its armour art is used with
  the author's permission. The worn armour sheets (`resources/assets/dbr/textures/models/armor/nb/`), the item icons
  (`resources/assets/dbr/textures/item/nb/`) and the Core Ore texture (`resources/assets/dbr/textures/block/nb/`) are
  Naruke's, copied unchanged; the item names come from NBArmors' language file. The armour models in
  `resources/assets/dbr/geo/armor/nb/` rebuild NBArmors' JBRA armour model (ArmorModelNB, trenchNB) and
  `scripts/18_nbarmors_data.js` / `scripts/19_nbarmors.js` its item list, Core items, recipes and Core Ore, all
  generated by `docs/dmz-spec/tools/convert_nbarmors.py` from the released mod. Its cosmetics (vanity items) are
  ported the same way by `docs/dmz-spec/tools/convert_nbarmors_cosmetics.py`: the worn sheets
  (`resources/assets/dbr/textures/models/armor/nbc/`) and icons (`resources/assets/dbr/textures/item/nbc/`) are
  Naruke's, copied unchanged; the models in `resources/assets/dbr/geo/armor/nbc/` rebuild NBArmors' vanity models
  (vanityextra, trenchcoat) and `scripts/19b_nbcosmetics_data.js` / `scripts/19c_nbcosmetics.js` its cosmetic items.
  The art is not covered by this addon's GPL licence: ask Naruke before reusing it elsewhere.

Dragon Ball is a trademark of its respective owners. This is a non-commercial fan project.
