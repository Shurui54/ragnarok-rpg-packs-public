// The Open Backpack key (rebind it in Controls): opens the backpack worn in the Back slot.
RPG.keys.register("backpacks_open", { name: "Open backpack", key: "j" });
RPG.on("keybind", (id, down) => { if (id == "backpacks_open" && down) RPG.net.send("backpack_open", {}); });
