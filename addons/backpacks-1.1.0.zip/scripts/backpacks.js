// =====================================================================================
//  Backpacks - right-click to open, or wear one in the Back slot (Accessories key, B) and open it
//  with the Open Backpack key (J). The items live with the world, keyed by the bag's id, so a
//  backpack keeps its contents when dropped, traded, worn or put in a chest.
// =====================================================================================
(function () {
    var SIZES = {
        small:  { name: "&6Small Backpack",  rows: 2, recipe: ["LSL", "L L", "LLL"], keys: { L: "minecraft:leather", S: "minecraft:string" } },
        medium: { name: "&aMedium Backpack", rows: 4, recipe: ["LIL", "LBL", "LLL"], keys: { L: "minecraft:leather", I: "minecraft:iron_ingot", B: "backpack_small" } },
        large:  { name: "&9Large Backpack",  rows: 6, recipe: ["LDL", "LBL", "LLL"], keys: { L: "minecraft:leather", D: "minecraft:diamond", B: "backpack_medium" } }
    };
    var IDS = {};      // size -> the item's real id

    // the Back accessory slot (other addons can use it too: anything with accessory: "back")
    RPG.slots.define("back", { name: "Back", icon: "backpacks:textures/gui/slot/back.png", order: 10 });

    Object.keys(SIZES).forEach((size) => {
        let s = SIZES[size];
        IDS[size] = "ragnarok_rpg:" + RPG.items.define("backpack_" + size, {
            name: s.name, lore: ["&7Right-click to open", "&7" + (s.rows * 9) + " slots", "&8Wear it in the Back slot (B)"],
            model: "backpacks:rpg/item/backpack_" + size, maxStack: 1, accessory: "back",
            onUse(player) { openHeld(player, size); return true; }
        });
        // recipe keys may name a smaller backpack: use its real id
        let keys = {};
        Object.keys(s.keys).forEach((k) => { let v = s.keys[k]; keys[k] = v.indexOf("backpack_") === 0 ? IDS[v.substring(9)] : v; });
        RPG.recipes.addShaped("backpack_" + size, s.recipe, keys, { id: IDS[size], count: 1 });
    });

    function isBackpack(stack) {
        if (!stack) return false;
        for (let k in IDS) if (IDS[k] === stack.id) return true;
        return false;
    }

    function sizeOf(stack) {
        for (let k in IDS) if (IDS[k] === stack.id) return k;
        return null;
    }

    /** Gives a bag its own id the first time it's opened; save(stack) writes it back where it came from. */
    function bagKey(p, stack, save) {
        let data = stack.data || {};
        if (!data.bag) {
            data.bag = p.uuid.substring(0, 8) + "-" + RPG.server.getTick().toString(36) + "-" + Math.floor(Math.random() * 1e6).toString(36);
            stack.data = data;
            save(stack);
        }
        return "bp:" + data.bag;
    }

    function openHeld(p, size) {
        let held = p.getHeldStack();
        if (!held) return;
        open(p, size, bagKey(p, held, (st) => p.setHeldStack(st)));
    }

    function openWorn(p) {
        let worn = p.getAccessory("back");
        let size = worn ? sizeOf(worn) : null;
        if (!size) { p.actionbar("&7You aren't wearing a backpack (put one in the Back slot with B)"); return; }
        open(p, size, bagKey(p, worn, (st) => p.setAccessory("back", st)));
    }

    RPG.net.on("backpack_open", (p) => openWorn(p));

    function open(p, size, key) {
        RPG.ui.container(p, {
            title: SIZES[size].name, rows: SIZES[size].rows, items: RPG.data.get(key, []),
            onClick(pl, s, stack) {
                // can't put a backpack inside a backpack, or move the open bag around
                if (isBackpack(stack)) return false;
            },
            onClose(pl, items) {
                // a backpack slipped in (shift-click from the hotbar): hand it back
                for (let i = 0; i < items.length; i++) if (isBackpack(items[i])) { pl.giveStack(items[i]); items[i] = null; }
                RPG.data.set(key, items);
            }
        });
        p.playSound("minecraft:item.armor.equip_leather", 0.8, 1.1);
    }
})();
