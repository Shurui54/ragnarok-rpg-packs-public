// =====================================================================================
//  Look HUD (server side)
//  The panel itself is drawn by client/scripts/look_hud.js from what the player's computer knows. A few
//  things only the server knows (what a chest holds, how far a furnace is, who owns a tamed animal, lines
//  other addons add) are answered here when the client asks: at most a few times a second per player, and
//  only for something within reach of that player.
//
//  Other addons add lines (any load order):
//    var LOOK_HUD_LINES = typeof LOOK_HUD_LINES !== "undefined" ? LOOK_HUD_LINES : [];
//    LOOK_HUD_LINES.push(function (target, player) {
//        // target: {kind: "block", dim, x, y, z, block, info} | {kind: "entity", entity (JsEntity), info (EntityInfo)}
//        return target.kind === "entity" && target.info.npc ? "&7Has a quest for you" : null;   // a line, lines or nothing
//    });
//  (client/scripts/look_hud.js documents the same hook on the client: LOOK_HUD_CLIENT_LINES.)
// =====================================================================================
var LOOK_HUD_LINES = typeof LOOK_HUD_LINES !== "undefined" ? LOOK_HUD_LINES : [];

(function () {
    var CFG = RPG.config.define("look_hud", {
        containers: { default: "items", options: ["off", "count", "items"],
            comment: "What the panel tells about containers players look at: nothing, how full they are, or also their most common items" },
        reach: { default: 12, min: 4, max: 64, integer: true, comment: "Farthest block or creature (blocks) the server describes" },
        minIntervalMs: { default: 200, min: 50, max: 2000, integer: true, comment: "Shortest time between two answers to the same player" }
    });
    var LAST = {};

    function near(p, dim, x, y, z) {
        var r = CFG.get("reach") + 2;
        if (String(p.dimension) !== String(dim)) return false;
        var dx = p.x - x, dy = p.y + 1.6 - y, dz = p.z - z;
        return dx * dx + dy * dy + dz * dz <= r * r;
    }
    function extraLines(target, p) {
        var out = [];
        for (var i = 0; i < LOOK_HUD_LINES.length; i++) {
            try {
                var r = LOOK_HUD_LINES[i](target, p);
                if (r === null || r === undefined || r === "") continue;
                if (typeof r === "string") out.push(r);
                else if (r.length !== undefined) for (var j = 0; j < r.length && out.length < 8; j++) if (r[j]) out.push(String(r[j]));
            } catch (e) { RPG.log("[Look HUD] a line provider failed: " + e); }
            if (out.length >= 8) break;
        }
        return out;
    }
    function playerName(uuid) {
        if (!uuid) return "";
        var on = RPG.server.players().filter(function (q) { return String(q.uuid) === String(uuid); })[0];
        return on ? String(on.name) : "";
    }

    RPG.net.on("look_hud_q", function (p, d) {
        if (!d || typeof d.k !== "string") return;
        var now = Date.now(), id = String(p.uuid);
        if (LAST[id] && now - LAST[id] < CFG.get("minIntervalMs")) return;
        LAST[id] = now;
        var reply = { k: d.k };
        if (d.b && d.b.length === 3) {
            var x = Math.floor(d.b[0]), y = Math.floor(d.b[1]), z = Math.floor(d.b[2]), dim = p.dimension;
            if (!near(p, dim, x + 0.5, y + 0.5, z + 0.5) || !RPG.world.isLoaded(dim, x, z)) return;
            var mode = CFG.get("containers");
            var info = RPG.world.blockInfo(dim, x, y, z, mode === "items" ? 6 : 0);
            if (!info) return;
            var b = {};
            if (info.container && mode !== "off") {
                b.container = { slots: info.container.slots, used: info.container.used, items: info.container.items, loot: info.container.loot };
                if (mode === "items") b.container.top = info.container.top.map(function (t) { return { id: String(t.id), count: Number(t.count) }; });
            }
            if (info.furnace) b.furnace = { cook: info.furnace.cook, cookTotal: info.furnace.cookTotal, burn: info.furnace.burn };
            if (info.brewing) b.brewing = { brew: info.brewing.brew, brewTotal: info.brewing.brewTotal, fuel: info.brewing.fuel };
            if (info.bees !== undefined && info.bees !== null) b.bees = info.bees;
            if (info.spawns) b.spawns = String(info.spawns);
            if (info.record) b.record = String(info.record);
            reply.block = b;
            reply.lines = extraLines({ kind: "block", dim: dim, x: x, y: y, z: z, block: String(info.id), info: info }, p);
        } else if (typeof d.e === "string") {
            var ent = RPG.world.entityByUuid(d.e), ei = RPG.world.entityInfo(d.e);
            if (!ent || !ei || !near(p, ei.dimension, ei.x, ei.y + 1, ei.z)) return;
            reply.entity = { rpgId: String(ei.rpgId || ""), boss: !!ei.boss, npc: !!ei.npc, owner: playerName(ei.owner) };
            reply.lines = extraLines({ kind: "entity", entity: ent, info: ei }, p);
        } else return;
        RPG.net.send(p, "look_hud_r", reply);
    });
    RPG.on("playerLeave", function (p) { delete LAST[String(p.uuid)]; });

    RPG.commands.register("lookhud", {
        description: "Look HUD: /rpgc lookhud (settings), /rpgc lookhud on | off",
        run: function (p, args) {
            if (!p) return;
            var a = String(args[0] || "settings").toLowerCase();
            RPG.net.send(p, "look_hud_cmd", { a: a === "on" || a === "off" ? a : "settings" });
        },
        suggest: function () { return ["settings", "on", "off"]; }
    });
})();
