// =====================================================================================
//  Look HUD (client script: runs on each player's computer)
//  A small panel at the top of the screen naming what the crosshair is on, in the spirit of WAILA / Jade.
//  Blocks: icon, name, the mod or addon it comes from, the tool (and tool level) it needs and whether you can
//  harvest it, crop growth, redstone power; chest contents, furnace / brewing progress, bees, spawner mob
//  (asked from the server). Creatures: name, health (hearts or a bar), armour, tamed animals' owner, RPG
//  mobs / NPCs / bosses (faction, role), villager jobs, item frames' item.
//
//  Everything shown is read on this computer (RPG.inspect, a few times a second). Only containers, furnaces
//  and the like, and lines other addons add on the server, need the server: asked when the target changes and
//  at most twice a second while you keep looking (scripts/look_hud.js).
//
//  Settings (saved for you in ragnarok_rpg/local/look_hud/settings.json, the same in every world): /rpgc lookhud,
//  or the "Look HUD settings" key. "Toggle Look HUD" key: unbound, set it in Options > Controls > Ragnarok Modding Toolkit.
//  Move / resize: K > Settings > Move / resize HUD ("Look HUD").
//
//  Other addons add lines here (any load order):
//    var LOOK_HUD_CLIENT_LINES = typeof LOOK_HUD_CLIENT_LINES !== "undefined" ? LOOK_HUD_CLIENT_LINES : [];
//    LOOK_HUD_CLIENT_LINES.push(function (info) { return info.rpgId === "my_npc" ? "&7Sells potions" : null; });
//  info is RPG.inspect()'s answer (see client.d.ts); return a line, lines or nothing. Server lines: scripts/look_hud.js.
// =====================================================================================
var LOOK_HUD_CLIENT_LINES = typeof LOOK_HUD_CLIENT_LINES !== "undefined" ? LOOK_HUD_CLIENT_LINES : [];

var LH_SHOW_KEYS = [
    ["icon", "Icon"], ["mod", "Mod / addon"], ["harvest", "Tool / harvest"], ["growth", "Growth"], ["redstone", "Redstone"],
    ["container", "Containers"], ["progress", "Furnaces"], ["health", "Health"], ["armor", "Armour"],
    ["owner", "Owner"], ["rpg", "Faction / role"], ["extra", "Addon lines"], ["props", "Block state"]
];
var LH_DEFAULT = { on: true, pos: "top", scale: 1, style: "vanilla", hearts: true, show: {} };
LH_SHOW_KEYS.forEach(function (k) { LH_DEFAULT.show[k[0]] = k[0] !== "props"; });

var LH = lhLoad();
var LH_INFO = null;            // RPG.inspect() of the current target, refreshed every other tick
var LH_MODEL = null;           // what to draw: {title, icon, entityId, lines: [...], items: [...], bar, hearts, armor}
var LH_SERVER = {};            // key -> last server answer
var LH_ASK = { key: "", at: 0 };
var LH_PANEL = { w: 0, h: 0 };

function lhLoad() {
    var s = null;
    try { s = RPG.files.readLocal("look_hud/settings.json"); } catch (e) { s = null; }
    if (!s || typeof s !== "object") s = RPG.storage.get("look_hud", null);
    var out = JSON.parse(JSON.stringify(LH_DEFAULT));
    if (s && typeof s === "object") {
        ["on", "pos", "scale", "style", "hearts"].forEach(function (k) { if (s[k] !== undefined && s[k] !== null) out[k] = s[k]; });
        if (s.show) for (var k in out.show) if (s.show[k] !== undefined) out.show[k] = !!s.show[k];
    }
    out.scale = Math.max(0.5, Math.min(2, Number(out.scale) || 1));
    if (["top", "topleft", "topright"].indexOf(out.pos) < 0) out.pos = "top";
    out.style = "vanilla";                                              // one look: vanilla's tooltip (an old "ragnarok" setting is dropped)
    return out;
}
function lhSave() {
    try { RPG.files.writeLocal("look_hud/settings.json", LH); }
    catch (e) { RPG.storage.set("look_hud", LH); }
}

// ---- names ---------------------------------------------------------------------------------------
function lhTitle(s) { return String(s || "").replace(/_/g, " ").replace(/\b\w/g, function (c) { return c.toUpperCase(); }); }
function lhItemName(id) {
    if (!id) return "";
    var i = id.indexOf(":"), ns = i < 0 ? "minecraft" : id.substring(0, i), p = i < 0 ? id : id.substring(i + 1);
    try {
        if (RPG.hasTranslation("item." + ns + "." + p)) return RPG.translate("item." + ns + "." + p);
        if (RPG.hasTranslation("block." + ns + "." + p)) return RPG.translate("block." + ns + "." + p);
    } catch (e) { }
    return lhTitle(p);
}
function lhEntityName(id) {
    if (!id) return "";
    var i = id.indexOf(":"), ns = i < 0 ? "minecraft" : id.substring(0, i), p = i < 0 ? id : id.substring(i + 1);
    try { if (RPG.hasTranslation("entity." + ns + "." + p)) return RPG.translate("entity." + ns + "." + p); } catch (e) { }
    return lhTitle(p);
}
function lhSecs(ticks) { var s = Math.ceil(ticks / 20); return s >= 60 ? Math.floor(s / 60) + "m " + (s % 60) + "s" : s + "s"; }

var LH_TOOL = { pickaxe: "Pickaxe", axe: "Axe", shovel: "Shovel", hoe: "Hoe", sword: "Sword" };
var LH_TIER = { wood: "Wood", gold: "Gold", stone: "Stone", iron: "Iron", diamond: "Diamond", netherite: "Netherite" };
var LH_VILLAGER_LEVEL = ["", "Novice", "Apprentice", "Journeyman", "Expert", "Master"];
var LH_ROLE = { trader: "Trader", follower: "Follower", transporter: "Transporter", bank: "Banker", guard: "Guard", healer: "Healer",
    itemgiver: "Gives items", shop: "Shopkeeper" };

// ---- building what to show ------------------------------------------------------------------------
function lhKey(info) {
    if (!info || info.type === "miss") return "";
    return info.type === "block" ? "b:" + info.x + "," + info.y + "," + info.z + ":" + info.id : "e:" + info.uuid;
}
function lhNeedsServer(info) {
    var s = LH.show;
    if (info.type === "block") return !!info.blockEntity && (s.container || s.progress || s.extra);
    if (info.type === "entity") return info.living && (s.owner || s.rpg || s.extra);
    return false;
}
function lhBuild(info) {
    var s = LH.show, m = { title: "&f" + info.name, icon: "", entityId: -1, lines: [], items: [], bar: null, hearts: null, armor: 0, from: "" };
    var srv = LH_SERVER[lhKey(info)] || null;
    if (info.type === "block") {
        m.icon = info.item || "";
        if (s.harvest) {
            if (info.unbreakable) m.lines.push("&8Unbreakable");
            else if (info.hardness > 0 || info.needsTool) {
                var tool = LH_TOOL[info.tool] || "";
                var tier = LH_TIER[info.toolLevel] || "";
                var what = tool ? (tier ? tier + " " + tool : tool) : (tier ? tier + " tool" : "");
                var ok = info.canHarvest;
                var mark = ok ? "&a✔" : "&c✘";
                if (what) m.lines.push(mark + " &7" + what + (info.heldEffective ? " &8(held)" : ""));
                else if (info.needsTool) m.lines.push(mark + " &7Needs a tool");
                else if (!ok) m.lines.push("&c✘ &7Drops nothing");
            }
        }
        if (s.growth && info.maxAge !== undefined && info.maxAge > 0 && /crop|stem|wart|berry|cocoa|sapling|bamboo|cactus|cane|kelp|vine|potato|carrot|beetroot|wheat|melon|pumpkin|pitcher|torchflower|sniffer|seed/i.test(info.id + " " + info.name)) {
            var pct = Math.floor(100 * info.age / info.maxAge);
            m.lines.push(pct >= 100 ? "&aMature" : "&7Growth: &f" + pct + "%");
        }
        if (s.redstone) {
            var pw = info.power !== undefined ? info.power : info.output !== undefined ? info.output : null;
            if (pw !== null) m.lines.push("&7Power: &c" + pw);
            else if (info.signal > 0) m.lines.push("&7Powered: &c" + info.signal);
            if (info.comparator !== undefined && info.comparator > 0 && !(srv && srv.block && srv.block.container)) m.lines.push("&7Comparator: &c" + info.comparator);
        }
        var b = srv && srv.block;
        if (b) {
            if (s.container && b.container) {
                var c = b.container;
                if (c.loot && c.used === 0) m.lines.push("&7Unopened loot");
                else m.lines.push("&7" + c.used + "/" + c.slots + " slots" + (c.items ? ", &f" + c.items + " &7items" : ""));
                if (c.top) m.items = c.top.slice(0, 6);
            }
            if (s.progress && b.furnace) {
                var f = b.furnace;
                if (f.cookTotal > 0 && f.cook > 0) m.bar = { label: "Smelting", value: f.cook / f.cookTotal, color: "#E8A33A" };
                if (f.burn > 0) m.lines.push("&7Fuel: &f" + lhSecs(f.burn));
            }
            if (s.progress && b.brewing) {
                var br = b.brewing;
                if (br.brew > 0) m.bar = { label: "Brewing", value: 1 - br.brew / br.brewTotal, color: "#B65EE0" };
                m.lines.push("&7Blaze fuel: &f" + br.fuel + "/20");
            }
            if (b.bees !== undefined) m.lines.push("&7Bees: &f" + b.bees + (info.props && info.props.honey_level !== undefined ? " &8| &7Honey: &f" + info.props.honey_level + "/5" : ""));
            if (b.spawns) m.lines.push("&7Spawns: &f" + lhEntityName(b.spawns));
            if (b.record) m.lines.push("&7Playing: &f" + lhItemName(b.record));
        }
        if (s.props && info.props) {
            var n = 0;
            for (var k in info.props) { if (n++ >= 6) break; m.lines.push("&8" + k + ": &7" + info.props[k]); }
        }
    } else {
        if (info.living) m.entityId = info.entityId;
        else m.icon = info.item || info.icon || "";
        if (String(info.name) !== String(info.typeName) && !info.player && !info.rpgId && !info.tamed) m.lines.push("&8" + info.typeName);
        if (info.item !== undefined && !info.living) {
            if (info.item) m.lines.push("&7Holds: &f" + info.itemName + (info.itemCount > 1 ? " &7x" + info.itemCount : ""));
            else if (info.entity === "minecraft:item_frame" || info.entity === "minecraft:glow_item_frame") m.lines.push("&8Empty");
        }
        if (info.living) {
            if (s.health && info.maxHealth > 0) {
                if (LH.hearts && info.maxHealth <= 40 && !info.rpgId) m.hearts = { hp: info.health, max: info.maxHealth, abs: info.absorption || 0 };
                else m.bar = { label: Math.ceil(info.health) + " / " + Math.ceil(info.maxHealth), value: info.health / info.maxHealth, color: "#D23B3B", hp: true };
            }
            if (s.armor && info.armor > 0) m.armor = info.armor;
            if (s.owner && info.tamed) m.lines.push("&7Owner: &f" + (srv && srv.entity && srv.entity.owner ? srv.entity.owner : info.owner));
            if (info.profession && info.profession !== "none" && info.profession !== "nitwit")
                m.lines.push("&7" + lhTitle(info.profession) + " &8(" + (LH_VILLAGER_LEVEL[info.professionLevel] || info.professionLevel) + ")");
            if (info.baby) m.lines.push("&8Baby");
        }
        if (s.rpg && info.rpgId) {
            var kind = srv && srv.entity && srv.entity.boss ? "boss" : info.rpgKind;
            if (kind === "boss") m.title = "&c" + info.name + " &4☠";
            if (kind === "npc") {
                var title = RPG.defField("npc", info.rpgId, "title");
                if (title) m.lines.push("&7" + title);
                var fac = RPG.defField("npc", info.rpgId, "faction");
                if (fac) m.lines.push("&7Faction: &f" + (RPG.defName("faction", fac) || lhTitle(fac)));
                var role = RPG.defField("npc", info.rpgId, "role");
                if (role && LH_ROLE[role]) m.lines.push("&7" + LH_ROLE[role]);
                else if (RPG.defField("npc", info.rpgId, "shop")) m.lines.push("&7Shopkeeper");
            } else if (kind === "mob" && info.hostile) m.lines.push("&8Hostile");
        }
    }
    if (s.extra) {
        LOOK_HUD_CLIENT_LINES.forEach(function (fn) {
            try {
                var r = fn(info);
                if (r === null || r === undefined || r === "") return;
                if (typeof r === "string") m.lines.push(r); else for (var i = 0; i < r.length; i++) if (r[i]) m.lines.push(String(r[i]));
            } catch (e) { }
        });
        if (srv && srv.lines) srv.lines.forEach(function (l) { m.lines.push(String(l)); });
    }
    if (m.lines.length > 12) m.lines.length = 12;
    if (s.mod) m.from = "&9&o" + (info.from || info.mod || "");
    return m;
}

function lhAsk(info, key) {
    var now = RPG.nowMs();
    if (key === LH_ASK.key && now - LH_ASK.at < 500) return;          // twice a second while you keep looking
    if (key !== LH_ASK.key && now - LH_ASK.at < 150) return;          // swinging the camera across a room
    LH_ASK = { key: key, at: now };
    if (info.type === "block") RPG.net.send("look_hud_q", { k: key, b: [info.x, info.y, info.z] });
    else RPG.net.send("look_hud_q", { k: key, e: info.uuid });
}

function lhRefresh() {
    if (!LH.on || !RPG.player.present) { LH_INFO = null; LH_MODEL = null; return; }
    var info = RPG.inspect();
    if (!info || info.type === "miss") { LH_INFO = null; LH_MODEL = null; return; }
    var key = lhKey(info);
    if (lhNeedsServer(info)) lhAsk(info, key);
    LH_INFO = info;
    LH_MODEL = lhBuild(info);
}

RPG.net.on("look_hud_r", function (d) {
    if (!d || !d.k) return;
    LH_SERVER = {};                                                     // only the latest target matters
    LH_SERVER[d.k] = d;
    if (LH_INFO && lhKey(LH_INFO) === d.k) LH_MODEL = lhBuild(LH_INFO);
});

// ---- drawing -------------------------------------------------------------------------------------
var LH_ICONS = "minecraft:textures/gui/icons.png";
function lhSample() {
    return { title: "&fOak Log", icon: "minecraft:oak_log", entityId: -1, lines: ["&a✔ &7Axe", "&7Growth: &f40%"], items: [], bar: null,
        hearts: null, armor: 0, from: LH.show.mod ? "&9&oMinecraft" : "" };
}
function lhMeasure(ctx, m) {
    var hasIcon = LH.show.icon && (m.icon || m.entityId >= 0);
    var textX = hasIcon ? 24 : 4, w = ctx.textWidth(m.title), h = 4 + 10;
    m.lines.forEach(function (l) { w = Math.max(w, ctx.textWidth(l)); h += 10; });
    if (m.hearts) { var n = Math.ceil(m.hearts.max / 2), rows = Math.ceil(n / 10); w = Math.max(w, Math.min(n, 10) * 8 + 1); h += rows * 9 + 1; }
    if (m.bar) { w = Math.max(w, 90); h += 11; }
    if (m.armor > 0) { w = Math.max(w, Math.min(10, Math.ceil(m.armor / 2)) * 8 + 1); h += 10; }
    if (m.items.length) { w = Math.max(w, m.items.length * 18); h += 18; }
    if (m.from) { w = Math.max(w, ctx.textWidth(m.from)); h += 10; }
    h = Math.max(h + 2, hasIcon ? 26 : 0);
    return { w: textX + w + 5, h: h, textX: textX, hasIcon: hasIcon };
}
function lhFrame(ctx, x, y, w, h) {
    ctx.tooltipBox(x, y, w, h);                                         // the vanilla item tooltip
}
function lhDraw(ctx) {
    if (!LH.on && !ctx.isEditing()) return;
    var m = LH_MODEL || (ctx.isEditing() ? lhSample() : null);
    if (!m) return;
    if (RPG.screen.getOpen() && !ctx.isEditing()) return;
    var sz = lhMeasure(ctx, m), sc = LH.scale, W = ctx.width, w = sz.w, h = sz.h;
    var x = LH.pos === "topleft" ? 4 : LH.pos === "topright" ? W - w * sc - 4 : Math.round((W - w * sc) / 2), y = 4;
    LH_PANEL = { w: w, h: h };
    // avoid: at its default spot it steps aside for a game's HUD (drawn before it) instead of covering it; once moved
    // in the HUD editor it stays where the player put it
    if (!ctx.group("look_hud", "Look HUD", x, y, w * sc, h * sc, { avoid: true })) return;
    ctx.push();
    ctx.translate(x, y);
    ctx.scale(sc, sc);
    lhFrame(ctx, 0, 0, w, h);
    if (sz.hasIcon) {
        if (m.entityId >= 0) {
            // fit the creature in a 18 x 20 box: tall ones by height, wide ones by width
            var span = Math.max(LH_INFO && LH_INFO.height ? LH_INFO.height : 1.8, LH_INFO && LH_INFO.width ? LH_INFO.width * 1.2 : 0.6, 0.5);
            ctx.clip(3, 3, 18, 20);
            ctx.entity(m.entityId, 12, 22, Math.min(16, 17 / span), 25);
            ctx.unclip();
        } else ctx.item(m.icon, 4, 5);
    }
    var tx = sz.textX, ty = 4;
    ctx.text(m.title, tx, ty, "#FFFFFF", true); ty += 10;
    m.lines.forEach(function (l) { ctx.text(l, tx, ty, "#AAAAAA", true); ty += 10; });
    if (m.hearts) {
        var n = Math.ceil(m.hearts.max / 2);
        for (var i = 0; i < n; i++) {
            var px = tx + (i % 10) * 8, py = ty + Math.floor(i / 10) * 9, v = m.hearts.hp - i * 2;
            ctx.image(LH_ICONS, px, py, 9, 9, 16, 0, 9, 9, 256, 256);
            if (v >= 2) ctx.image(LH_ICONS, px, py, 9, 9, 52, 0, 9, 9, 256, 256);
            else if (v > 0) ctx.image(LH_ICONS, px, py, 9, 9, 61, 0, 9, 9, 256, 256);
        }
        ty += Math.ceil(n / 10) * 9 + 1;
    }
    if (m.armor > 0) {
        var an = Math.min(10, Math.ceil(m.armor / 2));
        for (var j = 0; j < an; j++) {
            var av = m.armor - j * 2, ax = tx + j * 8;
            ctx.image(LH_ICONS, ax, ty, 9, 9, av >= 2 ? 34 : 25, 9, 9, 9, 256, 256);
        }
        if (m.armor > 20) ctx.text("&7+" + (m.armor - 20), tx + an * 8 + 2, ty + 1, "#AAAAAA", true);
        ty += 10;
    }
    if (m.bar) {
        var bw = Math.max(90, w - tx - 5), v2 = Math.max(0, Math.min(1, m.bar.value));
        ctx.rect(tx, ty, bw, 9, "#FF1A1A1A");
        ctx.rect(tx + 1, ty + 1, Math.round((bw - 2) * v2), 7, m.bar.color);
        ctx.rect(tx + 1, ty + 1, Math.round((bw - 2) * v2), 2, "#40FFFFFF");
        var label = m.bar.hp ? m.bar.label : m.bar.label + " " + Math.floor(v2 * 100) + "%";
        ctx.textAt(label, tx + bw / 2, ty + 1, 0.75, "#FFFFFF", 1, "center", true);
        ty += 11;
    }
    if (m.items.length) {
        m.items.forEach(function (it, k) { ctx.item(it.id, tx + k * 18, ty + 1, it.count); });
        ty += 18;
    }
    if (m.from) ctx.text(m.from, tx, ty, "#5555FF", true);
    ctx.pop();
    ctx.endGroup();
}

// ---- settings screen -----------------------------------------------------------------------------
function lhSettings() {
    var els = [], W = 250, half = W / 2 - 2, rowH = 15, y0 = -98;
    els.push({ id: "bg", type: "panel", anchor: "center", x: -W / 2 - 8, y: y0 - 18, w: W + 16, h: 206 });
    els.push({ id: "title", type: "text", anchor: "center", x: 0, y: y0 - 13, text: "Look HUD", align: "center", color: "#404040", shadow: false });
    function btn(id, label, x, y, w, fn) { els.push({ id: id, type: "button", anchor: "center", x: x, y: y, w: w, h: 13, label: label, onClick: fn }); }
    function change(fn) { return function () { fn(); lhSave(); lhSettings(); }; }
    btn("on", "Shown: " + (LH.on ? "&aOn" : "&cOff"), -W / 2, y0, half, change(function () { LH.on = !LH.on; }));
    var posName = { top: "Top", topleft: "Top left", topright: "Top right" }, order = ["top", "topleft", "topright"];
    btn("pos", "Position: " + posName[LH.pos], 2, y0, half, change(function () { LH.pos = order[(order.indexOf(LH.pos) + 1) % 3]; }));
    btn("hearts", "Health: " + (LH.hearts ? "Hearts" : "Bar"), -W / 2, y0 + rowH, half, change(function () { LH.hearts = !LH.hearts; }));
    btn("smaller", "-", -W / 2, y0 + rowH * 2, 16, change(function () { LH.scale = Math.max(0.5, Math.round((LH.scale - 0.1) * 10) / 10); }));
    els.push({ id: "scale", type: "text", anchor: "center", x: -W / 2 + half / 2, y: y0 + rowH * 2 + 3, text: "Size " + Math.round(LH.scale * 100) + "%", align: "center", color: "#404040", shadow: false });
    btn("bigger", "+", -W / 2 + half - 16, y0 + rowH * 2, 16, change(function () { LH.scale = Math.min(2, Math.round((LH.scale + 0.1) * 10) / 10); }));
    btn("reset", "Defaults", 2, y0 + rowH, half, change(function () { LH = JSON.parse(JSON.stringify(LH_DEFAULT)); }));
    els.push({ id: "showh", type: "text", anchor: "center", x: -W / 2, y: y0 + rowH * 3 + 4, text: "Show", color: "#404040", shadow: false });
    LH_SHOW_KEYS.forEach(function (k, i) {
        var col = i % 2, row = Math.floor(i / 2);
        btn("s_" + k[0], (LH.show[k[0]] ? "&a\u2714 &f" : "&8\u2718 &7") + k[1], col ? 2 : -W / 2, y0 + rowH * 4 + row * rowH, half,
            change(function () { LH.show[k[0]] = !LH.show[k[0]]; }));
    });
    btn("done", "Done", -40, y0 + rowH * 11 + 4, 80, function () { RPG.screen.close(); });
    RPG.screen.open({ id: "look_hud_settings", background: "dim", elements: els, closeOnEsc: true });
}

// ---- keys, commands, loop --------------------------------------------------------------------------
RPG.on("load", function () {
    RPG.keys.register("look_hud_toggle", { name: "Toggle Look HUD" });
    RPG.keys.register("look_hud_settings", { name: "Look HUD settings" });
    RPG.hud.onRender(lhDraw);
});
RPG.on("keybind", function (id, down) {
    if (!down) return;
    if (id === "look_hud_toggle") { LH.on = !LH.on; lhSave(); lhRefresh(); }
    else if (id === "look_hud_settings") lhSettings();
});
RPG.net.on("look_hud_cmd", function (d) {
    if (d.a === "on" || d.a === "off") { LH.on = d.a === "on"; lhSave(); lhRefresh(); }
    else lhSettings();
});
RPG.every(2, lhRefresh);
