// =====================================================================================
//  64_dmz_surge.js - DMZ's Ki Surge (KiSurgeService, SurgeBarState)
// =====================================================================================
//  Keep charging ki (C) at full ki: the burst arms (a small shockwave if this charge started
//  below full ki), then the surge bar fills in 4 s. Full: a big non-lethal burst and 12 s of
//  surge (ki damage x1.15, ki speed x1.25, charge x1.2, ki cost x1.25, move x1.25, fly x1.25,
//  attack speed x1.4), then a 15 s cooldown. Getting hit while charging drops the charge and any
//  partial surge (and locks C for 10 ticks); a stun or guard break cuts an active surge short.
//
//  Vars: dmz_surge 0..100 (the bar, 10_hud_xenoverse.js), dmz_surge_active 0|1 (others scale ki
//  damage/speed/cost/charge by DMZ_SURGE.mult(p, "kiDamage"|"kiSpeed"|"kiCost"|"kiCharge")).
//  Shared: auraBoost 0..100 (the bar again) makes the aura swell, speed up and whiten while it fills,
//  with a shock ring when the surge fires (29_dmz_auras.js); dmz_surge draws DMZ's surge flame border.
//  Config: config/dbr_surge.json (DMZ CombatConfig defaults).
// =====================================================================================
RPG.effects.define("dmz_surge", { name: "Ki Surge", color: "#FFF27A", hidden: true,
    // DMZ AuraBorderRenderer: while the surge runs, a thin flame field hugs the body (any aura mode). The full aura
    // (priority 10) replaces it while it shows; it falls back to a small 2D aura for players who turned 3D off.
    aura: { mode: "border", color: "dmzAura", alpha: 0.9, priority: 5, texture: AURA_KAKAROT, frames: 4, speed: 15, height: 3.0, flipSpeed: 0.42, flipShared: "flyFast" },
    attributes: {
        "minecraft:generic.movement_speed": { amount: 0.25, operation: "multiply_total" },     // surgeMoveSpeedMultiplier 1.25
        "minecraft:generic.attack_speed": { amount: 0.40, operation: "multiply_total" }        // surgeAttackSpeedMultiplier 1.40
    } });

var DMZ_SURGE = (function () {
    var CFG = dbrConfig("dbr_surge", {
        enableKiSurge: true,
        surgeFillSeconds: 4.0,
        surgeDurationSeconds: 12.0,
        surgeCooldownSeconds: 15,
        surgeBurstDamageRatio: 0.25,
        surgeBurstRadius: 10.0,
        surgeBurstKnockback: 2.2,
        kiBurstRadius: 8.0,
        kiBurstKnockback: 1.4,
        kiChargeInterruptOnHit: true,
        kiChargeInterruptLockTicks: 10,
        surgeKiCostMultiplier: 1.25,
        surgeKiDamageMultiplier: 1.15,
        surgeKiSpeedMultiplier: 1.25,
        surgeKiChargeSpeedMultiplier: 1.20
    });
    var S = {};               // uuid -> {charge, active, armed, was, earned, shown}
    var LOCK = {};            // uuid -> tick until C works again

    function tick() { return RPG.server.getTick(); }
    function st(p) { return S[p.uuid] || (S[p.uuid] = { charge: 0, active: false, armed: false, was: false, earned: false, shown: -1 }); }
    function cd(p) { return typeof DMZ_FLIGHT !== "undefined" && DMZ_FLIGHT.hasCooldown(p, "ki_surge_cd"); }
    function startCooldown(p) { if (typeof DMZ_FLIGHT !== "undefined") DMZ_FLIGHT.setCooldown(p, "ki_surge_cd", Math.max(1, CFG.surgeCooldownSeconds * 20)); }
    function charging(p) { return p.hasEffect("ki_charge") && !p.getVar("dmz_lowering", 0); }

    // only on change, and at most every 4 ticks (the player data syncs every 4 ticks anyway)
    function sync(p, s, force) {
        var v = Math.round(Math.max(0, Math.min(100, s.charge)));
        if (v === s.shown || (!force && tick() % 4 !== 0)) return;
        s.shown = v;
        if (Number(p.getVar("dmz_surge", 0)) !== v) p.setVar("dmz_surge", v);
        p.setShared("auraBoost", v > 0 ? v : null);            // the aura swells with the bar (29_dmz_auras.js boost)
        var act = s.active ? 1 : 0;
        if (Number(p.getVar("dmz_surge_active", 0)) !== act) p.setVar("dmz_surge_active", act);
    }
    function setActive(p, s, on) {
        s.active = on;
        if (on) p.addEffect("dmz_surge", -1); else p.removeEffect("dmz_surge");
        p.setVar("dmz_surge_active", on ? 1 : 0);
    }
    function clear(p, s) {
        s.armed = false; s.charge = 0;
        if (s.active) setActive(p, s, false);
        sync(p, s, true);
    }

    function breakSurge(p) {
        var s = S[p.uuid];
        if (!s || (!s.active && !s.armed && s.charge <= 0)) return;
        clear(p, s);
        startCooldown(p);
    }

    // CombatEvent: getting hit drops the charge and any partial surge
    function interruptCharge(p) {
        var s = st(p);
        if (s.active) return;
        if (!p.hasEffect("ki_charge") && !s.armed && s.charge <= 0) return;
        var lost = s.armed || s.charge > 0;
        p.removeEffect("ki_charge");
        p.setVar("dmz_lowering", 0);
        s.armed = false; s.charge = 0;
        if (lost) startCooldown(p);
        if (CFG.kiChargeInterruptLockTicks > 0) LOCK[p.uuid] = tick() + CFG.kiChargeInterruptLockTicks;
        sync(p, s, true);
    }

    function isMaster(e) {
        return typeof DMZ_MASTERS_DATA !== "undefined" && !!e.rpgId && !!DMZ_MASTERS_DATA.BY_NPC && DMZ_MASTERS_DATA.isMaster(DMZ_MASTERS_DATA.BY_NPC[e.rpgId]);
    }
    function sameParty(p, other) {
        if (!other.isPlayer()) return false;
        var found = false;
        p.partyMembers().forEach(function (m) { if (m.uuid === other.uuid) found = true; });
        return found;
    }
    function bpOf(e) {
        var pl = e.asPlayer();
        return pl ? DMZ_F.battlePower(dmzView(pl)) : powerLevel(e);
    }

    function triggerBurst(p, full) {
        var radius = full ? CFG.surgeBurstRadius : CFG.kiBurstRadius, kb = full ? CFG.surgeBurstKnockback : CFG.kiBurstKnockback;
        var cy = p.y + 0.9;
        RPG.world.particle(p.dimension, "minecraft:explosion", p.x, cy, p.z, full ? 12 : 6, radius * 0.35, 0);
        RPG.world.particle(p.dimension, "minecraft:flash", p.x, cy, p.z, 1, 0, 0);
        sfx(p, full ? "ki_explosion_impact" : "aura_start", full ? 4.0 : 2.0, full ? 0.7 : 1.1);
        var self = DMZ_F.battlePower(dmzView(p)), dmg = full ? p.maxResource("ki") * CFG.surgeBurstDamageRatio : 0;
        p.nearby(radius).forEach(function (v) {
            if (!v.isAlive() || v.uuid === p.uuid || isMaster(v) || sameParty(p, v)) return;
            if (!full && bpOf(v) >= self) return;
            var d = p.distanceTo(v), fall = Math.max(0, 1 - d / radius);
            if (fall <= 0) return;
            if (dmg > 0) {                                            // non-lethal: never below 1 HP
                var capped = Math.min(dmg * fall, v.health - 1);
                if (capped > 0) v.damageFrom(capped, p, { kind: "ki", tag: "surge", knockback: 0 });
            }
            var dx = v.x - p.x, dy = v.y - p.y, dz = v.z - p.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (l < 0.01) { dx = 0; dy = 1; dz = 0; l = 1; }
            v.push(dx / l * kb * fall, dy / l * kb * fall + 0.25 * kb * fall, dz / l * kb * fall);
        });
    }

    // ---- KiSurgeService.tick, every tick ----
    RPG.every(1, function () {
        if (!CFG.enableKiSurge) return;
        RPG.server.players().forEach(function (p) {
            var s = S[p.uuid];
            var chargingNow = p.hasEffect("ki_charge");
            if (!s && !chargingNow) return;                          // nothing going on: no work
            s = s || st(p);
            if (p.hasEffect("stunned")) { breakSurge(p); s.was = false; return; }
            if (s.active) {
                s.charge -= 100 / Math.max(1, CFG.surgeDurationSeconds * 20);
                if (s.charge <= 0) { s.charge = 0; setActive(p, s, false); startCooldown(p); sync(p, s, true); }
                else sync(p, s, false);
                return;
            }
            var ch = chargingNow && !p.getVar("dmz_lowering", 0);
            if (ch && !s.was) s.earned = p.resource("ki") < p.maxResource("ki");
            s.was = ch;
            if (ch && !s.armed && p.resource("ki") >= p.maxResource("ki") - 0.001 && !cd(p)) {
                s.armed = true;
                if (s.earned) { s.earned = false; triggerBurst(p, false); }
            }
            if (!s.armed) {
                if (s.charge > 0) { s.charge = 0; sync(p, s, true); }
                if (!ch && s.charge <= 0) delete S[p.uuid];
                return;
            }
            if (!ch) { s.charge = 0; s.armed = false; sync(p, s, true); return; }
            s.charge += 100 / Math.max(1, CFG.surgeFillSeconds * 20);
            if (s.charge >= 100) {
                s.charge = 100; s.armed = false;
                setActive(p, s, true);
                triggerBurst(p, true);
                sync(p, s, true);
            } else sync(p, s, false);
        });
    });

    RPG.on("hurt", function (e) {
        if (!CFG.kiChargeInterruptOnHit || e.isCancelled() || !e.target || !e.target.isPlayer()) return;
        var p = e.target.asPlayer();
        if (p.getVar("dmz_created", 0)) interruptCharge(p);
    });
    RPG.on("death", function (p) { breakSurge(p); });
    RPG.on("playerJoin", function (p) {
        if (Number(p.getVar("dmz_surge", 0)) || Number(p.getVar("dmz_surge_active", 0))) { p.setVar("dmz_surge", 0); p.setVar("dmz_surge_active", 0); }
        p.removeEffect("dmz_surge");
    });

    var MULT = { kiDamage: "surgeKiDamageMultiplier", kiSpeed: "surgeKiSpeedMultiplier", kiCost: "surgeKiCostMultiplier", kiCharge: "surgeKiChargeSpeedMultiplier" };
    return {
        CFG: CFG,
        isActive: function (p) { var s = S[p.uuid]; return !!(s && s.active); },
        /** the surge multiplier for "kiDamage" | "kiSpeed" | "kiCost" | "kiCharge" (1 when no surge). */
        mult: function (p, what) { var s = S[p.uuid]; return s && s.active && MULT[what] ? CFG[MULT[what]] : 1; },
        /** true for 10 ticks after a hit interrupted charging (45_keys.js key 9). */
        chargeLocked: function (p) { return (LOCK[p.uuid] || 0) > tick(); },
        interruptCharge: interruptCharge, breakSurge: breakSurge,
        /** ForceActivateSurge (e.g. an item). */
        force: function (p) {
            if (!CFG.enableKiSurge || cd(p)) return;
            var s = st(p);
            if (s.active) return;
            s.armed = false; s.charge = 100;
            setActive(p, s, true); triggerBurst(p, true); sync(p, s, true);
        }
    };
})();
