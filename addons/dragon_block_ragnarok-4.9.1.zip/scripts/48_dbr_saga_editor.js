// =====================================================================================
//  48_dbr_saga_editor.js - custom sagas and side quests made in game (the saga editor)
// =====================================================================================
//  Ported from DMZ Ragnarok (GPL-3.0): SagaFileManager / SideQuestFileManager and the
//  OpenSagaEditor / SaveSaga / DeleteSaga packets. Instead of files under dragonminez/,
//  each saga is one world-data key ("dbr_saga_<id>", RPG.data; over 20000 characters it is
//  split into "dbr_sagapart_saga.<id>.<n>" keys, as NBT strings stop at 64 KB) and each
//  standalone side quest one more ("dbr_sidequest_<id>"). A saga may be up to 245 KB. On load they are merged into
//  DMZ_QUEST_DATA (DMZ_QL.setCustom, shared/06_dmz_quest_logic.js), so 47_dmz_quests.js
//  and the quest screen run them like DMZ's own; a custom saga with a DMZ saga's id
//  overrides it, and deleting it brings DMZ's back.
//
//  Network ("dbr_saga", client -> server; "dbr_sagas" / "dbr_saga_editor", server -> client):
//    everything travels as JSON text cut into pieces of CHUNK (9000) characters, < 30 KB each
//    { action: "sync" }                       -> the custom data, to everyone who asks
//    { action: "open" }                       -> ops: opens the editor (also /rpgc sagaeditor)
//    { action: "save", kind, tx, i, n, part, old } -> ops: one piece of a saga / side quest
//    { action: "delete", kind, id }           -> ops: removes one
//  The editor itself is client/scripts/69_saga_editor.js.
// =====================================================================================
var DBR_SAGA_EDITOR = (function () {
    var QL = DMZ_QL, SAGA = "dbr_saga_", SIDE = "dbr_sidequest_", CHUNK = 9000, MAX_BYTES = 250000;
    // RPG.data keeps a value as one NBT string, which Minecraft writes with writeUTF (64 KB of UTF-8 at most), so a
    // bigger saga is split: "dbr_saga_<id>" = { id, _parts: n } and "dbr_sagapart_<kind>.<id>.<i>" = the JSON text
    var PART = "dbr_sagapart_", PART_LEN = 20000;
    var incoming = {};                          // uuid -> { tx, kind, old, n, parts, at }

    function canEdit(p) { return !!(p && p.isOp()); }
    function tell(p, text, color) { if (p) RPG.net.send(p, "dmz_msg", { text: text, color: color || "#55FF55" }); }

    // ---- storage ----
    function kindOf(prefix) { return prefix === SAGA ? "saga" : "side"; }
    function partKey(prefix, id, i) { return PART + kindOf(prefix) + "." + id + "." + (i === undefined ? "" : i); }
    function read(prefix, key) {
        let v = RPG.data.get(key, null);
        if (!v || typeof v !== "object" || !v._parts) return v;
        let text = "";
        for (let i = 0; i < v._parts; i++) text += String(RPG.data.get(partKey(prefix, v.id, i), ""));
        try { return JSON.parse(text); } catch (err) { RPG.log("Saga editor: " + key + " is damaged: " + err); return null; }
    }
    function erase(prefix, id) {
        RPG.data.remove(prefix + id);
        RPG.data.keys(partKey(prefix, id)).forEach((k) => RPG.data.remove(k));
    }
    function store(prefix, id, obj) {
        erase(prefix, id);
        let text = JSON.stringify(obj);
        if (text.length <= PART_LEN) { RPG.data.set(prefix + id, obj); return; }
        let n = Math.ceil(text.length / PART_LEN);
        for (let i = 0; i < n; i++) RPG.data.set(partKey(prefix, id, i), text.substring(i * PART_LEN, (i + 1) * PART_LEN));
        RPG.data.set(prefix + id, { id: id, _parts: n });
    }
    function loadSagas() {
        return RPG.data.keys(SAGA).map((k) => read(SAGA, k)).filter((b) => b && typeof b === "object" && b.id);
    }
    function loadSide() {
        return RPG.data.keys(SIDE).map((k) => read(SIDE, k)).filter((q) => q && typeof q === "object" && q.id);
    }
    function apply() {
        try { QL.setCustom(loadSagas(), loadSide()); } catch (err) { RPG.log("Saga editor: could not merge custom sagas: " + err); }
    }

    // ---- server -> client: the custom data in pieces ----
    var txCounter = 0;
    function payload() { return JSON.stringify({ sagas: QL.CUSTOM.sagas, side: QL.CUSTOM.side }); }
    function sendTo(players, channel, text, extra) {
        let tx = (++txCounter) + "_" + Date.now(), n = Math.max(1, Math.ceil(text.length / CHUNK));
        for (let i = 0; i < n; i++) {
            let msg = { tx: tx, i: i, n: n, part: text.substring(i * CHUNK, (i + 1) * CHUNK) };
            if (extra && i === n - 1) Object.keys(extra).forEach((k) => { msg[k] = extra[k]; });
            players.forEach((p) => RPG.net.send(p, channel, msg));
        }
    }
    function syncTo(p, open) { sendTo([p], "dbr_sagas", payload(), open ? { open: true } : null); }
    function syncAll() { let ps = RPG.server.players(); if (ps.length) sendTo(ps, "dbr_sagas", payload(), null); }

    // ---- saving ----
    function save(p, kind, text, old) {
        if (text.length > MAX_BYTES) return tell(p, "Too big to save (" + Math.round(text.length / 1024) + " KB, max 245 KB)", "#FF5555");
        let obj;
        try { obj = JSON.parse(text); } catch (err) { return tell(p, "Bad saga data: " + err, "#FF5555"); }
        if (kind === "saga") {
            let b = QL.normalizeSaga(obj);
            // compile once so a broken saga never reaches the quest engine
            try { QL.compileSaga(b); } catch (err) { return tell(p, "Bad saga data: " + err, "#FF5555"); }
            store(SAGA, b.id, b);
            if (old && QL.cleanId(old, "") && QL.cleanId(old, "") !== b.id) erase(SAGA, QL.cleanId(old, ""));
            tell(p, "Saved saga " + b.id + " (" + b.quests.length + " quests)");
        } else {
            let q = QL.normalizeSide(obj);
            store(SIDE, q.id, q);
            if (old && QL.cleanId(old, "") && QL.cleanId(old, "") !== q.id) erase(SIDE, QL.cleanId(old, ""));
            tell(p, "Saved side quest " + q.id);
        }
        apply();
        syncAll();
        RPG.log("Saga editor: " + p.name + " saved " + kind + " " + (obj && obj.id));
    }
    function remove(p, kind, id) {
        id = QL.cleanId(id, "");
        if (!id) return;
        let prefix = kind === "saga" ? SAGA : SIDE;
        if (!RPG.data.has(prefix + id)) return tell(p, "Nothing saved under " + id, "#FFFF55");
        erase(prefix, id);
        apply();
        syncAll();
        tell(p, "Deleted " + (kind === "saga" ? "saga " : "side quest ") + id);
        RPG.log("Saga editor: " + p.name + " deleted " + kind + " " + id);
    }

    RPG.net.on("dbr_saga", (p, d) => {
        if (!d || !p) return;
        let action = String(d.action || "");
        if (action === "sync") return syncTo(p, false);
        if (!canEdit(p)) { if (action !== "sync") tell(p, "Only operators can edit sagas", "#FF5555"); return; }
        if (action === "open") return syncTo(p, true);
        if (action === "delete") return remove(p, d.kind === "side" ? "side" : "saga", d.id);
        if (action === "save") {
            let id = String(p.uuid), kind = d.kind === "side" ? "side" : "saga", n = Number(d.n) || 0, i = Number(d.i);
            if (n < 1 || n > 32 || !(i >= 0 && i < n) || typeof d.part !== "string") return;
            let buf = incoming[id];
            if (!buf || buf.tx !== d.tx) buf = incoming[id] = { tx: d.tx, kind: kind, old: d.old ? String(d.old) : "", n: n, parts: [], got: 0, at: Date.now() };
            if (buf.parts[i] === undefined) { buf.parts[i] = d.part; buf.got++; }
            if (d.old) buf.old = String(d.old);
            if (buf.got < buf.n) return;
            delete incoming[id];
            save(p, buf.kind, buf.parts.join(""), buf.old);
        }
    });
    RPG.every(1200, () => { let now = Date.now(); Object.keys(incoming).forEach((k) => { if (now - incoming[k].at > 60000) delete incoming[k]; }); });

    RPG.on("playerJoin", (p) => { RPG.schedule(40, () => { try { syncTo(p, false); } catch (err) { } }); });

    function open(p) {
        if (!canEdit(p)) return tell(p, "Only operators can edit sagas", "#FF5555");
        syncTo(p, true);
    }
    RPG.commands.register("sagaeditor", {
        permission: 2, description: "/rpgc sagaeditor - edit custom sagas and side quests",
        run(p, args) {
            if (!p) { RPG.log("Custom sagas: " + QL.CUSTOM.sagas.map((s) => s.id).join(", ") + " | side quests: " + QL.CUSTOM.side.map((q) => q.id).join(", ")); return; }
            open(p);
        }
    });

    // ---- FORM_PURCHASE rewards (SaveSagaPacket.applyFormPurchaseGates): form key -> quest keys ----
    function formGates() {
        let out = {};
        function add(form, key) { if (!form) return; (out[form] = out[form] || []).indexOf(key) < 0 && out[form].push(key); }
        QL.SAGA_LIST.forEach((s) => { if (s.custom) s.quests.forEach((q) => (q.rewards || []).forEach((r) => { if (r.type === "FORM_PURCHASE") add(r.form, s.id + ":" + q.id); })); });
        QL.SIDE.forEach((q) => { if (q.custom) (q.rewards || []).forEach((r) => { if (r.type === "FORM_PURCHASE") add(r.form, q.id); }); });
        return out;
    }
    /** null = no saga-editor gate on this form ("group.form"); else whether one of its quests is done. */
    function formUnlocked(p, formKey) {
        let keys = formGates()[formKey];
        if (!keys || !keys.length) return null;
        return keys.some((k) => DMZ_QUESTS.isCompleted(p, k));
    }

    apply();
    syncAll();                                  // after /rpg reload, clients get the current data again

    return { reload: () => { apply(); syncAll(); }, open: open, formGates: formGates, formUnlocked: formUnlocked,
        sagas: () => QL.CUSTOM.sagas, side: () => QL.CUSTOM.side };
})();
