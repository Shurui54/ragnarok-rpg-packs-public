// =====================================================================================
//  16_dmz_items.js - every DragonMine Z item (GPL-3.0, ported from DMZ's MainItems and item
//  classes). GENERATED DATA + logic. Names are DMZ's registry ids.
// =====================================================================================
//  Not here on purpose: Dragon Balls (dball*), Dragon Radars (dball_radar, namekdball_radar,
//  fused_dball_radar) and vehicles (car_red, car_yellow, cc576, frieza_capsule, saiyan_ship,
//  flying_nimbus, black_nimbus) - owned by other scripts.
// =====================================================================================
var DMZ_ITEM_SPECS = [
{"id":"red_capsule","fx":"capsule","stat":"strength","abbr":"STR","pts":5,"stack":64,"n":"Capsule &a(STR)","lore":["Gives you +5 STR stat points to your attributes."],"m":"dmzpack:rpg/item/red_capsule"},
{"id":"gete_red_capsule","fx":"capsule","stat":"strength","abbr":"STR","pts":15,"stack":64,"rarity":"rare","n":"Capsule &6Gete &a(STR)","lore":["Gives you +15 STR stat points to your attributes."],"m":"dmzpack:rpg/item/gete_red_capsule"},
{"id":"purple_capsule","fx":"capsule","stat":"strike","abbr":"SKP","pts":5,"stack":64,"n":"Capsule &a(SKP)","lore":["Gives you +5 SKP stat points to your attributes."],"m":"dmzpack:rpg/item/purple_capsule"},
{"id":"gete_purple_capsule","fx":"capsule","stat":"strike","abbr":"SKP","pts":15,"stack":64,"rarity":"rare","n":"Capsule &6Gete &a(SKP)","lore":["Gives you +15 SKP stat points to your attributes."],"m":"dmzpack:rpg/item/gete_purple_capsule"},
{"id":"yellow_capsule","fx":"capsule","stat":"resistance","abbr":"RES","pts":5,"stack":64,"n":"Capsule &a(RES)","lore":["Gives you +5 RES stat points to your attributes."],"m":"dmzpack:rpg/item/yellow_capsule"},
{"id":"gete_yellow_capsule","fx":"capsule","stat":"resistance","abbr":"RES","pts":15,"stack":64,"rarity":"rare","n":"Capsule &6Gete &a(RES)","lore":["Gives you +15 RES stat points to your attributes."],"m":"dmzpack:rpg/item/gete_yellow_capsule"},
{"id":"green_capsule","fx":"capsule","stat":"vitality","abbr":"VIT","pts":5,"stack":64,"n":"Capsule &a(VIT)","lore":["Gives you +5 VIT stat points to your attributes."],"m":"dmzpack:rpg/item/green_capsule"},
{"id":"gete_green_capsule","fx":"capsule","stat":"vitality","abbr":"VIT","pts":15,"stack":64,"rarity":"rare","n":"Capsule &6Gete &a(VIT)","lore":["Gives you +15 VIT stat points to your attributes."],"m":"dmzpack:rpg/item/gete_green_capsule"},
{"id":"orange_capsule","fx":"capsule","stat":"kipower","abbr":"PWR","pts":5,"stack":64,"n":"Capsule &a(PWR)","lore":["Gives you +5 PWR stat points to your attributes."],"m":"dmzpack:rpg/item/orange_capsule"},
{"id":"gete_orange_capsule","fx":"capsule","stat":"kipower","abbr":"PWR","pts":15,"stack":64,"rarity":"rare","n":"Capsule &6Gete &a(PWR)","lore":["Gives you +15 PWR stat points to your attributes."],"m":"dmzpack:rpg/item/gete_orange_capsule"},
{"id":"blue_capsule","fx":"capsule","stat":"energy","abbr":"ENE","pts":5,"stack":64,"n":"Capsule &a(ENE)","lore":["Gives you +5 ENE stat points to your attributes."],"m":"dmzpack:rpg/item/blue_capsule"},
{"id":"gete_blue_capsule","fx":"capsule","stat":"energy","abbr":"ENE","pts":15,"stack":64,"rarity":"rare","n":"Capsule &6Gete &a(ENE)","lore":["Gives you +15 ENE stat points to your attributes."],"m":"dmzpack:rpg/item/gete_blue_capsule"},
{"id":"empty_capsule","stack":64,"n":"Empty Capsule","m":"dmzpack:rpg/item/empty_capsule"},
{"id":"mastery_capsule","fx":"mastery_capsule","stack":64,"n":"Mastery Capsule","lore":["Use to gain mastery of your active transformation."],"m":"dmzpack:rpg/item/mastery_capsule"},
{"id":"senzu_bean","fx":"senzu","kind":"all","stack":16,"n":"Senzu Bean","m":"dmzpack:rpg/item/senzu_bean"},
{"id":"senzu_bean_blue","fx":"senzu","kind":"ki","stack":16,"n":"Senzu Bean (&bKi&r)","m":"dmzpack:rpg/item/senzu_bean_blue"},
{"id":"senzu_bean_red","fx":"senzu","kind":"hp","stack":16,"n":"Senzu Bean (&cHealth&r)","m":"dmzpack:rpg/item/senzu_bean_red"},
{"id":"senzu_bean_yellow","fx":"senzu","kind":"st","stack":16,"n":"Senzu Bean (&eStamina&r)","m":"dmzpack:rpg/item/senzu_bean_yellow"},
{"id":"senzu_bean_seeds_blue","fx":"seed","crop":"senzu_blue","stack":64,"n":"Senzu Bean Seeds (&bKi&r)","m":"dmzpack:rpg/item/senzu_bean_seeds_blue"},
{"id":"senzu_bean_seeds_red","fx":"seed","crop":"senzu_red","stack":64,"n":"Senzu Bean Seeds (&cHealth&r)","m":"dmzpack:rpg/item/senzu_bean_seeds_red"},
{"id":"senzu_bean_seeds_yellow","fx":"seed","crop":"senzu_yellow","stack":64,"n":"Senzu Bean Seeds (&eStamina&r)","m":"dmzpack:rpg/item/senzu_bean_seeds_yellow"},
{"id":"senzu_bean_bag","fx":"senzu_bag","stack":1,"n":"Senzu Bag","m":"dmzpack:rpg/item/senzu_bean_bag"},
{"id":"medi_bug_ant","fx":"food","food":[2,1.2],"restore":0.85,"stack":64,"n":"Medi-Bug (Ant)","lore":["Restores 85% of your health, ki and stamina."],"m":"dmzpack:rpg/item/medi_bug_ant"},
{"id":"medi_bug_beetle","fx":"food","food":[2,1.2],"beetle":true,"stack":64,"n":"Medi-Bug (Beetle)","m":"dmzpack:rpg/item/medi_bug_beetle"},
{"id":"medi_bug_beetle_pair","fx":"beetle_pair","stack":1,"n":"Pair of Medi-Bugs (Beetle)","m":"dmzpack:rpg/item/medi_bug_beetle_pair"},
{"id":"medi_bug_rhino","fx":"food","food":[2,1.2],"effect":["medi_shell",900],"stack":64,"n":"Medi-Bug (Rhino)","lore":["Hardens your body: take 30% less damage for 45 seconds."],"m":"dmzpack:rpg/item/medi_bug_rhino"},
{"id":"medi_bug_worm","fx":"food","food":[2,1.2],"effect":["mastery_gain",6000],"stack":64,"n":"Medi-Bug (Worm)","lore":["Gain 50% more form mastery for 5 minutes."],"m":"dmzpack:rpg/item/medi_bug_worm"},
{"id":"might_tree_fruit","fx":"might_fruit","food":[2,20],"stack":6,"n":"Fruit of the Tree of Might","lore":["&7This fruit will give you a temporary power boost."],"m":"dmzpack:rpg/item/might_tree_fruit"},
{"id":"sacred_water","fx":"sacred_water","stack":16,"rarity":"epic","n":"Sacred Water","lore":["Permanently multiplies all your stats by x%s."],"m":"dmzpack:rpg/item/sacred_water"},
{"id":"satan_badge","stack":64,"n":"Satan Badge","m":"dmzpack:rpg/item/satan_badge"},
{"id":"raw_dino_meat","fx":"food","food":[4,3.6],"stack":64,"n":"Raw Dino Meat","m":"dmzpack:rpg/item/raw_dino_meat"},
{"id":"cooked_dino_meat","fx":"food","food":[8,12.8],"stack":64,"n":"Cooked Dino Meat","m":"dmzpack:rpg/item/cooked_dino_meat"},
{"id":"raw_baby_dino_meat","fx":"food","food":[2,2.4],"stack":64,"n":"Raw Baby Dino Meat","m":"dmzpack:rpg/item/raw_baby_dino_meat"},
{"id":"cooked_baby_dino_meat","fx":"food","food":[5,4.8],"stack":64,"n":"Cooked Baby Dino Meat","m":"dmzpack:rpg/item/cooked_baby_dino_meat"},
{"id":"dino_tail_raw","fx":"food","food":[6,4.8],"stack":64,"n":"Raw Dino Tail","m":"dmzpack:rpg/item/dino_tail_raw"},
{"id":"dino_tail_cooked","fx":"food","food":[12,9.6],"stack":64,"n":"Cooked Dino Tail","m":"dmzpack:rpg/item/dino_tail_cooked"},
{"id":"frog_legs_raw","fx":"food","food":[2,2.4],"stack":64,"n":"Raw Frog Legs","m":"dmzpack:rpg/item/frog_legs_raw"},
{"id":"frog_legs_cooked","fx":"food","food":[5,4.8],"stack":64,"n":"Cooked Frog Legs","m":"dmzpack:rpg/item/frog_legs_cooked"},
{"id":"giant_fish_raw","fx":"food","food":[5,2.4],"stack":64,"n":"Raw Giant Fish","m":"dmzpack:rpg/item/giant_fish_raw"},
{"id":"giant_fish_cooked","fx":"food","food":[12,9.4],"stack":64,"n":"Cooked Giant Fish","m":"dmzpack:rpg/item/giant_fish_cooked"},
{"id":"giant_turtle_raw","fx":"food","food":[5,2.4],"stack":64,"n":"Raw Giant Turtle","m":"dmzpack:rpg/item/giant_turtle_raw"},
{"id":"giant_turtle_cooked","fx":"food","food":[12,9.4],"stack":64,"n":"Cooked Giant Turtle","m":"dmzpack:rpg/item/giant_turtle_cooked"},
{"id":"heart_medicine","fx":"senzu","kind":"heart","stack":16,"n":"Heart Medicine","m":"dmzpack:rpg/item/heart_medicine"},
{"id":"turtle_scale","stack":64,"n":"Turtle Scale","m":"dmzpack:rpg/item/turtle_scale"},
{"id":"namek_moss","fx":"seed","crop":"namek_moss","stack":64,"n":"Namek Moss","m":"dmzpack:rpg/item/namek_moss"},
{"id":"oozaru_root","fx":"stat_plant","stat":"strength","crop":"oozaru_root","stack":64,"n":"Oozaru Root","lore":["Eat for a temporary +15 STR (15s). Plant on farmland to harvest more."],"m":"dmzpack:rpg/item/oozaru_root"},
{"id":"katchin_sprout","fx":"stat_plant","stat":"resistance","crop":"katchin_sprout","stack":64,"n":"Katchin Sprout","lore":["Eat for a temporary +15 RES (15s). Plant on farmland to harvest more."],"m":"dmzpack:rpg/item/katchin_sprout"},
{"id":"meteor_flower","fx":"stat_plant","stat":"strike","crop":"meteor_flower","stack":64,"n":"Meteor Flower","lore":["Eat for a temporary +15 SKP (15s). Plant on farmland to harvest more."],"m":"dmzpack:rpg/item/meteor_flower"},
{"id":"aura_lily","fx":"stat_plant","stat":"kipower","crop":"aura_lily","stack":64,"n":"Aura Lily","lore":["Eat for a temporary +15 PWR (15s). Plant on farmland to harvest more."],"m":"dmzpack:rpg/item/aura_lily"},
{"id":"hermit_fern","fx":"stat_plant","stat":"vitality","crop":"hermit_fern","stack":64,"n":"Hermit's Fern","lore":["Eat for a temporary +15 VIT (15s). Plant on farmland to harvest more."],"m":"dmzpack:rpg/item/hermit_fern"},
{"id":"kaioshin_fruit","fx":"stat_plant","stat":"ki_regen","crop":"kaioshin_fruit","stack":64,"n":"Kaioshin Fruit","lore":["Eat to regenerate ki for 5s. Plant on farmland to harvest more."],"m":"dmzpack:rpg/item/kaioshin_fruit"},
{"id":"zenkai_lotus","fx":"stat_plant","stat":"mastery","crop":"zenkai_lotus","stack":64,"n":"Zenkai Lotus","lore":["Eat to clear all negative effects and cooldowns. Plant on farmland to harvest more."],"m":"dmzpack:rpg/item/zenkai_lotus"},
{"id":"pothala_left","fx":"curio","slot":"head_tech","stack":1,"durability":3,"n":"Pothala (Left)","m":"dmzpack:rpg/item/pothala_left"},
{"id":"pothala_right","fx":"curio","slot":"head_tech","stack":1,"durability":3,"n":"Pothala (Right)","m":"dmzpack:rpg/item/pothala_right"},
{"id":"green_pothala_left","fx":"curio","slot":"head_tech","stack":1,"durability":3,"n":"Green Pothala (Left)","m":"dmzpack:rpg/item/green_pothala_left"},
{"id":"green_pothala_right","fx":"curio","slot":"head_tech","stack":1,"durability":3,"n":"Green Pothala (Right)","m":"dmzpack:rpg/item/green_pothala_right"},
{"id":"pothala_pair","fx":"pothala_pair","left":"pothala_left","right":"pothala_right","stack":1,"n":"Pair of Pothalas","m":"dmzpack:rpg/item/pothala_pair"},
{"id":"green_pothala_pair","fx":"pothala_pair","left":"green_pothala_left","right":"green_pothala_right","stack":1,"n":"Pair of Green Pothalas","m":"dmzpack:rpg/item/green_pothala_pair"},
{"id":"red_scouter","fx":"scouter","slot":"head_tech","stack":1,"durability":15,"n":"Scouter (Red)","m":"dmzpack:rpg/item/red_scouter"},
{"id":"blue_scouter","fx":"scouter","slot":"head_tech","stack":1,"durability":15,"n":"Scouter (Blue)","m":"dmzpack:rpg/item/blue_scouter"},
{"id":"green_scouter","fx":"scouter","slot":"head_tech","stack":1,"durability":15,"n":"Scouter (Green)","m":"dmzpack:rpg/item/green_scouter"},
{"id":"purple_scouter","fx":"scouter","slot":"head_tech","stack":1,"durability":15,"n":"Scouter (Purple)","m":"dmzpack:rpg/item/purple_scouter"},
{"id":"anti_ki_cloak","fx":"curio","slot":"head_tech","stats":{"ki_cloak":1},"stack":1,"n":"Anti-Ki Cloaking Device","m":"dmzpack:rpg/item/anti_ki_cloak"},
{"id":"demon_eye","fx":"curio","slot":"head_tech","stack":1,"rarity":"epic","n":"Demon Eye","lore":["While worn: all stats x%s."],"m":"dmzpack:rpg/item/demon_eye"},
{"id":"yajirobe_katana","fx":"weapon","damage":12,"speed":1.4,"durability":500,"stack":1,"n":"&eYajirobe's Katana","lore":["A katana used by Yajirobe. It is a simple weapon."],"m":"dmzpack:rpg/item/yajirobe_katana"},
{"id":"z_sword","fx":"weapon","damage":300,"speed":1.2,"durability":0,"stack":1,"n":"&eZ&f-&eSword","lore":["A legendary sword that was said to be unbreakable."],"m":"dmzpack:rpg/item/z_sword"},
{"id":"brave_sword","fx":"weapon","damage":75,"speed":1.6,"durability":2600,"stack":1,"n":"&bBrave Sword","lore":["A sword wielded by a brave warrior. It is said to be able to cut through anything."],"m":"dmzpack:rpg/item/brave_sword"},
{"id":"dimensional_sword","fx":"weapon","damage":250,"speed":1.6,"durability":2600,"stack":1,"n":"&dDimension &5Sword","lore":["A wicked blade capable of slicing through the very fabric of space."],"m":"dmzpack:rpg/item/dimensional_sword"},
{"id":"power_pole","fx":"weapon","damage":64,"speed":2.0,"durability":0,"stack":1,"n":"&cPower Pole","lore":["A magical staff that can extend to great lengths."],"m":"dmzpack:rpg/item/power_pole"},
{"id":"tamagami_sword","fx":"weapon","damage":230,"speed":1.6,"durability":2400,"stack":1,"n":"&bTamagami &3Sword","lore":["The blade wielded by Tamagami Number 1, guardian of the Demon Realm."],"m":"dmzpack:rpg/item/tamagami_sword"},
{"id":"tamagami_trident","fx":"weapon","damage":260,"speed":1.3,"durability":2600,"stack":1,"n":"&bTamagami &3Trident","lore":["The trident wielded by Tamagami Number 2, guardian of the Demon Realm."],"m":"dmzpack:rpg/item/tamagami_trident"},
{"id":"tamagami_hammer","fx":"weapon","damage":300,"speed":1.0,"durability":2800,"stack":1,"n":"&bTamagami &3Hammer","lore":["The hammer wielded by Tamagami Number 3, guardian of the Demon Realm."],"m":"dmzpack:rpg/item/tamagami_hammer"},
{"id":"laser_merus","fx":"gun","proj":"merus_laser","cd":30,"durability":250,"sound":"minecraft:block.beacon.activate","pitch":2.0,"stack":1,"n":"&bMerus' Laser","m":"dmzpack:rpg/item/laser_merus"},
{"id":"blaster_cannon","fx":"gun","proj":"blaster_shot","cd":60,"durability":200,"sound":"minecraft:block.beacon.activate","pitch":2.0,"stack":1,"n":"&cBlaster Cannon","m":"dmzpack:rpg/item/blaster_cannon"},
{"id":"healing_liquid_bucket","fx":"bucket","liquid":"healing_liquid_block","stack":1,"n":"Healing Liquid Bucket","m":"dmzpack:rpg/item/healing_liquid_bucket"},
{"id":"namek_water_bucket","fx":"bucket","liquid":"namek_water_liquid_block","stack":1,"n":"Namek Water Bucket","m":"dmzpack:rpg/item/namek_water_bucket"},
{"id":"gete_scrap","stack":64,"n":"Gete Scrap","m":"dmzpack:rpg/item/gete_scrap"},
{"id":"gete_ingot","stack":64,"n":"Gete Ingot","m":"dmzpack:rpg/item/gete_ingot"},
{"id":"kikono_shard","stack":64,"n":"Kikono Shard","m":"dmzpack:rpg/item/kikono_shard"},
{"id":"kikono_stick","stack":64,"n":"Kikono Stick","m":"dmzpack:rpg/item/kikono_stick"},
{"id":"majilite","stack":64,"n":"Majilite","m":"dmzpack:rpg/item/majilite"},
{"id":"ki_battery","fx":"ki_battery","stack":16,"n":"Ki Battery","m":"dmzpack:rpg/item/ki_battery"},
{"id":"weight_turtle_shell","fx":"curio","slot":"weights","stats":{"weight":1},"stack":1,"n":"Turtle Shell","m":"dmzpack:rpg/item/weight_turtle_shell"},
{"id":"workout_weights","fx":"curio","slot":"weights","stats":{"weight":1},"stack":1,"n":"Workout Weights","m":"dmzpack:rpg/item/workout_weights"},
{"id":"weight_piccolo_cape","fx":"curio","slot":"weights","stats":{"weight":1},"stack":1,"n":"Weighted Cape","m":"dmzpack:rpg/item/weight_piccolo_cape"},
{"id":"gete_pickaxe","fx":"tool","damage":8,"speed":1.2,"durability":3250,"stack":1,"n":"Gete Pickaxe","m":"dmzpack:rpg/item/gete_pickaxe"},
{"id":"gete_axe","fx":"tool","damage":12,"speed":1.0,"durability":3250,"stack":1,"n":"Gete Axe","m":"dmzpack:rpg/item/gete_axe"},
{"id":"gete_shovel","fx":"tool","damage":8.5,"speed":1.0,"durability":3250,"stack":1,"n":"Gete Shovel","m":"dmzpack:rpg/item/gete_shovel"},
{"id":"gete_hoe","fx":"tool","damage":3,"speed":4.0,"durability":3250,"stack":1,"n":"Gete Hoe","m":"dmzpack:rpg/item/gete_hoe"},
{"id":"radar_piece","stack":16,"n":"Radar's Piece","m":"dmzpack:rpg/item/radar_piece"},
{"id":"t1_radar_chip","stack":16,"n":"Radar's Chip (Earth)","m":"dmzpack:rpg/item/t1_radar_chip"},
{"id":"t1_radar_cpu","stack":16,"n":"Radar's CPU (Earth)","m":"dmzpack:rpg/item/t1_radar_cpu"},
{"id":"t2_radar_chip","stack":16,"n":"Radar's Chip (Namek)","m":"dmzpack:rpg/item/t2_radar_chip"},
{"id":"t2_radar_cpu","stack":16,"n":"Radar's CPU (Namek)","m":"dmzpack:rpg/item/t2_radar_cpu"},
{"id":"vehicle_engine","stack":16,"n":"Vehicle Engine","m":"dmzpack:rpg/item/vehicle_engine"},
{"id":"vehicle_propeller","stack":16,"n":"Vehicle Propeller","m":"dmzpack:rpg/item/vehicle_propeller"},
{"id":"vehicle_seat","stack":16,"n":"Vehicle Seat","m":"dmzpack:rpg/item/vehicle_seat"},
{"id":"vehicle_plating","stack":32,"n":"Vehicle Plating","m":"dmzpack:rpg/item/vehicle_plating"},
{"id":"punch_machine_item","fx":"plain_info","stack":64,"info":"The Punch Machine entity is not available yet.","n":"&ePunch Machine","m":"dmzpack:rpg/item/punch_machine_item"},
{"id":"music_disc_menu_music_1","fx":"disc","n":"Music Disc - Dragon Ball - Bulma is Happy","length":788,"stack":1,"rarity":"rare","desc":"Dragon Ball - Bulma is Happy by Shunsuke Kikuchi","lore":["Dragon Ball - Bulma is Happy by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_1"},
{"id":"music_disc_menu_music_2","fx":"disc","n":"Music Disc - Dragon Ball - Away on the Bike!","length":1212,"stack":1,"rarity":"rare","desc":"Dragon Ball - Away on the Bike! by Shunsuke Kikuchi","lore":["Dragon Ball - Away on the Bike! by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_2"},
{"id":"music_disc_menu_music_3","fx":"disc","n":"Music Disc - Dragon Ball - Goku's Dinner Bird","length":920,"stack":1,"rarity":"rare","desc":"Dragon Ball - Goku's Dinner Bird by Shunsuke Kikuchi","lore":["Dragon Ball - Goku's Dinner Bird by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_3"},
{"id":"music_disc_menu_music_4","fx":"disc","n":"Music Disc - Dragon Ball - Goku Leaves With Umigame","length":820,"stack":1,"rarity":"rare","desc":"Dragon Ball - Goku Leaves With Umigame by Shunsuke Kikuchi","lore":["Dragon Ball - Goku Leaves With Umigame by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_4"},
{"id":"music_disc_menu_music_5","fx":"disc","n":"Music Disc - Dragon Ball - The Joys Of Travel","length":640,"stack":1,"rarity":"rare","desc":"Dragon Ball - The Joys Of Travel by Shunsuke Kikuchi","lore":["Dragon Ball - The Joys Of Travel by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_5"},
{"id":"music_disc_menu_music_6","fx":"disc","n":"Music Disc - Dragon Ball - Kame Sennin Prepares The Kamehameha","length":1920,"stack":1,"rarity":"rare","desc":"Dragon Ball - Kame Sennin Prepares The Kamehameha by Shunsuke Kikuchi","lore":["Dragon Ball - Kame Sennin Prepares The Kamehameha by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_6"},
{"id":"music_disc_menu_music_7","fx":"disc","n":"Music Disc - Dragon Ball - Kuririn Arrives by Boat","length":800,"stack":1,"rarity":"rare","desc":"Dragon Ball - Kuririn Arrives by Boat by Shunsuke Kikuchi","lore":["Dragon Ball - Kuririn Arrives by Boat by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_7"},
{"id":"music_disc_menu_music_8","fx":"disc","n":"Music Disc - Dragon Ball - Milk Delivery","length":780,"stack":1,"rarity":"rare","desc":"Dragon Ball - Milk Delivery by Shunsuke Kikuchi","lore":["Dragon Ball - Milk Delivery by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_8"},
{"id":"music_disc_menu_music_9","fx":"disc","n":"Music Disc - Dragon Ball - Climbing The Tower","length":1104,"stack":1,"rarity":"rare","desc":"Dragon Ball - Climbing The Tower by Shunsuke Kikuchi","lore":["Dragon Ball - Climbing The Tower by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_9"},
{"id":"music_disc_menu_music_10","fx":"disc","n":"Music Disc - Dragon Ball - Yajirobe in Action","length":1320,"stack":1,"rarity":"rare","desc":"Dragon Ball - Yajirobe in Action by Shunsuke Kikuchi","lore":["Dragon Ball - Yajirobe in Action by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_10"},
{"id":"music_disc_menu_music_11","fx":"disc","n":"Music Disc - Dragon Ball Z - Prologue & Subtitle I","length":1440,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Prologue & Subtitle I by Shunsuke Kikuchi","lore":["Dragon Ball Z - Prologue & Subtitle I by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_11"},
{"id":"music_disc_menu_music_12","fx":"disc","n":"Music Disc - Dragon Ball Z - Cha-La Head Cha-La (Variations)","length":880,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Cha-La Head Cha-La (Variations) by Shunsuke Kikuchi","lore":["Dragon Ball Z - Cha-La Head Cha-La (Variations) by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_12"},
{"id":"music_disc_menu_music_13","fx":"disc","n":"Music Disc - Dragon Ball Z - Bridge Collection","length":3240,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Bridge Collection by Shunsuke Kikuchi","lore":["Dragon Ball Z - Bridge Collection by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_13"},
{"id":"music_disc_menu_music_14","fx":"disc","n":"Music Disc - Dragon Ball Z - Gohan's Theme","length":1860,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Gohan's Theme by Shunsuke Kikuchi","lore":["Dragon Ball Z - Gohan's Theme by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_14"},
{"id":"music_disc_menu_music_15","fx":"disc","n":"Music Disc - Dragon Ball Z - Alas, the Days of Training","length":1780,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Alas, the Days of Training by Shunsuke Kikuchi","lore":["Dragon Ball Z - Alas, the Days of Training by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_15"},
{"id":"music_disc_menu_music_16","fx":"disc","n":"Music Disc - Dragon Ball Z - Planet Namek and Hope Vanish","length":880,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Planet Namek and Hope Vanish by Shunsuke Kikuchi","lore":["Dragon Ball Z - Planet Namek and Hope Vanish by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_16"},
{"id":"music_disc_menu_music_17","fx":"disc","n":"Music Disc - Dragon Ball Z - Dragon Ball Z","length":1606,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Dragon Ball Z by Shunsuke Kikuchi","lore":["Dragon Ball Z - Dragon Ball Z by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_17"},
{"id":"music_disc_menu_music_18","fx":"disc","n":"Music Disc - Dragon Ball Z - The Strongest In This World","length":1358,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - The Strongest In This World by Shunsuke Kikuchi","lore":["Dragon Ball Z - The Strongest In This World by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_18"},
{"id":"music_disc_menu_music_19","fx":"disc","n":"Music Disc - Dragon Ball Z - All's Well That Ends Well: One More Conclusion","length":1264,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - All's Well That Ends Well: One More Conclusion by Shunsuke Kikuchi","lore":["Dragon Ball Z - All's Well That Ends Well: One More Conclusion by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_19"},
{"id":"music_disc_menu_music_20","fx":"disc","n":"Music Disc - Dragon Ball Z - Son Goku the Super Saiyajin","length":2020,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Son Goku the Super Saiyajin by Shunsuke Kikuchi","lore":["Dragon Ball Z - Son Goku the Super Saiyajin by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_20"},
{"id":"music_disc_menu_music_21","fx":"disc","n":"Music Disc - Dragon Ball Z - Goodbye Warriors","length":1092,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Goodbye Warriors by Shunsuke Kikuchi","lore":["Dragon Ball Z - Goodbye Warriors by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_21"},
{"id":"music_disc_menu_music_22","fx":"disc","n":"Music Disc - Dragon Ball Z - Angel","length":3286,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Angel by Shunsuke Kikuchi","lore":["Dragon Ball Z - Angel by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_22"},
{"id":"music_disc_menu_music_23","fx":"disc","n":"Music Disc - Dragon Ball Z - Enter A New Hero","length":1670,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Enter A New Hero by Shunsuke Kikuchi","lore":["Dragon Ball Z - Enter A New Hero by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_23"},
{"id":"music_disc_menu_music_24","fx":"disc","n":"Music Disc - Dragon Ball Z - Son Goku is the Strongest After All","length":1936,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Son Goku is the Strongest After All by Shunsuke Kikuchi","lore":["Dragon Ball Z - Son Goku is the Strongest After All by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_24"},
{"id":"music_disc_menu_music_25","fx":"disc","n":"Music Disc - Dragon Ball Z - Danger!! The Super Warrior Can't Rest","length":2674,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Danger!! The Super Warrior Can't Rest by Shunsuke Kikuchi","lore":["Dragon Ball Z - Danger!! The Super Warrior Can't Rest by Shunsuke Kikuchi"],"m":"dmzpack:rpg/item/music_disc_menu_music_25"},
{"id":"music_disc_menu_music_26","fx":"disc","n":"Music Disc - Dragon Ball Super - Beerus' Tea Time","length":1944,"stack":1,"rarity":"rare","desc":"Dragon Ball Super - Beerus' Tea Time by Norihito Sumitomo","lore":["Dragon Ball Super - Beerus' Tea Time by Norihito Sumitomo"],"m":"dmzpack:rpg/item/music_disc_menu_music_26"},
{"id":"music_disc_menu_music_27","fx":"disc","n":"Music Disc - Dragon Ball Super - Under the Blue Sky","length":2288,"stack":1,"rarity":"rare","desc":"Dragon Ball Super - Under the Blue Sky by Norihito Sumitomo","lore":["Dragon Ball Super - Under the Blue Sky by Norihito Sumitomo"],"m":"dmzpack:rpg/item/music_disc_menu_music_27"},
{"id":"music_disc_menu_music_28","fx":"disc","n":"Music Disc - Dragon Ball Super - Pleasant Days","length":1316,"stack":1,"rarity":"rare","desc":"Dragon Ball Super - Pleasant Days by Norihito Sumitomo","lore":["Dragon Ball Super - Pleasant Days by Norihito Sumitomo"],"m":"dmzpack:rpg/item/music_disc_menu_music_28"},
{"id":"music_disc_menu_music_29","fx":"disc","n":"Music Disc - Dragon Ball Super - Limit-Break x Survivor","length":2238,"stack":1,"rarity":"rare","desc":"Dragon Ball Super - Limit-Break x Survivor by Norihito Sumitomo","lore":["Dragon Ball Super - Limit-Break x Survivor by Norihito Sumitomo"],"m":"dmzpack:rpg/item/music_disc_menu_music_29"},
{"id":"music_disc_menu_music_30","fx":"disc","n":"Music Disc - Dragon Ball Super - Like That Cloud","length":2218,"stack":1,"rarity":"rare","desc":"Dragon Ball Super - Like That Cloud by Norihito Sumitomo","lore":["Dragon Ball Super - Like That Cloud by Norihito Sumitomo"],"m":"dmzpack:rpg/item/music_disc_menu_music_30"},
{"id":"music_disc_menu_music_31","fx":"disc","n":"Music Disc - Dragon Ball Z - Call for a Miracle","length":5500,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Call for a Miracle","lore":["Dragon Ball Z - Call for a Miracle"],"m":"dmzpack:rpg/item/music_disc_menu_music_31"},
{"id":"music_disc_menu_music_32","fx":"disc","n":"Music Disc - Dragon Ball Z - Goku's Father-Son Victory","length":1500,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Goku's Father-Son Victory by Bruce Faulconer","lore":["Dragon Ball Z - Goku's Father-Son Victory by Bruce Faulconer"],"m":"dmzpack:rpg/item/music_disc_menu_music_32"},
{"id":"music_disc_menu_music_33","fx":"disc","n":"Music Disc - Dragon Ball Z - Vegeta's Sacrifice","length":4000,"stack":1,"rarity":"rare","desc":"Dragon Ball Z - Vegeta's Sacrifice by Bruce Faulconer","lore":["Dragon Ball Z - Vegeta's Sacrifice by Bruce Faulconer"],"m":"dmzpack:rpg/item/music_disc_menu_music_33"},
{"id":"music_disc_menu_music_34","fx":"disc","n":"Music Disc - Kingdom Hearts II - Dearly Beloved","length":5180,"stack":1,"rarity":"rare","desc":"Kingdom Hearts II - Dearly Beloved by Yoko Shimomura","lore":["Kingdom Hearts II - Dearly Beloved by Yoko Shimomura"],"m":"dmzpack:rpg/item/music_disc_menu_music_34"},
{"id":"music_disc_menu_music_35","fx":"disc","n":"Music Disc - Chainsaw Man: Reze Arc - in the pool","length":4900,"stack":1,"rarity":"rare","desc":"Chainsaw Man: Reze Arc - in the pool by Kensuke Ushio","lore":["Chainsaw Man: Reze Arc - in the pool by Kensuke Ushio"],"m":"dmzpack:rpg/item/music_disc_menu_music_35"},
{"id":"music_disc_menu_music_36","fx":"disc","n":"Music Disc - Saint Seiya - Sad Brothers","length":2720,"stack":1,"rarity":"rare","desc":"Saint Seiya - Sad Brothers by Seiji Yokoyama","lore":["Saint Seiya - Sad Brothers by Seiji Yokoyama"],"m":"dmzpack:rpg/item/music_disc_menu_music_36"},
{"id":"music_disc_menu_music_37","fx":"disc","n":"Music Disc - SAO: Aria of a Starless Night - we will finish this game","length":3180,"stack":1,"rarity":"rare","desc":"SAO: Aria of a Starless Night - we will finish this game by Yuki Kajiura","lore":["SAO: Aria of a Starless Night - we will finish this game by Yuki Kajiura"],"m":"dmzpack:rpg/item/music_disc_menu_music_37"},
{"id":"music_disc_menu_music_38","fx":"disc","n":"Music Disc - Re: Zero - Styx Helix","length":5560,"stack":1,"rarity":"rare","desc":"Re: Zero - Styx Helix by MYTH & ROID","lore":["Re: Zero - Styx Helix by MYTH & ROID"],"m":"dmzpack:rpg/item/music_disc_menu_music_38"},
{"id":"music_disc_menu_music_39","fx":"disc","n":"Music Disc - Re: Zero - Stay Alive ~Regain~","length":5880,"stack":1,"rarity":"rare","desc":"Re: Zero - Stay Alive ~Regain~ by Rie Takahashi","lore":["Re: Zero - Stay Alive ~Regain~ by Rie Takahashi"],"m":"dmzpack:rpg/item/music_disc_menu_music_39"},
{"id":"armor_crafting_kit","stack":1,"n":"Armor Crafting Kit","m":"dmzpack:rpg/item/armor_crafting_kit"},
{"id":"kikono_string","stack":64,"n":"Kikono String","m":"dmzpack:rpg/item/kikono_string"},
{"id":"kikono_cloth","stack":64,"n":"Kikono Cloth","m":"dmzpack:rpg/item/kikono_cloth"},
{"id":"blank_pattern_z","stack":64,"n":"Blank Pattern (&cZ&r)","m":"dmzpack:rpg/item/blank_pattern_z"},
{"id":"blank_pattern_super","stack":64,"n":"Blank Pattern (&3Super&r)","m":"dmzpack:rpg/item/blank_pattern_super"},
{"id":"dino1_spawn_egg","fx":"egg","mob":"dinosaur","stack":64,"n":"Dinosaur Spawn Egg","icon":"orb"},
{"id":"dino2_spawn_egg","fx":"egg","mob":"triceratops","stack":64,"n":"Large Dinosaur Spawn Egg","icon":"orb"},
{"id":"dino3_spawn_egg","fx":"egg","mob":"tyrannosaurus","stack":64,"n":"Flying Dinosaur Spawn Egg","icon":"orb"},
{"id":"dinokid_spawn_egg","fx":"egg","mob":"baby_dino","stack":64,"n":"Baby Dinosaur Spawn Egg","icon":"orb"},
{"id":"giran_spawn_egg","fx":"egg","mob":null,"stack":64,"n":"Giran Spawn Egg","icon":"orb"},
{"id":"namek_frog_spawn_egg","fx":"egg","mob":"namek_frog","stack":64,"n":"Namekian Frog Spawn Egg","icon":"orb"},
{"id":"ginyu_frog_spawn_egg","fx":"egg","mob":null,"stack":64,"n":"Namekian Frog (Ginyu) Spawn Egg","icon":"orb"},
{"id":"giant_fish_spawn_egg","fx":"egg","mob":"giant_fish","stack":64,"n":"Giant Fish Spawn Egg","icon":"orb"},
{"id":"giant_turtle_spawn_egg","fx":"egg","mob":"giant_turtle","stack":64,"n":"Giant Turtle Spawn Egg","icon":"orb"},
{"id":"soldier01_spawn_egg","fx":"egg","mob":"frieza_soldier","stack":64,"n":"Frieza's Soldier Spawn Egg","icon":"orb"},
{"id":"soldier02_spawn_egg","fx":"egg","mob":"frieza_soldier_heavy","stack":64,"n":"Frieza's Soldier Spawn Egg","icon":"orb"},
{"id":"soldier03_spawn_egg","fx":"egg","mob":"frieza_soldier_elite","stack":64,"n":"Frieza's Soldier Spawn Egg","icon":"orb"},
{"id":"nwarrior_spawn_egg","fx":"egg","mob":"namek_warrior","stack":64,"n":"Namekian Warrior Spawn Egg","icon":"orb"},
{"id":"demon_villager_spawn_egg","fx":"egg","mob":null,"stack":64,"n":"Demon Realm Villager Spawn Egg","icon":"orb"},
{"id":"time_patroller_spawn_egg","fx":"egg","mob":null,"stack":64,"n":"Time Patroller Spawn Egg","icon":"orb"},
{"id":"saibaman_spawn_egg","fx":"egg","mob":"saibaman","stack":64,"n":"Saibaman Spawn Egg","icon":"orb"},
{"id":"kaiwareman_spawn_egg","fx":"egg","mob":"saibaman_2","stack":64,"n":"Kaiwareman Spawn Egg","icon":"orb"},
{"id":"kyukonman_spawn_egg","fx":"egg","mob":"saibaman_3","stack":64,"n":"Kyukonman Spawn Egg","icon":"orb"},
{"id":"copyman_spawn_egg","fx":"egg","mob":"saibaman_4","stack":64,"n":"Copyman Spawn Egg","icon":"orb"},
{"id":"tennenman_spawn_egg","fx":"egg","mob":"saibaman_5","stack":64,"n":"Tennenman Spawn Egg","icon":"orb"},
{"id":"jinkouman_spawn_egg","fx":"egg","mob":"saibaman_6","stack":64,"n":"Jinkouman Spawn Egg","icon":"orb"},
{"id":"bioman_spawn_egg","fx":"egg","mob":null,"stack":64,"n":"Bioman Spawn Egg","icon":"orb"},
{"id":"evil_clone_goku_spawn_egg","fx":"egg","mob":null,"stack":64,"n":"Evil Clone Goku Spawn Egg","icon":"orb"},
{"id":"evil_clone_vegeta_spawn_egg","fx":"egg","mob":null,"stack":64,"n":"Evil Clone Vegeta Spawn Egg","icon":"orb"},
{"id":"evil_clone_piccolo_spawn_egg","fx":"egg","mob":null,"stack":64,"n":"Evil Clone Piccolo Spawn Egg","icon":"orb"},
{"id":"evil_clone_nappa_spawn_egg","fx":"egg","mob":null,"stack":64,"n":"Evil Clone Nappa Spawn Egg","icon":"orb"},
{"id":"evil_clone_krillin_spawn_egg","fx":"egg","mob":null,"stack":64,"n":"Evil Clone Krillin Spawn Egg","icon":"orb"},
{"id":"redribbon_soldier_spawn_egg","fx":"egg","mob":"red_ribbon_soldier","stack":64,"n":"Red Ribbon's Soldier Spawn Egg","icon":"orb"},
{"id":"redribbon_robot1_spawn_egg","fx":"egg","mob":"rr_robot_1","stack":64,"n":"Red Ribbon Robot Spawn Egg","icon":"orb"},
{"id":"redribbon_robot2_spawn_egg","fx":"egg","mob":"rr_robot_2","stack":64,"n":"Red Ribbon Robot Spawn Egg","icon":"orb"},
{"id":"redribbon_robot3_spawn_egg","fx":"egg","mob":"rr_robot_3","stack":64,"n":"Red Ribbon Robot Spawn Egg","icon":"orb"},
{"id":"bandit_spawn_egg","fx":"egg","mob":"bandit","stack":64,"n":"Bandit Spawn Egg","icon":"orb"},
{"id":"ogre_red_spawn_egg","fx":"egg","mob":"ogre_red","stack":64,"n":"Red Ogre Spawn Egg","icon":"orb"},
{"id":"ogre_blue_spawn_egg","fx":"egg","mob":"ogre","stack":64,"n":"Blue Ogre Spawn Egg","icon":"orb"},
{"id":"pattern_gete","n":"Gete Pattern","m":"dmzpack:rpg/item/patterns_pattern_gete","stack":64,"lore":["&7Gete tools in a Kikono Station"]},
{"id":"pattern_a13","n":"Red Ribbon Army Pattern (Android 13)","m":"dmzpack:rpg/item/patterns_pattern_a13","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_a14","n":"Red Ribbon Army Pattern (Android 14)","m":"dmzpack:rpg/item/patterns_pattern_a14","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_a16","n":"Red Ribbon Army Pattern (Android 16)","m":"dmzpack:rpg/item/patterns_pattern_a16","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_a17","n":"Red Ribbon Army Pattern (Android 17)","m":"dmzpack:rpg/item/patterns_pattern_a17","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_a17_super","n":"Android 17 Pattern (Super)","m":"dmzpack:rpg/item/patterns_pattern_a17_super","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_a18","n":"Red Ribbon Army Pattern (Android 18)","m":"dmzpack:rpg/item/patterns_pattern_a18","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_a18_cell","n":"Android 18 Pattern (Cell Saga)","m":"dmzpack:rpg/item/patterns_pattern_a18_cell","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_a18_kame","n":"Android 18 Pattern (Kame House)","m":"dmzpack:rpg/item/patterns_pattern_a18_kame","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_a18_tournament","n":"Android 18 Pattern (Tournament)","m":"dmzpack:rpg/item/patterns_pattern_a18_tournament","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_a20","n":"Red Ribbon Army Pattern (Android 20)","m":"dmzpack:rpg/item/patterns_pattern_a20","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_age1000","n":"Capsule Corp Pattern (Age 1000)","m":"dmzpack:rpg/item/patterns_pattern_age1000","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_bardock1","n":"Saiyan Armor Pattern (Bardock) (DBZ)","m":"dmzpack:rpg/item/patterns_pattern_bardock1","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_bardock2","n":"Saiyan Armor Pattern (Bardock) (DBSuper)","m":"dmzpack:rpg/item/patterns_pattern_bardock2","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_beerus","n":"God of Destruction Pattern (Beerus)","m":"dmzpack:rpg/item/patterns_pattern_beerus","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_black","n":"Black Turtle Hermit School GI Pattern (Black)","m":"dmzpack:rpg/item/patterns_pattern_black","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_broly_super","n":"Saiyan Armor Pattern (Broly) (Super)","m":"dmzpack:rpg/item/patterns_pattern_broly_super","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_broly_z","n":"Control Jewelry Set Pattern (Broly)","m":"dmzpack:rpg/item/patterns_pattern_broly_z","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_capsule_corp","n":"Capsule Corp Pattern (Age 1000)","m":"dmzpack:rpg/item/patterns_pattern_capsule_corp","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_caulifla","n":"Saiyan Pattern (Caulifla)","m":"dmzpack:rpg/item/patterns_pattern_caulifla","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_chaoz","n":"Crane School Pattern (Chaoz)","m":"dmzpack:rpg/item/patterns_pattern_chaoz","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_cooler_soldier","n":"Cooler's Soldier Pattern","m":"dmzpack:rpg/item/patterns_pattern_cooler_soldier","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_dragon_clan","n":"DBOnline Armor Pattern (Dragon)","m":"dmzpack:rpg/item/patterns_pattern_dragon_clan","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_evil_buu","n":"Majin Pattern (Evil Buu)","m":"dmzpack:rpg/item/patterns_pattern_evil_buu","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_fighter","n":"DBOnline Armor Pattern (Fighter)","m":"dmzpack:rpg/item/patterns_pattern_fighter","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_fusionzamasu","n":"Kaioshin Pattern (Fused Zamasu)","m":"dmzpack:rpg/item/patterns_pattern_fusionzamasu","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_future_gohan","n":"Turtle Hermit School GI Pattern (Future Gohan)","m":"dmzpack:rpg/item/patterns_pattern_future_gohan","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_gamma1","n":"Red Ribbon Army Pattern (Gamma 1)","m":"dmzpack:rpg/item/patterns_pattern_gamma1","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_gamma2","n":"Red Ribbon Army Pattern (Gamma 2)","m":"dmzpack:rpg/item/patterns_pattern_gamma2","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_gas","n":"Heata Family Pattern (Gas)","m":"dmzpack:rpg/item/patterns_pattern_gas","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_gero","n":"Red Ribbon Army Pattern (Dr. Gero)","m":"dmzpack:rpg/item/patterns_pattern_gero","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_gine","n":"Saiyan Armor Pattern (Gine)","m":"dmzpack:rpg/item/patterns_pattern_gine","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_gogeta","n":"Metamoran Suit Pattern (Gogeta)","m":"dmzpack:rpg/item/patterns_pattern_gogeta","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_gohan1","n":"Demon GI Pattern (Gohan)","m":"dmzpack:rpg/item/patterns_pattern_gohan1","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_gohan_super","n":"Demon GI Pattern (Gohan) (Super)","m":"dmzpack:rpg/item/patterns_pattern_gohan_super","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_goku1","n":"Turtle Hermit School GI Pattern (Goku)","m":"dmzpack:rpg/item/patterns_pattern_goku1","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_goku_gt","n":"Blue Master GI Pattern (Goku) (GT)","m":"dmzpack:rpg/item/patterns_pattern_goku_gt","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_goku_kid","n":"Red Turtle Hermit School GI Pattern (Goku) (Kid)","m":"dmzpack:rpg/item/patterns_pattern_goku_kid","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_goku_super","n":"Turtle Hermit School GI Pattern (Goku) (Super)","m":"dmzpack:rpg/item/patterns_pattern_goku_super","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_goku_whis","n":"Whis Symbol GI Pattern (Goku)","m":"dmzpack:rpg/item/patterns_pattern_goku_whis","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_goten","n":"Turtle Hermit School GI Pattern (Goten)","m":"dmzpack:rpg/item/patterns_pattern_goten","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_goten_super","n":"Green Jacket Outfit Pattern (Goten) (Super)","m":"dmzpack:rpg/item/patterns_pattern_goten_super","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_granola","n":"Cerealian Pattern (Granola)","m":"dmzpack:rpg/item/patterns_pattern_granola","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_great_saiyaman","n":"Hero of Justice Pattern (Great Saiyaman)","m":"dmzpack:rpg/item/patterns_pattern_great_saiyaman","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_great_saiyaman_2","n":"Hero of Justice 2 Pattern (Great Saiyaman 2)","m":"dmzpack:rpg/item/patterns_pattern_great_saiyaman_2","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_hit","n":"Assassin Pattern (Hit)","m":"dmzpack:rpg/item/patterns_pattern_hit","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_kale","n":"Saiyan Pattern (Kale)","m":"dmzpack:rpg/item/patterns_pattern_kale","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_kefla","n":"Saiyan Pattern (Kefla)","m":"dmzpack:rpg/item/patterns_pattern_kefla","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_kibito","n":"Kaioshin Pattern (Kibito)","m":"dmzpack:rpg/item/patterns_pattern_kibito","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_king_vegeta","n":"Royal Armor Pattern (King Vegeta)","m":"dmzpack:rpg/item/patterns_pattern_king_vegeta","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_majin21","n":"Majin Pattern (Android 21)","m":"dmzpack:rpg/item/patterns_pattern_majin21","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_majin_buu","n":"Majin Pattern (Buu)","m":"dmzpack:rpg/item/patterns_pattern_majin_buu","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_mighty_majin","n":"DBOnline Armor Pattern (Mighty)","m":"dmzpack:rpg/item/patterns_pattern_mighty_majin","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_mystic","n":"DBOnline Armor Pattern (Mystic)","m":"dmzpack:rpg/item/patterns_pattern_mystic","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_orange_high","n":"Orange Star High School Pattern","m":"dmzpack:rpg/item/patterns_pattern_orange_high","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_piccolo","n":"Demon GI Pattern (Piccolo)","m":"dmzpack:rpg/item/patterns_pattern_piccolo","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_pride_troops","n":"Pride Troops Pattern (U11)","m":"dmzpack:rpg/item/patterns_pattern_pride_troops","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_raditz","n":"Saiyan Armor Pattern (Raditz)","m":"dmzpack:rpg/item/patterns_pattern_raditz","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_shin","n":"Kaioshin Pattern (Shin)","m":"dmzpack:rpg/item/patterns_pattern_shin","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_slug","n":"Evil Namekian Pattern (Slug)","m":"dmzpack:rpg/item/patterns_pattern_slug","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_super_buu","n":"Majin Pattern (Super Buu)","m":"dmzpack:rpg/item/patterns_pattern_super_buu","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_tien","n":"Crane School GI Pattern (Tien)","m":"dmzpack:rpg/item/patterns_pattern_tien","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_trunks_kid","n":"Green GI Pattern (Trunks) (Kid)","m":"dmzpack:rpg/item/patterns_pattern_trunks_kid","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_trunks_super","n":"Capsule Corp Jacket Pattern (Trunks) (Super)","m":"dmzpack:rpg/item/patterns_pattern_trunks_super","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_trunks_z","n":"Capsule Corp Jacket Pattern (Trunks)","m":"dmzpack:rpg/item/patterns_pattern_trunks_z","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_turles","n":"Saiyan Armor Pattern (Turles)","m":"dmzpack:rpg/item/patterns_pattern_turles","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_vegeta1","n":"Saiyan Armor Pattern (Vegeta) (Saiyan)","m":"dmzpack:rpg/item/patterns_pattern_vegeta1","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_vegeta2","n":"Saiyan Armor Pattern (Vegeta) (Namek)","m":"dmzpack:rpg/item/patterns_pattern_vegeta2","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_vegeta_buu","n":"Blue Training Outfit Pattern (Vegeta) (Buu)","m":"dmzpack:rpg/item/patterns_pattern_vegeta_buu","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_vegeta_gt","n":"Vegeta Pattern (GT)","m":"dmzpack:rpg/item/patterns_pattern_vegeta_gt","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_vegeta_super","n":"Saiyan Armor Pattern (Vegeta) (Super)","m":"dmzpack:rpg/item/patterns_pattern_vegeta_super","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_vegeta_whis","n":"Whis Symbol GI Pattern (Vegeta)","m":"dmzpack:rpg/item/patterns_pattern_vegeta_whis","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_vegeta_z","n":"Saiyan Armor Pattern (Vegeta) (Cell)","m":"dmzpack:rpg/item/patterns_pattern_vegeta_z","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_vegetto","n":"Inverted Turtle Hermit School GI Pattern (Vegito)","m":"dmzpack:rpg/item/patterns_pattern_vegetto","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_vergil","n":"The Alpha and the Omega Pattern (Vergil)","m":"dmzpack:rpg/item/patterns_pattern_vergil","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_videl","n":"Orange Star High School Pattern (Videl)","m":"dmzpack:rpg/item/patterns_pattern_videl","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_warrior_clan","n":"DBOnline Armor Pattern (Warrior)","m":"dmzpack:rpg/item/patterns_pattern_warrior_clan","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_whis","n":"Angel Pattern (Whis)","m":"dmzpack:rpg/item/patterns_pattern_whis","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_wonder_majin","n":"DBOnline Armor Pattern (Wonder)","m":"dmzpack:rpg/item/patterns_pattern_wonder_majin","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_xeno_goku","n":"Time Patrol Pattern (Goku Xeno)","m":"dmzpack:rpg/item/patterns_pattern_xeno_goku","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_xeno_goku_patreon","n":"Time Patrol Pattern (Goku Xeno Alternative)","m":"dmzpack:rpg/item/patterns_pattern_xeno_goku_patreon","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_yardrat","n":"Yardrat Outfit Pattern (Goku)","m":"dmzpack:rpg/item/patterns_pattern_yardrat","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"pattern_zamasu","n":"Kaioshin Pattern (Zamasu)","m":"dmzpack:rpg/item/patterns_pattern_zamasu","stack":64,"lore":["&7Use in a Kikono Station"]},
{"id":"a13_armor_chestplate","n":"Red Ribbon Army Chestplate (&cAndroid 13&r)","fx":"armor","slot":"chest","armor":35,"tex":"a13","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_a13_armor_chestplate"},
{"id":"a13_armor_leggings","n":"Red Ribbon Army Leggings (&cAndroid 13&r)","fx":"armor","slot":"legs","armor":26,"tex":"a13","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_a13_armor_leggings"},
{"id":"a13_armor_boots","n":"Red Ribbon Army Boots (&cAndroid 13&r)","fx":"armor","slot":"feet","armor":16,"tex":"a13","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_a13_armor_boots"},
{"id":"a14_armor_chestplate","n":"Red Ribbon Army Chestplate (&eAndroid 14&r)","fx":"armor","slot":"chest","armor":35,"tex":"a14","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_a14_armor_chestplate"},
{"id":"a14_armor_leggings","n":"Red Ribbon Army Leggings (&eAndroid 14&r)","fx":"armor","slot":"legs","armor":26,"tex":"a14","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_a14_armor_leggings"},
{"id":"a14_armor_boots","n":"Red Ribbon Army Boots (&eAndroid 14&r)","fx":"armor","slot":"feet","armor":16,"tex":"a14","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_a14_armor_boots"},
{"id":"a16_armor_chestplate","n":"Red Ribbon Army Chestplate (&aAndroid 16&r)","fx":"armor","slot":"chest","armor":35,"tex":"a16","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_a16_armor_chestplate"},
{"id":"a16_armor_leggings","n":"Red Ribbon Army Leggings (&aAndroid 16&r)","fx":"armor","slot":"legs","armor":26,"tex":"a16","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_a16_armor_leggings"},
{"id":"a16_armor_boots","n":"Red Ribbon Army Boots (&aAndroid 16&r)","fx":"armor","slot":"feet","armor":16,"tex":"a16","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_a16_armor_boots"},
{"id":"a17_armor_chestplate","n":"Red Ribbon Army Chestplate (&3Android 17&r)","fx":"armor","slot":"chest","armor":35,"tex":"a17","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_a17_armor_chestplate"},
{"id":"a17_armor_leggings","n":"Red Ribbon Army Leggings (&3Android 17&r)","fx":"armor","slot":"legs","armor":26,"tex":"a17","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_a17_armor_leggings"},
{"id":"a17_armor_boots","n":"Red Ribbon Army Boots (&3Android 17&r)","fx":"armor","slot":"feet","armor":16,"tex":"a17","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_a17_armor_boots"},
{"id":"a17_super_armor_chestplate","n":"Android 17 Chestplate (&bSuper&r)","fx":"armor","slot":"chest","armor":35,"tex":"a17super","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_a17_super_armor_chestplate"},
{"id":"a17_super_armor_leggings","n":"Android 17 Leggings (&bSuper&r)","fx":"armor","slot":"legs","armor":26,"tex":"a17super","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_a17_super_armor_leggings"},
{"id":"a17_super_armor_boots","n":"Android 17 Boots (&bSuper&r)","fx":"armor","slot":"feet","armor":16,"tex":"a17super","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_a17_super_armor_boots"},
{"id":"a18_armor_chestplate","n":"Red Ribbon Army Chestplate (&6Android 18&r)","fx":"armor","slot":"chest","armor":35,"tex":"a18","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_a18_armor_chestplate"},
{"id":"a18_armor_leggings","n":"Red Ribbon Army Leggings (&6Android 18&r)","fx":"armor","slot":"legs","armor":26,"tex":"a18","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_a18_armor_leggings"},
{"id":"a18_armor_boots","n":"Red Ribbon Army Boots (&6Android 18&r)","fx":"armor","slot":"feet","armor":16,"tex":"a18","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_a18_armor_boots"},
{"id":"a18_cell_armor_chestplate","n":"Android 18 Chestplate (&2Cell Saga&r)","fx":"armor","slot":"chest","armor":35,"tex":"a18cell","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_a18_cell_armor_chestplate"},
{"id":"a18_cell_armor_leggings","n":"Android 18 Leggings (&2Cell Saga&r)","fx":"armor","slot":"legs","armor":26,"tex":"a18cell","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_a18_cell_armor_leggings"},
{"id":"a18_cell_armor_boots","n":"Android 18 Boots (&2Cell Saga&r)","fx":"armor","slot":"feet","armor":16,"tex":"a18cell","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_a18_cell_armor_boots"},
{"id":"a18_kame_armor_chestplate","n":"Android 18 Chestplate (&eKame House&r)","fx":"armor","slot":"chest","armor":35,"tex":"a18kame","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_a18_kame_armor_chestplate"},
{"id":"a18_kame_armor_leggings","n":"Android 18 Leggings (&eKame House&r)","fx":"armor","slot":"legs","armor":26,"tex":"a18kame","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_a18_kame_armor_leggings"},
{"id":"a18_kame_armor_boots","n":"Android 18 Boots (&eKame House&r)","fx":"armor","slot":"feet","armor":16,"tex":"a18kame","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_a18_kame_armor_boots"},
{"id":"a18_tournament_armor_chestplate","n":"Android 18 Chestplate (&6Tournament&r)","fx":"armor","slot":"chest","armor":35,"tex":"a18tournament","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_a18_tournament_armor_chestplate"},
{"id":"a18_tournament_armor_leggings","n":"Android 18 Leggings (&6Tournament&r)","fx":"armor","slot":"legs","armor":26,"tex":"a18tournament","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_a18_tournament_armor_leggings"},
{"id":"a18_tournament_armor_boots","n":"Android 18 Boots (&6Tournament&r)","fx":"armor","slot":"feet","armor":16,"tex":"a18tournament","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_a18_tournament_armor_boots"},
{"id":"a20_armor_helmet","n":"Red Ribbon Army Helmet (&cAndroid 20&r)","fx":"armor","slot":"head","armor":2,"tex":"a20","stack":1,"durability":407,"m":"dmzpack:rpg/item/armors_a20_armor_helmet"},
{"id":"a20_armor_chestplate","n":"Red Ribbon Army Chestplate (&cAndroid 20&r)","fx":"armor","slot":"chest","armor":35,"tex":"a20","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_a20_armor_chestplate"},
{"id":"a20_armor_leggings","n":"Red Ribbon Army Leggings (&cAndroid 20&r)","fx":"armor","slot":"legs","armor":26,"tex":"a20","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_a20_armor_leggings"},
{"id":"a20_armor_boots","n":"Red Ribbon Army Boots (&cAndroid 20&r)","fx":"armor","slot":"feet","armor":16,"tex":"a20","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_a20_armor_boots"},
{"id":"age1000_armor_chestplate","n":"Capsule Corp Chestplate (&eAge 1000&r)","fx":"armor","slot":"chest","armor":35,"tex":"age1000","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_age1000_armor_chestplate"},
{"id":"age1000_armor_leggings","n":"Capsule Corp Leggings (&eAge 1000&r)","fx":"armor","slot":"legs","armor":26,"tex":"age1000","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_age1000_armor_leggings"},
{"id":"age1000_armor_boots","n":"Capsule Corp Boots (&eAge 1000&r)","fx":"armor","slot":"feet","armor":16,"tex":"age1000","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_age1000_armor_boots"},
{"id":"bardock_dbz_armor_chestplate","n":"Saiyan Armor Chestplate (&eBardock&r - DBZ)","fx":"armor","slot":"chest","armor":35,"tex":"bardock_armor","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_bardock_dbz_armor_chestplate"},
{"id":"bardock_dbz_armor_leggings","n":"Saiyan Armor Leggings (&eBardock&r - DBZ)","fx":"armor","slot":"legs","armor":26,"tex":"bardock_armor","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_bardock_dbz_armor_leggings"},
{"id":"bardock_dbz_armor_boots","n":"Saiyan Armor Boots (&eBardock&r - DBZ)","fx":"armor","slot":"feet","armor":16,"tex":"bardock_armor","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_bardock_dbz_armor_boots"},
{"id":"bardock_super_armor_chestplate","n":"Saiyan Armor Chestplate (&eBardock&r - DBSuper)","fx":"armor","slot":"chest","armor":35,"tex":"bardockdbs_armor","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_bardock_super_armor_chestplate"},
{"id":"bardock_super_armor_leggings","n":"Saiyan Armor Leggings (&eBardock&r - DBSuper)","fx":"armor","slot":"legs","armor":26,"tex":"bardockdbs_armor","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_bardock_super_armor_leggings"},
{"id":"bardock_super_armor_boots","n":"Saiyan Armor Boots (&eBardock&r - DBSuper)","fx":"armor","slot":"feet","armor":16,"tex":"bardockdbs_armor","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_bardock_super_armor_boots"},
{"id":"beerus_armor_chestplate","n":"God of Destruction Chestplate (Beerus)","fx":"armor","slot":"chest","armor":35,"tex":"beerus","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_beerus_armor_chestplate"},
{"id":"beerus_armor_leggings","n":"God of Destruction Leggings (Beerus)","fx":"armor","slot":"legs","armor":26,"tex":"beerus","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_beerus_armor_leggings"},
{"id":"beerus_armor_boots","n":"God of Destruction Boots (Beerus)","fx":"armor","slot":"feet","armor":16,"tex":"beerus","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_beerus_armor_boots"},
{"id":"blackgoku_armor_chestplate","n":"Black Turtle Hermit School GI Chestplate (&7Black Goku&r)","fx":"armor","slot":"chest","armor":35,"tex":"blackgoku","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_blackgoku_armor_chestplate"},
{"id":"blackgoku_armor_leggings","n":"Black Turtle Hermit School GI Leggings (&7Black Goku&r)","fx":"armor","slot":"legs","armor":26,"tex":"blackgoku","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_blackgoku_armor_leggings"},
{"id":"blackgoku_armor_boots","n":"Black Turtle Hermit School GI Boots (&7Black Goku&r)","fx":"armor","slot":"feet","armor":16,"tex":"blackgoku","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_blackgoku_armor_boots"},
{"id":"broly_super_armor_chestplate","n":"Saiyan Armor Chestplate (&aBroly&r)","fx":"armor","slot":"chest","armor":35,"tex":"broly_dbs","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_broly_super_armor_chestplate"},
{"id":"broly_super_armor_leggings","n":"Saiyan Armor Leggings (&aBroly&r)","fx":"armor","slot":"legs","armor":26,"tex":"broly_dbs","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_broly_super_armor_leggings"},
{"id":"broly_super_armor_boots","n":"Saiyan Armor Boots (&aBroly&r)","fx":"armor","slot":"feet","armor":16,"tex":"broly_dbs","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_broly_super_armor_boots"},
{"id":"broly_z_armor_helmet","n":"Control Jewelry Tiara (&aBroly&r)","fx":"armor","slot":"head","armor":2,"tex":"broly_dbz","stack":1,"durability":407,"m":"dmzpack:rpg/item/armors_broly_z_armor_helmet"},
{"id":"broly_z_armor_chestplate","n":"Control Jewelry Set Chestplate (&aBroly&r)","fx":"armor","slot":"chest","armor":35,"tex":"broly_dbz","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_broly_z_armor_chestplate"},
{"id":"broly_z_armor_leggings","n":"Control Jewelry Set Leggings (&aBroly&r)","fx":"armor","slot":"legs","armor":26,"tex":"broly_dbz","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_broly_z_armor_leggings"},
{"id":"broly_z_armor_boots","n":"Control Jewelry Set Boots (&aBroly&r)","fx":"armor","slot":"feet","armor":16,"tex":"broly_dbz","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_broly_z_armor_boots"},
{"id":"brightlys_regular_wear_armor_chestplate","n":"Brightly's Regular Wear Chestplate","fx":"armor","slot":"chest","armor":35,"tex":"brightlys_regular_wear","stack":1,"durability":592,"icon":"chestplate"},
{"id":"brightlys_regular_wear_armor_leggings","n":"Brightly's Regular Wear Leggings","fx":"armor","slot":"legs","armor":26,"tex":"brightlys_regular_wear","stack":1,"durability":555,"icon":"leggings"},
{"id":"brightlys_regular_wear_armor_boots","n":"Brightly's Regular Wear Boots","fx":"armor","slot":"feet","armor":16,"tex":"brightlys_regular_wear","stack":1,"durability":481,"icon":"boots"},
{"id":"capsule_corp_armor_chestplate","n":"Capsule Corp Chestplate","fx":"armor","slot":"chest","armor":35,"tex":"capsule_corp","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_capsule_corp_armor_chestplate"},
{"id":"capsule_corp_armor_leggings","n":"Capsule Corp Leggings","fx":"armor","slot":"legs","armor":26,"tex":"capsule_corp","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_capsule_corp_armor_leggings"},
{"id":"capsule_corp_armor_boots","n":"Capsule Corp Boots","fx":"armor","slot":"feet","armor":16,"tex":"capsule_corp","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_capsule_corp_armor_boots"},
{"id":"caulifla_armor_chestplate","n":"Saiyan Armor Chestplate (&dCaulifla&r)","fx":"armor","slot":"chest","armor":35,"tex":"caulifla","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_caulifla_armor_chestplate"},
{"id":"caulifla_armor_leggings","n":"Saiyan Armor Leggings (&dCaulifla&r)","fx":"armor","slot":"legs","armor":26,"tex":"caulifla","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_caulifla_armor_leggings"},
{"id":"caulifla_armor_boots","n":"Saiyan Armor Boots (&dCaulifla&r)","fx":"armor","slot":"feet","armor":16,"tex":"caulifla","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_caulifla_armor_boots"},
{"id":"chaoz_armor_helmet","n":"Crane School GI Helmet (&bChaotzu&r)","fx":"armor","slot":"head","armor":2,"tex":"chaoz","stack":1,"durability":407,"m":"dmzpack:rpg/item/armors_chaoz_armor_helmet"},
{"id":"chaoz_armor_chestplate","n":"Crane School GI Chestplate (&bChaotzu&r)","fx":"armor","slot":"chest","armor":35,"tex":"chaoz","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_chaoz_armor_chestplate"},
{"id":"chaoz_armor_leggings","n":"Crane School GI Leggings (&bChaotzu&r)","fx":"armor","slot":"legs","armor":26,"tex":"chaoz","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_chaoz_armor_leggings"},
{"id":"chaoz_armor_boots","n":"Crane School GI Boots (&bChaotzu&r)","fx":"armor","slot":"feet","armor":16,"tex":"chaoz","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_chaoz_armor_boots"},
{"id":"cooler_soldier_armor_chestplate","n":"Cooler's Soldier Chestplate","fx":"armor","slot":"chest","armor":35,"tex":"cooler_soldier","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_cooler_soldier_armor_chestplate"},
{"id":"cooler_soldier_armor_leggings","n":"Cooler's Soldier Leggings","fx":"armor","slot":"legs","armor":26,"tex":"cooler_soldier","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_cooler_soldier_armor_leggings"},
{"id":"cooler_soldier_armor_boots","n":"Cooler's Soldier Boots","fx":"armor","slot":"feet","armor":16,"tex":"cooler_soldier","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_cooler_soldier_armor_boots"},
{"id":"demon_gi_blue_armor_chestplate","n":"Demon GI Chestplate (&3Gohan&r)","fx":"armor","slot":"chest","armor":35,"tex":"demon_gi_gohan","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_demon_gi_blue_armor_chestplate"},
{"id":"demon_gi_blue_armor_leggings","n":"Demon GI Leggings (&3Gohan&r)","fx":"armor","slot":"legs","armor":26,"tex":"demon_gi_gohan","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_demon_gi_blue_armor_leggings"},
{"id":"demon_gi_blue_armor_boots","n":"Demon GI Boots (&3Gohan&r)","fx":"armor","slot":"feet","armor":16,"tex":"demon_gi_gohan","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_demon_gi_blue_armor_boots"},
{"id":"dragon_clan_armor_chestplate","n":"DBOnline Chestplate (&5Dragon&r)","fx":"armor","slot":"chest","armor":35,"tex":"dragon_clan","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_dragon_clan_armor_chestplate"},
{"id":"dragon_clan_armor_leggings","n":"DBOnline Leggings (&5Dragon&r)","fx":"armor","slot":"legs","armor":26,"tex":"dragon_clan","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_dragon_clan_armor_leggings"},
{"id":"dragon_clan_armor_boots","n":"DBOnline Boots (&5Dragon&r)","fx":"armor","slot":"feet","armor":16,"tex":"dragon_clan","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_dragon_clan_armor_boots"},
{"id":"evil_buu_armor_chestplate","n":"Majin Chestplate (&5Evil Buu&r)","fx":"armor","slot":"chest","armor":35,"tex":"evil_buu","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_evil_buu_armor_chestplate"},
{"id":"evil_buu_armor_leggings","n":"Majin Leggings (&5Evil Buu&r)","fx":"armor","slot":"legs","armor":26,"tex":"evil_buu","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_evil_buu_armor_leggings"},
{"id":"evil_buu_armor_boots","n":"Majin Boots (&5Evil Buu&r)","fx":"armor","slot":"feet","armor":16,"tex":"evil_buu","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_evil_buu_armor_boots"},
{"id":"fighter_armor_chestplate","n":"DBOnline Chestplate (&2Fighter&r)","fx":"armor","slot":"chest","armor":35,"tex":"fighter","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_fighter_armor_chestplate"},
{"id":"fighter_armor_leggings","n":"DBOnline Leggings (&2Fighter&r)","fx":"armor","slot":"legs","armor":26,"tex":"fighter","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_fighter_armor_leggings"},
{"id":"fighter_armor_boots","n":"DBOnline Boots (&2Fighter&r)","fx":"armor","slot":"feet","armor":16,"tex":"fighter","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_fighter_armor_boots"},
{"id":"fusion_zamasu_armor_chestplate","n":"Kaioshin Chestplate (&dFused Zamasu&r)","fx":"armor","slot":"chest","armor":35,"tex":"fzamasu_gi","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_fusion_zamasu_armor_chestplate"},
{"id":"fusion_zamasu_armor_leggings","n":"Kaioshin Leggings (&dFused Zamasu&r)","fx":"armor","slot":"legs","armor":26,"tex":"fzamasu_gi","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_fusion_zamasu_armor_leggings"},
{"id":"fusion_zamasu_armor_boots","n":"Kaioshin Boots (&dFused Zamasu&r)","fx":"armor","slot":"feet","armor":16,"tex":"fzamasu_gi","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_fusion_zamasu_armor_boots"},
{"id":"future_gohan_armor_chestplate","n":"Turtle Hermit School GI Chestplate (&6Future Gohan&r)","fx":"armor","slot":"chest","armor":35,"tex":"future_gohan","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_future_gohan_armor_chestplate"},
{"id":"future_gohan_armor_leggings","n":"Turtle Hermit School GI Leggings (&6Future Gohan&r)","fx":"armor","slot":"legs","armor":26,"tex":"future_gohan","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_future_gohan_armor_leggings"},
{"id":"future_gohan_armor_boots","n":"Turtle Hermit School GI Boots (&6Future Gohan&r)","fx":"armor","slot":"feet","armor":16,"tex":"future_gohan","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_future_gohan_armor_boots"},
{"id":"gamma1_armor_chestplate","n":"Red Ribbon Army Chestplate (&cGamma 1&r)","fx":"armor","slot":"chest","armor":35,"tex":"gamma1","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_gamma1_armor_chestplate"},
{"id":"gamma1_armor_leggings","n":"Red Ribbon Army Leggings (&cGamma 1&r)","fx":"armor","slot":"legs","armor":26,"tex":"gamma1","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_gamma1_armor_leggings"},
{"id":"gamma1_armor_boots","n":"Red Ribbon Army Boots (&cGamma 1&r)","fx":"armor","slot":"feet","armor":16,"tex":"gamma1","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_gamma1_armor_boots"},
{"id":"gamma2_armor_chestplate","n":"Red Ribbon Army Chestplate (&3Gamma 2&r)","fx":"armor","slot":"chest","armor":35,"tex":"gamma2","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_gamma2_armor_chestplate"},
{"id":"gamma2_armor_leggings","n":"Red Ribbon Army Leggings (&3Gamma 2&r)","fx":"armor","slot":"legs","armor":26,"tex":"gamma2","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_gamma2_armor_leggings"},
{"id":"gamma2_armor_boots","n":"Red Ribbon Army Boots (&3Gamma 2&r)","fx":"armor","slot":"feet","armor":16,"tex":"gamma2","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_gamma2_armor_boots"},
{"id":"gas_armor_chestplate","n":"Heata Family Chestplate (&dGas&r)","fx":"armor","slot":"chest","armor":35,"tex":"gas","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_gas_armor_chestplate"},
{"id":"gas_armor_leggings","n":"Heata Family Leggings (&dGas&r)","fx":"armor","slot":"legs","armor":26,"tex":"gas","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_gas_armor_leggings"},
{"id":"gas_armor_boots","n":"Heata Family Boots (&dGas&r)","fx":"armor","slot":"feet","armor":16,"tex":"gas","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_gas_armor_boots"},
{"id":"gero_armor_chestplate","n":"Red Ribbon Army Chestplate (&cDr. Gero&r)","fx":"armor","slot":"chest","armor":35,"tex":"gero","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_gero_armor_chestplate"},
{"id":"gero_armor_leggings","n":"Red Ribbon Army Leggings (&cDr. Gero&r)","fx":"armor","slot":"legs","armor":26,"tex":"gero","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_gero_armor_leggings"},
{"id":"gero_armor_boots","n":"Red Ribbon Army Boots (&cDr. Gero&r)","fx":"armor","slot":"feet","armor":16,"tex":"gero","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_gero_armor_boots"},
{"id":"gine_armor_chestplate","n":"Saiyan Armor Chestplate (&cGine&r)","fx":"armor","slot":"chest","armor":35,"tex":"gine","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_gine_armor_chestplate"},
{"id":"gine_armor_leggings","n":"Saiyan Armor Leggings (&cGine&r)","fx":"armor","slot":"legs","armor":26,"tex":"gine","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_gine_armor_leggings"},
{"id":"gine_armor_boots","n":"Saiyan Armor Boots (&cGine&r)","fx":"armor","slot":"feet","armor":16,"tex":"gine","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_gine_armor_boots"},
{"id":"gogeta_armor_chestplate","n":"Metamoran Suit Chestplate (&bGogeta&r)","fx":"armor","slot":"chest","armor":35,"tex":"gogeta","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_gogeta_armor_chestplate"},
{"id":"gogeta_armor_leggings","n":"Metamoran Suit Leggings (&bGogeta&r)","fx":"armor","slot":"legs","armor":26,"tex":"gogeta","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_gogeta_armor_leggings"},
{"id":"gogeta_armor_boots","n":"Metamoran Suit Boots (&bGogeta&r)","fx":"armor","slot":"feet","armor":16,"tex":"gogeta","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_gogeta_armor_boots"},
{"id":"gohan_super_armor_chestplate","n":"Demon GI Chestplate (&3Gohan&r - Super)","fx":"armor","slot":"chest","armor":35,"tex":"gohan_dbs","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_gohan_super_armor_chestplate"},
{"id":"gohan_super_armor_leggings","n":"Demon GI Leggings (&3Gohan&r - Super)","fx":"armor","slot":"legs","armor":26,"tex":"gohan_dbs","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_gohan_super_armor_leggings"},
{"id":"gohan_super_armor_boots","n":"Demon GI Boots (&3Gohan&r - Super)","fx":"armor","slot":"feet","armor":16,"tex":"gohan_dbs","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_gohan_super_armor_boots"},
{"id":"goku_armor_chestplate","n":"Turtle Hermit School GI Chestplate (&6Goku&r)","fx":"armor","slot":"chest","armor":35,"tex":"goku_gi","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_goku_armor_chestplate"},
{"id":"goku_armor_leggings","n":"Turtle Hermit School GI Leggings (&6Goku&r)","fx":"armor","slot":"legs","armor":26,"tex":"goku_gi","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_goku_armor_leggings"},
{"id":"goku_armor_boots","n":"Turtle Hermit School GI Boots (&6Goku&r)","fx":"armor","slot":"feet","armor":16,"tex":"goku_gi","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_goku_armor_boots"},
{"id":"goku_gt_armor_chestplate","n":"Blue Master GI Chestplate (&6Goku&r - GT)","fx":"armor","slot":"chest","armor":35,"tex":"goku_gt","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_goku_gt_armor_chestplate"},
{"id":"goku_gt_armor_leggings","n":"Blue Master GI Leggings (&6Goku&r - GT)","fx":"armor","slot":"legs","armor":26,"tex":"goku_gt","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_goku_gt_armor_leggings"},
{"id":"goku_gt_armor_boots","n":"Blue Master GI Boots (&6Goku&r - GT)","fx":"armor","slot":"feet","armor":16,"tex":"goku_gt","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_goku_gt_armor_boots"},
{"id":"goku_kid_armor_chestplate","n":"Red Turtle Hermit School GI Chestplate (&6Goku&r - Kid)","fx":"armor","slot":"chest","armor":35,"tex":"goku_kid","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_goku_kid_armor_chestplate"},
{"id":"goku_kid_armor_leggings","n":"Red Turtle Hermit School GI Leggings (&6Goku&r - Kid)","fx":"armor","slot":"legs","armor":26,"tex":"goku_kid","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_goku_kid_armor_leggings"},
{"id":"goku_kid_armor_boots","n":"Red Turtle Hermit School GI Boots (&6Goku&r - Kid)","fx":"armor","slot":"feet","armor":16,"tex":"goku_kid","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_goku_kid_armor_boots"},
{"id":"goku_super_armor_chestplate","n":"Turtle Hermit School GI Chestplate (&6Goku&r - Super)","fx":"armor","slot":"chest","armor":35,"tex":"goku_super","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_goku_super_armor_chestplate"},
{"id":"goku_super_armor_leggings","n":"Turtle Hermit School GI Leggings (&6Goku&r - Super)","fx":"armor","slot":"legs","armor":26,"tex":"goku_super","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_goku_super_armor_leggings"},
{"id":"goku_super_armor_boots","n":"Turtle Hermit School GI Boots (&6Goku&r - Super)","fx":"armor","slot":"feet","armor":16,"tex":"goku_super","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_goku_super_armor_boots"},
{"id":"goku_whis_armor_chestplate","n":"Whis Symbol GI Chestplate (&eGoku&r)","fx":"armor","slot":"chest","armor":35,"tex":"gokuwhis","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_goku_whis_armor_chestplate"},
{"id":"goku_whis_armor_leggings","n":"Whis Symbol GI Leggings (&eGoku&r)","fx":"armor","slot":"legs","armor":26,"tex":"gokuwhis","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_goku_whis_armor_leggings"},
{"id":"goku_whis_armor_boots","n":"Whis Symbol GI Boots (&eGoku&r)","fx":"armor","slot":"feet","armor":16,"tex":"gokuwhis","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_goku_whis_armor_boots"},
{"id":"goten_armor_chestplate","n":"Turtle Hermit School GI Chestplate (&eGoten&r)","fx":"armor","slot":"chest","armor":35,"tex":"goten_gi","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_goten_armor_chestplate"},
{"id":"goten_armor_leggings","n":"Turtle Hermit School GI Leggings (&eGoten&r)","fx":"armor","slot":"legs","armor":26,"tex":"goten_gi","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_goten_armor_leggings"},
{"id":"goten_armor_boots","n":"Turtle Hermit School GI Boots (&eGoten&r)","fx":"armor","slot":"feet","armor":16,"tex":"goten_gi","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_goten_armor_boots"},
{"id":"goten_super_armor_chestplate","n":"Green Jacket Outfit (&eGoten&r - Super)","fx":"armor","slot":"chest","armor":35,"tex":"goten_dbs","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_goten_super_armor_chestplate"},
{"id":"goten_super_armor_leggings","n":"Green Jacket Outfit Leggings (&eGoten&r - Super)","fx":"armor","slot":"legs","armor":26,"tex":"goten_dbs","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_goten_super_armor_leggings"},
{"id":"goten_super_armor_boots","n":"Green Jacket Outfit Boots (&eGoten&r - Super)","fx":"armor","slot":"feet","armor":16,"tex":"goten_dbs","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_goten_super_armor_boots"},
{"id":"granola_armor_chestplate","n":"Cereal Armor Chestplate (&dGranolah&r)","fx":"armor","slot":"chest","armor":35,"tex":"granola","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_granola_armor_chestplate"},
{"id":"granola_armor_leggings","n":"Cereal Armor Leggings (&dGranolah&r)","fx":"armor","slot":"legs","armor":26,"tex":"granola","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_granola_armor_leggings"},
{"id":"granola_armor_boots","n":"Cereal Armor Boots (&dGranolah&r)","fx":"armor","slot":"feet","armor":16,"tex":"granola","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_granola_armor_boots"},
{"id":"great_saiyaman_2_armor_helmet","n":"Hero of Justice 2 Helmet (&6Great Saiyaman 2&r)","fx":"armor","slot":"head","armor":2,"tex":"great_saiyaman_2","stack":1,"durability":407,"m":"dmzpack:rpg/item/armors_great_saiyaman_2_armor_helmet"},
{"id":"great_saiyaman_2_armor_chestplate","n":"Hero of Justice 2 Chestplate (&6Great Saiyaman 2&r)","fx":"armor","slot":"chest","armor":35,"tex":"great_saiyaman_2","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_great_saiyaman_2_armor_chestplate"},
{"id":"great_saiyaman_2_armor_leggings","n":"Hero of Justice 2 Leggings (&6Great Saiyaman 2&r)","fx":"armor","slot":"legs","armor":26,"tex":"great_saiyaman_2","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_great_saiyaman_2_armor_leggings"},
{"id":"great_saiyaman_2_armor_boots","n":"Hero of Justice 2 Boots (&6Great Saiyaman 2&r)","fx":"armor","slot":"feet","armor":16,"tex":"great_saiyaman_2","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_great_saiyaman_2_armor_boots"},
{"id":"great_saiyaman_armor_helmet","n":"Hero of Justice Helmet (&6Great Saiyaman&r)","fx":"armor","slot":"head","armor":2,"tex":"saiyaman_gi","stack":1,"durability":407,"m":"dmzpack:rpg/item/armors_great_saiyaman_armor_helmet"},
{"id":"great_saiyaman_armor_chestplate","n":"Hero of Justice Chestplate (&6Great Saiyaman&r)","fx":"armor","slot":"chest","armor":35,"tex":"saiyaman_gi","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_great_saiyaman_armor_chestplate"},
{"id":"great_saiyaman_armor_leggings","n":"Hero of Justice Leggings (&6Great Saiyaman&r)","fx":"armor","slot":"legs","armor":26,"tex":"saiyaman_gi","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_great_saiyaman_armor_leggings"},
{"id":"great_saiyaman_armor_boots","n":"Hero of Justice Boots (&6Great Saiyaman&r)","fx":"armor","slot":"feet","armor":16,"tex":"saiyaman_gi","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_great_saiyaman_armor_boots"},
{"id":"hit_armor_chestplate","n":"Assassin Chestplate (&dHit&r)","fx":"armor","slot":"chest","armor":35,"tex":"hit","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_hit_armor_chestplate"},
{"id":"hit_armor_leggings","n":"Assassin Leggings (&dHit&r)","fx":"armor","slot":"legs","armor":26,"tex":"hit","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_hit_armor_leggings"},
{"id":"hit_armor_boots","n":"Assassin Boots (&dHit&r)","fx":"armor","slot":"feet","armor":16,"tex":"hit","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_hit_armor_boots"},
{"id":"invencible_armor_helmet","n":"Super Hero Armor Helmet (&eInv&binc&eib&7le&r)","fx":"armor","slot":"head","armor":2,"tex":"invencible","stack":1,"durability":407,"m":"dmzpack:rpg/item/armors_invencible_armor_helmet"},
{"id":"invencible_armor_chestplate","n":"Super Hero Armor Chestplate (&eInv&binc&eib&7le&r)","fx":"armor","slot":"chest","armor":35,"tex":"invencible","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_invencible_armor_chestplate"},
{"id":"invencible_armor_leggings","n":"Super Hero Armor Leggings (&eInv&binc&eib&7le&r)","fx":"armor","slot":"legs","armor":26,"tex":"invencible","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_invencible_armor_leggings"},
{"id":"invencible_armor_boots","n":"Super Hero Armor Boots (&eInv&binc&eib&7le&r)","fx":"armor","slot":"feet","armor":16,"tex":"invencible","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_invencible_armor_boots"},
{"id":"invencible_blue_armor_helmet","n":"Super Hero Armor Helmet (&9Invincible&r)","fx":"armor","slot":"head","armor":2,"tex":"invencible_blue","stack":1,"durability":407,"m":"dmzpack:rpg/item/armors_invencible_blue_armor_helmet"},
{"id":"invencible_blue_armor_chestplate","n":"Super Hero Armor Chestplate (&9Invincible&r)","fx":"armor","slot":"chest","armor":35,"tex":"invencible_blue","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_invencible_blue_armor_chestplate"},
{"id":"invencible_blue_armor_leggings","n":"Super Hero Armor Leggings (&9Invincible&r)","fx":"armor","slot":"legs","armor":26,"tex":"invencible_blue","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_invencible_blue_armor_leggings"},
{"id":"invencible_blue_armor_boots","n":"Super Hero Armor Boots (&9Invincible&r)","fx":"armor","slot":"feet","armor":16,"tex":"invencible_blue","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_invencible_blue_armor_boots"},
{"id":"kale_armor_chestplate","n":"Saiyan Armor Chestplate (&cKale&r)","fx":"armor","slot":"chest","armor":35,"tex":"kale","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_kale_armor_chestplate"},
{"id":"kale_armor_leggings","n":"Saiyan Armor Leggings (&cKale&r)","fx":"armor","slot":"legs","armor":26,"tex":"kale","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_kale_armor_leggings"},
{"id":"kale_armor_boots","n":"Saiyan Armor Boots (&cKale&r)","fx":"armor","slot":"feet","armor":16,"tex":"kale","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_kale_armor_boots"},
{"id":"kefla_armor_chestplate","n":"Saiyan Armor Chestplate (&dKefla&r)","fx":"armor","slot":"chest","armor":35,"tex":"kefla","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_kefla_armor_chestplate"},
{"id":"kefla_armor_leggings","n":"Saiyan Armor Leggings (&dKefla&r)","fx":"armor","slot":"legs","armor":26,"tex":"kefla","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_kefla_armor_leggings"},
{"id":"kefla_armor_boots","n":"Saiyan Armor Boots (&dKefla&r)","fx":"armor","slot":"feet","armor":16,"tex":"kefla","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_kefla_armor_boots"},
{"id":"kibito_armor_chestplate","n":"Kaioshin Chestplate (&dKibito&r)","fx":"armor","slot":"chest","armor":35,"tex":"kibito","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_kibito_armor_chestplate"},
{"id":"kibito_armor_leggings","n":"Kaioshin Leggings (&dKibito&r)","fx":"armor","slot":"legs","armor":26,"tex":"kibito","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_kibito_armor_leggings"},
{"id":"kibito_armor_boots","n":"Kaioshin Boots (&dKibito&r)","fx":"armor","slot":"feet","armor":16,"tex":"kibito","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_kibito_armor_boots"},
{"id":"king_vegeta_armor_chestplate","n":"Royal Armor Chestplate (&9King Vegeta&r)","fx":"armor","slot":"chest","armor":35,"tex":"king_vegeta","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_king_vegeta_armor_chestplate"},
{"id":"king_vegeta_armor_leggings","n":"Royal Armor Leggings (&9King Vegeta&r)","fx":"armor","slot":"legs","armor":26,"tex":"king_vegeta","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_king_vegeta_armor_leggings"},
{"id":"king_vegeta_armor_boots","n":"Royal Armor Boots (&9King Vegeta&r)","fx":"armor","slot":"feet","armor":16,"tex":"king_vegeta","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_king_vegeta_armor_boots"},
{"id":"majin21_armor_chestplate","n":"Android 21 Chestplate (&dMajin&r)","fx":"armor","slot":"chest","armor":35,"tex":"majin21","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_majin21_armor_chestplate"},
{"id":"majin21_armor_leggings","n":"Android 21 Leggings (&dMajin&r)","fx":"armor","slot":"legs","armor":26,"tex":"majin21","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_majin21_armor_leggings"},
{"id":"majin21_armor_boots","n":"Android 21 Boots (&dMajin&r)","fx":"armor","slot":"feet","armor":16,"tex":"majin21","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_majin21_armor_boots"},
{"id":"majin_buu_armor_chestplate","n":"Majin Chestplate (&5Buu&r)","fx":"armor","slot":"chest","armor":35,"tex":"majinbuu_gi","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_majin_buu_armor_chestplate"},
{"id":"majin_buu_armor_leggings","n":"Majin Leggings (&5Buu&r)","fx":"armor","slot":"legs","armor":26,"tex":"majinbuu_gi","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_majin_buu_armor_leggings"},
{"id":"majin_buu_armor_boots","n":"Majin Boots (&5Buu&r)","fx":"armor","slot":"feet","armor":16,"tex":"majinbuu_gi","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_majin_buu_armor_boots"},
{"id":"mighty_majin_armor_chestplate","n":"DBOnline Chestplate (&eMighty&r)","fx":"armor","slot":"chest","armor":35,"tex":"mighty_majin","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_mighty_majin_armor_chestplate"},
{"id":"mighty_majin_armor_leggings","n":"DBOnline Leggings (&eMighty&r)","fx":"armor","slot":"legs","armor":26,"tex":"mighty_majin","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_mighty_majin_armor_leggings"},
{"id":"mighty_majin_armor_boots","n":"DBOnline Boots (&eMighty&r)","fx":"armor","slot":"feet","armor":16,"tex":"mighty_majin","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_mighty_majin_armor_boots"},
{"id":"mystic_armor_chestplate","n":"DBOnline Chestplate (&3Mystic&r)","fx":"armor","slot":"chest","armor":35,"tex":"mystic","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_mystic_armor_chestplate"},
{"id":"mystic_armor_leggings","n":"DBOnline Leggings (&3Mystic&r)","fx":"armor","slot":"legs","armor":26,"tex":"mystic","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_mystic_armor_leggings"},
{"id":"mystic_armor_boots","n":"DBOnline Boots (&3Mystic&r)","fx":"armor","slot":"feet","armor":16,"tex":"mystic","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_mystic_armor_boots"},
{"id":"naruke_armor_chestplate","n":"Saiyan Armor Chestplate (&bnarukebaransu&r)","fx":"armor","slot":"chest","armor":35,"tex":"naruke","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_naruke_armor_chestplate"},
{"id":"naruke_armor_leggings","n":"Saiyan Armor Leggings (&bnarukebaransu&r)","fx":"armor","slot":"legs","armor":26,"tex":"naruke","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_naruke_armor_leggings"},
{"id":"naruke_armor_boots","n":"Saiyan Armor Boots (&bnarukebaransu&r)","fx":"armor","slot":"feet","armor":16,"tex":"naruke","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_naruke_armor_boots"},
{"id":"orange_high_armor_chestplate","n":"Orange Star High School Chestplate","fx":"armor","slot":"chest","armor":35,"tex":"orange_high","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_orange_high_armor_chestplate"},
{"id":"orange_high_armor_leggings","n":"Orange Star High School Leggings","fx":"armor","slot":"legs","armor":26,"tex":"orange_high","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_orange_high_armor_leggings"},
{"id":"orange_high_armor_boots","n":"Orange Star High School Boots","fx":"armor","slot":"feet","armor":16,"tex":"orange_high","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_orange_high_armor_boots"},
{"id":"piccolo_armor_helmet","n":"Demon GI Turban (&5Piccolo&r)","fx":"armor","slot":"head","armor":2,"tex":"piccolo_gi","stack":1,"durability":407,"m":"dmzpack:rpg/item/armors_piccolo_armor_helmet"},
{"id":"piccolo_armor_chestplate","n":"Demon GI Chestplate (&5Piccolo&r)","fx":"armor","slot":"chest","armor":35,"tex":"piccolo_gi","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_piccolo_armor_chestplate"},
{"id":"piccolo_armor_leggings","n":"Demon GI Leggings (&5Piccolo&r)","fx":"armor","slot":"legs","armor":26,"tex":"piccolo_gi","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_piccolo_armor_leggings"},
{"id":"piccolo_armor_boots","n":"Demon GI Boots (&5Piccolo&r)","fx":"armor","slot":"feet","armor":16,"tex":"piccolo_gi","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_piccolo_armor_boots"},
{"id":"pride_troops_armor_chestplate","n":"Pride Trooper Chestplate (&5U11&r)","fx":"armor","slot":"chest","armor":35,"tex":"pride_troper","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_pride_troops_armor_chestplate"},
{"id":"pride_troops_armor_leggings","n":"Pride Trooper Leggings (&5U11&r)","fx":"armor","slot":"legs","armor":26,"tex":"pride_troper","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_pride_troops_armor_leggings"},
{"id":"pride_troops_armor_boots","n":"Pride Trooper Boots (&5U11&r)","fx":"armor","slot":"feet","armor":16,"tex":"pride_troper","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_pride_troops_armor_boots"},
{"id":"raditz_armor_chestplate","n":"Saiyan Armor Chestplate (&cRaditz&r)","fx":"armor","slot":"chest","armor":35,"tex":"raditz","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_raditz_armor_chestplate"},
{"id":"raditz_armor_leggings","n":"Saiyan Armor Leggings (&cRaditz&r)","fx":"armor","slot":"legs","armor":26,"tex":"raditz","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_raditz_armor_leggings"},
{"id":"raditz_armor_boots","n":"Saiyan Armor Boots (&cRaditz&r)","fx":"armor","slot":"feet","armor":16,"tex":"raditz","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_raditz_armor_boots"},
{"id":"shin_armor_chestplate","n":"Kaioshin Chestplate (&dShin&r)","fx":"armor","slot":"chest","armor":35,"tex":"kaioshin","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_shin_armor_chestplate"},
{"id":"shin_armor_leggings","n":"Kaioshin Leggings (&dShin&r)","fx":"armor","slot":"legs","armor":26,"tex":"kaioshin","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_shin_armor_leggings"},
{"id":"shin_armor_boots","n":"Kaioshin Boots (&dShin&r)","fx":"armor","slot":"feet","armor":16,"tex":"kaioshin","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_shin_armor_boots"},
{"id":"slug_armor_helmet","n":"Evil Namekian Helmet (&2Slug&r)","fx":"armor","slot":"head","armor":2,"tex":"slug","stack":1,"durability":407,"m":"dmzpack:rpg/item/armors_slug_armor_helmet"},
{"id":"slug_armor_chestplate","n":"Evil Namekian Chestplate (&2Slug&r)","fx":"armor","slot":"chest","armor":35,"tex":"slug","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_slug_armor_chestplate"},
{"id":"slug_armor_leggings","n":"Evil Namekian Leggings (&2Slug&r)","fx":"armor","slot":"legs","armor":26,"tex":"slug","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_slug_armor_leggings"},
{"id":"slug_armor_boots","n":"Evil Namekian Boots (&2Slug&r)","fx":"armor","slot":"feet","armor":16,"tex":"slug","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_slug_armor_boots"},
{"id":"strongest_armor_chestplate","n":"The Strongest Chestplate (&bGojo&r)","fx":"armor","slot":"chest","armor":35,"tex":"strongest","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_strongest_armor_chestplate"},
{"id":"strongest_armor_leggings","n":"The Strongest Leggings (&bGojo&r)","fx":"armor","slot":"legs","armor":26,"tex":"strongest","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_strongest_armor_leggings"},
{"id":"strongest_armor_boots","n":"The Strongest Boots (&bGojo&r)","fx":"armor","slot":"feet","armor":16,"tex":"strongest","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_strongest_armor_boots"},
{"id":"subaru_natsuki_arc6_armor_chestplate","n":"Subaru Natsuki Chestplate (&dArc 6&r)","fx":"armor","slot":"chest","armor":35,"tex":"subaru_natsuki_arc6","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_subaru_natsuki_arc6_armor_chestplate"},
{"id":"subaru_natsuki_arc6_armor_leggings","n":"Subaru Natsuki Leggings (&dArc 6&r)","fx":"armor","slot":"legs","armor":26,"tex":"subaru_natsuki_arc6","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_subaru_natsuki_arc6_armor_leggings"},
{"id":"subaru_natsuki_arc6_armor_boots","n":"Subaru Natsuki Boots (&dArc 6&r)","fx":"armor","slot":"feet","armor":16,"tex":"subaru_natsuki_arc6","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_subaru_natsuki_arc6_armor_boots"},
{"id":"subaru_natsuki_armor_chestplate","n":"Subaru Natsuki Chestplate (&bCasual&r)","fx":"armor","slot":"chest","armor":35,"tex":"subaru_natsuki","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_subaru_natsuki_armor_chestplate"},
{"id":"subaru_natsuki_armor_leggings","n":"Subaru Natsuki Leggings (&bCasual&r)","fx":"armor","slot":"legs","armor":26,"tex":"subaru_natsuki","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_subaru_natsuki_armor_leggings"},
{"id":"subaru_natsuki_armor_boots","n":"Subaru Natsuki Boots (&bCasual&r)","fx":"armor","slot":"feet","armor":16,"tex":"subaru_natsuki","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_subaru_natsuki_armor_boots"},
{"id":"super_buu_armor_chestplate","n":"Majin Chestplate (&5Super Buu&r)","fx":"armor","slot":"chest","armor":35,"tex":"super_buu","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_super_buu_armor_chestplate"},
{"id":"super_buu_armor_leggings","n":"Majin Leggings (&5Super Buu&r)","fx":"armor","slot":"legs","armor":26,"tex":"super_buu","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_super_buu_armor_leggings"},
{"id":"super_buu_armor_boots","n":"Majin Boots (&5Super Buu&r)","fx":"armor","slot":"feet","armor":16,"tex":"super_buu","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_super_buu_armor_boots"},
{"id":"thragg_armor_chestplate","n":"Viltrumite Chestplate (&4Thragg&r)","fx":"armor","slot":"chest","armor":35,"tex":"thragg","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_thragg_armor_chestplate"},
{"id":"thragg_armor_leggings","n":"Viltrumite Leggings (&4Thragg&r)","fx":"armor","slot":"legs","armor":26,"tex":"thragg","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_thragg_armor_leggings"},
{"id":"thragg_armor_boots","n":"Viltrumite Boots (&4Thragg&r)","fx":"armor","slot":"feet","armor":16,"tex":"thragg","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_thragg_armor_boots"},
{"id":"gilgamesh_armor_chestplate","n":"King of Heroes Chestplate (&6Gilgamesh&r)","fx":"armor","slot":"chest","armor":35,"tex":"gilgamesh","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_gilgamesh_armor_chestplate"},
{"id":"gilgamesh_armor_leggings","n":"King of Heroes Leggings (&6Gilgamesh&r)","fx":"armor","slot":"legs","armor":26,"tex":"gilgamesh","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_gilgamesh_armor_leggings"},
{"id":"gilgamesh_armor_boots","n":"King of Heroes Boots (&6Gilgamesh&r)","fx":"armor","slot":"feet","armor":16,"tex":"gilgamesh","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_gilgamesh_armor_boots"},
{"id":"scarletblaze_armor_chestplate","n":"Scarlet Blaze Chestplate (&4Scarlet Blaze&r)","fx":"armor","slot":"chest","armor":35,"tex":"scarletblaze","stack":1,"durability":592,"icon":"chestplate"},
{"id":"scarletblaze_armor_leggings","n":"Scarlet Blaze Leggings (&4Scarlet Blaze&r)","fx":"armor","slot":"legs","armor":26,"tex":"scarletblaze","stack":1,"durability":555,"icon":"leggings"},
{"id":"scarletblaze_armor_boots","n":"Scarlet Blaze Boots (&4Scarlet Blaze&r)","fx":"armor","slot":"feet","armor":16,"tex":"scarletblaze","stack":1,"durability":481,"icon":"boots"},
{"id":"taiyou_gi_armor_chestplate","n":"Taiyou Gi Chestplate","fx":"armor","slot":"chest","armor":35,"tex":"taiyou_gi","stack":1,"durability":592,"icon":"chestplate"},
{"id":"taiyou_gi_armor_leggings","n":"Taiyou Gi Leggings","fx":"armor","slot":"legs","armor":26,"tex":"taiyou_gi","stack":1,"durability":555,"icon":"leggings"},
{"id":"taiyou_gi_armor_boots","n":"Taiyou Gi Boots","fx":"armor","slot":"feet","armor":16,"tex":"taiyou_gi","stack":1,"durability":481,"icon":"boots"},
{"id":"tien_armor_chestplate","n":"Crane School GI Chestplate (&2Tien&r)","fx":"armor","slot":"chest","armor":35,"tex":"tenshinhan_armor","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_tien_armor_chestplate"},
{"id":"tien_armor_leggings","n":"Crane School GI Leggings (&2Tien&r)","fx":"armor","slot":"legs","armor":26,"tex":"tenshinhan_armor","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_tien_armor_leggings"},
{"id":"tien_armor_boots","n":"Crane School GI Boots (&2Tien&r)","fx":"armor","slot":"feet","armor":16,"tex":"tenshinhan_armor","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_tien_armor_boots"},
{"id":"trunks_kid_armor_chestplate","n":"Green GI Chestplate (&dTrunks&r - Kid)","fx":"armor","slot":"chest","armor":35,"tex":"trunks_gi","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_trunks_kid_armor_chestplate"},
{"id":"trunks_kid_armor_leggings","n":"Green GI Leggings (&dTrunks&r - Kid)","fx":"armor","slot":"legs","armor":26,"tex":"trunks_gi","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_trunks_kid_armor_leggings"},
{"id":"trunks_kid_armor_boots","n":"Green GI Boots (&dTrunks&r - Kid)","fx":"armor","slot":"feet","armor":16,"tex":"trunks_gi","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_trunks_kid_armor_boots"},
{"id":"trunks_super_armor_chestplate","n":"Capsule Corp Jacket Chestplate (&dTrunks&r - Super)","fx":"armor","slot":"chest","armor":35,"tex":"trunks_dbs","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_trunks_super_armor_chestplate"},
{"id":"trunks_super_armor_leggings","n":"Capsule Corp Jacket Leggings (&dTrunks&r - Super)","fx":"armor","slot":"legs","armor":26,"tex":"trunks_dbs","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_trunks_super_armor_leggings"},
{"id":"trunks_super_armor_boots","n":"Capsule Corp Jacket Boots (&dTrunks&r - Super)","fx":"armor","slot":"feet","armor":16,"tex":"trunks_dbs","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_trunks_super_armor_boots"},
{"id":"trunks_z_armor_chestplate","n":"Capsule Corp Jacket Chestplate (&dTrunks&r - DBZ)","fx":"armor","slot":"chest","armor":35,"tex":"trunks_armor","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_trunks_z_armor_chestplate"},
{"id":"trunks_z_armor_leggings","n":"Capsule Corp Jacket Leggings (&dTrunks&r - DBZ)","fx":"armor","slot":"legs","armor":26,"tex":"trunks_armor","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_trunks_z_armor_leggings"},
{"id":"trunks_z_armor_boots","n":"Capsule Corp Jacket Boots (&dTrunks&r - DBZ)","fx":"armor","slot":"feet","armor":16,"tex":"trunks_armor","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_trunks_z_armor_boots"},
{"id":"trunks_xeno_armor_chestplate","n":"Time Patrol Chestplate (&dTrunks Xeno&r)","fx":"armor","slot":"chest","armor":35,"tex":"trunks_xeno","stack":1,"durability":592,"icon":"chestplate"},
{"id":"trunks_xeno_armor_leggings","n":"Time Patrol Leggings (&dTrunks Xeno&r)","fx":"armor","slot":"legs","armor":26,"tex":"trunks_xeno","stack":1,"durability":555,"icon":"leggings"},
{"id":"trunks_xeno_armor_boots","n":"Time Patrol Boots (&dTrunks Xeno&r)","fx":"armor","slot":"feet","armor":16,"tex":"trunks_xeno","stack":1,"durability":481,"icon":"boots"},
{"id":"turles_armor_chestplate","n":"Saiyan Armor Chestplate (&5Turles&r)","fx":"armor","slot":"chest","armor":35,"tex":"turles_armor","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_turles_armor_chestplate"},
{"id":"turles_armor_leggings","n":"Saiyan Armor Leggings (&5Turles&r)","fx":"armor","slot":"legs","armor":26,"tex":"turles_armor","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_turles_armor_leggings"},
{"id":"turles_armor_boots","n":"Saiyan Armor Boots (&5Turles&r)","fx":"armor","slot":"feet","armor":16,"tex":"turles_armor","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_turles_armor_boots"},
{"id":"vegeta_buu_armor_chestplate","n":"Blue Training Outfit (&bVegeta&r - Buu)","fx":"armor","slot":"chest","armor":35,"tex":"vegetabuu","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_vegeta_buu_armor_chestplate"},
{"id":"vegeta_buu_armor_leggings","n":"Blue Training Outfit Leggings (&bVegeta&r - Buu)","fx":"armor","slot":"legs","armor":26,"tex":"vegetabuu","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_vegeta_buu_armor_leggings"},
{"id":"vegeta_buu_armor_boots","n":"Blue Training Outfit Boots (&bVegeta&r - Buu)","fx":"armor","slot":"feet","armor":16,"tex":"vegetabuu","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_vegeta_buu_armor_boots"},
{"id":"vegeta_gt_armor_chestplate","n":"Vegeta Chestplate (&9GT&r)","fx":"armor","slot":"chest","armor":35,"tex":"vegetagt","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_vegeta_gt_armor_chestplate"},
{"id":"vegeta_gt_armor_leggings","n":"Vegeta Leggings (&9GT&r)","fx":"armor","slot":"legs","armor":26,"tex":"vegetagt","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_vegeta_gt_armor_leggings"},
{"id":"vegeta_gt_armor_boots","n":"Vegeta Boots (&9GT&r)","fx":"armor","slot":"feet","armor":16,"tex":"vegetagt","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_vegeta_gt_armor_boots"},
{"id":"vegeta_namek_armor_chestplate","n":"Saiyan Armor Chestplate (&bVegeta&r - Namek)","fx":"armor","slot":"chest","armor":35,"tex":"vegetanamek_armor","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_vegeta_namek_armor_chestplate"},
{"id":"vegeta_namek_armor_leggings","n":"Saiyan Armor Leggings (&bVegeta&r - Namek)","fx":"armor","slot":"legs","armor":26,"tex":"vegetanamek_armor","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_vegeta_namek_armor_leggings"},
{"id":"vegeta_namek_armor_boots","n":"Saiyan Armor Boots (&bVegeta&r - Namek)","fx":"armor","slot":"feet","armor":16,"tex":"vegetanamek_armor","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_vegeta_namek_armor_boots"},
{"id":"vegeta_saiyan_armor_chestplate","n":"Saiyan Armor Chestplate (&bVegeta&r - Saiyan)","fx":"armor","slot":"chest","armor":35,"tex":"vegeta_saiyan_armor","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_vegeta_saiyan_armor_chestplate"},
{"id":"vegeta_saiyan_armor_leggings","n":"Saiyan Armor Leggings (&bVegeta&r - Saiyan)","fx":"armor","slot":"legs","armor":26,"tex":"vegeta_saiyan_armor","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_vegeta_saiyan_armor_leggings"},
{"id":"vegeta_saiyan_armor_boots","n":"Saiyan Armor Boots (&bVegeta&r - Saiyan)","fx":"armor","slot":"feet","armor":16,"tex":"vegeta_saiyan_armor","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_vegeta_saiyan_armor_boots"},
{"id":"vegeta_super_armor_chestplate","n":"Saiyan Armor Chestplate (&bVegeta&r - Super)","fx":"armor","slot":"chest","armor":35,"tex":"vegetasuper","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_vegeta_super_armor_chestplate"},
{"id":"vegeta_super_armor_leggings","n":"Saiyan Armor Leggings (&bVegeta&r - Super)","fx":"armor","slot":"legs","armor":26,"tex":"vegetasuper","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_vegeta_super_armor_leggings"},
{"id":"vegeta_super_armor_boots","n":"Saiyan Armor Boots (&bVegeta&r - Super)","fx":"armor","slot":"feet","armor":16,"tex":"vegetasuper","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_vegeta_super_armor_boots"},
{"id":"vegeta_whis_armor_chestplate","n":"Whis Symbol GI Chestplate (&9Vegeta&r)","fx":"armor","slot":"chest","armor":35,"tex":"vegetawhis","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_vegeta_whis_armor_chestplate"},
{"id":"vegeta_whis_armor_leggings","n":"Whis Symbol GI Leggings (&9Vegeta&r)","fx":"armor","slot":"legs","armor":26,"tex":"vegetawhis","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_vegeta_whis_armor_leggings"},
{"id":"vegeta_whis_armor_boots","n":"Whis Symbol GI Boots (&9Vegeta&r)","fx":"armor","slot":"feet","armor":16,"tex":"vegetawhis","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_vegeta_whis_armor_boots"},
{"id":"vegeta_z_armor_chestplate","n":"Saiyan Armor Chestplate (&bVegeta&r - Cell)","fx":"armor","slot":"chest","armor":35,"tex":"vegetaz_armor","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_vegeta_z_armor_chestplate"},
{"id":"vegeta_z_armor_leggings","n":"Saiyan Armor Leggings (&bVegeta&r - Cell)","fx":"armor","slot":"legs","armor":26,"tex":"vegetaz_armor","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_vegeta_z_armor_leggings"},
{"id":"vegeta_z_armor_boots","n":"Saiyan Armor Boots (&bVegeta&r - Cell)","fx":"armor","slot":"feet","armor":16,"tex":"vegetaz_armor","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_vegeta_z_armor_boots"},
{"id":"vegetto_armor_chestplate","n":"Inverted Turtle Hermit School GI Chestplate (&bVegito&r)","fx":"armor","slot":"chest","armor":35,"tex":"vegetto","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_vegetto_armor_chestplate"},
{"id":"vegetto_armor_leggings","n":"Inverted Turtle Hermit School GI Leggings (&bVegito&r)","fx":"armor","slot":"legs","armor":26,"tex":"vegetto","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_vegetto_armor_leggings"},
{"id":"vegetto_armor_boots","n":"Inverted Turtle Hermit School GI Boots (&bVegito&r)","fx":"armor","slot":"feet","armor":16,"tex":"vegetto","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_vegetto_armor_boots"},
{"id":"vergil_armor_chestplate","n":"The Alpha and the Omega Chestplate (&9Vergil&r)","fx":"armor","slot":"chest","armor":35,"tex":"vergil","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_vergil_armor_chestplate"},
{"id":"vergil_armor_leggings","n":"The Alpha and the Omega Leggings (&9Vergil&r)","fx":"armor","slot":"legs","armor":26,"tex":"vergil","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_vergil_armor_leggings"},
{"id":"vergil_armor_boots","n":"The Alpha and the Omega Boots (&9Vergil&r)","fx":"armor","slot":"feet","armor":16,"tex":"vergil","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_vergil_armor_boots"},
{"id":"videl_armor_chestplate","n":"Videl Chestplate","fx":"armor","slot":"chest","armor":35,"tex":"videl","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_videl_armor_chestplate"},
{"id":"videl_armor_leggings","n":"Videl Leggings","fx":"armor","slot":"legs","armor":26,"tex":"videl","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_videl_armor_leggings"},
{"id":"videl_armor_boots","n":"Videl Boots","fx":"armor","slot":"feet","armor":16,"tex":"videl","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_videl_armor_boots"},
{"id":"warrior_clan_armor_chestplate","n":"DBOnline Chestplate (&5Warrior&r)","fx":"armor","slot":"chest","armor":35,"tex":"warrior_clan","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_warrior_clan_armor_chestplate"},
{"id":"warrior_clan_armor_leggings","n":"DBOnline Leggings (&5Warrior&r)","fx":"armor","slot":"legs","armor":26,"tex":"warrior_clan","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_warrior_clan_armor_leggings"},
{"id":"warrior_clan_armor_boots","n":"DBOnline Boots (&5Warrior&r)","fx":"armor","slot":"feet","armor":16,"tex":"warrior_clan","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_warrior_clan_armor_boots"},
{"id":"whis_armor_chestplate","n":"Angel Chestplate (&dWhis&r)","fx":"armor","slot":"chest","armor":35,"tex":"whis","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_whis_armor_chestplate"},
{"id":"whis_armor_leggings","n":"Angel Leggings (&dWhis&r)","fx":"armor","slot":"legs","armor":26,"tex":"whis","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_whis_armor_leggings"},
{"id":"whis_armor_boots","n":"Angel Boots (&dWhis&r)","fx":"armor","slot":"feet","armor":16,"tex":"whis","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_whis_armor_boots"},
{"id":"wonder_majin_armor_chestplate","n":"DBOnline Chestplate (&eWonder&r)","fx":"armor","slot":"chest","armor":35,"tex":"wonder_majin","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_wonder_majin_armor_chestplate"},
{"id":"wonder_majin_armor_leggings","n":"DBOnline Leggings (&eWonder&r)","fx":"armor","slot":"legs","armor":26,"tex":"wonder_majin","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_wonder_majin_armor_leggings"},
{"id":"wonder_majin_armor_boots","n":"DBOnline Boots (&eWonder&r)","fx":"armor","slot":"feet","armor":16,"tex":"wonder_majin","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_wonder_majin_armor_boots"},
{"id":"xeno_goku_armor_chestplate","n":"Time Patrol Chestplate (&6Goku Xeno&r)","fx":"armor","slot":"chest","armor":35,"tex":"xeno_goku","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_xeno_goku_armor_chestplate"},
{"id":"xeno_goku_armor_leggings","n":"Time Patrol Leggings (&6Goku Xeno&r)","fx":"armor","slot":"legs","armor":26,"tex":"xeno_goku","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_xeno_goku_armor_leggings"},
{"id":"xeno_goku_armor_boots","n":"Time Patrol Boots (&6Goku Xeno&r)","fx":"armor","slot":"feet","armor":16,"tex":"xeno_goku","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_xeno_goku_armor_boots"},
{"id":"xeno_goku_patreon_armor_chestplate","n":"Time Patrol Chestplate (&7Goku Xeno Alternative&r)","fx":"armor","slot":"chest","armor":35,"tex":"xeno_goku_patreon","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_xeno_goku_patreon_armor_chestplate"},
{"id":"xeno_goku_patreon_armor_leggings","n":"Time Patrol Leggings (&7Goku Xeno Alternative&r)","fx":"armor","slot":"legs","armor":26,"tex":"xeno_goku_patreon","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_xeno_goku_patreon_armor_leggings"},
{"id":"xeno_goku_patreon_armor_boots","n":"Time Patrol Boots (&7Goku Xeno Alternative&r)","fx":"armor","slot":"feet","armor":16,"tex":"xeno_goku_patreon","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_xeno_goku_patreon_armor_boots"},
{"id":"yardrat_armor_chestplate","n":"Yardrat Outfit Chestplate (&6Goku&r)","fx":"armor","slot":"chest","armor":35,"tex":"yardrat_gi","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_yardrat_armor_chestplate"},
{"id":"yardrat_armor_leggings","n":"Yardrat Outfit Leggings (&6Goku&r)","fx":"armor","slot":"legs","armor":26,"tex":"yardrat_gi","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_yardrat_armor_leggings"},
{"id":"yardrat_armor_boots","n":"Yardrat Outfit Boots (&6Goku&r)","fx":"armor","slot":"feet","armor":16,"tex":"yardrat_gi","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_yardrat_armor_boots"},
{"id":"zamasu_armor_chestplate","n":"Kaioshin Chestplate (&dZamasu&r)","fx":"armor","slot":"chest","armor":35,"tex":"zamasu_gi","stack":1,"durability":592,"m":"dmzpack:rpg/item/armors_zamasu_armor_chestplate"},
{"id":"zamasu_armor_leggings","n":"Kaioshin Leggings (&dZamasu&r)","fx":"armor","slot":"legs","armor":26,"tex":"zamasu_gi","stack":1,"durability":555,"m":"dmzpack:rpg/item/armors_zamasu_armor_leggings"},
{"id":"zamasu_armor_boots","n":"Kaioshin Boots (&dZamasu&r)","fx":"armor","slot":"feet","armor":16,"tex":"zamasu_gi","stack":1,"durability":481,"m":"dmzpack:rpg/item/armors_zamasu_armor_boots"}
];
var DMZ_ARMOR_SETS = [{"id":"a13_armor","helmet":false,"pattern":"pattern_a13"},{"id":"a14_armor","helmet":false,"pattern":"pattern_a14"},{"id":"a16_armor","helmet":false,"pattern":"pattern_a16"},{"id":"a17_armor","helmet":false,"pattern":"pattern_a17"},{"id":"a17_super_armor","helmet":false,"pattern":"pattern_a17_super"},{"id":"a18_armor","helmet":false,"pattern":"pattern_a18"},{"id":"a18_cell_armor","helmet":false,"pattern":"pattern_a18_cell"},{"id":"a18_kame_armor","helmet":false,"pattern":"pattern_a18_kame"},{"id":"a18_tournament_armor","helmet":false,"pattern":"pattern_a18_tournament"},{"id":"a20_armor","helmet":true,"pattern":"pattern_a20"},{"id":"age1000_armor","helmet":false,"pattern":"pattern_age1000"},{"id":"bardock_dbz_armor","helmet":false,"pattern":"pattern_bardock1"},{"id":"bardock_super_armor","helmet":false,"pattern":"pattern_bardock2"},{"id":"beerus_armor","helmet":false,"pattern":"pattern_beerus"},{"id":"blackgoku_armor","helmet":false,"pattern":"pattern_black"},{"id":"broly_super_armor","helmet":false,"pattern":"pattern_broly_super"},{"id":"broly_z_armor","helmet":true,"pattern":"pattern_broly_z"},{"id":"brightlys_regular_wear_armor","helmet":false,"pattern":null},{"id":"capsule_corp_armor","helmet":false,"pattern":"pattern_capsule_corp"},{"id":"caulifla_armor","helmet":false,"pattern":"pattern_caulifla"},{"id":"chaoz_armor","helmet":true,"pattern":"pattern_chaoz"},{"id":"cooler_soldier_armor","helmet":false,"pattern":"pattern_cooler_soldier"},{"id":"demon_gi_blue_armor","helmet":false,"pattern":"pattern_gohan1"},{"id":"dragon_clan_armor","helmet":false,"pattern":"pattern_dragon_clan"},{"id":"evil_buu_armor","helmet":false,"pattern":"pattern_evil_buu"},{"id":"fighter_armor","helmet":false,"pattern":"pattern_fighter"},{"id":"fusion_zamasu_armor","helmet":false,"pattern":"pattern_fusionzamasu"},{"id":"future_gohan_armor","helmet":false,"pattern":"pattern_future_gohan"},{"id":"gamma1_armor","helmet":false,"pattern":"pattern_gamma1"},{"id":"gamma2_armor","helmet":false,"pattern":"pattern_gamma2"},{"id":"gas_armor","helmet":false,"pattern":"pattern_gas"},{"id":"gero_armor","helmet":false,"pattern":"pattern_gero"},{"id":"gine_armor","helmet":false,"pattern":"pattern_gine"},{"id":"gogeta_armor","helmet":false,"pattern":"pattern_gogeta"},{"id":"gohan_super_armor","helmet":false,"pattern":"pattern_gohan_super"},{"id":"goku_armor","helmet":false,"pattern":"pattern_goku1"},{"id":"goku_gt_armor","helmet":false,"pattern":"pattern_goku_gt"},{"id":"goku_kid_armor","helmet":false,"pattern":"pattern_goku_kid"},{"id":"goku_super_armor","helmet":false,"pattern":"pattern_goku_super"},{"id":"goku_whis_armor","helmet":false,"pattern":"pattern_goku_whis"},{"id":"goten_armor","helmet":false,"pattern":"pattern_goten"},{"id":"goten_super_armor","helmet":false,"pattern":"pattern_goten_super"},{"id":"granola_armor","helmet":false,"pattern":"pattern_granola"},{"id":"great_saiyaman_2_armor","helmet":true,"pattern":"pattern_great_saiyaman_2"},{"id":"great_saiyaman_armor","helmet":true,"pattern":"pattern_great_saiyaman"},{"id":"hit_armor","helmet":false,"pattern":"pattern_hit"},{"id":"invencible_armor","helmet":true,"pattern":null},{"id":"invencible_blue_armor","helmet":true,"pattern":null},{"id":"kale_armor","helmet":false,"pattern":"pattern_kale"},{"id":"kefla_armor","helmet":false,"pattern":"pattern_kefla"},{"id":"kibito_armor","helmet":false,"pattern":"pattern_kibito"},{"id":"king_vegeta_armor","helmet":false,"pattern":"pattern_king_vegeta"},{"id":"majin21_armor","helmet":false,"pattern":"pattern_majin21"},{"id":"majin_buu_armor","helmet":false,"pattern":"pattern_majin_buu"},{"id":"mighty_majin_armor","helmet":false,"pattern":"pattern_mighty_majin"},{"id":"mystic_armor","helmet":false,"pattern":"pattern_mystic"},{"id":"naruke_armor","helmet":false,"pattern":null},{"id":"orange_high_armor","helmet":false,"pattern":"pattern_orange_high"},{"id":"piccolo_armor","helmet":true,"pattern":"pattern_piccolo"},{"id":"pride_troops_armor","helmet":false,"pattern":"pattern_pride_troops"},{"id":"raditz_armor","helmet":false,"pattern":"pattern_raditz"},{"id":"shin_armor","helmet":false,"pattern":"pattern_shin"},{"id":"slug_armor","helmet":true,"pattern":"pattern_slug"},{"id":"strongest_armor","helmet":false,"pattern":null},{"id":"subaru_natsuki_arc6_armor","helmet":false,"pattern":null},{"id":"subaru_natsuki_armor","helmet":false,"pattern":null},{"id":"super_buu_armor","helmet":false,"pattern":"pattern_super_buu"},{"id":"thragg_armor","helmet":false,"pattern":null},{"id":"gilgamesh_armor","helmet":false,"pattern":null},{"id":"scarletblaze_armor","helmet":false,"pattern":null},{"id":"taiyou_gi_armor","helmet":false,"pattern":null},{"id":"tien_armor","helmet":false,"pattern":"pattern_tien"},{"id":"trunks_kid_armor","helmet":false,"pattern":"pattern_trunks_kid"},{"id":"trunks_super_armor","helmet":false,"pattern":"pattern_trunks_super"},{"id":"trunks_z_armor","helmet":false,"pattern":"pattern_trunks_z"},{"id":"trunks_xeno_armor","helmet":false,"pattern":null},{"id":"turles_armor","helmet":false,"pattern":"pattern_turles"},{"id":"vegeta_buu_armor","helmet":false,"pattern":"pattern_vegeta_buu"},{"id":"vegeta_gt_armor","helmet":false,"pattern":"pattern_vegeta_gt"},{"id":"vegeta_namek_armor","helmet":false,"pattern":"pattern_vegeta2"},{"id":"vegeta_saiyan_armor","helmet":false,"pattern":"pattern_vegeta1"},{"id":"vegeta_super_armor","helmet":false,"pattern":"pattern_vegeta_super"},{"id":"vegeta_whis_armor","helmet":false,"pattern":"pattern_vegeta_whis"},{"id":"vegeta_z_armor","helmet":false,"pattern":"pattern_vegeta_z"},{"id":"vegetto_armor","helmet":false,"pattern":"pattern_vegetto"},{"id":"vergil_armor","helmet":false,"pattern":"pattern_vergil"},{"id":"videl_armor","helmet":false,"pattern":"pattern_videl"},{"id":"warrior_clan_armor","helmet":false,"pattern":"pattern_warrior_clan"},{"id":"whis_armor","helmet":false,"pattern":"pattern_whis"},{"id":"wonder_majin_armor","helmet":false,"pattern":"pattern_wonder_majin"},{"id":"xeno_goku_armor","helmet":false,"pattern":"pattern_xeno_goku"},{"id":"xeno_goku_patreon_armor","helmet":false,"pattern":"pattern_xeno_goku_patreon"},{"id":"yardrat_armor","helmet":false,"pattern":"pattern_yardrat"},{"id":"zamasu_armor","helmet":false,"pattern":"pattern_zamasu"}];
var DMZ_PATTERN_GRIDS = {"pattern_goku_kid":{"blank":"blank_pattern_z","dyes":{"R":20,"K":6,"Y":1,"B":4}},"pattern_goku1":{"blank":"blank_pattern_z","dyes":{"O":17,"B":14}},"pattern_goku_super":{"blank":"blank_pattern_super","dyes":{"O":16,"A":14,"W":1}},"pattern_goku_gt":{"blank":"blank_pattern_z","dyes":{"B":21,"A":4,"M":2,"S":4}},"pattern_goku_whis":{"blank":"blank_pattern_super","dyes":{"O":16,"B":14,"W":1}},"pattern_yardrat":{"blank":"blank_pattern_z","dyes":{"W":8,"Y":8,"B":13,"N":2}},"pattern_goten":{"blank":"blank_pattern_z","dyes":{"O":17,"K":6,"B":8}},"pattern_goten_super":{"blank":"blank_pattern_super","dyes":{"L":15,"E":12,"S":4}},"pattern_gohan1":{"blank":"blank_pattern_z","dyes":{"U":21,"K":6,"B":4}},"pattern_gohan_super":{"blank":"blank_pattern_super","dyes":{"U":19,"K":6,"G":2,"R":4}},"pattern_future_gohan":{"blank":"blank_pattern_z","dyes":{"O":17,"B":12}},"pattern_trunks_kid":{"blank":"blank_pattern_z","dyes":{"C":19,"K":10,"O":2}},"pattern_tien":{"blank":"blank_pattern_z","dyes":{"E":10,"R":10}},"pattern_vegetto":{"blank":"blank_pattern_z","dyes":{"B":20,"A":2,"O":7}},"pattern_vegeta_buu":{"blank":"blank_pattern_z","dyes":{"B":21,"K":8}},"pattern_black":{"blank":"blank_pattern_super","dyes":{"G":17,"K":10,"R":4}},"pattern_vegeta1":{"blank":"blank_pattern_z","dyes":{"Y":5,"O":4,"W":9,"B":10,"S":2,"N":3}},"pattern_vegeta2":{"blank":"blank_pattern_z","dyes":{"W":11,"S":4,"B":12,"N":3,"Y":1,"K":2}},"pattern_vegeta_z":{"blank":"blank_pattern_z","dyes":{"N":5,"O":2,"B":8,"W":9,"A":4,"S":2,"Y":1,"K":2}},"pattern_vegeta_super":{"blank":"blank_pattern_super","dyes":{"Y":3,"S":4,"C":8,"W":9,"B":2,"N":3,"K":4}},"pattern_vegeta_whis":{"blank":"blank_pattern_super","dyes":{"Y":8,"K":10,"W":9,"S":2}},"pattern_bardock1":{"blank":"blank_pattern_z","dyes":{"E":8,"W":6,"B":9,"R":4,"K":2}},"pattern_bardock2":{"blank":"blank_pattern_super","dyes":{"Y":4,"W":6,"K":15,"B":4,"S":2,"A":2}},"pattern_turles":{"blank":"blank_pattern_z","dyes":{"S":6,"U":2,"B":11,"W":6,"K":2}},"pattern_gine":{"blank":"blank_pattern_z","dyes":{"Y":8,"W":2,"C":6,"S":5,"M":4}},"pattern_broly_z":{"blank":"blank_pattern_z","dyes":{"N":4,"Q":10,"A":3}},"pattern_broly_super":{"blank":"blank_pattern_super","dyes":{"L":4,"E":2,"W":8,"K":13}},"pattern_gas":{"blank":"blank_pattern_super","dyes":{"R":11,"Y":12,"S":4}},"pattern_piccolo":{"blank":"blank_pattern_z","dyes":{"U":21,"K":2,"R":2,"B":4}},"pattern_great_saiyaman":{"blank":"blank_pattern_z","dyes":{"E":14,"R":8,"K":8,"L":3}},"pattern_shin":{"blank":"blank_pattern_z","dyes":{"R":6,"C":12,"K":4,"W":3,"A":4,"O":4}},"pattern_zamasu":{"blank":"blank_pattern_super","dyes":{"Y":4,"G":6,"K":10,"U":6,"W":1,"A":4}},"pattern_fusionzamasu":{"blank":"blank_pattern_super","dyes":{"R":11,"G":10,"K":8,"W":2}},"pattern_hit":{"blank":"blank_pattern_super","dyes":{"K":6,"U":17,"C":4,"Y":2}},"pattern_beerus":{"blank":"blank_pattern_super","dyes":{"W":8,"N":2,"A":5,"S":6,"Y":2}},"pattern_whis":{"blank":"blank_pattern_super","dyes":{"K":14,"W":2,"M":8,"Y":9}},"pattern_gamma1":{"blank":"blank_pattern_super","dyes":{"R":5,"O":16,"K":2,"S":4,"N":6}},"pattern_gamma2":{"blank":"blank_pattern_super","dyes":{"A":4,"O":16,"K":2,"S":4,"B":1,"N":6}},"pattern_a16":{"blank":"blank_pattern_z","dyes":{"L":16,"E":8,"W":1,"K":3,"R":1}},"pattern_a17":{"blank":"blank_pattern_z","dyes":{"K":17,"R":5,"O":3,"S":4,"W":2}},"pattern_a17_super":{"blank":"blank_pattern_super","dyes":{"E":12,"K":8,"W":3,"S":6}},"pattern_a18":{"blank":"blank_pattern_z","dyes":{"B":15,"K":10,"S":4}},"pattern_a18_kame":{"blank":"blank_pattern_z","dyes":{"A":19,"B":6,"K":2}},"pattern_a18_tournament":{"blank":"blank_pattern_z","dyes":{"K":21,"G":4,"S":4}},"pattern_a18_cell":{"blank":"blank_pattern_z","dyes":{"S":7,"K":8,"W":9,"A":2,"Y":1}},"pattern_orange_high":{"blank":"blank_pattern_z","dyes":{"S":8,"K":9,"W":7,"E":1,"R":2,"O":2}},"pattern_videl":{"blank":"blank_pattern_z","dyes":{"W":16,"K":4,"N":8,"E":1}},"pattern_age1000":{"blank":"blank_pattern_z","dyes":{"R":6,"K":8,"L":10,"E":7}},"pattern_trunks_z":{"blank":"blank_pattern_z","dyes":{"U":24,"K":7}},"pattern_trunks_super":{"blank":"blank_pattern_super","dyes":{"A":10,"R":4,"B":12,"Y":2,"K":3}},"pattern_vegeta_gt":{"blank":"blank_pattern_z","dyes":{"R":21,"K":8}},"pattern_majin_buu":{"blank":"blank_pattern_z","dyes":{"U":16,"K":9,"Y":8}},"pattern_gogeta":{"blank":"blank_pattern_super","dyes":{"E":4,"Y":6,"K":11,"G":4}},"pattern_granola":{"blank":"blank_pattern_super","dyes":{"K":2,"W":6,"E":2,"S":6,"Y":1,"N":6,"G":2}},"pattern_majin21":{"blank":"blank_pattern_super","dyes":{"N":2,"K":17,"W":2,"Y":2}},"pattern_kale":{"blank":"blank_pattern_super","dyes":{"R":21,"K":2,"Y":2}},"pattern_caulifla":{"blank":"blank_pattern_super","dyes":{"P":4,"M":4,"K":9}},"pattern_kefla":{"blank":"blank_pattern_super","dyes":{"M":21,"Y":4}},"pattern_pride_troops":{"blank":"blank_pattern_super","dyes":{"K":8,"R":21,"W":2}},"pattern_a13":{"blank":"blank_pattern_z","dyes":{"Y":15,"K":5,"R":1,"O":4,"N":2}},"pattern_a14":{"blank":"blank_pattern_z","dyes":{"N":11,"Y":1}},"pattern_a20":{"blank":"blank_pattern_z","dyes":{"O":12,"S":4,"W":4,"R":3,"Y":4,"K":2}},"pattern_capsule_corp":{"blank":"blank_pattern_z","dyes":{"B":16,"K":6,"W":4,"S":5}},"pattern_chaoz":{"blank":"blank_pattern_z","dyes":{"E":16,"R":4,"Y":6,"W":1,"S":2}},"pattern_cooler_soldier":{"blank":"blank_pattern_z","dyes":{"W":4,"N":1,"U":6,"L":9,"K":6,"S":2}},"pattern_dragon_clan":{"blank":"blank_pattern_super","dyes":{"M":8,"K":2,"U":15,"R":4}},"pattern_evil_buu":{"blank":"blank_pattern_z","dyes":{"B":15,"Y":8,"K":6}},"pattern_fighter":{"blank":"blank_pattern_z","dyes":{"E":21,"K":2,"O":2,"S":4}},"pattern_gero":{"blank":"blank_pattern_z","dyes":{"N":2,"W":8,"O":19,"S":2}},"pattern_great_saiyaman_2":{"blank":"blank_pattern_z","dyes":{"E":2,"C":13,"U":6,"W":3,"O":1,"R":4}},"pattern_kibito":{"blank":"blank_pattern_z","dyes":{"R":17,"C":4,"A":4,"N":2,"O":4}},"pattern_king_vegeta":{"blank":"blank_pattern_z","dyes":{"P":4,"R":6,"W":9,"K":10,"B":2,"S":2}},"pattern_mighty_majin":{"blank":"blank_pattern_z","dyes":{"N":4,"Y":15,"E":2,"U":10}},"pattern_mystic":{"blank":"blank_pattern_z","dyes":{"W":9,"K":3,"C":11,"S":4}},"pattern_raditz":{"blank":"blank_pattern_z","dyes":{"N":8,"W":6,"K":2,"B":9}},"pattern_slug":{"blank":"blank_pattern_z","dyes":{"O":12,"Y":12,"U":5,"R":2}},"pattern_super_buu":{"blank":"blank_pattern_z","dyes":{"Y":4,"K":8}},"pattern_vergil":{"blank":"blank_pattern_super","dyes":{"B":24,"K":7}},"pattern_warrior_clan":{"blank":"blank_pattern_super","dyes":{"U":17,"K":2,"S":4}},"pattern_wonder_majin":{"blank":"blank_pattern_z","dyes":{"Y":6,"K":2,"U":13,"W":2}},"pattern_xeno_goku":{"blank":"blank_pattern_super","dyes":{"R":16,"K":7,"N":4,"B":4}},"pattern_xeno_goku_patreon":{"blank":"blank_pattern_super","dyes":{"S":16,"K":7,"G":4,"W":4}}};

// =====================================================================================
//  Accessory slots DMZ uses through Curios: "head_tech" (scouters, earrings, cloak, demon eye)
//  and "weights" (training weights).
// =====================================================================================
RPG.slots.define("head_tech", { name: "Head Tech", icon: "dbr:textures/gui/slot/head_tech.png", order: 10, keepOnDeath: true,
    onEquip(player, stack) { if (DMZ_ITEM_BY_REF[stack.id] === "demon_eye") player.addEffect("demon_eye", -1); },
    onUnequip(player, stack) { if (DMZ_ITEM_BY_REF[stack.id] === "demon_eye") player.removeEffect("demon_eye"); } });
RPG.slots.define("weights", { name: "Weights", icon: "dbr:textures/gui/slot/weights.png", order: 11, keepOnDeath: true });

// =====================================================================================
//  Effects the items give
// =====================================================================================
var DMZ_MULT_KEYS = ["STR", "SKP", "DEF", "STM", "VIT", "PWR", "ENE"];
/** Multiply DMZ's stat multipliers (player var "dmz_mult", read by 10_stats.js dmzView). */
function dmzScaleMult(player, factor) {
    let m = player.getVar("dmz_mult", null) || {};
    DMZ_MULT_KEYS.forEach((k) => { m[k] = (typeof m[k] === "number" ? m[k] : 1) * factor; });
    player.setVar("dmz_mult", m);
    player.refreshStats();
}
RPG.effects.define("medi_shell", { name: "Medi Shell", color: "#E0559B", beneficial: true });            // damage taken x0.7
RPG.effects.define("mastery_gain", { name: "Mastery Gain", color: "#9B59D0", beneficial: true });        // +50 % form mastery (read by forms)
[["oozaru_root", "Oozaru Root", "strength"], ["katchin_sprout", "Katchin Sprout", "resistance"], ["meteor_flower", "Meteor Flower", "strike"],
 ["aura_lily", "Aura Lily", "kipower"], ["hermit_fern", "Hermit Fern", "vitality"]].forEach((e) => {
    let st = {}; st[e[2]] = 15;
    RPG.effects.define(e[0], { name: e[1], color: "#55FF55", beneficial: true, stats: st });
});
RPG.effects.define("kaioshin_fruit", { name: "Kaioshin Fruit", color: "#3C7DFF", beneficial: true, tickInterval: 20,
    onTick(player) { player.addResource("ki", player.maxResource("ki") * 0.10); } });
RPG.effects.define("dmz_mightfruit", { name: "Fruit of Might", color: "#FF5555", beneficial: true,
    onApply(player) { dmzScaleMult(player, 1.2); }, onRemove(player) { dmzScaleMult(player, 1 / 1.2); } });
RPG.effects.define("demon_eye", { name: "&5Demon Eye", color: "#AA00AA", beneficial: true, keepOnDeath: true, tickInterval: 20,
    onApply(player) { dmzScaleMult(player, 1.5); }, onRemove(player) { dmzScaleMult(player, 1 / 1.5); },
    onTick(player) {
        let drain = player.maxResource("ki") * 0.02;
        if (player.resource("ki") >= drain) player.addResource("ki", -drain);
        else player.damage(player.maxHealth * 0.02);
    } });
RPG.on("hurt", (e) => {
    let p = e.target ? e.target.asPlayer() : null;
    if (p && p.hasEffect("medi_shell")) e.amount = e.amount * 0.7;
});

// =====================================================================================
//  Item behaviour
// =====================================================================================
function dmzTick() { return RPG.server.getTick(); }
function dmzCooldownLeft(player, key) { return Math.max(0, Number(player.getVar(key, 0)) - dmzTick()); }
function dmzRestore(player, hp, ki, st) {
    if (hp) player.health = Math.min(player.maxHealth, player.health + player.maxHealth * hp);
    if (ki) player.setResource("ki", Math.min(player.maxResource("ki"), player.resource("ki") + player.maxResource("ki") * ki));
    if (st) player.setResource("stamina", Math.min(player.maxResource("stamina"), player.resource("stamina") + player.maxResource("stamina") * st));
}
/** Vanilla hunger + DMZ's food regeneration (StatsEvents.onItemUseFinish: % of max over 6 s). */
function dmzEatFood(player, n, s) {
    let food = Math.min(20, player.getFood() + n);
    player.setFood(food);
    player.setSaturation(Math.min(food, n * s * 2));
    let hp = (n >= 2 ? Math.min(n, 20) * 0.01 : 0) + (s >= 0.4 ? Math.min(s, 2) * 0.001 : 0);
    let st = (n >= 2 ? Math.min(n, 20) * 0.02 : 0) + (s >= 0.4 ? Math.min(s, 2) * 0.004 : 0);
    if (hp <= 0 && st <= 0) return;
    let uuid = player.getUuid();
    for (let i = 1; i <= 6; i++) RPG.schedule(20 * i, () => {
        let p = RPG.world.entityByUuid(uuid);
        p = p ? p.asPlayer() : null;
        if (p && p.isAlive()) dmzRestore(p, hp / 6, hp / 6, st / 6);
    });
}
// Senzu beans (shared 240-tick cooldown on all four), heart medicine (own cooldown).
function dmzSenzu(player, kind) {
    let key = kind === "heart" ? "dmz_heart_cd" : "dmz_senzu_cd";
    if (player.hasEffect("stunned")) return false;
    let left = dmzCooldownLeft(player, key);
    if (left > 0) { player.actionbar("&cYou must wait " + Math.ceil(left / 20) + " seconds before eating another Senzu Bean!"); return false; }
    let all = kind === "all" || kind === "heart";
    dmzRestore(player, all || kind === "hp" ? 1 : 0, all || kind === "ki" ? 1 : 0, all || kind === "st" ? 1 : 0);
    if (kind !== "heart") player.setFood(20);
    player.setVar(key, dmzTick() + 240);
    sfx(player, "senzu", 1, 1);
}
function dmzCapsule(player, spec) {
    let have = player.stat(spec.stat), inc = Math.min(spec.pts, 1000000 - have);
    if (inc <= 0) { player.actionbar("&c" + spec.abbr + " is already at its maximum."); return false; }
    player.addStat(spec.stat, inc);
    sfx(player, "minecraft:block.amethyst_block.resonate", 1.5, 1.0);
    player.actionbar("&a+" + inc + " " + spec.abbr);
}
function dmzStatPlant(player, spec) {
    if (spec.stat === "mastery") {                                      // zenkai lotus: cleanse
        RPG.skills.list().forEach((id) => player.resetCooldown(id));
        ["stunned", "staggered"].forEach((e) => { if (player.hasEffect(e)) player.removeEffect(e); });
        ["poison", "wither", "slowness", "weakness", "mining_fatigue", "blindness", "nausea", "hunger", "darkness", "levitation", "unluck", "instant_damage"]
            .forEach((e) => player.removePotion("minecraft:" + e));
        player.setFood(Math.min(20, player.getFood() + 1));
        player.actionbar("&dYour body feels renewed!");
        return;
    }
    let effect = spec.stat === "ki_regen" ? "kaioshin_fruit" : spec.id;
    if (player.hasEffect(effect)) { player.actionbar("&cThat plant's effect is still active."); return false; }
    player.addEffect(effect, spec.stat === "ki_regen" ? 100 : 300);
    if (spec.stat === "vitality") player.addPotion("minecraft:regeneration", 300, 2);
    player.setFood(Math.min(20, player.getFood() + 1));
}
function dmzHeldData(player) { let st = player.getHeldStack(); return st && st.data ? st.data : {}; }
function dmzNewPairId() { return String(Date.now()) + "_" + Math.floor(Math.random() * 1e9); }

// Senzu bag: holds up to 64 senzu beans (any colour) in its item data.
var DMZ_SENZU_IDS = ["senzu_bean", "senzu_bean_red", "senzu_bean_blue", "senzu_bean_yellow"];
function dmzSenzuBagLore(beans) {
    let total = 0, lore = [];
    beans.forEach((b) => { total += b[1]; lore.push("&7" + b[1] + "x " + RPG.items.name(RPG.items.id(b[0]))); });
    return ["&a" + total + "/64 Senzu Beans"].concat(lore).concat(["&8Use: unpack the newest stack (or pack loose beans)", "&8Sneak + use: eat one"]);
}
function dmzSenzuBag(player) {
    let st = player.getHeldStack();
    if (!st) return false;
    let data = st.data || {}, beans = data.beans || [];                       // [[id, count], ...] newest first
    let total = 0; beans.forEach((b) => total += b[1]);
    if (player.isSneaking()) {
        for (let i = 0; i < beans.length; i++) {
            let kind = { senzu_bean: "all", senzu_bean_red: "hp", senzu_bean_blue: "ki", senzu_bean_yellow: "st" }[beans[i][0]];
            if (dmzSenzu(player, kind) === false) return false;
            beans[i][1]--; if (beans[i][1] <= 0) beans.splice(i, 1);
            break;
        }
    } else {
        let packed = 0;
        DMZ_SENZU_IDS.forEach((id) => {
            let n = Math.min(player.countItem(id), 64 - total);
            if (n > 0 && player.takeItem(id, n)) { beans.unshift([id, n]); total += n; packed += n; }
        });
        if (!packed && beans.length) { let b = beans.shift(); player.giveItem(b[0], b[1]); }
    }
    data.beans = beans;
    st.data = data; st.lore = dmzSenzuBagLore(beans);
    player.setHeldStack(st);
    return false;                                                              // never consumed
}

// Scouter (interim): right-click reads the target's power level; the DMZ HUD is a client script.
function dmzScouter(player) {
    let target = player.target(20);
    if (!target) { player.actionbar("&7Scouter: &8no target"); return false; }
    let pl = typeof powerLevel === "function" ? powerLevel(target) : Math.floor(target.maxHealth * 25);
    if (pl > 150000000) {
        let st = player.getHeldStack();
        if (st) { st.damage = (st.damage || 0) + 1; player.setHeldStack(st.damage >= 15 ? null : st); }
        player.actionbar("&cScouter overloaded!"); sfx(player, "minecraft:entity.item.break", 1, 1);
        return false;
    }
    player.actionbar("&a" + target.getName() + "&7 - Battle power: &e" + (typeof grouped === "function" ? grouped(pl) : pl));
    sfx(player, "pip_menu", 0.7, 2);
}
function dmzBucket(player, spec) {
    let at = player.lookBlock(5);
    if (!at || RPG.world.getBlock(player.dimension, at[0], at[1] + 1, at[2]) !== "minecraft:air") return false;
    dmzSet(player.dimension, at[0], at[1] + 1, at[2], spec.liquid);
    RPG.world.sound(player.dimension, "minecraft:item.bucket.empty", at[0] + 0.5, at[1] + 1, at[2] + 0.5, 1, 1);
    if (!dmzCreative(player)) player.giveItem("minecraft:bucket", 1);
}
function dmzSpawnEgg(player, spec) {
    let at = player.lookBlock(6);
    if (!at) return false;
    if (!spec.mob || !RPG.mobs.exists(spec.mob)) { player.actionbar("&7This creature isn't in the game yet."); return false; }
    RPG.world.spawnMob(player.dimension, spec.mob, at[0] + 0.5, at[1] + 1, at[2] + 0.5);
    if (dmzCreative(player)) return false;
}

// DMZ weapons whose in-hand model is GeckoLib (their item JSON's 3D half is parent builtin/entity): the item JSON
// still gives the flat icon (gui/ground/fixed) and DMZ's hand transforms, geo draws the 3D model. hide: the
// scabbard/holster bone DMZ hides while the weapon is held.
var DMZ_GEO_WEAPONS = {
    brave_sword: ["cubretodo"], dimensional_sword: [], power_pole: ["cubretodo"], tamagami_hammer: [],
    tamagami_sword: [], tamagami_trident: [], yajirobe_katana: [], z_sword: []
};
function dmzWeaponGeo(id) {
    return { model: "dmzpack:geo/weapons/" + id + ".geo.json", texture: "dmzpack:textures/item/weapons/" + id + ".png",
        hide: DMZ_GEO_WEAPONS[id] };
}

var DMZ_CAPE_TEXTURES = { king_vegeta: true, evil_buu: true };
function dmzItemDef(s) {
    let def = { name: s.n, maxStack: s.stack || 64 };
    if (s.m) def.model = s.m; else { def.icon = s.icon || "gem"; if (s.iconColor) def.iconColor = s.iconColor; }
    if (s.m && DMZ_GEO_WEAPONS.hasOwnProperty(s.id)) def.geo = dmzWeaponGeo(s.id);
    if (s.rarity) def.rarity = s.rarity;
    if (s.lore) def.lore = s.lore;
    if (s.durability) def.durability = s.durability;
    def.type = "material";
    let fx = s.fx || "";
    if (fx === "capsule") { def.type = "consumable"; def.onUse = (p) => dmzCapsule(p, s); }
    else if (fx === "mastery_capsule") {
        def.type = "consumable";
        def.onUse = (p) => {
            if (typeof dmzAddFormMastery === "function") return dmzAddFormMastery(p, 5);   // forms owner: return false when base form / maxed
            p.actionbar("&cYou need to be transformed to use this."); return false;
        };
    }
    else if (fx === "senzu") { def.type = "consumable"; def.useTime = 1; def.useAnim = "eat"; def.onUse = (p) => dmzSenzu(p, s.kind); }
    else if (fx === "senzu_bag") { def.type = "tool"; def.onUse = (p) => dmzSenzuBag(p); def.lore = dmzSenzuBagLore([]); }
    else if (fx === "food") {
        def.type = "consumable"; def.useTime = 32; def.useAnim = "eat";
        def.onUse = (p) => {
            if (s.restore) {
                let left = dmzCooldownLeft(p, "dmz_senzu_cd");
                if (left > 0) { p.actionbar("&cYou must wait " + Math.ceil(left / 20) + " seconds."); return false; }
                dmzRestore(p, s.restore, s.restore, s.restore); p.setVar("dmz_senzu_cd", dmzTick() + 240);
                let food = Math.min(20, p.getFood() + s.food[0]); p.setFood(food);
            } else dmzEatFood(p, s.food[0], s.food[1]);
            if (s.effect) p.addEffect(s.effect[0], s.effect[1]);
            if (s.beetle) { let d = dmzHeldData(p); if (d.pairId) p.setVar("dmz_beetle_pair", { id: d.pairId, until: dmzTick() + 600 }); }
        };
    }
    else if (fx === "beetle_pair") {
        def.type = "consumable";
        def.onUse = (p) => { p.giveStack({ id: "medi_bug_beetle", count: 2, data: { pairId: dmzNewPairId() }, lore: ["&dPaired beetle"] }); };
    }
    else if (fx === "might_fruit") {
        def.type = "consumable"; def.useTime = 32; def.useAnim = "eat";
        def.onUse = (p) => { p.setFood(Math.min(20, p.getFood() + 2)); p.setSaturation(20); p.removeEffect("dmz_mightfruit"); p.addEffect("dmz_mightfruit", 1200); };
    }
    else if (fx === "sacred_water") {
        def.type = "consumable"; def.useTime = 32; def.useAnim = "drink";
        def.onUse = (p) => {
            if (p.getVar("dmz_sacred_water", false)) { p.actionbar("&cYou have already drunk the Sacred Water."); return false; }
            p.setVar("dmz_sacred_water", true);
            dmzScaleMult(p, 1.1);
            p.tell("&bAll stats x1.10");
            sfx(p, "minecraft:entity.player.levelup", 0.8, 1.4);
        };
    }
    else if (fx === "ki_battery") {
        def.type = "consumable"; def.cooldown = 60;
        def.onUse = (p) => { dmzRestore(p, 0, 0.5, 0); sfx(p, "minecraft:block.beacon.power_select", 0.6, 1.6); };
    }
    else if (fx === "stat_plant") { def.type = "consumable"; def.useTime = 32; def.useAnim = "eat"; def.onUse = (p) => dmzStatPlant(p, s); }
    else if (fx === "seed") { def.type = "material"; }
    else if (fx === "curio") { def.type = "accessory"; def.accessory = s.slot; if (s.stats) def.stats = s.stats; }
    else if (fx === "scouter") { def.type = "accessory"; def.accessory = s.slot; def.onUse = (p) => dmzScouter(p); }
    else if (fx === "pothala_pair") {
        def.type = "consumable";
        def.onUse = (p) => {
            let id = dmzNewPairId();
            p.giveStack({ id: s.left, count: 1, data: { pairId: id } });
            p.giveStack({ id: s.right, count: 1, data: { pairId: id } });
        };
    }
    else if (fx === "weapon") { def.type = "weapon"; def.damage = s.damage; def.attackSpeed = s.speed; if (!s.durability) delete def.durability; }
    else if (fx === "tool") { def.type = "tool"; def.damage = s.damage; def.attackSpeed = s.speed; }
    else if (fx === "gun") {
        def.type = "weapon"; def.cooldown = s.cd;
        def.onUse = (p) => {
            p.shoot(s.proj, { damage: 10 });
            RPG.world.sound(p.dimension, s.sound, p.x, p.y, p.z, 1.0, s.pitch);
            let st = p.getHeldStack();
            if (st && !dmzCreative(p)) { st.damage = (st.damage || 0) + 1; p.setHeldStack(st.damage >= s.durability ? null : st); }
        };
    }
    else if (fx === "bucket") { def.type = "consumable"; def.onUse = (p) => dmzBucket(p, s); }
    else if (fx === "disc") {
        def.type = "tool"; def.cooldown = 20;
        def.onUse = (p) => { sfx(p, "menu_music_" + s.n, 2, 1); p.actionbar("&bNow playing: &f" + s.desc); };
    }
    else if (fx === "egg") { def.type = "consumable"; def.onUse = (p) => dmzSpawnEgg(p, s); }
    else if (fx === "plain_info") { def.onUse = (p) => { p.actionbar("&7" + s.info); return false; }; }
    else if (fx === "armor") {
        def.type = "armor"; def.slot = s.slot; def.armor = s.armor; def.toughness = 5; def.knockbackResistance = 0.1;
        def.armorTexture = "dmzpack:textures/armor/" + s.tex + "_layer{n}.png"; def.armorModel = "skin64";
        // DMZ's cape sets are drawn with its cape armour model (shoulder pads, a three-part cape)
        if (DMZ_CAPE_TEXTURES[s.tex]) def.armorGeo = "dmzpack:geo/armor/armorcape.geo.json";
    }
    return def;
}

DMZ_ITEM_SPECS.forEach((s) => {
    if (s.fx === "bucket" && RPG.fluids && RPG.fluids.exists(s.id.replace(/_bucket$/, ""))) return;   // real buckets: 14_dmz_fluids.js
    let def = dmzItemDef(s);
    // DMZ uses capsules, beetles and other non-food items the moment you right-click (no eating)
    if (def.type === "consumable" && def.useTime === undefined) def.useTime = 0;
    let id = RPG.items.define(s.id, def);
    DMZ_ITEM_BY_REF["ragnarok_rpg:" + id] = s.id;
    if (s.fx === "seed" || s.fx === "stat_plant") DMZ_PLANTABLE[s.id] = s.crop;
});

// =====================================================================================
//  Pattern Station: blank pattern in hand -> pick a pattern; costs the dyes of its 6x6 grid
//  (DMZPatternRecipeProvider). Kikono Station: pattern in hand -> sew a piece from the
//  template + Kikono cloth/string (DMZKikonoRecipeProvider), powered by a nearby Fuel Generator.
// =====================================================================================
var DMZ_DYES = { W: "minecraft:white_dye", S: "minecraft:light_gray_dye", G: "minecraft:gray_dye", K: "minecraft:black_dye", N: "minecraft:brown_dye",
    R: "minecraft:red_dye", O: "minecraft:orange_dye", Y: "minecraft:yellow_dye", L: "minecraft:lime_dye", E: "minecraft:green_dye", C: "minecraft:cyan_dye",
    A: "minecraft:light_blue_dye", B: "minecraft:blue_dye", U: "minecraft:purple_dye", M: "minecraft:magenta_dye", P: "minecraft:pink_dye", Q: "minecraft:gold_nugget" };
function dmzHasAll(player, cost) { return cost.every((c) => player.countItem(c[0]) >= c[1]); }
function dmzTakeAll(player, cost) { cost.forEach((c) => player.takeItem(c[0], c[1])); }
function dmzCostLore(cost) { return cost.map((c) => "&7" + c[1] + "x " + RPG.items.name(c[0].indexOf(":") >= 0 ? c[0] : "ragnarok_rpg:" + RPG.items.id(c[0]))); }
function dmzRecipeMenu(player, title, entries) {
    let rows = Math.max(1, Math.min(6, Math.ceil(entries.length / 9)));
    let items = entries.slice(0, rows * 9).map((e) => ({ id: e.result, count: e.count || 1,
        lore: dmzCostLore(e.cost).concat([dmzHasAll(player, e.cost) ? "&aClick to craft" : "&cMissing ingredients"]) }));
    RPG.ui.container(player, { title: title, rows: rows, mode: "menu", items: items,
        onClick(p, slot) {
            let e = entries[slot];
            if (!e) return;
            if (e.check && !e.check(p)) return;
            if (!dmzHasAll(p, e.cost)) { p.actionbar("&cMissing ingredients."); return; }
            dmzTakeAll(p, e.cost);
            p.giveItem(e.result, e.count || 1);
            sfx(p, "minecraft:block.smithing_table.use", 1, 1);
        } });
}
function dmzOpenPatternStation(player) {
    let heldName = DMZ_ITEM_BY_REF[String(player.getHeldItem())];
    if (heldName !== "blank_pattern_z" && heldName !== "blank_pattern_super") { player.actionbar("&7Hold a blank pattern."); return; }
    let entries = [];
    Object.keys(DMZ_PATTERN_GRIDS).forEach((pat) => {
        let g = DMZ_PATTERN_GRIDS[pat];
        if (g.blank !== heldName) return;
        let cost = [[heldName, 1]];
        Object.keys(g.dyes).forEach((ch) => cost.push([DMZ_DYES[ch], g.dyes[ch]]));
        entries.push({ result: pat, cost: cost });
    });
    dmzRecipeMenu(player, "Pattern Station", entries);          // 51 Z patterns, 31 Super patterns: one screen each
}
var DMZ_PIECES = {
    helmet: { tpl: "minecraft:iron_helmet", C: 2, S: 3 }, chestplate: { tpl: "minecraft:iron_chestplate", C: 5, S: 3 },
    leggings: { tpl: "minecraft:iron_leggings", C: 5, S: 2 }, boots: { tpl: "minecraft:iron_boots", C: 2, S: 2 }
};
var DMZ_GETE_RECIPES = [["gete_pickaxe", "minecraft:netherite_pickaxe", 3], ["gete_axe", "minecraft:netherite_axe", 3],
    ["gete_shovel", "minecraft:netherite_shovel", 1], ["gete_hoe", "minecraft:netherite_hoe", 2]];
var DMZ_FUELS = ["minecraft:coal", "minecraft:charcoal", "minecraft:coal_block", "minecraft:blaze_rod"];
function dmzNearGenerator(player, x, y, z) {
    let gen = blockRef("fuel_generator");
    for (let dx = -6; dx <= 6; dx++) for (let dy = -2; dy <= 2; dy++) for (let dz = -6; dz <= 6; dz++)
        if (RPG.world.getBlock(player.dimension, x + dx, y + dy, z + dz) === gen) return true;
    return false;
}
function dmzPower(player) {                                    // 1000 FE per craft ~ one coal burnt in the generator
    for (let i = 0; i < DMZ_FUELS.length; i++) if (player.takeItem(DMZ_FUELS[i], 1)) return true;
    player.actionbar("&cThe Fuel Generator needs fuel (coal, charcoal, coal block or blaze rod) in your inventory.");
    return false;
}
function dmzOpenKikonoStation(player, x, y, z) {
    let heldName = DMZ_ITEM_BY_REF[String(player.getHeldItem())];
    if (!heldName || heldName.indexOf("pattern_") !== 0 || heldName.indexOf("blank_") === 0) { player.actionbar("&7Hold an armour pattern (or the Gete pattern)."); return; }
    if (!dmzNearGenerator(player, x, y, z)) { player.actionbar("&cThe Kikono Station needs a Fuel Generator within 6 blocks."); return; }
    let entries = [];
    if (heldName === "pattern_gete") {
        DMZ_GETE_RECIPES.forEach((r) => entries.push({ result: r[0], cost: [[r[1], 1], ["gete_ingot", r[2]], ["kikono_stick", 2]], check: dmzPower }));
    } else {
        DMZ_ARMOR_SETS.forEach((set) => {
            if (set.pattern !== heldName) return;
            ["helmet", "chestplate", "leggings", "boots"].forEach((piece) => {
                if (piece === "helmet" && !set.helmet) return;
                let r = DMZ_PIECES[piece];
                entries.push({ result: set.id + "_" + piece, cost: [[r.tpl, 1], ["kikono_cloth", r.C], ["kikono_string", r.S]], check: dmzPower });
            });
        });
    }
    if (!entries.length) { player.actionbar("&7Nothing can be sewn with this pattern."); return; }
    dmzRecipeMenu(player, "Kikono Station", entries);
}
