// =====================================================================================
//  19_dbr_runes.js - DMZ Ragnarok's armour runes on the server
// =====================================================================================
//  A port of DMZR's runes package: rune items in four grades (Lesser, Normal, Greater,
//  Admin) whose tier is rolled inside the grade's band, the Rune Bench (socket, awaken,
//  remove), the 9-into-1 tier upgrade, and the stat bonus while worn. Works on ANY armour
//  item: vanilla, DMZ's outfits (52_armor.js), NBArmors, other mods. The rules live in
//  shared/26_dbr_runes.js; the tooltips are drawn by client/scripts/45_dbr_runes.js.
//
//  Obtaining (as in DMZR): every armour piece rolls a tier and affinity the first time a
//  survival player picks it up or puts it on; dormant runes are awakened at the bench for
//  Zeni (dbr_runes config); nine runes of one tier craft into one of the next. Rune items
//  are also given by staff (/rpg give, creative tab "RPG Items").
//
//  Stats: DMZR sums the arrows on all four worn pieces into ONE "*" bonus per stat in DMZ's
//  multiplied bucket (1 + arrows x 2.5 %). Here the same factor is folded into dmz_mult the
//  way 31_dmz_transform.js folds forms and 58_dmz_machines.js folds gravity, so it rides
//  every form multiplier exactly like DMZ's multiplied bucket. RES feeds defence and stamina.
// =====================================================================================
var DBR_RUNES_CFG = RPG.config.define("dbr_runes", {
    runeAwakenZeniCost: { default: 5000, min: 0, max: 1000000000, integer: true,
        comment: "Zeni charged to awaken one dormant rune at the rune bench. Charged before the dormant rune is consumed, so a player who cannot pay loses neither the rune nor any Zeni. Zero makes awakening free." }
});

var DBR_RUNE_ITEMS = (function () {
    var R = DBR_RUNES, byId = {}, byName = {}, ids = [];
    R.itemList().forEach(function (e) {
        var name = e[0], stat = e[1], grade = e[2], all = e[3];
        var art = stat ? R.STAT_INFO[stat].key : "dormant";
        var id = RPG.items.define(name, {
            name: R.itemName(stat, grade, all),
            model: "dbr:rpg/item/rune_" + art,
            // the sheen is the grade's marking (all grades share one piece of art); a dormant rune stays dull
            glint: !!(stat || all),
            maxStack: 64
        });
        var full = id && id.indexOf(":") < 0 ? "ragnarok_rpg:" + id : id;
        var info = { name: name, stat: stat, grade: grade, allStats: all };
        byId[full] = info;
        byName[name] = full;
        ids.push(full);
    });
    return {
        info: function (stack) { return stack && stack.id ? byId[stack.id] || null : null; },
        id: function (name) { return byName[name]; },
        of: function (stat, grade) { return byName["rune_" + DBR_RUNES.STAT_INFO[stat].key + DBR_RUNES.GRADE_INFO[grade || "NORMAL"].suffix]; },
        ids: ids,
        /** id -> [stat, grade, allStats], for the client's tooltips. */
        table: function () { var t = {}; Object.keys(byId).forEach(function (k) { var i = byId[k]; t[k] = [i.stat, i.grade, i.allStats]; }); return t; }
    };
})();

(function () {
    var R = DBR_RUNES, ITEMS = DBR_RUNE_ITEMS;
    var ARMOR_SLOTS = { feet: 36, legs: 37, chest: 38, head: 39 };

    // ---- rune stacks --------------------------------------------------------------------------
    function isDormant(info) { return info && !info.stat && !info.allStats; }
    function isAdmin(info) { return info && info.grade === "ADMIN"; }
    function hasTier(stack) { return !!(stack && stack.data && typeof stack.data === "object" && stack.data.runeTier); }
    function runeTier(stack) { return R.tierOf(stack && stack.data && stack.data.runeTier); }
    /** ensureTier: a rune from creative, /give or a loot table rolls its tier from its own grade, once. */
    function ensureTier(stack) {
        var info = ITEMS.info(stack);
        if (!info || isDormant(info)) return "LOW";
        if (hasTier(stack)) return runeTier(stack);
        if (!stack.data || typeof stack.data !== "object") stack.data = {};
        stack.data.runeTier = R.rollGradeTier(info.grade);
        return stack.data.runeTier;
    }
    function rolled(stat, grade, tier) {
        return { id: ITEMS.of(stat, grade), count: 1, data: { runeTier: tier || R.rollGradeTier(grade || "NORMAL") } };
    }
    /** A stack ready to write back: the display name stays in nbt, so it keeps its formatting. */
    function clean(stack) { delete stack.name; return stack; }

    // ---- rolling armour on pickup and on equip (RuneEvents) ------------------------------------
    function creative(p) { return p.getGameMode() === "creative"; }
    RPG.on("itemPickup", function (p, stack) {
        if (!stack || !stack.armorSlot || creative(p) || R.has(stack)) return;
        R.ensureRolled(stack);
        return clean(stack);
    });
    RPG.on("equipmentChange", function (p, slot, now) {
        if (!(slot in ARMOR_SLOTS)) return;
        // after the change is in place: a stack edited inside the change itself would only be swapped again
        RPG.schedule(1, function () {
            if (!p.alive && p.health <= 0) return;
            var idx = ARMOR_SLOTS[slot], st = p.getStack(idx);
            if (st && st.armorSlot && !creative(p) && !R.has(st)) { R.ensureRolled(st); p.setStack(idx, clean(st)); }
            refresh(p);
        });
    });

    // ---- the stat bonus while worn (RuneStatApplier) ---------------------------------------------
    // DMZ applies a stat's bonus to the stat itself; in DBR's formulas RES is read as defence and stamina
    var MULT_KEYS = { STR: ["STR"], SKP: ["SKP"], RES: ["DEF", "STM"], VIT: ["VIT"], PWR: ["PWR"], ENE: ["ENE"] };
    function wanted(p) {
        var totals = {}, out = {};
        R.STATS.forEach(function (s) { totals[s] = 0; });
        Object.keys(ARMOR_SLOTS).forEach(function (k) {
            var st = p.getStack(ARMOR_SLOTS[k]);
            if (R.has(st)) R.STATS.forEach(function (s) { totals[s] += R.arrows(st, s); });
        });
        R.STATS.forEach(function (s) {
            var f = totals[s] === 0 ? 1 : Math.max(0.05, 1 + totals[s] * R.ARROW_STEP);
            MULT_KEYS[s].forEach(function (k) { out[k] = f; });
        });
        return out;
    }
    /** Recompute from what is worn; the applied factor is kept INSIDE dmz_mult, so anything that resets it resets both. */
    function refresh(p) {
        if (!p) return;
        var want = wanted(p), m = p.getVar("dmz_mult", null) || {}, o = {}, applied = m.rune && typeof m.rune === "object" ? m.rune : {}, changed = false;
        Object.keys(m).forEach(function (k) { o[k] = m[k]; });
        var next = {};
        Object.keys(want).forEach(function (k) {
            var old = typeof applied[k] === "number" && applied[k] > 0 ? applied[k] : 1;
            next[k] = want[k];
            if (Math.abs(old - want[k]) < 1e-6) return;
            var cur = typeof o[k] === "number" ? o[k] : 1;
            o[k] = cur / old * want[k];
            changed = true;
        });
        if (!changed) return;
        o.rune = next;
        p.setVar("dmz_mult", o);
        p.refreshStats();
    }
    RPG.on("playerJoin", function (p) { RPG.schedule(20, function () { refresh(p); }); sendIds(p); });
    RPG.on("respawn", function (p) { RPG.schedule(5, function () { refresh(p); }); });

    // ---- once a second: unrolled runes get their tier (RuneItem.inventoryTick), bonuses stay true -----
    RPG.every(20, function () {
        RPG.server.players().forEach(function (p) {
            for (var i = 0; i <= 40; i++) {
                var id = p.getSlot(i);
                if (id === "minecraft:air" || id.indexOf("ragnarok_rpg:") !== 0) continue;
                var info = ITEMS.info({ id: id });
                if (!info || isDormant(info) || isAdmin(info)) continue;
                var st = p.getStack(i);
                if (st && !hasTier(st)) { ensureTier(st); p.setStack(i, clean(st)); }
            }
        });
    });
    RPG.every(100, function () { RPG.server.players().forEach(refresh); });

    // ---- the Rune Bench (RuneBenchBlock / RuneBenchMenu / RuneBenchScreen) ------------------------
    var SMITHING = "minecraft:textures/gui/container/smithing.png";
    var BTN_SOCKET = "socket", BTN_AWAKEN = "awaken";
    function benchWarning(so) {
        var pct = Math.round(R.DAMAGE_CHANCE * 100);
        return "&fRemoving the " + R.statLabel(so.stat) + "&f rune: &c" + pct + "%&f chance to " +
            (R.wouldRiskDestruction(so.tier) ? "DESTROY it" : "degrade it");
    }
    function update(bench) {
        var armor = bench.get(0), rune = bench.get(1), info = ITEMS.info(rune);
        var rolledPiece = !!armor && R.has(armor), so = rolledPiece ? R.sockets(armor) : [];
        bench.button(BTN_AWAKEN, { enabled: !!info && isDormant(info) });
        bench.button(BTN_SOCKET, { enabled: !!armor && !!info && !isDormant(info) && (!rolledPiece || R.freeSockets(armor) > 0) });
        for (var i = 0; i < R.SOCKETS; i++) {
            var filled = i < so.length;
            bench.button("remove" + i, { enabled: filled, tooltip: filled ? benchWarning(so[i]) : [] });
        }
    }
    function giveOrDrop(p, stack) { p.giveStack(stack); }
    function shrink(bench, slot) {
        var st = bench.get(slot);
        if (!st) return;
        st.count -= 1;
        bench.set(slot, st.count > 0 ? clean(st) : null);
    }
    function doAwaken(p, bench) {
        var slot = bench.get(1), info = ITEMS.info(slot);
        if (!info || !isDormant(info)) return;
        // the Zeni is taken before anything is consumed: a failed charge leaves the dormant rune untouched
        var cost = Number(DBR_RUNES_CFG.get("runeAwakenZeniCost")) || 0;
        if (cost > 0 && !p.takeMoney(cost)) {
            p.tell("&cYou need " + cost + " Zeni to awaken this rune (you have " + Math.floor(p.getMoney()) + ").");
            return;
        }
        var stat = R.STATS[Math.floor(Math.random() * R.STATS.length)];
        shrink(bench, 1);
        giveOrDrop(p, rolled(stat, "NORMAL"));
    }
    function doSocket(p, bench, armor) {
        var runeStack = bench.get(1), info = ITEMS.info(runeStack);
        if (!info || isDormant(info)) return;
        if (isAdmin(info)) {
            // fills the piece outright and needs no free socket
            if (!R.socketAdmin(armor, info.allStats ? null : info.stat)) return;
        } else {
            if (R.freeSockets(armor) <= 0) return;
            if (!R.socket(armor, info.stat, ensureTier(runeStack))) return;
        }
        bench.set(0, clean(armor));
        shrink(bench, 1);
    }
    function doRemove(p, bench, armor, index) {
        var so = R.unsocket(armor, index);
        if (!so) return;
        bench.set(0, clean(armor));
        // one roll: intact, or one tier lower, or gone when already at the bottom
        var result = "INTACT", tier = so.tier;
        if (Math.random() < R.DAMAGE_CHANCE) {
            tier = R.degrade(so.tier);
            result = tier ? "DEGRADED" : "BROKEN";
        }
        if (tier) giveOrDrop(p, rolled(so.stat, "NORMAL", tier));
        var name = R.statLabel(so.stat) + "&r";
        p.actionbar(result === "INTACT" ? "The " + name + " rune came out intact."
            : result === "DEGRADED" ? "The " + name + " rune was damaged and lost a tier." : "The " + name + " rune shattered.");
    }
    function onButton(p, id, bench) {
        if (id === BTN_AWAKEN) { doAwaken(p, bench); update(bench); return; }
        var armor = bench.get(0);
        if (!armor) return;
        // an unrolled piece can still be worked on: it gets its tier now rather than being refused
        if (!R.has(armor)) R.ensureRolled(armor);
        if (id === BTN_SOCKET) doSocket(p, bench, armor);
        else if (id.indexOf("remove") === 0) doRemove(p, bench, armor, Number(id.substring(6)));
        else bench.set(0, clean(armor));
        update(bench);
    }
    function openBench(p, x, y, z) {
        var bench = RPG.ui.workbench(p, {
            title: "Rune Bench",
            // vanilla's smithing screen by path, so resource packs that restyle it restyle the bench too
            background: SMITHING,
            titleColor: "404040", labelColor: "404040",
            slots: [{ x: 26, y: 48, accepts: "armor", max: 1 }, { x: 44, y: 48, accepts: ITEMS.ids }],
            // the hammer baked into the smithing art: covered with the empty panel beside it, drawn again lower down
            images: [{ x: 6, y: 4, u: 46, v: 4, w: 37, h: 35 }, { x: 6, y: 12, u: 6, v: 4, w: 37, h: 35 }],
            buttons: [
                { id: BTN_SOCKET, text: "Socket", x: 66, y: 16, enabled: false },
                { id: BTN_AWAKEN, text: "Awaken", x: 120, y: 16, enabled: false },
                { id: "remove0", text: "Remove 1", x: 66, y: 32, enabled: false },
                { id: "remove1", text: "Remove 2", x: 120, y: 32, enabled: false }
            ],
            at: { x: x, y: y, z: z, dimension: p.dimension },
            onChange: function (pl, b) { update(b); },
            onButton: onButton
        });
        if (bench) update(bench);
    }
    /** Other scripts (and staff) can open the bench without the block: DBR_RUNE_ITEMS.openBench(player). */
    ITEMS.openBench = function (p) { openBench(p, Math.floor(p.x), Math.floor(p.y), Math.floor(p.z)); };
    ITEMS.refresh = refresh;
    RPG.blocks.define("rune_bench", {
        name: "Rune Bench",
        model: "dbr:rpg/block/rune_bench",
        hardness: 3.5,
        requiresTool: true,
        // a table: one solid box up to the top surface (y12), rather than gaps between the legs
        shape: [0, 0, 0, 16, 12, 16],
        renderType: "translucent",
        onUse: openBench
    });

    // ---- recipes (rune_bench.json, RuneUpgradeRecipe) ----------------------------------------------
    RPG.recipes.addShaped("rune_bench", ["OOO", "ISI", "III"],
        { O: "minecraft:obsidian", I: "minecraft:iron_ingot", S: "minecraft:smithing_table" }, "rune_bench");
    // nine runes of one tier, same stat and grade, become one of the next tier; Mythical has nothing above it
    RPG.recipes.addSpecial("rune_upgrade", function (grid) {
        var first = null, tier = null, found = 0;
        for (var i = 0; i < grid.length; i++) {
            var st = grid[i];
            if (!st) continue;
            if (++found > 9) return null;
            var info = ITEMS.info(st);
            if (!info || isDormant(info)) return null;
            var t = runeTier(st);
            if (!first) { first = st; tier = t; continue; }
            if (st.id !== first.id || t !== tier) return null;
        }
        if (found !== 9 || !tier) return null;
        var next = R.promote(tier);
        return next ? { id: first.id, count: 1, data: { runeTier: next } } : null;
    });

    // ---- the client needs to know which placeholder ids are runes, for the tooltips ----------------
    function sendIds(p) { RPG.net.send(p, "dbr_runes_ids", ITEMS.table()); }
    RPG.net.on("dbr_runes_hello", function (p) { sendIds(p); });
    RPG.server.players().forEach(sendIds);
})();
