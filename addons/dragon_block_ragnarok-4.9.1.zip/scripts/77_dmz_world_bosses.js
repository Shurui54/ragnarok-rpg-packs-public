// =====================================================================================
//  77_dmz_world_bosses.js - DragonMine Z's world bosses (lairs, fights, contribution, rewards)
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): server/world/worldboss/{WorldBossManager,WorldBossLair,WorldBossSession,
//  WorldBossContribution,WorldBossRewards,WorldBossCombatEvents}.java, common/init/entities/worldboss/*,
//  GeneralServerConfig.WorldBossConfig. Numbers are DMZ's defaults (docs/dmz-spec 05 §2.12, Appendix B).
//
//  Lairs: one per boss and world (see "lairs" below for DMZ's exact shapes):
//    janemba            Other World Hell, 1000 blocks from 0,0: DMZ's spiked hell-stone arena (r16, rim r22, bone spikes)
//    turles             Overworld, at the foot of DMZ's Tree of Might (planned 1000+ blocks from spawn)
//    metal_cooler_core  Namek, in the chamber of DMZ's Big Gete Star (planned 1000+ blocks from spawn)
//    tamagami_1/2/3     the First / Second / Third Demon World: DMZ's raised platforms in each world's palette
//    gomah              Gomah's Cradle, the floating island over the First Demon World (chunk -70, -72)
//  The lair is built when a player first comes near (128 blocks; the big structures from ~330). The boss sleeps at its anchor and wakes
//  when a fighter comes within 32; if nobody is within 64 it heals, goes home and sleeps. Respawn 1 hour.
//  Fight: everyone with a character within 150 blocks is a participant (refreshed every 5 s); boss HP x(1 +
//  0.5 per extra fighter), damage x(1 + 0.25 per extra); 3 lives each - a lethal hit knocks you down
//  instead, an ally crouching within 6 blocks for 15 s revives you at 25% (interrupted by taking 10% max HP);
//  everyone down = wipe. Points = damage dealt + damage received + healing. Rewards: share >= 7.5%,
//  chances x(1 + 25/15/10%) for ranks 1-3, guaranteed amounts x(0.5 + 0.5 x points / best).
//  Results screen (30 min, /rpgc worldboss results), contribution HUD, revive bar, boss music.
//  Tamagami is subdued, not killed: it drops its Demon Realm Dragon Ball and sleeps until its timer is up.
//  Ops: /rpgc worldboss locate|tp|reset|ready|rebuild [boss], /rpgc worldboss summon <boss> (here, no lair).
// =====================================================================================
var DMZ_WB = (function () {
    var CFG = { contributionRange: 150, audienceRefresh: 100, lives: 3, reviveTicks: 300, reviveRange: 6, reviveRestore: 0.25,
        reviveInterrupt: 0.10, truceTicks: 300, minShare: 0.075, rankBonus: [0.25, 0.15, 0.10], guaranteedMin: 0.5,
        healthPerExtra: 0.5, damagePerExtra: 0.25, wake: 32, leash: 64, activation: 128, respawnMs: 3600 * 1000, resultsMs: 30 * 60 * 1000 };
    var OW = "minecraft:overworld", NAMEK = "ragnarok_rpg:namek", OTHER = "ragnarok_rpg:otherworld", DEMON = "ragnarok_rpg:demon_realm";

    function geo(model, tex, scale) { return sagaLook(model, tex || model, scale || 1); }
    // key -> boss: body, stats (saga x hardMode 2.0 x 4.0 HP, x1.5 damage), lair, music, rewards
    var BOSSES = {
        janemba: { name: "Janemba", mob: "wb_janemba_fat", model: "saga_janemba_fat", scale: 8, hp: 8064000, melee: 63180, ki: 57375, speed: 0.14, kb: 1,
            dim: OTHER, kind: "hell", color: "red", sleep: "boss1.sleep", music: "dmzpack:worldboss_music.janemba",
            next: { mob: "wb_super_janemba", name: "Super Janemba", model: "saga_super_janemba", scale: 1.5, hp: 8820000, melee: 69660, ki: 63345, speed: 0.42 },
            rewards: [{ type: "ATTRIBUTES", amount: 500, chance: 1 }, { type: "ITEM", item: "dimensional_sword", count: 1, chance: 0.5 }, { type: "SKILL", skill: "dimensional_teleport", chance: 0.2 }] },
        turles: { name: "Turles", mob: "wb_turles", model: "saga_turles", scale: 1, hp: 87200, melee: 540, ki: 540, speed: 0.3, kb: 0.5,
            dim: OW, kind: "tree", color: "purple", sleep: "boss2.sleep", music: "dmzpack:worldboss_music.turles",
            rewards: [{ type: "ATTRIBUTES", amount: 50, chance: 1 }, { type: "ITEM", item: "might_tree_fruit", count: 1, chance: 0.5 }, { type: "SKILL", skill: "kill_driver", chance: 0.25 }, { type: "SKILL", skill: "meteor_burst", chance: 0.15 }] },
        metal_cooler_core: { name: "Metal Cooler Core", mob: "wb_metal_cooler_core", model: "saga_metal_cooler_core", scale: 6, hp: 640000, melee: 4320, ki: 3615, speed: 0.13, kb: 1,
            dim: NAMEK, kind: "gete", color: "purple", music: "dmzpack:worldboss_music.metal_cooler_core",
            rewards: [{ type: "ATTRIBUTES", amount: 105, chance: 1 }, { type: "SKILL", skill: "supernova_cooler", chance: 0.2 }, { type: "ITEM", item: "gete_ingot", count: 4, chance: 1 },
                { type: "ITEM", item: "gete_red_capsule", count: 1, chance: 0.12 }, { type: "ITEM", item: "gete_purple_capsule", count: 1, chance: 0.12 }, { type: "ITEM", item: "gete_yellow_capsule", count: 1, chance: 0.12 },
                { type: "ITEM", item: "gete_green_capsule", count: 1, chance: 0.12 }, { type: "ITEM", item: "gete_orange_capsule", count: 1, chance: 0.12 }, { type: "ITEM", item: "gete_blue_capsule", count: 1, chance: 0.12 }] },
        tamagami_3: { name: "Tamagami Number 3", mob: "wb_tamagami_3", model: "saga_tamagami_3", scale: 1, hp: 3120000, melee: 73800, ki: 66780, pMelee: 84870, pKi: 76800, speed: 0.3, pSpeed: 0.34, kb: 0.8,
            dim: DEMON, kind: "platform", color: "white", sleep: "tamagami.sleep", music: "dmzpack:worldboss_music.tamagami_3", stars: 3,
            rewards: [{ type: "ATTRIBUTES", amount: 90, chance: 1 }, { type: "ITEM", item: "tamagami_hammer", count: 1, chance: 0.3 }] },
        tamagami_2: { name: "Tamagami Number 2", mob: "wb_tamagami_2", model: "saga_tamagami_2", scale: 1, hp: 12620000, melee: 99450, ki: 89985, pMelee: 114375, pKi: 103485, speed: 0.3, pSpeed: 0.34, kb: 0.6,
            dim: DEMON, kind: "platform", color: "white", sleep: "tamagami.sleep", music: "dmzpack:worldboss_music.tamagami_2", stars: 2,
            rewards: [{ type: "ATTRIBUTES", amount: 300, chance: 1 }, { type: "ITEM", item: "tamagami_trident", count: 1, chance: 0.3 }] },
        tamagami_1: { name: "Tamagami Number 1", mob: "wb_tamagami_1", model: "saga_tamagami_1", scale: 1, hp: 17000000, melee: 133965, ki: 121215, pMelee: 154065, pKi: 139395, speed: 0.3, pSpeed: 0.34, kb: 0.6,
            dim: DEMON, kind: "platform", color: "white", sleep: "tamagami.sleep", music: "dmzpack:worldboss_music.tamagami_1", stars: 1,
            rewards: [{ type: "ATTRIBUTES", amount: 360, chance: 1 }, { type: "ITEM", item: "tamagami_sword", count: 1, chance: 0.3 }] },
        gomah: { name: "Gomah", mob: "wb_gomah", model: "saga_gomah_third_eye", scale: 1, hp: 25292000, melee: 199245, ki: 180315, speed: 0.3, kb: 0.8,
            dim: DEMON, kind: "cradle", color: "red", music: "dmzpack:worldboss_music.gomah",
            rewards: [{ type: "ATTRIBUTES", amount: 435, chance: 1 }, { type: "ITEM", item: "demon_eye", count: 1, chance: 0.02 }] }
    };
    var BY_MOB = {};
    var SESS = {};            // key -> live fight session
    var STATE = null;         // RPG.data "dmz_wb": key -> { x, y, z, built, uuid, next }
    var RESULTS = RPG.data.get("dmz_wb_results", []) || [];

    function state() { if (!STATE) STATE = RPG.data.get("dmz_wb", {}) || {}; return STATE; }
    function saveState() { RPG.data.set("dmz_wb", STATE || {}); }
    function now() { return RPG.server.getTick(); }
    function alive(e) { try { return e && e.isAlive(); } catch (x) { return false; } }
    function fmt(n) { n = Math.round(n); return n >= 1e6 ? (n / 1e6).toFixed(2) + "M" : n >= 1e4 ? (n / 1e3).toFixed(1) + "K" : String(n); }
    function eligible(p) {
        var g = String(p.getGameMode());
        return p.isAlive() && g !== "creative" && g !== "spectator" && p.getVar("dmz_created", 0) && !p.hasTag("dmz_wb_ko");
    }
    function dist2(a, x, z) { var dx = a.x - x, dz = a.z - z; return dx * dx + dz * dz; }
    function dimExists(dim) {
        if (dim.indexOf("ragnarok_rpg:") !== 0) return true;
        // Namek, the Sacred Kai planet and the Demon Realm are data-pack dimensions (85_world.js dbrDimensionExists)
        try { return typeof dbrDimensionExists === "function" ? dbrDimensionExists(dim.substring(13)) : RPG.dimensions.exists(dim.substring(13)); } catch (e) { return false; }
    }

    // ---- bodies (WorldBossEntity / AllWorldBossesEntity) ----
    function defineBody(id, b) {
        BY_MOB[id] = b;
        RPG.mobs.define(id, {
            name: "&4&l" + b.name, geo: geo(b.model, b.tex, b.scale), health: b.hp, damage: b.melee, speed: b.speed, followRange: 64,
            persistent: true, xp: 0, scale: b.scale,
            onDeath: function (m, killer) { onBossDeath(m, killer); }
        });
    }
    Object.keys(BOSSES).forEach(function (k) {
        var b = BOSSES[k];
        b.key = k;
        defineBody(b.mob, b);
        if (b.next) { b.next.key = k; b.next.part = "next"; defineBody(b.next.mob, b.next); }
        if (b.stars) {
            var pw = { key: k, part: "powered", name: b.name + " (Powered Up)", model: b.model, tex: b.model + "_powered", scale: b.scale, hp: b.hp, melee: b.pMelee, ki: b.pKi, speed: b.pSpeed };
            b.powered = pw;
            defineBody(b.mob + "_powered", pw);
        }
    });
    // minions: Mini Janemba (3% of Janemba's stats, speed 0.46), Metal Cooler guardians and copies
    RPG.mobs.define("wb_mini_janemba", { name: "&cMini Janemba", geo: geo("saga_janemba_fat", null, 0.8), health: 241920, damage: 1895, speed: 0.46, followRange: 48, xp: 0 });
    RPG.mobs.define("wb_metal_cooler", { name: "&5Metal Cooler", geo: geo("saga_cooler_5ta", "saga_metal_cooler"), health: 32000, damage: 2600, speed: 0.3, followRange: 48, xp: 0 });
    RPG.mobs.define("wb_metal_cooler_copy", { name: "&5Metal Cooler Copy", geo: geo("saga_cooler_5ta", "saga_metal_cooler", 0.9), health: 6400, damage: 1300, speed: 0.32, followRange: 48, xp: 0 });
    function isBoss(e) { return !!e && !e.isPlayer() && !!BY_MOB[String(e.rpgId || "")]; }
    function isMinion(e) { var r = e && !e.isPlayer() ? String(e.rpgId || "") : ""; return r === "wb_mini_janemba" || r === "wb_metal_cooler" || r === "wb_metal_cooler_copy"; }

    // =========================================================================================
    //  lairs (WorldBossManager / WorldBossLair)
    // =========================================================================================
    //  janemba      WorldBossLair.Janemba: a column 1000 blocks from 0,0 (seeded angle) in Hell; the floor is the first
    //               block under y 92; arena: hell stone / ground floor r16 on a 4-deep deepstone foundation, a rim that
    //               ramps up 7 blocks to r22, 22 blocks of headroom, 18 bone spikes on the rim and 9 inside.
    //  tamagami_N   WorldBossLair.Tamagami: a flat site on the N-th Demon World (seeded, 920 / 760 / 600 blocks out,
    //               rings of 24 blocks), raised 3 blocks: a r15 platform in that world's palette with a r4 dais, 8 floor
    //               lights, 8 pillars (some broken) and four stair ramps.
    //  turles       the Tree of Might (BossStructures.TreeOfMightShape), planned once per world 1000+ blocks from
    //               spawn; Turles sleeps in the clearing (r26) at its foot.
    //  metal_cooler_core  the Big Gete Star (GeteStarShape) on Namek, 1000+ blocks from spawn; the core sits in its chamber.
    //  gomah        Gomah's Cradle (GomahCradleShape): the floating island over the First Demon World at chunk -70,-72.
    //  The three DMZ structures are DMZ's own shapes, rasterized offline (docs/dmz-spec/tools/build_dmz_lairs.py) and placed
    //  piece by piece with RPG.structures.placeGradually (stand-in blocks swapped back for DMZ's).
    var LAIR_V = 2;
    var STRUCT = { turles: "tree_of_might", metal_cooler_core: "gete_star", gomah: "gomah_cradle" };
    var DEMON_BANDS = { 1: { dist: 920, top: 251, bottom: 48 }, 2: { dist: 760, top: 481, bottom: 319 }, 3: { dist: 600, top: 766, bottom: 584 } };
    var CRADLE = { x: -70 * 16 + 8, z: -72 * 16 + 8, minSurface: 118, maxSurface: 136, ceiling: 252 - 24 - 4, clearance: 38, reach: 62 + 34 };
    var LAIR_DATA = {};
    function lairData(name) { if (!LAIR_DATA[name]) LAIR_DATA[name] = RPG.files.read("dmz_lairs/" + name + ".json"); return LAIR_DATA[name]; }

    function seedRng(salt) {
        var seed = typeof dmzWorldSeed === "function" ? dmzWorldSeed() : (RPG.data.get("dmz_world_seed", 12345) || 12345);
        var s = (seed ^ salt) >>> 0;
        return function () { s = (s + 0x6D2B79F5) >>> 0; var t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    }
    var SALTS = { janemba: 0x4A414E45, turles: 0x5455524C, metal_cooler_core: 0x47455445, tamagami_3: 0x54414D33, tamagami_2: 0x54414D32, tamagami_1: 0x54414D31, gomah: 0x474F4D41 };
    function isAir(b) { return b === "minecraft:air" || b === "minecraft:cave_air" || b === "minecraft:void_air"; }
    function isFluid(b) { return b === "minecraft:water" || b === "minecraft:lava" || /_liquid_block$/.test(b); }
    var SOFT = /^minecraft:(short_grass|grass|tall_grass|fern|large_fern|snow|vine|dead_bush|seagrass|tall_seagrass|light|glow_lichen|moss_carpet|.*_flower|dandelion|poppy|.*tulip|azure_bluet|oxeye_daisy|cornflower|allium|blue_orchid|lily_of_the_valley|sweet_berry_bush|.*_sapling|.*_mushroom|lily_pad|sugar_cane|kelp|kelp_plant)$/;
    function blocksRoot(b) { return !isAir(b) && !SOFT.test(b) && !isFluid(b); }      // TreeOfMightWriter.blocksRoot: solid
    function get(dim, x, y, z) { return RPG.world.getBlock(dim, x, y, z); }
    function loadedBox(dim, x, z, r) {
        var ok = true;
        for (var dx = -r; dx <= r + 15; dx += 16) for (var dz = -r; dz <= r + 15; dz += 16) {
            var px = x + Math.min(dx, r), pz = z + Math.min(dz, r);
            if (!RPG.world.isLoaded(dim, px, pz)) { RPG.world.requestChunks(dim, px, pz, 0); ok = false; }
        }
        return ok;
    }

    function lair(k) {
        var st = state(), b = BOSSES[k], L = st[k];
        if (L && L.v === LAIR_V) return L;
        if (!dimExists(b.dim)) return null;
        var old = L;
        L = st[k] = { v: LAIR_V, x: null, y: null, z: null, built: false, uuid: old ? old.uuid : null, next: old ? old.next || 0 : 0, phase: "pick" };
        if (old && old.built && typeof old.x === "number" && old.y !== null) L.oldLair = { x: old.x, y: old.y, z: old.z };   // improvised arena from before
        var r = seedRng(SALTS[k]);
        if (b.kind === "hell") {
            var a = r() * Math.PI * 2;
            L.x = Math.floor(Math.cos(a) * 1000); L.z = Math.floor(Math.sin(a) * 1000); L.phase = "resolve";
        } else if (b.kind === "cradle") {
            L.cx = CRADLE.x; L.cz = CRADLE.z; L.x = CRADLE.x; L.z = CRADLE.z; L.phase = "surface";
        } else if (b.kind === "platform") {
            var band = DEMON_BANDS[b.stars], a2 = r() * Math.PI * 2;
            L.ox = Math.floor(Math.cos(a2) * band.dist); L.oz = Math.floor(Math.sin(a2) * band.dist); L.x = L.ox; L.z = L.oz;
            L.search = { ring: 0, i: 0, offset: r() * Math.PI * 2, best: null, spread: 1e9 }; L.phase = "search";
        } else {
            L.phase = "plan"; L.probes = 0; L.ring = 1000;
        }
        saveState();
        return L;
    }
    function lairCenter(L) { return typeof L.cx === "number" ? { x: L.cx, z: L.cz } : typeof L.x === "number" ? { x: L.x, z: L.z } : null; }

    // ---- one-time cleanup of the improvised arenas older versions built -----------------------------
    function cleanupOld(k, L) {
        var o = L.oldLair, dim = BOSSES[k].dim;
        delete L.oldLair; saveState();
        if (!o || !RPG.edit) return;
        try {
            var reg = { type: "cuboid", x1: o.x - 23, y1: o.y - 4, z1: o.z - 23, x2: o.x + 40, y2: o.y + 45, z2: o.z + 23 };
            RPG.edit.replace(null, dim, reg, "iron_block,polished_deepslate,polished_blackstone,gilded_blackstone,oak_log,oak_leaves,moss_block", "air", { history: false, progress: false });
        } catch (e) { RPG.log("DMZ world boss: old arena cleanup: " + e); }
    }

    // ---- planning the Tree of Might / Big Gete Star sites (StructureSpawnPlanner, MIN_DISTANCE 1000) ----
    function planStep(k, L) {
        var b = BOSSES[k], m = lairData(STRUCT[k]);
        if (!m) return;
        var sp = b.dim === OW ? RPG.world.spawnPoint() : { x: 0, z: 0 }, sx = Number(sp.x) || 0, sz = Number(sp.z) || 0;
        if (!L.pending) {
            var r = seedRng(SALTS[k] + L.probes * 7919), a = r() * Math.PI * 2;
            L.pending = { x: Math.round(sx + Math.cos(a) * L.ring), z: Math.round(sz + Math.sin(a) * L.ring), waits: 0 };
            L.ring = Math.min(4000, L.ring + 64 * (1 + Math.floor(r() * 3)));
        }
        var p = L.pending, probe = typeof dmzProbe === "function" ? dmzProbe(b.dim, p.x, p.z, 96, 96, 3, true) : { n: 9, spread: 0, wet: 0, median: 64 };
        if (probe.n < 9 && ++p.waits < 60) return;
        var score = typeof dmzSiteScore === "function" ? dmzSiteScore("land", probe) : 100;
        L.probes++;
        if (!L.best || score > L.best.score) L.best = { x: p.x, z: p.z, score: score };
        L.pending = null;
        if (score >= 30 || L.probes >= 24) {
            L.cx = L.best.x; L.cz = L.best.z; L.x = L.cx; L.z = L.cz; L.phase = "base";
            RPG.log("[DMZ] world boss " + k + ": " + STRUCT[k] + " planned at " + L.cx + ", " + L.cz);
        }
        saveState();
    }

    // ---- Tamagami platform site search (WorldBossLair.Tamagami.findSite) ---------------------------
    function bandGround(dim, x, z, bottom, top, headroom) {
        if (isAir(get(dim, x, bottom, z))) return null;
        var y = bottom;
        while (y < top && !isAir(get(dim, x, y + 1, z))) y++;
        if (y >= top || isFluid(get(dim, x, y, z))) return null;
        for (var h = 1; h <= headroom; h++) if (!isAir(get(dim, x, y + h, z))) return null;
        return y;
    }
    function nearTunnel(x, z) {
        var T = typeof DR_TUNNELS !== "undefined" ? DR_TUNNELS : { lower: { ox: 700, oz: 450 }, upper: { ox: 0, oz: 0 } }, S = 2048;
        for (var n in T) {
            var dx = ((x - T[n].ox) % S + S) % S, dz = ((z - T[n].oz) % S + S) % S;
            dx = Math.min(dx, S - dx); dz = Math.min(dz, S - dz);
            if (Math.sqrt(dx * dx + dz * dz) < 90 + 10 + 48) return true;
        }
        return false;
    }
    function searchStep(k, L) {
        var b = BOSSES[k], band = DEMON_BANDS[b.stars], s = L.search, dim = b.dim, budget = 3;
        while (budget-- > 0) {
            if (s.ring > 8) {                                    // no flat ground nearby: the flattest one seen
                var best = s.best || { x: L.ox, z: L.oz, y: Math.floor((band.top + band.bottom) / 2) };
                L.x = best.x; L.z = best.z; L.ground = best.y; L.phase = "build"; saveState();
                RPG.log("[DMZ] " + b.name + ": no flat ground, using " + best.x + " " + best.y + " " + best.z);
                return;
            }
            var radius = s.ring * 24, points = s.ring === 0 ? 1 : Math.max(6, Math.ceil(Math.PI * 2 * radius / 24));
            var a = s.offset + Math.PI * 2 * s.i / points, x = L.ox + Math.floor(Math.cos(a) * radius), z = L.oz + Math.floor(Math.sin(a) * radius);
            var skip = nearTunnel(x, z) || (b.stars === 1 && Math.sqrt(Math.pow(x - CRADLE.x, 2) + Math.pow(z - CRADLE.z, 2)) < CRADLE.reach + 15 + 40);
            if (!skip) {
                if (!loadedBox(dim, x, z, 16)) return;               // wait for its chunks
                var g = bandGround(dim, x, z, band.bottom, band.top, 20);
                if (g !== null) {
                    var spread = 0;
                    for (var i = 0; i < 8 && spread < 1e9; i++) {
                        var aa = Math.PI * 2 * i / 8, sg = bandGround(dim, x + Math.floor(Math.cos(aa) * 14), z + Math.floor(Math.sin(aa) * 14), band.bottom, band.top, 4);
                        spread = sg === null ? 1e9 : Math.max(spread, Math.abs(sg - g));
                    }
                    if (spread <= 5) { L.x = x; L.z = z; L.ground = g; L.phase = "build"; saveState(); RPG.log("[DMZ] " + b.name + " lair found at " + x + " " + g + " " + z); return; }
                    if (spread < s.spread) { s.spread = spread; s.best = { x: x, z: z, y: g }; }
                }
            }
            if (++s.i >= points) { s.i = 0; s.ring++; }
            saveState();
        }
    }

    // ---- arenas built in the world, a few columns per tick ------------------------------------------
    var BUILD_QUEUE = [];
    RPG.every(1, function () {
        var t0 = Date.now();
        while (BUILD_QUEUE.length && Date.now() - t0 < 6) { try { BUILD_QUEUE.shift()(); } catch (e) { RPG.log("DMZ world boss arena: " + e); } }
    });
    function bone(dim, x, y, z) { if (isAir(get(dim, x, y, z))) RPG.world.setBlock(dim, x, y, z, "minecraft:bone_block[axis=y]"); }
    function spike(dim, x, baseY, z, height, rnd) {               // WorldBossLair.Janemba.spike
        for (var i = 0; i < height; i++) {
            var w = i < height / 3 ? 1 : 0;
            for (var dx = -w; dx <= w; dx++) for (var dz = -w; dz <= w; dz++) { if (w === 1 && Math.abs(dx) + Math.abs(dz) === 2) continue; bone(dim, x + dx, baseY + i, z + dz); }
            if (i > height / 2 && Math.floor(rnd() * 4) === 0) break;
        }
    }
    function queueJanembaArena(L, done) {                        // WorldBossLair.Janemba.buildArena
        var dim = OTHER, cx = L.x, cz = L.z, baseY = L.ground, R = 16, RIM = 22, HEAD = 22, FOUND = 4, RIMH = 7;
        var rnd = dmzRng ? dmzRng(dmzHash(cx, baseY, cz, 0x4A41)) : Math.random;
        var floor = blockRef("hell_stone"), ground = blockRef("hell_ground"), deep = blockRef("hell_deepstone");
        for (var dz = -RIM; dz <= RIM; dz++) (function (dz) {
            BUILD_QUEUE.push(function () {
                for (var dx = -RIM; dx <= RIM; dx++) {
                    var d = Math.sqrt(dx * dx + dz * dz), x = cx + dx, z = cz + dz;
                    if (d > RIM) continue;
                    if (d <= R) {
                        RPG.world.setBlock(dim, x, baseY, z, Math.floor(rnd() * 4) === 0 ? ground : floor);
                        RPG.world.fill(dim, x, baseY - FOUND, z, x, baseY - 1, z, deep, "keep");
                        RPG.world.fill(dim, x, baseY + 1, z, x, baseY + HEAD, z, "minecraft:air");
                    } else {
                        var wallTop = baseY + Math.ceil((d - R) / (RIM - R) * RIMH);
                        RPG.world.fill(dim, x, baseY - FOUND, z, x, baseY - 1, z, deep, "keep");
                        if (wallTop - 2 >= baseY) RPG.world.fill(dim, x, baseY, z, x, wallTop - 2, z, deep);
                        RPG.world.fill(dim, x, Math.max(baseY, wallTop - 1), z, x, wallTop, z, floor);
                        if (wallTop + 1 <= baseY + HEAD) RPG.world.fill(dim, x, wallTop + 1, z, x, baseY + HEAD, z, "minecraft:air");
                    }
                }
            });
        })(dz);
        BUILD_QUEUE.push(function () {
            for (var i = 0; i < 18; i++) {
                var a = Math.PI * 2 / 18 * i + rnd() * 0.15, rr = RIM - 1 - Math.floor(rnd() * 2);
                var x = cx + Math.floor(Math.cos(a) * rr), z = cz + Math.floor(Math.sin(a) * rr), top = null;
                for (var y = baseY + RIMH + 2; y >= baseY - FOUND; y--) if (!isAir(get(dim, x, y, z))) { top = y; break; }
                if (top !== null) spike(dim, x, top + 1, z, 5 + Math.floor(rnd() * 6), rnd);
            }
            for (var j = 0; j < 9; j++) {
                var a2 = rnd() * Math.PI * 2, r2 = 4 + Math.floor(rnd() * (R - 5)), x2 = cx + Math.floor(Math.cos(a2) * r2), z2 = cz + Math.floor(Math.sin(a2) * r2);
                if (Math.abs(x2 - cx) < 4 && Math.abs(z2 - cz) < 4) continue;
                spike(dim, x2, baseY + 1, z2, 3 + Math.floor(rnd() * 4), rnd);
            }
        });
        BUILD_QUEUE.push(done);
    }
    var PALETTES = {
        1: { base: "demon_rock", accent: "demon_bricks", trim: "red_ash", light: "crimson_crystal", stairs: "demon_brick_stairs" },
        2: { base: "turquoise_rock", accent: "namek_deepslate", trim: "namek_stone", light: "minecraft:sea_lantern", stairs: "namek_deepslate_stairs" },
        3: { base: "makai_stone", accent: "adobe_bricks", trim: "makai_strata_stone", light: "minecraft:shroomlight", stairs: "adobe_stairs" }
    };
    function ref(n) { return n.indexOf(":") >= 0 ? n : blockRef(n); }
    function isSupport(dim, x, y, z) {
        var b = get(dim, x, y, z);
        if (!blocksRoot(b) || /leaves/.test(b)) return false;
        var n = typeof dmzBlockAt === "function" ? DMZ_BLOCK_BY_REF[b] : null;
        return n !== "dark_sea_cloud" && n !== "makai_bush" && !/_leaves$/.test(n || "");
    }
    function fillBelow(dim, x, z, from, ground, block) {               // Tamagami.fillBelow (48 deep at most)
        var y = from;
        while (y >= from - 48 && !(y < ground && isSupport(dim, x, y, z))) y--;
        if (y < from) RPG.world.fill(dim, x, y + 1, z, x, from, z, block);
    }
    function queuePlatform(k, L, done) {                             // WorldBossLair.Tamagami.buildArena
        var b = BOSSES[k], dim = b.dim, P = PALETTES[b.stars], R = 15, RISE = 3, DAIS = 4, CLEAR = 20;
        var cx = L.x, cz = L.z, top = L.ground + RISE, ground = L.ground, rnd = dmzRng(dmzHash(cx, top, cz, 0x54414D));
        var base = ref(P.base), accent = ref(P.accent), trim = ref(P.trim), light = ref(P.light);
        function floorPattern(d, dx, dz) {
            if (d > R - 1.5) return accent;
            if (d > R - 4.5 && d <= R - 3.5) return trim;
            if (d > DAIS + 1.5 && d < R - 4.5 && Math.abs(Math.sin(Math.atan2(dz, dx) * 4)) * d < 0.9) return trim;
            return base;
        }
        for (var dz = -R; dz <= R; dz++) (function (dz) {
            BUILD_QUEUE.push(function () {
                for (var dx = -R; dx <= R; dx++) {
                    var d = Math.sqrt(dx * dx + dz * dz);
                    if (d > R + 0.5) continue;
                    var x = cx + dx, z = cz + dz;
                    RPG.world.fill(dim, x, top + 1, z, x, top + CLEAR, z, "minecraft:air");
                    RPG.world.setBlock(dim, x, top, z, floorPattern(d, dx, dz));
                    fillBelow(dim, x, z, top - 1, ground, d > R - 1.5 ? accent : base);
                }
            });
        })(dz);
        BUILD_QUEUE.push(function () {
            for (var dx = -DAIS; dx <= DAIS; dx++) for (var dz = -DAIS; dz <= DAIS; dz++) {
                var d = Math.sqrt(dx * dx + dz * dz);
                if (d <= DAIS + 0.2) RPG.world.setBlock(dim, cx + dx, top + 1, cz + dz, d > DAIS - 1 ? accent : trim);
            }
            for (var i = 0; i < 8; i++) {
                var a = Math.PI * 2 * i / 8;
                RPG.world.setBlock(dim, cx + Math.round(Math.cos(a) * (R - 4)), top, cz + Math.round(Math.sin(a) * (R - 4)), light);
            }
            // four stair ramps down to the ground, facing the platform
            [["north", 0, -1, "south"], ["east", 1, 0, "west"], ["south", 0, 1, "north"], ["west", -1, 0, "east"]].forEach(function (d) {
                var sideX = -d[2], sideZ = d[1];                        // clockwise of the direction
                for (var step = 1; step <= RISE; step++) {
                    var along = R + step, y = top - step + 1;
                    for (var w = -2; w <= 2; w++) {
                        var x = cx + d[1] * along + sideX * w, z = cz + d[2] * along + sideZ * w;
                        RPG.world.fill(dim, x, y + 1, z, x, y + 4, z, "minecraft:air");
                        if (typeof dmzSet === "function") dmzSet(dim, x, y, z, P.stairs, d[3]); else RPG.world.setBlock(dim, x, y, z, accent);
                        fillBelow(dim, x, z, y - 1, ground, base);
                    }
                }
            });
            for (var j = 0; j < 8; j++) {                               // pillars, a third of them broken
                var a3 = Math.PI * 2 * (j + 0.5) / 8, px = cx + Math.round(Math.cos(a3) * (R - 1.5)), pz = cz + Math.round(Math.sin(a3) * (R - 1.5));
                var broken = Math.floor(rnd() * 3) === 0, h = broken ? 2 + Math.floor(rnd() * 3) : 6 + Math.floor(rnd() * 4);
                [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (o) { RPG.world.setBlock(dim, px + o[0], top + 1, pz + o[1], trim); });
                RPG.world.fill(dim, px, top + 1, pz, px, top + h, pz, accent);
                if (broken) { var f = [[1, 0], [-1, 0], [0, 1], [0, -1]][Math.floor(rnd() * 4)]; RPG.world.setBlock(dim, px + f[0] * 2, top + 1, pz + f[1] * 2, accent); }
                else { RPG.world.setBlock(dim, px, top + h + 1, pz, trim); RPG.world.setBlock(dim, px, top + h + 2, pz, light); }
            }
            RPG.server.players().forEach(function (p) {                // nobody gets buried in the new platform
                if (p.dimension === dim && Math.pow(p.x - cx - 0.5, 2) + Math.pow(p.z - cz - 0.5, 2) <= Math.pow(R + RISE + 1, 2) && p.y >= ground - 2 && p.y < top + 1) p.teleport(p.x, top + 2, p.z);
            });
        });
        BUILD_QUEUE.push(done);
    }

    // ---- the three DMZ structures (pieces placed gradually, then their in-world touches) -------------
    function surfaceFor(x, z) {                                      // TreeOfMightWriter.surfaceFor
        function h(a, b) { var v = Math.imul(a, 73428767) ^ Math.imul(b, 912931); v ^= v >>> 13; v = Math.imul(v, 0x5BD1E995); return v ^ (v >>> 15); }
        var patch = (((h(x >> 2, z >> 2) + (((h(x, z) % 3) + 3) % 3)) % 10) + 10) % 10;
        return patch < 3 ? "minecraft:rooted_dirt" : patch < 6 ? "minecraft:coarse_dirt" : patch < 8 ? "minecraft:mud" : "minecraft:podzol";
    }
    function treeArena(L, m) {                                       // TreeOfMightWriter.shapeArena (before the tree)
        var dim = OW, ax = L.cx + m.arenaX, az = L.cz + m.arenaZ, F = L.arenaFloor, R = 26, REACH = 32;
        for (var dz = -REACH; dz <= REACH; dz++) (function (dz) {
            BUILD_QUEUE.push(function () {
                for (var dx = -REACH; dx <= REACH; dx++) {
                    var d = Math.sqrt(dx * dx + dz * dz), x = ax + dx, z = az + dz;
                    if (d > REACH) continue;
                    var topY = d <= R ? F : F - Math.ceil((d - R) * 0.6);
                    if (d <= R) RPG.world.fill(dim, x, F + 1, z, x, F + 40, z, "minecraft:air");
                    for (var y = topY, depth = 0; depth <= 16; y--, depth++) {
                        var cur = get(dim, x, y, z);
                        if (blocksRoot(cur) && (y < topY || d > R)) break;
                        RPG.world.setBlock(dim, x, y, z, y === topY ? surfaceFor(x, z) : "minecraft:dirt");
                    }
                }
            });
        })(dz);
    }
    function treeFinish(L, m) {                                      // extendBase + placeLights, after the tree
        var dim = OW, wood = blockRef("might_tree_wood");
        var base = m.base || [];
        for (var i = 0; i < base.length; i += 200) (function (i) {
            BUILD_QUEUE.push(function () {
                for (var j = i; j < Math.min(base.length, i + 200); j++) {
                    var x = L.cx + base[j][0], z = L.cz + base[j][1], y = L.base - 9, n = 0;
                    while (n < 48 && !blocksRoot(get(dim, x, y, z))) { y--; n++; }
                    if (n > 0) RPG.world.fill(dim, x, y + 1, z, x, L.base - 9, z, wood);
                }
            });
        })(i);
        var lights = m.lights || [];
        for (var k2 = 0; k2 < lights.length; k2 += 40) (function (k2) {
            BUILD_QUEUE.push(function () {
                for (var j = k2; j < Math.min(lights.length, k2 + 40); j++) {
                    var x = L.cx + lights[j][0], z = L.cz + lights[j][1], top = L.base + 36, g = null;
                    if (!RPG.world.isLoaded(dim, x, z) || blocksRoot(get(dim, x, top, z))) continue;
                    for (var y = top - 1; y >= L.base - 40; y--) if (blocksRoot(get(dim, x, y, z))) { g = y; break; }
                    if (g !== null && isAir(get(dim, x, g + 6, z))) RPG.world.setBlock(dim, x, g + 6, z, "minecraft:light[level=15]");
                }
            });
        })(k2);
    }
    function remapFor(m) {
        var out = {};
        for (var s in m.remap) { var id = blockRef(m.remap[s]); if (id) out[s] = id; }
        return out;
    }
    // A structure job: piece by piece, each once its chunks are loaded. Saved, so a restart resumes it.
    function structStep(k, L) {
        var b = BOSSES[k], m = lairData(STRUCT[k]), job = L.job;
        if (!m || !job) return;
        var t0 = Date.now();
        while (Date.now() - t0 < 5) {
            if (job.i >= m.pieces.length) {
                if (job.last && !RPG.structures.isPlaced(job.last)) return;
                delete L.job; L.phase = "finish"; saveState(); return;
            }
            if (RPG.structures.pendingBlocks() > 60000) return;
            var pc = m.pieces[job.i], x = L.cx + pc[0], z = L.cz + pc[1];
            var ok = true;
            [[0, 0], [31, 0], [0, 31], [31, 31]].forEach(function (o) { if (!RPG.world.isLoaded(b.dim, x + o[0], z + o[1])) { RPG.world.requestChunks(b.dim, x + o[0], z + o[1], 0); ok = false; } });
            if (!ok && ++job.waits < 400) return;
            job.waits = 0;
            var id = RPG.structures.placeGradually(b.dim, pc[2], x, L.base + m.min[1], z, 0, { remap: remapFor(m) });
            if (id) job.last = id;
            job.i++;
            saveState();
        }
    }
    function structBase(k, L) {                                     // ground under the centre: average of 9 samples (r18)
        var b = BOSSES[k], dim = b.dim, sum = 0;
        var pts = [[0, 0]];
        for (var i = 0; i < 8; i++) pts.push([Math.round(Math.cos(i * Math.PI / 4) * 18), Math.round(Math.sin(i * Math.PI / 4) * 18)]);
        for (var j = 0; j < pts.length; j++) {
            var x = L.cx + pts[j][0], z = L.cz + pts[j][1];
            if (!RPG.world.isLoaded(dim, x, z)) { RPG.world.requestChunks(dim, x, z, 1); return null; }
            var sy = RPG.world.surfaceY(dim, x, z);
            if (sy <= -9999) return null;
            sum += sy;
        }
        return Math.floor(sum / pts.length);
    }
    function cradleSurface(L) {                                     // GomahCradleShape.surfaceFor
        var samples = [[0, 0], [40, 0], [-40, 0], [0, 40], [0, -40], [28, 28], [-28, 28], [28, -28], [-28, -28], [70, 0], [-70, 0], [0, 70], [0, -70], [50, 50], [-50, 50], [50, -50], [-50, -50]];
        var g = 64;
        for (var i = 0; i < samples.length; i++) {
            var x = L.cx + samples[i][0], z = L.cz + samples[i][1];
            if (!RPG.world.isLoaded(DEMON, x, z)) { RPG.world.requestChunks(DEMON, x, z, 0); return null; }
            for (var y = CRADLE.ceiling; y > 48; y--) { var bl = get(DEMON, x, y, z); if (isAir(bl) || isFluid(bl)) continue; g = Math.max(g, y); break; }
        }
        return Math.max(CRADLE.minSurface, Math.min(CRADLE.maxSurface, g + CRADLE.clearance));
    }

    // One step of a lair's life: pick -> (search/plan) -> resolve -> build -> ready (WorldBossManager.tickLair)
    function lairStep(k, L, near, inDim) {
        var b = BOSSES[k], m;
        if (L.oldLair) cleanupOld(k, L);
        switch (L.phase) {
            case "search": if (near) searchStep(k, L); return false;
            case "plan": if (inDim) planStep(k, L); return false;
            case "resolve":                                              // Janemba: first block under y 92
                if (!near || !loadedBox(b.dim, L.x, L.z, 22)) return false;
                for (var y = 92; y >= -50; y--) if (!isAir(get(b.dim, L.x, y, L.z))) { L.ground = y; break; }
                if (L.ground === undefined) return false;
                L.phase = "build"; saveState(); return false;
            case "surface":                                              // Gomah: the island's height
                if (!inDim) return false;
                var s = cradleSurface(L);
                if (s === null) return false;
                L.base = s; L.phase = "struct"; saveState(); return false;
            case "base":                                                 // Tree / Gete Star: ground height
                if (!near) return false;
                var bs = structBase(k, L);
                if (bs === null) return false;
                L.base = bs;
                m = lairData(STRUCT[k]);
                if (k === "turles") {
                    var ax = L.cx + m.arenaX, az = L.cz + m.arenaZ;
                    if (!RPG.world.isLoaded(b.dim, ax, az)) { RPG.world.requestChunks(b.dim, ax, az, 1); return false; }
                    L.arenaFloor = RPG.world.surfaceY(b.dim, ax, az) - 1;          // DMZ: max(ground - 1, sea level - 1); flat worlds sit far below 62
                    treeArena(L, m);
                }
                L.phase = "struct"; saveState(); return false;
            case "struct":
                if (!near) return false;
                if (!L.job) { L.job = { i: 0, waits: 0 }; saveState(); RPG.log("[DMZ] building " + STRUCT[k] + " for " + b.name + " at " + L.cx + " " + L.base + " " + L.cz); }
                if (BUILD_QUEUE.length) return false;                     // the tree's clearing first
                structStep(k, L); return false;
            case "finish":
                m = lairData(STRUCT[k]);
                if (k === "turles") { treeFinish(L, m); L.x = L.cx + m.arenaX; L.z = L.cz + m.arenaZ; L.y = L.arenaFloor + 1; }
                else if (k === "metal_cooler_core") { L.x = L.cx + m.core[0]; L.z = L.cz + m.core[2]; L.y = L.base + m.core[1] + 1; L.tp = [L.cx + m.entrance[0], L.base + m.entrance[1] + 1, L.cz + m.entrance[2]]; }
                else if (k === "gomah") { L.x = L.cx + m.anchor[0]; L.z = L.cz + m.anchor[2]; L.y = L.base + m.anchor[1] + 1; L.tp = [L.x, L.y + 1, L.z + 62 - 14]; }
                L.built = true; L.phase = "ready"; saveState();
                RPG.log("[DMZ] " + STRUCT[k] + " for " + b.name + " finished");
                return false;
            case "build":                                                // Janemba / Tamagami arenas
                if (!near || BUILD_QUEUE.length) return false;
                if (!loadedBox(b.dim, L.x, L.z, 24)) return false;
                L.phase = "building"; saveState();
                var fin = function () {
                    if (b.kind === "hell") L.y = L.ground + 1;
                    else { L.y = L.ground + 3 + 2; L.tp = [L.x, L.ground + 3 + 1, L.z + 15 - 3]; }
                    L.built = true; L.phase = "ready"; saveState();
                };
                if (b.kind === "hell") queueJanembaArena(L, fin); else queuePlatform(k, L, fin);
                return false;
            case "building":
                if (!BUILD_QUEUE.length) L.phase = "build";                // interrupted by a restart: build again
                return false;
            case "ready":
                // the lair was broken (its floor block is gone) and nobody is fighting: rebuild the arena
                if (near && !SESS[k] && (b.kind === "hell" || b.kind === "platform") && RPG.world.isLoaded(b.dim, L.x, L.z) && isAir(get(b.dim, L.x, L.y - 1, L.z))) {
                    L.phase = "build"; L.built = false; saveState(); RPG.log("[DMZ] " + b.name + "'s lair floor is gone, rebuilding it");
                    return false;
                }
                return true;
        }
        return false;
    }

    function bossEntity(k) {
        var L = state()[k];
        if (!L || !L.uuid) return null;
        var e = RPG.world.entityByUuid(L.uuid);
        return alive(e) ? e : null;
    }
    function spawnBoss(k, L) {
        var b = BOSSES[k], m = RPG.world.spawnMob(b.dim, b.mob, L.x + 0.5, L.y, L.z + 0.5);
        if (!m) return null;
        L.uuid = String(m.uuid);
        saveState();
        m.setAttributeBase("generic.knockback_resistance", b.kb);
        sleep(k, m);
        RPG.log("[DMZ] world boss " + k + " spawned at " + L.x + " " + L.y + " " + L.z);
        return m;
    }
    function sleep(k, m) {
        var b = BOSSES[k];
        m.addTag("dmz_wb_asleep");
        m.target = null;
        m.setAI(false);
        if (b.stars) { try { m.setRotation(0, 35); } catch (e) { } }        // Tamagami: SLEEP_YAW 0, pitch 35
        if (b.sleep) m.playAnimation(b.sleep);
    }

    // every 20 ticks: lairs near players, respawns, wake / leash (WorldBossManager.tick, WorldBossEntity.tickSleep)
    RPG.every(20, function () {
        var players = RPG.server.players();
        Object.keys(BOSSES).forEach(function (k) {
            var b = BOSSES[k], L = lair(k);
            if (!L) return;
            var c = lairCenter(L);
            var reach = STRUCT[k] ? CFG.activation + 200 : CFG.activation;
            var near = c ? players.filter(function (p) { return p.dimension === b.dim && dist2(p, c.x, c.z) < reach * reach; }) : [];
            try { if (!lairStep(k, L, near.length > 0, players.some(function (p) { return p.dimension === b.dim; }))) return; }
            catch (e) { RPG.log("DMZ world boss lair " + k + ": " + e); return; }
            near = near.filter(function (p) { return dist2(p, L.x, L.z) < CFG.activation * CFG.activation; });
            if (!near.length && !SESS[k]) return;
            var m = bossEntity(k);
            if (!m) {
                if (SESS[k]) return;
                // the saved boss may just not be loaded yet: adopt any body of this boss near the anchor
                var found = RPG.world.entitiesNear(b.dim, L.x, L.y, L.z, 64).filter(function (e) { var mb = BY_MOB[String(e.rpgId || "")]; return mb && mb.key === k && alive(e); })[0];
                if (found) { L.uuid = String(found.uuid); saveState(); return; }
                if (Date.now() < (L.next || 0)) return;
                if (!near.some(function (p) { return dist2(p, L.x, L.z) < 48 * 48; })) return;     // its chunk must be loaded and ticking
                spawnBoss(k, L);
                return;
            }
            var asleep = m.hasTag("dmz_wb_asleep");
            if (asleep) {
                if (Math.abs(m.x - L.x - 0.5) > 4 || Math.abs(m.y - L.y) > 3 || Math.abs(m.z - L.z - 0.5) > 4) m.teleport(L.x + 0.5, L.y, L.z + 0.5);
                if (Date.now() < (L.next || 0)) return;               // subdued (Tamagami): sleeps until its timer is up
                var waker = near.filter(function (p) { return eligible(p) && p.distanceTo(m) <= CFG.wake; })[0];
                if (waker) wake(k, m, waker);
                return;
            }
            var anyone = players.some(function (p) { return p.dimension === b.dim && eligible(p) && p.distanceTo(m) <= CFG.leash; });
            if (!anyone && SESS[k] && !SESS[k].anyKo()) resetBoss(k, m, "reset");
        });
    });

    // =========================================================================================
    //  fight session (WorldBossSession)
    // =========================================================================================
    function Session(k, m) {
        var s = this;
        s.key = k; s.boss = m; s.start = now(); s.part = {}; s.extra = 0; s.dmgMult = 1; s.cds = {}; s.gap = 0; s.flags = {};
        s.anyKo = function () { for (var u in s.part) if (s.part[u].ko) return true; return false; };
    }
    function P(s, p) {
        var u = String(p.uuid), e = s.part[u];
        if (!e) e = s.part[u] = { uuid: u, name: p.name, dmg: 0, recv: 0, heal: 0, lives: CFG.lives, ko: false, aura: String(p.getVar("dmz_aura_color", "") || "#4FC3FF"), inAudience: false };
        return e;
    }
    function points(e) { return e.dmg + e.recv + e.heal; }
    function body(s) { return BY_MOB[String(s.boss.rpgId)] || BOSSES[s.key]; }

    function wake(k, m, waker) {
        m.removeTag("dmz_wb_asleep");
        m.setAI(true);
        m.target = waker;
        var s = SESS[k] = new Session(k, m);
        P(s, waker);
        refreshAudience(s);
        RPG.world.sound(m.dimension, "dmzpack:aura_start", m.x, m.y, m.z, 4, 0.7);
        if (k === "gomah") audience(s).forEach(function (p) { RPG.net.send(p, "dmz_msg", { key: "worldboss.dragonminez.gomah.awake", color: "#FF5555" }); });
    }
    function audience(s) {
        var m = s.boss;
        return RPG.server.players().filter(function (p) { return p.dimension === m.dimension && p.getVar("dmz_created", 0) && p.distanceTo(m) <= CFG.contributionRange; });
    }
    function refreshAudience(s) {
        var m = s.boss, list = audience(s), b = body(s);
        var inside = {};
        list.forEach(function (p) {
            var e = P(s, p);
            inside[e.uuid] = true;
            if (!e.inAudience) { e.inAudience = true; RPG.net.send(p, "dmz_wb_music", { id: BOSSES[s.key].music }); }
        });
        Object.keys(s.part).forEach(function (u) {
            var e = s.part[u];
            if (e.inAudience && !inside[u]) { e.inAudience = false; var p = RPG.server.player(e.name); if (p) { RPG.net.send(p, "dmz_wb_music", { id: "" }); RPG.ui.bossBarRemove("dmz_wb_" + s.key, p); } }
        });
        // group scaling: +50% max HP (fraction kept) and +25% damage per extra engaged fighter
        var engaged = list.filter(function (p) { return !s.part[String(p.uuid)].ko; }).length, extra = Math.max(0, engaged - 1);
        if (extra !== s.extra) {
            var frac = m.health / m.maxHealth;
            m.maxHealth = b.hp * (1 + CFG.healthPerExtra * extra);
            m.health = Math.max(1, m.maxHealth * frac);
            m.setAttributeBase("generic.attack_damage", b.melee * (1 + CFG.damagePerExtra * extra));
            s.extra = extra;
        }
        RPG.ui.bossBar("dmz_wb_" + s.key, { name: "&l" + b.name, color: s.flags.powered ? "red" : BOSSES[s.key].color, style: "10", progress: Math.max(0, m.health / m.maxHealth), players: list });
        sendContribution(s, list);
    }
    function ranking(s) {
        var list = Object.keys(s.part).map(function (u) { return s.part[u]; }).filter(function (e) { return points(e) > 0 || e.inAudience; });
        list.sort(function (a, b) { return points(b) - points(a); });
        return list;
    }
    function sendContribution(s, to, finished) {
        var rank = ranking(s), total = 0;
        rank.forEach(function (e) { total += points(e); });
        var data = { boss: body(s).name, elapsed: now() - s.start, finished: !!finished,
            entries: rank.map(function (e) { return { id: e.uuid, name: e.name, points: points(e), share: total > 0 ? points(e) / total : 0, aura: e.aura, ko: e.ko }; }) };
        (to || audience(s)).forEach(function (p) { RPG.net.send(p, "dmz_wb_contrib", data); });
    }
    function ksMult(s) { return (1 + CFG.damagePerExtra * s.extra) * s.dmgMult; }

    // ---- knock-outs and revives ----
    function knockOut(s, p) {
        var e = P(s, p);
        e.lives--;
        e.ko = true;
        p.addTag("dmz_wb_ko");
        p.health = 1;
        p.setInvulnerable(true);
        p.addEffect("dmz_tech_rooted", 20 * 3600);
        p.addPotion("minecraft:weakness", 20 * 3600, 9);
        p.title("&cYou have been knocked down.", "&7" + Math.max(0, e.lives) + " revives remaining.");
        RPG.world.sound(p.dimension, "dmzpack:knockback_character", p.x, p.y, p.z, 1, 0.8);
        s.boss.target = null;
        var up = audience(s).filter(function (o) { return !s.part[String(o.uuid)].ko; });
        if (!up.length) wipe(s);
    }
    function standUp(s, p, ratio) {
        var e = P(s, p);
        e.ko = false; e.reviver = null; e.rev = 0;
        p.removeTag("dmz_wb_ko");
        p.setInvulnerable(false);
        p.removeEffect("dmz_tech_rooted");
        p.removePotion("minecraft:weakness");
        if (ratio) p.health = Math.max(1, p.maxHealth * ratio);
    }
    function reviveTick(s) {
        Object.keys(s.part).forEach(function (u) {
            var e = s.part[u];
            if (!e.ko) return;
            var p = RPG.server.player(e.name);
            if (!p) return;
            var helper = null;
            if (e.lives > 0) RPG.server.players().forEach(function (o) {
                if (helper || String(o.uuid) === u || !o.isSneaking() || o.dimension !== p.dimension || o.distanceTo(p) > CFG.reviveRange) return;
                var oe = s.part[String(o.uuid)];
                if (oe && oe.ko) return;
                if (oe && oe.lockUntil && now() < oe.lockUntil) return;
                helper = o;
            });
            if (!helper) { if (e.rev) { e.rev = Math.max(0, e.rev - 3); } if (e.reviver) { var old = RPG.server.player(e.reviver); if (old) RPG.net.send(old, "dmz_wb_revive", { casting: false }); e.reviver = null; } return; }
            if (e.reviver !== helper.name) { e.reviver = helper.name; RPG.net.send(p, "dmz_msg", { key: "worldboss.dragonminez.revive.being_revived", args: [helper.name], color: "#B9FFA8" }); }
            e.rev = (e.rev || 0) + 20;
            RPG.net.send(helper, "dmz_wb_revive", { casting: true, target: e.name, progress: Math.min(1, e.rev / CFG.reviveTicks) });
            if (e.rev >= CFG.reviveTicks) {
                standUp(s, p, CFG.reviveRestore);
                RPG.net.send(helper, "dmz_wb_revive", { casting: false });
                RPG.world.particle(p.dimension, "minecraft:happy_villager", p.x, p.y + 1, p.z, 20, 0.5, 0.1);
            }
        });
    }
    function releaseAll(s) {
        Object.keys(s.part).forEach(function (u) {
            var e = s.part[u], p = RPG.server.player(e.name);
            if (!p) return;
            if (e.ko) standUp(s, p, 0.33);
            RPG.net.send(p, "dmz_wb_music", { id: "" });
            RPG.net.send(p, "dmz_wb_revive", { casting: false });
            p.setVar("dmz_wb_truce", Date.now() + CFG.truceTicks * 50);
        });
        RPG.ui.removeBossBar("dmz_wb_" + s.key);
    }
    function wipe(s) {
        audience(s).forEach(function (p) { p.title("&cFight lost", "&7Every fighter has fallen"); p.tell("&4[World Boss]&r Every fighter has fallen. The fight is lost."); });
        resetBoss(s.key, s.boss, "wipe");
    }
    function resetBoss(k, m, why) {
        var s = SESS[k];
        if (s) {
            sendContribution(s, null, true);
            if (why === "reset") audience(s).forEach(function (p) { p.title("&cFight lost", "&7" + body(s).name + " went back to sleep"); p.tell("&6[World Boss]&r The boss went back to sleep. You are back on your feet."); });
            releaseAll(s);
            cleanupMinions(s);
            delete SESS[k];
        }
        var b = BOSSES[k], L = state()[k];
        if (String(m.rpgId) !== b.mob) m.transform(b.mob, { heal: true });
        m.maxHealth = b.hp; m.health = b.hp;
        m.setAttributeBase("generic.attack_damage", b.melee);
        if (L && L.y !== null) m.teleport(L.x + 0.5, L.y, L.z + 0.5);
        sleep(k, m);
    }
    function cleanupMinions(s) {
        var m = s.boss;
        RPG.world.entitiesNear(m.dimension, m.x, m.y, m.z, 96).forEach(function (e) { if (isMinion(e) && e.hasTag("dmz_wb_" + s.key)) e.remove(); });
    }

    // ---- victory and rewards (WorldBossRewards.grantAndBuild) ----
    function onBossDeath(m, killer) {
        var b = BY_MOB[String(m.rpgId)];
        if (!b) return;
        var k = b.key, s = SESS[k];
        if (!s || String(s.boss.uuid) !== String(m.uuid)) {
            var L0 = state()[k];
            if (L0 && L0.uuid === String(m.uuid)) { L0.uuid = null; L0.next = Date.now() + CFG.respawnMs; saveState(); }
            return;
        }
        victory(k, s, m);
        var L = state()[k];
        if (L) { L.uuid = null; L.next = Date.now() + CFG.respawnMs; saveState(); }
    }
    // Tamagami is never killed (Tamagami.subdue): the lethal hit on its powered form ends the fight, it drops its Demon
    // Dragon Ball in front of the dais, turns back to its base form, goes home and sleeps until the respawn timer is up.
    function subdue(k, s, m) {
        var root = BOSSES[k], L = state()[k];
        victory(k, s, m);
        m.setAI(false);
        m.transform(root.mob, { heal: true });
        m.maxHealth = root.hp; m.health = root.hp;
        m.setAttributeBase("generic.attack_damage", root.melee);
        if (L && L.y !== null) m.teleport(L.x + 0.5, L.y, L.z + 0.5);
        sleep(k, m);
        if (L) { L.uuid = String(m.uuid); L.next = Date.now() + CFG.respawnMs; saveState(); }
        // the ball: 2.5 blocks in front of the anchor (SLEEP_YAW 0 faces +z), as a tracked Dragon Ball block
        var bx = Math.floor((L ? L.x : m.x) + 0.5), by = Math.floor(L ? L.y : m.y), bz = Math.floor((L ? L.z : m.z) + 0.5 + 2.5);
        var placed = false;
        if (typeof dbrPlaceDragonBall === "function" && isAir(get(m.dimension, bx, by, bz))) placed = dbrPlaceDragonBall("demon", root.stars, m.dimension, bx, by, bz);
        if (!placed) RPG.world.dropItem(m.dimension, bx + 0.5, by + 0.5, bz + 0.5, "dball" + root.stars + "_demon", 1);
        RPG.world.particle(m.dimension, "minecraft:end_rod", bx + 0.5, by + 1, bz + 0.5, 40, 0.3, 0.08);
        RPG.world.sound(m.dimension, "minecraft:block.beacon.activate", bx + 0.5, by + 1, bz + 0.5, 2, 1.4);
        RPG.server.players().forEach(function (p) {
            if (p.dimension === m.dimension && p.distanceTo(m) <= CFG.leash) p.tell("&6" + root.name + " dropped the " + root.stars + "-Star Demon Realm Dragon Ball!");
        });
    }
    function victory(k, s, m) {
        var rank = ranking(s), best = rank.length ? Math.max(1e-6, points(rank[0])) : 1, total = 0;
        rank.forEach(function (e) { total += points(e); });
        var res = { boss: BOSSES[k].name, key: k, at: Date.now(), duration: now() - s.start, players: [] };
        rank.forEach(function (e, i) {
            var share = total > 0 ? points(e) / total : 0, got = [], chances = [];
            var p = RPG.server.player(e.name);
            BOSSES[k].rewards.forEach(function (r) {
                var guaranteed = r.chance >= 1, ch = guaranteed ? 1 : Math.min(1, r.chance * (1 + (CFG.rankBonus[i] || 0)));
                var amountMult = guaranteed ? Math.max(CFG.guaranteedMin, CFG.guaranteedMin + (1 - CFG.guaranteedMin) * points(e) / best) : 1;
                var line = { label: rewardLabel(r), chance: share >= CFG.minShare ? ch : 0, guaranteed: guaranteed, got: false };
                if (share >= CFG.minShare && Math.random() < ch) { line.got = true; if (p) giveReward(p, r, amountMult); }
                chances.push(line);
            });
            res.players.push({ id: e.uuid, name: e.name, points: points(e), share: share, dmg: e.dmg, recv: e.recv, heal: e.heal, aura: e.aura, rewards: chances });
            if (p) {
                var title = BOSSES[k].name + " defeated!";
                p.title("&6" + title, i === 0 ? "&eMVP! You carried " + Math.round(share * 100) + "% of the fight" : points(e) > 0 ? "&7You finished #" + (i + 1) + " with " + Math.round(share * 100) + "% of the contribution" : "&7Thanks for showing up");
            }
        });
        RESULTS = RESULTS.filter(function (r) { return Date.now() - r.at < CFG.resultsMs; });
        RESULTS.unshift(res);
        RESULTS = RESULTS.slice(0, 8);
        RPG.data.set("dmz_wb_results", RESULTS);
        sendContribution(s, null, true);
        releaseAll(s);
        cleanupMinions(s);
        delete SESS[k];
        rank.forEach(function (e) {
            var p = RPG.server.player(e.name);
            if (!p) return;
            RPG.net.send(p, "dmz_wb_music", { id: "dmzpack:menu_music_12", once: true });
            RPG.net.send(p, "dmz_wb_results", res);
        });
    }
    function rewardLabel(r) {
        if (r.type === "ATTRIBUTES") return r.amount + " Attribute Points";
        if (r.type === "ITEM") return (r.count || 1) + "x " + (RPG.items.exists(r.item) ? RPG.items.name(r.item) : r.item);
        if (r.type === "SKILL") return "Technique: " + r.skill;
        return r.type;
    }
    function giveReward(p, r, mult) {
        if (r.type === "ATTRIBUTES") {                 // StatsData.grantAttributeReward (same as quest ATTRIBUTES)
            var attrs = Math.round(r.amount * mult), pts = Math.floor(attrs * 0.5);
            if (pts > 0) p.setStatPoints(p.getStatPoints() + pts);
            try {
                var c = DMZ_DATA.CLASSES[p.playerClass] || DMZ_DATA.CLASSES.warrior;
                var tp = DMZ_F.cost(DMZ_F.total(dmzView(p)) + p.getStatPoints(), attrs - pts, c.tpCost);
                if (tp > 0) p.addTp(tp, { raw: true, events: false, source: "boss" });
            } catch (e) { }
            return;
        }
        if (r.type === "ITEM") { if (RPG.items.exists(r.item)) p.giveItem(r.item, Math.max(1, Math.round((r.count || 1) * mult))); else p.tell("&7(" + r.item + " is not in this game)"); return; }
        if (r.type === "SKILL" && typeof DMZ_TECH !== "undefined") DMZ_TECH.unlock(p, r.skill, { source: "worldboss" });
    }

    // =========================================================================================
    //  abilities (AllWorldBossesEntity) - each boss has a set; one fires per ability gap
    // =========================================================================================
    function players(s, r) { var m = s.boss; return audience(s).filter(function (p) { return !s.part[String(p.uuid)] || !s.part[String(p.uuid)].ko ? p.distanceTo(m) <= (r || 64) : false; }); }
    function melee(s) { return body(s).melee * ksMult(s); }
    function ki(s) { return body(s).ki * ksMult(s); }
    function hurt(s, x, y, z, r, dmg, push, up) {
        var m = s.boss;
        players(s, 200).forEach(function (p) {
            var dx = p.x - x, dy = p.y - y, dz = p.z - z;
            if (dx * dx + dy * dy + dz * dz > r * r) return;
            p.damageFrom(dmg, m, { kind: "ki", ignoreIFrames: true, knockback: 0 });
            if (push || up) { var l = Math.sqrt(dx * dx + dz * dz) || 1; p.push(dx / l * (push || 0), up || 0.3, dz / l * (push || 0)); }
        });
    }
    function ring(dim, x, y, z, r, particle) {
        for (var i = 0; i < 24; i++) { var a = i / 24 * Math.PI * 2; RPG.world.particle(dim, particle || "minecraft:flame", x + Math.cos(a) * r, y + 0.2, z + Math.sin(a) * r, 1, 0, 0); }
    }
    function telegraph(s, x, y, z, r, ticks, then, particle) {
        var m = s.boss, n = Math.max(1, Math.floor(ticks / 5));
        for (var i = 0; i < n; i++) RPG.schedule(i * 5, function () { if (alive(m)) ring(m.dimension, x, y, z, r, particle); });
        RPG.schedule(ticks, function () { if (alive(m) && SESS[s.key] === s) then(); });
    }
    function ball(s, t, proj, size, dmg, colors, home) {
        var m = s.boss, ey = m.y + Math.max(1.6, (body(s).scale || 1) * 1.4);
        var dx = t.x - m.x, dy = t.y + 1 - ey, dz = t.z - m.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
        var p = RPG.world.shootFrom(m.dimension, m.x, ey, m.z, dx / l, dy / l, dz / l, proj, { size: size, colors: colors, damage: proj === "dmz_tech_ball" ? 0 : dmg, speed: 0.9, lifetime: 100 }, m);
        if (p && proj === "dmz_tech_ball") { p.setVar("dmg", dmg); p.setVar("r", Math.max(3, size * 1.5)); }
        if (p && home) p.homeAt(t, 0.12, 60);
        return p;
    }
    function behind(m, t, d) { var yaw = t.yaw * Math.PI / 180; m.teleport(t.x + Math.sin(yaw) * d, t.y, t.z - Math.cos(yaw) * d); m.lookAt(t.x, t.eyeY, t.z); }
    var PURPLE = { core: "#E9C7FF", border: "#A63EF0", outline: "#4A0B73" }, RED = { core: "#FFD0D0", border: "#C22948", outline: "#5A0010" }, GOLD = { core: "#FFF6A8", border: "#FFD700", outline: "#C89B00" };
    function A(id, cd, first, fn, range) { return { id: id, cd: cd, first: first || 0, run: fn, range: range || 64 }; }
    var ABILITIES = {
        wb_janemba_fat: [
            A("roar", 225, 60, function (s, t) { var m = s.boss; m.playAnimation("boss1.special2"); hurt(s, m.x, m.y, m.z, 14, melee(s) * 0.6, 2.2, 0.5); RPG.world.sound(m.dimension, "dmzpack:vegeta_oozaru_growl", m.x, m.y, m.z, 4, 0.6); }),
            A("dimensional_punch", 125, 40, function (s, t) { var x = t.x, y = t.y, z = t.z; RPG.world.particle(t.dimension, "minecraft:portal", x, y + 1, z, 40, 0.8, 0.4); telegraph(s, x, y, z, 3.5, 15, function () { hurt(s, x, y + 1, z, 3.5, ki(s) * 1.75, 1.2, 0.4); RPG.world.particle(t.dimension, "minecraft:explosion", x, y + 1, z, 1, 0, 0); }, "minecraft:portal"); }),
            A("destruction_balls", 200, 80, function (s, t) { for (var i = 0; i < 3; i++) (function (k) { RPG.schedule(k * 8, function () { if (alive(t)) ball(s, t, "dmz_tech_ball", 3, ki(s) * 1.75 / 3, PURPLE, true); }); })(i); s.boss.playAnimation("boss1.special3"); }),
            A("blaster_meteor", 400, 200, function (s, t) { meteorRain(s, t, GOLD, 100); }),
            A("stomp", 600, 120, function (s, t) { var m = s.boss, x = m.x, y = m.y, z = m.z; m.push(0, 1.4, 0); telegraph(s, x, y, z, 14, 62, function () { hurt(s, x, y, z, 14, melee(s) * 2.0, 1.5, 0.9); RPG.world.particle(m.dimension, "minecraft:explosion_emitter", x, y, z, 3, 4, 0); RPG.world.sound(m.dimension, "dmzpack:anchor_slam", x, y, z, 5, 0.6); }); }, 26),
            A("gum_punch", 100, 20, function (s, t) { var m = s.boss; if (m.distanceTo(t) > 12) return false; m.playAnimation("attack1_1"); RPG.schedule(10, function () { if (alive(t) && m.distanceTo(t) < 14) t.damageFrom(melee(s) * 1.5, m, { kind: "melee", ignoreIFrames: true, knockback: 2 }); }); }, 12)
        ],
        wb_super_janemba: [
            A("roar", 200, 60, function (s, t) { var m = s.boss; hurt(s, m.x, m.y, m.z, 12, melee(s) * 0.6, 2.2, 0.5); RPG.world.sound(m.dimension, "dmzpack:vegeta_oozaru_growl", m.x, m.y, m.z, 4, 0.8); }),
            A("mouth_blast", 260, 80, function (s, t) {
                var m = s.boss; m.playAnimation("grab_ki"); telegraph(s, t.x, t.y, t.z, 5, 37, function () {
                    var p = ball(s, t, "dmz_tech_wave", 1.6, 0, { core: "#FFD0D8", border: "#C22948", outline: "#8C1B32" });
                    if (p) { p.setVar("dmg", ki(s) * 1.5); p.setVar("hits", 2); p.setVar("r", 5); }
                }, "minecraft:soul_fire_flame"); }),
            A("destruction_balls", 240, 120, function (s, t) { for (var i = 0; i < 3; i++) (function (k) { RPG.schedule(k * 8, function () { if (alive(t)) ball(s, t, "dmz_tech_ball", 2, ki(s) * 1.75 / 3, PURPLE, true); }); })(i); }),
            A("warp", 120, 40, function (s, t) { var m = s.boss; RPG.world.particle(m.dimension, "minecraft:portal", m.x, m.y + 1, m.z, 40, 0.6, 0.4); behind(m, t, 2); RPG.world.sound(m.dimension, "dmzpack:zanzoken", m.x, m.y, m.z, 2, 0.8); }),
            A("cuts", 340, 160, function (s, t) {
                var m = s.boss; m.playAnimation("attack3_1");
                for (var i = 0; i < 6; i++) (function (k) {
                    RPG.schedule(10 + k * 12, function () {
                        if (!alive(m) || !alive(t) || SESS[s.key] !== s) return;
                        var x1 = m.x, z1 = m.z, dx = t.x - x1, dz = t.z - z1, l = Math.sqrt(dx * dx + dz * dz) || 1, len = Math.min(48, l + 6);
                        var x2 = x1 + dx / l * len, z2 = z1 + dz / l * len;
                        RPG.world.particleLine(m.dimension, "minecraft:crimson_spore", x1, t.y + 1, z1, x2, t.y + 1, z2, 0.5);
                        players(s, 64).forEach(function (p) {          // distance from the slash line
                            var px = p.x - x1, pz = p.z - z1, proj = (px * dx + pz * dz) / l;
                            if (proj < 0 || proj > len) return;
                            var ox = px - dx / l * proj, oz = pz - dz / l * proj;
                            if (ox * ox + oz * oz <= 7.8 * 7.8 / 4) p.damageFrom(melee(s) * 0.6, m, { kind: "melee", ignoreIFrames: true });
                        });
                        RPG.world.sound(m.dimension, "dmzpack:katana_slash", t.x, t.y, t.z, 2, 0.8);
                    });
                })(i); })
        ],
        wb_turles: [
            A("might_fruit", 1800, 900, function (s, t) { var m = s.boss; m.playAnimation("ki_ball"); s.dmgMult = 1.5; s.flags.fruitUntil = now() + 600; RPG.world.particle(m.dimension, "minecraft:totem_of_undying", m.x, m.y + 1, m.z, 40, 0.5, 0.3); RPG.world.sound(m.dimension, "minecraft:entity.generic.eat", m.x, m.y, m.z, 2, 0.8); }),
            A("kill_driver", 380, 100, function (s, t) { var m = s.boss, d = m.distanceTo(t); if (d < 6 || d > 40) return false; m.playAnimation("ki_ball"); RPG.schedule(20, function () { var p = ball(s, t, "dmz_tech_disk", 2.4, ki(s) * 1.75, GOLD, true); if (p) { p.setVar("boom", 1); p.setVar("r", 5.5); p.setVar("dmg", ki(s) * 1.75); } }); }),
            A("meteor_burst", 900, 400, function (s, t) {
                var m = s.boss; if (m.distanceTo(t) > 20) return false; behind(m, t, 1.5); m.playAnimation("combo2");
                for (var i = 0; i < 6; i++) (function (k) { RPG.schedule(4 + k * 6, function () { if (alive(t) && alive(m) && m.distanceTo(t) < 6) t.damageFrom(melee(s) * 3.05 / 6, m, { kind: "melee", ignoreIFrames: true, knockback: k === 5 ? 2 : 0.1 }); }); })(i);
                RPG.schedule(40, function () { if (alive(t)) hurt(s, t.x, t.y + 1, t.z, 4, ki(s) * 1.6, 1, 0.5); });
            }, 20),
            A("grab", 260, 60, function (s, t) {
                var m = s.boss, d = m.distanceTo(t); if (d > 8) return false;
                m.teleport(t.x, t.y, t.z + 1); t.addPotion("minecraft:slowness", 56, 10); m.playAnimation("grab_horns");
                RPG.schedule(50, function () { if (alive(t) && alive(m)) { t.damageFrom(melee(s) * 1.6, m, { kind: "melee", ignoreIFrames: true, knockback: 2.5 }); t.push(0, 0.8, 0); } });
            }, 8),
            A("volley", 120, 30, function (s, t) { var m = s.boss; m.playAnimation("ki_blast"); for (var i = 0; i < 8; i++) (function (k) { RPG.schedule(k * 2, function () { if (alive(t)) ball(s, t, "dmz_tech_bullet", 0.5, ki(s) * 1.25 / 8, GOLD, false); }); })(i); })
        ],
        wb_metal_cooler_core: [
            A("orbital_lasers", 340, 80, function (s, t) {
                for (var w = 0; w < 3; w++) (function (k) {
                    RPG.schedule(k * 25, function () {
                        players(s, 64).slice(0, 5).concat([]).forEach(function (p, i) {
                            if (i >= 5) return;
                            var x = p.x + (Math.random() - 0.5) * 4, z = p.z + (Math.random() - 0.5) * 4, y = p.y;
                            telegraph(s, x, y, z, 4, 30, function () { RPG.world.particleLine(p.dimension, "minecraft:end_rod", x, y + 30, z, x, y, z, 0.4); hurt(s, x, y + 1, z, 4, ki(s) * 0.9, 0.5, 0.2); RPG.world.sound(p.dimension, "dmzpack:laserbeam", x, y, z, 2, 0.6); }, "minecraft:electric_spark");
                        });
                    });
                })(w); }),
            A("cables", 500, 200, function (s, t) {
                var m = s.boss, list = players(s, 40).slice(0, 3);
                list.forEach(function (p) {
                    var x = p.x, y = p.y, z = p.z;
                    telegraph(s, x, y, z, 5, 30, function () {
                        players(s, 64).forEach(function (q) { if (q.distanceTo(m) < 200 && Math.abs(q.x - x) < 5 && Math.abs(q.z - z) < 5) { q.addPotion("minecraft:slowness", 44, 10); q.damageFrom(melee(s) * 0.5, m, { kind: "melee", ignoreIFrames: true }); RPG.world.particleLine(q.dimension, "minecraft:crit", m.x, m.y + 4, m.z, q.x, q.y + 1, q.z, 0.6); } });
                    }, "minecraft:crit");
                }); }),
            A("supernova", 1200, 200, function (s, t) {
                var m = s.boss, colors = { core: "#FF3866", border: "#A3143A", outline: "#4A0316" };
                RPG.world.sound(m.dimension, "dmzpack:ki_supernova_charge", m.x, m.y, m.z, 4, 0.8);
                var heal = RPG.every(20, function () { if (!alive(m)) return; RPG.world.entitiesNear(m.dimension, m.x, m.y, m.z, 64).forEach(function (e) { var r = String(e.rpgId || ""); if (r === "wb_metal_cooler") e.heal(e.maxHealth * 0.003); if (r === "wb_metal_cooler_copy") e.heal(e.maxHealth * 0.001); }); });
                for (var i = 0; i < 10; i++) RPG.schedule(i * 20, function () { if (alive(m)) RPG.world.particle(m.dimension, "minecraft:flame", m.x, m.y + 14, m.z, 30, 1 + i * 0.3, 0.02); });
                RPG.schedule(200, function () { RPG.cancel(heal); var tt = m.target && alive(m.target) ? m.target : t; if (alive(m) && alive(tt) && SESS[s.key] === s) { var p = ball(s, tt, "dmz_tech_ball", 8, ki(s) * 2.0, colors, false); if (p) p.setVar("endBoom", 1); RPG.world.sound(m.dimension, "dmzpack:ki_supernova_fire", m.x, m.y, m.z, 4, 0.8); } });
            }),
            A("guardians", 600, 40, function (s, t) {
                var m = s.boss, have = RPG.world.entitiesNear(m.dimension, m.x, m.y, m.z, 64).filter(function (e) { return String(e.rpgId || "") === "wb_metal_cooler"; }).length;
                for (var i = have; i < 3; i++) minion(s, "wb_metal_cooler", 8, t);
            }),
            A("blaster_meteor", 420, 160, function (s, t) { meteorRain(s, t, PURPLE, 30); })
        ],
        tamagami: [
            A("hammer_throw", 260, 60, function (s, t) { var m = s.boss; m.playAnimation("ki_ball"); RPG.schedule(10, function () { if (alive(t)) ball(s, t, "dmz_tech_disk", 1.6, melee(s) * 1.4, { core: "#E6F7FF", border: "#4FC3F7" }, true); }); }),
            A("slam", 200, 40, function (s, t) { var m = s.boss; if (m.distanceTo(t) > 10) return false; var x = t.x, y = t.y, z = t.z; m.playAnimation("attack1_1"); telegraph(s, x, y, z, 6, 20, function () { hurt(s, x, y, z, 6, melee(s) * 1.6, 1.4, 0.6); RPG.world.particle(m.dimension, "minecraft:explosion", x, y, z, 3, 2, 0); }); }, 10),
            A("lunge", 200, 100, function (s, t) { var m = s.boss, dx = t.x - m.x, dz = t.z - m.z, l = Math.sqrt(dx * dx + dz * dz) || 1; m.setVelocity(dx / l * 2, 0.2, dz / l * 2); RPG.schedule(8, function () { if (alive(t) && m.distanceTo(t) < 5) t.damageFrom(melee(s) * 1.3, m, { kind: "melee", ignoreIFrames: true, knockback: 2 }); }); }),
            A("gale", 500, 300, function (s, t) { var m = s.boss; players(s, 20).forEach(function (p) { var dx = p.x - m.x, dz = p.z - m.z, l = Math.sqrt(dx * dx + dz * dz) || 1; p.push(dx / l * 2.5, 0.6, dz / l * 2.5); p.damageFrom(ki(s) * 0.8, m, { kind: "ki", ignoreIFrames: true }); }); RPG.world.particle(m.dimension, "minecraft:cloud", m.x, m.y + 1, m.z, 80, 4, 0.4); }),
            A("flash", 150, 80, function (s, t) { var m = s.boss; behind(m, t, 1.5); RPG.schedule(4, function () { if (alive(t) && m.distanceTo(t) < 4) t.damageFrom(melee(s) * 1.2, m, { kind: "melee", ignoreIFrames: true }); }); RPG.world.sound(m.dimension, "dmzpack:zanzoken", m.x, m.y, m.z, 2, 1); })
        ],
        wb_gomah: [
            A("great_sphere", 500, 200, function (s, t) { var m = s.boss; m.playAnimation("ki_ball"); for (var i = 0; i < 5; i++) RPG.schedule(i * 20, function () { if (alive(m)) RPG.world.particle(m.dimension, "minecraft:dragon_breath", m.x, m.y + 6, m.z, 30, 1.5, 0.02); }); RPG.schedule(110, function () { var tt = m.target && alive(m.target) ? m.target : t; if (alive(m) && alive(tt) && SESS[s.key] === s) { var p = ball(s, tt, "dmz_tech_ball", 6, ki(s) * 2, RED, false); if (p) p.setVar("endBoom", 1); } }); }),
            A("quake", 300, 80, function (s, t) { var m = s.boss, x = m.x, y = m.y, z = m.z; telegraph(s, x, y, z, 10, 30, function () { hurt(s, x, y, z, 10, melee(s) * 1.5, 1.2, 0.8); RPG.world.particle(m.dimension, "minecraft:explosion_emitter", x, y, z, 2, 3, 0); }); }),
            A("eye_beam", 260, 60, function (s, t) { var m = s.boss; m.playAnimation("grab_ki"); RPG.schedule(30, function () { var tt = m.target && alive(m.target) ? m.target : t; if (alive(tt)) { var p = ball(s, tt, "dmz_tech_beam", 0.8, 0, RED, false); if (p) { p.setVar("dmg", ki(s) * 1.5); p.setVar("hits", 2); } } }); }),
            A("evil_eye", 400, 160, function (s, t) { t.addPotion("minecraft:blindness", 60, 0); t.addPotion("minecraft:slowness", 60, 2); RPG.world.particle(t.dimension, "minecraft:witch", t.x, t.y + 1, t.z, 30, 0.5, 0.1); }),
            A("demon_grab", 300, 120, function (s, t) { var m = s.boss; t.teleport(m.x + 1, m.y, m.z); t.addPotion("minecraft:slowness", 40, 10); RPG.schedule(30, function () { if (alive(t)) t.damageFrom(melee(s) * 1.6, m, { kind: "melee", ignoreIFrames: true, knockback: 2.5 }); }); })
        ]
    };
    function meteorRain(s, t, colors, charge) {
        var m = s.boss, cx = t.x, cy = t.y, cz = t.z;
        m.playAnimation("ki_ball");
        for (var w = 0; w < 5; w++) (function (k) {
            RPG.schedule(charge + k * 10, function () {
                if (!alive(m) || SESS[s.key] !== s) return;
                for (var j = 0; j < 4; j++) {
                    var a = Math.random() * Math.PI * 2, r = Math.random() * 7;
                    var p = RPG.world.shootFrom(m.dimension, cx + Math.cos(a) * r, cy + 20, cz + Math.sin(a) * r, 0, -1, 0, "dmz_tech_ball", { size: 1.2, colors: colors, damage: 0, speed: 1.2, lifetime: 40 }, m);
                    if (p) { p.setVar("dmg", ki(s) * 1.75 / 8); p.setVar("r", 3); }
                }
            });
        })(w);
    }
    function minion(s, id, r, t) {
        var m = s.boss, a = Math.random() * Math.PI * 2, e = RPG.world.spawnMob(m.dimension, id, m.x + Math.cos(a) * r, m.y + 0.5, m.z + Math.sin(a) * r);
        if (!e) return null;
        e.addTag("dmz_wb_" + s.key);
        if (t) e.target = t;
        return e;
    }
    function abilityList(s) {
        var id = String(s.boss.rpgId);
        if (ABILITIES[id]) return ABILITIES[id];
        if (id.indexOf("wb_tamagami") === 0) return ABILITIES.tamagami;
        return [];
    }

    // ---- per-session ticking (5 ticks): abilities, phases, revives, audience ----
    RPG.every(5, function () {
        var tk = now();
        Object.keys(SESS).forEach(function (k) {
            var s = SESS[k], m = s.boss;
            try {
                if (!alive(m)) { if (SESS[k] === s) { releaseAll(s); delete SESS[k]; } return; }
                if ((tk - s.start) % CFG.audienceRefresh < 5) refreshAudience(s);
                else RPG.ui.bossBarProgress("dmz_wb_" + k, Math.max(0, m.health / m.maxHealth));
                if ((tk - s.start) % 20 < 5) reviveTick(s);
                if (s.flags.fruitUntil && tk > s.flags.fruitUntil) { s.flags.fruitUntil = 0; s.dmgMult = s.flags.overloadUntil ? 2.5 : 1; }
                if (s.flags.overloadUntil && tk > s.flags.overloadUntil) { s.flags.overloadUntil = 0; s.dmgMult = 1; }
                phases(s, tk);
                var t = m.target;
                if (!t || !alive(t) || t.hasTag("dmz_wb_ko")) {
                    var pick = players(s, CFG.leash).filter(function (p) { return eligible(p); })[0];
                    if (pick) { m.target = pick; t = pick; } else return;
                }
                if (tk < s.gap) return;
                var list = abilityList(s), d = m.distanceTo(t);
                for (var i = 0; i < list.length; i++) {
                    var ab = list[i], ready = s.cds[ab.id] === undefined ? s.start + ab.first : s.cds[ab.id];
                    if (tk < ready || d > ab.range) continue;
                    var cdm = s.flags.powered ? 0.75 : 1;
                    if (ab.run(s, t) === false) continue;
                    s.cds[ab.id] = tk + Math.round(ab.cd * cdm);
                    s.gap = tk + 45;
                    break;
                }
            } catch (err) { RPG.log("DMZ world boss " + k + ": " + err); }
        });
    });
    function phases(s, tk) {
        var m = s.boss, f = m.health / m.maxHealth, id = String(m.rpgId);
        if (id === "wb_janemba_fat") {
            [0.8, 0.6].forEach(function (at) {
                if (f <= at && !s.flags["mini" + at]) { s.flags["mini" + at] = true; for (var i = 0; i < 10; i++) minion(s, "wb_mini_janemba", 6 + Math.random() * 6, m.target); RPG.world.sound(m.dimension, "dmzpack:vegeta_oozaru_growl", m.x, m.y, m.z, 4, 1.4); }
            });
        }
        if (id === "wb_metal_cooler_core") {
            [0.7, 0.35].forEach(function (at) {
                if (f <= at && !s.flags["ol" + at]) { s.flags["ol" + at] = true; s.flags.overloadUntil = tk + 240; s.dmgMult = 2.5; RPG.world.particle(m.dimension, "minecraft:electric_spark", m.x, m.y + 6, m.z, 80, 3, 0.3); }
            });
            if (f <= 0.7 && !s.flags.copies1) { s.flags.copies1 = true; for (var i = 0; i < 8; i++) minion(s, "wb_metal_cooler_copy", 10, m.target); }
            if (f <= 0.15 && !s.flags.copies2) { s.flags.copies2 = true; for (var j = 0; j < 6; j++) minion(s, "wb_metal_cooler_copy", 10, m.target); }
        }
        if (id === "wb_gomah") {                      // Demon Eye stacks: +30% damage each, every 400 t, max 5
            if (!s.flags.eyeAt) s.flags.eyeAt = tk + 400;
            if (tk >= s.flags.eyeAt) {
                s.flags.eyeAt = tk + 400;
                s.flags.eye = Math.min(5, (s.flags.eye || 0) + 1);
                s.dmgMult = 1 + 0.3 * s.flags.eye;
                audience(s).forEach(function (p) { RPG.net.send(p, "dmz_msg", { key: "worldboss.dragonminez.gomah.stack_gained", args: [s.flags.eye, 5], color: "#FF5555" }); });
            }
        }
    }

    // ---- damage hooks (WorldBossCombatEvents) ----
    RPG.on("damageFinal", function (e) {
        var t = e.target, a = e.attacker;
        if (!t) return;
        if (t.isPlayer()) {
            var tp = t.asPlayer();
            if (t.hasTag("dmz_wb_ko")) { e.cancel(); return; }
            if (a && a.isPlayer()) {                 // post-fight truce between participants
                var tr = Number(tp.getVar("dmz_wb_truce", 0)) || 0, ar = Number(a.asPlayer().getVar("dmz_wb_truce", 0)) || 0;
                if (Date.now() < tr || Date.now() < ar) { e.cancel(); return; }
            }
            if (!a || !(isBoss(a) || isMinion(a))) return;
            var s = sessionOf(a);
            if (!s) return;
            var pe = P(s, tp);
            pe.recv += Math.min(e.amount, t.health);
            Object.keys(s.part).forEach(function (u) {
                var ko = s.part[u];
                if (ko.ko && ko.reviver === tp.name && e.amount >= tp.maxHealth * CFG.reviveInterrupt) {
                    ko.reviver = null; ko.rev = 0; pe.lockUntil = now() + 300;
                    RPG.net.send(tp, "dmz_wb_revive", { casting: false });
                    RPG.net.send(tp, "dmz_msg", { key: "worldboss.dragonminez.revive.interrupted", color: "#FF5555" });
                }
            });
            return;
        }
        if (isBoss(t)) {
            if (t.hasTag("dmz_wb_asleep")) return;
            var s2 = sessionOf(t);
            if (!s2 || !a || !a.isPlayer()) return;
            var ap = a.asPlayer(), ae = P(s2, ap);
            if (ae.ko) { e.cancel(); return; }
            ae.dmg += Math.min(e.amount, t.health);
            if (String(t.rpgId) === "wb_gomah" && s2.flags.eye > 0) {      // 3 hits from behind within 200 t knock a stack off
                var yaw = t.yaw * Math.PI / 180, fx = -Math.sin(yaw), fz = Math.cos(yaw), dx = a.x - t.x, dz = a.z - t.z;
                if (fx * dx + fz * dz < 0) {
                    s2.flags.back = (s2.flags.backAt && now() - s2.flags.backAt < 200 ? s2.flags.back || 0 : 0) + 1;
                    s2.flags.backAt = now();
                    if (s2.flags.back >= 3) { s2.flags.back = 0; s2.flags.eye--; s2.dmgMult = 1 + 0.3 * s2.flags.eye; }
                }
            }
        }
    });
    RPG.on("heal", function (ent, amount) {
        if (!ent || !ent.isPlayer() || !(amount > 0)) return;
        for (var k in SESS) {
            var e = SESS[k].part[String(ent.uuid)];
            if (e && !e.ko && e.inAudience) e.heal += Math.min(amount, Math.max(0, ent.maxHealth - ent.health));
        }
    });
    function sessionOf(e) {
        if (isBoss(e)) { var b = BY_MOB[String(e.rpgId)], s = SESS[b.key]; return s && String(s.boss.uuid) === String(e.uuid) ? s : null; }
        if (isMinion(e)) for (var k in SESS) if (e.hasTag("dmz_wb_" + k)) return SESS[k];
        return null;
    }
    RPG.on("lethal", function (e) {
        var t = e.target;
        if (!t) return;
        if (t.isPlayer()) {                                     // knocked down instead of dying (lives)
            var p = t.asPlayer();
            for (var k in SESS) {
                var s = SESS[k], pe = s.part[String(p.uuid)];
                if (!pe || !pe.inAudience) continue;
                if (pe.ko) { e.cancel(); return; }
                if (pe.lives <= 0) return;
                e.cancel();
                knockOut(s, p);
                return;
            }
            return;
        }
        if (!isBoss(t)) return;
        var s2 = sessionOf(t), id = String(t.rpgId), b = BY_MOB[id];
        if (!s2) return;
        if (id === "wb_janemba_fat") {                          // Janemba -> Super Janemba
            e.cancel();
            transformBoss(s2, t, BOSSES.janemba.next.mob, 1);
            return;
        }
        var root = BOSSES[b.key];
        if (root.stars && b.part !== "powered") {               // Tamagami: powered up in place on the first lethal hit
            e.cancel();
            transformBoss(s2, t, root.mob + "_powered", 0.35);      // max(previous fraction, 0.35): the previous is 0 here
            s2.flags.powered = true;
        } else if (root.stars) {                                // ... and the next lethal hit subdues it
            e.cancel();
            subdue(b.key, s2, t);
        }
    });
    function transformBoss(s, m, nextId, frac) {
        var nb = BY_MOB[nextId];
        m.setAI(false);
        m.invulnerable = true;
        m.playAnimation("transformation_1");
        RPG.world.sound(m.dimension, "dmzpack:transform_on", m.x, m.y, m.z, 4, 0.7);
        RPG.schedule(60, function () {
            if (!alive(m)) return;
            m.transform(nextId, { heal: true });
            m.maxHealth = nb.hp * (1 + CFG.healthPerExtra * s.extra);
            m.health = m.maxHealth * frac;
            m.setAttributeBase("generic.attack_damage", nb.melee * (1 + CFG.damagePerExtra * s.extra));
            m.invulnerable = false;
            m.setAI(true);
            s.cds = {};
            RPG.world.particle(m.dimension, "minecraft:explosion_emitter", m.x, m.y + 2, m.z, 3, 2, 0);
            refreshAudience(s);
        });
    }
    RPG.on("playerLeave", function (p) {
        for (var k in SESS) { var e = SESS[k].part[String(p.uuid)]; if (e && e.ko) standUp(SESS[k], p, 0.33); }
    });
    RPG.on("playerJoin", function (p) {               // left mid-knockout: back on your feet
        if (p.hasTag("dmz_wb_ko")) { p.removeTag("dmz_wb_ko"); p.setInvulnerable(false); p.removeEffect("dmz_tech_rooted"); p.removePotion("minecraft:weakness"); }
    });

    // =========================================================================================
    //  commands (WorldBossCommand)
    // =========================================================================================
    function nearestKey(p) {
        var best = null, bd = 1e18;
        Object.keys(BOSSES).forEach(function (k) { var L = lair(k); if (!L || BOSSES[k].dim !== p.dimension) return; var d = dist2(p, L.x, L.z); if (d < bd) { bd = d; best = k; } });
        return best;
    }
    function status(k) {
        var L = state()[k];
        if (!L) return "&cno lair (dimension " + BOSSES[k].dim + " missing)";
        if (SESS[k]) return "&cFighting";
        if (bossEntity(k)) return "&aAlive";
        if (L.next && Date.now() < L.next) return "&eRespawns in " + Math.ceil((L.next - Date.now()) / 60000) + " min";
        return "&7Waiting to spawn" + (L.built ? "" : " (lair " + (L.phase === "plan" || L.phase === "search" ? "being planned" : "not built yet") + ")");
    }
    RPG.commands.register("worldboss", {
        description: "/rpgc worldboss results | locate [boss] | tp [boss] | reset [boss] | ready [boss] | rebuild [boss] | summon <boss>",
        run: function (p, args) {
            if (!p) return;
            var sub = String(args[0] || "results"), k = args[1] ? String(args[1]) : null;
            if (sub === "results") {
                RESULTS = RESULTS.filter(function (r) { return Date.now() - r.at < CFG.resultsMs; });
                if (!RESULTS.length) return p.tell("&6[World Boss]&r No recent results.");
                return RPG.net.send(p, "dmz_wb_results", RESULTS[0]);
            }
            if (sub === "locate") {
                (k ? [k] : Object.keys(BOSSES)).forEach(function (key) {
                    if (!BOSSES[key]) return;
                    var L = lair(key);
                    if (!L) return p.tell("&6[World Boss]&r " + BOSSES[key].name + ": &c" + BOSSES[key].dim + " doesn't exist in this game");
                    if (L.x === null) return p.tell("&6[World Boss]&r " + BOSSES[key].name + ": its lair in " + BOSSES[key].dim + " is still being planned (someone has to be in that world).");
                    p.tell("&6[World Boss]&r The " + BOSSES[key].name + " lair is at " + L.x + " " + (L.y === null ? "~" : L.y) + " " + L.z + " in " + BOSSES[key].dim + (p.dimension === BOSSES[key].dim ? " (" + Math.round(Math.sqrt(dist2(p, L.x, L.z))) + " blocks away)" : ""));
                    p.tell("   Status: " + status(key));
                });
                return;
            }
            if (!isOp(p)) return p.tell("&cOperators only.");
            if (sub === "summon") {
                if (!k || !BOSSES[k]) return p.tell("&cBosses: " + Object.keys(BOSSES).join(", "));
                var m = RPG.world.spawnMob(p.dimension, BOSSES[k].mob, p.x + 6, p.y, p.z);
                if (!m) return;
                if (SESS[k]) { releaseAll(SESS[k]); delete SESS[k]; }
                m.setAttributeBase("generic.knockback_resistance", BOSSES[k].kb);
                wake(k, m, p);
                return p.tell("&aSummoned " + BOSSES[k].name + " (fight session started, no lair).");
            }
            k = k || nearestKey(p);
            if (!k || !BOSSES[k]) return p.tell("&cNo lair in this dimension. Bosses: " + Object.keys(BOSSES).join(", "));
            var L = lair(k);
            if (!L) return p.tell("&c" + BOSSES[k].dim + " doesn't exist in this game.");
            if (sub === "tp") {
                if (L.x === null) return p.tell("&cThat lair hasn't been planned yet (be in " + BOSSES[k].dim + " for a moment).");
                if (L.tp) { p.teleportTo(BOSSES[k].dim, L.tp[0] + 0.5, L.tp[1], L.tp[2] + 0.5); return; }
                var bk = BOSSES[k], y = L.y !== null ? L.y + 1 : bk.kind === "hell" ? 95 : bk.kind === "platform" ? DEMON_BANDS[bk.stars].top - 4 : bk.kind === "cradle" ? CRADLE.maxSurface + 20 : 200;
                p.teleportTo(BOSSES[k].dim, L.x + 0.5, y, L.z + 0.5 + (L.y === null ? 0 : 8)); return;
            }
            if (sub === "rebuild") {                    // forget the lair and plan / build it again (keeps the boss's timer)
                var nx = L.next; delete state()[k]; saveState(); var L2 = lair(k); if (L2) { L2.next = nx; saveState(); }
                return p.tell("&a" + BOSSES[k].name + "'s lair will be rebuilt.");
            }
            if (sub === "reset") { var e = bossEntity(k); if (e) resetBoss(k, e, "reset"); return p.tell("&aReset " + BOSSES[k].name); }
            if (sub === "ready") { L.next = 0; saveState(); return p.tell("&a" + BOSSES[k].name + " respawns as soon as someone is near the lair."); }
        }
    });
    function isOp(p) { try { return p.isOp(); } catch (e) { return false; } }

    return { BOSSES: BOSSES, sessions: function () { return SESS; }, lair: lair, isBoss: isBoss, bossAlive: function (k) { return !!bossEntity(k); } };
})();
