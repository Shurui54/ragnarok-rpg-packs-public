// =====================================================================================
//  96_dbr_level_barrier.js - the Level Barrier (DMZ Ragnarok), server side
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0) sdu: BarrierBlock, BarrierBlockEntity, BarrierBER, BarrierConfigScreen,
//  SaveBarrierPacket, BlockFeatureEvents (barrier part) and Config.barrierDefaultLevel.
//
//  A force-field cube only players at a set level (and race) walk through; everyone else, mobs
//  included, hits a solid wall. It draws an animated field for every viewer: the open sprite to a
//  player who clears this block's gate, the closed one to a player who doesn't (per player, so two
//  players can see the same wall differently). Faces between barriers that look the same merge so
//  a wall reads as one field. Only creative players can break it.
//
//  - A new barrier copies the first face-adjacent barrier's level/race (extending a wall keeps its
//    gate), else barrierDefaultLevel (config dbr_level_barrier, default 100).
//  - Creative right-click: the config screen (required level + race); Save applies to the WHOLE
//    face-adjacent wall (flood fill, capped at 4096 blocks, loaded chunks only).
//  - Creative sneak-right-click: says what it requires.
//  The gate itself is the engine's BlockDef.gate: the level/race live in the block's data.
// =====================================================================================
var DBR_LEVEL_BARRIER = (function () {
    var CFG = dbrConfig("dbr_level_barrier", {
        barrierDefaultLevel: { default: 100, min: 0, max: 2147483647, integer: true,
            comment: "Default required level a freshly placed Level Barrier gates to. An op can then retune each wall in game (creative right-click)." }
    });
    var PROPAGATE_CAP = 4096;
    function defLevel() { return Math.max(0, Math.floor(Number(CFG.barrierDefaultLevel) || 0)); }

    var ID = null;
    function data(dim, x, y, z) {
        var d = RPG.world.getBlockData(dim, x, y, z);
        return { level: d && typeof d.level === "number" ? d.level : defLevel(), race: d && d.race ? String(d.race) : "" };
    }
    function isBarrier(dim, x, y, z) { return RPG.world.getBlock(dim, x, y, z) === ID; }
    var DIRS = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];

    ID = "ragnarok_rpg:" + RPG.blocks.define("level_barrier", {
        name: "Level Barrier",
        model: "dbr:rpg/block/level_barrier",
        decor: true, hardness: -1, drops: "none",
        gate: { level: defLevel(), texture: "dbr:block/level_barrier", openTexture: "dbr:block/level_barrier_open", alpha: 0.72 },
        onPlace: function (p, x, y, z) {
            var dim = p.dimension, d = null;
            for (var i = 0; i < DIRS.length && !d; i++) {
                var nx = x + DIRS[i][0], ny = y + DIRS[i][1], nz = z + DIRS[i][2];
                if (RPG.world.isLoaded(dim, nx, nz) && isBarrier(dim, nx, ny, nz)) d = data(dim, nx, ny, nz);     // first adjacent barrier wins
            }
            RPG.world.setBlockData(dim, x, y, z, d || { level: defLevel(), race: "" });
        },
        onUse: function (p, x, y, z) {
            if (p.getGameMode() !== "creative") return;                   // creative-only config
            var d = data(p.dimension, x, y, z);
            if (p.isSneaking()) { p.tell("&eThis Level Barrier requires level " + d.level + " / race: " + (d.race || "any") + "."); return; }
            RPG.net.send(p, "dbr_barrier_open", { x: x, y: y, z: z, level: d.level, race: d.race });
        }
    });

    // keep worlds whose barriers were placed by commands/structures (no data yet) at the default
    function ensure(dim, x, y, z) { if (!RPG.world.getBlockData(dim, x, y, z)) RPG.world.setBlockData(dim, x, y, z, { level: defLevel(), race: "" }); }

    /** BarrierBlockEntity.propagateLevel: the start barrier and every barrier reachable by face steps. */
    function propagate(dim, x, y, z, level, race) {
        var seen = {}, queue = [[x, y, z]], n = 0;
        seen[x + "," + y + "," + z] = 1;
        while (queue.length) {
            if (++n > PROPAGATE_CAP) { console.log("[DBR] Level Barrier flood fill exceeded " + PROPAGATE_CAP + " positions; stopping."); break; }
            var c = queue.shift();
            RPG.world.setBlockData(dim, c[0], c[1], c[2], { level: level, race: race });
            DIRS.forEach(function (d) {
                var nx = c[0] + d[0], ny = c[1] + d[1], nz = c[2] + d[2], k = nx + "," + ny + "," + nz;
                if (seen[k] || !RPG.world.isLoaded(dim, nx, nz)) return;
                if (isBarrier(dim, nx, ny, nz)) { seen[k] = 1; queue.push([nx, ny, nz]); }
            });
        }
        return n;
    }

    // SaveBarrierPacket: re-gate (creative), reach check (64 blocks), must really be a barrier
    RPG.net.on("dbr_barrier_save", function (p, d) {
        if (!d || p.getGameMode() !== "creative") return;
        var x = Math.floor(Number(d.x)), y = Math.floor(Number(d.y)), z = Math.floor(Number(d.z));
        if (!RPG.world.isLoaded(p.dimension, x, z)) return;
        var dx = p.x - x - 0.5, dy = p.y - y - 0.5, dz = p.z - z - 0.5;
        if (dx * dx + dy * dy + dz * dz > 64 * 64) return;
        if (!isBarrier(p.dimension, x, y, z)) return;
        var race = String(d.race || "").trim().toLowerCase();
        propagate(p.dimension, x, y, z, Math.max(0, Math.floor(Number(d.level) || 0)), race);
    });

    return { id: function () { return ID; }, propagate: propagate, ensure: ensure, data: data };
})();
