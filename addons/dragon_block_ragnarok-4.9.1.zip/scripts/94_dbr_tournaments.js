// =====================================================================================
//  94_dbr_tournaments.js - Tournaments (server): sign-ups, brackets, arenas and ring-outs,
//  match rules, spectator stands, schedules, announcements, rewards, titles, leaderboards
// =====================================================================================
//  Ported from DMZ Ragnarok's Tournaments module (GPL-3.0, shuruis_dmz_tournaments):
//  Config, TournamentDef / TournamentData, TournamentInstance, Bracket, Match, Team,
//  TournamentFormat, Scheduler, Announcer, RewardManager, TitleManager / TitleDisplay,
//  InventoryVault, TournamentNpcs, ForgeEventHandler (rule enforcement), TournamentCommand,
//  StatGemItem. Shared data: shared/24_dbr_tournaments.js. Screens and HUD:
//  client/scripts/84_dbr_tournaments.js.
//
//  Many tournaments can exist at once, each with its own arena / waiting area / stands,
//  format (1v1, 2v2, 3v3 brackets or an FFA "Tournament of Power"), schedule, rules,
//  announcements and rewards. Global defaults (DMZ Ragnarok's config keys and defaults):
//  ragnarok_rpg/config/dbr_tournaments.json, /rpg config dbr_tournaments, or
//  /tourney config <key> <value>. New tournaments are seeded from them.
//
//  Commands (/tourney, also /rpgc tourney):
//    list | join <name> | leave <name> | tpwait <name> | status <name> | spectate <name>
//    bracket <name> | top | team create <team> <name> | team join <teamId> <name> | team leave <name>
//    ops: edit | open <name> | start <name> | cancel <name> | forceexit <player>
//         bounds <arena|waiting|stands> <x1 y1 z1> <x2 y2 z2> <name>
//         npc spawn <name> | npc bind <name> | npc setgroup <group|all> | npc remove | npc removeall
//         title list | title set <id> <player> | title clear <id> | config [key] [value]
//
//  Tournament characters (the frozen fighter swapped in on entry, its move loadout, the forced
//  half-health transformation, the TP freeze and the swap back): 94_dbr_tournaments_chars.js,
//  hooked in below where DMZ Ragnarok's TournamentInstance calls TournamentCharacter.
//  Player commands: /tourney char [create|build|moves|delete|cancel], /tourney loadout,
//  /tourney cancelcharacter. Cross-shard routing (TournamentNetwork) has no meaning on a single
//  DBR server.
//
//  State that must survive /rpg reload or a crash is never only in script variables: running
//  tournaments are saved to RPG.data each second, and each contestant's stash, return point,
//  friendly-fist setting and scoreboard team live in their player vars until handed back.
// =====================================================================================

var DBR_TOURNEY_CFG = RPG.config.define("dbr_tournaments", {
    rules: {
        itemsAllowedInArena: { default: false, comment: "Whether contestants may use items (consumables, senzu, etc.) during a match." },
        healAfterFight: { default: true, comment: "Fully heal both contestants (health, energy, stamina) after every match." },
        forceFriendlyFist: { default: true, comment: "Force DragonMineZ friendly-fist (non-lethal) ON for contestants inside the arena." },
        allowPvpInWaitingArea: { default: false, comment: "Allow PvP in the fighter waiting area. Normally false." },
        allowPvpInStands: { default: false, comment: "Allow PvP in the spectator stands. Normally false." },
        countdownSeconds: { default: 5, min: 0, max: 60, integer: true, comment: "Countdown length before a match begins." },
        matchTimeLimitSeconds: { default: 300, min: 0, max: 3600, integer: true, comment: "Match time limit in seconds (0 = unlimited). On timeout the higher-health fighter wins." }
    },
    characters: {
        enabled: { default: true, comment: "Swap every contestant into a dedicated tournament-only character on entry and back to their real character afterwards. The tournament character has a fixed stat allocation pool, a chosen ki/strike attack loadout, and cannot gain TP. It is reloaded from a frozen template on every entry so it can never carry progress out of a tournament. Each tournament can also turn it off for itself." },
        trainingPointAllowance: { default: 100000, min: 0, max: 2147483647, integer: true, comment: "UNUSED. Superseded by characters.statAllocations: a tournament character is given flat stat allocations instead of a training-point pool, so this value is ignored (kept so a DMZ Ragnarok config carries over)." },
        statAllocations: { default: 2500, min: 0, max: 2147483647, integer: true, comment: "Flat stat allocations granted to a tournament character, spent through the stats screen. These are attribute points, spent one per stat point before any TP, so every contestant gets exactly this many stat increases whatever their race. Training points are set to zero on a tournament character so this is the only currency." },
        forceTransformAtHalfHealth: { default: true, comment: "When a contestant drops to or below half health, force them into their first reachable form (or Ultimate if their race has no forms) with invulnerability frames during the transformation." },
        forcedFormStatMultiplier: { default: 1.5, min: 1.0, max: 1000000, comment: "Flat stat multiplier a tournament character's form gives (every stat, every race), replacing the form's own multiplier. Applies only inside a tournament (the template is never written back)." },
        forcedTransformIframeTicks: { default: 40, min: 0, max: 600, integer: true, comment: "Length in ticks of the damage-immunity window granted while the forced transformation plays." }
    },
    signup: {
        maxParticipants: { default: 16, min: 0, max: 256, integer: true, comment: "Maximum contestants per tournament (bracket is padded with byes). 0 = unlimited." },
        durationMinutes: { default: 10, min: 1, max: 1440, integer: true, comment: "How long sign-ups stay open before an auto-scheduled tournament begins." },
        minParticipants: { default: 2, min: 2, max: 256, integer: true, comment: "Minimum contestants required or the tournament is cancelled." },
        requireDmzCharacter: { default: true, comment: "Require the player to have created a DragonMineZ character to sign up." },
        reminderSeconds: { default: 30, min: 0, max: 3600, integer: true, comment: "While sign-ups are open, repeat the on-screen 'Sign-ups Open' title + clickable join prompt every this-many seconds. 0 = announce only once." }
    },
    npc: {
        name: { default: "Hercule", comment: "Display name of the sign-up NPC." },
        character: { default: "hercule", comment: "Which character the sign-up NPC wears: hercule, announcer, or any rgnpc model id (/rpgc rgnpc list)." },
        lookRadius: { default: 8.0, min: 0, max: 64, comment: "How far (in blocks) a sign-up NPC will turn to face the nearest player. 0 disables look-at." }
    },
    schedule: {
        mode: { default: "MANUAL", options: ["MANUAL", "DAILY", "WEEKLY", "MONTHLY"], comment: "Automatic scheduling for new tournaments: MANUAL, DAILY, WEEKLY, or MONTHLY." },
        hour: { default: 18, min: 0, max: 23, integer: true, comment: "Hour (server local time, 0-23) sign-ups auto-open on a scheduled day." },
        minute: { default: 0, min: 0, max: 59, integer: true, comment: "Minute of that hour." },
        dayOfWeek: { default: 6, min: 1, max: 7, integer: true, comment: "Day of week for WEEKLY mode (1=Monday .. 7=Sunday)." },
        dayOfMonth: { default: 1, min: 1, max: 28, integer: true, comment: "Day of month for MONTHLY mode (1-28)." }
    },
    announce: {
        useOnScreenTitles: { default: true, comment: "Show announcements as on-screen titles in addition to chat." },
        sound: { default: "minecraft:ui.toast.challenge_complete", comment: "Sound played to everyone on major announcements (sound id, empty to disable)." },
        signupOpen: { default: "&e[Tournament] &fSign-ups are now OPEN! Talk to {npc} or use /tourney join.", comment: "Sign-ups open. {name} {id} {npc}" },
        starting: { default: "&6[Tournament] &fThe tournament is starting with {count} fighters!", comment: "Tournament starts. {name} {count}" },
        match: { default: "&6[Tournament] &fNext match: &e{p1} &fvs &e{p2}&f!", comment: "Before each match. {name} {p1} {p2}" },
        matchWin: { default: "&6[Tournament] &e{winner} &fdefeats &e{loser}&f!", comment: "After each match. {name} {winner} {loser}" },
        champion: { default: "&6[Tournament] &e{champion} &fis the new CHAMPION!", comment: "Tournament won. {name} {champion}" }
    },
    rewards: {
        winner: { default: ["title:champion", "item:minecraft:diamond:10", "message:&6You are the champion!"],
            comment: "Rewards for the champion. Tokens: 'command:<cmd with {player}>', 'item:<id>:<count>', 'tp:<amount>', 'skill:<dmzSkillId>:<levels>', 'title:<titleId>', 'message:<text>'." },
        runnerUp: { default: ["item:minecraft:diamond:3"], comment: "Rewards for the runner-up (same tokens)." },
        participation: { default: ["item:minecraft:gold_ingot:1"], comment: "Rewards for every other contestant (same tokens)." }
    },
    titles: {
        definitions: { default: ["champion|&6&lWorld Martial Arts Champion|&6&l [Champion]"],
            comment: "Configurable titles, format 'id|Display Text|Tag'. Granted via 'title:<id>' rewards. The tag is shown after the holder's chat name and above their head. Only one player holds a given title at a time; it transfers to the new winner." },
        chatPrefix: { default: true, comment: "Show a title holder's tag after their name in chat." },
        nametagPrefix: { default: true, comment: "Show a title holder's tag above their head." }
    }
});

var DBR_TOURNEY = (function () {
    var S = DBR_TOURNEY_SHARED, C = DBR_TOURNEY_CFG;
    var K_DEFS = "dbr_tourney_defs", K_RUNS = "dbr_tourney_runs", K_LAST = "dbr_tourney_lastrun",
        K_TITLES = "dbr_tourney_titles", K_HOSTS = "dbr_tourney_hosts";
    var V_RET = "dbr_tourney_ret", V_VAULT = "dbr_tourney_vault", V_FF = "dbr_tourney_ff", V_TEAM = "dbr_tourney_team";
    var B_WINS = "dbr_tourney_wins", B_BOUTS = "dbr_tourney_bouts", B_PLAYED = "dbr_tourney_played";
    var MATCH_START_GRACE_TICKS = 20, FIRE_WINDOW_MS = 12 * 60 * 60 * 1000;
    var TEAM_A = "dbrt_side_a", TEAM_B = "dbrt_side_b";
    // TitleManager.BUILT_IN_DEFS: always defined, config rows with the same id win
    var BUILT_IN_TITLES = ["god_of_destruction|&5&lGod of Destruction|&5&l [G.O.D.]", "angel|&b&lAngel|&b&l [Angel]", "grand_zeno|&d&lGrand Zeno|&d&l [Zeno]"];
    var PASSABLE = /(^|:)(air|cave_air|void_air|water|lava|light|grass|short_grass|tall_grass|fern|large_fern|dead_bush|snow|vine|torch|wall_torch|soul_torch|redstone_wire|rail|.*_rail|.*_button|.*_pressure_plate|.*_sapling|.*_flower|dandelion|poppy|.*_tulip|allium|azure_bluet|oxeye_daisy|cornflower|lily_of_the_valley|.*_carpet|.*_sign|.*_banner|seagrass|tall_seagrass|kelp|kelp_plant|bubble_column|structure_void)$/;

    RPG.teams.define(TEAM_A, { name: "Tournament A", color: "gold", friendlyFire: false });
    RPG.teams.define(TEAM_B, { name: "Tournament B", color: "aqua", friendlyFire: false });
    RPG.perms.group("default", ["rg.tourney.list", "rg.tourney.join", "rg.tourney.leave", "rg.tourney.tpwait", "rg.tourney.status",
        "rg.tourney.team", "rg.tourney.spectate", "rg.tourney.bracket", "rg.tourney.top", "rg.tourney.char", "rg.tourney.loadout", "rg.tourney.cancelcharacter"]);

    // ---- small helpers -------------------------------------------------------------------
    function now() { return Date.now(); }
    function uid(p) { return String(p.uuid); }
    var arr = DBR_TOURNEY_SHARED.list;
    function has(list, x) { return list.indexOf(x) >= 0; }
    function add(list, x) { if (list.indexOf(x) < 0) list.push(x); return list; }
    function del(list, x) { var i = list.indexOf(x); if (i >= 0) list.splice(i, 1); return i >= 0; }
    function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
    var ONLINE = {};
    function refreshOnline() { ONLINE = {}; RPG.server.players().forEach(function (p) { ONLINE[uid(p)] = p; }); }
    function player(id) { return id ? ONLINE[id] || null : null; }
    function created(p) { return !!p.getVar("dmz_created", 0); }
    /** Tournament characters (94_dbr_tournaments_chars.js, loaded after this file). */
    function tc() { return typeof DBR_TCHAR !== "undefined" ? DBR_TCHAR : null; }
    /** TournamentInstance.tournamentCharsEnabled: the global switch AND this tournament's own toggle. */
    function charsOn(def) { return !!def && !!def.tournamentChars && !!C.get("characters.enabled") && !!tc(); }
    function admin(p, node) { return !p || p.isOp() || RPG.perms.has(p, node); }
    function perm(p, node) { return !p || RPG.perms.has(p, node) || p.isOp(); }
    function tell(p, s) { if (p) p.tell(s); else RPG.log(String(s).replace(/&./g, "")); }
    function sound(p, id) { if (!id) return; try { p.playSound(String(id), 1, 1); } catch (e) { } }

    // ---- definitions (TournamentData) --------------------------------------------------------
    // read once into a cache of normalized definitions; every write goes through putDef / deleteDef
    var DEFS = null;
    function defs() {
        if (DEFS) return DEFS;
        var d = RPG.data.get(K_DEFS, null), out = {};
        if (d && typeof d === "object") Object.keys(d).forEach(function (k) { var n = S.normalize(d[k]); if (n.id) out[n.id] = n; });
        return (DEFS = out);
    }
    function getDef(id) { return defs()[String(id || "").toLowerCase()] || null; }
    function putDef(def) { var all = defs(); def = S.normalize(def); if (!def.id) return null; all[def.id] = def; RPG.data.set(K_DEFS, all); return def; }
    function deleteDef(id) { var all = defs(); delete all[id]; RPG.data.set(K_DEFS, all); }
    function allDefs() { var all = defs(); return Object.keys(all).sort().map(function (k) { return all[k]; }); }
    /** TournamentDef.createDefault: a new definition seeded from the global config. */
    function createDefault(id, name) {
        var d = S.normalize({ id: id, name: name });
        var mode = String(C.get("schedule.mode")).toUpperCase();
        d.scheduleEnabled = mode !== "MANUAL";
        d.scheduleHour = C.get("schedule.hour"); d.scheduleMinute = C.get("schedule.minute");
        // the def's cadence comes from its day fields (0 = ignore): seed only the one the mode wants
        d.scheduleDayOfWeek = mode === "WEEKLY" ? C.get("schedule.dayOfWeek") : 0;
        d.scheduleDayOfMonth = mode === "MONTHLY" ? C.get("schedule.dayOfMonth") : 0;
        d.signupMinutes = C.get("signup.durationMinutes"); d.minParticipants = C.get("signup.minParticipants");
        d.maxParticipants = C.get("signup.maxParticipants"); d.requireCharacter = C.get("signup.requireDmzCharacter");
        d.tournamentChars = C.get("characters.enabled");
        d.itemsAllowed = C.get("rules.itemsAllowedInArena"); d.healAfterFight = C.get("rules.healAfterFight");
        d.forceFriendlyFist = C.get("rules.forceFriendlyFist"); d.pvpInWaiting = C.get("rules.allowPvpInWaitingArea");
        d.pvpInStands = C.get("rules.allowPvpInStands"); d.countdownSeconds = C.get("rules.countdownSeconds");
        d.matchTimeLimit = C.get("rules.matchTimeLimitSeconds"); d.signupReminderSeconds = C.get("signup.reminderSeconds");
        d.npcName = C.get("npc.name"); d.useTitles = C.get("announce.useOnScreenTitles"); d.announceSound = C.get("announce.sound");
        d.msgSignupOpen = C.get("announce.signupOpen"); d.msgStarting = C.get("announce.starting"); d.msgMatch = C.get("announce.match");
        d.msgMatchWin = C.get("announce.matchWin"); d.msgChampion = C.get("announce.champion");
        d.winnerRewards = arr(C.get("rewards.winner")).map(String); d.runnerUpRewards = arr(C.get("rewards.runnerUp")).map(String);
        d.participationRewards = arr(C.get("rewards.participation")).map(String);
        return S.normalize(d);
    }
    function newId() { var id; do { id = "tourney_" + Date.now().toString(36).substring(3) + Math.floor(Math.random() * 36).toString(36); } while (defs()[id]); return id; }
    /** TournamentCommand.resolve: by display name (colours ignored), then by id. */
    function resolve(name) {
        var n = S.strip(String(name || "")).replace(/^"|"$/g, "").trim().toLowerCase();
        if (!n) return null;
        var hit = null;
        allDefs().forEach(function (d) { if (!hit && S.strip(d.name).toLowerCase() === n) hit = d; });
        return hit || getDef(n);
    }

    // ---- regions (Region: a dimension + two corners; containment is the X/Z column) ---------
    function inRegion(r, e) {
        return !!r && !!e && String(e.dimension) === r.dim && e.x >= r.min[0] && e.x < r.max[0] + 1 && e.z >= r.min[2] && e.z < r.max[2] + 1;
    }
    function passable(dim, x, y, z) { return PASSABLE.test(String(RPG.world.getBlock(dim, Math.floor(x), Math.floor(y), Math.floor(z)))); }
    function standable(dim, x, y, z) { return passable(dim, x, y, z) && passable(dim, x, y + 1, z) && !passable(dim, x, y - 1, z); }
    /** Region.snapToStand: keep X/Z, walk up from the region floor to the first spot with two clear blocks over solid ground. */
    function snap(r, x, z) {
        var top = Math.min(r.max[1], r.min[1] + 320);
        for (var y = r.min[1]; y <= top; y++) if (standable(r.dim, x, y, z)) return y;
        return r.min[1] + 1;
    }
    function randomStand(r) {
        for (var i = 0; i < 12; i++) {
            var x = r.min[0] + Math.floor(Math.random() * (r.max[0] - r.min[0] + 1)), z = r.min[2] + Math.floor(Math.random() * (r.max[2] - r.min[2] + 1));
            var top = Math.min(r.max[1], r.min[1] + 320);
            for (var y = r.min[1]; y <= top; y++) if (standable(r.dim, x, y, z)) return [x + 0.5, y, z + 0.5];
        }
        return [(r.min[0] + r.max[0]) / 2 + 0.5, r.min[1] + 1, (r.min[2] + r.max[2]) / 2 + 0.5];
    }
    /** Region.sideSpawn: side A along the min-Z wall, side B along the max-Z wall, spread across X. */
    function sideSpawn(r, sideA, index, count) {
        var z = sideA ? r.min[2] + 2.5 : r.max[2] - 1.5, x;
        if (count <= 1) x = (r.min[0] + r.max[0]) / 2 + 0.5;
        else { var step = Math.max(1, r.max[0] - r.min[0]) / (count + 1); x = r.min[0] + 0.5 + step * (index + 1); }
        return [x, z];
    }
    function teleportInto(p, r) { if (!p || !r) return; var at = randomStand(r); p.teleportTo(r.dim, at[0], at[1], at[2], p.yaw, p.pitch); }

    // ---- fighter state (DmzHooks, InventoryVault) -----------------------------------------
    function flying(p) { return (typeof DMZ_FLIGHT !== "undefined" && DMZ_FLIGHT.isFlying(p)) || p.isFlying(); }
    function land(p) {
        if (typeof DMZ_FLIGHT !== "undefined") DMZ_FLIGHT.land(p);
        var gm = p.getGameMode();
        if (p.isFlying() && gm !== "creative" && gm !== "spectator") p.setFlying(false);
    }
    /** Not onGround alone: DMZ flight hovers a fraction above the floor. Solid within half a block under the feet. */
    function touchingGround(p) { return p.onGround || !passable(p.dimension, p.x, p.y - 0.5, p.z); }
    function fullHeal(p) {
        if (!p) return;
        p.removeEffect("knocked_down"); p.removeEffect("stunned");
        p.health = p.maxHealth;
        ["ki", "stamina"].forEach(function (r) { try { p.setResource(r, p.maxResource(r)); } catch (e) { } });
        p.setFood(20);
    }
    function setFriendlyFist(p, on) {
        if (!p) return;
        if (on) {
            if (p.getVar(V_FF, null) === null) p.setVar(V_FF, Number(p.getVar("dmz_friendly_fist", 0)) === 1 ? 1 : 0);
            p.setVar("dmz_friendly_fist", 1);
        } else {
            var prev = p.getVar(V_FF, null);
            if (prev === null) return;
            p.setVar("dmz_friendly_fist", Number(prev) === 1 ? 1 : 0);
            p.setVar(V_FF, null);
        }
    }
    /** Fighters go on a per-side scoreboard team for the bout (teammates can't hurt each other, a party never blocks
     *  two opponents); FFA fighters leave theirs. The old team comes back when they leave the bout. */
    function setSide(p, team) {
        if (!p) return;
        if (p.getVar(V_TEAM, null) === null) p.setVar(V_TEAM, String(RPG.teams.get(p) || ""));
        if (team) { if (RPG.teams.get(p) !== team) RPG.teams.join(p, team); }
        else if (RPG.teams.get(p)) RPG.teams.leave(p);
    }
    function restoreSide(p) {
        var prev = p.getVar(V_TEAM, null);
        if (prev === null) return;
        p.setVar(V_TEAM, null);
        var cur = RPG.teams.get(p);
        if (prev && RPG.teams.exists(prev)) { if (cur !== prev) RPG.teams.join(p, prev); }
        else if (cur === TEAM_A || cur === TEAM_B) RPG.teams.leave(p);
    }
    /** InventoryVault.store: main inventory and off hand into a player var (armour stays on). */
    function vaultStore(p) {
        if (p.getVar(V_VAULT, null)) return;
        var slots = {}, n = 0;
        for (var i = 0; i <= 40; i++) {
            if (i > 35 && i < 40) continue;
            var st = p.getStack(i);
            if (st && st.id && st.id !== "minecraft:air") { slots[i] = st; n++; }
        }
        p.setVar(V_VAULT, { slots: slots });
        Object.keys(slots).forEach(function (k) { p.setStack(Number(k), null); });
        if (n) p.tell("&7Your items are stored safely until you leave the tournament.");
    }
    function vaultRestore(p) {
        var v = p.getVar(V_VAULT, null);
        if (!v) return;
        p.setVar(V_VAULT, null);
        var slots = v.slots || {};
        Object.keys(slots).forEach(function (k) {
            var i = Number(k), st = slots[k], cur = p.getStack(i);
            if (!cur || !cur.id || cur.id === "minecraft:air") p.setStack(i, st); else p.giveStack(st);
        });
    }
    function rememberReturn(p) {
        if (p.getVar(V_RET, null)) return;
        p.setVar(V_RET, { dim: String(p.dimension), x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch });
    }
    function returnHome(p) {
        var r = p.getVar(V_RET, null);
        if (!r) return;
        p.setVar(V_RET, null);
        // only someone the tournament moved (they stand in an arena, waiting area or stands) is sent back:
        // a sign-up who never left their spot is not yanked to where they stood when they joined
        if (!allDefs().some(function (d) { return inRegion(d.arena, p) || inRegion(d.waiting, p) || inRegion(d.stands, p); })) return;
        p.teleportTo(r.dim, r.x, r.y, r.z, r.yaw || 0, r.pitch || 0);
    }
    /** TournamentInstance.restoreFighter: everything a contestant lent the tournament comes back. */
    function restoreFighter(p) {
        if (!p) return;
        if (tc()) tc().exit(p, true);              // the tournament character comes off first (a build in progress stays)
        setFriendlyFist(p, false);
        restoreSide(p);
        vaultRestore(p);
    }

    // ---- titles (TitleManager, TitleDisplay) -------------------------------------------------
    function titleDefs() {
        var list = arr(C.get("titles.definitions")).map(String);
        BUILT_IN_TITLES.forEach(function (b) {
            var id = b.substring(0, b.indexOf("|")).toLowerCase();
            if (!list.some(function (d) { return d.split("|")[0].trim().toLowerCase() === id; })) list.push(b);
        });
        return list;
    }
    function titlePart(tid, i) {
        var hit = null;
        titleDefs().forEach(function (d) { var p = d.split("|"); if (!hit && p[0].trim().toLowerCase() === String(tid).toLowerCase()) hit = p; });
        if (!hit) return i === 1 ? String(tid) : "";
        return i < hit.length ? hit[i] : "";
    }
    function titleIds() { return titleDefs().map(function (d) { return d.split("|")[0].trim(); }).filter(function (s) { return s; }); }
    function isTitle(tid) { return titleIds().some(function (t) { return t.toLowerCase() === String(tid).toLowerCase(); }); }
    function holders() { var h = RPG.data.get(K_TITLES, null); return h && typeof h === "object" ? h : {}; }
    function heldTitleIds(id) { var h = holders(), out = []; Object.keys(h).sort().forEach(function (t) { if (h[t] && h[t].u === id) out.push(t); }); return out; }
    function grantTitle(tid, p) {
        if (!isTitle(tid)) return;
        tid = titleIds().filter(function (t) { return t.toLowerCase() === String(tid).toLowerCase(); })[0];
        var h = holders(), prev = h[tid] ? h[tid].u : null;
        h[tid] = { u: uid(p), n: p.name };
        RPG.data.set(K_TITLES, h);
        var display = titlePart(tid, 1);
        p.tell("&aYou have been awarded the title: " + display);
        if (prev && prev !== uid(p)) { refreshOnline(); var old = player(prev); if (old) old.tell("&cYour title '" + display + "&c' has passed to " + p.name + "."); }
        RPG.server.players().forEach(function (o) { o.tell("&e" + p.name + " &fnow holds the title &r" + display + "&f!"); });
        pushTags();
    }
    function clearTitle(tid) { var h = holders(), prev = h[tid] ? h[tid].u : null; delete h[tid]; RPG.data.set(K_TITLES, h); pushTags(); return prev; }
    function tagOf(id) { var held = heldTitleIds(id); return held.length ? titlePart(held[0], 2) : ""; }

    // title tags over heads and the host markers (client/scripts/84_dbr_tournaments.js draws them)
    function hosts() { var h = RPG.data.get(K_HOSTS, null); return h && typeof h === "object" ? h : {}; }
    function tagsPayload() {
        var titles = {}, h = holders(), hostLabels = {};
        if (C.get("titles.nametagPrefix")) Object.keys(h).forEach(function (t) { if (h[t] && !titles[h[t].u]) titles[h[t].u] = tagOf(h[t].u); });
        var hs = hosts();
        Object.keys(hs).forEach(function (u) {
            var e = hs[u];
            if (e.t) { var d = getDef(e.t); hostLabels[u] = d ? "&e" + d.npcName + " &7- &6" + d.name : "&7(deleted tournament)"; }
            else hostLabels[u] = "&6Tournaments" + (e.g ? " &7- " + e.g : "");
        });
        return { titles: titles, hosts: hostLabels };
    }
    function pushTags(p) {
        var data = tagsPayload();
        if (p) RPG.net.send(p, "dbr_tourney_tags", data);
        else RPG.server.players().forEach(function (o) { RPG.net.send(o, "dbr_tourney_tags", data); });
    }
    // chat: the tag after the holder's name
    // builds on an earlier chat format (if any); later ones (Ranks & Kits, Guilds) pass their line in as builtIn
    var prevChat = null;
    var myChat = function (p, message, builtIn) {
        var before = prevChat ? prevChat(p, message, builtIn) : null;
        if (before !== null && before !== undefined && String(before) !== "") builtIn = before;
        if (!C.get("titles.chatPrefix")) return builtIn;
        var tag = tagOf(uid(p));
        if (!tag) return builtIn;
        var name = typeof p.getDisplayName === "function" ? String(p.getDisplayName() || p.name) : p.name;
        if (builtIn) { var s = String(builtIn), i = s.indexOf(name); return i < 0 ? s : s.substring(0, i + name.length) + tag + "&r" + s.substring(i + name.length); }
        return "<" + name + tag + "&r> " + String(message).replace(/&/g, "&&");
    };
    prevChat = RPG.override("chatFormat", myChat) || null;
    if (prevChat === myChat) prevChat = null;

    // ---- rewards (RewardManager) -------------------------------------------------------------
    function giveAll(p, tokens) {
        if (!p) return;
        arr(tokens).forEach(function (tok) { try { applyReward(p, String(tok).trim()); } catch (e) { RPG.log("[Tournament] Failed to apply reward '" + tok + "': " + e); } });
    }
    function applyReward(p, token) {
        var c = token.indexOf(":");
        if (c < 0) return;
        var r = S.rewardFrom(token);
        switch (r.type) {
            case "COMMAND": RPG.server.runCommand(String(r.command).replace(/\{player\}/g, p.name).replace(/\{uuid\}/g, uid(p)).replace(/^\//, "")); break;
            case "MESSAGE": p.tell(r.message); break;
            case "ITEM": p.giveItem(r.item, r.count); break;
            case "TP": p.addTp(Number(r.tp) || 0, { source: "script", raw: true }); break;
            case "SKILL":
                if (typeof DMZ_SKILLS !== "undefined" && r.skill) DMZ_SKILLS.setLevel(p, String(r.skill).toLowerCase(), DMZ_SKILLS.level(p, String(r.skill).toLowerCase()) + (Number(r.level) || 1));
                else if (r.skill && RPG.skills.exists(r.skill)) p.setSkillLevel(r.skill, p.skillLevel(r.skill) + (Number(r.level) || 1));
                break;
            case "TITLE": grantTitle(r.title, p); break;
        }
    }

    // ---- announcements (Announcer) ----------------------------------------------------------
    function fmt(template, def) { return String(template || "").replace(/\{name\}/g, def.name).replace(/\{id\}/g, def.id).replace(/\{npc\}/g, def.npcName); }
    function recipients(audience) {
        return RPG.server.players().filter(function (p) { return (audience && has(audience, uid(p))) || p.isOp(); });
    }
    function show(list, chat, title, subtitle, def) {
        list.forEach(function (p) {
            if (chat) p.tell(chat);
            if (def.useTitles && title) p.title(title, subtitle || "");
            sound(p, def.announceSound);
        });
    }
    function announce(chat, title, def) { show(RPG.server.players(), chat, title, null, def); }
    function announceTo(audience, chat, title, def) { show(recipients(audience), chat, title, null, def); }
    function broadcastTo(audience, chat) { recipients(audience).forEach(function (p) { p.tell(chat); }); }
    function broadcast(chat) { RPG.server.players().forEach(function (p) { p.tell(chat); }); }
    function sec(s) { return String(s).replace(/&([0-9a-fk-or])/gi, "§$1"); }
    /** Announcer.broadcastJoinPrompt: a chat line ending in clickable [Join] / [Leave]. */
    function joinPrompt(def, prefix) {
        var cmd = "/rpgc tourney ";
        var line = [{ text: sec(prefix) },
            { text: "[Join]", color: "green", bold: true, clickEvent: { action: "run_command", value: cmd + "join " + def.id },
                hoverEvent: { action: "show_text", contents: sec("&aClick to sign up for &e" + def.name) } },
            { text: " " },
            { text: "[Leave]", color: "red", clickEvent: { action: "run_command", value: cmd + "leave " + def.id },
                hoverEvent: { action: "show_text", contents: sec("&cClick to withdraw from &e" + def.name) } }];
        try { RPG.server.runCommand("tellraw @a " + JSON.stringify(line)); }
        catch (e) { broadcast(prefix + "&a/tourney join " + def.id); }
    }

    // ---- running tournaments (TournamentInstance), kept as plain data so they can be saved ---
    var RUNS = {};
    var dirty = false;
    function blank(defId) {
        return { defId: defId, state: "IDLE", signups: [], names: {}, pending: [], nextPending: 1, teams: [], participants: [],
            eliminated: [], ffa: false, ffaAlive: [], ffaOrder: [], bracket: null, active: null, downed: [], tookOff: [], flightCut: [],
            phase: 0, ticks: 0, signupEnd: 0, reminder: 0 };
    }
    function inst(defId) { return RUNS[defId] || (RUNS[defId] = blank(defId)); }
    function save() {
        var out = {};
        Object.keys(RUNS).forEach(function (k) { if (RUNS[k].state !== "IDLE") out[k] = RUNS[k]; });
        RPG.data.set(K_RUNS, out);
        dirty = false;
    }
    function nameOf(I, id) { var p = player(id); return p ? p.name : (I.names[id] || String(id).substring(0, 8)); }
    function team(I, tid) { for (var i = 0; i < I.teams.length; i++) if (I.teams[i].id === tid) return I.teams[i]; return null; }
    function teamOfMember(I, id) { for (var i = 0; i < I.teams.length; i++) if (has(I.teams[i].members, id)) return I.teams[i]; return null; }
    function teamName(I, t, def) {
        if (!t) return "(bye)";
        if (S.isTeam(S.format(def.format))) return t.name && String(t.name).trim() ? t.name : "Team #" + t.id;
        return nameOf(I, t.members[0]);
    }
    function isContestant(I, id) { return (I.state === "MATCH" || I.state === "COUNTDOWN" || I.state === "INTERMISSION") && has(I.participants, id) && !has(I.eliminated, id); }
    function inActiveMatch(I, id) {
        if (I.ffa) return has(I.ffaAlive, id);
        if (!I.active) return false;
        var a = team(I, I.active.a), b = team(I, I.active.b);
        return (a && has(a.members, id)) || (b && has(b.members, id));
    }
    function isActiveFighter(I, id) {
        if (I.state !== "MATCH") return false;
        if (I.ffa) return has(I.ffaAlive, id);
        return inActiveMatch(I, id) && !has(I.downed, id) && !has(I.eliminated, id);
    }
    function sideOf(I, id) {
        if (!I.active) return null;
        var a = team(I, I.active.a), b = team(I, I.active.b);
        return a && has(a.members, id) ? "a" : b && has(b.members, id) ? "b" : null;
    }
    function anyRun(fn) { var hit = null; Object.keys(RUNS).forEach(function (k) { if (!hit && fn(RUNS[k])) hit = RUNS[k]; }); return hit; }
    function activeFighterRun(id) { return anyRun(function (I) { return isActiveFighter(I, id); }); }
    function contestantRun(id) { return anyRun(function (I) { return isContestant(I, id) || (I.state === "SIGNUP" && has(I.signups, id)); }); }

    // ---- sign-up -------------------------------------------------------------------------------
    function openSignups(defId, minutes) {
        var def = getDef(defId), I = inst(defId);
        if (!def || I.state !== "IDLE" || !S.hasAllRegions(def)) return false;
        RUNS[defId] = I = blank(defId);
        I.state = "SIGNUP";
        I.signupEnd = now() + Math.max(1, minutes || def.signupMinutes) * 60000;
        announce(fmt(def.msgSignupOpen, def), "&eSign-ups Open!", def);
        joinPrompt(def, "&7» Click to enter &e" + def.name + "&7: ");
        save();
        return true;
    }
    function joinResult(defId, p) {
        var def = getDef(defId), I = inst(defId), id = uid(p);
        if (!def) return "NO_SUCH_TOURNAMENT";
        if (I.state !== "SIGNUP") return "CLOSED";
        if (has(I.signups, id)) return "ALREADY";
        if (def.maxParticipants > 0 && I.signups.length >= def.maxParticipants) return "FULL";
        if (tc() && tc().isCreating(p)) return "CREATING";
        if (def.requireCharacter && !created(p)) return "NO_CHARACTER";
        var other = anyRun(function (R) { return R !== I && (has(R.signups, id) && R.state === "SIGNUP" || isContestant(R, id)); });
        if (other) return "BUSY";
        if (barringTitles(def, id).length) return "TITLE_HOLDER";
        I.signups.push(id);
        I.names[id] = p.name;
        rememberReturn(p);
        dirty = true;
        if (def.maxParticipants > 0 && I.signups.length >= def.maxParticipants) {
            announce("&6[" + def.name + "] &fRoster full - starting now!", "&6" + def.name + "!", def);
            begin(I);
        }
        return "OK";
    }
    function barringTitles(def, id) { return heldTitleIds(id).filter(function (t) { return has(def.excludeTitleIds, t); }); }
    function joinMessage(res, def, p) {
        switch (res) {
            case "OK": return "&aYou have signed up for '" + def.name + "&a'!";
            case "ALREADY": return "&eYou are already signed up.";
            case "CLOSED": return "&7Sign-ups aren't open yet - talk to the NPC when they are.";
            case "FULL": return "&cThat tournament is full.";
            case "NO_CHARACTER": return "&cCreate a DragonMineZ character first.";
            case "CREATING": return "&cFinish (or /tourney cancelcharacter) the tournament character you are building first.";
            case "BUSY": return "&cYou are already entered in another tournament.";
            case "TITLE_HOLDER":
                var t = barringTitles(def, uid(p));
                return t.length ? "&cYou hold a barred title (" + t.join(", ") + ") and cannot enter this tournament. Pass it on first."
                    : "&cTitle holders cannot enter this tournament. Pass your title on first.";
            default: return "&cNo such tournament.";
        }
    }
    function leave(defId, id) {
        var I = inst(defId);
        if (I.state !== "SIGNUP" || !del(I.signups, id)) return false;
        removeFromPending(I, id);
        var p = player(id) || RPG.player(I.names[id] || "");
        if (p) p.setVar(V_RET, null);
        dirty = true;
        return true;
    }
    function removeFromPending(I, id) {
        var removed = false;
        I.pending.forEach(function (t) { if (del(t.members, id)) removed = true; });
        I.pending = I.pending.filter(function (t) { return t.members.length > 0; });
        return removed;
    }
    function ensureSignedUp(I, p) { return has(I.signups, uid(p)) || joinResult(I.defId, p) === "OK"; }
    function createTeam(defId, p, name) {
        var I = inst(defId), def = getDef(defId);
        if (!def || I.state !== "SIGNUP" || !S.isTeam(S.format(def.format)) || !ensureSignedUp(I, p)) return false;
        removeFromPending(I, uid(p));
        name = String(name || "").replace(/[\u0000-\u001f]/g, "").trim().substring(0, 24);
        I.pending.push({ id: I.nextPending++, name: name || p.name + "'s Team", members: [uid(p)] });
        dirty = true;
        return true;
    }
    function joinTeam(defId, p, teamId) {
        var I = inst(defId), def = getDef(defId);
        if (!def || I.state !== "SIGNUP" || !S.isTeam(S.format(def.format))) return false;
        var t = I.pending.filter(function (x) { return x.id === Number(teamId); })[0];
        if (!t || t.members.length >= S.format(def.format).size || !ensureSignedUp(I, p)) return false;
        removeFromPending(I, uid(p));
        if (!I.pending.some(function (x) { return x === t; })) I.pending.push(t);    // was emptied by the move: keep it
        t.members.push(uid(p));
        dirty = true;
        return true;
    }

    // ---- start (begin / buildTeams) ------------------------------------------------------------
    function buildTeams(I, def, f) {
        var result = [], nextId = 1;
        if (!S.isTeam(f)) {
            I.signups.forEach(function (id) { if (player(id)) result.push({ id: nextId++, name: nameOf(I, id), members: [id] }); });
            return result;
        }
        var size = f.size, forming = [], assigned = [];
        I.pending.forEach(function (t) {
            var m = t.members.filter(function (id) { return has(I.signups, id) && player(id); });
            if (m.length) { forming.push({ name: t.name, members: m }); assigned = assigned.concat(m); }
        });
        var solos = shuffle(I.signups.filter(function (id) { return !has(assigned, id) && player(id); }));
        if (def.allowRandomFill) {
            forming.forEach(function (t) { while (t.members.length < size && solos.length) t.members.push(solos.shift()); });
            while (solos.length >= size) forming.push({ name: null, members: solos.splice(0, size) });
        }
        forming.forEach(function (t) {
            if (t.members.length === size) result.push({ id: nextId++, name: t.name && String(t.name).trim() ? t.name : nameOf(I, t.members[0]) + "'s Team", members: t.members });
            else t.members.forEach(function (id) { var p = player(id); if (p) p.tell("&cNot enough players to form a full team - you were dropped."); });
        });
        // solos who never got a team are told too
        solos.forEach(function (id) { var p = player(id); if (p) p.tell("&cNot enough players to form a full team - you were dropped."); });
        return result;
    }
    function begin(I) {
        var def = getDef(I.defId);
        if (!def) { resetToIdle(I); return; }
        var f = S.format(def.format);
        var built = buildTeams(I, def, f);
        var minTeams = Math.max(2, S.isTeam(f) ? 2 : def.minParticipants);
        if (built.length < minTeams) {
            broadcast("&c[" + def.name + "&c] Not enough fighters. Cancelled.");
            resetToIdle(I);
            return;
        }
        I.teams = built;
        I.participants = [];
        built.forEach(function (t) { I.participants = I.participants.concat(t.members); });
        // signed up but not fighting (dropped from a team, offline): their return point is let go
        I.signups.forEach(function (id) { if (!has(I.participants, id)) { var p = player(id); if (p) { restoreFighter(p); returnHome(p); } } });
        I.eliminated = []; I.downed = []; I.tookOff = []; I.flightCut = [];
        // a tournament character replaces the item stash: the fighter carries nothing of its own
        if (charsOn(def)) I.participants.forEach(function (id) { var p = player(id); if (p && !tc().enter(p, def.id) && !tc().isActive(p) && !def.itemsAllowed) vaultStore(p); });
        else if (!def.itemsAllowed) I.participants.forEach(function (id) { var p = player(id); if (p) vaultStore(p); });
        I.participants.forEach(function (id) { var p = player(id); if (p) { rememberReturn(p); RPG.data.addScore(B_PLAYED, p, 1); } });
        announce(fmt(def.msgStarting, def).replace(/\{count\}/g, String(I.participants.length)), "&6" + def.name + "!", def);
        I.ffa = S.isFfa(f);
        if (I.ffa) beginFfa(I, def);
        else { I.bracket = newBracket(I.teams.map(function (t) { return t.id; })); prepareNextMatch(I); }
        parkInWaiting(I, def);
        dirty = true;
    }
    function parkInWaiting(I, def) {
        if (!def.waiting) return;
        I.participants.forEach(function (id) { if (!inActiveMatch(I, id) && !has(I.eliminated, id)) teleportInto(player(id), def.waiting); });
    }

    // ---- Bracket: single elimination, one match at a time, odd team out gets a bye -----------
    function newBracket(ids) {
        var b = { round: 1, current: shuffle(ids.slice()), winners: [], pending: [], history: [], champion: null, runnerUp: null };
        buildRound(b);
        return b;
    }
    function buildRound(b) {
        b.pending = [];
        for (var i = 0; i < b.current.length; i += 2) b.pending.push([b.current[i], i + 1 < b.current.length ? b.current[i + 1] : null]);
        b.history.push(b.pending.map(function (m) { return { a: m[0], b: m[1], w: null }; }));
    }
    function nextMatch(b) {
        while (true) {
            if (!b.pending.length) {
                if (b.winners.length <= 1) { if (b.winners.length === 1) b.champion = b.winners[0]; return null; }
                b.current = b.winners; b.winners = []; b.round++;
                buildRound(b);
            }
            var m = b.pending[0];
            if (m[1] === null) { b.pending.shift(); b.winners.push(m[0]); record(b, m, m[0]); continue; }
            return m;
        }
    }
    function record(b, m, w) {
        var round = b.history[b.history.length - 1] || [];
        round.forEach(function (h) { if (h.a === m[0] && h.b === m[1]) h.w = w; });
    }
    function completeMatch(b, m, winner) {
        b.pending = b.pending.filter(function (x) { return !(x[0] === m[0] && x[1] === m[1]); });
        b.winners.push(winner);
        record(b, m, winner);
        if (!b.pending.length && b.current.length === 2) b.runnerUp = winner === m[0] ? m[1] : m[0];
    }

    // ---- bouts --------------------------------------------------------------------------------
    function resetBout(I) { I.downed = []; I.tookOff = []; I.flightCut = []; }
    function prepareNextMatch(I) {
        var def = getDef(I.defId);
        resetBout(I);
        var m = nextMatch(I.bracket);
        I.active = m ? { a: m[0], b: m[1] } : null;
        if (!m) { finishBracket(I); return; }
        var A = team(I, m[0]), B = team(I, m[1]);
        var aLive = anyOnline(A), bLive = anyOnline(B);
        if (!aLive && !bLive) { resolveMatch(I, A); return; }
        if (!aLive) { resolveMatch(I, B); return; }
        if (!bLive) { resolveMatch(I, A); return; }
        placeTeam(I, A, true, def); placeTeam(I, B, false, def);
        announceTo(I.participants, fmt(def.msgMatch, def).replace(/\{p1\}/g, teamName(I, A, def)).replace(/\{p2\}/g, teamName(I, B, def)), "&eFight!", def);
        I.ticks = 0;
        I.phase = Math.max(1, def.countdownSeconds) * 20;
        I.state = "COUNTDOWN";
        dirty = true;
    }
    function anyOnline(t) { return !!t && t.members.some(function (id) { return !!player(id); }); }
    function placeTeam(I, t, sideA, def) {
        var r = def.arena;
        t.members.forEach(function (id, i) {
            var p = player(id);
            if (!p) return;
            var at = sideSpawn(r, sideA, i, t.members.length), face = sideSpawn(r, !sideA, i, t.members.length);
            var yaw = Math.atan2(face[1] - at[1], face[0] - at[0]) * 180 / Math.PI - 90;
            var y = snap(r, Math.floor(at[0]), Math.floor(at[1]));
            p.teleportTo(r.dim, at[0], y, at[1], yaw, 0);
            p.fallDistance = 0;
            prepFighter(p, def, sideA ? TEAM_A : TEAM_B);
        });
    }
    function prepFighter(p, def, side) {
        if (charsOn(def)) {
            if (!tc().isActive(p)) tc().enter(p, def.id);    // reconnected or late: never fight as yourself in a character tournament
            tc().newBout(p);
        }
        if (def.healAfterFight) fullHeal(p);
        if (def.forceFriendlyFist) setFriendlyFist(p, true);
        setSide(p, side);
    }
    function beginFfa(I, def) {
        I.ffaAlive = I.teams.map(function (t) { return t.members[0]; });
        I.ffaOrder = [];
        placeFfa(I, def);
        announceTo(I.participants, "&6[" + def.name + "&6] &fTournament of Power - " + I.ffaAlive.length + " fighters!", "&6Battle Royale!", def);
        I.ticks = 0;
        I.phase = Math.max(1, def.countdownSeconds) * 20;
        I.state = "COUNTDOWN";
    }
    function placeFfa(I, def) {
        I.ffaAlive.forEach(function (id) {
            var p = player(id);
            if (!p) return;
            var at = randomStand(def.arena);
            p.teleportTo(def.arena.dim, at[0], at[1], at[2], p.yaw, 0);
            p.fallDistance = 0;
            prepFighter(p, def, null);
        });
    }

    function tickRun(I) {
        switch (I.state) {
            case "SIGNUP":
                if (now() >= I.signupEnd) begin(I); else tickReminder(I);
                break;
            case "COUNTDOWN": tickCountdown(I); break;
            case "MATCH": if (I.ffa) tickFfa(I); else tickMatch(I); break;
            case "INTERMISSION": if (--I.phase <= 0) prepareNextMatch(I); break;
            case "FINISHED": if (--I.phase <= 0) resetToIdle(I); break;
        }
    }
    function tickReminder(I) {
        var def = getDef(I.defId);
        if (!def || def.signupReminderSeconds <= 0) return;
        if (++I.reminder < def.signupReminderSeconds * 20) return;
        I.reminder = 0;
        var left = Math.max(0, Math.floor((I.signupEnd - now()) / 1000));
        show(RPG.server.players(), null, "&eSign-ups Open!", "&6" + def.name, def);
        joinPrompt(def, "&e[" + def.name + "&e] &fSign-ups still open &7(" + I.signups.length + " in, " + S.mmss(left) + " left)&f: ");
    }
    function tickCountdown(I) {
        var def = getDef(I.defId);
        if (I.phase % 20 === 0 && I.phase / 20 > 0) {
            broadcastTo(I.participants, "&e" + (I.phase / 20) + "...");
            fighters(I).forEach(function (p) { p.actionbar("&e&l" + (I.phase / 20)); });
        }
        if (--I.phase > 0) return;
        // re-place and heal at the bell so countdown damage or drift never carries into the bout
        if (I.ffa) placeFfa(I, def);
        else { placeTeam(I, team(I, I.active.a), true, def); placeTeam(I, team(I, I.active.b), false, def); }
        I.state = "MATCH";
        I.ticks = 0;
        announceTo(I.participants, "&6[" + def.name + "&6] FIGHT!", "&cFIGHT!", def);
        dirty = true;
    }
    function fighters(I) {
        var ids = I.ffa ? I.ffaAlive : (function () { var a = team(I, I.active.a), b = team(I, I.active.b); return (a ? a.members : []).concat(b ? b.members : []); })();
        return ids.map(player).filter(function (p) { return !!p; });
    }
    function tickMatch(I) {
        var def = getDef(I.defId);
        I.ticks++;
        var A = team(I, I.active.a), B = team(I, I.active.b);
        if (I.ticks > MATCH_START_GRACE_TICKS) {
            scanTeam(I, A, def); scanTeam(I, B, def);
            var aDown = teamDown(I, A), bDown = teamDown(I, B);
            if (aDown || bDown) { resolveMatch(I, bDown ? A : B); return; }      // both fell: side A wins
        }
        if (def.matchTimeLimit > 0 && I.ticks >= def.matchTimeLimit * 20) resolveMatch(I, teamHealth(A) >= teamHealth(B) ? A : B);
    }
    function scanTeam(I, t, def) {
        t.members.forEach(function (id) {
            if (has(I.downed, id)) return;
            var p = player(id);
            trackFlight(I, p, def);
            var reason = defeatReason(I, p, def);
            if (reason) { I.downed.push(id); knockOut(I, id, def, reason); }
        });
    }
    function tickFfa(I) {
        var def = getDef(I.defId);
        I.ticks++;
        if (I.ticks > MATCH_START_GRACE_TICKS) {
            I.ffaAlive.slice().forEach(function (id) {
                var p = player(id);
                trackFlight(I, p, def);
                var reason = defeatReason(I, p, def);
                if (!reason) return;
                del(I.ffaAlive, id);
                I.ffaOrder.push(id);
                knockOut(I, id, def, reason);
                broadcastTo(I.participants, "&6[" + def.name + "&6] &e" + nameOf(I, id) + " &fis out! &7(" + I.ffaAlive.length + " left)");
            });
            if (I.ffaAlive.length <= 1) { finishFfa(I); return; }
        }
        if (def.matchTimeLimit > 0 && I.ticks >= def.matchTimeLimit * 20) {
            var alive = I.ffaAlive.slice().sort(function (x, y) { return healthOf(y) - healthOf(x); });
            for (var i = alive.length - 1; i >= 1; i--) I.ffaOrder.push(alive[i]);
            I.ffaAlive = alive.length ? [alive[0]] : [];
            finishFfa(I);
        }
    }
    function trackFlight(I, p, def) {
        if (!p) return;
        if (!def.flightAllowed) {
            if (flying(p)) {
                land(p);
                // the first cut only: someone hovering at the bell did not choose to fall
                if (!has(I.flightCut, uid(p))) { I.flightCut.push(uid(p)); p.fallDistance = 0; }
            }
            return;
        }
        if (def.groundOut && !touchingGround(p)) add(I.tookOff, uid(p));
    }
    function defeatReason(I, p, def) {
        if (!p) return "logged off";
        // ring-out counts once they are down outside, so someone knocked flying can recover
        if (def.ringOut && touchingGround(p) && !inRegion(def.arena, p)) return "left the arena";
        // floor-out does NOT wait for the ground: passing the line in the air is enough
        if (def.floorOut && p.y < def.floorOutY) return "fell below the ring";
        if (def.groundOut && def.flightAllowed && touchingGround(p) && has(I.tookOff, uid(p))) return "touched the ground";
        if (!p.isAlive()) return "died";
        if (p.health <= 1.0) return "health depleted";
        if (p.hasEffect("knocked_down") || p.hasEffect("dmz_knocked_out")) return "knocked down";
        return null;
    }
    function knockOut(I, id, def, reason) {
        add(I.eliminated, id);
        var p = player(id);
        if (p) {
            if (def.healAfterFight) fullHeal(p);
            teleportInto(p, def.stands);
            restoreFighter(p);
            p.tell("&7You are out (" + reason + "). Watch the rest from the stands.");
        }
        RPG.log("[" + def.id + "] " + nameOf(I, id) + " knocked out (" + reason + ")");
        dirty = true;
    }
    function teamDown(I, t) { return t.members.every(function (id) { return has(I.downed, id); }); }
    function healthOf(id) { var p = player(id); return p && p.maxHealth > 0 ? p.health / p.maxHealth : 0; }
    function teamHealth(t) { var s = 0; t.members.forEach(function (id) { s += healthOf(id); }); return s; }
    function resolveMatch(I, winner) {
        var def = getDef(I.defId), m = [I.active.a, I.active.b];
        completeMatch(I.bracket, m, winner.id);
        var loser = team(I, winner.id === m[0] ? m[1] : m[0]);
        winner.members.forEach(function (id) {
            var p = player(id);
            if (!p) return;
            if (def.healAfterFight) fullHeal(p);
            setFriendlyFist(p, false);
            restoreSide(p);
            teleportInto(p, def.waiting);
            RPG.data.addScore(B_BOUTS, p, 1);
        });
        if (loser) loser.members.forEach(function (id) {
            add(I.eliminated, id);
            if (has(I.downed, id)) return;
            var p = player(id);
            if (!p) return;
            if (def.healAfterFight) fullHeal(p);
            teleportInto(p, def.stands);
            restoreFighter(p);
        });
        announceTo(I.participants, fmt(def.msgMatchWin, def).replace(/\{winner\}/g, teamName(I, winner, def)).replace(/\{loser\}/g, teamName(I, loser, def)), null, def);
        I.phase = 5 * 20;
        I.state = "INTERMISSION";
        dirty = true;
    }
    function finishBracket(I) { awardAndFinish(I, team(I, I.bracket.champion), team(I, I.bracket.runnerUp)); }
    function finishFfa(I) {
        var order = I.ffaOrder, champ = I.ffaAlive.length ? I.ffaAlive[0] : (order.length ? order[order.length - 1] : null), runner = null;
        if (order.length) { var last = order[order.length - 1]; runner = champ === last && order.length >= 2 ? order[order.length - 2] : (champ === last ? null : last); }
        I.ffaAlive.forEach(function (id) { var p = player(id); if (p) { restoreFighter(p); } });
        awardAndFinish(I, champ ? teamOfMember(I, champ) : null, runner ? teamOfMember(I, runner) : null);
    }
    function awardAndFinish(I, champion, runnerUp) {
        var def = getDef(I.defId), label = champion ? teamName(I, champion, def) : "(nobody)";
        I.active = null;
        announce(fmt(def.msgChampion, def).replace(/\{champion\}/g, label), "&6" + label + " wins!", def);
        var awarded = [];
        if (champion) champion.members.forEach(function (id) {
            awarded.push(id);
            var p = player(id);
            if (!p) return;
            restoreFighter(p);
            giveAll(p, def.winnerRewards);
            RPG.data.addScore(B_WINS, p, 1);
        });
        if (runnerUp) runnerUp.members.forEach(function (id) {
            awarded.push(id);
            var p = player(id);
            if (p) { restoreFighter(p); giveAll(p, def.runnerUpRewards); }
        });
        I.participants.forEach(function (id) {
            if (has(awarded, id)) return;
            var p = player(id);
            if (p) { restoreFighter(p); giveAll(p, def.participationRewards); }
        });
        I.phase = 10 * 20;
        I.state = "FINISHED";
        dirty = true;
    }
    function cancel(defId) {
        var I = inst(defId), def = getDef(defId);
        if (I.state === "IDLE") return false;
        broadcast("&c[" + (def ? def.name : defId) + "&c] Tournament cancelled by an administrator.");
        resetToIdle(I);
        return true;
    }
    function resetToIdle(I) {
        // hand everything back before the roster is forgotten, then send everyone home
        I.participants.concat(I.signups).forEach(function (id) { var p = player(id); if (p) { restoreFighter(p); returnHome(p); } });
        RUNS[I.defId] = blank(I.defId);
        dirty = true;
    }
    function forceStart(defId) { var I = inst(defId); if (I.state !== "SIGNUP") return false; begin(I); return true; }

    function statusLine(defId) {
        var def = getDef(defId), I = inst(defId);
        if (!def) return "&cNo tournament by that name.";
        var sb = "&6[" + def.name + "&6] &7(" + S.format(def.format).label + ") &fState: &e" + I.state;
        if (I.state === "IDLE" && def.scheduleEnabled) {
            var next = nextRunMillis(def);
            if (next > 0) sb += " &f| Sign-ups open in &e" + S.mmss((next - now()) / 1000);
        } else if (I.state === "SIGNUP") sb += " &f| Signed up: &e" + I.signups.length + " &f| Closes in &e" + S.mmss((I.signupEnd - now()) / 1000);
        else if (I.ffa) sb += " &f| Fighters left: &e" + I.ffaAlive.length + "/" + I.participants.length;
        else if (I.bracket) {
            var out = 0;
            I.teams.forEach(function (t) { if (t.members.every(function (id) { return has(I.eliminated, id); })) out++; });
            sb += " &f| Round &e" + I.bracket.round + " &f| Teams left: &e" + (I.teams.length - out);
            if (I.active) sb += " &f| Fighting: &e" + teamName(I, team(I, I.active.a), def) + " &fvs &e" + teamName(I, team(I, I.active.b), def);
        }
        return sb;
    }

    // ---- Scheduler: DAILY / WEEKLY / MONTHLY from the def's day fields (0 = ignore) --------
    function dim(y, m) { return new Date(y, m + 1, 0).getDate(); }
    function slotOf(def, nowD, dir) {        // dir -1: most recent slot at or before now, +1: soonest slot after now
        var h = Math.max(0, Math.min(23, def.scheduleHour)), mi = Math.max(0, Math.min(59, def.scheduleMinute));
        var y = nowD.getFullYear(), m = nowD.getMonth(), d = nowD.getDate(), slot;
        if (def.scheduleDayOfMonth > 0) {
            slot = new Date(y, m, Math.min(def.scheduleDayOfMonth, dim(y, m)), h, mi, 0, 0);
            if (dir < 0 ? slot > nowD : slot <= nowD) {
                var mm = m + dir, yy = y + Math.floor(mm / 12);
                mm = ((mm % 12) + 12) % 12;
                slot = new Date(yy, mm, Math.min(def.scheduleDayOfMonth, dim(yy, mm)), h, mi, 0, 0);
            }
            return slot;
        }
        if (def.scheduleDayOfWeek > 0) {
            var target = def.scheduleDayOfWeek % 7;              // 1=Monday .. 7=Sunday -> JS 0=Sunday
            var k = 0;
            while (new Date(y, m, d + k * dir).getDay() !== target) k++;
            slot = new Date(y, m, d + k * dir, h, mi, 0, 0);
            if (dir < 0 ? slot > nowD : slot <= nowD) slot = new Date(y, m, d + k * dir + 7 * dir, h, mi, 0, 0);
            return slot;
        }
        slot = new Date(y, m, d, h, mi, 0, 0);
        if (dir < 0 ? slot > nowD : slot <= nowD) slot = new Date(y, m, d + dir, h, mi, 0, 0);
        return slot;
    }
    function nextRunMillis(def) { return def && def.scheduleEnabled ? slotOf(def, new Date(), 1).getTime() : -1; }
    function tickSchedules() {
        var last = RPG.data.get(K_LAST, null) || {}, changed = false, t = now();
        allDefs().forEach(function (def) {
            if (!def.scheduleEnabled) return;
            var slot = slotOf(def, new Date(t), -1).getTime();
            if (slot > (Number(last[def.id]) || 0) && t - slot <= FIRE_WINDOW_MS) {
                last[def.id] = slot; changed = true;
                if (inst(def.id).state === "IDLE" && S.hasAllRegions(def)) openSignups(def.id, def.signupMinutes);
            }
        });
        if (changed) RPG.data.set(K_LAST, last);
    }

    // ---- the tick --------------------------------------------------------------------------
    var tickCount = 0;
    RPG.every(1, function () {
        tickCount++;
        var busy = Object.keys(RUNS).some(function (k) { return RUNS[k].state !== "IDLE"; });
        if (busy) {
            refreshOnline();
            Object.keys(RUNS).forEach(function (k) {
                var I = RUNS[k];
                if (I.state === "IDLE") return;
                if (!getDef(k)) { resetToIdle(I); return; }
                try { tickRun(I); } catch (e) { RPG.log("[Tournament] " + k + ": " + e); }
            });
        }
        if (tickCount % 20 === 0) {
            if (!busy) refreshOnline();
            tickSchedules();
            if (busy || dirty) save();
            hud();
        }
        if (tickCount % 10 === 5) tickLook();
    });

    // ---- the HUD (client draws it): open sign-ups, and the bout for those watching ----------
    var LAST_HUD = {};
    function teamView(I, t, def) {
        if (!t) return null;
        return { n: S.strip(teamName(I, t, def)), m: t.members.map(function (id) {
            var p = player(id);
            return { n: nameOf(I, id), h: p ? Math.round(p.health) : 0, x: p ? Math.round(p.maxHealth) : 1, o: has(I.downed, id) || !p };
        }) };
    }
    function hud() {
        var signups = [], watch = [];
        Object.keys(RUNS).forEach(function (k) {
            var I = RUNS[k], def = getDef(k);
            if (!def) return;
            if (I.state === "SIGNUP") signups.push({ I: I, def: def });
            else if (I.state !== "IDLE") watch.push({ I: I, def: def });
        });
        RPG.server.players().forEach(function (p) {
            var id = uid(p), data = { s: [], m: null };
            signups.forEach(function (o) {
                data.s.push({ id: o.def.id, n: o.def.name, c: o.I.signups.length, l: Math.max(0, Math.floor((o.I.signupEnd - now()) / 1000)), i: has(o.I.signups, id) });
            });
            watch.forEach(function (o) {
                if (data.m) return;
                var I = o.I, def = o.def;
                if (!has(I.participants, id) && !inRegion(def.arena, p) && !inRegion(def.stands, p) && !inRegion(def.waiting, p)) return;
                var m = { n: def.name, st: I.state, r: I.bracket ? I.bracket.round : 0, me: isActiveFighter(I, id) || (I.state === "COUNTDOWN" && inActiveMatch(I, id)) };
                if (def.matchTimeLimit > 0 && I.state === "MATCH") m.t = Math.max(0, def.matchTimeLimit - Math.floor(I.ticks / 20));
                if (I.state === "COUNTDOWN") m.c = Math.ceil(I.phase / 20);
                if (I.ffa) m.f = { a: I.ffaAlive.length, t: I.participants.length };
                else if (I.active) { m.a = teamView(I, team(I, I.active.a), def); m.b = teamView(I, team(I, I.active.b), def); }
                data.m = m;
            });
            var key = JSON.stringify(data);
            if (LAST_HUD[id] === key) return;
            LAST_HUD[id] = key;
            RPG.net.send(p, "dbr_tourney_hud", data);
        });
    }

    // ---- sign-up hosts (TournamentNpcs) --------------------------------------------------------
    function saveHosts(h) { RPG.data.set(K_HOSTS, h); pushTags(); }
    function hostNpcId(def) {
        var model = def.npcModelId || "";
        if (!model && !def.npcEntityType) {
            var ch = String(C.get("npc.character") || "hercule").toLowerCase();
            model = ch === "hercule" ? "saga_cl_hercule" : ch === "announcer" ? "saga_cl_tournament_announcer" : ch;
        }
        if (model) {
            var entry = typeof rgNpcResolve === "function" ? rgNpcResolve(model) : null;
            if (entry) return rgNpcId(entry);
            if (RPG.npcs.exists(model)) return model;
        }
        return def.npcEntityType && RPG.npcs.exists(def.npcEntityType) ? def.npcEntityType : "rgnpc_saga_cl_hercule";
    }
    function nearestEntity(p, r, onlyHosts) {
        var best = null, bd = r * r, hs = hosts();
        p.nearby(r).forEach(function (e) {
            if (e.isPlayer() || (onlyHosts && !hs[String(e.uuid)])) return;
            var dx = e.x - p.x, dy = e.y - p.y, dz = e.z - p.z, d = dx * dx + dy * dy + dz * dz;
            if (d < bd) { bd = d; best = e; }
        });
        return best;
    }
    function tickLook() {
        var r = Number(C.get("npc.lookRadius")) || 0;
        if (r <= 0) return;
        var hs = hosts();
        Object.keys(hs).forEach(function (u) {
            var e = RPG.world.entityByUuid(u);
            if (!e) return;
            var best = null, bd = r * r;
            RPG.server.players().forEach(function (p) {
                if (String(p.dimension) !== String(e.dimension)) return;
                var dx = p.x - e.x, dy = p.y - e.y, dz = p.z - e.z, d = dx * dx + dy * dy + dz * dz;
                if (d < bd) { bd = d; best = p; }
            });
            if (best) try { e.lookAt(best.x, best.eyeY, best.z); } catch (err) { }
        });
    }
    RPG.on("entityInteract", function (p, e) {
        if (!e) return;
        var h = hosts()[String(e.uuid)];
        if (!h) return;
        if (h.t) openSignup(p, h.t); else openBrowser(p, h.g || "");
        return false;
    });

    // ---- screens -------------------------------------------------------------------------------
    function signupView(p, defId) {
        var def = getDef(defId), I = inst(defId);
        refreshOnline();
        var f = S.format(def.format);
        return { page: "signup", id: def.id, name: def.name, open: I.state === "SIGNUP", signed: has(I.signups, uid(p)), count: I.signups.length,
            state: I.state, format: f.id, size: f.size, chars: charsOn(def),
            teams: I.pending.map(function (t) { return { id: t.id, name: t.name, members: t.members.map(function (m) { return nameOf(I, m); }) }; }) };
    }
    function openSignup(p, defId) {
        if (!getDef(defId)) { p.tell("&cThat tournament no longer exists."); return; }
        RPG.net.send(p, "dbr_tourney_open", signupView(p, defId));
    }
    function openBrowser(p, group) {
        var g = S.strip(group || "").trim().toLowerCase();
        var list = allDefs().map(function (d) {
            var I = inst(d.id);
            return { id: d.id, name: d.name, group: d.group, fmt: S.format(d.format).label, open: I.state === "SIGNUP", count: I.signups.length, state: I.state };
        });
        var mine = g ? list.filter(function (e) { return S.strip(e.group).trim().toLowerCase() === g; }) : list;
        RPG.net.send(p, "dbr_tourney_open", { page: "browser", entries: mine.length || !g ? mine : list, admin: admin(p, "rg.tourney.edit"), chars: !!C.get("characters.enabled") && !!tc() });
    }
    function openEditor(p) {
        RPG.net.send(p, "dbr_tourney_open", { page: "list", defs: allDefs(), titles: titleIds(),
            states: (function () { var s = {}; allDefs().forEach(function (d) { s[d.id] = inst(d.id).state; }); return s; })() });
    }
    function bracketView(defId) {
        var def = getDef(defId), I = inst(defId);
        refreshOnline();
        var v = { page: "bracket", id: def.id, name: def.name, state: I.state, rounds: [], ffa: null, status: statusLine(defId) };
        if (I.ffa) v.ffa = { alive: I.ffaAlive.map(function (id) { return nameOf(I, id); }), out: I.ffaOrder.map(function (id) { return nameOf(I, id); }).reverse(), total: I.participants.length };
        else if (I.bracket) v.rounds = I.bracket.history.map(function (round) {
            return round.map(function (h) {
                var a = team(I, h.a), b = team(I, h.b), live = I.active && I.active.a === h.a && I.active.b === h.b;
                return { a: teamName(I, a, def), b: h.b === null ? null : teamName(I, b, def), w: h.w === null ? 0 : h.w === h.a ? 1 : 2, live: !!live };
            });
        });
        return v;
    }
    function topView() {
        function board(id) { try { return arr(RPG.data.top(id, 10)).map(function (e) { return { r: e.rank, n: e.name, s: e.score }; }); } catch (err) { return []; } }
        return { page: "top", wins: board(B_WINS), bouts: board(B_BOUTS), played: board(B_PLAYED) };
    }
    function canSee(p, defId) { var I = inst(defId); return has(I.participants, uid(p)) || has(I.signups, uid(p)); }

    // ---- messages from the screens (never trusted) ---------------------------------------------
    RPG.net.on("dbr_tourney", function (p, d) {
        if (!p || !d || typeof d !== "object") return;
        refreshOnline();
        var a = String(d.a || ""), id = String(d.id || "").toLowerCase(), def = id ? getDef(id) : null;
        if (tc() && (a === "char" || a.indexOf("char_") === 0)) { tc().action(p, d); return; }
        switch (a) {
            case "browse": openBrowser(p, String(d.group || "")); return;
            case "signup": if (def) openSignup(p, id); return;
            case "join": if (def && perm(p, "rg.tourney.join")) { p.tell(joinMessage(joinResult(id, p), def, p)); } return;
            case "leave": if (def) p.tell(leave(id, uid(p)) ? "&eYou have withdrawn." : "&cYou were not signed up."); return;
            case "tpwait": if (def) tpWait(p, def); return;
            case "status": if (def) p.tell(statusLine(id)); return;
            case "bracket": if (def) RPG.net.send(p, "dbr_tourney_open", bracketView(id)); return;
            case "top": RPG.net.send(p, "dbr_tourney_open", topView()); return;
            case "create_team":
                if (!def) return;
                p.tell(createTeam(id, p, String(d.name || "")) ? "&aTeam created - teammates can join it from the sign-up screen." : "&cCould not create a team (sign-ups closed or full).");
                openSignup(p, id); return;
            case "join_team":
                if (!def) return;
                p.tell(joinTeam(id, p, Number(d.team) || 0) ? "&aJoined the team!" : "&cCould not join that team (full or missing).");
                openSignup(p, id); return;
            case "leave_team":
                if (!def) return;
                p.tell(removeFromPending(inst(id), uid(p)) ? (dirty = true, "&eYou left your team.") : "&cYou were not in a team.");
                openSignup(p, id); return;
            case "gem": useGem(p, Number(d.amount), String(d.stat || "")); return;
        }
        // ---- the editor (ops / rg.tourney.edit) ----
        if (!admin(p, "rg.tourney.edit")) return;
        switch (a) {
            case "list": openEditor(p); return;
            case "new": var nd = createDefault(newId(), "New Tournament"); RPG.net.send(p, "dbr_tourney_open", { page: "edit", def: nd, titles: titleIds(), isNew: true }); return;
            case "save":
                var src = d.def && typeof d.def === "object" ? d.def : null;
                if (!src || !src.id) return;
                var saved = putDef(src);
                if (saved) { p.tell("&aSaved '" + saved.name + "&a'."); pushTags(); }
                if (d.reopen) openEditor(p);
                return;
            case "copy":
                if (!def) return;
                var cp = S.normalize(def); cp.id = newId(); cp.name = def.name + " (copy)"; putDef(cp); openEditor(p); return;
            case "delete":
                if (!def) return;
                if (inst(id).state !== "IDLE") cancel(id);
                deleteDef(id); delete RUNS[id]; p.tell("&eDeleted '" + def.name + "&e'."); openEditor(p); return;
            case "open_signups":
                if (!def) return;
                if (!S.hasAllRegions(def)) p.tell("&cSet arena, waiting and stands bounds first.");
                else p.tell(openSignups(id, def.signupMinutes) ? "&aSign-ups opened for '" + def.name + "&a'." : "&cThat tournament is already running.");
                return;
            case "bounds_we":
                var key = String(d.key || ""), base = d.def && typeof d.def === "object" ? S.normalize(d.def) : def;
                if (!base || ["arena", "waiting", "stands"].indexOf(key) < 0) return;
                var sel = p.getVar("we_sel", null);
                if (!sel || !sel.p1 || !sel.p2 || !sel.dim) { p.tell("&cMake a WorldEdit selection first (//wand, or //pos1 and //pos2)."); return; }
                base[key] = S.region({ dim: sel.dim, min: sel.p1, max: sel.p2 });
                base = putDef(base);
                p.tell("&a" + key + " bounds set: " + S.regionText(base[key]));
                RPG.net.send(p, "dbr_tourney_def", { def: base });
                return;
        }
    });
    function tpWait(p, def) {
        var I = inst(def.id), id = uid(p);
        if (!has(I.signups, id) && !isContestant(I, id)) { p.tell("&cOnly signed-up fighters can teleport to the waiting area."); return; }
        if (!def.waiting) { p.tell("&cThe waiting area is not configured."); return; }
        if (isActiveFighter(I, id)) { p.tell("&cYou are fighting!"); return; }
        rememberReturn(p);
        teleportInto(p, def.waiting);
        p.tell("&aTeleported to the fighter waiting area.");
    }

    // ---- stat gems (StatGemItem, StatGemScreen) -----------------------------------------------
    S.STAT_GEMS.forEach(function (n) {
        RPG.items.define("stat_gem_" + n, {
            name: "&bStat Gem (+" + n + ")", model: "dbr:rpg/item/tournaments/stat_gem_" + n, type: "gem", maxStack: 64, consume: false, useTime: 0,
            rarity: n >= 250 ? "epic" : n >= 50 ? "rare" : "uncommon",
            lore: ["&7" + S.t("item.stat_gem.tooltip", n)],
            onUse: function (p) {
                if (!created(p)) { p.actionbar("&c" + S.t("item.stat_gem.no_character")); return false; }
                RPG.net.send(p, "dbr_tourney_open", { page: "gem", amount: n });
                return false;
            }
        });
    });
    function useGem(p, amount, key) {
        if (S.STAT_GEMS.indexOf(amount) < 0 || !created(p)) return;
        var stat = null;
        S.GEM_STATS.forEach(function (g) { if (g[0] === key) stat = g; });
        if (!stat) return;
        // past the stat cap the rest goes into a worn Z-Soul (92_dbr_raids_zsouls.js) instead of vanishing
        var z = typeof DBR_ZSOUL !== "undefined" ? DBR_ZSOUL : null;
        var room = z ? Math.max(0, Math.floor(z.cap() - p.baseStat(stat[1]))) : amount;
        var direct = Math.min(amount, room), over = amount - direct, banked = over > 0 && z ? z.room(p, stat[1], over) : 0;
        if (direct <= 0 && banked <= 0) { p.actionbar("&c" + S.t("item.stat_gem.maxed")); return; }
        if (!p.takeItem("stat_gem_" + amount, 1)) return;
        if (direct > 0) p.addStat(stat[1], direct);
        if (banked > 0) banked = z.grantBeyondCap(p, stat[1], banked);
        p.refreshStats();
        p.playSound("minecraft:entity.player.levelup", 0.6, 1.4);
        if (banked > 0) p.actionbar("&a" + S.t("item.stat_gem.used_one_zsoul", direct, S.t("gem.stat." + key), banked));
        else p.actionbar("&a" + S.t("item.stat_gem.used_one", direct, S.t("gem.stat." + key)));
    }

    // ---- rule enforcement (ForgeEventHandler) -----------------------------------------------
    RPG.on("itemUse", function (p) {
        var I = activeFighterRun(uid(p));
        if (!I) return;
        var def = getDef(I.defId);
        if (def && !def.itemsAllowed) return false;
    });
    RPG.on("hurt", function (e) {
        var t = e.target, a = e.attacker;
        if (!t || !t.isPlayer() || !a || !a.isPlayer()) return;
        var tid = String(t.uuid), aid = String(a.uuid);
        if (tid === aid) return;
        // a live bout: teammates can't hurt each other, and nobody outside the bout can reach in
        var I = activeFighterRun(tid);
        if (I) {
            if (!isActiveFighter(I, aid)) { e.cancel(); return; }
            if (!I.ffa && sideOf(I, aid) === sideOf(I, tid)) { e.cancel(); return; }
            return;
        }
        var tp = t.asPlayer(), stop = false;
        allDefs().forEach(function (def) {
            if (stop) return;
            if (inRegion(def.waiting, tp) && !def.pvpInWaiting) stop = true;
            else if (inRegion(def.stands, tp) && !def.pvpInStands) stop = true;
        });
        if (stop) e.cancel();
    });
    // in a live bout nobody dies: the would-be kill leaves 1 HP and the tick reads it as a knockout
    RPG.on("lethal", function (e) {
        var t = e.target;
        if (!t || !t.isPlayer() || (e.isCancelled && e.isCancelled())) return;
        if (!activeFighterRun(String(t.uuid))) return;
        e.cancel();
        t.asPlayer().health = 1;
    });

    // ---- logins, logouts and reloads -------------------------------------------------------
    RPG.on("playerLeave", function (p) {
        // hand the stash back before the player is saved; the tournament reads "logged off" if they were fighting
        if (!activeFighterRun(uid(p))) { setFriendlyFist(p, false); vaultRestore(p); }
        // the real character goes back before the player is saved (a live bout reads "logged off" next tick)
        if (tc()) tc().exit(p);
        delete LAST_HUD[uid(p)];
    });
    RPG.on("playerJoin", function (p) {
        refreshOnline();
        var id = uid(p), I = contestantRun(id);
        if (!I || (I.state !== "SIGNUP" && !isActiveFighter(I, id) && !isContestant(I, id))) {
            restoreFighter(p);
            if (!I) returnHome(p);
        }
        RPG.schedule(20, function () { pushTags(p); });
    });
    // reload or restart: running tournaments come back from RPG.data; nobody keeps a stale stash
    (function restore() {
        var saved = RPG.data.get(K_RUNS, null) || {};
        Object.keys(saved).forEach(function (k) {
            var I = saved[k];
            if (!I || !getDef(k)) return;
            var b = blank(k);
            Object.keys(b).forEach(function (f) { if (I[f] === undefined) I[f] = b[f]; });
            ["signups", "teams", "participants", "eliminated", "ffaAlive", "ffaOrder", "downed", "tookOff", "flightCut", "pending"].forEach(function (f) { I[f] = arr(I[f]); });
            I.teams.forEach(function (t) { t.members = arr(t.members); });
            I.pending.forEach(function (t) { t.members = arr(t.members); });
            if (I.bracket) ["current", "winners", "pending", "history"].forEach(function (f) { I.bracket[f] = arr(I.bracket[f]); });
            if (I.state === "MATCH") I.ticks = 0;                    // a fresh grace period after the reload
            RUNS[k] = I;
        });
        RPG.schedule(40, function () {
            refreshOnline();
            RPG.server.players().forEach(function (p) {
                var I = contestantRun(uid(p));
                if (!I) { restoreFighter(p); returnHome(p); }
            });
            pushTags();
        });
    })();

    // ---- commands (TournamentCommand) ---------------------------------------------------------
    /** Words with "quoted parts" joined. */
    function words(args) {
        var out = [], buf = null;
        arr(args).forEach(function (w) {
            w = String(w);
            if (buf !== null) { buf += " " + w; if (/"$/.test(w)) { out.push(buf.replace(/^"|"$/g, "")); buf = null; } return; }
            if (/^"/.test(w) && !/^".*"$/.test(w)) { buf = w; return; }
            out.push(w.replace(/^"|"$/g, ""));
        });
        if (buf !== null) out.push(buf.replace(/^"/, ""));
        return out;
    }
    var HELP = ["&6Tournaments: &f/tourney list | join <name> | leave <name> | tpwait <name> | status <name> | spectate <name> | bracket <name> | top",
        "&f/tourney char [create|build|moves|delete|cancel] | loadout | cancelcharacter &7(your tournament character)",
        "&f/tourney team create <team> <name> | team join <teamId> <name> | team leave <name>",
        "&7Ops: &fedit | open | start | cancel <name> | bounds <arena|waiting|stands> <x1 y1 z1> <x2 y2 z2> <name> | npc spawn|bind <name> | npc setgroup <group|all> | npc remove | npc removeall | title list|set|clear | config [key] [value] | forceexit <player>"];
    // Config.EDITABLE_KEYS -> dbr_tournaments keys
    var CONFIG_KEYS = { items: "rules.itemsAllowedInArena", healafterfight: "rules.healAfterFight", friendlyfist: "rules.forceFriendlyFist",
        pvpwaiting: "rules.allowPvpInWaitingArea", pvpstands: "rules.allowPvpInStands", countdown: "rules.countdownSeconds",
        timelimit: "rules.matchTimeLimitSeconds", maxparticipants: "signup.maxParticipants", minparticipants: "signup.minParticipants",
        signupminutes: "signup.durationMinutes", signupreminder: "signup.reminderSeconds", requirecharacter: "signup.requireDmzCharacter",
        tournamentchars: "characters.enabled", statallocations: "characters.statAllocations", forcetransform: "characters.forceTransformAtHalfHealth",
        formmultiplier: "characters.forcedFormStatMultiplier", iframeticks: "characters.forcedTransformIframeTicks", npcname: "npc.name", npccharacter: "npc.character", npclookradius: "npc.lookRadius",
        schedule: "schedule.mode", schedulehour: "schedule.hour", scheduleminute: "schedule.minute", scheduledayofweek: "schedule.dayOfWeek",
        scheduledayofmonth: "schedule.dayOfMonth", usetitles: "announce.useOnScreenTitles", sound: "announce.sound" };
    function configValue(key, raw) {
        var cur = C.get(key);
        if (typeof cur === "boolean") return /^(true|on|1|yes)$/i.test(raw);
        if (typeof cur === "number") return Number(raw);
        return key === "schedule.mode" ? String(raw).toUpperCase() : String(raw);
    }
    function command(p, args) {
        var w = words(args), sub = String(w[0] || "").toLowerCase(), rest = w.slice(1).join(" ");
        function need(node) { if (admin(p, node)) return true; tell(p, "&cYou don't have permission (" + node + ")."); return false; }
        function useP(node) { if (perm(p, node)) return true; tell(p, "&cYou don't have permission (" + node + ")."); return false; }
        function byName(s) { var d = resolve(s); if (!d) tell(p, "&cNo tournament by that name."); return d; }
        function me() { if (p) return true; tell(p, "This command must be run by a player."); return false; }
        refreshOnline();
        switch (sub) {
            case "": case "help": HELP.forEach(function (l) { tell(p, l); }); return;
            case "list":
                if (!useP("rg.tourney.list")) return;
                var all = allDefs();
                if (!all.length) { tell(p, "&7No tournaments. Use /tourney edit to create one."); return; }
                tell(p, "&6Tournaments:");
                all.forEach(function (d) { tell(p, "&e" + d.name + " &7[" + (S.hasAllRegions(d) ? "&aready" : "&cno bounds") + "&7, " + inst(d.id).state + "] &8(" + d.id + ")"); });
                return;
            case "join":
                if (!me() || !useP("rg.tourney.join")) return;
                var dj = byName(rest); if (dj) tell(p, joinMessage(joinResult(dj.id, p), dj, p)); return;
            case "leave":
                if (!me() || !useP("rg.tourney.leave")) return;
                var dl = byName(rest);
                if (!dl) return;
                if (leave(dl.id, uid(p))) { tell(p, "&eYou have withdrawn."); return; }
                // a spectator (or an eliminated fighter) heading home from the stands
                if (p.getVar(V_RET, null) && !contestantRun(uid(p))) { returnHome(p); tell(p, "&eBack where you were."); return; }
                tell(p, "&cYou were not signed up."); return;
            case "tpwait":
                if (!me() || !useP("rg.tourney.tpwait")) return;
                var dw = byName(rest); if (dw) tpWait(p, dw); return;
            case "status":
                if (!useP("rg.tourney.status")) return;
                var ds = byName(rest); if (ds) tell(p, statusLine(ds.id)); return;
            case "spectate":
                if (!me() || !useP("rg.tourney.spectate")) return;
                var dsp = byName(rest);
                if (!dsp) return;
                if (!dsp.stands) { tell(p, "&cThat tournament has no stands."); return; }
                if (activeFighterRun(uid(p))) { tell(p, "&cYou are fighting!"); return; }
                rememberReturn(p); teleportInto(p, dsp.stands); tell(p, "&aWelcome to the stands. &7(/tourney leave " + dsp.id + " takes you back)"); return;
            case "bracket":
                if (!me() || !useP("rg.tourney.bracket")) return;
                var db = byName(rest); if (db) RPG.net.send(p, "dbr_tourney_open", bracketView(db.id)); return;
            case "top":
                if (!me() || !useP("rg.tourney.top")) return;
                RPG.net.send(p, "dbr_tourney_open", topView()); return;
            case "browse":
                if (!me()) return;
                openBrowser(p, rest); return;
            case "team":
                if (!me() || !useP("rg.tourney.team")) return;
                var op = String(w[1] || "").toLowerCase();
                if (op === "create") { var dc = byName(w.slice(3).join(" ")); if (dc) tell(p, createTeam(dc.id, p, w[2]) ? "&aTeam '" + w[2] + "' created - teammates use /tourney team join." : "&cCould not create a team (sign-ups closed, full or not a team format)."); }
                else if (op === "join") { var dt = byName(w.slice(3).join(" ")); if (dt) tell(p, joinTeam(dt.id, p, Number(w[2])) ? "&aJoined the team!" : "&cCould not join that team (full or missing)."); }
                else if (op === "leave") { var dlt = byName(w.slice(2).join(" ")); if (dlt) { var ok = removeFromPending(inst(dlt.id), uid(p)); dirty = dirty || ok; tell(p, ok ? "&eYou left your team." : "&cYou were not in a team."); } }
                else tell(p, "&c/tourney team create <team> <name> | team join <teamId> <name> | team leave <name>");
                return;
            case "char":
                if (!me() || !useP("rg.tourney.char")) return;
                if (!tc()) { tell(p, "&cTournament characters are not loaded."); return; }
                tc().command(p, w.slice(1)); return;
            case "loadout":
                if (!me() || !useP("rg.tourney.loadout") || !tc()) return;
                tc().command(p, ["moves"]); return;
            case "cancelcharacter":
                if (!me() || !useP("rg.tourney.cancelcharacter") || !tc()) return;
                tc().cancelCreation(p); return;
            case "edit":
                if (!me() || !need("rg.tourney.edit")) return;
                openEditor(p); return;
            case "open":
                if (!need("rg.tourney.open")) return;
                var dop = byName(rest);
                if (!dop) return;
                if (!S.hasAllRegions(dop)) { tell(p, "&cSet arena, waiting and stands bounds first (/tourney edit)."); return; }
                tell(p, openSignups(dop.id, dop.signupMinutes) ? "&aSign-ups opened for '" + dop.name + "&a'." : "&cThat tournament is already running."); return;
            case "start":
                if (!need("rg.tourney.start")) return;
                var dst = byName(rest); if (dst) tell(p, forceStart(dst.id) ? "&aStarting now!" : "&cSign-ups are not open for that tournament."); return;
            case "cancel":
                if (!need("rg.tourney.cancel")) return;
                var dca = byName(rest); if (dca) tell(p, cancel(dca.id) ? "&eTournament cancelled." : "&cThat tournament is not running."); return;
            case "forceexit":
                if (!need("rg.tourney.forceexit")) return;
                var target = RPG.player(w[1] || "");
                if (!target) { tell(p, "&cNo such player online."); return; }
                if (activeFighterRun(uid(target))) { tell(p, "&cThey are fighting in a live tournament. Cancel the tournament first."); return; }
                if (tc() && tc().isCreating(target)) tc().cancelCreation(target);
                restoreFighter(target); returnHome(target);
                target.tell("&eYou have been released from the tournament.");
                tell(p, "&a" + target.name + " has their own character, items, team and position back."); return;
            case "bounds":
                if (!need("rg.tourney.bounds")) return;
                var key = String(w[1] || "").toLowerCase(), nums = w.slice(2, 8).map(function (s, i) {
                    var base = !p ? 0 : [p.x, p.y, p.z][i % 3];
                    return /^~/.test(s) ? Math.floor(base + (Number(s.substring(1)) || 0)) : Number(s);
                });
                var dbn = byName(w.slice(8).join(" "));
                if (!dbn) return;
                if (["arena", "waiting", "stands"].indexOf(key) < 0 || nums.length < 6 || nums.some(function (n) { return isNaN(n); })) { tell(p, "&c/tourney bounds <arena|waiting|stands> <x1 y1 z1> <x2 y2 z2> <name>"); return; }
                dbn[key] = S.region({ dim: p ? String(p.dimension) : "minecraft:overworld", min: nums.slice(0, 3), max: nums.slice(3, 6) });
                putDef(dbn);
                tell(p, "&a" + key + " bounds set: " + S.regionText(dbn[key])); return;
            case "npc":
                if (!me() || !need("rg.tourney.npc")) return;
                var nop = String(w[1] || "").toLowerCase(), hs = hosts();
                if (nop === "spawn") {
                    var dn = byName(w.slice(2).join(" "));
                    if (!dn) return;
                    var npcId = hostNpcId(dn), e = RPG.world.spawnNpc(p.dimension, npcId, p.x, p.y, p.z);
                    if (!e) { tell(p, "&cFailed to spawn NPC '" + npcId + "'."); return; }
                    e.teleportTo(p.dimension, p.x, p.y, p.z, p.yaw, 0);
                    hs[String(e.uuid)] = { t: dn.id }; saveHosts(hs);
                    tell(p, "&aSpawned '" + dn.npcName + "&a' (" + npcId + ") for '" + dn.name + "&a'.");
                } else if (nop === "bind") {
                    var db2 = byName(w.slice(2).join(" "));
                    if (!db2) return;
                    var near = nearestEntity(p, 6, false);
                    if (!near) { tell(p, "&cNo entity within 6 blocks to bind."); return; }
                    hs[String(near.uuid)] = { t: db2.id }; saveHosts(hs);
                    tell(p, "&aBound the nearby " + near.name + " to '" + db2.name + "&a' (single sign-up).");
                } else if (nop === "setgroup") {
                    var group = w.slice(2).join(" ").trim();
                    if (group.toLowerCase() === "all") group = "";
                    var ng = nearestEntity(p, 6, false);
                    if (!ng) { tell(p, "&cNo entity within 6 blocks."); return; }
                    hs[String(ng.uuid)] = { g: group }; saveHosts(hs);
                    tell(p, "&aThe nearby " + ng.name + " now browses " + (group ? "the '" + group + "' group." : "all tournaments."));
                } else if (nop === "remove") {
                    var nh = nearestEntity(p, 8, true);
                    if (!nh) { tell(p, "&cNo tournament NPC within 8 blocks."); return; }
                    delete hs[String(nh.uuid)]; saveHosts(hs);
                    if (!nh.isPlayer()) nh.remove();
                    tell(p, "&aRemoved the nearby tournament NPC (" + nh.name + ").");
                } else if (nop === "removeall") {
                    var n = 0;
                    Object.keys(hs).forEach(function (u) { var ent = RPG.world.entityByUuid(u); if (ent && !ent.isPlayer()) { ent.remove(); n++; } });
                    saveHosts({});
                    tell(p, "&aRemoved " + n + " tournament NPC" + (n === 1 ? "" : "s") + " (unloaded ones are forgotten, not removed).");
                } else tell(p, "&c/tourney npc spawn <name> | bind <name> | setgroup <group|all> | remove | removeall");
                return;
            case "title":
                if (!need("rg.tourney.title")) return;
                var top = String(w[1] || "").toLowerCase();
                if (top === "list") {
                    var h = holders();
                    titleIds().forEach(function (tid) { tell(p, "&e" + tid + " &f-> " + titlePart(tid, 1) + " &f| " + (h[tid] ? h[tid].n : "&7(vacant)")); });
                } else if (top === "set") {
                    var who = RPG.player(w[3] || "");
                    if (!isTitle(w[2] || "")) tell(p, "&cNo such title. See /tourney title list.");
                    else if (!who) tell(p, "&cNo such player online.");
                    else grantTitle(w[2], who);
                } else if (top === "clear") {
                    tell(p, clearTitle(String(w[2] || "")) ? "&eCleared holder of '" + w[2] + "'." : "&eTitle '" + w[2] + "' had no holder.");
                } else tell(p, "&c/tourney title list | set <id> <player> | clear <id>");
                return;
            case "config":
                if (!need("rg.tourney.config")) return;
                if (!w[1]) { tell(p, "&6Tournament settings: &f" + Object.keys(CONFIG_KEYS).map(function (k) { return k + "=" + C.get(CONFIG_KEYS[k]); }).join("&7, &f")); return; }
                var ck = CONFIG_KEYS[String(w[1]).toLowerCase()];
                if (!ck) { tell(p, "&cUnknown key. Keys: " + Object.keys(CONFIG_KEYS).join(", ")); return; }
                if (w.length < 3) { tell(p, "&e" + w[1] + " &f= " + C.get(ck)); return; }
                var val = configValue(ck, w.slice(2).join(" "));
                tell(p, C.set(ck, val) ? "&aSet " + w[1] + " = " + C.get(ck) : "&cBad value for " + w[1] + ".");
                return;
        }
        tell(p, "&cUnknown subcommand. /tourney help");
    }
    var SUBS = ["list", "join", "leave", "tpwait", "status", "spectate", "bracket", "top", "team", "char", "loadout", "cancelcharacter", "edit", "open", "start", "cancel", "forceexit", "bounds", "npc", "title", "config", "help"];
    function suggest(p, args) {
        var w = arr(args);
        if (w.length <= 1) return SUBS;
        var sub = String(w[0]).toLowerCase();
        var names = allDefs().map(function (d) { return S.strip(d.name).indexOf(" ") >= 0 ? d.id : S.strip(d.name); });
        if (sub === "team" && w.length === 2) return ["create", "join", "leave"];
        if (sub === "char" && w.length === 2) return ["create", "build", "moves", "delete", "cancel"];
        if (sub === "npc" && w.length === 2) return ["spawn", "bind", "setgroup", "remove", "removeall"];
        if (sub === "title" && w.length === 2) return ["list", "set", "clear"];
        if (sub === "title" && w.length === 3) return titleIds();
        if (sub === "bounds" && w.length === 2) return ["arena", "waiting", "stands"];
        if (sub === "config" && w.length === 2) return Object.keys(CONFIG_KEYS);
        if (sub === "forceexit") return RPG.server.players().map(function (o) { return o.name; });
        return names;
    }
    // one definition serves both /rpgc tourney and the top-level /tourney (skipped if another mod owns the name)
    RPG.commands.register("tourney", { root: true, aliases: ["tournament", "sdt"], description: "Tournaments: /tourney help", permission: 0, run: command, suggest: suggest });

    /** 61_dmz_masters.js: a DMZ tournament host's "Tournament" option opens the browser for its group (budokai, cell...). */
    function openBracket(p, host) { openBrowser(p, host || ""); }

    return { openBrowser: openBrowser, openBracket: openBracket, openSignup: openSignup, openEditor: openEditor,
        isActiveFighter: function (p) { return !!activeFighterRun(uid(p)); },
        isInTournament: function (p) { return !!contestantRun(uid(p)); },
        /** The tournament a player is an active fighter in, when it uses tournament characters (else null). */
        fighterDef: function (p) { var I = activeFighterRun(uid(p)), d = I ? getDef(I.defId) : null; return charsOn(d) ? d : null; },
        charsOn: charsOn,
        grantTitle: grantTitle, heldTitles: function (p) { return heldTitleIds(uid(p)); }, giveRewards: giveAll,
        defs: allDefs, status: statusLine, open: openSignups, cancel: cancel };
})();

/** The hook 61_dmz_masters.js looks for (TournamentPackets OPEN_BRACKET). */
var DMZ_TOURNAMENTS = DBR_TOURNEY;
