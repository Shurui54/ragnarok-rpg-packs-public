// =====================================================================================
//  14_dmz_fluids.js - DragonMine Z's fluids (GPL-3.0, ported from DMZ's MainFluids / SimpleFluid /
//  MainBlocks (LIQUIDOS) / MainItems / StatsEvents.onLivingTick).
// =====================================================================================
//  Two real flowing liquids, both water-like (ForgeFlowingFluid with DMZ's properties):
//    healing_liquid  fluid 1  #A4C977, light 5, heals 8 % HP / ki / stamina every 3 s, no drowning
//    namek_water     fluid 2  #AEF359, light 5, you can drown in it (Namek's oceans and springs)
//  DMZ draws both with the vanilla water textures tinted with its colour at alpha 0xA1, fog -8..48 blocks;
//  spread like water (tick rate 5, 1 level per block, looks 4 blocks for a slope), not renewable
//  (Forge's default), swimmable, put out fire, boats float. The buckets keep DMZ's item names
//  ("healing_liquid_bucket", "namek_water_bucket") so give, recipes and shops work unchanged.
//  Fixed slots (fluid 1 and 2) so worldgen can name them: liquid block "ragnarok_rpg:fluid_0001" /
//  "ragnarok_rpg:fluid_0002", fluids "ragnarok_rpg:fluid_000N" (source) and "ragnarok_rpg:flowing_fluid_000N".
//  The old block names ("healing_liquid_block", "namek_water_liquid_block") still work everywhere a DMZ
//  block name is used (structures, dmzSet, RPG.world.setBlock): they now place the fluid's source.
// =====================================================================================
var DMZ_FLUID = {};                 // DMZ fluid name -> slot id ("fluid_0001")
var DMZ_FLUID_FOR_BLOCK = {};       // old DMZ liquid block name -> fluid name

var DMZ_HEAL_LIQUID_TICK = {};      // player uuid -> server tick of the last heal (StatsEvents.lastHealingTime)
// StatsEvents.funcHealingLiquid: every 3 s in the liquid, +8 % of max HP, ki and stamina (not while knocked out
// in the Otherworld: BabaReviveService.isHealingBlocked), and it puts out fire.
function dmzHealingLiquidTick(entity) {
    if (!entity.isPlayer()) return;
    let now = RPG.server.getTick(), key = entity.getUuid();
    if (now - (DMZ_HEAL_LIQUID_TICK[key] || 0) < 60) return;
    DMZ_HEAL_LIQUID_TICK[key] = now;
    entity.setFire(0);
    if (typeof owKnockedOut === "function" && owKnockedOut(entity)) return;
    entity.heal(entity.maxHealth * 0.08);
    ["ki", "stamina"].forEach((r) => entity.addResource(r, entity.maxResource(r) * 0.08));
}

var DMZ_FLUID_SPECS = [
    {
        num: 1, id: "healing_liquid", block: "healing_liquid_block", name: "Healing Liquid", color: "#A4C977",
        canDrown: false,            // DMZ's properties say canDrown(false) (its SimpleFluid override ignores it)
        bucket: { name: "Healing Liquid Bucket", model: "dmzpack:rpg/item/healing_liquid_bucket" },
        inside: dmzHealingLiquidTick
    },
    {
        num: 2, id: "namek_water", block: "namek_water_liquid_block", name: "Namek Water", color: "#AEF359",
        canDrown: true,
        bucket: { name: "Namek Water Bucket", model: "dmzpack:rpg/item/namek_water_bucket" }
        // StatsEvents.funcNamekWater only puts out fire: canExtinguish does that for every entity
    }
];

DMZ_FLUID_SPECS.forEach((s) => {
    let def = {
        key: s.id, name: s.name,
        aliases: [s.block, s.id.replace("_liquid", "") + "_fluid"],     // + DMZ's fluid ids ("healing_fluid", "namek_water_fluid")
        // SimpleFluid: vanilla water textures, tinted (alpha 0xA1), fog -8..48 in the fluid's colour
        color: s.color, alpha: 0xA1, fogColor: s.color, fogStart: -8, fogDistance: 48,
        // FluidType.Properties: lightLevel 5, swim, extinguish, density / viscosity 1000 (water)
        lightLevel: 5, canSwim: true, canDrown: s.canDrown, canExtinguish: true, density: 1000, viscosity: 1000,
        // ForgeFlowingFluid.Properties: slopeFindDistance 4, levelDecreasePerBlock 1, tick rate 5 (water)
        tickRate: 5, slopeFindDistance: 4, levelDecreasePerBlock: 1, renewable: false,
        boats: true, pathType: "water",
        bucket: { id: s.id + "_bucket", name: s.bucket.name, model: s.bucket.model }
    };
    if (s.inside) def.onEntityInside = (entity, x, y, z) => s.inside(entity, x, y, z);
    let id = RPG.fluids.define(s.num, def);
    DMZ_FLUID[s.id] = id;
    DMZ_FLUID_FOR_BLOCK[s.block] = s.id;
    // DMZ block names used by structures (65_dmz_structures.js), dmzSet and blockRef now mean the fluid's source block
    if (typeof BLOCK_IDS !== "undefined") BLOCK_IDS[s.block] = id;
    if (typeof DMZ_ITEM_BY_REF !== "undefined") DMZ_ITEM_BY_REF[RPG.fluids.bucket(id)] = s.id + "_bucket";
    if (id !== "fluid_000" + s.num)
        console.warn("[DMZ] WARNING: " + s.id + " wanted fluid_000" + s.num + " but got " + id + ": worldgen naming ragnarok_rpg:fluid_000" + s.num + " points at the wrong fluid!");
});

/** The full liquid block id of a DMZ fluid or old liquid block name ("healing_liquid_block" -> "ragnarok_rpg:fluid_0001"), or null. */
function dmzFluidRef(name) {
    let f = DMZ_FLUID[name] || DMZ_FLUID[DMZ_FLUID_FOR_BLOCK[name]];
    return f ? "ragnarok_rpg:" + f : null;
}
