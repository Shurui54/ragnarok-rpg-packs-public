// =====================================================================================
//  92_dbr_raids_rifts.js - DMZ Ragnarok's dimensional tears (rifts): private one-fighter raid encounters
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0) shuruis_raid_bosses: rift/{RiftDef,RiftDefs,RiftArenaSlots,RiftArenaData},
//  entity/DimensionalTear, client/gui/{RiftListScreen,RiftEditScreen,RiftEncounterScreen}. DMZR's tear manager
//  lived in its private key; this is a DBR-side implementation of the behaviour RiftDef documents:
//   - each enabled rift rolls its own wait in [minSpawnMinutes, maxSpawnMinutes], then opens a tear near a
//     player in one of its regions (here: dimension ids, e.g. "overworld" or "ragnarok_rpg:namek"; empty = any)
//   - the tear (dbr:textures/entity/raids/dimensional_tear.png, client/scripts/82_dbr_raids.js) stays open
//     tearLifetimeSeconds; the first player to walk into it takes the fight and it vanishes for everyone else
//   - the fight runs in the rift's own arena cell in ragnarok_rpg:raid_arena (a void datapack dimension),
//     floored by arenaTheme and kept for the life of the world; one run per rift at a time
//   - the encounter is the rift's own (edited like a raid) or a stored raid named by raidId
//  Commands (ops, rg.raid.rift): /raid rift list | status | create <id> | delete <id> | open <id> | close [id] | edit
// =====================================================================================
(function () {
    var R = DBR_RAIDS, D = DBR_RAIDS_DATA;
    var ARENA_DIM = "ragnarok_rpg:raid_arena", CELL_SPACING = 1024, SURFACE_Y = 128, LANE_Z = 0, MAX_CELLS = 64, RADIUS = 24, WALL = 27, HEIGHT = 48;
    var FLOORS = { overworld: "minecraft:grass_block", namek: "minecraft:moss_block", kaio: "minecraft:grass_block", stony: "minecraft:stone",
        otherworld: "minecraft:smooth_quartz", nether: "minecraft:netherrack", end: "minecraft:end_stone", vegeta: "minecraft:red_sandstone", beerus: "minecraft:purpur_block" };
    var SKIP_DIMS = { "ragnarok_rpg:raid_arena": 1, "ragnarok_rpg:space": 1, "ragnarok_rpg:time_chamber": 1 };

    // ---- RiftDefs (own store, never folded into the raid file) ----
    var RIFTS = null;
    function rifts() {
        if (!RIFTS) {
            RIFTS = {};
            var raw = RPG.data.get("dbr_raids_rifts", {}) || {};
            Object.keys(raw).forEach(function (k) { var r = D.normalizeRift(raw[k]); if (r.id) RIFTS[r.id] = r; });
        }
        return RIFTS;
    }
    function save() { RPG.data.set("dbr_raids_rifts", RIFTS || {}); }
    function rift(id) { return id ? rifts()[String(id).toLowerCase()] || null : null; }
    /** RiftDefs.resolveRaid: the rift's own encounter wins outright, else the stored raid it names. */
    function resolve(r) { return r.encounter ? r.encounter : (r.raidId ? R.getDef(r.raidId) : null); }
    function runnable(r) { return r.enabled && !r.eventOnly && !!resolve(r); }

    // ---- arena cells (RiftArenaSlots / RiftArenaData) ----
    var CLAIMED = {};       // cell -> run marker
    function cells() { return RPG.data.get("dbr_raids_rift_cells", {}) || {}; }
    function ownedCell(id) {
        var c = cells();
        if (typeof c[id] === "number") return c[id];
        var used = {};
        Object.keys(c).forEach(function (k) { used[c[k]] = 1; });
        for (var i = 0; i < MAX_CELLS; i++) if (!used[i]) { c[id] = i; RPG.data.set("dbr_raids_rift_cells", c); return i; }
        return -1;
    }
    function cellCentre(i) { return { x: i * CELL_SPACING, y: SURFACE_Y, z: LANE_Z }; }
    function cellRegion(i) {
        var c = cellCentre(i);
        return { dim: ARENA_DIM, x1: c.x - RADIUS, y1: SURFACE_Y, z1: c.z - RADIUS, x2: c.x + RADIUS, y2: SURFACE_Y + HEIGHT, z2: c.z + RADIUS, cx: c.x + 0.5, cz: c.z + 0.5, r: RADIUS };
    }
    /** Cut the arena once (and again when the theme changes): floor disc, barrier wall and lid. */
    function buildCell(i, theme, done) {
        var built = RPG.data.get("dbr_raids_rift_built", {}) || {}, c = cellCentre(i), floor = FLOORS[theme] || "minecraft:stone";
        if (built[i] === theme) { done(); return; }
        var left = 4;
        function step() { if (--left === 0) { built[i] = theme; RPG.data.set("dbr_raids_rift_built", built); done(); } }
        RPG.edit.set(null, ARENA_DIM, { type: "cylinder", x: c.x, y: SURFACE_Y - 2, z: c.z, r: RADIUS, h: 3 }, floor, { progress: false }).then(step);
        RPG.edit.set(null, ARENA_DIM, { type: "cylinder", x: c.x, y: SURFACE_Y + 1, z: c.z, r: WALL - 1, h: HEIGHT }, "air", { progress: false }).then(step);
        RPG.edit.set(null, ARENA_DIM, { type: "cylinder", x: c.x, y: SURFACE_Y - 2, z: c.z, r: WALL, h: HEIGHT + 4, hollow: true }, "barrier", { progress: false }).then(step);
        RPG.edit.set(null, ARENA_DIM, { type: "cylinder", x: c.x, y: SURFACE_Y + HEIGHT + 1, z: c.z, r: WALL, h: 1 }, "barrier", { progress: false }).then(step);
    }

    // ---- tears (DimensionalTear) ----
    var TEARS = [];          // { key, riftId, dim, x, y, z, until, look, label }
    var RUNS = {};           // riftId -> Instance
    var SEQ = 0;
    function nextAt() { return RPG.data.get("dbr_raids_rift_next", {}) || {}; }
    function setNext(id, ms) { var n = nextAt(); if (ms) n[id] = ms; else delete n[id]; RPG.data.set("dbr_raids_rift_next", n); }
    function roll(r) {
        var min = Math.max(1, r.minSpawnMinutes), max = Math.max(min, r.maxSpawnMinutes);
        return Date.now() + Math.round((min + Math.random() * (max - min)) * 60000);
    }
    function dimName(dim) { var s = D.shortId(dim).replace(/_/g, " "); return s.charAt(0).toUpperCase() + s.substring(1); }
    function allowsDim(r, dim) {
        if (SKIP_DIMS[dim]) return false;
        if (!r.regions.length) return true;
        return r.regions.some(function (x) { x = String(x).trim().toLowerCase(); return x === dim || x === D.shortId(dim) || "minecraft:" + x === dim || "ragnarok_rpg:" + x === dim; });
    }
    function sendTears(to) {
        var data = { tears: TEARS.map(function (t) { return { key: t.key, dim: t.dim, x: t.x, y: t.y, z: t.z, look: t.look, label: t.label }; }) };
        (to ? [to] : RPG.server.players()).forEach(function (p) { RPG.net.send(p, "dbr_rift_tears", data); });
    }
    function openTear(r, near) {
        var players = near ? [near] : RPG.server.players().filter(function (p) {
            var g = String(p.getGameMode());
            return g !== "spectator" && allowsDim(r, p.dimension) && !R.runOfPlayer(p.uuid);
        });
        for (var attempt = 0; attempt < 12 && players.length; attempt++) {
            var p = players[Math.floor(Math.random() * players.length)], a = Math.random() * Math.PI * 2, d = near ? 6 : 24 + Math.random() * 40;
            var x = Math.floor(p.x + Math.cos(a) * d), z = Math.floor(p.z + Math.sin(a) * d);
            if (!RPG.world.isLoaded(p.dimension, x, z)) continue;
            var y = RPG.world.surfaceY(p.dimension, x, z);
            if (y === -9999 || Math.abs(y - p.y) > 40) continue;
            var below = String(RPG.world.getBlock(p.dimension, x, y - 1, z));
            if (below.indexOf("water") >= 0 || below.indexOf("lava") >= 0) continue;
            var t = { key: "t" + (++SEQ), riftId: r.id, dim: p.dimension, x: x + 0.5, y: y, z: z + 0.5, until: Date.now() + Math.max(10, r.tearLifetimeSeconds) * 1000,
                look: r.look || "", label: r.tearLabel || r.name, born: RPG.server.getTick() };
            TEARS.push(t);
            sendTears();
            if (r.msgOpened) RPG.broadcast(r.msgOpened.split("{name}").join(r.name).split("{region}").join(dimName(t.dim)));
            RPG.world.sound(t.dim, "minecraft:block.portal.trigger", t.x, t.y, t.z, 2, 1.4);
            return t;
        }
        return null;
    }
    function closeTear(t) { var i = TEARS.indexOf(t); if (i >= 0) { TEARS.splice(i, 1); sendTears(); } }
    function enterTear(p, t) {
        var r = rift(t.riftId), tell = function (s) { p.tell(s); };
        if (!r) { closeTear(t); return; }
        if (R.runOfPlayer(p.uuid)) { if (!t.refused) t.refused = {}; if (!t.refused[p.uuid]) { t.refused[p.uuid] = 1; tell("§cYou are already in a fight."); } return; }
        var enc = resolve(r);
        if (!enc) { closeTear(t); tell("§cThis tear leads nowhere: its encounter no longer exists."); return; }
        var cell = ownedCell(r.id);
        if (cell < 0 || CLAIMED[cell] || RUNS[r.id]) { if (!t.refused) t.refused = {}; if (!t.refused[p.uuid]) { t.refused[p.uuid] = 1; tell("§cThe tear collapsed: there was nowhere on the other side to put you."); } return; }
        closeTear(t);
        CLAIMED[cell] = true;
        var def = D.normalize(JSON.parse(JSON.stringify(enc)));
        def.id = "rift_" + r.id; def.arena = cellRegion(cell); def.playerSpawn = null; def.minParticipants = 1; def.maxParticipants = 1; def.eventOnly = false; def.randomPool = [];
        var inst = new R.Instance(def.id, def), name = p.name;
        RUNS[r.id] = inst;
        inst.onOutcome = function (won) {
            delete CLAIMED[cell];
            delete RUNS[r.id];
            var msg = won ? r.msgVictory : r.msgFailed;
            if (msg) RPG.broadcast(msg.split("{player}").join(name).split("{name}").join(r.name));
        };
        tell("§5You step through the tear into " + R.sec(r.tearLabel || r.name) + "§5...");
        inst.rememberLocation(p);
        var uuid = p.uuid;
        buildCell(cell, r.arenaTheme, function () {
            var pl = RPG.world.entityByUuid(uuid);
            pl = pl && pl.isPlayer() ? pl.asPlayer() : null;
            if (!pl || !inst.startImmediate(pl)) { inst.sendOutcome(false); inst.dispose(); }
        });
    }

    RPG.every(20, function () {
        var ms = Date.now(), changed = false;
        TEARS.slice().forEach(function (t) { if (ms >= t.until || !rift(t.riftId) || !rift(t.riftId).enabled) { TEARS.splice(TEARS.indexOf(t), 1); changed = true; } });
        if (changed) sendTears();
        var nx = nextAt();
        Object.keys(rifts()).forEach(function (id) {
            var r = rifts()[id];
            if (!runnable(r)) return;
            if (!nx[id]) { setNext(id, roll(r)); return; }
            if (ms < nx[id]) return;
            if (RUNS[id] || TEARS.some(function (t) { return t.riftId === id; })) return;
            setNext(id, roll(r));
            openTear(r, null);
        });
    });
    RPG.every(5, function () {
        if (!TEARS.length) return;
        var ms = Date.now();
        RPG.server.players().forEach(function (p) {
            if (String(p.getGameMode()) === "spectator" || !p.isAlive()) return;
            for (var i = 0; i < TEARS.length; i++) {
                var t = TEARS[i];
                if (t.dim !== p.dimension || RPG.server.getTick() - t.born < 20) continue;
                var dx = p.x - t.x, dz = p.z - t.z, dy = p.y - t.y;
                if (dx * dx + dz * dz <= 1.6 * 1.6 && dy > -1 && dy < 4) { enterTear(p, t); return; }
                if (t.refused && t.refused[p.uuid] && dx * dx + dz * dz > 9) delete t.refused[p.uuid];
            }
        });
    });
    RPG.on("playerJoin", function (p) { RPG.schedule(40, function () { sendTears(p); }); });
    RPG.on("playerLeave", function (p) {
        Object.keys(RUNS).forEach(function (id) { var inst = RUNS[id]; if (inst && inst.isParticipant(p.uuid)) inst.abandon(); });
    });

    // ---- editor (RiftListScreen / RiftEditScreen / RiftEncounterScreen) ----
    function rows() {
        var nx = nextAt();
        return Object.keys(rifts()).sort().map(function (id) {
            var r = rifts()[id], enc = resolve(r);
            return { id: id, name: r.name, enabled: r.enabled, raid: r.encounter ? "own encounter" : (r.raidId || ""), ok: !!enc,
                next: nx[id] ? Math.max(0, Math.round((nx[id] - Date.now()) / 1000)) : -1, open: TEARS.some(function (t) { return t.riftId === id; }), running: !!RUNS[id] };
        });
    }
    function pickId(base) {
        var id = String(base || "tear").toLowerCase().replace(/[^a-z0-9_]+/g, "_").replace(/^_+|_+$/g, "") || "tear", n = id, i = 2;
        while (rift(n)) n = id + "_" + (i++);
        return n;
    }
    R.riftRequest = function (p, d) {
        if (!R.can(p, "rg.raid.rift")) { R.msgTo(p, "You can't edit rifts.", "#FF5555"); return; }
        var op = String(d.op || "list"), id = String(d.id || "").toLowerCase();
        if (op === "new") { var nr = D.riftDefaults(pickId(d.name || "tear")); nr.name = "New Tear"; rifts()[nr.id] = nr; save(); return RPG.net.send(p, "dbr_rift_open_editor", { rift: nr, raids: R.poolChoices() }); }
        if (op === "edit") { var r = rift(id); if (r) RPG.net.send(p, "dbr_rift_open_editor", { rift: r, raids: R.poolChoices() }); return; }
        if (op === "save") {
            var s = D.normalizeRift(d.rift);
            if (!s.id) { R.msgTo(p, "That rift has no id and was not saved.", "#FF5555"); return; }
            var old = rift(s.id);
            s.encounter = old ? old.encounter : null;           // the encounter is saved by its own editor
            rifts()[s.id] = s; save();
            if (!s.enabled) setNext(s.id, 0);
            R.msgTo(p, "Saved rift " + R.strip(s.name), "#55FF55");
            return;
        }
        if (op === "delete") { delete rifts()[id]; save(); setNext(id, 0); TEARS.filter(function (t) { return t.riftId === id; }).forEach(closeTear); R.msgTo(p, "Deleted rift " + id, "#55FF55"); }
        if (op === "encounter") {
            var er = rift(id);
            if (!er) return;
            var enc = er.encounter || (er.raidId && R.getDef(er.raidId) ? D.normalize(JSON.parse(JSON.stringify(R.getDef(er.raidId)))) : null);
            if (!enc) { enc = R.createDefault("rift_" + id, er.name); enc.topRewards = []; enc.runnerUpRewards = []; enc.maxParticipants = 1; }
            enc.arena = null; enc.playerSpawn = null;
            return RPG.net.send(p, "dbr_raid_open_editor", { def: enc, target: "rift", riftId: id, pool: [] });
        }
        if (op === "dropencounter") { var dr = rift(id); if (dr) { dr.encounter = null; save(); R.msgTo(p, "Own encounter dropped: the rift is back to naming a raid.", "#55FF55"); } }
        if (op === "open") { var orr = rift(id); if (orr) R.msgTo(p, openTear(orr, p) ? "Opened a tear for " + id : "Could not open a tear here", "#55FF55"); }
        RPG.net.send(p, "dbr_rift_open_list", { rows: rows() });
    };
    R.saveRiftEncounter = function (p, id, def) {
        var r = rift(id);
        if (!r) return;
        def.arena = null; def.playerSpawn = null;
        r.encounter = def;
        save();
        R.msgTo(p, "Saved the encounter of " + R.strip(r.name), "#55FF55");
    };

    // ---- /raid rift ... ----
    function cmd(p, args) {
        var tell = function (s) { if (p) p.tell(s); else RPG.log(R.strip(s)); };
        if (!R.can(p, "rg.raid.rift")) return tell("§cYou don't have permission (rg.raid.rift).");
        var sub = String(args[0] || "list").toLowerCase(), id = String(args[1] || "").toLowerCase();
        if (sub === "edit") { if (p) RPG.net.send(p, "dbr_rift_open_list", { rows: rows() }); return; }
        if (sub === "list") {
            var rs = rows();
            if (!rs.length) return tell("§7No rifts. Use /raid rift create <id> to make one.");
            tell("§5Dimensional tears:");
            rs.forEach(function (r) { tell("§d" + r.id + " §7-> §f" + (r.raid || "-") + " §7(" + (!r.ok ? "§cno such raid" : !r.enabled ? "§7disabled" : r.next < 0 ? "§7not scheduled" : "§anext in " + Math.ceil(r.next / 60) + " min") + "§7)"); });
            return;
        }
        if (sub === "status") {
            tell("§5Tears open: §f" + TEARS.length + "§5, runs active: §f" + Object.keys(RUNS).length + "§5, arena cells in use: §f" + Object.keys(CLAIMED).length);
            TEARS.forEach(function (t) { tell("§7 tear §d" + t.riftId + " §7in §f" + t.dim + " §7at §f" + Math.floor(t.x) + " " + t.y + " " + Math.floor(t.z)); });
            Object.keys(RUNS).forEach(function (k) { tell("§7 run §f" + RUNS[k].participants.map(function (u) { return RUNS[k].names[u] || u; }).join(", ") + " §7in §d" + k + " §7(" + RUNS[k].state + ")"); });
            return;
        }
        if (sub === "create") {
            if (!id) return tell("§c/raid rift create <id> [raid]");
            if (rift(id)) return tell("§cA rift called '" + id + "' already exists.");
            var nr = D.riftDefaults(id.replace(/[^a-z0-9_]/g, ""));
            if (args[2]) { var rd = R.findDef(args.slice(2).join(" ")); if (rd) nr.raidId = rd.id; }
            rifts()[nr.id] = nr; save();
            return tell("§aCreated rift §d" + nr.id + "§a." + (nr.raidId ? "" : " Set its raid in /raid rift edit."));
        }
        var r = rift(id);
        if (sub === "close") {
            var n = 0;
            TEARS.slice().forEach(function (t) { if (!id || t.riftId === id) { closeTear(t); n++; } });
            Object.keys(RUNS).forEach(function (k) { if (!id || k === id) { RUNS[k].abandon(); n++; } });
            return tell("§aClosed §f" + n + "§a tear(s) and run(s).");
        }
        if (!r) return tell("§cNo rift with that id.");
        if (sub === "delete") { delete rifts()[id]; save(); setNext(id, 0); return tell("§aDeleted rift §d" + id + "§a."); }
        if (sub === "open") {
            if (!resolve(r)) return tell("§cThat rift has no encounter or raid.");
            var t = openTear(r, p);
            return tell(t ? "§aOpened a tear for §d" + id + " §ain §f" + t.dim + " §aat §f" + Math.floor(t.x) + " " + t.y + " " + Math.floor(t.z) + "§a." : "§cCould not open a tear for '" + id + "': no spot found.");
        }
        tell("§c/raid rift list | status | edit | create <id> [raid] | delete <id> | open <id> | close [id]");
    }
    cmd.suggest = function (p, words) {
        if (words.length <= 1) return ["list", "status", "edit", "create", "delete", "open", "close"];
        return Object.keys(rifts()).sort();
    };
    R.SUBS.rift = cmd;
})();
