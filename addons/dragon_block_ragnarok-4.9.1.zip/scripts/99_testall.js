// =====================================================================================
//  99_testall.js - test commands for ops
//    /rpgc testall [stat] [quests]   every skill/form/technique learned at max level, TP, stats,
//                                    full bars ("quests" also completes every quest)
//    /rpgc giveall [page]   every Dragon Block item, 36 per page (/rpgc giveall 2 for the next ones)
//    /rpgc resetall         back to a fresh character (opens the creator)
// =====================================================================================
(function () {
    RPG.commands.register("testall", {
        permission: 2,
        description: "/rpgc testall [stat amount] - learn everything, lots of TP and stats (for testing)",
        run(p, args) {
            if (!p.getVar("dmz_created", 0)) { p.tell("&cMake your character first (it opens on join, or /rpgc recreate)."); return; }
            let each = Math.max(0, Math.floor(Number(args[0]) || 5000));
            DMZ_DATA.STATS.forEach((k) => p.addStat(DMZ_DATA.STAT_IDS[k], each));
            p.addTp(1e9, { raw: true, events: false, source: "script" });
            p.setVar("dmz_potential", 10);                                   // highest power release cap
            let skills = RPG.skills.list(), n = 0;
            skills.forEach((id) => {
                try { p.learnSkill(id); p.setSkillLevel(id, 10); n++; } catch (err) { }
            });
            // DMZ skills (46_dmz_skills.js): every skill your race can have, at its top level
            if (typeof DMZ_SKILLS !== "undefined" && typeof DMZ_SKILLS_DATA !== "undefined") {
                let race = DMZ_DATA.DMZ[p.race] || p.race;
                Object.keys(DMZ_SKILLS_DATA.COSTS).concat(DMZ_SKILLS_DATA.FORM_SKILLS).forEach((sk) => {
                    try { let max = DMZ_SKILLS_DATA.maxLevel(sk, race); if (max > 0) DMZ_SKILLS.setLevel(p, sk, max); } catch (err) { }
                });
            }
            // every form and stack form fully mastered (31_dmz_transform.js)
            if (typeof DMZ_FORMS !== "undefined") {
                let fm = {}, sm = {};
                (DMZ_FORMS.groups(DMZ_DATA.DMZ[p.race] || p.race) || []).forEach((g) => g.forms.forEach((f) => { if (f.maxMastery > 0) fm[f.key] = f.maxMastery; }));
                (DMZ_FORMS.STACKS || []).forEach((g) => g.forms.forEach((f) => { if (f.maxMastery > 0) sm[f.key] = f.maxMastery; }));
                p.setVar("dmz_mastery", fm);
                p.setVar("dmz_stack_mastery", sm);
            }
            // "/rpgc testall 5000 quests" also completes every quest (their rewards and boss spawns run too)
            if (String(args[1] || "") === "quests") RPG.quests.list().forEach((q) => { try { if (!p.isQuestDone(q)) p.completeQuest(q); } catch (err) { } });
            p.refreshStats();
            RPG.schedule(1, () => {
                ["ki", "stamina"].forEach((r) => p.setResource(r, p.maxResource(r)));
                p.setHealth(p.maxHealth);
                p.setVar("dmz_release", 100);
            });
            p.tell("&a[Test] Learned " + n + " skills/forms/techniques, +" + each + " in every stat, 1e9 TP, release cap raised." + (String(args[1] || "") === "quests" ? " Quests done." : ""));
            p.tell("&7/rpgc giveall for every item, /rpgc resetall to start over.");
        }
    });

    RPG.commands.register("giveall", {
        permission: 2,
        description: "/rpgc giveall [page] - every Dragon Block item, 36 per page",
        run(p, args) {
            let ids = RPG.items.list().concat(RPG.blocks.list ? RPG.blocks.list() : []);
            let page = Math.max(1, Math.floor(Number(args[0]) || 1)), per = 36, pages = Math.max(1, Math.ceil(ids.length / per));
            ids.slice((page - 1) * per, page * per).forEach((id) => {
                try { p.giveItem(id, 1); } catch (err) { }
            });
            p.tell("&a[Test] Page " + page + " of " + pages + " (" + ids.length + " items in all)." + (page < pages ? " &7/rpgc giveall " + (page + 1) + " for more." : ""));
        }
    });

    RPG.commands.register("resetall", {
        permission: 2,
        description: "/rpgc resetall - wipe this character and make a new one",
        run(p, args) {
            DMZ_DATA.STATS.forEach((k) => { let id = DMZ_DATA.STAT_IDS[k]; p.addStat(id, -p.allocated(id)); });
            RPG.skills.list().forEach((id) => { try { if (p.hasSkill(id)) p.forgetSkill(id); } catch (err) { } });
            if (typeof DMZ_TECH !== "undefined") DMZ_TECH.clearAll(p);
            p.setVar("dmz_release", 0);
            p.setVar("dmz_potential", 0);
            p.setVar("dmz_created", 0);
            p.refreshStats();
            RPG.net.send(p, "dmz_open_creator", {});
            p.tell("&e[Test] Character reset.");
        }
    });

    RPG.commands.register("setrace", {
        permission: 2,
        description: "/rpgc setrace <race> - switch race, keeping this character's looks",
        run(p, args) {
            let race = String(args[0] || "");
            if (RPG.races.list().indexOf(race) < 0) { p.tell("&cRaces: " + RPG.races.list().join(", ")); return; }
            p.race = race;
            let d = DBR_RACE_DEFAULTS[race] || {};
            for (let k in d) p.setColor(k, String(d[k]));
            p.refreshStats();
            p.tell("&a[Test] Race set to " + race + ".");
        }
    });

    RPG.commands.register("dmzvar", {
        permission: 2,
        description: "/rpgc dmzvar <name> - show one of your script variables (for testing)",
        run(p, args) { p.tell("&7" + args[0] + " = &f" + JSON.stringify(p.getVar(String(args[0] || ""), null))); }
    });
})();
