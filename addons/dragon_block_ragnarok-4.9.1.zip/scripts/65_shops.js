// =====================================================================================
//  65_shops.js - places to spend Zeni
// =====================================================================================
//  A shop is a list of items. buy = price to buy, sell = what the shop pays you
//  (leave either out to disable it). count = how many per purchase. levelReq optional.
//  onBuy(player, qty) runs after a purchase.
//  Open one from an NPC (shop: "id" or a dialogue option openShop: "id") or from code:
//  player.openShop("id").
//  Write every entry as an { item, ... } object (mixing plain names in breaks the list).
// =====================================================================================

RPG.shops.define("roshi_shop", {
    name: "Kame House",
    items: [
        { item: "pattern_turtle_gi", buy: 300 },
        { item: "turtle_gi_chest", buy: 300 }, { item: "turtle_gi_legs", buy: 250 }, { item: "turtle_gi_boots", buy: 150 },
        { item: "kid_goku_gi_chest", buy: 250 }, { item: "kid_goku_gi_legs", buy: 200 }, { item: "kid_goku_gi_boots", buy: 120 },
        { item: "weight_turtle_shell", buy: 800 },
        { item: "power_pole", buy: 1500, levelReq: 5 },
        { item: "cooked_dino_meat", count: 4, buy: 60, sell: 10 },
        { item: "giant_turtle_cooked", buy: 40 },
        { item: "raw_dino_meat", sell: 15 }, { item: "turtle_scale", sell: 30 },
        { item: "music_disc_6", buy: 300 }
    ]
});

RPG.shops.define("korin_shop", {
    name: "Korin's Tower",
    items: [
        { item: "senzu_bean", buy: 500, sell: 100 },
        { item: "senzu_bean_red", buy: 150 }, { item: "senzu_bean_blue", buy: 150 }, { item: "senzu_bean_yellow", buy: 150 },
        { item: "senzu_bean_seeds_red", buy: 60 }, { item: "senzu_bean_seeds_blue", buy: 60 }, { item: "senzu_bean_seeds_yellow", buy: 60 },
        { item: "senzu_bean_bag", buy: 2400, levelReq: 20 },
        { item: "yajirobe_katana", buy: 2500, levelReq: 10 },
        { item: "invisible_ladder", count: 8, buy: 40 },
        { item: "mastery_capsule", buy: 4000, levelReq: 15,
          onBuy(player, qty) { player.tell("&7Korin: &fDon't tell Yajirobe where you got that."); } }
    ]
});

RPG.shops.define("yajirobe_shop", {
    name: "Yajirobe's Snacks",
    items: [
        { item: "cooked_dino_meat", count: 2, buy: 40 }, { item: "giant_fish_cooked", buy: 30 }, { item: "frog_legs_cooked", buy: 15 },
        { item: "dino_tail_cooked", buy: 50 }, { item: "cooked_baby_dino_meat", buy: 25 },
        { item: "giant_fish_raw", sell: 12 }, { item: "frog_legs_raw", sell: 4 }, { item: "dino_tail_raw", sell: 15 }
    ]
});

RPG.shops.define("capsule_shop", {
    name: "Capsule Corp.",
    items: [
        { item: "yellow_capsule", buy: 150 }, { item: "blue_capsule", buy: 250 }, { item: "green_capsule", buy: 200 },
        { item: "purple_capsule", buy: 600, levelReq: 10 }, { item: "red_capsule", buy: 900, levelReq: 15 },
        { item: "empty_capsule", sell: 10 },
        { item: "red_scouter", buy: 800 }, { item: "green_scouter", buy: 1200 }, { item: "blue_scouter", buy: 1600, levelReq: 15 },
        { item: "radar_piece", buy: 1500, levelReq: 10 },
        { item: "armor_crafting_kit", buy: 500 },
        { item: "pattern_capsule_corp_jacket", buy: 400 }, { item: "pattern_trunks_jacket", buy: 4000, levelReq: 55 },
        { item: "pattern_videl_outfit", buy: 600 }, { item: "pattern_great_saiyaman", buy: 2500, levelReq: 25 },
        { item: "car_red", buy: 3000 }, { item: "car_yellow", buy: 3000 }, { item: "cc576", buy: 8000, levelReq: 20 },
        { item: "blaster_cannon", buy: 2000, levelReq: 8 },
        { item: "heart_medicine", buy: 600 },
        { item: "brave_sword", buy: 6000, levelReq: 20 },
        { item: "meditation_mat", buy: 800 },
        { item: "gete_pickaxe", buy: 3000, levelReq: 15 },
        { item: "minecraft:golden_apple", buy: 250 },         // vanilla items work too
        // Sell-only entries: Capsule Corp. buys spare Dragon Balls and scrap
        { item: "dragon_ball_1", sell: 2500 }, { item: "gete_scrap", sell: 25 }, { item: "majilite", sell: 120 }
    ]
});

RPG.shops.define("namek_shop", {
    name: "Namekian Village",
    items: [
        { item: "namek_water_bucket", buy: 40 }, { item: "namek_moss", buy: 25 }, { item: "aura_lily", buy: 60 },
        { item: "medi_bug_worm", buy: 30 }, { item: "medi_bug_beetle", buy: 70 }, { item: "medi_bug_rhino", buy: 120 },
        { item: "t2_radar_chip", buy: 3000, levelReq: 25 }, { item: "t2_radar_cpu", buy: 3000, levelReq: 25 },
        { item: "pattern_demon_gi", buy: 400 },
        { item: "namek_stone", count: 16, buy: 30 }, { item: "namek_ajissa_planks", count: 16, buy: 40 },
        { item: "namek_grass", count: 8, buy: 10 }, { item: "namek_fern", count: 4, buy: 10 },
        { item: "frog_legs_raw", sell: 5 }, { item: "kikono_shard", sell: 50 }
    ]
});

RPG.shops.define("frieza_shop", {
    name: "Frieza Force Supply",
    items: [
        { item: "pattern_frieza_force_armor", buy: 500 }, { item: "pattern_saiyan_armor", buy: 1500, levelReq: 15 },
        { item: "pattern_namek_saiyan_armor", buy: 3000, levelReq: 25 }, { item: "pattern_raditz_armor", buy: 900, levelReq: 10 },
        { item: "pattern_bardock_armor", buy: 2500, levelReq: 20 }, { item: "pattern_turles_armor", buy: 5000, levelReq: 35 },
        { item: "purple_scouter", buy: 5000, levelReq: 30 }, { item: "healing_liquid_bucket", buy: 400 },
        { item: "frieza_capsule", buy: 12000, levelReq: 30 }, { item: "saiyan_ship", buy: 15000, levelReq: 30 },
        { item: "laser_merus", buy: 9000, levelReq: 30 }
    ]
});

RPG.shops.define("babidi_shop", {
    name: "Babidi's Spaceship",
    items: [
        { item: "pattern_majin_buu_vest", buy: 2000, levelReq: 30 }, { item: "pattern_super_buu_pants", buy: 7000, levelReq: 55 },
        { item: "black_nimbus", buy: 9000, levelReq: 25 }, { item: "anti_ki_cloak", buy: 6000, levelReq: 30 },
        { item: "demon_eye", sell: 400 },
        { item: "demon_dragon_ball_1", sell: 9000 }, { item: "demon_dragon_ball_2", sell: 9000 }, { item: "demon_dragon_ball_3", sell: 9000 }
    ]
});

// Toribot sells every music disc in the asset pack.
var TORIBOT_ITEMS = [{ item: "music_disc_dmz", buy: 500 }];
DISC_NAMES.forEach((name, i) => TORIBOT_ITEMS.push({ item: "music_disc_" + (i + 1), buy: 300 }));   // DISC_NAMES: 50_items.js
RPG.shops.define("toribot_shop", { name: "Toribot's Jukebox", items: TORIBOT_ITEMS });
