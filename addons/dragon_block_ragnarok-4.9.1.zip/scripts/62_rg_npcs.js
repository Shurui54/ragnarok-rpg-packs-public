// =====================================================================================
//  62_rg_npcs.js - DMZ Ragnarok's display-NPC cast ("rgnpc", formerly ninjin_npc)
// =====================================================================================
//  Every model of DMZ Ragnarok's rgnpc table (RgNpcModels) becomes an NPC type here:
//      rgnpc_<entry>        e.g. rgnpc_saga_cl_king_piccolo, rgnpc_7starspan, rgnpc_halloween_vegeta
//  The table itself (entry -> geo, texture, hitbox, name, group) is shared/14_rg_npc_data.js,
//  generated from DMZ Ragnarok's RgNpcModels + RgNpcModelSizes. Art: dbr:geo/entity/rgnpc/,
//  dbr:textures/entity/rgnpc/ (the saga_/master_ models are NinjinEntities, MIT - see the
//  ninjin_license.txt next to them).
//
//  Like DMZ Ragnarok's RgNpcEntity they are statues with life: they stand still, can't be hurt,
//  play saga_base "idle"/"walk" (the rig the models were retargeted onto), render at scale 1 and
//  use the baked hitbox from RgNpcModelSizes. Tails and capes (7starspan, master_buu) move too: DMZ's
//  always-on "tail"/"cape" clips play on their own controllers (geo.loops, set by dmzSagaStates).
//  Per-spawn size: /rpgc rgnpc <entry> [scale], or RPG.world.spawnNpc(..., { scale }).
//
//  Spawn one (ops):   /rpgc rgnpc <entry>          tab completes; old DMZ Ragnarok ids work too
//                     /rpgc rgnpc list [filter]    names and ids
//                     /rpgc rgnpc picker           a searchable picker screen (client/scripts/71_rg_npc_picker.js)
//  or the usual       /rpg npc rgnpc_<entry>
//  Scripts:           RPG.world.spawnNpc(dim, rgNpcId("saga_jiren"), x, y, z)
// =====================================================================================

var RG_NPC_INDEX = {};
(function () {
    var SAGA_ANIM = DMZ_ANIM + "sagas/saga_base.animation.json";
    RG_NPC_MODELS.forEach(function (r) {
        var entry = r[0], geo = r[1], tex = r[2], w = r[3], h = r[4], name = r[5];
        var look = dmzSagaStates({
            model: "dbr:geo/entity/rgnpc/" + geo + ".geo.json",
            texture: "dbr:textures/entity/rgnpc/" + tex + ".png",
            animation: SAGA_ANIM,
            idle: "idle", walk: "walk",
            attack: "attack1_1",
            scale: 1.0
        });
        RPG.npcs.define(rgNpcId(entry), {
            name: "&f" + name, geo: look, scale: 1.0, width: w, height: h,
            wander: false, invulnerable: true, immovable: true
        });
        RG_NPC_INDEX[entry] = r;
    });
})();

/** The NPC id for an rgnpc entry id ("saga_jiren" -> "rgnpc_saga_jiren"). */
function rgNpcId(entry) { return "rgnpc_" + String(entry).replace(/[^a-z0-9_]/g, "_"); }

/** An entry id from user input: exact, an old DMZ Ragnarok id (RgNpcModels' legacy table), or "rgnpc_<entry>". */
function rgNpcResolve(s) {
    s = String(s || "").toLowerCase().replace(/[^a-z0-9._-]/g, "_").replace(/^rgnpc_/, "");
    if (RG_NPC_INDEX[s]) return s;
    var m = RG_NPC_LEGACY[s];
    return m && RG_NPC_INDEX[m] ? m : null;
}

/** Spawns an rgnpc in front of a player, facing them, optionally at its own size. Returns the entity or null. */
function rgNpcSpawnFor(player, entry, scale) {
    var yaw = player.yaw * Math.PI / 180, x = player.x - Math.sin(yaw) * 2, z = player.z + Math.cos(yaw) * 2;
    var e = RPG.world.spawnNpc(player.dimension, rgNpcId(entry), x, player.y, z, scale > 0 ? { scale: scale } : null);
    if (e) e.teleportTo(player.dimension, x, player.y, z, player.yaw + 180, 0);
    return e;
}

RPG.commands.register("rgnpc", {
    description: "DMZ Ragnarok NPCs: /rpgc rgnpc <model> [scale] | list [filter] | picker",
    permission: 2,
    run(player, args) {
        var tell = function (s) { if (player) player.tell(s); else RPG.log(s.replace(/&./g, "")); };
        var what = (args[0] || "").toLowerCase();
        if (!what || what === "list") {
            var f = (args[1] || "").toLowerCase(), n = 0, line = [];
            RG_NPC_MODELS.forEach(function (r) {
                if (f && r[0].indexOf(f) < 0 && r[5].toLowerCase().indexOf(f) < 0 && r[6].toLowerCase().indexOf(f) < 0) return;
                n++; line.push("&e" + r[0] + " &7" + r[5]);
                if (line.length === 4) { tell(line.join("  ")); line = []; }
            });
            if (line.length) tell(line.join("  "));
            tell("&6" + n + " &7of &6" + RG_NPC_MODELS.length + " &7models. &f/rpgc rgnpc <model>&7 spawns one, &f/rpgc rgnpc picker&7 browses.");
            return;
        }
        if (!player) { tell("Run it in game: the NPC spawns in front of you."); return; }
        if (what === "picker") { RPG.net.send(player, "rg_npc_picker", { open: true }); return; }
        var entry = rgNpcResolve(what);
        if (!entry) { tell("&cNo rgnpc model '" + what + "'. &7Try &f/rpgc rgnpc list " + what.slice(0, 4)); return; }
        var scale = Number(args[1]) || 0;
        var e = rgNpcSpawnFor(player, entry, scale);
        tell(e ? "&aSpawned &f" + RG_NPC_INDEX[entry][5] + " &7(" + rgNpcId(entry) + ")" : "&cCouldn't spawn " + entry + " here.");
    },
    suggest(player, args) {
        if (args.length > 1) return args.length === 2 && rgNpcResolve(args[0]) ? ["0.5", "1", "2", "4"] : [];
        var f = (args[0] || "").toLowerCase(), out = ["list", "picker"];
        RG_NPC_MODELS.forEach(function (r) { if (!f || r[0].indexOf(f) >= 0) out.push(r[0]); });
        return out;
    }
});

// The picker screen asks for a spawn; only ops get one (same rule as the command).
RPG.net.on("rg_npc_picker", function (p, d) {
    if (!p || !d || !d.spawn) return;
    if (!p.isOp()) { p.tell("&cOnly operators can spawn rgnpc models."); return; }
    var entry = rgNpcResolve(d.spawn);
    if (!entry) return;
    var e = rgNpcSpawnFor(p, entry);
    p.tell(e ? "&aSpawned &f" + RG_NPC_INDEX[entry][5] : "&cCouldn't spawn " + entry + " here.");
});
