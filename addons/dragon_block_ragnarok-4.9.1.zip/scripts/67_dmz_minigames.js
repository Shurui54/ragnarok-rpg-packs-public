// =====================================================================================
//  67_dmz_minigames.js - DragonMine Z's training minigames (server side)
// =====================================================================================
//  Ported from DragonMine Z (GPL-3.0): common/training/MinigameSessionManager,
//  server/commands/MinigameCommand, MinigameStartC2S / MinigameInputC2S / MinigameStartS2C /
//  MinigameResultS2C, NPCActionC2S (Old Kai's challenge) and TrainingConfig.
//
//  The games themselves are shared/13_dmz_minigames.js; the screens are
//  client/scripts/53_dmz_minigames.js. Flow (like DMZ):
//    a master's "Train" option / the V menu's Minigames tab / /rpgc dmzminigame play
//        -> "dmz_mg_open" {game, origin, ...}          the client shows the game's ready screen
//    Play -> "dmz_mg" {a: "start", game, origin, ...}   checked here (master nearby, learned, ...)
//        <- "dmz_mg_start" {ok, sid, seed, cfg, chart?}  both sides build the same game
//    every second -> "dmz_mg" {a: "in", sid, from, to, ev: [[tick, type, key, frac, x, y]...]}
//        the server replays the inputs tick by tick and answers with the TP so far
//    the end -> "dmz_mg" {a: "in", ..., fin: true} -> rewards -> "dmz_mg_result" {final: true, ...}
//  Rewards: TP per minute played = 62 x (next stat's TP cost)^0.6, scaled by the level reached and
//  the grade (DMZ's TrainingConfig); a master's bonus when training at their side after learning it;
//  learning a game: 3 runs reaching level 5 with its master, then it's playable from the menu.
//  Old Kai's challenge: control, gravity, memory, precision, rhythm in a row, each to N levels.
//  Attacking, breaking/placing blocks, using items or crafting while a game is open voids it.
//  Saved per player in the var "dmz_mg": {known: [...], runs: {game: n}, songs: [...]}.
//  Config: config/dbr_training.json (DMZ's training.json values).
// =====================================================================================
var DMZ_MINIGAMES = (function () {
    var MG = DMZ_MG;
    var CFG_RAW = dbrConfig("dbr_training", MG.DEFAULTS);
    function cfg() { return MG.mergeCfg(CFG_RAW); }

    var PACE_SLACK_MS = 3000, IDLE_TIMEOUT_MS = 15000, CHALLENGE_TIMEOUT_MS = 30 * 60 * 1000, MAX_CHUNK_TICKS = 200, MAX_EVENTS_PER_TICK = 12;
    var MAX_SESSION_TICKS = 20 * 60 * 60 * 4, START_MIN_INTERVAL_MS = 500, COMMAND_GRANT_MS = 60000;
    var ANIMS = ["base.flex", "base.meditation"];
    var NPC_RANGE = ((DMZ_MASTERS_DATA.CONFIG || {}).npcRange || 8) + 1;

    var SESSIONS = {}, CHALLENGES = {}, GRANTS = {}, LAST_START = {}, OPEN = {};
    var nextSession = 1;

    // ---- saved progress (Character.knownMinigames / minigameLearnRuns / learnedSongs) ----
    function strings(list) {
        var out = [];
        if (list && typeof list === "object" && typeof list.length === "number") for (var i = 0; i < list.length; i++) out.push(String(list[i]));
        return out;
    }
    function data(p) {
        var v = p.getVar("dmz_mg", null), runs = {};
        if (!v || typeof v !== "object") v = {};
        if (v.runs && typeof v.runs === "object") for (var k in v.runs) runs[String(k)] = Number(v.runs[k]) || 0;
        return { known: strings(v.known), runs: runs, songs: strings(v.songs) };
    }
    function save(p, v) { p.setVar("dmz_mg", { known: v.known.slice(), runs: v.runs, songs: v.songs.slice() }); }
    function isKnown(p, id) { return data(p).known.indexOf(id) >= 0; }
    function learnRuns(p, id) { return Number(data(p).runs[id]) || 0; }
    function created(p) { return !!p.getVar("dmz_created", 0); }

    // ---- rhythm tracks: built-in songs + DMZ's music discs that have a chart ----
    var CHARTS = {};
    function chartFile(track) { return MG.isBuiltinSong(track) ? "song_" + track.substring(5) : track; }
    var CHART_JSON = {};          // read but not built yet (the warm-up reads one tick and builds the next)
    function chartJson(track) {
        if (CHART_JSON[track] === undefined) {
            var json = null;
            try { json = RPG.files.read("dmz_rhythm_charts/" + chartFile(track).replace(":", "_") + ".json"); } catch (e) { json = null; }
            CHART_JSON[track] = json;
        }
        return CHART_JSON[track];
    }
    function chartFor(track) {
        if (!/^[a-z0-9_:]{1,64}$/.test(track)) return null;
        if (CHARTS[track] === undefined) {
            var json = chartJson(track);
            delete CHART_JSON[track];
            CHARTS[track] = json && json.notes ? { json: json, chart: new MG.Chart(json) } : null;
        }
        return CHARTS[track];
    }
    var DISCS = null;
    function discs() {
        if (DISCS) return DISCS;
        DISCS = [];
        (typeof DMZ_ITEM_SPECS !== "undefined" ? DMZ_ITEM_SPECS : []).forEach(function (s) {
            if (s.fx !== "disc" || !chartFor(s.id)) return;
            var info = MG.parseDiscInfo(s.desc ? "Music Disc - " + s.desc : s.n);
            var credit = info[1] && info[2] ? info[1] + " - " + info[2] : info[1] || info[2] || "";
            DISCS.push({ key: s.id, name: info[0], sub: credit, dur: (Number(s.length) || 0) * 50 });
        });
        DISCS.sort(function (a, b) { return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : a.name.toLowerCase() > b.name.toLowerCase() ? 1 : 0; });
        return DISCS;
    }
    // read the charts in the background (one per tick) so the first rhythm game doesn't parse all of them at once
    (function warm() {
        var keys = MG.SONGS.map(function (s) { return s.key; }).concat((typeof DMZ_ITEM_SPECS !== "undefined" ? DMZ_ITEM_SPECS : [])
            .filter(function (s) { return s.fx === "disc"; }).map(function (s) { return s.id; }));
        var i = 0, build = null;
        // the file one tick, then the chart a few hundred notes per tick (a long chart in one go took 40+ ms)
        function step() {
            if (i >= keys.length) return;
            var k = keys[i];
            if (!/^[a-z0-9_:]{1,64}$/.test(k) || CHARTS[k] !== undefined) { i++; build = null; }
            else if (!build) {
                var json = chartJson(k);
                delete CHART_JSON[k];
                if (json && json.notes) build = new MG.ChartBuild(json);
                else { CHARTS[k] = null; i++; }
            } else {
                var chart = build.step(400);
                if (chart) { CHARTS[k] = { json: build.json, chart: chart }; build = null; i++; }
            }
            RPG.schedule(1, step);
        }
        RPG.schedule(100, step);
    })();
    function trackInfo(t, c) {
        var e = chartFor(t.key);
        if (!e) return t;
        t.bpm = Math.round(e.chart.bpm);
        t.vocals = e.chart.hasVocals();
        t.rec = [MG.recommendedDifficulty(e.chart, c.rhythm, 0), MG.recommendedDifficulty(e.chart, c.rhythm, 1)];
        return t;
    }
    function tracksFor(p) {
        var c = cfg(), learned = data(p).songs, out = [{ key: "", kind: "free" }];
        MG.SONGS.forEach(function (s) { if (chartFor(s.key)) out.push(trackInfo({ key: s.key, name: s.title, sub: s.artist, dur: s.durationMs, kind: "builtin" }, c)); });
        discs().forEach(function (d) {
            var isLearned = learned.indexOf(d.key) >= 0;
            if (c.rhythm.requireDiscInInventory && !isLearned && !p.hasItem(d.key, 1)) return;
            out.push(trackInfo({ key: d.key, name: d.name, sub: d.sub, dur: d.dur, kind: "disc", learned: isLearned }, c));
        });
        return out;
    }

    // ---- masters nearby (NPCActionC2S.isNpcInRange + NpcDispositionService.getServiceBlocker) ----
    function masterOf(id) { return MG.settingsOf(cfg(), id).masterName; }
    function npcInRange(p, dmzId) {
        var npc = typeof DMZ_MASTERS !== "undefined" ? DMZ_MASTERS.npcOf(dmzId) : dmzId;
        return p.nearby(NPC_RANGE).some(function (e) { return e.isAlive() && String(e.rpgId || "") === npc; });
    }
    function masterBlocked(p, dmzId) {
        if (typeof DMZ_MASTERS === "undefined") return false;
        return !!DMZ_MASTERS_DATA.masterBlocker(DMZ_MASTERS.alignment(p), dmzId);
    }

    // ---- open a game's screen on the client ----
    function openScreen(p, game, origin, extra) {
        var c = cfg(), d = { game: game, origin: origin, cfg: c, known: isKnown(p, game) || MG.settingsOf(c, game).unlockedByDefault };
        for (var k in extra || {}) d[k] = extra[k];
        if (game === "rhythm" && origin !== "CHALLENGE") d.tracks = tracksFor(p);
        OPEN[p.uuid] = { game: game, origin: origin, npc: d.npc || null };
        RPG.net.send(p, "dmz_mg_open", d);
    }

    /** a master's "Train" option (61_dmz_masters.js): BaseMinigameScreen.create(minigame, MASTER) */
    function start(p, game, origin, npc) {
        if (!created(p) || !MG.isValidId(game)) return;
        openScreen(p, game, String(origin || "MASTER"), { npc: npc || masterOf(game) });
    }
    /** Old Kai's "Unleash Power" (MasterServices -> new UltimateChallenge().start()) */
    function startChallenge(p, onCleared) {
        if (!created(p)) return;
        CHALLENGES[p.uuid] = { next: 0, last: Date.now(), onCleared: onCleared || null, armed: true };
        openScreen(p, MG.CHALLENGE_STAGES[0], "CHALLENGE", { stage: 0, stages: MG.CHALLENGE_STAGES.length });
    }
    /** the V menu's Minigames tab (MinigamesScreen) */
    function openHub(p) {
        var c = cfg(), v = data(p), known = {};
        MG.IDS.forEach(function (id) { known[id] = v.known.indexOf(id) >= 0 || MG.settingsOf(c, id).unlockedByDefault; });
        var masters = {};
        MG.IDS.forEach(function (id) { masters[id] = MG.settingsOf(c, id).masterName; });
        RPG.net.send(p, "dmz_mg_hub", { known: known, runs: v.runs, needRuns: Math.max(1, c.learnRequiredRuns), needLevel: Math.max(1, c.learnRequiredLevel), masters: masters });
    }
    /** /rpgc dmzminigame play (MinigameSessionManager.grantCommandSession) */
    function grantCommand(p, game, mentor) {
        GRANTS[p.uuid] = { game: game, mentor: !!mentor, until: Date.now() + COMMAND_GRANT_MS };
        openScreen(p, game, "COMMAND", {});
    }

    // ---- start (MinigameSessionManager.start) ----
    function reject(p, game, origin, stage, key) { RPG.net.send(p, "dmz_mg_start", { ok: false, game: game, origin: origin, stage: stage, reject: key }); }

    function validateChallengeStage(p, id, stage, now) {
        if (!(stage >= 0) || stage >= MG.CHALLENGE_STAGES.length || MG.CHALLENGE_STAGES[stage] !== id) return false;
        var ch = CHALLENGES[p.uuid];
        if (stage === 0) {
            if (!npcInRange(p, "oldkai") || masterBlocked(p, "oldkai")) return false;
            if (typeof DMZ_MASTERS !== "undefined" && !DMZ_MASTERS.meetsOldKai(p)) return false;
            CHALLENGES[p.uuid] = { next: 0, last: now, onCleared: ch ? ch.onCleared : null };
            return true;
        }
        if (!ch || ch.next !== stage) return false;
        ch.last = now;
        return true;
    }

    function onStart(p, d) {
        var id = String(d.game || "").toLowerCase(), origin = String(d.origin || "MENU"), stage = Math.floor(Number(d.stage) || 0), now = Date.now();
        if (LAST_START[p.uuid] && now - LAST_START[p.uuid] < START_MIN_INTERVAL_MS) return reject(p, id, origin, stage, "gui.dragonminez.minigame.reject.unavailable");
        LAST_START[p.uuid] = now;
        if (!created(p) || !MG.isValidId(id)) return reject(p, id, origin, stage, "gui.dragonminez.minigame.reject.unavailable");
        var prev = SESSIONS[p.uuid];
        if (prev) finish(p, prev, true);

        var c = cfg(), settings = MG.settingsOf(c, id), known = settings.unlockedByDefault || isKnown(p, id), mentor = false, target = -1;
        if (origin === "MENU") {
            if (!known) return reject(p, id, origin, stage, "gui.dragonminez.minigame.reject.unknown");
        } else if (origin === "MASTER") {
            var master = settings.masterName;
            if (!npcInRange(p, master) || masterBlocked(p, master)) return reject(p, id, origin, stage, "gui.dragonminez.minigame.reject.master");
            mentor = known;
        } else if (origin === "COMMAND") {
            var g = GRANTS[p.uuid];
            if (!g || g.game !== id || g.until < now) return reject(p, id, origin, stage, "gui.dragonminez.minigame.reject.unavailable");
            delete GRANTS[p.uuid];
            mentor = g.mentor;
        } else if (origin === "CHALLENGE") {
            if (!validateChallengeStage(p, id, stage, now)) return reject(p, id, origin, stage, "gui.dragonminez.minigame.reject.challenge");
            target = Math.max(1, MG.challengeTargetLevels(c, id));
        } else return reject(p, id, origin, stage, "gui.dragonminez.minigame.reject.unavailable");

        // rhythm: a song needs its chart, and a disc that isn't learned yet needs to be carried
        var track = "", difficulty = MG.clampDifficulty(d.difficulty === undefined ? 1 : d.difficulty), variant = MG.clampVariant(Math.floor(Number(d.variant) || 0));
        var entry = null;
        if (id === "rhythm" && origin !== "CHALLENGE" && d.track) {
            track = String(d.track);
            entry = chartFor(track);
            var builtin = MG.findSong(track), isDisc = !builtin && discs().some(function (x) { return x.key === track; });
            if (!entry || (!builtin && !isDisc)) return reject(p, id, origin, stage, "gui.dragonminez.minigame.reject.no_chart");
            if (!builtin && c.rhythm.requireDiscInInventory && data(p).songs.indexOf(track) < 0 && !p.hasItem(track, 1))
                return reject(p, id, origin, stage, "gui.dragonminez.minigame.reject.no_disc");
            variant = entry.chart.effectiveVariant(variant);
        }

        var seed = Math.floor(Math.random() * 4294967296) | 0;
        var logic = MG.create(id, c, seed, entry ? entry.chart : null, difficulty, variant);
        if (target > 0) logic.setTargetLevelsCleared(target);
        var sid = nextSession++;
        var s = { id: sid, game: id, origin: origin, stage: stage, logic: logic, start: now, last: now, known: known, mentor: mentor, track: track, invalid: false, cfg: c };
        SESSIONS[p.uuid] = s;
        RPG.net.send(p, "dmz_mg_start", {
            ok: true, sid: sid, seed: seed, game: id, origin: origin, stage: stage, target: target, mentor: mentor, known: known,
            runs: learnRuns(p, id), needRuns: Math.max(1, c.learnRequiredRuns), needLevel: Math.max(1, c.learnRequiredLevel), cfg: c,
            track: track, difficulty: difficulty, variant: variant, chart: entry ? entry.json : null
        });
        if (typeof act === "function") act(p, ANIMS[Math.floor(Math.random() * ANIMS.length)], 20 * 60 * 30);
    }

    // ---- inputs (MinigameSessionManager.input): replay the client's game tick by tick ----
    function onInput(p, d) {
        var s = SESSIONS[p.uuid];
        if (!s || s.id !== Number(d.sid)) return;
        var now = Date.now(), L = s.logic, from = Math.floor(Number(d.from)), to = Math.floor(Number(d.to)), ticks = to - from;
        var ev = d.ev && d.ev.length !== undefined ? d.ev : [], fin = !!d.fin, malformed = false, i;
        if (from !== L.tickN || !(ticks >= 0) || ticks > MAX_CHUNK_TICKS || ev.length > MAX_EVENTS_PER_TICK * (ticks + 1)) malformed = true;
        for (i = 0; i < ev.length && !malformed; i++) if (!MG.validEvent(ev[i])) malformed = true;
        if (!malformed && to > (now - s.start + PACE_SLACK_MS) / 50) malformed = true;
        if (malformed) {
            s.invalid = true;
            RPG.log("DMZ minigame: rejected input from " + p.name + " (" + s.game + "): chunk " + from + "-" + to + " failed validation");
            finish(p, s, true);
            return;
        }
        var index = 0, lastTick = from;
        while (L.tickN < to && !L.finished) {
            var k = L.tickN;
            while (index < ev.length && ev[index][0] <= k) {
                var e = ev[index++];
                if (e[0] < lastTick) continue;
                lastTick = e[0];
                L.applyEvent(e);
            }
            L.tick();
        }
        if (fin) {
            while (index < ev.length && !L.finished) {
                var e2 = ev[index++];
                if (e2[0] < lastTick || e2[0] > L.tickN) continue;
                lastTick = e2[0];
                L.applyEvent(e2);
            }
        }
        s.last = now;
        if (fin || L.finished || L.tickN >= MAX_SESSION_TICKS) finish(p, s, true);
        else if (s.origin !== "CHALLENGE") sendResult(p, s, false, {});
    }

    // ---- rewards (computeReward) ----
    function singleStatCost(p) {
        try {
            var cls = DMZ_DATA.CLASSES[p.playerClass] || DMZ_DATA.CLASSES.warrior;
            return DMZ_F.singleCost(DMZ_F.total(dmzView(p)), cls.tpCost);
        } catch (e) { return 16; }
    }
    function computeReward(p, s) {
        if (s.invalid || s.origin === "CHALLENGE") return 0;
        var c = s.cfg, settings = MG.settingsOf(c, s.game);
        var reward = s.logic.rewardUnits * MG.computeTpsPerMinute(c, singleStatCost(p), settings);
        if (s.mentor) reward *= 1 + Math.max(0, c.mentorBonus);
        var limit = settings.tpsLimitPerGame;
        if (limit > 0 && reward > limit) reward = limit;
        return Math.max(0, reward);
    }
    function sendResult(p, s, final, x) {
        var L = s.logic, c = s.cfg;
        RPG.net.send(p, "dmz_mg_result", {
            sid: s.id, final: final, invalid: s.invalid, tp: x.tp !== undefined ? x.tp : Math.floor(computeReward(p, s)), levels: L.levelsCleared, ticks: L.tickN,
            perf: L.performance, rate: L.rewardRate(), mentor: s.mentor, runs: x.runs !== undefined ? x.runs : learnRuns(p, s.game),
            needRuns: Math.max(1, c.learnRequiredRuns), learned: !!x.learned, counted: !!x.counted, challenge: x.challenge || "none", song: !!x.song
        });
    }

    function finish(p, s, notify) {
        if (SESSIONS[p.uuid] === s) delete SESSIONS[p.uuid];
        if (typeof stopAct === "function") stopAct(p);
        var L = s.logic, c = s.cfg, x = { tp: 0 };
        L.forceFinish();
        if (s.origin === "CHALLENGE") {
            x.challenge = resolveChallenge(p, s);
        } else if (!s.invalid) {
            var reward = computeReward(p, s);
            x.tp = Math.floor(reward);
            if (x.tp > 0) {
                if (typeof DMZ_TP === "function") DMZ_TP(p, x.tp, "training");
                else p.addTp(x.tp, { raw: true, events: false, source: "training" });
                p.playSound("minecraft:entity.player.levelup", 0.6, 1);
            }
            var v = data(p), changed = false;
            if (s.origin === "MASTER" && !s.known && v.known.indexOf(s.game) < 0 && L.level() >= Math.max(1, c.learnRequiredLevel)) {
                x.counted = true;
                var runs = (Number(v.runs[s.game]) || 0) + 1;
                v.runs[s.game] = runs;
                if (runs >= Math.max(1, c.learnRequiredRuns)) { v.known.push(s.game); delete v.runs[s.game]; x.learned = true; }
                changed = true;
            }
            if (s.game === "rhythm" && L.chart && L.songCompleted && L.health > 0 && s.track && !MG.isBuiltinSong(s.track)
                && L.accuracy() >= c.rhythm.learnSongAccuracy && v.songs.indexOf(s.track) < 0) {
                v.songs.push(s.track); x.song = true; changed = true;
            }
            if (changed) save(p, v);
            x.runs = x.learned ? Math.max(1, c.learnRequiredRuns) : (Number(v.runs[s.game]) || 0);
        }
        if (notify) sendResult(p, s, true, x);
    }

    function resolveChallenge(p, s) {
        var ch = CHALLENGES[p.uuid];
        if (s.invalid || !ch || ch.next !== s.stage || !s.logic.targetReached) {
            RPG.log("DMZ Old Kai challenge failed for " + p.name + " at stage " + (s.stage + 1) + " (" + s.game + "): " +
                (s.invalid ? "invalid input" : !ch ? "no challenge in progress" : ch.next !== s.stage ? "expected stage " + ch.next : "target not reached in the server replay"));
            if (ch) { ch.next = 0; ch.last = Date.now(); }        // keep the reward callback: "try again from the first trial"
            return "failed";
        }
        ch.next++;
        ch.last = Date.now();
        if (ch.next >= MG.CHALLENGE_STAGES.length) {
            delete CHALLENGES[p.uuid];
            if (typeof ch.onCleared === "function") { try { ch.onCleared(); } catch (e) { RPG.log("DMZ Old Kai reward failed: " + e); } }
            else if (typeof DMZ_MASTERS !== "undefined") DMZ_MASTERS.grantOldKaiChallengeReward(p);
            return "completed";
        }
        return "cleared";
    }

    // ---- network ----
    RPG.net.on("dmz_mg", function (p, d) {
        if (!d) return;
        var a = String(d.a || "");
        if (a === "start") onStart(p, d);
        else if (a === "in") onInput(p, d);
        else if (a === "hub") openHub(p);
        else if (a === "open") {                                     // MinigamesScreen -> Play (from the menu)
            var game = String(d.game || "");
            if (!MG.isValidId(game) || !created(p)) return;
            openScreen(p, game, "MENU", {});
        } else if (a === "challenge_next") {                         // UltimateChallenge.onStageCleared -> the next trial's screen
            var ch = CHALLENGES[p.uuid];
            if (!ch || ch.next <= 0 || ch.next >= MG.CHALLENGE_STAGES.length) return;
            openScreen(p, MG.CHALLENGE_STAGES[ch.next], "CHALLENGE", { stage: ch.next, stages: MG.CHALLENGE_STAGES.length });
        } else if (a === "challenge_restart") {                      // UltimateChallenge.restart after a failed trial
            if (!CHALLENGES[p.uuid]) return;
            CHALLENGES[p.uuid].next = 0;
            openScreen(p, MG.CHALLENGE_STAGES[0], "CHALLENGE", { stage: 0, stages: MG.CHALLENGE_STAGES.length });
        } else if (a === "close") {
            delete OPEN[p.uuid];
        }
    });

    // ---- doing something else while training voids the run (onPlayerAction) ----
    function onAction(p, what) {
        var s = p && SESSIONS[p.uuid];
        if (!s) return;
        s.invalid = true;
        RPG.log("DMZ minigame: invalidated " + s.game + " for " + p.name + ": " + what + " while the session was open");
        finish(p, s, true);
    }
    RPG.on("attack", function (e) { if (e.attacker && e.attacker.isPlayer()) onAction(e.attacker.asPlayer(), "attack"); });
    RPG.on("blockBreak", function (p) { onAction(p, "block break"); });
    RPG.on("blockPlace", function (p) { onAction(p, "block place"); });
    RPG.on("itemUse", function (p) { onAction(p, "item use"); });
    RPG.on("craft", function (p) { onAction(p, "crafting"); });
    RPG.on("playerLeave", function (p) {
        var s = SESSIONS[p.uuid];
        if (s) finish(p, s, false);
        delete CHALLENGES[p.uuid]; delete GRANTS[p.uuid]; delete OPEN[p.uuid]; delete LAST_START[p.uuid];
    });

    // idle sessions end after 15 s without input; abandoned challenges after 30 min
    RPG.every(20, function () {
        var now = Date.now();
        Object.keys(SESSIONS).forEach(function (uuid) {
            var s = SESSIONS[uuid];
            if (now - s.last < IDLE_TIMEOUT_MS) return;
            var p = RPG.server.players().filter(function (x) { return x.uuid === uuid; })[0];
            if (p) finish(p, s, true); else delete SESSIONS[uuid];
        });
        Object.keys(CHALLENGES).forEach(function (uuid) {
            if (now - CHALLENGES[uuid].last > CHALLENGE_TIMEOUT_MS && !SESSIONS[uuid]) delete CHALLENGES[uuid];
        });
    });

    // ---- /rpgc dmzminigame (MinigameCommand) ----
    RPG.commands.register("dmzminigame", {
        permission: 2, description: "/rpgc dmzminigame play <rhythm|control|memory|precision|gravity> [player] [masterBonus] | learn <game|all> [player] | forget <game|all> [player]",
        run: function (p, args) {
            var sub = String(args[0] || "").toLowerCase(), game = String(args[1] || "").toLowerCase();
            var target = args[2] ? RPG.server.player(args[2]) : p;
            function say(m) { if (p) p.tell(m); else RPG.log(m); }
            if (!target) { say("&cNo such player."); return; }
            if (sub === "play") {
                if (!MG.isValidId(game)) { say("&cUnknown minigame: " + game + " (" + MG.IDS.join(", ") + ")"); return; }
                if (!created(target)) { say("&c" + target.name + " has no character yet."); return; }
                grantCommand(target, game, String(args[3] || "").toLowerCase() === "true");
                say("&aOpened " + game + " for " + target.name + ".");
            } else if (sub === "learn" || sub === "forget") {
                var ids = game === "all" ? MG.IDS : MG.isValidId(game) ? [game] : null;
                if (!ids) { say("&cUnknown minigame: " + game); return; }
                var v = data(target);
                ids.forEach(function (id) {
                    var at = v.known.indexOf(id);
                    if (sub === "learn" && at < 0) v.known.push(id);
                    if (sub === "forget" && at >= 0) v.known.splice(at, 1);
                    delete v.runs[id];
                });
                save(target, v);
                say("&a" + (sub === "learn" ? "Taught " : "Forgot ") + ids.join(", ") + " " + (sub === "learn" ? "to " : "for ") + target.name + ".");
            } else say("&e/rpgc dmzminigame play <game> [player] [masterBonus] | learn <game|all> [player] | forget <game|all> [player]");
        }
    });

    return { start: start, startChallenge: startChallenge, openHub: openHub, grantCommand: grantCommand, isKnown: isKnown, config: cfg,
        sessions: function () { return SESSIONS; } };
})();
