// =====================================================================================
//  10_stats.js - DMZ's six stats
// =====================================================================================
//  STR Strength, SKP Strike Power, RES Resistance, VIT Vitality, PWR Ki Power, ENE Energy.
//  They start at 0 plus your class's base points (25_classes.js) and are bought with TP
//  (09_dmz_stats.js prices them like DMZ). What they do comes from DMZ's formulas in
//  shared/02_dmz_formulas.js: no vanilla attributes are attached here.
// =====================================================================================
[["strength", "Strength", "#D71432"], ["strike", "Strike Power", "#D71432"], ["resistance", "Resistance", "#D71432"],
 ["vitality", "Vitality", "#D71432"], ["kipower", "Ki Power", "#D71432"], ["energy", "Energy", "#D71432"]].forEach(function (s) {
    RPG.stats.define(s[0], { name: s[1], color: s[2], base: 0, max: 1000000 });
});

RPG.stats.define("weight", { name: "Training Weight", hidden: true, allocatable: false, base: 0 });
RPG.stats.define("ki_cloak", { name: "Ki Cloak", hidden: true, allocatable: false, base: 0 });
RPG.stats.define("fame", { name: "Fame", hidden: true, allocatable: false, base: 0 });

var COMBAT_STATS = ["strength", "strike", "resistance", "vitality", "kipower", "energy"];

/** A character view for DMZ_F (shared/02_dmz_formulas.js). */
function dmzView(player) {
    let mult = player.getVar("dmz_mult", null) || {};
    return {
        stat: (k) => player.stat(DMZ_DATA.STAT_IDS[k]),
        cls: player.playerClass || "warrior",
        release: Number(player.getVar("dmz_release", 0)) || 0,
        mult: (k) => typeof mult[k] === "number" ? mult[k] : 1,
        armor: player.armor, toughness: player.armorToughness,
        race: DMZ_DATA.DMZ[player.race] || player.race,
        capMult: typeof DBR_PRESTIGE !== "undefined" ? DBR_PRESTIGE.capMult(player) : 1      // 93_dbr_prestige.js
    };
}

function powerLevel(entity) {
    if (!entity) return 0;
    let player = entity.asPlayer();                // null for mobs
    if (player) {
        if (player.stat("ki_cloak") > 0 || player.race === "glind") return 5;   // cloaked / divine ki hides from scouters
        return Math.floor(DMZ_F.battlePower(dmzView(player)));
    }
    return Math.floor(entity.maxHealth * 25);      // mobs: based on their health
}
