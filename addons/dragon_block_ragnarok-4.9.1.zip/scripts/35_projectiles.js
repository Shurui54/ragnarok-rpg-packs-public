// =====================================================================================
//  35_projectiles.js - every ki ball, beam, disk and laser
// =====================================================================================
//  A projectile is pure data: what it looks like and what it does when it hits.
//  Techniques (40_skills.js) fire them with  player.shoot("kamehameha", overrides).
//
//    shape        "ball" | "beam" | "laser" | "disk" | "sprite" | "item"
//    colors       { core, border, outline }   three glowing shells, inside to outside
//    size         radius-ish, in blocks              speed      blocks per tick
//    gravity      0 = flies straight                 lifetime   ticks before it fizzles
//    damage       a number, or fn(owner, target)     pierce     enemies it passes through
//    knockback    push on hit                        explode    { power, breakBlocks }
//    particles    a vanilla particle id left as a trail
//  Beams and lasers stay attached to the caster's hands and follow their aim:
//    length       max length                         charge     ticks of the growing orb first
//    duration     ticks the beam lasts               hitInterval  ticks between damage ticks
//  sprite: texture (a picture that always faces you, spin: degrees per tick); item: item.
//  Callbacks: onHit(owner, target, x, y, z)  (target is null when it hit a block),
//             onTick(owner, age)  every 5 ticks.
//
//  Per shot, overrides change any field:  player.shoot("ki_blast", { damage: 12, size: 0.8,
//  colors: { border: "#FF0000" } }).  The techniques pass the damage this way, from stats.
//
//  Engine-neutral: a "ball" with gravity is a grenade, a "laser" is a railgun, an "item"
//  shape with item: "minecraft:arrow" is an arrow. See README > Projectiles.
// =====================================================================================

// projectile() defines one AND keeps a copy in PROJECTILES, so techniques can read a beam's
// charge time and duration to time their animations (40_skills.js).
var PROJECTILES = {};
function projectile(id, def) {
    PROJECTILES[id] = def;
    return RPG.projectiles.define(id, def);
}

// A visual + sound for anything that explodes.
function kiImpact(owner, x, y, z, big) {
    if (!owner) return;
    let at = { x: x, y: y, z: z, dimension: owner.dimension };
    RPG.world.particle(owner.dimension, big ? "minecraft:explosion_emitter" : "minecraft:explosion", x, y, z, 1, 0, 0);
    sfx(at, "ki_explosion_impact", big ? 2 : 1, big ? 0.8 : 1.1);
}

// ---- Basic ki ---------------------------------------------------------------------------
projectile("ki_blast", {
    shape: "ball",
    colors: { core: "#FFFFFF", border: "#7FFFFF", outline: "#29D8FF" },   // the shot passes the player's aura colour
    size: 0.55, speed: 1.8, lifetime: 40,
    damage: 4, knockback: 0.25
});

projectile("ki_volley", {
    shape: "sprite",                                     // a flat glowing picture from the asset pack
    texture: DMZ_TEX + "ki/kiblast.png",
    spin: 25,
    colors: { core: "#9FEFFF" },                         // sprites are tinted with `core`
    size: 0.9, speed: 2.2, lifetime: 30,
    damage: 2.5, knockback: 0.1
});

// ---- Beams ------------------------------------------------------------------------------
projectile("kamehameha", {
    shape: "beam",
    colors: { core: "#EDF4FF", border: "#29D8FF", outline: "#0077FF" },
    size: 1.3, length: 40, speed: 3,                     // grows 3 blocks per tick up to 40
    charge: 30, duration: 40, hitInterval: 4,
    damage: 10, knockback: 0.6
});

projectile("galick_gun", {
    shape: "beam",
    colors: { core: "#FAE5FF", border: "#A63EF0", outline: "#7106BD" },
    size: 1.3, length: 40, speed: 3,
    charge: 30, duration: 40, hitInterval: 4,
    damage: 10, knockback: 0.6
});

projectile("final_flash", {
    shape: "beam",
    colors: { core: "#FFFCD6", border: "#FFEB52", outline: "#F5C020" },
    size: 1.9, length: 55, speed: 3.5,
    charge: 45, duration: 50, hitInterval: 4,
    damage: 18, knockback: 1.0
});

projectile("masenko", {
    shape: "beam",
    colors: { core: "#FFFDE8", border: "#FFE14D", outline: "#E0A800" },
    size: 1.0, length: 35, speed: 3,
    charge: 20, duration: 30, hitInterval: 4,
    damage: 8, knockback: 0.5
});

projectile("tri_beam", {
    shape: "beam",
    colors: { core: "#FFF8E8", border: "#FFE89A", outline: "#D9B54D" },
    size: 2.4, length: 25, speed: 2.5,
    charge: 15, duration: 25, hitInterval: 3,
    damage: 12, knockback: 1.2
});

projectile("neo_tri_beam", {
    shape: "beam",
    colors: { core: "#FFFFFF", border: "#FFF0B0", outline: "#E8C14D" },
    size: 3.0, length: 30, speed: 3,
    charge: 20, duration: 60, hitInterval: 3,
    damage: 14, knockback: 1.5
});

projectile("mouth_blast", {
    shape: "beam",
    colors: { core: "#FFEFE0", border: "#FF9A4D", outline: "#D04A00" },
    size: 2.6, length: 30, speed: 3,
    charge: 10, duration: 30, hitInterval: 4,
    damage: 14, knockback: 1.0
});

// ---- Lasers (thin beams) ------------------------------------------------------------------
projectile("special_beam_cannon", {
    shape: "laser",
    colors: { core: "#FFFFF0", border: "#FFE14D", outline: "#B026FF" },  // yellow core, purple spiral
    size: 1.0, length: 60, speed: 6,
    charge: 50, duration: 20, hitInterval: 2,
    damage: 16, knockback: 1.0
});

projectile("dodonpa", {
    shape: "laser",
    colors: { core: "#FFF6E0", border: "#FFD24D", outline: "#E8A000" },
    size: 0.6, length: 35, speed: 8,
    duration: 10, hitInterval: 2,
    damage: 7, knockback: 0.3
});

projectile("death_beam", {
    shape: "laser",
    colors: { core: "#FFE6FF", border: "#E07BFF", outline: "#9A1FD6" },
    size: 0.35, length: 45, speed: 10,
    duration: 8, hitInterval: 2,
    damage: 6, knockback: 0.2
});

projectile("eye_laser", {
    shape: "laser",
    colors: { core: "#FFE0E0", border: "#FF4D4D", outline: "#C00000" },
    size: 0.3, length: 30, speed: 10,
    duration: 6, hitInterval: 2,
    damage: 5, knockback: 0.1
});

// Majin candy beam: weak enemies hit by it turn into a cookie.
projectile("candy_beam", {
    shape: "laser",
    colors: { core: "#FFE6F6", border: "#FF8AD8", outline: "#D0409A" },
    size: 0.45, length: 25, speed: 8,
    duration: 8, hitInterval: 8,
    damage: 2,
    onHit(owner, target, x, y, z) {
        if (!owner || !target || target.isPlayer() || target.health > 20 + owner.stat("kipower")) return;
        target.kill();
        RPG.world.particle(owner.dimension, "minecraft:heart", x, y + 1, z, 8, 0.4, 0);
        sfx(owner, "majin_absorb", 1, 1.4);
        let p = owner.asPlayer();
        if (p) { p.giveItem("minecraft:cookie", 1); p.actionbar("&dI'll turn you into candy!"); }
    }
});

// ---- Balls that explode --------------------------------------------------------------------
projectile("big_bang", {
    shape: "ball",
    colors: { core: "#E8FCFF", border: "#4DC3FF", outline: "#1F6BFF" },
    size: 2.0, speed: 1.4, lifetime: 60,
    damage: 16, knockback: 1.2,
    explode: { power: 3, breakBlocks: false },
    particles: "minecraft:electric_spark",
    onHit(owner, target, x, y, z) { kiImpact(owner, x, y, z, true); }
});

projectile("burning_attack", {
    shape: "ball",
    colors: { core: "#FFF4E0", border: "#FFB04D", outline: "#FF5A00" },
    size: 1.4, speed: 1.6, lifetime: 50,
    damage: 12, knockback: 0.8,
    explode: { power: 2, breakBlocks: false },
    particles: "minecraft:flame",
    onHit(owner, target, x, y, z) { kiImpact(owner, x, y, z, false); }
});

projectile("spirit_bomb", {
    shape: "ball",
    colors: { core: "#E8FCFF", border: "#7FD4FF", outline: "#2A7BFF" },
    size: 6, speed: 0.6, lifetime: 140,
    damage: 40, knockback: 2,
    explode: { power: 6, breakBlocks: false },
    particles: "minecraft:end_rod",
    onHit(owner, target, x, y, z) { kiImpact(owner, x, y, z, true); }
});

projectile("supernova", {
    shape: "ball",
    colors: { core: "#FFF0E0", border: "#FF7A2E", outline: "#C21E00" },
    size: 5, speed: 0.5, lifetime: 140,
    damage: 35, knockback: 2,
    explode: { power: 5, breakBlocks: false },
    particles: "minecraft:flame",
    onHit(owner, target, x, y, z) { kiImpact(owner, x, y, z, true); }
});

projectile("soul_punisher", {
    shape: "ball",
    colors: { core: "#F0F8FF", border: "#BFE6FF", outline: "#6FB8FF" },
    size: 3, speed: 0.9, lifetime: 80,
    damage: 24, knockback: 1.5,
    explode: { power: 3, breakBlocks: false },
    onHit(owner, target, x, y, z) { kiImpact(owner, x, y, z, true); }
});

projectile("planet_burst", {
    shape: "ball",
    colors: { core: "#FFE0F6", border: "#FF6EE7", outline: "#A0208A" },
    size: 1.2, speed: 1.1, lifetime: 60,
    damage: 9, knockback: 0.6,
    explode: { power: 2, breakBlocks: false },
    onHit(owner, target, x, y, z) { kiImpact(owner, x, y, z, false); }
});

projectile("blaster_meteor", {
    shape: "ball",
    colors: { core: "#E8FFE8", border: "#7FFF5F", outline: "#2EB82E" },
    size: 0.9, speed: 1.3, lifetime: 50,
    damage: 7, knockback: 0.5,
    explode: { power: 1.5, breakBlocks: false }
});

projectile("assault_rain", {
    shape: "ball",
    colors: { core: "#FFFFE0", border: "#FFE14D", outline: "#FFA000" },
    size: 0.5, speed: 1.6, gravity: 0.04, lifetime: 60,     // arcs down like rain
    damage: 5, knockback: 0.3,
    onHit(owner, target, x, y, z) { if (owner) RPG.world.particle(owner.dimension, "minecraft:explosion", x, y, z, 1, 0, 0); }
});

projectile("hellzone_grenade", {
    shape: "sprite",
    texture: DMZ_TEX + "ki/kiblast.png",
    spin: 15,
    colors: { core: "#FFF27A" },
    size: 1.2, speed: 0.9, lifetime: 80,
    damage: 6, knockback: 0.4,
    explode: { power: 1, breakBlocks: false }
});

// ---- Disks (pass through enemies) -------------------------------------------------------
projectile("destructo_disk", {
    shape: "disk",
    colors: { core: "#FFFFE0", border: "#FFE14D", outline: "#FFB000" },
    size: 1.2, speed: 1.5, lifetime: 60,
    damage: 14, knockback: 0, pierce: 8,                 // slices straight through a crowd
    particles: "minecraft:wax_on"
});

projectile("kill_driver", {
    shape: "disk",
    colors: { core: "#FFE6E6", border: "#FF5A5A", outline: "#C00000" },
    size: 1.8, speed: 1.2, lifetime: 60,
    damage: 12, knockback: 1, pierce: 3,
    explode: { power: 1.5, breakBlocks: false }
});

// ---- Item-shaped shots -----------------------------------------------------------------
// The Senzu Toss throws a real Senzu Bean model that heals whoever it hits.
projectile("senzu_toss", {
    shape: "item",
    item: "senzu_bean",
    size: 0.6, speed: 0.9, gravity: 0.03, lifetime: 60,
    damage: 0, knockback: 0,
    onHit(owner, target, x, y, z) {
        if (!target) return;
        target.heal(1000);
        RPG.world.particle(target.dimension, "minecraft:happy_villager", x, y + 1, z, 15, 0.5, 0);
        sfx(target, "senzu", 1, 1);
    }
});

// Guns from the weapons list (50_items.js).
projectile("blaster_shot", {
    shape: "ball",
    colors: { core: "#FFF0D0", border: "#FFAA33", outline: "#CC5500" },
    size: 0.35, speed: 2.5, lifetime: 30,
    damage: 6, knockback: 0.2
});

projectile("merus_laser", {
    shape: "laser",
    colors: { core: "#E0FFFF", border: "#5AF0FF", outline: "#1F8FFF" },
    size: 0.25, length: 40, speed: 12,
    duration: 5, hitInterval: 5,
    damage: 9, knockback: 0.1
});

// Boss ki (75_mobs_bosses.js). Mobs can shoot too: boss.shoot("boss_ki_blast", null).
projectile("boss_ki_blast", {
    shape: "ball",
    colors: { core: "#FFF0FF", border: "#D04DFF", outline: "#7A00CC" },
    size: 0.9, speed: 1.2, lifetime: 60,
    damage: 8, knockback: 0.5
});

projectile("boss_beam", {
    shape: "beam",
    colors: { core: "#FFFFFF", border: "#FF4D4D", outline: "#A00000" },
    size: 1.4, length: 30, speed: 2,
    charge: 30, duration: 35, hitInterval: 5,
    damage: 7, knockback: 0.8
});
