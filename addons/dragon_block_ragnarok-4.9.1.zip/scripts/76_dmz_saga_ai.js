// =====================================================================================
//  76_dmz_saga_ai.js - DragonMine Z's saga enemy brain (DBSagasEntity + EnemyBrain + SkillManager)
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): common/init/entities/sagas/DBSagasEntity.java, helper/SkillManager,
//  helper/ComboManager, entities/ai/{AiTier,AiProfile,EnemyBrain,AiTierResolver}. Kits per enemy:
//  43_dmz_saga_kits.js (generated from the DMZ constructors).
//
//  Every quest enemy (47_dmz_quests.js "dmzq_<dmz id>_v<n>" mobs) and the DMZ-kit common enemies in
//  75_mobs_bosses.js call DMZ_SAGA.onTick / onDeath from their mob definition; the brain then runs
//  for mobs with a live target in one shared loop every 5 ticks (no world scans):
//   - 4 AI tiers (NOVICE/SMART/ELITE/EXPERT): decision interval, dodge chance, cast commit, lockouts,
//     max consecutive casts + forced melee window, skill pick (highest cooldown / role fit / tactical)
//   - the kit's ki skills (37 KiSkillType kinds: waves, balls, lasers, disks, volleys, rains, AoE,
//     barrier, Taiyoken, Gum Bind, Wolf Fang, Dragon Fist...) with DMZ's tier damage/cooldown factors,
//     cast and fire ticks, colours and sizes; 80-tick spawn grace
//   - melee combos (kit cooldown + combo list), dash toward far targets (SMART+)
//   - evasion (cancels the hit + sidestep), zanzoken hops behind the attacker (SMART+), wild sense
//   - flight (canFly kits) when the target is in the air, slowed for 22 ticks after a ki hit
//   - transformation into the next form at 50% HP or on a lethal hit (DMZ_SAGA_CHAINS), 80 ticks
//     invulnerable, new stats = quest absolutes x difficulty or previous x 1.5, full health
//   - saga enemies never hurt each other (isQuestTeammate)
//  Per-enemy stats (ki damage, AI tier, transform numbers) come from DMZ_SAGA.setup(mob, {...}) and are
//  saved in RPG.data ("dzm:<uuid>") so a restart keeps them.
//  Test: /rpgc saga spawn <dmz id> [tier 1-4] [hp] [melee] [ki]   /rpgc saga info
// =====================================================================================
var DMZ_SAGA = (function () {
    var KITS = DMZ_SAGA_KITS, CHAINS = DMZ_SAGA_CHAINS;
    var FINAL = {};
    DMZ_SAGA_FINAL.forEach(function (id) { FINAL[id] = true; });

    // DBSagasEntity.Tier: damage multiplier (total damage as factor of the stat) / cooldown factor
    var TIER = { W: [1.25, 1.0], M: [1.5, 1.5], S: [1.75, 2.0] };
    var SKILL_GRACE = 80, KI_HIT_SLOW = 22, TRANSFORM_TICKS = 80, MELEE_REACH = 3.2;
    var MID_RANGE = 12, OUT_RANGE = 28;

    // KiSkillType: role (RT ranged travel, HS hitscan, PF projectile fast, AO aoe burst, DF defensive, GB guard break,
    // ZN zoning, BL blind), tier, default colours, kind (how we fire it), fire tick, cast duration (SkillManager)
    function S(role, tier, kind, fire, dur, colors, anim, snd) { return { role: role, tier: tier, kind: kind, fire: fire, dur: dur, c: colors || null, anim: anim, snd: snd || null }; }
    var SK = {
        1: S("RT", "M", "wave", 37, 60, ["#EDF4FF", "#29D8FF", "#0077FF"], "grab_ki", "ki_kame"),
        2: S("RT", "M", "wave", 37, 60, ["#FAE5FF", "#A63EF0", "#7106BD"], "grab_ki", "ki_beam"),
        3: S("HS", "M", "beam", 37, 60, ["#FFE657", "#F5A627", "#8B17CF"], "grab_ki", "ki_beam"),
        4: S("HS", "W", "laser", 1, 10, ["#FFFFFF", "#FFFFFF", null], "ki_blast", null),
        5: S("AO", "M", "explosion", 37, 60, null, "ki_ball", "ki_explosion"),
        6: S("DF", "W", "barrier", 1, 37, null, "ki_ball", null),
        7: S("AO", "S", "roar", 20, 50, null, "grab_horns", null),
        8: S("RT", "W", "wave", 37, 60, null, "grab_ki", "ki_beam"),
        9: S("RT", "M", "wave", 37, 60, null, "grab_ki", "ki_beam"),
        10: S("PF", "W", "volley", 37, 60, null, "ki_blast", null),
        11: S("PF", "W", "small", 1, 12, null, "ki_blast", null),
        12: S("AO", "S", "hurricane", 30, 30, null, "ki_ball", null),
        13: S("HS", "M", "triple", 10, 40, null, "ki_blast", null),
        14: S("HS", "M", "disk", 22, 30, null, "ki_ball", "ki_disk"),
        15: S("GB", "S", "giant", 50, 60, null, "ki_ball", "ki_supernova"),
        16: S("RT", "M", "wave", 32, 40, ["#FFFC85", "#FCE062", "#FFFFFF"], "grab_ki", "ki_beam"),
        17: S("GB", "S", "ball", 24, 30, ["#E3FFFF", "#E3FFFF", "#889999"], "ki_ball", "ki_beam"),
        18: S("RT", "S", "wave", 32, 40, ["#FFFCD6", "#FFEB52", "#F5C020"], "grab_ki", "ki_finalflash"),
        19: S("ZN", "S", "candy", 20, 35, null, "ki_blast", null),
        20: S("ZN", "W", "airvolley", 37, 60, null, "ki_blast", null),
        21: S("RT", "S", "wave", 32, 40, null, "grab_ki", "ki_beam"),
        22: S("GB", "M", "wolffang", 1, 35, null, "attack1_1", null),
        23: S("GB", "S", "dragonfist", 5, 27, ["#FFD700", "#FF8C00", null], "attack3_1", null),
        24: S("RT", "M", "wave", 37, 60, ["#FFE3E3", "#FF2A2A", "#B00020"], "grab_ki", "ki_kame"),
        25: S("BL", "W", "taiyoken", 12, 30, null, "ki_blast", null),
        26: S("HS", "W", "laser", 1, 18, ["#FFEB7A", "#FFE657", null], "ki_blast", null),
        27: S("RT", "M", "ball", 24, 30, ["#FFF3D0", "#FF7A1A", "#C43A00"], "ki_ball", "ki_burning"),
        28: S("GB", "S", "giant", 50, 60, ["#FF3866", "#A3143A", "#4A0316"], "ki_ball", "ki_supernova"),
        29: S("ZN", "S", "rain", 30, 80, ["#FFB8F4", "#8A2BE2", "#FF38D4"], "ki_blast", null),
        30: S("ZN", "S", "meteor", 30, 80, ["#9DFF8A", "#3DF54A", "#0FBF1B"], "ki_ball", null),
        31: S("ZN", "S", "dimpunch", 20, 40, ["#C451FF", "#C451FF", null], "attack2_1", null),
        32: S("RT", "S", "destruction", 30, 50, ["#C77DFF", "#5A189A", "#0B0014"], "ki_ball", null),
        33: S("RT", "S", "ball", 40, 60, ["#FFFFFF", "#FFFFFF", "#FFFFFF"], "ki_ball", "ki_spiritbomb"),
        34: S("RT", "M", "ball", 24, 30, ["#FFF1C2", "#FFB52E", "#C46A00"], "ki_ball", "ki_beam"),
        35: S("AO", "S", "slam", 20, 40, null, "attack1_1", null),
        36: S("AO", "S", "slam", 25, 45, null, "attack3_1", null),
        37: S("ZN", "M", "gumbind", 15, 30, null, "ki_blast", null)
    };
    var MELEE_SCALED = { 7: 1, 12: 1, 19: 1, 22: 1, 23: 1, 35: 1, 36: 1 };

    // AiProfile per tier: decision interval, dodge chance, cast commit, post-cast / global / strong lockouts,
    // max consecutive casts, forced melee window, skill pick, zanzoken allowed, dash allowed
    var PROFILE = {
        1: { dec: 10, dodge: 0.6, commit: 0.55, post: 120, glob: 60, strong: 420, consec: 1, forced: 100, pick: "cd", zz: false, dash: false },
        2: { dec: 6, dodge: 0.75, commit: 0.6, post: 90, glob: 50, strong: 320, consec: 2, forced: 70, pick: "role", zz: true, dash: true },
        3: { dec: 4, dodge: 0.9, commit: 0.75, post: 70, glob: 40, strong: 260, consec: 3, forced: 50, pick: "tac", zz: true, dash: true },
        4: { dec: 3, dodge: 0.97, commit: 0.9, post: 50, glob: 30, strong: 200, consec: 3, forced: 40, pick: "tac", zz: true, dash: true }
    };
    var ZZ_HOPS = [0, 2, 4, 6];

    var BRAIN = {};          // uuid -> brain (live mobs this session)
    var ACTIVE = {};         // uuid -> brain, mobs with a target (the 5-tick loop)
    function now() { return RPG.server.getTick(); }
    function num(v, d) { var n = Number(v); return isNaN(n) ? d : n; }

    /** "dmzq_saga_raditz_v1" -> "saga_raditz"; legacy ids via spec.kit. */
    function dmzId(mob) {
        var rid = String(mob.rpgId || "");
        if (rid.indexOf("dmzq_") === 0) return rid.substring(5).replace(/_v\d+$/, "");
        return ALIAS[rid] || null;
    }
    var ALIAS = typeof DMZ_SAGA_ALIAS !== "undefined" ? DMZ_SAGA_ALIAS : {};
    /** Common enemies that use a DMZ kit: register their mob id -> DMZ id (75_mobs_bosses.js). */
    function alias(mobId, dmz) { ALIAS[mobId] = dmz; }

    // ---- per-enemy stats, saved across restarts ----
    function load(uuid) { return RPG.data.get("dzm:" + uuid, null); }
    function store(uuid, st) {
        RPG.data.set("dzm:" + uuid, st);
        var idx = RPG.data.get("dzm_index", {}) || {};
        idx[uuid] = Date.now();
        RPG.data.set("dzm_index", idx);
    }
    function forget(uuid) {
        if (!RPG.data.has("dzm:" + uuid)) return;
        RPG.data.remove("dzm:" + uuid);
        var idx = RPG.data.get("dzm_index", {}) || {};
        delete idx[uuid];
        RPG.data.set("dzm_index", idx);
    }
    (function prune() {                  // entries of enemies that vanished long ago
        var idx = RPG.data.get("dzm_index", {}) || {}, cut = Date.now() - 6 * 3600 * 1000, changed = false;
        Object.keys(idx).forEach(function (u) { if (idx[u] < cut) { RPG.data.remove("dzm:" + u); delete idx[u]; changed = true; } });
        if (changed) RPG.data.set("dzm_index", idx);
    })();

    /**
     * Stats for a quest / raid / test enemy (QuestService.spawnKillObjectives + DBSagasEntity.onAddedToWorld):
     *   { hp, melee, ki, tier (1-4), diff: {hp, dmg}, tf: {hp, melee, ki, trigger}, noTransform }
     * hp/melee/ki are final values (difficulty and party already applied); tf absolutes get diff on transform.
     */
    function setup(mob, o) {
        o = o || {};
        var id = dmzId(mob), kit = KITS[id] || {};
        if (o.hp) { mob.maxHealth = o.hp; mob.health = o.hp; }
        if (o.melee) mob.setAttributeBase("generic.attack_damage", o.melee);
        var st = { ki: o.ki || 20, tier: o.tier || 1, diff: o.diff || null, tf: o.tf || null, notf: !!o.noTransform, at: now() };
        store(mob.uuid, st);
        var b = brain(mob, true);
        if (b) { b.st = st; b.ki = st.ki; b.tier = st.tier; b.prof = PROFILE[st.tier] || PROFILE[1]; }
        return b;
    }

    function brain(mob, create) {
        var u = mob.uuid, b = BRAIN[u];
        if (b || !create) return b || null;
        var id = dmzId(mob);
        if (!id) return null;
        var kit = KITS[id] || {}, st = load(u) || { ki: 20, tier: 1 };
        var t = now();
        b = {
            mob: mob, uuid: u, id: id, kit: kit, st: st, ki: num(st.ki, 20), tier: num(st.tier, 1), prof: PROFILE[num(st.tier, 1)] || PROFILE[1],
            born: t, skills: (kit.sk || []).map(function (s) {
                var d = SK[s[0]] || SK[11], f = TIER[d.tier][1];
                var cd = Math.max(10, Math.round(s[1] * 2.0 * f));
                return { type: s[0], def: d, cd: cd, size: s[2] || 1, c: [s[3] || (d.c && d.c[0]) || "#FFFFFF", s[4] || (d.c && d.c[1]) || "#FFD24A", s[5] || (d.c && d.c[2]) || null],
                    ready: t + SKILL_GRACE + (s[0] === 23 || s[0] === 25 ? Math.round(cd / 2) : 0) };
            }),
            castUntil: 0, lockUntil: 0, strongUntil: 0, consec: 0, forcedUntil: 0, nextDec: 0,
            evadeAt: 0, zzAt: 0, wsAt: 0, comboAt: t + 40, dashAt: 0, dashUntil: 0, slowUntil: 0, barrierUntil: 0,
            flying: false, tf: false, lastTarget: t, speed: mob.getAttributeBase("generic.movement_speed")
        };
        BRAIN[u] = b;
        try { mob.setAttributeBase("generic.knockback_resistance", dmzSagaBase(id)[4]); } catch (e) { }
        return b;
    }
    function drop(b) {
        delete ACTIVE[b.uuid];
        delete BRAIN[b.uuid];
    }

    // ---- helpers ----
    function alive(m) { try { return m && m.isAlive(); } catch (e) { return false; } }
    function isSaga(e) { if (!e || e.isPlayer()) return false; var r = String(e.rpgId || ""); return r.indexOf("dmzq_") === 0 || !!ALIAS[r]; }
    function snd(m, id, vol, pitch) { sfx(m, id, vol || 1, pitch || 1); }
    function dirTo(fx, fy, fz, t) {
        var dx = t.x - fx, dy = (t.y + 1.0) - fy, dz = t.z - fz, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
        return { x: dx / l, y: dy / l, z: dz / l };
    }
    function spread(d, deg) {
        var a = deg * Math.PI / 180, x = d.x + (Math.random() * 2 - 1) * a, y = d.y + (Math.random() * 2 - 1) * a, z = d.z + (Math.random() * 2 - 1) * a;
        var l = Math.sqrt(x * x + y * y + z * z) || 1;
        return { x: x / l, y: y / l, z: z / l };
    }
    function hurtAround(m, x, y, z, r, dmg, push) {
        if (dmg <= 0) return;
        RPG.world.entitiesNear(m.dimension, x, y, z, r).forEach(function (e) {
            try {
                if (e.uuid === m.uuid || !e.isAlive() || isSaga(e) || m.isAlly(e)) return;
                e.damageFrom(dmg, m, { kind: "ki", ignoreIFrames: true });
                if (push) { var dx = e.x - x, dz = e.z - z, l = Math.sqrt(dx * dx + dz * dz) || 1; e.push(dx / l * push, 0.4, dz / l * push); }
            } catch (err) { }
        });
    }
    function setSpeed(b, v) { try { b.mob.setAttributeBase("generic.movement_speed", v); } catch (e) { } }

    // SkillManager.getCalculatedDamage
    function skillDamage(b, s) {
        var mult = TIER[s.def.tier][0], melee = b.mob.attribute("generic.attack_damage");
        switch (s.type) {
            case 6: case 25: case 37: return 0;
            case 13: return b.ki * mult / 3;
            case 10: case 20: case 29: case 30: return b.ki * mult / 8;
            case 11: return b.ki * mult / 4;
        }
        return MELEE_SCALED[s.type] ? melee * mult : b.ki * mult;
    }

    // =========================================================================================
    //  firing (SkillManager.REGISTRY)
    // =========================================================================================
    function shot(m, id, d, over) {
        var p = RPG.world.shootFrom(m.dimension, m.x, m.eyeY - 0.2, m.z, d.x, d.y, d.z, id, over, m);
        return p;
    }
    function fire(b, s, t) {
        var m = b.mob, dmg = skillDamage(b, s), d = dirTo(m.x, m.eyeY - 0.2, m.z, t), ks = num(b.kit.ks, 0.6), size = s.size;
        var colors = { core: s.c[0], border: s.c[1], outline: s.c[2] || undefined };
        if (s.def.snd) snd(m, s.def.snd + "_fire", 1.5, 1);
        switch (s.def.kind) {
            case "wave": case "beam": {
                var p = shot(m, s.def.kind === "wave" ? "dmz_tech_wave" : "dmz_tech_beam", d,
                    { size: size * (s.def.kind === "beam" ? 0.6 : 1), colors: colors, damage: 0, speed: Math.max(0.8, ks), duration: 40, length: 64, followAim: false });
                if (p) { p.setVar("dmg", dmg); p.setVar("hits", 2); p.setVar("r", size * 2.5); }
                return;
            }
            case "laser":
                shot(m, "dmz_tech_laser", d, { size: Math.max(0.3, size * 0.4), colors: colors, damage: dmg, speed: Math.max(8, ks * 8) });
                snd(m, "laserbeam", 0.8, 1.1);
                return;
            case "triple":
                [0, 10, 20].forEach(function (delay) {
                    RPG.schedule(delay, function () {
                        if (!alive(m) || b.tf) return;
                        var tt = m.target || t;
                        shot(m, "dmz_tech_laser", dirTo(m.x, m.eyeY - 0.2, m.z, tt), { size: 0.4, colors: colors, damage: dmg, speed: Math.max(8, ks * 8) });
                        snd(m, "laserbeam", 0.8, 1.2);
                    });
                });
                return;
            case "disk": {
                var dk = shot(m, "dmz_tech_disk", d, { size: size, colors: colors, damage: dmg, speed: Math.max(0.6, ks), lifetime: 70 });
                if (dk && t) dk.homeAt(t, 0.15, 40);
                return;
            }
            case "small": {
                shot(m, "dmz_tech_bullet", d, { size: 0.5 * size, colors: colors, damage: dmg, speed: Math.max(0.6, ks), lifetime: 60 });
                snd(m, "kiblast_shoot", 0.8, 1 + Math.random() * 0.2);
                return;
            }
            case "volley": {
                for (var i = 0; i < 8; i++) (function (k) {
                    RPG.schedule(k * 2, function () {
                        if (!alive(m) || b.tf) return;
                        var tt = m.target || t;
                        shot(m, "dmz_tech_bullet", spread(dirTo(m.x, m.eyeY - 0.2, m.z, tt), 5), { size: 0.45 * size, colors: colors, damage: dmg, speed: Math.max(0.6, ks), lifetime: 60 });
                        snd(m, "kiblast_shoot", 0.3, 1.4 + Math.random() * 0.4);
                    });
                })(i);
                return;
            }
            case "airvolley": case "rain": case "meteor": {
                var cx = t.x, cy = t.y, cz = t.z, waves = s.def.kind === "airvolley" ? 2 : 4;
                for (var w = 0; w < waves; w++) (function (k) {
                    RPG.schedule(k * 10, function () {
                        if (!alive(m)) return;
                        for (var j = 0; j < 4; j++) {
                            var a = Math.random() * Math.PI * 2, r = Math.random() * 5;
                            RPG.world.shootFrom(m.dimension, cx + Math.cos(a) * r, cy + 18, cz + Math.sin(a) * r, 0.1 * (Math.random() - 0.5), -1, 0.1 * (Math.random() - 0.5),
                                "dmz_tech_bullet", { damage: dmg, size: s.def.kind === "meteor" ? 0.9 : 0.6, colors: colors, speed: 1.4, lifetime: 40 }, m);
                        }
                    });
                })(w);
                return;
            }
            case "ball": case "giant": {
                var giant = s.def.kind === "giant";
                var bl = shot(m, "dmz_tech_ball", d, { size: giant ? size * 2.5 : size, colors: colors, damage: 0, speed: giant ? 0.45 : Math.max(0.6, ks * 0.8), lifetime: 100 });
                if (bl) { bl.setVar("dmg", dmg); bl.setVar("r", giant ? Math.max(size * 2, 5) : Math.max(size, 2.5)); if (giant) bl.setVar("endBoom", 1); }
                return;
            }
            case "destruction": {
                for (var q = 0; q < 3; q++) (function (k) {
                    RPG.schedule(k * 6, function () {
                        if (!alive(m)) return;
                        var tt = m.target || t, o = shot(m, "dmz_tech_ball", spread(dirTo(m.x, m.eyeY, m.z, tt), 12), { size: size, colors: colors, damage: 0, speed: 0.7, lifetime: 80 });
                        if (o) { o.setVar("dmg", dmg / 3); o.setVar("r", 2.5); o.homeAt(tt, 0.12, 60); }
                    });
                })(q);
                return;
            }
            case "explosion":
                hurtAround(m, m.x, m.y + 1, m.z, Math.max(4, size * 5), dmg, 1.2);
                RPG.world.particle(m.dimension, "minecraft:explosion_emitter", m.x, m.y + 1, m.z, 2, 1.5, 0);
                snd(m, "ki_explosion_impact", 3, 0.7);
                return;
            case "roar": case "hurricane": case "candy": case "slam": {
                var rr = s.def.kind === "roar" ? 8 : s.def.kind === "hurricane" ? 6 : 5;
                var at = s.def.kind === "slam" ? t : m;
                hurtAround(m, at.x, at.y + 0.5, at.z, rr * Math.max(1, size * 0.8), dmg, s.def.kind === "roar" ? 2 : 0.8);
                RPG.world.particle(m.dimension, s.def.kind === "hurricane" ? "minecraft:cloud" : "minecraft:explosion", at.x, at.y + 1, at.z, 12, rr * 0.4, 0.05);
                snd(m, s.def.kind === "roar" ? "vegeta_oozaru_growl" : s.def.kind === "slam" ? "oozaru_fist" : "ki_explosion_impact", 2, 1);
                return;
            }
            case "barrier":
                b.barrierUntil = now() + 37;
                RPG.world.particle(m.dimension, "minecraft:end_rod", m.x, m.y + 1, m.z, 40, 1.4, 0.02);
                return;
            case "taiyoken":
                m.nearby(14).forEach(function (e) {
                    if (!e.isPlayer() || !m.canSee(e)) return;
                    e.addPotion("minecraft:blindness", 70, 0);
                    e.addPotion("minecraft:slowness", 40, 1);
                });
                RPG.world.particle(m.dimension, "minecraft:flash", m.x, m.eyeY, m.z, 1, 0, 0);
                return;
            case "gumbind":
                if (t && m.distanceTo(t) < 20) {
                    t.addPotion("minecraft:slowness", 60, 6);
                    t.addPotion("minecraft:mining_fatigue", 60, 2);
                    RPG.world.particleLine(m.dimension, "minecraft:dripping_honey", m.x, m.eyeY, m.z, t.x, t.y + 1, t.z, 0.5);
                }
                return;
            case "dimpunch": {
                var px = t.x, py = t.y, pz = t.z;
                RPG.world.particle(m.dimension, "minecraft:portal", px, py + 1, pz, 30, 0.6, 0.3);
                RPG.schedule(12, function () {
                    if (!alive(m)) return;
                    hurtAround(m, px, py + 1, pz, 3.5, dmg, 1);
                    RPG.world.particle(m.dimension, "minecraft:explosion", px, py + 1, pz, 1, 0, 0);
                });
                return;
            }
            case "wolffang": case "dragonfist": {
                var fist = s.def.kind === "dragonfist", hits = fist ? 1 : 3;
                m.setVelocity(d.x * 1.6, Math.max(0.1, d.y * 0.8), d.z * 1.6);
                for (var h = 0; h < hits; h++) (function (k) {
                    RPG.schedule(4 + k * 10, function () {
                        if (!alive(m) || !t.isAlive() || m.distanceTo(t) > 4.5) return;
                        var part = fist ? dmg : (k === hits - 1 ? dmg * 0.35 : dmg * 0.65 / (hits - 1));
                        t.damageFrom(part, m, { kind: "melee", ignoreIFrames: true, knockback: k === hits - 1 ? 1.8 : 0.2 });
                        snd(m, fist ? "dragon_fist" : "punch" + RPG.randomInt(1, 6), 1.2, 1);
                        if (fist) RPG.world.particle(m.dimension, "minecraft:flame", t.x, t.y + 1, t.z, 40, 0.8, 0.2);
                    });
                })(h);
                return;
            }
        }
    }

    // ---- skill choice (EnemyBrain.scoreSkill, simplified to distance/role) ----
    function score(b, s, dist, t, maxCd) {
        var role = s.def.role, los = b.mob.canSee(t), directional = role !== "AO" && role !== "DF" && role !== "BL";
        if (directional && !los) return 0;
        var burst = role === "AO" ? (s.type === 7 ? 9 : 6) : 0;
        if (b.prof.pick === "cd") {
            if (role === "DF") return 0.2;
            if (role === "AO") return dist <= burst ? 1.1 : 0;
            return 0.9 + 0.6 * (s.cd / maxCd) - (dist <= MELEE_REACH * 0.8 ? 0.3 : 0);
        }
        var sc = 0.5, airborne = !t.onGround;
        switch (role) {
            case "RT": sc = dist > OUT_RANGE ? 0.85 : dist > MID_RANGE ? 1.0 : dist > MELEE_REACH ? 0.8 : 0.35; break;
            case "HS": sc = dist > OUT_RANGE ? 0.75 : dist > MELEE_REACH ? 1.0 : 0.6; break;
            case "PF": sc = dist > OUT_RANGE ? 0.3 : dist > MID_RANGE ? 0.6 : 0.9; break;
            case "ZN": sc = (dist > MID_RANGE ? 1.0 : 0.45) + (airborne ? 0.3 : 0); break;
            case "GB": sc = (t.blocking ? 1.35 : 0.25) + (dist <= MID_RANGE ? 0.2 : 0); break;
            case "BL": if (dist > MID_RANGE) return 0; sc = 0.85 + (b.mob.health / b.mob.maxHealth < 0.4 ? 0.3 : 0); break;
            case "AO": if (dist > burst) return 0; sc = 1.2; break;
            case "DF": sc = b.mob.health / b.mob.maxHealth < 0.3 && dist > MELEE_REACH ? 0.6 : 0.15; break;
        }
        if (b.prof.pick === "tac" && s.def.tier === "S") sc += t.blocking ? 0.35 : -0.25;
        return sc + (Math.random() - 0.5) * (b.prof.pick === "role" ? 0.2 : 0.1);
    }
    function pick(b, t, dist, tk) {
        var ready = b.skills.filter(function (s) { return tk >= s.ready && !(s.def.tier === "S" && tk < b.strongUntil); });
        if (!ready.length) return null;
        var maxCd = 1, best = null, bs = 0.3;
        ready.forEach(function (s) { if (s.cd > maxCd) maxCd = s.cd; });
        ready.forEach(function (s) { var v = score(b, s, dist, t, maxCd); if (v > bs) { bs = v; best = s; } });
        return best;
    }
    function cast(b, s, t, tk) {
        var m = b.mob;
        b.castUntil = tk + s.def.dur;
        s.ready = tk + s.cd;
        b.lockUntil = tk + Math.round(b.prof.post * 0.5) + b.prof.glob;
        if (s.def.tier === "S") b.strongUntil = tk + b.prof.strong;
        if (++b.consec >= b.prof.consec) { b.consec = 0; b.forcedUntil = tk + b.prof.forced; }
        setSpeed(b, 0);
        m.lookAt(t.x, t.eyeY, t.z);
        m.playAnimation(s.def.anim);
        if (s.def.snd && s.def.fire > 5) snd(m, s.def.snd + "_charge", 1.2, 1);
        RPG.schedule(Math.max(1, s.def.fire), function () {
            if (!alive(m) || b.tf) return;
            var tt = m.target && m.target.isAlive() ? m.target : t;
            if (!tt || !tt.isAlive()) return;
            m.lookAt(tt.x, tt.eyeY, tt.z);
            fire(b, s, tt);
        });
        RPG.schedule(s.def.dur, function () { if (alive(m) && !b.tf) setSpeed(b, b.speed); });
    }

    // ---- melee combos (ComboManager: BASIC/AIR/KI_CHARGE_ATTACK/... as 3-5 hit strings) ----
    var COMBO_TIER = { BASIC: "M", AIR: "M", GUM_PUNCH: "M", GUM_EXPAND: "W", SLEEP_RECOVERY: "W", RAPID_KICKS: "W" };
    function combo(b, t, tk) {
        var m = b.mob, list = b.kit.cb.slice(1), type = list[RPG.randomInt(0, list.length - 1)] || "BASIC";
        var mult = TIER[COMBO_TIER[type] || "S"][0], melee = m.attribute("generic.attack_damage") * mult;
        var hits = type === "RAPID_KICKS" ? 5 : type === "BASIC" || type === "AIR" ? 3 : 4, anims = ["attack1_1", "attack2_1", "attack3_1", "combo1", "combo2"];
        b.comboAt = tk + Math.round(num(b.kit.cb[0], 120));
        b.castUntil = tk + hits * 6 + 4;
        setSpeed(b, 0);
        for (var i = 0; i < hits; i++) (function (k) {
            RPG.schedule(k * 6, function () {
                if (!alive(m) || b.tf || !t.isAlive() || m.distanceTo(t) > 5) return;
                m.lookAt(t.x, t.eyeY, t.z);
                m.playAnimation(anims[k % anims.length]);
                var last = k === hits - 1;
                t.damageFrom(last ? melee * 0.4 : melee * 0.6 / (hits - 1), m, { kind: "melee", ignoreIFrames: true, knockback: last ? 1.5 : 0.1 });
                if (type === "AIR" && k === 0) t.push(0, 0.9, 0);
                snd(m, last ? "critic_punch1" : "punch" + RPG.randomInt(1, 6), 1, 1);
                RPG.world.particle(m.dimension, "minecraft:crit", t.x, t.y + 1, t.z, 6, 0.3, 0.1);
            });
        })(i);
        RPG.schedule(hits * 6 + 4, function () { if (alive(m) && !b.tf) setSpeed(b, b.speed); });
    }

    // ---- movement: flight + dash ----
    function groundY(m) { var y = RPG.world.surfaceY(m.dimension, Math.floor(m.x), Math.floor(m.z)); return y === -9999 ? m.y : y; }
    function flight(b, t, tk) {
        var m = b.mob;
        if (!b.kit.fly) return;
        var dy = t.y - m.y, tAir = !t.onGround && t.y - groundY(t) > 2.5;
        var want = tAir || (b.flying && m.y - groundY(m) > 1.2 && dy > -1);
        if (want && !b.flying) { b.flying = true; m.setNoGravity(true); }
        else if (!want && b.flying) { b.flying = false; m.setNoGravity(false); return; }
        if (!b.flying || tk < b.castUntil) { if (b.flying) m.setVelocity(0, 0, 0); return; }
        var fs = num(b.kit.fs, 0.35) * (tk < b.slowUntil ? 0.2 : 1) * 1.6;
        var dx = t.x - m.x, dz = t.z - m.z, ty = t.y + 0.6 - m.y, hd = Math.sqrt(dx * dx + dz * dz) || 1;
        var close = hd < 2.4;
        m.lookAt(t.x, t.eyeY, t.z);
        m.setVelocity(close ? 0 : dx / hd * fs, Math.max(-fs, Math.min(fs, ty * 0.25)), close ? 0 : dz / hd * fs);
    }
    function dash(b, t, dist, tk) {
        if (!b.prof.dash || tk < b.dashAt || dist < 7 || dist > 22 || b.flying) return false;
        var m = b.mob, dx = t.x - m.x, dz = t.z - m.z, l = Math.sqrt(dx * dx + dz * dz) || 1;
        b.dashAt = tk + 80;
        m.setVelocity(dx / l * 1.4, 0.15, dz / l * 1.4);
        RPG.world.particle(m.dimension, "minecraft:cloud", m.x, m.y + 0.2, m.z, 6, 0.3, 0.02);
        return true;
    }

    // ---- defence (EnemyBrain.react: evade / zanzoken / wild sense), from the damage event ----
    function teleportBehind(m, a, dist) {
        var yaw = a.yaw * Math.PI / 180, x = a.x + Math.sin(yaw) * dist, z = a.z - Math.cos(yaw) * dist;
        var y = a.y;
        if (RPG.world.getBlock(m.dimension, Math.floor(x), Math.floor(y), Math.floor(z)) !== "minecraft:air") return false;
        RPG.world.particle(m.dimension, "minecraft:cloud", m.x, m.y + 1, m.z, 8, 0.3, 0.02);
        m.teleport(x, y, z);
        m.lookAt(a.x, a.eyeY, a.z);
        return true;
    }
    function defend(b, e, tk) {
        var m = b.mob, a = e.attacker;
        if (!a || !a.isPlayer() || tk < b.born + 20) return false;
        if (b.kit.ws && tk >= b.wsAt) {                         // wild sense: always reads the first hit, then cools down
            b.wsAt = tk + b.kit.ws;
            if (teleportBehind(m, a, 1.6)) { snd(m, "zanzoken", 1, 1); return true; }
        }
        if (b.kit.zz && b.prof.zz && tk >= b.zzAt && Math.random() < b.prof.dodge * 0.5) {
            b.zzAt = tk + Math.round(b.kit.zz[1] * (b.tier === 2 ? 1.5 : b.tier === 4 ? 0.8 : 1));
            var hops = ZZ_HOPS[Math.max(1, Math.min(3, b.kit.zz[0]))];
            for (var i = 0; i < hops; i++) (function (k) {
                RPG.schedule(k * 5, function () {
                    if (!alive(m) || !alive(a)) return;
                    var ang = Math.random() * Math.PI * 2, r = 4 + Math.random() * 2;
                    m.teleport(a.x + Math.cos(ang) * r, a.y, a.z + Math.sin(ang) * r);
                    RPG.world.particle(m.dimension, "minecraft:cloud", m.x, m.y + 1, m.z, 5, 0.3, 0.02);
                });
            })(i);
            RPG.schedule(hops * 5, function () { if (alive(m) && alive(a)) teleportBehind(m, a, 1.6); });
            snd(m, "zanzoken", 1, 1);
            return true;
        }
        if (b.kit.ev && tk >= b.evadeAt && Math.random() < b.prof.dodge * 0.5) {
            b.evadeAt = tk + b.kit.ev;
            var dx = m.x - a.x, dz = m.z - a.z, l = Math.sqrt(dx * dx + dz * dz) || 1, side = Math.random() < 0.5 ? 1 : -1;
            m.playAnimation("evasion1");
            m.setVelocity((-dz / l * side) * 1.1 + dx / l * 0.3, 0.2, (dx / l * side) * 1.1 + dz / l * 0.3);
            snd(m, "evasion" + RPG.randomInt(1, 2), 1, 1);
            return true;
        }
        return false;
    }

    // ---- transformation (DBSagasEntity.startTransformation / finishTransformationSpawn) ----
    function nextMob(b) {
        var next = CHAINS[b.id];
        if (!next || (b.st && b.st.notf)) return null;
        var variant = String(b.mob.rpgId).match(/_v(\d+)$/), id = "dmzq_" + next + "_v" + (variant ? variant[1] : "0");
        if (!RPG.mobs.exists(id)) id = "dmzq_" + next + "_v0";
        return RPG.mobs.exists(id) ? id : null;
    }
    function transform(b) {
        var m = b.mob, nid = nextMob(b);
        if (!nid || b.tf) return false;
        b.tf = true;
        b.castUntil = now() + TRANSFORM_TICKS;
        m.health = Math.max(1, m.health);
        setSpeed(b, 0);
        if (b.flying) m.setVelocity(0, 0, 0);
        m.playAnimation("transformation_1");
        snd(m, "transform_on", 2, 0.8);
        snd(m, "ki_charge_loop", 1.5, 1);
        var pulses = RPG.every(10, function () { if (alive(m)) RPG.world.particle(m.dimension, "minecraft:end_rod", m.x, m.y + 1, m.z, 15, 0.8, 0.15); });
        RPG.schedule(TRANSFORM_TICKS, function () {
            RPG.cancel(pulses);
            if (!alive(m)) { b.tf = false; return; }
            var st = b.st || {}, tf = st.tf || {}, diff = st.diff || { hp: 1, dmg: 1 };
            var prevMax = m.maxHealth, prevMelee = m.attribute("generic.attack_damage");
            m.transform(nid, { heal: true });
            var hp = tf.hp ? tf.hp * diff.hp : prevMax * 1.5;
            var melee = tf.melee ? tf.melee * diff.dmg : prevMelee * 1.5;
            var ki = tf.ki ? tf.ki * diff.dmg : b.ki * 1.5;
            m.maxHealth = hp; m.health = hp;
            m.setAttributeBase("generic.attack_damage", melee);
            RPG.world.particle(m.dimension, "minecraft:explosion_emitter", m.x, m.y + 1, m.z, 1, 0, 0);
            var nst = { ki: ki, tier: b.tier, diff: st.diff, tf: null, notf: false, at: now() };
            delete BRAIN[b.uuid]; delete ACTIVE[b.uuid];
            store(m.uuid, nst);
            var nb = brain(m, true);
            if (nb) { nb.flying = b.flying; ACTIVE[nb.uuid] = nb; }
        });
        return true;
    }

    // =========================================================================================
    //  the loop
    // =========================================================================================
    function step(b, tk) {
        var m = b.mob;
        if (!alive(m)) { drop(b); return; }
        if (b.tf) return;
        var t = m.target;
        if (!t || !t.isAlive() || t.dimension !== m.dimension) {
            if (tk - b.lastTarget > 200) { if (b.flying) { b.flying = false; m.setNoGravity(false); } delete ACTIVE[b.uuid]; }
            return;
        }
        b.lastTarget = tk;
        flight(b, t, tk);
        if (tk < b.castUntil || tk < b.nextDec) return;
        b.nextDec = tk + b.prof.dec;
        var dist = m.distanceTo(t);
        if (tk >= b.born + SKILL_GRACE && tk >= b.lockUntil && tk >= b.forcedUntil && b.skills.length && Math.random() < b.prof.commit) {
            var s = pick(b, t, dist, tk);
            if (s) { cast(b, s, t, tk); return; }
        }
        if (b.kit.cb && dist <= MELEE_REACH + 0.8 && tk >= b.comboAt) { combo(b, t, tk); return; }
        dash(b, t, dist, tk);
    }
    RPG.every(5, function () {
        var tk = now();
        for (var u in ACTIVE) {
            try { step(ACTIVE[u], tk); } catch (err) { RPG.log("DMZ saga brain: " + err); drop(ACTIVE[u]); }
        }
    });

    // MobDef hooks (once a second): wake the brain when the enemy has a target
    function onTick(mob) {
        var b = brain(mob, true);
        if (!b || ACTIVE[b.uuid]) return;
        var t = mob.target;
        if (t && t.isAlive()) { b.lastTarget = now(); ACTIVE[b.uuid] = b; }
    }
    function onDeath(mob) {
        var b = BRAIN[mob.uuid];
        if (b) drop(b);
        forget(mob.uuid);
    }

    RPG.on("damageFinal", function (e) {
        var t = e.target;
        if (!t || t.isPlayer()) return;
        var a = e.attacker;
        if (a && !a.isPlayer() && isSaga(a) && isSaga(t) && a.hasTag("dbr_raid_ally") === t.hasTag("dbr_raid_ally")) { e.cancel(); return; }      // isQuestTeammate (raid allies: 92_dbr_raids.js)
        var b = BRAIN[t.uuid];
        if (!b) return;
        var tk = now();
        if (b.tf || tk < b.barrierUntil) { e.cancel(); return; }
        if (tk >= b.castUntil && defend(b, e, tk)) { e.cancel(); return; }
        if (e.kind === "ki" && b.flying) b.slowUntil = tk + KI_HIT_SLOW;
        if (a && a.isPlayer() && !ACTIVE[b.uuid]) { ACTIVE[b.uuid] = b; b.lastTarget = tk; }
        // transformTrigger 0.5: transform when this hit takes it to half health (lethal hits: below)
        if (CHAINS[b.id] && t.health - e.amount <= t.maxHealth * num(b.st && b.st.tf && b.st.tf.trigger, 0.5) && t.health - e.amount > 0) {
            if (transform(b)) e.amount = Math.max(0, Math.min(e.amount, t.health - 1));
        }
    });
    RPG.on("lethal", function (e) {
        var t = e.target;
        if (!t || t.isPlayer()) return;
        var b = BRAIN[t.uuid];
        if (!b || !CHAINS[b.id]) return;
        if (b.tf || transform(b)) { e.cancel(); t.health = 1; }
    });
    // saga shots pass through other saga enemies
    RPG.on("projectileHit", function (p, target) {
        if (!target || target.isPlayer() || !p || !p.owner) return;
        if (isSaga(target) && isSaga(p.owner) && target.hasTag("dbr_raid_ally") === p.owner.hasTag("dbr_raid_ally")) return false;
    });

    // chain targets the quest data doesn't list still need a body to transform into
    Object.keys(CHAINS).forEach(function (from) {
        var to = CHAINS[from], id = "dmzq_" + to + "_v0";
        if (RPG.mobs.exists(id) || !RPG.mobs.exists("dmzq_" + from + "_v0")) return;
        var kit = KITS[to] || {}, srcModel = KITS[from] && (KITS[from].g & 1) ? from : null;
        var base = dmzSagaBase(to);
        RPG.mobs.define(id, {
            name: "&c" + to.replace(/^saga_/, "").replace(/_/g, " ").replace(/\b[a-z]/g, function (c) { return c.toUpperCase(); }),
            geo: sagaLook((kit.g & 1) ? to : (srcModel || from), to, kit.sc || 1),
            health: base[0], damage: base[2], speed: base[1], followRange: base[3], hostile: true, persistent: true, xp: 0,
            onTick: function (m) { onTick(m); }, onDeath: function (m) { onDeath(m); }
        });
    });

    // ---- test command ----
    RPG.commands.register("saga", {
        permission: 2, description: "/rpgc saga spawn <dmz id> [tier] [hp] [melee] [ki] | info | list <filter>",
        run: function (p, args) {
            if (!p) return;
            var sub = String(args[0] || "");
            if (sub === "list") {
                var f = String(args[1] || "");
                p.tell("&e" + Object.keys(KITS).filter(function (k) { return k.indexOf(f) >= 0 && RPG.mobs.exists("dmzq_" + k + "_v0"); }).slice(0, 60).join(", "));
                return;
            }
            if (sub === "info") {
                var n = 0;
                Object.keys(ACTIVE).forEach(function (u) { var b = ACTIVE[u]; n++; p.tell("&7" + b.id + " tier " + b.tier + " ki " + Math.round(b.ki) + " hp " + Math.round(b.mob.health) + "/" + Math.round(b.mob.maxHealth) + (b.flying ? " &bflying" : "")); });
                p.tell("&e" + n + " active saga enemies, " + Object.keys(BRAIN).length + " known");
                return;
            }
            if (sub !== "spawn" || !args[1]) { p.tell("&c/rpgc saga spawn <dmz id> [tier 1-4] [hp] [melee] [ki]"); return; }
            var id = String(args[1]).replace(/^dragonminez:/, ""), mid = "dmzq_" + id + "_v0";
            if (!RPG.mobs.exists(mid)) { p.tell("&cNo saga enemy " + id + " (try /rpgc saga list " + id.substring(0, 6) + ")"); return; }
            var yaw = p.yaw * Math.PI / 180, m = RPG.world.spawnMob(p.dimension, mid, p.x - Math.sin(yaw) * 8, p.y, p.z + Math.cos(yaw) * 8);
            if (!m) return;
            var base = dmzSagaBase(id);
            setup(m, { tier: Math.max(1, Math.min(4, num(args[2], 2))), hp: num(args[3], base[0]), melee: num(args[4], base[2]), ki: num(args[5], 20), diff: { hp: 1, dmg: 1 } });
            m.target = p;
            p.tell("&aSpawned " + id + " &7(kit: " + JSON.stringify(KITS[id] || {}) + ")");
        }
    });

    /** AiTierResolver.storyTier: EASY 1, NORMAL 2, HARD 3 (4 for the final bosses). */
    function storyTier(diffName, dmz) {
        var t = diffName === "EASY" ? 1 : diffName === "HARD" ? 3 : 2;
        return t === 3 && FINAL[dmz] ? 4 : t;
    }

    return { setup: setup, onTick: onTick, onDeath: onDeath, alias: alias, storyTier: storyTier, dmzId: dmzId, isSaga: isSaga,
        brainOf: function (m) { return BRAIN[m.uuid] || null; }, PROFILE: PROFILE, SK: SK };
})();
