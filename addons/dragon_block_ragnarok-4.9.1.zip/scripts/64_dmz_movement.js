// =====================================================================================
//  64_dmz_movement.js - DMZ flight, dash, perfect evasion, speed dodge, jump/sprint skills
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): FlyToggleC2S, FlightModeC2S, FlightModeLockC2S,
//  SetFlightSpeedLimitC2S, CombatFlyImpulseC2S, FlyStatusHandler, CombatEvent.maybeForceCombatFly,
//  DashC2S/DashHandler, SpeedDodgeHandler, UpdateSkillC2S TOGGLE and MovementSkillsHandler's
//  sprint modifier. DMZ steers flight on the client (FlySkillEvent / CombatFlightHandler), and so
//  does this port: client/scripts/44_dmz_flight.js moves the player every tick and asks the server
//  here to switch flight on/off, change mode, pay for impulses and dash.
//
//  Player vars (the radial menu and the client read them):
//    dmz_flight_mode 0 search | 1 combat     dmz_flight_lock 0|1     dmz_flight_locked_mode 0|1
//    dmz_flight_speed_limit 5..100            dmz_skill_active {jump: true, sprint: true, kisense: true...}
//    dmz_speed_attr  the movement-speed attribute (client air-drag compensation)
//    fly_fast 1 while sprint-flying (aura, 31_dmz_transform.js)
//  Flying itself is the effect "flight" (others check p.hasEffect("flight")).
//
//  Net: client -> "dmz_flight" {a: "on"|"off"|"mode"|"impulse"|"dash"|"state"|"hello", ...}
//       server -> "dmz_fly" {a: "key"|"menu"|"dash"}, "dmz_move_cfg" (config), "dmz_bar" {key, args}
//  Config: config/dbr_movement.json (DMZ CombatConfig defaults).
// =====================================================================================
RPG.effects.define("flight", {
    name: "Flying",
    color: "#E0F0FF",
    tickInterval: 5,
    onApply(player) {
        player.setFlying(true);                // mayfly for the anti-cheat; the client script steers
        player.setFlySpeed(0);                 // no vanilla creative-flight input on top of DMZ's
        player.fallDistance = 0;
        player.progressQuest("fly", 1);
    },
    onTick(player) {
        if (!player.isFlying()) player.setFlying(true);       // vanilla drops "flying" on a double jump
    },
    onRemove(player) {
        player.setFlying(false);
        player.setFlySpeed(0.05);
        player.fallDistance = 0;
        if (player.getVar("fly_fast", 0)) player.setVar("fly_fast", 0);
        player.setShared("flyFast", null);
        resumeHeld(player);
    }
});
// DMZ's mob-effect icons for the cooldowns (MainEffects.DASH_CD / DOUBLEDASH_CD)
RPG.effects.define("dash_cd", { name: "Dash", color: "#9AD8FF", beneficial: false });
RPG.effects.define("doubledash_cd", { name: "Double Dash", color: "#5FB7FF", beneficial: false });
// MovementSkillsHandler.SPRINT_SPEED_UUID: MULTIPLY_TOTAL +0.06 per Sprint level
RPG.effects.define("dmz_sprint_skill", { name: "Sprint", hidden: true, maxStacks: 10,
    attributes: { "minecraft:generic.movement_speed": { amount: 0.06, operation: "multiply_total" } } });

var DMZ_FLIGHT = (function () {
    var CFG = dbrConfig("dbr_movement", {
        baselineFormDrain: 80,
        combatFlyAutoSwitchOnDamage: true,
        combatFlyLockSeconds: 8,
        combatFlyBaseSpeed: 0.30,
        combatFlySprintSpeed: 0.50,
        combatFlyHoldSpeedMultiplier: 1.6,
        combatFlyDrainMultiplier: 0.5,
        combatFlyImpulseKiCostPct: 0.05,
        combatFlyImpulseCooldownTicks: 25,
        dashCooldownSeconds: 4,
        doubleDashCooldownSeconds: 12,
        enablePerfectEvasion: true,
        perfectEvasionWindowMs: 200,
        enableSpeedDodge: true,
        speedDodgeRatioAtLevel1: 2.5,
        speedDodgeRatioAtMaxLevel: 1.4,
        speedDodgeCooldownTicks: 10,
        nonPlayerAttackerSpeed: 1.0,
        speedDodgeBaseChance: 0.10,
        speedDodgeMaxChancePvp: 0.35,
        speedDodgeMaxChancePve: 0.50,
        speedDodgeMeditationChanceFloor: 0.60,
        speedDodgeFullChanceSpeedRatio: 2.0,
        speedDodgeBpRatioAtLevel1: 2.0,
        speedDodgeBpRatioAtMaxLevel: 1.0,
        speedDodgeFullChanceBpRatio: 10.0,
        speedDodgeStreakMultiplier: 0.75,
        speedDodgeStreakResetTicks: 60,
        speedDodgeStaminaCostPct: 0.03,
        surgeFlySpeedMultiplier: 1.25
    });
    var TOGGLEABLE = ["kiprotection", "ki_infusion", "jump", "sprint", "kisense"];   // UpdateSkillC2S.TOGGLEABLE_SKILLS

    // ---- helpers ------------------------------------------------------------------------
    function num(v, d) { v = Number(v); return isNaN(v) || !isFinite(v) ? d : v; }
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function lerp(t, a, b) { return a + (b - a) * t; }
    function tick() { return RPG.server.getTick(); }
    function skill(p, s) { return typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS.level(p, s) : 0; }
    function created(p) { return !!p.getVar("dmz_created", 0); }
    function stunned(p) { return p.hasEffect("stunned"); }
    function creative(p) { var g = p.getGameMode(); return g === "creative" || g === "spectator"; }
    function flying(p) { return p.hasEffect("flight"); }
    function mode(p) { return num(p.getVar("dmz_flight_mode", 0), 0) === 1 ? 1 : 0; }
    function riding(p) { var v = p.vehicle; return !!v && !v.isPlayer(); }
    function bar(p, key, args) { RPG.net.send(p, "dmz_bar", { key: key, args: args || [] }); }
    function setVarIf(p, k, v) { if (p.getVar(k, null) !== v) p.setVar(k, v); }
    function activeMap(p) { var m = p.getVar("dmz_skill_active", null); return m && typeof m === "object" ? m : {}; }
    function skillActive(p, s) { return !!activeMap(p)[s]; }
    function activationCost(lvl) { return Math.ceil(CFG.baselineFormDrain * Math.max(0.01, 0.04 - lvl * 0.003)); }
    function view(p) { return dmzView(p); }

    // DMZ Cooldowns (ticks, not saved: they are all a few seconds)
    var CD = {};
    function hasCd(p, k) { var c = CD[p.uuid]; return !!c && (c[k] || 0) > tick(); }
    function setCd(p, k, t) { (CD[p.uuid] || (CD[p.uuid] = {}))[k] = tick() + Math.max(0, t); }
    function clearCd(p, k) { var c = CD[p.uuid]; if (c) delete c[k]; }
    function cdLeft(p, k) { var c = CD[p.uuid]; return c ? Math.max(0, (c[k] || 0) - tick()) : 0; }
    // PacketRateLimiter.allow(uuid, key, gameTime, minTicks)
    var RATE = {};
    function rate(p, k, ticks) {
        var key = p.uuid + k, now = tick();
        if (RATE[key] !== undefined && now - RATE[key] < ticks) return false;
        RATE[key] = now;
        return true;
    }

    // ---- FlyToggleC2S -------------------------------------------------------------------
    function flyRequest(p, enable) {
        if (!rate(p, "flytoggle", 2) || stunned(p)) return;
        var lvl = skill(p, "fly");
        if (lvl <= 0 || flying(p) === enable) return;
        if (enable && riding(p)) return;
        if (enable && !creative(p) && p.resource("ki") < activationCost(lvl)) return;
        if (enable) p.addEffect("flight", -1);
        else p.removeEffect("flight");
    }

    // ---- FlightModeC2S (target -1 = switch; starts flying in combat mode when off) --------
    function setMode(p, target) {
        target = target === undefined || target === null ? -1 : Math.floor(num(target, -1));
        if (!rate(p, "flightmode", 2)) return;
        if (!created(p) || stunned(p)) return;
        var lvl = skill(p, "fly");
        if (lvl <= 0 || skill(p, "kicontrol") <= 0) return;
        var cur = mode(p), t = target === -1 ? (cur === 1 ? 0 : 1) : target;
        if ((t !== 0 && t !== 1) || t === cur) return;
        if (t === 0 && hasCd(p, "combat_fly_lock")) return;
        if (!flying(p) && target === -1) {
            if (p.resource("ki") < activationCost(lvl)) return;
            p.addEffect("flight", -1);
        }
        p.setVar("dmz_flight_mode", t);
        if (p.getVar("dmz_flight_lock", 0)) p.setVar("dmz_flight_locked_mode", t);
    }

    // ---- FlightModeLockC2S ------------------------------------------------------------------
    function toggleLock(p) {
        if (!rate(p, "flightlock", 2)) return;
        if (!created(p) || stunned(p)) return;
        if (skill(p, "fly") <= 0 || skill(p, "kicontrol") <= 0) return;
        var lock = !p.getVar("dmz_flight_lock", 0);
        p.setVar("dmz_flight_lock", lock ? 1 : 0);
        if (lock) p.setVar("dmz_flight_locked_mode", mode(p));
    }

    // ---- SetFlightSpeedLimitC2S ---------------------------------------------------------------
    function setSpeedLimit(p, v) {
        if (stunned(p)) return;
        v = Math.floor(num(v, 0));
        var next = v <= 0 ? 100 : Math.max(5, Math.min(100, Math.floor(v / 5) * 5));
        setVarIf(p, "dmz_flight_speed_limit", next);
    }

    // The radial's Fly node and the F key run DMZ's client-side toggle (performStandardToggle):
    // a 250 ms wait on the ground, the take-off jump, flight from the top of the jump.
    function toggle(p) { RPG.net.send(p, "dmz_fly", { a: "menu" }); }
    function keyPress(p) { RPG.net.send(p, "dmz_fly", { a: "key" }); }
    function dashKey(p) { RPG.net.send(p, "dmz_fly", { a: "dash" }); }

    // ---- CombatEvent.maybeForceCombatFly -------------------------------------------------------
    function forceCombat(p) {
        if (!CFG.combatFlyAutoSwitchOnDamage || !p || !flying(p)) return;
        setCd(p, "combat_fly_lock", CFG.combatFlyLockSeconds * 20);
        if (mode(p) === 0) p.setVar("dmz_flight_mode", 1);
    }

    // ---- server side of flight, every tick (FlyStatusHandler.onPlayerTick) ----------------------
    var TRACK = {};               // uuid -> {x, y, z, speed (3D), h (horizontal)}, blocks per tick
    var FLYSTATE = {};            // uuid -> {fast, sprint} as the client reports it
    RPG.every(1, function () {
        RPG.server.players().forEach(function (p) {
            if (p.getVar("dmz_flight_lock", 0)) {                  // restoreLockedFlightMode
                var lm = num(p.getVar("dmz_flight_locked_mode", 0), 0);
                if (mode(p) !== lm && !hasCd(p, "combat_fly_lock")) p.setVar("dmz_flight_mode", lm);
            }
            var tr = TRACK[p.uuid];
            if (!flying(p)) { if (tr) { delete TRACK[p.uuid]; delete FLYSTATE[p.uuid]; } return; }
            if (!tr) tr = TRACK[p.uuid] = { x: p.x, y: p.y, z: p.z, speed: 0, h: 0 };
            var dx = p.x - tr.x, dy = p.y - tr.y, dz = p.z - tr.z;
            tr.h = Math.sqrt(dx * dx + dz * dz); tr.speed = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (tr.speed > 32) { tr.speed = 0; tr.h = 0; }      // a teleport
            tr.x = p.x; tr.y = p.y; tr.z = p.z;
            if (riding(p)) { p.removeEffect("flight"); return; }  // mounting stops flight
            if (creative(p)) return;
            p.fallDistance = 0;
            // flyIntoWall: crashing sideways faster than 0.35 b/t hurts 5-35 % of max health
            if (p.horizontalCollision && tr.h > 0.35) {
                var f = clamp((tr.h - 0.35) / (1.5 - 0.35), 0, 1);
                p.damage(p.maxHealth * lerp(f, 0.05, 0.35));
                sfx(p, "minecraft:entity.player.hurt", 1, 0.5 + f * 0.5);
            }
        });
    });

    // ---- ki drain every second (FlyStatusHandler.handleFlightKiDrain) -----------------------------
    function drainCost(p) {
        var lvl = skill(p, "fly"), base = CFG.baselineFormDrain / 4;
        var pct = Math.max(0.002, 0.03 - lvl * 0.005) * lerp((clamp(lvl, 1, 10) - 1) / 9, 4, 1);
        var tr = TRACK[p.uuid];
        if (p.sprinting && tr && tr.speed > 0.65) pct *= 2;          // sprint flight
        if (mode(p) === 1) pct *= CFG.combatFlyDrainMultiplier;
        return Math.ceil(base * pct);
    }
    RPG.every(20, function () {
        RPG.server.players().forEach(function (p) {
            if (!flying(p) || creative(p)) return;
            var cost = drainCost(p);
            if (p.resource("ki") >= cost) p.addResource("ki", -cost);
            else p.removeEffect("flight");
        });
    });

    // ---- CombatFlyImpulseC2S -------------------------------------------------------------------
    function impulse(p) {
        if (!created(p) || !flying(p) || mode(p) !== 1 || hasCd(p, "combatfly_impulse_cd")) return;
        if (creative(p)) { setCd(p, "combatfly_impulse_cd", CFG.combatFlyImpulseCooldownTicks); return; }
        var cost = Math.ceil(CFG.baselineFormDrain * CFG.combatFlyImpulseKiCostPct);
        if (p.resource("ki") < cost) return;
        p.addResource("ki", -cost);
        setCd(p, "combatfly_impulse_cd", CFG.combatFlyImpulseCooldownTicks);
    }

    // ---- DashHandler ------------------------------------------------------------------------------
    var LAST_HURT = {};           // uuid -> {t (ms), a (attacker)}   (Status.lastHurtTime, DMZ_LAST_ATTACKER_ID_TAG)

    // LivingEntity.knockback(strength, x, z) as DMZ calls it
    function knockback(e, s, x, z, scale) {
        var len = Math.sqrt(x * x + z * z);
        if (s <= 0 || len < 1e-5) return;
        var nx = x / len * s, nz = z / len * s, k = scale || 1;
        e.setVelocity((e.vx / 2 - nx) * k, (e.onGround ? Math.min(0.4, e.vy / 2 + s) : e.vy) * k, (e.vz / 2 - nz) * k);
    }
    function lookOf(e) {
        var yaw = e.yaw * Math.PI / 180, pitch = e.pitch * Math.PI / 180;
        return { x: -Math.sin(yaw) * Math.cos(pitch), y: -Math.sin(pitch), z: Math.cos(yaw) * Math.cos(pitch) };
    }
    // DashHandler.getDashDirectionFromInput: 1 front, 2 back, 3 right, 4 left
    function dashDirection(x, z) {
        if (z > 0 && x === 0) return 1;
        if (z < 0 && x === 0) return 2;
        if (x < 0 && z === 0) return 4;
        if (x > 0 && z === 0) return 3;
        if (z > 0) return 1;
        if (z < 0) return 2;
        return 1;
    }
    // collision shape empty (approximation: air, fluids and plants have none)
    var PASSABLE = /(^|:)(air|cave_air|void_air|water|lava|light|grass|short_grass|tall_grass|fern|large_fern|dead_bush|snow|vine|torch|wall_torch|redstone_wire|rail|.*_rail|.*_button|.*_pressure_plate|.*_sapling|.*_flower|dandelion|poppy|.*_tulip|allium|azure_bluet|oxeye_daisy|cornflower|lily_of_the_valley|.*_mushroom|sugar_cane|kelp|seagrass|tall_seagrass|.*_carpet|.*_sign|.*_banner|cobweb|fire|soul_fire|lever|tripwire|.*_coral_fan)$/;
    function empty(dim, x, y, z) { return PASSABLE.test(String(RPG.world.getBlock(dim, Math.floor(x), Math.floor(y), Math.floor(z)) || "minecraft:air").split("[")[0]); }
    function tryStepUp(p, dx, dz, maxStep) {
        var len = Math.sqrt(dx * dx + dz * dz);
        if (maxStep <= 0 || len < 1e-3) return;
        var tx = p.x + dx / len * 0.9, tz = p.z + dz / len * 0.9, by = Math.floor(p.y), dim = p.dimension;
        if (empty(dim, tx, by, tz)) return;
        for (var s = 1; s <= maxStep; s++) {
            var fy = by + s;
            if (empty(dim, tx, fy, tz) && empty(dim, tx, fy + 1, tz) && !empty(dim, tx, fy - 1, tz)) {
                p.teleport(tx, fy, tz);
                return;
            }
        }
    }

    function dash(p, xIn, zIn, isDouble) {
        if (!created(p) || stunned(p) || p.hasEffect("dmz_tech_rooted")) return;
        xIn = clamp(num(xIn, 0), -1, 1); zIn = clamp(num(zIn, 0), -1, 1);
        if (xIn === 0 && zIn === 0) zIn = 1;

        // perfect evasion: a dash within 200 ms of being hit; within 100 ms you vanish behind the attacker
        var now = Date.now(), lh = LAST_HURT[p.uuid], win = CFG.perfectEvasionWindowMs;
        var since = lh ? now - lh.t : 1e9;
        var attacker = lh && lh.a && lh.a.isAlive() && lh.a.dimension === p.dimension ? lh.a : null;
        var isEvasion = since <= win && !hasCd(p, "perfect_evasion_cd");
        var isVanish = !!attacker && since <= Math.max(50, win / 2);
        if (isEvasion && CFG.enablePerfectEvasion) {
            var eCost = Math.ceil(CFG.baselineFormDrain * 0.65);
            if (p.resource("ki") >= eCost) {
                p.addResource("ki", -eCost);
                lh.t = 0;
                setCd(p, "perfect_evasion_cd", 30);
                if (attacker) {
                    if (isVanish) {
                        var look = lookOf(attacker);
                        p.teleportTo(p.dimension, attacker.x - look.x * 1.3, attacker.y, attacker.z - look.z * 1.3, attacker.yaw, p.pitch);
                        knockback(attacker, 1.1, attacker.x - p.x, attacker.z - p.z);
                        attacker.damageFrom(Math.max(1, DMZ_F.melee(view(p)) * 0.2), p);
                    } else {
                        knockback(attacker, 1.35, attacker.x - p.x, attacker.z - p.z, 0.6);
                    }
                }
                sfx(p, isVanish ? "tp_short" : "evasion1", 1, isVanish ? 1 : 1.2 + Math.random() * 0.2);
                animPulse(p, "evade", { v: 0 });
                return;
            }
        }

        var fly = flying(p);
        if (fly && mode(p) === 1) return;                       // no dashes in combat flight (it has impulses)
        var dashActive = hasCd(p, "dash_active");
        if (isDouble && !dashActive) isDouble = false;          // the client only asks for a double inside DashActive
        var canDouble = !fly && isDouble && dashActive && !hasCd(p, "doubledash_cd");
        var canNormal = !isDouble && !hasCd(p, "dash_cd");
        if (!canDouble && !canNormal) return;

        var distance = 4 * (num(p.attribute("generic.movement_speed"), 0.1) / 0.1);
        var drain = CFG.baselineFormDrain, kiCost = 0, stamCost = 0, total;
        if (canDouble) {
            distance *= 1.5;
            total = Math.ceil(drain * 0.25);
            kiCost = Math.ceil(total * 0.25); stamCost = Math.ceil(total * 0.75);
        } else {
            total = Math.ceil(drain * 0.12);
            if (fly) kiCost = total; else stamCost = total;
        }
        if (creative(p)) { kiCost = 0; stamCost = 0; }
        if (p.resource("ki") < kiCost || p.resource("stamina") < stamCost) return;
        if (p.getFood() <= 3) return;
        if (kiCost > 0) p.addResource("ki", -kiCost);
        if (stamCost > 0) p.addResource("stamina", -stamCost);

        var yaw = p.yaw * Math.PI / 180, fx = -Math.sin(yaw), fz = Math.cos(yaw);   // forward; right = (-fz, 0, fx)
        var dx = fx * zIn - fz * xIn, dz = fz * zIn + fx * xIn, dl = Math.sqrt(dx * dx + dz * dz) || 1;
        dx /= dl; dz /= dl;
        if (fly) {
            var tr = TRACK[p.uuid];
            var sampled = Math.max(Math.sqrt(p.vx * p.vx + p.vy * p.vy + p.vz * p.vz), tr ? tr.speed : 0);
            var imp = Math.min(3.8, Math.max(0.55, distance * 0.30 + sampled * 2.5));
            p.setVelocity(p.vx + dx * imp, 0, p.vz + dz * imp);
            p.fallDistance = 0;
        } else {
            p.setVelocity(p.vx + dx * distance * 0.3, p.vy + (p.onGround ? 0.35 : 0.2), p.vz + dz * distance * 0.3);
            tryStepUp(p, dx, dz, canDouble ? 2 : 1);
        }
        RPG.world.particle(p.dimension, "minecraft:explosion", p.x, p.y + 0.5, p.z, 1, 0, 0);

        var dashCd = CFG.dashCooldownSeconds * 20, dblCd = CFG.doubleDashCooldownSeconds * 20;
        setCd(p, "dash_cd", dashCd);
        p.addEffect("dash_cd", dashCd);
        if (canDouble) {
            setCd(p, "doubledash_cd", dblCd);
            clearCd(p, "dash_active");
            p.addEffect("doubledash_cd", dblCd);
        } else setCd(p, "dash_active", 15);
        sfx(p, "minecraft:entity.player.attack.sweep", 0.5, 1.5 + Math.random() * 0.3);
        if (!fly) animPulse(p, "dash", { d: dashDirection(xIn, zIn) + (canDouble ? 4 : 0) });
    }

    // ---- SpeedDodgeHandler (passive, needs Meditation) ----------------------------------------------
    var STREAK = {};
    function medProgress(lvl) { return (clamp(lvl, 1, 10) - 1) / 9; }
    function lerpMed(a, b, lvl) { return a + (b - a) * medProgress(lvl); }
    function maxChance(lvl, pvp) {
        var cap = pvp ? CFG.speedDodgeMaxChancePvp : CFG.speedDodgeMaxChancePve, floor = CFG.speedDodgeMeditationChanceFloor;
        return cap * (floor + (1 - floor) * medProgress(lvl));
    }
    function scaleChance(progress, lvl, pvp) {
        var max = maxChance(lvl, pvp), base = Math.min(CFG.speedDodgeBaseChance, max);
        return base + (max - base) * clamp(progress, 0, 1);
    }
    function speedChance(mine, theirs, lvl, pvp) {
        if (theirs <= 0) return 0;
        var req = lerpMed(CFG.speedDodgeRatioAtLevel1, CFG.speedDodgeRatioAtMaxLevel, lvl), ratio = mine / theirs;
        if (ratio < req) return 0;
        return scaleChance(Math.log(ratio / req) / Math.log(CFG.speedDodgeFullChanceSpeedRatio), lvl, pvp);
    }
    function dodgeChance(p, a, lvl) {
        var mine = DMZ_F.speed(view(p));
        if (a.isPlayer() && created(a.asPlayer())) return speedChance(mine, DMZ_F.speed(view(a.asPlayer())), lvl, true);
        var bp = a.rpgId ? powerLevel(a) : 0;                   // toolkit mobs have a battle power (IBattlePower)
        if (bp <= 0) return speedChance(mine, CFG.nonPlayerAttackerSpeed, lvl, false);
        var req = lerpMed(CFG.speedDodgeBpRatioAtLevel1, CFG.speedDodgeBpRatioAtMaxLevel, lvl);
        var ratio = DMZ_F.battlePower(view(p)) / bp;
        if (ratio < req) return 0;
        return scaleChance(Math.log(ratio / req) / Math.log(CFG.speedDodgeFullChanceBpRatio), lvl, false);
    }
    function dodgeVariant(p, a) {     // 1 front, 2 back, 3 left, 4 right: away from the attacker
        var tx = a.x - p.x, tz = a.z - p.z, l = Math.sqrt(tx * tx + tz * tz);
        if (l < 1e-3) return 2;
        tx /= l; tz /= l;
        var yaw = p.yaw * Math.PI / 180, lx = -Math.sin(yaw), lz = Math.cos(yaw), rx = -lz, rz = lx;
        var fwd = lx * tx + lz * tz, side = rx * tx + rz * tz;
        if (Math.abs(fwd) >= Math.abs(side)) return fwd > 0 ? 2 : 1;
        return side > 0 ? 3 : 4;
    }
    function trySpeedDodge(p, e) {
        var a = e.attacker;
        if (!CFG.enableSpeedDodge || !a || e.projectile || e.kind !== "melee" || a.uuid === p.uuid) return false;
        if (stunned(p) || p.getGameMode() === "spectator") return false;
        if (hasCd(p, "dash_active") || hasCd(p, "dodge_cd")) return false;
        var lvl = skill(p, "meditation");
        if (lvl <= 0) return false;
        var chance = dodgeChance(p, a, lvl);
        if (chance <= 0) return false;
        var now = tick(), st = STREAK[p.uuid];
        var n = st && now - st.at <= CFG.speedDodgeStreakResetTicks ? st.n : 0;
        chance *= Math.pow(CFG.speedDodgeStreakMultiplier, n);
        var cost = p.maxResource("stamina") * CFG.speedDodgeStaminaCostPct;
        if (p.resource("stamina") < cost) return false;
        if (Math.random() >= chance) return false;
        e.cancel();
        setCd(p, "dodge_cd", CFG.speedDodgeCooldownTicks);
        if (cost > 0) p.addResource("stamina", -cost);
        STREAK[p.uuid] = { n: n + 1, at: now };
        sfx(p, "evasion1", 1, 1.2 + Math.random() * 0.2);
        animPulse(p, "evade", { v: dodgeVariant(p, a) });
        return true;
    }

    RPG.on("hurt", function (e) {
        var t = e.target;
        if (!t || !t.isPlayer() || e.isCancelled()) return;
        var p = t.asPlayer();
        if (!created(p)) return;
        if (trySpeedDodge(p, e)) return;
        LAST_HURT[p.uuid] = { t: Date.now(), a: e.attacker && e.attacker.uuid !== p.uuid ? e.attacker : null };
        forceCombat(p);
        if (e.attacker && e.attacker.isPlayer() && e.attacker.uuid !== p.uuid) forceCombat(e.attacker.asPlayer());
    });

    // ---- UpdateSkillC2S TOGGLE + the Sprint skill's speed modifier -------------------------------
    function setActive(p, id, on) {
        var m = activeMap(p), was = !!m[id];
        if (was === !!on) return;
        if (on) m[id] = true; else delete m[id];
        p.setVar("dmz_skill_active", m);
        refreshSprint(p);
    }
    function skillToggle(p, id) {
        id = String(id || "");
        if (TOGGLEABLE.indexOf(id) < 0 || stunned(p) || skill(p, id) <= 0) return;
        setActive(p, id, !skillActive(p, id));
    }
    function refreshSprint(p) {
        var lvl = created(p) && skillActive(p, "sprint") && num(p.getVar("dmz_release", 0), 0) >= 5 && !stunned(p) ? Math.min(10, skill(p, "sprint")) : 0;
        if (p.effectStacks("dmz_sprint_skill") === lvl) return;
        p.removeEffect("dmz_sprint_skill");
        if (lvl > 0) p.addEffectStacks("dmz_sprint_skill", -1, lvl);
    }
    RPG.every(20, function () {
        RPG.server.players().forEach(function (p) {
            if (!created(p)) return;
            refreshSprint(p);
            setVarIf(p, "dmz_speed_attr", Math.round(num(p.attribute("generic.movement_speed"), 0.1) * 1000) / 1000);
            setVarIf(p, "dmz_creative", creative(p) ? 1 : 0);
        });
    });

    function attachSkills() {
        if (typeof DMZ_SKILLS === "undefined") return;
        DMZ_SKILLS.toggle = skillToggle;
        DMZ_SKILLS.isActive = skillActive;
        DMZ_SKILLS.setActive = setActive;
    }
    attachSkills();

    // ---- config for the client -----------------------------------------------------------
    function sendCfg(p) {
        RPG.net.send(p, "dmz_move_cfg", {
            combatFlyBaseSpeed: CFG.combatFlyBaseSpeed, combatFlySprintSpeed: CFG.combatFlySprintSpeed,
            combatFlyHoldSpeedMultiplier: CFG.combatFlyHoldSpeedMultiplier, combatFlyImpulseCooldownTicks: CFG.combatFlyImpulseCooldownTicks,
            baselineFormDrain: CFG.baselineFormDrain, surgeFlySpeedMultiplier: CFG.surgeFlySpeedMultiplier
        });
    }
    RPG.on("playerJoin", function (p) { RPG.schedule(20, function () { sendCfg(p); }); });
    RPG.on("death", function (p) { if (flying(p)) p.removeEffect("flight"); });

    RPG.net.on("dmz_flight", function (p, d) {
        if (!d) return;
        switch (String(d.a || "")) {
            case "hello": sendCfg(p); break;
            case "on": if (created(p)) flyRequest(p, true); break;
            case "off": flyRequest(p, false); break;
            case "mode": setMode(p, d.v); break;
            case "impulse": impulse(p); break;
            case "dash": dash(p, d.x, d.z, !!d.dbl); break;
            case "state": {
                if (!flying(p)) return;
                var fast = !!d.fast, sprint = !!d.sprint, s = FLYSTATE[p.uuid] || (FLYSTATE[p.uuid] = {});
                if (s.fast !== fast) { s.fast = fast; p.setShared("flyFast", fast ? 1 : null); }
                if (s.sprint !== sprint) { s.sprint = sprint; setVarIf(p, "fly_fast", sprint ? 1 : 0); }
                break;
            }
        }
    });

    return {
        CFG: CFG,
        // radial menu (62_dmz_radial.js)
        toggle: toggle, setMode: setMode, setSpeedLimit: setSpeedLimit, toggleLock: toggleLock,
        // keys (45_keys.js)
        keyPress: keyPress, dashKey: dashKey,
        isFlying: flying, mode: mode,
        /** true while flying fast in search mode (DMZ isFlyingFast; the fly_fast animation). */
        fast: function (p) { var s = FLYSTATE[p.uuid]; return flying(p) && !!(s && s.fast); },
        speedLimit: function (p) { var v = num(p.getVar("dmz_flight_speed_limit", 0), 0); return v > 0 ? v : 100; },
        /** stop flying (techniques, cutscenes). */
        land: function (p) { if (flying(p)) p.removeEffect("flight"); },
        forceCombat: forceCombat,
        // DMZ Cooldowns shared with instant transmission (64_dmz_senses.js) and the surge
        hasCooldown: hasCd, setCooldown: setCd, clearCooldown: clearCd, cooldownLeft: cdLeft,
        skillActive: skillActive, setSkillActive: setActive, toggleSkill: skillToggle,
        bar: bar, activationCost: activationCost, dashDirection: dashDirection, trackedSpeed: function (p) { var t = TRACK[p.uuid]; return t ? t.speed : 0; },
        // for tests
        _dash: dash, _drainCost: drainCost, _flyRequest: flyRequest, _impulse: impulse, _dodgeChance: dodgeChance
    };
})();
