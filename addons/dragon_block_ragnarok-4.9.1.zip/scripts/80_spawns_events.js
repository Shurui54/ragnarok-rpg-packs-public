// =====================================================================================
//  80_spawns_events.js - where enemies appear, and random world events
// =====================================================================================
//  Spawns are checked every `interval` ticks per player and appear minDistance-maxDistance
//  blocks away. Pick the body with mob: (RPG.mobs), entity: (vanilla), boss: or npc:.
//    dimensions: ["minecraft:overworld", "ragnarok_rpg:namek"]
//    biomes: ["minecraft:plains", "#minecraft:is_forest"]   ids or #tags
//    time: "day" | "night" | "any"     light: "dark" | "bright" | "any"
//    group: [min, max]   maxNearby   minLevel / maxLevel (player level)
//    levelScaling: 0.05  -> +5% health & damage per player level
//    condition(player) / onSpawn(entity, player)
// =====================================================================================

var OVERWORLD = ["minecraft:overworld"];

// ---- DragonMine Z natural spawns (forge/biome_modifier/*.json, MainEntities spawn rules) ----------
// DMZ has no level gates. Saga enemies spawn only in the dark (block light <= 7) and pass 35% of the time;
// wild enemies (bandits, Red Ribbon, robots, sabertooths) need open sky. "rocky" is DMZ's own biome:
// here badlands and windswept/stony hills stand in for it.
var ROCKY = ["#minecraft:is_badlands", "minecraft:windswept_gravelly_hills", "minecraft:windswept_hills", "minecraft:stony_peaks", "minecraft:stony_shore"];
var VILLAGE_LAND = ["minecraft:plains", "minecraft:sunflower_plains", "#minecraft:is_savanna", "minecraft:snowy_plains"];

// saibamans.json: saga_saibaman1..6 weights 80/70/60/45/35/25, groups 2-4 / 2-4 / 1-3 / 1-3 / 1-2 / 1-2
[["saibaman", 80, [2, 4]], ["saibaman_2", 70, [2, 4]], ["saibaman_3", 60, [1, 3]], ["saibaman_4", 45, [1, 3]], ["saibaman_5", 35, [1, 2]], ["saibaman_6", 25, [1, 2]]]
    .forEach((s) => {
        RPG.spawns.define("dmz_" + s[0], {
            mob: s[0], dimensions: OVERWORLD, biomes: ROCKY, light: "dark", interval: 400, chance: 0.35 * s[1] / 100,
            group: s[2], maxNearby: 8,
            onSpawn(entity) { RPG.world.particle(entity.dimension, "minecraft:composter", entity.x, entity.y, entity.z, 10, 0.3, 0.1); }
        });
    });
// biomans.json: #forge:is_snowy, weight 60, 2-4
RPG.spawns.define("dmz_biomans", {
    mob: "bioman", dimensions: OVERWORLD, biomes: ["#forge:is_snowy", "minecraft:snowy_plains", "minecraft:snowy_taiga", "minecraft:ice_spikes", "minecraft:snowy_slopes"],
    light: "dark", interval: 400, chance: 0.35 * 0.6, group: [2, 4], maxNearby: 6
});
// robots.json (villages: savanna/plains/snowy): red_ribbon_soldier 30 (1-3), robot3 10, robot2 10, robot1 5
[["red_ribbon_soldier", 30, [1, 3]], ["rr_robot_3", 10, [1, 1]], ["rr_robot_2", 10, [1, 1]], ["rr_robot_1", 5, [1, 1]]].forEach((s) => {
    RPG.spawns.define("dmz_" + s[0], { mob: s[0], dimensions: OVERWORLD, biomes: VILLAGE_LAND, light: "dark", interval: 400, chance: s[1] / 100, group: s[2], maxNearby: 6 });
});
// sabertooth.json: sabertooth 18 (1-2), bandit 12 (1-2) in savanna, plains, forest, jungle
var SABER_LAND = ["#minecraft:is_savanna", "minecraft:plains", "#minecraft:is_forest", "#minecraft:is_jungle", "minecraft:dark_forest"];
RPG.spawns.define("dmz_sabertooth", { mob: "sabertooth", dimensions: OVERWORLD, biomes: SABER_LAND, interval: 400, chance: 0.18, group: [1, 2], maxNearby: 4 });
RPG.spawns.define("dmz_bandit", { mob: "bandit", dimensions: OVERWORLD, biomes: SABER_LAND, light: "dark", interval: 400, chance: 0.12, group: [1, 2], maxNearby: 4 });

// ---- Animals (dinosaurs.json, giant_turtle.json, giant_fish.json) ------------------------
var DINO_LAND = ["#minecraft:is_savanna", "#minecraft:is_badlands", "#minecraft:is_mountain", "#minecraft:is_hill"].concat(ROCKY);
RPG.spawns.define("dmz_dino1", { mob: "dinosaur", biomes: DINO_LAND, light: "dark", interval: 400, chance: 0.35 * 0.22, group: [1, 2], maxNearby: 4 });
RPG.spawns.define("dmz_dino2", { mob: "triceratops", biomes: DINO_LAND, light: "dark", interval: 400, chance: 0.35 * 0.18, group: [1, 2], maxNearby: 4 });
RPG.spawns.define("dmz_dino3", { mob: "tyrannosaurus", biomes: DINO_LAND, light: "dark", interval: 400, chance: 0.35 * 0.14, group: [1, 2], maxNearby: 2 });
RPG.spawns.define("dmz_dinokid", { mob: "baby_dino", biomes: DINO_LAND, light: "dark", interval: 400, chance: 0.35 * 0.10, group: [1, 3], maxNearby: 4 });
RPG.spawns.define("dmz_giant_turtle", { mob: "giant_turtle", biomes: ["#minecraft:is_beach"], interval: 600, chance: 0.08, group: [1, 2], maxNearby: 3 });
RPG.spawns.define("dmz_giant_fish", { mob: "giant_fish", biomes: ["#minecraft:is_ocean", "#minecraft:is_beach", "#minecraft:is_river"], interval: 600, chance: 0.10, group: [1, 2], maxNearby: 3 });

// ---- Namek and the Other World (85_world.js) ----------------------------------------------
// namek_soldiers.json: saga_friezasoldier01/02/03 weight 2 (1) each; namek_fauna.json: frogs 2 (1-3) + Ginyu frog 5 (1)
[["frieza_soldier", "dmz_namek_soldier1"], ["frieza_soldier_heavy", "dmz_namek_soldier2"], ["frieza_soldier_elite", "dmz_namek_soldier3"]].forEach((s) => {
    RPG.spawns.define(s[1], { mob: s[0], dimensions: ["ragnarok_rpg:namek"], light: "dark", interval: 400, chance: 0.35 * 0.1, group: [1, 1], maxNearby: 3 });
});
RPG.spawns.define("dmz_namek_frogs", { mob: "namek_frog", dimensions: ["ragnarok_rpg:namek"], interval: 400, chance: 0.1, group: [1, 3], maxNearby: 5 });
RPG.spawns.define("dmz_namek_frog_ginyu", { mob: "namek_frog_2", dimensions: ["ragnarok_rpg:namek"], interval: 400, chance: 0.1, group: [1, 1], maxNearby: 2 });
RPG.spawns.define("namek_warriors", {
    mob: "namek_warrior", dimensions: ["ragnarok_rpg:namek"], interval: 600, chance: 0.2, group: [1, 2], maxNearby: 3
});
// hell_ogres.json: red 60 (1-2), blue 40 (1-2), only on the hell floor (y < 96), fewer than 4 ogres within 48
RPG.spawns.define("dmz_ogre_red", { mob: "ogre_red", dimensions: ["ragnarok_rpg:otherworld"], interval: 400, chance: 0.6, group: [1, 2], maxNearby: 3, countRange: 48,
    condition(p) { return p.y < 96; } });
RPG.spawns.define("dmz_ogre_blue", { mob: "ogre", dimensions: ["ragnarok_rpg:otherworld"], interval: 400, chance: 0.4, group: [1, 2], maxNearby: 3, countRange: 48,
    condition(p) { return p.y < 96; } });

// =====================================================================================
//  Random events: the server rolls every `interval` ticks and may start one.
//  Test one now:  /rpg event start saibamen_invasion
// =====================================================================================
RPG.randomEvents.configure({
    enabled: true,
    interval: 12000,               // roll every 10 minutes...
    chance: 0.35,                  // ...35% chance that something happens
    maxActive: 1
});

// Spawns `count` mobs in a ring around a player.
function spawnAround(player, mobId, count) {
    for (let i = 0; i < count; i++) {
        let angle = Math.random() * Math.PI * 2;
        let dist = RPG.random(6, 12);
        RPG.world.spawnMob(player.dimension, mobId, player.x + Math.cos(angle) * dist, player.y, player.z + Math.sin(angle) * dist);
    }
}

RPG.randomEvents.define("saibamen_invasion", {
    name: "Saibamen Invasion",
    weight: 3,                     // picked 3x as often as a weight-1 event
    duration: 2400,                // 2 minutes
    cooldown: 24000,
    announce: "&a&l[Event] &2Saibamen are sprouting everywhere! &7(2 minutes)",
    endMessage: "&7The Saibamen have withered away.",
    // Runs when the event starts, with every online player.
    onStart(players) { players.forEach((p) => spawnAround(p, "saibaman_" + RPG.randomInt(2, 6), 3)); },
    // Runs once a second while active; tick counts up.
    onTick(players, tick) {
        if (tick % 600 === 0) players.forEach((p) => spawnAround(p, "saibaman", 2));  // a new wave every 30s
    }
});

RPG.randomEvents.define("frieza_force_raid", {
    name: "Frieza Force Raid",
    weight: 2, duration: 2400, cooldown: 36000,
    announce: "&d&l[Event] &5Frieza Force pods are landing! &7(2 minutes)",
    endMessage: "&7The surviving soldiers flee to their ships.",
    onStart(players) {
        players.forEach((p) => {
            if (p.getLevel() < 15) return;
            RPG.world.spawnNpc(p.dimension, "frieza_pod", p.x + 10, p.y, p.z);
            spawnAround(p, "frieza_soldier", 3);
            spawnAround(p, "frieza_soldier_heavy", 1);
            sfx(p, "vehicle.frieza_capsule.land", 1.5, 1);
        });
    }
});

RPG.randomEvents.define("red_ribbon_raid", {
    name: "Red Ribbon Raid",
    weight: 2, duration: 1800, cooldown: 24000,
    announce: "&c&l[Event] &4The Red Ribbon Army is attacking! &7(90 seconds)",
    endMessage: "&7The Red Ribbon Army retreats.",
    onStart(players) { players.forEach((p) => { spawnAround(p, "red_ribbon_soldier", 3); if (p.getLevel() >= 15) spawnAround(p, "rr_robot_" + RPG.randomInt(1, 3), 1); }); }
});

RPG.randomEvents.define("radar_ping", {
    name: "Dragon Radar Ping",
    weight: 2, duration: 200,
    announce: "&6&l[Event] &eEvery radar on Earth just pinged...",
    endMessage: "",
    onStart(players) {
        players.forEach((p) => {
            sfx(p, "dragonradar", 1, 1);
            if (RPG.chance(0.2)) {
                let star = RPG.randomInt(1, 7);
                p.giveItem("dragon_ball_" + star, 1);
                p.title("&6Lucky!", "&eYou found the " + star + "-Star Dragon Ball");
                sfx(p, "dragonballssound", 1, 1);
            } else {
                p.tell("&7The signal was too weak. Maybe next time.");
            }
        });
    }
});

RPG.randomEvents.define("namek_radar_ping", {
    name: "Namekian Dragon Ball Signal",
    weight: 1, duration: 200,
    announce: "&a&l[Event] &2A Namekian Dragon Ball signal flickers on Namek...",
    endMessage: "",
    onStart(players) {
        players.forEach((p) => {
            if (p.dimension === "ragnarok_rpg:namek" && RPG.chance(0.35)) {
                p.giveItem("namek_dragon_ball_" + RPG.randomInt(1, 7), 1);
                p.title("&aFound one!", "&2A Namekian Dragon Ball");
            }
        });
    }
});

// No callbacks at all: the TP doubling is a "tpGain" hook (90_hooks.js) that checks isActive.
RPG.randomEvents.define("double_tp", {
    name: "Double TP Hour",
    weight: 1,
    duration: 72000,               // one real hour
    cooldown: 72000,
    announce: "&b&l[Event] &3Double TP for the next hour!",
    endMessage: "&7Double TP is over."
});

// World bosses are not a random event in DragonMine Z: they live in lairs (77_dmz_world_bosses.js).
