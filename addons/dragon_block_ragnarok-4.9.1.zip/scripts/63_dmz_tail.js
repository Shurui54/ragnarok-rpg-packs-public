// =====================================================================================
//  63_dmz_tail.js - the Saiyan tail: loose or wrapped round the waist (DMZ's tail toggle in
//  the X radial menu), and one place that keeps the tail's state in step
// =====================================================================================
//  look "tail"     "0" = no tail (Dende removes it, grows it back with "1")
//  var dmz_tail    copy of that for 31_dmz_transform.js (Oozaru needs a tail)
//  var dmz_tail_visible 1 loose / 0 wrapped (the radial menu reads it)
//  look "tailWrap" "1" while wrapped: the avatar swaps the loose fur tail for DMZ's tailenrolled part
//  shared "tailHide" tells the client animator to hide the model's own tail bones
// =====================================================================================
var DMZ_RACIAL_EXT = (function () {
    var prev = typeof DMZ_RACIAL_EXT !== "undefined" && DMZ_RACIAL_EXT ? DMZ_RACIAL_EXT : {};
    function isSaiyan(p) { return p.race === "saiyan"; }
    function hasTail(p) { return isSaiyan(p) && String(p.getColor("tail") || "1") !== "0"; }

    function sync(p) {
        let has = hasTail(p), wrapped = has && Number(p.getVar("dmz_tail_visible", 1)) === 0;
        if (Number(p.getVar("dmz_tail", 1)) !== (has ? 1 : 0)) p.setVar("dmz_tail", has ? 1 : 0);
        let wrap = wrapped ? "1" : "0";
        if (String(p.getColor("tailWrap") || "0") !== wrap) p.setColor("tailWrap", wrap);
        let hide = isSaiyan(p) && (!has || wrapped) ? 1 : null;
        if (p.getShared("tailHide") !== hide) p.setShared("tailHide", hide);
    }

    function toggleTail(p) {
        if (!hasTail(p)) { p.actionbar("&7You don't have a tail."); return; }
        let loose = Number(p.getVar("dmz_tail_visible", 1)) !== 0;
        p.setVar("dmz_tail_visible", loose ? 0 : 1);
        sync(p);
        p.playSound("dmzpack:" + (loose ? "switch_off" : "switch_on"), 0.8, 1);
    }

    RPG.every(20, () => RPG.server.players().forEach(sync));
    RPG.on("playerJoin", (p) => RPG.schedule(5, () => sync(p)));

    let out = {};
    for (let k in prev) out[k] = prev[k];
    out.toggleTail = toggleTail;
    out.syncTail = sync;
    return out;
})();
