// =====================================================================================
//  66_dmz_sites.js - DragonMine Z's procedural raid sites and the Capsule Corp village house
// =====================================================================================
//  Ports (GPL-3.0) of server/world/structure/BossStructures.java:
//    SaiyanCraterStructure   Overworld, random_spread 40/20 (salt 51738264): a scorched crater with a
//                            Saiyan space pod and a scout in it
//    NamekRuinsStructure     Namek, random_spread 40/20 (salt 63918274): a scorched plaza with craters and
//                            3-4 bombed Namekian houses (DMZ's village residences, data/dmz_structures/namek_ruins_*)
//    GomahCampStructure      Demon Realm, random_spread 40/20 (salt 82640175): a palisade camp with tents,
//                            supplies, a campfire and a Demon soldier, on whichever of the three worlds you're on
//  and helper/VillagePoolInjector: DMZ adds its Capsule Corp house (cc_villager) to vanilla plains villages
//  (weight 20). A data pack can't append to a vanilla pool, so a plains village a player walks into gets one
//  Capsule Corp house next to it.
//  Like 65_dmz_structures.js, a site is checked when a player comes within DMZ_BUILD_RANGE of it, only on loaded
//  chunks (one check per second), and built from a queue a few milliseconds per tick.
// =====================================================================================
var DMZ_SITES = {
    saiyan_crater: { dim: "minecraft:overworld", salt: 51738264, spacing: 40, separation: 20, triangular: false },
    namek_ruins:   { dim: "ragnarok_rpg:namek", salt: 63918274, spacing: 40, separation: 20, triangular: false },
    gomah_camp:    { dim: "ragnarok_rpg:demon_realm", salt: 82640175, spacing: 40, separation: 20, triangular: false }
};
var DMZ_SITE_QUEUE = [], DMZ_SITE_TICK_MS = 5, DMZ_SITE_TICK = 0;

function siteNoise(seed, x, y, z) { return dmzHash(seed, x, y, z) / 4294967296; }
function siteMob(ids) { for (let i = 0; i < ids.length; i++) if (RPG.mobs.exists(ids[i])) return ids[i]; return null; }
var SITE_LOOSE = /air$|water|lava|leaves|_log$|_wood$|:grass$|fern|flower|sapling|vine|bush|:snow$|kelp|seagrass|lily|mushroom|dandelion|poppy|tulip|orchid|allium|bluet|daisy|cornflower|lilac|rose|peony|sugar_cane|bamboo|berry|carpet|torch/;
function siteLoose(b) { return SITE_LOOSE.test(b); }
// the top solid, non-plant block (SaiyanCraterStructure.groundHeight), or null if unloaded
function siteGround(dim, x, z) {
    if (!RPG.world.isLoaded(dim, x, z)) return null;
    let y = RPG.world.surfaceY(dim, x, z) - 1, n = 0;
    if (y < -9000) return null;
    while (n++ < 40 && siteLoose(RPG.world.getBlock(dim, x, y, z))) y--;
    return y;
}
// dryHeight: the surface, or null when it is under water
function siteDry(dim, x, z) {
    if (!RPG.world.isLoaded(dim, x, z)) return null;
    let y = RPG.world.surfaceY(dim, x, z) - 1;
    if (y < -9000) return null;
    let b = RPG.world.getBlock(dim, x, y, z);
    return (b.indexOf("water") >= 0 || b.indexOf("lava") >= 0) ? null : y;
}
function siteAreaLoaded(dim, x, z, r) {
    for (let ax = x - r; ax <= x + r + 15; ax += 16) for (let az = z - r; az <= z + r + 15; az += 16) if (!RPG.world.isLoaded(dim, ax, az)) return false;
    return true;
}

// ---- Saiyan crater -------------------------------------------------------------------------
function siteSaiyanCrater(dim, cx, cz, seed) {
    let cy = siteDry(dim, cx, cz), R = 10, RIM = 4, DEPTH = 5, CLEAR = 14;
    if (cy === null || cy <= 63) return false;
    let lo = cy, hi = cy;
    for (let i = 0; i < 8; i++) {
        let a = Math.PI * 2 * i / 8, y = siteDry(dim, cx + Math.round(Math.cos(a) * (R + RIM)), cz + Math.round(Math.sin(a) * (R + RIM)));
        if (y === null) return false;
        lo = Math.min(lo, y); hi = Math.max(hi, y);
    }
    if (hi - lo > 6) return false;
    let phase = (seed & 1023) / 1023 * Math.PI * 2, outer = R + RIM + 1;
    let pick = (r, list) => { for (let i = 0; i < list.length; i++) if (r < list[i][0]) return list[i][1]; return list[list.length - 1][1]; };
    for (let dz = -outer; dz <= outer; dz++) (function (dz) {
        DMZ_SITE_QUEUE.push(() => {
            for (let dx = -outer; dx <= outer; dx++) {
                let x = cx + dx, z = cz + dz, ang = Math.atan2(dz, dx);
                let d = Math.sqrt(dx * dx + dz * dz) / (1 + 0.07 * Math.sin(ang * 5 + phase) + 0.04 * Math.sin(ang * 9 + phase * 2));
                if (d > R + RIM) continue;
                let g = siteGround(dim, x, z);
                if (g === null) continue;
                let r1 = siteNoise(seed, x, 1, z), r2 = siteNoise(seed, x, 2, z);
                let sub = pick(r1, [[0.5, "minecraft:stone"], [0.75, "minecraft:tuff"], [1, "minecraft:cobblestone"]]);
                if (d <= R) {                              // carveBowl
                    let t = d / R, floorY = cy - Math.round(DEPTH * (1 - t * t));
                    RPG.world.fill(dim, x, floorY + 1, z, x, Math.max(g, cy) + CLEAR, z, "minecraft:air", "replace");
                    if (g + 1 <= floorY - 1) RPG.world.fill(dim, x, g + 1, z, x, floorY - 1, z, sub, "replace");
                    RPG.world.fill(dim, x, floorY - 2, z, x, floorY - 1, z, sub, "replace");
                    RPG.world.setBlock(dim, x, floorY, z, t < 0.4
                        ? pick(r2, [[0.35, "minecraft:blackstone"], [0.55, "minecraft:basalt"], [0.75, "minecraft:cobbled_deepslate"], [1, "minecraft:tuff"]])
                        : pick(r2, [[0.3, "minecraft:gravel"], [0.55, "minecraft:tuff"], [0.75, "minecraft:stone"], [0.9, "minecraft:andesite"], [1, "minecraft:cobblestone"]]));
                } else {                                   // raiseRim
                    let t = (d - R) / RIM, rimTop = cy + Math.round(2 * (1 - t));
                    let rim = pick(r2, [[0.35, "minecraft:coarse_dirt"], [0.65, "minecraft:gravel"], [0.8, "minecraft:tuff"], [1, "minecraft:dirt"]]);
                    if (g + 1 <= rimTop - 1) RPG.world.fill(dim, x, g + 1, z, x, rimTop - 1, z, "minecraft:dirt", "replace");
                    if (rimTop > g) RPG.world.setBlock(dim, x, rimTop, z, rim);
                    else if (r1 < 0.6) RPG.world.setBlock(dim, x, g, z, rim);
                    let s = Math.max(rimTop, g);
                    RPG.world.fill(dim, x, s + 1, z, x, s + CLEAR, z, "minecraft:air", "replace");
                }
            }
        });
    })(dz);
    DMZ_SITE_QUEUE.push(() => {                         // placeCrew: a Saiyan pod in the middle, a scout beside it
        let fy = siteGround(dim, cx, cz);
        if (fy === null) return;
        RPG.world.spawnVehicle(dim, "spacepod", cx + 0.5, fy + 1, cz + 0.5, (seed % 360));
        let mob = siteMob(["saga_saiyan_soldier", "saiyan_soldier", "saibaman"]), sy = siteGround(dim, cx + 3, cz + 1);
        if (mob && sy !== null) RPG.world.spawnMob(dim, mob, cx + 3.5, sy + 1, cz + 1.5);
    });
    return true;
}

// ---- Namek ruins ---------------------------------------------------------------------------
function siteScorched(r) { return r < 0.4 ? "minecraft:blackstone" : r < 0.65 ? "minecraft:basalt" : r < 0.85 ? "minecraft:tuff" : "minecraft:coarse_dirt"; }
function siteBreakable(b) { return b !== "minecraft:air" && !/chest|barrel|furnace|smoker|bed|water|lava|bedrock|spawner/.test(b); }
function siteNamekRuins(dim, key, cx, cz, seed, rnd) {
    let cy = siteDry(dim, cx, cz);
    if (cy === null || cy <= 64) return false;
    let sacred = RPG.world.getBlock(dim, cx, cy, cz) === blockRef("namek_sacred_grass_block");
    let count = 3 + Math.floor(rnd() * 2), base = rnd() * Math.PI * 2, houses = [];
    for (let i = 0; i < count; i++) {
        let name = "namek_ruins_" + (sacred ? "sacred_" : "ajissa_") + (rnd() < 0.5 ? "big" : "small") + "_r" + Math.floor(rnd() * 4), m = dmzManifest(name);
        if (!m) continue;
        let radius = Math.max(m.size[0], m.size[2]) * 0.8 + 6, a = base + Math.PI * 2 * i / count + (rnd() - 0.5) * 0.3;
        let hx = cx + Math.round(Math.cos(a) * radius), hz = cz + Math.round(Math.sin(a) * radius), g = siteDry(dim, hx, hz);
        if (g === null) continue;
        houses.push({ key: key + "#" + i, name: name, x: hx - Math.floor(m.size[0] / 2), y: g + 1, z: hz - Math.floor(m.size[2] / 2), sx: m.size[0], sy: m.size[1], sz: m.size[2] });
    }
    if (houses.length < 2) return false;
    // PlazaPiece: scorched ground, three small craters, a Frieza soldier on watch
    DMZ_SITE_QUEUE.push(() => {
        for (let dx = -7; dx <= 7; dx++) for (let dz = -7; dz <= 7; dz++) {
            if (dx * dx + dz * dz > 49 || siteNoise(seed, cx + dx, 0, cz + dz) > 0.45) continue;
            let y = siteGround(dim, cx + dx, cz + dz);
            if (y !== null && siteBreakable(RPG.world.getBlock(dim, cx + dx, y, cz + dz))) RPG.world.setBlock(dim, cx + dx, y, cz + dz, siteScorched(siteNoise(seed, cx + dx, 1, cz + dz)));
        }
        for (let i = 0; i < 3; i++) {
            let x = cx + Math.round((siteNoise(seed, i, 2, 0) - 0.5) * 11.2), z = cz + Math.round((siteNoise(seed, i, 3, 0) - 0.5) * 11.2), r = 1.5 + siteNoise(seed, i, 4, 0) * 0.8;
            let y = siteGround(dim, x, z), reach = Math.ceil(r) + 1;
            if (y === null) continue;
            for (let dx = -reach; dx <= reach; dx++) for (let dz = -reach; dz <= reach; dz++) for (let dy = -reach; dy <= 1; dy++) {
                let dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (dist > r + 1) continue;
                let b = RPG.world.getBlock(dim, x + dx, y + dy, z + dz);
                if (!siteBreakable(b)) continue;
                if (dist <= r) RPG.world.setBlock(dim, x + dx, y + dy, z + dz, "minecraft:air");
                else if (dy <= 0) RPG.world.setBlock(dim, x + dx, y + dy, z + dz, siteScorched(siteNoise(seed, x + dx, y + dy, z + dz)));
            }
        }
        let mob = siteMob(["frieza_soldier"]), sy = siteGround(dim, cx, cz);
        if (mob && sy !== null) RPG.world.spawnMob(dim, mob, cx + 0.5, sy + 1, cz + 0.5);
    });
    houses.forEach((h) => dmzQueueBuild(h.key, h.name, dim, h.x, h.y, h.z));
    let ruins = RPG.data.get("dmz_ruins", {}) || {};
    ruins[key] = { seed: seed, houses: houses, done: false, dim: dim };
    RPG.data.set("dmz_ruins", ruins);
    return true;
}
// HousePiece.ruin, once a house stands: collapse (more near the roof), two blast holes
function siteRuinHouse(dim, h, seed) {
    let blasts = [];
    for (let i = 0; i < 2; i++) blasts.push([h.x + Math.floor(siteNoise(seed, i, 11, 0) * h.sx), h.y + Math.floor((0.4 + siteNoise(seed, i, 12, 0) * 0.6) * h.sy),
        h.z + Math.floor(siteNoise(seed, i, 13, 0) * h.sz), 3 + siteNoise(seed, i, 14, 0) * 3]);
    for (let y = h.y + 1; y < h.y + h.sy; y++) (function (y) {
        DMZ_SITE_QUEUE.push(() => {
            let hf = (y - h.y) / Math.max(1, h.sy - 1);
            for (let x = h.x; x < h.x + h.sx; x++) for (let z = h.z; z < h.z + h.sz; z++) {
                let hit = siteNoise(seed, x, y, z) < 0.08 + 0.6 * hf * hf;
                for (let k = 0; !hit && k < blasts.length; k++) {
                    let b = blasts[k], dx = x - b[0], dy = y - b[1], dz = z - b[2];
                    hit = dx * dx + dy * dy + dz * dz <= b[3] * b[3];
                }
                if (hit && siteBreakable(RPG.world.getBlock(dim, x, y, z))) RPG.world.setBlock(dim, x, y, z, "minecraft:air");
            }
        });
    })(y);
}

// ---- Gomah camp ------------------------------------------------------------------------------
var GOMAH_BANDS = [[251, 48], [481, 319], [766, 584]];      // the three worlds' floors (GomahCampStructure.FLOOR_BANDS)
function siteSolid(dim, x, y, z) { let b = RPG.world.getBlock(dim, x, y, z); return b !== "minecraft:air" && b !== "minecraft:light" && b !== "minecraft:cave_air"; }
function siteBandGround(dim, x, z, band) {
    let y = band[0];
    while (y > band[1] && siteSolid(dim, x, y, z)) y--;
    while (y > band[1] && !siteSolid(dim, x, y, z)) y--;
    if (y <= band[1] || RPG.world.getBlock(dim, x, y, z).indexOf("water") >= 0) return null;
    for (let h = 1; h <= 8; h++) if (siteSolid(dim, x, y + h, z)) return null;
    return y;
}
function siteNear(dim, x, z, y0) {                             // columnGround: a solid block within 6 of the camp floor
    for (let y = y0 + 6; y > y0 - 6; y--) if (siteSolid(dim, x, y, z)) return y;
    return y0;
}
function siteGomahCamp(dim, cx, cz, seed, py) {
    let band = py < 290 ? GOMAH_BANDS[0] : py < 540 ? GOMAH_BANDS[1] : GOMAH_BANDS[2];
    let gy = siteBandGround(dim, cx, cz, band);
    if (gy === null) return false;
    for (let i = 0; i < 8; i++) {
        let a = Math.PI * 2 * i / 8, x = cx + Math.round(Math.cos(a) * 13), z = cz + Math.round(Math.sin(a) * 13), s = siteNear(dim, x, z, gy);
        if (Math.abs(s - gy) > 3 || !siteSolid(dim, x, s, z)) return false;
    }
    let R = 14, gate = siteNoise(seed, 0, 0, 0) * Math.PI, wrap = (a) => { while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; return a; };
    let inGate = (a) => Math.abs(wrap(a - gate)) <= 0.21 || Math.abs(wrap(a - gate - Math.PI)) <= 0.21;
    for (let dz = -R - 1; dz <= R + 1; dz++) (function (dz) {
        DMZ_SITE_QUEUE.push(() => {
            for (let dx = -R - 1; dx <= R + 1; dx++) {
                let x = cx + dx, z = cz + dz, d = Math.sqrt(dx * dx + dz * dz);
                let roll = siteNoise(seed, x, 1, z);
                if (d <= R && roll <= 0.45) {                  // dressGround
                    let y = siteNear(dim, x, z, gy);
                    RPG.world.setBlock(dim, x, y, z, roll < 0.3 ? "minecraft:coarse_dirt" : "minecraft:gravel");
                }
                if (Math.abs(d - R) <= 0.5 && !inGate(Math.atan2(dz, dx))) {   // palisade
                    let r2 = siteNoise(seed, x, 2, z), h = r2 < 0.12 ? 1 + Math.floor(r2 * 100) % 2 : (r2 < 0.6 ? 3 : 4), b = siteNear(dim, x, z, gy);
                    RPG.world.fill(dim, x, b + 1, z, x, b + h, z, "minecraft:dark_oak_log[axis=y]", "replace");
                }
            }
        });
    })(dz);
    DMZ_SITE_QUEUE.push(() => {
        let tents = 3 + (siteNoise(seed, 1, 0, 0) < 0.5 ? 0 : 1);
        for (let i = 0; i < tents; i++) {                       // tents: a purple wool ridge roof, barrel, banner
            let a = gate + Math.PI / 2 + Math.PI * 2 * i / tents, tx = cx + Math.round(Math.cos(a) * 8), tz = cz + Math.round(Math.sin(a) * 8);
            let fx = cx - tx, fz = cz - tz, front = Math.abs(fx) >= Math.abs(fz) ? [(fx > 0 ? 1 : -1), 0] : [0, (fz > 0 ? 1 : -1)], right = [-front[1], front[0]];
            let b = siteNear(dim, tx, tz, gy);
            for (let u = -2; u <= 2; u++) {
                let h = 3 - Math.abs(u);
                for (let v = -2; v <= 2; v++) {
                    let x = tx + right[0] * u + front[0] * v, z = tz + right[1] * u + front[1] * v;
                    RPG.world.setBlock(dim, x, b + h, z, u === 0 ? "minecraft:black_wool" : "minecraft:purple_wool");
                    for (let y = 1; y < h; y++) RPG.world.setBlock(dim, x, b + y, z, v === -2 ? "minecraft:purple_wool" : "minecraft:air");
                }
            }
            RPG.world.setBlock(dim, tx - front[0], b + 1, tz - front[1], "minecraft:barrel[facing=up]");
            let flx = tx + front[0] * 3 + right[0] * 3, flz = tz + front[1] * 3 + right[1] * 3, fb = siteNear(dim, flx, flz, gy);
            let dir = front[1] === -1 ? 0 : front[0] === 1 ? 1 : front[1] === 1 ? 2 : 3;      // north, east, south, west
            RPG.world.setBlock(dim, flx, fb + 1, flz, "minecraft:dark_oak_fence");
            RPG.world.setBlock(dim, flx, fb + 2, flz, "minecraft:purple_banner[rotation=" + ((dir * 4 + 8) % 16) + "]");
        }
        for (let c = 0; c < 4; c++) {                           // supply clusters by the palisade
            let a = gate + Math.PI * 2 * (c + 0.5) / 4, x0 = cx + Math.round(Math.cos(a) * 11), z0 = cz + Math.round(Math.sin(a) * 11);
            let n = 2 + Math.floor(siteNoise(seed, c, 3, 0) * 3);
            for (let i = 0; i < n; i++) {
                let x = x0 + Math.round((siteNoise(seed, c, 4, i) - 0.5) * 3), z = z0 + Math.round((siteNoise(seed, c, 5, i) - 0.5) * 3), b = siteNear(dim, x, z, gy);
                RPG.world.setBlock(dim, x, b + 1, z, siteNoise(seed, c, 6, i) < 0.6 ? "minecraft:barrel[facing=up]" : "minecraft:dark_oak_planks");
                if (siteNoise(seed, c, 7, i) < 0.3) RPG.world.setBlock(dim, x, b + 2, z, "minecraft:dark_oak_planks");
            }
        }
        let b = siteNear(dim, cx, cz, gy);                       // fireplace and log seats
        for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) if (dx || dz) RPG.world.setBlock(dim, cx + dx, b, cz + dz, "minecraft:blackstone");
        RPG.world.setBlock(dim, cx, b + 1, cz, "minecraft:campfire");
        for (let dx = -1; dx <= 1; dx++) {
            RPG.world.setBlock(dim, cx + dx, b + 1, cz - 3, "minecraft:dark_oak_log[axis=x]");
            RPG.world.setBlock(dim, cx + dx, b + 1, cz + 3, "minecraft:dark_oak_log[axis=x]");
        }
        let mob = siteMob(["saga_gomah_soldier_1", "gomah_soldier"]), sy = siteNear(dim, cx + 3, cz + 1, gy);
        if (mob) RPG.world.spawnMob(dim, mob, cx + 3.5, sy + 1, cz + 1.5);
    });
    return true;
}

// ---- checking cells near players --------------------------------------------------------------
// checked cells, kept in memory (this file is the only writer) instead of re-read from RPG.data every second
var DMZ_SITE_CELLS_MEM = null;
function siteCells() { if (!DMZ_SITE_CELLS_MEM) DMZ_SITE_CELLS_MEM = RPG.data.get("dmz_site_cells", {}) || {}; return DMZ_SITE_CELLS_MEM; }
function siteCheck(p) {
    for (let name in DMZ_SITES) {
        let set = DMZ_SITES[name];
        if (p.dimension !== set.dim || !dbrDimensionExistsSafe(set.dim)) continue;
        let size = set.spacing * 16, cellX = Math.floor(p.x / size), cellZ = Math.floor(p.z / size);
        let cells = siteCells();
        for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
            let key = name + "@" + (cellX + dx) + "," + (cellZ + dz);
            if (cells[key]) continue;
            let ch = dmzSpreadChunk(set, cellX + dx, cellZ + dz), x = ch[0] * 16 + 8, z = ch[1] * 16 + 8;
            if (!dmzNear(p, set.dim, x, z, DMZ_BUILD_RANGE)) continue;
            if (!siteAreaLoaded(set.dim, x, z, 40)) { RPG.world.requestChunks(set.dim, x, z, 3); continue; }
            let seed = dmzHash(dmzWorldSeed(), set.salt, cellX + dx, cellZ + dz), ok;
            if (name === "saiyan_crater") ok = siteSaiyanCrater(set.dim, x, z, seed);
            else if (name === "namek_ruins") ok = siteNamekRuins(set.dim, key, x, z, seed, dmzRng(seed));
            else ok = siteGomahCamp(set.dim, x, z, seed, p.y);
            cells[key] = ok ? "built" : "rejected";
            RPG.data.set("dmz_site_cells", cells);
            if (ok) RPG.log("[DMZ] " + name + " at " + x + ", " + z);
            return true;                                        // one site check per second
        }
    }
    return false;
}
function dbrDimensionExistsSafe(dim) {
    if (dim.indexOf("ragnarok_rpg:") !== 0) return true;
    let id = dim.substring(13);
    return typeof dbrDimensionExists === "function" ? dbrDimensionExists(id) : RPG.dimensions.exists(id);
}
function siteRuinBuilt() {
    let ruins = RPG.data.get("dmz_ruins", {}) || {}, built = dmzBuilt(), changed = false;
    for (let k in ruins) {
        let r = ruins[k];
        if (r.done || !r.houses.every((h) => built[h.key] && built[h.key].done)) continue;
        r.houses.forEach((h, i) => siteRuinHouse(r.dim || "ragnarok_rpg:namek", h, r.seed + i));
        r.done = true; changed = true;
    }
    if (changed) RPG.data.set("dmz_ruins", ruins);
}

// ---- Capsule Corp house next to plains villages (VillagePoolInjector, weight 20) ------------------
function siteCapsuleHouse(p) {
    let v = RPG.world.entitiesNear(p.dimension, p.x, p.y, p.z, 96, "minecraft:villager")[0];
    if (!v) return;
    let key = "cc_villager@" + Math.floor(v.x / 256) + "," + Math.floor(v.z / 256), cells = siteCells();
    if (cells[key]) return;
    let rnd = dmzRng(dmzHash(dmzWorldSeed(), 20, Math.floor(v.x / 256), Math.floor(v.z / 256))), found = null;
    for (let i = 0; i < 12 && !found; i++) {
        let a = rnd() * Math.PI * 2, d = 18 + rnd() * 22, x = Math.round(v.x + Math.cos(a) * d), z = Math.round(v.z + Math.sin(a) * d);
        if (!siteAreaLoaded(p.dimension, x, z, 8)) continue;
        let r = dmzProbe(p.dimension, x, z, 11, 11, 3, false);
        if (r.n >= 8 && r.wet === 0 && r.spread <= 2 && dmzFrac(r, "grass") >= 0.5) found = { x: x, z: z, y: r.median };
    }
    cells[key] = found ? "built" : "rejected";
    RPG.data.set("dmz_site_cells", cells);
    if (!found) return;
    let m = dmzManifest("cc_villager");
    if (m) dmzQueueBuild(key, "cc_villager", p.dimension, found.x - 5, found.y - (m.ground || 0), found.z - 5);
}

RPG.every(1, () => {
    let t0 = Date.now();
    while (DMZ_SITE_QUEUE.length && Date.now() - t0 < DMZ_SITE_TICK_MS) {
        try { DMZ_SITE_QUEUE.shift()(); } catch (e) { RPG.log("[DMZ] site build: " + e); }
    }
    if (++DMZ_SITE_TICK % 20 !== 10 || typeof dmzSpreadChunk !== "function") return;
    let checked = false;
    RPG.server.players().forEach((p) => {
        if (!checked) checked = siteCheck(p);
        if (p.dimension === "minecraft:overworld" && DMZ_SITE_TICK % 600 === 10) siteCapsuleHouse(p);
    });
    if (DMZ_SITE_TICK % 100 === 10) siteRuinBuilt();
});

// /rpgc dmzsite list [filter]   - checked raid sites / villages (built or rejected)
// /rpgc dmzsite <saiyan_crater|namek_ruins|gomah_camp|demon_village>   - build one centred where you stand (ops)
RPG.commands.register("dmzsite", {
    description: "DMZ raid sites: /rpgc dmzsite list | <saiyan_crater|namek_ruins|gomah_camp|demon_village>",
    permission: 2,
    run(player, args) {
        let tell = (s) => player ? player.tell(s) : RPG.log(s), what = args[0] || "list";
        if (what === "list") {
            let cells = siteCells(), vill = typeof dvCells === "function" ? dvCells() : RPG.data.get("dbr_village_cells", {}) || {}, want = args[1] || "";
            [cells, vill].forEach((c) => { for (let k in c) if (c[k] === "built" && (!want || k.indexOf(want) >= 0)) tell("&e" + k + " &7(" + c[k] + ")"); });
            return;
        }
        if (!player) return;
        let x = Math.floor(player.x), z = Math.floor(player.z), seed = dmzHash(RPG.server.getTick(), x, z, 77), ok = false, key = what + "@manual" + RPG.server.getTick();
        if (what === "saiyan_crater") ok = siteSaiyanCrater(player.dimension, x, z, seed);
        else if (what === "namek_ruins") ok = siteNamekRuins(player.dimension, key, x, z, seed, dmzRng(seed));
        else if (what === "gomah_camp") ok = siteGomahCamp(player.dimension, x, z, seed, player.y);
        else if (what === "demon_village" && typeof dvPlan === "function") { let plan = dvPlan(key, x, z, dmzRng(seed)); if (plan) { dvQueue(plan); ok = true; } }
        tell(ok ? "&aBuilding " + what + "..." : "&cThe ground here doesn't fit a " + what + " (DMZ's site checks).");
    },
    suggest() { return ["list", "saiyan_crater", "namek_ruins", "gomah_camp", "demon_village"]; }
});
