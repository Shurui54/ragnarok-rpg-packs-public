// =====================================================================================
//  55_blocks.js - this addon's own blocks (not from DragonMine Z)
// =====================================================================================
//  Every DMZ block (Namek, Demon Realm, woods, ores, crops, machines...) is defined in
//  13_dmz_blocks.js, which also provides the helpers block(name, def) and blockRef(name)
//  ("ragnarok_rpg:block_0150", for setBlock and dimensions).
//    model: "dmzpack:rpg/block/namek_stone"    any model under assets/<ns>/models/rpg/
//    hardness (-1 = unbreakable), light (0-15), shape, collision, drops, speed, jump,
//    onUse / onStep / onBreak / onPlace (player or entity, x, y, z) / onRandomTick(dim, x, y, z)
// =====================================================================================

function dmzBlock(model) { return DMZ + "rpg/block/" + model; }

// A block you can right-click: meditate for TP once a minute.
block("meditation_mat", {
    name: "Meditation Mat", model: dmzBlock("kikono_block"), hardness: 1,
    onUse(player, x, y, z) {
        let now = RPG.server.getTick();
        let last = player.getVar("meditate_tick", 0);   // per-player saved number
        if (now - last < 1200) {
            player.actionbar("&7Your mind needs rest. (" + Math.ceil((1200 - (now - last)) / 20) + "s)");
            return;
        }
        player.setVar("meditate_tick", now);
        player.addTp(20 + player.getLevel());
        act(player, "base.meditation", 60);
        player.progressQuest("meditate", 1);
        player.actionbar("&bYou meditate... &3+TP");
        RPG.world.particle(player.dimension, "minecraft:enchant", x + 0.5, y + 1.5, z + 0.5, 30, 0.5, 0.5);
    }
});

// Wild herbs: the grown DMZ crops. Break one to harvest it.
[["aura_lily", "aura_lily"], ["hermit_fern", "hermit_fern"], ["katchin_sprout", "katchin_sprout"], ["meteor_flower", "meteor_flower"],
 ["oozaru_root", "oozaru_root"], ["zenkai_lotus", "zenkai_lotus"], ["namek_moss", "namek_moss"], ["kaioshin_fruit", "kaioshin_fruit"]].forEach((h) => {
    block("wild_" + h[0], {
        name: "Wild " + h[0].replace("_", " "), model: dmzBlock(h[0] + "_crop_stage2"), shape: "cross", collision: false, hardness: 0,
        drops: h[0] === "kaioshin_fruit" ? [{ item: h[1], count: 1, chance: 0.2 }] : [{ item: h[1], count: 1 }, { item: h[1], count: 1, chance: 0.5 }]
    });
});
