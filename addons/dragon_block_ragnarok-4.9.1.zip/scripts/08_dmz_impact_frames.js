// =====================================================================================
//  08_dmz_impact_frames.js - DragonMine Z's impact frames (server side)
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): ImpactFramesHandler / TriggerImpactFrameS2C, triggered from
//  CombatEvent like DMZ (spec 03 section 3.9):
//    - a ki GIANT_BALL or EXPLOSION technique hits something      -> (0.7, 0.1, 2 ticks)
//    - one hit of >= 200 raw damage that is >= 50 % of the victim's max health -> (0.8, 0.05, 2 ticks)
//  (DMZ's third trigger, the momentum strike, has no DBR counterpart yet.)
//  The frame goes to everyone near the victim, like sendToTrackingEntityAndSelf. Each player's
//  client shows it only if their "Impact Frames" option is on (off by default, like DMZ):
//  client/scripts/57_dmz_impact_frames.js. Runs before 09_dmz_stats.js so it sees the raw hit.
// =====================================================================================
var DMZ_IMPACT = (function () {
    var RANGE = 64, MIN_GAP_TICKS = 4;
    var last = {};                       // dimension -> server tick of the last frame (one burst per AoE)

    /** DMZ's TriggerImpactFrameS2C(threshold, thresholdLerp, ticks, invert) to everyone near `at`. */
    function play(at, threshold, lerp, ticks) {
        if (!at || !at.dimension) return;
        var now = RPG.server.getTick();
        if (last[at.dimension] !== undefined && now - last[at.dimension] < MIN_GAP_TICKS) return;
        last[at.dimension] = now;
        var data = { t: threshold, l: lerp, k: ticks || 2, i: 1 };
        RPG.server.players().forEach(function (p) {
            if (p.dimension !== at.dimension) return;
            var dx = p.x - at.x, dy = p.y - at.y, dz = p.z - at.z;
            if (dx * dx + dy * dy + dz * dz <= RANGE * RANGE) RPG.net.send(p, "dmz_impact", data);
        });
    }

    // CombatEvent: raw >= 200 and >= 50 % of max HP -> impact frame (0.8, 0.05, 2)
    RPG.on("damageFinal", function (e) {
        var t = e.target;
        if (!t || e.isCancelled() || !(e.amount >= 200)) return;
        var max = Number(t.maxHealth);
        if (!(max > 0) || e.amount < max * 0.5) return;
        play(t, 0.8, 0.05, 2);
    });

    return {
        play: play,
        /** A ki GIANT / EXPLOSION technique hit (41_dmz_techniques.js). */
        kiHit: function (at) { play(at, 0.7, 0.1, 2); }
    };
})();
