// =====================================================================================
//  15_resources.js - Ki and Stamina, sized by DMZ's formulas
// =====================================================================================
//  Max ki = 20 + ENE x class scaling, max stamina = 20 + RES x class scaling (times form
//  multipliers). Regeneration follows DMZ too and runs in 09_dmz_stats.js, so the engine's
//  own regen is off here.
// =====================================================================================
RPG.resources.define("ki", {
    name: "Ki",
    color: "#3FA9FF",
    max: (player) => DMZ_F.maxKi(dmzView(player)),
    regen: 0,
    startFull: true,
    refillOnRespawn: true
});

RPG.resources.define("stamina", {
    name: "Stamina",
    color: "#F5A623",
    max: (player) => DMZ_F.maxStamina(dmzView(player)),
    regen: 0,
    startFull: true,
    refillOnRespawn: true
});
