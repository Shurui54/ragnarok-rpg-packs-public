// =====================================================================================
//  17_dmz_recipes.js - DragonMine Z's crafting and smelting recipes (GPL-3.0, ported from
//  DMZRecipeProvider.java and data/dragonminez/recipes/*.json)
// =====================================================================================
//  Pattern Station (6x6 dye grids) and Kikono Station (armour / Gete tools) recipes are menus on
//  those blocks (16_dmz_items.js). Ore smelting/blasting with vanilla results (Namek iron,
//  diamond...) is real JSON in datapack/data/dbr/recipes/ (those ores have fixed block ids).
//  Not expressible here: smoker / campfire / blast-furnace recipes with our own results, brewing
//  (Curative Flask, Heart Medicine), NBT-exact ingredients, and crafting remainders (DMZ keeps the
//  Armour Crafting Kit in the grid).
// =====================================================================================

// Script items/blocks are resolved to "ragnarok_rpg:item_0042" now, because RPG.recipes reads
// names through the previous load's registry (new names would come out empty on a first load).
function R(ref) {
    if (ref.indexOf(":") >= 0 || ref.charAt(0) === "#") return ref;
    let id = RPG.items.id(ref);
    if (!id) throw new Error("17_dmz_recipes.js: unknown item '" + ref + "'");
    return "ragnarok_rpg:" + id;
}
function shaped(id, pattern, keys, result, count) {
    let k = {};
    Object.keys(keys).forEach((c) => k[c] = R(keys[c]));
    RPG.recipes.addShaped("dmz_" + id, pattern, k, { id: R(result), count: count || 1 });
}
function shapeless(id, ingredients, result, count) {
    RPG.recipes.addShapeless("dmz_" + id, ingredients.map(R), { id: R(result), count: count || 1 });
}
function smelt(id, input, result, xp, ticks) { RPG.recipes.addSmelting("dmz_" + id, R(input), R(result), xp, ticks); }
var DMZ_RECIPE_COUNT = 0;
(function () {
    let n0 = 0;
    // ---- cooking (smelting only; DMZ also has smoking 100 t and campfire 600 t) ----
    [["frog_legs_raw", "frog_legs_cooked"], ["giant_fish_raw", "giant_fish_cooked"], ["giant_turtle_raw", "giant_turtle_cooked"],
     ["raw_dino_meat", "cooked_dino_meat"], ["raw_baby_dino_meat", "cooked_baby_dino_meat"], ["dino_tail_raw", "dino_tail_cooked"]]
        .forEach((f) => { smelt(f[1], f[0], f[1], 0.35, 200); n0++; });
    smelt("gete_scrap_from_smelting_gete_debris_ore", "gete_debris_ore", "gete_scrap", 3.5, 200);
    smelt("kikono_shard_from_smelting_namek_kikono_ore", "namek_kikono_ore", "kikono_shard", 2.5, 200);
    n0 += 2;

    // ---- machines, tech ----
    ["weight_turtle_shell", "workout_weights", "weight_piccolo_cape"].forEach((w) => {       // W = #dragonminez:weighted_items
        shaped("gravity_device_" + w, ["RWR", "ICI", "RAR"], { R: "minecraft:repeater", W: w, I: "minecraft:iron_block", C: "t1_radar_cpu", A: "minecraft:anvil" }, "gravity_device");
        n0++;
    });
    ["red", "purple", "yellow", "green", "orange", "blue"].forEach((c) => { shapeless("gete_" + c + "_capsule", [c + "_capsule", "gete_ingot"], "gete_" + c + "_capsule"); n0++; });
    shaped("pattern_gete", ["IGI", "GTG", "IGI"], { T: "pattern_gete", G: "gete_scrap", I: "minecraft:iron_ingot" }, "pattern_gete", 2);
    shaped("ki_battery", ["RLR", "LGL", "RLR"], { R: "minecraft:redstone", L: "minecraft:lapis_lazuli", G: "gete_ingot" }, "ki_battery");
    n0 += 2;

    // ---- farming ----
    shapeless("namek_moss", ["minecraft:wheat_seeds", "healing_liquid_bucket"], "namek_moss");
    [["oozaru_root", "raw_dino_meat"], ["katchin_sprout", "turtle_scale"], ["meteor_flower", "minecraft:gunpowder"], ["aura_lily", "minecraft:glowstone_dust"],
     ["hermit_fern", "senzu_bean"], ["kaioshin_fruit", "minecraft:golden_apple"], ["zenkai_lotus", "minecraft:amethyst_shard"]].forEach((p) => {
        shapeless(p[0], ["namek_moss", "namek_moss", "namek_moss", "namek_moss", p[1], p[1]], p[0]); n0++;
    });
    shapeless("senzu_bean_from_colors", ["senzu_bean_red", "senzu_bean_blue", "senzu_bean_yellow", "namek_moss"], "senzu_bean", 3);
    shaped("senzu_bean_bag", ["LSL", " L "], { L: "minecraft:leather", S: "#forge:seeds" }, "senzu_bean_bag");
    [["red", "green_capsule"], ["blue", "blue_capsule"], ["yellow", "yellow_capsule"]].forEach((c) => {
        shapeless("senzu_bean_seeds_" + c[0], ["senzu_bean_" + c[0]], "senzu_bean_seeds_" + c[0]);
        shapeless("senzu_bean_seeds_" + c[0] + "_from_capsule", ["namek_moss", c[1]], "senzu_bean_seeds_" + c[0]);
        n0 += 2;
    });
    shapeless("turtle_scale", ["minecraft:scute"], "turtle_scale");
    shapeless("scute_from_turtle_scale", ["turtle_scale"], "minecraft:scute");
    shaped("empty_capsule", ["G", "R", "I"], { G: "minecraft:glass_pane", R: "minecraft:redstone", I: "minecraft:iron_ingot" }, "empty_capsule");
    n0 += 6;
    // stat capsules: Curative Flask + ingredient + empty capsule + 2 plants. The flask is an NBT potion
    // (Regeneration V, brewed from water + namek moss) that recipes can't match: any potion is accepted.
    [["red_capsule", "raw_dino_meat", "oozaru_root"], ["yellow_capsule", "turtle_scale", "katchin_sprout"], ["purple_capsule", "minecraft:gunpowder", "meteor_flower"],
     ["orange_capsule", "minecraft:glowstone_dust", "aura_lily"], ["green_capsule", "senzu_bean_red", "hermit_fern"], ["blue_capsule", "minecraft:golden_apple", "kaioshin_fruit"],
     ["mastery_capsule", "minecraft:amethyst_shard", "zenkai_lotus"]].forEach((c) => {
        shapeless(c[0], ["minecraft:potion", c[1], "empty_capsule", c[2], c[2]], c[0]); n0++;
    });

    // ---- building blocks ----
    let set = (base, slab, stairs, wall, slabCount) => {
        shaped(slab, ["###"], { "#": base }, slab, slabCount || 6);
        shaped(stairs, ["#  ", "## ", "###"], { "#": base }, stairs, 4);
        if (wall) shaped(wall, ["###", "###"], { "#": base }, wall, 6);
        n0 += wall ? 3 : 2;
    };
    set("namek_stone", "namek_stone_slab", "namek_stone_stairs", "namek_stone_wall");
    set("namek_cobblestone", "namek_cobblestone_slab", "namek_cobblestone_stairs", "namek_cobblestone_wall", 4);
    set("namek_deepslate", "namek_deepslate_slab", "namek_deepslate_stairs", "namek_deepslate_wall");
    set("rocky_stone", "rocky_stone_slab", "rocky_stone_stairs", "rocky_stone_wall");
    set("rocky_cobblestone", "rocky_cobblestone_slab", "rocky_cobblestone_stairs", "rocky_cobblestone_wall");
    set("makai_stone", "makai_stone_slab", "makai_stone_stairs", "makai_stone_wall");
    set("demon_bricks", "demon_brick_slab", "demon_brick_stairs", "demon_brick_wall");
    set("adobe", "adobe_slab", "adobe_stairs", "adobe_wall");
    shapeless("adobe", ["makai_sand", "minecraft:clay_ball", "minecraft:clay_ball", "minecraft:wheat"], "adobe", 2);
    shaped("adobe_bricks", ["##", "##"], { "#": "adobe" }, "adobe_bricks", 4);
    shaped("demon_bricks", ["##", "##"], { "#": "demon_rock" }, "demon_bricks", 4);
    n0 += 3;
    // Ajissa & Sacred wood (data/dragonminez/recipes/*.json; planks from the #namek_alog / #namek_slog log tags)
    ["ajissa", "sacred"].forEach((w) => {
        let p = "namek_" + w;
        [p + "_log", p + "_wood", "namek_stripped_" + w + "_log", "namek_stripped_" + w + "_wood"].forEach((log) => { shapeless(w + "_planks_from_" + log, [log], p + "_planks", 4); n0++; });
        shapeless(w + "_button", [p + "_planks"], p + "_button");
        shaped(w + "_door", ["##", "##", "##"], { "#": p + "_planks" }, p + "_door", 3);
        shaped(w + "_fence", ["W#W", "W#W"], { "#": "minecraft:stick", W: p + "_planks" }, p + "_fence", 3);
        shaped(w + "_fence_gate", ["#W#", "#W#"], { "#": "minecraft:stick", W: p + "_planks" }, p + "_fence_gate");
        shaped(w + "_slab", ["###"], { "#": p + "_planks" }, p + "_slab", 6);
        shaped(w + "_stairs", ["#  ", "## ", "###"], { "#": p + "_planks" }, p + "_stairs", 4);
        shaped(w + "_trapdoor", ["###", "###"], { "#": p + "_planks" }, p + "_trapdoor", 2);
        shaped(w + "_wood", ["##", "##"], { "#": p + "_log" }, p + "_wood", 3);
        shaped(w + "_pressure_plate", ["##"], { "#": p + "_planks" }, p + "_pressure_plate");
        n0 += 9;
    });
    // gete
    shapeless("gete_ingot", ["minecraft:netherite_scrap", "minecraft:netherite_scrap", "minecraft:netherite_scrap", "minecraft:netherite_scrap",
        "gete_scrap", "gete_scrap", "gete_scrap", "gete_scrap"], "gete_ingot");
    shaped("gete_block", ["###", "###", "###"], { "#": "gete_ingot" }, "gete_block");
    n0 += 2;

    // ---- radar parts, vehicles parts (the radars and vehicles themselves are other scripts') ----
    shaped("radar_piece", ["SIS", "IRI", "SIS"], { S: "minecraft:string", I: "minecraft:iron_ingot", R: "minecraft:redstone" }, "radar_piece");
    shaped("t1_radar_chip", ["RBR", "GPG", "RBR"], { R: "minecraft:redstone", G: "minecraft:green_concrete", P: "radar_piece", B: "minecraft:repeater" }, "t1_radar_chip");
    shaped("t1_radar_cpu", ["RBR", "CPC", "ROR"], { R: "minecraft:comparator", O: "minecraft:observer", C: "t1_radar_chip", B: "minecraft:repeater", P: "radar_piece" }, "t1_radar_cpu");
    shaped("t2_radar_cpu", ["RCR", "TTT", "OCO"], { R: "minecraft:comparator", O: "minecraft:observer", C: "t2_radar_chip", T: "t1_radar_cpu" }, "t2_radar_cpu");
    shaped("t2_radar_chip", ["ROR", "BPB", "TTT"], { O: "minecraft:observer", R: "minecraft:redstone_torch", B: "minecraft:blue_concrete", P: "radar_piece", T: "t1_radar_cpu" }, "t2_radar_chip");
    shaped("vehicle_engine", ["IPI", "RFR", "III"], { I: "minecraft:iron_ingot", P: "minecraft:piston", R: "minecraft:redstone", F: "minecraft:blast_furnace" }, "vehicle_engine");
    shaped("vehicle_propeller", [" I ", "ICI", " I "], { I: "minecraft:iron_ingot", C: "minecraft:copper_block" }, "vehicle_propeller");
    shaped("vehicle_seat", ["L  ", "LWW", "I I"], { L: "minecraft:leather", W: "minecraft:cyan_wool", I: "minecraft:iron_ingot" }, "vehicle_seat");
    shaped("vehicle_plating", ["III", "ICI", "III"], { I: "minecraft:iron_ingot", C: "minecraft:copper_ingot" }, "vehicle_plating", 2);
    n0 += 9;
    // vehicle recipes: 56_vehicles.js (after the vehicle items exist)

    // ---- weapons, scouters ----
    shaped("yajirobe_katana", ["  I", "GI ", "SG "], { I: "minecraft:iron_ingot", G: "minecraft:gold_ingot", S: "minecraft:stick" }, "yajirobe_katana");
    ["red", "blue", "green", "purple"].forEach((c) => {
        shaped(c + "_scouter", ["  R", "PPT", " B "], { R: "radar_piece", P: "minecraft:" + c + "_stained_glass_pane", T: "t1_radar_cpu", B: "minecraft:stone_button" }, c + "_scouter");
        n0++;
    });
    n0++;

    // ---- Kikono / patterns ----
    shaped("kikono_station", ["ACA", "KTK", "PSP"], { A: "minecraft:anvil", C: "minecraft:diamond_chestplate", K: "kikono_block", T: "t2_radar_cpu",
        P: "minecraft:heavy_weighted_pressure_plate", S: "minecraft:smithing_table" }, "kikono_station");
    shaped("fuel_generator", ["OOO", "OTO", "OOO"], { O: "minecraft:crying_obsidian", T: "t1_radar_chip" }, "fuel_generator");
    shaped("energy_cable", [" W ", "WCW", " W "], { W: "minecraft:black_wool", C: "t1_radar_chip" }, "energy_cable", 4);
    shapeless("kikono_shard", ["kikono_block"], "kikono_shard", 9);
    shaped("kikono_block", ["KKK", "KKK", "KKK"], { K: "kikono_shard" }, "kikono_block");
    shapeless("armor_crafting_kit", ["minecraft:red_wool", "minecraft:shears"], "armor_crafting_kit");
    shaped("kikono_stick", ["K", "K"], { K: "kikono_shard" }, "kikono_stick", 2);
    shapeless("kikono_string", ["kikono_shard", "armor_crafting_kit"], "kikono_string", 2);
    shapeless("kikono_cloth", ["kikono_string", "kikono_string", "kikono_string", "kikono_string", "armor_crafting_kit"], "kikono_cloth");
    shaped("blank_pattern_z", ["RRR", "#W#", "RRR"], { "#": "minecraft:paper", W: "minecraft:white_wool", R: "minecraft:red_wool" }, "blank_pattern_z");
    shaped("blank_pattern_super", ["CPC", "#W#", "CPC"], { "#": "minecraft:paper", W: "minecraft:white_wool", P: "blank_pattern_z", C: "minecraft:cyan_wool" }, "blank_pattern_super");
    shaped("pattern_station", ["TST", "QKQ", "TST"], { T: "minecraft:crafting_table", S: "minecraft:quartz_slab", Q: "minecraft:quartz_block", K: "armor_crafting_kit" }, "pattern_station");
    n0 += 12;
    DMZ_RECIPE_COUNT = n0;
})();
