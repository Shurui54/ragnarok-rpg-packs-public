// =====================================================================================
//  93_dbr_prestige.js - Prestige: start a maxed character over for permanent bonuses
// =====================================================================================
//  Port of DMZ Ragnarok's prestige (GPL-3.0, shuruisutilities prestige/: PrestigeManager,
//  PrestigeCaps, PrestigeLedger, PrestigeEvents, PrestigeNpcs, PrestigeSettings,
//  HardSagaGateBridge, the race / quest gates and client/PrestigeScreen, PrestigeAdminScreen).
//
//  The rules (DMZR's defaults, all editable in game):
//    - A character at max level (every DMZ stat at its cap) can prestige at a prestige NPC.
//      Its DMZ progress is wiped - stats, TP, skills, techniques, form mastery, quests and
//      sagas, Z-Soul bank - and it climbs again with permanent bonuses per prestige level:
//      +10% TP earned (prestigeTpBonusPerLevel) and +25% to the per-stat cap
//      (prestigeCapBonusPerLevel). Max prestige 3 (prestigeMax).
//    - Prestige is per character slot (93_dbr_characters.js), so each character climbs alone.
//    - Rewards are paid once per player per level (the reward ledger): one more character
//      slot per level, the level's reward items, the name colour from that level, and the
//      "citizen" group on reaching the max. A second character reaching a level the player
//      was already paid for gets nothing again.
//    - HARD saga difficulty needs prestige 1 (HardSagaGate); races and quests can require a
//      prestige level, races can be operator-only.
//    - /prestige forceall <n> sets a server-wide floor: every character of everybody who had
//      already played is raised to it the next time they log in, and reset like a prestige
//      (a copy is kept: /prestige floorrestore). Parked characters are reset when next loaded.
//
//  Prestige NPCs: any entity bound with /prestige npc spawn|bind; right-click opens the
//  prestige screen, sneak-right-click (operators / dbr.prestige.admin) the config screen.
//  World data: dbr_prestige_settings, dbr_prestige_npcs. Player var: dbr_prestige (ledger),
//  dbr_prestige_view (what the client shows: level, bonuses, race locks, hard gate).
// =====================================================================================
var DBR_PRESTIGE = (function () {
    var K_SET = "dbr_prestige_settings", K_NPCS = "dbr_prestige_npcs", V_LEDGER = "dbr_prestige", V_VIEW = "dbr_prestige_view";
    var PERM_USE = "dbr.prestige.use", PERM_ADMIN = "dbr.prestige.admin";
    var BASE_CAP = 1000000;
    var STATS = ["strength", "strike", "resistance", "vitality", "kipower", "energy"];
    var DEFAULTS = { enabled: true, max: 3, tpPerLevel: 10, capPerLevel: 25, model: "minecraft:villager", name: "Prestige Master",
        raceReq: {}, opOnly: [], questReq: {}, minPrestige: 0, minAt: 0, minBy: "", levelRewards: {}, levelColours: {}, citizenGroup: "citizen" };
    var COLOURS = { black: "0", dark_blue: "1", dark_green: "2", dark_aqua: "3", dark_red: "4", dark_purple: "5", gold: "6", gray: "7", grey: "7",
        dark_gray: "8", dark_grey: "8", blue: "9", green: "a", aqua: "b", red: "c", light_purple: "d", yellow: "e", white: "f" };

    function uid(p) { return String(p.uuid); }
    function log(s) { RPG.log("[Prestige] " + s); }
    function C() { return DBR_CHARS; }

    // =================================================================================
    //  Settings (PrestigeSettings)
    // =================================================================================
    var CACHE = null;
    function settings() {
        if (CACHE) return CACHE;
        var s = RPG.data.get(K_SET, null), o = JSON.parse(JSON.stringify(DEFAULTS));
        if (s && typeof s === "object") Object.keys(DEFAULTS).forEach(function (k) { if (s[k] !== undefined && s[k] !== null) o[k] = s[k]; });
        o.max = Math.max(0, Math.floor(Number(o.max) || 0));
        o.tpPerLevel = Math.max(0, Number(o.tpPerLevel) || 0);
        o.capPerLevel = Math.max(0, Number(o.capPerLevel) || 0);
        if (!o.raceReq || typeof o.raceReq !== "object") o.raceReq = {};
        if (!o.questReq || typeof o.questReq !== "object") o.questReq = {};
        if (!o.levelRewards || typeof o.levelRewards !== "object") o.levelRewards = {};
        if (!o.levelColours || typeof o.levelColours !== "object") o.levelColours = {};
        var ops = [];
        if (o.opOnly && typeof o.opOnly.length === "number") for (var i = 0; i < o.opOnly.length; i++) ops.push(String(o.opOnly[i]).toLowerCase());
        o.opOnly = ops;
        return (CACHE = o);
    }
    function saveSettings(o) { RPG.data.set(K_SET, o); CACHE = null; RPG.server.players().forEach(sendView); }
    function enabled() { return !!settings().enabled; }

    // =================================================================================
    //  The player's level and bonuses (PrestigeManager / PrestigeCaps)
    // =================================================================================
    function level(p) { return C().getActivePrestige(p); }
    // hot paths (every TP gain, every stat recompute) read a per-player cache, refreshed by sendView on join,
    // respawn, switch, prestige and settings saves
    var LV = {};
    function cachedLevel(p) { var v = LV[uid(p)]; if (v === undefined) v = LV[uid(p)] = level(p); return v; }
    function tpPct(p) { return enabled() ? cachedLevel(p) * settings().tpPerLevel : 0; }
    function capPct(p) { return enabled() ? cachedLevel(p) * settings().capPerLevel : 0; }
    function capMult(p) { return 1 + capPct(p) / 100; }
    /** the per-stat cap for this character (DMZ maxValue x prestige multiplier) */
    function capFor(p) { return Math.min(2147483647, Math.round(BASE_CAP * capMult(p))); }
    /** what the dmzTp / quest rewards multiply TP by (PrestigeEvents.onTpGain) */
    function tpMult(p) { return 1 + tpPct(p) / 100; }

    /** max level: every DMZ stat at this character's cap (StatsData.getLevel() >= getConfiguredMaxValue()) */
    function statsAtCap(p) {
        var cap = capFor(p), n = 0;
        STATS.forEach(function (s) { if (p.baseStat(s) >= cap) n++; });
        return n;
    }
    function statsMaxed(p) { return statsAtCap(p) >= STATS.length; }
    function canPrestige(p) {
        return enabled() && !!p.getVar("dmz_created", 0) && level(p) < settings().max && statsMaxed(p) && !busy(p);
    }
    function busy(p) {
        if (typeof DBR_TCHAR !== "undefined" && (DBR_TCHAR.isActive(p) || DBR_TCHAR.isCreating(p))) return "Finish with your tournament character first.";
        if (typeof DMZ_FUSION !== "undefined" && DMZ_FUSION.isFused(p)) return "You can't prestige while fused.";
        return null;
    }

    // ---- the ledger (PrestigeLedger): highest level ever paid out to this player ------------------
    function ledgerObj(p) { var l = p.getVar(V_LEDGER, null); return l && typeof l === "object" ? l : {}; }
    function ledger(p) { return Math.max(0, Math.floor(Number(ledgerObj(p).rewarded) || 0)); }
    function setLedger(p, n) { var l = ledgerObj(p); l.rewarded = Math.max(0, Math.floor(n)); p.setVar(V_LEDGER, l); }
    /** "only going forward": a player met for the first time is seeded at their current highest prestige */
    function seedLedger(p) {
        var l = ledgerObj(p);
        if (l.seeded) return;
        l.seeded = 1;
        l.rewarded = Math.max(Math.floor(Number(l.rewarded) || 0), C().highestPrestige(p));
        if (!l.seen) l.seen = C().root(p).existed ? 1 : Date.now();      // 1 = was already a player when this arrived
        p.setVar(V_LEDGER, l);
    }

    // =================================================================================
    //  The wipe (PrestigeManager.wipeActiveCharacter)
    // =================================================================================
    function wipe(p) {
        try { if (typeof DMZ_TF !== "undefined") { DMZ_TF.stopCharge(p, -2); DMZ_TF.descend(p, false, true); } } catch (e) { }
        DMZ_DATA.STATS.forEach(function (k) { var id = DMZ_DATA.STAT_IDS[k]; var a = p.allocated(id); if (a) p.addStat(id, -a); });
        p.setStatPoints(0);
        p.setTp(0);
        p.setVar("dmz_quests", null);                     // every saga and side quest (PlayerQuestData.resetAll)
        p.setVar("dmz_story_resets", 0);
        RPG.skills.list().forEach(function (s) { try { if (p.hasSkill(s)) p.forgetSkill(s); } catch (err) { } });
        p.setVar("dmz_skills", {});
        p.setVar("dmz_potential", 0);
        if (typeof DMZ_TECH !== "undefined" && DMZ_TECH.clearAll) DMZ_TECH.clearAll(p);
        // form and stack-form mastery and the "used before" records (CharacterSlots.clearMasteries)
        ["dmz_mastery", "dmz_stack_mastery"].forEach(function (k) { p.setVar(k, {}); });
        ["dmz_form", "dmz_stack", "dmz_sel", "dmz_sel_stack", "dmz_form_name"].forEach(function (k) { p.setVar(k, ""); });
        ["dmz_prev", "dmz_prev_stack", "dmz_mult", "dmz_form_mult", "dmz_surge", "dmz_surge_active", "dmz_skill_active"].forEach(function (k) { p.setVar(k, null); });
        p.setVar("dmz_release", 0);
        p.setVar("dmz_cd", {});
        p.setVar("dmz_android", 0);
        if (p.getVar("dmz_majin", 0)) { p.setVar("dmz_majin", 0); p.removeEffect("dmz_majin"); }
        p.clearEffects();
        p.setVar("dbr_zsoul", null);                      // beyond-cap Z-Soul progress (ZSoulBridge.reset)
        p.refreshStats();
        if (typeof DMZ_SKILLS !== "undefined") DMZ_SKILLS.ensureDefaults(p);
        try { p.health = p.maxHealth; } catch (e) { }
    }

    // =================================================================================
    //  Prestiging (the key's PrestigeHooks.prestige) and the rewards
    // =================================================================================
    function prestige(p) {
        if (!enabled()) return "Prestige is not enabled on this server.";
        if (!p.getVar("dmz_created", 0)) return "Create your character first.";
        var s = settings(), lvl = level(p);
        if (lvl >= s.max) return "Maximum prestige reached.";
        var b = busy(p);
        if (b) return b;
        if (!statsMaxed(p)) return "Reach max level to prestige (every stat at " + fmt(capFor(p)) + ").";
        wipe(p);
        C().setActivePrestige(p, lvl + 1);
        payRewards(p, lvl + 1);
        log(p.name + " prestiged: " + lvl + " -> " + (lvl + 1) + " (slot " + C().activeSlot(p).name + ")");
        p.title("&6&lPRESTIGE " + (lvl + 1), "&eYour journey starts again, stronger.");
        p.playSound("dmzpack:ui_menu_switch", 1, 0.8);
        RPG.server.broadcast("&6" + p.name + " &ereached &6Prestige " + (lvl + 1) + "&e!");
        onCharacterLoaded(p);
        if (typeof DMZ_QUESTS !== "undefined") DMZ_QUESTS.sync(p);
        return null;
    }
    /** one payout per newly crossed level: items, and the citizen group at max (slots follow the ledger by themselves) */
    function payRewards(p, newLevel) {
        seedLedger(p);
        var paid = ledger(p), s = settings();
        if (newLevel <= paid) return;
        for (var L = paid + 1; L <= newLevel; L++) {
            var items = s.levelRewards[String(L)];
            if (items && typeof items.length === "number") for (var i = 0; i < items.length; i++) { try { p.giveStack(items[i]); } catch (e) { log("reward item: " + e); } }
            p.tell("&6Prestige " + L + " reward: &fone more character slot" + (items && items.length ? " and " + items.length + " item(s)" : "") + ".");
        }
        setLedger(p, newLevel);
        if (newLevel >= s.max && s.citizenGroup) { try { RPG.perms.addGroup(p, String(s.citizenGroup)); } catch (e) { } }
    }

    // =================================================================================
    //  The floor (/prestige forceall, PrestigeManager.applyMinimum)
    // =================================================================================
    function backupKey(p) { return "dbr_floor_backup_" + C().activeSlot(p).id; }
    function floorQualifies(p) {
        var s = settings(), l = ledgerObj(p);
        return s.minPrestige > 0 && (Number(l.seen) || 0) < (Number(s.minAt) || 0);
    }
    function applyMinimum(p) {
        var s = settings();
        if (!enabled() || !floorQualifies(p)) return 0;
        var r = C().root(p), floor = s.minPrestige, raised = 0, activeRaised = false;
        r.slots.forEach(function (sl) {
            var cur = Math.floor(Number(sl.prestige) || 0);
            if (cur >= floor) return;
            if (sl.id === r.active) activeRaised = cur;
            else { sl.floorPrev = cur; sl.floorReset = 1; }
            sl.prestige = floor;
            raised++;
        });
        if (!raised) return 0;
        C().save(p, r);
        if (activeRaised !== false && p.getVar("dmz_created", 0)) {
            p.saveProfile(backupKey(p), C().opts());
            p.setVar("dbr_floor_backup_meta", { slot: r.active, prestige: activeRaised, at: Date.now() });
            wipe(p);
            p.tell("&eThis character was prestiged by the server-wide reset, so it starts again from scratch.");
        }
        payRewards(p, C().highestPrestige(p));
        log(p.name + ": raised " + raised + " character(s) to the prestige floor " + floor);
        onCharacterLoaded(p);
        return raised;
    }
    /** a parked character the floor raised gets its reset when it is next loaded (called after a switch) */
    function owedFloorReset(p) {
        var r = C().root(p), i = C().slotIndex(r, r.active);
        if (i < 0 || !r.slots[i].floorReset) return;
        if (settings().minPrestige <= 0) { log("floor reset skipped for " + p.name + ": no floor is set any more"); return; }
        if (p.getVar("dmz_created", 0)) {
            p.saveProfile(backupKey(p), C().opts());
            p.setVar("dbr_floor_backup_meta", { slot: r.active, prestige: r.slots[i].floorPrev || 0, at: Date.now() });
            wipe(p);
            p.tell("&eThis character was prestiged by the server-wide reset, so it starts again from scratch.");
        }
        delete r.slots[i].floorReset; delete r.slots[i].floorPrev;
        C().save(p, r);
    }
    function floorRestore(p) {
        var key = backupKey(p), meta = p.getVar("dbr_floor_backup_meta", null);
        if (!p.hasProfile(key)) return "This character has no copy from before the prestige floor.";
        if (!p.loadProfile(key, C().opts())) return "Could not restore it.";
        p.deleteProfile(key);
        if (meta && meta.slot === C().activeSlot(p).id) C().setActivePrestige(p, Math.max(0, Number(meta.prestige) || 0));
        p.setVar("dbr_floor_backup_meta", null);
        C().settle(p, false);
        return null;
    }

    // =================================================================================
    //  Gates: races, quests, HARD saga difficulty
    // =================================================================================
    function raceLocks(p) {
        var s = settings(), out = {}, lvl = level(p);
        Object.keys(s.raceReq).forEach(function (r) { var req = Number(s.raceReq[r]) || 0; if (req > 0 && lvl < req) out[r] = req; });
        if (!p.isOp()) s.opOnly.forEach(function (r) { out[r] = -1; });
        return out;
    }
    /** why this race can't be picked now, or null */
    function raceLocked(p, race) {
        if (!enabled()) return null;
        var l = raceLocks(p)[String(race).toLowerCase()];
        if (l === undefined) return null;
        return l < 0 ? "That race is for operators only." : "That race requires Prestige " + l + ".";
    }
    function questAllowed(p, key) {
        if (!enabled()) return true;
        var req = Number(settings().questReq[String(key).toLowerCase()]) || 0;
        return req <= 0 || level(p) >= req;
    }
    function questRequired(key) { return Number(settings().questReq[String(key).toLowerCase()]) || 0; }
    /** HardSagaGateBridge.mayUseHard: prestiged at least once, unless prestige is off (then the door is open) */
    function mayUseHard(p) { return !enabled() || settings().max <= 0 || level(p) >= 1; }

    // =================================================================================
    //  The name colour and what the client sees
    // =================================================================================
    function colourFor(lvl) {
        var s = settings(), best = null, bestL = -1;
        Object.keys(s.levelColours).forEach(function (k) { var L = Number(k); if (L <= lvl && L > bestL) { bestL = L; best = s.levelColours[k]; } });
        return best;
    }
    function colourCode(name) {
        if (!name) return null;
        var c = String(name).trim().toLowerCase().replace(/^[&§]/, "");
        if (/^[0-9a-f]$/.test(c)) return c;
        return COLOURS[c] || null;
    }
    var OUR_NAME = {};
    function applyName(p) {
        try {
            var cur = String(p.getTempName() || ""), mine = OUR_NAME[uid(p)];
            if (cur && cur !== mine) return;                       // a fusion name (64_dmz_fusion.js) or another script's wins
            var code = enabled() && level(p) > 0 ? colourCode(colourFor(level(p))) : null;
            var want = code ? "&" + code + p.name : "";
            if (want === cur) return;
            p.setTempName(want || null);
            if (want) OUR_NAME[uid(p)] = want; else delete OUR_NAME[uid(p)];
        } catch (e) { }
    }
    function sendView(p) {
        LV[uid(p)] = level(p);
        try {
            var s = settings();
            p.setVar(V_VIEW, { on: enabled() ? 1 : 0, lvl: level(p), max: s.max, tp: tpPct(p), cap: capPct(p), hard: mayUseHard(p) ? 1 : 0, locks: raceLocks(p) });
        } catch (e) { log("view " + p.name + ": " + e); }
    }
    function onCharacterLoaded(p) {
        var before = LV[uid(p)];
        sendView(p);
        applyName(p);
        if (before !== LV[uid(p)]) { try { p.refreshStats(); if (typeof DBR_ZSOUL !== "undefined") DBR_ZSOUL.refresh(p); } catch (e) { } }   // the cap moved
    }

    RPG.on("playerJoin", function (p) {
        RPG.schedule(25, function () {
            seedLedger(p);
            applyMinimum(p);
            sendView(p);
            applyName(p);
        });
    });
    RPG.on("respawn", function (p) { RPG.schedule(2, function () { sendView(p); applyName(p); }); });
    RPG.on("playerLeave", function (p) { delete OUR_NAME[uid(p)]; delete LV[uid(p)]; });

    // =================================================================================
    //  NPCs (PrestigeNpcs)
    // =================================================================================
    function npcs() { var n = RPG.data.get(K_NPCS, null); return n && typeof n === "object" ? n : {}; }
    function isNpc(e) { return !!(e && npcs()[String(e.uuid)]); }
    function isAdmin(p) { return p.isOp() || RPG.perms.has(p, PERM_ADMIN); }
    function spawnNpc(p, model, name) {
        model = String(model || settings().model || "minecraft:villager");
        var e = null, entry = typeof rgNpcResolve === "function" ? rgNpcResolve(model) : null;
        try {
            if (entry) e = RPG.world.spawnNpc(p.dimension, rgNpcId(entry), p.x, p.y, p.z);
            else if (RPG.npcs.exists(model)) e = RPG.world.spawnNpc(p.dimension, model, p.x, p.y, p.z);
            else e = RPG.world.spawn(p.dimension, model.indexOf(":") > 0 ? model : "minecraft:" + model, p.x, p.y, p.z);
        } catch (err) { log("spawn " + model + ": " + err); }
        if (!e) return null;
        try { e.teleportTo(p.dimension, p.x, p.y, p.z, p.yaw, 0); e.setAI(false); } catch (err) { }
        name = String(name || settings().name || "Prestige Master");
        try { e.setCustomName("&6" + name); e.setNameVisible(true); } catch (err) { }
        var n = npcs();
        n[String(e.uuid)] = { name: name, model: model };
        RPG.data.set(K_NPCS, n);
        return e;
    }
    RPG.on("entityInteract", function (p, e) {
        if (!e || !isNpc(e)) return;
        if (p.isSneaking() && isAdmin(p)) openAdmin(p, e);
        else openScreen(p);
        return false;
    });

    // =================================================================================
    //  Screens (PacketPrestigeGui / PacketPrestigeAdminGui and their saves)
    // =================================================================================
    function screenData(p) {
        var s = settings(), rows = [];
        for (var L = 1; L <= s.max; L++) rows.push({ l: L, tp: L * s.tpPerLevel, cap: L * s.capPerLevel, reward: !!(s.levelRewards[String(L)] && s.levelRewards[String(L)].length) });
        return { level: level(p), max: s.max, tpPer: s.tpPerLevel, capPer: s.capPerLevel, can: canPrestige(p), atCap: statsAtCap(p), cap: capFor(p),
            created: !!p.getVar("dmz_created", 0), on: enabled(), rows: rows, slot: C().activeSlot(p).name, why: busy(p) || "" };
    }
    function openScreen(p) {
        if (!enabled()) { p.tell("&cPrestige is not enabled on this server."); return; }
        RPG.net.send(p, "dbr_prestige_gui", screenData(p));
    }
    function openAdmin(p, e) {
        var s = settings(), races = [];
        try { races = RPG.races.list().map(String); } catch (err) { }
        var npc = e ? npcs()[String(e.uuid)] : null;
        RPG.net.send(p, "dbr_prestige_admin", { max: s.max, tp: s.tpPerLevel, cap: s.capPerLevel, model: npc ? npc.model : s.model,
            name: npc ? npc.name : s.name, entity: e ? String(e.uuid) : "", races: races, raceReq: s.raceReq, opOnly: s.opOnly, enabled: !!s.enabled,
            raceNames: races.map(function (r) { try { return String(RPG.races.name(r)); } catch (err) { return r; } }) });
    }
    RPG.net.on("dbr_prestige", function (p, d) {
        if (!d) return;
        var a = String(d.action || "");
        if (a === "prestige") {
            var err = prestige(p);
            if (err) { p.tell("&c" + err); p.playSound("dmzpack:ui_menu_switch", 0.6, 0.6); }
            openScreen(p);
            return;
        }
        if (!isAdmin(p)) return;
        var s = settings();
        if (a === "admin_save" || a === "admin_spawn") {
            s.max = clampInt(d.max, 0, 100000, s.max);
            s.tpPerLevel = clampInt(d.tp, 0, 100000, s.tpPerLevel);
            s.capPerLevel = clampInt(d.cap, 0, 100000, s.capPerLevel);
            if (typeof d.enabled === "boolean") s.enabled = d.enabled;
            var model = String(d.model || "").trim(), name = String(d.name || "").trim().substring(0, 48);
            var ent = d.entity ? RPG.world.entityByUuid(String(d.entity)) : null, n = npcs(), rec = ent ? n[String(ent.uuid)] : null;
            if (rec) {
                // per NPC: name, and a changed model respawns it in place
                if (name) { rec.name = name; try { ent.setCustomName("&6" + name); } catch (err) { } }
                if (model && model !== rec.model) {
                    var e2 = spawnNpc({ dimension: ent.dimension, x: ent.x, y: ent.y, z: ent.z, yaw: ent.yaw }, model, rec.name);
                    if (e2) { delete n[String(ent.uuid)]; try { ent.remove(); } catch (err) { } var n2 = npcs(); delete n2[String(ent.uuid)]; RPG.data.set(K_NPCS, n2); }
                    else p.tell("&cCould not spawn '" + model + "'.");
                } else RPG.data.set(K_NPCS, n);
            } else {
                if (model) s.model = model;
                if (name) s.name = name;
            }
            saveSettings(s);
            if (a === "admin_spawn") { var e3 = spawnNpc(p, null, null); p.tell(e3 ? "&aPrestige NPC spawned." : "&cCould not spawn '" + settings().model + "'."); }
            else p.tell("&aPrestige settings saved.");
            return;
        }
        if (a === "race_save") {
            var req = {}, src = d.raceReq || {};
            Object.keys(src).forEach(function (k) { var v = Math.floor(Number(src[k]) || 0); if (v > 0) req[String(k).toLowerCase()] = v; });
            s.raceReq = req;
            var ops = [];
            if (d.opOnly && typeof d.opOnly.length === "number") for (var i = 0; i < d.opOnly.length; i++) ops.push(String(d.opOnly[i]).toLowerCase());
            s.opOnly = ops;
            saveSettings(s);
            p.tell("&aRace gates saved.");
        }
    });
    function clampInt(v, lo, hi, def) { var n = Math.floor(Number(v)); return isNaN(n) ? def : Math.max(lo, Math.min(hi, n)); }
    function fmt(n) { return String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }

    // =================================================================================
    //  /prestige
    // =================================================================================
    var HELP = ["&6/prestige &7- your prestige", "&6/prestige npc spawn [model] [name] &7| &6bind &7| &6unbind &7- prestige NPCs",
        "&6/prestige admin &7- the config screen", "&6/prestige set <player> <level> &7| &6reset <player>",
        "&6/prestige forceall <level> &7- server-wide floor (0 clears) &7| &6floorrestore [player]",
        "&6/prestige reward <level> add|clear|list &7- items paid once on reaching a level (add = held item)",
        "&6/prestige colour <level> <colour|clear> &7| &6questgate <quest> <level> &7| &6enable|disable"];
    function nearestEntity(p, r) {
        var best = null, bd = r * r;
        p.nearby(r).forEach(function (e) {
            if (e.isPlayer()) return;
            var dx = e.x - p.x, dy = e.y - p.y, dz = e.z - p.z, d = dx * dx + dy * dy + dz * dz;
            if (d < bd) { bd = d; best = e; }
        });
        return best;
    }
    function command(p, args) {
        var sub = String(args[0] || "").toLowerCase(), s = settings();
        function tell(m) { if (p) p.tell(m); else RPG.log(m.replace(/&./g, "")); }
        function target(i) { var t = args[i] ? RPG.server.player(args[i]) : p; if (!t) tell("&cNo such player online."); return t; }
        if (!sub || sub === "info") {
            var t0 = target(1);
            if (!t0) return;
            tell("&6" + t0.name + ": &ePrestige " + level(t0) + "&7/" + s.max + " &7(+" + tpPct(t0) + "% TP, +" + capPct(t0) + "% stat cap)" + (canPrestige(t0) ? " &a- ready to prestige" : ""));
            if (p && isAdmin(p)) tell("&8/prestige help");
            return;
        }
        if (sub === "help") { HELP.forEach(tell); return; }
        if (p && !isAdmin(p)) { tell("&cYou don't have permission (" + PERM_ADMIN + ")."); return; }
        switch (sub) {
            case "gui": if (p) openScreen(p); return;
            case "admin": if (p) openAdmin(p, null); return;
            case "enable": case "disable": s.enabled = sub === "enable"; saveSettings(s); tell("&aPrestige " + sub + "d."); return;
            case "npc": {
                if (!p) return;
                var op = String(args[1] || "").toLowerCase(), n = npcs();
                if (op === "spawn") { var e = spawnNpc(p, args[2], args.slice(3).join(" ")); tell(e ? "&aPrestige NPC spawned." : "&cCould not spawn that model."); }
                else if (op === "bind") { var nb = nearestEntity(p, 6); if (!nb) { tell("&cNo entity within 6 blocks."); return; } n[String(nb.uuid)] = { name: s.name, model: "" }; RPG.data.set(K_NPCS, n); tell("&aBound the nearby " + nb.name + " as a prestige NPC."); }
                else if (op === "unbind") { var nu = nearestEntity(p, 6); if (!nu || !n[String(nu.uuid)]) { tell("&cNo prestige NPC within 6 blocks."); return; } delete n[String(nu.uuid)]; RPG.data.set(K_NPCS, n); tell("&aUnbound."); }
                else tell("&c/prestige npc spawn [model] [name] | bind | unbind");
                return;
            }
            case "set": {
                var t = target(1), lv = Math.floor(Number(args[2]));
                if (!t || isNaN(lv)) { tell("&c/prestige set <player> <level>"); return; }
                C().setActivePrestige(t, Math.max(0, lv));
                payRewards(t, Math.max(0, lv));
                onCharacterLoaded(t);
                tell("&a" + t.name + "'s character '" + C().activeSlot(t).name + "' is now prestige " + level(t) + ".");
                return;
            }
            case "reset": {
                var tr = target(1);
                if (!tr) return;
                var r = C().root(tr);
                r.slots.forEach(function (sl) { sl.prestige = 0; delete sl.floorReset; delete sl.floorPrev; });
                C().save(tr, r);
                tr.setVar(V_LEDGER, { seeded: 1, rewarded: 0, seen: ledgerObj(tr).seen || Date.now() });
                onCharacterLoaded(tr);
                tell("&aReset " + tr.name + "'s prestige on every character (progress kept).");
                return;
            }
            case "forceall": {
                var fl = Math.max(0, Math.floor(Number(args[1]) || 0));
                s.minPrestige = fl; s.minAt = fl > 0 ? Date.now() : 0; s.minBy = fl > 0 ? (p ? p.name : "console") : "";
                saveSettings(s);
                tell(fl > 0 ? "&aPrestige floor set to " + fl + ": everyone who had already played is raised (and reset) on their next login." : "&aPrestige floor cleared.");
                if (fl > 0) RPG.server.players().forEach(applyMinimum);
                return;
            }
            case "floorrestore": {
                var tf = target(1);
                if (!tf) return;
                var err = floorRestore(tf);
                tell(err ? "&c" + err : "&aRestored " + tf.name + "'s character from before the prestige floor.");
                return;
            }
            case "reward": {
                var L = Math.floor(Number(args[1])), op2 = String(args[2] || "list").toLowerCase();
                if (!(L > 0)) { tell("&c/prestige reward <level> add|clear|list"); return; }
                var list = s.levelRewards[String(L)] || [];
                if (op2 === "add" && p) {
                    var held = p.getHeldStack();
                    if (!held || !held.id || held.id === "minecraft:air") { tell("&cHold the item to add."); return; }
                    list.push(held); s.levelRewards[String(L)] = list; saveSettings(s); tell("&aAdded " + (held.count || 1) + "x " + held.id + " to the prestige " + L + " reward.");
                } else if (op2 === "clear") { delete s.levelRewards[String(L)]; saveSettings(s); tell("&aCleared the prestige " + L + " reward."); }
                else { tell("&6Prestige " + L + " reward: " + (list.length ? list.map(function (it) { return (it.count || 1) + "x " + it.id; }).join(", ") : "&7nothing (one character slot only)")); }
                return;
            }
            case "colour": case "color": {
                var Lc = Math.floor(Number(args[1])), c = String(args[2] || "");
                if (!(Lc > 0) || !c) { tell("&c/prestige colour <level> <gold|&6|clear>"); return; }
                if (c === "clear") delete s.levelColours[String(Lc)];
                else if (!colourCode(c)) { tell("&cNot a colour: " + c); return; }
                else s.levelColours[String(Lc)] = c;
                saveSettings(s);
                RPG.server.players().forEach(applyName);
                tell("&aSaved.");
                return;
            }
            case "questgate": {
                var q = String(args[1] || "").toLowerCase(), Lq = Math.floor(Number(args[2]) || 0);
                if (!q) { tell("&6Quest gates: " + (Object.keys(s.questReq).map(function (k) { return k + "=" + s.questReq[k]; }).join(", ") || "&7none")); return; }
                if (Lq > 0) s.questReq[q] = Lq; else delete s.questReq[q];
                saveSettings(s);
                tell("&aQuest " + q + (Lq > 0 ? " now requires prestige " + Lq : " is ungated") + ".");
                return;
            }
            default: HELP.forEach(tell);
        }
    }
    function suggest(p, args) {
        if (args.length <= 1) return p && isAdmin(p) ? ["info", "help", "npc", "admin", "set", "reset", "forceall", "floorrestore", "reward", "colour", "questgate", "enable", "disable"] : ["info"];
        if (args[0] === "npc" && args.length === 2) return ["spawn", "bind", "unbind"];
        return [];
    }
    RPG.commands.register("prestige", { root: true, permission: 0, description: "Prestige: /prestige", run: command, suggest: suggest });

    return { level: level, tpPct: tpPct, capPct: capPct, capMult: capMult, capFor: capFor, tpMult: tpMult, canPrestige: canPrestige, prestige: prestige,
        statsMaxed: statsMaxed, ledger: ledger, wipe: wipe, raceLocked: raceLocked, questAllowed: questAllowed, questRequired: questRequired,
        mayUseHard: mayUseHard, onCharacterLoaded: onCharacterLoaded, owedFloorReset: owedFloorReset, applyMinimum: applyMinimum, openScreen: openScreen,
        openAdmin: openAdmin, settings: settings, isNpc: isNpc, BASE_CAP: BASE_CAP };
})();
