// =====================================================================================
//  56_vehicles.js - DMZ's vehicles (VehicleEntity, CarEntity, CC576Entity, FriezaCapsuleEntity,
//  SpacePodEntity, FlyingNimbusEntity) on the engine's rideable vehicles (RPG.vehicles)
// =====================================================================================
//  Use the item on a block to set the vehicle down, right-click it to get in (sneak gets
//  out), punch it to pack it back into its item. Driving (DMZ's controls): W/S, A/D,
//  sprint for the boost, Space up, Left Alt down. Frieza's capsule hovers; double-tap
//  Space to take off. The space pod opens its destination list when you get in.
// =====================================================================================
// players who just arrived in a pod (the next mount opens no menu); 86_dbr_space.js sets it too
var DBR_POD_ARRIVING = {};
(function () {
    var GEO = DMZ + "geo/entity/", TEX = DMZ + "textures/entity/", ANIM = DMZ + "animations/entity/";
    var PX = 1 / 16;

    // DMZ seats are model pixels: modelToLocal ((x, y, -z) + modelOffset) * modelScale / 16, then minus the seated hip
    // height (0.6) plus the riding offset (0.35). scale / off = the vehicle's geo.scale / geo.offset (DMZ modelScale /
    // modelOffset), so the seats stay where the model's passenger bones are drawn.
    var ARRIVING = DBR_POD_ARRIVING;
    function seat(x, y, z, scale, off) {
        var s = scale || 1, o = off || [0, 0, 0];
        return [(x + o[0]) * s * PX, (y + o[1]) * s * PX - 0.6 + 0.35, -(z + o[2]) * s * PX];
    }
    var CC576_OFFSET = [-10, 0, -40];

    // ---- the vehicles (sizes = DMZ's entity hitboxes, speeds in blocks per tick) ----
    ["red", "yellow"].forEach((c) => {
        RPG.vehicles.define("car_" + c, {
            name: "Capsule Car", item: "car_" + c, mode: "ground", width: 2.4, height: 1.3,
            geo: { model: GEO + "vehicles/car.geo.json", texture: TEX + "vehicles/car_" + c + ".png" },
            speed: 0.45, sprint: 1.7, accel: 0.03, turnSpeed: 5, health: 50, stepHeight: 1,
            seats: [seat(5.5, 8.5, 2), seat(-5.5, 8.5, 2)],
            engineSound: DMZ + "vehicle.car.engine"
        });
    });
    RPG.vehicles.define("cc576", {
        name: "CC-576", item: "cc576", mode: "fly", width: 4.5, height: 4.0,
        // DMZ CC576Entity: modelOffset(-10, 0, -40) centres the plane on its hitbox
        geo: { model: GEO + "vehicles/cc576.geo.json", texture: TEX + "vehicles/cc576.png", offset: CC576_OFFSET },
        speed: 0.9, sprint: 1.6, climb: 0.3, accel: 0.03, health: 80,
        seats: [seat(21, 22, 3, 1, CC576_OFFSET), seat(-1, 22, 3, 1, CC576_OFFSET), seat(21, 22, 25, 1, CC576_OFFSET), seat(-1, 22, 25, 1, CC576_OFFSET)],
        engineSound: DMZ + "vehicle.cc576.engine"
    });
    RPG.vehicles.define("frieza_capsule", {
        name: "Frieza's Capsule", item: "frieza_capsule", mode: "hybrid", width: 1.5, height: 1.6,
        // DMZ FriezaCapsuleEntity: model("vehicles/frieza_capsule", 2.5F); the model is ~10 px wide, drawn at 2.5x
        geo: { model: GEO + "vehicles/frieza_capsule.geo.json", texture: TEX + "vehicles/frieza_capsule.png", scale: 2.5 },
        speed: 0.5, sprint: 1.6, climb: 0.4, accel: 0.04, gravity: 0.04, jump: 0.45, health: 60,
        seats: [seat(0, 7, 0, 2.5)],
        engineSound: DMZ + "vehicle.frieza_capsule.engine"
    });
    RPG.vehicles.define("spacepod", {
        name: "Space Pod", item: "saiyan_ship", mode: "fly", width: 2.0, height: 2.0,
        // DMZ SpacePodEntity: model("spacepod", 1.1F)
        geo: { model: GEO + "spacepod.geo.json", texture: TEX + "spacepod.png", animation: ANIM + "spacepod.animation.json", scale: 1.1 },
        speed: 1.08, climb: 0.4, accel: 0.05, health: 80,
        // in space (86_dbr_space.js) the pod drifts with inertia; DMZ Ragnarok's pod cruises at up to ~2.4 by hand
        dimensionModes: { "ragnarok_rpg:space": "space" }, spaceSpeed: 2.4, sprint: 1, thrust: 0.08, drag: 0.004,
        seats: [seat(0, 10.9, -1.05, 1.1)],
        engineSound: DMZ + "vehicle.spacepod.engine",
        onMount(p, pod) {
            if (ARRIVING[p.uuid]) { delete ARRIVING[p.uuid]; return; }      // just landed: no menu
            p.playSound(DMZ + "ship_open", 1, 1);
            RPG.schedule(10, () => openDestinations(p));
        }
    });
    [["flying_nimbus", "kinton", "Flying Nimbus", (a) => a > 66, "Only the pure of heart can ride the Flying Nimbus."],
     ["black_nimbus", "black_kinton", "Black Nimbus", (a) => a < 67, "The Black Nimbus refuses you."]].forEach((n) => {
        RPG.vehicles.define(n[0], {
            name: n[2], item: n[0], mode: "fly", width: 2.0, height: 1.3,
            geo: { model: GEO + "kinton.geo.json", texture: TEX + n[1] + ".png", animation: ANIM + "kinton.animation.json", idle: "idle" },
            speed: 1.2, climb: 0.4, accel: 0.06, health: -1,
            seats: [[0, 0.9 - 0.35, 0.4], [0, 0.9 - 0.35, -0.4]],
            // FlyingNimbusEntity: only riders with the right alignment
            onInteract(p, v) {
                if (!n[3](Number(p.getVar("dmz_alignment", 100)))) { p.actionbar("&7" + n[4]); p.playSound(DMZ + "nube", 0.8, 0.6); return false; }
                p.playSound(DMZ + "nube", 1, 1);
            }
        });
    });

    // ---- items: use on a block to set the vehicle down ----
    var ITEMS = [["car_red", "car_red", "Red Capsule Car"], ["car_yellow", "car_yellow", "Yellow Capsule Car"], ["cc576", "cc576", "CC-576"],
                 ["frieza_capsule", "frieza_capsule", "&5Frieza's Capsule"], ["saiyan_ship", "spacepod", "Saiyan Space Pod"],
                 ["flying_nimbus", "flying_nimbus", "&eFlying Nimbus"], ["black_nimbus", "black_nimbus", "&8Black Nimbus"]];
    ITEMS.forEach((it) => {
        RPG.items.define(it[0], {
            name: it[2], model: DMZ + "rpg/item/" + it[0], type: "tool", rarity: "rare", maxStack: 1,
            lore: ["Use on the ground to set it down.", "Right-click it to ride, punch it to pack it up."],
            onUse(p) {
                let hit = p.lookBlock(6);
                let at = hit ? { x: hit[0] + 0.5, y: hit[1] + 1, z: hit[2] + 0.5 } : lookPoint(p, 3);
                let v = RPG.world.spawnVehicle(p.dimension, it[1], at.x, at.y, at.z, p.yaw);
                if (!v) return false;
                RPG.world.particle(p.dimension, "minecraft:poof", at.x, at.y + 0.5, at.z, 25, 1, 0.05);
                sfx(p, it[0].indexOf("nimbus") >= 0 ? "nube" : "vehicle.door", 1, 1);
                if (p.getGameMode() !== "creative") p.takeItem(it[0], 1);
                return true;
            }
        });
    });

    // ---- recipes (DMZ) ----
    [["saiyan_ship", ["QCQ", "CTC", "RML"], { Q: "minecraft:quartz_block", C: "t2_radar_chip", R: "minecraft:repeater", M: "minecraft:minecart", L: "minecraft:red_wool", T: "t2_radar_cpu" }],
     ["car_red", ["PDP", "SES", "W W"], { P: "vehicle_plating", D: "minecraft:red_dye", S: "vehicle_seat", E: "vehicle_engine", W: "minecraft:black_wool" }],
     ["car_yellow", ["PDP", "SES", "W W"], { P: "vehicle_plating", D: "minecraft:yellow_dye", S: "vehicle_seat", E: "vehicle_engine", W: "minecraft:black_wool" }],
     ["cc576", ["HGH", "SES", "PEP"], { H: "vehicle_propeller", G: "minecraft:glass", S: "vehicle_seat", E: "vehicle_engine", P: "vehicle_plating" }]
    ].forEach((r) => { try { shaped(r[0], r[1], r[2], r[0]); } catch (err) { RPG.log("[DMZ] vehicle recipe " + r[0] + ": " + err); } });

    // ---- the space pod's destinations (DMZSpacePodDestinationProvider) ----
    var DESTINATIONS = [
        { id: "overworld", dim: "minecraft:overworld", icon: 0, unlock: () => true },
        { id: "namek", dim: "ragnarok_rpg:namek", icon: 1, unlock: () => true },
        { id: "otherworld", dim: "ragnarok_rpg:otherworld", icon: 2, pos: [54, 210, 1082], unlock: (p) => questDone(p, "bulma_otherworld_drive") },
        { id: "sacredkaiplanet", dim: "ragnarok_rpg:sacredkaiplanet", icon: 3, unlock: (p) => questDone(p, "buu_saga:23") },
        { id: "time_chamber", dim: "ragnarok_rpg:time_chamber", icon: 2, pos: [0.5, 130, 0.5], unlock: (p) => questDone(p, "bulma_time_chamber_link") },
        { id: "demon_realm", dim: "ragnarok_rpg:demon_realm", icon: 6, pos: [160.5, 745, 0.5], unlock: (p) => questDone(p, "daima_saga:3") },
        // DMZ Ragnarok's own planet (always unlocked there); lands beside the Saiyan settlement spot
        { id: "planet_vegeta", dim: "ragnarok_rpg:planet_vegeta", icon: 0, pos: [155, 65, -75], unlock: () => true }
    ];
    function questDone(p, key) {
        try { return typeof DMZ_QUESTS !== "undefined" && DMZ_QUESTS.isCompleted(p, key); } catch (err) { return false; }
    }
    function openDestinations(p) {
        let pod = p.getVehicle();
        if (!pod || pod.getVehicleId() !== "spacepod") return;
        RPG.net.send(p, "dmz_spacepod", { list: DESTINATIONS.map((d) => ({ id: d.id, icon: d.icon, unlocked: !!d.unlock(p), here: d.dim === p.dimension })),
            space: typeof dbrSpaceAvailable === "function" && dbrSpaceAvailable() });
    }
    var LAST_TRAVEL = {};
    RPG.net.on("dmz_spacepod_travel", (p, d) => {
        let dest = DESTINATIONS.filter((x) => x.id === String(d && d.id))[0], pod = p.getVehicle();
        if (!dest || !pod || pod.getVehicleId() !== "spacepod" || !dest.unlock(p)) return;
        if (RPG.server.getTick() - (LAST_TRAVEL[p.uuid] || -100) < 20) return;           // rate limit 20 ticks
        LAST_TRAVEL[p.uuid] = RPG.server.getTick();
        // planets fly there through space (DMZ Ragnarok's pod autopilot) when the space dimension is loaded
        if (typeof dbrSpaceAutopilot === "function" && dbrSpaceAutopilot(p, dest.dim)) return;
        let x = dest.pos ? dest.pos[0] : p.x, y = dest.pos ? dest.pos[1] : p.y, z = dest.pos ? dest.pos[2] : p.z;
        p.dismount();
        // no fixed landing spot: arrive high above the same x/z and settle on the ground once that chunk has loaded
        // (planets have different heights: keeping your current height could drop you into the void)
        let settle = !dest.pos;
        if (settle) y = 200;
        let ok = p.teleportTo(dest.dim, x, y, z);
        if (ok === false || p.dimension !== dest.dim) {
            // that world isn't loaded (new dimensions need the world restarted once): keep the pod, stay inside
            p.mount(pod);
            ARRIVING[p.uuid] = true;
            p.actionbar("&cThe pod can't reach " + dest.id + " yet. Restart the world once so that planet loads.");
            RPG.log("[DBR] space pod: dimension " + dest.dim + " is not loaded (restart the world/server once after installing or updating)");
            return;
        }
        p.playSound(DMZ + "ui_nave_takeoff", 1, 1);
        pod.remove();
        let land = (tries) => {
            if (!p.alive || p.dimension !== dest.dim) return;
            if (settle) {
                let sy = RPG.world.isLoaded(dest.dim, Math.floor(x), Math.floor(z)) ? RPG.world.surfaceY(dest.dim, Math.floor(x), Math.floor(z)) : -9999;
                if (sy <= -9999 && tries < 40) { p.teleportTo(dest.dim, x, 200, z); RPG.schedule(2, () => land(tries + 1)); return; }
                p.teleportTo(dest.dim, x, (sy > -9999 ? sy : 100) + 0.2, z);
            }
            let np = RPG.world.spawnVehicle(dest.dim, "spacepod", p.x, p.y, p.z, p.yaw);
            if (np) { ARRIVING[p.uuid] = true; p.mount(np); p.playSound(DMZ + "ship_landing_open", 1, 1); }
        };
        RPG.schedule(2, () => land(0));
    });
})();
