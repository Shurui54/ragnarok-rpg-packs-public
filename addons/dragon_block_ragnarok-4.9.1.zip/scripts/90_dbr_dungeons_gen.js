// =====================================================================================
//  90_dbr_dungeons_gen.js - DMZ Ragnarok's Dungeons: floor generation
// =====================================================================================
//  DMZR's floor builder lived in its closed "Ragnarok Key"; this is an open re-implementation
//  built from what the public module ships and documents:
//   - DMZR's room templates, jigsaw pools and per-theme block palettes
//     (converted by a script into data/dbr_dungeons/: templates/*.json, pools.json, palettes/*.json)
//   - GridModel: rooms on a 16 x 16 cell grid, rotated about the origin with DMZR's anchor offset
//   - LayoutStyle: SPINE_AND_RIBS (prison: a main-corridor spine, ribs to dead ends, the exit at the
//     end), ROADS_AND_BUILDINGS (promenade: a road with doglegs and crossroads branches, buildings
//     and props along it), INSUFFERABLE_CRYPT (an enclosed labyrinth around a central boss room)
//   - rooms join only through authored doorways; the doorway jigsaws (bars, rubble, walls) close
//     every opening that does not lead to a neighbour; decoration jigsaws (cells, cages, corpses,
//     crates, spawner runes, chests) are expanded like vanilla jigsaws
//   - DungeonRoomLayout markers: spawner runes -> enemy spawners, chests -> crates (chestChancePercent),
//     barrels -> crates (barrelChancePercent), the spawn and exit rooms -> portals
//   - a theme-palette terrain disc (size x depth) and a barrier box around the floor
//   - BOSS floors: one standalone arena (the Insufferable Crypt boss room) holding the guardian
//  A floor is rolled and placed once (seeded from its number) and never re-rolled; /dungeon floor
//  regen re-stamps it.
// =====================================================================================
var DBRD_GEN = (function () {
    var C = DBRD_CFG, CELL = 16;
    var TPL = {}, POOLS = null, PALS = {};
    function template(path) {
        if (TPL[path] === undefined) TPL[path] = RPG.files.read("dbr_dungeons/templates/" + path + ".json") || null;
        return TPL[path];
    }
    function pools() { if (!POOLS) POOLS = RPG.files.read("dbr_dungeons/pools.json") || {}; return POOLS; }
    function palette(theme) {
        var k = DBRD.paletteFor(theme);
        if (!PALS[k]) PALS[k] = (RPG.files.read("dbr_dungeons/palettes/" + k + ".json") || {}).map || {};
        return PALS[k];
    }
    function pickWeighted(list, r) {
        var total = 0; list.forEach(function (e) { total += e[0]; });
        var x = r() * total, acc = 0;
        for (var i = 0; i < list.length; i++) { acc += list[i][0]; if (x < acc) return list[i]; }
        return list[list.length - 1];
    }
    function poolPick(name, r) {
        var p = pools()[name];
        if (!p || !p.length) return null;
        var e = pickWeighted(p, r);
        return e[1] ? { path: e[1], proc: e[2] || "" } : null;
    }

    // ---- block states: parse, palette, rotate --------------------------------------------
    function parse(s) {
        var b = s.indexOf("["), props = {};
        if (b < 0) return { id: s, props: props };
        s.substring(b + 1, s.lastIndexOf("]")).split(",").forEach(function (kv) { var e = kv.indexOf("="); if (e > 0) props[kv.substring(0, e)] = kv.substring(e + 1); });
        return { id: s.substring(0, b), props: props };
    }
    function str(id, props) {
        var keys = Object.keys(props);
        return keys.length ? id + "[" + keys.map(function (k) { return k + "=" + props[k]; }).join(",") + "]" : id;
    }
    var HDIR = ["north", "east", "south", "west"];
    function rotDir(d, r) { var i = HDIR.indexOf(d); return i < 0 ? d : HDIR[(i + r) % 4]; }
    function rotateProps(props, r) {
        if (!r) return props;
        var out = {}, k;
        for (k in props) out[k] = props[k];
        if (props.facing) out.facing = rotDir(props.facing, r);
        if (props.axis && r % 2) out.axis = props.axis === "x" ? "z" : props.axis === "z" ? "x" : props.axis;
        if (props.rotation !== undefined) out.rotation = String((Number(props.rotation) + 4 * r) % 16);
        if (props.north !== undefined || props.east !== undefined || props.south !== undefined || props.west !== undefined) {
            HDIR.forEach(function (d) { if (props[d] !== undefined) out[rotDir(d, r)] = props[d]; });
        }
        return out;
    }
    // DBR fallbacks for DragonMine Z blocks this addon lacks (by shape)
    function vanillaFor(x) {
        if (/_stairs$/.test(x)) return "minecraft:stone_brick_stairs";
        if (/_slab$/.test(x)) return "minecraft:stone_brick_slab";
        if (/_wall$/.test(x)) return "minecraft:stone_brick_wall";
        if (/_fence_gate$/.test(x)) return "minecraft:spruce_fence_gate";
        if (/_fence$/.test(x)) return "minecraft:spruce_fence";
        if (/_door$/.test(x)) return "minecraft:spruce_door";
        if (/_trapdoor$/.test(x)) return "minecraft:spruce_trapdoor";
        if (/_leaves$/.test(x)) return "minecraft:oak_leaves";
        if (/_log$/.test(x)) return "minecraft:spruce_log";
        if (/_planks$/.test(x)) return "minecraft:spruce_planks";
        if (/grass$/.test(x)) return "minecraft:short_grass";
        if (/dirt|grass_block/.test(x)) return "minecraft:dirt";
        if (/cloud/.test(x)) return "minecraft:white_wool";
        return "minecraft:stone_bricks";
    }
    function dmzBlock(x, props) {
        var name = x;
        if (/_door$/.test(x)) name = x + (props.half === "upper" ? "_top" : "") + (props.open === "true" ? "_open" : "");
        else if (/_slab$/.test(x) && props.type === "double") name = x + "_double";
        else if (/(_fence_gate|_trapdoor)$/.test(x) && props.open === "true") name = x + "_open";
        var id = typeof BLOCK_IDS !== "undefined" ? (BLOCK_IDS[name] || BLOCK_IDS[x]) : null;
        if (!id) return str(vanillaFor(x), props);
        var keep = {};
        if (props.facing) keep.facing = props.facing;
        return str("ragnarok_rpg:" + id, keep);
    }
    // a template palette entry -> the block placed for this theme, rotated
    function resolve(src, theme, r) {
        var st = parse(src), map = palette(theme);
        var target = map[st.id] !== undefined ? map[st.id] : st.id;
        if (target.indexOf("dbrd:") === 0) target = "minecraft:air";
        var props = rotateProps(st.props, r);
        var t = parse(target);
        for (var k in t.props) props[k] = t.props[k];
        if (t.id.indexOf("dragonminez:") === 0) return dmzBlock(t.id.substring(12), props);
        return str(t.id, props);
    }

    // ---- a block-list builder ------------------------------------------------------------
    function Builder(theme) {
        var palIndex = {}, pal = [], blocks = [], resolved = {};
        function idx(state) { var i = palIndex[state]; if (i === undefined) { i = palIndex[state] = pal.length; pal.push(state); } return i; }
        return {
            pal: pal, blocks: blocks,
            put: function (x, y, z, state) { blocks.push(x, y, z, idx(state)); },
            src: function (x, y, z, srcState, r) {
                var key = srcState + "#" + r, s = resolved[key];
                if (s === undefined) s = resolved[key] = resolve(srcState, theme, r);
                blocks.push(x, y, z, idx(s));
            }
        };
    }

    // ---- grid maths (GridModel) ----------------------------------------------------------
    function rot(x, z, r) {
        switch (r & 3) { case 1: return [-z, x]; case 2: return [-x, -z]; case 3: return [z, -x]; default: return [x, z]; }
    }
    function anchor(r, sx, sz) {
        switch (r & 3) { case 1: return [sz - 1, 0]; case 2: return [sx - 1, sz - 1]; case 3: return [0, sx - 1]; default: return [0, 0]; }
    }
    var FACES = ["n", "e", "s", "w"], FDX = { n: 0, e: 1, s: 0, w: -1 }, FDZ = { n: -1, e: 0, s: 1, w: 0 };
    function rotFace(f, r) { return FACES[(FACES.indexOf(f) + r) % 4]; }
    function opp(f) { return rotFace(f, 2); }
    function doorsOf(path, r) {
        var t = template(path), out = {};
        if (!t || !t.doors) return out;
        for (var f in t.doors) out[rotFace(f, r)] = true;
        return out;
    }
    function rotationFor(path, need) {                         // rotations whose world doors include every face in need
        var ok = [];
        for (var r = 0; r < 4; r++) {
            var d = doorsOf(path, r), good = true;
            need.forEach(function (f) { if (!d[f]) good = false; });
            if (good) ok.push(r);
        }
        return ok;
    }

    // ---- layouts -------------------------------------------------------------------------
    // a piece: {path, gx, gz, r, gy, role, proc}; cells: "gx,gz" -> piece
    function Layout(radius, r) {
        var pieces = [], cells = {};
        function key(x, z) { return x + "," + z; }
        function free(x, z) { return Math.abs(x) <= radius && Math.abs(z) <= radius && !cells[key(x, z)]; }
        function add(path, gx, gz, rr, role, proc) {
            var t = template(path);
            if (!t) return null;
            var w = Math.ceil(((rr % 2) ? t.size[2] : t.size[0]) / CELL), l = Math.ceil(((rr % 2) ? t.size[0] : t.size[2]) / CELL), i, j;
            for (i = 0; i < w; i++) for (j = 0; j < l; j++) if (!free(gx + i, gz + j)) return null;
            var p = { path: path, gx: gx, gz: gz, r: rr, gy: 0, role: role || "", proc: proc || "", w: w, l: l };
            for (i = 0; i < w; i++) for (j = 0; j < l; j++) cells[key(gx + i, gz + j)] = p;
            pieces.push(p);
            return p;
        }
        return { pieces: pieces, cells: cells, free: free, add: add, at: function (x, z) { return cells[key(x, z)] || null; }, radius: radius, r: r };
    }
    function pick(pool, r) { var e = poolPick(pool, r); return e ? e.path : null; }
    function procOf(pool, path) { var p = pools()[pool] || []; for (var i = 0; i < p.length; i++) if (p[i][1] === path) return p[i][2] || ""; return ""; }

    // place one room at (gx, gz) entered from face `from` (world face of the new room that touches the previous one)
    function attach(L, pool, gx, gz, need, role, r) {
        for (var tries = 0; tries < 6; tries++) {
            var path = pick(pool, r);
            if (!path) return null;
            var rots = rotationFor(path, need);
            if (!rots.length) continue;
            var rr = rots[Math.floor(r() * rots.length)];
            var p = L.add(path, gx, gz, rr, role, procOf(pool, path));
            if (p) return p;
        }
        return null;
    }

    // SPINE_AND_RIBS (PrisonGridGenerator): spine of main corridors from the spawn, ribs of corridors to dead ends
    function genPrison(L, r) {
        var spawn = L.add("prison/spawn", 0, 0, 0, "spawn");     // spawn's door faces south: the spine runs +z
        var len = Math.min(L.radius - 1, 4 + Math.floor(r() * 5)), z = 1, ribs = [];
        for (; z <= len; z++) {
            var p = attach(L, "prison/main_corridor", 0, z, ["n", "s"], "spine", r);
            if (!p) break;
            var d = doorsOf(p.path, p.r);
            if (d.e) ribs.push([0, z, "e"]);
            if (d.w) ribs.push([0, z, "w"]);
        }
        var exit = L.add("prison/end", 0, z, 0, "exit");          // prison/end's door is north: back up the spine
        if (!exit) { var last = L.at(0, z - 1); if (last) last.role = "exit"; }
        ribs.forEach(function (rb) {
            if (r() < 0.25) return;
            var f = rb[2], gx = rb[0], gz = rb[1], n = 1 + Math.floor(r() * 4), axis = [f === "e" || f === "w" ? "e" : "n", f === "e" || f === "w" ? "w" : "s"];
            for (var i = 0; i < n; i++) {
                gx += FDX[f]; gz += FDZ[f];
                if (!L.free(gx, gz)) return;
                var last = i === n - 1 || !L.free(gx + FDX[f], gz + FDZ[f]);
                if (last) { if (!attach(L, "prison/main_corridor_end", gx, gz, [opp(f)], "end", r)) attach(L, "prison/corridor", gx, gz, axis, "rib", r); return; }
                if (!attach(L, r() < 0.35 ? "prison/main_corridor" : "prison/corridor", gx, gz, axis, "rib", r)) return;
            }
        });
        return spawn;
    }

    // INSUFFERABLE_CRYPT: a tight labyrinth grown room by room from the spawn, the boss room at its far end
    function genCrypt(L, r) {
        var spawn = L.add("prison/spawn", 0, 0, 0, "spawn");
        var frontier = [[0, 1, "n", 1]], target = Math.min(14 + Math.floor(r() * 12), (2 * L.radius - 1) * (2 * L.radius - 1)), placed = 1, far = null;
        while (frontier.length && placed < target) {
            var i = Math.floor(r() * Math.min(frontier.length, 3)), f = frontier.splice(frontier.length - 1 - i, 1)[0];
            var gx = f[0], gz = f[1];
            if (!L.free(gx, gz)) continue;
            var p = attach(L, r() < 0.55 ? "prison/main_corridor" : "prison/corridor", gx, gz, [f[2]], "maze", r);
            if (!p) continue;
            p.depth = f[3]; placed++;
            if (!far || p.depth > far.depth) far = p;
            var d = doorsOf(p.path, p.r);
            FACES.forEach(function (face) { if (d[face] && face !== f[2]) frontier.push([gx + FDX[face], gz + FDZ[face], opp(face), f[3] + 1]); });
        }
        // the boss room (34 x 28: 3 x 2 cells) beside the deepest room, else the prison exit
        var bossPlaced = null;
        if (far) {
            var tries = [[1, 0], [-3, 0], [0, 1], [0, -2], [-1, 1], [-1, -2]];
            for (var t = 0; t < tries.length && !bossPlaced; t++) bossPlaced = L.add("insufferable_crypt/boss_room", far.gx + tries[t][0], far.gz + tries[t][1], 0, "exit");
        }
        if (!bossPlaced) {
            for (var k = 0; k < frontier.length && !bossPlaced; k++) if (L.free(frontier[k][0], frontier[k][1])) bossPlaced = attach(L, "prison/end", frontier[k][0], frontier[k][1], [frontier[k][2]], "exit", r);
            if (!bossPlaced && far) far.role = "exit";
        }
        // dead ends get caps
        frontier.forEach(function (f) { if (L.free(f[0], f[1]) && r() < 0.6) attach(L, "prison/main_corridor_end", f[0], f[1], [f[2]], "end", r); });
        return spawn;
    }

    // ROADS_AND_BUILDINGS (BetterPromenadeGridGenerator): a road with doglegs and crossroads branches
    var ROAD = { "promenade/path/straight": { n: 1, s: 1 }, "promenade/path/turn": { n: 1, e: 1 }, "promenade/path/crossroads": { n: 1, s: 1, e: 1 }, "promenade/path/half": { n: 1 } };
    function roadRot(kind, need) {
        var base = ROAD[kind], out = [];
        for (var rr = 0; rr < 4; rr++) {
            var d = {}; for (var f in base) d[rotFace(f, rr)] = 1;
            var ok = Object.keys(d).length === need.length;
            need.forEach(function (n) { if (!d[n]) ok = false; });
            if (ok) out.push(rr);
        }
        return out;
    }
    function roadPiece(L, kind, gx, gz, need, r) {
        var rots = roadRot(kind, need);
        if (!rots.length) return null;
        var path = kind === "promenade/path/straight" ? pick("promenade/path/straight", r) : kind === "promenade/path/turn" ? pick("promenade/path/turn", r) :
            kind === "promenade/path/crossroads" ? "promenade/path/crossroads" : "promenade/path/half";
        if (!template(path)) path = kind === "promenade/path/turn" ? "promenade/path/turn/0" : "promenade/path/straight/0";
        return L.add(path, gx, gz, rots[0], "road");
    }
    function genPromenade(L, r) {
        var spawn = L.add("promenade/spawn", 0, -1, 0, "spawn");
        var road = [], exitDone = false;
        function walk(gx, gz, dir, length, main) {
            for (var i = 0; i < length; i++) {
                if (!L.free(gx, gz)) return;
                var back = opp(dir), nx = gx + FDX[dir], nz = gz + FDZ[dir];
                var end = i === length - 1 || !L.free(nx, nz);
                if (end) {
                    if (main && !exitDone) {
                        var e = attach(L, "promenade/overground_end", gx, gz, [back], "exit", r);
                        if (e) { exitDone = true; return; }
                    }
                    roadPiece(L, "promenade/path/half", gx, gz, [back], r);
                    road.push([gx, gz]);
                    return;
                }
                var roll = r();
                if (roll < 0.18 && i > 1) {                            // dogleg
                    var turnTo = rotFace(dir, r() < 0.5 ? 1 : 3);
                    if (L.free(gx + FDX[turnTo], gz + FDZ[turnTo]) && roadPiece(L, "promenade/path/turn", gx, gz, [back, turnTo], r)) {
                        road.push([gx, gz]); dir = turnTo; gx += FDX[dir]; gz += FDZ[dir]; continue;
                    }
                } else if (roll < 0.32 && i > 1 && main) {             // crossroads with a branch
                    var side = rotFace(dir, r() < 0.5 ? 1 : 3);
                    if (roadPiece(L, "promenade/path/crossroads", gx, gz, [back, dir, side], r)) {
                        road.push([gx, gz]);
                        walk(gx + FDX[side], gz + FDZ[side], side, 3 + Math.floor(r() * 5), false);
                        gx = nx; gz = nz; continue;
                    }
                }
                roadPiece(L, "promenade/path/straight", gx, gz, [back, dir], r);
                road.push([gx, gz]);
                gx = nx; gz = nz;
            }
        }
        walk(0, 0, "s", Math.min(L.radius * 2 - 2, 12 + Math.floor(r() * 10)), true);
        if (!exitDone && road.length) L.at(road[road.length - 1][0], road[road.length - 1][1]).role = "exit";
        // buildings along the road, facing it; props on some empty lots
        road.forEach(function (c) {
            FACES.forEach(function (f) {
                var bx = c[0] + FDX[f], bz = c[1] + FDZ[f];
                if (!L.free(bx, bz)) return;
                var roll = r();
                if (roll < 0.45) {
                    var pool = r() < 0.6 ? "promenade/overground" : "promenade/path/building", path = pick(pool, r);
                    if (!path) return;
                    var rots = rotationFor(path, [opp(f)]);
                    var rr = rots.length ? rots[Math.floor(r() * rots.length)] : (FACES.indexOf(opp(f)) + 2) % 4;
                    L.add(path, bx, bz, rr, "building", procOf(pool, path));
                } else if (roll < 0.6) {
                    var deco = ["promenade/king_statue", "promenade/gallows", "promenade/chain_pile", "promenade/path/post/before_crossroads"][Math.floor(r() * 4)];
                    var dp = pick(deco, r) || deco;
                    if (template(dp)) L.add(dp, bx, bz, Math.floor(r() * 4), "prop");
                }
            });
        });
        return spawn;
    }

    // ---- jigsaw expansion (decorations, doorways) -----------------------------------------
    var VEC = { north: [0, 0, -1], south: [0, 0, 1], east: [1, 0, 0], west: [-1, 0, 0], up: [0, 1, 0], down: [0, -1, 0] };
    function vrot(dir, r) { return (dir === "up" || dir === "down") ? dir : rotDir(dir, r); }
    function oppDir(d) { return { north: "south", south: "north", east: "west", west: "east", up: "down", down: "up" }[d]; }
    function orient(o) { var s = String(o).split("_"); return { front: s[0], top: s[1] || "up" }; }

    // world position of a local block in a placed piece
    function placeAt(piece, lx, ly, lz, t) {
        var rr = rot(lx, lz, piece.r);
        if (piece.grid) { var a = anchor(piece.r, t.size[0], t.size[2]); return [piece.ox + rr[0] + a[0], piece.oy + ly, piece.oz + rr[1] + a[1]]; }
        return [piece.ox + rr[0], piece.oy + ly, piece.oz + rr[1]];
    }
    function boundaryFace(t, x, z) {
        if (z === 0) return "n"; if (z === t.size[2] - 1) return "s"; if (x === 0) return "w"; if (x === t.size[0] - 1) return "e"; return null;
    }
    function emitPiece(B, piece, theme, r, out, depth, L) {
        var t = template(piece.path);
        if (!t) return;
        var bl = t.blocks, pal = t.palette, decay = piece.proc === "brick_decay";
        for (var i = 0; i + 3 < bl.length; i += 4) {
            var w = placeAt(piece, bl[i], bl[i + 1], bl[i + 2], t), s = pal[bl[i + 3]];
            if (decay && r() < 0.15) s = s.replace("dbrd:prison_bricks", "dbrd:cracked_prison_bricks").replace("dbrd:prison_brick_stairs", "dbrd:cracked_prison_brick_stairs");
            B.src(w[0], w[1], w[2], s, piece.r);
        }
        (t.runes || []).forEach(function (q) { out.runes.push(placeAt(piece, q[0], q[1], q[2], t)); });
        (t.jigsaws || []).forEach(function (j) {
            var pw = placeAt(piece, j[0], j[1], j[2], t), o = orient(j[3]), pool = j[4].replace(/^dbrd:/, "");
            var front = vrot(o.front, piece.r), top = vrot(o.top, piece.r);
            var finalState = function () { B.src(pw[0], pw[1], pw[2], j[7], piece.r); };
            if (j[4] === "minecraft:empty" || depth > 4) { finalState(); return; }
            // doorway caps only on openings that lead nowhere
            if (/doorway|corridor_hole/.test(pool) && piece.grid && L) {
                var bf = boundaryFace(t, j[0], j[2]);
                if (bf) {
                    var wf = rotFace(bf, piece.r), nb = L.at(piece.cgx + FDX[wf], piece.cgz + FDZ[wf]);
                    if (nb && nb !== piece.cell && doorsOf(nb.path, nb.r)[opp(wf)]) { finalState(); return; }
                }
            }
            var child = poolPick(pool, r);
            finalState();
            if (!child) return;
            var ct = template(child.path);
            if (!ct || !ct.jigsaws) return;
            var cands = ct.jigsaws.filter(function (cj) { return cj[5] === j[6]; });
            if (!cands.length) return;
            var cj = cands[Math.floor(r() * cands.length)], co = orient(cj[3]), want = oppDir(front);
            var rots = [];
            for (var s = 0; s < 4; s++) {
                if (vrot(co.front, s) !== want) continue;
                if ((front === "up" || front === "down") && vrot(co.top, s) !== top) continue;
                rots.push(s);
            }
            if (!rots.length) return;
            var cr = rots[Math.floor(r() * rots.length)], cq = rot(cj[0], cj[2], cr), v = VEC[front];
            var cp = { path: child.path, r: cr, ox: pw[0] + v[0] - cq[0], oy: pw[1] + v[1] - cj[1], oz: pw[2] + v[2] - cq[1], proc: child.proc, grid: false };
            emitPiece(B, cp, theme, r, out, depth + 1, L);
        });
    }

    // ---- placement helpers ---------------------------------------------------------------
    function chain(tasks, onProgress, done) {
        var i = 0, total = tasks.length;
        function next() {
            if (i >= total) { done(true); return; }
            var job = tasks[i++];
            try {
                var t = job();
                if (onProgress) onProgress(i / total);
                if (t && t.then) t.then(function (res) { if (res && res.error) RPG.log("[dungeons] edit error: " + res.error); RPG.schedule(1, next); });
                else RPG.schedule(1, next);
            } catch (e) { RPG.log("[dungeons] build step failed: " + e); done(false); }
        }
        next();
    }
    function solid(dim, x, y, z) { var b = RPG.world.getBlock(dim, x, y, z); return b && !/air$|barrier|light$|water|lava|torch|vine|cobweb|chain|ladder|banner|sign|carpet|pressure_plate|flower|grass$|fern/.test(b); }
    function clear(dim, x, y, z) { var b = RPG.world.getBlock(dim, x, y, z); return !b || /air$|light$|torch|vine|cobweb|carpet|pressure_plate|banner|grass$/.test(b); }
    // the first spot from y downwards with solid ground and two clear blocks above
    function findFloor(dim, x, y, z, minY) {
        for (var yy = y; yy > minY; yy--) if (solid(dim, x, yy - 1, z) && clear(dim, x, yy, z) && clear(dim, x, yy + 1, z)) return yy;
        return null;
    }
    function findStand(dim, cx, top, cz, minY) {
        var off = [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [2, 2], [-2, -2], [2, -2], [-2, 2], [3, 0], [-3, 0], [0, 3], [0, -3]];
        for (var i = 0; i < off.length; i++) { var y = findFloor(dim, cx + off[i][0], top, cz + off[i][1], minY); if (y !== null) return { x: cx + off[i][0], y: y, z: cz + off[i][1] }; }
        return { x: cx, y: top, z: cz };
    }

    // ---- the build -----------------------------------------------------------------------
    function build(n, f, style, epoch, onProgress, onDone) {
        var dim = DBRD.dimFor(f.theme), c = DBRD.cellCentre(n, epoch), seed = DBRD.floorSeed(n) ^ (epoch * 7919), r = DBRD.rng(seed);
        var size = f.size, depth = f.depth, surface = DBRD.SURFACE_Y, half = Math.floor(size / 2);
        var boss = f.type === "BOSS", theme = f.theme;
        var L = Layout(Math.max(2, Math.floor(half / CELL) - 1), r), spawn;
        if (boss) spawn = L.add("insufferable_crypt/boss_room", -1, -1, 0, "arena");
        else if (style === "ROADS_AND_BUILDINGS") spawn = genPromenade(L, r);
        else if (style === "INSUFFERABLE_CRYPT") spawn = genCrypt(L, r);
        else spawn = genPrison(L, r);
        var B = Builder(theme), out = { runes: [] };
        var oy = surface - 1;
        L.pieces.forEach(function (p) { p.grid = true; p.ox = c.x + p.gx * CELL; p.oy = oy + p.gy * CELL; p.oz = c.z + p.gz * CELL; p.cgx = p.gx; p.cgz = p.gz; p.cell = p; });
        // rooms are turned into blocks a few at a time (keeps every tick well under the script budget)
        var next = 0;
        (function emitStep() {
            var t0 = Date.now();
            try { while (next < L.pieces.length && Date.now() - t0 < 12) emitPiece(B, L.pieces[next++], theme, r, out, 0, L); }
            catch (e) { RPG.log("[dungeons] floor " + n + " room " + next + " failed: " + e); onDone(null); return; }
            if (onProgress) onProgress(0.05 * next / Math.max(1, L.pieces.length));
            if (next < L.pieces.length) { RPG.schedule(1, emitStep); return; }
            RPG.schedule(1, function () { place(n, f, dim, c, L, spawn, out, B, theme, size, depth, surface, half, boss, onProgress, onDone); });
        })();
    }
    function place(n, f, dim, c, L, spawn, out, B, theme, size, depth, surface, half, boss, onProgress, onDone) {
        // ground blocks for this theme
        var top = resolve("minecraft:grass_block", theme, 0), mid = resolve("minecraft:dirt", theme, 0), body = resolve("minecraft:stone", theme, 0);
        if (/air$/.test(top)) top = "minecraft:grass_block"; if (/air$/.test(mid)) mid = "minecraft:dirt"; if (/air$/.test(body)) body = "minecraft:stone";
        var maxH = 24;
        L.pieces.forEach(function (p) { var t = template(p.path); if (t) maxH = Math.max(maxH, t.size[1]); });
        var R = half, roof = surface + maxH + 8, per = C.get("dungeonRoomBlocksPerTick") * 4;
        var tasks = [];
        tasks.push(function () { return RPG.edit.set(null, dim, { type: "cylinder", x: c.x, y: surface - depth, z: c.z, r: R, h: depth - 4 }, body, { progress: false, history: false }); });
        tasks.push(function () { return RPG.edit.set(null, dim, { type: "cylinder", x: c.x, y: surface - 4, z: c.z, r: R, h: 3 }, mid, { progress: false, history: false }); });
        tasks.push(function () { return RPG.edit.set(null, dim, { type: "cylinder", x: c.x, y: surface - 1, z: c.z, r: R, h: 1 }, top, { progress: false, history: false }); });
        tasks.push(function () { return RPG.edit.set(null, dim, { type: "walls", x1: c.x - R - 2, y1: surface - depth - 1, z1: c.z - R - 2, x2: c.x + R + 2, y2: roof, z2: c.z + R + 2 }, "minecraft:barrier", { progress: false, history: false }); });
        tasks.push(function () { return RPG.edit.set(null, dim, { type: "cuboid", x1: c.x - R - 2, y1: roof, z1: c.z - R - 2, x2: c.x + R + 2, y2: roof, z2: c.z + R + 2 }, "minecraft:barrier", { progress: false, history: false }); });
        for (var s = 0; s < B.blocks.length; s += per) {
            (function (from) {
                tasks.push(function () { return RPG.edit.place(null, dim, { palette: B.pal, blocks: B.blocks.slice(from, from + per) }, { progress: false, history: false }); });
            })(s);
        }
        // markers: chests / barrels the rooms placed -> crate candidates
        var chests = [], barrels = [];
        for (var i = 0; i + 3 < B.blocks.length; i += 4) {
            var st = B.pal[B.blocks[i + 3]];
            if (st.indexOf("minecraft:chest") === 0) chests.push([B.blocks[i], B.blocks[i + 1], B.blocks[i + 2]]);
            else if (st.indexOf("minecraft:barrel") === 0) barrels.push([B.blocks[i], B.blocks[i + 1], B.blocks[i + 2]]);
        }
        chain(tasks, onProgress ? function (x) { onProgress(0.05 + 0.95 * x); } : null, function (ok) {
            if (!ok) { onDone(null); return; }
            RPG.schedule(10, function () {
                try { onDone(finish(n, f, dim, c, L, spawn, out, chests, barrels, surface, maxH, boss)); }
                catch (e) { RPG.log("[dungeons] finishing floor " + n + " failed: " + e); onDone(null); }
            });
        });
    }
    function pieceCentre(p) { var t = template(p.path); var w = (p.r % 2 ? t.size[2] : t.size[0]), l = (p.r % 2 ? t.size[0] : t.size[2]); return [p.ox + Math.floor(w / 2), p.oz + Math.floor(l / 2), t.size[1]]; }
    function finish(n, f, dim, c, L, spawn, out, chests, barrels, surface, maxH, boss) {
        var lay = { dim: dim, centre: c, size: f.size, theme: f.theme, type: f.type, spawners: [], crates: [], pieces: L.pieces.length };
        var minY = surface - 6;
        var sc = spawn ? pieceCentre(spawn) : [c.x, c.z, 10];
        if (boss && spawn) {
            // the arena: the player comes in at the doorway side, the guardian waits in the middle
            var t = template(spawn.path), ent = placeAt(spawn, 30, 2, 6, t);
            var st = findStand(dim, ent[0], surface + 8, ent[2], minY);
            lay.spawn = { x: st.x, y: st.y, z: st.z, yaw: 90 };
            var g = findStand(dim, sc[0], surface + 12, sc[1], minY);
            lay.boss = { x: g.x, y: g.y, z: g.z };
            var ex = findStand(dim, ent[0] - 2, surface + 8, ent[2] + 4, minY);
            lay.exit = { x: ex.x, y: ex.y, z: ex.z };
        } else {
            var s2 = findStand(dim, sc[0], surface + 3, sc[1], minY);
            lay.spawn = { x: s2.x, y: s2.y, z: s2.z, yaw: 0 };
            var exitP = null;
            L.pieces.forEach(function (p) { if (p.role === "exit") exitP = p; });
            if (exitP) { var ec = pieceCentre(exitP); var e2 = findStand(dim, ec[0], surface + 3, ec[1], minY); lay.exit = { x: e2.x, y: e2.y, z: e2.z }; }
        }
        if (C.get("dbr.autoPortals") && typeof DBRD_LOOT !== "undefined") {
            var pb = DBRD_LOOT.portalBlock();
            var rp = findStand(dim, lay.spawn.x + 2, lay.spawn.y + 1, lay.spawn.z + 2, minY);
            // portals sit in the floor: stepping on one uses it
            RPG.world.setBlock(dim, rp.x, rp.y - 1, rp.z, pb); DBRD_CORE.setPortal(dim, rp.x, rp.y - 1, rp.z, { kind: "exit" }); lay.returnPortal = { x: rp.x, y: rp.y - 1, z: rp.z };
            if (lay.exit) {
                RPG.world.setBlock(dim, lay.exit.x, lay.exit.y - 1, lay.exit.z, pb);
                DBRD_CORE.setPortal(dim, lay.exit.x, lay.exit.y - 1, lay.exit.z, { kind: "next", bosslock: boss });
                lay.exitPortal = { x: lay.exit.x, y: lay.exit.y - 1, z: lay.exit.z };
            }
        }
        // enemy spawners under the runes, crates where DMZR converted chests and a share of the barrels
        out.runes.forEach(function (q) { lay.spawners.push({ x: q[0], y: q[1], z: q[2] }); });
        var loot = f.crateLoot;
        chests.forEach(function (q) { if (DBRD.chestSelected(DBRD.posKey(q[0], q[1], q[2]), loot.chestChancePercent)) lay.crates.push({ x: q[0], y: q[1], z: q[2], kind: "chest" }); });
        barrels.forEach(function (q) { if (DBRD.barrelSelected(DBRD.posKey(q[0], q[1], q[2]), loot.barrelChancePercent)) lay.crates.push({ x: q[0], y: q[1], z: q[2], kind: "barrel" }); });
        lay.crates.forEach(function (q) { RPG.world.setBlock(dim, q.x, q.y, q.z, "minecraft:air"); });
        return lay;
    }

    // the Dungeon Gate: DMZR's overworld_portal structure with a gate portal in its doorway
    function placeGate(p) {
        var t = template("overworld_portal");
        if (!t) return;
        var yaw = ((Math.round(p.yaw / 90) % 4) + 4) % 4, rr = (yaw + 2) % 4;
        var B = Builder("OVERWORLD"), ox = Math.floor(p.x), oy = Math.floor(p.y), oz = Math.floor(p.z);
        var piece = { path: "overworld_portal", r: rr, ox: ox, oy: oy, oz: oz, grid: false, proc: "" };
        var doorway = [];
        for (var i = 0; i + 3 < t.blocks.length; i += 4) {
            var s = t.palette[t.blocks[i + 3]], w = placeAt(piece, t.blocks[i], t.blocks[i + 1], t.blocks[i + 2], t);
            if (/dbrd:(prison|overworld)_doorway/.test(s)) doorway.push(w);
            B.src(w[0], w[1], w[2], s, rr);
        }
        RPG.edit.place(p, p.dimension, { palette: B.pal, blocks: B.blocks }, { label: "Dungeon Gate" }).then(function () {
            var pb = DBRD_LOOT.portalBlock();
            if (!doorway.length) { var c = placeAt(piece, 6, 1, 5, t); doorway.push(c); }
            // the doorway itself becomes the portal: right-click it (or walk into it) to pick a floor
            doorway.forEach(function (w) {
                RPG.world.setBlock(p.dimension, w[0], w[1], w[2], pb);
                DBRD_CORE.setPortal(p.dimension, w[0], w[1], w[2], { kind: "gate" });
            });
            p.tell("&aDungeon Gate placed. Players right-click its doorway to pick a floor.");
        });
    }

    return { build: build, placeGate: placeGate, template: template, findStand: findStand };
})();
