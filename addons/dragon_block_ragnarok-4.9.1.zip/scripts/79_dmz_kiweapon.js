// =====================================================================================
//  79_dmz_kiweapon.js - DMZ's Ki Weapons (Ki Manipulation) and Friendly Fist (Ki Control)
// =====================================================================================
//  Ki weapons (SelectKiWeaponC2S, PlayerAttackHelper, CombatEvent, DMZWeaponsLayer):
//    - the X radial menu's Ki Weapons node (needs the Ki Manipulation and Ki Control skills) sends
//      "kiweapon" <blade|clawlance|scythe> -> select(): picks that weapon and switches the
//      kimanipulation skill on; picking the active weapon again switches it off.
//    - while it is on and the main hand is EMPTY: the weapon is drawn on the right arm in the ki colour
//      (the active form's aura colour, else the player's aura), punches swing the weapon's combo
//      (sword / scythe / trident, client/scripts/42_combat.js), the attack speed drops (blade -2.4,
//      scythe -2.8, claw lance -2.6) and every hit costs ki and adds
//      baseDamage + kiDamage x kiScalingDamage x (Ki Manipulation level x 0.1) when you have the ki
//      (09_dmz_stats.js calls meleeBonus). Table: DMZ_COMBAT.KI_WEAPONS (shared/04_dmz_combat.js).
//  Friendly Fist (ExecuteActionC2S TOGGLE_FRIENDLY_FIST, CombatEvent): needs Ki Control. While on, your
//    hits never kill a player: a hit that would leaves them on 1 HP, knocked down (30 s, can't be hurt,
//    forms dropped), and you can't hit players who are already knocked down.
//
//  Vars / looks:  dmz_kiweapon "blade"   dmz_skill_active.kimanipulation   dmz_friendly_fist 0|1
//                 look kiWeapon (type while drawn, else "")   look kiWeaponColor   shared "pose" (stance)
// =====================================================================================
var DMZ_KIWEAPON = (function () {
    var KW = DMZ_COMBAT.KI_WEAPONS, ORDER = DMZ_COMBAT.KI_WEAPON_ORDER;
    var BASELINE_DRAIN = (typeof DMZ_FORMS !== "undefined" && DMZ_FORMS.D && DMZ_FORMS.D.baselineDrain) || 80;   // CombatConfig.baselineFormDrain
    var KNOCKDOWN_TICKS = 30 * 20;                                                                                 // CombatConfig.knockdownDurationSeconds

    function created(p) { return !!p.getVar("dmz_created", 0); }
    function creative(p) { var g = String(p.getGameMode()); return g === "creative" || g === "spectator"; }
    function owned(p, s) { return typeof DMZ_SKILLS !== "undefined" && DMZ_SKILLS.owned(p, s); }
    function level(p, s) { return typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS.level(p, s) : 0; }
    function activeMap(p) { var m = p.getVar("dmz_skill_active", null); return m && typeof m === "object" ? m : {}; }
    function manipulating(p) { return !!activeMap(p).kimanipulation; }
    function setManipulating(p, on) {
        var m = activeMap(p), out = {};
        for (var k in m) out[k] = m[k];
        if (on) out.kimanipulation = true; else delete out.kimanipulation;
        p.setVar("dmz_skill_active", out);
    }
    function emptyHand(p) { var h = p.getHeldStack(); return !h || h.id === "minecraft:air"; }
    function type(p) { var t = String(p.getVar("dmz_kiweapon", "") || "").toLowerCase(); return KW[t] ? t : ORDER[0]; }

    /** PlayerAttackHelper.isKiWeaponActive: the skill on and nothing in the main hand -> the weapon type, else null. */
    function activeType(p) { return created(p) && manipulating(p) && emptyHand(p) ? type(p) : null; }

    // ---- attack speed while a weapon is out (StatsEvents: KI_WEAPON_ATTACK_SPEED_UUID, ADDITION) ----
    ORDER.forEach(function (k) {
        RPG.effects.define("dmz_kiweapon_" + k, { name: "Ki Weapon", hidden: true, keepOnDeath: false,
            attributes: { "minecraft:generic.attack_speed": { amount: KW[k].attackSpeed, operation: "add" } } });
    });

    /** KiWeaponHelper.resolveColorForType + DMZWeaponsLayer.getKiColor. */
    function colorOf(p, t) {
        var forced = String(KW[t].forcedColor || "").replace("#", "");
        if (/^[0-9a-fA-F]{6}$/.test(forced) && forced.toUpperCase() !== "FFFFFF") return "#" + forced;
        var f = typeof DMZ_TF !== "undefined" ? DMZ_TF.activeForm(p) : null;
        return (f && f.aura) || p.getColor("aura") || "#7FFFFF";
    }

    function sync(p) {
        var t = activeType(p) || "";
        if (String(p.getColor("kiWeapon") || "") !== t) p.setColor("kiWeapon", t);
        if (t) { var c = colorOf(p, t); if (String(p.getColor("kiWeaponColor") || "") !== c) p.setColor("kiWeaponColor", c); }
        ORDER.forEach(function (k) {
            var id = "dmz_kiweapon_" + k;
            if (k === t) { if (!p.hasEffect(id)) p.addEffect(id, -1); }
            else if (p.hasEffect(id)) p.removeEffect(id);
        });
        var pose = t && KW[t].pose ? KW[t].pose : null;                    // the scythe / claw lance stance
        if ((p.getShared("pose", null) || null) !== pose) p.setShared("pose", pose);
    }

    /** SelectKiWeaponC2S. */
    function select(p, t) {
        t = String(t || "").toLowerCase();
        if (p.hasEffect("stunned") || !owned(p, "kimanipulation") || !KW[t]) return;
        var on = manipulating(p), cur = String(p.getVar("dmz_kiweapon", "") || "").toLowerCase();
        if (on && cur === t) setManipulating(p, false);
        else {
            p.setVar("dmz_kiweapon", t);
            if (!on) setManipulating(p, true);
        }
        sync(p);
    }

    /** CombatEvent: the ki weapon's bonus for one bare-handed hit (v = dmzView(p)); spends the ki. */
    function meleeBonus(p, v) {
        var t = activeType(p);
        if (!t) return 0;
        var c = KW[t], cost = Math.round(c.baseKiCost + BASELINE_DRAIN * c.kiScalingCost), bonus = 0;
        if (p.resource("ki") >= cost) bonus = c.baseDamage + DMZ_F.ki(v) * c.kiScalingDamage * (level(p, "kimanipulation") * 0.1);
        if (!creative(p)) p.addResource("ki", -Math.min(cost, p.resource("ki")));
        return bonus;
    }

    // ---- Friendly Fist ------------------------------------------------------------------
    function friendly(p) { return Number(p.getVar("dmz_friendly_fist", 0)) === 1; }
    function toggleFriendlyFist(p) {
        if (!owned(p, "kicontrol")) return;
        p.setVar("dmz_friendly_fist", friendly(p) ? 0 : 1);
    }

    // knocked down: on the ground, can't act, can't be hurt (KNOCKDOWN_DURATION + KNOCKDOWN_INVULN);
    // 12_anim_state.js shares "down" for the faint pose
    RPG.effects.define("knocked_down", { name: "&cKnocked Down", color: "#AA0000", hidden: true, beneficial: false, keepOnDeath: false,
        flags: ["noMove", "noJump", "noAttack", "noSkills", "invulnerable"] });

    function knockDown(p) {
        p.addEffect("knocked_down", KNOCKDOWN_TICKS);
        if (typeof DMZ_TF !== "undefined") {                               // clearActiveForm + clearActiveStackForm
            if (p.getVar("dmz_stack", "")) DMZ_TF.setStack(p, null, null);
            if (p.getVar("dmz_form", "")) DMZ_TF.setForm(p, null, null);
        }
    }

    function attackerPlayer(e) { return e.attacker && e.attacker.isPlayer() ? e.attacker.asPlayer() : null; }

    // a friendly-fist attacker can't hit a player who is down
    RPG.on("damageFinal", function (e) {
        var a = attackerPlayer(e), t = e.target;
        if (!a || !t || !t.isPlayer() || e.isCancelled()) return;
        if (t.asPlayer().hasEffect("knocked_down") && friendly(a)) e.cancel();
    });

    // the hit that would kill leaves them on 1 HP, knocked down (after Zenkai, world bosses, Baba... had their say)
    RPG.on("lethal", function (e) {
        var a = attackerPlayer(e), t = e.target;
        if (!a || !t || !t.isPlayer() || e.isCancelled() || a.uuid === t.uuid || !friendly(a)) return;
        if (e.type === "minecraft:out_of_world" || e.type === "minecraft:generic_kill") return;
        var p = t.asPlayer();
        e.amount = Math.max(0, p.health - 1);
        knockDown(p);
    });

    // ---- keep the looks in step (main hand, form aura) ----------------------------------
    RPG.every(4, function () { RPG.server.players().forEach(sync); });
    RPG.on("playerJoin", function (p) {
        if (!p.getVar("dmz_kiweapon", "")) p.setVar("dmz_kiweapon", ORDER[0]);      // Status default "blade"
        RPG.schedule(5, function () { sync(p); });
    });

    /** Radial menu hook (62_dmz_radial.js). */
    function radial(p, node, value) {
        if (node === "kiweapon") { select(p, value); return true; }
        if (node === "friendly_fist") { toggleFriendlyFist(p); return true; }
        return false;
    }

    return { select: select, selectKiWeapon: select, activeType: activeType, meleeBonus: meleeBonus, sync: sync,
        toggleFriendlyFist: toggleFriendlyFist, friendly: friendly, knockDown: knockDown, radial: radial };
})();
