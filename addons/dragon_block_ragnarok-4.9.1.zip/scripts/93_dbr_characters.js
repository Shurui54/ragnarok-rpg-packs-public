// =====================================================================================
//  93_dbr_characters.js - Character slots: several DMZ characters per player
// =====================================================================================
//  Port of DMZ Ragnarok's character slots (GPL-3.0, shuruisutilities character/:
//  CharacterSlots, CommandCharacter, CharacterCombatTracker, CharacterPersistence,
//  PacketCharacterGui / PacketCharacterAction, TournamentCharBridge, PlayerPositionSanitizer
//  and client/CharacterSelectScreen).
//
//  What a slot holds (DMZR's capture()): the whole DMZ character - race, class, look, stats,
//  TP, skills, techniques, forms and mastery, quests and sagas, Z-Soul bank, super wishes -
//  plus the inventory with armour and offhand, the accessory slots (Z-Souls...), XP, food
//  and effects. The ender chest is shared on purpose, and so are the things that belong to
//  the person rather than a character: the slot list itself, prestige rewards, the
//  tournament character and where they are (space, dungeons, homes).
//
//  How it is stored: the active character IS the live player; every other character is an
//  engine player profile ("dbr_char_<id>", player.swapProfile). A switch captures the live
//  player completely before anything is applied, rolls back if applying fails, and happens
//  in one tick inside the player's own save, so a crash can never leave half a switch.
//  Each character exists exactly once (live or stored), so nothing can be duplicated.
//  Profiles and the slot list live in the player data, which survives death and relogs.
//
//  Commands: /character (/char, /characters) [list | switch <n> | new [name] | rename <n> <name>
//            | delete <n>]   ops: /character admin <player> [setslots <n> | restoredeleted]
//  Settings (/character settings, ops): default slots (DMZR su.character.slots = 1), swap
//  cooldown (600 s), combat lock (120 s). More slots: the permission node
//  dbr.character.slots.<n>, an admin grant, or prestige (one slot per prestige level reached).
//  Player var: dbr_chars {v, active, seq, slots: [{id, name, prestige, ...}], last, granted, at}
// =====================================================================================
var DBR_CHARS = (function () {
    var V = "dbr_chars", PREFIX = "dbr_char_", TRASH = "dbr_char_trash", K_SET = "dbr_chars_settings";
    var HARD_CAP = 20;
    var DEFAULTS = { slots: 1, cooldown: 600, combatLock: 120 };
    // vars that stay with the person across characters (engine ProfileOptions.keepVars)
    var KEEP = ["dbr_chars", "dbr_prestige*", "dbr_tchar*", "dbr_tourney_*", "dbr_space_*", "dbr_surface*", "dbr_visited_*", "dbrd_*",
        "travel_return", "dmz_home", "dmz_aura3d_pref", "dmz_in_kaio_planet", "dmz_wb_truce", "dbr_floor_backup*"];
    var LAST_COMBAT = {};       // uuid -> ms (CharacterCombatTracker)

    function uid(p) { return String(p.uuid); }
    function log(s) { RPG.log("[Characters] " + s); }
    function list(v) {
        var o = [];
        if (!v || typeof v === "string") return o;
        if (typeof v.length === "number") { for (var i = 0; i < v.length; i++) o.push(v[i]); return o; }
        if (typeof v.size === "function") for (var j = 0; j < v.size(); j++) o.push(v.get(j));
        return o;
    }
    function engineOk(p) { return typeof p.swapProfile === "function"; }
    function opts() { return { keepVars: KEEP }; }

    // ---- settings (perm GUI "Values" in DMZR; here world data, edited by ops) ----------------
    function settings() {
        var s = RPG.data.get(K_SET, null), o = {};
        Object.keys(DEFAULTS).forEach(function (k) { o[k] = s && typeof s[k] === "number" ? s[k] : DEFAULTS[k]; });
        return o;
    }
    function setSetting(k, v) {
        var s = settings();
        s[k] = Math.max(0, Math.floor(Number(v) || 0));
        if (k === "slots") s[k] = Math.max(1, Math.min(HARD_CAP, s[k]));
        RPG.data.set(K_SET, s);
    }

    // ---- the slot list ------------------------------------------------------------------------
    function root(p) {
        var r = p.getVar(V, null);
        if (r && typeof r === "object" && r.slots && list(r.slots).length) { r.slots = list(r.slots); return r; }
        // first use: slot 1 is the character the player already has
        r = { v: 1, active: "c1", seq: 1, slots: [{ id: "c1", name: "Main", prestige: 0 }], last: 0, granted: 0, at: Date.now(),
            existed: p.getVar("dmz_created", 0) ? 1 : 0 };
        p.setVar(V, r);
        return r;
    }
    function save(p, r) { p.setVar(V, r); }
    function slotIndex(r, id) { for (var i = 0; i < r.slots.length; i++) if (r.slots[i].id === id) return i; return -1; }
    function activeSlot(p) { var r = root(p), i = slotIndex(r, r.active); return i < 0 ? r.slots[0] : r.slots[i]; }
    function activeIndex(p) { var r = root(p); return Math.max(0, slotIndex(r, r.active)); }

    // ---- per-slot prestige (stored on the slot entry, so it never travels in a snapshot) ----------
    function getActivePrestige(p) { return Math.max(0, Math.floor(Number(activeSlot(p).prestige) || 0)); }
    function setActivePrestige(p, lvl) {
        var r = root(p), i = slotIndex(r, r.active);
        if (i < 0) return;
        r.slots[i].prestige = Math.max(0, Math.floor(lvl));
        save(p, r);
    }
    function highestPrestige(p) {
        var r = p.getVar(V, null), m = 0;
        if (!r || !r.slots) return 0;
        list(r.slots).forEach(function (s) { m = Math.max(m, Math.floor(Number(s.prestige) || 0)); });
        return m;
    }

    // ---- slot count (CommandCharacter.maxSlots + PrestigeLedger.slotsRaw) -------------------------
    function permSlots(p) {
        for (var n = HARD_CAP; n > 1; n--) { try { if (RPG.perms.has(p, "dbr.character.slots." + n)) return n; } catch (e) { return 0; } }
        return 0;
    }
    function maxSlots(p) {
        var r = root(p), n = settings().slots;
        n = Math.max(n, permSlots(p), Math.floor(Number(r.granted) || 0));
        // one slot plus one per prestige level reached (the reward ledger keeps paid levels after a reset / delete)
        var ledger = typeof DBR_PRESTIGE !== "undefined" ? DBR_PRESTIGE.ledger(p) : 0;
        n = Math.max(n, 1 + Math.max(highestPrestige(p), ledger));
        return Math.max(1, Math.min(HARD_CAP, n));
    }

    // ---- combat lock (CharacterCombatTracker) -----------------------------------------------------
    RPG.on("damageFinal", function (e) {
        if (!e || e.amount <= 0) return;
        var a = e.attacker, t = e.target;
        if (!a || !t || a === t) return;
        try { if (String(a.uuid) === String(t.uuid)) return; } catch (err) { return; }
        if (t.isPlayer()) LAST_COMBAT[String(t.uuid)] = Date.now();
        if (a.isPlayer()) LAST_COMBAT[String(a.uuid)] = Date.now();
    });
    RPG.on("death", function (p) { delete LAST_COMBAT[uid(p)]; });
    RPG.on("playerLeave", function (p) { delete LAST_COMBAT[uid(p)]; });
    function combatLeft(p) {
        var lock = settings().combatLock, last = LAST_COMBAT[uid(p)];
        if (lock <= 0 || !last) return 0;
        return Math.max(0, last + lock * 1000 - Date.now());
    }
    function fmt(ms) {
        var s = Math.ceil(ms / 1000), m = Math.floor(s / 60);
        s %= 60;
        return m > 0 ? m + "m " + (s < 10 ? "0" : "") + s + "s" : s + "s";
    }

    // ---- when a character can't be parked right now ------------------------------------------------
    function blocked(p) {
        if (!engineOk(p)) return "Character slots need a newer Ragnarok RPG engine.";
        if (!p.alive) return "You can't change characters while dead.";
        if (typeof DBR_TCHAR !== "undefined" && (DBR_TCHAR.isActive(p) || DBR_TCHAR.isCreating(p))) return "Finish with your tournament character first.";
        if (typeof DMZ_FUSION !== "undefined" && DMZ_FUSION.isFused(p)) return "You can't change characters while fused.";
        if (typeof DBR_RAIDS !== "undefined" && DBR_RAIDS.runOfPlayer && DBR_RAIDS.runOfPlayer(p.uuid)) return "You can't change characters during a raid.";
        if (p.getVar("dmz_dead", 0)) return "You can't change characters while you are dead in the Other World.";
        var c = combatLeft(p);
        if (c > 0) return "You were in combat recently. You can swap characters in " + fmt(c) + ".";
        return null;
    }
    /** the parked character must not keep a transformation running: back to base, charging stopped */
    function toBase(p) {
        try { if (typeof DMZ_TF !== "undefined") { DMZ_TF.stopCharge && DMZ_TF.stopCharge(p); DMZ_TF.descend(p, false, true); } } catch (e) { }
    }

    /** after a character lands: every script that keeps per-player state reads it again (what a join does) */
    function settle(p, fresh) {
        try {
            p.refreshStats();
            if (typeof DMZ_TF !== "undefined") DMZ_TF.refresh(p);
            if (p.getVar("dmz_created", 0)) {
                var v = dmzView(p), hp = DMZ_F.maxHealth(v);
                if (hp > 0 && Math.abs(p.maxHealth - hp) > 0.01) p.maxHealth = hp;
                var lvl = DMZ_F.level(v);
                if (p.getLevel() !== lvl) p.setLevel(lvl, { silent: true });
            }
            // a fresh start on every swap (CharacterSlots.fullHeal): full health, hunger, ki and stamina
            p.health = p.maxHealth;
            p.setFood(20); p.setSaturation(5);
            ["ki", "stamina"].forEach(function (r) { try { p.setResource(r, p.maxResource(r)); } catch (e) { } });
            if (typeof DMZ_SKILLS !== "undefined") { if (p.getVar("dmz_created", 0)) DMZ_SKILLS.ensureDefaults(p); DMZ_SKILLS.sendState(p); }
            if (typeof DMZ_TECH !== "undefined" && DMZ_TECH.sendState) DMZ_TECH.sendState(p);
            if (typeof DMZ_TF !== "undefined") DMZ_TF.sendState(p);
            if (typeof DBR_ZSOUL !== "undefined") DBR_ZSOUL.refresh(p);
            if (typeof DMZ_QUESTS !== "undefined") DMZ_QUESTS.sync(p);
            if (typeof DMZ_KIWEAPON !== "undefined" && DMZ_KIWEAPON.sync) DMZ_KIWEAPON.sync(p);
            if (typeof DBR_PRESTIGE !== "undefined") DBR_PRESTIGE.onCharacterLoaded(p);
        } catch (e) { log("settle " + p.name + ": " + e); }
        RPG.net.send(p, "dbr_chars_loaded", { fresh: !!fresh });
        if (!p.getVar("dmz_created", 0)) RPG.schedule(10, function () { if (!p.getVar("dmz_created", 0)) RPG.net.send(p, "dmz_open_creator", {}); });
    }

    // =================================================================================
    //  Actions (CharacterSlots.switchTo / create / rename / delete)
    // =================================================================================
    function switchTo(p, index) {
        var r = root(p);
        if (index < 0 || index >= r.slots.length) return "No such character slot.";
        var target = r.slots[index];
        if (target.id === r.active) return "That character is already active.";
        var why = blocked(p);
        if (why) return why;
        var cd = settings().cooldown, since = Date.now() - (Number(r.last) || 0);
        if (cd > 0 && since < cd * 1000 && !p.isOp()) return "Character swap on cooldown. Try again in " + fmt(cd * 1000 - since) + ".";
        if (!p.hasProfile(PREFIX + target.id)) {
            log("slot " + target.id + " of " + p.name + " has no stored character; refusing to switch");
            return "That character's data is missing. Nothing was changed; ask an admin.";
        }
        toBase(p);
        var from = r.active, fromName = activeSlot(p).name;
        var err = p.swapProfile(PREFIX + from, PREFIX + target.id, opts());
        if (err) { log("switch failed for " + p.name + ": " + err); return err; }
        r = root(p);                     // the slot list is kept on the player: the same list, updated now
        r.active = target.id;
        r.last = Date.now();
        save(p, r);
        log(p.name + " switched from '" + fromName + "' (" + from + ") to '" + target.name + "' (" + target.id + ")");
        if (typeof DBR_PRESTIGE !== "undefined") DBR_PRESTIGE.owedFloorReset(p);
        settle(p, false);
        return null;
    }
    function create(p, name) {
        var r = root(p), max = maxSlots(p);
        if (r.slots.length >= max) return "You've reached your character slot limit (" + max + ").";
        var why = blocked(p);
        if (why) return why;
        name = String(name || "").replace(/[§&][0-9a-fk-or]/gi, "").trim().substring(0, 32);
        var id = "c" + (Math.floor(Number(r.seq) || r.slots.length) + 1);
        while (slotIndex(r, id) >= 0 || p.hasProfile(PREFIX + id)) id = "c" + (Number(id.substring(1)) + 1);
        toBase(p);
        var err = p.swapProfile(PREFIX + r.active, null, opts());
        if (err) { log("create failed for " + p.name + ": " + err); return err; }
        r = root(p);
        r.slots.push({ id: id, name: name || "Character " + (r.slots.length + 1), prestige: 0, created: Date.now() });
        r.seq = Number(id.substring(1));
        r.active = id;
        save(p, r);
        log(p.name + " created character " + id);
        // a new character starts like a first join
        try { p.startQuest("tutorial_basics"); p.startQuest("first_lesson"); } catch (e) { }
        settle(p, true);
        return null;
    }
    function rename(p, index, name) {
        var r = root(p);
        if (index < 0 || index >= r.slots.length) return "No such character slot.";
        name = String(name || "").replace(/[§&][0-9a-fk-or]/gi, "").trim().substring(0, 32);
        if (!name) return "Name cannot be empty.";
        r.slots[index].name = name;
        save(p, r);
        return null;
    }
    function remove(p, index) {
        var r = root(p);
        if (index < 0 || index >= r.slots.length) return "No such character slot.";
        if (r.slots.length <= 1) return "You can't delete your only character.";
        var s = r.slots[index];
        if (s.id === r.active) return "Switch to another character before deleting this one.";
        // kept once, so an accidental delete can be undone by an admin (/character admin <player> restoredeleted)
        if (p.hasProfile(PREFIX + s.id)) {
            p.deleteProfile(TRASH);
            if (!p.renameProfile(PREFIX + s.id, TRASH)) return "Could not delete that character safely.";
            r.trash = { name: s.name, prestige: s.prestige || 0, at: Date.now() };
        }
        r.slots.splice(index, 1);
        save(p, r);
        log(p.name + " deleted character '" + s.name + "' (" + s.id + "); kept as the last deleted character");
        return null;
    }
    function restoreDeleted(p) {
        var r = root(p);
        if (!r.trash || !p.hasProfile(TRASH)) return "There is no deleted character to restore.";
        var id = "c" + (Math.floor(Number(r.seq) || r.slots.length) + 1);
        while (slotIndex(r, id) >= 0 || p.hasProfile(PREFIX + id)) id = "c" + (Number(id.substring(1)) + 1);
        if (!p.renameProfile(TRASH, PREFIX + id)) return "Could not restore it.";
        r.slots.push({ id: id, name: r.trash.name || "Restored", prestige: r.trash.prestige || 0, created: Date.now() });
        r.seq = Number(id.substring(1));
        delete r.trash;
        save(p, r);
        return null;
    }

    // =================================================================================
    //  The picker (PacketCharacterGui / PacketCharacterAction)
    // =================================================================================
    function view(p) {
        var r = root(p), act = r.active;
        var slots = r.slots.map(function (s) {
            var row = { id: s.id, name: s.name, prestige: Math.floor(Number(s.prestige) || 0), active: s.id === act };
            if (row.active) { row.race = String(p.race || ""); row.level = p.getLevel(); row.created = !!p.getVar("dmz_created", 0); }
            else {
                var info = p.profileInfo(PREFIX + s.id);
                if (info) { row.race = String(info.race || ""); row.level = Number(info.level) || 1; row.created = !!p.profileVar(PREFIX + s.id, "dmz_created", 0); }
                else row.missing = true;
            }
            return row;
        });
        var cd = settings().cooldown, since = Date.now() - (Number(r.last) || 0);
        var T = typeof DBR_TCHAR !== "undefined" ? DBR_TCHAR : null;
        return { slots: slots, max: maxSlots(p), cooldown: cd > 0 && !p.isOp() ? Math.max(0, cd * 1000 - since) : 0, combat: combatLeft(p),
            tourFeature: !!(T && T.enabled()), tourPresent: !!(T && T.hasTemplate(p)), tourActive: !!(T && (T.isActive(p) || T.isCreating(p))),
            op: p.isOp() };
    }
    function openGui(p) { RPG.net.send(p, "dbr_chars_gui", view(p)); }
    function tell(p, err, ok) {
        if (err) { p.tell("&c" + err); p.playSound("dmzpack:ui_menu_switch", 0.6, 0.6); }
        else if (ok) p.tell("&a" + ok);
    }
    RPG.net.on("dbr_chars", function (p, d) {
        if (!d) return;
        var a = String(d.action || ""), n = Math.floor(Number(d.slot)), name = String(d.name || "");
        var r = root(p), err = null;
        switch (a) {
            case "open": break;
            case "switch": err = switchTo(p, n); tell(p, err, err ? null : "Switched to character #" + (n + 1) + "."); break;
            case "new": err = create(p, name); tell(p, err, err ? null : "Created a new character."); break;
            case "rename": err = rename(p, n, name); tell(p, err, err ? null : "Renamed."); break;
            case "delete": err = remove(p, n); tell(p, err, err ? null : "Deleted character #" + (n + 1) + "."); break;
            case "tour_create": if (typeof DBR_TCHAR !== "undefined") DBR_TCHAR.beginCreation(p); return;
            case "tour_delete": if (typeof DBR_TCHAR !== "undefined") DBR_TCHAR.remove(p); break;
            default: return;
        }
        if (a === "new" && !err) return;            // the creator opens instead
        openGui(p);
    });

    // =================================================================================
    //  Safety nets
    // =================================================================================
    // CharacterPersistence: the slot list and profiles are engine player data, which death copies. Nothing to do.
    // A slot whose stored character went missing (should never happen) is reported, never silently dropped.
    RPG.on("playerJoin", function (p) {
        RPG.schedule(30, function () {
            var r = p.getVar(V, null);
            if (!r || !r.slots) return;
            list(r.slots).forEach(function (s) {
                if (s.id !== r.active && engineOk(p) && !p.hasProfile(PREFIX + s.id)) log("WARNING " + p.name + ": stored character " + s.id + " ('" + s.name + "') has no data");
            });
        });
        // PlayerPositionSanitizer: a saved position outside the world sends the player to spawn instead of a death loop
        RPG.schedule(2, function () {
            var x = p.x, y = p.y, z = p.z, bad = null;
            if (!isFinite(x) || !isFinite(y) || !isFinite(z)) bad = "coordinate is not a finite number";
            else if (Math.abs(x) > 3e7 || Math.abs(z) > 3e7) bad = "outside the world border limit";
            else if (y < -2048 || y > 8192) bad = "outside the world";
            if (!bad) return;
            var sp = RPG.world.spawnPoint(), dim = "minecraft:overworld";
            var sy = RPG.world.surfaceY(dim, sp.x, sp.z);
            p.teleportTo(dim, sp.x + 0.5, (isFinite(sy) ? sy : sp.y) + 1, sp.z + 0.5);
            log(p.name + " logged in at an impossible position (" + x + ", " + y + ", " + z + "): " + bad + ". Moved to spawn.");
            p.tell("&eYour saved position was outside the world, so you have been moved to spawn.");
        });
    });

    // =================================================================================
    //  /character
    // =================================================================================
    var HELP = ["&8/character switch <n> · new [name] · rename <n> <name> · delete <n>"];
    function sendList(p) {
        var r = root(p);
        p.tell("&aCharacters (" + r.slots.length + "/" + maxSlots(p) + "):");
        r.slots.forEach(function (s, i) {
            var cur = s.id === r.active;
            p.tell((cur ? "&a> " : "&7  ") + "#" + (i + 1) + " " + s.name + (s.prestige ? " &6[P" + s.prestige + "]" : "") + (cur ? " &a(active)" : ""));
        });
        HELP.forEach(function (l) { p.tell(l); });
    }
    function command(p, args) {
        if (!p) { RPG.log("/character is for players"); return; }
        var sub = String(args[0] || "gui").toLowerCase(), n = Math.floor(Number(args[1])) - 1, err;
        switch (sub) {
            case "gui": openGui(p); return;
            case "list": sendList(p); return;
            case "switch": err = switchTo(p, n); tell(p, err, err ? null : "Switched to character #" + (n + 1) + "."); return;
            case "new": err = create(p, args.slice(1).join(" ")); tell(p, err, err ? null : "Created a new character."); return;
            case "rename": err = rename(p, n, args.slice(2).join(" ")); tell(p, err, err ? null : "Renamed."); return;
            case "delete": err = remove(p, n); tell(p, err, err ? null : "Deleted character #" + (n + 1) + "."); return;
            case "settings":
                if (!p.isOp()) { p.tell("&cOperators only."); return; }
                if (args[1] && DEFAULTS[args[1]] !== undefined && args[2] !== undefined) setSetting(args[1], args[2]);
                var s = settings();
                p.tell("&6Character slots: &fdefault slots &e" + s.slots + "&f, swap cooldown &e" + s.cooldown + "s&f, combat lock &e" + s.combatLock + "s");
                p.tell("&8/character settings <slots|cooldown|combatLock> <value>");
                return;
            case "admin":
                if (!p.isOp()) { p.tell("&cOperators only."); return; }
                var t = args[1] ? RPG.server.player(args[1]) : null;
                if (!t) { p.tell("&c/character admin <player> [setslots <n> | restoredeleted]"); return; }
                var op = String(args[2] || "").toLowerCase();
                if (op === "setslots") {
                    var r = root(t); r.granted = Math.max(0, Math.min(HARD_CAP, Math.floor(Number(args[3]) || 0))); save(t, r);
                    p.tell("&a" + t.name + " may now have " + maxSlots(t) + " characters.");
                } else if (op === "restoredeleted") { err = restoreDeleted(t); tell(p, err, err ? null : "Restored " + t.name + "'s last deleted character as a new slot."); }
                else {
                    var rr = root(t);
                    p.tell("&6" + t.name + ": &f" + rr.slots.length + "/" + maxSlots(t) + " characters, active &e" + activeSlot(t).name + (rr.trash ? "&7, deleted: " + rr.trash.name : ""));
                    rr.slots.forEach(function (s, i) { p.tell("&7 #" + (i + 1) + " " + s.name + " &8(" + s.id + ", prestige " + (s.prestige || 0) + (t.hasProfile(PREFIX + s.id) || s.id === rr.active ? "" : ", NO DATA") + ")"); });
                }
                return;
            default: sendList(p);
        }
    }
    function suggest(p, args) {
        if (args.length <= 1) return ["list", "switch", "new", "rename", "delete"].concat(p && p.isOp() ? ["settings", "admin"] : []);
        return [];
    }
    RPG.commands.register("character", { root: true, aliases: ["characters", "char"], permission: 0,
        description: "Your character slots: /character", run: command, suggest: suggest });

    return { root: root, activeSlot: activeSlot, activeIndex: activeIndex, maxSlots: maxSlots, openGui: openGui, switchTo: switchTo, create: create,
        rename: rename, remove: remove, getActivePrestige: getActivePrestige, setActivePrestige: setActivePrestige, highestPrestige: highestPrestige,
        save: save, slotIndex: slotIndex, PREFIX: PREFIX, KEEP: KEEP, opts: opts, settle: settle, combatLeft: combatLeft, HARD_CAP: HARD_CAP };
})();
