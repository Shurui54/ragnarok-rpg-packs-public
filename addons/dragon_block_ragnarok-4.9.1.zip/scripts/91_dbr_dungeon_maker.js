// =====================================================================================
//  91_dbr_dungeon_maker.js - Dragon Block's settings for the Dungeon Maker addon
// =====================================================================================
//  Dungeons in DBR are built by staff with the Dungeon Maker (an addon that comes with the
//  engine and is switched on with Dragon Block: addon.json "requires"). Open the Dungeon
//  Selection menu with O, the Dungeons button in the inventory, /dungeons (or /dungeon), a
//  Dungeon Gate portal or the Gatekeeper. Staff: Admin > + New makes a dungeon and a workshop plot.
//
//  Here DBR only tells it about Dragon Block:
//   - "Level" rules and cards use DBR's level (worked out from your stats), not vanilla XP.
//   - your DMZ party (78_dmz_party.js) comes along into the same run.
//   - optional TP for finishing a dungeon, by difficulty (off by default; loot points can hold
//     TP Gems and the other dungeon items, which all still exist).
//  The old procedural floors (90_dbr_dungeons*.js) are still there behind dbr.legacySystem.
// =====================================================================================
var DBR_DM_CFG = RPG.config.define("dbr_dungeon_maker", {
    completionTp: { default: [0, 0, 0, 0, 0], comment: "TP each player gets for finishing a dungeon, by difficulty: Easy, Medium, Hard, Very Hard, Epic." }
});
var DUNGEON_MAKER_SETUP = (typeof DUNGEON_MAKER_SETUP !== "undefined" ? DUNGEON_MAKER_SETUP : []);
DUNGEON_MAKER_SETUP.push(function (DM) {
    DM.hooks.levelName = "Level";
    DM.hooks.levelOf = function (p) { return p.getLevel(); };
    DM.hooks.xpLevelRule = false;                      // DBR has no use for the vanilla XP bar
    DM.hooks.partyOf = function (p) {
        if (typeof DMZ_PARTY === "undefined") return [];
        return DMZ_PARTY.members(p).filter(function (m) { return String(m.uuid) !== String(p.uuid); });
    };
    DM.hooks.onComplete = function (def, players) {
        var list = DBR_DM_CFG.get("completionTp") || [], tp = Number(list[def.difficulty | 0]) || 0;
        if (tp <= 0) return;
        players.forEach(function (p) {
            p.addTp(tp, { raw: true, events: false, source: "dungeon" });
            p.tell("&6[Dungeons] &e+" + tp.toLocaleString() + " TP");
        });
    };
});
