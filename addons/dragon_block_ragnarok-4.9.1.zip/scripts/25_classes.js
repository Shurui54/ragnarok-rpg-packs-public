// =====================================================================================
//  25_classes.js - DMZ's eight classes
// =====================================================================================
//  In DMZ the class (not the race) decides your starting stats, how they scale and your
//  TP multipliers. The numbers live in shared/00_dmz_data.js so the character creator
//  shows the same values the server uses. Picked in the creator's Class tab.
// =====================================================================================
var DMZ_STAT_IDS = DMZ_DATA.STAT_IDS;
var CLASS_NAMES = { warrior: "Warrior", spiritualist: "Spiritualist", martialartist: "Martial Artist", berserker: "Berserker",
    paladin: "Paladin", tank: "Tank", cleric: "Cleric", unversed: "Unversed" };

DMZ_DATA.CLASS_ORDER.forEach(function (id) {
    let c = DMZ_DATA.CLASSES[id], stats = {};
    for (let s in c.base) if (c.base[s]) stats[DMZ_STAT_IDS[s]] = c.base[s];
    RPG.classes.define(id, {
        name: CLASS_NAMES[id],
        description: "DMZ class. Base stats " + DMZ_DATA.STATS.map((s) => s + " " + c.base[s]).join(", ") + ".",
        stats: stats,
        tpMultiplier: c.tpGain
    });
});
