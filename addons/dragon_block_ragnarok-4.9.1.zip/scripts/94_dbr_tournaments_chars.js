// =====================================================================================
//  94_dbr_tournaments_chars.js - Tournament characters: the fighter a contestant is swapped
//  into for a tournament, built once and reloaded on every entry
// =====================================================================================
//  Port of DMZ Ragnarok's tournament characters (GPL-3.0, shuruis_dmz_tournaments:
//  character/TournamentCharacter, TournamentAttacks, TournamentMoveAccess, TournamentFighters,
//  mixin/StatsDataTournamentFormMixin, client/gui/LoadoutScreen and the character parts of
//  TournamentInstance / ForgeEventHandler / TournamentCommand).
//
//  What a tournament character is (DMZR's rules):
//    - A frozen fighter template per player: race, class, look, a flat pool of stat
//      allocations (characters.statAllocations, spent 1:1 because pointsBeforeTp spends AP
//      before TP), TP zero, every DMZ skill the race may hold at its ceiling (techniques
//      excepted), full mastery of every form, and a move loadout of exactly 4 ki + 4 strike
//      attacks. No items, accessories (Z-Souls) or effects ride into the arena.
//    - On tournament start each contestant's REAL state is snapshotted into a player var and
//      the template is loaded. Nothing the fighter does is written back to the template.
//    - TP is frozen at 0 for the fighter (every gain is undone each tick).
//    - At half health the fighter is forced into its first reachable form (Ultimate when the
//      race has none) with characters.forcedTransformIframeTicks of damage immunity, once per
//      bout. While a fighter is in any form, its form multiplier reads as a FLAT
//      characters.forcedFormStatMultiplier for every stat and race.
//    - The real state comes back whenever the fighter leaves: knockout, match loss, the end,
//      cancel, /tourney forceexit, logout, a login with no live bout, death, /rpg reload
//      (through 94_dbr_tournaments.js restoreFighter) or a crash rejoin (the snapshot and the
//      marker live in player vars, saved with the player).
//    - Full creation (DMZR's "create in advance"): the player is put in a blank sandbox
//      character, DMZ's creator opens (race + look), then the stats screen to spend the pool,
//      then the move picker; saving freezes the template and puts the real character back.
//      A sandbox left by logging out is undone on the next login.
//
//  Commands: /tourney char [create | build | moves | delete | cancel]   (screen: /tourney char)
//            /tourney loadout (the move picker), /tourney cancelcharacter (abandon a build)
//  Player vars: dbr_tchar (marker + flags), dbr_tchar_restore (the real state while swapped),
//  dbr_tchar_template (the fighter), dbr_tchar_loadout (the chosen 4 + 4 attack ids).
// =====================================================================================
var DBR_TCHAR = (function () {
    var C = DBR_TOURNEY_CFG, SD = DMZ_SKILLS_DATA, TD = DMZ_TECH_DATA, FD = DMZ_FORMS;
    var V_STATE = "dbr_tchar", V_RESTORE = "dbr_tchar_restore", V_TEMPLATE = "dbr_tchar_template", V_LOADOUT = "dbr_tchar_loadout";
    var KI_SLOTS = 4, STRIKE_SLOTS = 4;
    // the look a character is drawn with (form colours are recomputed by 31_dmz_transform.js)
    var LOOKS = ["body1", "body2", "body3", "hair", "eyes", "eye2", "aura", "halo", "tail", "tailWrap", "kiWeapon", "kiWeaponColor",
        "bodyType", "bodyModel", "eyeStyle", "nose", "mouth", "hairStyle", "tattoo", "headBone", "majinArmor"];
    // the player vars that make up a DMZ character (DMZR snapshots StatsData whole)
    var VARS = ["dmz_created", "dmz_release", "dmz_potential", "dmz_skills", "dmz_tech", "dmz_tech_cd", "dmz_form", "dmz_stack", "dmz_sel",
        "dmz_sel_stack", "dmz_prev", "dmz_prev_stack", "dmz_mastery", "dmz_stack_mastery", "dmz_action", "dmz_form_mult", "dmz_mult",
        "dmz_form_name", "dmz_formcharge", "dmz_tail", "dmz_tail_visible", "dmz_android", "dmz_majin", "dmz_zenkai_release", "dmz_alignment",
        "dmz_kiweapon", "dmz_aura_perm", "dmz_forced_aura", "dmz_aura_color", "dmz_racial_applied", "dmz_mutant", "dmz_release_limit",
        "dmzr_release_boost", "dmz_rage", "dmz_surge", "dmz_surge_active", "dmz_skill_active", "dmz_bio_skill"];
    var FORM_VARS = ["dmz_form", "dmz_stack", "dmz_sel", "dmz_sel_stack", "dmz_prev", "dmz_prev_stack"];
    // DMZR's flat form multiplier covers all six stats (STM is RES's stamina channel here)
    var FLAT_KEYS = ["STR", "SKP", "DEF", "PWR", "VIT", "ENE", "STM"];

    function uid(p) { return String(p.uuid); }
    function list(v) {          // JS arrays and Java lists alike
        var o = [];
        if (!v || typeof v === "string") return o;
        if (typeof v.length === "number") { for (var i = 0; i < v.length; i++) o.push(v[i]); return o; }
        if (typeof v.size === "function") { for (var j = 0; j < v.size(); j++) o.push(v.get(j)); }
        return o;
    }
    function obj(v) { return v && typeof v === "object" ? v : {}; }
    function clone(o) { return o === null || o === undefined ? o : JSON.parse(JSON.stringify(o)); }
    function empty(st) { return !st || !st.id || String(st.id) === "minecraft:air"; }
    function enabled() { return !!C.get("characters.enabled"); }
    function allocations() { return Math.max(0, Math.floor(Number(C.get("characters.statAllocations")) || 0)); }
    function dmzRace(race) { return DMZ_DATA.DMZ[race] || race || "human"; }
    function log(s) { RPG.log("[Tournament characters] " + s); }

    // ---- the marker (dbr_tchar): {active, creating, kit, awaiting, defId, forced, corr} ----------------
    function state(p) { return obj(p.getVar(V_STATE, null)); }
    function setState(p, s) { p.setVar(V_STATE, s && (s.active || s.creating) ? s : null); }
    function isActive(p) { return !!state(p).active; }
    function isCreating(p) { return !!state(p).creating; }
    function inBout(p) { var s = state(p); return !!s.active && !s.creating; }

    // =================================================================================
    //  The moves (TournamentAttacks, TournamentMoveAccess)
    // =================================================================================
    function isKi(id) { return TD.KI_IDS.indexOf(id) >= 0 && id !== TD.REVIVE_ID; }
    function isStrike(id) { return TD.STRIKE_IDS.indexOf(id) >= 0; }
    /** May a fighter of this race hold the move (DMZ's race lists; DMZR also hides title / unlock gated moves). */
    function mayUse(race, android, id) {
        if (!isKi(id) && !isStrike(id)) return false;
        return SD.allowed(id, dmzRace(race), !!android);
    }
    function universal(id) { return (isKi(id) || isStrike(id)) && !(SD.RACES[id] && SD.RACES[id].length); }
    function kiFor(race, android) { return TD.KI_IDS.filter(function (id) { return mayUse(race, android, id); }); }
    function strikeFor(race, android) { return TD.STRIKE_IDS.filter(function (id) { return mayUse(race, android, id); }); }
    function defaultLoadout() {
        var ki = TD.KI_IDS.filter(function (id) { return isKi(id) && universal(id); }).slice(0, KI_SLOTS);
        var sk = TD.STRIKE_IDS.filter(function (id) { return universal(id); }).slice(0, STRIKE_SLOTS);
        return ki.concat(sk);
    }
    /** A save is valid only as exactly 4 ki + 4 strike moves the fighter may hold (never padded). */
    function validLoadout(race, android, ids) {
        var seen = {}, ki = 0, sk = 0, ok = true;
        list(ids).forEach(function (raw) {
            var id = String(raw || "");
            if (!id || seen[id] || !mayUse(race, android, id)) { ok = false; return; }
            seen[id] = 1;
            if (isKi(id)) ki++; else sk++;
        });
        return ok && ki === KI_SLOTS && sk === STRIKE_SLOTS;
    }
    function loadout(p) {
        var l = list(p.getVar(V_LOADOUT, null)).map(String).filter(function (id) { return isKi(id) || isStrike(id); });
        return l.length ? l : defaultLoadout();
    }
    /** dmz_tech holding exactly the loadout, equipped in order (TournamentAttacks.applyLoadout). */
    function techFor(ids) {
        var v = { u: {}, s: [], fl: null };
        list(ids).forEach(function (id) { if (!v.u[id] && v.s.length < TD.SLOT_COUNT) { v.u[id] = { x: 0, d: 0, c: 0, r: 0 }; v.s.push(id); } });
        while (v.s.length < TD.SLOT_COUNT) v.s.push("");
        return v;
    }

    // =================================================================================
    //  The fighter kit (grantFighterKit / grantMaxMastery)
    // =================================================================================
    /** Every DMZ skill the race may hold, at its ceiling. Techniques come from the loadout only, and Fusion is
     *  left out: fusing hands state between two players, which a swap-and-restore cannot follow. */
    function kitSkills(race, android, ids) {
        var r = dmzRace(race), map = {};
        Object.keys(SD.COSTS).forEach(function (s) {
            if (SD.isTechnique(s) || s === "fusion" || SD.isForm(s)) return;
            if (!SD.allowed(s, r, !!android)) return;
            var max = SD.maxLevel(s, r);
            if (max > 0) map[s] = max;
        });
        SD.raceFormSkills(r, !!android).forEach(function (s) { var max = SD.maxLevel(s, r); map[s] = Math.max(0, max); });
        list(ids).forEach(function (id) { if (SD.COSTS[id]) map[id] = 1; });
        return map;
    }
    function maxMastery(race) {
        var forms = {}, stacks = {};
        FD.groups(dmzRace(race)).forEach(function (g) { g.forms.forEach(function (f) { if (f.maxMastery > 0) forms[f.key] = f.maxMastery; }); });
        FD.STACKS.forEach(function (g) { g.forms.forEach(function (f) { if (f.maxMastery > 0) stacks[f.key] = f.maxMastery; }); });
        return { forms: forms, stacks: stacks };
    }
    /** A character with the fighter kit on top: no items, effects, TP or bought stats, base form. */
    function fighterize(base, ids) {
        var t = clone(base), m = maxMastery(t.race), android = t.vars.dmz_android;
        t.inv = {}; t.acc = {}; t.fx = []; t.tp = 0; t.hp = 1; t.ki = 1; t.st = 1; t.kit = true;
        t.vars.dmz_skills = kitSkills(t.race, android, ids);
        t.vars.dmz_potential = t.vars.dmz_skills.potentialunlock || 0;
        t.vars.dmz_tech = techFor(ids);
        t.vars.dmz_mastery = m.forms; t.vars.dmz_stack_mastery = m.stacks;
        t.vars.dmz_mult = {}; t.vars.dmz_form_mult = {};
        ["dmz_tech_cd", "dmz_prev", "dmz_prev_stack", "dmz_surge", "dmz_surge_active", "dmz_skill_active", "dmzr_release_boost"].forEach(function (k) { delete t.vars[k]; });
        ["dmz_form", "dmz_stack", "dmz_sel", "dmz_sel_stack", "dmz_form_name"].forEach(function (k) { t.vars[k] = ""; });
        t.vars.dmz_release = 0; t.vars.dmz_formcharge = 0; t.vars.dmz_rage = 0; t.vars.dmz_forced_aura = 0;
        if (t.vars.dmz_android && dmzRace(t.race) === "human") t.vars.dmz_form = "androidforms:androidbase";
        return t;
    }
    /** buildTemplateInPlace, as data: the real race and look, the pool unspent, the kit and the loadout. */
    function templateFrom(real, ids) {
        var t = fighterize(real, ids);
        t.alloc = {}; t.sp = allocations();
        return t;
    }

    // =================================================================================
    //  Snapshots (capture / apply): everything the swap touches, in one player var
    // =================================================================================
    function frac(v, max) { return max > 0 ? Math.max(0, Math.min(1, v / max)) : 1; }
    function capture(p, withItems) {
        var s = { v: 1, race: String(p.race || ""), cls: String(p.playerClass || ""), looks: {}, alloc: {}, vars: {}, skills: {}, bar: [], fx: [],
            sp: p.getStatPoints(), skp: p.getSkillPoints(), tp: p.getTp(),
            hp: frac(p.health, p.maxHealth), ki: frac(p.resource("ki"), p.maxResource("ki")), st: frac(p.resource("stamina"), p.maxResource("stamina")) };
        LOOKS.forEach(function (k) { s.looks[k] = String(p.getColor(k) || ""); });
        list(RPG.stats.list()).forEach(function (id) { var a = Number(p.allocated(String(id))) || 0; if (a) s.alloc[String(id)] = a; });
        VARS.forEach(function (k) { var v = p.getVar(k, null); if (v !== null && v !== undefined) s.vars[k] = clone(v); });
        list(RPG.skills.list()).forEach(function (id) { id = String(id); if (p.hasSkill(id)) s.skills[id] = p.skillLevel(id); });
        s.bar = list(p.skillBar).map(function (b) { return b ? String(b) : ""; });
        var ticks = typeof p.effectTicks === "function";
        // effectTicks (engine): ticks left, -1 forever; an older engine without it gets a minute back
        list(p.effects()).forEach(function (id) { id = String(id); s.fx.push([id, ticks ? p.effectTicks(id) : 1200, p.effectStacks(id) || 1]); });
        if (withItems) {
            s.inv = {}; s.acc = {};
            for (var i = 0; i <= 40; i++) { var st = p.getStack(i); if (!empty(st)) s.inv[i] = st; }
            list(RPG.slots.list()).forEach(function (id) { id = String(id); var a = p.getAccessory(id); if (!empty(a)) s.acc[id] = a; });
        }
        return s;
    }
    var TOKEN = {};
    /** Write a snapshot onto the live player. Returns true when the character half landed. */
    function apply(p, s) {
        if (!s || typeof s !== "object" || !s.race) return false;
        var id = uid(p), tok = (TOKEN[id] = (TOKEN[id] || 0) + 1);
        if (String(p.race || "") !== s.race) p.setRace(s.race);
        if (s.cls && String(p.playerClass || "") !== s.cls) p.setPlayerClass(s.cls);
        var vars = obj(s.vars);
        VARS.forEach(function (k) { p.setVar(k, Object.prototype.hasOwnProperty.call(vars, k) ? clone(vars[k]) : null); });
        var alloc = obj(s.alloc);
        list(RPG.stats.list()).forEach(function (sid) {
            sid = String(sid);
            var want = Number(alloc[sid]) || 0, cur = Number(p.allocated(sid)) || 0;
            if (Math.abs(want - cur) > 1e-9) p.addStat(sid, want - cur);
        });
        p.setStatPoints(Math.max(0, Math.floor(Number(s.sp) || 0)));
        p.setSkillPoints(Math.max(0, Math.floor(Number(s.skp) || 0)));
        p.setTp(Math.max(0, Number(s.tp) || 0));
        var skills = obj(s.skills);
        list(RPG.skills.list()).forEach(function (k) {
            k = String(k);
            var want = Number(skills[k]) || 0, has = p.hasSkill(k);
            if (has && !want) p.forgetSkill(k);
            else if (want) { if (!has) p.learnSkill(k); if (p.skillLevel(k) !== want) p.setSkillLevel(k, want); }
        });
        list(s.bar).forEach(function (b, i) { try { p.setSkillBar(i, b ? String(b) : null); } catch (e) { } });
        LOOKS.forEach(function (k) { var v = obj(s.looks)[k]; p.setColor(k, v ? String(v) : ""); });
        p.clearEffects();
        list(s.fx).forEach(function (f) {
            var ticks = Number(f[1]);
            if (ticks === 0 || isNaN(ticks)) return;
            try { if (RPG.effects.exists(f[0])) p.addEffectStacks(f[0], ticks, Math.max(1, Number(f[2]) || 1)); } catch (e) { }
        });
        if (s.inv) {
            for (var i = 0; i <= 40; i++) p.setStack(i, null);
            Object.keys(s.inv).forEach(function (k) { p.setStack(Number(k), s.inv[k]); });
        }
        if (s.acc) {
            list(RPG.slots.list()).forEach(function (sl) { sl = String(sl); p.setAccessory(sl, s.acc[sl] || null); });
        }
        p.refreshStats();
        if (s.kit && typeof DMZ_SKILLS !== "undefined") {
            // what owning those levels means elsewhere (form and Kaioken skills learned, 46_dmz_skills.js)
            var map = obj(vars.dmz_skills);
            Object.keys(map).forEach(function (k) { if (!SD.isTechnique(k)) DMZ_SKILLS.setLevel(p, k, map[k]); });
        }
        settle(p, s);
        // a race change wipes the form vars a tick later (31_dmz_transform.js): put them back after it
        RPG.schedule(2, function () {
            if (TOKEN[id] !== tok) return;
            FORM_VARS.forEach(function (k) { p.setVar(k, Object.prototype.hasOwnProperty.call(vars, k) ? clone(vars[k]) : null); });
            settle(p, s);
        });
        return true;
    }
    function settle(p, s) {
        try {
            p.refreshStats();
            if (typeof DMZ_TF !== "undefined") DMZ_TF.refresh(p);
            if (p.getVar("dmz_created", 0)) {
                var hp = DMZ_F.maxHealth(dmzView(p));
                if (hp > 0 && Math.abs(p.maxHealth - hp) > 0.01) p.maxHealth = hp;
                if (typeof DMZ_F.level === "function") { var lvl = DMZ_F.level(dmzView(p)); if (p.getLevel() !== lvl) p.setLevel(lvl, { silent: true }); }
            }
            p.health = Math.max(1, p.maxHealth * (s.hp === undefined ? 1 : s.hp));
            p.setResource("ki", p.maxResource("ki") * (s.ki === undefined ? 1 : s.ki));
            p.setResource("stamina", p.maxResource("stamina") * (s.st === undefined ? 1 : s.st));
            if (typeof DMZ_SKILLS !== "undefined") DMZ_SKILLS.sendState(p);
            if (typeof DMZ_TECH !== "undefined") DMZ_TECH.sendState(p);
            if (typeof DMZ_TF !== "undefined") DMZ_TF.sendState(p);
        } catch (e) { log("settle " + p.name + ": " + e); }
    }

    // =================================================================================
    //  Entering and leaving (enter / exit)
    // =================================================================================
    /** Swap into the fighter. Idempotent: never overwrites a snapshot already held. */
    function enter(p, defId) {
        if (!p || isActive(p)) return false;
        var real = capture(p, true), first = !p.getVar(V_TEMPLATE, null);
        if (!hold(p, real)) return false;
        setState(p, { active: true, defId: String(defId || ""), forced: false, corr: {} });
        try {
            var tpl = p.getVar(V_TEMPLATE, null);
            if (!tpl || !tpl.race) { tpl = templateFrom(real, loadout(p)); p.setVar(V_TEMPLATE, tpl); }
            apply(p, tpl);
            FIGHTERS[uid(p)] = 1;
            p.tell("&6[Tournament] &fYou fight as your &etournament character&f. Your own character comes back when you leave.");
            if (first) {
                p.tell("&7No tournament character yet: one was built from your race and look. Pick its moves now, or later with &f/tourney char&7.");
                if (p.getStatPoints() > 0) p.tell("&7Spend its &d" + p.getStatPoints() + " &7stat allocations in the stats screen (V).");
                openMoves(p, false);
            }
            return true;
        } catch (e) {
            log("enter failed for " + p.name + ": " + e);
            // a failed swap must not strand the player: the snapshot is only dropped once it is back on them
            if (safeApply(p, real)) { setState(p, null); p.setVar(V_RESTORE, null); delete FIGHTERS[uid(p)]; }
            return false;
        }
    }
    /** Store the real state, and refuse the swap when it did not land (a player var holds at most 256 KB). */
    function hold(p, real) {
        try { p.setVar(V_RESTORE, real); } catch (e) { }
        var back = p.getVar(V_RESTORE, null);
        if (back && back.race === real.race) return true;
        p.setVar(V_RESTORE, null);
        p.tell("&cYour character could not be stored safely (too many items with data?), so it was not swapped. Empty some containers and try again.");
        log("snapshot did not fit for " + p.name + "; not swapped");
        return false;
    }
    function safeApply(p, s) { try { return apply(p, s); } catch (e) { log("restore failed for " + p.name + ": " + e); return false; } }
    /** Swap back. keepCreation leaves a creation sandbox alone (a reload does not end one). Returns true when the
     *  player holds their real character afterwards. Keeps the snapshot when it could not be applied. */
    function exit(p, keepCreation) {
        if (!p) return false;
        var s = state(p);
        if (!s.active) return true;
        if (s.creating && keepCreation) return false;
        var real = p.getVar(V_RESTORE, null);
        if (real && !safeApply(p, real)) {
            log("could not restore " + p.name + "; the snapshot is kept for the next login");
            return false;
        }
        p.setVar(V_RESTORE, null);
        setState(p, null);
        delete FIGHTERS[uid(p)];
        delete IFRAMES[uid(p)];
        return true;
    }
    /** A new bout: the half-health transformation can fire again (TournamentInstance.prepareNextMatch). */
    function newBout(p) {
        if (!p || !inBout(p)) return;
        var s = state(p);
        s.forced = false;
        setState(p, s);
        delete IFRAMES[uid(p)];
    }

    // =================================================================================
    //  The template: create in advance, moves, delete
    // =================================================================================
    function hasTemplate(p) { var t = p.getVar(V_TEMPLATE, null); return !!(t && t.race); }
    /** Quick build: the template from the real character's race and look (DMZR buildTemplateNow). */
    function build(p) {
        if (isActive(p)) { p.tell("&cYou can't rebuild your tournament character while you hold it."); return false; }
        p.setVar(V_TEMPLATE, templateFrom(capture(p, false), loadout(p)));
        p.tell("&aTournament character built from your race and look. It has &d" + allocations() + " &astat allocations to spend when it enters.");
        return true;
    }
    function setLoadout(p, ids) {
        var t = p.getVar(V_TEMPLATE, null), race = t && t.race ? t.race : String(p.race || ""), android = t && t.vars ? t.vars.dmz_android : p.getVar("dmz_android", 0);
        if (isCreating(p)) { race = String(p.race || ""); android = p.getVar("dmz_android", 0); }
        if (!validLoadout(race, android, ids)) { p.tell("&cPick exactly " + KI_SLOTS + " ki and " + STRIKE_SLOTS + " strike attacks."); return false; }
        var clean = list(ids).map(String);
        p.setVar(V_LOADOUT, clean);
        if (isCreating(p)) return finalizeCreation(p);
        // the template is separate from the live fighter, so it is patched even mid-tournament (next entry uses it)
        if (t && t.race) {
            t.vars = obj(t.vars);
            var skills = obj(t.vars.dmz_skills);
            Object.keys(skills).forEach(function (k) { if (SD.isTechnique(k)) delete skills[k]; });
            clean.forEach(function (id) { if (SD.COSTS[id]) skills[id] = 1; });
            t.vars.dmz_skills = skills;
            t.vars.dmz_tech = techFor(clean);
            p.setVar(V_TEMPLATE, t);
        } else p.setVar(V_TEMPLATE, templateFrom(capture(p, false), clean));
        p.tell("&aTournament moves saved." + (inBout(p) ? " &7They apply from your next tournament." : ""));
        return true;
    }
    function remove(p) {
        if (isActive(p)) { p.tell("&cYou can't delete your tournament character while you hold it."); return false; }
        if (!hasTemplate(p)) { p.tell("&7You have no tournament character."); return false; }
        p.setVar(V_TEMPLATE, null);
        p.setVar(V_LOADOUT, null);
        p.tell("&eTournament character deleted. A new one is built the next time you enter.");
        return true;
    }

    // ---- full creation (beginCreation / tickCreations / finalizeCreation) ----------------------
    function busy(p) { return typeof DBR_TOURNEY !== "undefined" && DBR_TOURNEY.isInTournament(p); }
    function beginCreation(p) {
        if (isCreating(p)) { prompt(p); return false; }
        if (isActive(p)) { p.tell("&cYou can't create a tournament character during a tournament."); return false; }
        if (busy(p)) { p.tell("&cLeave the tournament you signed up for first."); return false; }
        if (!p.getVar("dmz_created", 0)) { p.tell("&cCreate your own character first."); return false; }
        var real = capture(p, true);
        if (!hold(p, real)) return false;
        setState(p, { active: true, creating: true, kit: false, awaiting: false, defId: "" });
        try {
            var blank = fighterize(real, []);
            blank.alloc = {}; blank.sp = 0; blank.kit = false;
            blank.vars = { dmz_created: 0, dmz_alignment: real.vars.dmz_alignment };
            apply(p, blank);
            RPG.net.send(p, "dmz_open_creator", {});
            p.tell("&e[Tournament] &fCreating your tournament character: pick its race and look. Your own character is kept safe.");
            return true;
        } catch (e) {
            log("beginCreation failed for " + p.name + ": " + e);
            if (safeApply(p, real)) { setState(p, null); p.setVar(V_RESTORE, null); }
            return false;
        }
    }
    function prompt(p) {
        var s = state(p);
        if (!p.getVar("dmz_created", 0)) { RPG.net.send(p, "dmz_open_creator", {}); return; }
        if (p.getStatPoints() > 0) { p.tell("&e[Tournament] &fSpend your &d" + p.getStatPoints() + " &fstat allocations in the stats screen, then pick 4 ki + 4 strike moves."); RPG.net.send(p, "dmz_open_stats", {}); return; }
        if (s.awaiting) openMoves(p, true);
    }
    function clickable(p, text, cmd) {
        var line = [{ text: String(text).replace(/&([0-9a-fk-or])/gi, "§$1"), color: "gold", clickEvent: { action: "run_command", value: cmd },
            hoverEvent: { action: "show_text", contents: "§eClick" } }];
        try { RPG.server.runCommand("tellraw " + p.name + " " + JSON.stringify(line)); } catch (e) { p.tell(text + " &7(" + cmd + ")"); }
    }
    function tickCreation(p) {
        var s = state(p);
        if (!s.creating || s.awaiting || !p.getVar("dmz_created", 0)) return;
        if (!s.kit) {
            // DMZ's create handler has run: the pool and the kit go on now (reassertConstraints)
            list(RPG.stats.list()).forEach(function (sid) { sid = String(sid); var a = Number(p.allocated(sid)) || 0; if (a) p.addStat(sid, -a); });
            p.setStatPoints(allocations());
            p.setTp(0);
            var kit = kitSkills(String(p.race || ""), p.getVar("dmz_android", 0), []), m = maxMastery(String(p.race || ""));
            p.setVar("dmz_skills", kit);
            p.setVar("dmz_mastery", m.forms); p.setVar("dmz_stack_mastery", m.stacks);
            p.setVar("dmz_potential", kit.potentialunlock || 0);
            if (typeof DMZ_SKILLS !== "undefined") Object.keys(kit).forEach(function (k) { DMZ_SKILLS.setLevel(p, k, kit[k]); });
            p.refreshStats();
            s.kit = true;
            setState(p, s);
            if (p.getStatPoints() > 0) {
                p.tell("&e[Tournament] &fSpend your &d" + p.getStatPoints() + " &fstat allocations in the stats screen (V). The move picker opens once they are all spent.");
                RPG.net.send(p, "dmz_open_stats", {});
            }
            return;
        }
        // stats first, then moves: the picker waits until every allocation is spent
        if (p.getStatPoints() > 0) return;
        s.awaiting = true;
        setState(p, s);
        clickable(p, "[Tournament] All allocations spent - click to pick 4 ki + 4 strike moves.", "/rpgc tourney char moves");
        openMoves(p, true);
    }
    /** /tourney cancelcharacter: abandon an unfinished build and get the real character straight back. */
    function cancelCreation(p) {
        if (!isCreating(p)) { p.tell("&cYou are not building a tournament character."); return false; }
        if (exit(p)) p.tell("&eBuild cancelled. You are back on your own character.");
        return true;
    }
    function finalizeCreation(p) {
        var s = state(p);
        if (!s.creating) return false;
        if (p.getStatPoints() > 0) { p.tell("&cSpend your " + p.getStatPoints() + " stat allocations first."); return false; }
        if (!p.getVar("dmz_created", 0)) { p.tell("&cFinish the character creator first."); return false; }
        try {
            var t = fighterize(capture(p, false), loadout(p));
            t.sp = 0;
            p.setVar(V_TEMPLATE, t);
        } catch (e) { log("finalizeCreation failed for " + p.name + ": " + e); }
        if (exit(p)) p.tell("&a[Tournament] &fYour tournament character is ready. Your own character is back.");
        return true;
    }

    // =================================================================================
    //  The bout: TP freeze, half-health transformation, flat form multiplier
    // =================================================================================
    var FIGHTERS = {}, IFRAMES = {};
    function fighterRun(p) { return typeof DBR_TOURNEY !== "undefined" && DBR_TOURNEY.fighterDef ? DBR_TOURNEY.fighterDef(p) : null; }
    /** Force a transform past the usual gates: the first reachable form, else Ultimate (forceTransform). */
    function forceTransform(p) {
        if (typeof DMZ_TF === "undefined") return;
        try {
            var cur = String(p.getVar("dmz_form", "") || ""), base = !cur || cur === "androidforms:androidbase";
            if (base) {
                DMZ_TF.ensureSelection(p);
                var sel = String(p.getVar("dmz_sel", "") || ""), i = sel.indexOf(":");
                var f = i > 0 ? FD.form(DMZ_TF.race(p), sel.substring(0, i), sel.substring(i + 1)) : null;
                if (f) { p.setVar("dmz_prev", { v: cur }); DMZ_TF.setForm(p, sel.substring(0, i), sel.substring(i + 1)); }
                else if (!p.getVar("dmz_stack", "")) DMZ_TF.setStack(p, "ultimate", "ultimate");
            }
            sfx(p, "insta_form_on", 1, 1);
            p.playAnimationFor("transf.generic", 20);
            p.actionbar("&e&lForced transformation!");
            correct(p);
        } catch (e) { log("forceTransform " + p.name + ": " + e); }
    }
    RPG.on("damageFinal", function (e) {
        var t = e.target;
        if (!t || !t.isPlayer() || !(e.amount > 0)) return;
        var p = t.asPlayer(), id = uid(p);
        if (!FIGHTERS[id] || !inBout(p)) return;
        if (IFRAMES[id] && RPG.server.getTick() < IFRAMES[id]) { e.cancel(); return; }
        if (!C.get("characters.forceTransformAtHalfHealth") || !fighterRun(p)) return;
        var s = state(p);
        if (s.forced || !(p.maxHealth > 0) || p.health - e.amount > p.maxHealth * 0.5) return;
        s.forced = true;
        setState(p, s);
        var ticks = Math.max(0, Math.floor(Number(C.get("characters.forcedTransformIframeTicks")) || 0));
        if (ticks > 0) IFRAMES[id] = RPG.server.getTick() + ticks;
        forceTransform(p);
    });
    /** StatsDataTournamentFormMixin: any form reads as the flat multiplier for a fighter. Kept as a factor on
     *  dmz_mult that 31_dmz_transform.js carries through its own form updates (it rescales by ratio). */
    function correct(p) {
        var s = state(p), fm = obj(p.getVar("dmz_form_mult", null)), m = obj(p.getVar("dmz_mult", null)), corr = obj(s.corr), changed = false;
        var formed = !!(p.getVar("dmz_form", "") || p.getVar("dmz_stack", "")) && String(p.getVar("dmz_form", "")) !== "androidforms:androidbase";
        var flat = Number(C.get("characters.forcedFormStatMultiplier")) || 1;
        FLAT_KEYS.forEach(function (k) {
            var f = typeof fm[k] === "number" && fm[k] > 0 ? fm[k] : 1;
            var want = formed && flat > 0 ? flat / f : 1, have = typeof corr[k] === "number" && corr[k] > 0 ? corr[k] : 1;
            if (Math.abs(want / have - 1) < 1e-6) return;
            m[k] = (typeof m[k] === "number" ? m[k] : 1) * want / have;
            corr[k] = want;
            changed = true;
        });
        if (!changed) return;
        s.corr = corr;
        setState(p, s);
        p.setVar("dmz_mult", m);
        p.refreshStats();
    }
    var tick = 0;
    RPG.every(1, function () {
        tick++;
        Object.keys(FIGHTERS).forEach(function (id) {
            var e = RPG.world.entityByUuid(id), p = e && e.isPlayer() ? e.asPlayer() : null;
            if (!p) { delete FIGHTERS[id]; return; }
            if (p.getTp() > 0) p.setTp(0);                 // the fighter earns no TP
            if (tick % 5 === 0 && inBout(p)) correct(p);
        });
        if (tick % 20 !== 0) return;
        RPG.server.players().forEach(function (p) {
            var s = state(p);
            if (!s.active) { if (FIGHTERS[uid(p)]) delete FIGHTERS[uid(p)]; return; }
            FIGHTERS[uid(p)] = 1;
            if (s.creating) tickCreation(p);
        });
    });
    // a creation sandbox is never a live match: logging out ends it (ForgeEventHandler.onLogin)
    RPG.on("playerJoin", function (p) { if (isCreating(p)) exit(p); });
    RPG.on("respawn", function (p) {
        // a fighter who somehow died outside a live bout goes back to their own character
        RPG.schedule(2, function () { if (inBout(p) && !fighterRun(p) && !(typeof DBR_TOURNEY !== "undefined" && DBR_TOURNEY.isInTournament(p))) exit(p); });
    });

    // =================================================================================
    //  Screens: the character page and the move picker (LoadoutScreen)
    // =================================================================================
    function view(p) {
        var t = p.getVar(V_TEMPLATE, null), s = state(p);
        return { page: "char", enabled: enabled(), has: !!(t && t.race), race: t && t.race ? t.race : "", cls: t ? t.cls : "",
            pool: allocations(), spent: t ? Object.keys(obj(t.alloc)).reduce(function (a, k) { return a + (Number(t.alloc[k]) || 0); }, 0) : 0,
            unspent: t ? Number(t.sp) || 0 : 0, moves: loadout(p), custom: !!p.getVar(V_LOADOUT, null), active: !!s.active, creating: !!s.creating,
            mult: Number(C.get("characters.forcedFormStatMultiplier")) || 1, forced: !!C.get("characters.forceTransformAtHalfHealth") };
    }
    function openPage(p) { RPG.net.send(p, "dbr_tourney_open", view(p)); }
    function openMoves(p, creation) {
        var t = p.getVar(V_TEMPLATE, null), useLive = creation || !(t && t.race);
        var race = useLive ? String(p.race || "") : t.race, android = useLive ? p.getVar("dmz_android", 0) : obj(t.vars).dmz_android;
        RPG.net.send(p, "dbr_tourney_open", { page: "loadout", ki: kiFor(race, android), strike: strikeFor(race, android), selected: loadout(p),
            kiMax: KI_SLOTS, strikeMax: STRIKE_SLOTS, creation: !!creation });
    }
    function action(p, d) {
        var a = String(d.a || "");
        if (a === "char") { openPage(p); return true; }
        if (!enabled() && a.indexOf("char_") === 0) { p.tell("&cTournament characters are turned off (characters.enabled)."); return true; }
        switch (a) {
            case "char_create": beginCreation(p); return true;
            case "char_build": build(p); openPage(p); return true;
            case "char_delete": remove(p); openPage(p); return true;
            case "char_moves": openMoves(p, isCreating(p)); return true;
            case "char_save": if (setLoadout(p, d.ids) && !isCreating(p)) openPage(p); return true;
            case "char_cancel": cancelCreation(p); return true;
        }
        return false;
    }
    function command(p, args) {
        var op = String(args[0] || "").toLowerCase();
        if (!op) { openPage(p); return; }
        if (!enabled()) { p.tell("&cTournament characters are turned off (characters.enabled)."); return; }
        if (op === "create") beginCreation(p);
        else if (op === "build") build(p);
        else if (op === "moves" || op === "loadout") openMoves(p, isCreating(p));
        else if (op === "delete") remove(p);
        else if (op === "cancel") cancelCreation(p);
        else p.tell("&c/tourney char [create | build | moves | delete | cancel]");
    }

    // /rpg reload: everyone already swapped keeps being watched
    RPG.schedule(20, function () { RPG.server.players().forEach(function (p) { if (isActive(p)) FIGHTERS[uid(p)] = 1; }); });

    return { enabled: enabled, enter: enter, exit: exit, newBout: newBout, isActive: isActive, isCreating: isCreating, inBout: inBout,
        hasTemplate: hasTemplate, build: build, remove: remove, beginCreation: beginCreation, cancelCreation: cancelCreation, setLoadout: setLoadout, action: action, command: command,
        openPage: openPage, openMoves: openMoves, forceTransform: forceTransform,
        // for tests / other scripts
        capture: capture, apply: apply, templateFrom: templateFrom, kitSkills: kitSkills, validLoadout: validLoadout, defaultLoadout: defaultLoadout, correct: correct };
})();
