// =====================================================================================
//  64_dmz_fusion.js - DMZ fusion: the Fusion Dance (Metamoru), Potara earrings and paired
//  Medi-Bug beetles. Port of DragonMine Z's FusionLogic, FusionModeHandler,
//  FusionDanceAligner, FusionStatusHandler, BeetleFusionTracker, the potara-pose part of
//  TickHandler and the fusion parts of ForgeCommonEvents / TPGainEvents (GPL-3.0, NOTICE.md).
// =====================================================================================
//  How players fuse (all DMZ's rules):
//   Dance   pick Fusion in the X menu (dmz_action "FUSION"), hold G (needs skill "fusion",
//           no PvP combat cooldown, no Fusion CD). +10 charge a second. Two dancers within
//           8 blocks are lined up side by side (8-tick glide) and both charges reset; at 100
//           a dancer fuses with a dancer within 5 blocks who is at >= 50. Same race, same
//           form + stack form, no android, total stats within 50 % of each other.
//   Potara  the RIGHT earring's wearer (accessory slot head_tech) leads; a player within 20
//           blocks wearing the matching LEFT earring (same pairId) -> both are pulled together
//           ("potara pose") and fuse at < 1.4 blocks or after 200 ticks. Any race.
//   Beetle  eat a paired Medi-Bug beetle (16_dmz_items.js sets dmz_beetle_pair); the partner
//           eats the other one within 600 ticks within 20 blocks; the earlier eater leads.
//  The fused warrior is the leader: it gets + partner STR/SKP/PWR x mult (dance/beetle
//  1.25-2.0, potara 1.75-2.5 by the stat ratio), the max of both skill levels and form
//  masteries, a mixed name/colours, half its TP goes to the partner. The partner becomes a
//  spectator riding the leader. Ends on the timer (dance 900 s x avg fusion level / 5,
//  potara/beetle 900 s), on death or logout of either (DMZ kills the other one too), or if the
//  partner leaves spectator mode. Fusion CD 1800 s (potara/beetle: not when ended by death;
//  the partner only gets it after a dance). Potara earrings lose 1 durability per fusion and
//  break when the timer runs out.
//
//  Saved (player vars; a fusion left behind by a crash/restart is undone on the next join):
//    dmz_fusion        leader: { leader, partner, pname, type, name, total, color, cross, orig, start, base, bonus }
//                      partner: { leader: false, partner, pname, type, name, nick, gm }
//    dmz_fusion_left   leader: ticks left          dmz_fusion_skills  leader: fused skill levels (46_dmz_skills.js)
//    dmz_fusion_eye2   leader: partner's eye colour (31_dmz_transform.js)
//    dmz_fused         1 while fused (61_dmz_masters.js)   dmz_fusion_hud  {n,t,l,tot,lead,pn} for the timer HUD
//  Effects: dmz_fused / dmz_fused_spectator, dmz_fusion_cd (Fusion CD), dmz_fusion_bonus_<stat>.
//  Config: ragnarok_rpg/config/dbr_fusion.json (DMZ GameplayConfig defaults).
// =====================================================================================
RPG.effects.define("dmz_fused", { name: "Fused", color: "#55FFFF", beneficial: true });
RPG.effects.define("dmz_fused_spectator", { name: "Fused", color: "#55FFFF", beneficial: true,
    flags: ["noKeys", "noSkills", "noAttack", "noUse"] });
RPG.effects.define("dmz_fusion_cd", { name: "Fusion CD", color: "#9A9A9A", keepOnDeath: true });
RPG.effects.define("dmz_fusion_dance", { name: "Fusion Dance", color: "#FFB347", hidden: true, flags: ["noMove", "noJump"] });
RPG.effects.define("dmz_fusion_pose", { name: "Potara", color: "#FFE066", hidden: true, flags: ["noJump", "noAttack"] });
[["STR", "strength"], ["SKP", "strike"], ["RES", "resistance"], ["VIT", "vitality"], ["PWR", "kipower"], ["ENE", "energy"]].forEach(function (s) {
    var st = {}; st[s[1]] = 1;
    RPG.effects.define("dmz_fusion_bonus_" + s[0].toLowerCase(), { name: "Fusion Bonus", hidden: true, maxStacks: 2000000000, stats: st });
});

var DMZ_FUSION = (function () {
    var CFG = dbrConfig("dbr_fusion", {
        fusionDurationSeconds: 900, fusionCooldownSeconds: 1800, metamoruFusionThreshold: 0.5,
        fusionBoosts: ["STR", "SKP", "PWR"],
        // ForgeCommonEvents.endFusionIfNeeded: logging out while fused kills both halves (DMZ)
        killOnLogout: true
    });
    var STAT_IDS = { STR: "strength", SKP: "strike", RES: "resistance", VIT: "vitality", PWR: "kipower", ENE: "energy" };
    var PAIR_RANGE_SQ = 64, GLIDE_TICKS = 8;
    var DEFAULT_REACH = 22.60, SLIM_REACH = 22.08, MAJIN_FAT_REACH = 24.42;
    var POTHALA_LEFT = { pothala_right: "pothala_left", green_pothala_right: "green_pothala_left" };

    var ST = {};          // uuid -> { charging, charge, ticks, combat, req: {uuid: tick} }   (not saved)
    var SLOTS = {};       // FusionDanceAligner slots: uuid -> { partner, aligned, fx, fz, tx, tz, yaw, ticks }
    var POSE = {};        // potara/beetle pose: uuid -> { partner, leader, beetle, t }
    var LEADERS = {}, PARTNERS = {};      // uuids of fused players online
    var BEETLE_SEEN = {};
    var BUSY = {};        // re-entry guard for endFusionIfNeeded (kill() fires "death" again)

    // ---- helpers -----------------------------------------------------------------------
    function num(v, d) { v = Number(v); return isNaN(v) ? d : v; }
    function obj(v) { return v && typeof v === "object" ? v : {}; }
    function copy(o) { var out = {}; for (var k in obj(o)) out[k] = o[k]; return out; }
    function tick() { return RPG.server.getTick(); }
    function st(p) { return ST[p.uuid] || (ST[p.uuid] = { charging: false, charge: 0, ticks: 0, combat: 0, req: {} }); }
    function online(uuid) {
        if (!uuid) return null;
        var list = RPG.server.players();
        for (var i = 0; i < list.length; i++) if (list[i].uuid === uuid) return list[i];
        return null;
    }
    function rec(p) { var r = p.getVar("dmz_fusion", null); return r && typeof r === "object" && r.partner ? r : null; }
    function fused(p) { return !!rec(p); }
    function race(p) { return DMZ_DATA.DMZ[p.race] || p.race || "human"; }
    function android(p) { return !!p.getVar("dmz_android", 0); }
    function skill(p, s) { return typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS.level(p, s) : 0; }
    function baseSkill(p, s) { var m = typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS.levels(p) : {}; return typeof m[s] === "number" ? m[s] : 0; }
    function maxFusionLevel() { return typeof DMZ_SKILLS_DATA !== "undefined" ? Math.max(1, DMZ_SKILLS_DATA.maxLevel("fusion")) : 5; }
    function msg(p, key, args) { if (p) RPG.net.send(p, "dmz_msg", { key: key, args: args || [], color: "#FFFFFF" }); }
    function hud(p, v) { p.setVar("dmz_fusion_hud", v); }
    function totalStats(p) { return DMZ_F.total(dmzView(p)) - bonusTotal(p); }
    function bonusTotal(p) {
        var r = rec(p), t = 0;
        if (r && r.leader) for (var k in obj(r.bonus)) t += num(r.bonus[k], 0);
        return t;
    }
    function ownColor(p, k) {
        var c = p.getColor(k);
        if (c) return String(c);
        var rc = (typeof RACE_COLORS !== "undefined" && RACE_COLORS[p.race]) || {};
        return rc[k] || "#FFFFFF";
    }
    function headTech(p) {
        var s = p.getAccessory("head_tech");
        if (!s || !s.id) return null;
        var id = typeof DMZ_ITEM_BY_REF !== "undefined" ? DMZ_ITEM_BY_REF[s.id] : null;
        if (!id) { var i = String(s.id).indexOf(":"); id = i >= 0 ? String(s.id).substring(i + 1) : String(s.id); }
        return { id: id, stack: s, pairId: s.data && s.data.pairId ? String(s.data.pairId) : "" };
    }
    function distSq(a, b) { var dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z; return dx * dx + dy * dy + dz * dz; }
    function nearbyPlayers(p, r) {
        return p.nearby(r).filter(function (e) { return e.isPlayer(); }).map(function (e) { return e.asPlayer(); });
    }
    function spectator(p) { return String(p.getGameMode()) === "spectator"; }
    // the fused name: a temporary one (never saved, so a crash can't leave it behind) when the engine has it
    function fusedName(p, name, oldNick) {
        if (typeof p.setTempName === "function") { p.setTempName(name || null); return; }
        p.setNick(name || oldNick || "");
    }

    // =================================================================================
    //  Rules (FusionLogic)
    // =================================================================================
    function sameForm(a, b) {
        var fa = String(a.getVar("dmz_form", "") || "").toLowerCase(), fb = String(b.getVar("dmz_form", "") || "").toLowerCase();
        var sa = String(a.getVar("dmz_stack", "") || "").toLowerCase(), sb = String(b.getVar("dmz_stack", "") || "").toLowerCase();
        return fa === fb && sa === sb;
    }
    function metamoruBlocker(l, p) {
        if (android(l) || android(p)) return "message.dragonminez.fusion.android_cannot_fuse";
        if (race(l) !== race(p)) return "message.dragonminez.fusion.different_race";
        if (!sameForm(l, p)) return "message.dragonminez.fusion.different_form";
        var a = totalStats(l), b = totalStats(p), th = num(CFG.metamoruFusionThreshold, 0.5);
        if (th > 0 && Math.max(a, b) > 0 && Math.abs(a - b) / Math.max(a, b) > th) return "message.dragonminez.fusion.level_gap";
        return null;
    }
    function busy(p) { return fused(p) || !!POSE[p.uuid]; }

    function buildFusionName(leaderName, partnerName, type) {
        if (!leaderName) return partnerName;
        if (!partnerName) return leaderName;
        var cmp = leaderName.charAt(0).toLowerCase().charCodeAt(0) - partnerName.charAt(0).toLowerCase().charCodeAt(0);
        if (cmp === 0) cmp = leaderName.toLowerCase() < partnerName.toLowerCase() ? -1 : leaderName.toLowerCase() > partnerName.toLowerCase() ? 1 : 0;
        var alphaFirst = cmp <= 0 ? leaderName : partnerName, alphaSecond = cmp <= 0 ? partnerName : leaderName;
        var first = type === "POTHALA" ? alphaSecond : alphaFirst, second = type === "POTHALA" ? alphaFirst : alphaSecond;
        return first.substring(0, Math.floor((first.length + 1) / 2)) + second.substring(Math.floor((second.length + 1) / 2));
    }
    function mixHex(c1, c2) {
        c1 = String(c1 || "").replace("#", ""); c2 = String(c2 || "").replace("#", "");
        if (!/^[0-9a-fA-F]{6}$/.test(c1) || !/^[0-9a-fA-F]{6}$/.test(c2)) return c1 ? "#" + c1 : "#FFFFFF";
        var a = parseInt(c1, 16), b = parseInt(c2, 16);
        var r = Math.floor((((a >> 16) & 255) + ((b >> 16) & 255)) / 2), g = Math.floor((((a >> 8) & 255) + ((b >> 8) & 255)) / 2),
            bl = Math.floor(((a & 255) + (b & 255)) / 2);
        return "#" + ((1 << 24) + (r << 16) + (g << 8) + bl).toString(16).substring(1).toUpperCase();
    }
    function wearsHair(p) {
        var r = race(p);
        if (r !== "human" && r !== "saiyan") return false;
        var v = String(p.getColor("hairStyle") || "1");
        if (typeof DMZ_HAIR !== "undefined") return DMZ_HAIR.hasVisibleHair(DMZ_HAIR.presetOf(v, r));
        return v !== "bald" && v !== "5" && v !== "0";
    }

    // FusedData.build: skills = leader's, each partner skill merged by max (cross-race: the
    // partner's form skills stay out, DMZ keeps them for the partner-race forms we don't have)
    function fusedSkills(l, p, cross) {
        var out = copy(DMZ_SKILLS.levels(l)), pm = DMZ_SKILLS.levels(p);
        var formSkills = {};
        if (typeof DMZ_SKILLS_DATA !== "undefined") {
            DMZ_SKILLS_DATA.FORM_SKILLS.forEach(function (s) { formSkills[s] = 1; });
            [race(l), race(p)].forEach(function (r) { DMZ_SKILLS_DATA.raceFormSkills(r, false).forEach(function (s) { formSkills[s] = 1; }); });
        }
        Object.keys(pm).forEach(function (s) {
            if (typeof pm[s] !== "number" || (cross && formSkills[s])) return;
            if (typeof out[s] !== "number" || out[s] < pm[s]) out[s] = pm[s];
        });
        return out;
    }
    function mergeMax(a, b) {
        var out = copy(a);
        Object.keys(obj(b)).forEach(function (k) { if (num(b[k], 0) > num(out[k], 0)) out[k] = num(b[k], 0); });
        return out;
    }

    // calculateAndApplyStats: + partner stat x mult, mult = min + ratio x (max - min)
    function applyStats(l, p, type, lvl1, lvl2) {
        var ratio = Math.max(lvl1, lvl2) > 0 ? Math.min(lvl1, lvl2) / Math.max(lvl1, lvl2) : 1;
        var lo = type === "POTHALA" ? 1.75 : 1.25, hi = type === "POTHALA" ? 2.5 : 2.0;
        var mult = lo + ratio * (hi - lo), bonus = {};
        (CFG.fusionBoosts || []).forEach(function (s) {
            s = String(s).toUpperCase();
            if (!STAT_IDS[s]) return;
            var v = Math.round(p.stat(STAT_IDS[s]) * mult);
            if (v <= 0) return;
            l.removeEffect("dmz_fusion_bonus_" + s.toLowerCase());
            l.addEffectStacks("dmz_fusion_bonus_" + s.toLowerCase(), -1, v);
            bonus[s] = v;
        });
        return { mult: mult, bonus: bonus };
    }
    function clearBonus(p) { Object.keys(STAT_IDS).forEach(function (s) { p.removeEffect("dmz_fusion_bonus_" + s.toLowerCase()); }); }

    // FusionLogic.applyFusion
    function applyFusion(l, p, type, lvl1, lvl2, duration, color) {
        var cross = race(l) !== race(p);
        var lm = obj(l.getVar("dmz_mastery", null)), lsm = obj(l.getVar("dmz_stack_mastery", null));
        var pm = obj(p.getVar("dmz_mastery", null)), psm = obj(p.getVar("dmz_stack_mastery", null));
        var m = cross ? copy(lm) : mergeMax(lm, pm), sm = mergeMax(lsm, psm);
        var name = buildFusionName(String(l.name), String(p.name), type);
        var orig = { colors: {}, nick: String(l.getNick() || "") };
        ["body1", "hair", "aura", "hairStyle"].forEach(function (k) { orig.colors[k] = String(l.getColor(k) || ""); });
        var skills = fusedSkills(l, p, cross);
        var r = { v: 1, leader: true, partner: p.uuid, pname: String(p.name), type: type, name: name, total: duration, color: color || "",
            cross: cross, at: tick(), orig: orig, start: { m: copy(m), sm: copy(sm) }, base: { m: copy(lm), sm: copy(lsm) }, bonus: {} };
        var pr = { v: 1, leader: false, partner: l.uuid, pname: String(l.name), type: type, name: name, color: color || "",
            nick: String(p.getNick() || ""), gm: String(p.getGameMode() || "survival") };

        // the partner stops whatever it was doing and rides along as a spectator
        stopCharge(p); clearPose(p); stopCharge(l); clearPose(l);
        p.setVar("dmz_fusion", pr);
        p.setVar("dmz_fused", 1);
        p.setGameMode("spectator");
        p.teleport(l.x, l.y, l.z);
        p.mount(l);
        if (typeof p.spectate === "function") p.spectate(l);         // the partner sees through the leader's eyes
        p.addEffect("dmz_fused_spectator", duration);
        fusedName(p, name);

        l.setVar("dmz_fusion", r);
        l.setVar("dmz_fusion_left", duration);
        l.setVar("dmz_fusion_skills", skills);
        l.setVar("dmz_mastery", m);
        l.setVar("dmz_stack_mastery", sm);
        l.setVar("dmz_fused", 1);
        if (num(skills.potentialunlock, 0) > num(l.getVar("dmz_potential", 0), 0)) l.setVar("dmz_potential", skills.potentialunlock);
        l.addEffect("dmz_fused", duration);
        fusedName(l, name);

        // mixAppearance: body/hair/aura averaged, second eye = partner's eye (+ FusedData hair:
        // a bald/hairless leader takes the partner's hair)
        l.setColor("body1", mixHex(ownColor(l, "body1"), ownColor(p, "body1")));
        l.setColor("aura", mixHex(ownColor(l, "aura"), ownColor(p, "aura")));
        if (!wearsHair(l) && wearsHair(p)) {
            l.setColor("hairStyle", String(p.getColor("hairStyle") || "base"));
            l.setColor("hair", ownColor(p, "hair"));
        } else l.setColor("hair", mixHex(ownColor(l, "hair"), ownColor(p, "hair")));
        l.setVar("dmz_fusion_eye2", ownColor(p, "eyes"));

        var s = applyStats(l, p, type, lvl1, lvl2);
        r.bonus = s.bonus; r.mult = s.mult;
        l.setVar("dmz_fusion", r);
        l.refreshStats();
        LEADERS[l.uuid] = 1; PARTNERS[p.uuid] = 1;
        updateHud(l, r, duration);
        if (typeof DMZ_TF !== "undefined") DMZ_TF.refresh(l);
        if (typeof DMZ_SKILLS !== "undefined") { DMZ_SKILLS.sendState(l); DMZ_SKILLS.sendState(p); }
        // AuraRenderer fusion flash (60 ticks of rays in the aura colour): a burst here
        burst(l, "minecraft:end_rod", 60, 1.2, 0.25);
        burst(l, "minecraft:flash", 1, 0, 0);
        [l, p].forEach(function (who) { RPG.net.send(who, "dmz_fusion", { op: "fused", name: name, type: type, lead: who === l }); });
    }

    function executeMetamoru(l, p) {
        var b = metamoruBlocker(l, p);
        if (b) { msg(l, b); return false; }
        if (busy(l) || busy(p)) return false;
        var lvl1 = totalStats(l), lvl2 = totalStats(p);
        var prom = Math.floor((skill(l, "fusion") + skill(p, "fusion")) / 2);
        var per = Math.floor(num(CFG.fusionDurationSeconds, 900) * 20 / maxFusionLevel());
        applyFusion(l, p, "METAMORU", lvl1, lvl2, Math.max(20, per * prom), "");
        msg(l, "message.dragonminez.fusion.success", [p.name]);
        msg(p, "message.dragonminez.fusion.success", [l.name]);
        return true;
    }
    function executePothala(l, p) {
        if (busy(l) || busy(p)) return;
        var lvl1 = totalStats(l), lvl2 = totalStats(p);
        var h = headTech(l), green = !!h && h.id.indexOf("green") >= 0;
        applyFusion(l, p, "POTHALA", lvl1, lvl2, num(CFG.fusionDurationSeconds, 900) * 20, green ? "green" : "yellow");
        msg(l, "message.dragonminez.fusion.success", [p.name]);
        msg(p, "message.dragonminez.fusion.success", [l.name]);
        sfx(l, "fusion", 1, 1);
        damageEarring(l, 1); damageEarring(p, 1);
    }
    function executeBeetle(l, p) {
        if (busy(l) || busy(p)) return;
        var lvl1 = totalStats(l), lvl2 = totalStats(p);
        applyFusion(l, p, "BEETLE", lvl1, lvl2, num(CFG.fusionDurationSeconds, 900) * 20, "");
        msg(l, "message.dragonminez.fusion.success", [p.name]);
        msg(p, "message.dragonminez.fusion.success", [l.name]);
        sfx(l, "fusion", 1, 1);
    }
    // damageEarring (1) / breakPothala (all): the earring in head_tech
    function damageEarring(p, amount) {
        var h = headTech(p);
        if (!h || h.id.indexOf("pothala") < 0) return;
        var s = h.stack, max = num(s.maxDamage, 3) || 3;
        s.damage = num(s.damage, 0) + amount;
        p.setAccessory("head_tech", s.damage >= max ? null : s);
        if (s.damage >= max) sfx(p, "minecraft:entity.item.break", 1, 1);
    }

    // =================================================================================
    //  Ending (FusionLogic.endFusion / ForgeCommonEvents.endFusionIfNeeded)
    // =================================================================================
    function revertUnownedForms(l) {
        if (typeof DMZ_TF === "undefined") return;
        var FD = DMZ_FORMS, sf = DMZ_TF.activeStack(l), f = DMZ_TF.activeForm(l);
        if (sf && !(skill(l, sf.type) >= sf.lvl && (sf.lvl > 0 || skill(l, sf.type) > 0))) DMZ_TF.setStack(l, null, null);
        if (f) {
            var g = FD.group(race(l), f.group);
            if (!g || DMZ_TF.unlockedForms(l, g).indexOf(f) < 0) {
                l.setVar("dmz_prev", null);
                DMZ_TF.setForm(l, null, null);
            }
        }
        try { DMZ_TF.ensureSelection(l); } catch (e) { /* selection is re-checked on the next menu open */ }
    }
    function reconcile(l, r) {
        // FusedData.reconcileInto: mastery gained while fused goes to the leader's own masteries
        var now = obj(l.getVar("dmz_mastery", null)), nowS = obj(l.getVar("dmz_stack_mastery", null));
        var base = copy(obj(r.base).m), baseS = copy(obj(r.base).sm), start = obj(obj(r.start).m), startS = obj(obj(r.start).sm);
        Object.keys(now).forEach(function (k) { var d = num(now[k], 0) - num(start[k], 0); if (d > 0) base[k] = num(base[k], 0) + d; });
        Object.keys(nowS).forEach(function (k) { var d = num(nowS[k], 0) - num(startS[k], 0); if (d > 0) baseS[k] = num(baseS[k], 0) + d; });
        l.setVar("dmz_mastery", base);
        l.setVar("dmz_stack_mastery", baseS);
    }
    function cleanLeader(l, r, forcedByDeath) {
        reconcile(l, r);
        l.setVar("dmz_fusion_skills", null);
        l.setVar("dmz_potential", baseSkill(l, "potentialunlock"));
        revertUnownedForms(l);
        clearBonus(l);
        var o = obj(r.orig), c = obj(o.colors);
        Object.keys(c).forEach(function (k) { l.setColor(k, c[k] ? c[k] : null); });
        l.setVar("dmz_fusion_eye2", null);
        fusedName(l, null, o.nick);
        var appliesCd = r.type === "METAMORU" || !forcedByDeath;
        if (appliesCd) l.addEffect("dmz_fusion_cd", num(CFG.fusionCooldownSeconds, 1800) * 20);
        ["dmz_fusion", "dmz_fusion_left", "dmz_fused", "dmz_fusion_hud"].forEach(function (k) { l.setVar(k, null); });
        l.removeEffect("dmz_fused");
        delete LEADERS[l.uuid];
        l.refreshStats();
        if (typeof DMZ_TF !== "undefined") DMZ_TF.refresh(l);
        if (typeof DMZ_SKILLS !== "undefined") DMZ_SKILLS.sendState(l);
    }
    function cleanPartner(p, r) {
        if (r.type === "METAMORU") p.addEffect("dmz_fusion_cd", num(CFG.fusionCooldownSeconds, 1800) * 20);
        ["dmz_fusion", "dmz_fused", "dmz_fusion_hud"].forEach(function (k) { p.setVar(k, null); });
        delete PARTNERS[p.uuid];
        p.removeEffect("dmz_fused_spectator");
        p.dismount();
        var gm = String(r.gm || "survival");
        p.setGameMode(gm === "spectator" || !gm ? "survival" : gm);
        p.spectate && p.spectate(null);
        fusedName(p, null, r.nick);
        if (typeof DMZ_SKILLS !== "undefined") DMZ_SKILLS.sendState(p);
    }
    // endFusion(player, forcedByDeath): cleans this player and the other half if it's online
    function endFusion(p, forcedByDeath) {
        var r = rec(p);
        if (!r) return;
        var other = online(r.partner), or = other ? rec(other) : null;
        if (or && or.partner !== p.uuid) { other = null; or = null; }        // not linked any more
        if (r.leader) {
            cleanLeader(p, r, forcedByDeath);
            if (other) cleanPartner(other, or);
        } else {
            if (other) cleanLeader(other, or, forcedByDeath);
            cleanPartner(p, r);
        }
    }
    // endFusionIfNeeded: on death/logout the linked other half is killed as well (DMZ)
    function endFusionIfNeeded(p, kill) {
        if (BUSY[p.uuid]) return;
        var r = rec(p);
        if (!r) return;
        BUSY[p.uuid] = 1;
        try {
            var other = online(r.partner), or = other ? rec(other) : null;
            if (or && or.partner === p.uuid) {
                if (kill && other.alive) { try { other.kill(); } catch (e) { RPG.log("dmz_fusion kill: " + e); } }
                endFusion(other, true);
            }
            endFusion(p, true);
        } finally { delete BUSY[p.uuid]; }
    }

    // =================================================================================
    //  The Fusion Dance: action mode FUSION + G (FusionModeHandler, FusionDanceAligner)
    // =================================================================================
    function canCharge(p) {
        return skill(p, "fusion") > 0 && st(p).combat <= tick() && !p.hasEffect("dmz_fusion_cd") && !busy(p)
            && !p.hasEffect("stunned") && !p.hasEffect("knocked_down") && !spectator(p);
    }
    function mode(p) { return String(p.getVar("dmz_action", "") || ""); }
    function startCharge(p) {
        var s = st(p);
        if (s.charging || !p.getVar("dmz_created", 0) || !canCharge(p)) return;
        s.charging = true; s.charge = 0; s.ticks = 0;
        p.addEffect("dmz_fusion_dance", -1);
        p.setVar("dmz_tf_anim", (typeof DMZ_FORMS !== "undefined" && DMZ_FORMS.D.anim) || "transf.generic");
        p.setVar("dmz_formcharge", 0);
        sendRequests(p);
    }
    function stopCharge(p) {
        var s = ST[p.uuid];
        if (!s || !s.charging) return;
        s.charging = false; s.charge = 0; s.ticks = 0;
        p.removeEffect("dmz_fusion_dance");
        p.setVar("dmz_tf_anim", "");
        p.setVar("dmz_formcharge", 0);
        p.setShared("fusion", null);
        var slot = SLOTS[p.uuid];
        delete SLOTS[p.uuid];
        if (slot) { var o = online(slot.partner); if (o && SLOTS[o.uuid] && SLOTS[o.uuid].partner === p.uuid) { delete SLOTS[o.uuid]; o.setShared("fusion", null); } }
    }
    // the "request": dancers near you get a toast (DMZ shows it only as the dance animation)
    function sendRequests(p) {
        var s = st(p), now = tick();
        nearbyPlayers(p, 8).forEach(function (o) {
            if (busy(o) || skill(o, "fusion") <= 0 || (ST[o.uuid] && ST[o.uuid].charging)) return;
            if (s.req[o.uuid] && now - s.req[o.uuid] < 200) return;
            s.req[o.uuid] = now;
            RPG.net.send(o, "dmz_fusion", { op: "request", name: String(p.name), mode: mode(o) === "FUSION" });
        });
    }
    function dancing(p) { var s = ST[p.uuid]; return !!s && s.charging && !fused(p); }

    function reach(p) {
        var r = race(p), female = String(p.getColor("dmzGender") || "") === "female", px;
        if (r === "majin") px = female ? SLIM_REACH : String(p.getColor("bodyType") || "") === "2" ? DEFAULT_REACH : MAJIN_FAT_REACH;
        else if (female && (r === "human" || r === "saiyan")) px = SLIM_REACH;
        else px = DEFAULT_REACH;
        var scale = typeof DMZ_FORMS !== "undefined" && DMZ_FORMS.D.scale ? DMZ_FORMS.D.scale : 0.9375;
        return px * scale / 16;
    }
    function sideOf(p, o, yaw) {
        var rad = yaw * Math.PI / 180, rx = -Math.cos(rad), rz = -Math.sin(rad);
        return (p.x - o.x) * rx + (p.z - o.z) * rz > 0 ? "left" : "right";
    }
    function pairDance(p) {
        var best = PAIR_RANGE_SQ, partner = null;
        RPG.server.players().forEach(function (o) {
            if (o.uuid === p.uuid || SLOTS[o.uuid] || o.dimension !== p.dimension || !dancing(o)) return;
            var d = distSq(o, p);
            if (d > best) return;
            best = d; partner = o;
        });
        if (!partner) return null;
        var leader = p.uuid < partner.uuid ? p : partner;
        var b = metamoruBlocker(p, partner);
        if (b) {
            msg(p, b); msg(partner, b);
            SLOTS[partner.uuid] = { partner: p.uuid, aligned: false };
            SLOTS[p.uuid] = { partner: partner.uuid, aligned: false };
            p.setShared("fusion", sideOf(p, partner, leader.yaw)); partner.setShared("fusion", sideOf(partner, p, leader.yaw));
            return SLOTS[p.uuid];
        }
        st(p).charge = 0; st(partner).charge = 0;
        var ax = p.x, az = p.z, bx = partner.x, bz = partner.z, dx = bx - ax, dz = bz - az, len = Math.sqrt(dx * dx + dz * dz);
        var D2R = Math.PI / 180, fx, fz;
        if (len < 1e-3) { fx = -Math.sin(p.yaw * D2R); fz = Math.cos(p.yaw * D2R); }
        else {
            fx = -dz / len; fz = dx / len;
            var lookX = -Math.sin(p.yaw * D2R) - Math.sin(partner.yaw * D2R), lookZ = Math.cos(p.yaw * D2R) + Math.cos(partner.yaw * D2R);
            if (fx * lookX + fz * lookZ < 0) { fx = -fx; fz = -fz; }
        }
        var yaw = Math.atan2(-fx, fz) / D2R, rx = -Math.cos(yaw * D2R), rz = -Math.sin(yaw * D2R);
        var mx = (ax + bx) / 2, mz = (az + bz) / 2, side = (ax - mx) * rx + (az - mz) * rz;
        var sign = side > 0 || (side === 0 && p.uuid < partner.uuid) ? 1 : -1;
        var pr = reach(p), qr = reach(partner);
        var px = mx + rx * sign * pr, pz = mz + rz * sign * pr, qx = mx - rx * sign * qr, qz = mz - rz * sign * qr;
        // canStand: no block where we'd glide to (feet and head), else stay put
        function solid(who, x, z) {
            var w = RPG.world;
            return [0, 1].some(function (dy) { var b = w.getBlock(who.dimension, Math.floor(x), Math.floor(who.y) + dy, Math.floor(z)); return b && !/air|grass|flower|torch|snow|carpet|button|sign|fern|sapling|vine/.test(String(b)); });
        }
        try { if (solid(p, px, pz) || solid(partner, qx, qz)) { px = ax; pz = az; qx = bx; qz = bz; } } catch (e) { /* no block query: glide anyway */ }
        SLOTS[p.uuid] = { partner: partner.uuid, aligned: true, fx: ax, fz: az, tx: px, tz: pz, yaw: yaw, ticks: 0 };
        SLOTS[partner.uuid] = { partner: p.uuid, aligned: true, fx: bx, fz: bz, tx: qx, tz: qz, yaw: yaw, ticks: 0 };
        // the dance side each one plays (the client picks it from the leader's facing in DMZ)
        var pSide = ((px - qx) * rx + (pz - qz) * rz) > 0 ? "left" : "right";
        p.setShared("fusion", pSide); partner.setShared("fusion", pSide === "left" ? "right" : "left");
        return SLOTS[p.uuid];
    }
    function alignTick(p) {
        var slot = SLOTS[p.uuid];
        if (slot) {
            var o = online(slot.partner);
            if (!o || o.dimension !== p.dimension || distSq(o, p) > PAIR_RANGE_SQ || !dancing(o)) { delete SLOTS[p.uuid]; p.setShared("fusion", null); slot = null; }
        }
        if (!slot) slot = pairDance(p);
        if (!slot || !slot.aligned || slot.ticks >= GLIDE_TICKS) return;
        slot.ticks++;
        var t = slot.ticks / GLIDE_TICKS, e = t * t * (3 - 2 * t);
        p.teleportTo(p.dimension, slot.fx + (slot.tx - slot.fx) * e, p.y, slot.fz + (slot.tz - slot.fz) * e, slot.yaw, 0);
    }
    function attemptFusion(p) {
        var s = st(p), done = false;
        nearbyPlayers(p, 5).forEach(function (t) {
            if (done) return;
            var ts = ST[t.uuid];
            if (!ts || !ts.charging || ts.charge < 50 || s.charge < 100) return;
            if (executeMetamoru(p, t)) {
                s.charge = 0; ts.charge = 0;
                sfx(p, "fusion", 1, 1);
                done = true;
            }
        });
        return done;
    }
    function maxRelease(p) {
        var mult = p.race === "saiyan" ? 1 + Math.min(0.15, num(p.getVar("dmz_zenkai_release", 0), 0)) : 1;
        return DMZ_F.maxRelease(num(p.getVar("dmz_potential", 0), 0), mult, num(p.getVar("dmzr_release_boost", 0), 0));
    }
    function danceTick(p) {
        var s = st(p);
        if (mode(p) !== "FUSION" || !canCharge(p) || !p.alive) { stopCharge(p); return; }
        s.ticks++;
        alignTick(p);
        // TickHandler: the power release climbs while an action charges
        if (s.ticks % 2 === 0) {
            var rel = num(p.getVar("dmz_release", 0), 0), max = maxRelease(p);
            if (rel < max) p.setVar("dmz_release", Math.min(max, rel + DMZ_F.releaseStep(s.ticks, num(p.getVar("dmz_potential", 0), 0))));
        }
        // handleActionCharge every 20 ticks: +10, at 100 try to fuse (FUSION stays at 100)
        if (s.ticks % 20 === 0) {
            if (s.charge < 100) s.charge = Math.min(100, s.charge + 10);
            if (s.charge >= 100) attemptFusion(p);
            if (ST[p.uuid] && ST[p.uuid].charging) {
                p.setVar("dmz_formcharge", s.charge);
                if (!p.getVar("dmz_tf_anim", "")) p.setVar("dmz_tf_anim", (typeof DMZ_FORMS !== "undefined" && DMZ_FORMS.D.anim) || "transf.generic");
            }
            if (s.ticks % 100 === 0) sendRequests(p);
        }
    }

    // =================================================================================
    //  Potara / beetle pose (TickHandler 278-340, BeetleFusionTracker)
    // =================================================================================
    function startPose(l, p, beetle) {
        stopCharge(l); stopCharge(p);
        POSE[l.uuid] = { partner: p.uuid, leader: true, beetle: !!beetle, t: 1 };
        POSE[p.uuid] = { partner: l.uuid, leader: false, beetle: !!beetle, t: 1 };
        [l, p].forEach(function (w) { w.addEffect("dmz_fusion_pose", -1); });
    }
    function clearPose(p) {
        if (!POSE[p.uuid]) return;
        delete POSE[p.uuid];
        p.removeEffect("dmz_fusion_pose");
        p.setShared("potara", null);
    }
    function poseTick(p) {
        var ps = POSE[p.uuid], o = online(ps.partner);
        if (!o || !o.alive || o.dimension !== p.dimension || p.distanceTo(o) > 24) { clearPose(p); return; }
        var t = ps.t, dx = o.x - p.x, dy = o.y - p.y, dz = o.z - p.z, dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        var speed = Math.min(2.5, 0.02 + t * t * 0.0015);
        if (dist > 0.05) { var step = Math.min(speed, dist) / dist; p.setVelocity(dx * step, dy * step, dz * step); }
        else p.setVelocity(0, 0, 0);
        p.fallDistance = 0;
        ps.t = t + 1;
        if (t % 5 === 1) {
            var leader = p.uuid < o.uuid ? p : o;
            p.setShared("potara", sideOf(p, o, leader.yaw));
        }
        if (ps.leader && (dist < 1.4 || t > 200)) {
            var beetle = ps.beetle;
            clearPose(p);
            if (POSE[o.uuid]) {
                clearPose(o);
                if (beetle) executeBeetle(p, o); else executePothala(p, o);
            }
        }
    }
    function potaraScan(p) {
        if (POSE[p.uuid] || fused(p) || spectator(p)) return;
        var h = headTech(p), counterpart = h ? POTHALA_LEFT[h.id] : null;
        if (!counterpart || !h.pairId) return;
        var others = nearbyPlayers(p, 20);
        for (var i = 0; i < others.length; i++) {
            var o = others[i];
            if (POSE[o.uuid] || fused(o) || spectator(o) || p.distanceTo(o) > 20) continue;
            var oh = headTech(o);
            if (oh && oh.id === counterpart && oh.pairId === h.pairId) { startPose(p, o, false); return; }
        }
    }
    function beetleCanFuse(p) { return !fused(p) && !POSE[p.uuid] && !!p.getVar("dmz_created", 0) && !spectator(p); }
    function beetleScan(p) {
        var b = p.getVar("dmz_beetle_pair", null);
        if (!b || typeof b !== "object" || !b.id) return;
        var now = tick(), key = b.id + "@" + b.until;
        if (now > num(b.until, 0)) {
            p.setVar("dmz_beetle_pair", null); delete BEETLE_SEEN[p.uuid];
            if (beetleCanFuse(p)) msg(p, "message.dragonminez.fusion.beetle.expired");
            return;
        }
        var first = BEETLE_SEEN[p.uuid] !== key;
        BEETLE_SEEN[p.uuid] = key;
        if (!beetleCanFuse(p)) {
            p.setVar("dmz_beetle_pair", null); delete BEETLE_SEEN[p.uuid];
            if (first) msg(p, "message.dragonminez.fusion.beetle.unavailable");
            return;
        }
        var others = nearbyPlayers(p, 20);
        for (var i = 0; i < others.length; i++) {
            var o = others[i], ob = o.getVar("dmz_beetle_pair", null);
            if (!ob || typeof ob !== "object" || String(ob.id) !== String(b.id) || now > num(ob.until, 0)) continue;
            if (p.distanceTo(o) > 20 || !beetleCanFuse(o)) continue;
            p.setVar("dmz_beetle_pair", null); o.setVar("dmz_beetle_pair", null);
            delete BEETLE_SEEN[p.uuid]; delete BEETLE_SEEN[o.uuid];
            if (num(b.until, 0) <= num(ob.until, 0)) startPose(p, o, true); else startPose(o, p, true);
            return;
        }
        if (first) msg(p, "message.dragonminez.fusion.beetle.waiting");
    }

    // =================================================================================
    //  Ticks (FusionStatusHandler: every tick; the timer once a second here)
    // =================================================================================
    function updateHud(l, r, left) {
        var v = { n: r.name, t: r.type, l: Math.max(0, Math.ceil(left / 20)), tot: Math.ceil(num(r.total, 0) / 20), lead: true, pn: r.pname, c: r.color || "" };
        hud(l, v);
        var p = online(r.partner);
        if (p) hud(p, { n: v.n, t: v.t, l: v.l, tot: v.tot, lead: false, pn: String(l.name), c: v.c });
    }
    function leaderTick(l, second) {
        var r = rec(l);
        if (!r || !r.leader) { delete LEADERS[l.uuid]; return; }
        var p = online(r.partner);
        if (!p) { endFusion(l, true); return; }
        if (!p.alive) { endFusion(l, true); return; }
        var pr = rec(p);
        if (!pr || pr.partner !== l.uuid) { endFusion(l, true); return; }
        // ForgeCommonEvents.onGamemodeChange: the partner left spectator mode
        if (!spectator(p) && tick() - num(r.at, 0) > 40) { endFusionIfNeeded(p, true); return; }
        if (p.dimension !== l.dimension) {
            p.dismount();
            p.teleportTo(l.dimension, l.x, l.y, l.z, l.yaw, l.pitch);
            p.mount(l);
            if (typeof p.spectate === "function") p.spectate(l);
        } else if (p.distanceTo(l) > 5) {
            if (!p.vehicle) p.mount(l);
            p.teleport(l.x, l.y, l.z);
        }
        if (!second) return;
        var left = num(l.getVar("dmz_fusion_left", 0), 0) - 20;
        if (left <= 0) {
            var potara = r.type === "POTHALA";
            endFusion(l, false);
            if (potara) { damageEarring(l, 99); if (p) damageEarring(p, 99); }
            return;
        }
        l.setVar("dmz_fusion_left", left);
        updateHud(l, r, left);
    }
    function partnerTick(p) {
        var r = rec(p);
        if (!r || r.leader) { delete PARTNERS[p.uuid]; return; }
        var l = online(r.partner);
        if (!l || !l.alive) endFusion(p, true);
    }

    var T = 0;
    RPG.every(1, function () {
        T++;
        var second = T % 20 === 0;
        Object.keys(LEADERS).forEach(function (u) { var l = online(u); if (!l) delete LEADERS[u]; else leaderTick(l, second); });
        Object.keys(PARTNERS).forEach(function (u) { var p = online(u); if (!p) delete PARTNERS[u]; else partnerTick(p); });
        Object.keys(POSE).forEach(function (u) { var p = online(u); if (!p) delete POSE[u]; else if (POSE[u]) poseTick(p); });
        Object.keys(ST).forEach(function (u) {
            if (!ST[u].charging) return;
            var p = online(u);
            if (!p) { delete ST[u]; delete SLOTS[u]; return; }
            danceTick(p);
        });
        if (T % 10 === 0) {
            RPG.server.players().forEach(function (p) {
                if (!p.getVar("dmz_created", 0)) return;
                if (second) {
                    var r = rec(p);          // re-find fused players after /rpg reload
                    if (r) { if (r.leader) LEADERS[p.uuid] = 1; else PARTNERS[p.uuid] = 1; }
                }
                potaraScan(p);
                beetleScan(p);
            });
        }
    });

    // PvP combat cooldown (CombatEvent: attacker 200 t, victim 120 t) - no fusion right after a fight
    RPG.on("damageFinal", function (e) {
        if (e.isCancelled() || !(e.amount > 0) || !e.target || !e.attacker || !e.target.isPlayer() || !e.attacker.isPlayer()) return;
        var a = e.attacker.asPlayer(), v = e.target.asPlayer();
        if (a.uuid === v.uuid) return;
        var now = tick();
        st(a).combat = Math.max(st(a).combat, now + 200);
        st(v).combat = Math.max(st(v).combat, now + 120);
    });

    RPG.on("death", function (p) {
        stopCharge(p); clearPose(p);
        endFusionIfNeeded(p, true);
    });
    RPG.on("playerLeave", function (p) {
        stopCharge(p); clearPose(p);
        endFusionIfNeeded(p, !!CFG.killOnLogout);
        delete ST[p.uuid]; delete BEETLE_SEEN[p.uuid];
    });
    // a fusion still saved on join (crash, restart, the other half logged out first): undo it
    RPG.on("playerJoin", function (p) {
        RPG.schedule(5, function () {
            p.removeEffect("dmz_fusion_dance"); p.removeEffect("dmz_fusion_pose");
            p.setShared("fusion", null); p.setShared("potara", null);
            if (rec(p)) endFusion(p, true);
            else if (p.getVar("dmz_fused", 0) || p.getVar("dmz_fusion_skills", null)) {
                p.setVar("dmz_fused", null); p.setVar("dmz_fusion_skills", null); p.setVar("dmz_fusion_hud", null); clearBonus(p);
            }
        });
    });

    // ---- the action mode (radial Fusion node -> 62_dmz_radial.js, SwitchActionC2S) and G ----
    function toggleMode(p) {
        if (p.hasEffect("stunned") || p.hasEffect("knocked_down")) return;
        var next = mode(p) !== "FUSION" ? "FUSION" : "FORM";
        p.setVar("dmz_action", next);
        if (next !== "FUSION") {
            stopCharge(p);
            if (typeof DMZ_TF !== "undefined") { try { DMZ_TF.ensureSelection(p); DMZ_TF.sendState(p, false); } catch (e) { /* ok */ } }
        }
    }
    // called by 31_dmz_transform.js for G while dmz_action is "FUSION"
    function key(p, phase) {
        if (phase === "press" || phase === "hold") startCharge(p);
        else if (phase === "release") stopCharge(p);
    }
    // 09_dmz_stats.js dmzTp: TPGainEvents.shareWithFusionPartner (half, unboosted)
    function shareTp(p, gain) {
        var r = rec(p);
        if (!r || !r.leader || !(gain >= 2)) return;
        var o = online(r.partner);
        if (o) o.addTp(Math.floor(gain / 2), { raw: true, events: false, source: "fusion" });
    }

    RPG.commands.register("dmzfusion", {
        permission: 2, description: "/rpgc dmzfusion end|clearcd [player] - end a DMZ fusion / clear the Fusion CD",
        run(p, args) {
            var target = args[1] ? RPG.server.player(String(args[1])) : p;
            if (!target) return;
            if (String(args[0]) === "clearcd") { target.removeEffect("dmz_fusion_cd"); if (p) p.tell("&aFusion CD cleared."); return; }
            if (rec(target)) { endFusion(target, false); if (p) p.tell("&aFusion ended."); }
            else if (p) p.tell("&7Not fused.");
        }
    });

    // the fused partner changed game mode: leaving spectator ends it (after the 2 s grace, like the poll)
    function onGameMode(p, mode) {
        var r = rec(p);
        if (!PARTNERS[p.uuid] || !r || mode === "spectator") return;
        if (tick() - num(r.at, 0) > 40) endFusionIfNeeded(p, true);
    }

    return { onGameMode: onGameMode, toggleMode: toggleMode, key: key, shareTp: shareTp, isFused: fused, record: rec, endFusion: endFusion,
        isDancing: dancing, buildFusionName: buildFusionName, mixHex: mixHex, metamoruBlocker: metamoruBlocker, CFG: CFG };
})();

// ForgeCommonEvents.onGamemodeChange: the partner leaving spectator mode ends the fusion at once (engine event; the
// once-a-second check above stays as a fallback)
RPG.on("gameModeChange", (p, mode) => {
    if (mode === "spectator" || typeof DMZ_FUSION === "undefined" || !DMZ_FUSION.onGameMode) return;
    DMZ_FUSION.onGameMode(p, mode);
});
