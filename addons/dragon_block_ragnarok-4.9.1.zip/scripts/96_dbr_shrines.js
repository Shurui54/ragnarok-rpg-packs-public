// =====================================================================================
//  96_dbr_shrines.js - Shenron shrines and stat shrines (DMZ Ragnarok), server side
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0):
//
//  Shenron shrines (sdu/shenron: ShenronShrineBlock, ShrineConfig, ShrineColorConfig, ShrineWish,
//  ShrineSummon, ShrineModels, ShenronDisplayEntity, Shrine*C2S, ShrineConfigSave):
//    four shrine blocks (blue / gold / green / red). Right-click shows the colour's required
//    offerings; Summon takes them from the whole inventory and calls a non-interactable Shenron
//    (the colour's model, skin and scale) 3 blocks above the shrine, facing you, with night and
//    a storm while it stays (darkenSky). Only the summoner picks ONE of the colour's wishes
//    (empty list = every wish); each wish runs its console commands (%player% = the summoner).
//    The dragon leaves 100 ticks after the wish or when summonDurationTicks run out, putting the
//    time and weather back. Config: wishes + colours, edited in game by operators (/shrine shenron),
//    seeded like config/sdu/shenron_shrines.json (one "riches" wish, a nether star per colour).
//
//  Stat shrines (shuruisutilities: ShrinePlayerData, ShrineEditScreen, ShrineListScreen, DmzBridge,
//  the /shrine command strings; the module itself lived in the closed Ragnarok Key, so its
//  behaviour is rebuilt from those): named shrines bound to any blocks in the world. Right-
//  clicking a bound block gives a timed buff, a STAT shrine one DMZ stat x(1 + percent/100), a
//  TP shrine +percent% TP gain, with a per-player per-shrine cooldown. Buffs are keyed by shrine
//  name, so different shrines stack and re-using the same one refreshes it; they survive relog
//  and death. Ops: /shrine create|delete|list|info|settype|setstat|setpercent|setduration|
//  setcooldown|setdisplay|bind|unbind|gui (and the list/edit screens).
//
//  Hooks into other files (kept tiny): 90_hooks.js multiplies TP by dbrShrineTpFactor(p); the
//  stat buffs fold into the shared "dmz_mult" var the way 58_dmz_machines.js folds gravity.
// =====================================================================================

var DBR_SHRINE_COLORS = ["blue", "gold", "green", "red"];
var DBR_SHRINE_COLOR_NAMES = { blue: "Blue", gold: "Gold", green: "Green", red: "Red" };

// ShrineModels: every Shenron shape and skin a shrine may use, in picker order. A skin is not tied to a shape
// (the four flat DMZ-rig colours share one UV map; Super/Cerulean are 512px maps for the HD serpent), so the
// lists stay flat like DMZ Ragnarok's. The animation follows the shape (a clip only drives its own rig's bones).
var DBR_SHRINE_GEOS = [
    { id: "dbr:geo/entity/shenron.geo.json", label: "Shrine Shenron", anim: DMZ_ANIM + "dragon/shenron.animation.json" },
    { id: DMZ_GEO + "dragon/shenron.geo.json", label: "DMZ Shenron", anim: DMZ_ANIM + "dragon/shenron.animation.json" },
    { id: DMZ_GEO + "dragon/porunga.geo.json", label: "DMZ Porunga", anim: DMZ_ANIM + "dragon/porunga.animation.json" },
    { id: "dbr:geo/entity/shadow_shenron.geo.json", label: "Shadow Shenron", anim: "dbr:animations/entity/shadow_shenron.animation.json" },
    { id: "dbr:geo/entity/dragon/shenron_super.geo.json", label: "Super Shenron", anim: "dbr:animations/entity/dragon/shenron_hd.animation.json" },
    { id: "dbr:geo/entity/dragon/shenron_cerulean.geo.json", label: "Cerulean Shenron", anim: "dbr:animations/entity/dragon/shenron_hd.animation.json" }
];
var DBR_SHRINE_TEXTURES = [
    { id: "dbr:textures/entity/shenron.png", label: "Shrine Shenron" },
    { id: DMZ_TEX + "dragon/shenron.png", label: "DMZ Shenron" },
    { id: DMZ_TEX + "dragon/porunga.png", label: "DMZ Porunga" },
    { id: "dbr:textures/entity/shadow_shenron.png", label: "Shadow Shenron" },
    { id: "dbr:textures/entity/dragon/shenron_apophis.png", label: "Apophis (red)" },
    { id: "dbr:textures/entity/dragon/shenron_green.png", label: "Green" },
    { id: "dbr:textures/entity/dragon/shenron_blue.png", label: "Blue" },
    { id: "dbr:textures/entity/dragon/shenron_delta.png", label: "Delta" },
    { id: "dbr:textures/entity/dragon/shenron_super.png", label: "Super Shenron" },
    { id: "dbr:textures/entity/dragon/shenron_cerulean.png", label: "Cerulean Shenron" }
];

var DBR_SHRINES = (function () {
    var DATA_KEY = "dbr_shenron_shrines", SUMMON_KEY = "dbr_shenron_shrine_summons";
    var DEFAULT_DURATION = 1200;

    // ---- the display dragon: one NPC definition per shape x skin (the engine gives an NPC one model) ----
    function dragonId(g, t) { return "dbr_shrine_dragon_" + g + "_" + t; }
    DBR_SHRINE_GEOS.forEach(function (g, gi) {
        DBR_SHRINE_TEXTURES.forEach(function (t, ti) {
            RPG.npcs.define(dragonId(gi, ti), {
                name: "Shenron",
                geo: { model: g.id, texture: t.id, animation: g.anim, idle: "idle" },
                width: 2, height: 3, immovable: true, invulnerable: true, wander: false,
                // pure spectacle: interaction does nothing (the wish screen comes from the summon)
                onInteract: function () { return false; }
            });
        });
    });
    function indexOf(list, id, fallback) { for (var i = 0; i < list.length; i++) if (list[i].id === id) return i; return fallback; }

    // ---- config (ShrineConfig) ----
    function seedColor() {
        return { requiredItems: [{ item: "minecraft:nether_star", count: 1 }], modelGeo: DBR_SHRINE_GEOS[0].id, modelTexture: DBR_SHRINE_TEXTURES[0].id,
                 entityScale: 1, wishIds: [], darkenSky: true, summonDurationTicks: DEFAULT_DURATION };
    }
    function seed() {
        var c = { configVersion: 1, wishes: [{ id: "riches", name: "Riches", description: "A pile of zeni", commands: ["say %player% wished for riches"] }], colors: {} };
        DBR_SHRINE_COLORS.forEach(function (k) { c.colors[k] = seedColor(); });
        return c;
    }
    function str(v, d) { return v === undefined || v === null ? d : String(v); }
    function cleanWish(o) {
        if (!o || typeof o !== "object") return null;
        var w = { id: str(o.id, "").trim(), name: str(o.name, ""), description: str(o.description, ""), commands: [] };
        if (Array.isArray(o.commands)) o.commands.forEach(function (c) { if (c !== null && c !== undefined && String(c).trim()) w.commands.push(String(c)); });
        return w.id ? w : null;
    }
    function cleanColor(o) {
        var c = seedColor();
        if (!o || typeof o !== "object") return c;
        c.requiredItems = [];
        if (Array.isArray(o.requiredItems)) o.requiredItems.forEach(function (r) {
            if (r && typeof r === "object") c.requiredItems.push({ item: str(r.item, "minecraft:nether_star"), count: Math.max(1, Math.floor(Number(r.count) || 1)) });
        });
        if (o.modelGeo) c.modelGeo = String(o.modelGeo).trim();
        if (o.modelTexture) c.modelTexture = String(o.modelTexture).trim();
        var sc = Number(o.entityScale);
        c.entityScale = sc > 0 ? sc : 1;
        c.wishIds = Array.isArray(o.wishIds) ? o.wishIds.map(function (x) { return String(x); }) : [];
        c.darkenSky = o.darkenSky === undefined ? true : !!o.darkenSky;
        c.summonDurationTicks = o.summonDurationTicks === undefined ? DEFAULT_DURATION : Math.max(1, Math.floor(Number(o.summonDurationTicks) || DEFAULT_DURATION));
        return c;
    }
    /** ShrineConfigSave: broken entries skipped, duplicate wish ids last-wins (re-appended), every colour present. */
    function clean(root) {
        var out = { configVersion: 1, wishes: [], colors: {} }, byId = {};
        if (root && Array.isArray(root.wishes)) root.wishes.forEach(function (o) {
            var w = cleanWish(o);
            if (!w) return;
            if (byId[w.id] !== undefined) out.wishes.splice(byId[w.id], 1);
            out.wishes.push(w);
            byId = {}; out.wishes.forEach(function (x, i) { byId[x.id] = i; });
        });
        DBR_SHRINE_COLORS.forEach(function (k) { out.colors[k] = cleanColor(root && root.colors ? root.colors[k] : null); });
        return out;
    }
    var CFG = null;
    function cfg() {
        if (CFG) return CFG;
        var saved = RPG.data.get(DATA_KEY, null);
        if (!saved) { CFG = seed(); RPG.data.set(DATA_KEY, CFG); console.log("[DBR] Seeded default Shenron-shrine config."); }
        else CFG = clean(saved);
        return CFG;
    }
    function color(k) { return cfg().colors[k] || seedColor(); }
    function wishById(id) { var l = cfg().wishes; for (var i = 0; i < l.length; i++) if (l[i].id === id) return l[i]; return null; }
    function wishesFor(k) {
        var c = color(k);
        if (!c.wishIds || !c.wishIds.length) return cfg().wishes.slice();
        var out = [];
        c.wishIds.forEach(function (id) { var w = wishById(id); if (w) out.push(w); });
        return out;
    }

    // ---- offerings (ShrineSummon: matched by item only, counted across the whole inventory) ----
    var ITEM_IDS = null;
    function known(id) {
        if (!id) return false;
        if (!ITEM_IDS) { ITEM_IDS = {}; try { RPG.server.registryIds("item").forEach(function (i) { ITEM_IDS[i] = 1; }); } catch (e) { } }
        return !!ITEM_IDS[id] || id.indexOf(":") < 0;                  // script item names ("senzu_bean") count as known
    }
    function hasItems(p, req) {
        for (var i = 0; i < (req || []).length; i++) {
            var r = req[i];
            if (!r.item || !known(r.item)) continue;      // a typo can't hard-lock a shrine
            if (p.countItem(r.item) < Math.max(1, r.count)) return false;
        }
        return true;
    }
    function takeItems(p, req) { (req || []).forEach(function (r) { if (r.item && known(r.item)) p.takeItem(r.item, Math.max(1, r.count)); }); }

    // ---- the shrine blocks ----
    function shrineBlock(k) {
        RPG.blocks.define("shenron_shrine_" + k, {
            name: DBR_SHRINE_COLOR_NAMES[k] + " Shenron Shrine",
            model: "dbr:rpg/block/shenron_shrine_" + k,
            decor: true, hardness: 3, requiresTool: true, renderType: "cutout",
            onUse: function (p, x, y, z) { openShrine(p, k, x, y, z); }
        });
    }
    DBR_SHRINE_COLORS.forEach(shrineBlock);

    function openShrine(p, k, x, y, z) {
        var c = color(k);
        RPG.net.send(p, "dbr_shrine_open", { x: x, y: y, z: z, color: k, hasItems: hasItems(p, c.requiredItems),
            required: c.requiredItems.map(function (r) { var n = ""; try { n = RPG.items.name(r.item); } catch (e) { } return { item: r.item, count: r.count, name: n || r.item }; }) });
    }

    // ---- summons (ShenronDisplayEntity's lifetime, persisted so a restart still puts the sky back) ----
    var SUMMONS = RPG.data.get(SUMMON_KEY, null) || {};       // uuid -> {owner, color, dim, x,y,z, born, life, granted, despawnAt, darken, savedTime}
    function saveSummons() { RPG.data.set(SUMMON_KEY, SUMMONS); }
    function now() { return RPG.world.gameTime(""); }

    RPG.net.on("dbr_shrine_summon", function (p, d) {
        if (!d) return;
        var k = String(d.color), x = Math.floor(Number(d.x)), y = Math.floor(Number(d.y)), z = Math.floor(Number(d.z));
        if (DBR_SHRINE_COLORS.indexOf(k) < 0) return;
        // anti-spoof: that colour's shrine, loaded, within 8 blocks
        if (!RPG.world.isLoaded(p.dimension, x, z)) return;
        var dx = p.x - (x + 0.5), dy = p.y - (y + 0.5), dz = p.z - (z + 0.5);
        if (dx * dx + dy * dy + dz * dz > 64) return;
        if (RPG.world.getBlock(p.dimension, x, y, z) !== RPG.blocks.id("shenron_shrine_" + k)) return;
        var c = color(k);
        if (!hasItems(p, c.requiredItems)) { p.actionbar("&cYou are missing required offerings."); return; }
        var g = indexOf(DBR_SHRINE_GEOS, c.modelGeo, 0), t = indexOf(DBR_SHRINE_TEXTURES, c.modelTexture, 0);
        var bx = x + 0.5, by = y + 3.5, bz = z + 0.5;                       // ~3 blocks above the shrine
        var e = RPG.world.spawnNpc(p.dimension, dragonId(g, t), bx, by, bz, { scale: c.entityScale });
        if (!e) { p.actionbar("&cYou are missing required offerings."); return; }
        takeItems(p, c.requiredItems);
        try { e.lookAt(p.x, p.eyeY, p.z); } catch (er) { }
        var s = { owner: p.uuid, color: k, dim: p.dimension, x: x, y: y, z: z, born: now(), life: c.summonDurationTicks,
                  granted: false, despawnAt: -1, darken: !!c.darkenSky, savedTime: RPG.world.getTime(p.dimension) };
        SUMMONS[e.uuid] = s;
        saveSummons();
        if (s.darken) {                                                    // night + a storm for the whole summon
            RPG.server.runCommand("execute in " + p.dimension + " run time set 18000");
            RPG.world.setWeather(p.dimension, "thunder", c.summonDurationTicks);
        }
        RPG.world.sound(p.dimension, DMZ + "shenron", x + 0.5, y + 0.5, z + 0.5, 1, 1);
        RPG.net.send(p, "dbr_shrine_wishes", { dragon: e.uuid, color: k,
            wishes: wishesFor(k).map(function (w) { return { id: w.id, name: w.name, description: w.description }; }) });
    });

    RPG.net.on("dbr_shrine_wish", function (p, d) {
        if (!d) return;
        var s = SUMMONS[d.dragon], e = d.dragon ? RPG.world.entityByUuid(String(d.dragon)) : null;
        if (!s || !e || !e.isAlive()) return;
        if (s.owner !== p.uuid) return;                                    // only the summoner may wish
        if (s.granted) { p.actionbar("&cShenron has already granted a wish."); return; }
        var k = String(d.color);
        if (k !== s.color) return;
        var ok = wishesFor(k).some(function (w) { return w.id === d.wish; });
        var w = ok ? wishById(String(d.wish)) : null;
        if (!w) return;
        (w.commands || []).forEach(function (cmd) {
            if (!cmd || !String(cmd).trim()) return;
            try { RPG.server.runCommand(String(cmd).replace(/%player%/g, p.name)); }
            catch (er) { console.warn("[DBR] Shrine wish command failed '" + cmd + "': " + er); }
        });
        s.granted = true;
        s.despawnAt = now() + 100;                                         // DMZ's 100-tick goodbye
        saveSummons();
    });

    function leave(uuid) {
        var s = SUMMONS[uuid];
        delete SUMMONS[uuid];
        saveSummons();
        var e = RPG.world.entityByUuid(uuid);
        if (e) e.remove();
        if (s && s.darken) {                                               // put it back exactly like DMZ
            RPG.world.setWeather(s.dim, "clear", 6000);
            if (s.savedTime >= 0) RPG.server.runCommand("execute in " + s.dim + " run time set " + Math.floor(s.savedTime % 24000));
        }
    }
    RPG.every(20, function () {
        var t = now(), changed = false;
        Object.keys(SUMMONS).forEach(function (u) {
            var s = SUMMONS[u];
            if ((s.despawnAt >= 0 && t >= s.despawnAt) || t - s.born >= s.life) { leave(u); return; }
            var e = RPG.world.entityByUuid(u);
            if (!e && RPG.world.isLoaded(s.dim, s.x, s.z)) { leave(u); changed = true; }   // gone (killed, /kill): restore the sky
        });
        if (changed) saveSummons();
    });

    // ---- the operator editor (ShrineConfigScreen) ----
    function canEdit(p) { return !!p && (p.isOp() || RPG.perms.has(p, "dbr.shrine.edit")); }
    function openConfig(p) {
        if (!canEdit(p)) { p.tell("&cYou don't have permission to edit Shenron shrines."); return; }
        RPG.net.send(p, "dbr_shrine_config", { config: cfg(),
            geos: DBR_SHRINE_GEOS.map(function (g) { return { v: g.id, l: g.label }; }),
            textures: DBR_SHRINE_TEXTURES.map(function (t) { return { v: t.id, l: t.label }; }) });
    }
    RPG.net.on("dbr_shrine_config_save", function (p, d) {
        if (!canEdit(p)) return;
        if (!d || typeof d.config !== "object" || !d.config) { p.tell("&cShrine config save failed: malformed payload."); return; }
        CFG = clean(d.config);
        RPG.data.set(DATA_KEY, CFG);
        p.tell("&aSaved Shenron shrine config (" + CFG.wishes.length + " wish(es)).");
    });
    RPG.net.on("dbr_shrine_config_open", function (p) { openConfig(p); });

    return { config: cfg, openConfig: openConfig, wishesFor: wishesFor, summons: function () { return SUMMONS; } };
})();

// =====================================================================================
//  Stat shrines
// =====================================================================================
var DBR_STAT_SHRINES = (function () {
    var DATA_KEY = "dbr_stat_shrines";
    // Shrine.toml (ConfigShrine lived in the closed Ragnarok Key; these are the knobs its messages name)
    var CFG = dbrConfig("dbr_shrines", {
        maxPercent: { default: 100, min: 0, max: 100000, comment: "Highest boost a shrine may give, in percent (\"Percent capped at ...% by config\")." },
        maxDurationSeconds: { default: 86400, min: 1, max: 31536000, integer: true, comment: "Longest buff a shrine may give, in seconds (\"Duration capped at ... by config\")." },
        allowedStats: { default: ["STR", "SKP", "RES", "STM", "VIT", "PWR", "ENE"], comment: "Stats a STAT shrine may boost (DMZ keys; RES boosts defense)." }
    });
    var STAT_KEYS = ["STR", "SKP", "RES", "STM", "VIT", "PWR", "ENE"];
    var STAT_NAMES = { STR: "Strength", SKP: "Strike Power", RES: "Resistance", STM: "Stamina", VIT: "Vitality", PWR: "Ki Power", ENE: "Energy" };
    function multKey(stat) { return stat === "RES" ? "DEF" : stat; }       // DmzBridge.bonusKey: RES is written under DEF

    RPG.effects.define("dbr_shrine_stat", { name: "Shrine Blessing", color: "#FFD700", beneficial: true, keepOnDeath: true });
    RPG.effects.define("dbr_shrine_tp", { name: "Shrine TP Boost", color: "#55FFFF", beneficial: true, keepOnDeath: true });

    var SHRINES = RPG.data.get(DATA_KEY, null) || {};                       // name -> {displayName, type, statKey, percent, duration, cooldown, bindings: ["dim x y z"]}
    var BOUND = {};                                                         // "dim x y z" -> name
    function save() { RPG.data.set(DATA_KEY, SHRINES); index(); }
    function index() { BOUND = {}; Object.keys(SHRINES).forEach(function (n) { (SHRINES[n].bindings || []).forEach(function (b) { BOUND[b] = n; }); }); }
    index();
    function posKey(dim, x, y, z) { return dim + " " + x + " " + y + " " + z; }
    function allowed() { var a = CFG.allowedStats; return Array.isArray(a) && a.length ? a.map(function (s) { return String(s).toUpperCase(); }) : STAT_KEYS; }
    function maxPct() { return Number(CFG.maxPercent) || 100; }
    function maxDur() { return Math.floor(Number(CFG.maxDurationSeconds) || 86400); }

    /** StringUtil.formatDuration: H:MM:SS. */
    function hms(sec) {
        sec = Math.max(0, Math.floor(sec));
        var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
        return h + ":" + (m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s;
    }
    function trimNum(v) { v = Number(v) || 0; return v === Math.round(v) ? String(Math.round(v)) : String(v); }
    function display(name) { var s = SHRINES[name]; return s && s.displayName ? s.displayName : name; }

    // ---- per-player data (ShrinePlayerData: one entry per shrine name, epoch millis) ----
    function pdata(p) {
        var d = p.getVar("dbr_shrine", null);
        if (!d || typeof d !== "object") d = {};
        if (!d.stats) d.stats = {};
        if (!d.tps) d.tps = {};
        if (!d.cd) d.cd = {};
        return d;
    }
    function setPdata(p, d) { p.setVar("dbr_shrine", d); }

    /** Fold the live stat buffs into dmz_mult (rescaling what this file folded in before, like gravity does). */
    function applyStats(p, d) {
        var want = {};
        Object.keys(d.stats).forEach(function (n) {
            var b = d.stats[n], k = multKey(b.statKey);
            if (STAT_KEYS.indexOf(b.statKey) < 0 || !(b.pct > 0)) return;
            want[k] = (want[k] || 1) * (1 + b.pct / 100);
        });
        var old = p.getVar("dbr_shrine_mult", null) || {}, keys = {}, changed = false;
        Object.keys(old).forEach(function (k) { keys[k] = 1; });
        Object.keys(want).forEach(function (k) { keys[k] = 1; });
        var m = p.getVar("dmz_mult", null) || {}, o = {};
        Object.keys(m).forEach(function (k) { o[k] = m[k]; });
        Object.keys(keys).forEach(function (k) {
            var was = Number(old[k]) || 1, now = want[k] || 1;
            if (Math.abs(was - now) < 1e-9) return;
            var cur = typeof o[k] === "number" ? o[k] : 1;
            o[k] = cur / was * now;
            changed = true;
        });
        if (!changed) return;
        p.setVar("dmz_mult", o);
        p.setVar("dbr_shrine_mult", want);
        p.refreshStats();
    }
    /** The TP-gain factor of a player's shrine buffs (percents add up, like TpBoostState). */
    function tpFactor(p) {
        var d = p.getVar("dbr_shrine", null);
        if (!d || !d.tps) return 1;
        var t = Date.now(), sum = 0;
        Object.keys(d.tps).forEach(function (n) { var b = d.tps[n]; if (b.until > t && b.pct > 0) sum += b.pct; });
        return 1 + sum / 100;
    }
    function pips(p, d) {                                                   // the effect icons show the longest buff left
        var t = Date.now(), ls = 0, lt = 0;
        Object.keys(d.stats).forEach(function (n) { ls = Math.max(ls, d.stats[n].until - t); });
        Object.keys(d.tps).forEach(function (n) { lt = Math.max(lt, d.tps[n].until - t); });
        if (ls > 0) p.addEffect("dbr_shrine_stat", Math.ceil(ls / 50)); else if (p.hasEffect("dbr_shrine_stat")) p.removeEffect("dbr_shrine_stat");
        if (lt > 0) p.addEffect("dbr_shrine_tp", Math.ceil(lt / 50)); else if (p.hasEffect("dbr_shrine_tp")) p.removeEffect("dbr_shrine_tp");
    }
    function tick(p) {
        var d = p.getVar("dbr_shrine", null);
        if (!d) { if (p.getVar("dbr_shrine_mult", null)) applyStats(p, { stats: {} }); return; }
        d = pdata(p);
        var t = Date.now(), dirty = false;
        ["stats", "tps", "cd"].forEach(function (k) {
            Object.keys(d[k]).forEach(function (n) {
                var until = k === "cd" ? d[k][n] : d[k][n].until;
                if (until <= t) { delete d[k][n]; dirty = true; if (k === "stats") p.tell("&7The blessing of " + display(n) + "&7 fades."); }
            });
        });
        if (dirty) setPdata(p, d);
        applyStats(p, d);
        if (dirty) pips(p, d);
    }
    RPG.every(20, function () { RPG.server.players().forEach(tick); });
    RPG.on("playerJoin", function (p) { var d = pdata(p); applyStats(p, d); pips(p, d); });
    RPG.on("respawn", function (p) { var d = pdata(p); applyStats(p, d); pips(p, d); });

    // ---- activation: right-click a bound block ----
    function activate(p, name) {
        var s = SHRINES[name];
        if (!s) return;
        var d = pdata(p), t = Date.now();
        if (d.cd[name] && d.cd[name] > t) { p.actionbar("&eThe " + display(name) + "&e is dormant. Try again in " + hms((d.cd[name] - t) / 1000) + "."); return; }
        var pct = Math.min(maxPct(), Math.max(0, Number(s.percent) || 0)), dur = Math.min(maxDur(), Math.max(0, Math.floor(Number(s.duration) || 0)));
        if (pct <= 0 || dur <= 0) { p.actionbar("&7The " + display(name) + "&7 is silent."); return; }
        var until = t + dur * 1000;
        if (s.type === "TP") {
            d.tps[name] = { pct: pct, until: until };
            p.tell("&a" + display(name) + "&a blesses you: &f+" + trimNum(pct) + "% TP gain &afor &f" + hms(dur) + "&a.");
        } else {
            var stat = STAT_KEYS.indexOf(s.statKey) >= 0 ? s.statKey : "STR";
            d.stats[name] = { statKey: stat, pct: pct, until: until };
            p.tell("&a" + display(name) + "&a blesses you: &f+" + trimNum(pct) + "% " + STAT_NAMES[stat] + " &afor &f" + hms(dur) + "&a.");
        }
        if (Number(s.cooldown) > 0) d.cd[name] = t + Math.floor(Number(s.cooldown)) * 1000;
        setPdata(p, d);
        applyStats(p, d);
        pips(p, d);
        RPG.world.sound(p.dimension, "minecraft:block.beacon.power_select", p.x, p.y, p.z, 1, 1.2);
        RPG.world.particle(p.dimension, "minecraft:totem_of_undying", p.x, p.y + 1, p.z, 30, 0.6, 0.15);
    }
    RPG.on("blockInteract", function (p, block, x, y, z, dim) {
        var n = BOUND[posKey(dim, x, y, z)];
        if (!n) return;
        activate(p, n);
        return false;
    });

    // ---- editing (/shrine and the editor screens) ----
    function canEdit(p) { return !p || p.isOp() || RPG.perms.has(p, "dbr.shrine.edit"); }
    function blank(display) { return { displayName: display || "", type: "STAT", statKey: "STR", percent: 0, duration: 0, cooldown: 0, bindings: [] }; }
    function looked(p) {
        var r = p.raycast(6, { blocks: true, entities: false });
        return r && r.hit === "block" ? { x: r.blockX, y: r.blockY, z: r.blockZ } : null;
    }
    function rows() {
        return Object.keys(SHRINES).sort().map(function (n) { var s = SHRINES[n]; return { name: n, type: s.type, stat: s.statKey, percent: s.percent, duration: s.duration, cooldown: s.cooldown, bound: (s.bindings || []).length }; });
    }
    function sendList(p) { RPG.net.send(p, "dbr_stat_shrine_list", { rows: rows() }); }
    function sendEdit(p, n) {
        var s = SHRINES[n];
        if (!s) { sendList(p); return; }
        RPG.net.send(p, "dbr_stat_shrine_edit", { name: n, shrine: s, stats: allowed(), maxPercent: maxPct(), maxDuration: maxDur() });
    }
    function setNum(p, n, key, raw, cap) {
        var v = Number(raw);
        if (isNaN(v) || v < 0) { p && p.tell("&cThe string " + raw + " is not a valid number"); return false; }
        if (cap !== undefined && v > cap) { v = cap; p && p.tell("&e" + (key === "percent" ? "Percent capped at " + trimNum(cap) + "% by config." : "Duration capped at " + hms(cap) + " by config.")); }
        SHRINES[n][key] = key === "percent" ? v : Math.floor(v);
        return true;
    }
    RPG.net.on("dbr_stat_shrine", function (p, d) {
        if (!canEdit(p) || !d) return;
        var n = String(d.name || "").trim(), s = SHRINES[n];
        switch (d.op) {
            case "list": sendList(p); return;
            case "open": sendEdit(p, n); return;
            case "new":
                if (!n || !/^[A-Za-z0-9_\-]{1,64}$/.test(n)) { p.tell("&cShrine names are letters, digits, _ and - (max 64)."); return; }
                if (s) { p.tell("&cA shrine named '" + n + "' already exists."); return; }
                SHRINES[n] = blank(); save(); sendEdit(p, n); return;
            case "copy":
                var to = String(d.to || "").trim();
                if (!s || !to || SHRINES[to]) return;
                var c = JSON.parse(JSON.stringify(s)); c.bindings = []; SHRINES[to] = c; save(); sendList(p); return;
            case "delete":
                if (!s) return;
                delete SHRINES[n]; save(); p.tell("&aDeleted shrine '" + n + "'."); sendList(p); return;
            case "unbind":
                if (!s) return;
                s.bindings = (s.bindings || []).filter(function (b) { return b !== d.key; }); save(); p.tell("&aUnbound shrine block " + d.key + "."); sendEdit(p, n); return;
            case "save":
                if (!s) return;
                s.displayName = String(d.displayName || "").substring(0, 128);
                s.type = d.type === "TP" ? "TP" : "STAT";
                var st = String(d.statKey || "STR").toUpperCase();
                if (allowed().indexOf(st) < 0) { p.tell("&cStat '" + st + "' is not a valid/allowed stat. Allowed: " + allowed().join(", ")); return; }
                s.statKey = st;
                if (!setNum(p, n, "percent", d.percent, maxPct())) return;
                if (!setNum(p, n, "duration", d.duration, maxDur())) return;
                if (!setNum(p, n, "cooldown", d.cooldown)) return;
                save(); p.tell("&aSaved shrine '" + n + "'."); sendEdit(p, n); return;
        }
    });

    function info(who, n) {
        var s = SHRINES[n], t = function (m) { if (who) who.tell(m); else console.log(m); };
        t("&6Shrine '" + n + "':");
        t("&7  display: &f" + (s.displayName || n));
        t("&7  type: &f" + s.type);
        if (s.type !== "TP") t("&7  stat: &f" + s.statKey);
        t("&7  percent: &f" + trimNum(s.percent) + "%");
        t("&7  duration: &f" + s.duration + "s (" + hms(s.duration) + ")");
        t("&7  cooldown: &f" + s.cooldown + "s (" + hms(s.cooldown) + ")");
        t("&7  bound blocks: &f" + (s.bindings || []).length);
    }
    var HELP = "&7/shrine create <name> | delete <name> | list | info <name> | settype <name> STAT|TP | setstat <name> <stat> | setpercent <name> <n> | " +
               "setduration <name> <seconds> | setcooldown <name> <seconds> | setdisplay <name> <text> | bind <name> | unbind | gui | shenron";
    RPG.commands.register("shrine", { root: true, aliases: ["shrines"], permission: 2, description: "Shrines: /shrine help",
        suggest: function (p, args) {
            if (args.length <= 1) return ["create", "delete", "list", "info", "settype", "setstat", "setpercent", "setduration", "setcooldown", "setdisplay", "bind", "unbind", "gui", "shenron"];
            if (args.length === 2 && args[0] !== "create") return Object.keys(SHRINES);
            if (args.length === 3 && args[0] === "settype") return ["STAT", "TP"];
            if (args.length === 3 && args[0] === "setstat") return allowed();
            return [];
        },
        run: function (p, args) {
            var t = function (m) { if (p) p.tell(m); else console.log(m); };
            var sub = (args[0] || "").toLowerCase(), n = args[1], s = n ? SHRINES[n] : null;
            var need = function () { if (!s) { t("&cNo shrine named '" + n + "'."); return false; } return true; };
            switch (sub) {
                case "gui": case "edit": if (p) sendList(p); return;
                case "shenron": case "shenronconfig": if (p) DBR_SHRINES.openConfig(p); return;
                case "create":
                    if (!n || !/^[A-Za-z0-9_\-]{1,64}$/.test(n)) { t("&cUse /shrine create <name> (letters, digits, _ and -)."); return; }
                    if (s) { t("&cA shrine named '" + n + "' already exists."); return; }
                    SHRINES[n] = blank(args.slice(2).join(" ")); save();
                    t("&aCreated shrine '" + n + "'. Configure it with /shrine settype/setstat/setpercent, then /shrine bind (looking at a block)."); return;
                case "delete": if (!need()) return; delete SHRINES[n]; save(); t("&aDeleted shrine '" + n + "'."); return;
                case "list":
                    var names = Object.keys(SHRINES).sort();
                    if (!names.length) { t("&7No shrines defined."); return; }
                    t("&6Shrines:");
                    names.forEach(function (k) { var x = SHRINES[k]; t("&7- " + k + " (" + (x.type === "TP" ? "TP" : x.type + " " + x.statKey) + " +" + trimNum(x.percent) + "%, " + x.duration + "s, cd " + x.cooldown + "s)"); });
                    return;
                case "info": if (!need()) return; info(p, n); return;
                case "settype":
                    if (!need()) return;
                    var ty = String(args[2] || "").toUpperCase();
                    if (ty !== "STAT" && ty !== "TP") { t("&cType must be STAT or TP."); return; }
                    s.type = ty; save(); t("&aSet type of '" + n + "' to " + ty + "."); return;
                case "setstat":
                    if (!need()) return;
                    var st = String(args[2] || "").toUpperCase();
                    if (allowed().indexOf(st) < 0) { t("&cStat '" + st + "' is not a valid/allowed stat. Allowed: " + allowed().join(", ")); return; }
                    s.statKey = st; save(); t("&aSet stat of '" + n + "' to " + st + "."); return;
                case "setpercent": if (!need() || !setNum(p, n, "percent", args[2], maxPct())) return; save(); t("&aSet percent of '" + n + "' to " + trimNum(s.percent) + "%."); return;
                case "setduration": if (!need() || !setNum(p, n, "duration", args[2], maxDur())) return; save(); t("&aSet duration of '" + n + "' to " + hms(s.duration) + "."); return;
                case "setcooldown": if (!need() || !setNum(p, n, "cooldown", args[2])) return; save(); t("&aSet cooldown of '" + n + "' to " + hms(s.cooldown) + "."); return;
                case "setdisplay":
                    if (!need()) return;
                    s.displayName = args.slice(2).join(" "); save(); t("&aSet display name of '" + n + "' to " + s.displayName + "&a."); return;
                case "bind":
                    if (!p) return;
                    if (!need()) return;
                    var b = looked(p);
                    if (!b) { t("&cLook at a block to bind it as a shrine."); return; }
                    var key = posKey(p.dimension, b.x, b.y, b.z);
                    if (BOUND[key] && BOUND[key] !== n) SHRINES[BOUND[key]].bindings = SHRINES[BOUND[key]].bindings.filter(function (k) { return k !== key; });
                    s.bindings = s.bindings || [];
                    if (s.bindings.indexOf(key) < 0) s.bindings.push(key);
                    save(); t("&aBound block " + key + " to shrine '" + n + "'."); return;
                case "unbind":
                    if (!p) return;
                    var u = looked(p);
                    if (!u) { t("&cLook at the shrine block to unbind it."); return; }
                    var uk = posKey(p.dimension, u.x, u.y, u.z), owner = BOUND[uk];
                    if (!owner) { t("&cThat block is not bound to a shrine."); return; }
                    SHRINES[owner].bindings = SHRINES[owner].bindings.filter(function (k) { return k !== uk; });
                    save(); t("&aUnbound shrine block " + uk + "."); return;
                default: t(HELP);
            }
        } });

    return { tpFactor: tpFactor, shrines: function () { return SHRINES; }, activate: activate, hms: hms };
})();

/** TP multiplier from the player's shrine buffs (read by 90_hooks.js's single tpGain handler). */
function dbrShrineTpFactor(p) { try { return DBR_STAT_SHRINES.tpFactor(p); } catch (e) { return 1; } }
