// =====================================================================================
//  44_dbr_ragnarok_combat.js - DMZ Ragnarok's combat layer: the dash, the sonic boom /
//  crash through terrain, the melee clash and the NPC lunge
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0), shuruisutilities/combat:
//    DashService + DashCost + DashCooldownEffect   double-tap the Ragnarok Dash key (R): a
//        committed run at whoever you aim at (104 blocks, crosshair ray then a look cone),
//        along a planned curve: W/none straight in (hits and stops; the only one that can
//        clash), A/D round to their left/right flank, S over the top and down behind them.
//        Nobody aimed at: an 18-block burst where you look. 5 % of max ki and stamina, 5 s
//        cooldown. The client flies the curve (DashLocalMotion); the server plans, watches and
//        only pulls a player back who strays 10+ blocks from it.
//    SonicBoomService + SonicCrash                 double-tap sprint while flying with Fly at
//        its maximum: break the sound barrier (5 % ki, 4 % stamina, 3 s cooldown) and fly 1.25x
//        faster THROUGH terrain, smashing a tunnel and hitting whoever you pass, for 0.5 % ki and
//        0.75 % stamina a tick, until you stop, land or run dry. A clash lost 2:1 or worse
//        throws the loser the same way (the slam) for 30 ticks.
//    MeleeClashService + ClashRhythm               two straight dashes meeting head on lock
//        both fighters into a 10 s rhythm duel (client/scripts/44_dmz_ragnarok_combat.js); the
//        higher score wins: the loser is thrown back (routed through terrain at 2:1), the
//        winner's dash cooldown is cleared. Punches fly the whole time for everyone watching.
//    NpcDash                                       fighting mobs (DBR's own mobs) lunge at the
//        player they hunt; a lunge meeting the player's straight dash head on is a clash too.
//  Terrain goes through the same rules as ki destruction (42_dbr_destruction.js: the "players"
//  switch, claims through the explode event) and grows back the same way.
//  Net: client -> "dbr_rag" {a: "dash", m, t} | {a: "boom"} | {a: "score", s}
//       server -> "dbr_rag_dash" {id, on, ...route}, "dbr_rag_crash" {id, on, ...},
//                 "dbr_rag_clash" {a: "start"|"end", ...}, "dbr_rag_clashfx" {a, b, on}
//  Config: config/dbr_ragnarok_combat.json (DMZ Ragnarok's values).
// =====================================================================================
RPG.effects.define("rag_dash_cd", { name: "Dash Cooldown", color: "#3FC8D8", beneficial: false });

var DBR_RAG_COMBAT = (function () {
    var RC = DBR_RC, V = RC.V, add = RC.add, sub = RC.sub, mul = RC.mul, dot = RC.dot, len = RC.len, norm = RC.norm;
    var C = dbrConfig("dbr_ragnarok_combat", {
        dash: true, sonicBoom: true, meleeClash: true, npcDash: true,
        dashCostFraction: 0.05, dashCooldownTicks: 100,
        boomKiCostFraction: 0.05, boomStaminaCostFraction: 0.04, boomCooldownTicks: 60,
        crashKiFractionPerTick: 0.005, crashStaminaFractionPerTick: 0.0075, crashSpeedMultiplier: 1.25,
        clashLoserKnockback: 2.6, clashFollowUpTicks: 40
    });

    // ---- DashService constants ----
    var WINDUP_TICKS = 3, MAX_DASH_TICKS = 58, MAX_RANGE = 104, SMALL_TARGET_RANGE = 9, FREE_DASH_DISTANCE = 18, SPEED = 3.2;
    var LEASH_DISTANCE = 10, ROUTE_GRACE_TICKS = 4, IMPACT_DISTANCE = 4.2, CLASH_YIELD_DISTANCE = 6.2, AIM_CONE = 0.94, AIM_INFLATE = 0.4;
    var WALL_PROGRESS = 0.35, WALL_TICKS_BEFORE_ABORT = 6, LOST_TARGET_GLIDE = 4, MIN_IMPACT_DAMAGE = 1.05, IMPACT_KNOCKBACK = 2.1, IMPACT_LIFT = 0.38;

    function num(v, d) { v = Number(v); return isNaN(v) || !isFinite(v) ? d : v; }
    function tick() { return RPG.server.getTick(); }
    function created(p) { return !!p.getVar("dmz_created", 0); }
    function creative(p) { var g = p.getGameMode(); return g === "creative" || g === "spectator"; }
    function pos(e) { return V(e.x, e.y, e.z); }
    function eye(e) { return V(e.x, e.eyeY, e.z); }
    function lookOf(e) { var y = e.yaw * Math.PI / 180, pt = e.pitch * Math.PI / 180; return V(-Math.sin(y) * Math.cos(pt), -Math.sin(pt), Math.cos(y) * Math.cos(pt)); }
    function eyeHeight(e) { return e.eyeY - e.y; }
    function radius(e) { return num(e.width, 0.6) * 0.5; }
    function halfHeight(e) { return num(e.height, 1.8) * 0.5; }
    function bodyFacing(e) { return RC.facing(num(e.bodyYaw, e.yaw)); }
    function arr(v) { return v ? [v.x, v.y, v.z] : [0, 0, 0]; }
    function playerByUuid(u) { var r = null; RPG.server.players().forEach(function (p) { if (p.uuid === u) r = p; }); return r; }
    function entityByUuid(u) { try { return RPG.world.entityByUuid(u); } catch (e) { return null; } }
    function viewersOf(e, range) {
        return RPG.server.players().filter(function (v) {
            if (v.dimension !== e.dimension) return false;
            if (!range) return true;
            var dx = v.x - e.x, dy = v.y - e.y, dz = v.z - e.z;
            return dx * dx + dy * dy + dz * dz <= range * range;
        });
    }
    function broadcast(e, channel, data, range) { viewersOf(e, range).forEach(function (v) { RPG.net.send(v, channel, data); }); }

    /** CombatBystanders.isProtected: masters, quest givers and other standing NPCs are hit but never shoved. */
    function isProtected(e) {
        if (!e || e.isPlayer()) return false;
        try { if (e.invulnerable || !e.hasAI()) return true; } catch (err) { }
        return e.type === "ragnarok_rpg:npc" && !e.target;
    }
    /** DmzResourceDrain.spendFraction: both shares or nothing. */
    function spendFraction(p, ki, stamina) {
        if (creative(p)) return true;
        var k = p.maxResource("ki") * ki, s = p.maxResource("stamina") * stamina;
        if (p.resource("ki") < k || p.resource("stamina") < s) return false;
        p.addResource("ki", -k); p.addResource("stamina", -s);
        return true;
    }
    function refund(p, ki, stamina) {
        if (creative(p)) return;
        p.addResource("ki", p.maxResource("ki") * ki); p.addResource("stamina", p.maxResource("stamina") * stamina);
    }
    function meleeOf(p) { try { return DMZ_F.melee(dmzView(p)); } catch (e) { return Math.max(1, p.attribute("generic.attack_damage")); } }

    // =================================================================================
    //  Dash
    // =================================================================================
    var ACTIVE = {}, COOLDOWN = {};

    function canSee(p, e) { try { return p.canSee(e); } catch (err) { return true; } }
    function isSmall(e) { return num(e.height, 1.8) < 1.2 || num(e.width, 0.6) < 0.5; }
    // distance from the ray (origin o, unit direction d, up to maxT) to a target's body (a box grown by AIM_INFLATE)
    function rayHits(o, d, maxT, e) {
        var r = radius(e) + AIM_INFLATE, minY = e.y - AIM_INFLATE, maxY = e.y + num(e.height, 1.8) + AIM_INFLATE;
        var lo = 0, hi = maxT, ax = ["x", "y", "z"], mins = { x: e.x - r, y: minY, z: e.z - r }, maxs = { x: e.x + r, y: maxY, z: e.z + r };
        for (var i = 0; i < 3; i++) {
            var k = ax[i];
            if (Math.abs(d[k]) < 1e-9) { if (o[k] < mins[k] || o[k] > maxs[k]) return -1; continue; }
            var t1 = (mins[k] - o[k]) / d[k], t2 = (maxs[k] - o[k]) / d[k];
            if (t1 > t2) { var tmp = t1; t1 = t2; t2 = tmp; }
            lo = Math.max(lo, t1); hi = Math.min(hi, t2);
            if (lo > hi) return -1;
        }
        return lo;
    }
    /** acquireTarget: a ray down the look against slightly grown boxes (stopped by terrain), then a look cone, then the client's hint. */
    function acquireTarget(p, hint) {
        var o = eye(p), look = norm(lookOf(p));
        var wall = p.raycast(MAX_RANGE, { blocks: true, entities: false });
        var rayEnd = wall && wall.hit === "block" ? num(wall.distance, MAX_RANGE) : MAX_RANGE;
        var byRay = null, bestRay = 1e9, byCone = null, bestCone = AIM_CONE;
        p.nearby(MAX_RANGE).forEach(function (e) {
            if (!e.isAlive() || e.uuid === p.uuid) return;
            if (e.isPlayer() && e.asPlayer().getGameMode() === "spectator") return;
            var d = p.distanceTo(e);
            if (d > MAX_RANGE || (isSmall(e) && d > SMALL_TARGET_RANGE)) return;
            var t = rayHits(o, look, rayEnd, e);
            if (t >= 0) { if (t < bestRay) { bestRay = t; byRay = e; } return; }
            var to = sub(eye(e), o);
            if (RC.lenSq(to) < 1e-6) return;
            var al = dot(norm(to), look);
            if (al > bestCone && canSee(p, e)) { bestCone = al; byCone = e; }
        });
        if (byRay) return byRay;
        if (byCone) return byCone;
        if (hint) {
            var h = entityByUuid(String(hint));
            if (h && h.uuid !== p.uuid && h.isAlive() && h.dimension === p.dimension && p.distanceTo(h) <= MAX_RANGE && canSee(p, h)) return h;
        }
        return null;
    }
    function destinationFor(p, t, d) { return RC.destination(eye(p), eye(t), bodyFacing(t), radius(t), halfHeight(t), d.mode, d.side); }
    function planRoute(p, t, d) {
        var o = eye(p);
        d.side = RC.pinnedSide(o, eye(t), bodyFacing(t), d.mode);
        var dest = destinationFor(p, t, d);
        d.origin = o;
        d.control = RC.control(o, dest, eye(t), d.side, d.mode, radius(t), halfHeight(t));
        d.travelTicks = RC.travelTicks(RC.curveLength(o, d.control, dest));
    }
    function plannedDuration(d) {
        var travel = d.target ? d.travelTicks : Math.ceil(d.maxTravel / SPEED);
        return Math.min(MAX_DASH_TICKS, d.windup + travel + 4);
    }
    // DashAnimation.direction: DMZ's four dash clips from the heading against the facing (1 front, 2 back, 3 right, 4 left)
    function clipFor(p, h) {
        var f = RC.facing(p.yaw), flat = V(h.x, 0, h.z);
        if (RC.lenSq(flat) < 1e-8) return 1;
        flat = norm(flat);
        var ahead = dot(flat, f);
        if (ahead >= 0.55) return 1;
        if (ahead <= -0.55) return 2;
        return dot(flat, V(-f.z, 0, f.x)) >= 0 ? 3 : 4;
    }

    function requestDash(p, modeId, hint) {
        if (!C.dash || !created(p) || p.hasEffect("stunned") || p.hasEffect("dmz_tech_rooted") || riding(p)) return false;
        if (ACTIVE[p.uuid] || (COOLDOWN[p.uuid] || 0) > tick() || inClash(p.uuid) || crashing(p)) return false;
        var mode = RC.modeById(modeId), target = acquireTarget(p, hint);
        var d = { ticks: 0, mode: mode, travelling: false, lastPos: pos(p), stuck: 0, travelled: 0, hit: false, target: null };
        if (!target) {
            var look = lookOf(p);
            if (RC.lenSq(look) < 1e-6) return false;
            d.windup = 0; d.heading = norm(look); d.maxTravel = FREE_DASH_DISTANCE;
        } else {
            d.target = target; d.windup = WINDUP_TICKS; d.maxTravel = 0;
            d.heading = norm(sub(eye(target), eye(p)));
            planRoute(p, target, d);
        }
        // DashCost: charged last, so a refused dash never costs anything
        if (!spendFraction(p, C.dashCostFraction, C.dashCostFraction)) return false;
        ACTIVE[p.uuid] = d;
        sfx(p, "minecraft:entity.player.attack.sweep", 0.5, 0.6);
        sfx(p, "transform_on", 0.7, 1.2);                 // DMZ's fast-flight cue: a dash IS entering fast flight
        p.setShared("flyFast", 1);                       // MixinDmzFlySkillFast / AuraDashFlip: fast-flight pose, aura laid over
        p.setShared("rgDash", 1);
        animPulse(p, "dash", { d: clipFor(p, d.heading) });
        broadcast(p, "dbr_rag_dash", { id: p.entityId, on: 1, dur: plannedDuration(d), m: mode, t: target ? target.entityId : 0, w: d.windup,
            tt: d.travelTicks || 0, mt: d.maxTravel, o: arr(d.origin || eye(p)), c: arr(d.control || eye(p)), s: arr(d.side || mul(lookOf(p), -1)), h: arr(d.heading) });
        return true;
    }

    function endVisuals(p) {
        p.setShared("rgDash", null);
        var fast = typeof DMZ_FLIGHT !== "undefined" && DMZ_FLIGHT.fast(p);
        p.setShared("flyFast", fast ? 1 : null);
        broadcast(p, "dbr_rag_dash", { id: p.entityId, on: 0 });
    }
    function endDash(p, d, charge) {
        delete ACTIVE[p.uuid];
        if (charge) {
            COOLDOWN[p.uuid] = tick() + C.dashCooldownTicks;
            p.addEffect("rag_dash_cd", C.dashCooldownTicks);
        }
        var drift = d.heading ? mul(d.heading, 0.15) : V(0, 0, 0);    // bleed off: a glide, not a wall
        p.setVelocity(drift.x, drift.y, drift.z);
        endVisuals(p);
    }
    /** Stop a dash without charging the cooldown (a clash seizing both dashers). */
    function cancelDash(p) { if (p && ACTIVE[p.uuid]) { delete ACTIVE[p.uuid]; endVisuals(p); } }

    function targetOf(d) { var t = d.target; try { return t && t.isAlive() ? t : null; } catch (e) { return null; } }
    function closing(p, t) {
        var th = dashHeading(t);
        if (!th) return false;
        var between = sub(pos(t), pos(p));
        return RC.lenSq(between) >= 1e-6 && dot(th, norm(between)) < -0.5;
    }
    function impact(p, t, stopping) {
        try {
            var dmg = Math.max(MIN_IMPACT_DAMAGE, num(p.attribute("generic.attack_damage"), 1));
            var landed = t.damageFrom(dmg, p, { kind: "melee", knockback: 0 });
            var away = sub(pos(t), pos(p)), dir = RC.lenSq(away) < 1e-6 ? lookOf(p) : norm(away);
            if (landed && !isProtected(t)) t.setVelocity(dir.x * IMPACT_KNOCKBACK, dir.y * IMPACT_KNOCKBACK + IMPACT_LIFT, dir.z * IMPACT_KNOCKBACK);
            if (stopping) p.setVelocity(dir.x * 0.35, dir.y * 0.35, dir.z * 0.35);
            if (landed) sfx(t, "minecraft:entity.player.attack.strong", 1.2, 0.85);
        } catch (e) { }
    }
    /** Watch one tick; take the wheel only when the player is 10+ blocks off the route. True = wedged. */
    function advance(p, d, step, gap) {
        var before = pos(p), moved = d.lastPos ? RC.dist(before, d.lastPos) : 0;
        d.lastPos = before;
        d.travelled += moved;
        p.fallDistance = 0;
        if (gap > LEASH_DISTANCE) {
            var k = Math.min(1, SPEED * 1.6 / Math.max(1e-6, gap));
            p.setVelocity(step.x * k, step.y * k, step.z * k);
        }
        if (d.ticks <= d.windup + 1) return false;
        d.stuck = moved < WALL_PROGRESS ? d.stuck + 1 : 0;
        return d.stuck >= WALL_TICKS_BEFORE_ABORT;
    }
    function tickTargeted(p, d) {
        var t = targetOf(d);
        if (!t || t.dimension !== p.dimension) {
            d.target = null;
            d.maxTravel = d.travelled + LOST_TARGET_GLIDE;        // glide out rather than stop dead
            return !d.heading;
        }
        var distance = p.distanceTo(t) - radius(t);
        var yieldToClash = distance <= CLASH_YIELD_DISTANCE && isDashing(t) && RC.canClash(d.mode) && closing(p, t);
        if (!d.hit && !yieldToClash && distance <= IMPACT_DISTANCE) {
            d.hit = true;
            impact(p, t, RC.stopsOnContact(d.mode));
            if (RC.stopsOnContact(d.mode)) return true;
        }
        var dest = destinationFor(p, t, d);
        var want = RC.sample(d.origin, d.control, dest, (d.ticks - d.windup) / Math.max(1, d.travelTicks));
        var step = sub(sub(want, V(0, eyeHeight(p), 0)), pos(p)), l = len(step);
        if (l > 1e-6) d.heading = norm(step);
        var stuck = advance(p, d, step, l);
        return stuck || (d.ticks - d.windup) > d.travelTicks + ROUTE_GRACE_TICKS;
    }
    function tickFree(p, d) {
        var remaining = d.maxTravel - d.travelled;
        if (remaining <= 0) return true;
        var step = mul(d.heading, Math.min(SPEED, remaining));
        return advance(p, d, step, len(step));
    }
    function tickDashes() {
        var ids = Object.keys(ACTIVE);
        if (!ids.length) return;
        var players = {};
        RPG.server.players().forEach(function (p) { players[p.uuid] = p; });
        ids.forEach(function (u) {
            var d = ACTIVE[u], p = players[u];
            if (!p || !p.isAlive()) { delete ACTIVE[u]; if (p) endVisuals(p); return; }
            d.ticks++;
            if (d.ticks <= d.windup) { p.fallDistance = 0; return; }   // committed, not moving: the client holds still
            if (!d.travelling) { d.travelling = true; d.lastPos = pos(p); if (d.target) d.origin = eye(p); }
            if (d.ticks > MAX_DASH_TICKS) { endDash(p, d, true); return; }
            var done = d.target ? tickTargeted(p, d) : tickFree(p, d);
            if (done) endDash(p, d, true);
        });
    }
    function isDashing(e) { return !!(e && ACTIVE[e.uuid]); }
    function dashHeading(e) { var d = e && ACTIVE[e.uuid]; return d ? d.heading : null; }
    function riding(p) { var v = p.vehicle; return !!v && !v.isPlayer(); }

    // =================================================================================
    //  Sonic boom / crash
    // =================================================================================
    var SELF_TICKS = 20 * 300, SLAM_TICKS = 30, SELF_SPEED = 2.4, SLAM_SPEED = 3.1, BREAK_RADIUS = 1;
    var SWEEP_START = 0.5, SWEEP_AHEAD = 2.5, MAX_SWEEP = 16, HIT_DAMAGE_SHARE = 0.5, HIT_KNOCKBACK = 2.4, DRIFT_TOLERANCE = 3;
    var STOPPED_SPEED = 0.08, STOP_GRACE_TICKS = 4;
    var CRASH = {}, BOOM_READY = {};

    function crashing(p) { return !!(p && CRASH[p.uuid]); }
    function refuse(p, why) { p.actionbar("&f" + why); }
    function flyMaxed(p) {
        try { return DMZ_SKILLS.level(p, "fly") >= DMZ_SKILLS_DATA.maxLevel("fly", p.race); } catch (e) { return false; }
    }
    function requestBoom(p) {
        if (!C.sonicBoom || !created(p) || crashing(p)) return;
        if ((BOOM_READY[p.uuid] || 0) > tick()) return;                                   // silent: a fumbled double-tap
        if (typeof DMZ_FLIGHT === "undefined" || !DMZ_FLIGHT.isFlying(p)) return;         // on the ground it's just sprinting
        if (!flyMaxed(p)) { refuse(p, "Your flight is not mastered enough to break the sound barrier."); return; }
        if (!spendFraction(p, C.boomKiCostFraction, C.boomStaminaCostFraction)) { refuse(p, "Not enough ki and stamina to break the sound barrier."); return; }
        var look = norm(lookOf(p));
        if (RC.lenSq(look) < 1e-4) { refund(p, C.boomKiCostFraction, C.boomStaminaCostFraction); return; }
        var c = begin(p, look, SELF_SPEED, meleeOf(p) * HIT_DAMAGE_SHARE, SELF_TICKS, true);
        boom(p);
        BOOM_READY[p.uuid] = tick() + C.boomCooldownTicks;
        return c;
    }
    /** The clash loser's version: thrown along a fixed line through whatever is behind them. */
    function slam(p, dir, damage) {
        if (!p || !dir || RC.lenSq(dir) < 1e-4) return;
        begin(p, norm(dir), SLAM_SPEED, damage || 0, SLAM_TICKS, false);
        boom(p);
    }
    function begin(p, heading, speed, damage, ticks, steered) {
        var c = { heading: heading, speed: speed, damage: damage, ticksLeft: ticks, steered: steered, struck: {}, expected: pos(p),
            lastPos: pos(p), lastStep: V(0, 0, 0), stalled: 0, ticksRun: 0, travelled: 0 };
        CRASH[p.uuid] = c;
        p.fallDistance = 0;
        p.setVelocity(heading.x * speed, heading.y * speed, heading.z * speed);
        broadcast(p, "dbr_rag_crash", { id: p.entityId, on: 1, h: arr(heading), sp: speed, t: ticks, st: steered ? 1 : 0, mul: C.crashSpeedMultiplier });
        return c;
    }
    function endCrash(p) { delete CRASH[p.uuid]; broadcast(p, "dbr_rag_crash", { id: p.entityId, on: 0 }); }
    /** The bang: the crack and the low roll, one big burst, the impact frame, DMZ's punch flash and the cone of cloud. */
    function boom(p) {
        var at = V(p.x, p.y + num(p.height, 1.8) * 0.5, p.z), dim = p.dimension;
        sfx(p, "minecraft:entity.lightning_bolt.thunder", 1.4, 1.7);
        sfx(p, "minecraft:entity.generic.explode", 1.6, 0.5);
        RPG.world.particle(dim, "minecraft:explosion_emitter", at.x, at.y, at.z, 1, 0, 0);
        if (typeof DMZ_IMPACT !== "undefined") DMZ_IMPACT.play({ dimension: dim, x: at.x, y: at.y, z: at.z }, 0.7, 0.1, 2);
        RPG.world.particle(dim, "minecraft:flash", at.x, at.y, at.z, 1, 0, 0);
        RPG.world.particle(dim, "minecraft:crit", at.x, at.y, at.z, 12, 0.75, 0.3);
        ring(dim, at, lookOf(p));
    }
    function ring(dim, at, heading) {
        var axis = RC.lenSq(heading) < 1e-4 ? V(0, 0, 1) : norm(heading);
        var side = Math.abs(axis.y) > 0.9 ? V(1, 0, 0) : V(0, 1, 0);
        var u = norm(RC.cross(axis, side)), v = norm(RC.cross(axis, u));
        for (var i = 0; i < 24; i++) {
            var a = Math.PI * 2 * i / 24, o = add(mul(u, Math.cos(a)), mul(v, Math.sin(a)));
            RPG.world.particle(dim, "minecraft:cloud", at.x + o.x * 1.2, at.y + o.y * 1.2, at.z + o.z * 1.2, 1, 0.05, 0.08);
        }
    }
    function sustain(p, c) {
        var look = lookOf(p);
        if (RC.lenSq(look) > 1e-4) c.heading = norm(look);
        if (p.onGround) return false;                                   // a crash is a thing that happens in the air
        var step = sub(pos(p), c.lastPos), moved = len(step);
        c.lastStep = step; c.lastPos = pos(p); c.travelled += moved;
        c.stalled = moved < STOPPED_SPEED ? c.stalled + 1 : 0;
        if (c.stalled > STOP_GRACE_TICKS) return false;
        return spendFraction(p, C.crashKiFractionPerTick, C.crashStaminaFractionPerTick);
    }
    // the pull back onto a thrown body's line never puts it inside something solid (bedrock, a claim's walls): a body
    // driven into what it could not break stops there
    var OPEN = /(^|:)(air|cave_air|void_air|water|lava|light|grass|short_grass|tall_grass|fern|large_fern|snow|vine|fire)$/;
    function open(dim, x, y, z) { return OPEN.test(String(RPG.world.getBlock(dim, Math.floor(x), Math.floor(y), Math.floor(z)) || "minecraft:air").split("[")[0]); }
    /** False when the thrown body has hit something it can't pass. */
    function drive(p, c) {
        if (c.steered) { c.expected = pos(p); return true; }            // their own flight, only faster: nothing to assert
        var step = mul(c.heading, c.speed);
        c.expected = add(c.expected, step);
        if (RC.dist(pos(p), c.expected) > DRIFT_TOLERANCE) {
            var e = c.expected;
            if (!open(p.dimension, e.x, e.y + 0.1, e.z) || !open(p.dimension, e.x, e.y + 1.2, e.z)) { p.setVelocity(0, 0, 0); return false; }
            p.teleport(e.x, e.y, e.z);
        } else c.expected = pos(p);
        p.setVelocity(step.x, step.y, step.z);
        return true;
    }
    function mayGrief(p) {
        try { var D = DBR_DESTRUCTION.config; return D.get("enabled") && D.get("players"); } catch (e) { return true; }
    }
    /** Sweep the ground the body crossed this tick plus a look-ahead with a 3-wide bore; best effort, never ends the run. */
    function smash(p, c) {
        if (!mayGrief(p)) return;
        var step = c.lastStep, facing;
        if (RC.lenSq(step) > 1e-6) facing = norm(step);
        else if (p.speed > 1e-3) facing = norm(V(p.vx, p.vy, p.vz));
        else facing = c.heading;
        var from = V(p.x, p.y + num(p.height, 1.8) * 0.5, p.z), travelled = Math.min(len(step), MAX_SWEEP);
        var a = add(from, mul(facing, SWEEP_START)), b = add(from, mul(facing, travelled + SWEEP_AHEAD));
        var regen = 60, placed = true;
        try { regen = DBR_DESTRUCTION.config.get("regenSeconds"); placed = DBR_DESTRUCTION.config.get("protectPlayerBuilt"); } catch (e) { }
        var n = RPG.world.destroy(p.dimension, { type: "line", x1: a.x, y1: a.y, z1: a.z, x2: b.x, y2: b.y, z2: b.z, r: BREAK_RADIUS + 0.5 },
            { regen: regen, drops: false, maxResistance: 1000, protectPlaced: placed, debris: 1, maxBlocks: 400 }, p);
        if (n > 0) {
            var at = add(from, mul(facing, Math.min(travelled + SWEEP_AHEAD, 2)));
            RPG.world.particle(p.dimension, "minecraft:explosion", at.x, at.y, at.z, 3, 0.4, 0);
            sfx({ dimension: p.dimension, x: at.x, y: at.y, z: at.z }, "minecraft:entity.generic.explode", 0.7, 1.4);
        }
    }
    function hitPassed(p, c) {
        p.nearby(1.2 + 1.5).forEach(function (e) {
            if (!e.isAlive() || c.struck[e.uuid]) return;
            var dx = e.x - p.x, dz = e.z - p.z, r = radius(e) + 0.3 + 1.2;
            if (dx * dx + dz * dz > r * r || e.y > p.y + num(p.height, 1.8) + 1.2 || e.y + num(e.height, 1.8) < p.y - 1.2) return;
            c.struck[e.uuid] = true;
            if (c.damage > 0) e.damageFrom(c.damage, p, { kind: "sonic_crash", knockback: 0 });
            if (isProtected(e)) return;
            e.setVelocity(c.heading.x * HIT_KNOCKBACK, c.heading.y * HIT_KNOCKBACK + 0.4, c.heading.z * HIT_KNOCKBACK);
            sfx(e, "minecraft:entity.player.attack.crit", 1.2, 0.7);
            RPG.world.particle(e.dimension, "minecraft:explosion", e.x, e.y + num(e.height, 1.8) * 0.5, e.z, 2, 0.3, 0);
        });
    }
    function tickCrashes() {
        var ids = Object.keys(CRASH);
        if (!ids.length) return;
        var players = {};
        RPG.server.players().forEach(function (p) { players[p.uuid] = p; });
        ids.forEach(function (u) {
            var c = CRASH[u], p = players[u];
            if (!p || !p.isAlive() || c.ticksLeft-- <= 0) { if (p) endCrash(p); else delete CRASH[u]; return; }
            c.ticksRun++;
            p.fallDistance = 0;
            if (c.steered && !sustain(p, c)) { endCrash(p); return; }
            if (!c.steered) { c.lastStep = c.ticksRun > 1 ? sub(pos(p), c.lastPos) : mul(c.heading, c.speed); c.lastPos = pos(p); }   // the hole covers the whole step
            hitPassed(p, c);
            smash(p, c);                                                  // before the move: always flying into cleared space
            if (!drive(p, c)) endCrash(p);
        });
    }

    // =================================================================================
    //  Melee clash
    // =================================================================================
    var TRIGGER_DISTANCE = 6, CLASH_SEPARATION = 1, CONVERGE_DOT = -0.82, PUNCH_MIN_GAP = 3, PUNCH_MAX_GAP = 8, CRIT_PUNCH_CHANCE = 0.2;
    var VISUALS_RANGE = 96, REPORT_GRACE_TICKS = 40, FREEZE_LEASH = 0.35, RECLASH_LOCKOUT_TICKS = 30, NPC_SWING_TICKS = 4;
    var STRUGGLES = [], RECENT = {}, FOLLOW_UP = {};

    function inClash(u) { for (var i = 0; i < STRUGGLES.length; i++) if (STRUGGLES[i].a === u || STRUGGLES[i].b === u) return true; return false; }
    function npcInClash(u) { for (var i = 0; i < STRUGGLES.length; i++) if (STRUGGLES[i].npc === u) return true; return false; }
    function recent(u) { return (RECENT[u] || 0) > tick(); }
    function faceAlong(p, dir) {
        var yaw = Math.atan2(-dir.x, dir.z) * 180 / Math.PI, pitch = -Math.atan2(dir.y, Math.sqrt(dir.x * dir.x + dir.z * dir.z)) * 180 / Math.PI;
        p.teleportTo(p.dimension, p.x, p.y, p.z, yaw, pitch);
    }
    function mutual(a, b) {
        if (a.distanceTo(b) > TRIGGER_DISTANCE) return false;
        var ha = dashHeading(a), hb = dashHeading(b);
        if (!ha || !hb || dot(ha, hb) > CONVERGE_DOT) return false;
        var ab = sub(pos(b), pos(a));
        if (RC.lenSq(ab) < 1e-6) return false;
        ab = norm(ab);
        return dot(ha, ab) > 0.7 && dot(hb, ab) < -0.7;
    }
    function seed() { return RPG.randomInt(1, 2147483646); }
    function visuals(a, b, on) { broadcast(a, "dbr_rag_clashfx", { a: a.entityId, b: b ? b.entityId : a.entityId, on: on ? 1 : 0 }, VISUALS_RANGE); }
    function closeIn(a, bPos, axis) {
        var mid = mul(add(pos(a), bPos), 0.5), half = mul(axis, CLASH_SEPARATION * 0.5);
        return { a: sub(mid, half), b: add(mid, half) };
    }
    function anchor(s, p) { s.anchor = V(p.x, p.y, p.z); }
    function beginPair(a, b) {
        cancelDash(a); cancelDash(b);
        var axis = sub(pos(b), pos(a));
        if (RC.lenSq(axis) < 1e-6) return;
        axis = norm(axis);
        if (a.distanceTo(b) > CLASH_SEPARATION) {
            var c = closeIn(a, pos(b), axis);
            a.teleport(c.a.x, c.a.y, c.a.z); b.teleport(c.b.x, c.b.y, c.b.z);
        }
        faceAlong(a, axis); faceAlong(b, mul(axis, -1));
        a.setVelocity(0, 0, 0); b.setVelocity(0, 0, 0);
        var s = { a: a.uuid, b: b.uuid, axis: axis, ticks: 0, seed: seed(), scoreA: -1, scoreB: -1, simulated: false, npc: null,
            nextPunch: 0, npcSwingOff: -1, anchorA: pos(a), anchorB: pos(b) };
        STRUGGLES.push(s);
        RPG.net.send(a, "dbr_rag_clash", { a: "start", seed: s.seed, opp: b.getName() });
        RPG.net.send(b, "dbr_rag_clash", { a: "start", seed: s.seed, opp: a.getName() });
        visuals(a, b, true);
    }
    function beginNpc(p, npc) {
        if (!C.meleeClash || !p || !npc || !npc.isAlive()) return false;
        if (inClash(p.uuid) || recent(p.uuid) || recent(npc.uuid) || npcInClash(npc.uuid)) return false;
        cancelDash(p);
        var axis = sub(pos(npc), pos(p));
        if (RC.lenSq(axis) < 1e-6) return false;
        axis = norm(axis);
        if (p.distanceTo(npc) > CLASH_SEPARATION) {
            var c = closeIn(p, pos(npc), axis);
            p.teleport(c.a.x, c.a.y, c.a.z); npc.teleport(c.b.x, c.b.y, c.b.z);
        }
        faceAlong(p, axis);
        p.setVelocity(0, 0, 0); npc.setVelocity(0, 0, 0);
        try { npc.lookAt(p.x, p.eyeY, p.z); } catch (e) { }
        var s = { a: p.uuid, b: p.uuid, axis: axis, ticks: 0, seed: seed(), scoreA: -1, scoreB: -1, simulated: true, npc: npc.uuid, npcRef: npc,
            nextPunch: 0, npcSwingOff: -1, anchorA: pos(p) };
        STRUGGLES.push(s);
        RPG.net.send(p, "dbr_rag_clash", { a: "start", seed: s.seed, opp: npc.getName() });
        broadcast(p, "dbr_rag_clashfx", { a: p.entityId, b: npc.entityId, on: 1 }, VISUALS_RANGE);
        return true;
    }
    /** /dbrclash [player]: a clash on demand; alone it is a solo training round against a simulated opponent. */
    function forceClash(a, b) {
        if (!a || inClash(a.uuid) || recent(a.uuid)) return false;
        if (!b || b.uuid === a.uuid) {
            var look = lookOf(a);
            var s = { a: a.uuid, b: a.uuid, axis: RC.lenSq(look) < 1e-6 ? V(0, 0, 1) : norm(look), ticks: 0, seed: seed(), scoreA: -1, scoreB: -1,
                simulated: true, npc: null, nextPunch: 0, npcSwingOff: -1, anchorA: pos(a) };
            STRUGGLES.push(s);
            RPG.net.send(a, "dbr_rag_clash", { a: "start", seed: s.seed, opp: "Training" });
            visuals(a, null, true);
            return true;
        }
        if (inClash(b.uuid) || recent(b.uuid)) return false;
        beginPair(a, b);
        return inClash(a.uuid);
    }
    function reportScore(p, score) {
        STRUGGLES.forEach(function (s) {
            var clamped = Math.max(0, Math.min(Math.floor(num(score, 0)), RC.maxScore(s.seed)));
            if (s.a === p.uuid && s.scoreA < 0) s.scoreA = clamped;
            else if (s.b === p.uuid && !s.simulated && s.scoreB < 0) s.scoreB = clamped;
        });
    }
    function hold(p, at) {
        p.fallDistance = 0;
        var dx = p.x - at.x, dy = p.y - at.y, dz = p.z - at.z;
        if (dx * dx + dy * dy + dz * dz > FREEZE_LEASH * FREEZE_LEASH) p.teleport(at.x, at.y, at.z);
        if (p.speed > 0.01) p.setVelocity(0, 0, 0);
    }
    function sendEnd(p, outcome, own, other) { if (p) RPG.net.send(p, "dbr_rag_clash", { a: "end", o: outcome, own: own, other: other }); }
    function push(e, dir, speed) { var d = norm(dir); e.setVelocity(d.x * speed, d.y * speed + 0.42, d.z * speed); }
    function npcSwing(npc, on) { if (npc && on) { try { npc.playAnimation("attack"); } catch (e) { } } }
    // blows land ON the fighters: a burst scattered over the body (DMZ's punch particle -> a crit flash here)
    function shockwave(e) {
        for (var i = 0; i < 3; i++) {
            var x = e.x + (Math.random() - 0.5) * 0.9, y = e.y + 0.8 + (Math.random() - 0.5) * 0.9, z = e.z + (Math.random() - 0.5) * 0.9;
            RPG.world.particle(e.dimension, "minecraft:crit", x, y, z, 4, 0.08, 0.25);
        }
        RPG.world.particle(e.dimension, "minecraft:sweep_attack", e.x, e.y + 1, e.z, 1, 0.3, 0);
    }
    function punchFlurry(s, a, other) {
        if (s.ticks < s.nextPunch) return;
        s.nextPunch = s.ticks + PUNCH_MIN_GAP + RPG.randomInt(0, PUNCH_MAX_GAP - PUNCH_MIN_GAP);
        var mid = other ? mul(add(pos(a), pos(other)), 0.5) : pos(a);
        shockwave(a);
        if (other) shockwave(other);
        if (s.npc && other) { npcSwing(other, true); s.npcSwingOff = s.ticks + NPC_SWING_TICKS; }
        var crit = Math.random() < CRIT_PUNCH_CHANCE;
        var snd = crit ? "critic_punch" + RPG.randomInt(1, 2) : "punch" + RPG.randomInt(1, 6);
        sfx({ dimension: a.dimension, x: mid.x, y: mid.y + 1, z: mid.z }, snd, 1, 0.9 + Math.random() * 0.25);
    }
    // ClashVisuals: each fighter throws DMZ's one-handed punch every 7 ticks, hands alternating, the two out of step
    var PUNCH_INTERVAL = 7;
    function swing(s, side, p) {
        var k = "next" + side, off = "off" + side;
        if (s[k] === undefined) { s[k] = side === "A" ? 1 : 1 + Math.floor(PUNCH_INTERVAL / 2); s[off] = side === "B"; }
        if (--s[k] > 0) return;
        s[k] = PUNCH_INTERVAL;
        animPulse(p, "melee", { a: "combat.one_handed_punch_right", off: !!s[off], s: 1 });
        s[off] = !s[off];
    }
    function isRout(w, l) { return w > 0 && w >= l * 2; }
    function resolve(winner, loser, away, ws, ls) {
        if (loser) {
            if (isRout(ws, ls)) slam(loser, norm(add(norm(away), V(0, 0.25, 0))), 0);
            else push(loser, away, C.clashLoserKnockback);
        }
        if (!winner) return;
        COOLDOWN[winner.uuid] = 0;                                     // the follow-up: dash again straight away
        winner.removeEffect("rag_dash_cd");
        FOLLOW_UP[winner.uuid] = tick() + C.clashFollowUpTicks;
    }
    function tickStruggles() {
        for (var i = STRUGGLES.length - 1; i >= 0; i--) {
            var s = STRUGGLES[i], a = playerByUuid(s.a), b = s.simulated ? null : playerByUuid(s.b);
            var npc = s.npc ? s.npcRef : null;
            s.ticks++;
            var npcGone = !!s.npc && (!npc || !npc.isAlive());
            if (npcGone) { sendEnd(a, 3, 0, 0); if (a) visuals(a, null, false); RECENT[s.a] = tick() + RECLASH_LOCKOUT_TICKS; STRUGGLES.splice(i, 1); continue; }
            if (!a || !a.isAlive() || (!s.simulated && (!b || !b.isAlive() || b.dimension !== a.dimension))) {
                sendEnd(a, 3, 0, 0); sendEnd(b, 3, 0, 0);
                if (a) visuals(a, b, false);
                STRUGGLES.splice(i, 1);
                continue;
            }
            var R = RC.R;
            if (s.ticks < R.DURATION_TICKS) {
                hold(a, s.anchorA);
                if (b) hold(b, s.anchorB);
                if (npc) npc.setVelocity(0, 0, 0);
                punchFlurry(s, a, b || npc);
                swing(s, "A", a);
                if (b) swing(s, "B", b);
                continue;
            }
            var pending = s.scoreA < 0 || (!s.simulated && s.scoreB < 0);
            if (pending && s.ticks < R.DURATION_TICKS + REPORT_GRACE_TICKS) { hold(a, s.anchorA); if (b) hold(b, s.anchorB); continue; }
            var sa = Math.max(0, s.scoreA);
            var npcPower = npc ? Math.max(1, num(npc.maxHealth, 1)) : 1, playerPower = Math.max(1, num(a.maxHealth, 20));
            var sb = s.simulated ? RC.npcScore(s.seed, npcPower, playerPower) : Math.max(0, s.scoreB);
            if (sa === sb) {
                sendEnd(a, 2, sa, sb); sendEnd(b, 2, sb, sa);
                push(a, mul(s.axis, -1), C.clashLoserKnockback * 0.6);
                if (b) push(b, s.axis, C.clashLoserKnockback * 0.6);
                else if (npc) push(npc, s.axis, C.clashLoserKnockback * 0.6);
            } else if (sa > sb) {
                sendEnd(a, 1, sa, sb); sendEnd(b, 0, sb, sa);
                resolve(a, b, s.axis, sa, sb);
                if (!b && npc) push(npc, s.axis, C.clashLoserKnockback);
            } else {
                sendEnd(b, 1, sb, sa); sendEnd(a, 0, sa, sb);
                resolve(b, a, mul(s.axis, -1), sb, sa);
            }
            if (npc) broadcast(a, "dbr_rag_clashfx", { a: a.entityId, b: npc.entityId, on: 0 }, VISUALS_RANGE);
            else visuals(a, b, false);
            RECENT[s.a] = tick() + RECLASH_LOCKOUT_TICKS;
            if (!s.simulated) RECENT[s.b] = tick() + RECLASH_LOCKOUT_TICKS;
            if (npc) RECENT[npc.uuid] = tick() + RECLASH_LOCKOUT_TICKS;
            STRUGGLES.splice(i, 1);
        }
    }
    function detectClashes() {
        if (!C.meleeClash) return;
        for (var any in ACTIVE) break;
        if (any === undefined) return;                               // nobody is dashing: nothing can clash
        var dashers = RPG.server.players().filter(function (p) { return isDashing(p) && !inClash(p.uuid) && !recent(p.uuid); });
        for (var i = 0; i < dashers.length; i++)
            for (var j = i + 1; j < dashers.length; j++) {
                var a = dashers[i], b = dashers[j];
                if (a.dimension !== b.dimension || inClash(a.uuid) || inClash(b.uuid)) continue;
                if (mutual(a, b)) beginPair(a, b);
            }
    }

    // =================================================================================
    //  NPC lunge (NpcDash)
    // =================================================================================
    var MIN_LUNGE_RANGE = 6, MAX_LUNGE_RANGE = 26, FACING_DOT = 0.55, LUNGE_SPEED = 1.35, LUNGE_TICKS = 10, NPC_DASH_COOLDOWN = 90;
    var DASH_CHANCE = 0.06, NPC_CLASH_DISTANCE = 6, NPC_CLASH_DOT = -0.6, SCAN_INTERVAL = 4;
    var LUNGES = {}, NPC_CD = {}, scanTimer = 0;
    /** DMZ Ragnarok only lets fighters from the DMZ family lunge; here: DBR's own mobs and bosses, not vanilla ones. */
    function isFighter(e) { return !e.isPlayer() && !!e.rpgId && e.type !== "ragnarok_rpg:npc"; }
    function tickNpcDash() {
        if (!C.npcDash) return;
        Object.keys(LUNGES).forEach(function (u) {
            var l = LUNGES[u], npc = l.npc, target = playerByUuid(l.target);
            if (!npc || !npc.isAlive() || l.ticksLeft <= 0 || !target || !target.isAlive() || target.dimension !== npc.dimension) { delete LUNGES[u]; return; }
            if (isDashing(target) && npc.distanceTo(target) <= NPC_CLASH_DISTANCE && dot(dashHeading(target), l.heading) <= NPC_CLASH_DOT) {
                delete LUNGES[u];
                NPC_CD[u] = tick() + NPC_DASH_COOLDOWN;
                beginNpc(target, npc);
                return;
            }
            npc.setVelocity(l.heading.x * LUNGE_SPEED, l.heading.y * LUNGE_SPEED, l.heading.z * LUNGE_SPEED);
            npc.fallDistance = 0;
            l.ticksLeft--;
        });
        if (--scanTimer > 0) return;
        scanTimer = SCAN_INTERVAL;
        RPG.server.players().forEach(function (p) {
            if (!p.isAlive()) return;
            p.nearby(MAX_LUNGE_RANGE, { targeting: true }).forEach(function (m) {      // only mobs after this player
                if (LUNGES[m.uuid] || (NPC_CD[m.uuid] || 0) > tick() || !m.isAlive() || !isFighter(m) || npcInClash(m.uuid)) return;
                var t = m.target;
                if (!t || t.uuid !== p.uuid) return;
                var d = m.distanceTo(p);
                if (d < MIN_LUNGE_RANGE || d > MAX_LUNGE_RANGE) return;
                var to = norm(sub(pos(p), pos(m)));
                if (dot(norm(lookOf(m)), to) < FACING_DOT || Math.random() > DASH_CHANCE) return;
                LUNGES[m.uuid] = { npc: m, target: p.uuid, heading: to, ticksLeft: LUNGE_TICKS };
                NPC_CD[m.uuid] = tick() + NPC_DASH_COOLDOWN + LUNGE_TICKS;
            });
        });
    }

    // ---- CombatTickHandler: dashes, then crashes, then clashes, then lunges ----
    RPG.every(1, function () {
        tickDashes();
        tickCrashes();
        tickStruggles();
        detectClashes();
        tickNpcDash();
    });
    RPG.on("playerLeave", function (p) { delete ACTIVE[p.uuid]; delete CRASH[p.uuid]; });

    RPG.net.on("dbr_rag", function (p, d) {
        if (!d) return;
        switch (String(d.a || "")) {
            case "dash": requestDash(p, d.m, d.t); break;
            case "boom": requestBoom(p); break;
            case "score": reportScore(p, d.s); break;
        }
    });

    RPG.commands.register("dbrclash", {
        description: "DMZ Ragnarok melee clash: /rpgc dbrclash [player] (alone = a training round)",
        permission: 2,
        run(p, args) {
            if (!p) return;
            var other = args && args[0] ? RPG.server.player(String(args[0])) : null;
            if (!forceClash(p, other)) p.tell("&cCan't start a clash right now.");
        }
    });

    return {
        CFG: C, isDashing: isDashing, dashHeading: dashHeading, cancelDash: cancelDash, inClash: function (p) { return !!p && inClash(p.uuid); },
        isCrashing: crashing, slam: slam, forceClash: forceClash, beginNpcClash: beginNpc, isProtected: isProtected,
        hasFollowUp: function (p) { return (FOLLOW_UP[p.uuid] || 0) > tick(); },
        _request: requestDash, _boom: requestBoom
    };
})();
