// =====================================================================================
//  96_dbr_shrines.js - Shenron shrines, stat shrines and the Level Barrier, client screens
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0) screens: ShrineScreen, WishSelectScreen, ShrineConfigScreen,
//  ShrineWishEditScreen (sdu/client/gui/shenron), ShrineListScreen + ShrineEditScreen
//  (shuruisutilities editor) and BarrierConfigScreen (sdu/client/gui/block), with DMZR's labels and
//  tooltips. Drawn in DMZ's menubig / characterbuttons art like the other DBR editors
//  (82_dbr_raids.js helpers). Servers: scripts/96_dbr_shrines.js, scripts/96_dbr_level_barrier.js.
// =====================================================================================
(function () {
    var U = DMZ_UI, UI = DBR_RAIDS_UI, FONT = U.FONT;
    var COLORS = ["blue", "gold", "green", "red"];
    var COLOR_NAMES = { blue: "Blue", gold: "Gold", green: "Green", red: "Red" };
    function amp(s) { return String(s || "").replace(/&([0-9a-fk-or])/gi, "§$1"); }
    function clone(o) { return JSON.parse(JSON.stringify(o)); }
    function click() { RPG.sound("dmzpack:pip_menu", 1, 1); }

    // =================================================================================
    //  ShrineScreen: the colour's offerings and "Summon Shenron"
    // =================================================================================
    var SH = null;
    RPG.net.on("dbr_shrine_open", function (d) {
        if (!d) return;
        SH = d;
        var W = 220, H = 180, els = [];
        (d.required || []).forEach(function (r, i) {
            els.push({ id: "it" + i, type: "item", anchor: "center", x: -W / 2 + 22, y: -H / 2 + 38 + i * 20, w: 16, h: 16, item: r.item, tooltip: "item" });
        });
        els.push(UI.btn("summon", -80, H / 2 - 52, 160, 20, "Summon Shenron", function () {
            RPG.net.send("dbr_shrine_summon", { x: d.x, y: d.y, z: d.z, color: d.color }); RPG.screen.close();
        }, { disabled: !d.hasItems }));
        els.push(UI.btn("close", -80, H / 2 - 28, 160, 20, "Close", function () { RPG.screen.close(); }));
        RPG.screen.open({ id: "dbr_shrine", referenceHeight: 300, background: "dim", elements: els, onBackground: function (ctx) {
            if (!SH) return;
            var cx = ctx.width / 2, cy = ctx.height / 2, x = cx - W / 2, y = cy - H / 2;
            UI.panel(ctx, x, y, W, H);
            U.bordered(ctx, (COLOR_NAMES[SH.color] || SH.color) + " Shenron Shrine", cx, y + 10, "#FFAA00", 0.5);
            U.bordered(ctx, "Required offerings:", cx, y + 26, "#FFFFFF", 0.5);
            var rowY = y + 42;
            (SH.required || []).forEach(function (r) {
                U.bordered(ctx, U.ellipsis(ctx, "x" + r.count + "  " + amp(r.name), W - 60), x + 44, rowY, SH.hasItems ? "#55FF55" : "#FF5555", 0);
                rowY += 20;
            });
            if (!(SH.required || []).length) U.bordered(ctx, "No offerings required.", cx, rowY, "#55FF55", 0.5);
            else if (!SH.hasItems) U.bordered(ctx, "You are missing required offerings.", cx, y + H - 66, "#FF5555", 0.5);
        }, onClose: function () { SH = null; } });
    });

    // =================================================================================
    //  WishSelectScreen: the summoner picks one wish
    // =================================================================================
    var WS = null;
    RPG.net.on("dbr_shrine_wishes", function (d) {
        if (!d) return;
        WS = { d: d, sel: -1 };
        openWishes();
    });
    var WW = 240, WH = 200, WROW = 18;
    function wishRows() { return Math.max(1, Math.floor((WH - 56 - 30) / WROW)); }
    function openWishes() {
        var d = WS.d;
        var els = [
            UI.btn("confirm", -80, WH / 2 - 50, 160, 20, "Wish", function () {
                var w = (d.wishes || [])[WS.sel];
                if (!w) return;
                RPG.net.send("dbr_shrine_wish", { dragon: d.dragon, color: d.color, wish: w.id }); RPG.screen.close();
            }, { disabled: WS.sel < 0 }),
            UI.btn("close", -80, WH / 2 - 26, 160, 20, "Close", function () { RPG.screen.close(); })
        ];
        RPG.screen.open({ id: "dbr_shrine_wish", referenceHeight: 300, background: "dim", elements: els, onBackground: function (ctx) {
            if (!WS) return;
            var cx = ctx.width / 2, cy = ctx.height / 2, x = cx - WW / 2, y = cy - WH / 2, list = WS.d.wishes || [], top = y + 30;
            UI.panel(ctx, x, y, WW, WH);
            U.bordered(ctx, "Make Your Wish", cx, y + 10, "#FFAA00", 0.5);
            WS.x = x; WS.top = top; WS.hover = null;
            for (var i = 0; i < Math.min(wishRows(), list.length); i++) {
                var w = list[i], ry = top + i * WROW, over = U.inside(ctx.mouseX, ctx.mouseY, x + 12, ry, WW - 24, WROW);
                if (i === WS.sel) ctx.fill(x + 10, ry - 1, WW - 20, WROW - 1, "#33AA33", 0.5);
                else if (over) ctx.fill(x + 10, ry - 1, WW - 20, WROW - 1, "#FFFFFF", 0.25);
                U.bordered(ctx, U.ellipsis(ctx, amp(w.name || w.id), WW - 36), x + 16, ry + 4, "#FFFFFF", 0);
                if (over) WS.hover = w;
            }
            if (!list.length) U.bordered(ctx, "No wishes are available.", cx, top + 10, "#FF5555", 0.5);
        }, onRender: function (ctx) {
            if (WS && WS.hover && WS.hover.description) U.tooltip(ctx, [[amp(WS.hover.description), "#FFFFFF"]], ctx.mouseX, ctx.mouseY);
        }, onMouse: function (mx, my, button, action) {
            if (!WS || action !== "down" || button !== 0) return;
            var list = WS.d.wishes || [];
            for (var i = 0; i < Math.min(wishRows(), list.length); i++) {
                if (U.inside(mx, my, WS.x + 12, WS.top + i * WROW, WW - 24, WROW)) { WS.sel = i; click(); RPG.screen.update("confirm", { disabled: false }); return false; }
            }
        }, onClose: function () { WS = null; } });
    }

    // =================================================================================
    //  A small form engine (panel, optional tabs, scrolled rows, footer) in the DBR editor look
    // =================================================================================
    var PW = 340, PH = 280, ROW = 18, LX = -158, CX = -20, CW = 170;
    var F = null;
    function form(spec) {
        var keep = F && spec.id && F.id === spec.id;
        F = { id: spec.id, title: spec.title, sub: spec.sub || "", tabs: spec.tabs || null, tab: keep ? F.tab : spec.tab || 0, rows: spec.rows,
              scroll: keep ? F.scroll : 0, footer: spec.footer || [], onClose: spec.onClose || null };
        show();
    }
    function curRows() { return F.tabs ? F.tabs[F.tab].rows() : F.rows(); }
    function top() { return F.tabs ? -98 : -110; }
    function visible() { return Math.floor((PH / 2 - 36 - top()) / ROW); }
    function show() {
        if (!F) return;
        var mine = F, els = [], rows = curRows(), vis = visible();
        F.scroll = Math.max(0, Math.min(F.scroll, Math.max(0, rows.length - vis)));
        if (F.tabs) F.tabs.forEach(function (t, i) {
            var w = Math.floor((PW - 24) / F.tabs.length);
            els.push(UI.btn("tab" + i, -PW / 2 + 12 + i * w, -118, w - 2, 15, (i === F.tab ? "§e" : "") + t.name, function () { F.tab = i; F.scroll = 0; click(); show(); }));
        });
        var y = top();
        for (var i = 0; i < vis && i + F.scroll < rows.length; i++, y += ROW) rowEls(els, rows[i + F.scroll], i + F.scroll, y);
        if (rows.length > vis) {
            els.push(UI.btn("up", PW / 2 - 18, top(), 12, 12, "▲", function () { F.scroll = Math.max(0, F.scroll - vis + 1); show(); }));
            els.push(UI.btn("down", PW / 2 - 18, top() + vis * ROW - 14, 12, 12, "▼", function () { F.scroll += vis - 1; show(); }));
        }
        var fw = Math.min(100, Math.floor((PW - 24) / Math.max(1, F.footer.length)) - 4), fx = -(F.footer.length * (fw + 4)) / 2;
        F.footer.forEach(function (b, j) {
            if (b.input) { els.push({ id: "ft" + j, type: "input", anchor: "center", x: fx + j * (fw + 4) + 3, y: PH / 2 - 23, w: fw - 6, h: 10, value: b.get(), maxLength: 64, hint: b.placeholder || "", onChange: function (e, v) { b.set(v); } }); return; }
            els.push(UI.btn("ft" + j, fx + j * (fw + 4), PH / 2 - 26, fw, 18, b.label, b.run, b.extra));
        });
        F.rebuilding = true;
        RPG.screen.open({ id: "dbr_shrine_form", referenceHeight: 330, background: "dim", elements: els, onBackground: render,
            onScroll: function (x, yy, d) { if (F !== mine) return; var n = curRows().length, v = visible(); if (n <= v) return; F.scroll = Math.max(0, Math.min(n - v, F.scroll - (d > 0 ? 1 : -1))); show(); },
            onClose: function () { if (F === mine && !F.rebuilding) { var c = F.onClose; F = null; if (c) c(); } } });
        F.rebuilding = false;
    }
    function render(ctx) {
        if (!F) return;
        var cx = ctx.width / 2, cy = ctx.height / 2;
        UI.panel(ctx, cx - PW / 2, cy - PH / 2, PW, PH);
        UI.title(ctx, cx, cy - PH / 2 + 4, F.title);
        if (F.sub && !F.tabs) U.bordered(ctx, "§7" + F.sub, cx, cy - PH / 2 + 27, "#FFFFFF", 0.5);
        var rows = curRows(), vis = visible(), y = cy + top();
        for (var i = 0; i < vis && i + F.scroll < rows.length; i++, y += ROW) {
            var r = rows[i + F.scroll];
            if (r.type === "text" || r.type === "int" || r.type === "num") U.fieldArt(ctx, cx + CX - 2, y, (r.w || CW) + 4, 16);
            if (r.type === "item" && r.input) U.fieldArt(ctx, cx + r.input.x - 2, y, r.input.w + 4, 16);
        }
        if (F.footer.some(function (b) { return b.input; })) {
            var n = F.footer.length, fw = Math.min(100, Math.floor((PW - 24) / Math.max(1, n)) - 4), fx = -(n * (fw + 4)) / 2;
            F.footer.forEach(function (b, j) { if (b.input) U.fieldArt(ctx, cx + fx + j * (fw + 4), cy + PH / 2 - 26, fw, 16); });
        }
        U.drawStatus(ctx, cx, cy + PH / 2 - 40);
    }
    function label(els, id, text, x, y, tip, wrap) {
        var e = { id: id, type: "text", anchor: "center", x: x, y: y, text: text, font: FONT, color: "#FFFFFF", outline: "#000000" };
        if (tip) e.tooltip = tip;
        if (wrap) e.wrap = wrap;
        els.push(e);
    }
    function str(v) { return v === undefined || v === null ? "" : String(v); }
    function numStr(v) { var n = Number(v) || 0; return n === Math.round(n) ? String(Math.round(n)) : String(n); }
    /** Row types: head note text int num bool enum button item. */
    function rowEls(els, r, idx, y) {
        var id = "r" + idx;
        if (r.type === "spacer") return;
        if (r.type === "head") { label(els, id, "§e" + r.label, LX, y + 5); return; }
        if (r.type === "note") { label(els, id, "§7" + r.text, LX, y + 4, null, PW - 30); return; }
        if (r.type === "button") { els.push(UI.btn(id, LX + (r.x || 0), y, r.w || 140, 16, r.label, r.run, { tooltip: r.tip, disabled: !!r.disabled })); return; }
        if (r.type === "item") {
            label(els, id + "l", U.strip(r.text).length > (r.room || 34) ? r.text.substring(0, r.room || 34) + "…" : r.text, LX, y + 4, r.tip);
            if (r.input) els.push({ id: id + "in", type: "input", anchor: "center", x: r.input.x + 2, y: y + 3, w: r.input.w - 4, h: 10, value: str(r.input.get()), maxLength: 256,
                tooltip: r.input.tip, onChange: function (e, v) { r.input.set(v); } });
            var bs = r.buttons || [], bx = PW / 2 - 22;
            for (var k = bs.length - 1; k >= 0; k--) {
                var b = bs[k], bw = b.w || 44;
                bx -= bw;
                els.push(UI.btn(id + "b" + k, bx, y, bw, 16, b.label, b.run, { tooltip: b.tip, disabled: !!b.disabled }));
                bx -= 2;
            }
            if (r.click) els.push({ id: id + "c", type: "rect", anchor: "center", x: LX - 4, y: y, w: bx - LX + 2, h: 16, color: "#000000", alpha: 0.01, onClick: r.click, tooltip: r.tip });
            return;
        }
        label(els, id + "l", r.label, LX, y + 4, r.tip);
        if (r.type === "bool") {
            els.push(UI.btn(id, CX, y, 70, 16, r.get() ? "§a[x] ON" : "§7[ ] OFF", function () { r.set(!r.get()); RPG.sound(r.get() ? "dmzpack:switch_on" : "dmzpack:switch_off", 1, 1); RPG.screen.update(id, { label: r.get() ? "§a[x] ON" : "§7[ ] OFF" }); }, { tooltip: r.tip }));
        } else if (r.type === "enum") {
            els.push(U.dropdown(id, CX - 2, y, CW + 4, 16, r.options.map(function (o) { return { value: o.v, label: o.l }; }), r.get(), function (v) {
                r.set(v); click();
                if (r.rebuild) show();
            }, { tooltip: r.tip, search: r.options.length > 8, listWidth: 220 }));
        } else {
            els.push({ id: id, type: "input", anchor: "center", x: CX + 2, y: y + 3, w: (r.w || CW) - 4, h: 10, value: r.type === "int" || r.type === "num" ? numStr(r.get()) : str(r.get()), maxLength: r.max || 256,
                tooltip: r.tip, onChange: function (e, v) {
                    if (r.type === "int") { var n = parseInt(v, 10); if (!isNaN(n)) r.set(n); }
                    else if (r.type === "num") { var m = Number(v); if (String(v).trim() !== "" && !isNaN(m)) r.set(m); }
                    else r.set(String(v));
                    if (r.relabel) RPG.screen.update(id + "l", { text: r.relabel() });
                } });
        }
    }
    function fld(obj, key, type, lbl, tip, more) {
        var r = { type: type, label: lbl, tip: tip, get: function () { return obj[key]; }, set: function (v) { obj[key] = v; } };
        for (var k in more || {}) r[k] = more[k];
        return r;
    }
    function head(t) { return { type: "head", label: t }; }
    function note(t) { return { type: "note", text: t }; }

    // =================================================================================
    //  ShrineConfigScreen (+ ShrineWishEditScreen): wishes and the four colours
    // =================================================================================
    var SC = null;
    RPG.net.on("dbr_shrine_config", function (d) {
        if (!d || !d.config) return;
        SC = { cfg: clone(d.config), geos: d.geos || [], textures: d.textures || [] };
        shrineConfig();
    });
    function withCurrent(opts, cur) {
        var out = opts.slice();
        if (cur && !opts.some(function (o) { return o.v === cur; })) out.push({ v: cur, l: "§7" + cur });
        return out;
    }
    function shrineConfig() {
        var c = SC.cfg;
        var tabs = [{ name: "Wishes", rows: function () {
            var out = [head("Wishes")];
            c.wishes.forEach(function (w, i) {
                out.push({ type: "item", text: "§b" + amp(w.name || w.id) + " §7(" + w.id + ")", room: 40,
                    buttons: [{ label: "Edit", run: function () { wishEdit(w); } },
                              { label: "§cX", w: 16, tip: "Delete", run: function () { c.wishes.splice(i, 1); show(); } }] });
            });
            if (!c.wishes.length) out.push(note("No wishes configured yet."));
            out.push({ type: "button", label: "§a+ Add Wish", run: function () {
                var n = c.wishes.length + 1;
                while (c.wishes.some(function (w) { return w.id === "wish_" + n; })) n++;
                c.wishes.push({ id: "wish_" + n, name: "", description: "", commands: [] }); show();
            } });
            return out;
        } }];
        COLORS.forEach(function (k) { tabs.push({ name: COLOR_NAMES[k], rows: function () { return colorRows(c.colors[k]); } }); });
        form({ id: "shrinecfg", title: "Shenron Shrine Config", tabs: tabs, footer: [
            { label: "§aSave", run: function () { RPG.net.send("dbr_shrine_config_save", { config: c }); } },
            { label: "Close", run: function () { RPG.screen.close(); } }] });
    }
    function colorRows(cc) {
        var out = [head("Display Entity"),
            { type: "enum", label: "Model geo", tip: "GeckoLib geo model for the summoned Shenron. The animation follows the shape.",
              options: withCurrent(SC.geos, cc.modelGeo), get: function () { return cc.modelGeo; }, set: function (v) { cc.modelGeo = v; } },
            { type: "enum", label: "Model texture", tip: "Texture for the summoned Shenron. A skin drawn for another rig still renders, but looks wrong.",
              options: withCurrent(SC.textures, cc.modelTexture), get: function () { return cc.modelTexture; }, set: function (v) { cc.modelTexture = v; } },
            fld(cc, "entityScale", "num", "Entity scale", "Render scale multiplier for the summoned Shenron."),
            head("Summon"),
            fld(cc, "darkenSky", "bool", "Darken sky", "Darken the sky while Shenron is summoned."),
            fld(cc, "summonDurationTicks", "int", "Duration (ticks)", "How long the summon lasts, in ticks (20 = 1 second)."),
            head("Offered Wishes"),
            note(cc.wishIds.length ? "Only the wishes marked In are offered." : "Every configured wish is offered (none marked In).")];
        SC.cfg.wishes.forEach(function (w) {
            var on = cc.wishIds.indexOf(w.id) >= 0;
            out.push({ type: "item", text: "§f" + amp(w.name || w.id) + " §8" + w.id, tip: "Wishes this colour offers. Leave empty to offer every configured wish.",
                buttons: [{ label: on ? "§aIn" : "§7Out", run: function () {
                    var i = cc.wishIds.indexOf(w.id);
                    if (i >= 0) cc.wishIds.splice(i, 1); else cc.wishIds.push(w.id);
                    click(); show();
                } }] });
        });
        out.push(head("Required Offerings"));
        cc.requiredItems.forEach(function (r, i) {
            out.push({ type: "item", text: "Item " + (i + 1), input: { x: CX, w: 130, tip: "Item id (minecraft:nether_star, or a DBR item name)", get: function () { return r.item; }, set: function (v) { r.item = String(v).trim(); } },
                buttons: [{ label: "§cX", w: 16, tip: "Remove", run: function () { cc.requiredItems.splice(i, 1); show(); } }] });
            out.push(fld(r, "count", "int", "  Count", "", { w: 60 }));
        });
        out.push({ type: "button", label: "§a+ Add Item", run: function () { cc.requiredItems.push({ item: "minecraft:nether_star", count: 1 }); show(); } });
        return out;
    }
    function wishEdit(w) {
        form({ id: "shrinewish", title: "Edit Wish", sub: "Editor", rows: function () {
            return [
                fld(w, "id", "text", "ID", "Stable key referenced by a colour's offered-wish list. Keep it unique.", { max: 64 }),
                fld(w, "name", "text", "Name", "Display name shown in the wish-select GUI."),
                fld(w, "description", "text", "Description", "Description shown under the name in the wish-select GUI."),
                { type: "text", label: "Commands", tip: "Console commands run when granted, separated by ' | '. %player% is the summoner's name.", max: 4000,
                  get: function () { return (w.commands || []).join(" | "); },
                  set: function (v) { w.commands = String(v).split("|").map(function (s) { return s.trim(); }).filter(function (s) { return s; }); } },
                note("Commands run as the console. %player% becomes the summoner's name.")];
        }, footer: [{ label: "Back", run: function () { w.id = String(w.id || "").trim(); shrineConfig(); } }] });
    }

    // =================================================================================
    //  ShrineListScreen + ShrineEditScreen: the stat shrines
    // =================================================================================
    var SL = { rows: [], newName: "", confirm: null };
    function trimNum(v) { v = Number(v) || 0; return v === Math.round(v) ? String(Math.round(v)) : String(v); }
    function hms(sec) {
        sec = Math.floor(Number(sec));
        if (isNaN(sec)) return "?";
        sec = Math.max(0, sec);
        var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
        return h + ":" + (m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s;
    }
    function act(op, more) { var d = { op: op }; for (var k in more || {}) d[k] = more[k]; RPG.net.send("dbr_stat_shrine", d); }
    RPG.net.on("dbr_stat_shrine_list", function (d) { SL.rows = (d && d.rows) || []; SL.confirm = null; shrineList(); });
    function uniqueCopy(base) {
        var taken = {}; SL.rows.forEach(function (r) { taken[r.name] = 1; });
        var c = base + "_copy", n = 2;
        while (taken[c]) c = base + "_copy" + (n++);
        return c;
    }
    function shrineList() {
        form({ id: "statlist", title: "Shrines", sub: "Shrines (" + SL.rows.length + ")", rows: function () {
            var out = [];
            SL.rows.forEach(function (r) {
                var armed = SL.confirm === r.name;
                out.push({ type: "item", text: "§b" + r.name + "  §7" + (r.type === "TP" ? "TP" : r.stat) + " +" + trimNum(r.percent) + "%", room: 36,
                    click: function () { click(); act("open", { name: r.name }); },
                    buttons: [{ label: "Copy", w: 40, run: function () { act("copy", { name: r.name, to: uniqueCopy(r.name) }); } },
                              { label: armed ? "§cConfirm" : "Delete", w: 42, run: function () {
                                  if (armed) act("delete", { name: r.name }); else { SL.confirm = r.name; show(); } } }] });
            });
            if (!SL.rows.length) out.push(note("No shrines defined."));
            return out;
        }, footer: [
            { input: true, placeholder: "new shrine name", get: function () { return SL.newName; }, set: function (v) { SL.newName = v; } },
            { label: "New", run: function () { var v = String(SL.newName || "").trim(); if (v) { SL.newName = ""; act("new", { name: v }); } } },
            { label: "Shenron", extra: { tooltip: "Shenron shrine colours, required items and their wishes." }, run: function () { RPG.net.send("dbr_shrine_config_open", {}); } },
            { label: "Close", run: function () { RPG.screen.close(); } }] });
    }
    var SE = null;
    RPG.net.on("dbr_stat_shrine_edit", function (d) {
        if (!d || !d.shrine) return;
        var keepTab = SE && SE.name === d.name;
        SE = { name: d.name, s: clone(d.shrine), stats: d.stats || ["STR", "SKP", "RES", "STM", "VIT", "PWR", "ENE"], maxPercent: d.maxPercent, maxDuration: d.maxDuration };
        if (!keepTab && F && F.id === "statedit") F = null;
        shrineEdit();
    });
    function shrineEdit() {
        var s = SE.s;
        form({ id: "statedit", title: "Shrines: " + SE.name, tabs: [
            { name: "Settings", rows: function () {
                var out = [
                    fld(s, "displayName", "text", "Display name", "Shown in the activation message. Supports & colour codes.", { max: 128 }),
                    { type: "enum", label: "Type", tip: "STAT = timed boost to one DMZ stat. TP = timed Training-Point gain boost.", rebuild: true,
                      options: [{ v: "STAT", l: "STAT" }, { v: "TP", l: "TP" }], get: function () { return s.type === "TP" ? "TP" : "STAT"; }, set: function (v) { s.type = v; } }];
                if (s.type !== "TP") out.push({ type: "enum", label: "Stat", tip: "Which DMZ stat this shrine boosts.",
                    options: SE.stats.map(function (k) { return { v: k, l: k }; }), get: function () { return s.statKey; }, set: function (v) { s.statKey = v; } });
                out.push(fld(s, "percent", "num", "Percent", "Boost strength, e.g. 25 = +25%." + (SE.maxPercent ? " Capped at " + trimNum(SE.maxPercent) + "%." : "")));
                out.push(fld(s, "duration", "int", "Duration (s): " + hms(s.duration), "Buff duration, in seconds. Shown as H:MM:SS in the label.",
                    { relabel: function () { return "Duration (s): " + hms(s.duration); } }));
                out.push(fld(s, "cooldown", "int", "Cooldown (s): " + hms(s.cooldown), "Per-player per-shrine cooldown, in seconds. Shown as H:MM:SS in the label.",
                    { relabel: function () { return "Cooldown (s): " + hms(s.cooldown); } }));
                return out;
            } },
            { name: "Bindings", rows: function () {
                var b = s.bindings || [], out = [note("Bound blocks (" + b.length + "):")];
                b.forEach(function (key) {
                    out.push({ type: "item", text: "§f" + key, room: 44, buttons: [{ label: "Unbind", w: 48, run: function () { act("unbind", { name: SE.name, key: key }); } }] });
                });
                out.push(note("Bind blocks in-world: /shrine bind " + SE.name + " while looking at a block."));
                return out;
            } }],
            footer: [
                { label: "§aSave", run: function () { act("save", { name: SE.name, displayName: s.displayName, type: s.type, statKey: s.statKey, percent: s.percent, duration: s.duration, cooldown: s.cooldown }); } },
                { label: "Back", run: function () { act("list"); } },
                { label: "Close", run: function () { RPG.screen.close(); } }] });
    }

    // =================================================================================
    //  BarrierConfigScreen: one Level Barrier wall's level and race
    // =================================================================================
    RPG.net.on("dbr_barrier_open", function (d) {
        if (!d) return;
        var b = { level: Number(d.level) || 0, race: String(d.race || "") };
        var races = [{ v: "", l: "§7(none)" }];
        try { RPG.defIds("race").forEach(function (id) { races.push({ v: id, l: RPG.defName("race", id) || id }); }); } catch (e) { }
        if (b.race && !races.some(function (r) { return r.v === b.race; })) races.push({ v: b.race, l: b.race });
        F = null;
        form({ id: "barrier", title: "Level Barrier", sub: "Per-block level gate", rows: function () {
            return [
                fld(b, "level", "int", "Required Level", "Level a player must reach to pass this barrier (applies to the whole connected wall)."),
                { type: "enum", label: "Required Race", tip: "Only players of this race can pass (in addition to the level requirement). Leave as (none) for any race.",
                  options: races, get: function () { return b.race; }, set: function (v) { b.race = v; } }];
        }, footer: [
            { label: "§aSave", run: function () { RPG.net.send("dbr_barrier_save", { x: d.x, y: d.y, z: d.z, level: Math.max(0, Math.floor(b.level)), race: b.race }); RPG.screen.close(); } },
            { label: "Cancel", run: function () { RPG.screen.close(); } }] });
    });
})();
