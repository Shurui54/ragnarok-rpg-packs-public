// =====================================================================================
//  57_dmz_impact_frames.js - DragonMine Z's impact frames (client side)
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): ImpactFramesHandler. A big hit (scripts/08_dmz_impact_frames.js)
//  turns the whole picture into a hard black-and-white frame for a couple of ticks: DMZ's own
//  shader from the asset pack (dmzpack:shaders/post/impact_frame.json, impact_frame.fsh) with
//  DMZ's uniforms: treshhold (brightness cut, relative to the brightest of 9 sample points),
//  treshholdLerp (soft edge) and invert (1 = bright parts go black).
//  Only when this player's "Impact Frames" option is on (V menu > Config > Visuals; off by default
//  like DMZ). Without the engine's post effects it falls back to a short white flash.
// =====================================================================================
(function () {
    var SHADER = "dmzpack:shaders/post/impact_frame.json";
    var flash = { until: 0, total: 1 };

    RPG.net.on("dmz_impact", function (d) {
        if (!DMZ_OPTS.impactFrames() || !d) return;
        var ticks = Math.max(1, Math.min(20, Number(d.k) || 2));
        var ok = false;
        try {
            if (RPG.camera && typeof RPG.camera.postEffect === "function")
                ok = RPG.camera.postEffect(SHADER, ticks, { treshhold: Number(d.t) || 0.7, treshholdLerp: Number(d.l) || 0, invert: d.i ? 1 : 0 });
        } catch (e) { ok = false; }
        if (!ok) { flash.total = ticks * 50; flash.until = RPG.nowMs() + flash.total; }
    });

    RPG.on("load", function () {
        RPG.hud.onRender(function (ctx) {
            var left = flash.until - RPG.nowMs();
            if (left > 0) ctx.fill(0, 0, ctx.width, ctx.height, "#FFFFFF", 0.69 * Math.min(1, left / flash.total + 0.3));
        });
    });
})();
