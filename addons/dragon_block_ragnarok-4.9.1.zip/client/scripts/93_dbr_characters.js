// =====================================================================================
//  93_dbr_characters.js - Character slots and prestige screens (client)
// =====================================================================================
//  Ports of DMZ Ragnarok's CharacterSelectScreen, PrestigeScreen and PrestigeAdminScreen
//  (GPL-3.0, shuruisutilities character/client and prestige/client), drawn with DragonMine
//  Z's own GUI art in the form editor's look (70_form_editor.js): questmenu panel, the
//  menubig ribbon, characterbuttons buttons / chips / fields / icons.
//
//  Every action goes to the server (scripts/93_dbr_characters.js, 93_dbr_prestige.js),
//  which answers with a refreshed copy of the screen, so a screen always shows the
//  authoritative state.
// =====================================================================================
var DBR_CHAR_UI = (function () {
    var U = DMZ_UI, D = DMZ_DATA;
    var FONT = "dmzpack:smooth";
    var BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png";
    var RACE_ICON = "dmzpack:textures/gui/hud/racial_icons/";
    var RACE_ICONS = { human: 1, saiyan: 1, namekian: 1, frostdemon: 1, majin: 1, bioandroid: 1 };
    var SCREEN = "dbr_chars_screen";

    // one screen at a time: S.kind = "chars" | "prestige" | "admin"
    var S = null;
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function now() { return RPG.nowMs(); }

    // =================================================================================
    //  Drawing kit (the form editor's helpers)
    // =================================================================================
    function txt(ctx, t, x, y, color, align, scale, alpha) { ctx.textStyled(String(t), x, y, scale || 0.75, color || "#FFFFFF", alpha === undefined ? 1 : alpha, align || 0, FONT, "#000000"); }
    function tw(ctx, t, scale) { return ctx.textWidthIn(String(t), FONT) * (scale || 0.75); }
    function fit(ctx, t, w, scale) {
        t = String(t);
        if (tw(ctx, t, scale) <= w) return t;
        while (t.length > 1 && tw(ctx, t + "...", scale) > w) t = t.substring(0, t.length - 1);
        return t + "...";
    }
    function inside(x, y, r) { return x >= r.x && y >= r.y && x < r.x + r.w && y < r.y + r.h; }
    function hit(x, y, w, h, fn, tip) { var r = { x: x, y: y, w: w, h: h, fn: fn, tip: tip }; S.hits.push(r); return r; }
    function over(ctx, x, y, w, h) { return inside(ctx.mouseX, ctx.mouseY, { x: x, y: y, w: w, h: h }); }
    function q(ctx, sx, sy, sw, sh, dx, dy, dw, dh, alpha) { ctx.quad(BUTTONS, dx, dy, dw, dh, sx / 256, sy / 256, (sx + sw) / 256, (sy + sh) / 256, "#FFFFFF", alpha === undefined ? 1 : alpha); }
    function button(ctx, label, x, y, w, fn, opt) {
        opt = opt || {};
        var dis = !!opt.disabled, hov = !dis && over(ctx, x, y, w, 20), v = hov || opt.light ? 48 : 28;
        q(ctx, 0, v, 4, 20, x, y, 4, 20); q(ctx, 4, v, 66, 20, x + 4, y, w - 8, 20); q(ctx, 70, v, 4, 20, x + w - 4, y, 4, 20);
        if (dis) ctx.fill(x + 2, y + 2, w - 4, 16, "#000000", 0.4);
        var col = opt.color || (dis ? "#909090" : opt.light ? "#1A3A10" : hov ? "#FFFFA0" : "#FFFFFF");
        ctx.textStyled(label, x + w / 2, y + 6, 1, col, 1, 0.5, FONT, opt.light ? null : "#000000");
        if (!dis) hit(x, y, w, 20, fn, opt.tip);
        else if (opt.tip) hit(x, y, w, 20, null, opt.tip);
    }
    function chip(ctx, label, x, y, w, sel, fn, tip) {
        var hov = fn && over(ctx, x, y, w, 12), v = sel || hov ? 48 : 28;
        U.slice9(ctx, BUTTONS, x, y, w, 12, 0, v, 74, 20, 4);
        txt(ctx, label, x + w / 2, y + 3, sel ? "#14300C" : hov ? "#FFFFA0" : "#FFFFFF", 0.5, 0.7);
        hit(x, y, w, 12, fn || null, tip);
    }
    function icon(ctx, kind, x, y, fn, tip) {
        var src = { plus: [0, 0], minus: [142, 0], trash: [10, 0], info: [112, 0], equal: [102, 0] }[kind];
        var hov = over(ctx, x, y, 10, 10);
        q(ctx, src[0], src[1] + (hov ? 10 : 0), 10, 10, x, y, 10, 10);
        hit(x, y, 10, 10, fn, tip);
    }
    function bigIcon(ctx, kind, x, y, size, fn, tip, disabled) {
        var u = { up: 162, down: 182, edit: 202 }[kind], hov = !disabled && over(ctx, x, y, size, size);
        q(ctx, u, hov ? 20 : 0, 20, 20, x, y, size, size, disabled ? 0.35 : 1);
        if (!disabled) hit(x, y, size, size, fn, tip);
    }
    function toggle(ctx, on, x, y, fn) { q(ctx, 122, on ? 0 : 10, 20, 10, x, y, 20, 10); hit(x, y, 20, 10, fn); }
    function field(ctx, x, y, w, h) {
        var v = 108;
        q(ctx, 0, v, 3, 3, x, y, 3, 3); q(ctx, 3, v, 101, 3, x + 3, y, w - 6, 3); q(ctx, 104, v, 3, 3, x + w - 3, y, 3, 3);
        q(ctx, 0, v + 3, 3, 11, x, y + 3, 3, h - 7); q(ctx, 3, v + 3, 101, 11, x + 3, y + 3, w - 6, h - 7); q(ctx, 104, v + 3, 3, 11, x + w - 3, y + 3, 3, h - 7);
        q(ctx, 0, v + 14, 3, 4, x, y + h - 4, 3, 4); q(ctx, 3, v + 14, 101, 4, x + 3, y + h - 4, w - 6, 4); q(ctx, 104, v + 14, 3, 4, x + w - 3, y + h - 4, 3, 4);
    }
    function panel(ctx, x, y, w, h, title) {
        U.QUEST_PANEL.draw(ctx, x, y, w, h);
        if (title) {
            var tw2 = Math.min(w - 30, 150);
            U.slice9(ctx, MENU_BIG, x + (w - tw2) / 2, y + 7, tw2, 21, 142, 22, 107, 21, 10);
            ctx.textStyled("§l" + title, x + w / 2, y + 14, 1, "#FFD700", 1, 0.5, FONT, "#000000");
        }
    }
    function scrollbar(ctx, x, top, h, total) {
        if (total <= h) return;
        var th = Math.max(16, h * h / total), ty = top + (h - th) * S.scroll / (total - h);
        ctx.fill(x, top, 2, h, "#000000", 0.35);
        ctx.fill(x, ty, 2, th, "#D2D7F1", 1);
    }
    var L = { listTop: 0, listH: 0, total: 0, rowH: 18, x: 0, w: 0 };
    function listArea(ctx, x, y, w, h, rows, rowH, drawRow) {
        L.listTop = y; L.listH = h; L.total = rows.length * rowH; L.rowH = rowH; L.x = x; L.w = w;
        S.scroll = clamp(S.scroll, 0, Math.max(0, L.total - h));
        ctx.clip(x, y, w, h);
        var saved = S.hits.length;
        rows.forEach(function (r, i) {
            var ry = y + i * rowH - S.scroll;
            if (ry + rowH < y || ry > y + h) return;
            drawRow(r, i, ry);
        });
        ctx.unclip();
        for (var k = S.hits.length - 1; k >= saved; k--) { var hb = S.hits[k]; if (hb.y + hb.h <= y || hb.y >= y + h) S.hits.splice(k, 1); }
        scrollbar(ctx, x + w + 2, y, h, L.total);
    }
    function status(t, c) { if (!S) return; S.msg = t; S.msgColor = c || "#FFFFFF"; S.msgUntil = now() + 4500; }
    function confirmKey(k) { return S.confirm && S.confirm.k === k && now() < S.confirm.until; }
    function askConfirm(k, fn, what) {
        if (confirmKey(k)) { S.confirm = null; fn(); return; }
        S.confirm = { k: k, until: now() + 3000 };
        status(what || "Click again to confirm", "#FFB040");
    }
    function raceIcon(ctx, ourRace, x, y, size, hov) {
        var dmz = (D.DMZ && D.DMZ[ourRace]) || ourRace || "";
        ctx.image(RACE_ICON + (RACE_ICONS[dmz] ? dmz : "custom") + ".png", x, y, size, size, 0, hov ? 16 : 0, 16, 16, 16, 32);
    }
    function raceName(ourRace) {
        if (!ourRace) return "No race yet";
        var dmz = (D.DMZ && D.DMZ[ourRace]) || ourRace, k = "race.dragonminez." + dmz;
        return U.hasTr(k) ? D.strip(U.tr(k)) : U.humanize(ourRace);
    }
    function fmtMs(ms) { var s = Math.ceil(ms / 1000), m = Math.floor(s / 60); s %= 60; return m > 0 ? m + "m " + (s < 10 ? "0" : "") + s + "s" : s + "s"; }

    // ---- the engine text box (one at a time) ----
    var INPUT = "dbr_ch_input";
    function showInput(x, y, w, value, maxLen, hint) {
        var sig = [Math.round(x), Math.round(y), w].join(",");
        if (S.inputSig === sig) return;
        S.inputSig = sig;
        RPG.screen.update(INPUT, { type: "input", anchor: "topleft", x: x, y: y, w: w, h: 12, value: S.inputValue === undefined ? (value || "") : S.inputValue,
            maxLength: maxLen || 32, hint: hint || "", visible: true,
            onChange: function (id, v) { if (S) S.inputValue = String(v); } });
    }
    function hideInput() { if (!S || S.inputSig === "hidden") return; S.inputSig = "hidden"; try { RPG.screen.update(INPUT, { visible: false }); } catch (e) { } }
    function inputValue() { return String(S && S.inputValue || "").trim(); }

    // =================================================================================
    //  The screen shell
    // =================================================================================
    function open(kind, data) {
        var keep = S && S.kind === kind && RPG.screen.getOpen() === SCREEN;
        if (keep) { S.data = data; S.confirm = null; return; }
        S = { kind: kind, data: data, hits: [], scroll: 0, tab: 0, msg: "", msgColor: "#FFFFFF", msgUntil: 0, confirm: null, inputSig: "", inputValue: undefined,
            work: null, edit: null };
        RPG.screen.open({ id: SCREEN, referenceHeight: 360, background: "dim", pause: false, elements: [],
            onBackground: render, onRender: renderTip, onMouse: mouse, onScroll: scroll, onKey: key, onClose: function () { S = null; } });
    }
    function render(ctx) {
        if (!S) return;
        S.hits = [];
        var cx = Math.floor(ctx.width / 2), cy = Math.floor(ctx.height / 2);
        S.wantsInput = false;
        if (S.kind === "chars") renderChars(ctx, cx, cy);
        else if (S.kind === "prestige") renderPrestige(ctx, cx, cy);
        else if (S.kind === "admin") renderAdmin(ctx, cx, cy);
        if (!S.wantsInput) hideInput();
        var left = S.msgUntil - now();
        if (left > 0 && S.msg) txt(ctx, S.msg, cx, ctx.height - 14, S.msgColor, 0.5, 0.8, Math.min(1, left / 800));
    }
    function renderTip(ctx) {
        if (!S) return;
        for (var i = S.hits.length - 1; i >= 0; i--) {
            var h = S.hits[i];
            if (h.tip && inside(ctx.mouseX, ctx.mouseY, h)) {
                var lines = (typeof h.tip === "string" ? [h.tip] : h.tip).map(function (l, n) { return [l, n === 0 ? "#FFD700" : "#C0C0C0"]; });
                U.tooltip(ctx, lines, ctx.mouseX, ctx.mouseY);
                break;
            }
        }
    }
    function mouse(x, y, b, action) {
        if (!S || action !== "down" || b !== 0) return;
        for (var i = S.hits.length - 1; i >= 0; i--) {
            var h = S.hits[i];
            if (h.fn && inside(x, y, h)) {
                try { RPG.sound("dmzpack:pip_menu", 0.6, 1); } catch (e) { }
                h.fn();
                return false;
            }
        }
    }
    function scroll(x, y, d) {
        if (!S) return;
        if (x >= L.x && x <= L.x + L.w + 6 && y >= L.listTop && y <= L.listTop + L.listH)
            S.scroll = clamp(S.scroll - (d > 0 ? L.rowH * 2 : -L.rowH * 2), 0, Math.max(0, L.total - L.listH));
    }
    function key(name, action) {
        if (!S || action !== "down") return;
        if ((name === "key.keyboard.enter" || name === "key.keyboard.keypad.enter") && S.kind === "chars" && inputValue()) { newChar(); return false; }
    }

    // =================================================================================
    //  1. Character slots (CharacterSelectScreen)
    // =================================================================================
    function act(action, slot, name) { RPG.net.send("dbr_chars", { action: action, slot: slot, name: name || "" }); }
    function newChar() {
        var d = S.data;
        if (d.slots.length >= d.max) { status("Slot limit reached (" + d.max + ")", "#FF6060"); return; }
        askConfirm("new", function () { act("new", 0, inputValue()); S.inputValue = ""; S.inputSig = ""; },
            "Click again: your current character is stored and a new one starts");
    }
    function renderChars(ctx, cx, cy) {
        var d = S.data, w = 320, h = 300, x = cx - w / 2, y = cy - h / 2;
        panel(ctx, x, y, w, h, "Characters");
        chip(ctx, "Slots (" + d.slots.length + "/" + d.max + ")", x + 16, y + 34, 90, false, null, ["Character slots", "More slots: prestige, or ask an admin"]);
        // what blocks a switch right now (the server checks again)
        var lockLine = d.combat > 0 ? ["In combat: swaps unlock in " + fmtMs(d.combat - (now() - S.at)), "#FF8060"]
            : d.cooldown > 0 && d.cooldown - (now() - S.at) > 0 ? ["Swap cooldown: " + fmtMs(d.cooldown - (now() - S.at)), "#FFB040"] : null;
        if (lockLine) txt(ctx, lockLine[0], x + w - 18, y + 37, lockLine[1], 1, 0.68);

        var bandH = d.tourFeature ? 92 : 72;
        listArea(ctx, x + 16, y + 52, w - 36, h - 52 - bandH, d.slots, 28, function (s, i, ry) {
            var rw = w - 36, hov = over(ctx, x + 16, ry, rw, 26);
            ctx.fill(x + 16, ry, rw, 26, s.active ? "#7CFF7C" : "#FFFFFF", s.active ? (hov ? 0.2 : 0.13) : (hov ? 0.16 : 0.07));
            if (s.active) ctx.fill(x + 16, ry, 2, 26, "#7CFF7C", 1);
            raceIcon(ctx, s.race, x + 21, ry + 3, 20, hov);
            txt(ctx, fit(ctx, (s.active ? "§a" : "§f") + "#" + (i + 1) + " " + s.name + (s.active ? " §a(active)" : ""), 150, 0.95), x + 47, ry + 4, "#FFFFFF", 0, 0.95);
            var sub = s.missing ? "§cdata missing" : (s.created ? raceName(s.race) + " · Lv " + (s.level || 1) : "§7not created yet");
            if (s.prestige > 0) sub += " · §6Prestige " + s.prestige;
            txt(ctx, fit(ctx, sub, 160, 0.65), x + 47, ry + 15, "#9FB8AE", 0, 0.65);
            // trailing Switch / Rename / delete, right-aligned (DMZR's row)
            var right = x + 16 + rw - 4;
            if (!s.active && d.slots.length > 1) {
                var dk = "del" + s.id;
                icon(ctx, "trash", right - 10, ry + 8, function () { askConfirm(dk, function () { act("delete", i); }, "Click again to delete " + s.name + " for good"); },
                    confirmKey(dk) ? ["Click again to delete", s.name] : ["Delete character", s.name, "Its items and progress go with it"]);
                right -= 14;
            }
            chip(ctx, "Rename", right - 44, ry + 7, 42, false, function () {
                var n = inputValue();
                if (!n) { status("Type the new name in the box below first", "#FFB040"); return; }
                act("rename", i, n); S.inputValue = ""; S.inputSig = "";
            }, ["Rename", "Uses the name typed in the box below"]);
            right -= 48;
            if (!s.active) button(ctx, "Switch", right - 52, ry + 3, 52, function () { act("switch", i); }, { disabled: !!s.missing });
        });

        // tournament character row (TournamentCharBridge): never a selectable slot, only made in advance or deleted
        var by = y + h - bandH + 6;
        if (d.tourFeature) {
            ctx.fill(x + 16, by - 2, w - 36, 18, "#FFFFFF", 0.05);
            txt(ctx, "Tournament character", x + 22, by + 3, d.tourPresent ? "#55FFFF" : "#707070", 0, 0.85);
            if (!d.tourPresent) {
                chip(ctx, "+ Create (not a slot)", x + w - 20 - 104, by + 1, 104, false, function () { act("tour_create", 0); },
                    ["Build your tournament fighter", "A separate fighter used only in tournaments.", "Your own character comes back when you finish."]);
            } else if (!d.tourActive) {
                icon(ctx, "trash", x + w - 32, by + 3, function () { askConfirm("tdel", function () { act("tour_delete", 0); }); },
                    confirmKey("tdel") ? "Click again to delete" : ["Delete tournament character", "Your own characters are not touched"]);
            } else txt(ctx, "in use", x + w - 22, by + 4, "#FFB040", 1, 0.7);
            by += 22;
        }
        // name field + New character
        field(ctx, x + 16, by, 160, 16);
        S.wantsInput = true;
        showInput(x + 20, by + 2, 152, "", 32, "name (New / Rename)");
        var canNew = d.slots.length < d.max;
        button(ctx, canNew ? "§a+ New character" : "§7Slot limit reached", x + 182, by - 2, w - 198, newChar, { disabled: !canNew,
            tip: canNew ? ["New character", "Stores the current one and starts fresh"] : ["Slot limit reached", "Prestige gives one more slot per level"] });
        button(ctx, "Back", x + w / 2 - 35, y + h - 30, 70, function () { RPG.screen.close(); });
    }

    RPG.net.on("dbr_chars_gui", function (d) {
        if (!d) return;
        d.slots = d.slots || [];
        open("chars", d);
        S.at = now();
    });
    // a character switch replaces the player's data: anything this computer cached about the old one goes
    RPG.net.on("dbr_chars_loaded", function (d) {
        try { if (typeof DMZ_STATS_UI !== "undefined" && DMZ_STATS_UI.reset) DMZ_STATS_UI.reset(); } catch (e) { }
        if (d && d.fresh && S && S.kind === "chars") RPG.screen.close();
    });

    // =================================================================================
    //  2. Prestige (PrestigeScreen)
    // =================================================================================
    function renderPrestige(ctx, cx, cy) {
        var d = S.data, w = 300, h = 300, x = cx - w / 2, y = cy - h / 2;
        panel(ctx, x, y, w, h, "Prestige");
        chip(ctx, "Prestige " + d.level + " / " + d.max, x + 16, y + 34, 100, false, null, ["Your character's prestige", "Each character slot climbs on its own", "This one: " + d.slot]);
        txt(ctx, "Bonus per prestige level:", x + 20, y + 52, "#B0B0B0", 0, 0.75);
        // the level list: scrolls when there are more levels than fit; opens at the next level
        var listTop = y + 64, listH = 104;
        if (!S.placed) { S.placed = true; S.scroll = clamp((d.level - 3) * 13, 0, Math.max(0, d.rows.length * 13 - listH)); }
        listArea(ctx, x + 16, listTop, w - 36, listH, d.rows, 13, function (r, i, ry) {
            var got = r.l <= d.level, next = r.l === d.level + 1;
            if (next) ctx.fill(x + 16, ry, w - 36, 12, "#FFD700", 0.1);
            txt(ctx, (got ? "§a> " : "§8- ") + "§fPrestige " + r.l + ": §e+" + r.tp + "%§f TP §7· §b+" + r.cap + "%§f cap" + (got ? " §a(earned)" : "") + (r.reward && !got ? " §6+ reward" : ""),
                x + 20, ry + 2, "#FFFFFF", 0, 0.72);
        });
        var iy = listTop + listH + 8;
        txt(ctx, "§6Total: §e+" + d.level * d.tpPer + "% TP§6, §b+" + d.level * d.capPer + "% stat cap", x + 20, iy, "#FFFFFF", 0, 0.8); iy += 13;
        var capTxt = String(Math.floor(d.cap)).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        txt(ctx, "§7Stats at the cap (" + capTxt + "): " + (d.atCap >= 6 ? "§a" : "§f") + d.atCap + " / 6", x + 20, iy, "#FFFFFF", 0, 0.75); iy += 14;
        txt(ctx, "§c[!] Prestiging resets your stats, abilities,", x + 20, iy, "#FFFFFF", 0, 0.72); iy += 10;
        txt(ctx, "§c    mastery, techniques, quests and Z-Soul progress.", x + 20, iy, "#FFFFFF", 0, 0.72); iy += 12;
        var line = d.can ? "§aMax level reached, ready to prestige!" : d.why ? "§7" + d.why : d.level >= d.max ? "§7Maximum prestige reached." : !d.created ? "§7Create your character first." : "§7Reach max level to prestige.";
        txt(ctx, line, x + 20, iy, "#FFFFFF", 0, 0.75);
        var by = y + h - 54;
        button(ctx, d.can ? "§6§lPRESTIGE" : d.level >= d.max ? "Maxed" : "Not max level", x + 20, by, w - 40, function () {
            askConfirm("prestige", function () { RPG.net.send("dbr_prestige", { action: "prestige" }); }, "Click again to prestige: this character starts over");
        }, { disabled: !d.can, light: d.can && confirmKey("prestige") });
        button(ctx, "Back", x + w / 2 - 35, y + h - 30, 70, function () { RPG.screen.close(); });
    }
    RPG.net.on("dbr_prestige_gui", function (d) { if (d) { d.rows = d.rows || []; open("prestige", d); } });

    // =================================================================================
    //  3. Prestige config (PrestigeAdminScreen): Config and Race tabs
    // =================================================================================
    function adminRows(W) {
        return [
            { kind: "bool", label: "Prestige enabled", get: function () { return W.enabled; }, set: function (v) { W.enabled = v; }, tip: ["Prestige enabled", "Off: nobody can prestige and every bonus pauses"] },
            { kind: "num", label: "Max prestige level", key: "max", step: 1, min: 0, max: 100000, tip: ["Highest prestige a character can reach", "DMZR default: 3"] },
            { kind: "num", label: "TP bonus % / level", key: "tp", step: 5, min: 0, max: 100000, tip: ["Bonus TP earned per prestige level", "Additive: 10 = +30% at prestige 3"] },
            { kind: "num", label: "Stat cap % / level", key: "cap", step: 5, min: 0, max: 100000, tip: ["Raises the per-stat cap per prestige level", "Additive: 25 = double the cap at prestige 4"] },
            { kind: "text", label: "NPC model", key: "model", tip: ["What a prestige NPC is", "A DMZ Ragnarok NPC id (rgnpc), a script NPC or an entity id", "minecraft:villager by default"] },
            { kind: "text", label: W.entity ? "NPC name" : "Default name", key: "name", tip: ["The name over the NPC"] }
        ];
    }
    function renderAdmin(ctx, cx, cy) {
        var d = S.data, W = S.work, w = 320, h = 310, x = cx - w / 2, y = cy - h / 2;
        panel(ctx, x, y, w, h, "Prestige Config");
        chip(ctx, "Config", x + 16, y + 34, 60, S.tab === 0, function () { S.tab = 0; S.scroll = 0; S.edit = null; });
        chip(ctx, "Race", x + 80, y + 34, 60, S.tab === 1, function () { S.tab = 1; S.scroll = 0; S.edit = null; });
        if (S.tab === 0) {
            var ry = y + 54;
            adminRows(W).forEach(function (r) { drawRow(ctx, r, x + 16, ry, w - 32, 16, W); ry += 19; });
            txt(ctx, W.entity ? "Changing the model respawns this NPC." : "Model = default type for new prestige NPCs.", x + 20, ry + 4, "#808080", 0, 0.68);
            txt(ctx, "Rewards, colours, quest gates: /prestige help", x + 20, ry + 16, "#808080", 0, 0.68);
            var by = y + h - 54;
            button(ctx, "§aSave", x + 20, by, 136, function () { sendAdmin("admin_save"); });
            button(ctx, "Spawn NPC here", x + 164, by, 136, function () { sendAdmin("admin_spawn"); }, { tip: ["Save, then spawn a prestige NPC where you stand"] });
        } else {
            txt(ctx, "Required prestige per race (0 = unlocked), OP = operators only", x + 20, y + 52, "#B0B0B0", 0, 0.68);
            listArea(ctx, x + 16, y + 64, w - 36, h - 64 - 62, d.races, 18, function (race, i, ry) {
                var k = String(race).toLowerCase(), hov = over(ctx, x + 16, ry, w - 36, 16);
                ctx.fill(x + 16, ry, w - 36, 16, "#FFFFFF", hov ? 0.12 : 0.05);
                raceIcon(ctx, race, x + 19, ry + 1, 14, false);
                txt(ctx, fit(ctx, d.raceNames[i] || race, 110, 0.78), x + 38, ry + 4, "#FFFFFF", 0, 0.78);
                var r = { kind: "num", label: race, step: 1, min: 0, max: 100000,
                    get: function () { return Number(W.raceReq[k]) || 0; }, set: function (v) { if (v > 0) W.raceReq[k] = v; else delete W.raceReq[k]; } };
                numField(ctx, r, x + 160, ry + 1, 96, 14);
                var op = W.opOnly.indexOf(k) >= 0;
                chip(ctx, "OP", x + w - 20 - 34, ry + 2, 30, op, function () { var j = W.opOnly.indexOf(k); if (j >= 0) W.opOnly.splice(j, 1); else W.opOnly.push(k); },
                    op ? ["Operators only", "Click: everyone may pick it"] : ["Not operator only", "Click: only operators may pick it"]);
            });
            button(ctx, "§aSave Race Gates", x + 20, y + h - 54, w - 40, function () { RPG.net.send("dbr_prestige", { action: "race_save", raceReq: W.raceReq, opOnly: W.opOnly }); });
        }
        button(ctx, "Back", x + w / 2 - 35, y + h - 30, 70, function () { RPG.screen.close(); });
    }
    function sendAdmin(action) {
        var W = S.work;
        RPG.net.send("dbr_prestige", { action: action, max: W.max, tp: W.tp, cap: W.cap, model: W.model, name: W.name, entity: W.entity, enabled: W.enabled });
        RPG.screen.close();
    }
    // rows: bool / num / text, in the form editor's style
    function drawRow(ctx, r, x, y, w, h, W) {
        if (over(ctx, x, y, w, h)) ctx.fill(x, y, w, h, "#FFFFFF", 0.07);
        txt(ctx, r.label, x + 4, y + 4, "#FFFFFF", 0, 0.78);
        if (r.tip) hit(x, y, Math.floor(w * 0.44), h, null, r.tip);
        var vx = x + Math.floor(w * 0.48), vw = w - Math.floor(w * 0.48) - 4;
        if (r.kind === "bool") { toggle(ctx, !!r.get(), vx + 2, y + 3, function () { r.set(!r.get()); }); return; }
        if (r.kind === "num") {
            numField(ctx, { kind: "num", label: r.label, step: r.step, min: r.min, max: r.max, get: function () { return W[r.key]; }, set: function (v) { W[r.key] = v; } }, vx, y, vw, h);
            return;
        }
        // text: an engine input while editing
        var editing = S.edit === r.key;
        field(ctx, vx, y, vw, h);
        if (editing) {
            S.wantsInput = true;
            showInput(vx + 4, y + 2, vw - 8, String(W[r.key] || ""), 64, "");
            W[r.key] = S.inputValue === undefined ? W[r.key] : S.inputValue;
        } else {
            txt(ctx, fit(ctx, String(W[r.key] || ""), vw - 8, 0.72), vx + 4, y + 4, "#FFFFFF", 0, 0.72);
            hit(vx, y, vw, h, function () { S.edit = r.key; S.inputValue = String(W[r.key] || ""); S.inputSig = ""; }, "Click to edit");
        }
    }
    function numField(ctx, r, vx, y, vw, h) {
        var v = Number(r.get()) || 0;
        icon(ctx, "minus", vx, y + 2, function () { r.set(clamp(v - r.step * (shift() ? 10 : 1), r.min, r.max)); }, ["-" + r.step, "Shift: x10"]);
        field(ctx, vx + 12, y, vw - 24, h);
        txt(ctx, String(v), vx + vw / 2, y + 4, v ? "#FFFFFF" : "#9A9A9A", 0.5, 0.72);
        icon(ctx, "plus", vx + vw - 10, y + 2, function () { r.set(clamp(v + r.step * (shift() ? 10 : 1), r.min, r.max)); }, ["+" + r.step, "Shift: x10"]);
    }
    function shift() { return RPG.isKeyDown("key.keyboard.left.shift") || RPG.isKeyDown("key.keyboard.right.shift"); }
    RPG.net.on("dbr_prestige_admin", function (d) {
        if (!d) return;
        d.races = d.races || []; d.raceNames = d.raceNames || [];
        open("admin", d);
        var req = {}, ops = [];
        Object.keys(d.raceReq || {}).forEach(function (k) { req[k] = Number(d.raceReq[k]) || 0; });
        (d.opOnly || []).forEach(function (k) { ops.push(String(k)); });
        S.work = { max: Number(d.max) || 0, tp: Number(d.tp) || 0, cap: Number(d.cap) || 0, model: String(d.model || ""), name: String(d.name || ""),
            entity: String(d.entity || ""), enabled: d.enabled !== false, raceReq: req, opOnly: ops };
    });

    return { state: function () { return S; }, open: function () { RPG.net.send("dbr_chars", { action: "open" }); } };
})();
