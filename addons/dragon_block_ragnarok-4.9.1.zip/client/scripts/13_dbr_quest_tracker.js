// =====================================================================================
//  13_dbr_quest_tracker.js - DMZ Ragnarok's quest tracker HUD
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0, by Shurui): shuruisutilities/.../client/gui/task/QuestTrackerOverlay.java
//  and QuestArt.java. Art: dbr:textures/gui/task/quest_info.png (the quest banner) and
//  dbr:textures/gui/marker/<red|blue|yellow|purple|green>.png (the marker pins), copied from
//  DMZ Ragnarok's assets/dmz_ragnarok/textures/gui.
//
//  The commissioned quest banner (it is the panel's title, so no text header is drawn over it), then:
//   - ONE quest entry for the mission you are TRACKING (Track in the quest menu; with nothing tracked
//     the first accepted, unfinished quest stands in): its pin (red story / blue side), its name, and
//     under it, indented and dimmer, its outstanding objectives in DMZ's own phrasing, "(1/3)" when the
//     count is above one (a parallel quest lists them all, a sequential one only the one it is on).
//     DBR has no compass, so location objectives are listed too (DMZ Ragnarok does this without one).
//   - a row per active notice other DBR systems register with DBR_QUEST_TRACKER.addProvider (open
//     tournament sign-ups, purple, like DMZ Ragnarok's TournamentSignupWaypoints).
//  Rows wrap on words (name and suffix as one unit) to the banner's width and stop at the screen's
//  bottom with "...". The panel slides in from the nearest screen edge (tau 0.16 s) and out again.
//  Movable / resizable / hideable in the HUD editor as "Quest Tracker" (dbr_quest_tracker); the
//  default place is DMZ Ragnarok's top-right fallback (5 px from the right, 120 px down, 160 wide).
// =====================================================================================
var DBR_QUEST_TRACKER = (function () {
    var BANNER = "dbr:textures/gui/task/quest_info.png", BANNER_W = 354, BANNER_H = 58;
    var PIN = function (c) { return "dbr:textures/gui/marker/" + c + ".png"; };
    var PIN_COLOR = { red: "#FF8C26", blue: "#80A6F4", yellow: "#E8BC1A", purple: "#B88BEA", green: "#6FD816" };
    var BOX_W = 160, BOX_H = 100, ROW_LEFT = 4, ICON = 8, ICON_GAP = 4, ROW_H = 11, LINE_H = 9;
    var TEXT = "#FFFFFF", SUFFIX = "#BFC7D5", NONE = "#CFD6E4";
    var GAP_BELOW_BANNER = 3, INDENT = 6, MIN_TEXT_W = 70, BOTTOM_MARGIN = 4, RIGHT_MARGIN = 5, TOP_Y = 120;
    var SLIDE_TAU = 0.16, SLIDE_EXTRA = 8;
    var providers = [];

    function tr(key, fallback) { try { return RPG.hasTranslation(key) ? String(RPG.translate(key)) : fallback; } catch (e) { return fallback; } }

    // ---- the quest state (scripts/47_dmz_quests.js syncs it when it changes; ask once on join) ----
    RPG.on("load", function () { RPG.net.send("dmz_quest", { action: "state" }); });
    var asked = 0;
    RPG.every(200, function () {
        if (typeof QUESTS_SCREEN === "undefined" || !RPG.getVar("dmz_created", 0)) return;
        if (!Object.keys(QUESTS_SCREEN.data.q || {}).length && asked < 3) { asked++; RPG.net.send("dmz_quest", { action: "state" }); }
    });

    /** pickQuest: the tracked quest if accepted and unfinished, else the first accepted, unfinished one. */
    function pickQuest(data, QL) {
        var q = data.q || {}, tracked = data.tr;
        if (tracked && q[tracked] && q[tracked].s === QL.ACCEPTED && QL.entry(tracked)) return tracked;
        var keys = Object.keys(q);
        for (var i = 0; i < keys.length; i++) if (q[keys[i]] && q[keys[i]].s === QL.ACCEPTED && QL.entry(keys[i])) return keys[i];
        return null;
    }
    function questEntry() {
        if (typeof QUESTS_SCREEN === "undefined" || typeof DMZ_QL === "undefined") return null;
        var QL = DMZ_QL, data = QUESTS_SCREEN.data, key = pickQuest(data, QL);
        if (!key) return null;
        var e = QL.entry(key), q = e.quest, view = { q: data.q }, lines = [];
        try {
            var objs = q.objectives || [];
            for (var i = 0; i < objs.length; i++) {
                var o = objs[i];
                if (!o) continue;
                var cur = QL.progress(view, key, i), req = QL.required(o);
                if (cur >= req) continue;
                var text;
                try { text = QUESTS_SCREEN.describeObjective(o); } catch (x) { text = String(o.type || "").toLowerCase(); }
                lines.push(req > 1 ? "- " + text + " (" + cur + "/" + req + ")" : "- " + text);
                if (!q.parallel_objectives) break;
            }
        } catch (x) { /* a quest with no listable objectives is still an entry */ }
        var title;
        try { title = DMZ_QUEST_NAMES.title(e); } catch (x) { title = key; }
        return { pin: e.side ? "blue" : "red", label: title, suffix: null, objectives: lines };
    }
    function collect() {
        var out = [], q = questEntry();
        if (q) out.push(q);
        providers.forEach(function (fn) {
            try { (fn() || []).forEach(function (r) { if (r && r.label) out.push({ pin: r.pin || null, label: String(r.label), suffix: r.suffix || null, objectives: [] }); }); }
            catch (x) { /* one broken provider never empties the panel */ }
        });
        return out;
    }

    // ---- word wrap of [text, colour] runs to a width (Font.split on a styled component) ----
    function wrapRuns(ctx, runs, width) {
        var words = [];
        runs.forEach(function (r) { String(r[0]).split(" ").forEach(function (w, i) { if (w.length) words.push({ t: w, c: r[1], sp: words.length > 0 }); }); });
        var lines = [], line = [], lw = 0, space = ctx.textWidth(" ");
        words.forEach(function (w) {
            var ww = ctx.textWidth(w.t), add = line.length ? space + ww : ww;
            if (line.length && lw + add > width) { lines.push(line); line = []; lw = 0; add = ww; }
            line.push(w); lw += add;
        });
        if (line.length) lines.push(line);
        return lines;
    }
    function drawLine(ctx, line, x, y) {
        var cx = x, space = ctx.textWidth(" ");
        line.forEach(function (w, i) {
            if (i > 0) cx += space;
            ctx.text(w.t, cx, y, w.c, true);
            cx += ctx.textWidth(w.t);
        });
    }
    function exclamation(ctx, x, y, size, color) {
        var w = Math.max(2, Math.floor(size / 4)), cx = x + Math.floor(size / 2) - Math.floor(w / 2);
        ctx.fill(cx, y, w, Math.floor(size * 3 / 5), color, 1);
        ctx.fill(cx, y + Math.floor(size * 3 / 4), w, w, color, 1);
    }

    // drawPanel, in the element's local space (0, 0 = the banner's top-left), bottomLimit = local screen bottom
    function drawPanel(ctx, entries, bottomLimit) {
        var scale = Math.max(0.35, Math.min(1, BOX_W / BANNER_W)), bw = Math.round(BANNER_W * scale), bh = Math.round(BANNER_H * scale);
        ctx.quad(BANNER, 0, 0, bw, bh, 0, 0, 1, 1, "#FFFFFF", 1);
        var textX = ROW_LEFT + ICON + ICON_GAP, room = Math.max(16, Math.max(MIN_TEXT_W, bw - textX));
        var y = bh + GAP_BELOW_BANNER, cut = false;
        for (var n = 0; n < entries.length && !cut; n++) {
            var en = entries[n];
            if (y + ROW_H > bottomLimit) { cut = true; break; }
            var iy = y + (ROW_H - ICON) / 2;
            if (en.pin && PIN_COLOR[en.pin]) ctx.quad(PIN(en.pin), ROW_LEFT, iy, ICON, ICON, 0, 0, 1, 1, "#FFFFFF", 1);
            else exclamation(ctx, ROW_LEFT, iy, ICON, NONE);
            var ty = y + (ROW_H - LINE_H) / 2, runs = [[en.label, TEXT]];
            if (en.suffix) runs.push([en.suffix, SUFFIX]);
            var lines = wrapRuns(ctx, runs, room);
            for (var i = 0; i < lines.length; i++) {
                if (y + ROW_H > bottomLimit) { cut = true; break; }
                drawLine(ctx, lines[i], textX, ty);
                y += ROW_H; ty += ROW_H;
            }
            for (var o = 0; o < en.objectives.length && !cut; o++) {
                var parts = wrapRuns(ctx, [[en.objectives[o], SUFFIX]], Math.max(16, room - INDENT));
                for (var j = 0; j < parts.length; j++) {
                    if (y + ROW_H > bottomLimit) { cut = true; break; }
                    drawLine(ctx, parts[j], textX + INDENT, ty);
                    y += ROW_H; ty += ROW_H;
                }
            }
        }
        if (cut) ctx.text("...", ROW_LEFT, y, SUFFIX, true);
    }

    // ---- the element: slide in / out (RagnarokHud.paint's SLIDE appear) ----
    var shown = [], appear = 0, lastMs = 0;
    function ease(target) {
        var now = RPG.nowMs(), dt = lastMs ? (now - lastMs) / 1000 : 0;
        lastMs = now;
        if (dt > 1) return appear = target;
        dt = Math.min(dt, 0.25);
        appear += (target - appear) * (1 - Math.exp(-dt / SLIDE_TAU));
        if (Math.abs(target - appear) <= 0.005) appear = target;
        return appear;
    }
    function render(ctx) {
        if (!RPG.player.present) return;
        var editing = ctx.isEditing(), live = collect();
        if (live.length) shown = live;
        else if (editing) shown = [{ pin: "red", label: tr("gui.dragonminez.hud_editor.sample.quest_title", "Sample Quest"), suffix: "(120m)",
            objectives: [tr("gui.dragonminez.hud_editor.sample.quest_objective", "- Defeat the enemy (1/3)")] }];
        var a = editing ? (appear = 1) : ease(live.length ? 1 : 0);
        if (a <= 0.005 || !shown.length) { if (!live.length && a <= 0.005) shown = []; return; }
        var x = ctx.width - BOX_W - RIGHT_MARGIN, y = Math.min(TOP_Y, Math.max(2, ctx.height - BOX_H - 2));
        if (!ctx.group("dbr_quest_tracker", "Quest Tracker", x, y, BOX_W, BOX_H)) return;
        ctx.push();
        ctx.translate(x, y);
        if (!editing && a < 1) {
            var t = 1 - (1 - a) * (1 - a), fromRight = x + BOX_W / 2 >= ctx.width / 2;
            ctx.translate((1 - t) * (fromRight ? ctx.width - x + SLIDE_EXTRA : -(x + BOX_W + SLIDE_EXTRA)), 0);
        }
        ctx.alpha(a);
        // the panel runs past its box down to the screen's bottom; the group's own scale is not known here,
        // so stop at the unscaled screen bottom (DMZ Ragnarok's RagnarokHudFrame.screenBottom at scale 1)
        drawPanel(ctx, shown, ctx.height - y - BOTTOM_MARGIN);
        ctx.alpha(1);
        ctx.pop();
        ctx.endGroup();
    }
    RPG.on("load", function () { RPG.hud.onRender(render); });

    return {
        /** fn() -> [{ label, suffix?, pin?: "red" | "blue" | "yellow" | "purple" | "green" }], called every frame. */
        addProvider: function (fn) { if (typeof fn === "function") providers.push(fn); },
        /** Whether the tracker is drawing (other HUD pieces fold into it instead of drawing their own panel). */
        active: function () { return true; }
    };
})();
