// =====================================================================================
//  72_dball_rims.js - the stars inside each placed Dragon Ball, and its thin glowing rim
// =====================================================================================
//  DMZ Ragnarok (SuDragonBallBlockRenderer / DragonBallShell) draws its see-through balls
//  with the stars on a sprite that always faces the camera, floating in the middle of the
//  glass, and a lighter, glowing ring at the edge. The glass is a block model (the exact
//  shape of the set's DMZ geo, resources/.../dball_glass); the stars and the rim are drawn
//  here with RPG.world3d. The server sends the placed balls near you (57_dragon_balls.js,
//  "dbr_ball_rims": [x, y, z, set, stars, dormant]). Dormant (stone) balls get neither.
// =====================================================================================
(function () {
    // ball centre height and half-size in blocks (the geo's bounds, inflate included: DragonBallSets), rim colour (the
    // set's glass, lighter) and star tint (DragonBallShell PIP_RED, or PIP_DARK for Black Star)
    var RED = "#DB2105", DARK = "#242424";
    var SETS = {
        earth: { cy: 3.375 / 16, r: 3.75 / 16, color: "#FFD27A", pip: RED },
        namek: { cy: 5.625 / 16, r: 5.75 / 16, color: "#FFD27A", pip: RED },
        demon: { cy: 5.625 / 16, r: 5.75 / 16, color: "#FFAA66", pip: RED },
        // DMZ Ragnarok's sets (DragonBallSets; rim = DragonBallShell.lighten of the glass colour)
        super: { cy: 22.5 / 16, r: 23 / 16, color: "#FFEB7D", pip: RED },
        blackstar: { cy: 3.375 / 16, r: 3.75 / 16, color: "#FFC466", pip: DARK },
        cerulean: { cy: 1.6875 / 16, r: 1.875 / 16, color: "#FFBC66", pip: RED }
    };
    var TEX = "dbr:textures/block/dball_glass/rim.png", STARS = "dbr:textures/entity/dball_stars/star";
    // DragonBallShell.drawStars: the sprite is 2 x 0.62 x the ball radius across. DMZ Ragnarok draws it first and its
    // 70%-opaque glass over it, so 30% of the star shows through; here the glass is already drawn, so the star goes on
    // top at that same 30%. nudge pulls it out in front of the glass (the geo's corners reach about 1.2 radii from the
    // centre) at the same size on screen, so the glass doesn't hide it but a wall in front of the ball still does.
    var STAR_SIZE = 2 * 0.62, STAR_ALPHA = 0.3, NUDGE = 1.25;
    RPG.net.on("dbr_ball_rims", function (d) {
        if (!RPG.world3d) return;
        RPG.world3d.removePrefix("dbr_rim_");
        RPG.world3d.removePrefix("dbr_stars_");
        (d && d.list || []).forEach(function (b) {
            // b[5]: the set is dormant. A stone ball has no stars or rim (DormantBallRender: no glass, no star, no rim)
            if (b[5]) return;
            var set = SETS[b[3]] || SETS.earth, key = b[0] + "_" + b[1] + "_" + b[2];
            var x = b[0] + 0.5, y = b[1] + set.cy, z = b[2] + 0.5, n = Math.max(1, Math.min(7, Number(b[4]) || 1));
            RPG.world3d.billboard("dbr_stars_" + key, {
                x: x, y: y, z: z, size: set.r * STAR_SIZE, texture: STARS + n + ".png",
                color: set.pip, alpha: STAR_ALPHA, emissive: true, nudge: set.r * NUDGE
            });
            RPG.world3d.billboard("dbr_rim_" + key, {
                x: x, y: y, z: z, size: set.r * 2 * 1.12,
                texture: TEX, color: set.color, alpha: 1, blend: "additive", emissive: true
            });
        });
    });
})();
