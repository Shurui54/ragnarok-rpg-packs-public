// =====================================================================================
//  82_dbr_raids_zsouls.js - Z-Souls on the client: the Z-Soul "+" next to a capped stat in
//  DMZ's stats screen (ZSoulStatsScreenMixin + ZSoulAddButton) and the Z-Soul screen
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0) shuruis_raid_bosses client: the stats-screen button shows
//  only for a stat with a soul worn whose base is at the cap, buys beyond-cap points at DMZ's
//  own escalating price (tooltip: the real TP cost), and is server-validated
//  (scripts/92_dbr_raids_zsouls.js). Click = 1 point, Shift = 10, Ctrl = 100, both = 1000.
//  The Z-Soul screen (/raid zsoul, or right-click a soul with no free slot) lists every stat:
//  worn tier, active / banked / allowance, and the same purchase in x1 .. x1000.
// =====================================================================================
(function () {
    var U = DMZ_UI, FONT = U.FONT, BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var TIER_COLORS = ["#FFAA00", "#C8C8C8", "#FFFF55", "#FF77FF"];
    var MULTS = [1, 10, 100, 1000];
    var ST = null;               // last dbr_zsoul_state
    RPG.net.on("dbr_zsoul_state", function (d) { ST = d || null; });          // the open screen reads it every frame
    function send(a, extra) { var d = { a: a }; for (var k in extra || {}) d[k] = extra[k]; RPG.net.send("dbr_zsoul", d); }
    function fmt(n) { return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
    function row(dmz) { if (!ST) return null; for (var i = 0; i < ST.rows.length; i++) if (ST.rows[i].d === dmz) return ST.rows[i]; return null; }
    function usable(r) { return !!(ST && ST.on && r && r.t >= 0 && r.capped && r.b < r.max); }
    function cost(r, n) { return typeof DMZ_F !== "undefined" ? DMZ_F.cost(r.start, Math.max(1, Math.min(n, r.max - r.b)), ST.m || 1) : 0; }
    function clickMult() {
        var sh = RPG.isKeyDown("key.keyboard.left.shift") || RPG.isKeyDown("key.keyboard.right.shift");
        var ct = RPG.isKeyDown("key.keyboard.left.control") || RPG.isKeyDown("key.keyboard.right.control");
        return sh && ct ? 1000 : ct ? 100 : sh ? 10 : 1;
    }
    function tierName(t) { return ST && ST.tiers[t] ? ST.tiers[t].n : "?"; }

    // ---- the "+" in DMZ's stats screen (client/scripts/30_stats_screen.js lays its own "+" at x 27) ----
    var SHOWN = {}, WAS_OPEN = false, ASKED = 0;
    function tip(r) {
        var n = Math.max(1, Math.min(clickMult(), r.max - r.b));
        return { title: "§bZ-Soul §7(" + tierName(r.t) + ")", lines: ["§f+" + n + " " + r.n + " beyond cap  §e" + fmt(cost(r, n)) + " TP",
            "§7Active +" + fmt(r.a) + " / allowance +" + fmt(r.max), "§8Shift x10, Ctrl x100, both x1000"] };
    }
    function syncStatsScreen() {
        var open = RPG.screen.getOpen() === "dmz_stats";
        if (!open) { if (WAS_OPEN) { SHOWN = {}; WAS_OPEN = false; } return; }
        if (!WAS_OPEN) { WAS_OPEN = true; SHOWN = {}; send("state"); ASKED = RPG.time(); }
        else if (RPG.time() - ASKED > 40) { send("state"); ASKED = RPG.time(); }
        DMZ_DATA.STATS.forEach(function (s, i) {
            var id = "zsoul_plus_" + s, r = row(s), want = usable(r);
            if (!want) { if (SHOWN[id]) { RPG.screen.remove(id); delete SHOWN[id]; } return; }
            var t = tip(r), key = JSON.stringify(t);
            if (SHOWN[id] === key) return;
            SHOWN[id] = key;
            RPG.screen.update(id, { id: id, type: "button", anchor: "left", x: 15, y: -4 + 12 * i, w: 10, h: 10, texture: BUTTONS, texW: 256, texH: 256,
                u: 0, v: 0, uw: 10, vh: 10, hoverU: 0, hoverV: 10, tint: "#8FB8FF", tooltip: t,
                onClick: function () { send("invest", { stat: s, n: clickMult() }); RPG.sound("minecraft:ui.button.click", 0.6, 1.2); } });
        });
    }
    RPG.every(4, syncStatsScreen);

    // ---- the Z-Soul screen ----
    var OPEN = false, MI = 0, HIT = [];
    RPG.net.on("dbr_zsoul_open", function () { OPEN = true; render(); });
    function render() {
        RPG.screen.open({ id: "dbr_zsoul", referenceHeight: 360, background: "dim", elements: [], onBackground: draw, onMouse: mouse,
            onClose: function () { OPEN = false; } });
    }
    function draw(ctx) {
        var W = 330, H = 236, px = Math.floor((ctx.width - W) / 2), py = Math.floor((ctx.height - H) / 2), mx = ctx.mouseX, my = ctx.mouseY, tipLines = null;
        HIT = [];
        ctx.fill(px + 6, py + 6, W - 12, H - 12, "#0F1020", 0.8);
        U.QUEST_PANEL.draw(ctx, px, py, W, H);
        U.bordered(ctx, "§lZ-Souls", px + W / 2, py + 10, "#8FB8FF", 0.5);
        if (!ST) { U.plain(ctx, "§7Loading...", px + W / 2, py + 40, "#FFFFFF", 0.5); return; }
        if (!ST.on) { U.plain(ctx, "§cThe Z-Soul system is disabled.", px + W / 2, py + 40, "#FFFFFF", 0.5); }
        U.plain(ctx, "§7Global cap §f" + fmt(ST.cap) + "§7  ·  TP §e" + fmt(RPG.player.tp) + "§7  ·  " + ST.slots + " slot" + (ST.slots === 1 ? "" : "s"), px + W / 2, py + 22, "#FFFFFF", 0.5);
        var y = py + 38, cols = [px + 16, px + 92, px + 156, px + 232];
        U.plain(ctx, "§6Stat", cols[0], y, "#FFFFFF"); U.plain(ctx, "§6Soul", cols[1], y, "#FFFFFF"); U.plain(ctx, "§6Active / Banked", cols[2], y, "#FFFFFF");
        y += 12;
        ST.rows.forEach(function (r) {
            U.plain(ctx, r.n, cols[0], y, r.capped ? "#FFFFFF" : "#A0A0A0");
            U.plain(ctx, r.t >= 0 ? tierName(r.t) + " §7+" + fmt(r.max) : "§8not worn", cols[1], y, r.t >= 0 ? TIER_COLORS[r.t] : "#808080");
            U.plain(ctx, "§a+" + fmt(r.a) + " §7/ " + fmt(r.b), cols[2], y, "#FFFFFF");
            var ok = usable(r), bx = cols[3], by = y - 2, bw = 74, bh = 12, over = mx >= bx && my >= by && mx < bx + bw && my < by + bh;
            U.buttonArt(ctx, bx, by, bw, bh, over && ok);
            if (!ok) ctx.fill(bx + 2, by + 2, bw - 4, bh - 4, "#000000", 0.45);
            var n = Math.max(1, Math.min(MULTS[MI], r.max - r.b));
            ctx.textStyled("+" + MULTS[MI] + "  §e" + (ok ? fmt(cost(r, n)) + " TP" : "-"), bx + bw / 2, by + 3, 0.75, ok ? "#FFFFFF" : "#808080", 1, 0.5, FONT, "#000000");
            HIT.push([bx, by, bw, bh, function () { if (ok) send("invest", { stat: r.d, n: MULTS[MI] }); }]);
            if (over) tipLines = ok ? [["+" + n + " " + r.n + " beyond the cap for " + fmt(cost(r, n)) + " TP", "#FFFFFF"]]
                : [[r.t < 0 ? "Wear a " + r.n + " or Rainbow Z-Soul (B)" : !r.capped ? "Raise " + r.n + " to " + fmt(ST.cap) + " first" : "Full: a higher tier goes further", "#FF8080"]];
            y += 16;
        });
        y += 4;
        U.plain(ctx, ST.auto ? "§7Auto: worn souls turn TP into growth (§f" + ST.per + " TP§7 a point) once the stat is capped." : "§7Buy growth here or with the Z-Soul + in the stats screen (V).",
            px + W / 2, y, "#FFFFFF", 0.5);
        U.plain(ctx, "§8Tiers: " + ST.tiers.map(function (t) { return t.n + " " + t.p + "%"; }).join(", "), px + W / 2, y + 11, "#FFFFFF", 0.5);
        var fy = py + H - 30, buttons = [["x" + MULTS[MI], function () { MI = (MI + 1) % MULTS.length; }], ["Accessories", function () { send("accessories"); OPEN = false; }], ["Close", function () { RPG.screen.close(); }]];
        buttons.forEach(function (b, i) {
            var bx = px + W / 2 - 124 + i * 84, over = mx >= bx && my >= fy && mx < bx + 76 && my < fy + 16;
            U.buttonArt(ctx, bx, fy, 76, 16, over);
            ctx.textStyled(b[0], bx + 38, fy + 5, 0.8, over ? "#FFFFA0" : "#FFFFFF", 1, 0.5, FONT, "#000000");
            HIT.push([bx, fy, 76, 16, b[1]]);
        });
        U.drawStatus(ctx, px + W / 2, py + H - 44);
        if (tipLines) U.tooltip(ctx, tipLines, mx, my, "#5080FF");
    }
    function mouse(x, y, btn, action) {
        if (action !== "down" || btn !== 0) return;
        for (var i = 0; i < HIT.length; i++) {
            var h = HIT[i];
            if (x >= h[0] && y >= h[1] && x < h[0] + h[2] && y < h[1] + h[3]) { RPG.sound("dmzpack:pip_menu", 1, 1); h[4](); return false; }
        }
    }
})();
