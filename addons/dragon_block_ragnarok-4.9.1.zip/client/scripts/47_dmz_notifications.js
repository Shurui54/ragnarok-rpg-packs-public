// =====================================================================================
//  DMZ NotificationHUD: the pop-up cards in the top right (techniques learned, quest
//  toasts, party invites...). Port of DragonMine Z's NotificationHUD (GPL-3.0): 200 x 56 panel,
//  title FFE066 / subtitle 9FD8FF / description white / extra A0A6B0, slides in from the screen
//  edge, stays 5 s, at most 5 at once, sorted by priority. Movable in the HUD editor
//  ("Notifications", like DMZ's HudElement.NOTIFICATIONS at top right, x -6, y 6, scale 0.9).
//
//  DMZ_NOTIFY.push({ title, subtitle, description, extra }, priority)   (any field may be null)
//  DMZ_NOTIFY.pin(key, () => content | null, priority) / unpin(key)      (live cards)
//  DMZ_NOTIFY.PRIORITY.LOW / NORMAL / HIGH / TOURNAMENT / TUTORIAL / TRACKED_QUEST
// =====================================================================================
var DMZ_NOTIFY = (function () {
    var WIDTH = 200, HEIGHT = 56, PADDING = 6, GAP = 4, LINE = 10, EXTRA_SCALE = 0.75, DURATION = 5000, MAX_TRANSIENT = 5;
    var PRIORITY = { LOW: 100, NORMAL: 300, HIGH: 600, TOURNAMENT: 900, TUTORIAL: 950, TRACKED_QUEST: 1000 };
    var FONT = "dmzpack:smooth";
    var TITLE = "#FFE066", SUBTITLE = "#9FD8FF", DESCRIPTION = "#FFFFFF", EXTRA = "#A0A6B0";
    var PANEL_FILL = "#141B25", PANEL_FILL_A = 0.78, PANEL_FRAME = "#070A0F", PANEL_FRAME_A = 0.92;
    var PINNED = {}, PIN_KEYS = [], TRANSIENT = [], seq = 0;

    // HudSmoother: exponential approach with tau seconds
    function Smoother(tau, eps) { this.tau = Math.max(0.001, tau); this.eps = eps; this.init = false; this.value = 0; this.last = 0; }
    Smoother.prototype.snap = function (t) { this.init = true; this.value = t; this.last = RPG.nowMs(); };
    Smoother.prototype.update = function (t) {
        var now = RPG.nowMs();
        if (!this.init) { this.snap(t); return this.value; }
        var dt = (now - this.last) / 1000;
        this.last = now;
        if (dt <= 0) return this.value;
        if (dt > 1) { this.value = t; return t; }
        if (dt > 0.25) dt = 0.25;
        this.value += (t - this.value) * (1 - Math.exp(-dt / this.tau));
        if (Math.abs(t - this.value) <= this.eps) this.value = t;
        return this.value;
    };

    function entry(key, content, priority) {
        return { key: key, content: content, priority: priority, seq: seq++, appear: new Smoother(0.16, 0.005), y: new Smoother(0.14, 0.01),
            start: 0, removing: false, present: false, shown: false, last: null };
    }
    function push(content, priority) {
        if (!content) return;
        var e = entry(null, function () { return content; }, priority === undefined ? PRIORITY.NORMAL : priority);
        e.start = RPG.nowMs();
        TRANSIENT.push(e);
        var live = 0;
        for (var i = TRANSIENT.length - 1; i >= 0; i--) {
            if (TRANSIENT[i].removing) continue;
            if (++live > MAX_TRANSIENT) TRANSIENT[i].start = 0;
        }
    }
    function pin(key, supplier, priority) {
        if (PINNED[key]) { PINNED[key].content = supplier; PINNED[key].priority = priority; return; }
        PINNED[key] = entry(key, supplier, priority);
        PIN_KEYS.push(key);
    }
    function unpin(key) { delete PINNED[key]; PIN_KEYS = PIN_KEYS.filter(function (k) { return k !== key; }); }
    function clear() { TRANSIENT = []; PIN_KEYS.forEach(function (k) { PINNED[k].appear.snap(0); PINNED[k].shown = false; }); }

    // ---- layout (NotificationHUD.measure) ----
    var cache = {}, cacheCount = 0;
    function width(ctx, t) { return ctx.textWidthIn(t, FONT); }
    function split(ctx, text, w) {
        var ck = w + "|" + text;
        if (cache[ck]) return cache[ck];
        if (++cacheCount > 200) { cache = {}; cacheCount = 0; }
        var out = [];
        String(text).split("\n").forEach(function (para) {
            var line = "";
            para.split(" ").forEach(function (word) {
                var next = line ? line + " " + word : word;
                if (line && width(ctx, next) > w) { out.push(line); line = word; }
                else line = next;
            });
            out.push(line);
        });
        return (cache[ck] = out);
    }
    function measure(ctx, c) {
        var tw = WIDTH - PADDING * 2, L = { title: [], subtitle: [], description: [], extra: null, height: 0 };
        if (c.title) L.title = split(ctx, c.title, tw);
        if (c.subtitle) L.subtitle = split(ctx, c.subtitle, tw);
        if (c.description) L.description = split(ctx, c.description, tw);
        if (c.extra) L.extra = String(c.extra);
        var h = PADDING + L.title.length * LINE + L.subtitle.length * LINE;
        if (L.description.length) h += (L.title.length || L.subtitle.length ? 1 : 0) + L.description.length * LINE;
        if (L.extra) h += LINE * EXTRA_SCALE + 2;
        L.height = h + PADDING - 2;
        return L;
    }

    // HudRender.panel + dmzText (outlined DMZ font)
    function panel(ctx, w, h, a) {
        ctx.fill(1, 1, w - 2, h - 2, PANEL_FILL, PANEL_FILL_A * a);
        ctx.fill(0, 0, w, 1, PANEL_FRAME, PANEL_FRAME_A * a);
        ctx.fill(0, h - 1, w, 1, PANEL_FRAME, PANEL_FRAME_A * a);
        ctx.fill(0, 1, 1, h - 2, PANEL_FRAME, PANEL_FRAME_A * a);
        ctx.fill(w - 1, 1, 1, h - 2, PANEL_FRAME, PANEL_FRAME_A * a);
    }
    function text(ctx, t, x, y, scale, align, color, a) {
        if (a * 255 <= 3 || !t) return;
        ctx.textStyled(t, x, y, scale, color, a, align, FONT, "#000000");
    }
    function draw(ctx, L, slide, y, a) {
        ctx.push();
        ctx.translate(slide, y);
        panel(ctx, WIDTH, L.height, a);
        var ty = PADDING;
        L.title.forEach(function (l) { text(ctx, l, PADDING, ty, 1, 0, TITLE, a); ty += LINE; });
        L.subtitle.forEach(function (l) { text(ctx, l, PADDING, ty, 1, 0, SUBTITLE, a); ty += LINE; });
        if (L.description.length && (L.title.length || L.subtitle.length)) ty += 1;
        L.description.forEach(function (l) { text(ctx, l, PADDING, ty, 1, 0, DESCRIPTION, a); ty += LINE; });
        if (L.extra) text(ctx, L.extra, WIDTH - PADDING, ty + 2, EXTRA_SCALE, 1, EXTRA, a);
        ctx.pop();
    }
    function ease(t) { t = Math.max(0, Math.min(1, t)); return 1 - (1 - t) * (1 - t); }
    function tr(key, fallback) { return RPG.hasTranslation(key) ? RPG.translate(key) : fallback; }

    function render(ctx) {
        if (!RPG.player.present) return;
        var W = ctx.width, H = ctx.height, unit = Math.max(0.25, H / 360), scale = 0.9 * unit;
        var bw = WIDTH * scale, bh = HEIGHT * scale, bx = W - 6 * unit - bw, by = 6 * unit;
        var editing = ctx.isEditing();
        if (!ctx.group("dmz_notifications", tr("gui.dragonminez.hud_editor.element.notifications", "Notifications"), bx, by, bw, bh)) {
            if (!editing) clear();
            return;
        }
        ctx.push();
        ctx.translate(bx, by);
        ctx.scale(scale, scale);
        if (editing) {
            var cur = 0;
            [{ title: tr("gui.dragonminez.hud_editor.sample.quest_title", "Quest"), subtitle: tr("gui.dragonminez.story.hud.tracked", "Tracked"),
                description: tr("gui.dragonminez.hud_editor.sample.quest_objective", "Objective"), extra: "1:35" },
                { title: "Technique Learned", subtitle: tr("technique.dragonminez.kamehameha", "Kamehame Ha"), description: null, extra: tr("technique.type.wave", "Wave") }]
                .forEach(function (c) { var L = measure(ctx, c); draw(ctx, L, 0, cur, 1); cur += L.height + GAP; });
            ctx.pop();
            ctx.endGroup();
            return;
        }
        var now = RPG.nowMs(), ordered = [];
        PIN_KEYS.forEach(function (k) {
            var e = PINNED[k], c = null;
            try { c = e.content(); } catch (err) { c = null; }
            e.present = !!c; e.last = c;
            if (e.present || e.appear.value > 0.02) ordered.push(e);
        });
        TRANSIENT = TRANSIENT.filter(function (e) {
            if (!e.removing && now - e.start >= DURATION) e.removing = true;
            if (e.removing && e.appear.value <= 0.02 && e.shown) return false;
            e.present = !e.removing;
            e.last = e.content();
            ordered.push(e);
            return true;
        });
        ordered.sort(function (a, b) { return a.priority !== b.priority ? b.priority - a.priority : b.seq - a.seq; });
        var edge = (W - bx) / scale + 8, cursor = 0;
        ordered.forEach(function (e) {
            if (!e.last) return;
            var L = measure(ctx, e.last), target = cursor;
            if (!e.shown) { e.y.snap(target); e.appear.snap(0); e.shown = true; }
            var y = e.y.update(target), a = e.appear.update(e.present ? 1 : 0);
            if (a <= 0.005 && !e.present) return;
            draw(ctx, L, (1 - ease(a)) * edge, y, a);
            cursor += (L.height + GAP) * Math.max(0, Math.min(1, a * 1.5));
        });
        ctx.pop();
        ctx.endGroup();
    }

    RPG.on("load", function () { RPG.hud.onRender(render); });

    return { push: push, pin: pin, unpin: unpin, clear: clear, PRIORITY: PRIORITY, WIDTH: WIDTH, HEIGHT: HEIGHT };
})();
