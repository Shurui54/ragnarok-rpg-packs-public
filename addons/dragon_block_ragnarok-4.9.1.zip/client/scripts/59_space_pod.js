// =====================================================================================
//  The space pod's destination list (SpacePodScreen): pick a planet, Travel.
// =====================================================================================
(function () {
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png", ICONS = "dmzpack:textures/gui/spaceshipicons.png";
    var BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png", FONT = "dmzpack:smooth";
    var ROW = 24, VISIBLE = 7;
    var S = null;          // { list, selected }

    RPG.net.on("dmz_spacepod", function (d) {
        S = { list: d.list || [], selected: -1 };
        RPG.sound("dmzpack:ui_menu_switch", 1, 1);
        var els = [
            { id: "panel", type: "image", anchor: "center", x: -70, y: -106, w: 141, h: 213, texture: MENU_BIG, texW: 256, texH: 256, u: 0, v: 0, uw: 141, vh: 213 },
            { id: "travel", type: "button", anchor: "bottom", x: -40, y: -30, w: 74, h: 20, texture: BUTTONS, texW: 256, texH: 256, u: 0, v: 28, uw: 74, vh: 20,
              hoverU: 0, hoverV: 48, label: RPG.translate("gui.dragonminez.travel"), font: FONT, visible: false, onClick: travel }
        ];
        S.list.forEach(function (dest, i) {
            if (i >= VISIBLE) return;
            els.push({ id: "row" + i, type: "rect", anchor: "center", x: -60, y: -71 + i * ROW, w: 116, h: ROW, color: "#00000000",
                onClick: function () {
                    if (!dest.unlocked || dest.here) return;
                    S.selected = i;
                    RPG.sound("dmzpack:pip_menu", 1, 1);
                } });
        });
        RPG.screen.open({ id: "dmz_spacepod", referenceHeight: DMZ_OPTS.menuRef(), background: "dim", elements: els, onRender: render });
    });

    function travel() {
        if (!S || S.selected < 0) return;
        RPG.net.send("dmz_spacepod_travel", { id: S.list[S.selected].id });
        RPG.sound("dmzpack:ui_nave_takeoff", 1, 1);
        RPG.screen.close();
        S = null;
    }

    function render(ctx) {
        if (!S) return;
        var cx = ctx.width / 2, top = ctx.height / 2 - 106, left = cx - 60;
        ctx.textStyled(RPG.translate("gui.dragonminez.spacepod.title"), cx, top + 18, 1, "#FFD700", 1, 0.5, FONT, "#000000");
        S.list.forEach(function (dest, i) {
            if (i >= VISIBLE) return;
            var y = top + 35 + i * ROW;
            var hover = ctx.mouseX >= left && ctx.mouseX < left + 116 && ctx.mouseY >= y && ctx.mouseY < y + ROW;
            if (dest.unlocked) {
                if (i === S.selected) { ctx.fill(left, y, 116, ROW, "#D4AF37", 0.5); ctx.fill(left, y, 116, 1, "#FFD700", 1); ctx.fill(left, y + ROW - 1, 116, 1, "#FFD700", 1); }
                else if (hover) ctx.fill(left, y, 116, ROW, "#555555", 0.5);
            } else ctx.fill(left, y, 116, ROW, "#000000", 0.19);
            var u = dest.unlocked ? 3 : 20, v = 3 + dest.icon * 14;
            ctx.quad(ICONS, left + 5, y + (ROW - 11) / 2, 11, 11, u / 256, v / 256, (u + 11) / 256, (v + 11) / 256, "#FFFFFF", 1);
            var name = dest.unlocked ? "§l" + RPG.translate("gui.dragonminez.spacepod." + dest.id) : "§l???";
            ctx.textStyled(name + (dest.here ? " §7(here)" : ""), left + 25, y + 8, 1, dest.unlocked ? "#20E0FF" : "#747678", 1, 0, FONT, "#000000");
        });
        RPG.screen.update("travel", { visible: S.selected >= 0 });
    }
})();
