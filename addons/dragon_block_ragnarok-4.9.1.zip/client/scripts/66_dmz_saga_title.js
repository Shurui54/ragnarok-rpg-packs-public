// =====================================================================================
//  DMZ SagaTitleCardHUD: "A New Saga Begins" + the saga name in big gold letters when the first
//  quest of a saga starts (server: 47_dmz_quests.js -> "dmz_saga_title"). Port of DragonMine Z (GPL-3.0):
//  fade in 600 ms, hold 2700 ms, fade out 1200 ms; header x1.3 E8F0FF, title x3 FFD700, at 1/4 height.
//  Movable in the HUD editor ("Saga Title Card").
// =====================================================================================
(function () {
    var FADE_IN = 600, HOLD = 2700, FADE_OUT = 1200, TOTAL = FADE_IN + HOLD + FADE_OUT, FONT = "dmzpack:smooth";
    var card = null;
    function tr(key, fallback) { return RPG.hasTranslation(key) ? RPG.translate(key) : fallback; }

    RPG.net.on("dmz_saga_title", function (d) {
        if (!d || !d.name) return;
        card = { title: tr(d.name, d.label || String(d.name).replace(/^dmz\.saga\./, "").replace(/_/g, " ")), start: RPG.nowMs() };
        RPG.sound("minecraft:ui.toast.challenge_complete", 1, 1);
    });

    function render(ctx) {
        var W = ctx.width, H = ctx.height, editing = ctx.isEditing();
        if (!card && !editing) return;
        var gw = 300, gh = 50, gx = W / 2 - gw / 2, gy = H / 4 - 4;
        if (!ctx.group("dmz_saga_title", "Saga Title Card", gx, gy, gw, gh)) return;
        var a = 1, title = editing && !card ? tr("dmz.saga.saiyan_saga", "Saiyan Saga") : card.title;
        if (card) {
            var t = RPG.nowMs() - card.start;
            if (t >= TOTAL) { card = null; if (!editing) { ctx.endGroup(); return; } }
            else a = t < FADE_IN ? t / FADE_IN : t < FADE_IN + HOLD ? 1 : 1 - (t - FADE_IN - HOLD) / FADE_OUT;
        }
        a = Math.max(0, Math.min(1, a));
        if (a >= 0.05) {
            ctx.textStyled(tr("gui.dragonminez.saga_titlecard.header", "A New Saga Begins"), gx + gw / 2, gy + 4, 1.3, "#E8F0FF", a, 0.5, FONT, null);
            ctx.textStyled(title, gx + gw / 2, gy + 22, 3, "#FFD700", a, 0.5, FONT, null);
        }
        ctx.endGroup();
    }
    RPG.on("load", function () { RPG.hud.onRender(render); });
})();
