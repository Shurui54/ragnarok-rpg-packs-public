// =====================================================================================
//  82_dbr_raids_editor.js - DMZ Ragnarok raid editors (/raid edit)
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0) shuruis_raid_bosses client/gui: RaidHubScreen, RaidListScreen, RaidEditScreen
//  (tabs General / Type / Arena / Scaling / Boss / Rules / Schedule / Messages / Rewards, with DMZR's labels and
//  tooltips), EnemyWave/BossStage/Ally/KiMove/Reward list + edit screens, RandomPoolListScreen, the bounds row
//  (Set via WE / Set manually), RiftListScreen, RiftEditScreen and the tear encounter editor. Drawn in DMZ's
//  menubig / characterbuttons art (82_dbr_raids.js helpers). Data: shared/22_dbr_raids_data.js; the server
//  (scripts/92_dbr_raids.js) checks the rg.raid.edit / rg.raid.rift nodes on every request.
// =====================================================================================
(function () {
    var U = DMZ_UI, D = DBR_RAIDS_DATA, UI = DBR_RAIDS_UI, FONT = U.FONT;
    var BUTTONS = UI.BUTTONS;
    var PW = 380, PH = 290, ROW = 18, LX = -180, CX = -24, CW = 196;

    // =========================================================================================
    //  Form engine: a panel, optional tabs, a scrolled list of rows, footer buttons
    // =========================================================================================
    var F = null;
    function form(spec) {
        F = { title: spec.title, tabs: spec.tabs || null, tab: spec.tab || 0, rows: spec.rows, scroll: 0, footer: spec.footer || [], back: spec.back || null, data: spec.data || null };
        show();
    }
    // a note that wraps takes as many rows as it has lines (spacer rows under it), so it never runs into the next row
    function curRows() {
        var out = [];
        (F.tabs ? F.tabs[F.tab].rows() : F.rows()).forEach(function (r) {
            out.push(r);
            if (r && r.type === "note") for (var k = Math.ceil(U.strip(r.text).length / 62) - 1; k > 0; k--) out.push({ type: "spacer" });
        });
        return out;
    }
    function top() { return F.tabs ? (F.tabs.length > 5 ? -86 : -102) : -110; }
    function visible() { return Math.floor((PH / 2 - 34 - top()) / ROW); }
    function show() {
        if (!F) return;
        SUG_IDS = {};
        var mine = F, els = [], rows = curRows(), vis = visible();
        F.scroll = Math.max(0, Math.min(F.scroll, Math.max(0, rows.length - vis)));
        if (F.tabs) F.tabs.forEach(function (t, i) {
            var perRow = Math.min(5, F.tabs.length), w = Math.floor((PW - 24) / perRow), r = Math.floor(i / 5), c = i % 5;
            els.push(UI.btn("tab" + i, -PW / 2 + 12 + c * w, -118 + r * 16, w - 2, 15, (i === F.tab ? "§e" : "") + t.name, function () { F.tab = i; F.scroll = 0; show(); }));
        });
        var y = top();
        for (var i = 0; i < vis && i + F.scroll < rows.length; i++, y += ROW) rowEls(els, rows[i + F.scroll], i + F.scroll, y);
        if (rows.length > vis) {
            els.push(UI.btn("up", PW / 2 - 18, top(), 12, 12, "▲", function () { F.scroll = Math.max(0, F.scroll - vis + 1); show(); }));
            els.push(UI.btn("down", PW / 2 - 18, top() + vis * ROW - 14, 12, 12, "▼", function () { F.scroll += vis - 1; show(); }));
        }
        var fw = Math.min(110, Math.floor((PW - 24) / Math.max(1, F.footer.length)) - 4), fx = -(F.footer.length * (fw + 4)) / 2;
        F.footer.forEach(function (b, j) { els.push(UI.btn("ft" + j, fx + j * (fw + 4), PH / 2 - 26, fw, 18, b.label, b.run, b.extra)); });
        F.rebuilding = true;
        RPG.screen.open({ id: "dbr_raid_form", referenceHeight: 340, background: "dim", elements: els, onBackground: render,
            onScroll: function (x, yy, d) { if (F !== mine) return; var n = curRows().length, v = visible(); if (n <= v) return; F.scroll = Math.max(0, Math.min(n - v, F.scroll - (d > 0 ? 1 : -1))); show(); },
            onClose: function () { if (F === mine && !F.rebuilding) F = null; } });
        F.rebuilding = false;
    }
    function render(ctx) {
        if (!F) return;
        var cx = ctx.width / 2, cy = ctx.height / 2;
        UI.panel(ctx, cx - PW / 2, cy - PH / 2, PW, PH);
        UI.title(ctx, cx, cy - PH / 2 + 4, F.title);
        var rows = curRows(), vis = visible(), y = cy + top();
        for (var i = 0; i < vis && i + F.scroll < rows.length; i++, y += ROW) {
            var r = rows[i + F.scroll];
            if (r.type === "text" || r.type === "int" || r.type === "num" || r.type === "manual") field(ctx, cx + CX - 2, y, (r.type === "manual" ? 64 : CW) + 4, 16);
            if (r.type === "manual") field(ctx, cx + CX + 68, y, 68, 16);
        }
        U.drawStatus(ctx, cx, cy + PH / 2 - 40);
    }
    function field(ctx, x, y, w, h) {
        function f(sx, sy, sw, sh, dx, dy, dw, dh) { ctx.quad(BUTTONS, dx, dy, dw, dh, sx / 256, sy / 256, (sx + sw) / 256, (sy + sh) / 256, "#FFFFFF", 1); }
        var v = 108;
        f(0, v, 3, 3, x, y, 3, 3); f(3, v, 101, 3, x + 3, y, w - 6, 3); f(104, v, 3, 3, x + w - 3, y, 3, 3);
        f(0, v + 3, 3, 11, x, y + 3, 3, h - 7); f(3, v + 3, 101, 11, x + 3, y + 3, w - 6, h - 7); f(104, v + 3, 3, 11, x + w - 3, y + 3, 3, h - 7);
        f(0, v + 14, 3, 4, x, y + h - 4, 3, 4); f(3, v + 14, 101, 4, x + 3, y + h - 4, w - 6, 4); f(104, v + 14, 3, 4, x + w - 3, y + h - 4, 3, 4);
    }
    function label(els, id, text, x, y, tip, w) {
        var e = { id: id, type: "text", anchor: "center", x: x, y: y, text: text, font: FONT, color: "#FFFFFF", outline: "#000000" };
        if (tip) e.tooltip = tip;
        if (w) e.wrap = w;          // only notes wrap; a row label stays on one line next to its field
        els.push(e);
    }
    /** Shorten to n visible characters, colour codes kept. */
    function cut(s, n) {
        s = String(s || "");
        var out = "", vis = 0;
        for (var i = 0; i < s.length; i++) {
            var c = s.charAt(i);
            if (c === "§" && i + 1 < s.length) { out += c + s.charAt(i + 1); i++; continue; }
            if (vis >= n) return out + "…";
            out += c; vis++;
        }
        return out;
    }
    function str(v) { return v === undefined || v === null ? "" : String(v); }
    function numStr(v) { var n = Number(v) || 0; return n === Math.round(n) ? String(Math.round(n)) : String(n); }
    /** One row's elements. Row types: text int num bool enum pick button note item bounds manual. */
    function rowEls(els, r, idx, y) {
        var id = "r" + idx;
        if (r.type === "spacer") return;
        if (r.type === "note") { label(els, id, "§7" + r.text, LX, y + 4, null, PW - 30); return; }
        if (r.type === "button") { els.push(UI.btn(id, LX + 10, y, PW - 44, 16, r.label, r.run, { tooltip: r.tip, disabled: !!r.disabled })); return; }
        if (r.type === "item") {
            var nx = (r.extra || []).length, room = r.toggle ? 52 : nx ? 34 + nx * 8 : r.edit || r.del ? 44 : 60;
            label(els, id + "l", cut(r.text, room), LX, y + 4, r.tip || (U.strip(r.text).length > room ? r.text : null), 0);
            var bx = PW / 2 - 24 - 92;
            if (r.toggle) { els.push(UI.btn(id + "t", PW / 2 - 70, y, 46, 16, r.toggle.on ? "§aIn" : "§7Out", r.toggle.run)); return; }
            if (r.edit) els.push(UI.btn(id + "e", bx, y, 36, 16, "Edit", r.edit));
            if (r.up) els.push(UI.btn(id + "u", bx + 38, y, 16, 16, "▲", r.up));
            if (r.down) els.push(UI.btn(id + "d", bx + 56, y, 16, 16, "▼", r.down));
            if (r.del) els.push(UI.btn(id + "x", bx + 74, y, 16, 16, "§cX", r.del, { tooltip: "Delete" }));
            (r.extra || []).forEach(function (b, k) { els.push(UI.btn(id + "b" + k, PW / 2 - 24 - (nx - k) * 48, y, 46, 16, b.label, b.run, { tooltip: b.tip })); });
            return;
        }
        label(els, id + "l", r.label, LX, y + 4, r.tip, 0);
        if (r.type === "bool") {
            els.push(UI.btn(id, CX, y, 70, 16, r.get() ? "§a[x] ON" : "§7[ ] OFF", function () { r.set(!r.get()); RPG.sound(r.get() ? "dmzpack:switch_on" : "dmzpack:switch_off", 1, 1); RPG.screen.update(id, { label: r.get() ? "§a[x] ON" : "§7[ ] OFF" }); }, { tooltip: r.tip }));
        } else if (r.type === "enum") {
            els.push(U.dropdown(id, CX - 2, y, CW + 4, 16, r.options.map(function (o) { return { value: o.v, label: o.l }; }), r.get(), function (v) {
                r.set(v); RPG.sound("dmzpack:pip_menu", 1, 1);
                if (r.rebuild) show();
            }, { tooltip: r.tip }));
        } else if (r.type === "pick") {
            // a searchable list filled by the server; custom: a typed id the list does not know can still be used
            var cur = str(r.get()), opts = suggestions(r.kind, id);
            els.push(U.dropdown(id, CX - 2, y, CW + 4, 16, opts, cur, function (v) { r.set(String(v)); }, { tooltip: r.tip, search: true, custom: true, placeholder: "§7(none)", listWidth: 260 }));
        } else if (r.type === "bounds") {
            label(els, id + "v", r.get() ? "§a" + D.regionText(r.get()) : "§c(not set)", CX, y + 4, r.tip, 0);
            els.push(UI.btn(id + "we", PW / 2 - 108, y, 56, 16, "Set via WE", function () { askBounds(r.which, "we"); }, { tooltip: "Use your WorldEdit selection (wand, or //pos1 and //pos2)" }));
            els.push(UI.btn(id + "c", PW / 2 - 50, y, 26, 16, "§cX", function () { r.set(null); show(); }, { tooltip: "Clear" }));
        } else if (r.type === "manual") {
            els.push({ id: id + "a", type: "input", anchor: "center", x: CX, y: y + 3, w: 64, h: 10, value: r.min || "", maxLength: 40, onChange: function (e, v) { r.min = v; }, tooltip: "Min corner: x y z" });
            els.push({ id: id + "b", type: "input", anchor: "center", x: CX + 70, y: y + 3, w: 64, h: 10, value: r.max || "", maxLength: 40, onChange: function (e, v) { r.max = v; }, tooltip: "Max corner: x y z" });
            els.push(UI.btn(id + "s", PW / 2 - 76, y, 52, 16, "Set manually", function () { askBounds(r.which, "manual", r.min, r.max); }, { tooltip: "Two corners in your current dimension (no WorldEdit needed)" }));
        } else {
            var w = CW;
            els.push({ id: id, type: "input", anchor: "center", x: CX + 2, y: y + 3, w: w - 4, h: 10, value: r.type === "int" || r.type === "num" ? numStr(r.get()) : str(r.get()), maxLength: r.max || 256, autofocus: !!r.autofocus,
                tooltip: r.tip, onChange: function (e, v) {
                    if (r.type === "int") { var n = parseInt(v, 10); if (!isNaN(n)) r.set(n); }
                    else if (r.type === "num") { var m = Number(v); if (String(v).trim() !== "" && !isNaN(m)) r.set(m); }
                    else r.set(String(v));
                } });
        }
    }
    function T(type, lbl, tip, get, set, more) { var r = { type: type, label: lbl, tip: tip, get: get, set: set }; for (var k in more || {}) r[k] = more[k]; return r; }
    function fld(obj, key, type, lbl, tip, more) { return T(type, lbl, tip, function () { return obj[key]; }, function (v) { obj[key] = v; }, more); }
    function note(text) { return { type: "note", text: text }; }
    function button(lbl, run, tip, more) { var r = { type: "button", label: lbl, run: run, tip: tip }; for (var k in more || {}) r[k] = more[k]; return r; }

    // ---- bounds (SetBoundsPacket / BoundsResultPacket) ----
    var BOUNDS_CB = null;
    function askBounds(which, mode, min, max) {
        BOUNDS_CB = which;
        var split = function (s) { return String(s || "").trim().split(/[\s,]+/).filter(function (x) { return x; }); };
        RPG.net.send("dbr_raid_bounds", { which: which, mode: mode, min: split(min), max: split(max) });
    }
    RPG.net.on("dbr_raid_bounds_result", function (d) {
        if (!d || !EDIT || BOUNDS_CB !== d.which) return;
        EDIT.def[d.which === "playerspawn" ? "playerSpawn" : "arena"] = d.region || null;
        U.showStatus(d.region ? "Bounds set: " + D.regionText(d.region) : "Bounds cleared", "#55FF55");
        show();
    });

    // ---- pick lists (DmzDropdown's searchable list, filled by the server once per kind) ----
    var SUG = {}, SUG_WANTED = {}, SUG_IDS = {};
    function sugOptions(kind) {
        var list = SUG[kind] || [], out = [{ value: "", label: "§7(none)" }];
        list.forEach(function (o) { out.push({ value: o.id, label: o.label && o.label !== o.id ? "§f" + o.label + " §8" + o.id : "§f" + o.id }); });
        return out;
    }
    /** The options for a pick row now (asks the server the first time); the row is refreshed when they arrive. */
    function suggestions(kind, elId) {
        (SUG_IDS[kind] = SUG_IDS[kind] || []).push(elId);
        if (!SUG[kind] && !SUG_WANTED[kind]) { SUG_WANTED[kind] = true; RPG.net.send("dbr_raid_suggest", { kind: kind, q: "", all: true }); }
        return sugOptions(kind);
    }
    RPG.net.on("dbr_raid_suggestions", function (d) {
        if (!d || !d.kind || String(d.q || "") !== "") return;
        SUG[d.kind] = d.list || [];
        SUG_WANTED[d.kind] = false;
        var ids = SUG_IDS[d.kind] || [], opts = sugOptions(d.kind);
        SUG_IDS[d.kind] = [];
        if (RPG.screen.getOpen() === "dbr_raid_form") ids.forEach(function (id) { if (RPG.screen.get(id)) { RPG.screen.update(id, { options: opts }); SUG_IDS[d.kind].push(id); } });
    });

    // =========================================================================================
    //  Hub, raid list
    // =========================================================================================
    RPG.net.on("dbr_raid_open_hub", function () { hub(); });
    function hub() {
        form({ title: "Shurui's Raid Bosses", rows: function () {
            return [note("Editor Menu"),
                button("Raids", function () { RPG.net.send("dbr_raid_req", { what: "list" }); }, "Every configured raid boss: arena, boss, scaling, schedule, rewards"),
                button("Dimensional Tears", function () { RPG.net.send("dbr_raid_req", { what: "rift", op: "list" }); }, "Rifts that open in the world, and the encounter each one leads to")];
        }, footer: [{ label: "Close", run: function () { RPG.screen.close(); } }] });
    }
    var STATES = ["§7Idle", "§aSign-ups", "§eStarting", "§cIn progress", "§7Finishing"];
    var CONFIRM = null;
    RPG.net.on("dbr_raid_open_list", function (d) { raidList((d && d.rows) || []); });
    function raidList(list) {
        form({ title: "Raid Bosses", rows: function () {
            var rows = [note("Edit opens a raid's settings, Signups opens sign-ups, Delete removes it. §a[ready]§7 = an arena is set; §c[no arena]§7 = set one first.")];
            list.forEach(function (r) {
                rows.push({ type: "item", text: "§f" + r.name.replace(/&([0-9a-fk-or])/gi, "§$1") + " §7(" + r.id + ")" + (r.ready ? " §a[ready]" : " §c[no arena]") + " " + (STATES[r.state] || ""),
                    tip: D.TYPE_LABELS[r.type] + (r.signups ? " · " + r.signups + " signed up" : ""), small: true,
                    extra: [{ label: "Edit", run: function () { RPG.net.send("dbr_raid_req", { what: "edit", id: r.id }); } },
                        { label: "Copy", run: function () { RPG.net.send("dbr_raid_req", { what: "copy", id: r.id }); } },
                        { label: r.state === 1 ? "Start" : r.state === 0 ? "Signups" : "§cCancel", run: function () { RPG.net.send("dbr_raid_req", { what: r.state === 1 ? "start" : r.state === 0 ? "open" : "cancel", id: r.id }); }, tip: "Open sign-ups / force start / cancel" },
                        { label: CONFIRM === r.id ? "§c§lSure?" : "§cDelete", run: function () { if (CONFIRM === r.id) { CONFIRM = null; RPG.net.send("dbr_raid_req", { what: "delete", id: r.id }); } else { CONFIRM = r.id; show(); } } }] });
            });
            return rows;
        }, footer: [{ label: "New Raid", run: function () { RPG.net.send("dbr_raid_req", { what: "new", name: "New Raid" }); } }, { label: "Menu", run: hub }, { label: "Close", run: function () { RPG.screen.close(); } }] });
    }

    // =========================================================================================
    //  RaidEditScreen
    // =========================================================================================
    var EDIT = null;     // { def, target, riftId, pool, tab }
    RPG.net.on("dbr_raid_open_editor", function (d) {
        if (!d || !d.def) return;
        EDIT = { def: D.normalize(d.def), target: d.target || "raid", riftId: d.riftId || "", pool: d.pool || [] };
        raidEditor(0);
    });
    function AI(v) { return [{ v: 0, l: "(none)" }, { v: 1, l: "1 Simple" }, { v: 2, l: "2 Tactical" }, { v: 3, l: "3 Advanced" }]; }
    function raidEditor(tab) {
        var d = EDIT.def, rift = EDIT.target === "rift";
        var tabs = [
            { name: "General", rows: function () {
                var r = [fld(d, "name", "text", "Display Name", "The raid's display name, used in announcements, the sign-up GUI, the NPC name, and in commands (/raid join <name>). Supports & colour codes.")];
                if (!rift) r.push(fld(d, "npcEntityType", "pick", "Host Entity", "Which entity is used as the sign-up NPC. Right-clicking it opens sign-up. Ragnarok NPC characters are listed as rgnpc#name.", { kind: "entity" }),
                    fld(d, "npcModelId", "pick", "Host Model", "Which ragnarok NPC character it looks like, when the entity above is dmz_ragnarok:rgnpc. Leave blank for any other entity.", { kind: "rgmodel" }),
                    fld(d, "npcName", "text", "NPC Name", "The name shown above the sign-up NPC's head."));
                r.push(fld(d, "bossEntityType", "pick", "Boss Entity", "Which entity is spawned as the raid boss. Any living entity works (DMZ saga enemies, warden, wither...). Ragnarok NPC characters are listed as rgnpc#name.", { kind: "entity" }),
                    fld(d, "bossModelId", "pick", "Boss Model", "Which ragnarok NPC character the boss looks like, when the entity above is dmz_ragnarok:rgnpc.", { kind: "rgmodel" }),
                    fld(d, "bossName", "text", "Boss Name", "Display name shown above the boss and on its raid bar. Supports & colour codes."));
                if (!rift) r.push(fld(d, "category", "text", "Category", "The dropdown group this raid appears under in the raid-NPC browser (e.g. 'Saiyan Sagas'). Supports & colour codes."),
                    fld(d, "showInNpcMenu", "bool", "Show in NPC Menu", "If OFF, this raid is hidden from the NPC browser (useful for Soul-only or template raids)."),
                    fld(d, "eventOnly", "bool", "Event Only", "If ON, this raid runs only while a timed event lists it, and is otherwise hidden and never scheduled. (DBR has no timed-event engine yet, so an event-only raid never runs.)"),
                    button("Random raid pool (" + d.randomPool.length + ")", poolEditor, "Pick raids this one may roll. With any selected, this raid stops running its own content and instead spawns a random pooled raid in THIS arena."));
                return r;
            } },
            { name: "Type", rows: function () {
                var r = [T("enum", "Raid Type", "Standard = one scaled boss. Parallel Quest = waves of assorted enemies scored by damage AND kills (MVP). Boss Rush = a sequence of bosses spawned one after another.",
                    function () { return d.raidType; }, function (v) { d.raidType = v; }, { options: D.TYPES.map(function (t) { return { v: t, l: D.TYPE_LABELS[t] }; }), rebuild: true })];
                if (d.raidType === "PARALLEL_QUEST") r.push(button("Enemies (" + d.enemies.length + ")", function () { tokenList("Parallel Quest Enemies", d.enemies, WAVE, function () { raidEditor(1); }); }),
                    fld(d, "mvpKillWeight", "num", "MVP Kill Weight", "MVP score = total damage + this weight x kills. Raise it to reward kills more than raw damage."),
                    note("Everyone who dealt damage or scored a kill is ranked; the MVP gets the Top reward."));
                else if (d.raidType === "BOSS_RUSH") r.push(button("Boss Stages (" + d.rushStages.length + ")", function () { tokenList("Boss Rush Stages", d.rushStages, STAGE, function () { raidEditor(1); }); }),
                    note("Bosses spawn in order; each stage has its own pre-spawn delay. Rewards are given once the final boss falls."));
                else r.push(note("Configure the single boss under the General, Scaling and Boss tabs."));
                r.push(button("Allies (" + d.allies.length + ")", function () { tokenList("Allies", d.allies, ALLY, function () { raidEditor(1); }); }), note("NPCs that fight on the players' side from the start of the raid."));
                return r;
            } },
            { name: "Arena", rows: function () {
                var a = [T("bounds", "Arena", "Players are teleported inside this region; the boss spawns at its centre.", function () { return d.arena; }, function (v) { d.arena = v; }, { which: "arena" }),
                    { type: "manual", label: "", which: "arena" },
                    T("bounds", "Player spawn area", "Where players are placed when they enter this raid. Unlike the arena this keeps the height you selected. Leave unset to scatter players across the arena.", function () { return d.playerSpawn; }, function (v) { d.playerSpawn = v; }, { which: "playerspawn" }),
                    { type: "manual", label: "", which: "playerspawn" },
                    note("Two ways to set bounds: make a WorldEdit selection and press \"Set via WE\", OR type the two corner coordinates (in your current dimension) and press \"Set manually\"."),
                    note("PvP inside the arena follows the 'PvP in Arena' rule (Rules tab).")];
                return a;
            } },
            { name: "Scaling", rows: function () {
                return [fld(d, "baseHealth", "num", "Base Health", "The boss's max health for a single participant."),
                    fld(d, "healthPerPlayer", "num", "Health Per Player", "Extra max health added per additional participant. Total = base + perPlayer x (participants - 1)."),
                    fld(d, "maxHealthCap", "num", "Max Health Cap (0=none)", "Hard cap on the scaled max health. 0 means no cap."),
                    fld(d, "scaleDamage", "bool", "Scale Attack Damage", "If ON, the boss also hits harder with more participants."),
                    fld(d, "damagePerPlayer", "num", "Attack Damage Per Player", "Extra attack damage added per additional participant (only used when 'Scale Attack Damage' is ON)."),
                    fld(d, "maxDamagePercentPerHit", "num", "Max Damage Per Hit (%)", "The most a single hit may take off this boss, as a percent of its max health. 2.5 means the boss always takes at least 40 landed hits. 0 = no ceiling. This limits the HIT, not the player.")];
            } },
            { name: "Boss", rows: function () {
                return [note("DragonMine Z saga enemies only for ki and AI. 0 / (none) keeps the entity's own value."),
                    fld(d, "parallelBoss", "bool", "Boss Finale (Parallel)", "PARALLEL QUEST only: after the last enemy wave is cleared, spawn this boss as the finale."),
                    fld(d, "baseMeleeDamage", "num", "Melee Damage (0=default)", "The boss's melee attack-damage attribute. 0 keeps the entity default."),
                    fld(d, "baseDefense", "num", "Defense (0=none)", "Damage-resistance stat applied to hits on raid enemies (higher = tankier). 0 = no mitigation."),
                    fld(d, "kiBlastDamage", "num", "Ki Damage (0=default)", "Damage dealt by the boss's ki attacks. 0 keeps the entity default."),
                    fld(d, "moveSpeed", "num", "Move Speed (0=default)", "The boss's movement-speed attribute. 0 keeps the entity default."),
                    T("enum", "AI Tier", "Combat AI sophistication (DragonMine Z AI tier). Simple < Tactical < Advanced. (none) keeps the default.", function () { return d.aiTier; }, function (v) { d.aiTier = v; }, { options: AI() }),
                    button("Ki Moves (" + d.kiMoves.length + ")", function () { tokenList("Boss Ki Moves", d.kiMoves, KI, function () { raidEditor(4); }); }),
                    note("Empty = the boss keeps its own default ki moves."),
                    fld(d, "useDefaultTransform", "bool", "Use DMZ Default Transformations", "When ON the boss transforms via DragonMine Z's own chain (e.g. Frieza's forms).")];
            } },
            { name: "Rules", rows: function () {
                var r = [];
                if (!rift) r.push(fld(d, "signupMinutes", "int", "Sign-up Minutes", "How long sign-ups stay open before an auto-scheduled raid begins."),
                    fld(d, "signupReminderSeconds", "int", "Reminder Interval (s, 0=off)", "Repeat the sign-up announcement every N seconds while sign-ups are open. 0 = announce only once."),
                    fld(d, "minParticipants", "int", "Min Participants", "If fewer than this many players sign up, the raid is cancelled instead of starting."),
                    fld(d, "maxParticipants", "int", "Max Participants (0=unlimited)", "Cap on the number of participants. 0 means no limit."),
                    fld(d, "requireCharacter", "bool", "Require DMZ Character", "If ON, a player must have created a DragonMine Z character before they can sign up."));
                r.push(fld(d, "healOnStart", "bool", "Heal On Start", "Fully restore every participant's health, ki and stamina when the fight begins."));
                if (!rift) r.push(fld(d, "pvpInArena", "bool", "PvP in Arena", "Allow players to damage each other inside the arena. Normally OFF."),
                    fld(d, "preventReentry", "bool", "Prevent Re-Entry", "If ON, any player who is not an active participant of the running raid is bounced out of the arena (eliminated fighters stay locked out too)."));
                r.push(fld(d, "vanillaDrops", "bool", "Vanilla Drops", "Whether raid enemies still drop their own loot on death. OFF (default) = rewards come from the reward table."));
                if (!rift) r.push(fld(d, "useTitles", "bool", "On-screen Title Announcements", "Also show big on-screen titles for major announcements."));
                r.push(fld(d, "countdownSeconds", "int", "Countdown Seconds", "Countdown after participants are teleported in, before the boss spawns."),
                    fld(d, "fightTimeLimit", "int", "Fight Time Limit (s, 0=none)", "If the boss isn't killed within this time, it despawns and nobody is rewarded. 0 = no limit."));
                return r;
            } },
            { name: "Schedule", rows: function () {
                return [fld(d, "scheduleEnabled", "bool", "Auto-schedule", "If ON, sign-ups open automatically at the time below. If OFF, run manually with /raid open <name>."),
                    fld(d, "scheduleIntervalMinutes", "int", "Repeat Every (min, 0=off)", "If > 0, sign-ups also auto-open every N minutes (anchored at midnight) on cadence-matching days."),
                    T("text", "Daily Times (HH:MM, comma)", "A comma-separated list of 24h HH:MM times, e.g. 09:00, 14:30, 20:00. Overrides the single Hour/Minute below.",
                        function () { return d.scheduleTimes.join(", "); }, function (v) { d.scheduleTimes = String(v).split(",").map(function (x) { return x.trim(); }).filter(function (x) { return /^\d{1,2}:\d{1,2}$/.test(x); }); }),
                    fld(d, "scheduleHour", "int", "Hour (0-23)", "Time of day (server local, 24h) that sign-ups auto-open."),
                    fld(d, "scheduleMinute", "int", "Minute (0-59)", "Minute of the hour for the auto-open time."),
                    fld(d, "scheduleDayOfWeek", "int", "Day of Week (0=ignore, 1-7)", "Weekly cadence: 1=Monday .. 7=Sunday. 0 ignores this and (unless Day of Month is set) runs DAILY."),
                    fld(d, "scheduleDayOfMonth", "int", "Day of Month (0=ignore, 1-28)", "Monthly cadence: day of the month to run. 0 falls back to the weekly or daily schedule.")];
            } },
            { name: "Messages", rows: function () {
                var r = [];
                if (!rift) r.push(fld(d, "announceSound", "text", "Announce Sound", "Sound played to everyone on major announcements (a sound id; empty to disable)."));
                r.push(fld(d, "bossMusic", "text", "Boss Music", "Sound looped for fighters inside this encounter, on the music channel (e.g. dmzpack:worldboss_music.janemba). Empty = no music."),
                    fld(d, "spawnOnObsidian", "bool", "Seat Boss On Block", "When ON, the boss spawns seated on the chosen block inside the arena (nearest to the centre) instead of the arena centre."),
                    fld(d, "spawnAnchorBlock", "text", "Seat Block Id", "Block the boss is seated on when the option above is ON. Default minecraft:obsidian."));
                if (!rift) r.push(fld(d, "msgSignupOpen", "text", "Msg: Sign-ups Open", "Chat message when sign-ups open. Placeholders: {name} {id} {npc} {boss}. Use & colour codes."),
                    fld(d, "msgStarting", "text", "Msg: Starting", "Message when the raid starts. Placeholders: {name} {count} {boss}."),
                    fld(d, "msgBossSpawn", "text", "Msg: Boss Spawn", "Announced when the boss spawns. Placeholders: {name} {boss} {health}."),
                    fld(d, "msgVictory", "text", "Msg: Victory", "Announced when the boss is defeated. Placeholders: {name} {boss} {top} {top_percent}."),
                    fld(d, "msgTimeout", "text", "Msg: Timeout", "Announced when the fight times out. Placeholders: {name} {boss}."));
                return r;
            } },
            { name: "Rewards", rows: function () {
                var r = [button("Participant Rewards (" + d.participantRewards.length + ")", function () { tokenList("Participant Rewards", d.participantRewards, REWARD, function () { raidEditor(rift ? 7 : 8); }); })];
                if (!rift) r.push(button("Top Damage Rewards: #1 (" + d.topRewards.length + ")", function () { tokenList("Top Damage Rewards", d.topRewards, REWARD, function () { raidEditor(8); }); }),
                    button("Runner-up Rewards: #2-4 (" + d.runnerUpRewards.length + ")", function () { tokenList("Runner-up Rewards (2-4)", d.runnerUpRewards, REWARD, function () { raidEditor(8); }); }),
                    note("Top = #1 (MVP in Parallel Quests); Runner-up = ranks #2-4; Participant = everyone who dealt damage or scored a kill."));
                else r.push(note("Handed to the fighter on a win. A tear has one fighter, so there is no top or runner up."));
                r.push(note("Tokens: item: skill: form: tp: command: message:. Placeholders %player% %rank% %damage_percent% %kills%. Any reward can carry a chance (a random custom drop)."));
                return r;
            } }
        ];
        if (rift) tabs = tabs.filter(function (t) { return t.name !== "Arena" && t.name !== "Schedule"; });
        form({ title: rift ? "Tear Encounter" : "Edit Raid: " + U.strip(d.name), tabs: tabs, tab: Math.min(tab || 0, tabs.length - 1), footer: [
            { label: "Save", run: function () { RPG.net.send("dbr_raid_save", { def: EDIT.def, target: EDIT.target, riftId: EDIT.riftId }); } },
            { label: "Back", run: function () { if (rift) RPG.net.send("dbr_raid_req", { what: "rift", op: "edit", id: EDIT.riftId }); else RPG.net.send("dbr_raid_req", { what: "list" }); } }] });
    }

    // ---- RandomPoolListScreen ----
    function poolEditor() {
        var d = EDIT.def, tab = F ? F.tab : 0;
        form({ title: "Random Raid Pool", rows: function () {
            var rows = [note("Raids this one may roll. Any raid type can be pooled; the drawn raid runs in this raid's arena.")];
            EDIT.pool.forEach(function (o) {
                if (o.id === d.id) { rows.push({ type: "item", text: "§7" + o.name.replace(/&([0-9a-fk-or])/gi, "§$1") + " §8(" + o.id + ") §7Self" }); return; }
                var on = d.randomPool.indexOf(o.id) >= 0;
                rows.push({ type: "item", text: "§f" + o.name.replace(/&([0-9a-fk-or])/gi, "§$1") + " §8(" + o.id + ") §7" + D.TYPE_LABELS[o.type],
                    toggle: { on: on, run: function () { var i = d.randomPool.indexOf(o.id); if (i >= 0) d.randomPool.splice(i, 1); else d.randomPool.push(o.id); show(); } } });
            });
            return rows;
        }, footer: [{ label: "Back", run: function () { raidEditor(tab); } }] });
    }

    // ---- token list editors (EnemyWave / BossStage / Ally / KiMove / Reward) ----
    var WAVE = { add: "+ Add Enemy", parse: D.wave, token: D.waveToken, summary: D.waveSummary, title: "Edit Enemy", rows: function (o) {
        return [fld(o, "entityType", "pick", "Entity", "Which entity to spawn. Ragnarok NPC characters are listed as rgnpc#name.", { kind: "entity" }),
            fld(o, "rgModelId", "pick", "Ragnarok NPC", "Which ragnarok NPC character these enemies look like, when the entity is dmz_ragnarok:rgnpc.", { kind: "rgmodel" }),
            fld(o, "count", "int", "Amount", "How many copies of this entity spawn."),
            fld(o, "wave", "int", "Wave", "Which sequential wave this enemy belongs to. Wave 1 spawns first; wave 2 once wave 1 is cleared, and so on, then the optional boss finale."),
            fld(o, "health", "num", "Health", "Max health per enemy. 0 keeps the entity's own default health."),
            fld(o, "meleeDamage", "num", "Melee Damage", "Melee attack damage per enemy. 0 falls back to the raid's melee, then the entity default."),
            fld(o, "kiPower", "num", "Ki Damage", "Ki blast damage per enemy (DMZ saga entities). 0 falls back to the raid's ki damage."),
            fld(o, "defense", "num", "Defense", "Damage resistance per enemy. 0 falls back to the raid's defense, then no mitigation.")];
    } };
    var ALLY = { add: "+ Add Ally", parse: D.ally, token: D.allyToken, summary: D.allySummary, title: "Edit Ally", rows: function (o) {
        return [fld(o, "entityType", "pick", "Entity", "What this ally is. Ragnarok characters each appear as their own row.", { kind: "entity" }),
            fld(o, "rgModelId", "pick", "Ragnarok NPC", "Which ragnarok NPC character it looks like, when the entity is dmz_ragnarok:rgnpc.", { kind: "rgmodel" }),
            fld(o, "name", "text", "Name", "Shown over the ally's head. Blank uses the entity's own name."),
            fld(o, "count", "int", "Amount", "How many of this ally spawn."),
            fld(o, "health", "num", "Health", "0 keeps the entity's own max health."),
            fld(o, "meleeDamage", "num", "Melee Damage", "0 falls back to the raid's melee damage, then the entity default."),
            fld(o, "kiPower", "num", "Ki Power", "0 falls back to the raid's ki power, then the entity default."),
            fld(o, "defense", "num", "Defense", "0 falls back to the raid's base defense (0 there is no mitigation)."),
            button("Ki Moves (" + o.kiMoves.length + ")", function () { var back = F; tokenList("Ally Ki Moves", o.kiMoves, KI, function () { F = back; show(); }); }, "This ally's OWN ki loadout (empty = none, never the boss's).")];
    } };
    var STAGE = { add: "+ Add Boss", parse: D.stage, token: D.stageToken, summary: function (s) { return D.stageSummary(s); }, title: "Edit Boss Stage", rows: function (o) {
        return [fld(o, "entityType", "pick", "Entity", "Which entity this stage spawns. Ragnarok NPC characters are listed as rgnpc#name.", { kind: "entity" }),
            fld(o, "rgModelId", "pick", "Ragnarok NPC", "Which ragnarok NPC character this stage's boss looks like, when the entity is dmz_ragnarok:rgnpc.", { kind: "rgmodel" }),
            fld(o, "bossName", "text", "Boss Name", "Display name over this boss. Supports & colour codes."),
            fld(o, "health", "num", "Health (0=scaled)", "Max health for this boss. 0 uses the raid's participant-scaled base health."),
            fld(o, "meleeDamage", "num", "Melee Damage", "Melee attack damage for this boss. 0 falls back to the raid's melee."),
            fld(o, "kiPower", "num", "Ki Damage", "Ki blast damage for this boss (DMZ saga bosses). 0 falls back to the raid's ki damage."),
            fld(o, "defense", "num", "Defense", "Damage resistance. 0 falls back to the raid's defense."),
            fld(o, "delaySeconds", "int", "Delay Before (s)", "Seconds to wait after the previous boss dies before this one spawns."),
            button("Ki Moves (" + o.kiMoves.length + ")", function () { var back = F; tokenList("Stage Ki Moves", o.kiMoves, KI, function () { F = back; show(); }); }),
            button("Stage Allies (" + o.allies.length + ")", function () { var back = F; tokenList("Stage Allies", o.allies, ALLY, function () { F = back; show(); }); }, "Allies spawned when this stage begins. Allies from earlier stages fight on."),
            fld(o, "swapSides", "bool", "Swap Sides", "Everyone alive changes sides as this stage begins: allies turn on the players, enemies join them. Applied before this stage's own boss and allies arrive.")];
    } };
    var KI = { add: "+ Add Ki Move", parse: D.ki, token: D.kiToken, summary: D.kiSummary, title: "Edit Ki Move", rows: function (o) {
        return [T("enum", "Move", "Which ki attack is fired (DragonMine Z saga ki skills).", function () { return o.type; }, function (v) { o.type = v; }, { options: D.KI_TYPES.map(function (t) { return { v: t, l: t }; }) }),
            fld(o, "cooldown", "int", "Cooldown", "Ticks between uses of this move (20 ticks = 1 second). Minimum 10."),
            fld(o, "size", "num", "Size", "Projectile / effect scale multiplier. 1.0 is the normal size.")];
    } };
    var REWARD = { add: "+ Add Reward", parse: D.reward, token: D.rewardToken, summary: D.rewardSummary, title: "Edit Reward", rows: function (o) {
        var r = [T("enum", "Type", "What this reward does. The fields below change to match the selected type. Command/message support %player% %damage% %damage_percent% %rank% %boss% %total_damage%.",
            function () { return o.type; }, function (v) { o.type = v; }, { options: D.REWARD_TYPES.map(function (t) { return { v: t, l: t }; }), rebuild: true })];
        if (o.type === "ITEM") r.push(fld(o, "item", "text", "Item", "An item id (minecraft:diamond) or a DBR item name (senzu_bean). Z-Souls: z_soul_<vitality|stamina|strength|ki_power|strike_power|energy|rainbow>_<bronze|silver|gold|prismatic>."), fld(o, "count", "int", "Count", "How many."));
        else if (o.type === "SKILL") r.push(fld(o, "skill", "pick", "Skill", "A DragonMine Z skill or technique id.", { kind: "skill" }), fld(o, "level", "int", "Levels", "Levels to add."));
        else if (o.type === "TP") r.push(fld(o, "tp", "text", "TP amount", "DragonMine Z training points to grant."));
        else if (o.type === "MESSAGE") r.push(fld(o, "message", "text", "Message", "A coloured chat message (& codes and placeholders)."));
        else r.push(fld(o, "command", "text", "Command", "Run by the server console, without the slash. Placeholders are filled per player."));
        r.push(fld(o, "chance", "num", "Chance % (0=always)", "Roll 0-100: the reward is given only on success (a random custom drop). 0 or 100 = always."));
        return r;
    } };
    function tokenList(title, arr, kind, back) {
        form({ title: title, rows: function () {
            var rows = [];
            arr.forEach(function (tok, i) {
                var o = kind.parse(tok);
                rows.push({ type: "item", text: (kind === STAGE ? "§8#" + (i + 1) + " " : "") + kind.summary(o),
                    edit: function () { itemEditor(kind, kind.parse(arr[i]), function (n) { arr[i] = kind.token(n); }, function () { tokenList(title, arr, kind, back); }); },
                    up: i > 0 ? function () { var t = arr[i - 1]; arr[i - 1] = arr[i]; arr[i] = t; show(); } : null,
                    down: i < arr.length - 1 ? function () { var t = arr[i + 1]; arr[i + 1] = arr[i]; arr[i] = t; show(); } : null,
                    del: function () { arr.splice(i, 1); show(); } });
            });
            if (!arr.length) rows.push(note("(none)"));
            rows.push(button(kind.add, function () { var o = kind.parse(""); itemEditor(kind, o, function (n) { arr.push(kind.token(n)); }, function () { tokenList(title, arr, kind, back); }); }));
            return rows;
        }, footer: [{ label: "Back", run: back }] });
    }
    function itemEditor(kind, obj, commit, back) {
        form({ title: kind.title, rows: function () { return kind.rows(obj); },
            footer: [{ label: "Done", run: function () { commit(obj); back(); } }, { label: "Cancel", run: back }] });
    }

    // =========================================================================================
    //  Rifts: RiftListScreen / RiftEditScreen
    // =========================================================================================
    RPG.net.on("dbr_rift_open_list", function (d) { riftList((d && d.rows) || []); });
    function riftList(list) {
        form({ title: "Dimensional Tears", rows: function () {
            var rows = [note("A rift is a kind of tear: where it opens, how often, and which raid is on the other side.")];
            list.forEach(function (r) {
                var status = !r.ok ? "§cno raid" : !r.enabled ? "§7disabled" : r.running ? "§cfighting" : r.open ? "§dopen" : r.next >= 0 ? "§anext " + Math.ceil(r.next / 60) + "m" : "§aready";
                rows.push({ type: "item", small: true, text: "§f" + r.name.replace(/&([0-9a-fk-or])/gi, "§$1") + " §7(" + r.id + ") " + status, tip: "Leads to: " + (r.raid || "-"),
                    extra: [{ label: "Edit", run: function () { RPG.net.send("dbr_raid_req", { what: "rift", op: "edit", id: r.id }); } },
                        { label: "Open", run: function () { RPG.net.send("dbr_raid_req", { what: "rift", op: "open", id: r.id }); }, tip: "Open a tear right next to you now" },
                        { label: CONFIRM === "rift:" + r.id ? "§c§lSure?" : "§cDelete", run: function () { if (CONFIRM === "rift:" + r.id) { CONFIRM = null; RPG.net.send("dbr_raid_req", { what: "rift", op: "delete", id: r.id }); } else { CONFIRM = "rift:" + r.id; show(); } } }] });
            });
            return rows;
        }, footer: [{ label: "New Rift", run: function () { RPG.net.send("dbr_raid_req", { what: "rift", op: "new", name: "tear" }); } }, { label: "Menu", run: hub }, { label: "Close", run: function () { RPG.screen.close(); } }] });
    }
    RPG.net.on("dbr_rift_open_editor", function (d) { if (d && d.rift) riftEditor(D.normalizeRift(d.rift), d.raids || []); });
    function riftEditor(r, raids) {
        var raidOpts = [{ v: "", l: "(none)" }].concat(raids.map(function (o) { return { v: o.id, l: U.strip(o.name) + " (" + o.id + ")" }; }));
        form({ title: "Edit Rift", tabs: [
            { name: "General", rows: function () {
                return [fld(r, "name", "text", "Name", "Operator name for this rift, and the fallback label on the tear. Supports & colour codes."),
                    fld(r, "tearLabel", "text", "Tear Label", "Drawn above the tear so players can see what it leads to. Blank uses the name."),
                    fld(r, "enabled", "bool", "Enabled", "A disabled rift keeps its settings but never opens a tear."),
                    fld(r, "eventOnly", "bool", "Event Only", "If ON, this rift opens tears only while a timed event lists it (DBR has no timed-event engine yet, so it never opens)."),
                    T("enum", "Portal Look", "The tear's appearance. Default is the normal swirl; Halloween is an orange and purple jack-o'-lantern portal with ghost particles.",
                        function () { return r.look || "default"; }, function (v) { r.look = v === "default" ? "" : v; }, { options: D.LOOKS.map(function (l) { return { v: l, l: l.charAt(0).toUpperCase() + l.substring(1) }; }) }),
                    T("enum", "Raid", "The raid fought on the other side, when the rift has no encounter of its own.", function () { return r.raidId; }, function (v) { r.raidId = v; }, { options: raidOpts }),
                    button("Encounter: " + (r.encounter ? U.strip(r.encounter.bossName) : "not set"), function () { RPG.net.send("dbr_raid_req", { what: "rift", op: "encounter", id: r.id }); },
                        "The fight on the other side: boss, fight type, stages, friendlies, ki moves and rewards. The arena is supplied by the tear. Save the rift first if you changed it."),
                    button("Drop own encounter", function () { RPG.net.send("dbr_raid_req", { what: "rift", op: "dropencounter", id: r.id }); }, "Go back to naming a raid", { disabled: !r.encounter }),
                    T("enum", "Arena Theme", "What the arena floor is made of.", function () { return r.arenaTheme; }, function (v) { r.arenaTheme = v; }, { options: D.THEMES.map(function (t) { return { v: t, l: t }; }) })];
            } },
            { name: "Timing", rows: function () {
                return [fld(r, "minSpawnMinutes", "int", "Min Minutes", "Shortest wait between tears of this rift. The actual wait is rolled between min and max."),
                    fld(r, "maxSpawnMinutes", "int", "Max Minutes", "Longest wait between tears. Below the minimum, it is treated as the minimum."),
                    fld(r, "tearLifetimeSeconds", "int", "Open Seconds", "How long an unclaimed tear stays in the world before it closes on its own.")];
            } },
            { name: "Regions", rows: function () {
                return [T("text", "Dimensions", "Where tears may open: dimension ids, comma separated (overworld, namek, otherworld, minecraft:the_nether...). Empty = every dimension a player is in.",
                    function () { return r.regions.join(", "); }, function (v) { r.regions = String(v).split(",").map(function (x) { return x.trim(); }).filter(function (x) { return x; }); }),
                    note("A tear opens 24-64 blocks from a random player standing in an allowed dimension, on dry ground.")];
            } },
            { name: "Messages", rows: function () {
                return [fld(r, "msgOpened", "text", "Opened", "Broadcast when a tear opens. {name} and {region} are substituted. Blank sends nothing."),
                    fld(r, "msgVictory", "text", "Victory", "Broadcast when the fighter wins. {player} and {name} are substituted."),
                    fld(r, "msgFailed", "text", "Failed", "Broadcast when the fighter is lost, logs out, or the run is closed. {player} and {name} are substituted.")];
            } }
        ], footer: [{ label: "Save", run: function () { RPG.net.send("dbr_raid_req", { what: "rift", op: "save", rift: r }); } },
            { label: "Back", run: function () { RPG.net.send("dbr_raid_req", { what: "rift", op: "list" }); } }] });
    }
})();
