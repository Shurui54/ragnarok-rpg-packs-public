// =====================================================================================
//  45_transform.js - DMZ's radial utility menu (UtilityMenuScreen + client/gui/radial/*), X
// =====================================================================================
//  Port of DragonMine Z's UtilityMenuScreen (GPL-3.0, see NOTICE.md): 8 base slots on a ring
//  (0 top Super Forms, 1 Extra Forms, 2 addon, 3 Movement, 4 Descend, 5 Actions, 6 addon,
//  7 Stack Skills), child rings that open outward on hover, a scrollable/draggable option panel
//  ("More", Limit Release, Flight Speed), a model preview of the hovered form in the middle,
//  the same colours, radii, 140 ms open/close easing, hover animations and sounds.
//    hover        expands a category; children follow the mouse outward, ring by ring
//    click        select (forms: the G target; toggles: on/off); double-click a form = instant
//    wheel        over Limit Release / Flight Speed: +-5 %
//    More panel   drag a row to reorder (saved like DMZ's RadialLayoutStore)
//    X            hold to keep it open (release closes, like DMZ); a quick tap keeps it open
//                 until X / Esc
//  Forms, stack, racial, descend, aura and the release limit talk to the server
//  (scripts/31_dmz_transform.js on "dmz_tf", scripts/62_dmz_radial.js on "dmz_radial");
//  nodes whose systems are not ported yet send "dmz_radial" too and 62_dmz_radial.js routes
//  them to DMZ_TECH / DMZ_FLIGHT / DMZ_FUSION / ... when those exist.
//
//  Drawing: the engine has no triangle/arc primitive, so each annular sector is ONE rotated
//  textured quad sampling a pre-rendered mask (dbr:textures/gui/radial/sector_l<level>.png,
//  one cell per inner/outer radius ratio; docs/dmz-spec/tools/gen_radial_sectors.py).
// =====================================================================================
var DMZ_RADIAL = (function () {
    var ID = "dmz_radial", FONT = "dmzpack:smooth";
    // ---- UtilityMenuScreen constants -------------------------------------------------
    var ANIMATION_DURATION = 140, SLOTS = 8;
    var R_INNER = 40, R_OUTER = 86, CHILD_BAND = 42, SECTOR_GAP_DEG = 3;
    var ICON_BASE = 16, ICON_CHILD = 14;
    var MODEL_SCALE = 32, MODEL_Y_OFFSET = 26, ANIM_SPEED = 14;
    var PANEL = [0.11, 0.11, 0.13, 0.60], PANEL_HOVER = [0.20, 0.52, 0.96, 0.90], PANEL_INACTIVE = [0.09, 0.09, 0.10, 0.42];
    var CHILD_PANEL = [0.10, 0.12, 0.11, 0.64], CHILD_HOVER = [0.22, 0.46, 0.30, 0.86];
    var PANEL_WIDTH = 130, PANEL_ROW_H = 13, PANEL_TITLE_H = 15, PANEL_PAD = 5, PANEL_SCREEN_MARGIN = 4, PANEL_CLEAR_GAP = 12, PANEL_MAX_ROWS = 8;
    var DOUBLE_CLICK_MS = 300, MAX_SLOTS = 5, CONFIRM_WINDOW_MS = 5000;
    var GREEN = "#2BFF00", RED = "#FF1B00", WHITE = "#FFFFFF";
    var KI_WEAPON_TYPES = ["blade", "clawlance", "scythe"];          // CombatConfig defaults, sorted like getKiWeaponTypes
    var RADIAL_ICONS = { absorption: 1, absorptionbarrier: 1, actions: 1, androidforms: 1, assimilation: 1, aura: 1, celljr: 1, descend: 1,
        flight_locked: 1, flight_unlocked: 1, fly: 1, friendlyfist: 1, fusion: 1, godforms: 1, jump: 1, kaioken: 1, kiactions: 1, kifist: 1,
        kiprotection: 1, kiweapon: 1, legendaryforms: 1, more: 1, movement: 1, placeholder: 1, racial: 1, regen: 1, selfdestruct: 1, sprint: 1,
        superforms: 1, tail: 1, ultimate: 1, vitaldrain: 1 };
    var LAYOUT_KEY = "dmz_radial_layout";

    // ---- the sector mask atlases (must match the generator) ----------------------------
    var BASE_ARC = (R_INNER + R_OUTER) / 2 * (Math.PI / 4);
    function childArcDeg(level) {
        var mid = R_OUTER + (level - 1) * CHILD_BAND + CHILD_BAND / 2;
        return Math.min(1.25 * BASE_ARC / mid * 180 / Math.PI, 360 / SLOTS);
    }
    function childDrawnHalfDeg(level) { return childArcDeg(level) / 2 - SECTOR_GAP_DEG / 2; }
    var SECTOR_LEVELS = [
        { tex: "dbr:textures/gui/radial/sector_l0.png", kmin: 0.40, kmax: 0.48, n: 16, cell: 128, cols: 4, size: 512 },
        { tex: "dbr:textures/gui/radial/sector_l1.png", kmin: 0.62, kmax: 1.0, n: 64, cell: 96, cols: 8, size: 768 },
        { tex: "dbr:textures/gui/radial/sector_l2.png", kmin: 0.70, kmax: 1.0, n: 64, cell: 96, cols: 8, size: 768 },
        { tex: "dbr:textures/gui/radial/sector_l3.png", kmin: 0.76, kmax: 1.0, n: 64, cell: 96, cols: 8, size: 768 }
    ];
    SECTOR_LEVELS.forEach(function (L, i) { L.half = i === 0 ? 22.5 - SECTOR_GAP_DEG / 2 : childDrawnHalfDeg(i); L.pad = 2; });

    // ---- state -----------------------------------------------------------------------
    var S = null, stateSerial = 0;     // last dmz_tf_state from the server
    var V = null;                      // per-frame snapshot of the synced vars ("StatsData")
    var U = null;                      // the open menu
    var ADDON_SLOTS = [];
    var ANIM = {};                     // node key -> { s: animScale, e: animExpand, h: animHighlight }
    var TCACHE = {}, WRAP = {}, TRUNC = {};
    var frame = 0;

    // ---- small helpers ---------------------------------------------------------------
    function T(key, fb, arg) {
        var ck = arg === undefined ? key : key + "\u0000" + arg;
        if (TCACHE[ck] !== undefined) return TCACHE[ck];
        var out = fb;
        try { if (RPG.hasTranslation(key)) out = arg === undefined ? RPG.translate(key) : RPG.translate(key, arg); } catch (e) { }
        TCACHE[ck] = String(out);
        return TCACHE[ck];
    }
    function icon(n) { return "dmzpack:textures/gui/radial/" + n + ".png"; }
    function num(v, d) { v = Number(v); return isNaN(v) ? d : v; }
    function obj(v) { return v && typeof v === "object" ? v : {}; }
    function pair(v) { v = String(v || ""); var i = v.indexOf(":"); return i > 0 ? { g: v.substring(0, i), f: v.substring(i + 1) } : null; }
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function floorMod(a, n) { return ((a % n) + n) % n; }
    function easeOut(t) { var inv = 1 - t; return 1 - inv * inv * inv; }
    function hex2(v) { v = Math.round(clamp(v, 0, 1) * 255); return (v < 16 ? "0" : "") + v.toString(16); }
    function hexOf(c) { return "#" + hex2(c[0]) + hex2(c[1]) + hex2(c[2]); }
    function lerpColor(a, b, t) {
        t = clamp(t, 0, 1);
        return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, a[3] + (b[3] - a[3]) * t];
    }
    function absAngleDiff(a, b) { var d = ((a - b) % 360 + 540) % 360 - 180; return Math.abs(d); }
    function val(n, k) { var v = n[k]; return typeof v === "function" ? v.call(n) : v; }
    function sendTf(o) { RPG.net.send("dmz_tf", o); }
    // a node whose system lives elsewhere: the techniques port may claim it on the client first
    function hook(node, value) {
        try {
            if (typeof DMZ_TECH_CLIENT !== "undefined" && DMZ_TECH_CLIENT && typeof DMZ_TECH_CLIENT.radial === "function"
                && DMZ_TECH_CLIENT.radial(node, value) === true) return;
        } catch (e) { RPG.log("DMZ_TECH_CLIENT.radial failed: " + e); }
        RPG.net.send("dmz_radial", { node: node, value: value === undefined ? null : value });
    }
    function playToggle(on) { RPG.sound(on ? "dmzpack:switch_on" : "dmzpack:switch_off", 1, 1); }
    function playClick() { RPG.sound("minecraft:ui.button.click", 0.25, 1); }   // SimpleSoundInstance.forUI volume

    // ---- the "StatsData" snapshot (vars the server syncs) -------------------------------
    function snapshot() {
        var p = RPG.player, race = S ? String(S.race || "") : "";
        var v = {
            race: race, ourRace: String(p.race || ""), level: num(p.level, 0),
            action: String(RPG.getVar("dmz_action", "FORM") || "FORM"),
            sel: String(RPG.getVar("dmz_sel", S ? S.sel : "") || ""), selStack: String(RPG.getVar("dmz_sel_stack", S ? S.selStack : "") || ""),
            form: String(RPG.getVar("dmz_form", "") || ""), stack: String(RPG.getVar("dmz_stack", "") || ""),
            aura: !!num(RPG.getVar("dmz_aura_perm", 0), 0), auraColor: String(RPG.getVar("dmz_aura_color", "") || ""),
            release: num(RPG.getVar("dmz_release", 0), 0), releaseLimit: num(RPG.getVar("dmz_release_limit", 0), 0),
            android: !!num(RPG.getVar("dmz_android", 0), 0), tail: num(RPG.getVar("dmz_tail", 1), 1),
            tailVisible: !!num(RPG.getVar("dmz_tail_visible", 1), 1),
            skills: obj(RPG.getVar("dmz_skills", null)), skillOn: obj(RPG.getVar("dmz_skill_active", null)),
            flying: p.hasEffect("flight"),
            flightMode: num(RPG.getVar("dmz_flight_mode", 0), 0), flightLock: !!num(RPG.getVar("dmz_flight_lock", 0), 0),
            flightSpeed: num(RPG.getVar("dmz_flight_speed_limit", 0), 0),
            regen: num(RPG.getVar("dmz_regen_state", 0), 0),
            kiWeapon: String(RPG.getVar("dmz_kiweapon", "") || ""), friendlyFist: !!num(RPG.getVar("dmz_friendly_fist", 0), 0),
            bioSkill: String(RPG.getVar("dmz_bio_skill", "drain") || "drain")
        };
        var pot = num(RPG.getVar("dmz_potential", 0), 0);
        var mult = v.ourRace === "saiyan" ? 1 + Math.min(0.15, num(RPG.getVar("dmz_zenkai_release", 0), 0)) : 1;
        var boost = num(RPG.getVar("dmzr_release_boost", 0), 0);
        v.releaseMax = typeof DMZ_F !== "undefined" ? DMZ_F.maxRelease(pot, mult, boost) : Math.floor((50 + 5 * pot) * mult) + boost;
        return v;
    }
    function lvl(s) { var x = V.skills[s]; return typeof x === "number" ? x : 0; }
    function hasSkill(s) { return Object.prototype.hasOwnProperty.call(V.skills, s); }     // Skills.hasSkill: owned at any level
    function skillOn(s) { return !!V.skillOn[s]; }
    function bioTier() { var f = pair(V.form); return !f ? "imperfect" : f.f === "semiperfect" ? "semi" : "perfect"; }

    // =================================================================================
    //  Nodes (radial/nodes/*). A node: key, label, icon, faceText, tint, labelColor, active,
    //  visible, interactive, kids, expandable, onSelect, onDoubleSelect, orderKey, preview.
    // =================================================================================
    function N(key, o) {
        o.key = key;
        if (o.kids === undefined) o.kids = [];
        if (o.label === undefined) o.label = "";
        if (o.icon === undefined) o.icon = null;
        if (o.labelColor === undefined) o.labelColor = WHITE;
        if (o.active === undefined) o.active = false;
        if (o.visible === undefined) o.visible = true;
        if (o.interactive === undefined) o.interactive = true;
        if (o.expandable === undefined) o.expandable = function () { return this.kids.length > 0; };
        if (o.orderKey === undefined) o.orderKey = "";
        return o;
    }
    function category(key, label, ic, kids) {
        return N(key, { kind: "category", label: label, icon: icon(ic), kids: kids || [],
            visible: function () { for (var i = 0; i < this.kids.length; i++) if (val(this.kids[i], "visible")) return true; return false; } });
    }
    function toggleNode(key, label, ic, has, isOn, toggle) {
        return N(key, { kind: "toggle", label: label, icon: icon(ic), visible: has, active: isOn,
            labelColor: function () { return isOn() ? GREEN : RED; },
            onSelect: function () { var was = isOn(); toggle(was); playToggle(!was); } });
    }

    // ---- forms (RadialForms, FormSelectNode, FormGroupHeadNode, MoreNode) -----------------
    function iconForFormType(type) {
        var t = String(type || "").toLowerCase();
        if (!t) return icon("superforms");
        if (t.indexOf("legendary") >= 0) return icon("legendaryforms");
        if (t.indexOf("super") >= 0) return icon("superforms");
        if (t.indexOf("god") >= 0) return icon("godforms");
        if (t.indexOf("android") >= 0) return icon("androidforms");
        if (t.indexOf("kaioken") >= 0) return icon("kaioken");
        if (t.indexOf("ultimate") >= 0) return icon("ultimate");
        if (RADIAL_ICONS[t]) return icon(t);
        return icon("superforms");
    }
    function formLabel(g, f, stack) {
        return stack ? T("race.dragonminez.stack.form." + g.id + "." + f.id, f.n)
            : T("race.dragonminez." + V.race + ".form." + g.id + "." + f.id, f.n);
    }
    function formNode(parentKey, g, f, stack, head) {
        var tag = g.id + ":" + f.id;
        var n = N(parentKey + (head ? "/group:" + (stack ? "stack:" : "") + g.id : "/form:" + tag), {
            kind: "form", g: g.id, f: f.id, stack: stack, label: formLabel(g, f, stack), icon: iconForFormType(g.type), tint: f.aura || null,
            orderKey: head ? "group:" + (stack ? "stack:" : "") + g.id : (stack ? "stack:" : "form:") + tag,
            active: function () { return stack ? V.action === "STACK" && V.selStack === tag : V.action === "FORM" && V.sel === tag; },
            labelColor: function () { return this.active() ? GREEN : RED; },
            preview: function () { return { g: g.id, f: f.id, stack: stack }; },
            onSelect: function () { sendTf({ op: "select", g: g.id, f: f.id, stack: stack, instant: false }); playToggle(true); },
            onDoubleSelect: function () { sendTf({ op: "select", g: g.id, f: f.id, stack: stack, instant: true }); playToggle(true); }
        });
        return n;
    }
    function layout() { try { return obj(RPG.storage.get(LAYOUT_KEY, null)); } catch (e) { return {}; } }
    function applyOrder(categoryKey, nodes) {
        var order = layout()[categoryKey];
        if (!order || !order.length) return nodes;
        var remaining = nodes.slice(), result = [];
        order.forEach(function (k) {
            for (var i = 0; i < remaining.length; i++) if (remaining[i].orderKey === k) { result.push(remaining.splice(i, 1)[0]); break; }
        });
        return result.concat(remaining);
    }
    function moreNode(parentKey, categoryKey, options) {
        return N(parentKey + "/more", { kind: "more", categoryKey: categoryKey, options: options,
            label: T("gui.dragonminez.radial.more", "More"), icon: icon("more"), expandable: false });
    }
    function orderAndCap(parentKey, categoryKey, list) {
        list = applyOrder(categoryKey, list);
        if (list.length <= MAX_SLOTS) return list;
        var head = list.slice(0, MAX_SLOTS - 1);
        head.push(moreNode(parentKey, categoryKey, list.slice()));
        return head;
    }
    function groupHead(parentKey, g, stack, categoryKey) {
        var forms = (g.forms || []).filter(function (f) { return f.selectable; });     // getSelectableFormNames
        if (!forms.length) return null;
        var head = formNode(parentKey, g, forms[0], stack, true);
        var rest = forms.slice(1).map(function (f) { return formNode(head.key, g, f, stack, false); });
        head.kids = orderAndCap(head.key, categoryKey + ":" + g.id, rest);
        return head;
    }
    function typeIs(t, list) { t = String(t || "").toLowerCase(); for (var i = 0; i < list.length; i++) if (t.indexOf(list[i]) >= 0) return true; return false; }
    function formHeads(parentKey, categoryKey, groups, stack) {
        var heads = [];
        groups.forEach(function (g) { var h = groupHead(parentKey, g, stack, categoryKey); if (h) heads.push(h); });
        heads.sort(function (a, b) { var x = a.label.toLowerCase(), y = b.label.toLowerCase(); return x < y ? -1 : x > y ? 1 : 0; });
        return orderAndCap(parentKey, categoryKey, heads);
    }
    var SUPER_TYPES = ["super", "legendary", "android"];

    // ---- Actions (RacialSkillNode, NamekRegenNode, FusionNode, ReleaseNode, KiWeapons, KiActions)
    function racialSkill() { return V.race; }        // RaceCharacterConfig.racialSkill = the DMZ race id for every default race
    function isActionRacial() {
        var r = racialSkill();
        return r === "namekian" || r === "majin" || r === "bioandroid" || (r === "human" && V.android);
    }
    function isTailRace() { var f = pair(V.form); return V.race === "saiyan" || (f && f.f.indexOf("oozaru") >= 0); }
    function racialNode(key) {
        var n = N(key, {
            kind: "racial",
            label: function () {
                if (isActionRacial()) {
                    var skill = racialSkill();
                    if (skill === "bioandroid") {
                        var tier = bioTier();
                        if (tier === "semi" && V.bioSkill === "explode") return T("gui.action.dragonminez.racial.bioandroid.explode", "Self-Destruct");
                        return T("gui.action.dragonminez.racial.bioandroid." + tier, "Vital Drain");
                    }
                    return T("gui.action.dragonminez.racial." + skill, S && S.racial ? S.racial.label : skill);
                }
                if (isTailRace()) return T("gui.action.dragonminez.tail", "Tail");
                return "";
            },
            icon: function () {
                if (isActionRacial()) {
                    var skill = racialSkill();
                    if (skill === "namekian") return icon("assimilation");
                    if (skill === "majin") return icon("absorption");
                    if (skill === "human") return icon("absorptionbarrier");
                    if (skill === "bioandroid") {
                        var tier = bioTier();
                        if (tier === "perfect") return icon("celljr");
                        if (tier === "semi" && V.bioSkill === "explode") return icon("selfdestruct");
                        return icon("vitaldrain");
                    }
                    return icon("racial");
                }
                return isTailRace() ? icon("tail") : icon("racial");
            },
            visible: function () { return !!V.race && (isTailRace() || isActionRacial()); },
            active: function () {
                if (isActionRacial()) return V.action === "RACIAL";
                if (isTailRace()) return V.tailVisible;
                return false;
            },
            labelColor: function () { return this.active() ? GREEN : RED; },
            onSelect: function () {
                if (isActionRacial()) {
                    var was = V.action === "RACIAL";
                    if (racialSkill() === "human") hook("racial_mode", "human");          // Absorption Barrier: not ported
                    else sendTf({ op: "mode", mode: was ? "FORM" : "RACIAL" });          // SwitchActionC2S toggles back to FORM
                    playToggle(!was);
                } else if (isTailRace()) {
                    var on = V.tailVisible;
                    hook("tail", !on);
                    playToggle(!on);
                }
            }
        });
        var skill = racialSkill();
        if (skill === "bioandroid" && bioTier() === "semi") n.kids = [bioChoice(key, false), bioChoice(key, true)];
        else if (skill === "majin" && S && S.racial) n.kids = (S.racial.slots || []).map(function (name, i) { return ejectNode(key, i, name); });
        return n;
    }
    function bioChoice(parentKey, explode) {
        return N(parentKey + "/bio:" + (explode ? "explode" : "drain"), {
            kind: "bio", label: T("gui.action.dragonminez.racial.bioandroid." + (explode ? "explode" : "semi"), explode ? "Self-Destruct" : "Vital Drain"),
            icon: icon(explode ? "selfdestruct" : "vitaldrain"),
            active: function () { return explode === (V.bioSkill === "explode"); },
            labelColor: function () { return this.active() ? GREEN : WHITE; },
            onSelect: function () {
                if (V.action !== "RACIAL") sendTf({ op: "mode", mode: "RACIAL" });
                if (this.active()) { playToggle(true); return; }
                hook("bio_skill", explode ? "explode" : "drain");
                playToggle(true);
            }
        });
    }
    var PENDING = {};                  // eject confirm windows by slot index (survive rebuilds like DMZ's signature check)
    function ejectNode(parentKey, i, name) {
        function pending() { return PENDING[i] > 0 && RPG.nowMs() - PENDING[i] < CONFIRM_WINDOW_MS; }
        return N(parentKey + "/eject:" + i, {
            kind: "eject", icon: icon("absorption"),
            label: function () {
                if (pending()) return T("gui.dragonminez.racial.majin.eject_confirm", "Click again to eject");
                return name ? String(name) : T("gui.dragonminez.racial.majin.eject_slot", "Slot " + (i + 1), i + 1);
            },
            labelColor: function () { return pending() ? RED : WHITE; },
            onSelect: function () {
                if (pending()) { PENDING[i] = 0; sendTf({ op: "eject", i: i }); playToggle(false); }
                else { PENDING[i] = RPG.nowMs(); playClick(); hook("eject_confirm_msg", i); }
            }
        });
    }
    function releaseNode(key) {
        function limit() { return V.releaseLimit; }
        return N(key, {
            kind: "release", label: T("gui.action.dragonminez.release", "Limit Release"),
            faceText: function () { return (limit() > 0 ? limit() : V.releaseMax) + "%"; },
            visible: function () { return !!V.race; },
            active: function () { return limit() > 0; },
            labelColor: function () { return limit() > 0 ? GREEN : WHITE; },
            expandable: false,
            onSelect: function () { hook("release_limit", 0); playToggle(false); },
            adjustByWheel: function (delta) {
                if (!delta) return;
                var max = V.releaseMax, cur = limit() > 0 ? limit() : max;
                var next = Math.max(5, Math.min(max, cur + (delta > 0 ? 5 : -5)));
                if (next !== cur) { V.releaseLimit = next; hook("release_limit", next); playClick(); }
            },
            buildOptions: function () {
                var out = [];
                for (var v = V.releaseMax; v >= 5; v -= 5) out.push(limitOption(key + "/opt:" + v, v, function () { return V.releaseLimit; }, "release_limit"));
                return out;
            }
        });
    }
    function limitOption(key, value, current, hookName) {
        return N(key, { kind: "option", label: value + "%",
            active: function () { return current() === value; },
            labelColor: function () { return current() === value ? GREEN : WHITE; },
            onSelect: function () { hook(hookName, value); playClick(); } });
    }
    function kiWeaponNode(parentKey, type) {
        return N(parentKey + "/kiweapon:" + type, {
            kind: "kiweapon", label: T("skill.dragonminez.kiweapon." + type, type), icon: icon("kiweapon"),
            tint: function () { return V.auraColor || null; },
            active: function () { return skillOn("kimanipulation") && V.kiWeapon.toLowerCase() === type; },
            labelColor: function () { return this.active() ? GREEN : RED; },
            onSelect: function () { var was = this.active(); hook("kiweapon", type); playToggle(!was); }
        });
    }
    function actionsNode() {
        var key = "actions";
        var kiWeapons = category(key + "/kiweapons", T("gui.dragonminez.radial.kiweapons", "Ki Weapons"), "kiweapon",
            KI_WEAPON_TYPES.map(function (t) { return kiWeaponNode(key + "/kiweapons", t); }));
        kiWeapons.visible = function () { return hasSkill("kimanipulation") && hasSkill("kicontrol") && this.kids.length > 0; };
        var kk = key + "/kiactions";
        var kiActions = category(kk, T("gui.dragonminez.radial.kiactions", "Ki Actions"), "kiactions", [
            toggleNode(kk + "/aura", T("skill.dragonminez.aurastatus", "Aura Status"), "aura",
                function () { return hasSkill("kicontrol"); }, function () { return V.aura; },
                function () { sendTf({ op: "aura" }); }),
            toggleNode(kk + "/friendlyfist", T("skill.dragonminez.friendlyfist", "Friendly Fist"), "friendlyfist",
                function () { return hasSkill("kicontrol"); }, function () { return V.friendlyFist; },
                function (was) { hook("friendly_fist", !was); }),
            toggleNode(kk + "/kiprotection", T("skill.dragonminez.kiprotection", "Ki Protection"), "kiprotection",
                function () { return hasSkill("kiprotection"); }, function () { return skillOn("kiprotection"); },
                function (was) { hook("skill_toggle", "kiprotection"); }),
            toggleNode(kk + "/ki_infusion", T("skill.dragonminez.ki_infusion", "Ki Infusion"), "kifist",
                function () { return hasSkill("ki_infusion"); }, function () { return skillOn("ki_infusion"); },
                function (was) { hook("skill_toggle", "ki_infusion"); })
        ]);
        var regen = N(key + "/regen", {
            kind: "regen", label: T("gui.action.dragonminez.racial.namekian.regen", "Regeneration"), icon: icon("regen"),
            visible: function () { return V.race === "namekian"; },
            active: function () { return V.regen === 1; },
            labelColor: function () { return V.regen === 2 ? RED : V.regen === 1 ? GREEN : RED; },
            onSelect: function () { if (V.regen === 2) return; hook("namek_regen", true); playToggle(true); }
        });
        var fusion = N(key + "/fusion", {
            kind: "fusion", label: T("gui.action.dragonminez.fusion", "Fusion"), icon: icon("fusion"),
            visible: function () { return hasSkill("fusion"); },
            active: function () { return V.action === "FUSION"; },
            labelColor: function () { return V.action === "FUSION" ? GREEN : RED; },
            onSelect: function () { var was = V.action === "FUSION"; hook("fusion", !was); playToggle(!was); }
        });
        return category(key, T("gui.dragonminez.radial.actions", "Actions"), "actions",
            [racialNode(key + "/racial"), regen, fusion, releaseNode(key + "/release"), kiWeapons, kiActions]);
    }

    // ---- Movement (FlyNode, FlightModeNode, FlightSpeedNode, FlightModeLockNode, SkillToggleNode)
    function canFly() { return lvl("fly") > 0 && lvl("kicontrol") > 0; }   // FlyNode.canFly
    function movementNode() {
        var key = "movement", fk = key + "/fly";
        var fly = toggleNode(fk, T("skill.dragonminez.fly", "Fly"), "fly", canFly, function () { return V.flying; },
            function (was) { hook("fly", !was); });
        fly.kind = "fly";
        var speed = N(fk + "/speed", {
            kind: "flightspeed", label: T("gui.action.dragonminez.flightspeed", "Flight Speed"),
            faceText: function () { return (V.flightSpeed > 0 ? V.flightSpeed : 100) + "%"; },
            visible: canFly,
            active: function () { return V.flightSpeed > 0 && V.flightSpeed < 100; },
            labelColor: function () { return this.active() ? GREEN : WHITE; },
            expandable: false,
            onSelect: function () { hook("flight_speed", 100); playToggle(false); },
            adjustByWheel: function (delta) {
                if (!delta) return;
                var cur = V.flightSpeed > 0 ? V.flightSpeed : 100, next = Math.max(5, Math.min(100, cur + (delta > 0 ? 5 : -5)));
                if (next !== cur) { V.flightSpeed = next; hook("flight_speed", next); playClick(); }
            },
            buildOptions: function () {
                var out = [];
                for (var v = 100; v >= 5; v -= 5) out.push(limitOption(fk + "/speed/opt:" + v, v, function () { return V.flightSpeed; }, "flight_speed"));
                return out;
            }
        });
        fly.kids = [
            N(fk + "/mode", {
                kind: "flightmode",
                label: function () { return V.flightMode === 1 ? T("gui.dragonminez.radial.flight_mode.combat", "Combat Fly") : T("gui.dragonminez.radial.flight_mode.search", "Search Fly"); },
                icon: icon("fly"), visible: canFly,
                active: function () { return V.flightMode === 1; },
                onSelect: function () { var on = V.flightMode === 1; hook("flight_mode", on ? 0 : 1); playToggle(!on); }
            }),
            speed,
            N(fk + "/lock", {
                kind: "flightlock",
                label: function () { return V.flightLock ? T("gui.dragonminez.radial.flight_mode.locked", "Mode Lock: On") : T("gui.dragonminez.radial.flight_mode.unlocked", "Mode Lock: Off"); },
                icon: function () { return icon(V.flightLock ? "flight_locked" : "flight_unlocked"); },
                visible: canFly,
                active: function () { return V.flightLock; },
                labelColor: function () { return V.flightLock ? GREEN : RED; },
                onSelect: function () { hook("flight_lock", !V.flightLock); playToggle(!V.flightLock); }
            })
        ];
        return category(key, T("gui.dragonminez.radial.movement", "Movement"), "movement", [
            fly,
            toggleNode(key + "/jump", T("skill.dragonminez.jump", "Jump"), "jump", function () { return hasSkill("jump"); },
                function () { return skillOn("jump"); }, function () { hook("skill_toggle", "jump"); }),
            toggleNode(key + "/sprint", T("skill.dragonminez.sprint", "Sprint"), "sprint", function () { return hasSkill("sprint"); },
                function () { return skillOn("sprint"); }, function () { hook("skill_toggle", "sprint"); })
        ]);
    }

    function descendNode() {
        return N("descend", {
            kind: "descend", label: T("gui.action.dragonminez.descend", "Descend"), icon: icon("descend"),
            visible: function () {
                var f = pair(V.form), androidBase = V.android && f && f.f === "androidbase";
                if (V.stack || (f && !androidBase)) return true;
                return V.release > 0;
            },
            labelColor: RED,
            onSelect: function () { sendTf({ op: "descend", all: false }); playToggle(false); }
        });
    }
    function emptyNode(i) { return N("empty:" + i, { kind: "empty", interactive: false }); }
    function addonNode(i, slot) {           // IUtilityMenuSlotAdapter
        function info() { try { return slot.render(V) || null; } catch (e) { return null; } }
        return N("addon:" + i, {
            kind: "addon", icon: icon("placeholder"),
            label: function () { var x = info(); return x && x.line1 ? String(x.line1) : ""; },
            visible: function () { var x = info(); return !!x && !!(x.line1 || x.line2); },
            active: function () { var x = info(); return !!x && !!x.selected; },
            labelColor: function () { return this.active() ? GREEN : WHITE; },
            onSelect: function () { try { slot.handle(V, false); } catch (e) { RPG.log("radial addon slot: " + e); } playClick(); }
        });
    }

    function buildBaseNodes() {
        var groups = S ? S.groups || [] : [], stacks = S ? S.stacks || [] : [];
        var addon = 0;
        function nextAddon(i) { return addon < ADDON_SLOTS.length ? addonNode(i, ADDON_SLOTS[addon++]) : emptyNode(i); }
        return [
            category("superforms", T("gui.dragonminez.radial.superforms", "Super Forms"), "superforms",
                formHeads("superforms", "superforms", groups.filter(function (g) { return typeIs(g.type, SUPER_TYPES); }), false)),
            category("moreforms", T("gui.dragonminez.radial.extraforms", "Extra Forms"), "godforms",
                formHeads("moreforms", "moreforms", groups.filter(function (g) { return !typeIs(g.type, SUPER_TYPES); }), false)),
            nextAddon(2),
            movementNode(),
            descendNode(),
            actionsNode(),
            nextAddon(6),
            category("stackskills", T("gui.dragonminez.radial.stackskills", "Stack Skills"), "kaioken",
                formHeads("stackskills", "stackforms", stacks, true))
        ];
    }

    // =================================================================================
    //  Model preview (ModelFormPreview): the player in the hovered form, facing the screen
    // =================================================================================
    var PASS_KEYS = ["body1", "body2", "body3", "hair", "eyes", "eye2", "aura", "bodyType", "bodyModel", "eyeStyle", "nose", "mouth",
        "hairStyle", "tattoo", "halo", "tail", "dmzSlim", "dmzGender"];
    var C_MAP = { fBody1: "body1", fBody2: "body2", fBody3: "body3", fHair: "hair", fEye1: "eye1", fEye2: "eye2" };
    function ownColor(k) {
        var c = String(RPG.player.color(k, "") || "");
        if (c) return c;
        var d = typeof DBR_RACE_DEFAULTS !== "undefined" ? DBR_RACE_DEFAULTS[V.ourRace] || {} : {};
        return d[k] || "#FFFFFF";
    }
    function variant(bodyType) { var t = String(bodyType || ""); return t.indexOf("female") === 0 ? "female" : t.indexOf("slim") >= 0 ? "slim" : "male"; }
    function modelFile(race, f, bodyType, bodyModel) {       // DMZ_LOOK.modelFile (scripts/30_forms.js)
        var v = variant(bodyType), fem = v === "female";
        var base = { human: bodyModel || "human", saiyan: bodyModel || "human", glind: bodyModel || "human", namekian: "human",
            frostdemon: "frostdemon", bioandroid: f ? "bioandroid_perfect" : "bioandroid", majin: bodyModel || "majin" }[race] || "human";
        var key = f ? f.model || "" : "";
        if (!key) return base;
        function three(m, s, w) { return fem ? w : v === "slim" ? s : m; }
        switch (key) {
            case "buffed": case "ssj4gt": return three("hbuffed", "hbuffed_slim", "hbuffed_fem");
            case "buffedg3": case "ssj4d": return three("hbuffedg3", "hbuffed_slimg3", "hbuffed_femg3");
            case "4arms": return three("h4arms", "h4armsslim", "h4armsfem");
            case "namekian_buffed": case "namekian_orange": return "hbuffed";
            case "majin_kid": case "majin_evil": return fem ? "majin_slim" : "human_slim";
            case "majin_super": return fem ? "majin_slim" : "human";
            case "majin_ultra": return fem ? "hbuffed_fem" : "hbuffed";
            case "frostdemon_final": case "frostdemon_mecha": return "frostdemon";
            case "trascended": return fem ? "trascended_fem" : "trascended";
            case "finalbase": return base;
            default: return key;
        }
    }
    function previewLook(pv) {
        if (!pv || typeof DMZ_FORMS === "undefined") return null;
        var FD = DMZ_FORMS, race = V.race;
        var f = pv.stack ? null : FD.form(race, pv.g, pv.f), s = pv.stack ? FD.stackForm(pv.g, pv.f) : null;
        if (!f && !s) return null;
        var key = f ? "effect:dmzf_" + race + "_" + (f.group === "oozaru" ? "o" : f.group) + "_" + f.id
            : FD.groups(race).length ? "effect:dmzb_" + race : null;
        if (!key) return null;
        var colors = {};
        PASS_KEYS.forEach(function (k) { var c = String(RPG.player.color(k, "") || ""); if (c) colors[k] = c; });
        var eyes = ownColor("eyes");
        var base = { fBody1: ownColor("body1"), fBody2: ownColor("body2"), fBody3: ownColor("body3"), fHair: ownColor("hair"),
            fEye1: eyes, fEye2: race === "bioandroid" ? "#FFFFFF" : eyes };
        Object.keys(C_MAP).forEach(function (k) { colors[k] = (s && s.c && s.c[C_MAP[k]]) || (f && f.c && f.c[C_MAP[k]]) || base[k]; });
        var t = s && s.tint && s.tint[1] > 0 ? s.tint : f && f.tint && f.tint[1] > 0 ? f.tint : null;
        if (t) ["fBody1", "fBody2", "fBody3", "fHair"].forEach(function (k) { colors[k] = FD.tint(colors[k], t[0], t[1]); });
        var bodyType = colors.bodyType || ownColor("bodyType"), bodyModel = colors.bodyModel || "";
        colors.dmzModel = modelFile(race, f, bodyType, bodyModel);
        colors.dmzAura = s ? s.aura || "#FFFFFF" : (f && f.aura) || ownColor("aura");
        return { key: key, colors: colors };
    }
    function modelScaleFor(pv) {     // ModelFormPreview.adjustedScale
        if (typeof DMZ_FORMS === "undefined") return 1;
        var FD = DMZ_FORMS, f = null;
        if (pv && !pv.stack) f = FD.form(V.race, pv.g, pv.f);
        else if (!pv) { var a = pair(V.form); f = a ? FD.form(V.race, a.g, a.f) : null; }
        var sc = FD.scaleOf(V.race, f), cur = (Number(sc[0]) + Number(sc[1])) / 2;
        return cur > 1 ? 0.9375 / cur : 1;
    }

    // =================================================================================
    //  The screen (UtilityMenuScreen)
    // =================================================================================
    function uiScaleFor(w, h) {        // ScaledScreen.calculateUiScale (x2/3, x "Menu Panel Scale", x "Utility Menu Scale")
        var fit = Math.max(0.25, Math.min(w / 320, h / 240));
        var menu = typeof DMZ_OPTS !== "undefined" ? DMZ_OPTS.menuScale() : 0.75, util = typeof DMZ_OPTS !== "undefined" ? DMZ_OPTS.utilityScale() : 1;
        return clamp(Math.max(1, Math.min(w / 320, h / 240)) * (2 / 3) * util * menu, 0.25, fit);
    }
    function newHover() { return { path: [], keys: {}, deepest: null, angle: 0, level: 0 }; }
    function addPath(h, n) { h.path.push(n); h.keys[n.key] = 1; }
    function anim(n) { return ANIM[n.key] || (ANIM[n.key] = { s: 0, e: 0, h: 0 }); }
    function isActiveSlot(n) { return val(n, "visible") && val(n, "interactive"); }
    function baseCenter(i) { return -90 + i * (360 / SLOTS); }
    function baseSlotAt(ang) { return floorMod(Math.round((ang + 90) / 45), SLOTS); }
    function radiusForLevel(level) { return level <= 0 ? (R_INNER + R_OUTER) / 2 : R_OUTER + (level - 0.5) * CHILD_BAND; }
    function visibleChildren(n) {
        if (n._vf === frame) return n._vis;
        var out = [];
        for (var i = 0; i < n.kids.length; i++) if (val(n.kids[i], "visible")) out.push(n.kids[i]);
        n._vf = frame; n._vis = out;
        return out;
    }
    function indexByKey(list, key) { for (var i = 0; i < list.length; i++) if (list[i].key === key) return i; return -1; }

    function computeOpenScale(now) {
        if (U.closing) return easeOut(Math.max(0, 1 - Math.min(1, (now - U.closeStart) / ANIMATION_DURATION)));
        return easeOut(Math.min(1, (now - U.openTime) / ANIMATION_DURATION));
    }
    function approach(cur, target) { var step = Math.min(1, U.dt * ANIM_SPEED); return cur + (target - cur) * step; }
    function updateAnim(n, hover) {
        var a = anim(n), hovered = hover.deepest === n, lit = hovered || !!hover.keys[n.key];
        a.h = approach(a.h, lit ? 1 : 0);
        a.s = approach(a.s, hovered ? 1 : 0);
        a.e = approach(a.e, lit && val(n, "expandable") ? 1 : 0);
    }

    function pickChildByAngle(children, parentCenter, ang, level) {
        var k = children.length, arc = childArcDeg(level), best = arc / 2, bestIdx = -1;
        for (var j = 0; j < k; j++) {
            var d = absAngleDiff(ang, parentCenter + (j - (k - 1) / 2) * arc);
            if (d < best) { best = d; bestIdx = j; }
        }
        return bestIdx;
    }
    function resolveHover(cx, cy, mx, my, openScale) {
        var res = newHover(), base = U.base, chain = U.chain;
        var dx = mx - cx, dy = my - cy, d = Math.sqrt(dx * dx + dy * dy), ang = Math.atan2(dy, dx) * 180 / Math.PI;
        var inner = R_INNER * openScale, outer = R_OUTER * openScale, band = CHILD_BAND * openScale;
        if (d < inner) { chain.length = 0; return res; }
        var level = d < outer ? 0 : Math.floor(1 + Math.floor((d - outer) / band));
        if (level === 0) {
            var slot = baseSlotAt(ang), n0 = base[slot];
            chain.length = 0;
            if (!isActiveSlot(n0)) return res;
            chain.push(n0); addPath(res, n0); res.deepest = n0; res.angle = baseCenter(slot); res.level = 0;
            return res;
        }
        if (!chain.length) {
            var s2 = baseSlotAt(ang), n1 = base[s2];
            if (!isActiveSlot(n1)) return res;
            chain.push(n1);
        }
        if (chain.length > level + 1) chain.length = level + 1;
        var bi = indexByKey(base, chain[0].key);
        if (bi < 0) { chain.length = 0; return res; }
        var cur = base[bi];
        chain[0] = cur;
        addPath(res, cur); res.deepest = cur; res.angle = baseCenter(bi); res.level = 0;
        var center = baseCenter(bi);
        for (var l = 1; l <= level; l++) {
            if (!val(cur, "expandable")) break;
            var vis = visibleChildren(cur), k = vis.length, idx;
            if (!k) break;
            if (l === level) {
                idx = pickChildByAngle(vis, center, ang, l);
                if (idx < 0) break;
                chain[l] = vis[idx];
            } else {
                idx = l < chain.length ? indexByKey(vis, chain[l].key) : -1;
                if (idx < 0) {
                    idx = pickChildByAngle(vis, center, ang, l);
                    if (idx < 0) break;
                    chain[l] = vis[idx];
                } else chain[l] = vis[idx];
            }
            var child = vis[idx];
            center = center + (idx - (k - 1) / 2) * childArcDeg(l);
            addPath(res, child); res.deepest = child; res.angle = center; res.level = l;
            cur = child;
        }
        if (chain.length > res.path.length) chain.length = res.path.length;
        return res;
    }

    // ---- drawing ---------------------------------------------------------------------
    function fillSector(ctx, cx, cy, rIn, rOut, centerDeg, level, color) {
        if (rOut <= rIn || color[3] <= 0.01) return;
        var L = SECTOR_LEVELS[Math.min(level, SECTOR_LEVELS.length - 1)];
        var k = clamp(rIn / rOut, L.kmin, L.kmax), i = Math.round((k - L.kmin) / (L.kmax - L.kmin) * (L.n - 1));
        k = L.kmin + (L.kmax - L.kmin) * i / (L.n - 1);
        if (k >= 0.9999) return;
        var h = L.half * Math.PI / 180, x0 = k * Math.cos(h), sh = Math.sin(h);
        var col = i % L.cols, row = Math.floor(i / L.cols), sz = L.size;
        var u0 = (col * L.cell + L.pad) / sz, v0 = (row * L.cell + L.pad) / sz, u1 = (col * L.cell + L.cell - L.pad) / sz, v1 = (row * L.cell + L.cell - L.pad) / sz;
        ctx.push();
        ctx.translate(cx, cy);
        ctx.rotate(centerDeg);
        ctx.quad(L.tex, x0 * rOut, -sh * rOut, (1 - x0) * rOut, 2 * sh * rOut, u0, v0, u1, v1, hexOf(color), color[3]);
        ctx.pop();
    }
    function drawBaseSectors(ctx, cx, cy, hover, openScale) {
        for (var i = 0; i < U.base.length; i++) {
            var n = U.base[i], hl = 0, hv = 0, color = PANEL_INACTIVE;
            if (isActiveSlot(n)) {
                updateAnim(n, hover);
                var a = anim(n); hl = a.h; hv = a.s;
                color = lerpColor(PANEL, PANEL_HOVER, Math.max(hl * 0.5, hv));
            }
            fillSector(ctx, cx, cy, (R_INNER - 2 * hv) * openScale, (R_OUTER + 4 * hv) * openScale, baseCenter(i), 0, color);
        }
    }
    function drawChildSectors(ctx, cx, cy, parent, parentCenter, level, hover, facesPass, openScale) {
        var expand = anim(parent).e;
        if (expand < 0.01) return;
        var vis = visibleChildren(parent), k = vis.length;
        if (!k) return;
        var t = easeOut(expand);
        var ringInner = (R_OUTER + (level - 1) * CHILD_BAND) * openScale, ringOuter = ringInner + CHILD_BAND * openScale * t;
        var faceRadius = (ringInner + ringOuter) / 2, arc = childArcDeg(level);
        for (var j = 0; j < k; j++) {
            var child = vis[j], center = parentCenter + (j - (k - 1) / 2) * arc;
            if (!facesPass) {
                updateAnim(child, hover);
                var a = anim(child), c = lerpColor(CHILD_PANEL, CHILD_HOVER, Math.max(a.h * 0.5, a.s));
                c[3] *= t;
                fillSector(ctx, cx, cy, ringInner, ringOuter + 4 * a.s, center, level, c);
            } else if (t >= 0.4) {
                drawFace(ctx, cx, cy, child, center, faceRadius, ICON_CHILD, anim(child).s, t, childDrawnHalfDeg(level));
            }
            drawChildSectors(ctx, cx, cy, child, center, level + 1, hover, facesPass, openScale);
        }
    }
    function drawBaseFaces(ctx, cx, cy, openScale) {
        var radius = (R_INNER + R_OUTER) / 2 * openScale;
        for (var i = 0; i < U.base.length; i++) {
            var n = U.base[i];
            if (!isActiveSlot(n)) continue;
            drawFace(ctx, cx, cy, n, baseCenter(i), radius, ICON_BASE, anim(n).s, 1, (360 / SLOTS) / 2 - SECTOR_GAP_DEG / 2);
        }
    }
    function drawFace(ctx, cx, cy, n, angleDeg, radius, iconBase, hv, alpha, sectorHalfDeg) {
        var rad = angleDeg * Math.PI / 180, x = cx + Math.cos(rad) * radius, y = cy + Math.sin(rad) * radius - 3;
        var maxWidth = Math.max(28, Math.round(2 * radius * Math.sin(sectorHalfDeg * Math.PI / 180)));
        var face = val(n, "faceText"), color = val(n, "labelColor");
        if (face) {
            if (alpha >= 0.4) {
                var sc = 1.5 + 0.25 * hv;
                ctx.textStyled(String(face), x, y - 4 * sc, sc, color, 1, 0.5, FONT, "#000000");
            }
        } else {
            var ic = val(n, "icon");
            if (ic) {
                var size = iconBase + 4 * hv, tint = val(n, "tint");
                ctx.quad(ic, x - size / 2, y - size / 2, size, size, 0, 0, 1, 1, tint || WHITE, alpha);
            }
        }
        if (alpha < 0.4) return;
        var label = val(n, "label");
        if (!label) return;
        var lines = wrap(ctx, String(label), maxWidth), startY = Math.round(y + (iconBase + 4 * hv) / 2 + 2), centerX = Math.round(x);
        for (var i = 0; i < lines.length; i++) ctx.textStyled(lines[i], centerX, startY + i * 9, 1, color, 1, 0.5, FONT, "#000000");
    }
    function wrap(ctx, text, maxWidth) {           // TextUtil.wrap (font.split)
        var ck = text + "\u0000" + maxWidth;
        if (WRAP[ck]) return WRAP[ck];
        var out = [], line = "";
        function width(s) { return ctx.textWidthIn(s, FONT); }
        String(text).split(" ").forEach(function (word) {
            var tryLine = line ? line + " " + word : word;
            if (width(tryLine) <= maxWidth) { line = tryLine; return; }
            if (line) out.push(line);
            line = "";
            while (width(word) > maxWidth && word.length > 1) {
                var cut = word.length - 1;
                while (cut > 1 && width(word.substring(0, cut)) > maxWidth) cut--;
                out.push(word.substring(0, cut));
                word = word.substring(cut);
            }
            line = word;
        });
        if (line || !out.length) out.push(line);
        WRAP[ck] = out;
        return out;
    }
    function truncate(ctx, text, width) {          // font.plainSubstrByWidth
        var ck = text + "\u0000" + width;
        if (TRUNC[ck] !== undefined) return TRUNC[ck];
        var t = text;
        while (t.length && ctx.textWidthIn(t, FONT) > width) t = t.substring(0, t.length - 1);
        TRUNC[ck] = t;
        return t;
    }

    // ---- the option panel ------------------------------------------------------------
    function visiblePanelRows() { var total = U.panel.options.length; return U.panel.scrollable ? Math.min(total, PANEL_MAX_ROWS) : total; }
    function panelBounds(cx, cy) {
        var rows = visiblePanelRows(), height = PANEL_TITLE_H + rows * PANEL_ROW_H + PANEL_PAD;
        var rad = U.panel.angle * Math.PI / 180, clear = radiusForLevel(U.panel.level) + CHILD_BAND * 0.6 + PANEL_CLEAR_GAP;
        var px = Math.round(cx + Math.cos(rad) * clear - PANEL_WIDTH / 2), py = Math.round(cy + Math.sin(rad) * clear - height / 2);
        px = clamp(px, PANEL_SCREEN_MARGIN, Math.max(PANEL_SCREEN_MARGIN, U.w - PANEL_WIDTH - PANEL_SCREEN_MARGIN));
        py = clamp(py, PANEL_SCREEN_MARGIN, Math.max(PANEL_SCREEN_MARGIN, U.h - height - PANEL_SCREEN_MARGIN));
        return [px, py, PANEL_WIDTH, height];
    }
    function maxScrollRows() { return Math.max(0, U.panel.options.length - PANEL_MAX_ROWS); }
    function rowIndexAt(rowsTop, y) { return Math.floor((y - rowsTop) / PANEL_ROW_H); }
    function rowBorder(ctx, x0, y0, x1, y1, color) {
        ctx.fill(x0, y0, x1 - x0, 1, color, 1); ctx.fill(x0, y1 - 1, x1 - x0, 1, color, 1);
        ctx.fill(x0, y0, 1, y1 - y0, color, 1); ctx.fill(x1 - 1, y0, 1, y1 - y0, color, 1);
    }
    function scrollThumb(trackTop, trackLen) {
        var total = U.panel.options.length * PANEL_ROW_H, view = trackLen, maxS = maxScrollRows() * PANEL_ROW_H;
        var thumb = clamp(trackLen * view / (view + maxS), Math.min(6, trackLen), trackLen);
        var start = trackTop + (trackLen - thumb) * (maxS > 0 ? clamp(U.panel.scroll * PANEL_ROW_H / maxS, 0, 1) : 0);
        return { start: start, size: thumb, total: total };
    }
    function drawPanel(ctx, cx, cy, mx, my) {
        var P = U.panel, opts = P.options, rowsVis = visiblePanelRows(), b = panelBounds(cx, cy), px = b[0], py = b[1], pw = b[2], ph = b[3];
        ctx.fill(px - 1, py - 1, pw + 2, ph + 2, "#000000", 1);
        ctx.fill(px, py, pw, ph, "#141420", 0xF0 / 255);
        ctx.fill(px, py, pw, PANEL_TITLE_H, "#FFFFFF", 0x30 / 255);
        ctx.textStyled(P.title || T("gui.dragonminez.radial.options", "Options"), Math.round(px + pw / 2), py + 4, 1, WHITE, 1, 0.5, FONT, "#000000");
        var rowsTop = py + PANEL_TITLE_H, canScroll = P.scrollable && maxScrollRows() > 0;
        var textWidth = pw - 12 - (canScroll ? 4 : 0);
        var first = P.scrollable ? P.scroll : 0, count = P.scrollable ? rowsVis : opts.length;
        var inRows = mx >= px && mx <= px + pw && my >= rowsTop && my < rowsTop + rowsVis * PANEL_ROW_H;
        for (var r = 0; r < count; r++) {
            var i = first + r, node = opts[i];
            if (!node) break;
            var ry = rowsTop + r * PANEL_ROW_H, dragged = !P.scrollable && U.dragging && i === U.dragIndex;
            var drawY = dragged ? Math.round(U.dragY - PANEL_ROW_H / 2) : ry;
            var hovered = !U.dragging && inRows && my >= ry && my < ry + PANEL_ROW_H;
            if (hovered) ctx.fill(px + 1, ry, pw - 2, PANEL_ROW_H - 1, "#000000", 0x55 / 255);
            if (dragged) ctx.fill(px + 1, drawY, pw - 2, PANEL_ROW_H - 1, "#FFFFFF", 0x33 / 255);
            if (val(node, "active")) rowBorder(ctx, px + 1, drawY, px + pw - 1, drawY + PANEL_ROW_H - 1, "#3BE05A");
            ctx.textStyled(truncate(ctx, String(val(node, "label")), textWidth), px + 6, drawY + 3, 1, val(node, "labelColor"), 1, 0, FONT, "#000000");
        }
        if (canScroll) {
            var trackLen = rowsVis * PANEL_ROW_H, th = scrollThumb(rowsTop, trackLen), bx = px + pw - 3;
            var overThumb = mx >= bx - 1 && mx <= bx + 3 && my >= th.start && my <= th.start + th.size;
            ctx.fill(bx, rowsTop, 2, trackLen, "#FFFFFF", 0x40 / 255);
            ctx.fill(bx, th.start, 2, th.size, "#FFFFFF", U.barDrag || overThumb ? 1 : 0xC0 / 255);
        }
        if (!P.scrollable && U.dragging && U.dragIndex >= 0) {
            var target = clamp(rowIndexAt(rowsTop, my), 0, opts.length);
            ctx.fill(px + 2, rowsTop + target * PANEL_ROW_H - 1, pw - 4, 1, WHITE, 1);
        }
    }
    function openPanel(options, title, hover, scrollable, more) {
        U.panel = { options: options, title: title, scrollable: scrollable, angle: hover.angle, level: hover.level, more: more || null, scroll: 0 };
        U.frozen = hover;
    }
    function closePanel() { U.panel = null; U.dragIndex = -1; U.dragging = false; U.barDrag = null; }
    function selectNode(n) {
        if (!n || !val(n, "interactive")) return;
        var now = RPG.nowMs(), dbl = U.lastClick === n.key && now - U.lastClickMs <= DOUBLE_CLICK_MS;
        U.lastClick = n.key; U.lastClickMs = dbl ? 0 : now;
        if (dbl && n.onDoubleSelect) n.onDoubleSelect(); else if (n.onSelect) n.onSelect();
    }
    function findPathTo(cur, target, out) {
        if (cur === target) return true;
        for (var i = 0; i < cur.kids.length; i++) if (findPathTo(cur.kids[i], target, out)) { out.unshift(cur.kids[i]); return true; }
        return false;
    }
    function findMore(n, categoryKey) {
        for (var i = 0; i < n.kids.length; i++) {
            var c = n.kids[i];
            if (c.kind === "more" && c.categoryKey === categoryKey) return c;
            var deep = findMore(c, categoryKey);
            if (deep) return deep;
        }
        return null;
    }
    function refreshMorePanel(categoryKey) {
        var found = null;
        U.base.forEach(function (b) { if (!found) found = findMore(b, categoryKey); });
        if (!found || !U.panel) return;
        U.panel.more = found; U.panel.options = found.options;
        var h = newHover();
        U.base.forEach(function (b) {
            if (h.deepest) return;
            var path = [];
            if (findPathTo(b, found, path)) {
                path.pop();                     // findPathTo puts the target at the end
                addPath(h, b); path.forEach(function (p) { addPath(h, p); }); addPath(h, found);
                h.deepest = found; h.angle = U.frozen.angle; h.level = U.frozen.level;
            }
        });
        U.frozen = h;
    }
    function reorderOption(from, to) {
        var P = U.panel;
        if (!P || !P.more) return;
        var opts = P.more.options;
        if (from < 0 || from >= opts.length || from === to) return;
        var moved = opts.splice(from, 1)[0];
        if (to > from) to--;
        to = clamp(to, 0, opts.length);
        opts.splice(to, 0, moved);
        var keys = [], orderable = true;
        opts.forEach(function (n) { if (!n.orderKey) orderable = false; else keys.push(n.orderKey); });
        var categoryKey = P.more.categoryKey;
        if (orderable) {
            var store = layout();
            store[categoryKey] = keys;
            try { RPG.storage.set(LAYOUT_KEY, store); } catch (e) { }
        }
        rebuild();
        refreshMorePanel(categoryKey);
    }

    // ---- input -----------------------------------------------------------------------
    function toUi(x) { return x / U.scale; }
    function onMouse(x, y, button, action) {
        if (!U) return false;
        var ux = toUi(x), uy = toUi(y), cx = U.w / 2, cy = U.h / 2;
        if (action === "up") {
            if (U.barDrag) { U.barDrag = null; return false; }
            if (U.panel && !U.panel.scrollable && U.dragIndex >= 0) {
                if (!U.dragging) selectNode(U.panel.options[U.dragIndex]);
                else {
                    var bb = panelBounds(cx, cy);
                    reorderOption(U.dragIndex, clamp(rowIndexAt(bb[1] + PANEL_TITLE_H, uy), 0, U.panel.options.length));
                }
                U.dragIndex = -1; U.dragging = false;
            }
            return false;
        }
        if (U.closing || !S) return false;
        if (U.panel) {
            var b = panelBounds(cx, cy);
            if (!(ux >= b[0] && ux <= b[0] + b[2] && uy >= b[1] && uy <= b[1] + b[3])) { closePanel(); return false; }
            var rowsTop = b[1] + PANEL_TITLE_H;
            if (U.panel.scrollable) {
                var rowsVis = visiblePanelRows(), bx = b[0] + b[2] - 3;
                if (button === 0 && maxScrollRows() > 0 && ux >= bx - 1 && ux <= bx + 3 && uy >= rowsTop && uy < rowsTop + rowsVis * PANEL_ROW_H) {
                    var th = scrollThumb(rowsTop, rowsVis * PANEL_ROW_H);
                    var onThumb = uy >= th.start && uy <= th.start + th.size;
                    U.barDrag = { offset: onThumb ? uy - th.start : th.size / 2, top: rowsTop, len: rowsVis * PANEL_ROW_H, size: th.size };
                    dragBar(uy);
                    return false;
                }
                var rel = uy - rowsTop;
                if (rel >= 0 && rel < rowsVis * PANEL_ROW_H) {
                    var i = Math.floor(rel / PANEL_ROW_H) + U.panel.scroll;
                    if (i >= 0 && i < U.panel.options.length) selectNode(U.panel.options[i]);
                }
                return false;
            }
            var idx = rowIndexAt(rowsTop, uy);
            if (idx >= 0 && idx < U.panel.options.length) { U.dragIndex = idx; U.dragStartY = uy; U.dragY = uy; U.dragging = false; }
            return false;
        }
        var hover = resolveHover(cx, cy, ux, uy, computeOpenScale(RPG.nowMs()));
        var n = hover.deepest;
        if (!n) return false;
        if (n.kind === "more") { openPanel(n.options, T("gui.dragonminez.radial.options", "Options"), hover, false, n); return false; }
        if (n.kind === "release" || n.kind === "flightspeed") {
            if (val(n, "active")) { n.onSelect(); return false; }
            openPanel(n.buildOptions(), val(n, "label"), hover, true, null);
            return false;
        }
        if (n.kind === "form" && val(n, "interactive")) { selectNode(n); return false; }
        if ((n.kind === "racial" || n.kind === "fly") && val(n, "interactive")) { n.onSelect(); return false; }
        if (val(n, "interactive") && !val(n, "expandable") && n.onSelect) n.onSelect();
        return false;
    }
    function dragBar(uy) {
        var d = U.barDrag, travel = d.len - d.size, maxRows = maxScrollRows();
        if (travel <= 0 || maxRows <= 0) return;
        U.panel.scroll = Math.round(clamp((uy - d.offset - d.top) / travel, 0, 1) * maxRows);
    }
    function onScroll(x, y, delta) {
        if (!U || !S) return;
        var ux = toUi(x), uy = toUi(y);
        if (!U.panel) {
            var h = resolveHover(U.w / 2, U.h / 2, ux, uy, computeOpenScale(RPG.nowMs()));
            if (h.deepest && h.deepest.adjustByWheel) { h.deepest.adjustByWheel(delta); return; }
        }
        if (U.panel && U.panel.scrollable && maxScrollRows() > 0 && delta) U.panel.scroll = clamp(U.panel.scroll - (delta > 0 ? 1 : -1), 0, maxScrollRows());
    }
    function onKey(key) {
        if (!U) return;
        if (key === "key.keyboard.escape") {
            if (U.panel) closePanel(); else startClosing();
            return false;
        }
        if (key === U.holdKey) {              // KeyBinds.UTILITY_MENU is swallowed; a tap-opened menu closes on it
            if (!U.hold) startClosing();
            return false;
        }
    }
    function startClosing() { if (U && !U.closing) { U.closing = true; U.closeStart = RPG.nowMs(); } }

    // ---- per frame -------------------------------------------------------------------
    function rebuild() {
        U.base = buildBaseNodes();
        U.sig = treeSig();
        // keep the hover chain on the rebuilt nodes (same keys)
        var chain = [], parentList = U.base;
        for (var i = 0; i < U.chain.length; i++) {
            var idx = indexByKey(parentList, U.chain[i].key);
            if (idx < 0) break;
            chain.push(parentList[idx]);
            parentList = parentList[idx].kids;
        }
        U.chain = chain;
        if (U.panel && U.panel.more) refreshMorePanel(U.panel.more.categoryKey);
        else if (U.frozen) U.frozen = remapHover(U.frozen);
    }
    function remapHover(h) {
        var out = newHover(), list = U.base;
        for (var i = 0; i < h.path.length; i++) {
            var idx = indexByKey(list, h.path[i].key);
            if (idx < 0) break;
            addPath(out, list[idx]); out.deepest = list[idx];
            list = list[idx].kids;
        }
        out.angle = h.angle; out.level = h.level;
        return out;
    }
    function treeSig() {
        var r = S && S.racial ? (S.racial.slots || []).join(",") : "";
        return stateSerial + "|" + V.race + "|" + bioTier() + "|" + r + "|" + V.android + "|" + ADDON_SLOTS.length;
    }
    function updateModel(openScale, cx, cy) {
        var pv = U.preview, ck = U.previewKey + "|" + stateSerial + "|" + V.form;
        if (U.lookKey !== ck) { U.lookKey = ck; U.look = previewLook(pv); U.lookScale = modelScaleFor(pv); U.lookSig = U.look ? U.look.key + JSON.stringify(U.look.colors) : ""; }
        var lk = U.look;
        var size = Math.max(1, Math.round(MODEL_SCALE * openScale * U.lookScale * U.scale));
        var mx = Math.round(cx * U.scale), my = Math.round((cy + MODEL_Y_OFFSET * openScale + 12 * openScale) * U.scale);
        var sig = mx + "|" + my + "|" + size + "|" + U.lookSig;
        if (sig === U.modelSig) return;
        U.modelSig = sig;
        RPG.screen.update("model", { type: "entity", x: mx - 60, y: my - 160, w: 120, h: 160, modelX: 60, modelY: 160, size: size,
            rotation: 180, tilt: 0, look: lk ? { key: lk.key, colors: lk.colors } : null, visible: true });
    }
    function render(ctx) {
        if (!U) return;
        frame++;
        var now = RPG.nowMs();
        U.dt = U.last ? Math.min(0.1, (now - U.last) / 1000) : 0;
        U.last = now;
        if (!V || frame % 3 === 0) V = snapshot();
        if (treeSig() !== U.sig) rebuild();
        // hold-to-open: releasing X closes, like ForgeClientEvents.handleUtilityMenuHold
        if (U.hold && !U.closing && !RPG.isKeyDown(U.holdKey)) startClosing();
        if (U.closing && now - U.closeStart >= ANIMATION_DURATION) { close(); return; }
        U.scale = uiScaleFor(ctx.width, ctx.height);
        U.w = Math.max(1, Math.round(ctx.width / U.scale)); U.h = Math.max(1, Math.round(ctx.height / U.scale));
        var openScale = computeOpenScale(now), mx = ctx.mouseX / U.scale, my = ctx.mouseY / U.scale;
        var cx = U.w / 2, cy = U.h / 2;
        if (U.dragIndex >= 0 && U.panel && !U.panel.scrollable) {          // mouseDragged
            if (Math.abs(my - U.dragStartY) > 3) U.dragging = true;
            U.dragY = my;
        }
        if (U.barDrag && U.panel) dragBar(my);
        var hover = U.closing || !S ? newHover() : U.panel ? U.frozen : resolveHover(cx, cy, mx, my, openScale);
        var pv = hover.deepest && hover.deepest.preview ? hover.deepest.preview() : null;
        var pvKey = pv ? pv.g + ":" + pv.f + ":" + pv.stack : "";
        if (pvKey !== U.previewKey) { U.previewKey = pvKey; U.preview = pv; }
        updateModel(openScale, cx, cy);
        ctx.push();
        ctx.scale(U.scale, U.scale);
        drawBaseSectors(ctx, cx, cy, hover, openScale);
        U.base.forEach(function (n, i) { if (isActiveSlot(n)) drawChildSectors(ctx, cx, cy, n, baseCenter(i), 1, hover, false, openScale); });
        drawBaseFaces(ctx, cx, cy, openScale);
        U.base.forEach(function (n, i) { if (isActiveSlot(n)) drawChildSectors(ctx, cx, cy, n, baseCenter(i), 1, hover, true, openScale); });
        if (U.panel) drawPanel(ctx, cx, cy, mx, my);
        ctx.pop();
    }

    // ---- open / close ----------------------------------------------------------------
    function open() {
        if (!S) return;
        if (U) { V = snapshot(); rebuild(); return; }
        var holdKey = "key.keyboard.x";
        U = { openTime: RPG.nowMs(), closing: false, closeStart: 0, last: 0, dt: 0, scale: 1, w: 1, h: 1,
            base: [], chain: [], panel: null, frozen: newHover(), dragIndex: -1, dragging: false, dragStartY: 0, dragY: 0, barDrag: null,
            lastClick: null, lastClickMs: 0, preview: null, previewKey: "", modelSig: "", sig: "", lookKey: null, look: null, lookScale: 1, lookSig: "",
            holdKey: holdKey, hold: RPG.isKeyDown(holdKey) };
        V = snapshot();
        rebuild();
        RPG.screen.open({ id: ID, background: "none", pause: false, closeOnEsc: false,
            elements: [{ id: "model", type: "entity", x: -1000, y: -1000, w: 1, h: 1, size: 1, rotation: 180, visible: false }],
            onRender: render, onMouse: onMouse, onScroll: onScroll, onKey: onKey,
            onClose: function () { U = null; } });
        RPG.sound("dmzpack:ui_menu_switch", 1, 1);
    }
    function close() {
        U = null;
        if (RPG.screen.getOpen() === ID) RPG.screen.close();
    }

    RPG.net.on("dmz_tf_state", function (d) {
        S = d; stateSerial++;
        WRAP = {}; TRUNC = {};
        if (d && d.open) open();
        else if (U && RPG.screen.getOpen() === ID) { V = snapshot(); rebuild(); }
    });

    return {
        open: open, close: close, state: function () { return S; },
        /** UtilityMenuScreen.addMenuSlot: {render(stats) -> {line1, line2, selected}, handle(stats, rightClick)} fills slots 2 and 6. */
        addMenuSlot: function (slot) { if (slot && typeof slot.render === "function") ADDON_SLOTS.push(slot); },
        _test: { childArcDeg: childArcDeg, baseSlotAt: baseSlotAt, uiScaleFor: uiScaleFor, buildBaseNodes: function () { V = snapshot(); return buildBaseNodes(); },
            render: render, onMouse: onMouse, onScroll: onScroll, onKey: onKey, U: function () { return U; }, SECTOR_LEVELS: SECTOR_LEVELS }
    };
})();
var DMZ_TF_MENU = DMZ_RADIAL;           // older name
