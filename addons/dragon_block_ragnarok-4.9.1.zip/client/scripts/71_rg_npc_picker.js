// =====================================================================================
//  71_rg_npc_picker.js - picker for DMZ Ragnarok's rgnpc cast (/rpgc rgnpc picker, ops)
// =====================================================================================
//  A searchable list of every model in shared/14_rg_npc_data.js. Clicking one asks the server
//  (scripts/62_rg_npcs.js, "rg_npc_picker") to spawn it in front of you. Scroll or use the
//  arrows to page; the search matches id, name and group.
// =====================================================================================
(function () {
    var COLS = 3, ROWS = 12, PER = COLS * ROWS, BW = 128, BH = 14, GAP = 2;
    var W = COLS * BW + (COLS - 1) * GAP + 16, H = ROWS * (BH + GAP) + 64;
    var st = { filter: "", page: 0, list: RG_NPC_MODELS };

    function apply() {
        var f = st.filter.toLowerCase();
        st.list = RG_NPC_MODELS.filter(function (r) {
            return !f || r[0].indexOf(f) >= 0 || r[5].toLowerCase().indexOf(f) >= 0 || r[6].toLowerCase().indexOf(f) >= 0;
        });
        var pages = Math.max(1, Math.ceil(st.list.length / PER));
        st.page = Math.max(0, Math.min(st.page, pages - 1));
        for (var i = 0; i < PER; i++) {
            var r = st.list[st.page * PER + i];
            RPG.screen.update("b" + i, r ? { visible: true, label: r[5], tooltip: { title: r[5], lines: ["&7" + r[6], "&8" + r[0]] } } : { visible: false });
        }
        RPG.screen.update("page", { text: "&7" + (st.page + 1) + " / " + pages + "  &8(" + st.list.length + " models)" });
    }

    function open() {
        var x0 = -W / 2 + 8, y0 = -H / 2 + 40, els = [
            { id: "bg", type: "rect", anchor: "center", x: -W / 2, y: -H / 2, w: W, h: H, color: "#E0000D32" },
            { id: "edge", type: "rect", anchor: "center", x: -W / 2, y: -H / 2, w: W, h: 2, color: "#FFDD9923" },
            { id: "title", type: "text", anchor: "center", x: 0, y: -H / 2 + 6, text: "&6DMZ Ragnarok NPCs", align: "center", font: "dmzpack:smooth" },
            { id: "search", type: "input", anchor: "center", x: x0, y: -H / 2 + 20, w: W - 16 - 44, h: 14, value: st.filter, maxLength: 40, autofocus: true,
              onChange: function (id, v) { st.filter = String(v || ""); st.page = 0; apply(); } },
            { id: "prev", type: "button", anchor: "center", x: W / 2 - 50, y: -H / 2 + 20, w: 20, h: 14, label: "<", onClick: function () { st.page--; apply(); } },
            { id: "next", type: "button", anchor: "center", x: W / 2 - 28, y: -H / 2 + 20, w: 20, h: 14, label: ">", onClick: function () { st.page++; apply(); } },
            { id: "page", type: "text", anchor: "center", x: 0, y: H / 2 - 14, text: "", align: "center" }
        ];
        for (var i = 0; i < PER; i++) (function (i) {
            els.push({ id: "b" + i, type: "button", anchor: "center", x: x0 + (i % COLS) * (BW + GAP), y: y0 + Math.floor(i / COLS) * (BH + GAP),
                w: BW, h: BH, label: "", onClick: function () {
                    var r = st.list[st.page * PER + i];
                    if (r) RPG.net.send("rg_npc_picker", { spawn: r[0] });
                } });
        })(i);
        RPG.screen.open({ id: "rg_npc_picker", referenceHeight: 270, closeOnEsc: true, elements: els,
            onScroll: function (x, y, d) { st.page += d < 0 ? 1 : -1; apply(); } });
        apply();
    }

    RPG.net.on("rg_npc_picker", function (d) { if (d && d.open) open(); });
})();
