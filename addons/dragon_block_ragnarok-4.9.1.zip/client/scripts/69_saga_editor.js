// =====================================================================================
//  69_saga_editor.js - the in-game saga editor for operators (/rpgc sagaeditor)
// =====================================================================================
//  Ported from DMZ Ragnarok (GPL-3.0): client/gui/saga/SagaListScreen -> SagaEditScreen ->
//  QuestEditScreen -> Objective / Reward / ConditionEditScreen, plus SideQuestListScreen /
//  SideQuestEditScreen, with the fields of sdu/saga/SagaData and SideQuestData. Drawn in
//  DMZ's style (questmenu panel, characterbuttons buttons / switches / arrows, smooth font).
//
//  Also receives the custom sagas for everyone ("dbr_sagas", in pieces) and merges them into
//  DMZ_QUEST_DATA (DMZ_QL.setCustom), so the quest screen shows them. Saving / deleting goes
//  to the server (scripts/48_dbr_saga_editor.js), which checks the player is an operator.
// =====================================================================================
var DBR_SAGA_EDITOR_CLIENT = null;
(function () {
    var U = DMZ_UI, QL = DMZ_QL, FONT = U.FONT, BUTTONS = U.BUTTONS;
    var PW = 400, PH = 300, CHUNK = 9000, TS = 0.8;      // 9000 chars stays under ~30 KB even as 3-byte UTF-8

    // ---- choices (SagaData.OBJECTIVE_TYPES / REWARD_TYPES / CONDITION_TYPES, plus DMZ types the defaults use) ----
    var OBJ_TYPES = ["KILL", "TALK_TO", "ITEM", "DIMENSION", "BIOME", "STRUCTURE", "COORDS", "SKILL", "SPAR", "DELIVER", "SURVIVE_WAVES", "DRAGON_SUMMON"];
    var REW_TYPES = ["TPS", "ITEM", "SKILL", "TECHNIQUE", "COMMAND", "FORM_PURCHASE", "ATTRIBUTES", "ALIGNMENT"];
    var COND_TYPES = ["LEVEL", "DIMENSION", "BIOME", "ALIGNMENT", "TIME", "RACE"];
    var PREREQ_TYPES = COND_TYPES.concat(["SAGA_QUEST", "QUEST"]);
    var SIDE_TYPES = ["SIDEQUEST", "DAILY", "EVENT"];
    var DMZ_NPCS = ["roshi", "goku", "krillin", "gohan", "piccolo", "bulma", "dende", "guru", "popo", "oldkai", "mr_satan", "trunks", "karin",
        "baba_earth", "kingkai", "tien", "yamcha", "vegeta"];
    var LISTS = {
        dimension: ["minecraft:overworld", "minecraft:the_nether", "minecraft:the_end", "dragonminez:namek", "dragonminez:otherworld", "dragonminez:time_chamber"],
        biome: ["minecraft:plains", "minecraft:desert", "minecraft:forest", "minecraft:jungle", "minecraft:savanna", "minecraft:snowy_plains", "minecraft:badlands",
            "minecraft:mountains", "#minecraft:is_ocean", "#minecraft:is_beach", "#minecraft:is_river", "#minecraft:is_forest", "#dragonminez:is_plains"],
        // DMZ's structures (built by 65_dmz_structures.js / 66_dmz_sites.js) and generated ones (RPG.world.isInStructure)
        structure: ["dragonminez:goku_house", "dragonminez:roshi_house", "dragonminez:elder_guru", "dragonminez:timechamber", "dragonminez:kamilookout",
            "dragonminez:gero_lab", "dragonminez:village_ajissa", "dragonminez:village_sacred", "dragonminez:baba_palace", "dragonminez:babidi",
            "dragonminez:buu_house", "dragonminez:cell_arena", "dragonminez:frieza_ship", "dragonminez:namek_ruins", "dragonminez:oldkai_pillar",
            "dragonminez:piccolo_house", "dragonminez:rrtower", "dragonminez:red_ribbon_base", "dragonminez:trunks_ship", "dragonminez:vegeta_pod",
            "dragonminez:yamcha_house", "dragonminez:budokai_tenkaichi", "#minecraft:village", "minecraft:village_plains", "minecraft:village_desert",
            "minecraft:village_savanna", "minecraft:village_snowy", "minecraft:village_taiga", "minecraft:pillager_outpost"],
        race: (typeof DMZ_DATA !== "undefined" && DMZ_DATA.RACES) || ["human", "saiyan", "namekian", "frostdemon", "bioandroid", "majin"],
        dragon: ["shenron", "porunga"]
    };
    function defIds(type) { try { return (RPG.defIds(type) || []).slice(); } catch (e) { return []; } }
    function uniq(a) { var seen = {}; return a.filter(function (x) { if (!x || seen[x]) return false; seen[x] = 1; return true; }); }
    var lazy = {};
    function list(name) {
        if (name === "sagaIds") return uniq(allSagaIds());
        if (LISTS[name]) return LISTS[name];
        if (lazy[name]) return lazy[name];
        var out = [];
        if (name === "entity") out = Object.keys(QL.DATA.entities || {}).concat(["minecraft:zombie", "minecraft:skeleton", "minecraft:spider", "minecraft:husk"],
            defIds("mob").map(function (m) { return "rpg:" + m; }));
        else if (name === "item") out = ["minecraft:diamond", "minecraft:iron_ingot", "minecraft:gold_ingot", "minecraft:emerald", "minecraft:bread"].concat(defIds("item"));
        else if (name === "npc") out = DMZ_NPCS.concat(defIds("npc"));
        else if (name === "skill") {
            if (typeof DMZ_SKILLS_DATA !== "undefined") {
                Object.keys(DMZ_SKILLS_DATA.OFFERINGS || {}).forEach(function (k) { out = out.concat(DMZ_SKILLS_DATA.OFFERINGS[k]); });
                out = out.concat(DMZ_SKILLS_DATA.FORM_SKILLS || [], DMZ_SKILLS_DATA.STACK_SKILLS || []);
                out = out.filter(function (s) { return !DMZ_SKILLS_DATA.isTechnique || !DMZ_SKILLS_DATA.isTechnique(s); });
            }
            out = ["fly", "jump", "kicontrol", "meditation", "potential_unlock"].concat(out);
        } else if (name === "technique") out = typeof DMZ_TECH_DATA !== "undefined" ? DMZ_TECH_DATA.all() : ["kamehameha"];
        else if (name === "form") {
            if (typeof DMZ_FORMS !== "undefined") Object.keys(DMZ_FORMS.GROUPS || {}).forEach(function (r) {
                DMZ_FORMS.GROUPS[r].forEach(function (g) { (g.forms || []).forEach(function (f) { out.push(g.id + "." + f.id); }); });
            });
        }
        return (lazy[name] = uniq(out));
    }

    // fields per type: [key, label, kind, tip]. kinds: text, int, num, pick:<list>, cycle:<name>, bool, time
    var OBJ_FIELDS = {
        KILL: [["entity", "Entity", "pick:entity", "What to fight. DMZ saga enemies, rpg:<mob> for our mobs, or any entity id"], ["count", "Count", "int"],
            ["health", "Health", "num"], ["meleeDamage", "Melee damage", "num"], ["kiDamage", "Ki damage", "num"], ["AITier", "AI tier", "cycle:aitier"],
            ["sdu_defer_spawn", "Spawn at location", "bool", "Hold the enemies back until the player reaches this quest's COORDS objective"]],
        SPAR: [["entity", "Partner", "pick:entity"], ["count", "Count", "int"], ["health", "Health", "num"], ["meleeDamage", "Melee damage", "num"], ["kiDamage", "Ki damage", "num"]],
        TALK_TO: [["npcId", "NPC id", "pick:npc", "A DMZ npc id (roshi, goku...) or one of our NPC ids"],
            ["sdu_talk_npc_name", "NPC name", "text", "Talking to any NPC with exactly this name also counts"]],
        ITEM: [["item", "Item", "pick:item"], ["count", "Count", "int"]],
        DELIVER: [["item", "Item", "pick:item"], ["count", "Count", "int"], ["npcId", "To NPC", "pick:npc"]],
        DIMENSION: [["dimension", "Dimension", "pick:dimension"]],
        BIOME: [["biome", "Biome", "pick:biome", "A biome id or #tag"]],
        STRUCTURE: [["structure", "Structure", "pick:structure", "A DMZ structure, or any generated structure id or #tag (vanilla, data packs)"]],
        COORDS: [["x", "X", "int"], ["y", "Y", "int"], ["z", "Z", "int"], ["radius", "Radius", "int", "How close counts as arrived (blocks)"]],
        SKILL: [["skill", "Skill", "pick:skill"], ["level", "Level", "int"]],
        SURVIVE_WAVES: [["entity", "Entity", "pick:entity"], ["waves", "Waves", "int"], ["mobs_per_wave", "Per wave", "int"], ["wave_delay_seconds", "Delay (s)", "int"],
            ["health", "Health", "num"], ["meleeDamage", "Melee damage", "num"]],
        DRAGON_SUMMON: [["dragon", "Dragon", "pick:dragon"]]
    };
    var OBJ_DEF = {
        KILL: { entity: "dragonminez:saga_raditz", count: 1, health: 100, meleeDamage: 10, kiDamage: 20, spawn: "QUEST", count_mode: "QUEST_SPAWNED_ONLY" },
        SPAR: { entity: "dragonminez:saga_krillin", count: 1, health: 100, meleeDamage: 10, kiDamage: 20, spawn: "QUEST", count_mode: "QUEST_SPAWNED_ONLY" },
        TALK_TO: { npcId: "roshi" }, ITEM: { item: "minecraft:diamond", count: 1 }, DELIVER: { item: "minecraft:diamond", count: 1, npcId: "roshi" },
        DIMENSION: { dimension: "minecraft:overworld" }, BIOME: { biome: "minecraft:plains" }, STRUCTURE: { structure: "dragonminez:roshi_house" },
        COORDS: { x: 0, y: 64, z: 0, radius: 4 }, SKILL: { skill: "fly", level: 1 },
        SURVIVE_WAVES: { entity: "dragonminez:saga_friezasoldier01", waves: 3, mobs_per_wave: 2, wave_delay_seconds: 8, health: 60, meleeDamage: 6, spawn: "QUEST" },
        DRAGON_SUMMON: { dragon: "shenron" }
    };
    var REW_FIELDS = {
        TPS: [["amount", "Amount", "int"]], ATTRIBUTES: [["amount", "Attributes", "int", "DMZ attribute reward: half stat points, half TP"]],
        ALIGNMENT: [["amount", "Alignment", "int"]],
        ITEM: [["item", "Item", "pick:item"], ["count", "Count", "int"], ["nbt", "NBT", "text", "Optional SNBT {...} (enchantments, a name...). Given with /give"]],
        SKILL: [["skill", "Skill", "pick:skill"], ["level", "Level", "int"]], TECHNIQUE: [["technique", "Technique", "pick:technique"]],
        COMMAND: [["command", "Command", "text", "Run by the server; %player% is the player's name"]],
        FORM_PURCHASE: [["form", "Form", "pick:form", "Lets the player buy this form (group.form); nothing is given"]]
    };
    var REW_DEF = { TPS: { amount: 1000 }, ATTRIBUTES: { amount: 5 }, ALIGNMENT: { amount: 5 }, ITEM: { item: "minecraft:diamond", count: 1 }, SKILL: { skill: "fly", level: 1 },
        TECHNIQUE: { technique: "kamehameha" }, COMMAND: { command: "say %player% finished a quest" }, FORM_PURCHASE: { form: "" } };
    var COND_FIELDS = {
        LEVEL: [["minLevel", "Min level", "int"]], DIMENSION: [["dimension", "Dimension", "pick:dimension"]], BIOME: [["biome", "Biome", "pick:biome"]],
        ALIGNMENT: [["min", "Min", "int"], ["max", "Max", "int"]],
        TIME: [["mode", "Mode", "cycle:timemode", "GAME_TIME counts world ticks (20/s, 24000/day); REAL_TIME counts wall-clock milliseconds"],
            ["_time", "Delay", "time", "Starts once the other start requirements are met: how DMZ gates a daily quest"]],
        RACE: [["race", "Race", "pick:race"]], SAGA_QUEST: [["sagaId", "Saga id", "pick:saga"], ["questId", "Quest id", "int"]],
        QUEST: [["questId", "Quest id", "text", "A side quest id (or <saga>_b<id> for a branch quest)"]]
    };
    var COND_DEF = { LEVEL: { minLevel: 1 }, DIMENSION: { dimension: "minecraft:overworld" }, BIOME: { biome: "minecraft:plains" }, ALIGNMENT: { min: 0, max: 100 },
        TIME: { mode: "REAL_TIME", milliseconds: 86400000 }, RACE: { race: "human" }, SAGA_QUEST: { sagaId: "classic_saga", questId: 1 }, QUEST: { questId: "" } };
    var CYCLES = {
        aitier: [[-1, "Auto (difficulty)"], [1, "Simple"], [2, "Tactical"], [3, "Advanced"]],
        timemode: [["GAME_TIME", "Game time"], ["REAL_TIME", "Real time"]],
        claim: [["TREE_OR_NPC", "Tree or NPC"], ["NPC_ONLY", "NPC only"]]
    };

    // ---- summaries (SagaData.*.summary) ----
    function short(id) { return String(id || "?").replace(/^#?[a-z_]+:/, "").replace(/^saga_/, ""); }
    function dur(sec) {
        sec = Math.max(0, Math.round(sec));
        if (!sec) return "0s";
        var d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60, out = [];
        if (d) out.push(d + "d"); if (h) out.push(h + "h"); if (m) out.push(m + "m"); if (s && !d) out.push(s + "s");
        return out.slice(0, 2).join(" ");
    }
    function objSummary(o) {
        switch (o.type) {
            case "KILL": return "Kill " + (o.count || 1) + "x " + short(o.entity) + (o.sdu_defer_spawn ? " (at location)" : "");
            case "SPAR": return "Spar " + short(o.entity);
            case "TALK_TO": return "Talk to " + (o.sdu_talk_npc_name || o.npcId || "?");
            case "ITEM": return "Collect " + (o.count || 1) + "x " + short(o.item);
            case "DELIVER": return "Deliver " + (o.count || 1) + "x " + short(o.item) + " to " + o.npcId;
            case "DIMENSION": return "Reach " + short(o.dimension);
            case "BIOME": return "Reach " + short(o.biome);
            case "STRUCTURE": return "Find " + short(o.structure);
            case "COORDS": return "Go to " + o.x + " " + o.y + " " + o.z + " (r " + (o.radius || 4) + ")";
            case "SKILL": return "Skill " + o.skill + " lvl " + o.level;
            case "SURVIVE_WAVES": return "Survive " + o.waves + " waves of " + short(o.entity);
            case "DRAGON_SUMMON": return "Summon " + (o.dragon || "the dragon");
            default: return o.type;
        }
    }
    function rewSummary(r) {
        switch (r.type) {
            case "TPS": return r.amount + " TP";
            case "ATTRIBUTES": return r.amount + " attributes";
            case "ALIGNMENT": return (r.amount > 0 ? "+" : "") + r.amount + " alignment";
            case "ITEM": return (r.count || 1) + "x " + short(r.item) + (r.nbt ? " +nbt" : "");
            case "SKILL": return "Skill " + r.skill + " lvl " + r.level;
            case "TECHNIQUE": return "Technique " + (r.technique || r.id || "?");
            case "KI_TECHNIQUE": return "Technique " + (r.technique || r.id || r.code || "?");
            case "COMMAND": return "/" + r.command;
            case "FORM_PURCHASE": return "Form purchase: " + (r.form || "?");
            default: return r.type;
        }
    }
    function condSummary(c) {
        if (c.conditions) return (c.operator === "OR" ? "Any of " : "All of ") + c.conditions.length + " conditions";
        switch (c.type) {
            case "LEVEL": return "Level >= " + c.minLevel;
            case "DIMENSION": return "In " + short(c.dimension);
            case "BIOME": return "In " + short(c.biome);
            case "ALIGNMENT": return "Alignment " + c.min + "-" + c.max;
            case "TIME": return "After " + (c.mode === "GAME_TIME" ? dur((c.ticks || 0) / 20) + " game time" : dur((c.milliseconds || 0) / 1000));
            case "RACE": return "Race: " + c.race;
            case "SAGA_QUEST": return "Done " + c.sagaId + " #" + c.questId;
            case "QUEST": return "Done " + c.questId;
            case "STRUCTURE": return "Near " + short(c.structure);
            case "SKILL": return "Skill " + c.skill + " >= " + c.minLevel;
            default: return c.type;
        }
    }

    // ---- custom data from the server ----
    var inbox = {}, W = null, E = { open: false, token: 0, stack: [], widgets: [], clip: {}, showDefaults: false, confirm: null, closeArmed: 0 };
    RPG.net.on("dbr_sagas", function (d) {
        if (!d || typeof d.part !== "string") return;
        if (Object.keys(inbox).length > 8) inbox = {};
        var b = inbox[d.tx] || (inbox[d.tx] = { parts: [], got: 0, n: d.n || 1 });
        if (b.parts[d.i] === undefined) { b.parts[d.i] = d.part; b.got++; }
        if (d.open) b.open = true;
        if (b.got < b.n) return;
        delete inbox[d.tx];
        var data;
        try { data = JSON.parse(b.parts.join("")); } catch (e) { RPG.log("Saga editor: bad saga data from the server: " + e); return; }
        try { QL.setCustom(data.sagas || [], data.side || []); } catch (e2) { RPG.log("Saga editor: could not merge custom sagas: " + e2); }
        received(!!b.open);
    });
    RPG.schedule(30, function () { RPG.net.send("dbr_saga", { action: "sync" }); });

    function clone(o) { return JSON.parse(JSON.stringify(o)); }
    function resetWorking() {
        W = { sagas: QL.CUSTOM.sagas.map(function (b) { return { b: clone(b), orig: b.id, dirty: false }; }),
            side: QL.CUSTOM.side.map(function (q) { return { q: clone(q), orig: q.id, dirty: false }; }) };
    }
    function merge(entries, server, field) {
        var byId = {};
        server.forEach(function (x) { byId[x.id] = x; });
        var keep = entries.filter(function (en) {
            var id = en[field].id;
            if (en.pending && byId[QL.cleanId(id, "")]) { en[field] = clone(byId[QL.cleanId(id, "")]); en.orig = en[field].id; en.dirty = false; en.pending = false; return true; }
            if (en.dirty) return true;
            if (en.orig && byId[en.orig]) { en[field] = clone(byId[en.orig]); return true; }
            return false;                                       // deleted on the server
        });
        server.forEach(function (x) {
            if (!keep.some(function (en) { return en.orig === x.id || en[field].id === x.id; })) { var o = { orig: x.id, dirty: false }; o[field] = clone(x); keep.push(o); }
        });
        return keep;
    }
    function received(open) {
        if (!W || !E.open) resetWorking();
        else { W.sagas = merge(W.sagas, QL.CUSTOM.sagas, "b"); W.side = merge(W.side, QL.CUSTOM.side, "q"); }
        if (open) { if (!E.open) { E.stack = [{ type: "sagas" }]; } show(); }
        else if (E.open) show();
    }

    // ---- saving ----
    function sendSave(kind, obj, old) {
        var text = JSON.stringify(obj), n = Math.max(1, Math.ceil(text.length / CHUNK)), tx = RPG.nowMs() + "_" + Math.floor(Math.random() * 1e6);
        if (text.length > 250000) { U.showStatus("Too big to save (" + Math.round(text.length / 1024) + " KB, max 245 KB)", "#FF5555"); return false; }
        for (var i = 0; i < n; i++) RPG.net.send("dbr_saga", { action: "save", kind: kind, tx: tx, i: i, n: n, part: text.substring(i * CHUNK, (i + 1) * CHUNK), old: old || "" });
        return true;
    }
    function ownLink(c, en) { return c.type === "SAGA_QUEST" && (!c.sagaId || c.sagaId === en.b.id || (en.orig && c.sagaId === en.orig)); }
    function saveSaga(en) {
        var b = en.b, id = QL.cleanId(b.id, "");
        if (!id) return U.showStatus("The saga needs an id", "#FF5555");
        var seen = {}, dup = null;
        b.quests.forEach(function (q) { if (seen[q.id]) dup = q.id; seen[q.id] = 1; });
        if (dup !== null) return U.showStatus("Two quests have id " + dup + ": give each its own id", "#FF5555");
        var bad = b.quests.filter(function (q) { return q.sdu_branch && !parentOf(en, q); });
        b.quests.forEach(function (q) { (q.prerequisites && q.prerequisites.conditions || []).forEach(function (c) { if (ownLink(c, en)) c.sagaId = id; }); });
        b.id = id;
        if (sendSave("saga", b, en.orig && en.orig !== id ? en.orig : "")) {
            en.pending = true;
            U.showStatus(bad.length ? "Saving... (branch quest #" + bad[0].id + " has no \"Branch after\" parent, so it won't show in the tree)" : "Saving...", bad.length ? "#FFAA00" : "#FFFF55");
        }
    }
    function saveSide(en) {
        var id = QL.cleanId(en.q.id, "");
        if (!id) return U.showStatus("The side quest needs an id", "#FF5555");
        en.q.id = id;
        if (sendSave("side", en.q, en.orig && en.orig !== id ? en.orig : "")) {
            en.pending = true;
            U.showStatus(en.q.quest_giver || hasSagaLink(en.q) ? "Saving..." : "Saving... (no quest giver or saga prerequisite: players can't reach it)", "#FFFF55");
        }
    }
    function hasSagaLink(q) { return (q.prerequisites && q.prerequisites.conditions || []).some(function (c) { return c.type === "SAGA_QUEST" || c.type === "QUEST"; }); }

    // ---- model helpers ----
    function newQuest(id) {
        return { id: id, title: "Quest " + id, description: "", parallel_objectives: false, party_scaling: true, secret: false, claim_mode: "TREE_OR_NPC",
            sdu_branch: false, sdu_time_limit: 0, sdu_repeat_interval: 0, sdu_consume_items: false,
            prerequisites: { operator: "AND", conditions: [] }, requirements: { operator: "AND", conditions: [] }, objectives: [], rewards: [] };
    }
    function newSide(id) {
        var q = newQuest(1);
        delete q.sdu_branch;
        q.id = id; q.title = "New Side Quest"; q.type = "SIDEQUEST"; q.category = "general"; q.quest_giver = null; q.turn_in = null;
        return q;
    }
    function nextQuestId(b) { var n = 1; b.quests.forEach(function (q) { n = Math.max(n, (Number(q.id) || 0) + 1); }); return n; }
    function allSagaIds() { return QL.SAGA_LIST.map(function (s) { return s.id; }).concat(W.sagas.map(function (en) { return en.b.id; })); }
    function uniqueId(base, taken) { var id = base, n = 2; while (taken.indexOf(id) >= 0) id = base + "_" + n++; return id; }
    function parentOf(en, q) {
        var conds = (q.prerequisites && q.prerequisites.conditions) || [];
        for (var i = 0; i < conds.length; i++) if (ownLink(conds[i], en)) return Number(conds[i].questId) || 0;
        return 0;
    }
    function setParent(en, q, pid) {
        q.prerequisites = q.prerequisites || { operator: "AND", conditions: [] };
        q.prerequisites.conditions = q.prerequisites.conditions.filter(function (c) { return !ownLink(c, en); });
        if (pid) q.prerequisites.conditions.unshift({ type: "SAGA_QUEST", sagaId: en.b.id, questId: pid });
    }
    function retype(o, type, defs) {
        var d = defs[type] || {}, out = { type: type };
        Object.keys(d).forEach(function (k) { out[k] = o[k] !== undefined && o.type !== undefined && sameShape(o[k], d[k]) ? o[k] : d[k]; });
        return out;
    }
    function sameShape(a, b) { return typeof a === typeof b; }
    function sagaLabel(id) { var s = QL.SAGAS[id]; return s ? (s.label || U.tr(s.name)) : id; }
    function trOr(t) { var s = String(t || ""); return /^[a-z0-9_]+(\.[a-z0-9_]+)+$/.test(s) && U.hasTr(s) ? U.tr(s) : s; }

    // ---- pages ----
    function page() { return E.stack[E.stack.length - 1]; }
    // push / back only change the page stack; act() (every click and key) redraws the screen afterwards
    function push(p) { p.scroll = {}; E.stack.push(p); }
    function back() {
        if (E.stack.length > 1) { E.stack.pop(); return; }
        var dirty = W && (W.sagas.some(function (e) { return e.dirty; }) || W.side.some(function (e) { return e.dirty; }));
        if (dirty && RPG.nowMs() - E.closeArmed > 3000) { E.closeArmed = RPG.nowMs(); U.showStatus("Unsaved changes: close again to discard them", "#FFAA00"); return; }
        E.open = false; E.token++;
        RPG.screen.close();
    }
    function mark(en) { if (en) en.dirty = true; }
    function confirmed(key) {
        if (E.confirm && E.confirm.key === key && RPG.nowMs() < E.confirm.until) { E.confirm = null; return true; }
        E.confirm = { key: key, until: RPG.nowMs() + 3000 };
        return false;
    }
    function armed(key) { return E.confirm && E.confirm.key === key && RPG.nowMs() < E.confirm.until; }

    // widget builders (panel coordinates)
    var B;
    function text(x, y, t, color, scale, align) { B.push({ k: "text", x: x, y: y, t: t, color: color, scale: scale, align: align }); }
    function input(x, y, w, get, set, opts) { B.push({ k: "input", x: x, y: y, w: w, get: get, set: set, max: (opts && opts.max) || 128, tip: opts && opts.tip }); }
    function button(x, y, w, t, fn, tip, color) { B.push({ k: "btn", x: x, y: y, w: w, h: 16, t: t, fn: fn, tip: tip, color: color }); }
    function toggle(x, y, t, get, set, tip) { B.push({ k: "toggle", x: x, y: y, w: 24 + Math.ceil(t.length * 4.6), h: 12, t: t, get: get, set: set, tip: tip }); }
    /** A pick-one list: a searchable dropdown element (extra: more dropdown props, e.g. custom: true for typed ids). */
    function cycle(x, y, w, opts, get, set, tip, extra) { B.push({ k: "cycle", x: x, y: y, w: w, h: 14, opts: opts, get: get, set: set, tip: tip, extra: extra }); }
    function arrows(x, y, prev, next, tip) { B.push({ k: "arrows", x: x, y: y, w: 22, h: 12, prev: prev, next: next, tip: tip }); }
    function tab(x, y, w, t, active, fn) { B.push({ k: "tab", x: x, y: y, w: w, h: 15, t: t, active: active, fn: fn }); }
    function listBox(key, x, y, w, h, rows) { B.push({ k: "list", key: key, x: x, y: y, w: w, h: h, rows: rows }); }
    function label(x, y, t, tip) { text(x, y + 3, t, "#E0E0E0"); if (tip) B.push({ k: "tip", x: x, y: y, w: Math.ceil(t.length * 4.6) + 2, h: 12, tip: tip }); }
    function intGet(o, k, d) { return function () { return o[k] === undefined || o[k] === null ? String(d) : String(o[k]); }; }
    function intSet(o, k, en, isFloat) {
        return function (v) { var n = isFloat ? parseFloat(v) : parseInt(v, 10); if (!isNaN(n)) { o[k] = n; mark(en); } else if (v === "" || v === "-") { o[k] = 0; mark(en); } };
    }
    function strGet(o, k) { return function () { return o[k] === undefined || o[k] === null ? "" : String(o[k]); }; }
    function strSet(o, k, en, nullable) { return function (v) { o[k] = nullable && v === "" ? null : v; mark(en); }; }
    /** An id from a known list (searchable; any typed id is accepted too). */
    function pick(listName, x, y, w, o, k, en) {
        cycle(x, y, w, function () { return [["", "§7(none)"]].concat(list(listName).map(function (v) { return [v, v]; })); }, strGet(o, k), strSet(o, k, en, false), null,
            { search: true, custom: true, placeholder: "§7(none)", listWidth: Math.max(w, 180) });
    }
    function footer(buttons) {
        var w = 76, gap = 6, total = buttons.length * w + (buttons.length - 1) * gap, x = Math.floor((PW - total) / 2);
        buttons.forEach(function (b) { button(x, PH - 30, w, b[0], b[1], b[2], b[3]); x += w + gap; });
    }

    // ---- page: saga list / side quest list (SagaListScreen, SideQuestListScreen) ----
    function buildLists(p) {
        var sides = p.type === "sides";
        text(PW / 2, 10, "§l" + (sides ? "Side Quest Editor" : "Saga Editor"), "#FFD700", 1, 0.5);
        tab(20, 26, 90, "Sagas", !sides, function () { E.stack = [{ type: "sagas", scroll: {} }]; });
        tab(114, 26, 90, "Side Quests", sides, function () { E.stack = [{ type: "sides", scroll: {} }]; });
        text(PW - 20, 30, "§7saved with the world", "#AAAAAA", 0.7, 1);
        listBox(p.type, 14, 46, PW - 28, PH - 84, function () { return sides ? sideRows() : sagaRows(); });
        var kind = sides ? "side" : "saga";
        footer([["New", function () { if (sides) newSideEntry(); else newSagaEntry(); }, sides ? "A new side quest" : "A new custom saga"],
            ["Paste", function () { if (E.clip[kind]) { if (sides) pasteSide(); else pasteSaga(); } else U.showStatus("Nothing copied yet", "#FFAA00"); }, "Paste the copied " + (sides ? "side quest" : "saga") + " as a new one"],
            [E.showDefaults ? "Defaults: On" : "Defaults: Off", function () { E.showDefaults = !E.showDefaults; }, "Show DMZ's own " + (sides ? "side quests" : "sagas") + " (edit one to override it)"],
            ["Close", back]]);
    }
    function sagaRows() {
        var rows = [], base = {};
        QL.BASE_SAGAS.forEach(function (s) { base[s.id] = s; });
        W.sagas.forEach(function (en) {
            var b = en.b, tag = (en.dirty ? " §e*" : "") + (base[b.id] ? " §9(overrides DMZ)" : "") + (!en.orig ? " §6(unsaved)" : "");
            rows.push({ t: trOr(b.name) + " §7" + b.id + " §8" + b.quests.length + " quests" + tag,
                actions: [["Edit", function () { push({ type: "saga", en: en }); }], ["Copy", function () { E.clip.saga = clone(b); U.showStatus("Copied " + b.id, "#55FF55"); }],
                    [armed("ds" + b.id) ? "Sure?" : "X", function () {
                        if (!confirmed("ds" + b.id)) return;
                        W.sagas.splice(W.sagas.indexOf(en), 1);
                        if (en.orig) RPG.net.send("dbr_saga", { action: "delete", kind: "saga", id: en.orig });
                    }, true, en.orig ? (base[en.orig] ? "Delete (DMZ's saga comes back)" : "Delete from the world") : "Discard"]] });
        });
        if (E.showDefaults) QL.BASE_SAGAS.forEach(function (s) {
            if (W.sagas.some(function (en) { return en.b.id === s.id || en.orig === s.id; })) return;
            rows.push({ t: "§9" + (s.label || U.tr(s.name)) + " §7" + s.id + " §8" + s.quests.length + " quests (DMZ)",
                actions: [["Edit", function () { var en = { b: QL.bundleOf(s), orig: null, dirty: true }; W.sagas.push(en); push({ type: "saga", en: en }); }, false, "Edit a copy that overrides DMZ's saga"],
                    ["Copy", function () { E.clip.saga = QL.bundleOf(s); U.showStatus("Copied " + s.id, "#55FF55"); }]] });
        });
        if (!rows.length) rows.push({ t: "§7No custom sagas yet. Press New, or turn on Defaults to start from DMZ's.", actions: [] });
        return rows;
    }
    function sideRows() {
        var rows = [], base = {};
        QL.BASE_SIDE.forEach(function (q) { base[q.id] = q; });
        W.side.forEach(function (en) {
            var q = en.q, tag = (en.dirty ? " §e*" : "") + (base[q.id] ? " §9(overrides DMZ)" : "") + (!en.orig ? " §6(unsaved)" : "");
            rows.push({ t: trOr(q.title) + " §7" + q.id + " §8" + q.type + tag,
                actions: [["Edit", function () { push({ type: "quest", en: en, q: en.q, side: true, tab: 0 }); }],
                    ["Copy", function () { E.clip.side = clone(q); U.showStatus("Copied " + q.id, "#55FF55"); }],
                    [armed("dq" + q.id) ? "Sure?" : "X", function () {
                        if (!confirmed("dq" + q.id)) return;
                        W.side.splice(W.side.indexOf(en), 1);
                        if (en.orig) RPG.net.send("dbr_saga", { action: "delete", kind: "side", id: en.orig });
                    }, true, en.orig ? "Delete from the world" : "Discard"]] });
        });
        if (E.showDefaults) QL.BASE_SIDE.forEach(function (q) {
            if (W.side.some(function (en) { return en.q.id === q.id || en.orig === q.id; })) return;
            rows.push({ t: "§9" + trOr(q.title) + " §7" + q.id + " §8(DMZ)",
                actions: [["Edit", function () { var en = { q: QL.normalizeSide(q), orig: null, dirty: true }; W.side.push(en); push({ type: "quest", en: en, q: en.q, side: true, tab: 0 }); }, false, "Edit a copy that overrides DMZ's side quest"],
                    ["Copy", function () { E.clip.side = QL.normalizeSide(q); U.showStatus("Copied " + q.id, "#55FF55"); }]] });
        });
        if (!rows.length) rows.push({ t: "§7No custom side quests yet.", actions: [] });
        return rows;
    }
    function newSagaEntry() {
        var id = uniqueId("custom_saga", allSagaIds()), en = { b: QL.normalizeSaga({ id: id, name: "New Custom Saga", quests: [] }), orig: null, dirty: true };
        W.sagas.push(en);
        push({ type: "saga", en: en });
    }
    function pasteSaga() {
        var b = clone(E.clip.saga), old = b.id;
        b.id = uniqueId(QL.cleanId(old + "_copy"), allSagaIds()); b.name = trOr(b.name) + " (Copy)";
        b.quests.forEach(function (q) { (q.prerequisites && q.prerequisites.conditions || []).forEach(function (c) { if (c.type === "SAGA_QUEST" && c.sagaId === old) c.sagaId = b.id; }); });
        W.sagas.push({ b: b, orig: null, dirty: true });
        U.showStatus("Pasted as " + b.id + " (press Save in it to keep it)", "#55FF55");
    }
    function sideIds() { return QL.SIDE.map(function (q) { return q.id; }).concat(W.side.map(function (en) { return en.q.id; })); }
    function newSideEntry() {
        var en = { q: newSide(uniqueId("custom_sidequest", sideIds())), orig: null, dirty: true };
        W.side.push(en);
        push({ type: "quest", en: en, q: en.q, side: true, tab: 0 });
    }
    function pasteSide() {
        var q = clone(E.clip.side);
        q.id = uniqueId(QL.cleanId(q.id + "_copy"), sideIds()); q.title = trOr(q.title) + " (Copy)";
        W.side.push({ q: q, orig: null, dirty: true });
        U.showStatus("Pasted as " + q.id, "#55FF55");
    }

    // ---- page: one saga (SagaEditScreen) ----
    function buildSaga(p) {
        var en = p.en, b = en.b;
        text(PW / 2, 10, "§lEdit Saga" + (en.dirty ? " §e*" : ""), "#FFD700", 1, 0.5);
        label(16, 28, "ID", "Unique saga id (lowercase, a-z 0-9 _). A DMZ saga's id overrides that saga");
        input(36, 28, 120, strGet(b, "id"), strSet(b, "id", en), { max: 48 });
        label(166, 28, "Name", "Display name of the saga");
        input(196, 28, PW - 212, strGet(b, "name"), strSet(b, "name", en), { max: 128 });
        var sagaOpts = function () {
            return [["", "(none)"]].concat(uniq(allSagaIds()).filter(function (id) { return id !== b.id; }).map(function (id) { return [id, sagaLabel(id)]; }));
        };
        label(16, 48, "After saga", "This saga unlocks once that saga is finished (DMZ's previous-saga lock)");
        cycle(80, 47, 150, sagaOpts, function () { return b.prev || ""; }, function (v) { b.prev = v; mark(en); });
        label(16, 66, "Needs quest", "Also locked until this quest is done (saga + quest). Both gates must be met");
        cycle(80, 65, 150, sagaOpts, function () { return b.prereqSaga || ""; }, function (v) { b.prereqSaga = v; b.prereqQuest = 0; mark(en); });
        cycle(236, 65, PW - 252, function () {
            var s = QL.SAGAS[b.prereqSaga], out = [[0, "(none)"]];
            if (s) s.quests.forEach(function (q) { out.push([q.id, "#" + q.id + " " + trOr(q.title)]); });
            if (b.prereqQuest && !out.some(function (o) { return o[0] === b.prereqQuest; })) out.push([b.prereqQuest, "#" + b.prereqQuest]);
            return out;
        }, function () { return b.prereqQuest || 0; }, function (v) { b.prereqQuest = Number(v) || 0; mark(en); });
        text(16, 88, "§eQuests", "#FFFF55", TS);
        text(PW - 16, 88, "§7main line runs in id order; branches hang off their parent", "#AAAAAA", 0.65, 1);
        listBox("quests", 14, 98, PW - 28, PH - 136, function () {
            if (!b.quests.length) return [{ t: "§7No quests yet: Add Quest", actions: [] }];
            return b.quests.map(function (q) {
                var pid = parentOf(en, q);
                return { t: (q.sdu_branch ? "§d⌥ #" + q.id + " §r" : "§7#" + q.id + " §r") + trOr(q.title) + (pid ? " §8after #" + pid : "") + (q.sdu_time_limit ? " §c⏱" : "") + (q.sdu_repeat_interval ? " §b⟳" : ""),
                    actions: [["Edit", function () { push({ type: "quest", en: en, q: q, side: false, tab: 0 }); }],
                        ["Copy", function () { E.clip.quest = clone(q); E.clip.questSaga = b.id; U.showStatus("Copied quest #" + q.id, "#55FF55"); }],
                        [armed("q" + q.id) ? "Sure?" : "X", function () { if (confirmed("q" + q.id)) { b.quests.splice(b.quests.indexOf(q), 1); mark(en); } }, true, "Remove this quest"]] };
            });
        });
        footer([["Add Quest", function () { var q = newQuest(nextQuestId(b)); b.quests.push(q); mark(en); push({ type: "quest", en: en, q: q, side: false, tab: 0 }); }, "Add a new quest to this saga"],
            ["Paste Quest", function () {
                if (!E.clip.quest) return U.showStatus("No quest copied yet", "#FFAA00");
                var q = clone(E.clip.quest), src = E.clip.questSaga;
                q.id = nextQuestId(b); q.title = trOr(q.title) + " (Copy)";
                if (q.prerequisites) q.prerequisites.conditions = q.prerequisites.conditions.filter(function (c) { return !(c.type === "SAGA_QUEST" && c.sagaId === src && src !== b.id); });
                b.quests.push(q); mark(en);
            }, "Paste the copied quest with a new id"],
            ["Save Saga", function () { saveSaga(en); }, "Write this saga to the world"], ["Back", back]]);
    }

    // ---- page: one quest (QuestEditScreen / SideQuestEditScreen) ----
    var TABS = ["General", "Objectives", "Rewards", "Requirements", "Prereqs"];
    function prereqIdx(p) {
        var conds = (p.q.prerequisites && p.q.prerequisites.conditions) || [], out = [];
        conds.forEach(function (c, i) { if (p.side || !ownLink(c, p.en)) out.push(i); });
        return out;
    }
    function buildQuest(p) {
        var q = p.q, en = p.en, side = p.side;
        q.prerequisites = q.prerequisites || { operator: "AND", conditions: [] };
        q.requirements = q.requirements || { operator: "AND", conditions: [] };
        q.objectives = q.objectives || []; q.rewards = q.rewards || [];
        text(PW / 2, 10, "§l" + (side ? "Side Quest " + q.id : "Quest #" + q.id) + (en.dirty ? " §e*" : ""), "#FFD700", 1, 0.5);
        var counts = [null, q.objectives.length, q.rewards.length, q.requirements.conditions.length, prereqIdx(p).length];
        TABS.forEach(function (t, i) { tab(14 + i * 75, 26, 72, t + (counts[i] !== null ? " (" + counts[i] + ")" : ""), p.tab === i, function () { p.tab = i; }); });
        var save = ["Save", function () { if (side) saveSide(en); else saveSaga(en); }, side ? "Write this side quest to the world" : "Write the whole saga to the world"];
        if (p.tab === 0) { buildGeneral(p); footer([save, ["Back", back]]); return; }
        var kind = ["", "obj", "rew", "cond", "cond"][p.tab], arr, idx = null;
        if (p.tab === 1) arr = q.objectives;
        else if (p.tab === 2) arr = q.rewards;
        else if (p.tab === 3) arr = q.requirements.conditions;
        else { arr = q.prerequisites.conditions; idx = prereqIdx(p); }
        var types = p.tab === 1 ? OBJ_TYPES : p.tab === 2 ? REW_TYPES : p.tab === 3 ? COND_TYPES : PREREQ_TYPES;
        var summary = p.tab === 1 ? objSummary : p.tab === 2 ? rewSummary : condSummary;
        var hint = ["", (q.parallel_objectives ? "All at once (parallel)" : "In order, top to bottom") + (q.sdu_consume_items ? "; ITEM objectives are taken on completion" : ""),
            "Given on completion" + (q.claim_mode === "NPC_ONLY" ? " (claimed at the NPC)" : ""), "Must be met to START the quest",
            side ? "Hide the quest until met (SAGA_QUEST / QUEST attach it to a saga tree)" : "Hide the quest until met (the Branch after link is on General)"][p.tab];
        text(16, 46, "§7" + hint, "#AAAAAA", 0.7);
        listBox(kind + p.tab, 14, 56, PW - 28, PH - 94, function () {
            var items = idx ? idx.map(function (i) { return [arr[i], i]; }) : arr.map(function (o, i) { return [o, i]; });
            if (!items.length) return [{ t: "§7None", actions: [] }];
            return items.map(function (it, n) {
                var o = it[0], i = it[1];
                return { t: "§7" + (n + 1) + ". §r" + summary(o),
                    actions: [["Edit", function () { if (o.conditions) return U.showStatus("Nested condition groups can only be removed here", "#FFAA00"); push({ type: "item", kind: kind, arr: arr, o: o, en: en, types: types }); }],
                        ["Copy", function () { E.clip[kind] = clone(o); U.showStatus("Copied", "#55FF55"); }],
                        [armed(kind + i) ? "Sure?" : "X", function () { if (confirmed(kind + i)) { arr.splice(i, 1); mark(en); } }, true]] };
            });
        });
        var defs = kind === "obj" ? OBJ_DEF : kind === "rew" ? REW_DEF : COND_DEF;
        footer([["Add", function () { var o = retype({}, types[0], defs); arr.push(o); mark(en); push({ type: "item", kind: kind, arr: arr, o: o, en: en, types: types }); }, "Add a new one"],
            ["Paste", function () { if (!E.clip[kind]) return U.showStatus("Nothing copied yet", "#FFAA00"); arr.push(clone(E.clip[kind])); mark(en); }],
            save, ["Back", back]]);
    }
    function buildGeneral(p) {
        var q = p.q, en = p.en, side = p.side, y = 48;
        label(16, y, "Title", "The quest's title (a lang key or plain text)");
        input(56, y, side ? PW - 72 : 250, strGet(q, "title"), strSet(q, "title", en), { max: 256 });
        if (!side) {
            label(318, y, "ID", "Numeric quest id, unique in this saga. The main line runs in id order");
            input(334, y, PW - 350, intGet(q, "id", 1), intSet(q, "id", en));
        }
        y += 20;
        if (side) {
            label(16, y, "ID", "Unique side quest id");
            input(56, y, 140, strGet(q, "id"), strSet(q, "id", en), { max: 48 });
            label(206, y, "Category", "Groups side quests (DMZ's category)");
            input(256, y, PW - 272, strGet(q, "category"), strSet(q, "category", en), { max: 64 });
            y += 20;
        }
        label(16, y, "Desc", "The quest's description");
        input(56, y, PW - 72, strGet(q, "description"), strSet(q, "description", en), { max: 2048 });
        y += 20;
        label(16, y, "Time limit (s)", "Seconds to finish once accepted; 0 = no limit. Running out fails the quest");
        input(86, y, 56, intGet(q, "sdu_time_limit", 0), intSet(q, "sdu_time_limit", en));
        B.push({ k: "text", x: 146, y: y + 3, t: function () { return q.sdu_time_limit > 0 ? "§7" + dur(q.sdu_time_limit) : "§8none"; }, scale: 0.7 });
        label(200, y, "Repeat (s)", "After completing, the quest can be taken again once this many seconds pass. 0 = once. 86400 = daily, 604800 = weekly");
        input(256, y, 60, intGet(q, "sdu_repeat_interval", 0), intSet(q, "sdu_repeat_interval", en));
        cycle(322, y, PW - 338, function () { return [[0, "once"], [3600, "hourly"], [86400, "daily"], [604800, "weekly"]].concat(
            [0, 3600, 86400, 604800].indexOf(Number(q.sdu_repeat_interval) || 0) < 0 ? [[q.sdu_repeat_interval, dur(q.sdu_repeat_interval)]] : []); },
            function () { return Number(q.sdu_repeat_interval) || 0; }, function (v) { q.sdu_repeat_interval = Number(v) || 0; mark(en); }, "Repeat presets");
        y += 20;
        label(16, y, "Claim", "Where the rewards are claimed: the quest tree or the turn-in NPC, or only at the NPC");
        cycle(56, y, 110, function () { return CYCLES.claim; }, function () { return q.claim_mode || "TREE_OR_NPC"; }, function (v) { q.claim_mode = v; mark(en); });
        if (!side) {
            label(176, y, "Branch after", "The quest this one follows in the tree. With Branch on, it becomes a side path off that quest");
            cycle(236, y, PW - 252, function () {
                return [[0, "(root)"]].concat(en.b.quests.filter(function (o) { return o !== q; }).map(function (o) { return [o.id, "#" + o.id + " " + trOr(o.title)]; }));
            }, function () { return parentOf(en, q); }, function (v) { setParent(en, q, Number(v) || 0); mark(en); });
        } else {
            label(176, y, "Type", "SIDEQUEST = once; DAILY / EVENT = repeatable (DMZ's quest types)");
            cycle(206, y, PW - 222, function () { return SIDE_TYPES.map(function (t) { return [t, t]; }); }, function () { return q.type || "SIDEQUEST"; }, function (v) { q.type = v; mark(en); });
            y += 20;
            label(16, y, "Giver", "NPC that offers the quest (talking to it starts it). Blank = none");
            pick("npc", 56, y, 140, q, "quest_giver", en);
            label(206, y, "Turn-in", "NPC the quest is handed in to (completes it there and pays out). Blank = none");
            pick("npc", 246, y, PW - 262, q, "turn_in", en);
        }
        y += 22;
        var flags = [["Party", "party_scaling", "Party scaling: more members = tougher enemies and more items"], ["Secret", "secret", "Hide the quest from the tree until started"],
            ["Parallel", "parallel_objectives", "Objectives can be done in any order"]];
        if (!side) flags.push(["Branch", "sdu_branch", "Put this quest on a side path (needs a Branch after parent)"]);
        flags.push(["Consume", "sdu_consume_items", "Completing takes the items the ITEM objectives asked for"]);
        var fx = 16;
        flags.forEach(function (f) {
            toggle(fx, y, f[0], function () { return !!q[f[1]]; }, function (v) { q[f[1]] = v; mark(en); }, f[2]);
            fx += side ? 92 : 74;
        });
        y += 20;
        B.push({ k: "text", x: 16, y: y, t: function () {
            var bits = [];
            if (!side && q.sdu_branch && !parentOf(en, q)) bits.push("§cBranch quests need a Branch after parent");
            if (q.sdu_time_limit > 0) bits.push("§7Fails after " + dur(q.sdu_time_limit));
            if (q.sdu_repeat_interval > 0) bits.push("§7Repeats " + dur(q.sdu_repeat_interval) + " after completion");
            if (side && !q.quest_giver && !hasSagaLink(q)) bits.push("§eNo giver and no SAGA_QUEST prerequisite: players can't find it");
            return bits.join("   ");
        }, scale: 0.7 });
    }

    // ---- page: one objective / reward / condition (Objective-, Reward-, ConditionEditScreen) ----
    function buildItem(p) {
        var o = p.o, en = p.en, kind = p.kind;
        var fields = (kind === "obj" ? OBJ_FIELDS : kind === "rew" ? REW_FIELDS : COND_FIELDS)[o.type] || [];
        var defs = kind === "obj" ? OBJ_DEF : kind === "rew" ? REW_DEF : COND_DEF;
        text(PW / 2, 10, "§l" + (kind === "obj" ? "Objective" : kind === "rew" ? "Reward" : "Condition"), "#FFD700", 1, 0.5);
        label(16, 34, "Type", kind === "obj" ? "What the player must do" : kind === "rew" ? "What the player gets" : "What must be true");
        cycle(90, 33, 170, function () {
            var opts = p.types.map(function (t) { return [t, t]; });
            if (p.types.indexOf(o.type) < 0) opts.unshift([o.type, o.type]);
            return opts;
        }, function () { return o.type; }, function (v) {
            if (v === o.type) return;
            var n = retype(o, v, defs);
            Object.keys(o).forEach(function (k) { delete o[k]; });
            Object.keys(n).forEach(function (k) { o[k] = n[k]; });
            mark(en);
        });
        var y = 56;
        fields.forEach(function (f) {
            var key = f[0], kindF = f[2];
            label(16, y, f[1], f[3]);
            if (kindF === "int" || kindF === "num") input(90, y, 90, intGet(o, key, 0), intSet(o, key, en, kindF === "num"));
            else if (kindF === "text") input(90, y, PW - 106, strGet(o, key), strSet(o, key, en), { max: 512 });
            else if (kindF === "bool") toggle(90, y, o[key] ? "On" : "Off", function () { return !!o[key]; }, function (v) { if (v) o[key] = true; else delete o[key]; mark(en); }, f[3]);
            else if (kindF.indexOf("pick:") === 0) pick(kindF.substring(5) === "saga" ? "sagaIds" : kindF.substring(5), 90, y, 240, o, key, en);
            else if (kindF.indexOf("cycle:") === 0) {
                var cname = kindF.substring(6);
                cycle(90, y, 170, function () { return CYCLES[cname]; }, function () {
                    if (cname === "aitier") return o.AITier > 0 ? o.AITier : -1;
                    return o[key];
                }, function (v) {
                    if (cname === "aitier") { if (Number(v) > 0) o.AITier = Number(v); else delete o.AITier; }
                    else if (cname === "timemode") {
                        if (v === o.mode) return;
                        if (v === "GAME_TIME") { o.ticks = Math.round((o.milliseconds || 0) / 50); delete o.milliseconds; }
                        else { o.milliseconds = (o.ticks || 0) * 50; delete o.ticks; }
                        o.mode = v;
                    } else o[key] = v;
                    mark(en);
                });
            } else if (kindF === "time") {
                var tk = function () { return o.mode === "GAME_TIME" ? "ticks" : "milliseconds"; };
                input(90, y, 110, function () { return String(o[tk()] || 0); }, function (v) { var n = parseInt(v, 10); if (!isNaN(n)) { o[tk()] = Math.max(0, n); mark(en); } });
                B.push({ k: "text", x: 206, y: y + 3, t: function () { return "§7" + (o.mode === "GAME_TIME" ? "ticks = " + dur((o.ticks || 0) / 20) : "ms = " + dur((o.milliseconds || 0) / 1000)); }, scale: 0.7 });
            }
            y += 20;
        });
        if (o.type === "COORDS") button(90, y, 110, "Use my position", function () {
            o.x = Math.floor(RPG.player.x); o.y = Math.floor(RPG.player.y); o.z = Math.floor(RPG.player.z); mark(en);
        }, "Fill in where you stand");
        if (o.type === "TIME") {
            button(90, y, 60, "1 hour", function () { o.mode = "REAL_TIME"; delete o.ticks; o.milliseconds = 3600000; mark(en); });
            button(154, y, 60, "1 day", function () { o.mode = "REAL_TIME"; delete o.ticks; o.milliseconds = 86400000; mark(en); });
            button(218, y, 60, "1 week", function () { o.mode = "REAL_TIME"; delete o.ticks; o.milliseconds = 604800000; mark(en); });
        }
        if (!fields.length) text(16, y + 2, "§7This type has no settings here (its other fields are kept as they are)", "#AAAAAA", 0.7);
        B.push({ k: "text", x: 16, y: PH - 48, t: function () { return "§7→ §f" + (kind === "obj" ? objSummary(o) : kind === "rew" ? rewSummary(o) : condSummary(o)); }, scale: TS });
        footer([["Done", back], [armed("del") ? "Sure?" : "Delete", function () {
            if (!confirmed("del")) return;
            var i = p.arr.indexOf(o);
            if (i >= 0) p.arr.splice(i, 1);
            mark(en); E.stack.pop();
        }, "Remove it", "#FF8080"]]);
    }

    // ---- screen ----
    function show() {
        if (!W) resetWorking();
        var p = page();
        if (!p) return;
        p.scroll = p.scroll || {};
        B = [];
        if (p.type === "sagas" || p.type === "sides") buildLists(p);
        else if (p.type === "saga") buildSaga(p);
        else if (p.type === "quest") buildQuest(p);
        else if (p.type === "item") buildItem(p);
        E.widgets = B;
        var els = [], n = 0;
        B.forEach(function (w) {
            if (w.k !== "input") return;
            w.id = "in" + (n++);
            els.push({ id: w.id, type: "input", anchor: "center", x: w.x - PW / 2 + 1, y: w.y - PH / 2, w: w.w - 2, h: 12, maxLength: w.max, value: w.get(),
                onChange: (function (wd) { return function (id, v) { wd.set(String(v)); }; })(w) });
        });
        // pick-one lists: searchable dropdowns (drawn by the engine, the open list over everything)
        B.forEach(function (w) {
            if (w.k !== "cycle") return;
            w.id = "dd" + (n++);
            var extra = { listWidth: Math.max(w.w, 140) };
            for (var key in w.extra || {}) extra[key] = w.extra[key];
            els.push(U.dropdown(w.id, w.x - PW / 2, w.y - PH / 2, w.w, w.h, (w.opts() || []).map(function (o) { return { value: o[0], label: o[1] }; }), w.get(),
                (function (wd) { return function (v) { act(function () { wd.set(v); }); }; })(w), extra));
        });
        var tok = ++E.token;
        E.open = true;
        RPG.screen.open({ id: "dbr_saga_editor", referenceHeight: 360, background: "dim", closeOnEsc: false, elements: els,
            onBackground: render, onRender: function (ctx) { if (E.tip) U.tooltip(ctx, U.wrap(ctx, E.tip, 220).map(function (l) { return [l, "#E0E0E0"]; }), ctx.mouseX, ctx.mouseY); },
            onMouse: mouse, onScroll: scroll,
            onKey: function (k, action) { if (action === "down" && k === "key.keyboard.escape") { act(back, true); return false; } },
            onClose: function () { if (tok === E.token) E.open = false; } });
    }
    function open() {
        E.stack = [{ type: "sagas", scroll: {} }];
        resetWorking();
        show();
    }

    // ---- drawing ----
    function val(x) { return typeof x === "function" ? x() : x; }
    function txt(ctx, t, x, y, color, align, scale) { ctx.textStyled(String(t), x, y, scale || TS, color || "#FFFFFF", 1, align || 0, FONT, "#000000"); }
    function tw(ctx, t, scale) { return ctx.textWidthIn(String(t), FONT) * (scale || TS); }
    function fit(ctx, t, w, scale) {
        if (tw(ctx, t, scale) <= w) return t;
        while (t.length > 1 && tw(ctx, t + "...", scale) > w) t = t.substring(0, t.length - 1);
        return t + "...";
    }
    function drawButton(ctx, x, y, w, h, label, hover, color, active) {
        U.buttonArt(ctx, x, y, w, h, hover || active);
        if (active) ctx.fill(x + 2, y + 2, w - 4, h - 4, "#FFD700", 0.18);
        txt(ctx, fit(ctx, label, w - 6, 0.75), x + w / 2, y + Math.floor((h - 6) / 2), active ? "#FFD700" : hover ? "#FFFFA0" : (color || "#FFFFFF"), 0.5, 0.75);
    }
    function render(ctx) {
        var p = page();
        if (!p) return;
        var px = Math.floor((ctx.width - PW) / 2), py = Math.floor((ctx.height - PH) / 2), mx = ctx.mouseX - px, my = ctx.mouseY - py, tip = null;
        E.px = px; E.py = py;
        ctx.fill(px + 6, py + 6, PW - 12, PH - 12, "#0F1020", 0.8);
        U.QUEST_PANEL.draw(ctx, px, py, PW, PH);
        E.widgets.forEach(function (w) {
            var hov = mx >= w.x && my >= w.y && mx < w.x + (w.w || 0) && my < w.y + (w.h || 0);
            var x = px + w.x, y = py + w.y;
            switch (w.k) {
                case "text": txt(ctx, val(w.t), x, y, w.color || "#FFFFFF", w.align || 0, w.scale || TS); break;
                case "btn": drawButton(ctx, x, y, w.w, w.h, val(w.t), hov, w.color, false); break;
                case "tab": drawButton(ctx, x, y, w.w, w.h, w.t, hov, null, w.active); break;
                case "toggle":
                    var on = !!w.get();
                    ctx.quad(BUTTONS, x, y + 1, 20, 10, 122 / 256, (on ? 0 : 10) / 256, 142 / 256, (on ? 10 : 20) / 256, "#FFFFFF", 1);
                    txt(ctx, w.t, x + 24, y + 2, hov ? "#FFFFA0" : on ? "#FFFFFF" : "#A0A0A0", 0, 0.75);
                    break;
                case "arrows":
                    var al = hov && mx < w.x + 11, ar = hov && !al;
                    ctx.quad(BUTTONS, x, y + 1, 10, 10, 142 / 256, (al ? 10 : 0) / 256, 152 / 256, (al ? 20 : 10) / 256, "#FFFFFF", 1);
                    ctx.quad(BUTTONS, x + 12, y + 1, 10, 10, 0, (ar ? 10 : 0) / 256, 10 / 256, (ar ? 20 : 10) / 256, "#FFFFFF", 1);
                    break;
                case "list": tip = drawList(ctx, w, x, y, mx, my) || tip; break;
            }
            if (hov && w.tip && w.k !== "list") tip = w.tip;
        });
        U.drawStatus(ctx, px + PW / 2, py + PH - 44);
        E.tip = tip;               // drawn by onRender, above the elements
    }
    var ROW = 16;
    function rowsOf(w) { if (!w._rows || w._at !== E.token + ":" + RPG.time()) { w._rows = w.rows(); w._at = E.token + ":" + RPG.time(); } return w._rows; }
    function actionRects(w, rx, ry, row) {
        var out = [], x = rx + w.w - 4;
        for (var i = row.actions.length - 1; i >= 0; i--) {
            var a = row.actions[i], bw = a[0] === "X" ? 16 : a[0] === "Sure?" ? 34 : 30;
            x -= bw;
            out.unshift([x, ry + 1, bw, ROW - 2, a]);
            x -= 3;
        }
        return out;
    }
    function drawList(ctx, w, x, y, mx, my) {
        var rows = rowsOf(w), p = page(), total = rows.length * ROW, max = Math.max(0, total - w.h), tip = null;
        var sc = p.scroll[w.key] = Math.max(0, Math.min(p.scroll[w.key] || 0, max));
        ctx.fill(x, y, w.w, w.h, "#000000", 0.3);
        ctx.fill(x, y, w.w, 1, "#444466", 0.6); ctx.fill(x, y + w.h - 1, w.w, 1, "#444466", 0.6);
        ctx.clip(x, y, w.w, w.h);
        rows.forEach(function (r, i) {
            var ry = y + i * ROW - sc;
            if (ry + ROW < y || ry > y + w.h) return;
            var lx = mx + E.px, ly = my + E.py, hov = lx >= x && lx < x + w.w && ly >= ry && ly < ry + ROW && ly >= y && ly < y + w.h;
            if (hov) ctx.fill(x + 1, ry, w.w - 2, ROW, "#FFFFFF", 0.07);
            var rects = actionRects(w, x, ry, r), textW = (rects.length ? rects[0][0] - x : w.w) - 10;
            txt(ctx, fit(ctx, r.t, textW, TS), x + 5, ry + 4, "#FFFFFF", 0, TS);
            rects.forEach(function (rc) {
                var bh = lx >= rc[0] && lx < rc[0] + rc[2] && ly >= rc[1] && ly < rc[1] + rc[3] && ly >= y && ly < y + w.h;
                drawButton(ctx, rc[0], rc[1], rc[2], rc[3], rc[4][0], bh, rc[4][2] ? "#FF9090" : null, false);
                if (bh && rc[4][3]) tip = rc[4][3];
            });
            if (hov && !tip && tw(ctx, r.t, TS) > textW) tip = U.strip(r.t);
        });
        ctx.unclip();
        if (total > w.h) {
            var th = Math.max(12, w.h * w.h / total), ty = y + (w.h - th) * sc / max;
            ctx.fill(x + w.w - 3, y, 2, w.h, "#000000", 0.4); ctx.fill(x + w.w - 3, ty, 2, th, "#D2D7F1", 1);
        }
        return tip;
    }

    // ---- input ----
    function mouse(x, y, button, action) {
        if (action !== "down" || button !== 0 || E.px === undefined) return;
        var mx = x - E.px, my = y - E.py, ws = E.widgets, handled = false;
        for (var i = ws.length - 1; i >= 0 && !handled; i--) {
            var w = ws[i];
            if (w.k === "list") {
                if (mx < w.x || my < w.y || mx >= w.x + w.w || my >= w.y + w.h) continue;
                var rows = rowsOf(w), sc = page().scroll[w.key] || 0, ri = Math.floor((my - w.y + sc) / ROW), r = rows[ri];
                if (!r) return false;
                actionRects(w, w.x, w.y + ri * ROW - sc, r).forEach(function (rc) {
                    if (!handled && mx >= rc[0] && mx < rc[0] + rc[2] && my >= rc[1] && my < rc[1] + rc[3]) { handled = true; act(rc[4][1]); }
                });
                return false;
            }
            if (!(mx >= w.x && my >= w.y && mx < w.x + (w.w || 0) && my < w.y + (w.h || 0))) continue;
            if (w.k === "btn" || w.k === "tab") { handled = true; act(w.fn); }
            else if (w.k === "toggle") { handled = true; var nv = !w.get(); RPG.sound(nv ? "dmzpack:switch_on" : "dmzpack:switch_off", 1, 1); act(function () { w.set(nv); }, true); }
            else if (w.k === "arrows") { handled = true; act(mx < w.x + 11 ? w.prev : w.next); }
        }
        if (handled) return false;
    }
    function act(fn, silent) {
        if (!silent) RPG.sound("dmzpack:pip_menu", 1, 1);
        try { fn(); } catch (e) { RPG.log("Saga editor: " + e); U.showStatus("Error: " + e, "#FF5555"); }
        if (E.open) show();
    }
    function scroll(x, y, delta) {
        if (E.px === undefined) return;
        var mx = x - E.px, my = y - E.py, p = page();
        E.widgets.forEach(function (w) {
            if (w.k === "list" && mx >= w.x && my >= w.y && mx < w.x + w.w && my < w.y + w.h) p.scroll[w.key] = Math.max(0, (p.scroll[w.key] || 0) - (delta > 0 ? ROW * 2 : -ROW * 2));
        });
    }

    RPG.net.on("dbr_saga_editor_open", function () { open(); });
    DBR_SAGA_EDITOR_CLIENT = { open: function () { RPG.net.send("dbr_saga", { action: "open" }); }, isOpen: function () { return E.open; } };
})();
