// =====================================================================================
//  56_dmz_camera.js - DragonMine Z's Over Shoulder Camera (OverShoulderCamera +
//  OverShoulderCameraScreen), opened from the options screen's "Over Shoulder Camera"
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0). In third person (behind), the camera moves to a shoulder:
//  Distance behind, Height and Side (right, or left with "Left Shoulder"), easing there by
//  Smoothing each frame, pulled in by walls. Mode: Disabled, Lock-On Only (while 46_dmz_senses.js
//  has a lock-on target) or Always (DMZ's default). The settings screen switches to third
//  person and previews the shoulder view whatever the mode, then puts the view back.
//  Uses the engine's RPG.camera.offset / clearOffset. DMZ also decouples aiming from the camera
//  (a moving crosshair); here the view direction stays the player's.
// =====================================================================================
var DMZ_SHOULDER = (function () {
    var O = DMZ_OPTS, K = O.KEYS, U = DMZ_UI, FONT = U.FONT;
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png", BUTTONS = U.BUTTONS;
    var MODE_NONE = 0, MODE_LOCK_ON = 1, MODE_ALWAYS = 2;
    var PANEL_W = 141, PANEL_H = 213, MARGIN = 16, BUTTON_W = 74, SLIDER_W = 111;
    var SLIDERS = [
        { id: "back", key: K.overShoulderBack, label: "gui.dragonminez.overShoulder.distance", min: 1, max: 6, def: 3.0, y: 102 },
        { id: "up", key: K.overShoulderUp, label: "gui.dragonminez.overShoulder.height", min: -1, max: 2, def: 0.35, y: 130 },
        { id: "side", key: K.overShoulderSide, label: "gui.dragonminez.overShoulder.side", min: 0, max: 3, def: 1.45, y: 158 },
        { id: "smooth", key: K.overShoulderSmoothing, label: "gui.dragonminez.overShoulder.smoothing", min: 0.05, max: 0.6, def: 0.4, y: 186 }
    ];

    // ---- GeneralUserConfig getters ----
    function mode() { var m = Math.round(O.num(K.overShoulderMode, MODE_ALWAYS)); return m < 0 || m > 2 ? MODE_ALWAYS : m; }
    function left() { return O.bool(K.overShoulderLeft, false); }
    function value(s) { return O.num(s.key, s.def); }
    function smoothing() { var v = O.num(K.overShoulderSmoothing, 0.4); return v <= 0 ? 0.4 : Math.min(v, 1); }

    // ---- OverShoulderCamera.isActive / computeMove ----
    var preview = false, applied = null;
    function active() {
        if (preview) return true;
        var m = mode();
        if (m === MODE_ALWAYS) return true;
        if (m === MODE_LOCK_ON) return !!RPG.getVar("lock_uuid", "");
        return false;
    }
    function tick() {
        var cam = RPG.camera;
        if (typeof cam.offset !== "function") return;
        if (RPG.player.present && active()) {
            // a bigger body (giant forms) moves the shoulder camera out with it
            var k = Math.max(0.3, Number(RPG.player.modelSize) || 1);
            var b = value(SLIDERS[0]) * k, u = value(SLIDERS[1]) * k, sd = value(SLIDERS[2]) * (left() ? -1 : 1) * k, sm = smoothing();
            var sig = b + "|" + u + "|" + sd + "|" + sm;
            if (sig !== applied) { cam.offset(b, u, sd, sm); applied = sig; }
        } else if (applied !== null) { cam.clearOffset(); applied = null; }
    }
    RPG.on("tick", tick);
    RPG.on("load", function () { applied = null; });

    // ---- OverShoulderCameraScreen ----
    var S = null;
    function modeLabel() { return U.tr(["gui.dragonminez.overShoulder.mode.none", "gui.dragonminez.overShoulder.mode.lockOn", "gui.dragonminez.overShoulder.mode.always"][mode()]); }
    function sideLabel() { return U.tr(left() ? "gui.dragonminez.overShoulder.side.left" : "gui.dragonminez.overShoulder.side.right"); }
    /** The panel sits on the side of the chosen shoulder (anchored to that screen edge). */
    function anchor() { return left() ? "left" : "right"; }
    function panelX() { return left() ? MARGIN : -PANEL_W - MARGIN; }
    function elements() {
        var a = anchor(), px = panelX(), py = -Math.floor(PANEL_H / 2), bx = px + (PANEL_W - BUTTON_W) / 2, sx = px + (PANEL_W - SLIDER_W) / 2;
        var btn = function (id, y, label, onClick) {
            var e = { id: id, type: "button", anchor: a, x: bx, y: py + y, w: BUTTON_W, h: 20, label: label, onClick: onClick };
            for (var k in U.BUTTON_SKIN) e[k] = U.BUTTON_SKIN[k];
            return e;
        };
        var els = [
            btn("mode", 40, modeLabel(), function () {
                O.set(K.overShoulderMode, (mode() + 1) % 3);
                RPG.sound("dmzpack:pip_menu", 1, 1);
                RPG.screen.update("mode", { label: modeLabel() });
            }),
            btn("shoulder", 64, sideLabel(), function () {
                O.set(K.overShoulderLeft, !left());
                RPG.sound("dmzpack:pip_menu", 1, 1);
                relayout();
            })
        ];
        SLIDERS.forEach(function (s) {
            els.push({ id: "s_" + s.id, type: "slider", anchor: a, x: sx, y: py + s.y, w: SLIDER_W, h: 10, min: s.min, max: s.max, step: 0.01,
                value: value(s), trackColor: "#000000", fillColor: "#5A3A10", knobColor: "#E07A10",
                onChange: function (id, v) { O.set(s.key, Math.round(Number(v) * 100) / 100); } });
        });
        return els;
    }
    function relayout() {
        elements().forEach(function (e) { RPG.screen.update(e.id, { anchor: e.anchor, x: e.x, label: e.label }); });
    }
    function render(ctx) {
        var x = left() ? MARGIN : ctx.width - PANEL_W - MARGIN, y = Math.floor(ctx.height / 2) - Math.floor(PANEL_H / 2);
        ctx.image(MENU_BIG, x, y, PANEL_W, PANEL_H, 0, 0, PANEL_W, PANEL_H, 256, 256);
        ctx.image(MENU_BIG, x + 17, y + 10, 107, 21, 142, 22, 107, 21, 256, 256);
        U.bordered(ctx, U.tr("gui.dragonminez.overShoulder.title"), x + PANEL_W / 2, y + 17, "#FFD700", 0.5);
        var sx = x + (PANEL_W - SLIDER_W) / 2;
        SLIDERS.forEach(function (s) {
            var ly = y + s.y - 11;
            U.bordered(ctx, U.tr(s.label), sx, ly, "#FFFFFF", 0);
            U.bordered(ctx, value(s).toFixed(2), sx + SLIDER_W, ly, "#7CFDD6", 1);
        });
    }
    function open() {
        var wasFirst = false;
        RPG.avatar.players().forEach(function (pl) { if (pl.local) wasFirst = !!pl.firstPerson; });
        S = { wasFirst: wasFirst };
        RPG.camera.mode("third");
        preview = true;
        var mine = S;
        RPG.screen.open({ id: "dmz_over_shoulder", referenceHeight: O.menuRef(), background: "none", pause: false, elements: elements(), onBackground: render,
            onClose: function () {
                if (S !== mine) return;
                S = null; preview = false;
                if (mine.wasFirst) RPG.camera.mode("first");
                // OverShoulderCameraScreen.onClose: back to the options screen
                RPG.schedule(1, function () { if (!RPG.screen.getOpen() && typeof DMZ_CONFIG_MENU !== "undefined") DMZ_CONFIG_MENU.open(); });
            } });
    }

    return { open: open, active: active, MODE_NONE: MODE_NONE, MODE_LOCK_ON: MODE_LOCK_ON, MODE_ALWAYS: MODE_ALWAYS };
})();
