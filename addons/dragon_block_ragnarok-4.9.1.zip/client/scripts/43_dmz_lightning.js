// =====================================================================================
//  43_dmz_lightning.js - bio-electric lightning around players (SSJ2-style sparks)
// =====================================================================================
//  Ported from DragonMine Z 2.2 (GPL-3.0): LightningBoltRenderer (procedural jagged bolts that
//  orbit a 1.9 x 0.62 column around the body, 2 tracks x up to 2 bolts, each struck twice per
//  life and faded over 3 ticks, with barbs and forks), AuraRenderer.renderSparksImpl (third
//  person for everyone, screen-edge bolts at 0.275 alpha in your own first person) and
//  SoundClientHandler (ki_sparks at 0.3 volume every 60 ticks per player with lightning).
//
//  The server shares "dmzBolt" = "#RRGGBB;charged;speed" per player (scripts/31_dmz_transform.js):
//  charged = their aura is showing (faster, thicker bolts), speed = 1.5 during a ki surge.
//  Drawn with the engine's RPG.world3d.bolt (white-hot core, coloured rim, soft halo), following
//  the player smoothly and growing with their model size.
// =====================================================================================
var DMZ_LIGHTNING = (function () {
    var HEIGHT = 1.9, RADIUS = 0.62;
    var TRACKS = 2, TRACK_BOLTS = 2, FP_TRACK_BOLTS = 1;
    var CHARGED_PERIOD = 7, CHARGED_WINDOW = 0.90, IDLE_PERIOD = 14, IDLE_WINDOW = 0.80;
    var START_SPREAD = 0.25, STRIKES = 2, FADE_TICKS = 3, FADE_WIDTH = 0.45;
    var WIDTH_PER_RADIUS = 0.085, CHARGED_WIDTH = 1.35, IDLE_WIDTH = 0.95;
    var BARB_CHANCE = 0.5, MAX_BARBS = 3;
    var FP_ALPHA = 0.275, FP_DEPTH = 1.5, FP_EDGE_BIAS = 0.40, FP_EDGE_LIMIT = 0.97, FP_LENGTH = 0.55, FP_LENGTH_SPREAD = 0.45;
    var FP_UNIT = 0.22, FP_WIDTH = 0.026, FP_TANGENT_JITTER = 1.2;
    var TWO_PI = Math.PI * 2;

    // ---- seeded randomness: the same seed gives the same bolt every tick of its life ----
    function mix(seed, slot, cycle) {
        var h = Math.imul(seed | 0, 0x9E3779B1) ^ Math.imul(slot | 0, 0x85EBCA77) ^ Math.imul(cycle | 0, 0xC2B2AE3D);
        h ^= h >>> 16; h = Math.imul(h, 0x7FEB352D); h ^= h >>> 15; h = Math.imul(h, 0x846CA68B); h ^= h >>> 16;
        return h | 0;
    }
    function Rand(seed) { this.a = seed | 0; }
    Rand.prototype.f = function () {
        var a = this.a = (this.a + 0x6D2B79F5) | 0;
        var t = Math.imul(a ^ (a >>> 15), 1 | a);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    Rand.prototype.b = function () { return this.f() < 0.5; };
    Rand.prototype.i = function (n) { return Math.floor(this.f() * n); };

    function kink(jitter, unit) { var bend = jitter.f(); return (bend < 0.25 ? 0.03 : 0.12 + 0.24 * jitter.f()) * unit; }

    // ---- paths ----
    function orbitPath(shape, jitter, stops, centre, level, h, r) {
        var sweep = (shape.b() ? 1 : -1) * (0.9 + 1.0 * shape.f());
        var theta = centre - sweep * 0.5;
        var rise = (shape.f() - 0.5) * h * 1.1;
        var startY = h * (0.10 + 0.80 * level) - rise * 0.5;
        var baseR = r * (0.95 + 0.45 * shape.f());
        var pts = [], side = jitter.b() ? 1 : -1;
        for (var k = 0; k < stops.length; k++) {
            var s = stops[k], ang = theta + sweep * s;
            var rr = baseR * (1 + 0.3 * Math.sin(Math.PI * s));
            var y = Math.max(h * 0.02, Math.min(h * 1.10, startY + rise * s));
            if (k !== 0 && k !== stops.length - 1) {
                var amp = kink(jitter, r);
                if (jitter.f() < 0.7) side = -side;
                y += amp * side * (0.5 + 0.5 * jitter.f());
                rr += amp * (jitter.f() - 0.5) * 1.4;
            }
            pts.push([Math.cos(ang) * rr, y, Math.sin(ang) * rr]);
        }
        return pts;
    }
    function screenPath(shape, jitter, stops, unit, sw, sh) {
        var dir = shape.f() * TWO_PI, dx = Math.cos(dir), dy = Math.sin(dir);
        var edge = Math.pow(shape.f(), FP_EDGE_BIAS) * FP_EDGE_LIMIT;
        var reach = edge / Math.max(Math.abs(dx), Math.abs(dy));
        var cx = dx * reach * sw, cy = dy * reach * sh;
        var heading = dir + Math.PI / 2 + (shape.f() - 0.5) * FP_TANGENT_JITTER;
        var ax = Math.cos(heading), ay = Math.sin(heading);
        var len = sh * (FP_LENGTH + FP_LENGTH_SPREAD * shape.f());
        var pts = [], side = jitter.b() ? 1 : -1;
        for (var k = 0; k < stops.length; k++) {
            var along = (stops[k] - 0.5) * len, across = 0;
            if (k !== 0 && k !== stops.length - 1) {
                if (jitter.f() < 0.7) side = -side;
                across = kink(jitter, unit) * side * (0.5 + 0.5 * jitter.f());
            }
            pts.push([cx + ax * along - ay * across, cy + ay * along + ax * across, 0]);
        }
        return pts;
    }
    function barb(out, prev, origin, w0, r, shape, jitter, alpha) {
        var d = [origin[0] - prev[0], origin[1] - prev[1], origin[2] - prev[2]];
        var l = Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
        if (l < 1e-3) return;
        d = [d[0] / l + (shape.f() - 0.5) * 1.2, d[1] / l + (shape.f() - 0.5) * 1.2, d[2] / l + (shape.f() - 0.5) * 1.2];
        l = Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
        if (l < 1e-3) return;
        d = [d[0] / l, d[1] / l, d[2] / l];
        var fork = shape.f() < 0.35;
        var len = r * (fork ? 0.45 + 0.45 * shape.f() : 0.15 + 0.20 * shape.f()), kk = len * 0.25;
        var mid = [origin[0] + d[0] * len * 0.45 + (jitter.f() - 0.5) * kk, origin[1] + d[1] * len * 0.45 + (jitter.f() - 0.5) * kk * 2, origin[2] + d[2] * len * 0.45 + (jitter.f() - 0.5) * kk];
        var tip = [origin[0] + d[0] * len, origin[1] + d[1] * len, origin[2] + d[2] * len];
        out.push({ points: [origin[0], origin[1], origin[2], mid[0], mid[1], mid[2], tip[0], tip[1], tip[2]],
            widths: [w0 * 0.7, w0 * (fork ? 0.45 : 0.3), 0], alpha: alpha });
    }

    // one bolt: 6-10 (screen 5-7) uneven segments, widths swelling and pinched to points at the ends
    function bolt(out, seed, life, fade, centre, level, h, r, scale, charged, screen) {
        var strike = Math.min(STRIKES - 1, Math.floor(life * STRIKES));
        var shape = new Rand(seed), jitter = new Rand(mix(seed, 31, strike));
        var baseW = screen ? screen[1] * FP_WIDTH : r * WIDTH_PER_RADIUS * scale;
        var width = baseW * (charged ? CHARGED_WIDTH : IDLE_WIDTH) * (0.8 + 0.4 * shape.f()) * (FADE_WIDTH + (1 - FADE_WIDTH) * fade);
        var n = screen ? 5 + shape.i(3) : 6 + shape.i(5);
        var stops = [0], total = 0, k;
        for (k = 1; k <= n; k++) { total += (shape.f() < 0.4 ? 0.35 : 1.0) * (0.6 + 0.8 * shape.f()); stops.push(total); }
        for (k = 1; k <= n; k++) stops[k] /= total;
        var pts = screen ? screenPath(shape, jitter, stops, r, screen[0], screen[1]) : orbitPath(shape, jitter, stops, centre, level, h * scale, r * scale);
        var widths = [];
        for (k = 0; k <= n; k++) {
            var end = k === 0 || k === n;
            var profile = Math.pow(Math.sin(Math.PI * stops[k]), 0.8);
            var swell = k % 2 === 0 ? 0.45 + 0.35 * shape.f() : 0.9 + 0.5 * shape.f();
            widths.push(end ? 0 : width * profile * swell);
        }
        var barbs = 0;
        for (k = 1; k < n && barbs < MAX_BARBS; k++) {
            if (shape.f() >= BARB_CHANCE) continue;
            barbs++;
            barb(out, pts[k - 1], pts[k], widths[k], screen ? r : r * scale, shape, jitter, fade);
        }
        var flat = [];
        pts.forEach(function (p) { flat.push(p[0], p[1], p[2]); });
        out.push({ points: flat, widths: widths, alpha: fade });
    }

    function burst(out, seed, track, clockTicks, scale, charged, screen) {
        var period = charged ? CHARGED_PERIOD : IDLE_PERIOD, win = charged ? CHARGED_WINDOW : IDLE_WINDOW;
        var clock = clockTicks / period + track / TRACKS, cur = Math.floor(clock);
        for (var cycle = cur - 1; cycle <= cur; cycle++) {
            var elapsed = (clock - cycle) * period;
            var bs = mix(seed, track, cycle), pick = new Rand(bs);
            var count = 1 + pick.i(screen ? FP_TRACK_BOLTS : TRACK_BOLTS);
            var baseAngle = pick.f() * TWO_PI, baseLevel = pick.f(), sector = TWO_PI / count;
            for (var i = 0; i < count; i++) {
                var delay = pick.f() * START_SPREAD * period;
                var hold = win * (0.6 + 0.4 * pick.f()) * period;
                var aj = (pick.f() - 0.5) * 0.6;
                var age = elapsed - delay;
                if (age < 0 || age >= hold + FADE_TICKS) continue;
                var life = Math.min(age / hold, 1);
                var fade = age < hold ? 1 : 1 - (age - hold) / FADE_TICKS;
                bolt(out, mix(bs, i, cycle), life, fade, baseAngle + sector * (i + aj), (baseLevel + i / count) % 1,
                    HEIGHT, screen ? FP_UNIT * screen[1] : RADIUS, scale, charged, screen);
            }
        }
    }

    // ---- per tick: every player with lightning ----
    var drawn = {}, soundAt = {}, clock = {};
    function parse(v) {
        if (!v) return null;
        var a = String(v).split(";");
        if (!/^#[0-9A-Fa-f]{6}$/.test(a[0])) return null;
        return { color: a[0], charged: a[1] === "1", speed: Number(a[2]) || 1 };
    }
    RPG.on("tick", function () {
        var seen = {};
        if (RPG.player.present) {
            RPG.avatar.players().forEach(function (pl) {
                var b = parse(pl.shared("dmzBolt", null));
                if (!b || pl.dead || pl.spectator || pl.invisible) return;
                var id = pl.id, key = "dmzbolt_" + id;
                seen[key] = true;
                // the bolt clock runs faster during a surge (lightningSpeedMultiplier)
                clock[id] = (clock[id] === undefined ? pl.tick : clock[id] + b.speed);
                var paths = [];
                var fp = pl.local && pl.firstPerson;
                if (fp) {
                    var aspect = Math.max(0.5, RPG.screenWidth / Math.max(1, RPG.screenHeight));
                    for (var t = 0; t < TRACKS; t++) burst(paths, id, t, clock[id], 1, b.charged, [aspect, 1]);
                    RPG.world3d.bolt(key, { anchor: "screen", entity: -1, depth: FP_DEPTH, paths: paths, color: b.color, coreWhite: 0.85,
                        alpha: FP_ALPHA, glow: 0.6, ticks: 3 });
                } else {
                    var size = Math.max(0.2, Number(pl.modelSize) || 1);
                    for (var t2 = 0; t2 < TRACKS; t2++) burst(paths, id, t2, clock[id], size, b.charged, null);
                    RPG.world3d.bolt(key, { anchor: "world", entity: id, paths: paths, color: b.color, coreWhite: 0.85, alpha: 1, glow: 0.6, ticks: 3 });
                }
                drawn[key] = true;
                // SoundClientHandler: ki_sparks every 60 ticks per player while their lightning shows
                var now = pl.gameTime;
                if (soundAt[id] === undefined || now >= soundAt[id]) {
                    RPG.soundAt("dmzpack:ki_sparks", pl.x, pl.y, pl.z, 0.3, 0.9 + Math.random() * 0.2);
                    soundAt[id] = now + 60;
                }
            });
        }
        Object.keys(drawn).forEach(function (k) {
            if (seen[k]) return;
            RPG.world3d.remove(k);
            delete drawn[k];
            var id = k.substring(8);
            delete soundAt[id]; delete clock[id];
        });
    });
    RPG.on("unload", function () { drawn = {}; soundAt = {}; clock = {}; });

    return { mix: mix };
})();
