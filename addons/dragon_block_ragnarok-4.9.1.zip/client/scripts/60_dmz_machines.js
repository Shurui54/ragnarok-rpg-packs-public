// =====================================================================================
//  60_dmz_machines.js - DragonMine Z's machine screens (GPL-3.0 port)
// =====================================================================================
//  PatternStationScreen, KikonoStationScreen, FuelGeneratorScreen, GravityDeviceScreen with
//  DMZ's textures (dmzpack:textures/gui/screen/*) and slot positions (shared/12_dmz_machines_data.js).
//  The server (scripts/58_dmz_machines.js) owns every item: a click here is sent as
//  {a: "click", s: slot, b: button, sh: shift}, the server answers with the new slots.
//  Also the client half of GravityLogic: extra fall speed under gravity, and DMZ_GRAVITY_CLIENT
//  (jump / flight factors) for the flight and jump scripts.
// =====================================================================================
var DMZ_GRAVITY_CLIENT = { net: 0, jump: 1, fly: 1, fall: 0, hardStop: false };

(function () {
    var FONT = "dmzpack:smooth";
    var C = null;          // the open machine screen

    function lay() { return DMZ_MACH.LAYOUT[C.type]; }
    function slotsOf(type) { return DMZ_MACH.LAYOUT[type].slots; }
    function viewOf(sid) {
        if (sid.charAt(0) === "p") return C.inv[Number(sid.substring(1))] || null;
        return C.slots[sid] || null;
    }
    function itemProps(v) {
        if (!v) return { visible: false };
        return { visible: true, item: v.i, count: v.c, tooltip: { title: v.t[0], lines: v.t.slice(1) } };
    }
    function energyTip() {
        var d = C.data || {};
        if (C.type === "fuel_generator") return RPG.translate("gui.dragonminez.fuel_generator.energy", d.e || 0, d.max || 0);
        return (d.e || 0) + " / " + (d.max || 0) + " Star Energy";
    }
    function toggleLabel() {
        return RPG.translate(C.data && C.data.active ? "gui.dragonminez.gravity_device.turn_off" : "gui.dragonminez.gravity_device.turn_on");
    }
    function parseGravity() {
        var v = parseInt(String(RPG.screen.value("grav_in") || ""), 10), max = (C.data && C.data.maxG) || 1000;
        if (!isFinite(v)) v = 1;
        return Math.max(1, Math.min(v, max));
    }
    function sendGravity(on) { RPG.net.send("dmzm", { a: "grav", on: on, g: parseGravity() }); }

    function build(d) {
        var L = DMZ_MACH.LAYOUT[d.type], W = L.w, H = L.h, ox = -W / 2, oy = -H / 2;
        var els = [{ id: "bg", type: "image", anchor: "center", x: ox, y: oy, w: W, h: H, texture: L.tex, u: 0, v: 0, uw: W, vh: H, texW: L.texW, texH: L.texH }];
        // energy bar hover areas (the screens' renderTooltip rectangles)
        if (d.type === "fuel_generator") els.push({ id: "etip", type: "rect", anchor: "center", x: ox + 156, y: oy + 16, w: 9, h: 53, color: "#00000000", tooltip: "" });
        if (d.type === "gravity_device") els.push({ id: "etip", type: "rect", anchor: "center", x: ox + 154, y: oy + 16, w: 13, h: 53, color: "#00000000", tooltip: "" });
        if (d.type === "kikono_station") els.push({ id: "etip", type: "rect", anchor: "center", x: ox + 10, y: oy + 16, w: 9, h: 53, color: "#00000000", tooltip: "" });
        els.push({ id: "hl", type: "rect", anchor: "topleft", x: 0, y: 0, w: 16, h: 16, color: "#80FFFFFF", visible: false });
        L.slots.forEach(function (s) {
            els.push({ id: "it_" + s[0], type: "item", anchor: "center", x: ox + s[1], y: oy + s[2], w: 16, h: 16, item: "minecraft:air", visible: false });
        });
        if (d.type === "gravity_device") {
            els.push({ id: "grav_in", type: "input", anchor: "center", x: ox + 40, y: oy + 20, w: 50, h: 16, maxLength: 4,
                value: String(Math.max(1, (d.data && d.data.g) || 1)) });
            els.push({ id: "grav_set", type: "button", anchor: "center", x: ox + 95, y: oy + 19, w: 40, h: 18, font: FONT,
                label: RPG.translate("gui.dragonminez.gravity_device.set"), onClick: function () { if (C) sendGravity(!!(C.data && C.data.active)); } });
            els.push({ id: "grav_toggle", type: "button", anchor: "center", x: ox + 40, y: oy + 42, w: 95, h: 18, font: FONT, label: "",
                onClick: function () { if (C) sendGravity(!(C.data && C.data.active)); } });
        }
        els.push({ id: "carried", type: "item", anchor: "topleft", x: 0, y: 0, w: 16, h: 16, item: "minecraft:air", visible: false });
        return els;
    }

    function apply(d) {
        if (d.slots) { Object.keys(d.slots).forEach(function (k) { C.slots[k] = d.slots[k]; RPG.screen.update("it_" + k, itemProps(d.slots[k])); }); }
        if (d.inv) { C.inv = d.inv; for (var i = 0; i < 36; i++) RPG.screen.update("it_p" + i, itemProps(d.inv[i])); }
        if (d.carried !== undefined) {
            C.carried = d.carried;
            RPG.screen.update("carried", d.carried ? { visible: true, item: d.carried.i, count: d.carried.c } : { visible: false });
        }
        if (d.data) {
            C.data = d.data;
            if (C.type !== "pattern_station") RPG.screen.update("etip", { tooltip: energyTip() });
            if (C.type === "gravity_device") RPG.screen.update("grav_toggle", { label: toggleLabel() });
        }
    }

    RPG.net.on("dmzm_open", function (d) {
        C = { type: d.type, key: d.key, slots: {}, inv: [], carried: null, data: d.data || {}, lw: 0, lh: 0, hover: null, serverClosed: false };
        RPG.screen.open({ id: "dmz_machine", background: "dim", elements: build(d), onRender: render, onMouse: mouse, onKey: key,
            onClose: function () {
                if (C && !C.serverClosed) RPG.net.send("dmzm", { a: "close" });
                C = null;
            } });
        apply(d);
    });
    RPG.net.on("dmzm_state", function (d) { if (C && d && d.key === C.key) apply(d); });
    RPG.net.on("dmzm_close", function () {
        if (!C) return;
        C.serverClosed = true;
        if (RPG.screen.getOpen() === "dmz_machine") RPG.screen.close();
        C = null;
    });

    function origin() { var L = lay(); return { x: Math.round(C.lw / 2 - L.w / 2), y: Math.round(C.lh / 2 - L.h / 2) }; }
    function slotAt(x, y) {
        if (!C || !C.lw) return null;
        var o = origin(), s = slotsOf(C.type);
        for (var i = 0; i < s.length; i++) {
            var sx = o.x + s[i][1], sy = o.y + s[i][2];
            if (x >= sx - 1 && x < sx + 17 && y >= sy - 1 && y < sy + 17) return s[i];
        }
        return null;
    }
    function shift() { return RPG.isKeyDown("key.keyboard.left.shift") || RPG.isKeyDown("key.keyboard.right.shift"); }
    function mouse(x, y, button, action) {
        if (!C || action !== "down" || button > 1) return;
        var s = slotAt(x, y);
        if (!s) return;
        RPG.net.send("dmzm", { a: "click", s: s[0], b: button, sh: shift() });
        return false;
    }
    function key(name, action) {
        // the inventory key closes a container screen (the text box has the keys while it is focused)
        if (action === "down" && name === "key.keyboard.e" && C) { RPG.screen.close(); return false; }
    }

    function render(ctx) {
        if (!C) return;
        C.lw = ctx.width; C.lh = ctx.height;
        var L = lay(), o = origin(), x = o.x, y = o.y, d = C.data || {}, tex = L.tex;
        // labels: title + "Inventory" (AbstractContainerScreen.renderLabels), the Gravity Device centres its title with a border
        if (C.type === "gravity_device") ctx.textStyled(RPG.translate(L.title), x + L.w / 2, y + 6, 1, "#FFFFFF", 1, 0.5, FONT, "#000000");
        else ctx.text(RPG.translate(L.title), x + 8, y + 6, "#404040", false);
        ctx.text(RPG.translate("container.inventory"), x + L.invLabel[0], y + L.invLabel[1], "#404040", false);
        // bars
        if (C.type !== "pattern_station") {
            var eh = d.max ? Math.floor((d.e || 0) * 60 / d.max) : 0, ex = C.type === "kikono_station" ? 9 : 154;
            if (eh > 0) ctx.image(tex, x + ex, y + 21 + (52 - eh), 12, eh, 177, 21 + (60 - eh), 12, eh, 256, 256);
        }
        if (C.type === "fuel_generator" && d.burn > 0) {
            var k = d.maxBurn ? Math.floor((d.maxBurn - d.burn) * 14 / d.maxBurn) : 0;
            if (k > 0) ctx.image(tex, x + 81, y + 19 + (14 - k), 14, k, 177, 1 + (14 - k), 14, k, 256, 256);
        }
        if (C.type === "kikono_station" && d.prog > 0 && d.maxProg > 0) {
            var w = Math.floor(d.prog * 26 / d.maxProg);
            if (w > 0) ctx.image(tex, x + 111, y + 35, w, 17, 177, 2, w, 17, 256, 256);
        }
        if (C.type === "gravity_device") {
            var st, col;
            if (!d.valid) { st = RPG.translate("gui.dragonminez.gravity_device.no_room"); col = "#FF5555"; }
            else if (d.running) { st = RPG.translate("gui.dragonminez.gravity_device.running", d.g); col = "#55FF55"; }
            else if (d.active) { st = RPG.translate("gui.dragonminez.gravity_device.no_energy"); col = "#FFAA00"; }
            else { st = RPG.translate("gui.dragonminez.gravity_device.idle"); col = "#AAAAAA"; }
            ctx.textStyled(st, x + L.w / 2, y + 64, 1, col, 1, 0.5, FONT, "#000000");
        }
        // slot highlight under the mouse, and the item on the mouse
        var s = slotAt(ctx.mouseX, ctx.mouseY), hk = s ? s[0] + "@" + x + "," + y : null;
        if (hk !== C.hover) {
            C.hover = hk;
            RPG.screen.update("hl", s ? { visible: true, x: x + s[1], y: y + s[2] } : { visible: false });
        }
        if (C.carried) RPG.screen.update("carried", { x: Math.round(ctx.mouseX - 8), y: Math.round(ctx.mouseY - 8) });
    }

    // ---- gravity on this computer (MovementSkillsHandler: extra fall speed; flight/jump read DMZ_GRAVITY_CLIENT) ----
    RPG.on("tick", function () {
        var g = RPG.getVar("dmz_gravity", null);
        if (!g) { DMZ_GRAVITY_CLIENT.net = 0; DMZ_GRAVITY_CLIENT.jump = 1; DMZ_GRAVITY_CLIENT.fly = 1; DMZ_GRAVITY_CLIENT.fall = 0; DMZ_GRAVITY_CLIENT.hardStop = false; return; }
        DMZ_GRAVITY_CLIENT.net = g.net || 0;
        DMZ_GRAVITY_CLIENT.jump = typeof g.jump === "number" ? g.jump : 1;
        DMZ_GRAVITY_CLIENT.fly = typeof g.fly === "number" ? g.fly : 1;
        DMZ_GRAVITY_CLIENT.fall = g.fall || 0;
        DMZ_GRAVITY_CLIENT.hardStop = (g.net || 0) >= (g.hard || 75);
        var p = RPG.player;
        if (!p.present || !(g.fall > 0)) return;
        if (!p.onGround && !p.flying && !p.inWater && !p.hasEffect("flight")) p.addVelocity(0, -g.fall, 0);
    });
})();
