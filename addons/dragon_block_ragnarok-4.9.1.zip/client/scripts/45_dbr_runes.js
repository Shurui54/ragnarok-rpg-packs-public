// =====================================================================================
//  45_dbr_runes.js - DMZ Ragnarok's armour rune tooltips (RuneTooltip, RuneItem)
// =====================================================================================
//  Armour that has rolled shows its rune slots, one arrow row per stat and its equipment
//  tier, plus the removal risk of every socketed rune; rune items show what they favour,
//  what they weaken, their grade and their tier. Text lines (shared/26_dbr_runes.js), so
//  they compose with every other tooltip line, in any inventory or recipe viewer.
// =====================================================================================
(function () {
    var IDS = {};          // placeholder id -> [stat, grade, allStats], sent by scripts/19_dbr_runes.js
    RPG.net.on("dbr_runes_ids", function (t) { IDS = t || {}; });
    RPG.on("load", function () { RPG.net.send("dbr_runes_hello", {}); });

    RPG.on("itemTooltip", function (stack) {
        var r = IDS[stack.id];
        if (r) return DBR_RUNES.runeTooltip({ stat: r[0], grade: r[1], allStats: !!r[2] }, stack);
        return DBR_RUNES.has(stack) ? DBR_RUNES.armorTooltip(stack) : null;
    });
})();
