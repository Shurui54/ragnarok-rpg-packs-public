// =====================================================================================
//  DMZ parties on the client (server: scripts/78_dmz_party.js). Ports of DragonMine Z (GPL-3.0):
//   - PartyHUD: up to 3 other members on the left (name, HP + ki bars, red when down, distance when out of
//     sight), drawn in DMZ Ragnarok's HUD art (dbr:textures/gui/hud/ragnarok). Movable ("Party").
//   - PartyMarkerOverlay: a marker above every other member's head (hidden within 2.5 blocks), name +
//     distance, bigger when you look at it. Movable/hideable as "Party Markers".
//   - PartyInviteToastS2C: the invite pops up in the DMZ notification panel (47_dmz_notifications.js).
//   - PartyMenuScreen (simplified): V menu > Party tab: create, invite, leave/disband, kick, PvP,
//     invitations with accept/reject and the difficulty confirmation.
// =====================================================================================
var DMZ_PARTY_UI = (function () {
    var SHEET = "dmzpack:textures/gui/hud/hud_party.png", SW = 256, SH = 128, FONT = "dmzpack:smooth";
    var HUD = { members: [] }, STATE = null, PENDING_CONFIRM = null;
    function tr(key, fallback) {
        var args = Array.prototype.slice.call(arguments, 2), i = 0;
        if (!RPG.hasTranslation(key)) return fallback;
        var s = String(RPG.translate(key));
        s = s.replace(/%(\d+)\$s/g, function (m, n) { var v = args[Number(n) - 1]; return v === undefined ? "" : String(v); });
        return s.replace(/%s|%d/g, function () { var v = args[i++]; return v === undefined ? "" : String(v); }).replace(/%%/g, "%");
    }
    function sprite(ctx, u, v, w, h, x, y, dw, dh, color, a) {
        ctx.quad(SHEET, x, y, dw, dh, u / SW, v / SH, (u + w) / SW, (v + h) / SH, color || "#FFFFFF", a);
    }
    function hpColor(f) { return f > 0.5 ? "#5BD64A" : f > 0.25 ? "#F2C94C" : "#E5484D"; }
    function fmt(n) { n = Math.round(n || 0); return n >= 1e6 ? (n / 1e6).toFixed(1) + "M" : n >= 1e4 ? (n / 1e3).toFixed(1) + "K" : String(n); }

    RPG.net.on("dmz_party_hud", function (d) { HUD = d || { members: [] }; });
    RPG.net.on("dmz_party_state", function (d) { STATE = d; if (RPG.screen.getOpen() === "dmz_party") openScreen(); });
    RPG.net.on("dmz_open_party", function () { openScreen(); });
    RPG.net.on("dmz_party_invite", function (d) {
        RPG.sound("dmzpack:pip_menu", 1, 1.2);
        if (typeof DMZ_NOTIFY !== "undefined")
            DMZ_NOTIFY.push({ title: tr("toast.dragonminez.party.invite.title", "Party Invite"), description: tr("toast.dragonminez.party.invite.desc", (d.from || "?") + " invited you to a quest party", d.from || "?"),
                extra: "/rpgc party accept" }, DMZ_NOTIFY.PRIORITY.HIGH);
    });
    RPG.net.on("dmz_party_confirm", function (d) { PENDING_CONFIRM = d; openConfirm(d); });

    // ---- PartyHUD, in DMZ Ragnarok's HUD art (the "Ragnarok" style of 11_hud_ragnarok.js) ----
    // Each member is a small copy of the Ragnarok stat panel: the scouter orb (lens + ring) with their initial and
    // the form crescent under it in their aura colour, then the gold-trimmed navy housing with their health (DMZ
    // Ragnarok's green > amber > red ramp, red tint when down) and the ki track filled in their aura colour.
    // Same data as DMZ's PartyHUD: name, distance when out of sight / far, health number. Movable as "Party".
    function rtex(n) { return "dbr:textures/gui/hud/ragnarok/" + n + ".png"; }
    function img(ctx, n, x, y, w, h, color, a) { ctx.quad(rtex(n), x, y, w, h, 0, 0, 1, 1, color || "#FFFFFF", a === undefined ? 1 : a); }
    function part(ctx, n, x, y, w, h, f, color, a) { if (f > 0) ctx.quad(rtex(n), x, y, w * f, h, 0, 0, f, 1, color, a === undefined ? 1 : a); }
    function lerpHex(a, b, t) {
        var pa = parseInt(a.substring(1), 16), pb = parseInt(b.substring(1), 16), r = 0;
        for (var sh = 16; sh >= 0; sh -= 8) { var ca = (pa >> sh) & 255, cb = (pb >> sh) & 255; r |= Math.round(ca + (cb - ca) * t) << sh; }
        return "#" + ("000000" + r.toString(16)).slice(-6);
    }
    function healthRamp(f) {                     // 11_hud_ragnarok.js healthRgb: red -> amber -> green
        var toAmber = Math.max(0, Math.min(1, f / 0.5)), toGreen = Math.max(0, Math.min(1, (f - 0.5) / 0.5));
        return lerpHex(lerpHex("#FF001D", "#FFBB00", toAmber), "#0CFF00", toGreen);
    }
    function others() {
        var me = RPG.player.name;
        return (HUD.members || []).filter(function (m) { return m.name !== me; }).slice(0, 3);
    }
    var K = 0.4;                                  // the housing at 0.4 of the main panel's size
    var ORB_W = 68 * 0.36, ORB_H = 79 * 0.36, ROW = 31, HX = ORB_W + 1;
    var FR = { x: HX, y: 9, w: 209 * K, h: 31 * K }, HB = { x: HX + 17 * K, y: 9 + 7 * K, w: 188 * K, h: 20 * K };
    var KT = { x: HX + 15 * K, y: 9 + 29 * K, w: 114 * K, h: 18 * K }, KB = { x: HX + 19 * K, y: 9 + 33 * K, w: 106 * K, h: 10 * K };
    var PANEL_W = HX + 209 * K + 2, PANEL_H = 3 * ROW + 2;
    function drawHud(ctx) {
        if (!RPG.player.present) return;
        var list = others(), editing = ctx.isEditing();
        if (!list.length && !editing) return;
        if (!list.length) list = [{ name: "Goku", hp: 1800, max: 2000, ki: 900, kmax: 1500, aura: "#FF8A65" }, { name: "Vegeta", hp: 450, max: 2000, ki: 1300, kmax: 1500, aura: "#4FC3FF" },
            { name: "Piccolo", hp: 1200, max: 2000, ki: 400, kmax: 1500, aura: "#7CFDD6", far: true }];
        var unit = Math.max(0.25, ctx.height / 360), sc = 0.9 * unit, w = PANEL_W * sc, h = PANEL_H * sc, x = 46 * unit, y = ctx.height / 2 - h / 2;
        if (!ctx.group("dmz_party_hud", tr("gui.dragonminez.hud_editor.element.party", "Party"), x, y, w, h)) return;
        ctx.push();
        ctx.translate(x, y);
        ctx.scale(sc, sc);
        var startY = 1 + (3 - list.length) * ROW / 2;
        list.forEach(function (m, i) {
            ctx.push();
            ctx.translate(0, startY + i * ROW);
            var down = m.down || m.hp <= 0, aura = m.aura || "#4FC3FF";
            var f = m.max > 0 ? Math.max(0, Math.min(1, m.hp / m.max)) : 0, kf = m.kmax > 0 ? Math.max(0, Math.min(1, m.ki / m.kmax)) : 0;
            // the orb: lens, initial, aura crescent, ring (red-tinted when down)
            img(ctx, "orb", 0, 0, ORB_W, ORB_H);
            ctx.textStyled(String(m.name).charAt(0).toUpperCase(), ORB_W / 2, 7.4, 1.1, "#FFFFFF", 1, 0.5, FONT, "#000000");
            img(ctx, "transform_arc", 11 * 0.36, 57 * 0.36, 46 * 0.36, 12 * 0.36, aura, 1);
            img(ctx, "orb_frame", 0, 0, ORB_W, ORB_H, down ? "#FF6060" : "#FFFFFF", 1);
            // name and distance over the housing
            ctx.textStyled(m.name, HX + 3, 0, 0.75, down ? "#FF7A7A" : "#FFFFFF", 1, 0, FONT, "#000000");
            var p = RPG.player, far = m.far || m.dim !== p.dimension;
            if (far || dist(m) > 64) ctx.textStyled(far ? "?" : Math.round(dist(m)) + "m", HX + 3 + ctx.textWidthIn(m.name, FONT) * 0.75 + 4, 0, 0.75, "#A8B0C0", 1, 0, FONT, "#000000");
            // housing + health, ki track + ki
            img(ctx, "main_frame", FR.x, FR.y, FR.w, FR.h);
            part(ctx, "health_fill_grey", HB.x, HB.y, HB.w, HB.h, f, down ? "#7A0000" : healthRamp(f), 1);
            img(ctx, "ki_track", KT.x, KT.y, KT.w, KT.h);
            part(ctx, "ki_fill_grey", KB.x, KB.y, KB.w, KB.h, kf, aura, 1);
            ctx.textStyled(fmt(m.hp), HB.x + HB.w - 2, HB.y + 1.6, 0.6, "#FFFFFF", 1, 1, FONT, "#000000");
            ctx.pop();
        });
        ctx.pop();
        ctx.endGroup();
    }
    function dist(m) { var p = RPG.player, dx = m.x - p.x, dy = m.y - p.y, dz = m.z - p.z; return Math.sqrt(dx * dx + dy * dy + dz * dz); }

    // ---- PartyMarkerOverlay ----
    function drawMarkers(ctx) {
        if (!RPG.player.present || !RPG.storage.get("dmz_cfg_party_markers", true)) return;   // DMZ option "Party Markers"
        var list = others(), p = RPG.player;
        if (!list.length) return;
        if (!ctx.group("dmz_party_markers", tr("gui.dragonminez.config.partyMarkers", "Party Markers"), ctx.width / 2 - 20, 6, 40, 12)) return;
        if (ctx.isEditing()) { ctx.textStyled("Party Markers", ctx.width / 2, 8, 0.75, "#FFFFFF", 1, 0.5, FONT, "#000000"); ctx.endGroup(); return; }
        var unit = Math.max(0.25, ctx.height / 360), cx = ctx.width / 2, cy = ctx.height / 2;
        list.forEach(function (m) {
            if (m.dim !== p.dimension) return;
            var d = dist(m);
            if (d < 2.5 || d > 2000) return;
            var s = RPG.project(m.x, m.y + 0.4, m.z);
            if (!s.visible) return;
            var off = Math.sqrt((s.x - cx) * (s.x - cx) + (s.y - cy) * (s.y - cy)), focus = off < 12 * unit, k = (focus ? 1.6 : 1) * unit, a = focus ? 1 : 0.8;
            var tint = m.down ? "#FF7A7A" : (m.aura || "#4FC3FF");
            ctx.push();
            ctx.translate(s.x, s.y);
            ctx.scale(k, k);
            sprite(ctx, 200, 0, 32, 32, -4, -8, 8, 8, tint, a);
            img(ctx, "orb", -5, -20.5, 10, 11.6, "#FFFFFF", a);           // the Ragnarok orb in place of DMZ's head frame
            img(ctx, "orb_frame", -5, -20.5, 10, 11.6, tint, a);
            ctx.textStyled(m.name, 0, -28, 0.75, m.down ? "#FF7A7A" : "#FFFFFF", a, 0.5, FONT, "#000000");
            if (focus) ctx.textStyled(Math.round(d) + "m", 0, -37, 0.75, "#B8C0CC", a, 0.5, FONT, "#000000");
            ctx.pop();
        });
        ctx.endGroup();
    }

    // ---- PartyMenuScreen (simplified) ----
    function send(action, extra) { var d = extra || {}; d.action = action; RPG.net.send("dmz_party", d); RPG.sound("dmzpack:ui_menu_switch", 1, 1); }
    // the form editor's look (70_form_editor.js panel()): DMZ's quest-menu panel, the menubig ribbon carrying the
    // gold title, DMZ's characterbuttons buttons. bg = the {x, y, w, h} the panel covers, centre-relative.
    function styled(spec, bg, title) {
        var U = DMZ_UI;
        spec.elements.forEach(function (e) { if (e.type === "button") for (var k in U.BUTTON_SKIN) if (e[k] === undefined) e[k] = U.BUTTON_SKIN[k]; });
        spec.onBackground = function (ctx) {
            var x = ctx.width / 2 + bg.x, y = ctx.height / 2 + bg.y;
            U.QUEST_PANEL.draw(ctx, x, y, bg.w, bg.h);
            var tw = Math.min(bg.w - 30, 150);
            U.slice9(ctx, "dmzpack:textures/gui/menu/menubig.png", x + (bg.w - tw) / 2, y + 7, tw, 21, 142, 22, 107, 21, 10);
            ctx.textStyled("§l" + title, x + bg.w / 2, y + 14, 1, "#FFD700", 1, 0.5, "dmzpack:smooth", "#000000");
        };
        return spec;
    }
    var inviteOpen = false;
    function openScreen() {
        var st = STATE || { members: [], invites: [], players: [] }, els = [], y = -82;
        var me = st.me, mine = null;
        (st.members || []).forEach(function (m) { if (m.id === me) mine = m; });
        var leader = !!(mine && mine.leader), owner = !!(mine && mine.owner);
        if (!st.id) {
            els.push({ id: "hint", type: "text", anchor: "center", x: 0, y: y, text: tr("gui.dragonminez.party.create_hint", "Create a party to share quest progress."), align: "center", color: "#FFFFFF", wrap: 260 });
            els.push({ id: "w1", type: "text", anchor: "center", x: -135, y: y + 18, text: "§7- " + tr("gui.dragonminez.party.welcome.quests", "Share quest progress."), color: "#FFFFFF", wrap: 270 });
            els.push({ id: "w2", type: "text", anchor: "center", x: -135, y: y + 30, text: "§7- " + tr("gui.dragonminez.party.welcome.explore", "Friendly fire off by default."), color: "#FFFFFF", wrap: 270 });
            els.push({ id: "create", type: "button", anchor: "center", x: -50, y: y + 48, w: 100, h: 18, label: tr("gui.dragonminez.party.create", "Create Party"), onClick: function () { send("create"); } });
            y += 76;
        } else {
            els.push({ id: "role", type: "text", anchor: "center", x: -135, y: y, text: (leader ? tr("gui.dragonminez.party.role.leader", "Role: Leader") : tr("gui.dragonminez.party.role.member", "Role: Member")) +
                "   " + tr("gui.dragonminez.party.members", "Members: " + st.members.length, String(st.members.length)) + "   PvP: " + (st.pvp ? "§con" : "§aoff"), color: "#C7EAFC" });
            y += 14;
            st.members.forEach(function (m, i) {
                var line = (m.online ? "§f" : "§7") + m.name + (m.leader ? " §e(leader)" : "") + (m.owner ? " §6★" : "") + (m.online ? "  §7Lv " + (m.level || "?") + "  " + (m.race || "") + "  " + (m.cls || "") + "  §c" + fmt(m.hp) + "/" + fmt(m.max) : "  §8offline");
                els.push({ id: "m" + i, type: "text", anchor: "center", x: -135, y: y, text: line, color: "#FFFFFF" });
                if (leader && m.id !== me && !m.owner) els.push({ id: "k" + i, type: "button", anchor: "center", x: 100, y: y - 3, w: 36, h: 13, label: "Kick", onClick: function () { send("kick", { id: m.id }); } });
                y += 14;
            });
            y += 4;
            if (leader) {
                els.push({ id: "inv", type: "button", anchor: "center", x: -140, y: y, w: 90, h: 18, label: tr("gui.dragonminez.party.invite_players", "Invite Players"), onClick: function () { inviteOpen = !inviteOpen; openScreen(); } });
                els.push({ id: "pvp", type: "button", anchor: "center", x: -45, y: y, w: 90, h: 18, label: "PvP: " + (st.pvp ? "On" : "Off"), onClick: function () { send("pvp"); } });
            }
            els.push({ id: "leave", type: "button", anchor: "center", x: 50, y: y, w: 90, h: 18, label: owner && st.members.length > 1 ? tr("gui.dragonminez.party.disband", "Disband Party") : tr("gui.dragonminez.party.leave", "Leave Party"),
                onClick: function () { send(owner && st.members.length > 1 ? "disband" : "leave"); } });
            y += 24;
            if (inviteOpen && leader) {
                if (!st.players.length) els.push({ id: "none", type: "text", anchor: "center", x: -135, y: y, text: "§7" + tr("gui.dragonminez.party.invite_none", "No players available"), color: "#FFFFFF" });
                st.players.slice(0, 8).forEach(function (o, i) {
                    els.push({ id: "pl" + i, type: "button", anchor: "center", x: -140 + (i % 4) * 70, y: y + Math.floor(i / 4) * 16, w: 66, h: 14, label: o.name, tooltip: "Lv " + o.level, onClick: function () { send("invite", { name: o.name }); } });
                });
                y += 36;
            }
        }
        if (st.invites && st.invites.length) {
            els.push({ id: "ih", type: "text", anchor: "center", x: -135, y: y, text: "§l" + tr("gui.dragonminez.party.invites", "Invitations"), color: "#FFD54F" });
            y += 12;
            st.invites.slice(0, 3).forEach(function (iv, i) {
                els.push({ id: "iv" + i, type: "text", anchor: "center", x: -135, y: y + 3, text: iv.from + " §7(" + iv.diff + ", " + iv.left + "s)", color: "#FFFFFF" });
                els.push({ id: "ia" + i, type: "button", anchor: "center", x: 40, y: y, w: 46, h: 14, label: tr("quest.dmz.party.invite.accept", "Accept"), onClick: function () { send("accept", { party: iv.party }); } });
                els.push({ id: "ir" + i, type: "button", anchor: "center", x: 90, y: y, w: 46, h: 14, label: tr("quest.dmz.party.invite.reject", "Reject"), onClick: function () { send("reject", { party: iv.party }); } });
                y += 16;
            });
        }
        RPG.screen.open(styled({ id: "dmz_party", referenceHeight: DMZ_OPTS.menuRef(), background: "dim", elements: els },
            { x: -155, y: -120, w: 310, h: Math.max(140, y + 140) }, tr("gui.dragonminez.party.title", "Party")));
    }
    function openConfirm(d) {
        RPG.screen.open(styled({ id: "dmz_party_confirm", referenceHeight: DMZ_OPTS.menuRef(), background: "dim", elements: [
            { id: "b", type: "text", anchor: "center", x: -115, y: -24, wrap: 230, color: "#FFFFFF",
                text: tr("gui.dragonminez.party.confirm.difficulty.body", "This party plays on " + d.diff + ". Joining changes your difficulty permanently. Continue?", d.diff) },
            { id: "y", type: "button", anchor: "center", x: -100, y: 20, w: 90, h: 18, label: tr("gui.dragonminez.party.confirm_yes", "Confirm"), onClick: function () { RPG.screen.close(); send("accept", { party: d.party, confirm: true }); } },
            { id: "n", type: "button", anchor: "center", x: 10, y: 20, w: 90, h: 18, label: tr("gui.dragonminez.party.confirm_no", "Cancel"), onClick: function () { RPG.screen.close(); } }
        ] }, { x: -135, y: -62, w: 270, h: 112 }, tr("gui.dragonminez.party.confirm.difficulty.title", "Difficulty Change")));
    }

    RPG.on("load", function () { RPG.hud.onRender(drawHud); RPG.hud.onRender(drawMarkers); });
    return { open: function () { RPG.net.send("dmz_party", { action: "state" }); openScreen(); } };
})();
