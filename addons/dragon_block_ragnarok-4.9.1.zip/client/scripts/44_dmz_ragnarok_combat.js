// =====================================================================================
//  44_dmz_ragnarok_combat.js - DMZ Ragnarok's combat layer on the player's computer
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0), shuruisutilities/client/combat:
//    DashInput             double-tap the Ragnarok Dash key (R): the movement keys held choose the
//                          dash (S over the top, A / D round a flank, W or nothing straight in)
//    DashAuraState +       every dash anyone in view makes (the server tells everyone), so their
//    DashLocalMotion       trail and pose show; your own dash is flown here from the server's
//                          route, smooth at your frame rate, held still through the windup
//    SonicBoomInput +      double-tap sprint while flying to break the sound barrier; while it
//    SonicCrashLocalMotion lasts your own flight runs 1.25x faster (let go of W to stop), and a
//                          clash rout throws you along the server's line
//    ClashRhythmOverlay    the melee clash rhythm duel: arrows scroll right to left, press W/A/S/D
//                          (or the arrow keys) as each crosses the line, hold the long ones; the
//                          panel is a HUD piece (move / resize it in the HUD editor). You can't walk
//                          while it runs. The score goes to the server when the chart ends.
//  Server side: scripts/44_dbr_ragnarok_combat.js. Shared maths: shared/19_dbr_ragnarok_combat.js.
// =====================================================================================
var DBR_RAG_COMBAT = (function () {
    var RC = DBR_RC, V = RC.V, sub = RC.sub, mul = RC.mul, len = RC.len, norm = RC.norm, R = RC.R;

    // the local AnimPlayer, looked up once per tick
    var ME = null, ME_T = -1;
    function me() {
        var t = RPG.time();
        if (t !== ME_T) { ME_T = t; ME = null; RPG.avatar.players().forEach(function (pl) { if (pl.local) ME = pl; }); }
        return ME;
    }
    function myId() { var a = me(); return a ? a.id : -1; }
    function vec(a) { return a && a.length >= 3 ? V(Number(a[0]), Number(a[1]), Number(a[2])) : V(0, 0, 0); }

    // ---- dashes in view (DashAuraState) ----
    var DASH = {};                              // entity id -> {route, heading, expires}
    RPG.net.on("dbr_rag_dash", function (d) {
        if (!d) return;
        if (!d.on) { delete DASH[d.id]; return; }
        DASH[d.id] = { expires: RPG.nowMs() + Math.max(1, Number(d.dur) || 1) * 50, heading: vec(d.h),
            route: { mode: RC.modeById(d.m), target: Number(d.t) || 0, windup: Number(d.w) || 0, travelTicks: Number(d.tt) || 0,
                maxTravel: Number(d.mt) || 0, origin: vec(d.o), control: vec(d.c), side: vec(d.s), clientTicks: 0, anchored: false, travelled: 0 } };
    });
    function dash(id) {
        var e = DASH[id];
        if (e && RPG.nowMs() > e.expires) { delete DASH[id]; return null; }
        return e || null;
    }

    // ---- DashInput: two presses 50..650 ms apart ----
    var lastPress = 0;
    try { RPG.keys.register("dbr_rag_dash", { name: "Dash (double tap)", key: "r" }); } catch (e) { }
    function dashMode() {
        var pl = me();
        if (!pl) return RC.MODE.STRAIGHT;
        if (pl.keyBack) return RC.MODE.OVER_TOP;
        if (pl.keyLeft && !pl.keyRight) return RC.MODE.LEFT_ARC;
        if (pl.keyRight && !pl.keyLeft) return RC.MODE.RIGHT_ARC;
        return RC.MODE.STRAIGHT;
    }
    function requestDash() {
        var hint = "";
        try {
            var t = RPG.target();
            if (t && t.type === "entity" && t.entityId) { var e = RPG.world.entity(t.entityId); if (e) hint = e.uuid; }
        } catch (err) { }
        RPG.net.send("dbr_rag", { a: "dash", m: dashMode(), t: hint });
    }
    RPG.on("keybind", function (id, down) {
        if (id !== "dbr_rag_dash" || !down || clash.active) return;
        var now = RPG.nowMs(), gap = now - lastPress;
        if (gap >= 50 && gap <= 650) { requestDash(); lastPress = 0; }
        else lastPress = now;
    });

    // ---- DashLocalMotion: fly your own route ----
    var MAX_STEP = 5.5;
    function flyRoute() {
        var id = myId(), e = dash(id);
        if (!e) return;
        var r = e.route, p = RPG.player;
        r.clientTicks++;
        if (r.clientTicks <= r.windup) { p.setVelocity(0, 0, 0); return; }
        var myEye = V(p.x, p.eyeY, p.z);
        if (!r.anchored) { r.anchored = true; r.origin = myEye; }
        var step, t = r.target > 0 ? RPG.world.entity(r.target) : null;
        if (t) {
            var tEye = V(t.x, t.eyeY !== undefined ? t.eyeY : t.y + t.height * 0.85, t.z);
            var dest = RC.destination(myEye, tEye, RC.facing(t.bodyYaw !== undefined ? t.bodyYaw : t.yaw || 0), (t.width || 0.6) * 0.5, t.height * 0.5, r.mode, r.side);
            var want = RC.sample(r.origin, r.control, dest, (r.clientTicks - r.windup) / Math.max(1, r.travelTicks));
            step = sub(sub(want, V(0, p.eyeY - p.y, 0)), V(p.x, p.y, p.z));
        } else {
            var remaining = r.maxTravel - r.travelled;
            if (remaining <= 0 || len(e.heading) < 1e-6) return;
            step = mul(e.heading, Math.min(3.2, remaining));
            r.travelled += len(step);
        }
        var l = len(step);
        if (l > MAX_STEP) step = mul(step, MAX_STEP / l);
        if (l > 1e-6) e.heading = norm(step);
        p.setVelocity(step.x, step.y, step.z);
    }

    // ---- sonic boom input (double-tap sprint, 50..400 ms) and the crash motion ----
    var sprintWas = false, sprintAt = 0, CRASH = {};
    function boomInput() {
        var pl = me();
        if (!pl) return;
        var down = !!pl.keySprint;
        if (down && !sprintWas && !RPG.screen.getOpen()) {
            var now = RPG.nowMs(), gap = now - sprintAt;
            if (gap >= 50 && gap <= 400) { RPG.net.send("dbr_rag", { a: "boom" }); sprintAt = 0; }
            else sprintAt = now;
        }
        sprintWas = down;
    }
    RPG.net.on("dbr_rag_crash", function (d) {
        if (!d) return;
        if (!d.on) { delete CRASH[d.id]; return; }
        CRASH[d.id] = { heading: norm(vec(d.h)), speed: Number(d.sp) || 0, left: Number(d.t) || 0, steered: !!d.st, mul: Number(d.mul) || 1.25 };
    });
    function crashMotion() {
        var id = myId(), c = CRASH[id], p = RPG.player;
        Object.keys(CRASH).forEach(function (k) { if (CRASH[k].left-- <= 0) delete CRASH[k]; });
        if (!c || !CRASH[id]) return;
        var pl = me();
        if (c.steered && !(pl && pl.keyForward)) { delete CRASH[id]; return; }      // let go of W: the boost lapses
        if (c.steered) { if (p.vx * p.vx + p.vy * p.vy + p.vz * p.vz > 1e-8) p.setVelocity(p.vx * c.mul, p.vy * c.mul, p.vz * c.mul); }
        else p.setVelocity(c.heading.x * c.speed, c.heading.y * c.speed, c.heading.z * c.speed);
    }

    // ---- ClashRhythmOverlay ----
    var PANEL_W = 240, PANEL_H = 76, LANES = 4, NOTE = 13, HIT_INSET = 10, RESULT_HOLD = 40;
    var COL_PANEL = "#B0101018", COL_BORDER = "#FF6A4CB8", COL_HIT = "#FFCFE8B0", COL_NOTE = "#FF8FD0FF", COL_PERFECT = "#FFFFF06A",
        COL_DEAD = "#60707070", COL_TEXT = "#FFE8E8F0";
    var clash = { active: false, seed: 0, opp: "", tick: 0, score: 0, notes: [], consumed: [], holding: [], paid: [], was: [false, false, false, false],
        result: 0, outcome: 0, own: 0, other: 0 };
    function resetClash() {
        clash.active = false; clash.tick = 0; clash.score = 0; clash.notes = []; clash.consumed = []; clash.holding = []; clash.paid = [];
        clash.was = [false, false, false, false];
        try { RPG.input.block(["move", "jump", "sneak"], false); } catch (e) { }
    }
    RPG.net.on("dbr_rag_clash", function (d) {
        if (!d) return;
        if (d.a === "start") {
            resetClash();
            clash.seed = Number(d.seed) || 0; clash.opp = String(d.opp || ""); clash.notes = RC.timeline(clash.seed);
            var n = clash.notes.length;
            for (var i = 0; i < n; i++) { clash.consumed.push(false); clash.holding.push(false); clash.paid.push(false); }
            clash.active = true; clash.result = 0;
            delete DASH[myId()];
            try { RPG.input.block(["move", "jump", "sneak"], true); } catch (e) { }      // WASD plays the duel, not the body
        } else if (d.a === "end") {
            resetClash();
            clash.outcome = Number(d.o) || 0; clash.own = Number(d.own) || 0; clash.other = Number(d.other) || 0;
            clash.result = RESULT_HOLD;
        }
    });
    RPG.on("unload", resetClash);
    function key(n) { return RPG.isKeyDown("key.keyboard." + n); }
    function lanesDown() {
        var pl = me() || {};
        return [!!pl.keyForward || key("w") || key("up"), !!pl.keyLeft || key("a") || key("left"),
                !!pl.keyBack || key("s") || key("down"), !!pl.keyRight || key("d") || key("right")];
    }
    function press(dir) {
        var best = -1, bestValue = 0, bestOff = 1e9;
        clash.notes.forEach(function (n, i) {
            if (clash.consumed[i]) return;
            var v = RC.judge(n, dir, clash.tick);
            if (v <= 0) return;
            var off = Math.abs(clash.tick - n.hit);
            if (off < bestOff) { best = i; bestValue = v; bestOff = off; }
        });
        if (best >= 0) {
            clash.consumed[best] = true;
            clash.score += bestValue;
            if (clash.notes[best].hold > 0) clash.holding[best] = true;
        }
    }
    function sustains(down) {
        clash.notes.forEach(function (n, i) {
            if (!clash.holding[i] || clash.paid[i]) return;
            var still = down[n.dir];
            if (clash.tick >= n.hit + n.hold) { if (still) clash.score += RC.sustainBonus(n); clash.paid[i] = true; clash.holding[i] = false; }
            else if (!still && clash.tick > n.hit + R.SUSTAIN_RELEASE_GRACE) { clash.paid[i] = true; clash.holding[i] = false; }
        });
    }
    function clashTick() {
        if (clash.result > 0 && !clash.active) clash.result--;
        if (!clash.active) return;
        if (!RPG.screen.getOpen()) {
            var down = lanesDown();
            for (var d = 0; d < LANES; d++) { if (down[d] && !clash.was[d]) press(d); clash.was[d] = down[d]; }
            sustains(down);
        } else clash.was = [false, false, false, false];
        clash.tick++;
        if (clash.tick > R.DURATION_TICKS) {
            // our own timer ran out: report, and leave the panel to the server's verdict
            RPG.net.send("dbr_rag", { a: "score", s: clash.score });
            clash.active = false;
            try { RPG.input.block(["move", "jump", "sneak"], false); } catch (e) { }
        }
    }
    function arrowX(left, travel, ticksAway) { return left + PANEL_W - NOTE - 4 - Math.round((1 - ticksAway / R.LEAD_TICKS) * travel); }
    function arrow(ctx, x, y, size, dir, col) {
        var half = Math.floor(size / 2), stem = Math.max(2, Math.floor(size / 3)), r, c;
        if (dir === R.DIR_UP) {
            for (r = 0; r < half; r++) ctx.rect(x + half - r, y + r, 2 * r + 1, 1, col);
            ctx.rect(x + half - Math.floor(stem / 2), y + half, Math.floor(stem / 2) * 2 + 1, size - half, col);
        } else if (dir === R.DIR_DOWN) {
            for (r = 0; r < half; r++) ctx.rect(x + half - r, y + size - r - 1, 2 * r + 1, 1, col);
            ctx.rect(x + half - Math.floor(stem / 2), y, Math.floor(stem / 2) * 2 + 1, half + 1, col);
        } else if (dir === R.DIR_LEFT) {
            for (c = 0; c < half; c++) ctx.rect(x + c, y + half - c, 1, 2 * c + 1, col);
            ctx.rect(x + half, y + half - Math.floor(stem / 2), size - half, Math.floor(stem / 2) * 2 + 1, col);
        } else {
            for (c = 0; c < half; c++) ctx.rect(x + size - c - 1, y + half - c, 1, 2 * c + 1, col);
            ctx.rect(x, y + half - Math.floor(stem / 2), half + 1, Math.floor(stem / 2) * 2 + 1, col);
        }
    }
    function tr(key, fallback, a, b) {
        var s = RPG.hasTranslation(key) ? RPG.translate(key, a, b) : fallback;
        return String(s).replace("%s", a === undefined ? "" : a).replace("%s", b === undefined ? "" : b);
    }
    function drawPanel(ctx, left, top, preview) {
        ctx.rect(left, top, PANEL_W, PANEL_H, COL_PANEL);
        ctx.rect(left, top, PANEL_W, 1, COL_BORDER); ctx.rect(left, top + PANEL_H - 1, PANEL_W, 1, COL_BORDER);
        ctx.rect(left, top, 1, PANEL_H, COL_BORDER); ctx.rect(left + PANEL_W - 1, top, 1, PANEL_H, COL_BORDER);
        var lineX = left + HIT_INSET + NOTE;
        if (preview || clash.active) ctx.rect(lineX, top + 4, 1, PANEL_H - 16, COL_HIT);
        if (preview) { ctx.text(tr("gui.dmz_ragnarok.clash.score", "Score: %s", 0), left + 6, top + PANEL_H - 10, COL_TEXT, false); return; }
        if (!clash.active) {
            var keys = ["gui.dmz_ragnarok.clash.lost", "gui.dmz_ragnarok.clash.won", "gui.dmz_ragnarok.clash.drew", "gui.dmz_ragnarok.clash.cancelled"];
            var names = ["Clash lost", "Clash won", "Clash drawn", "Clash ended"], cols = ["#FF5555", "#55FF55", "#FFFF55", "#FF5555"];
            var o = Math.max(0, Math.min(3, clash.outcome)), title = tr(keys[o], names[o]);
            ctx.text(title, left + (PANEL_W - ctx.textWidth(title)) / 2, top + 14, cols[o], false);
            var line = tr("gui.dmz_ragnarok.clash.result", "%s vs %s", clash.own, clash.other);
            ctx.text(line, left + (PANEL_W - ctx.textWidth(line)) / 2, top + 30, COL_TEXT, false);
            return;
        }
        ctx.clip(left + 1, top + 1, PANEL_W - 2, PANEL_H - 2);             // long notes' tails stay inside the panel
        var laneH = Math.floor((PANEL_H - 16) / LANES), travel = PANEL_W - HIT_INSET - NOTE * 2, now = clash.tick + (ctx.partial || 0);
        clash.notes.forEach(function (n, i) {
            var away = n.hit - now, gone = n.hold > 0 ? -(n.hold + R.GOOD_WINDOW) : -R.GOOD_WINDOW;
            if (away > R.LEAD_TICKS || away < gone) return;
            var y = top + 6 + n.dir * laneH, size = Math.min(NOTE, laneH - 1), headX = arrowX(left, travel, away);
            if (n.hold > 0) {
                var tailX = arrowX(left, travel, n.hit + n.hold - now), x0 = Math.min(headX, tailX) + size / 2, x1 = Math.max(headX, tailX) + size / 2;
                ctx.rect(x0, y + size / 2 - 1, x1 - x0, 2, clash.paid[i] ? COL_DEAD : clash.holding[i] ? COL_PERFECT : COL_NOTE);
            }
            arrow(ctx, headX, y, size, n.dir, clash.consumed[i] ? COL_DEAD : Math.abs(away) <= R.PERFECT_WINDOW ? COL_PERFECT : COL_NOTE);
        });
        ctx.unclip();
        ctx.text(tr("gui.dmz_ragnarok.clash.score", "Score: %s", clash.score), left + 6, top + PANEL_H - 10, COL_TEXT, false);
        if (clash.opp) ctx.text(clash.opp, left + PANEL_W - 6 - ctx.textWidth(clash.opp), top + PANEL_H - 10, COL_TEXT, false);
    }
    RPG.hud.onRender(function (ctx) {
        var editing = ctx.isEditing && ctx.isEditing();
        if (!editing && !clash.active && clash.result <= 0) return;
        // centred, a quarter of the way down: where DMZ draws its ki clash meter
        var left = Math.round((ctx.width - PANEL_W) / 2), top = Math.round(ctx.height / 4);
        if (!ctx.group("dbr_melee_clash", "Melee Clash", left, top, PANEL_W, PANEL_H)) return;
        drawPanel(ctx, left, top, editing && !clash.active && clash.result <= 0);
        ctx.endGroup();
    });

    RPG.on("tick", function () {
        if (!RPG.player.present) return;
        boomInput();
        flyRoute();
        crashMotion();
        clashTick();
    });

    return {
        /** a dash or its fast-flight decoration (DashAuraState.isDashing). */
        isDashing: function (id) { return !!dash(id); },
        isRealDash: function (id) { return !!dash(id); },
        heading: function (id) { var e = dash(id); return e ? e.heading : null; },
        clashActive: function () { return clash.active; }
    };
})();
