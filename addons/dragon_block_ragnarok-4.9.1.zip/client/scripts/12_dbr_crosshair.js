// =====================================================================================
//  12_dbr_crosshair.js - DMZ Ragnarok's crescent crosshair
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0, by Shurui): sdu/.../client/hud/OverShoulderCrosshairOverlay.java.
//  Texture: dbr:textures/gui/crosshair.png (DMZ Ragnarok's assets/dmz_ragnarok/textures/gui/crosshair.png).
//
//  - First person: vanilla's white cross is hidden and the crescent is drawn at screen centre.
//  - Third person with DMZ's over-the-shoulder camera on (56_dmz_camera.js): vanilla draws no crosshair
//    there, so the crescent is drawn where the look ray actually lands (the camera sits to one side, so
//    that is not screen centre): the block / entity under the crosshair within reach, else the first
//    block or entity along the ray out to 128 blocks, else the far point. The drawn position eases toward
//    it (tau 0.06 s) and snaps on jumps over 48 px, and is kept on screen.
//  Plus DragonMine Z's own crosshair rules (InGameHudMixin / ForgeClientEvents), which DMZ Ragnarok's
//  reticle inherits: it turns red while an enemy is in melee reach under it (hasTargetsInReach), and
//  while you guard it becomes DMZ's block shield (dmzpack textures/gui/hud/block_shield.png, 18 px).
//  Options (DMZ Config menu): dbr_cfg_crosshair_fp ("Custom First Person Crosshair") and
//  dbr_cfg_crosshair_os ("Over Shoulder Crosshair"), both on by default like DMZ Ragnarok's.
// =====================================================================================
var DBR_CROSSHAIR = (function () {
    var TEX = "dbr:textures/gui/crosshair.png", DRAW_SIZE = 15;
    var SHIELD = "dmzpack:textures/gui/hud/block_shield.png", SHIELD_SIZE = 18, MELEE_REACH = 4;
    var MAX_AIM = 128, STEP = 0.5, SMOOTH_TAU = 0.06, SNAP = 48;
    // blocks the aim ray passes through (vanilla's COLLIDER clip with fluids ignored)
    var PASS = /(^|:)(air|cave_air|void_air|water|lava|bubble_column|light|short_grass|grass|tall_grass|fern|large_fern|dead_bush|seagrass|tall_seagrass|kelp|kelp_plant|vine|snow|torch|wall_torch|soul_torch|redstone_torch|cobweb|sugar_cane|.*_sapling|.*_flower|dandelion|poppy|.*_tulip|cornflower|azure_bluet|oxeye_daisy|allium|blue_orchid|lily_of_the_valley|.*_mushroom|.*_carpet|.*_button|.*_pressure_plate|rail|.*_rail|ladder|lever|tripwire|.*_sign|.*_banner)$/;

    function fpOn() { return !!RPG.storage.get("dbr_cfg_crosshair_fp", true); }
    function osOn() { return !!RPG.storage.get("dbr_cfg_crosshair_os", true); }
    function mode() { try { return RPG.camera.currentMode(); } catch (e) { return "first"; } }

    // vanilla's crosshair is hidden while ours replaces it (first person) and in third person, where the only
    // crosshair vanilla could draw is none and ours is the one players see
    RPG.every(5, function () {
        if (typeof DBR_VANILLA === "undefined") return;
        DBR_VANILLA.want("crosshair", RPG.player.present && (mode() !== "first" || fpOn()) ? ["crosshair"] : []);
    });

    // ---- the aim distance along the look ray, refreshed every tick (one block march + one entity sweep) ----
    var aimDist = MAX_AIM;
    function passable(id) { return id === "" || PASS.test(id); }
    function marchBlocks(ex, ey, ez, lx, ly, lz) {
        var lastX = null, lastY = null, lastZ = null;
        for (var d = STEP; d <= MAX_AIM; d += STEP) {
            var bx = Math.floor(ex + lx * d), by = Math.floor(ey + ly * d), bz = Math.floor(ez + lz * d);
            if (bx === lastX && by === lastY && bz === lastZ) continue;
            lastX = bx; lastY = by; lastZ = bz;
            var id = String(RPG.world.getBlock(bx, by, bz) || "");
            if (!passable(id)) return d;
        }
        return MAX_AIM;
    }
    function sweepEntities(ex, ey, ez, lx, ly, lz, maxD) {
        var best = maxD, list;
        try { list = RPG.world.entities(Math.min(128, maxD + 2)); } catch (e) { return best; }
        for (var i = 0; i < list.length; i++) {
            var en = list[i];
            if (en.name === RPG.player.name && en.player) continue;
            var h = en.height || 1.8, cx = en.x - ex, cy = en.y + h / 2 - ey, cz = en.z - ez;
            var t = cx * lx + cy * ly + cz * lz;
            if (t <= 0.3 || t >= best) continue;
            var px = cx - lx * t, py = cy - ly * t, pz = cz - lz * t, r = Math.max(0.6, h / 2) + 0.5;
            if (px * px + py * py + pz * pz <= r * r) best = t;
        }
        return best;
    }
    RPG.on("tick", function () {
        if (!RPG.player.present || !osOn() || mode() !== "third" || typeof DMZ_SHOULDER === "undefined" || !DMZ_SHOULDER.active()) return;
        var p = RPG.player, l = p.look, ex = p.x, ey = p.eyeY, ez = p.z;
        var t = RPG.target();
        if (t && t.type !== "miss" && t.x !== undefined) {
            var dx = t.x - ex, dy = t.y - ey, dz = t.z - ez;
            aimDist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            return;
        }
        aimDist = sweepEntities(ex, ey, ez, l.x, l.y, l.z, marchBlocks(ex, ey, ez, l.x, l.y, l.z));
    });

    // ---- easing (OverShoulderCrosshairOverlay.smoothCentre) ----
    var sx = 0, sy = 0, valid = false, lastNs = 0;
    function smooth(tx, ty) {
        var now = RPG.nowMs();
        if (!valid) { sx = tx; sy = ty; valid = true; lastNs = now; return; }
        var dx = tx - sx, dy = ty - sy;
        if (dx * dx + dy * dy > SNAP * SNAP) { sx = tx; sy = ty; lastNs = now; return; }
        var dt = (now - lastNs) / 1000;
        lastNs = now;
        if (dt <= 0) return;
        if (dt > 0.25) dt = 0.25;
        var a = 1 - Math.exp(-dt / SMOOTH_TAU);
        sx += dx * a; sy += dy * a;
    }
    /** DMZ's hasTargetsInReach, approximated: a living thing under the crosshair within melee reach. */
    function targetInReach() {
        var t = RPG.target();
        if (!t || t.type !== "entity" || t.x === undefined) return false;
        var p = RPG.player, dx = t.x - p.x, dy = t.y - p.eyeY, dz = t.z - p.z;
        return dx * dx + dy * dy + dz * dz <= MELEE_REACH * MELEE_REACH;
    }
    /** cx, cy = the reticle centre */
    function sprite(ctx, cx, cy) {
        if (RPG.player.hasEffect("guarding")) {
            ctx.quad(SHIELD, Math.round(cx - SHIELD_SIZE / 2), Math.round(cy - SHIELD_SIZE / 2), SHIELD_SIZE, SHIELD_SIZE, 0, 0, 1, 1, "#FFFFFF", 1);
            return;
        }
        ctx.quad(TEX, Math.round(cx - DRAW_SIZE / 2), Math.round(cy - DRAW_SIZE / 2), DRAW_SIZE, DRAW_SIZE, 0, 0, 1, 1, targetInReach() ? "#FF0000" : "#FFFFFF", 1);
    }

    function render(ctx) {
        if (!RPG.player.present || ctx.isEditing() || RPG.screen.getOpen()) { valid = false; return; }
        var m = mode();
        if (m === "first") {
            valid = false;
            if (fpOn()) sprite(ctx, ctx.width / 2, ctx.height / 2);
            return;
        }
        if (m !== "third" || !osOn() || typeof DMZ_SHOULDER === "undefined" || !DMZ_SHOULDER.active()) { valid = false; return; }
        var p = RPG.player, l = p.look, tx = ctx.width / 2, ty = ctx.height / 2;
        var s = RPG.project(p.x + l.x * aimDist, p.eyeY + l.y * aimDist, p.z + l.z * aimDist);
        if (s && s.visible && isFinite(s.x) && isFinite(s.y)) { tx = s.x; ty = s.y; }
        smooth(tx, ty);
        sprite(ctx, Math.max(DRAW_SIZE / 2, Math.min(ctx.width - DRAW_SIZE / 2, sx)), Math.max(DRAW_SIZE / 2, Math.min(ctx.height - DRAW_SIZE / 2, sy)));
    }
    RPG.on("load", function () { RPG.hud.onRender(render); });
    return { firstPerson: fpOn, overShoulder: osOn };
})();
