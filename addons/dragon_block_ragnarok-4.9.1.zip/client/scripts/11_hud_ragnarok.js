// =====================================================================================
//  11_hud_ragnarok.js - DMZ Ragnarok's "Ragnarok" HUD (the default DBR HUD)
// =====================================================================================
//  Ported from DMZ Ragnarok (GPL-3.0, by Shurui):
//    shuruisutilities/.../client/hud/ScouterStatHudOverlay.java (the stat panel + zeni pill)
//    sdu/.../client/hud/ragnarok/RagnarokHud.java (fade-in, editor preview)
//  Textures: dbr:textures/gui/hud/ragnarok/*.png, copied from DMZ Ragnarok's
//  assets/dmz_ragnarok/textures/gui/hud/rework (+ orb_frame / transform_arc).
//
//  The scouter orb with your portrait in its lens, the release % in its dome, the red form
//  crescent under it, and the health / ki / stamina bars in the gold-trimmed navy housing,
//  plus the zeni pill. Animated with DMZ's HudBar machinery (10_hud_xenoverse.js exports
//  it): bars ease (tau 0.55 s), a loss leaves a pale chip that holds 1.5 s then drains, a
//  burst heal breathes green, a hit flashes the health white and shakes the panel, shines
//  cascade every 5.5 s, ki flows (faster while charging) and takes the aura colour, under
//  25% health the bar, frame and orb ring beat red, and every number counts, pulses and
//  fades out after 2.5 s unless "Always Visible HUD Values" is on.
//
//  Options (DMZ Config menu, 54_dmz_config_menu.js): dmz_hud_hidden, dmz_hud_hide_numbers,
//  dmz_cfg_adv_desc, dmz_hud_percent, dmz_hud_always_numbers, and dmz_hud_style ("xenoverse" brings back the
//  classic DMZ HUD). Move / resize / hide both pieces in the HUD editor ("dmz_hud", "dmz_hud_zeni").
// =====================================================================================
var DMZ_HUD = (function () {
    var X = XV, clamp = X.clamp, mix = X.mix, hex = X.hex;
    var REFERENCE_HEIGHT = 360;
    function tex(n) { return "dbr:textures/gui/hud/ragnarok/" + n + ".png"; }
    function S(n, w, h) { return X.sprite(0, 0, w, h, tex(n), w, h); }

    // ---- layout, in panel pixels (ScouterStatHudOverlay's measured constants) ----
    var ORB_X = 0, ORB_Y = 2, ORB_W = 68, ORB_H = 79;
    var ARC_X = 11, ARC_Y = 57, ARC_W = 46, ARC_H = 12;
    var FRAME = { x: 41, y: 19, w: 209, h: 31 };
    var HEALTH = { x: 58, y: 26, w: 188, h: 20 };
    var KI_TRACK = { x: 56, y: 48, w: 114, h: 18 }, KI = { x: 60, y: 52, w: 106, h: 10 };
    var STM_TRACK = { x: 168, y: 35, w: 82, h: 15 }, STM = { x: 177, y: 38, w: 69, h: 8 };
    var GLINT_TOP = { x: 48, y: 5, w: 58, h: 26 };
    var GLINT_LOW = { x: 180, y: 35, w: 58, h: 25 };          // the no-role-bar position (DBR has no fourth bar)
    var LENS_X0 = 7, LENS_Y0 = 16, LENS_X1 = 60, LENS_Y1 = 61;
    // the portrait: a still, front-facing model framed on its head (the engine measures the head bone of whatever race
    // or form is drawn), so every body puts its face here at this size: DMZ's 40 px/block head with its top at y34
    var PREVIEW_CENTER_X = 34, PREVIEW_HEAD_CY = 43.4, PREVIEW_HEAD_SIZE = 18.75;
    var PORTRAIT = { still: true, anchor: "head", headSize: PREVIEW_HEAD_SIZE };
    var RELEASE_CX = 34.5, RELEASE_CY = 10.5, RELEASE_SCALE = 0.65, RELEASE_COLOR = "#FACAF7";
    var HEALTH_TEXT_BIAS_X = -40, BAR_TEXT_SCALE = 0.75;
    // zeni pill: coin 22x22 at 177, pill drawn from u=11 at 187, Z centred in the coin, gold digits after it
    var ZENI_BAR_X = 187, ZENI_BAR_Y = 1, ZENI_BAR_W = 80, ZENI_BAR_H = 20, ZENI_BAR_U = 11, ZENI_BAR_DRAW_W = 69;
    var ZENI_ORB_X = 177, ZENI_ORB_Y = 0, ZENI_ORB_S = 22, ZENI_Z_X = 186, ZENI_Z_Y = 7;
    var ZENI_TEXT_LEFT = ZENI_ORB_X + ZENI_ORB_S + 2, ZENI_TEXT_RIGHT = ZENI_BAR_X + ZENI_BAR_DRAW_W - 2;
    var ZENI_TEXT_Y = ZENI_BAR_Y + ZENI_BAR_H / 2, ZENI_TEXT_SCALE = 0.75, ZENI_COLOR = 0xFFD34D;
    var STATS_W = FRAME.x + FRAME.w, STATS_H = ORB_Y + ORB_H;
    var CUR_X0 = ZENI_ORB_X, CUR_W = ZENI_BAR_X + ZENI_BAR_DRAW_W - ZENI_ORB_X, CUR_H = ZENI_ORB_S;
    var MARGIN = 4;

    var SP = {
        health: S("health_fill_grey", HEALTH.w, HEALTH.h), ki: S("ki_fill_grey", KI.w, KI.h), stm: S("stamina_fill", STM.w, STM.h),
        frame: S("main_frame", FRAME.w, FRAME.h), ring: S("orb_frame", ORB_W, ORB_H)
    };
    // the fill colours the art is drawn in; health is the grey fill tinted by DMZ's smooth ramp across them
    var FILL_HEALTH = 0x0CFF00, FILL_AMBER = 0xFFBB00, FILL_RED = 0xFF001D, ALERT = 0xFF3B3B, SURGE_TOP = 0.55;

    // ---- a canvas that fades everything it draws (RagnarokHud's FADE appear, tau 0.18 s) ----
    function Faded(ctx, a) { this.c = ctx; this.a = a; this.width = ctx.width; this.height = ctx.height; this.partial = ctx.partial; }
    Faded.prototype.quad = function (t, x, y, w, h, u0, v0, u1, v1, col, al) { this.c.quad(t, x, y, w, h, u0, v0, u1, v1, col, al * this.a); };
    Faded.prototype.quadCorners = function (t, x, y, w, h, u0, v0, u1, v1, col, a, b, c, d) {
        var f = this.a; this.c.quadCorners(t, x, y, w, h, u0, v0, u1, v1, col, a * f, b * f, c * f, d * f);
    };
    Faded.prototype.additive = function (on) { this.c.additive(on); };
    Faded.prototype.textStyled = function (s, x, y, sc, col, al, align, font, outline) { this.c.textStyled(s, x, y, sc, col, al * this.a, align, font, outline); };

    // ---- animation state (ScouterStatHudOverlay.Animated) ----
    var HP = new X.Bar("health"), KIB = new X.Bar("ki"), STMB = new X.Bar("stamina");
    KIB.flowing = true;
    var RELEASE = new X.Smoother(0.10, 0.05), FORM = new X.Smoother(0.08), GLOW = new X.Smoother(0.15), SHAKE = new X.Smoother(0.12);
    var APPEAR = new X.Smoother(0.18, 0.005), APPEAR_ZENI = new X.Smoother(0.18, 0.005);
    var ZENI_NUM = new X.Smoother(0.11, 0.45), ZENI_TEXT = new X.Numbers("health");
    var lastHealth = -1;

    function opt(key, def) { try { var v = RPG.storage.get(key, def); return v === undefined || v === null ? def : v; } catch (e) { return def; } }
    function style() { return opt("dmz_hud_style", "ragnarok") === "xenoverse" ? "xenoverse" : "ragnarok"; }
    function img(ctx, name, x, y, w, h) { ctx.quad(tex(name), x, y, w, h, 0, 0, 1, 1, "#FFFFFF", 1); }

    function healthRgb(f) {
        var toAmber = X.smoothStep(0.20, 0.30, f), toGreen = X.smoothStep(0.45, 0.55, f);
        return mix(mix(FILL_RED, FILL_AMBER, toAmber), FILL_HEALTH, toGreen);
    }
    function grouped(n) { n = Math.round(n); var neg = n < 0; return (neg ? "-" : "") + String(Math.abs(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
    /** "cur/max", or a floored percentage when "Adv. Desc. (Percentage)" is on (never 100% short of full, never 0% with a sliver left). */
    function amount(cur, max) {
        cur = Math.max(0, cur); max = Math.max(0, max);
        if (!opt("dmz_hud_percent", true)) return Math.round(cur) + "/" + Math.round(max);
        if (max <= 0) return "0%";
        var pct = Math.floor(100 * cur / max);
        if (pct >= 100 && cur < max) pct = 99;
        if (pct <= 0 && cur > 0) pct = 1;
        return clamp(pct, 0, 100) + "%";
    }

    /** Vanilla font, black stamped at all eight neighbours, then the text (drawBarValue / drawPillAmount). */
    function stamped(ctx, text, x, y, scale, rgb, alpha) {
        if (alpha <= 0.012) return;
        var d = scale, diag = [[-1, -1], [1, -1], [-1, 1], [1, 1]];
        for (var i = 0; i < 4; i++) ctx.textStyled(text, x + diag[i][0] * d, y + diag[i][1] * d, scale, "#000000", alpha, 0, null, null);
        ctx.textStyled(text, x, y, scale, hex(rgb), alpha, 0, null, "#000000");
    }
    function barValue(ctx, text, r, bias, dx, dy, rgb, alpha) {
        var tw = ctx.c.textWidthIn(text, null) * BAR_TEXT_SCALE, th = 9 * BAR_TEXT_SCALE;
        stamped(ctx, text, r.x + (r.w - tw) / 2 + bias + dx, r.y + (r.h - th) / 2 + dy, BAR_TEXT_SCALE, rgb, alpha);
    }
    /** One bar readout: counts toward the value and wears DMZ's change pulse, shake and idle fade. */
    function drawValue(ctx, bar, r, bias, tick) {
        if (!opt("dmz_cfg_adv_desc", true)) return;          // DMZ "Advanced Description": no bar values at all when off
        var pct = opt("dmz_hud_percent", true);
        var cv = pct ? Math.round(bar.cur / bar.max * 100) : Math.round(bar.cur);
        var st = bar.nums.update(String(cv), cv, tick);
        if (st.alpha <= 0.012) return;
        barValue(ctx, amount(bar.number.value, bar.max), r, bias, st.dx, st.dy, st.rgb, st.alpha);
    }
    /** Release %: DMZ's power-release pink, centred in the orb's dome, always shown (as in DMZ). */
    function releaseText(ctx, release) {
        var s = Math.round(release) + "%";
        ctx.textStyled(s, RELEASE_CX, RELEASE_CY + ORB_Y - 4 * RELEASE_SCALE, RELEASE_SCALE, RELEASE_COLOR, 1, 0.5, null, "#000000");
    }

    function sample() {
        return { health: 14, maxHealth: 20, ki: 65, maxKi: 100, stm: 80, maxStm: 100, release: 50, form: 0, glow: 0, surge: 0, aura: 0x7FD4FF };
    }
    function live(p) {
        return {
            health: p.health, maxHealth: Math.max(1, p.maxHealth),
            ki: p.resource("ki"), maxKi: Math.max(1, p.resourceMax("ki")),
            stm: p.resource("stamina"), maxStm: Math.max(1, p.resourceMax("stamina")),
            release: Number(RPG.getVar("dmz_release", 0)) || 0,
            form: clamp((Number(RPG.getVar("dmz_formcharge", 0)) || 0) / 100, 0, 1),
            glow: p.hasEffect("ki_charge") ? 1 : 0,
            surge: clamp((Number(RPG.getVar("dmz_surge", 0)) || 0) / 100, 0, 1),
            aura: X.parse(RPG.getVar("dmz_aura_color", "") || p.color("aura", "#7FD4FF"))
        };
    }

    // ---- the stat panel ----
    function drawStats(ctx, s, editing) {
        HP.update(s.health, s.maxHealth);
        KIB.update(s.ki, s.maxKi);
        STMB.update(s.stm, s.maxStm);
        var release = RELEASE.update(s.release), form = FORM.update(s.form), glow = GLOW.update(s.glow);
        if (lastHealth >= 0 && s.health < lastHealth) {
            var lost = (lastHealth - s.health) / s.maxHealth;
            if (lost >= 0.02) SHAKE.snap(Math.min(1, SHAKE.value + lost * 6));       // DMZ's hit shake
        }
        lastHealth = s.health;
        var shake = editing ? 0 : SHAKE.update(0), seconds = X.clock(), tick = RPG.time() + ctx.partial;
        var low = X.heartbeat(HP.target());
        KIB.flowBoost = clamp(glow, 0, 1);

        ctx.c.push();
        ctx.c.translate(Math.sin(seconds * 61) * 1.6 * shake, Math.cos(seconds * 47) * 1.0 * shake);
        // the two gold clouds first: the bars and the orb lap over them
        img(ctx, "decor_glint_low", GLINT_LOW.x, GLINT_LOW.y, GLINT_LOW.w, GLINT_LOW.h);
        img(ctx, "decor_glint_top", GLINT_TOP.x, GLINT_TOP.y, GLINT_TOP.w, GLINT_TOP.h);
        // housing, its heartbeat alert, then health
        img(ctx, "main_frame", FRAME.x, FRAME.y, FRAME.w, FRAME.h);
        if (low > 0) X.spriteDraw(ctx, SP.frame, FRAME.x, FRAME.y, FRAME.w, FRAME.h, ALERT, low * 0.6);
        HP.drawFill(ctx, SP.health, HEALTH.x, HEALTH.y, HEALTH.w, HEALTH.h, healthRgb(HP.anim.front), low);
        // ki: aura tinted, flowing, swept while charging, the surge band on top
        img(ctx, "ki_track", KI_TRACK.x, KI_TRACK.y, KI_TRACK.w, KI_TRACK.h);
        KIB.drawFill(ctx, SP.ki, KI.x, KI.y, KI.w, KI.h, s.aura, 0);
        KIB.drawSweep(ctx, SP.ki, KI.x, KI.y, KI.w, KI.h, seconds * 1.1, glow);
        if (s.surge > 0) X.spritePart(ctx, SP.ki, KI.x, KI.y, KI.w, KI.h, 0, SURGE_TOP, s.surge, 1, mix(s.aura, 0xFFFFFF, 0.75), 0.95);
        img(ctx, "stamina_track", STM_TRACK.x, STM_TRACK.y, STM_TRACK.w, STM_TRACK.h);
        STMB.drawFill(ctx, SP.stm, STM.x, STM.y, STM.w, STM.h, 0xFFFFFF, 0);

        // the orb: backdrop, your portrait in the lens, the ring on top (its lens is punched to the circle)
        img(ctx, "orb", ORB_X, ORB_Y, ORB_W, ORB_H);
        if (ctx.a > 0.5 && typeof ctx.c.player === "function") {
            ctx.c.clip(LENS_X0, LENS_Y0 + ORB_Y, LENS_X1 - LENS_X0, LENS_Y1 - LENS_Y0);
            ctx.c.player(PREVIEW_CENTER_X, PREVIEW_HEAD_CY + ORB_Y, 40, 180, PORTRAIT);
            ctx.c.unclip();
        }
        img(ctx, "orb_frame", ORB_X, ORB_Y, ORB_W, ORB_H);
        if (low > 0) X.spriteDraw(ctx, SP.ring, ORB_X, ORB_Y, ORB_W, ORB_H, 0xFF3030, low * 0.5);
        // the form crescent, revealed left to right (each texture column holds only its own part of the curve)
        var cols = Math.round(ARC_W * clamp(form, 0, 1));
        if (cols > 0) ctx.quad(tex("transform_arc"), ARC_X, ARC_Y + ORB_Y, cols, ARC_H, 0, 0, cols / ARC_W, 1, "#FFFFFF", 1);
        releaseText(ctx, release);

        if (!opt("dmz_hud_hide_numbers", false)) {
            drawValue(ctx, HP, HEALTH, HEALTH_TEXT_BIAS_X, tick);
            drawValue(ctx, KIB, KI, 0, tick);
            drawValue(ctx, STMB, STM, 0, tick);
        }
        ctx.c.pop();
    }

    // ---- the zeni pill ----
    // DMZ pulses its numbers from white to green (gain) or red (loss); the figure is gold, so carry the strength over
    function pulse(base, dmz) {
        dmz &= 0xFFFFFF;
        if (dmz === 0xFFFFFF) return base;
        var r = (dmz >> 16) & 255, g = (dmz >> 8) & 255, gain = r < 255;
        var t = gain ? (255 - r) / (255 - 0x55) : (255 - g) / (255 - 0x55);
        return mix(base, gain ? 0x55FF55 : 0xFF5555, t);
    }
    function drawZeni(ctx, zeni, tick) {
        var shown = ZENI_NUM.update(zeni), st = ZENI_TEXT.update(String(zeni), zeni, tick);
        ctx.quad(tex("zeni_bar"), ZENI_BAR_X, ZENI_BAR_Y, ZENI_BAR_DRAW_W, ZENI_BAR_H, ZENI_BAR_U / ZENI_BAR_W, 0, 1, 1, "#FFFFFF", 1);
        img(ctx, "zeni_orb", ZENI_ORB_X, ZENI_ORB_Y, ZENI_ORB_S, ZENI_ORB_S);
        img(ctx, "zeni_z", ZENI_Z_X, ZENI_Z_Y, 4, 8);
        var text = grouped(shown), avail = ZENI_TEXT_RIGHT - ZENI_TEXT_LEFT, w = ctx.c.textWidthIn(text, null), scale = ZENI_TEXT_SCALE;
        if (w * scale > avail) scale = avail / w;
        stamped(ctx, text, ZENI_TEXT_LEFT + st.dx, ZENI_TEXT_Y - 9 * scale / 2 + st.dy, scale, pulse(ZENI_COLOR, st.rgb), 1);
    }

    function render(ctx) {
        var p = RPG.player;
        if (!p.present || style() !== "ragnarok" || opt("dmz_hud_hidden", false)) return;
        var editing = ctx.isEditing(), created = X.created();
        if (!created && !editing) { APPEAR.snap(0); APPEAR_ZENI.snap(0); lastHealth = -1; return; }
        var unit = Math.max(0.25, ctx.height / REFERENCE_HEIGHT), m = MARGIN * unit;
        var tick = RPG.time() + ctx.partial;

        // the stat panel (editor region "dmz_hud", shared with the classic HUD)
        var a = APPEAR.update(1);
        if (editing) { APPEAR.snap(1); a = 1; }
        if (a > 0.005 && ctx.group("dmz_hud", "DragonMine Z HUD", m, m, STATS_W * unit, STATS_H * unit)) {
            ctx.push();
            ctx.translate(m, m);
            ctx.scale(unit, unit);
            drawStats(new Faded(ctx, a), created ? live(p) : sample(), editing);
            ctx.pop();
            ctx.endGroup();
        }

        // the zeni pill (its own region, so it can be moved off the panel); hidden until the balance is known
        var zeni = Number(p.money);
        var known = isFinite(zeni) && (created || editing);
        if (!known && editing) zeni = 1250000;
        var az = APPEAR_ZENI.update(known || editing ? 1 : 0);
        if (editing) { APPEAR_ZENI.snap(1); az = 1; }
        var zx = m + CUR_X0 * unit;
        if (az > 0.005 && ctx.group("dmz_hud_zeni", "Zeni", zx, m, CUR_W * unit, CUR_H * unit)) {
            ctx.push();
            ctx.translate(zx, m);
            ctx.scale(unit, unit);
            ctx.translate(-CUR_X0, 0);
            drawZeni(new Faded(ctx, az), isFinite(zeni) ? zeni : 0, tick);
            ctx.pop();
            ctx.endGroup();
        }
    }

    return { render: render, style: style, setStyle: function (s) { try { RPG.storage.set("dmz_hud_style", s === "xenoverse" ? "xenoverse" : "ragnarok"); } catch (e) { } } };
})();

RPG.on("load", () => RPG.hud.onRender(DMZ_HUD.render));
