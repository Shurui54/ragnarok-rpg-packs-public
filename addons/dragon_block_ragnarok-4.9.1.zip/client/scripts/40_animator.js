// =====================================================================================
//  40_animator.js - DragonMine Z's player animations (PlayerGeoAnimatableMixin), as a script
// =====================================================================================
//  Runs once per tick for every player you can see. Each avatar has DMZ's layers
//  (scripts/20_races.js DBR_ANIM_LAYERS): base, attack, mining, block, shield, tail, dash,
//  pose, eat, ki, extra. Later layers win on the bones they move.
//
//  What other players are doing (charging, flying, a dash...) comes from the server with
//  pl.shared(key); see scripts/12_anim_state.js for the list.
//
//  Addons: change anything with DBR_ANIMATOR.extend(fn). fn(pl, out, mem) runs after the
//  DMZ rules; edit out.layers / out.bones / out.headLook. mem is that player's memory.
//      DBR_ANIMATOR.extend((pl, out) => { if (pl.shared("spin")) out.layers.extra = "skp.meteor"; });
//  Weapon stances: DBR_ANIMATOR.poses["minecraft:diamond_sword"] = "combat.pose_two_handed_sword";
// =====================================================================================
var DBR_ANIMATOR = (function () {
    // DMZ timings (ticks / blocks per tick)
    var STOPPED_THRESHOLD = 3, WALK_BASE = 0.2158, RUN_BASE = 0.2806, FROZEN = 0.01;
    var LANDING_TICKS = 13, FALL_TRIGGER = 4.5, LANDING_LEAD = 7, LANDING_RAY = 7;
    var KI_FIRE_TICKS = 14;

    var CHARGE = { human: "base.ki_charge_human", saiyan: "base.ki_charge_saiyan", namekian: "base.ki_charge_namekian",
        frost_demon: "base.ki_charge_frostdemon", bio_android: "base.ki_charge_bioandroid", majin: "base.ki_charge_majin",
        glind: "base.ki_charge_glind" };
    var DASH = { 1: "base.dash_front", 2: "base.evasion_back", 3: "base.evasion_right", 4: "base.evasion_left",
        6: "base.dash_back", 7: "base.dash_right", 8: "base.dash_left" };
    var EVADE = { 1: "base.dodge_front", 2: "base.dodge_back", 3: "base.dodge_left", 4: "base.dodge_right" };

    var MEM = {};
    var LOCAL_MELEE = [], localN = 0, LOCAL_GUARD = { on: false };
    var extensions = [];
    var poses = {};

    function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }
    // eases a speed toward its target and rounds it, so tiny wobbles don't change it every tick
    function smooth(m, key, target) {
        var v = m[key] === undefined ? target : m[key] + (target - m[key]) * 0.25;
        m[key] = v;
        return Math.round(v * 20) / 20;
    }
    function pulse(pl, key, m) {
        // a one-off event from the server ({..., n}); returns it once, the first tick it's new
        var v = pl.shared(key, null);
        if (!v || typeof v !== "object" || v.n === undefined) return null;
        // the model only animates while it's drawn: after a gap (first person, out of view) an event that arrived
        // meanwhile is old news and is dropped instead of playing late
        var now = RPG.nowMs(), seen = m["t_" + key];
        m["t_" + key] = now;
        if (m["n_" + key] === v.n) return null;
        var first = m["n_" + key] === undefined;
        m["n_" + key] = v.n;
        if (seen !== undefined && now - seen > 400) return null;
        return first ? null : v;          // joining late shouldn't replay an old event
    }

    // ---- moving / landing (isActuallyMoving, updateLanding) ----
    function movement(pl, m) {
        var speed = pl.speed;
        if (speed * speed > 0.0001) { m.moving = true; m.stopped = 0; }
        else if (++m.stopped >= STOPPED_THRESHOLD) m.moving = false;
        if (!pl.onGround) {
            m.maxFall = Math.max(m.maxFall, pl.fallDistance);
            var descent = -pl.vy;
            if (!m.landingTriggered && m.maxFall >= FALL_TRIGGER && descent > 0.1) {
                var clear = pl.groundClearance(LANDING_RAY);
                if (clear >= 0 && clear / descent <= LANDING_LEAD) { m.landing = LANDING_TICKS; m.landingTriggered = true; }
            }
        } else { m.maxFall = 0; m.landingTriggered = false; }
        if (m.landing > 0) m.landing--;
        return speed;
    }

    function flyAnim(pl) {
        if (pl.local) {
            if (pl.keyForward) return "base.fly_front";
            if (pl.keyBack) return "base.fly_back";
            if (pl.keyLeft) return "base.fly_left";
            if (pl.keyRight) return "base.fly_right";
            return "base.fly_idle";
        }
        var f = pl.moveForward, r = pl.moveRight;
        if (Math.sqrt(f * f + r * r) < 0.01) return "base.fly_idle";
        if (Math.abs(f) >= Math.abs(r)) return f >= 0 ? "base.fly_front" : "base.fly_back";
        return r >= 0 ? "base.fly_right" : "base.fly_left";
    }

    // ---- base layer (predicate) ----
    function base(pl, m, speed, out) {
        if (m.dashTicks > 0) return null;
        var charging = !!pl.shared("charge"), tf = pl.shared("tf", ""), blocking = !!pl.shared("block");
        var moving = m.moving && !((charging || tf) && speed < FROZEN);
        var oozaru = pl.look.indexOf("oozaru") >= 0;

        var potara = pl.shared("potara", null);
        if (potara) return potara === "left" ? "base.fusion_pothala_left" : "base.fusion_pothala_right";
        if (pl.shared("down")) return { anim: "base.faint_horizontal", mode: "hold" };
        if (pl.shared("stun")) return "base.stunned";
        if (pl.shared("drain")) return pl.shared("drainSemiPerfect") ? "base.absorb2" : { anim: "base.absorb", mode: "hold" };
        if (pl.passenger) return "base.sit";
        if (pl.sleeping) return null;
        if (charging && !moving && !blocking) {
            if (pl.shared("surge")) return { anim: "base.ki_overcharge_start", mode: "once", then: "base.ki_overcharge" };
            return CHARGE[pl.shared("race", pl.race)] || "base.ki_charge_saiyan";
        }
        if (tf) {
            out.headLook = false;                      // DMZ keeps the head forward while transforming
            var fusion = pl.shared("fusion", null);
            if (fusion) return { anim: fusion === "left" ? "base.fusion_dance_left" : "base.fusion_dance_right", mode: "hold", speed: 0.583 };
            return tf === "transf.generic" || tf === "transf.freezer2" || tf === "transf.ssj" ? tf : { anim: tf, mode: "hold" };
        }
        if (pl.shared("meditate")) return "base.meditation";
        if (pl.swimming) return "base.swimming";
        if (pl.crawling) return moving ? "base.crawling_move" : "base.crawling";
        // a Ragnarok dash (44_dbr_ragnarok_combat.js) is drawn as fast flight from start to finish (DashAnimation)
        if (pl.shared("rgDash")) return "base.fly_fast";
        if (pl.shared("fly") || pl.flying || pl.gliding) return pl.shared("flyFast") ? "base.fly_fast" : flyAnim(pl);
        if (pl.climbing && !pl.onGround) return "base.climb";
        if (m.landing > 0 && !pl.crouching) return "base.landing";
        if (pl.onGround) {
            if (pl.crouching) return moving ? "base.crouching_walk" : "base.crouching";
            if (moving && pl.sprinting) return { anim: "base.run", speed: smooth(m, "runSpeed", clamp(speed / RUN_BASE, 0.6, 1.8)) };
            if (moving) return { anim: oozaru ? "base.walk_ozaru" : "base.walk", speed: smooth(m, "walkSpeed", clamp(speed / WALK_BASE, 0.6, 1.8)) };
            return oozaru ? "base.idle_ozaru" : "base.idle";
        }
        if (pl.vy < -0.08) return "base.fly_idle";
        return "base.jump";
    }

    // ---- hands (attackPredicate, miningPredicate) ----
    function isTool(k) { return k === "tool"; }
    function placing(pl) {
        var block = pl.mainKind === "block" || pl.offKind === "block";
        var eating = pl.useAnim === "eat" || pl.useAnim === "drink";
        return block && ((pl.usingItem && !eating) || pl.swinging || pl.swingTime > 0);
    }

    function swingStarted(pl, m) {
        var started = pl.swinging && (!m.swingWas || pl.swingTime < m.lastSwingTime);
        m.swingWas = pl.swinging;
        m.lastSwingTime = pl.swingTime;
        return started;
    }

    function attack(pl, m, swung, out) {
        if (pl.sleeping) { m.attackTicks = 0; return null; }
        if (m.attackTicks > 0) m.attackTicks--;
        var melee = pulse(pl, "melee", m);
        // your own punches play the instant you click. The model only animates while it's drawn, so in first person
        // nothing takes them: only the newest counts, and only while it's fresh (no backlog replaying in third person)
        if (pl.local) {
            var lm = LOCAL_MELEE.length ? LOCAL_MELEE.pop() : null;
            LOCAL_MELEE.length = 0;
            melee = lm && RPG.nowMs() - lm.t < 400 ? lm : null;
        }
        if (melee && melee.a) {
            var speed = Math.max(0.15, Number(melee.s) || 1);
            var id = String(melee.a).replace(/^dragonminez:/, "").replace(/^animation\.base\./, "").replace(/^combat\./, "");
            if (melee.off && id.indexOf("right") >= 0 && pl.has("combat." + id.replace("right", "left"))) id = id.replace("right", "left");
            var anim = pl.has("combat." + id) ? "combat." + id : pl.has(id) ? id : "base.attack1";
            m.attackAnim = { anim: anim, mode: "once", speed: speed, restart: "m" + melee.n };
            m.attackTicks = Math.max(8, Math.round(12 / speed));
        } else if (m.attackTicks <= 0 && swung && !pl.usingItem && !pl.shared("block") && !placing(pl)
                   && !(pl.hasShared("race") && pl.mainKind === "empty" && pl.offKind === "empty")      // DBR fists use the combo
                   && !isTool(pl.mainKind) && !isTool(pl.offKind)) {
            m.attackN = (m.attackN || 0) + 1;
            m.attackAnim = { anim: "base.mining1", mode: "once", restart: "s" + m.attackN };   // DMZ's unarmed punch
            m.attackTicks = 8;
        }
        return m.attackTicks > 0 ? m.attackAnim : null;
    }

    function mining(pl, m, swung) {
        if (pl.sleeping || pl.useAnim === "eat" || pl.useAnim === "drink") { m.miningTicks = 0; return null; }
        if (m.miningTicks > 0) m.miningTicks--;
        var blocking = !!pl.shared("block");
        if (placing(pl) && !blocking) {
            if (swung || !m.miningAnim) { m.miningN = (m.miningN || 0) + 1; m.miningAnim = { anim: pl.mainKind === "block" ? "base.attack1" : "base.attack2", mode: "once", restart: "p" + m.miningN }; }
            m.miningTicks = 8;
            return m.miningAnim;
        }
        if (m.attackTicks > 0) { m.miningTicks = 0; return null; }
        var swinging = pl.swinging || pl.swingTime > 0;
        if (swinging && (isTool(pl.mainKind) || isTool(pl.offKind)) && !blocking) {
            if (swung || !m.miningAnim) { m.miningN = (m.miningN || 0) + 1; m.miningAnim = { anim: isTool(pl.mainKind) ? "base.mining1" : "base.mining2", mode: "once", restart: "t" + m.miningN }; }
            m.miningTicks = 10;
            return m.miningAnim;
        }
        return m.miningTicks > 0 ? m.miningAnim : null;
    }

    function shield(pl) {
        if (!pl.usingItem) return null;
        var main = pl.mainKind === "shield", off = pl.offKind === "shield";
        if (!main && !off) return null;
        var right = !pl.leftHanded;
        return main ? (right ? "base.shield_right" : "base.shield_left") : (right ? "base.shield_left" : "base.shield_right");
    }

    // ---- dash / evasion (dashPredicate) ----
    function dash(pl, m) {
        if (m.dashTicks > 0) m.dashTicks--;
        var e = pulse(pl, "evade", m), d = pulse(pl, "dash", m);
        if (e) { m.dashAnim = { anim: EVADE[e.v] || EVADE[1 + Math.floor(Math.random() * 4)], mode: "once", restart: "e" + e.n }; m.dashTicks = 12; }
        else if (d) { m.dashAnim = { anim: DASH[d.d] || DASH[1], mode: "once", restart: "d" + d.n }; m.dashTicks = 12; }
        return m.dashTicks > 0 ? m.dashAnim : null;
    }

    // ---- weapon stance (posePredicate) ----
    function pose(pl, m) {
        if (m.attackTicks > 0 || m.dashTicks > 0 || m.actActive) return null;
        if (pl.swimming || pl.crawling || pl.passenger) return null;
        if (pl.shared("block") || pl.shared("charge") || pl.shared("stun")) return null;
        var p = pl.shared("pose", "") || poses[pl.mainItem] || "";
        return p ? { anim: p, transition: m.poseResume ? 0 : 4 } : null;
    }

    // ---- techniques (kiPredicate): cast animations hold, fire animations play through ----
    function ki(pl, m) {
        var a = pulse(pl, "act", m);
        if (a) m.act = a.a ? { anim: a.a, start: pl.tick, ticks: Math.max(1, a.t || 20), n: a.n } : null;
        if (!m.act) { m.actActive = false; return null; }
        var fire = /_fire$/.test(m.act.anim);
        var ticks = fire ? Math.max(KI_FIRE_TICKS, m.act.ticks) : m.act.ticks;
        if (pl.tick - m.act.start >= ticks) { m.act = null; m.actActive = false; return null; }
        m.actActive = true;
        return { anim: m.act.anim, mode: fire ? "once" : "hold", restart: "k" + m.act.n };
    }

    // ---- eating (eatPredicate) ----
    function eat(pl, m) {
        var eating = pl.usingItem && (pl.useAnim === "eat" || pl.useAnim === "drink");
        if (eating && !m.wasEating) m.eatN = (m.eatN || 0) + 1;
        m.wasEating = eating;
        return eating ? { anim: "base.eat", restart: "f" + m.eatN } : null;
    }

    // ---- the tail (tailpredicate) ----
    function tail(pl, m, speed) {
        if (pl.shared("race", pl.race) === "bio_android" && pl.shared("drain")) return null;
        // livelier the faster you move (DMZ plays it at one speed; this only speeds it up)
        var lively = 1 + clamp(speed * 3, 0, 1.2) + (pl.shared("flyFast") ? 0.6 : 0) + (pl.shared("charge") ? 0.4 : 0);
        return { anim: "base.tail", speed: smooth(m, "tailSpeed", lively) };
    }

    function animate(pl) {
        var m = MEM[pl.id] || (MEM[pl.id] = { moving: false, stopped: 0, maxFall: 0, landing: 0, attackTicks: 0, miningTicks: 0, dashTicks: 0 });
        m.seen = pl.tick;
        var out = { layers: {}, bones: {}, headLook: true };
        var speed = movement(pl, m);
        var swung = swingStarted(pl, m);
        var L = out.layers;
        L.ki = ki(pl, m);
        L.dash = dash(pl, m);
        L.attack = attack(pl, m, swung, out);
        if (m.attackTicks > 0) m.poseResume = true;
        L.mining = mining(pl, m, swung);
        var guarding = pl.local ? LOCAL_GUARD.on : !!pl.shared("block");
        L.block = guarding ? { anim: "base.block", mode: "hold" } : null;
        L.shield = shield(pl);
        L.tail = tail(pl, m, speed);
        L.eat = eat(pl, m);
        L.pose = pose(pl, m);
        if (L.pose) m.poseResume = false;
        L.base = base(pl, m, speed, out);
        if (m.actActive || pl.sleeping || pl.shared("down")) out.headLook = false;
        // tail wrapped round the waist or removed (scripts/63_dmz_tail.js): hide the model's own tail
        if (pl.shared("tailHide")) for (var tb = 1; tb <= 9; tb++) out.bones["tail" + tb] = { hide: true };
        for (var i = 0; i < extensions.length; i++) {
            try { extensions[i](pl, out, m); } catch (err) { RPG.log("DBR animator extension failed: " + err); extensions.splice(i--, 1); }
        }
        return out;
    }

    RPG.avatar.animator(animate);

    // forget players that left (every 30 s)
    RPG.every(600, function () {
        for (var id in MEM) if (RPG.avatar.player(Number(id)) === null) delete MEM[id];
    });

    return {
        /** fn(pl, out, mem) after the DMZ rules: change out.layers / out.bones / out.headLook. */
        extend: function (fn) { if (typeof fn === "function") extensions.push(fn); },
        /** Play a melee animation on your own player now (the server shows it to everyone else). */
        playMelee: function (anim, speed) { LOCAL_MELEE = [{ a: anim, s: speed || 1, n: "L" + (++localN), t: RPG.nowMs() }]; },
        /** Your own guard, shown at once (the server's flag follows a moment later). */
        setLocalGuard: function (on) { LOCAL_GUARD.on = !!on; },
        /** item id -> stance animation for the pose layer. */
        poses: poses,
        /** race id -> ki charge animation. */
        chargeAnimations: CHARGE,
        /** this player's memory (moving, landing, attackTicks...), or null. */
        memory: function (id) { return MEM[id] || null; }
    };
})();
