// =====================================================================================
//  DMZ SkillsMenuScreen: tabs Skills / Ki Attacks / Forms / Strike Attacks / Evasion
//  Attacks, the skill list (left), the INFORMATION panel (right), the forms tree and the
//  bottom navigation row, laid out like DragonMine Z in its 360-px GUI space.
//  Levels and prices come from the server (scripts/46_dmz_skills.js, "dmz_skills_state").
// =====================================================================================
var SKILLS_SCREEN = (function () {
    var U = DMZ_UI, SD = DMZ_SKILLS_DATA, FONT = U.FONT;
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png", MENU_SMALL = "dmzpack:textures/gui/menu/menusmall.png";
    var NAV = "dmzpack:textures/gui/buttons/menubuttons.png", BUTTONS = U.BUTTONS;
    var EXCLAMATION = "dmzpack:textures/gui/quest/exclamation_mark_quest.png";
    var ITEM_H = 20, VISIBLE = 8, DESC_X = 12, DESC_W = 119, LINE = 11;
    var RACIAL = RPG.files.read("racial_parts.json") || { parts: {} };
    var TABS = [["skills", 142, 44, "gui.dragonminez.skills.tab.skills"], ["ki", 170, 44, "gui.dragonminez.skills.tab.kiattacks"],
        ["forms", 198, 44, "gui.dragonminez.skills.tab.forms"], ["strike", 226, 44, "gui.dragonminez.skills.tab.strikeattacks"],
        ["evasion", 142, 77, "gui.dragonminez.skills.tab.evasionattacks"]];

    var state = { skills: {}, race: "human", android: false, done: [] };
    var st = null;          // per-open UI state

    function fresh() {
        return { tab: "skills", selected: null, scroll: 0, descScroll: 0, binding: false, last: RPG.nowMs(), reveal: 0, formsT: 0, leftHover: 0,
            leftX: 12, rightX: 0, pan: [0, 0], zoom: 1, targetZoom: 1, drag: null, formGroup: null, formName: null, lastFormClick: 0, nodes: [] };
    }

    // ---- data helpers ----
    function level(s) { var v = state.skills[s]; return typeof v === "number" ? v : 0; }
    function owned(s) { return Object.prototype.hasOwnProperty.call(state.skills, s); }
    function done(key) { return state.done.indexOf(key) >= 0; }
    function skillName(s) { return U.tr("skill.dragonminez." + s); }
    function className() { return RPG.player.playerClass || "warrior"; }
    function passiveTitle() { return U.strip(U.tr("class.dragonminez." + className()) + " " + U.tr("class.dragonminez.passive")); }

    function racialParts() {
        var list = (RACIAL.parts && RACIAL.parts[state.race]) || [];
        return list.filter(function (p) { return state.android || (p.id !== "android_core" && p.id !== "absorption_barrier"); })
            .map(function (p) { return { id: "racial_" + p.id, name: p.name, desc: p.desc }; });
    }

    // the Ki / Strike / Evasion tabs: the DMZ techniques we unlocked (41_dmz_techniques.js), plus any of
    // this addon's own skills (40_skills.js) that DMZ didn't replace, so they can be bound to a slot too
    var TC = DMZ_TECH_CLIENT, TD = DMZ_TECH_DATA;
    function isDmz(id) { return TD.exists(id); }
    function techniques(tab) {
        var out = [], seen = {};
        TC.unlocked(tab).forEach(function (id) { if (TD.kind(id) === tab) { seen[id] = 1; out.push(id); } });
        var mapped = {};
        Object.keys(SD.TECHNIQUES).forEach(function (k) { if (TD.exists(k)) mapped[SD.TECHNIQUES[k]] = 1; });   // replaced by DMZ
        RPG.defIds("skill").forEach(function (id) {
            if (seen[id] || mapped[id] || RPG.player.skillLevel(id) <= 0) return;
            var kind = RPG.defField("skill", id, "kind") || "", passive = RPG.defField("skill", id, "passive");
            if (kind === "form" || passive === "true" || passive === 1) return;
            var t = kind === "ki" ? "ki" : kind === "strike" ? "strike" : "evasion";
            if (t === tab) { seen[id] = 1; out.push(id); }
        });
        return out;
    }

    // SkillsMenuScreen.getVisibleSkillNames (rebuilt a few times a second)
    var entryCache = { at: 0, key: "", list: [] };
    function entries() {
        var k = st.tab + "|" + RPG.player.race;
        if (entryCache.key === k && RPG.nowMs() - entryCache.at < 250) return entryCache.list;
        entryCache = { at: RPG.nowMs(), key: k, list: buildEntries() };
        return entryCache.list;
    }
    function buildEntries() {
        var out = [];
        if (st.tab === "skills") {
            Object.keys(state.skills).forEach(function (s) {
                if (SD.KI.indexOf(s) >= 0 || SD.STRIKE.indexOf(s) >= 0 || SD.EVASION.indexOf(s) >= 0 || SD.isStack(s) || SD.isForm(s)) return;
                if (SD.allowed(s, state.race, state.android)) out.push(s);
            });
            out.sort(function (a, b) { return skillName(a).toLowerCase() < skillName(b).toLowerCase() ? -1 : 1; });
            var head = racialParts().map(function (p) { return p.id; });
            head.push("__class_passive__");
            return head.concat(out);
        }
        if (st.tab === "forms") {
            Object.keys(state.skills).forEach(function (s) { if ((SD.isForm(s) || SD.isStack(s)) && SD.allowed(s, state.race, state.android)) out.push(s); });
            out.sort(function (a, b) { return skillName(a).toLowerCase() < skillName(b).toLowerCase() ? -1 : 1; });
            return out;
        }
        out = techniques(st.tab);
        out.sort(function (a, b) { return TC.name(a).toLowerCase() < TC.name(b).toLowerCase() ? -1 : 1; });
        return out;
    }
    function entryName(e) {
        if (e === "__class_passive__") return passiveTitle();
        if (e.indexOf("racial_") === 0) { var p = racialParts().filter(function (x) { return x.id === e; })[0]; return p ? p.name : e; }
        if (st.tab === "ki" || st.tab === "strike" || st.tab === "evasion") return TC.name(e);
        return skillName(e);
    }

    // ---- forms tree (SkillsMenuScreen.buildFormsTree) ----
    var TYPE_ORDER = ["superforms", "androidforms", "legendaryforms", "godforms"];
    function buildForms() {
        var ordered = [];
        (SD.FORM_TREES[state.race] || []).forEach(function (g) {
            if (!SD.allowed(g[1], state.race, state.android)) return;
            g[2].forEach(function (f) { ordered.push({ group: g[0], type: g[1], name: f[0], lvl: f[1], color: f[2], saga: f[3], race: state.race }); });
        });
        ordered.sort(function (a, b) {
            var ta = TYPE_ORDER.indexOf(a.type), tb = TYPE_ORDER.indexOf(b.type);
            ta = ta < 0 ? 99 : ta; tb = tb < 0 ? 99 : tb;
            if (ta !== tb) return ta - tb;
            if (a.lvl !== b.lvl) return a.lvl - b.lvl;
            return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1;
        });
        SD.STACK_SKILLS.forEach(function (s) {
            (SD.FORM_TREES.stack || []).forEach(function (g) {
                if (g[1] !== s || !SD.allowed(s, state.race, state.android)) return;
                g[2].forEach(function (f) { ordered.push({ group: g[0], type: g[1], name: f[0], lvl: f[1], color: f[2], saga: f[3], race: "stack" }); });
            });
        });
        var groups = [], byGroup = {};
        ordered.forEach(function (n) {
            if (!byGroup[n.group]) { byGroup[n.group] = []; groups.push(n.group); }
            byGroup[n.group].push(n);
        });
        var nodes = [], gy = -Math.floor(groups.length * 80 / 2);
        groups.forEach(function (g) {
            var list = byGroup[g], fx = -Math.floor(list.length * 80 / 2);
            list.forEach(function (n) { n.x = fx; n.y = gy; nodes.push(n); fx += 80; });
            gy += 80;
        });
        st.nodes = nodes;
    }
    function formLabel(n) {
        if (n.race === "stack") return [U.tr("race.dragonminez.stack.group." + n.group), U.tr("race.dragonminez.stack.form." + n.group + "." + n.name)];
        return [U.tr("race.dragonminez." + n.race + ".group." + n.group), U.tr("race.dragonminez." + n.race + ".form." + n.group + "." + n.name)];
    }
    function nodeInfo(n) {
        var cur = level(n.type), has = owned(n.type), unlocked = has && cur >= n.lvl;
        var target = Math.max(0, n.lvl - 1), cost = SD.cost(n.type, target, state.race);
        var firstStack = SD.isStack(n.type) && target === 0;
        var locked = !unlocked && n.saga && !done(n.saga);
        var canBuy = !unlocked && n.lvl === cur + 1 && !firstStack && !locked && cost >= 0 && RPG.player.tp >= cost;
        return { cur: cur, unlocked: unlocked, cost: cost, firstStack: firstStack, locked: locked, canBuy: canBuy };
    }

    // ---- open ----
    function open() {
        st = fresh();
        TC.request();
        st.rightX = 0;
        var els = [{ id: "model", type: "entity", anchor: "center", x: -35, y: -30, w: 80, h: 100, rotation: 180, followMouse: false, size: 75 }];
        var nav = [[-110, 120, "party"], [-70, 0, "stats"], [-30, 20, "skills"], [10, 60, "quests"], [50, 140, "minigames"], [90, 100, "config"]];
        nav.forEach(function (n) {
            els.push({ id: "nav_" + n[2], type: "button", anchor: "bottom", x: n[0], y: -30, w: 20, h: 20, texture: NAV, texW: 256, texH: 256,
                u: n[1], v: 0, uw: 20, vh: 20, hoverU: n[1], hoverV: 20, tooltip: n[2].charAt(0).toUpperCase() + n[2].slice(1),
                onClick: function () { navigate(n[2]); } });
        });
        RPG.screen.open({ id: "dmz_skills", referenceHeight: DMZ_OPTS.menuRef(), background: "dim", elements: els, onRender: render, onMouse: mouse, onScroll: scroll,
            onKey: function (k, a) { if (typeof DMZ_TUTORIAL !== "undefined" && DMZ_TUTORIAL.active("dmz_skills")) return DMZ_TUTORIAL.key(k, a); },
            onClose: function () { st = null; if (typeof DMZ_TUTORIAL !== "undefined") DMZ_TUTORIAL.closed("dmz_skills"); } });
        tutorial();
    }
    // ---- DMZ's tutorials (SkillsMenuScreen.generalTutorial / techniqueTutorial / formsTutorial), once each ----
    function tutorial() {
        if (typeof DMZ_TUTORIAL === "undefined" || !st || DMZ_TUTORIAL.active()) return;
        var left = function (ctx) { return [[12, Math.floor(ctx.height / 2) - 105, 141, 213]]; };
        var right = function (ctx) { return [[ctx.width - 158, Math.floor(ctx.height / 2) - 105, 141, 222]]; };
        var pre = "gui.dragonminez.tutorial.skills.";
        if (st.tab === "skills") DMZ_TUTORIAL.request("dmz_skills", "skills_general", [
            { text: pre + "tabs", title: pre + "tabs.title", revealTabs: true, rects: function (ctx) { return [[12 + 122, Math.floor(ctx.height / 2) - 99, 46, 160]]; } },
            { text: pre + "list", title: pre + "list.title", rects: left },
            { text: pre + "details", title: pre + "details.title", rects: right }]);
        else if (st.tab === "ki" || st.tab === "strike" || st.tab === "evasion") DMZ_TUTORIAL.request("dmz_skills", "skills_techniques", [
            { text: pre + "techniques.list", title: pre + "techniques.list.title", rects: left },
            { text: pre + "techniques.details", title: pre + "techniques.details.title", rects: right }]);
        else if (st.tab === "forms") DMZ_TUTORIAL.request("dmz_skills", "skills_forms", [
            { text: pre + "forms.main", title: pre + "forms.main.title", rects: function (ctx) { return [[ctx.width / 2 - 210, ctx.height / 2 - 120, 330, 120]]; } },
            { text: pre + "forms.legendary", title: pre + "forms.legendary.title", rects: function (ctx) { return [[ctx.width / 2 - 210, ctx.height / 2, 330, 110]]; } }]);
    }
    function navigate(where) {
        RPG.sound("dmzpack:ui_menu_switch", 1, 1);
        if (where === "skills") return;
        RPG.net.send("dmz_menu", { tab: where });
    }
    function setTab(t) {
        st.tab = t; st.selected = null; st.scroll = 0; st.descScroll = 0; st.binding = false;
        if (t === "forms") { st.formGroup = null; st.formName = null; buildForms(); }
        RPG.sound("dmzpack:pip_menu", 1, 1);
        tutorial();
    }

    // ---- render ----
    function render(ctx) {
        if (!st) return;
        var W = ctx.width, H = ctx.height, cy = Math.floor(H / 2), mx = ctx.mouseX, my = ctx.mouseY;
        st.cy = cy; st.H = H;
        var now = RPG.nowMs(), dt = Math.min(0.1, (now - st.last) / 1000), step = dt / 0.24;
        st.last = now;
        st.formsT = U.approach(st.formsT, st.tab === "forms" ? 1 : 0, step);
        st.zoom += (st.targetZoom - st.zoom) * Math.min(1, dt * 60 * 0.08);
        if (st.drag) { st.pan[0] = st.drag.px + (mx - st.drag.x); st.pan[1] = st.drag.py + (my - st.drag.y); }

        var nearLeft = mx <= 36, overLeft = mx >= st.leftX && mx < st.leftX + 141 + 42 && my >= cy - 105 && my < cy + 108;
        st.leftHover = U.approach(st.leftHover, nearLeft || overLeft ? 1 : 0, step);
        var leftPos = 12 - 117 * (1 - U.ease(st.leftHover)) * U.ease(st.formsT);
        st.leftX = Math.floor(leftPos);
        st.rightX = Math.floor(W - 158 + 200 * U.ease(st.formsT));

        // the player model slides to the right in the forms view
        var modelX = (W / 2 + 5) + ((W - 80) - (W / 2 + 5)) * U.ease(st.formsT);
        RPG.screen.update("model", { x: Math.round(modelX - W / 2 - 40) });

        if (st.formsT > 0) renderForms(ctx, mx, my);
        renderLeft(ctx, st.leftX, cy - 105, mx, my, cy);
        if (st.formsT < 1) renderRight(ctx, st.rightX, cy - 105, mx, my);
        if (st.formsT > 0.8) formTooltip(ctx, mx, my);
        if (typeof DMZ_TUTORIAL !== "undefined") DMZ_TUTORIAL.render(ctx);
    }

    function renderLeft(ctx, px, py, mx, my, cy) {
        // category tabs slide out from under the panel
        var hidden = px + 122, visible = px + 141;
        var overPanel = mx >= px && mx < px + 141 && my >= py && my < py + 213;
        var overHot = mx >= hidden && mx < visible + 26 && my >= py + 6 && my < py + 171;
        var cur = typeof DMZ_TUTORIAL !== "undefined" && DMZ_TUTORIAL.active("dmz_skills") ? DMZ_TUTORIAL.current() : null;
        st.reveal = U.approach(st.reveal, overPanel || overHot || (cur && cur.revealTabs) ? 1 : 0, 1 / 15);
        var tx = hidden + (visible - hidden) * U.ease(st.reveal);
        TABS.forEach(function (t, i) {
            var y = py + 6 + 32 * i, clip = visible;
            var x0 = Math.max(tx, clip), w = tx + 26 - x0;
            if (w <= 0) return;
            var du = x0 - tx;
            ctx.quad(MENU_BIG, x0, y, w, 32, (t[1] + du) / 256, t[2] / 256, (t[1] + 26) / 256, (t[2] + 32) / 256, "#FFFFFF", 1);
        });
        ctx.image(MENU_BIG, px, py, 141, 213, 0, 0, 141, 213, 256, 256);
        ctx.image(MENU_BIG, px + 17, py + 10, 107, 21, 142, 22, 107, 21, 256, 256);

        var list = entries(), startY = py + 30, viewH = VISIBLE * ITEM_H, total = list.length * ITEM_H;
        var canScroll = total > viewH, listRight = px + (canScroll ? 124 : 130);
        st.scroll = Math.max(0, Math.min(st.scroll, Math.max(0, total - viewH)));
        list.forEach(function (e, i) {
            var y = startY + i * ITEM_H - st.scroll;
            if (y < startY - 2 || y + 12 > startY + viewH) return;
            var sel = e === st.selected, hov = mx >= px + 10 && mx <= px + 100 && my >= y && my <= y + ITEM_H;
            var color = sel ? "#FFAA00" : hov ? "#AAAAAA" : "#FFFFFF";
            U.bordered(ctx, U.ellipsis(ctx, entryName(e), 100), px + 15, y + 5, color);
            if (st.tab === "skills" || st.tab === "forms") {
                if (owned(e)) { var lv = String(level(e)); U.bordered(ctx, lv, listRight - U.width(ctx, lv), y + 5, color); }
            } else if (TD.gainsXp(e) && TC.state.u[e]) {
                var xp = String(TC.state.u[e].x || 0); U.bordered(ctx, xp, listRight - U.width(ctx, xp), y + 5, color);
            }
        });
        if (canScroll) {
            var thumb = Math.max(20, viewH * viewH / total), ty = startY + (viewH - thumb) * (st.scroll / (total - viewH));
            ctx.fill(px + 128, startY, 2, viewH, "#000000", 0.4);
            ctx.fill(px + 128, ty, 2, thumb, "#FFFFFF", 0.7);
        }
        var tab = TABS.filter(function (t) { return t[0] === st.tab; })[0];
        U.bordered(ctx, "§l" + U.tr(tab[3]), px + 68, cy - 88, "#FBC51C", 0.5);
    }

    function renderRight(ctx, px, py, mx, my) {
        var tech = st.tab === "ki" || st.tab === "strike" || st.tab === "evasion";
        if (tech) {
            ctx.image(MENU_BIG, px, py, 141, 213, 0, 0, 141, 213, 256, 256);
            ctx.image(MENU_BIG, px + 17, py + 10, 107, 21, 142, 22, 107, 21, 256, 256);
        } else {
            ctx.image(MENU_SMALL, px, py, 141, 94, 0, 0, 141, 94, 256, 256);
            ctx.image(MENU_BIG, px + 17, py + 10, 107, 21, 142, 22, 107, 21, 256, 256);
            ctx.image(MENU_SMALL, px, py + 96, 141, 94, 0, 0, 141, 94, 256, 256);
            ctx.image(MENU_SMALL, px, py + 190, 141, 32, 0, 154, 141, 32, 256, 256);
        }
        U.bordered(ctx, "§l" + U.tr("gui.dragonminez.character_stats.info"), px + 70, py + 16, "#FFD700", 0.5);
        if (!st.selected) return;
        if (tech) renderTechnique(ctx, px, py, mx, my);
        else if (st.tab === "skills") renderSkill(ctx, px, py, mx, my);
        U.drawStatus(ctx, px + 70, py + 208);
    }

    function descBox(ctx, text, x, y, mx, my) {
        var lines = U.wrap(ctx, text, DESC_W - 4), viewH = 6 * LINE, total = lines.length * LINE;
        st.descScroll = Math.max(0, Math.min(st.descScroll, Math.max(0, total - viewH)));
        st.descRect = [x, y, DESC_W, viewH];
        lines.forEach(function (l, i) {
            var ly = y + i * LINE - st.descScroll;
            if (ly < y - 1 || ly + 9 > y + viewH) return;
            U.plain(ctx, l, x, ly, "#CCCCCC");
        });
        if (total > viewH) {
            var thumb = Math.max(10, viewH * viewH / total), ty = y + (viewH - thumb) * (st.descScroll / (total - viewH));
            ctx.fill(x + DESC_W - 1, y, 2, viewH, "#000000", 0.4);
            ctx.fill(x + DESC_W - 1, ty, 2, thumb, "#FFFFFF", 0.7);
        }
    }

    // SkillsMenuScreen.renderSkillDetails + the Upgrade button
    function renderSkill(ctx, px, py, mx, my) {
        var s = st.selected, y0 = py + 40, desc, name;
        st.upgradeRect = null;
        if (s === "__class_passive__") {
            name = passiveTitle(); desc = U.tr("class.dragonminez." + className() + ".passive.desc");
            U.bordered(ctx, "§l" + name, px + 72, y0, "#FFFFFF", 0.5);
            U.bordered(ctx, U.tr("class.dragonminez.passive"), px + 72, y0 + 12, "#FFD200", 0.5);
        } else if (s.indexOf("racial_") === 0) {
            var part = racialParts().filter(function (x) { return x.id === s; })[0];
            if (!part) return;
            U.bordered(ctx, "§l" + part.name, px + 72, y0, "#FFFFFF", 0.5);
            U.bordered(ctx, U.tr("gui.dragonminez.skills.racial"), px + 72, y0 + 12, "#55FF55", 0.5);
            desc = part.desc;
        } else {
            if (!owned(s)) return;
            var lv = level(s), max = SD.maxLevel(s, state.race), cost = SD.cost(s, lv, state.race);
            U.bordered(ctx, "§l" + skillName(s), px + 72, y0, "#FFFFFF", 0.5);
            U.bordered(ctx, U.tr("gui.dragonminez.skills.level", lv, max), px + 72, y0 + 12, "#AAAAAA", 0.5);
            if (cost > 0) U.bordered(ctx, cost + " TPS", px + 72, y0 + 24, "#AAAAAA", 0.5);
            desc = U.tr("skill.dragonminez." + s + ".desc");
            if (lv < max && cost >= 0) {
                var can = RPG.player.tp >= cost;
                U.button(ctx, U.tr("gui.dragonminez.skills.upgrade"), px + 35, py + 196, can);
                st.upgradeRect = [px + 35, py + 196, can];
            }
        }
        descBox(ctx, desc, px + DESC_X, y0 + 70, mx, my);
    }

    // SkillsMenuScreen.renderTechniqueDetails + initBindButtons / initTechniqueUpgradeButtons
    function raceAllowed(id) { return !isDmz(id) || SD.allowed(id, TC.state.race || state.race, TC.state.android); }
    function racesText(id) {
        var list = SD.RACES[id] || [];
        if (!list.length) return U.tr("gui.dragonminez.technique.races.all");
        return list.map(function (r) { return U.hasTr("race.dragonminez." + r) ? U.tr("race.dragonminez." + r) : U.humanize(r); }).join(", ");
    }
    function line(ctx, label, value, x, y, color) { U.bordered(ctx, U.tr(label) + ": " + value, x, y, color); }
    function renderTechnique(ctx, px, py, mx, my) {
        var id = st.selected, y = py + 40;
        st.bindRect = null; st.slotRects = []; st.deleteRect = null; st.upRects = [];
        if (!isDmz(id)) return renderLegacy(ctx, px, py, mx, my);
        var t = TD.get(id), r = TC.state.u[id], inf = TC.state.info[id] || {};
        if (!r) return;
        U.bordered(ctx, "§l" + TC.name(id), px + 70, y, "#FFFFFF", 0.5);
        y += 12;
        if (TD.gainsXp(id)) U.bordered(ctx, U.tr("gui.dragonminez.technique.xp", r.x || 0), px + 70, y, "#55FF55", 0.5);
        y += 16;
        var allowed = raceAllowed(id), fmt1 = function (n) { return (Math.round(n * 10) / 10).toFixed(1); };
        var cdTicks = inf.cd || 0, xpReq = TD.MIN_XP_COST;
        var upRow = function (stat) {
            if (allowed && TD.canUpgrade(id, stat) && (r.x || 0) >= xpReq) {
                var bx = px + 115, by = y - 1, over = U.inside(mx, my, bx, by, 14, 11);
                ctx.image(U.BUTTONS, bx, by, 14, 11, 0, over ? 10 : 0, 10, 10, 256, 256);
                st.upRects.push([bx, by, stat]);
            }
        };
        if (t.kind === "ki") {
            line(ctx, "gui.dragonminez.technique.type", TC.typeLabel(id), px + 15, y, "#DDDDDD"); y += 12;
            line(ctx, "gui.dragonminez.technique.races", racesText(id), px + 15, y, allowed ? "#DDDDDD" : "#FF5555"); y += 12;
            line(ctx, "gui.dragonminez.technique.damage", String(inf.dmg || 0), px + 15, y, "#FFFFFF"); y += 12;
            line(ctx, "gui.dragonminez.technique.size", fmt1(t.size), px + 15, y, "#FFFFFF"); y += 12;
            line(ctx, "gui.dragonminez.technique.speed", fmt1(t.speed), px + 15, y, "#FFFFFF"); y += 12;
            line(ctx, "gui.dragonminez.technique.armor_pen", "0", px + 15, y, "#FFFFFF"); y += 12;
        } else if (t.kind === "strike") {
            line(ctx, "gui.dragonminez.technique.type", TC.typeLabel(id), px + 15, y, "#DDDDDD"); y += 12;
            line(ctx, "gui.dragonminez.technique.races", racesText(id), px + 15, y, allowed ? "#DDDDDD" : "#FF5555"); y += 12;
            upRow("damage");
            line(ctx, "gui.dragonminez.technique.damage", String(inf.dmg || 0), px + 15, y, "#FFFFFF"); y += 12;
        } else if (t.kind === "evasion") {
            line(ctx, "gui.dragonminez.technique.type", TC.typeLabel(id), px + 15, y, "#DDDDDD"); y += 12;
            line(ctx, "gui.dragonminez.technique.races", racesText(id), px + 15, y, allowed ? "#DDDDDD" : "#FF5555"); y += 12;
            upRow("duration");
            line(ctx, "gui.dragonminez.technique.duration", fmt1((inf.dur || t.dur) / 20) + "s", px + 15, y, "#FFFFFF"); y += 12;
        }
        if (t.kind !== "ki") upRow("cooldown");
        line(ctx, "gui.dragonminez.technique.cooldown", fmt1(cdTicks / 20) + "s", px + 15, y, "#FFFFFF"); y += 12;
        line(ctx, "gui.dragonminez.technique.energy_cost", fmt1(inf.cost || 0), px + 15, y, "#FFAAAA"); y += 12;
        U.bordered(ctx, U.tr("gui.dragonminez.technique.req_xp", xpReq), px + 15, y, "#AAAAAA");
        var left = TC.cooldown(id);
        if (left > 0) U.bordered(ctx, left.toFixed(1) + "s", px + 126, py + 40, "#FFD200", 1);
        if (!allowed) U.bordered(ctx, U.tr("gui.dragonminez.technique.race_locked"), px + 70, py + 191, "#FF5555", 0.5);
        bindButtons(ctx, px, py, mx, my, allowed, true);
    }
    // an addon skill (40_skills.js) in a technique tab: what the skill exposes, and Bind to Slot
    function renderLegacy(ctx, px, py, mx, my) {
        var id = st.selected, y = py + 40;
        U.bordered(ctx, "§l" + RPG.defName("skill", id), px + 70, y, "#FFFFFF", 0.5); y += 12;
        var lv = RPG.player.skillLevel(id), max = Number(RPG.defField("skill", id, "maxLevel")) || 0;
        U.bordered(ctx, U.tr("gui.dragonminez.skills.level", lv, max || lv), px + 70, y, "#55FF55", 0.5); y += 16;
        var cd = Number(RPG.defField("skill", id, "cooldown"));
        if (cd > 0) { line(ctx, "gui.dragonminez.technique.cooldown", (cd / 20).toFixed(1) + "s", px + 15, y, "#FFFFFF"); y += 12; }
        var desc = RPG.defField("skill", id, "description");
        if (desc) descBox(ctx, String(desc), px + DESC_X, Math.max(y + 4, py + 110), mx, my);
        bindButtons(ctx, px, py, mx, my, true, false);
    }
    function bindButtons(ctx, px, py, mx, my, allowed, deletable) {
        if (!allowed) st.binding = false;
        if (!st.binding) {
            var yPos = py + 185;
            if (allowed) { U.button(ctx, U.tr("gui.dragonminez.skills.bind_to_slot"), px + 35, yPos, true); st.bindRect = [px + 35, yPos]; }
            if (deletable) {
                var dx = px + 119, dy = yPos - 14, over = U.inside(mx, my, dx, dy, 14, 11);
                ctx.image(U.BUTTONS, dx, dy, 14, 11, 10, over ? 10 : 0, 10, 10, 256, 256);
                st.deleteRect = [dx, dy];
            }
        } else {
            for (var i = 0; i < 8; i++) {
                var sx = px + 50 + (i < 4 ? i : i - 4) * 12, sy = i < 4 ? py + 175 : py + 186;
                var o = U.inside(mx, my, sx, sy, 10, 10);
                ctx.image(BUTTONS, sx, sy, 10, 10, 152, o ? 10 : 0, 10, 10, 256, 256);
                U.plain(ctx, String(i + 1), sx + 5, sy + 1, "#FFFFFF", 0.5);
                st.slotRects.push([sx, sy, i]);
            }
        }
    }

    // our projectile id -> DMZ technique type name (technique.type.*)
    function projType(proj) {
        var shape = proj ? String(RPG.defField("projectile", proj, "shape") || "") : "";
        if (shape === "beam") return "beam";
        if (shape === "laser") return "laser";
        if (shape === "disk") return "disk";
        if (/barrage|volley/.test(String(proj))) return "barrage";
        return shape === "ball" ? "medium_ball" : "wave";
    }

    function renderForms(ctx, mx, my) {
        var W = ctx.width, H = ctx.height, a = st.formsT, z = st.zoom, spacing = 20;
        var ox = ((st.pan[0] % spacing) + spacing) % spacing, oy = ((st.pan[1] % spacing) + spacing) % spacing;
        for (var x = ox - spacing; x < W; x += spacing) ctx.fill(x, 0, 1, H, "#222244", a);
        for (var y = oy - spacing; y < H; y += spacing) ctx.fill(0, y, W, 1, "#222244", a);
        var cx = W / 2 + st.pan[0], cy = H / 2 + st.pan[1];
        var nodes = st.nodes;
        for (var i = 0; i < nodes.length - 1; i++) {
            var c = nodes[i], n = nodes[i + 1];
            if (c.group !== n.group) continue;
            var t = Math.max(1, 3 * z);
            ctx.fill(cx + (c.x + 16) * z, cy + (c.y + 16) * z - t / 2, (n.x - c.x) * z, t, "#555555", a);
        }
        st.hoverNode = null;
        nodes.forEach(function (n) {
            var nx = cx + n.x * z, ny = cy + n.y * z, size = 32 * z, info = nodeInfo(n);
            if (mx >= nx && mx <= nx + size && my >= ny && my <= ny + size) st.hoverNode = n;
            var sel = n.group === st.formGroup && n.name === st.formName;
            ctx.fill(nx - 2, ny - 2, size + 4, size + 4, sel ? "#FFFF00" : info.unlocked ? "#00AA00" : "#333333", a);
            ctx.fill(nx, ny, size, size, "#111111", a);
            var tint = info.unlocked ? (n.color || "#FFFFFF") : "#666666";
            ctx.quad("dmzpack:textures/gui/icons/" + n.type + ".png", nx + 4 * z, ny + 4 * z, 24 * z, 24 * z, 0, 0, 1, 1, tint, a);
            if (info.canBuy) ctx.quad(EXCLAMATION, nx + size - 6 * z, ny - 10 * z, 6 * z, 15 * z, 0, 0, 1, 1, "#FFFFFF", a);
        });
    }

    function formTooltip(ctx, mx, my) {
        var n = st.hoverNode;
        if (!n) return;
        var lbl = formLabel(n), info = nodeInfo(n), stack = n.race === "stack", lines = [];
        lines.push(["§l" + lbl[0], stack ? "#5555FF" : "#FFAA00"]);
        lines.push([lbl[1], stack ? "#55FFFF" : "#FFFF55"]);
        lines.push([skillName(n.type) + ": " + n.lvl, "#AAAAAA"]);
        if (info.unlocked) lines.push([U.tr("gui.dragonminez.skills.purchased"), "#55FF55"]);
        else if (info.cost < 0) {
            var quests = typeof DMZ_QUEST_NAMES !== "undefined" ? DMZ_QUEST_NAMES.grantingSkill(n.type, n.lvl) : [];
            if (!quests.length) lines.push([U.tr("gui.dragonminez.skills.priceless"), "#AA0000"]);
            else {
                lines.push([U.tr("gui.dragonminez.skills.unlocked_by_quest"), "#FF55FF"]);
                quests.forEach(function (q) { lines.push([q, "#AAAAAA"]); });
            }
        } else {
            lines.push([U.tr("gui.dragonminez.quests.rewards.tps", info.cost), "#55FFFF"]);
            if (info.locked) lines.push([U.tr("gui.dragonminez.skills.locked_until", typeof DMZ_QUEST_NAMES !== "undefined" ? DMZ_QUEST_NAMES.label(n.saga) : n.saga), "#FF5555"]);
            else if (n.lvl === info.cur + 1 && !info.firstStack && RPG.player.tp >= info.cost) lines.push([U.tr("gui.dragonminez.skills.doubleclick_buy"), "#FFFF55"]);
        }
        U.tooltip(ctx, lines, mx, my, "#FFFFFF");
    }

    // ---- input ----
    function mouse(x, y, button, action) {
        if (!st) return;
        if (typeof DMZ_TUTORIAL !== "undefined" && DMZ_TUTORIAL.active("dmz_skills")) return DMZ_TUTORIAL.mouse(x, y, button, action);
        if (action === "up") { st.drag = null; return; }
        var cy = st.cy || 180, px = st.leftX, py = cy - 105;
        // tabs
        var tx = px + 122 + 19 * U.ease(st.reveal);
        for (var i = 0; i < TABS.length; i++) {
            var ty = py + 6 + 32 * i;
            if (x >= Math.max(tx, px + 141) && x < tx + 26 && y >= ty && y < ty + 32) { setTab(TABS[i][0]); return false; }
        }
        // list
        var list = entries(), startY = py + 30;
        if (x >= px + 10 && x <= px + 100 && y >= startY && y < startY + VISIBLE * ITEM_H) {
            var idx = Math.floor((y - startY + st.scroll) / ITEM_H);
            if (idx >= 0 && idx < list.length) {
                st.selected = list[idx]; st.descScroll = 0; st.binding = false;
                if (st.tab === "forms") {
                    st.formName = null;
                    for (var k = 0; k < st.nodes.length; k++) if (st.nodes[k].type === st.selected) {
                        st.formGroup = st.nodes[k].group; st.formName = st.nodes[k].name; st.pan = [-st.nodes[k].x, -st.nodes[k].y]; break;
                    }
                }
                RPG.sound("dmzpack:pip_menu", 1, 1);
                return false;
            }
        }
        if (x >= px && x <= px + 141 && y >= py && y <= py + 213) return false;
        // right panel buttons
        if (st.formsT < 1) {
            if (st.upgradeRect && st.upgradeRect[2] && U.inside(x, y, st.upgradeRect[0], st.upgradeRect[1], 74, 20)) {
                RPG.net.send("dmz_skill", { action: "upgrade", skill: st.selected });
                return false;
            }
            if (st.bindRect && !st.binding && U.inside(x, y, st.bindRect[0], st.bindRect[1], 74, 20)) { st.binding = true; RPG.sound("dmzpack:pip_menu", 1, 1); return false; }
            if (st.binding && st.slotRects) for (var j = 0; j < st.slotRects.length; j++) {
                var r = st.slotRects[j];
                if (U.inside(x, y, r[0], r[1], 10, 10)) {
                    TC.equip(r[2], st.selected);                         // EquipTechniqueC2S
                    st.binding = false; RPG.sound("dmzpack:pip_menu", 1, 1);
                    return false;
                }
            }
            if (!st.binding && st.deleteRect && U.inside(x, y, st.deleteRect[0], st.deleteRect[1], 14, 11)) {
                TC.forget(st.selected);                                  // DeleteTechniqueC2S
                st.selected = null; entryCache.at = 0; RPG.sound("dmzpack:pip_menu", 1, 1);
                return false;
            }
            if (st.upRects) for (var q = 0; q < st.upRects.length; q++) {
                var ur = st.upRects[q];
                if (U.inside(x, y, ur[0], ur[1], 14, 11)) { TC.upgrade(st.selected, ur[2]); return false; }   // UpgradeTechniqueC2S
            }
            if (x >= st.rightX && x <= st.rightX + 141 && y >= py && y <= py + 213) return false;
        }
        // forms tree: click selects, double click buys, drag pans
        if (st.tab === "forms" && button === 0 && y < (st.H || 360) - 34) {
            var n = st.hoverNode;
            if (n) {
                var now = RPG.nowMs(), same = n.group === st.formGroup && n.name === st.formName;
                if (same && now - st.lastFormClick < 500) {
                    var info = nodeInfo(n);
                    if (info.canBuy) RPG.net.send("dmz_skill", { action: "upgrade", skill: n.type });
                } else { st.formGroup = n.group; st.formName = n.name; st.selected = n.type; }
                st.lastFormClick = now;
                return false;
            }
            st.drag = { x: x, y: y, px: st.pan[0], py: st.pan[1] };
            return false;
        }
    }

    function scroll(x, y, delta) {
        if (!st) return;
        var py = (st.cy || 180) - 105, d = delta > 0 ? 1 : -1;
        if (x >= st.leftX && x <= st.leftX + 141 && y >= py && y <= py + 213) { st.scroll = Math.max(0, st.scroll - d * ITEM_H * 2); return; }
        if (st.descRect && U.inside(x, y, st.descRect[0], st.descRect[1], st.descRect[2] + 4, st.descRect[3])) { st.descScroll = Math.max(0, st.descScroll - d * 24); return; }
        if (st.tab === "forms") st.targetZoom = Math.max(0.25, Math.min(2, st.targetZoom + d * 0.1));
    }

    RPG.net.on("dmz_skills_state", function (d) {
        if (!d) return;
        state.skills = d.skills || {}; state.race = d.race || "human"; state.android = !!d.android; state.done = d.done || [];
        entryCache.at = 0;
        if (st && st.tab === "forms") buildForms();
    });

    TC.onState(function () { entryCache.at = 0; });

    return { open: open, state: state };
})();

RPG.net.on("dmz_open_skills", function () { SKILLS_SCREEN.open(); });
