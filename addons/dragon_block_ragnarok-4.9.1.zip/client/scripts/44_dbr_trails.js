// =====================================================================================
//  44_dbr_trails.js - aura trails, space pod trails and the space pod aura (DMZ Ragnarok)
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0):
//    DashTrailRenderer + FastFlightAura's "flying" verdict   -> the aura streak behind every
//        player who is flying or dashing: five thin lines in their aura colour, brightest at
//        the body, gone about a second behind them. Option "Aura Trails" (default on).
//    PodTrailRenderer                                         -> the engine wake behind every
//        moving space pod in space: a wide soft band, a hot core and an exhaust glow, tinted
//        with the pilot's aura colour. Option "Space Pod Trails" (default on).
//    MixinDmzAuraPodEncase + MixinDmzAuraLayer (pod exhaust)  -> a pilot's aura wraps the whole
//        pod and streams out behind it; your own pod under autopilot wears your aura as its
//        exhaust even when you are not powered up. Option "Space Pod Aura" (default on).
//  Everything is drawn on each player's own computer from what they can see, so other
//  players' trails and pod auras show for everyone. The engine records the trails
//  (RPG.trails) and wraps the aura around the vehicle (RPG.auras.options vehicles).
// =====================================================================================
var DBR_TRAILS = (function () {
    var KEYS = { auraTrails: "dbr_cfg_aura_trails", podTrails: "dbr_cfg_pod_trails", podAura: "dbr_cfg_pod_aura" };
    var SPACE = "ragnarok_rpg:space", POD = "spacepod";

    function opt(key) { try { var v = RPG.storage.get(key, true); return v === null || v === undefined ? true : !!v; } catch (e) { return true; } }
    function setOpt(key, v) { try { RPG.storage.set(key, !!v); } catch (e) { } apply(); }

    // ---- colours ------------------------------------------------------------------------
    function hex(n) { var s = (n & 0xFFFFFF).toString(16); while (s.length < 6) s = "0" + s; return "#" + s; }
    function rgb(n) { return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255]; }
    function toInt(c) { return (Math.round(c[0] * 255) << 16) | (Math.round(c[1] * 255) << 8) | Math.round(c[2] * 255); }
    function whiten(c, t) { return [c[0] * (1 - t) + t, c[1] * (1 - t) + t, c[2] * (1 - t) + t]; }
    /** AuraColors.of: the aura the player is drawn with now (form colour included), white if unknown. */
    function auraOf(pl) { try { return pl.color("dmzAura", -1); } catch (e) { return -1; } }

    // ---- who is flying (FastFlightAura): flight skill on, off the ground, moving 0.12+ b/t, held 6 ticks ----
    var HOLD_TICKS = 6, MIN_TRAIL_SPEED = 0.12;
    var LAST = {}, FLY_UNTIL = {}, T = 0;
    function dashing(id) { return typeof DBR_RAG_COMBAT !== "undefined" && DBR_RAG_COMBAT.isDashing(id); }
    function sampleFlight(pl) {
        var prev = LAST[pl.id], now = { x: pl.x, y: pl.y, z: pl.z };
        LAST[pl.id] = now;
        if (!prev) return;
        var dx = now.x - prev.x, dy = now.y - prev.y, dz = now.z - prev.z, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d < MIN_TRAIL_SPEED || pl.onGround || !pl.shared("fly", 0)) { delete FLY_UNTIL[pl.id]; return; }
        FLY_UNTIL[pl.id] = T + HOLD_TICKS;
    }
    function trailing(pl) { return dashing(pl.id) || (FLY_UNTIL[pl.id] || 0) > T; }

    // ---- DashTrailRenderer: 5 strands, 0.45 spread, waist height, 20 points / 1.2 s, cut past 12 blocks ----
    var HIGHLIGHT = 0.25;
    function auraTrail(pl, on) {
        var id = "dbr_at_" + pl.id;
        if (!on) { if (RPG.trails.has(id)) RPG.trails.update(id, { active: false }); return; }
        var a = auraOf(pl), tint = a < 0 ? [1, 1, 1] : rgb(a);
        var spec = { entity: pl.id, style: "lines", strands: 5, spread: 0.45, y: 0.9, setback: 0.45, samples: 20, life: 24,
            maxSegment: 12, color: hex(toInt(whiten(tint, HIGHLIGHT))), alpha: 1, active: true, decay: true };
        RPG.trails.set(id, spec);
    }

    // ---- PodTrailRenderer: 48 points / 2.4 s, cut past 16 blocks, nothing under 0.2 b/t, width by speed 0.2..1.2 ----
    var CORE_RGB = [1.0, 0.86, 0.58], GLOW_RGB = [0.35, 0.72, 1.0], CORE_WHITEN = 0.5;
    function podTrail(pl, on) {
        var id = "dbr_pt_" + pl.id;
        if (!on) {
            // out of the pod the trail would follow the pilot instead: drop it; outside space it just stops recording
            if (RPG.trails.has(id)) { if (pl.vehicleId !== POD) RPG.trails.remove(id); else RPG.trails.update(id, { active: false }); }
            return;
        }
        var a = auraOf(pl), glow = a < 0 ? GLOW_RGB : rgb(a), core = a < 0 ? CORE_RGB : whiten(glow, CORE_WHITEN);
        RPG.trails.set(id, { entity: pl.id, vehicle: true, style: "ribbon", y: 0, setback: 0.55, samples: 48, life: 48, maxSegment: 16,
            minSpeed: 0.2, width: 0.95, alpha: 0.26, color: hex(toInt(glow)), blend: "additive", speedWidth: [0.2, 1.2],
            core: { width: 0.30, alpha: 0.60, color: hex(toInt(core)) }, flare: { radius: 0.85, alpha: 1, color: hex(toInt(glow)) },
            active: true, decay: false });
    }

    // ---- the pod aura: riders' auras wrap the pod; your autopilot pod wears your aura (MixinDmzAuraLayer) ----
    var AURA_BASE = "effect:dmz_aura_3";              // the plain powered-up aura (height 4.5, 30_forms.js)
    function autopilot() { try { return typeof dbrPodAutopilot === "function" && !!dbrPodAutopilot(); } catch (e) { return false; } }

    var applied = null;
    function apply() {
        var key = [opt(KEYS.auraTrails), opt(KEYS.podTrails), opt(KEYS.podAura)].join();
        if (key === applied) return;
        applied = key;
        if (!opt(KEYS.auraTrails)) RPG.trails.removePrefix("dbr_at_");
        if (!opt(KEYS.podTrails)) RPG.trails.removePrefix("dbr_pt_");
        try { RPG.auras.options({ vehicles: opt(KEYS.podAura) ? [POD] : [] }); } catch (e) { }
    }

    RPG.on("load", function () { applied = null; apply(); });
    RPG.on("tick", function () {
        T++;
        if (!RPG.player.present) return;
        apply();
        var trails = opt(KEYS.auraTrails), pods = opt(KEYS.podTrails), podAura = opt(KEYS.podAura);
        var inSpace = RPG.player.dimension === SPACE, seen = {};
        RPG.avatar.players().forEach(function (pl) {
            seen[pl.id] = true;
            sampleFlight(pl);
            var riding = pl.vehicleId === POD;
            if (trails) auraTrail(pl, !riding && !pl.spectator && trailing(pl));
            if (pods) podTrail(pl, riding && inSpace);
            if (pl.local && podAura && riding && autopilot()) RPG.auras.show(pl.id, AURA_BASE, 6);
        });
        if (T % 40 === 0) {                        // players out of view: drop what was kept for them
            Object.keys(LAST).forEach(function (id) {
                if (seen[id]) return;
                delete LAST[id]; delete FLY_UNTIL[id];
                RPG.trails.remove("dbr_at_" + id); RPG.trails.remove("dbr_pt_" + id);
            });
        }
    });

    return {
        KEYS: KEYS,
        auraTrails: function () { return opt(KEYS.auraTrails); }, setAuraTrails: function (v) { setOpt(KEYS.auraTrails, v); },
        podTrails: function () { return opt(KEYS.podTrails); }, setPodTrails: function (v) { setOpt(KEYS.podTrails, v); },
        podAura: function () { return opt(KEYS.podAura); }, setPodAura: function (v) { setOpt(KEYS.podAura, v); },
        isTrailing: function (id) { return (FLY_UNTIL[id] || 0) > T || dashing(id); }
    };
})();
