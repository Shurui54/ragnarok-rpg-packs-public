// =====================================================================================
//  83_dbr_npc_regions.js - NPC regions: world-map area editor + region/NPC forms (operators)
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0) shuruisutilities NPC region editors: NpcRegionListScreen, NpcRegionEditScreen,
//  NpcRegionDisplayScreen, NpcConfigEditScreen (tabs General / Stats / Ki / Spawn / Rewards / Drops with DMZR's
//  labels and tooltips) and the copy / paste NPC clipboard. Drawn in DMZ's menubig / characterbuttons art, rows in
//  the raid and form editors' style; every entity, model and item is a searchable dropdown.
//
//  The area is drawn free-form on the world map (the engine's "worldmap" element: explored terrain, polygons,
//  onMapMouse in world coordinates). Left click places points, click the first point to close the shape, drag a
//  point to move it, shift+click (or Delete) removes one, click an edge of a closed shape to insert a point.
//  Freehand: hold left and draw; release closes it. Right drag pans, wheel zooms. A region can have several
//  shapes; every region of this dimension shows on the map (toggle), Select picks one to edit.
//
//  Opened by /npcregion edit or the unbound "NPC Region Editor (operators)" key. The server
//  (scripts/93_dbr_npc_regions.js) checks op / rg.npcregion on every request.
// =====================================================================================
(function () {
    if (typeof DBR_RAIDS_UI === "undefined" || typeof DBR_NPCR_DATA === "undefined") return;
    var U = DMZ_UI, D = DBR_NPCR_DATA, UI = DBR_RAIDS_UI, FONT = U.FONT, CHUNK = 24000;
    var MAP_SCREEN = "dbr_npcr_map", FORM_SCREEN = "dbr_npcr_form";

    // =========================================================================================
    //  State
    // =========================================================================================
    var S = null;   // { regions, alive, dim, work, oldId, cur, sel, mode, others, grid, view, dirty, drag, stroke, hover, confirm }
    function newRegion(dim) {
        var r = D.region({ name: "", dim: dim || "minecraft:overworld" });
        r.id = ""; r.name = "";
        return r;
    }
    function workShapes() { return S.work.shapes; }
    function curShape() { return S.work.shapes[S.cur] || null; }
    function loadWork(r) {
        S.work = JSON.parse(JSON.stringify(r));
        S.work.shapes.forEach(function (s) { s.closed = true; delete s.b; });
        S.oldId = r.id || "";
        S.cur = S.work.shapes.length ? 0 : -1; S.sel = -1; S.dirty = false;
    }
    function changed() { S.dirty = true; }

    // ---- chunked data from the server ----
    var parts = {};
    RPG.net.on("dbr_npcr_data", function (d) {
        if (!d || typeof d.s !== "string") return;
        var box = parts[d.kind];
        if (!box || box.id !== d.id) box = parts[d.kind] = { id: d.id, n: Number(d.n) || 1, got: 0, s: [] };
        if (box.s[d.i] === undefined) { box.s[d.i] = d.s; box.got++; }
        if (box.got < box.n) return;
        delete parts[d.kind];
        var obj = null;
        try { obj = JSON.parse(box.s.join("")); } catch (e) { return; }
        if (d.kind === "editor") gotData(obj);
    });
    function gotData(o) {
        var first = !S;
        var keep = S;
        S = S || { mode: "points", others: true, grid: false, view: null, work: null, cur: -1, sel: -1, dirty: false };
        S.regions = (o.regions || []).map(D.region);
        S.alive = o.alive || {};
        S.dim = o.dim || RPG.player.dimension;
        if (o.select) {
            var r = byId(o.select);
            if (r) { loadWork(r); fitTo(r); }
        } else if (first || !S.work) { loadWork(newRegion(S.dim)); S.oldId = ""; }
        if (keep && keep.after) { var f = keep.after; keep.after = null; f(); return; }
        if (S.where === "list") regionList(); else if (S.where === "form") { /* stay */ } else openMap();
    }
    function byId(id) { for (var i = 0; i < S.regions.length; i++) if (S.regions[i].id === id) return S.regions[i]; return null; }
    RPG.net.on("dbr_npcr_open", function () { S = null; RPG.net.send("dbr_npcr", { op: "open" }); });
    RPG.net.on("dbr_npcr_ack", function (d) {
        if (!d) return;
        U.showStatus(d.msg || (d.ok ? "Done" : "Failed"), d.ok ? "#7CFF7C" : "#FF6060");
        if (S && d.ok && d.op === "save") S.dirty = false;
    });
    try { RPG.keys.register("dbr_npcr_editor", { name: "NPC Region Editor (operators)" }); } catch (e) { }
    RPG.on("keybind", function (id, down) { if (id === "dbr_npcr_editor" && down && !RPG.screen.getOpen()) { S = null; RPG.net.send("dbr_npcr", { op: "open" }); } });

    function send(op, extra) { var d = { op: op }; for (var k in extra || {}) d[k] = extra[k]; RPG.net.send("dbr_npcr", d); }
    function save() {
        var r = JSON.parse(JSON.stringify(S.work));
        var open = r.shapes.filter(function (s) { return !s.closed; }).length;
        r.shapes = r.shapes.filter(function (s) { return s.closed && s.points.length >= 6; }).map(function (s) { return { points: s.points }; });
        if (!String(r.name || "").trim()) { U.showStatus("Name the region first (Define region…)", "#FF6060"); return false; }
        if (!r.shapes.length) { U.showStatus("Draw and close a shape first", "#FF6060"); return false; }
        r.id = D.idOf(r.name);
        var s = JSON.stringify({ region: r, oldId: S.oldId }), n = Math.max(1, Math.ceil(s.length / CHUNK)), id = String(RPG.nowMs());
        for (var i = 0; i < n; i++) RPG.net.send("dbr_npcr", { op: "save", id: id, i: i, n: n, s: s.substring(i * CHUNK, (i + 1) * CHUNK) });
        if (open) U.showStatus(open + " open shape(s) were left out: close them to keep them", "#FFD34D");
        S.oldId = r.id; S.work.id = r.id;
        return true;
    }

    // =========================================================================================
    //  Map editor
    // =========================================================================================
    var MX = -292, MY = -138, MW = 404, MH = 292, SX = 120, SW = 172;
    var DEF_COLOR = "#55FF55", WORK_COLOR = "#FFD34D";
    function rgb(c, fb) { return /^#[0-9a-fA-F]{6}$/.test(String(c || "")) ? String(c).substring(1) : fb.substring(1); }
    function argb(alpha, hex) { var a = Math.round(alpha * 255).toString(16); if (a.length < 2) a = "0" + a; return "#" + a + hex; }
    function zoom() { return (S.view && S.view.zoom) || 1; }
    function saveView() {
        if (RPG.screen.getOpen() !== MAP_SCREEN) return;
        var m = RPG.screen.get("map");
        if (m) S.view = { cx: m.centerX, cz: m.centerZ, zoom: m.zoom };
    }
    function fitTo(r) {
        if (!r || !r.shapes.length) return;
        var b = D.regionBounds(r), w = Math.max(16, b[2] - b[0]), h = Math.max(16, b[3] - b[1]);
        S.view = { cx: (b[0] + b[2]) / 2, cz: (b[1] + b[3]) / 2, zoom: Math.max(0.0625, Math.min(8, Math.min(MW / w, MH / h) * 0.8)) };
    }
    function polygons() {
        var out = [];
        if (S.others) S.regions.forEach(function (r) {
            if (r.dim !== S.dim || r.id === S.oldId) return;
            var c = rgb(r.color, DEF_COLOR);
            r.shapes.forEach(function (s, i) { out.push({ points: s.points, fill: argb(0.22, c), outline: argb(0.9, c), width: 1, label: i === 0 ? "§f" + U.strip(r.title || r.name) : null }); });
        });
        if (S.work.dim === S.dim) {
            var wc = rgb(S.work.color, WORK_COLOR);
            S.work.shapes.forEach(function (s, i) {
                var cur = i === S.cur;
                var p = { points: s.points, closed: !!s.closed, outline: s.closed ? argb(1, wc) : "#FFFFFFFF", width: cur ? 2 : 1.5,
                    vertices: cur, vertexSize: 2, vertexColor: "#FFFFFFFF", selectedVertex: cur ? S.sel : -1, selectedColor: "#FFFF5555" };
                if (s.closed) p.fill = argb(cur ? 0.32 : 0.22, wc);
                if (i === 0 && s.closed && S.work.name) p.label = "§e" + U.strip(S.work.title || S.work.name);
                out.push(p);
            });
            var c2 = curShape();
            if (c2 && !c2.closed && c2.points.length >= 2 && S.hover) {
                var n = c2.points.length;
                out.push({ points: [c2.points[n - 2], c2.points[n - 1], S.hover.x, S.hover.z], closed: false, outline: "#80FFFFFF", width: 1 });
            }
        }
        return out;
    }
    function shapeLabel() { var n = S.work.shapes.length; return n ? "Shape " + (S.cur + 1) + " / " + n : "No shapes yet"; }
    function refresh() {
        if (RPG.screen.getOpen() !== MAP_SCREEN) return;
        RPG.screen.update("map", { polygons: polygons() });
        RPG.screen.update("shapelbl", { text: shapeLabel() });
    }

    // ---- hit tests (screen pixels -> blocks with the current zoom) ----
    function near(ax, az, bx, bz, px) { var r = px / zoom(); return (ax - bx) * (ax - bx) + (az - bz) * (az - bz) <= r * r; }
    function hitVertex(s, x, z) { if (!s) return -1; for (var i = (s.points.length >> 1) - 1; i >= 0; i--) if (near(s.points[i * 2], s.points[i * 2 + 1], x, z, 6)) return i; return -1; }
    function hitEdge(s, x, z) {
        if (!s || !s.closed) return -1;
        var p = s.points, n = p.length >> 1, best = -1, bd = 5 / zoom();
        for (var i = 0; i < n; i++) {
            var j = (i + 1) % n, ax = p[i * 2], az = p[i * 2 + 1], bx = p[j * 2], bz = p[j * 2 + 1], dx = bx - ax, dz = bz - az, l = dx * dx + dz * dz;
            var t = l > 0 ? Math.max(0, Math.min(1, ((x - ax) * dx + (z - az) * dz) / l)) : 0, qx = ax + dx * t - x, qz = az + dz * t - z, d = Math.sqrt(qx * qx + qz * qz);
            if (d < bd) { bd = d; best = i; }
        }
        return best;
    }
    function snap(v) { return Math.round(v); }
    /** Ramer-Douglas-Peucker on an interleaved point list. */
    function simplify(pts, tol) {
        var n = pts.length >> 1;
        if (n < 4) return pts;
        var keep = []; keep[0] = keep[n - 1] = true;
        (function rdp(a, b) {
            var ax = pts[a * 2], az = pts[a * 2 + 1], bx = pts[b * 2], bz = pts[b * 2 + 1], dx = bx - ax, dz = bz - az, l = Math.sqrt(dx * dx + dz * dz) || 1, far = -1, fd = 0;
            for (var i = a + 1; i < b; i++) { var d = Math.abs((pts[i * 2] - ax) * dz - (pts[i * 2 + 1] - az) * dx) / l; if (d > fd) { fd = d; far = i; } }
            if (far >= 0 && fd > tol) { keep[far] = true; rdp(a, far); rdp(far, b); }
        })(0, n - 1);
        var out = [];
        for (var i = 0; i < n; i++) if (keep[i]) out.push(pts[i * 2], pts[i * 2 + 1]);
        return out;
    }
    function startShape() { S.work.shapes.push({ points: [], closed: false }); S.cur = S.work.shapes.length - 1; S.sel = -1; }
    function closeCur() {
        var s = curShape();
        if (!s || s.closed) return;
        s.points = D.cleanPoints(s.points);
        if (s.points.length < 6) { U.showStatus("A shape needs at least 3 points", "#FF6060"); return; }
        s.closed = true; S.sel = -1; changed();
        U.showStatus("Shape closed (" + Math.round(D.area(s.points)) + " blocks²)", "#7CFF7C");
    }
    function deleteVertex(i) {
        var s = curShape();
        if (!s || i < 0) return;
        s.points.splice(i * 2, 2);
        if (s.closed && s.points.length < 6) s.closed = false;
        S.sel = -1; changed();
    }

    function onMapMouse(id, action, button, x, z, shift) {
        if (!S) return;
        if (action === "move") {
            S.hover = { x: snap(x), z: snap(z), fx: x, fz: z };
            var c = curShape();
            if (c && !c.closed && c.points.length) refresh();
            return;
        }
        if (button !== 0) return;
        if (S.work.dim !== S.dim && action === "down") { U.showStatus("This region is in " + S.work.dim + ": go there to edit its shape", "#FF6060"); return true; }
        var px = snap(x), pz = snap(z);
        if (action === "down") {
            S.hover = { x: px, z: pz, fx: x, fz: z };
            if (S.mode === "select") {
                var hitR = null;
                S.regions.forEach(function (r) { if (!hitR && r.dim === S.dim && r.id !== S.oldId && r.shapes.some(function (s) { return D.inPoly(s.points, x, z); })) hitR = r; });
                if (!hitR) { U.showStatus("No region there", "#FF6060"); return true; }
                if (S.dirty && S.confirm !== hitR.id) { S.confirm = hitR.id; U.showStatus("Unsaved changes: click again to open " + hitR.id, "#FFD34D"); return true; }
                S.confirm = null;
                loadWork(hitR); S.mode = "points";
                U.showStatus("Editing " + hitR.id, "#7CFF7C");
                openMapKeep();
                return true;
            }
            var s = curShape();
            if (S.mode === "freehand") {
                if (!s || s.closed || s.points.length) startShape();
                curShape().points.push(px, pz);
                S.stroke = true; refresh();
                return true;
            }
            // points mode: grab a vertex of the current shape (shift: delete it)
            var vi = hitVertex(s, x, z);
            if (vi >= 0) {
                if (shift) { deleteVertex(vi); refresh(); return true; }
                if (s && !s.closed && vi === 0 && s.points.length >= 6) { closeCur(); refresh(); openMapKeep(); return true; }
                S.sel = vi; S.drag = { shape: S.cur, v: vi }; refresh();
                return true;
            }
            // another shape's vertex: switch to that shape
            for (var k = 0; k < S.work.shapes.length; k++) {
                if (k === S.cur) continue;
                var vk = hitVertex(S.work.shapes[k], x, z);
                if (vk >= 0) { S.cur = k; S.sel = vk; S.drag = { shape: k, v: vk }; refresh(); return true; }
            }
            if (s && s.closed) {
                var ei = hitEdge(s, x, z);
                if (ei >= 0) { s.points.splice((ei + 1) * 2, 0, px, pz); S.sel = ei + 1; S.drag = { shape: S.cur, v: ei + 1 }; changed(); refresh(); return true; }
                for (var k2 = 0; k2 < S.work.shapes.length; k2++) if (S.work.shapes[k2].closed && D.inPoly(S.work.shapes[k2].points, x, z)) { S.cur = k2; S.sel = -1; refresh(); return true; }
                S.sel = -1; refresh();
                U.showStatus("Shape is closed: drag points, click an edge to add one, or New shape", "#FFD34D");
                return true;
            }
            if (!s) startShape();
            s = curShape();
            s.points.push(px, pz); S.sel = (s.points.length >> 1) - 1; changed(); refresh();
            return true;
        }
        if (action === "drag") {
            S.hover = { x: px, z: pz, fx: x, fz: z };
            if (S.stroke) {
                var cs = curShape(), n = cs.points.length, step = Math.max(1, 3 / zoom());
                if (!n || Math.abs(cs.points[n - 2] - x) + Math.abs(cs.points[n - 1] - z) >= step) { cs.points.push(px, pz); refresh(); }
                return;
            }
            if (S.drag) {
                var ds = S.work.shapes[S.drag.shape];
                if (ds && ds.points[S.drag.v * 2] !== px || ds && ds.points[S.drag.v * 2 + 1] !== pz) { ds.points[S.drag.v * 2] = px; ds.points[S.drag.v * 2 + 1] = pz; changed(); refresh(); }
            }
            return;
        }
        if (action === "up") {
            S.drag = null;
            if (S.stroke) {
                S.stroke = false;
                var st = curShape();
                st.points = simplify(D.cleanPoints(st.points), Math.max(0.75, 1.5 / zoom()));
                if (st.points.length >= 6) { st.closed = true; changed(); U.showStatus("Freehand shape closed (" + (st.points.length >> 1) + " points, " + Math.round(D.area(st.points)) + " blocks²)", "#7CFF7C"); }
                else { S.work.shapes.splice(S.cur, 1); S.cur = S.work.shapes.length - 1; U.showStatus("Too short: hold left and draw around the area", "#FF6060"); }
                openMapKeep();
            }
        }
    }
    function openMapKeep() { saveView(); openMap(); }
    function setMode(m) { saveView(); S.mode = m; if (m !== "points") S.sel = -1; openMap(); }
    function act(fn) { return function () { saveView(); fn(); openMap(); }; }

    function openMap() {
        if (!S) return;
        S.where = "map";
        if (!S.view) { var p = RPG.player; S.view = { cx: p.x, cz: p.z, zoom: 1 }; }
        var els = [], b = UI.btn, y = MY + 18, half = (SW - 4) / 2, third = (SW - 8) / 3;
        els.push({ id: "map", type: "worldmap", anchor: "center", x: MX, y: MY, w: MW, h: MH, centerX: S.view.cx, centerZ: S.view.cz, zoom: S.view.zoom,
            minZoom: 0.03125, maxZoom: 16, panButton: 1, chunkGrid: S.grid, gridColor: "#30FFFFFF", labelZoom: 0.05, background: "#FF0A0A0A",
            polygons: polygons(), onMapMouse: onMapMouse });
        function mb(id, label, m, x) { els.push(b(id, x, y, third, 16, (S.mode === m ? "§e" : "§7") + label, function () { setMode(m); }, { tooltip: MODE_TIPS[m] })); }
        mb("m_pts", "Points", "points", SX); mb("m_free", "Freehand", "freehand", SX + third + 4); mb("m_sel", "Select", "select", SX + 2 * (third + 4));
        y += 19;
        var cs = curShape();
        els.push(b("close", SX, y, half, 16, "Close shape", act(closeCur), { tooltip: "Join the last point to the first (or click the first point)" }));
        els.push(b("undo", SX + half + 4, y, half, 16, "Undo point", act(function () {
            var s = curShape();
            if (!s || !s.points.length) return;
            if (s.closed) s.closed = false; else s.points.splice(s.points.length - 2, 2);
            if (!s.points.length) { S.work.shapes.splice(S.cur, 1); S.cur = S.work.shapes.length - 1; }
            S.sel = -1; changed();
        }), { tooltip: "Reopen a closed shape, or remove the last point" }));
        y += 19;
        els.push(b("newshape", SX, y, half, 16, "New shape", act(function () { var s = curShape(); if (s && !s.closed) closeCur(); startShape(); S.mode = S.mode === "select" ? "points" : S.mode; }), { tooltip: "Start another area in this region (regions can have several shapes)" }));
        els.push(b("delshape", SX + half + 4, y, half, 16, S.confirm === "shape" ? "§c§lSure?" : "§cDelete shape", act(function () {
            if (S.cur < 0) return;
            if (S.confirm !== "shape") { S.confirm = "shape"; return; }
            S.confirm = null; S.work.shapes.splice(S.cur, 1); S.cur = S.work.shapes.length - 1; S.sel = -1; changed();
        }), { tooltip: "Remove the current shape" }));
        y += 19;
        var nsh = S.work.shapes.length;
        els.push(b("prev", SX, y, 20, 16, "◀", act(function () { if (nsh) { S.cur = (S.cur - 1 + nsh) % nsh; S.sel = -1; } })));
        els.push({ id: "shapelbl", type: "text", anchor: "center", x: SX + SW / 2, y: y + 4, text: shapeLabel(), align: "center", font: FONT, color: "#FFFFFF", outline: "#000000" });
        els.push(b("next", SX + SW - 20, y, 20, 16, "▶", act(function () { if (nsh) { S.cur = (S.cur + 1) % nsh; S.sel = -1; } })));
        y += 19;
        els.push(b("delpt", SX, y, half, 16, "Delete point", act(function () { deleteVertex(S.sel); }), { tooltip: "Delete the selected point (or shift+click a point, or press Delete)" }));
        els.push(b("center", SX + half + 4, y, half, 16, "Center", function () { saveView(); var p = RPG.player; S.view.cx = p.x; S.view.cz = p.z; openMap(); }, { tooltip: "Center the map on yourself" }));
        y += 19;
        els.push(b("others", SX, y, half, 16, S.others ? "§aRegions: on" : "§7Regions: off", act(function () { S.others = !S.others; }), { tooltip: "Show the other NPC regions of this dimension" }));
        els.push(b("grid", SX + half + 4, y, half, 16, S.grid ? "§aChunks: on" : "§7Chunks: off", act(function () { S.grid = !S.grid; }), { tooltip: "Chunk borders" }));
        y += 19;
        els.push(b("fit", SX, y, half, 16, "Fit region", act(function () { fitTo(S.work); }), { tooltip: "Zoom to this region's shapes" }));
        els.push(b("newreg", SX + half + 4, y, half, 16, S.confirm === "new" ? "§c§lDiscard?" : "New region", act(function () {
            if (S.dirty && S.confirm !== "new") { S.confirm = "new"; return; }
            S.confirm = null; loadWork(newRegion(S.dim)); S.oldId = "";
        }), { tooltip: "Start a new region (unsaved changes are lost)" }));
        y += 23;
        els.push(b("define", SX, y, SW, 18, "§6Define region…", function () { saveView(); regionForm(0); }, { tooltip: "Name, Y band, display, TP falloff and the NPCs that spawn here" }));
        y += 21;
        els.push(b("save", SX, y, half, 18, "§aSave", function () { saveView(); save(); }));
        els.push(b("list", SX + half + 4, y, half, 18, "Regions…", function () { saveView(); regionList(); }));
        els.push(b("closebtn", SX + SW - 60, MY + MH - 18, 60, 18, "Close", function () { RPG.screen.close(); }));
        RPG.screen.open({ id: MAP_SCREEN, referenceHeight: 340, background: "dim", elements: els, onBackground: renderMap, onRender: renderMapTop,
            onKey: function (k, a) {
                if (a !== "down" || !S) return;
                if (k === "key.keyboard.delete" || k === "key.keyboard.backspace") { saveView(); deleteVertex(S.sel); openMap(); return false; }
                if (k === "key.keyboard.enter" || k === "key.keyboard.c") { saveView(); closeCur(); openMap(); return false; }
                if (k === "key.keyboard.z") { saveView(); var s = curShape(); if (s && !s.closed && s.points.length) { s.points.splice(s.points.length - 2, 2); changed(); } openMap(); return false; }
            },
            onClose: function () { } });
    }
    var MODE_TIPS = {
        points: "Left click: add a point. Click the first point (or Enter) to close. Drag a point to move it, shift+click or Delete removes it, click an edge to insert one. Right drag pans, wheel zooms.",
        freehand: "Hold left and draw around the area; release to close it (smoothed). Right drag pans.",
        select: "Click inside another region to edit it."
    };
    function renderMap(ctx) {
        if (!S) return;
        var cx = ctx.width / 2, cy = ctx.height / 2;
        UI.panel(ctx, cx - 300, cy - 166, 600, 332);
        UI.title(ctx, cx, cy - 166 + 4, "NPC Region: " + (S.work.name ? U.strip(S.work.name) : "§7(new)") + (S.dirty ? " §c*" : ""));
        ctx.fill(cx + MX - 1, cy + MY - 1, MW + 2, MH + 2, "#000000", 0.8);
    }
    function renderMapTop(ctx) {
        if (!S) return;
        var cx = ctx.width / 2, cy = ctx.height / 2, x = cx + SX, y = cy + MY + 2;
        U.bordered(ctx, "§7" + S.work.dim.replace("minecraft:", "") + (S.work.dim !== S.dim ? " §c(you're in " + S.dim.replace("minecraft:", "") + ")" : ""), x, y, "#FFFFFF", 0);
        var ly = cy + MY + 220, s = curShape(), tot = 0;
        S.work.shapes.forEach(function (sh) { if (sh.closed) tot += D.area(sh.points); });
        var lines = [
            "§7Points: §f" + (s ? s.points.length >> 1 : 0) + (s ? (s.closed ? " §a(closed)" : " §e(open)") : ""),
            "§7Area: §f" + Math.round(tot) + " blocks²  §7NPCs: §f" + S.work.npcs.length,
            S.hover ? "§7Cursor: §f" + S.hover.x + ", " + S.hover.z : "§7Right drag pans · wheel zooms"
        ];
        lines.forEach(function (l, i) { U.bordered(ctx, l, x, ly + i * 10, "#FFFFFF", 0); });
        U.drawStatus(ctx, cx + MX + MW / 2, cy + MY + MH + 6);
    }

    // =========================================================================================
    //  Form engine (the raid editor's): a panel, optional tabs, a scrolled list of rows, footer buttons
    // =========================================================================================
    var PW = 380, PH = 290, ROW = 18, LX = -180, CX = -24, CW = 196;
    var F = null;
    function form(spec) {
        S.where = "form";
        F = { title: spec.title, tabs: spec.tabs || null, tab: spec.tab || 0, rows: spec.rows, scroll: 0, footer: spec.footer || [] };
        show();
    }
    function curRows() {
        var out = [];
        (F.tabs ? F.tabs[F.tab].rows() : F.rows()).forEach(function (r) {
            out.push(r);
            if (r && r.type === "note") for (var k = Math.ceil(U.strip(r.text).length / 62) - 1; k > 0; k--) out.push({ type: "spacer" });
        });
        return out;
    }
    function top() { return F.tabs ? (F.tabs.length > 5 ? -86 : -102) : -110; }
    function visible() { return Math.floor((PH / 2 - 34 - top()) / ROW); }
    function show() {
        if (!F) return;
        SUG_IDS = {};
        var mine = F, els = [], rows = curRows(), vis = visible();
        F.scroll = Math.max(0, Math.min(F.scroll, Math.max(0, rows.length - vis)));
        if (F.tabs) F.tabs.forEach(function (t, i) {
            var perRow = Math.min(6, F.tabs.length), w = Math.floor((PW - 24) / perRow), r = Math.floor(i / 6), c = i % 6;
            els.push(UI.btn("tab" + i, -PW / 2 + 12 + c * w, -118 + r * 16, w - 2, 15, (i === F.tab ? "§e" : "") + t.name, function () { F.tab = i; F.scroll = 0; show(); }));
        });
        var y = top();
        for (var i = 0; i < vis && i + F.scroll < rows.length; i++, y += ROW) rowEls(els, rows[i + F.scroll], i + F.scroll, y);
        if (rows.length > vis) {
            els.push(UI.btn("up", PW / 2 - 18, top(), 12, 12, "▲", function () { F.scroll = Math.max(0, F.scroll - vis + 1); show(); }));
            els.push(UI.btn("down", PW / 2 - 18, top() + vis * ROW - 14, 12, 12, "▼", function () { F.scroll += vis - 1; show(); }));
        }
        var fw = Math.min(110, Math.floor((PW - 24) / Math.max(1, F.footer.length)) - 4), fx = -(F.footer.length * (fw + 4)) / 2;
        F.footer.forEach(function (b, j) { els.push(UI.btn("ft" + j, fx + j * (fw + 4), PH / 2 - 26, fw, 18, b.label, b.run, b.extra)); });
        F.rebuilding = true;
        RPG.screen.open({ id: FORM_SCREEN, referenceHeight: 340, background: "dim", elements: els, onBackground: render,
            onScroll: function (x, yy, d) { if (F !== mine) return; var n = curRows().length, v = visible(); if (n <= v) return; F.scroll = Math.max(0, Math.min(n - v, F.scroll - (d > 0 ? 1 : -1))); show(); },
            onClose: function () { if (F === mine && !F.rebuilding) F = null; } });
        F.rebuilding = false;
    }
    function render(ctx) {
        if (!F) return;
        var cx = ctx.width / 2, cy = ctx.height / 2;
        UI.panel(ctx, cx - PW / 2, cy - PH / 2, PW, PH);
        UI.title(ctx, cx, cy - PH / 2 + 4, F.title);
        var rows = curRows(), vis = visible(), y = cy + top();
        for (var i = 0; i < vis && i + F.scroll < rows.length; i++, y += ROW) {
            var r = rows[i + F.scroll];
            if (r.type === "text" || r.type === "int" || r.type === "num" || r.type === "anchor") field(ctx, cx + CX - 2, y, CW + 4, 16);
        }
        U.drawStatus(ctx, cx, cy + PH / 2 - 40);
    }
    function field(ctx, x, y, w, h) {
        var BUTTONS = UI.BUTTONS;
        function f(sx, sy, sw, sh, dx, dy, dw, dh) { ctx.quad(BUTTONS, dx, dy, dw, dh, sx / 256, sy / 256, (sx + sw) / 256, (sy + sh) / 256, "#FFFFFF", 1); }
        var v = 108;
        f(0, v, 3, 3, x, y, 3, 3); f(3, v, 101, 3, x + 3, y, w - 6, 3); f(104, v, 3, 3, x + w - 3, y, 3, 3);
        f(0, v + 3, 3, 11, x, y + 3, 3, h - 7); f(3, v + 3, 101, 11, x + 3, y + 3, w - 6, h - 7); f(104, v + 3, 3, 11, x + w - 3, y + 3, 3, h - 7);
        f(0, v + 14, 3, 4, x, y + h - 4, 3, 4); f(3, v + 14, 101, 4, x + 3, y + h - 4, w - 6, 4); f(104, v + 14, 3, 4, x + w - 3, y + h - 4, 3, 4);
    }
    function label(els, id, text, x, y, tip, w) {
        var e = { id: id, type: "text", anchor: "center", x: x, y: y, text: text, font: FONT, color: "#FFFFFF", outline: "#000000" };
        if (tip) e.tooltip = tip;
        if (w) e.wrap = w;
        els.push(e);
    }
    function cut(s, n) {
        s = String(s || "");
        var out = "", vis = 0;
        for (var i = 0; i < s.length; i++) {
            var c = s.charAt(i);
            if (c === "§" && i + 1 < s.length) { out += c + s.charAt(i + 1); i++; continue; }
            if (vis >= n) return out + "…";
            out += c; vis++;
        }
        return out;
    }
    function str(v) { return v === undefined || v === null ? "" : String(v); }
    function numStr(v) { var n = Number(v) || 0; return n === Math.round(n) ? String(Math.round(n)) : String(Math.round(n * 1000) / 1000); }
    /** Row types: text int num bool enum pick anchor button note item spacer. */
    function rowEls(els, r, idx, y) {
        var id = "r" + idx;
        if (r.type === "spacer") return;
        if (r.type === "note") { label(els, id, "§7" + r.text, LX, y + 4, null, PW - 30); return; }
        if (r.type === "button") { els.push(UI.btn(id, LX + 10, y, PW - 44, 16, r.label, r.run, { tooltip: r.tip, disabled: !!r.disabled })); return; }
        if (r.type === "item") {
            var nx = (r.extra || []).length, room = nx ? 40 + Math.max(0, 4 - nx) * 6 : r.edit || r.del ? 44 : 60;
            label(els, id + "l", cut(r.text, room), LX, y + 4, r.tip || (U.strip(r.text).length > room ? r.text : null), 0);
            var bx = PW / 2 - 24 - 92;
            if (r.edit) els.push(UI.btn(id + "e", bx, y, 36, 16, "Edit", r.edit));
            if (r.up) els.push(UI.btn(id + "u", bx + 38, y, 16, 16, "▲", r.up));
            if (r.down) els.push(UI.btn(id + "d", bx + 56, y, 16, 16, "▼", r.down));
            if (r.del) els.push(UI.btn(id + "x", bx + 74, y, 16, 16, "§cX", r.del, { tooltip: "Delete" }));
            (r.extra || []).forEach(function (b, k) { els.push(UI.btn(id + "b" + k, PW / 2 - 24 - (nx - k) * 48, y, 46, 16, b.label, b.run, { tooltip: b.tip })); });
            return;
        }
        label(els, id + "l", r.label, LX, y + 4, r.tip, 0);
        if (r.type === "bool") {
            els.push(UI.btn(id, CX, y, 70, 16, r.get() ? "§a[x] ON" : "§7[ ] OFF", function () {
                r.set(!r.get()); RPG.sound(r.get() ? "dmzpack:switch_on" : "dmzpack:switch_off", 1, 1);
                if (r.rebuild) show(); else RPG.screen.update(id, { label: r.get() ? "§a[x] ON" : "§7[ ] OFF" });
            }, { tooltip: r.tip }));
        } else if (r.type === "enum") {
            els.push(U.dropdown(id, CX - 2, y, CW + 4, 16, r.options.map(function (o, i) { return { value: o.v !== undefined ? o.v : i, label: o.l !== undefined ? o.l : o }; }), r.get(), function (v) {
                r.set(v); RPG.sound("dmzpack:pip_menu", 1, 1);
                if (r.rebuild) show();
            }, { tooltip: r.tip }));
        } else if (r.type === "pick") {
            els.push(U.dropdown(id, CX - 2, y, CW + 4, 16, suggestions(r.kind, id), str(r.get()), function (v) { r.set(String(v)); if (r.rebuild) show(); },
                { tooltip: r.tip, search: true, custom: true, placeholder: "§7(none)", listWidth: 260 }));
        } else if (r.type === "anchor") {
            // a max-level anchor: shows its effective value; left as shown stays auto, a number pins it, "auto" un-pins
            var shown = numStr(r.get()), auto = r.isAuto();
            els.push({ id: id, type: "input", anchor: "center", x: CX + 2, y: y + 3, w: CW - 40, h: 10, value: shown, maxLength: 24, tooltip: r.tip,
                onChange: function (e, v) {
                    var t = String(v).trim();
                    if (t === "" || t.toLowerCase() === "auto") r.set(null);
                    else if (t !== shown) { var m = Number(t); if (!isNaN(m)) r.set(Math.max(0, m)); }
                } });
            label(els, id + "a", auto ? "§7auto" : "§epinned", CX + CW - 34, y + 4, auto ? "Follows the level 1 value (x" + D.DEFAULT_MULTIPLE + ")" : "Type auto to follow the level 1 value again", 0);
        } else {
            els.push({ id: id, type: "input", anchor: "center", x: CX + 2, y: y + 3, w: CW - 4, h: 10, value: r.type === "int" || r.type === "num" ? numStr(r.get()) : str(r.get()), maxLength: r.max || 256,
                tooltip: r.tip, onChange: function (e, v) {
                    if (r.type === "int") { var n = parseInt(v, 10); if (!isNaN(n)) r.set(r.min !== undefined ? Math.max(r.min, n) : n); }
                    else if (r.type === "num") { var m = Number(v); if (String(v).trim() !== "" && !isNaN(m)) r.set(r.min !== undefined ? Math.max(r.min, m) : m); }
                    else r.set(String(v));
                } });
        }
    }
    function T(type, lbl, tip, get, set, more) { var r = { type: type, label: lbl, tip: tip, get: get, set: set }; for (var k in more || {}) r[k] = more[k]; return r; }
    function fld(obj, key, type, lbl, tip, more) { return T(type, lbl, tip, function () { return obj[key]; }, function (v) { obj[key] = v; changed(); }, more); }
    function note(text) { return { type: "note", text: text }; }
    function button(lbl, run, tip) { return { type: "button", label: lbl, run: run, tip: tip }; }
    function anchor(c, key, lbl, tip) {
        return T("anchor", lbl, tip, function () { return D.atMax(c, key); }, function (v) { c[key + "AtMax"] = v; changed(); }, { isAuto: function () { return c[key + "AtMax"] === null || c[key + "AtMax"] === undefined; } });
    }

    // ---- pick lists, filled by the server once per kind ----
    var SUG = {}, SUG_WANTED = {}, SUG_IDS = {};
    function sugOptions(kind) {
        var list = SUG[kind] || [], out = [{ value: "", label: "§7(none)" }];
        list.forEach(function (o) { out.push({ value: o.id, label: o.label && o.label !== o.id ? "§f" + o.label + " §8" + o.id : "§f" + o.id }); });
        return out;
    }
    function suggestions(kind, elId) {
        (SUG_IDS[kind] = SUG_IDS[kind] || []).push(elId);
        if (!SUG[kind] && !SUG_WANTED[kind]) { SUG_WANTED[kind] = true; send("suggest", { kind: kind }); }
        return sugOptions(kind);
    }
    RPG.net.on("dbr_npcr_suggestions", function (d) {
        if (!d || !d.kind) return;
        SUG[d.kind] = d.list || []; SUG_WANTED[d.kind] = false;
        var ids = SUG_IDS[d.kind] || [], opts = sugOptions(d.kind);
        if (RPG.screen.getOpen() === FORM_SCREEN) ids.forEach(function (id) { if (RPG.screen.get(id)) RPG.screen.update(id, { options: opts }); });
    });

    // =========================================================================================
    //  Region list (NpcRegionListScreen)
    // =========================================================================================
    var CONFIRM = null;
    function regionList() {
        S.where = "list";
        form({ title: "NPC Regions (" + S.regions.length + ")", rows: function () {
            var rows = [note("Edit opens a region on the map. New: draw on the map, then Define region and Save. Import reads DMZ Ragnarok's npcregions.json from ragnarok_rpg/config/dbr_npcregion_import.json.")];
            S.regions.forEach(function (r) {
                rows.push({ type: "item", text: "§f" + U.strip(r.title || r.name) + " §7(" + r.id + ")" + (r.enabled ? "" : " §c[off]") + (r.eventOnly ? " §d[event]" : ""),
                    tip: { title: r.name, lines: ["§7" + r.dim, "§7" + D.regionArea(r) + " blocks², " + r.shapes.length + " shape(s)", "§7" + r.npcs.length + " NPC(s), " + (S.alive[r.id] || 0) + " alive"] },
                    extra: [{ label: "Edit", run: function () { loadWork(r); fitTo(r); if (r.dim !== S.dim) U.showStatus("That region is in " + r.dim, "#FFD34D"); openMap(); } },
                        { label: "TP", run: function () { send("tp", { id: r.id }); RPG.screen.close(); }, tip: "Teleport into the region" },
                        { label: "Clear", run: function () { send("clear", { id: r.id }); }, tip: "Remove its live NPCs (they respawn)" },
                        { label: CONFIRM === r.id ? "§c§lSure?" : "§cDelete", run: function () { if (CONFIRM === r.id) { CONFIRM = null; send("delete", { id: r.id }); } else { CONFIRM = r.id; show(); } } }] });
            });
            if (!S.regions.length) rows.push(note("No regions yet."));
            return rows;
        }, footer: [{ label: "New region", run: function () { loadWork(newRegion(S.dim)); S.oldId = ""; openMap(); } },
            { label: "Import", run: function () { send("import"); } },
            { label: "Map", run: openMap }, { label: "Close", run: function () { RPG.screen.close(); } }] });
    }

    // =========================================================================================
    //  Region form (NpcRegionEditScreen + NpcRegionDisplayScreen)
    // =========================================================================================
    var CLIP = null;
    function regionForm(tab) {
        var r = S.work;
        var tabs = [
            { name: "General", rows: function () {
                return [fld(r, "name", "text", "Name", "The region's internal name; its id (for commands) is made from it. Required."),
                    note("Dimension: §f" + r.dim + "§7 · " + r.shapes.filter(function (s) { return s.closed; }).length + " closed shape(s), " + Math.round(r.shapes.reduce(function (a, s) { return a + (s.closed ? D.area(s.points) : 0); }, 0)) + " blocks²"),
                    fld(r, "minY", "int", "Min Y", "Bottom of the spawn band. The horizontal footprint is the shapes drawn on the map."),
                    fld(r, "maxY", "int", "Max Y", "Top of the spawn band. Narrow it to confine spawns to a floor or a cave layer."),
                    fld(r, "enabled", "bool", "Enabled", "Off: the region keeps its settings but spawns nothing."),
                    fld(r, "eventOnly", "bool", "Event Only", "If ON, this region runs only while a timed event owns it, and is otherwise dark. Normal regions leave this OFF."),
                    fld(r, "tpFalloffLevel", "int", "TP Falloff Level", "Killer DMZ level above which kills in this region give less TP. 0 = falloff off. Does not apply to NPCs that scale with level (on by default), only to ones with scaling turned off and to other mobs here.", { min: 0 }),
                    fld(r, "tpFalloffRange", "int", "TP Falloff Range", "Levels over which TP falls linearly from full down to a 20% floor.", { min: 1 })];
            } },
            { name: "Display", rows: function () {
                return [note("Player-facing display options"),
                    fld(r, "title", "text", "Title", "Player-facing region title (supports & colour codes). Blank uses the region's internal name."),
                    fld(r, "difficulty", "text", "Difficulty", "Free-form difficulty label shown on the region HUD, e.g. Easy, &6Hard, &cDeadly."),
                    fld(r, "description", "text", "Description", "Short description shown on the region HUD under the title (supports & colour codes)."),
                    fld(r, "showTitle", "bool", "Show Entry Title", "Show the title on screen when a player enters the region."),
                    fld(r, "showHud", "bool", "Show Region HUD", "Show the region HUD (title/difficulty/description) while a player is inside. Players move it in the HUD editor."),
                    fld(r, "color", "text", "Map Color", "This region's fill colour on the world map (#RRGGBB). Blank uses the default faint green.", { max: 7 })];
            } },
            { name: "NPCs (" + r.npcs.length + ")", rows: function () {
                var rows = [note("NPCs in this region (" + r.npcs.length + "). Each spawns up to its amount per nearby player and refills every cooldown.")];
                r.npcs.forEach(function (c, i) {
                    rows.push({ type: "item", text: "§f#" + (i + 1) + " §7" + npcLabel(c), tip: c.entityTypeId,
                        edit: function () { npcForm(c, i, 0); },
                        up: i > 0 ? function () { r.npcs.splice(i - 1, 0, r.npcs.splice(i, 1)[0]); changed(); show(); } : null,
                        down: i < r.npcs.length - 1 ? function () { r.npcs.splice(i + 1, 0, r.npcs.splice(i, 1)[0]); changed(); show(); } : null,
                        del: function () { r.npcs.splice(i, 1); changed(); regionForm(2); } });
                });
                rows.push(button("+ Add NPC", function () { r.npcs.push(D.npc({})); changed(); npcForm(r.npcs[r.npcs.length - 1], r.npcs.length - 1, 0); }),
                    button("Copy NPCs", function () { CLIP = JSON.parse(JSON.stringify(r.npcs)); U.showStatus("Copied " + CLIP.length + " NPC(s) to clipboard.", "#7CFF7C"); }),
                    button("Paste NPCs", function () {
                        if (!CLIP) { U.showStatus("Nothing copied yet. Use Copy NPCs on another region first.", "#FF6060"); return; }
                        CLIP.forEach(function (c) { r.npcs.push(D.npc(JSON.parse(JSON.stringify(c)))); });
                        changed(); U.showStatus("Pasted " + CLIP.length + " NPC(s). Press Save to apply.", "#7CFF7C"); regionForm(2);
                    }));
                return rows;
            } }
        ];
        form({ title: "NPC Region: " + (r.name ? U.strip(r.name) : "(new)"), tabs: tabs, tab: tab || 0,
            footer: [{ label: "§aSave", run: function () { save(); } }, { label: "Map", run: openMap }, { label: "Regions…", run: regionList }] });
    }
    function npcLabel(c) {
        var e = c.entityTypeId, m = c.rgModelId || (e.indexOf("rgnpc#") === 0 ? e.substring(6) : "");
        var name = c.displayName ? U.strip(c.displayName) : (m ? m : e.replace(/^[a-z_]+:/, ""));
        return name + " §8x" + c.maxSpawns + " /" + Math.round(c.cooldownTicks / 20) + "s · " + D.BEHAVIORS[c.behavior];
    }

    // =========================================================================================
    //  NPC form (NpcConfigEditScreen)
    // =========================================================================================
    function npcForm(c, idx, tab) {
        var anchorTip = "This stat at the max level (the Rewards tab sets the max level); the field above is the level 1 value. A new NPC is scaled for the lowest DMZ level among the players near it, and raised to a stronger player's level when that player hits it. Leave it as shown for automatic (" + D.DEFAULT_MULTIPLE + "x the level 1 value), type a number to pin it, or type auto.";
        var rewardTip = "Value at the max level. Leave it as shown to keep it automatic (" + D.DEFAULT_MULTIPLE + "x the level 1 value, following it when that changes), type a number to pin it, or type auto to go back to automatic.";
        var tabs = [
            { name: "General", rows: function () {
                return [fld(c, "entityTypeId", "pick", "Entity", "Which entity this NPC spawns. Searchable list of every registered entity type (DMZ, this game's mobs, vanilla, mods). Every ragnarok NPC character is in this list too, as its own row (rgnpc#name): type a character's name to find it.", { kind: "entity" }),
                    fld(c, "rgModelId", "pick", "Ragnarok NPC", "Which ragnarok NPC character it looks like, when the entity above is dmz_ragnarok:rgnpc (or the DMZ fighter). Leave it blank for any other entity. Not the same as Model ID.", { kind: "rgmodel" }),
                    fld(c, "displayName", "text", "Display Name", "Custom name shown above the spawned entity's head. Leave blank for the entity's default name."),
                    fld(c, "modelId", "text", "Model ID (sdu NPC)", "Kept from DMZ Ragnarok's sdu NPCs (a CustomNPCs model key). Saved with the region; unused by Dragon Block Ragnarok's bodies.")];
            } },
            { name: "Stats", rows: function () {
                var rows = [fld(c, "maxHealth", "num", "Max Health", "Overrides the entity's max health attribute.", { min: 1 }),
                    fld(c, "attackDamage", "num", "Melee Damage", "Overrides the entity's attack damage attribute.", { min: 0 }),
                    fld(c, "moveSpeed", "num", "Speed", "Overrides the entity's movement speed attribute.", { min: 0 }),
                    fld(c, "defense", "num", "Defense", "DMZ defense scale (not armor points): incoming damage is cut by defense / (defense + 100), at most 88%.", { min: 0 }),
                    fld(c, "scale", "num", "Scale", "Render/hitbox scale multiplier. 1 = normal size.", { min: 0.05 }),
                    fld(c, "aggroRange", "num", "Aggro Range", "How close (in blocks) a player must get before this NPC notices and targets them. Default 4.", { min: 0 })];
                if (D.scales(c)) rows.push(anchor(c, "maxHealth", "Max Health at max level", anchorTip), anchor(c, "attackDamage", "Melee Damage at max level", anchorTip), anchor(c, "defense", "Defense at max level", anchorTip));
                return rows;
            } },
            { name: "Ki", rows: function () {
                var rows = [fld(c, "kiPower", "num", "Ki Power", "Ki power used by the entity's ki attacks (DMZ saga enemies).", { min: 0 })];
                if (D.scales(c)) rows.push(anchor(c, "kiPower", "Ki Power at max level", anchorTip));
                rows.push(T("enum", "Moveset", "Which DMZ fighter's ki attacks this NPC uses (sdu NPCs; saved for DMZ Ragnarok, a DMZ saga enemy keeps its own kit).", function () { return c.moveset; }, function (v) { c.moveset = Number(v); changed(); }, { options: D.MOVESETS }),
                    T("enum", "AI Tier", "Combat smarts: teleport/dodge/block frequency. Simple keeps an ordinary region mob grounded (no flight, teleports or dashes).", function () { return c.aiTier; }, function (v) { c.aiTier = Number(v); changed(); }, { options: D.AI_TIERS }),
                    fld(c, "kiEnabled", "bool", "Ki Attacks", "Enable ki attacks from the moveset. Off = melee only."),
                    T("enum", "Behavior", "How the entity behaves toward players. Passive / Wander / Dialogue / Follower never attack unless provoked (attacking one provokes its regionmates nearby). Guard, Hostile and DMZ Fighter attack players inside the aggro range.", function () { return c.behavior; }, function (v) { c.behavior = Number(v); changed(); }, { options: D.BEHAVIORS }));
                return rows;
            } },
            { name: "Spawn", rows: function () {
                return [fld(c, "maxSpawns", "int", "Spawn Amount (per player)", "How many of THIS NPC to keep alive PER nearby player (they only spawn near players). e.g. 6 with 3 players nearby = up to 18 alive. Each NPC has its own cap.", { min: 1 }),
                    fld(c, "cooldownTicks", "int", "Cooldown (ticks)", "Ticks between spawn waves that refill up to the spawn amount (20 ticks = 1 second).", { min: 1 }),
                    note("Spawns land on real ground inside the region's shapes and Y band, near players: never in water, and on a canopy or a roof only when no ground was found.")];
            } },
            { name: "Rewards", rows: function () {
                var rows = [fld(c, "tpMin", "int", "TP Min", "Lowest DMZ Training Points granted to the player who kills this NPC.", { min: 0 }),
                    fld(c, "tpMax", "int", "TP Max", "Highest DMZ Training Points per kill. A random amount in [Min, Max] is granted. Set both equal for a fixed amount.", { min: 0 }),
                    fld(c, "balMin", "int", "Balance Min", "Lowest zeni granted to the player who kills this NPC.", { min: 0 }),
                    fld(c, "balMax", "int", "Balance Max", "Highest zeni per kill. A random amount in [Min, Max] is granted. Set both equal for a fixed amount.", { min: 0 }),
                    fld(c, "killCommands", "text", "Kill Commands", "Console commands run when a player kills this NPC. Separate several with ; and use %player% for the killer's name, e.g. give %player% minecraft:diamond 3; xp add %player% 10 levels", { max: 1000 }),
                    T("bool", "Scale with level", "On: this NPC's TP and balance (and its stats) follow the player's DMZ level in a straight line, from the level 1 values in the fields above to the max-level values below. A max-level value left on auto is " + D.DEFAULT_MULTIPLE + "x the level 1 value. The region's level falloff does not apply to this NPC.",
                        function () { return D.scales(c); }, function (v) { c.levelScaling = v ? null : false; changed(); }, { rebuild: true })];
                if (D.scales(c)) {
                    rows.push(T("int", "Max level", "The DMZ level at which the max-level values apply. Levels above it get the max-level values.", function () { return D.maxLevel(c); },
                        function (v) { c.scaleMaxLevel = Math.max(2, v) === D.DEFAULT_MAX_LEVEL ? null : Math.max(2, v); changed(); }),
                        anchor(c, "tpMin", "TP Min at max level", rewardTip), anchor(c, "tpMax", "TP Max at max level", rewardTip),
                        anchor(c, "balMin", "Balance Min at max level", rewardTip), anchor(c, "balMax", "Balance Max at max level", rewardTip));
                }
                return rows;
            } },
            { name: "Drops (" + c.drops.length + ")", rows: function () {
                var rows = [fld(c, "vanillaDrops", "bool", "Vanilla Drops", "Whether the entity's own loot-table drops still appear on death. OFF (default) = only the custom drops below drop.")];
                c.drops.forEach(function (d, i) {
                    rows.push({ type: "item", text: (d.nbt ? "§d◆ " : "") + "§f" + d.itemId + " §7x" + d.minCount + (d.maxCount !== d.minCount ? "-" + d.maxCount : "") + " §e" + numStr(d.chance) + "%",
                        tip: d.nbt ? "Carries copied NBT data (enchants/names/modded tags)." : null,
                        edit: function () { dropForm(c, idx, d); }, del: function () { c.drops.splice(i, 1); changed(); npcForm(c, idx, 5); } });
                });
                rows.push(button("+ Add Drop", function () { var d = D.drop({}); c.drops.push(d); changed(); dropForm(c, idx, d); }),
                    button("+ Held Item (with NBT)", function () { HELD_TO = { c: c, idx: idx }; send("held"); }, "Adds the item you are holding as a drop, copying its full NBT data (enchantments, custom names, modded tags)."));
                return rows;
            } }
        ];
        form({ title: "NPC #" + (idx + 1) + " §7(" + c.entityTypeId + ")", tabs: tabs, tab: tab || 0,
            footer: [{ label: "§aDone", run: function () { regionForm(2); } }] });
    }
    var HELD_TO = null;
    RPG.net.on("dbr_npcr_held", function (d) {
        if (!d || !HELD_TO) return;
        var c = HELD_TO.c, idx = HELD_TO.idx;
        HELD_TO = null;
        c.drops.push(D.drop({ itemId: d.itemId, minCount: d.count || 1, maxCount: d.count || 1, chance: 100, nbt: d.nbt || "" }));
        changed(); npcForm(c, idx, 5);
    });
    function dropForm(c, idx, d) {
        form({ title: "Custom Drop", rows: function () {
            return [fld(d, "itemId", "pick", "Item", "Item id to drop, e.g. minecraft:diamond. Searchable; any id can be typed.", { kind: "item" }),
                fld(d, "minCount", "int", "Min", "Fewest dropped.", { min: 0 }),
                fld(d, "maxCount", "int", "Max", "Most dropped.", { min: 0 }),
                fld(d, "chance", "num", "Chance %", "Roll chance (0-100), rolled on its own for each kill.", { min: 0 }),
                fld(d, "nbt", "text", "NBT", "Optional SNBT on the dropped stack (enchantments, names, modded data).", { max: 4000 })];
        }, footer: [{ label: "§aDone", run: function () { d.chance = Math.max(0, Math.min(100, Number(d.chance) || 0)); npcForm(c, idx, 5); } }] });
    }

    // =========================================================================================
    //  Region HUD + entry (every player)
    // =========================================================================================
    RPG.net.on("dbr_npcr_here", function (d) {
        if (!d || !d.id || !d.hud) { RPG.hud.remove("dbr_npcr_hud"); RPG.hud.remove("dbr_npcr_hud2"); return; }
        RPG.hud.set("dbr_npcr_hud", { type: "text", anchor: "topleft", x: 6, y: 128, text: "§6" + d.title + (d.difficulty ? " §7[" + d.difficulty + "§7]" : ""), color: "#FFFFFF", shadow: true, movable: true, label: "NPC region" });
        if (d.description) RPG.hud.set("dbr_npcr_hud2", { type: "text", anchor: "topleft", x: 6, y: 139, text: "§7" + d.description, color: "#FFFFFF", shadow: true, scale: 0.85, movable: true, label: "NPC region description" });
        else RPG.hud.remove("dbr_npcr_hud2");
    });
})();
