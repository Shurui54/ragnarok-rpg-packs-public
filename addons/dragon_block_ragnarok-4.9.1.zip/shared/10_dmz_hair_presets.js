// =====================================================================================
//  DragonMine Z hair presets (HairPresets.java, GPL-3.0 - see NOTICE.md): ids, names and which
//  SSJ4 style a preset falls back to. The styles themselves (DMZ's preset codes, decoded with
//  DMZ_HAIR.decodePreset) are in client/data/dmz_hair_presets/<id>.json - only clients draw hair.
//  Generated from DMZ's codes; 5 (Krillin) is DMZ's bald preset.
// =====================================================================================
var DMZ_HAIR_PRESETS = {
    order: [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28],
    names: {
        1: "Goku",
        2: "Vegeta",
        3: "Trunks",
        4: "Gohan",
        5: "Krillin",
        6: "Trunks (Large)",
        7: "Gohan DBS",
        8: "Raditz",
        9: "Patreon (__Travis__)",
        10: "Goku [Heroes of Eden]",
        11: "Vegeta [Heroes of Eden]",
        12: "Trunks [Heroes of Eden]",
        13: "Gohan [Heroes of Eden]",
        14: "Adult Gohan [Heroes of Eden]",
        15: "Future Gohan [Heroes of Eden]",
        16: "Goten GT [Heroes of Eden]",
        17: "Goten Super [Heroes of Eden]",
        18: "Broly Z [Heroes of Eden]",
        19: "Broly Super [Heroes of Eden]",
        20: "Fasha [Heroes of Eden]",
        21: "Broly Super [Heroes of Eden]",
        22: "Kale [Heroes of Eden]",
        23: "Vegetto [Heroes of Eden]",
        24: "Caulifla",
        25: "Yamcha [Heroes of Eden]",
        26: "Android 21 [Chillir]",
        27: "Gojo Patreon (Re:Wheezer)",
        28: "Glind"
    },
    // HairPresets.registerSsj4: presets with their own SSJ4 style (the rest use DEFAULT_SSJ4_CODE)
    ssj4: {"3":"TRUNKS_SSJ4_CODE","4":"GOHAN_SSJ4_CODE","6":"TRUNKS_SSJ4_CODE","7":"GOHAN_SSJ4_CODE","12":"TRUNKS_SSJ4_CODE","14":"GOHAN_SSJ4_CODE"}
};
