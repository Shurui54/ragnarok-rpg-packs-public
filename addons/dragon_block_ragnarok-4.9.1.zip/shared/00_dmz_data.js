// =====================================================================================
//  DMZ data shared by server and client scripts (shared/ runs on both sides).
//  Values from DragonMine Z's defaults (ConfigManager.createDefaultStatsConfig and the
//  race configs); see docs in NOTICE.md.
// =====================================================================================
var DMZ_DATA = (function () {
    // DMZ race id -> our race id (and back)
    var RACES = ["human", "saiyan", "namekian", "frostdemon", "bioandroid", "majin", "glind"];
    var OUR = { human: "human", saiyan: "saiyan", namekian: "namekian", frostdemon: "frost_demon", bioandroid: "bio_android", majin: "majin", glind: "glind" };
    var DMZ = {};
    Object.keys(OUR).forEach(function (k) { DMZ[OUR[k]] = k; });

    // classes in DMZ's creator order: base stats, scaling, regen bases, TP multipliers, name colour
    var CLASSES = {
        warrior:       { color: "§c", base: { STR: 10, SKP: 0, RES: 5, VIT: 5, PWR: 0, ENE: 0 }, scaling: { STR: 1.4, SKP: 1.0, DEF: 0.24, DEF_max: 0.96, STM: 1.6, VIT: 1.8, VIT_max: 7.2, PWR: 0.5, ENE: 1.5 }, baseHp5: 1.75, hp5VitScaling: 0.06, baseEp5: 4.0, ep5EneScaling: 0.08, baseSp5: 12.0, sp5VitScaling: 0.045, sp5ResScaling: 0.06, tpGain: 1.0, tpCost: 1.0 },
        spiritualist:  { color: "§b", base: { STR: 0, SKP: 0, RES: 0, VIT: 0, PWR: 10, ENE: 10 }, scaling: { STR: 0.3, SKP: 0.5, DEF: 0.156, DEF_max: 0.624, STM: 0.7, VIT: 1.4, VIT_max: 5.6, PWR: 1.9, ENE: 3.7 }, baseHp5: 0.5, hp5VitScaling: 0.015, baseEp5: 8.0, ep5EneScaling: 0.20, baseSp5: 5.0, sp5VitScaling: 0.01875, sp5ResScaling: 0.025, tpGain: 1.0, tpCost: 1.0 },
        martialartist: { color: "§f", base: { STR: 0, SKP: 10, RES: 0, VIT: 10, PWR: 0, ENE: 0 }, scaling: { STR: 0.8, SKP: 1.8, DEF: 0.18, DEF_max: 0.72, STM: 1.3, VIT: 2.2, VIT_max: 8.8, PWR: 0.6, ENE: 1.6 }, baseHp5: 1.5, hp5VitScaling: 0.0525, baseEp5: 4.0, ep5EneScaling: 0.08, baseSp5: 9.0, sp5VitScaling: 0.03375, sp5ResScaling: 0.045, tpGain: 1.0, tpCost: 1.0 },
        berserker:     { color: "§4", base: { STR: 10, SKP: 0, RES: 0, VIT: 10, PWR: 0, ENE: 0 }, scaling: { STR: 1.7, SKP: 0.8, DEF: 0.18, DEF_max: 0.72, STM: 1.1, VIT: 3.0, VIT_max: 12.0, PWR: 0.4, ENE: 1.3 }, baseHp5: 1.0, hp5VitScaling: 0.0375, baseEp5: 2.0, ep5EneScaling: 0.04, baseSp5: 14.0, sp5VitScaling: 0.04875, sp5ResScaling: 0.065, tpGain: 1.0, tpCost: 1.0 },
        paladin:       { color: "§e", base: { STR: 0, SKP: 5, RES: 10, VIT: 5, PWR: 0, ENE: 0 }, scaling: { STR: 0.8, SKP: 1.2, DEF: 0.336, DEF_max: 1.344, STM: 1.2, VIT: 2.0, VIT_max: 8.0, PWR: 0.6, ENE: 1.2 }, baseHp5: 2.0, hp5VitScaling: 0.0675, baseEp5: 4.0, ep5EneScaling: 0.08, baseSp5: 8.0, sp5VitScaling: 0.03, sp5ResScaling: 0.04, tpGain: 1.0, tpCost: 1.0 },
        tank:          { color: "§d", base: { STR: 0, SKP: 0, RES: 10, VIT: 10, PWR: 0, ENE: 0 }, scaling: { STR: 0.6, SKP: 0.7, DEF: 0.384, DEF_max: 1.536, STM: 1.5, VIT: 2.5, VIT_max: 10.0, PWR: 0.5, ENE: 0.8 }, baseHp5: 2.25, hp5VitScaling: 0.075, baseEp5: 5.0, ep5EneScaling: 0.10, baseSp5: 9.0, sp5VitScaling: 0.03375, sp5ResScaling: 0.045, tpGain: 1.25, tpCost: 1.0 },
        cleric:        { color: "§a", base: { STR: 0, SKP: 0, RES: 5, VIT: 0, PWR: 0, ENE: 15 }, scaling: { STR: 0.5, SKP: 0.5, DEF: 0.168, DEF_max: 0.672, STM: 2.6, VIT: 1.2, VIT_max: 4.8, PWR: 0.8, ENE: 3.0 }, baseHp5: 0.5, hp5VitScaling: 0.015, baseEp5: 12.0, ep5EneScaling: 0.24, baseSp5: 16.0, sp5VitScaling: 0.045, sp5ResScaling: 0.06, tpGain: 1.25, tpCost: 0.9 },
        unversed:      { color: "§5", base: { STR: 4, SKP: 3, RES: 3, VIT: 4, PWR: 3, ENE: 3 }, scaling: { STR: 0.9, SKP: 0.9, DEF: 0.22, DEF_max: 0.88, STM: 1.35, VIT: 1.9, VIT_max: 7.6, PWR: 0.85, ENE: 1.75 }, baseHp5: 1.4, hp5VitScaling: 0.048, baseEp5: 5.0, ep5EneScaling: 0.10, baseSp5: 10.0, sp5VitScaling: 0.0375, sp5ResScaling: 0.05, tpGain: 1.0, tpCost: 1.0 }
    };
    var CLASS_ORDER = Object.keys(CLASSES);
    var STATS = ["STR", "SKP", "RES", "VIT", "PWR", "ENE"];
    // DMZ stat key -> our stat id (scripts/10_stats.js)
    var STAT_IDS = { STR: "strength", SKP: "strike", RES: "resistance", VIT: "vitality", PWR: "kipower", ENE: "energy" };

    // appearance options per race (DMZ texture sets; bodies are our look values)
    // headBones: RaceCharacterConfig.headBones without "hair" (the creator's hair tab picks one: look value headBone)
    function range(n) { var o = []; for (var i = 0; i < n; i++) o.push(String(i)); return o; }
    // hair: DMZ's hair presets 1-28 (shared/10_dmz_hair_presets.js; 5 = Krillin = bald)
    var HAIR = range(29).slice(1);
    var LOOKS = {
        human:      { bodies: ["male_1", "male_2", "male_2_slim", "female_1", "female_2"], eyes: range(13), nose: range(6), mouth: range(9), hair: HAIR, colors: ["body1"], hairColor: true },
        saiyan:     { bodies: ["male_1", "male_2", "male_2_slim", "female_1", "female_2"], eyes: range(13), nose: range(6), mouth: range(9), hair: HAIR, colors: ["body1"], hairColor: true },
        glind:      { bodies: ["male_1", "male_2", "male_2_slim", "female_1", "female_2"], eyes: range(13), nose: range(6), mouth: range(9), hair: HAIR, colors: ["body1"], hairColor: true },
        namekian:   { bodies: range(3), eyes: range(5), nose: range(2), mouth: range(2), colors: ["body1", "body2", "body3"], headBones: ["ears1", "ears2", "ears3"] },
        frostdemon: { bodies: range(3), eyes: range(7), nose: range(2), mouth: range(2), colors: ["body1", "body2", "body3"], headBones: ["horns1", "horns2", "horns3", "horns4", "horns5"] },
        bioandroid: { bodies: range(6), eyes: [], nose: [], mouth: [], colors: ["body1", "body2", "body3", "hair"] },
        majin:      { bodies: ["male_0", "male_1", "male_2", "female_0", "female_1", "female_2"], eyes: range(2), nose: range(2), mouth: range(2), colors: ["body1"], headBones: ["majin1", "majin2", "majin3"] }
    };
    // DMZ tattoo types: 0 = none, 1-5 = textures/entity/races/tattoos/tattoo_N.png (drawn untinted)
    var TATTOOS = ["0", "1", "2", "3", "4", "5"];

    /** DMZ's class/race name colour codes stripped, for plain labels. */
    function strip(s) { return String(s || "").replace(/§[0-9a-fk-or]/gi, ""); }

    return { RACES: RACES, OUR: OUR, DMZ: DMZ, CLASSES: CLASSES, CLASS_ORDER: CLASS_ORDER, STATS: STATS, STAT_IDS: STAT_IDS, LOOKS: LOOKS, TATTOOS: TATTOOS, strip: strip };
})();
