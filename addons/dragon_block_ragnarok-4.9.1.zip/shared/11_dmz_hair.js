// =====================================================================================
//  DMZ strand hair: hair codes, presets, per-form styles and the mapping onto the
//  toolkit's strand-hair renderer (avatar `hair` blocks, see api.d.ts > AvatarHair).
//
//  Ported from DragonMine Z (GPL-3.0) - common/hair/* (HairCodec, CustomHair, HairStrand,
//  HairSegmentOverride, HairLegacyMigrator, HairPoseBuilder, HairPresets, HairStyleSlot,
//  HairPhysicsProfile) and client/render/hair/HairStyleResolver. See NOTICE.md.
//
//  How it fits together
//    - A DMZ hairstyle ("CustomHair") is up to 68 strands on five faces of the head
//      (front 4, back/left/right/top 16 each). Each strand: segments, length, length ratio,
//      width, depth, taper, root offset, rotation, bend, twist, colours, per-segment overrides.
//    - Codes: "DMZ1:"/"DMZF1:" = base62, "DMZ22:"/"DMZF22:" = base64url; both raw-deflated NBT.
//      "F" codes are full sets: one style per slot (base, ssj, ssj2, ssj3, ssj4).
//    - Presets: DMZ's preset codes, decoded ahead of time with this file's decoder (so nothing is
//      inflated in game) into client/data/dmz_hair_presets/<id>.json (one small file per preset, read
//      only when that preset is first drawn; extra.json holds the named extra styles); their ids and names are in
//      shared/10_dmz_hair_presets.js. DMZ_HAIR.decode(code) still decodes any DMZ hair code.
//    - Players pick a preset: look value hairStyle = "1".."28" (DMZ hairId; 5 = Krillin = bald).
//    - Each avatar has a hair block whose style is "dmzh{hairStyle}_<slot>"; the client
//      registers those names lazily (RPG.avatar.defineHair) from the preset data, built by
//      DMZ_HAIR.strands() below into the toolkit's generic strand format.
// =====================================================================================
var DMZ_HAIR = (function () {
    var PIXEL = 1;                         // the toolkit takes pixels (DMZ works in blocks: px / 16)
    var DEG = Math.PI / 180;

    // ---- HairStyleSlot ------------------------------------------------------------------
    var SLOTS = ["base", "ssj", "ssj2", "ssj3", "ssj4"];
    var SLOT_CODE = { base: "B", ssj: "S", ssj2: "S2", ssj3: "T", ssj4: "S4" };
    var SLOT_LEGACY = { base: "Base", ssj: "SSJ", ssj2: "SSJ2", ssj3: "SSJ3", ssj4: "SSJ4" };

    // ---- CustomHair faces ---------------------------------------------------------------
    var FACES = [
        { key: "F", name: "FRONT", max: 4, rows: 1, cols: 4 },
        { key: "B", name: "BACK", max: 16, rows: 4, cols: 4 },
        { key: "L", name: "LEFT", max: 16, rows: 4, cols: 4 },
        { key: "R", name: "RIGHT", max: 16, rows: 4, cols: 4 },
        { key: "T", name: "TOP", max: 16, rows: 4, cols: 4 }
    ];
    var BASE_ROT = { F: [-90, 0, 0], B: [90, 0, 0], L: [0, 0, 90], R: [0, 0, -90], T: [0, 0, 0] };

    function basePosition(fi, index) {
        var face = FACES[fi], row = Math.floor(index / face.cols), col = index % face.cols;
        var P = [-3, -1, 1, 3], Y = [0, -1.5, -3, -4.5];
        var gx = P[col % 4], gz = P[row % 4], ry = Y[row % 4];
        switch (face.key) {
            case "F": return [gx, 7.25, -4];
            case "B": return [gx, 7.25 + ry, 4];
            case "L": return [-3.95, 7.25 + ry, gx];
            case "R": return [3.95, 7.25 + ry, -gx];
            default: return [gx, 7.85, gz];
        }
    }

    // ---- small maths (JOML semantics: rotateX etc. post-multiply) -------------------------
    function qid() { return [0, 0, 0, 1]; }
    function qmul(a, b) {
        return [a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
                a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
                a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
                a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]];
    }
    function qrotX(q, r) { var h = r * 0.5; return qmul(q, [Math.sin(h), 0, 0, Math.cos(h)]); }
    function qrotY(q, r) { var h = r * 0.5; return qmul(q, [0, Math.sin(h), 0, Math.cos(h)]); }
    function qrotZ(q, r) { var h = r * 0.5; return qmul(q, [0, 0, Math.sin(h), Math.cos(h)]); }
    function qconj(q) { return [-q[0], -q[1], -q[2], q[3]]; }
    function qapply(q, v) {
        var x = q[0], y = q[1], z = q[2], w = q[3];
        var tx = 2 * (y * v[2] - z * v[1]), ty = 2 * (z * v[0] - x * v[2]), tz = 2 * (x * v[1] - y * v[0]);
        return [v[0] + w * tx + (y * tz - z * ty), v[1] + w * ty + (z * tx - x * tz), v[2] + w * tz + (x * ty - y * tx)];
    }
    function add(a, b) { return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]; }
    function sub(a, b) { return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]; }
    function len(a) { return Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]); }
    function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }
    function clampF(v, lo, hi, fb) { return typeof v === "number" && isFinite(v) ? clamp(v, lo, hi) : fb; }
    function wrapDeg(d) { var w = d % 360; if (w >= 180) w -= 360; if (w < -180) w += 360; return w; }

    // ---- HairColors -----------------------------------------------------------------------
    function parseColor(hex) {
        if (hex === null || hex === undefined) return -1;
        var v = String(hex).trim();
        if (v.charAt(0) === "#") v = v.substring(1);
        if (!/^[0-9A-Fa-f]{6}$/.test(v)) return -1;
        return parseInt(v, 16);
    }
    function normColor(hex) {
        var c = parseColor(hex);
        if (c < 0) return null;
        var s = c.toString(16).toUpperCase();
        while (s.length < 6) s = "0" + s;
        return "#" + s;
    }

    // =====================================================================================
    //  Codec: base62 / base64url -> raw inflate -> NBT
    // =====================================================================================
    var B62 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    var B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

    // BigInteger(base62).toByteArray() minus a leading 0 byte. Limbs of 20 bits, 5 digits a step.
    function decodeBase62(s) {
        if (!s.length) return [];
        var limbs = [0], LB = 1048576, i, k;           // little-endian 20-bit limbs
        for (i = 0; i < s.length; i += 5) {
            var n = Math.min(5, s.length - i), mul = 1, addv = 0;
            for (k = 0; k < n; k++) {
                var d = B62.indexOf(s.charAt(i + k));
                if (d < 0) throw new Error("invalid character '" + s.charAt(i + k) + "'");
                mul *= 62; addv = addv * 62 + d;
            }
            var carry = addv;
            for (k = 0; k < limbs.length; k++) {
                var t = limbs[k] * mul + carry;
                limbs[k] = t % LB;
                carry = Math.floor(t / LB);
            }
            while (carry > 0) { limbs.push(carry % LB); carry = Math.floor(carry / LB); }
        }
        // limbs -> big-endian bytes
        var bits = [], bytes = [];
        var acc = 0, accBits = 0;
        for (k = 0; k < limbs.length; k++) {
            acc += limbs[k] * Math.pow(2, accBits); accBits += 20;
            while (accBits >= 8) { bits.push(acc % 256); acc = Math.floor(acc / 256); accBits -= 8; }
        }
        while (acc > 0) { bits.push(acc % 256); acc = Math.floor(acc / 256); }
        while (bits.length > 1 && bits[bits.length - 1] === 0) bits.pop();
        for (k = bits.length - 1; k >= 0; k--) bytes.push(bits[k]);
        // BigInteger.toByteArray adds a sign byte when the top bit is set; the codec strips one leading 0
        return bytes;
    }

    function decodeBase64Url(s) {
        var out = [], buf = 0, nb = 0;
        for (var i = 0; i < s.length; i++) {
            var c = s.charAt(i);
            if (c === "=") break;
            var v = B64.indexOf(c);
            if (v < 0) v = "+/".indexOf(c) >= 0 ? 62 + "+/".indexOf(c) : -1;
            if (v < 0) throw new Error("invalid base64 character");
            buf = (buf << 6) | v; nb += 6;
            if (nb >= 8) { nb -= 8; out.push((buf >> nb) & 255); }
        }
        return out;
    }

    // ---- raw DEFLATE (RFC 1951) ----
    function inflate(data) {
        var pos = 0, bitBuf = 0, bitCnt = 0, out = [];
        function bit() {
            if (bitCnt === 0) { if (pos >= data.length) throw new Error("truncated data"); bitBuf = data[pos++]; bitCnt = 8; }
            var b = bitBuf & 1; bitBuf >>= 1; bitCnt--; return b;
        }
        function bits(n) { var v = 0; for (var i = 0; i < n; i++) v |= bit() << i; return v; }
        function build(lengths, n) {
            var counts = [], offs = [], symbols = [], i;
            for (i = 0; i < 16; i++) counts[i] = 0;
            for (i = 0; i < n; i++) counts[lengths[i]]++;
            counts[0] = 0;
            offs[1] = 0;
            for (i = 1; i < 15; i++) offs[i + 1] = offs[i] + counts[i];
            for (i = 0; i < n; i++) if (lengths[i]) symbols[offs[lengths[i]]++] = i;
            return { counts: counts, symbols: symbols };
        }
        function decodeSym(h) {
            var code = 0, first = 0, index = 0;
            for (var l = 1; l < 16; l++) {
                code |= bit();
                var c = h.counts[l];
                if (code - c < first) return h.symbols[index + (code - first)];
                index += c; first += c; first <<= 1; code <<= 1;
            }
            throw new Error("bad huffman code");
        }
        var LBASE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
        var LEXT = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
        var DBASE = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
        var DEXT = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
        var fixedL = null, fixedD = null;
        var last;
        do {
            last = bit();
            var type = bits(2), lt, dt, i;
            if (type === 0) {
                bitCnt = 0;
                var ln = data[pos] | (data[pos + 1] << 8); pos += 4;
                for (i = 0; i < ln; i++) out.push(data[pos++]);
                continue;
            } else if (type === 1) {
                if (!fixedL) {
                    var l = [];
                    for (i = 0; i < 144; i++) l[i] = 8;
                    for (; i < 256; i++) l[i] = 9;
                    for (; i < 280; i++) l[i] = 7;
                    for (; i < 288; i++) l[i] = 8;
                    fixedL = build(l, 288);
                    var d = [];
                    for (i = 0; i < 30; i++) d[i] = 5;
                    fixedD = build(d, 30);
                }
                lt = fixedL; dt = fixedD;
            } else if (type === 2) {
                var hlit = bits(5) + 257, hdist = bits(5) + 1, hclen = bits(4) + 4;
                var ORDER = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
                var cl = [];
                for (i = 0; i < 19; i++) cl[i] = 0;
                for (i = 0; i < hclen; i++) cl[ORDER[i]] = bits(3);
                var ch = build(cl, 19), lens = [];
                while (lens.length < hlit + hdist) {
                    var sym = decodeSym(ch);
                    if (sym < 16) lens.push(sym);
                    else if (sym === 16) { var prev = lens[lens.length - 1], r = 3 + bits(2); while (r--) lens.push(prev); }
                    else if (sym === 17) { var z = 3 + bits(3); while (z--) lens.push(0); }
                    else { var z2 = 11 + bits(7); while (z2--) lens.push(0); }
                }
                lt = build(lens.slice(0, hlit), hlit);
                dt = build(lens.slice(hlit), hdist);
            } else throw new Error("bad block type");
            for (;;) {
                var s = decodeSym(lt);
                if (s < 256) out.push(s);
                else if (s === 256) break;
                else {
                    s -= 257;
                    var length = LBASE[s] + bits(LEXT[s]);
                    var ds = decodeSym(dt);
                    var dist = DBASE[ds] + bits(DEXT[ds]);
                    var from = out.length - dist;
                    for (i = 0; i < length; i++) out.push(out[from + i]);
                }
                if (out.length > 2097152) throw new Error("hair code too large");
            }
        } while (!last);
        return out;
    }

    // ---- NBT (big endian) to plain objects; lists become arrays ----
    function readNbt(b) {
        var p = 0;
        function u8() { return b[p++]; }
        function u16() { var v = (b[p] << 8) | b[p + 1]; p += 2; return v; }
        function i32() { var v = (b[p] << 24) | (b[p + 1] << 16) | (b[p + 2] << 8) | b[p + 3]; p += 4; return v; }
        function f32() {
            var bitsv = i32() >>> 0, sign = bitsv >>> 31 ? -1 : 1, e = (bitsv >>> 23) & 255, m = bitsv & 0x7FFFFF;
            if (e === 255) return m ? NaN : sign * Infinity;
            if (e === 0) return sign * m * Math.pow(2, -149);
            return sign * (1 + m / 8388608) * Math.pow(2, e - 127);
        }
        function f64() {
            var hi = i32() >>> 0, lo = i32() >>> 0, sign = hi >>> 31 ? -1 : 1, e = (hi >>> 20) & 2047;
            var m = (hi & 0xFFFFF) * 4294967296 + lo;
            if (e === 2047) return m ? NaN : sign * Infinity;
            if (e === 0) return sign * m * Math.pow(2, -1074);
            return sign * (1 + m / 4503599627370496) * Math.pow(2, e - 1023);
        }
        function str() {
            var n = u16(), s = "", end = p + n;
            while (p < end) {
                var c = b[p++];
                if (c < 128) s += String.fromCharCode(c);
                else if ((c & 0xE0) === 0xC0) s += String.fromCharCode(((c & 31) << 6) | (b[p++] & 63));
                else { s += String.fromCharCode(((c & 15) << 12) | ((b[p] & 63) << 6) | (b[p + 1] & 63)); p += 2; }
            }
            return s;
        }
        function payload(t) {
            var n, i, a;
            switch (t) {
                case 1: { var v = u8(); return v > 127 ? v - 256 : v; }
                case 2: { var s = u16(); return s > 32767 ? s - 65536 : s; }
                case 3: return i32();
                case 4: { var h = i32(); var l = i32() >>> 0; return h * 4294967296 + l; }
                case 5: return f32();
                case 6: return f64();
                case 7: n = i32(); a = []; for (i = 0; i < n; i++) a.push(payload(1)); return a;
                case 8: return str();
                case 9: { var et = u8(); n = i32(); a = []; for (i = 0; i < n; i++) a.push(payload(et)); return a; }
                case 10: {
                    var o = {};
                    for (;;) {
                        var tt = u8();
                        if (tt === 0) return o;
                        var name = str();
                        o[name] = payload(tt);
                    }
                }
                case 11: n = i32(); a = []; for (i = 0; i < n; i++) a.push(i32()); return a;
                case 12: n = i32(); a = []; for (i = 0; i < n; i++) a.push(payload(4)); return a;
                default: throw new Error("bad nbt tag " + t);
            }
        }
        var root = u8();
        if (root !== 10) throw new Error("not a compound");
        str();
        return payload(10);
    }

    function decodeTag(code) {
        if (code.length > 262144) return null;
        var bytes;
        if (code.indexOf("DMZF22:") === 0) bytes = decodeBase64Url(code.substring(7));
        else if (code.indexOf("DMZ22:") === 0) bytes = decodeBase64Url(code.substring(6));
        else if (code.indexOf("DMZF1:") === 0) bytes = decodeBase62(code.substring(6));
        else if (code.indexOf("DMZ1:") === 0) bytes = decodeBase62(code.substring(5));
        else return null;
        return readNbt(inflate(bytes));
    }

    // =====================================================================================
    //  CustomHair: NBT -> canonical style {name, gc, keepEmpty, faces: {F: [strand...]}}
    //  A strand: {i, sg, ln, lr, w, d, tp, tg, ox, oy, oz, rx, ry, rz, bx, by, bz, tw, c, tc, so: [override]}
    //  (DMZ's own NBT keys, version 7 meaning: override scales are relative to the previous segment)
    // =====================================================================================
    function num(t, k, fb) { return typeof t[k] === "number" ? t[k] : fb; }

    function defaultStrand(fi, index) {
        var r = BASE_ROT[FACES[fi].key];
        return { i: fi * 100 + index, sg: 0, ln: 6, lr: 0.6, w: 2, d: 2, tp: 0.6, tg: 1, ox: 0, oy: 0, oz: 0,
                 rx: r[0], ry: r[1], rz: r[2], bx: 0, by: 0, bz: 0, tw: 0, c: null, tc: null, so: [] };
    }

    function loadOverride(t) {
        return { k: t.k | 0, ox: clampF(num(t, "ox", 0), -2, 2, 0), oy: clampF(num(t, "oy", 0), -2, 2, 0), oz: clampF(num(t, "oz", 0), -2, 2, 0),
                 rx: clampF(num(t, "rx", 0), -180, 180, 0), ry: clampF(num(t, "ry", 0), -180, 180, 0), rz: clampF(num(t, "rz", 0), -180, 180, 0),
                 ls: clampF(num(t, "ls", 1), 0.1, 16, 1), ws: clampF(num(t, "ws", 1), 0.1, 16, 1), ds: clampF(num(t, "ds", 1), 0.1, 16, 1),
                 c: t.c !== undefined ? normColor(t.c) : null };
    }
    function isIdentity(o) {
        var e = 1e-4;
        return Math.abs(o.ox) < e && Math.abs(o.oy) < e && Math.abs(o.oz) < e && Math.abs(o.rx) < e && Math.abs(o.ry) < e && Math.abs(o.rz) < e
            && Math.abs(o.ls - 1) < e && Math.abs(o.ws - 1) < e && Math.abs(o.ds - 1) < e && !o.c;
    }
    function getOverride(s, k) { for (var i = 0; i < s.so.length; i++) if (s.so[i].k === k) return s.so[i]; return null; }
    function getOrCreateOverride(s, k) {
        var o = getOverride(s, k);
        if (!o) { o = { k: k, ox: 0, oy: 0, oz: 0, rx: 0, ry: 0, rz: 0, ls: 1, ws: 1, ds: 1, c: null }; s.so.push(o); s.so.sort(function (a, b) { return a.k - b.k; }); }
        return o;
    }
    function removeOverride(s, k) { s.so = s.so.filter(function (o) { return o.k !== k; }); }

    function loadStrand(t) {
        var s = { i: t.i | 0, sg: clamp(t.sg | 0, 0, 32) };
        s.ln = "ln" in t ? clampF(t.ln, 0.1, 128, 6) : 6;
        s.lr = "lr" in t ? clampF(t.lr, 0.1, 4, 1) : 1;
        s.w = "w" in t ? clampF(t.w, 0.1, 16, 2) : 2;
        s.d = "d" in t ? clampF(t.d, 0.1, 16, 2) : 2;
        s.tp = "tp" in t ? clampF(t.tp, 0.05, 2, 1) : 1;
        s.tg = "tg" in t ? clampF(t.tg, 0.25, 4, 1) : 1;
        s.ox = clampF(num(t, "ox", 0), -4, 4, 0); s.oy = clampF(num(t, "oy", 0), -4, 4, 0); s.oz = clampF(num(t, "oz", 0), -4, 4, 0);
        s.rx = wrapDeg(num(t, "rx", 0)); s.ry = wrapDeg(num(t, "ry", 0)); s.rz = wrapDeg(num(t, "rz", 0));
        s.bx = clampF(num(t, "bx", 0), -3600, 3600, 0); s.by = clampF(num(t, "by", 0), -3600, 3600, 0); s.bz = clampF(num(t, "bz", 0), -3600, 3600, 0);
        s.tw = clampF(num(t, "tw", 0), -3600, 3600, 0);
        s.c = t.c !== undefined ? normColor(t.c) : null;
        s.tc = t.tc !== undefined ? normColor(t.tc) : null;
        s.so = [];
        (t.so || []).forEach(function (ot) {
            var o = loadOverride(ot);
            if (o.k >= 0 && o.k < 32) { removeOverride(s, o.k); s.so.push(o); }
        });
        s.so.sort(function (a, b) { return a.k - b.k; });
        return s;
    }

    // HairStrand.convertAbsoluteSegmentScales (codes older than version 7)
    function convertAbsoluteScales(s) {
        var ls = 1, ws = 1, dsc = 1;
        for (var k = 0; k < s.sg; k++) {
            var ex = getOverride(s, k);
            var al = ex ? ex.ls : 1, aw = ex ? ex.ws : 1, ad = ex ? ex.ds : 1;
            if (!ex && ls === 1 && ws === 1 && dsc === 1) continue;
            var o = getOrCreateOverride(s, k);
            o.ls = clamp(al / ls, 0.1, 16); o.ws = clamp(aw / ws, 0.1, 16); o.ds = clamp(ad / dsc, 0.1, 16);
            if (isIdentity(o)) { removeOverride(s, k); continue; }
            ls *= o.ls; ws *= o.ws; dsc *= o.ds;
        }
    }

    // ---- HairPoseBuilder.buildGeometry (positions in pixels) ----
    function poseOf(s, fi, index) {
        var seg = s.sg, base = basePosition(fi, index);
        var root = [base[0] + s.ox, base[1] + s.oy, base[2] + s.oz];
        var baseRot = qrotZ(qrotY(qrotX(qid(), s.rx * DEG), s.ry * DEG), s.rz * DEG);
        var out = { root: root, baseRot: baseRot, seg: seg, lengths: [], widths: [], depths: [], params: [], rel: [], offs: [], restRot: [], restStart: [], tip: root };
        if (seg <= 0) return out;
        var total = 0, k;
        for (k = 0; k < seg; k++) { var pr = seg > 1 ? k / (seg - 1) : 0; out.params[k] = pr; total += Math.pow(s.lr, pr); }
        var joints = Math.max(1, seg - 1);
        var bx = seg > 1 ? s.bx / joints * DEG : 0, by = seg > 1 ? s.by / joints * DEG : 0, bz = seg > 1 ? s.bz / joints * DEG : 0;
        var tw = seg > 1 ? s.tw / joints * DEG : 0;
        var lsc = 1, wsc = 1, dsc = 1;
        for (k = 0; k < seg; k++) {
            var param = out.params[k], ov = getOverride(s, k);
            var weight = Math.pow(s.lr, param) / total;
            var taper = Math.pow(s.tp, Math.pow(param, s.tg));
            if (ov) { lsc *= ov.ls; wsc *= ov.ws; dsc *= ov.ds; }
            out.lengths[k] = s.ln * weight * lsc;
            out.widths[k] = s.w * taper * wsc;
            out.depths[k] = s.d * taper * dsc;
            var rel = qid();
            if (k > 0) rel = qrotY(qrotZ(qrotY(qrotX(rel, bx), by), bz), tw);
            var off = [0, 0, 0];
            if (ov) {
                off = qapply(rel, [ov.ox, ov.oy, ov.oz]);
                rel = qrotZ(qrotY(qrotX(rel, ov.rx * DEG), ov.ry * DEG), ov.rz * DEG);
            }
            out.rel[k] = rel; out.offs[k] = off;
        }
        var parent = baseRot, cursor = root;
        for (k = 0; k < seg; k++) {
            var start = add(qapply(parent, out.offs[k]), cursor);
            var rot = qmul(parent, out.rel[k]);
            out.restStart[k] = start; out.restRot[k] = rot;
            cursor = add(qapply(rot, [0, out.lengths[k], 0]), start);
            parent = rot;
        }
        out.tip = cursor;
        return out;
    }

    // ---- HairLegacyMigrator (codes older than version 6) ----
    function m4id() { return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]; }   // column-major
    function m4mul(a, b) {
        var r = [];
        for (var c = 0; c < 4; c++) for (var rr = 0; rr < 4; rr++) {
            var v = 0;
            for (var k = 0; k < 4; k++) v += a[k * 4 + rr] * b[c * 4 + k];
            r[c * 4 + rr] = v;
        }
        return r;
    }
    function m4t(m, x, y, z) { return m4mul(m, [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1]); }
    function m4rx(m, a) { var c = Math.cos(a), s = Math.sin(a); return m4mul(m, [1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]); }
    function m4ry(m, a) { var c = Math.cos(a), s = Math.sin(a); return m4mul(m, [c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]); }
    function m4rz(m, a) { var c = Math.cos(a), s = Math.sin(a); return m4mul(m, [c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]); }
    function m4s(m, x, y, z) { return m4mul(m, [x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1]); }
    function m4p(m, v) { return [m[0] * v[0] + m[4] * v[1] + m[8] * v[2] + m[12], m[1] * v[0] + m[5] * v[1] + m[9] * v[2] + m[13], m[2] * v[0] + m[6] * v[1] + m[10] * v[2] + m[14]]; }

    function legacyF(t, a, b, fb) { var v = typeof t[a] === "number" ? t[a] : typeof t[b] === "number" ? t[b] : fb; return isFinite(v) ? v : fb; }

    function migrateStrand(fi, index, t) {
        var L = {
            length: Math.max(0, "l" in t ? t.l | 0 : (t.Length | 0)), lengthScale: legacyF(t, "ls", "LengthScale", 1),
            rx: legacyF(t, "rx", "RotX", 0), ry: legacyF(t, "ry", "RotY", 0), rz: legacyF(t, "rz", "RotZ", 0),
            sx: legacyF(t, "sx", "ScaleX", 1), sy: legacyF(t, "sy", "ScaleY", 1), sz: legacyF(t, "sz", "ScaleZ", 1),
            cw: legacyF(t, "cw", "CubeW", 2), ch: legacyF(t, "ch", "CubeH", 2), cd: legacyF(t, "cd", "CubeD", 2),
            cx: legacyF(t, "cx", "CurveX", 0), cy: legacyF(t, "cy", "CurveY", 0), cz: legacyF(t, "cz", "CurveZ", 0),
            color: t.c !== undefined ? t.c : t.Color !== undefined ? t.Color : null
        };
        var s = defaultStrand(fi, index);
        s.rx = wrapDeg(L.rx); s.ry = wrapDeg(L.ry); s.rz = wrapDeg(L.rz);
        s.c = normColor(L.color);
        var seg = Math.min(L.length, 32);
        if (seg <= 0) { s.sg = 0; return s; }
        var DECAY = 0.85, decaySum = (1 - Math.pow(DECAY, seg)) / (1 - DECAY), ratio = Math.pow(DECAY, seg - 1);
        s.sg = seg;
        s.ln = clampF(L.ch * L.lengthScale * L.sy * decaySum, 0.1, 128, s.ln);
        s.lr = clampF(ratio, 0.1, 4, s.lr);
        s.tp = clampF(ratio, 0.05, 2, s.tp);
        s.tg = 1;
        s.w = clampF(L.cw * L.sx, 0.1, 16, s.w);
        s.d = clampF(L.cd * L.sz, 0.1, 16, s.d);
        s.bx = clampF(L.cx * (seg - 1), -3600, 3600, 0); s.by = clampF(L.cy * (seg - 1), -3600, 3600, 0); s.bz = clampF(L.cz * (seg - 1), -3600, 3600, 0);

        // the old centre line
        var base = basePosition(fi, index);
        var m = m4s(m4rz(m4ry(m4rx(m4t(m4id(), base[0], base[1], base[2]), L.rx * DEG), L.ry * DEG), L.rz * DEG), L.sx, L.sy, L.sz);
        var joints = [], decay = 1, prevH = 0, i;
        for (i = 0; i < seg; i++) {
            var h = L.ch * decay * L.lengthScale;
            if (i > 0) m = m4rz(m4ry(m4rx(m4t(m, 0, prevH, 0), L.cx * DEG), L.cy * DEG), L.cz * DEG);
            joints[i] = m4p(m, [0, 0, 0]);
            prevH = h; decay *= DECAY;
        }
        joints[seg] = m4p(m, [0, prevH, 0]);

        var pose = poseOf(s, fi, index), maxDev = 0;
        for (i = 0; i < seg; i++) maxDev = Math.max(maxDev, len(sub(pose.restStart[i], joints[i])));
        maxDev = Math.max(maxDev, len(sub(pose.tip, joints[seg])));
        if (maxDev > 0.1) fitCenterline(s, joints, pose);
        return s;
    }

    function fitCenterline(s, joints, pose) {
        s.so = [];
        var seg = pose.seg, baseLen = pose.lengths.slice();
        var parent = pose.baseRot;
        var j = Math.max(1, seg - 1);
        var bx = seg > 1 ? s.bx / j * DEG : 0, by = seg > 1 ? s.by / j * DEG : 0, bz = seg > 1 ? s.bz / j * DEG : 0;
        for (var k = 0; k < seg; k++) {
            var frame = parent;
            if (k > 0) frame = qrotZ(qrotY(qrotX(frame, bx), by), bz);
            var dir = sub(joints[k + 1], joints[k]), actual = len(dir);
            if (actual < 1e-5 || baseLen[k] < 1e-5) { parent = frame; continue; }
            dir = qapply(qconj(frame), dir);
            dir = [dir[0] / actual, dir[1] / actual, dir[2] / actual];
            var rz = Math.asin(clamp(-dir[0], -1, 1)), rx = Math.atan2(dir[2], dir[1]);
            var o = getOrCreateOverride(s, k);
            o.rx = clamp(rx / DEG, -180, 180); o.ry = 0; o.rz = clamp(rz / DEG, -180, 180);
            o.ls = clamp(actual / baseLen[k], 0.1, 16);
            if (isIdentity(o)) removeOverride(s, k);
            parent = qrotZ(qrotX(frame, rx), rz);
        }
    }

    function resolveIndex(fi, t, listIndex, version) {
        if (version < 2) return listIndex;
        var id = "i" in t ? t.i : (t.Id | 0);
        var index = id - fi * 100;
        return index >= 0 && index < FACES[fi].max ? index : listIndex;
    }

    function loadHair(tag) {
        var version = "v" in tag ? tag.v : ("Version" in tag ? tag.Version : 1);
        var hair = { name: tag.n !== undefined ? tag.n : (tag.Name !== undefined ? tag.Name : "Custom"),
                     gc: normColor(tag.gc !== undefined ? tag.gc : tag.GlobalColor) || "#000000", keep: !!tag.e, faces: {} };
        FACES.forEach(function (face, fi) {
            var list = tag[face.key] || tag[face.name];
            var out = [];
            if (list && list.length) list.forEach(function (st, li) {
                var index = resolveIndex(fi, st, li, version);
                if (index < 0 || index >= face.max) return;
                var s;
                if (version >= 6) s = loadStrand(st);
                else s = migrateStrand(fi, index, st);
                if (version < 7) convertAbsoluteScales(s);
                s.i = fi * 100 + index;
                if (s.sg > 0 && s.ln > 0) out[index] = s;
            });
            hair.faces[face.key] = out;
        });
        return hair;
    }

    function isEmpty(h) {
        if (!h) return true;
        for (var f in h.faces) for (var i = 0; i < h.faces[f].length; i++) if (h.faces[f][i]) return false;
        return true;
    }

    // HairCodec.fromCode: a single style (a full-set code gives its base)
    function fromCode(code) {
        var c = String(code || "").trim();
        if (!c) return null;
        if (isFullSetCode(c)) { var set = fromFullSetCode(c); return set ? set.base : null; }
        var tag = decodeTag(c);
        if (!tag) return null;
        if (tag.Base && (tag.SSJ || tag.SSJ2 || tag.SSJ3)) return loadHair(tag.Base);
        return loadHair(tag);
    }
    function isFullSetCode(c) { return c.indexOf("DMZF22:") === 0 || c.indexOf("DMZF1:") === 0; }
    function copyHair(h) { return JSON.parse(JSON.stringify(h)); }
    function emptyHair() { var h = { name: "Custom", gc: "#000000", keep: false, faces: {} }; FACES.forEach(function (f) { h.faces[f.key] = []; }); return h; }

    // HairCodec.fromFullSetCode
    function fromFullSetCode(code) {
        var c = String(code).trim();
        var tag = decodeTag(c);
        if (!tag) return null;
        var styles = {};
        SLOTS.forEach(function (slot) {
            var key = tag[SLOT_CODE[slot]] ? SLOT_CODE[slot] : tag[SLOT_LEGACY[slot]] ? SLOT_LEGACY[slot] : null;
            if (key) styles[slot] = loadHair(tag[key]);
        });
        if (!styles.base) styles.base = emptyHair();
        if (c.indexOf("DMZF1:") === 0 && !styles.ssj2 && styles.ssj) styles.ssj2 = copyHair(styles.ssj);
        if (!styles.ssj) styles.ssj = copyHair(styles.base);
        if (!styles.ssj2) styles.ssj2 = copyHair(styles.base);
        if (!styles.ssj3) styles.ssj3 = copyHair(styles.base);
        if (!styles.ssj4) styles.ssj4 = emptyHair();
        return styles;
    }

    // HairPresets.decode: a preset code -> styles per slot (single codes fill every slot but ssj4)
    function decodePreset(code) {
        if (isFullSetCode(code)) return fromFullSetCode(code);
        var single = fromCode(code), out = {};
        if (!single) return null;
        SLOTS.forEach(function (slot) { if (slot !== "ssj4") out[slot] = single; });
        return out;
    }

    // =====================================================================================
    //  Presets (HairPresets.get) over the pre-decoded data
    // =====================================================================================
    var INDEX = typeof DMZ_HAIR_PRESETS !== "undefined" ? DMZ_HAIR_PRESETS : { order: [], names: {}, ssj4: {} };
    var BALD = 5;
    var files = {};               // client/data/dmz_hair_presets/<name>.json, each read the first time it is needed
    var cache = {};               // "id:slot" -> unpacked style

    // The JSON's array strands back into strand objects (generator: DMZ_HAIR.decodePreset + pack)
    function unpackStrand(a) {
        var s = { i: a[0] | 0, sg: a[1] | 0, ln: a[2], lr: nv(a[3], 1), w: nv(a[4], 2), d: nv(a[5], 2), tp: nv(a[6], 1), tg: nv(a[7], 1),
                  ox: nv(a[8], 0), oy: nv(a[9], 0), oz: nv(a[10], 0), rx: nv(a[11], 0), ry: nv(a[12], 0), rz: nv(a[13], 0),
                  bx: nv(a[14], 0), by: nv(a[15], 0), bz: nv(a[16], 0), tw: nv(a[17], 0), c: a[18] || null, tc: a[19] || null, so: [] };
        (a[20] || []).forEach(function (o) {
            s.so.push({ k: o[0] | 0, ox: nv(o[1], 0), oy: nv(o[2], 0), oz: nv(o[3], 0), rx: nv(o[4], 0), ry: nv(o[5], 0), rz: nv(o[6], 0),
                        ls: nv(o[7], 1), ws: nv(o[8], 1), ds: nv(o[9], 1), c: o[10] || null });
        });
        return s;
    }
    function nv(x, fb) { return typeof x === "number" ? x : fb; }
    function unpack(p) {
        var h = { name: "", gc: p.gc || "#000000", keep: !!p.e, faces: {} };
        FACES.forEach(function (face, fi) {
            var out = [];
            (p[face.key] || []).forEach(function (a) {
                var s = unpackStrand(a), index = s.i - fi * 100;
                if (index >= 0 && index < face.max) out[index] = s;
            });
            h.faces[face.key] = out;
        });
        return h;
    }
    // One preset's file (~30 KB) instead of all of them at once: reading the whole set (600 KB) in one go took longer
    // than a frame may, and it happened in the middle of drawing the HUD portrait.
    function presetFile(name) {
        if (!(name in files)) {
            var d = null;
            if (/^[A-Za-z0-9_]{1,40}$/.test(name) && RPG.files && RPG.files.read) {
                try { d = RPG.files.read("dmz_hair_presets/" + name + ".json"); } catch (e) { d = null; }
            }
            files[name] = d || null;
        }
        return files[name];
    }
    function packedStyle(id, slot) {
        var p = presetFile(String(id));
        if (!p) return null;
        var st = p[slot];
        if (typeof st === "string") st = p[st];
        return st || null;
    }
    function style(id, slot) {
        var key = id + ":" + slot;
        if (!(key in cache)) {
            var st = typeof id === "string" ? (presetFile("extra") || {})[id] : packedStyle(id, slot);
            cache[key] = st ? unpack(st) : null;
        }
        return cache[key];
    }

    function presetIds() { return INDEX.order.slice(); }
    function presetName(id) { return INDEX.names[id] || ("Preset " + id); }
    function exists(id) { return !!INDEX.names[id]; }

    // HairPresets.get(presetId, slot)
    function preset(id, slot) {
        if (!exists(id)) return null;
        var hair = style(id, slot);
        if (slot === "ssj4") return hair && (!isEmpty(hair) || hair.keep) ? hair : style(INDEX.ssj4[id] || "DEFAULT_SSJ4_CODE", "base");
        return hair || style(id, "base");
    }

    // Old DBR look values -> preset ids ("base" was the plain cap, "bald" no hair)
    function presetOf(value, race) {
        var v = String(value === undefined || value === null ? "" : value);
        if (v === "bald") return BALD;
        if (v === "base") return defaultPreset(race) || 1;
        var n = parseInt(v, 10);
        if (!isNaN(n) && String(n) === v && (n === 0 || exists(n))) return n;
        return defaultPreset(race);
    }
    // RaceCharacterConfig.defaultHairType: humans and Saiyans Goku (1), Glinds their own (28), the rest none (0)
    function defaultPreset(race) { return race === "glind" ? 28 : race === "human" || race === "saiyan" ? 1 : 0; }
    function hasVisibleHair(id) { return id > 0 && id !== BALD && exists(id); }

    // =====================================================================================
    //  Mapping onto the toolkit's strands
    //  Each strand: {id, pos: [x,y,z] (pixels from the head pivot), rot: [rx,ry,rz] (degrees, X then Y then Z),
    //  segs: [{len, w, d, q: [x,y,z,w] (relative to the previous segment), off: [x,y,z]?, color?}], color?, tip?}
    // =====================================================================================
    function r4(v) { return Math.round(v * 10000) / 10000; }

    function toStrands(hair, ownColors) {
        var out = [];
        if (!hair) return out;
        FACES.forEach(function (face, fi) {
            var list = hair.faces[face.key] || [];
            for (var index = 0; index < list.length; index++) {
                var s = list[index];
                if (!s || s.sg <= 0) continue;
                var p = poseOf(s, fi, index), segs = [];
                for (var k = 0; k < p.seg; k++) {
                    var q = p.rel[k], o = p.offs[k];
                    var sd = { len: r4(p.lengths[k] * PIXEL), w: r4(p.widths[k] * PIXEL), d: r4(p.depths[k] * PIXEL) };
                    if (Math.abs(q[0]) + Math.abs(q[1]) + Math.abs(q[2]) > 1e-6) sd.q = [r4(q[0]), r4(q[1]), r4(q[2]), r4(q[3])];
                    if (Math.abs(o[0]) + Math.abs(o[1]) + Math.abs(o[2]) > 1e-6) sd.off = [r4(o[0]), r4(o[1]), r4(o[2])];
                    var ov = ownColors ? getOverride(s, k) : null;
                    if (ov && ov.c) sd.color = ov.c;
                    segs.push(sd);
                }
                var st = { id: s.i, pos: [r4(p.root[0]), r4(p.root[1]), r4(p.root[2])], rot: [r4(s.rx), r4(s.ry), r4(s.rz)], segs: segs };
                if (ownColors && s.c) st.color = s.c;
                if (ownColors && s.tc) st.tip = s.tc;
                out.push(st);
            }
        });
        return out;
    }

    // Engine style names: "dmzh<preset>_<slot>" with own strand colours, "...f" when the form forces the colour
    // (HairStyleResolver: a form hair colour override draws every strand in the form colour).
    function styleName(slot, forced) { return "dmzh{hairStyle}_" + slot + (forced ? "f" : ""); }

    function strandsFor(styleId) {
        var m = /^dmzh([A-Za-z0-9]+)_(base|ssj|ssj2|ssj3|ssj4)(f?)$/.exec(String(styleId));
        if (!m) return null;
        var id = presetOf(m[1], "");
        if (id <= 0) return [];
        return toStrands(preset(id, m[2]), m[3] !== "f");
    }

    // HairPhysicsProfile.defaultFor(slot): stiffness, damping, gravity, max deviation (degrees)
    var PHYSICS = {
        base: { stiffness: 0.30, damping: 1.00, gravity: 0.10, maxAngle: 50 },
        ssj: { stiffness: 0.45, damping: 1.00, gravity: 0.03, maxAngle: 30 },
        ssj2: { stiffness: 0.45, damping: 1.00, gravity: 0.03, maxAngle: 30 },
        ssj3: { stiffness: 0.32, damping: 0.95, gravity: 0.12, maxAngle: 70 },
        ssj4: { stiffness: 0.30, damping: 1.00, gravity: 0.12, maxAngle: 55 }
    };

    // The avatar `hair` block for a slot ("base", "ssj"... or "" / "empty" for none). colorName: the
    // player colour the hair takes ("hair", "fHair"); forced: the form overrides the hair colour.
    function avatarHair(slot, colorName, forced) {
        if (!slot || slot === "empty" || SLOTS.indexOf(slot) < 0) return null;
        var ph = PHYSICS[slot];
        return {
            style: styleName(slot, forced), color: colorName || "hair", bone: "head",
            texture: DMZ_TEX + "races/hair.png", transition: 8,
            physics: { stiffness: ph.stiffness, damping: ph.damping, gravity: ph.gravity, maxAngle: ph.maxAngle, energy: ["charge", "tf"] }
        };
    }

    // Client: register every preset x slot lazily (the engine builds a style the first time a player shows it)
    if (RPG.isClient() && RPG.avatar && RPG.avatar.defineHair) {
        var names = ["bald", "base"].concat(INDEX.order.map(String));
        names.forEach(function (n) {
            SLOTS.forEach(function (slot) {
                ["", "f"].forEach(function (f) {
                    var id = "dmzh" + n + "_" + slot + f;
                    RPG.avatar.defineHair(id, function () { return strandsFor(id); });
                });
            });
        });
    }

    return {
        SLOTS: SLOTS, BALD: BALD, PHYSICS: PHYSICS,
        decode: fromCode, decodeFullSet: fromFullSetCode, decodePreset: decodePreset, decodeTag: decodeTag,
        preset: preset, presetIds: presetIds, presetName: presetName, exists: exists, presetOf: presetOf,
        defaultPreset: defaultPreset, hasVisibleHair: hasVisibleHair, isEmpty: isEmpty,
        toStrands: toStrands, strandsFor: strandsFor, avatarHair: avatarHair, styleName: styleName,
        _inflate: inflate, _base62: decodeBase62, _nbt: readNbt, _pose: poseOf, _migrate: migrateStrand
    };
})();
