// =====================================================================================
//  23_dbr_npc_regions_data.js - NPC regions: shared data model (server + client editor)
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0) shuruisutilities npcregion: NpcRegion, NpcSpawnConfig, CustomDrop, LevelScale
//  and PolygonXZ. Field names and defaults are DMZ Ragnarok's own, so a region exported from DMZR's
//  npcregions.json imports as is (see fromDmzr).
//
//  What is new here: a region's area is drawn on the world map as free-form polygons ("shapes", each
//  [x0, z0, x1, z1, ...] in block corners), instead of DMZR's map-dragged boxes. Membership is a point-in-polygon
//  test on the block column (x + 0.5, z + 0.5) inside minY..maxY.
//
//  Server: scripts/93_dbr_npc_regions.js. Client: client/scripts/83_dbr_npc_regions.js (map editor + forms).
// =====================================================================================
var DBR_NPCR_DATA = (function () {
    // LevelScale: values at level 1 and at scaleMaxLevel, a straight line between, clamped outside
    var DEFAULT_MAX_LEVEL = 100000, DEFAULT_MULTIPLE = 100, DEFAULT_AGGRO_RANGE = 4;
    var MOVESETS = ["None (melee only)", "Saibamen", "Frieza Soldier", "Cui", "Dodoria", "Zarbon", "Ginyu Force", "Frieza", "Androids", "Cell", "Babidi Soldier", "Majin Buu"];
    var AI_TIERS = ["Simple", "Tactical", "Advanced"];
    var BEHAVIORS = ["Passive", "Wander", "Dialogue", "Follower", "Guard", "Hostile", "DMZ Fighter"];
    var DEFAULT_ENTITY = "dmz_ragnarok:dmz_fighter";

    function num(v, fb) { var n = Number(v); return v === null || v === undefined || v === "" || !isFinite(n) ? fb : n; }
    function int(v, fb) { return Math.round(num(v, fb)); }
    function str(v, fb) { return v === null || v === undefined ? (fb || "") : String(v); }
    function bool(v, fb) { return v === undefined || v === null ? fb : !!v; }
    function optNum(v) { var n = Number(v); return v === null || v === undefined || v === "" || !isFinite(n) ? null : Math.max(0, n); }

    function fraction(level, maxLevel) {
        var max = Math.max(2, maxLevel | 0), l = Math.max(1, Math.min(max, Number(level) || 1));
        return (l - 1) / (max - 1);
    }
    function lerp(a1, aMax, level, maxLevel) { return a1 + (aMax - a1) * fraction(level, maxLevel); }
    function lerpInt(a1, aMax, level, maxLevel) { var v = Math.round(lerp(a1, aMax, level, maxLevel)); return v <= 0 ? 0 : v; }
    function autoMax(v) { return Math.max(0, Number(v) || 0) * DEFAULT_MULTIPLE; }
    /** LevelScale.roll: both ends of the range interpolated, then a uniform roll between them. */
    function roll(lo1, hi1, loM, hiM, level, maxLevel) {
        var a = lerpInt(Math.min(lo1, hi1), Math.min(loM, hiM), level, maxLevel), b = lerpInt(Math.max(lo1, hi1), Math.max(loM, hiM), level, maxLevel);
        var lo = Math.min(a, b), hi = Math.max(a, b);
        if (hi <= 0) return 0;
        if (hi <= lo) return lo;
        return lo + Math.floor(Math.random() * (hi - lo + 1));
    }

    // ---- CustomDrop ----
    function drop(d) {
        d = d || {};
        return { itemId: str(d.itemId, "minecraft:diamond"), minCount: int(d.minCount, 1), maxCount: int(d.maxCount, 1),
            chance: Math.max(0, Math.min(100, num(d.chance, 100))), nbt: str(d.nbt, "") };
    }

    // ---- NpcSpawnConfig (nullable anchors stay null = auto, levelScaling null = on, as in DMZR's JSON) ----
    function npc(c) {
        c = c || {};
        var o = {
            entityTypeId: str(c.entityTypeId, DEFAULT_ENTITY) || DEFAULT_ENTITY, displayName: str(c.displayName),
            maxHealth: Math.max(1, num(c.maxHealth, 20)), attackDamage: Math.max(0, num(c.attackDamage, 3)), moveSpeed: Math.max(0, num(c.moveSpeed, 0.25)),
            defense: Math.max(0, num(c.defense, 0)),
            kiAttack: int(c.kiAttack, 0), moveset: Math.max(0, Math.min(MOVESETS.length - 1, int(c.moveset, 0))),
            aiTier: Math.max(0, Math.min(2, int(c.aiTier, 0))), kiEnabled: bool(c.kiEnabled, false), kiPower: Math.max(0, num(c.kiPower, 0)),
            behavior: Math.max(0, Math.min(BEHAVIORS.length - 1, int(c.behavior, 0))), scale: num(c.scale, 1) > 0 ? num(c.scale, 1) : 1,
            modelId: str(c.modelId), rgModelId: str(c.rgModelId),
            aggroRange: num(c.aggroRange, 0) > 0 ? num(c.aggroRange, 0) : DEFAULT_AGGRO_RANGE,
            maxSpawns: Math.max(1, int(c.maxSpawns, 6)), cooldownTicks: Math.max(1, int(c.cooldownTicks, 200)),
            tpMin: Math.max(0, int(c.tpMin, 0)), tpMax: Math.max(0, int(c.tpMax, 0)), balMin: Math.max(0, int(c.balMin, 0)), balMax: Math.max(0, int(c.balMax, 0)),
            levelScaling: c.levelScaling === false ? false : null,
            scaleMaxLevel: c.scaleMaxLevel === null || c.scaleMaxLevel === undefined || int(c.scaleMaxLevel, DEFAULT_MAX_LEVEL) === DEFAULT_MAX_LEVEL ? null : Math.max(2, int(c.scaleMaxLevel, 2)),
            tpMinAtMax: optNum(c.tpMinAtMax), tpMaxAtMax: optNum(c.tpMaxAtMax), balMinAtMax: optNum(c.balMinAtMax), balMaxAtMax: optNum(c.balMaxAtMax),
            maxHealthAtMax: optNum(c.maxHealthAtMax), attackDamageAtMax: optNum(c.attackDamageAtMax), kiPowerAtMax: optNum(c.kiPowerAtMax), defenseAtMax: optNum(c.defenseAtMax),
            killCommands: str(c.killCommands), drops: (c.drops || []).filter(function (d) { return d; }).map(drop), vanillaDrops: bool(c.vanillaDrops, false)
        };
        // pre-merge ids (sdu:...) and the retired npc id, as DMZR's sanitize() does
        if (o.entityTypeId.indexOf("sdu:") === 0) o.entityTypeId = "dmz_ragnarok:" + o.entityTypeId.substring(4);
        if (o.entityTypeId === "dmz_ragnarok:npc") o.entityTypeId = DEFAULT_ENTITY;
        return o;
    }
    function scales(c) { return c.levelScaling !== false; }
    function maxLevel(c) { return c.scaleMaxLevel === null || c.scaleMaxLevel === undefined ? DEFAULT_MAX_LEVEL : Math.max(2, c.scaleMaxLevel); }
    function atMax(c, key) { var v = c[key + "AtMax"]; return v === null || v === undefined ? autoMax(c[key]) : v; }
    /** The stats a config gives at a level (level 1 values when it does not scale). */
    function statsAt(c, level) {
        if (!scales(c)) return { hp: c.maxHealth, dmg: c.attackDamage, def: c.defense, ki: c.kiPower };
        var m = maxLevel(c);
        return { hp: Math.max(1, lerp(c.maxHealth, atMax(c, "maxHealth"), level, m)), dmg: Math.max(0, lerp(c.attackDamage, atMax(c, "attackDamage"), level, m)),
            def: Math.max(0, lerp(c.defense, atMax(c, "defense"), level, m)), ki: Math.max(0, lerp(c.kiPower, atMax(c, "kiPower"), level, m)) };
    }
    /** A kill's TP and balance for a killer of this level. */
    function rewardsAt(c, level) {
        if (!scales(c)) return { tp: roll(c.tpMin, c.tpMax, c.tpMin, c.tpMax, 1, 2), bal: roll(c.balMin, c.balMax, c.balMin, c.balMax, 1, 2) };
        var m = maxLevel(c);
        return { tp: roll(c.tpMin, c.tpMax, atMax(c, "tpMin"), atMax(c, "tpMax"), level, m), bal: roll(c.balMin, c.balMax, atMax(c, "balMin"), atMax(c, "balMax"), level, m) };
    }

    // ---- PolygonXZ ----
    /** Even-odd ray cast: is the point inside the polygon [x0, z0, ...]? */
    function inPoly(pts, x, z) {
        var n = pts.length >> 1, inside = false;
        for (var i = 0, j = n - 1; i < n; j = i++) {
            var xi = pts[i * 2], zi = pts[i * 2 + 1], xj = pts[j * 2], zj = pts[j * 2 + 1];
            if ((zi > z) !== (zj > z) && x < (xj - xi) * (z - zi) / (zj - zi) + xi) inside = !inside;
        }
        return inside;
    }
    function bounds(pts) {
        var b = [Infinity, Infinity, -Infinity, -Infinity];
        for (var i = 0; i + 1 < pts.length; i += 2) {
            b[0] = Math.min(b[0], pts[i]); b[1] = Math.min(b[1], pts[i + 1]); b[2] = Math.max(b[2], pts[i]); b[3] = Math.max(b[3], pts[i + 1]);
        }
        return b;
    }
    function area(pts) {
        var a = 0, n = pts.length >> 1;
        for (var i = 0; i < n; i++) { var j = (i + 1) % n; a += pts[i * 2] * pts[j * 2 + 1] - pts[j * 2] * pts[i * 2 + 1]; }
        return Math.abs(a) / 2;
    }
    function cleanPoints(p) {
        var out = [];
        (p || []).forEach(function (v, i) { out.push(Math.round(Number(v) || 0)); });
        if (out.length % 2) out.pop();
        // drop consecutive duplicates and a closing duplicate of the first point
        var res = [];
        for (var i = 0; i + 1 < out.length; i += 2) {
            var k = res.length;
            if (k >= 2 && res[k - 2] === out[i] && res[k - 1] === out[i + 1]) continue;
            res.push(out[i], out[i + 1]);
        }
        if (res.length >= 4 && res[0] === res[res.length - 2] && res[1] === res[res.length - 1]) res.splice(res.length - 2, 2);
        return res;
    }

    // ---- NpcRegion ----
    function idOf(name) { return String(name || "").trim().toLowerCase().replace(/[^a-z0-9_\-]+/g, "_").replace(/^_+|_+$/g, "").substring(0, 48); }
    function region(r) {
        r = r || {};
        var o = {
            id: idOf(r.id || r.name) || "region", name: str(r.name, r.id || "region"), dim: str(r.dim, "minecraft:overworld") || "minecraft:overworld",
            shapes: [], minY: int(r.minY, -64), maxY: int(r.maxY, 320),
            title: str(r.title), description: str(r.description), difficulty: str(r.difficulty),
            showTitle: bool(r.showTitle, true), showHud: bool(r.showHud, true),
            color: /^#[0-9a-fA-F]{6}$/.test(str(r.color)) ? str(r.color) : "",
            eventOnly: bool(r.eventOnly, false), enabled: bool(r.enabled, true),
            tpFalloffLevel: Math.max(0, int(r.tpFalloffLevel, 0)), tpFalloffRange: int(r.tpFalloffRange, 20) > 0 ? int(r.tpFalloffRange, 20) : 20,
            npcs: []
        };
        (r.shapes || []).forEach(function (s) {
            var pts = cleanPoints(s && s.points ? s.points : s);
            if (pts.length >= 6) o.shapes.push({ points: pts });
        });
        if (o.maxY < o.minY) { var t = o.minY; o.minY = o.maxY; o.maxY = t; }
        var list = (r.npcs || []).slice();
        if (r.config) list.push(r.config);              // DMZR's pre multi-NPC single config
        o.npcs = list.filter(function (c) { return c; }).map(npc);
        return o;
    }
    /** The exact XZ test on a position (an entity), then the Y band. */
    function contains(r, dim, x, y, z) {
        if (!r || r.dim !== dim || y < r.minY || y > r.maxY + 1) return false;
        for (var i = 0; i < r.shapes.length; i++) {
            var p = r.shapes[i].points, b = r.shapes[i].b || (r.shapes[i].b = bounds(p));
            if (x < b[0] || x > b[2] || z < b[1] || z > b[3]) continue;
            if (inPoly(p, x, z)) return true;
        }
        return false;
    }
    /** Whether the block column (bx, bz) is inside (its centre is). */
    function containsColumn(r, bx, bz) {
        for (var i = 0; i < r.shapes.length; i++) if (inPoly(r.shapes[i].points, bx + 0.5, bz + 0.5)) return true;
        return false;
    }
    function regionBounds(r) {
        var b = [Infinity, Infinity, -Infinity, -Infinity];
        r.shapes.forEach(function (s) { var sb = bounds(s.points); b[0] = Math.min(b[0], sb[0]); b[1] = Math.min(b[1], sb[1]); b[2] = Math.max(b[2], sb[2]); b[3] = Math.max(b[3], sb[3]); });
        return b;
    }
    function regionArea(r) { var a = 0; r.shapes.forEach(function (s) { a += area(s.points); }); return Math.round(a); }
    /** A point inside the first shape (for teleports): the bounds centre if inside, else a scanline middle. */
    function interior(r) {
        var s = r.shapes[0];
        if (!s) return null;
        var b = bounds(s.points), cx = (b[0] + b[2]) / 2, cz = (b[1] + b[3]) / 2;
        if (inPoly(s.points, cx, cz)) return { x: cx, z: cz };
        var xs = [], p = s.points, n = p.length >> 1;
        for (var i = 0, j = n - 1; i < n; j = i++) {
            var zi = p[i * 2 + 1], zj = p[j * 2 + 1];
            if ((zi > cz) !== (zj > cz)) xs.push((p[j * 2] - p[i * 2]) * (cz - zi) / (zj - zi) + p[i * 2]);
        }
        xs.sort(function (a, b) { return a - b; });
        return xs.length >= 2 ? { x: (xs[0] + xs[1]) / 2, z: cz } : { x: p[0], z: p[1] };
    }

    /**
     * A region from DMZ Ragnarok's npcregions.json: a freeform box keeps its outline, a cuboid becomes a rectangle;
     * Y spans every box. Spawn configs, display options and the TP falloff carry over field for field.
     */
    function fromDmzr(j) {
        if (!j || typeof j !== "object") return null;
        var boxes = (j.boxes && j.boxes.length) ? j.boxes : [{ minX: j.minX, minY: j.minY, minZ: j.minZ, maxX: j.maxX, maxY: j.maxY, maxZ: j.maxZ }];
        var shapes = [], minY = Infinity, maxY = -Infinity;
        boxes.forEach(function (b) {
            if (!b) return;
            minY = Math.min(minY, int(b.minY, -64)); maxY = Math.max(maxY, int(b.maxY, 320));
            if (b.outline && b.outline.length >= 6) shapes.push({ points: b.outline.slice() });
            else {
                var x1 = int(b.minX, 0), z1 = int(b.minZ, 0), x2 = int(b.maxX, 0) + 1, z2 = int(b.maxZ, 0) + 1;
                shapes.push({ points: [x1, z1, x2, z1, x2, z2, x1, z2] });
            }
        });
        var r = {}; for (var k in j) r[k] = j[k];
        r.shapes = shapes;
        r.minY = isFinite(minY) ? minY : -64; r.maxY = isFinite(maxY) ? maxY : 320;
        return region(r);
    }

    return { DEFAULT_MAX_LEVEL: DEFAULT_MAX_LEVEL, DEFAULT_MULTIPLE: DEFAULT_MULTIPLE, DEFAULT_ENTITY: DEFAULT_ENTITY,
        MOVESETS: MOVESETS, AI_TIERS: AI_TIERS, BEHAVIORS: BEHAVIORS,
        num: num, int: int, fraction: fraction, lerp: lerp, roll: roll, autoMax: autoMax,
        drop: drop, npc: npc, scales: scales, maxLevel: maxLevel, atMax: atMax, statsAt: statsAt, rewardsAt: rewardsAt,
        inPoly: inPoly, bounds: bounds, area: area, cleanPoints: cleanPoints,
        idOf: idOf, region: region, contains: contains, containsColumn: containsColumn, regionBounds: regionBounds, regionArea: regionArea, interior: interior,
        fromDmzr: fromDmzr };
})();
