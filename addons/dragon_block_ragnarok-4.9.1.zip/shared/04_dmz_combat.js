// =====================================================================================
//  DMZ melee data (data/dragonminez/weapon_attributes/fist.json, PlayerAttackHelper, CombatConfig)
//  shared by the client (input, animations) and the server (damage, validation).
// =====================================================================================
var DMZ_COMBAT = (function () {
    // bare-hand combo: hitbox shape, upswing (share of the animation before the hit), damage x, animation
    var FIST = [
        { shape: "forward", upswing: 0.4, damage: 1, anim: "combat.one_handed_punch_right" },
        { shape: "forward", upswing: 0.4, damage: 1, anim: "combat.one_handed_punch_right" },
        { shape: "forward", upswing: 0.4, damage: 1, anim: "combat.one_handed_punch_right" },
        { shape: "horizontal", upswing: 0.7, damage: 1, anim: "combat.lowkick_right" },
        { shape: "vertical", upswing: 0.5, damage: 1, anim: "combat.one_handed_uppercut_right" },
        { shape: "vertical", upswing: 0.6, damage: 1, anim: "combat.gutkick_right" },
        // only with Ki Infusion active and level >= 5
        { shape: "vertical", upswing: 0.5, damage: 1.5, anim: "combat.one_handed_uppercut_right", infusion: true }
    ];
    var CFG = {
        attackIntervalCap: 2, comboResetExtra: 30, staminaRatio: 0.083,
        parryWindowMs: 150, parryStaminaPenalty: 2.0, parryPenaltyMs: 4000,
        poiseDamageMult: 0.25, blockStaminaCost: 0.25, blockCap: 0.65, blockMin: 0.05,
        guardBreakStun: 60, poiseRegenCooldown: 100, reblockMs: 250
    };
    // Ki weapons (CombatConfig.kiWeaponsConfig + the weapon_attributes combo each one swings with: sword, scythe, trident).
    // damage = baseDamage + kiDamage x kiScalingDamage x (Ki Manipulation level x 0.1); ki per hit =
    // round(baseKiCost + baselineFormDrain x kiScalingCost); attackSpeed is added to the attack speed attribute.
    // forcedColor "#FFFFFF" = use the ki (aura) colour. Used by scripts/79_dmz_kiweapon.js and client/scripts/42_combat.js.
    var KI_WEAPON_ORDER = ["blade", "clawlance", "scythe"];
    var KI_WEAPONS = {
        blade: { baseDamage: 0, kiScalingDamage: 0.25, baseKiCost: 0, kiScalingCost: 0.075, attackSpeed: -2.4, forcedColor: "#FFFFFF", attacks: [
            { damage: 1, anim: "combat.one_handed_slash_horizontal_right_1", sound: "sword_slash" },
            { damage: 1, anim: "combat.one_handed_slash_horizontal_right_2", sound: "sword_slash" },
            { damage: 1, anim: "combat.one_handed_stab_right", sound: "sword_slash", pitch: 1.2 }] },
        scythe: { baseDamage: 0, kiScalingDamage: 0.45, baseKiCost: 0, kiScalingCost: 0.105, attackSpeed: -2.8, forcedColor: "#FFFFFF",
            pose: "combat.pose_two_handed_scythe", attacks: [
            { damage: 1, anim: "combat.two_handed_slash_horizontal_right", sound: "scythe_slash" },
            { damage: 1, anim: "combat.two_handed_slash_horizontal_left", sound: "scythe_slash" }] },
        clawlance: { baseDamage: 0, kiScalingDamage: 0.65, baseKiCost: 0, kiScalingCost: 0.175, attackSpeed: -2.6, forcedColor: "#FFFFFF",
            pose: "combat.pose_two_handed_polearm", attacks: [
            { damage: 1, anim: "combat.one_handed_stab_right", sound: "spear_stab" }] }
    };
    function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }
    /** The attacks usable right now (infusion step only when it's active). */
    function combo(infusion) { return FIST.filter(function (a) { return !a.infusion || infusion; }); }
    function attackFor(count, infusion) { var c = combo(infusion); return c[count % c.length]; }
    /** cooldownTicks, animSpeed, animTicks for an attack speed (vanilla attribute, 4 = fist). */
    function timing(attackSpeed) {
        var cd = clamp(Math.max(20 / Math.max(0.25, attackSpeed), CFG.attackIntervalCap), 2, 200);
        var speed = clamp(12 / cd, 0.55, 1.35);
        return { cooldown: cd, speed: speed, animTicks: Math.max(8, Math.round(12 / speed)) };
    }
    return { FIST: FIST, CFG: CFG, combo: combo, attackFor: attackFor, timing: timing, KI_WEAPONS: KI_WEAPONS, KI_WEAPON_ORDER: KI_WEAPON_ORDER };
})();
