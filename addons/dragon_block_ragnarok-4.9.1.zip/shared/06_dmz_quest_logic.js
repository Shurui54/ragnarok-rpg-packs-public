// =====================================================================================
//  DMZ quest rules shared by the server (scripts/47_dmz_quests.js) and the quest screen:
//  quest keys, unlock prerequisites, saga order, node status, objective counts, rewards
//  (QuestAvailabilityChecker, PlayerQuestData, QuestTreeScreen.computeNodeStatus).
//
//  A "view" of a player's quest state:
//    { q: { key: { s: 1 accepted | 2 completed | 3 failed, p: [progress], c: [claimed reward
//      indices], d: difficulty } }, d: chosen difficulty, resets: story resets }
//  plus skill(id) -> DMZ skill level, level -> character level, alignment.
// =====================================================================================
var DMZ_QL = (function () {
    var D = DMZ_QUEST_DATA;
    var BY_KEY = {}, SAGAS = {}, SAGA_LIST = D.sagas, SIDE = D.side;
    var ACCEPTED = 1, COMPLETED = 2, FAILED = 3;
    // DMZ's own sagas / side quests, kept so custom ones (the saga editor) can override and be removed again
    var BASE_SAGAS = D.sagas.slice(), BASE_SIDE = D.side.slice();
    var CUSTOM = { sagas: [], side: [], version: 0 };

    function index() {
        Object.keys(BY_KEY).forEach(function (k) { delete BY_KEY[k]; });
        Object.keys(SAGAS).forEach(function (k) { delete SAGAS[k]; });
        D.sagas.forEach(function (s) {
            SAGAS[s.id] = s;
            s.quests.forEach(function (q, i) { var k = s.id + ":" + q.id; BY_KEY[k] = { key: k, quest: q, saga: s, index: i, side: false }; });
        });
        D.side.forEach(function (q) { BY_KEY[q.id] = { key: q.id, quest: q, saga: null, index: -1, side: true }; });
    }
    index();

    // ---- custom sagas from the saga editor (scripts/48_dbr_saga_editor.js, client/scripts/69_saga_editor.js) ----
    // Stored as "bundles" in DMZ Ragnarok's editor shape: { id, name, prev, prereqSaga, prereqQuest, quests: [DMZ quest
    // json + sdu_branch / sdu_time_limit / sdu_repeat_interval / sdu_consume_items] }. Branch quests become DMZ side
    // quests "<saga>_b<id>" hanging off their parent (SagaData.Quest.toSideQuestJson), the rest the saga's main line.
    function clone(o) { return o === undefined ? undefined : JSON.parse(JSON.stringify(o)); }
    function cleanId(s, fallback) {
        var v = String(s === undefined || s === null ? "" : s).toLowerCase().replace(/[^a-z0-9_]/g, "_").replace(/^_+|_+$/g, "").substring(0, 48);
        return v || fallback || "custom";
    }
    function int(v, def) { var n = parseInt(v, 10); return isNaN(n) ? def : n; }
    function num(v, def) { var n = Number(v); return isNaN(n) ? def : n; }
    function str(v, def, max) { return v === undefined || v === null ? def : String(v).substring(0, max || 512); }
    function group(g) {
        if (!g || typeof g !== "object" || !g.conditions || !g.conditions.length) return { operator: "AND", conditions: [] };
        return { operator: g.operator === "OR" ? "OR" : "AND", conditions: g.conditions.filter(function (c) { return c && typeof c === "object"; }).slice(0, 64) };
    }
    function normalizeQuest(q, side) {
        q = clone(q && typeof q === "object" ? q : {});
        var o = q;
        o.id = side ? cleanId(q.id, "custom_sidequest") : Math.max(1, int(q.id, 1));
        o.title = str(q.title, side ? "New Side Quest" : "New Quest", 256);
        o.description = str(q.description, "", 2048);
        o.parallel_objectives = !!q.parallel_objectives;
        o.party_scaling = q.party_scaling !== false;
        o.secret = !!q.secret;
        o.claim_mode = q.claim_mode === "NPC_ONLY" ? "NPC_ONLY" : "TREE_OR_NPC";
        o.sdu_time_limit = Math.max(0, int(q.sdu_time_limit, 0));
        o.sdu_repeat_interval = Math.max(0, int(q.sdu_repeat_interval, 0));
        o.sdu_consume_items = !!q.sdu_consume_items;
        if (side) {
            o.type = q.type === "DAILY" || q.type === "EVENT" ? q.type : "SIDEQUEST";
            o.category = str(q.category, "general", 64);
            o.quest_giver = q.quest_giver ? str(q.quest_giver, "", 64) : null;
            o.turn_in = q.turn_in ? str(q.turn_in, "", 64) : null;
            delete o.sdu_branch;
        } else o.sdu_branch = !!q.sdu_branch;
        o.prerequisites = group(q.prerequisites);
        o.requirements = group(q.requirements);
        // a SAGA_QUEST start requirement is a second linear gate that breaks branching (SagaData.Quest.fromJson)
        o.requirements.conditions = o.requirements.conditions.filter(function (c) { return c.type !== "SAGA_QUEST"; });
        o.objectives = (Array.isArray(q.objectives) ? q.objectives : []).filter(function (x) { return x && typeof x === "object" && x.type; }).slice(0, 32);
        o.rewards = (Array.isArray(q.rewards) ? q.rewards : []).filter(function (x) { return x && typeof x === "object" && x.type; }).slice(0, 32);
        return o;
    }
    function normalizeSaga(b) {
        b = b && typeof b === "object" ? b : {};
        var id = cleanId(b.id, "custom_saga"), seen = {};
        var quests = (Array.isArray(b.quests) ? b.quests : []).slice(0, 256).map(function (q) { return normalizeQuest(q, false); })
            .filter(function (q) { if (seen[q.id]) return false; seen[q.id] = 1; return true; });
        return { v: 1, id: id, name: str(b.name, id, 128), prev: b.prev ? cleanId(b.prev, "") : "",
            prereqSaga: b.prereqSaga ? cleanId(b.prereqSaga, "") : "", prereqQuest: Math.max(0, int(b.prereqQuest, 0)), quests: quests };
    }
    function normalizeSide(q) { return normalizeQuest(q, true); }

    function branchSid(sagaId, q) { return sagaId + "_b" + q.id; }
    function parentId(q, sagaId) {
        var conds = (q.prerequisites && q.prerequisites.conditions) || [];
        for (var i = 0; i < conds.length; i++) if (conds[i].type === "SAGA_QUEST" && (!conds[i].sagaId || conds[i].sagaId === sagaId)) return int(conds[i].questId, 0);
        return 0;
    }
    /** bundle -> { saga: the runtime saga (main line), side: [branch quests as side quests] } */
    function compileSaga(b) {
        b = normalizeSaga(b);
        var byId = {}, folder = "saga_" + b.id;
        b.quests.forEach(function (q) { byId[q.id] = q; });
        function link(q) {
            var pid = parentId(q, b.id), parent = byId[pid];
            if (!parent || parent === q) return null;
            return parent.sdu_branch ? { type: "QUEST", questId: branchSid(b.id, parent) } : { type: "SAGA_QUEST", sagaId: b.id, questId: parent.id };
        }
        function others(q) { return q.prerequisites.conditions.filter(function (c) { return !(c.type === "SAGA_QUEST" && (!c.sagaId || c.sagaId === b.id)); }); }
        var main = [], side = [];
        b.quests.forEach(function (q) {
            var r = clone(q), l = link(q);
            r.category = folder; r.custom = true; r.sdu_saga = b.id;
            r.prerequisites = { operator: "AND", conditions: (l ? [l] : []).concat(others(q)) };
            if (!r.prerequisites.conditions.length) delete r.prerequisites;
            if (q.sdu_branch) {
                r.id = branchSid(b.id, q); r.type = "SIDEQUEST"; r.sdu_branch_id = q.id; r.quest_giver = null; r.turn_in = null;
                side.push(r);
            } else { r.type = "SAGA"; main.push(r); }
        });
        main.sort(function (a, c) { return a.id - c.id; });
        var saga = { id: b.id, name: b.name, label: b.name, prev: b.prev, quests: main, custom: true };
        if (b.prereqSaga && b.prereqQuest) { saga.sdu_prereq_saga = b.prereqSaga; saga.sdu_prereq_quest = b.prereqQuest; }
        return { saga: saga, side: side };
    }
    /** Replace the custom sagas / side quests (a custom saga or side quest with a DMZ id overrides DMZ's). */
    function setCustom(bundles, sides) {
        CUSTOM.sagas = (bundles || []).map(normalizeSaga);
        CUSTOM.side = (sides || []).map(normalizeSide);
        CUSTOM.version++;
        var compiled = CUSTOM.sagas.map(compileSaga), over = {}, overSide = {};
        compiled.forEach(function (c) { over[c.saga.id] = c.saga; });
        var extraSide = [];
        compiled.forEach(function (c) { c.side.forEach(function (q) { overSide[q.id] = q; extraSide.push(q); }); });
        CUSTOM.side.forEach(function (q) { var r = clone(q); r.custom = true; overSide[r.id] = r; extraSide.push(r); });
        D.sagas.length = 0;
        BASE_SAGAS.forEach(function (s) { D.sagas.push(over[s.id] || s); delete over[s.id]; });
        compiled.forEach(function (c) { if (over[c.saga.id]) D.sagas.push(c.saga); });
        D.side.length = 0;
        BASE_SIDE.forEach(function (q) { if (!overSide[q.id]) D.side.push(q); });
        extraSide.forEach(function (q) { D.side.push(q); });
        index();
        return CUSTOM.version;
    }
    /** A DMZ saga as an editor bundle (to override it). */
    function bundleOf(saga) {
        return normalizeSaga({ id: saga.id, name: saga.label || saga.name, prev: saga.prev, quests: clone(saga.quests) });
    }

    // Difficulty.java: enemy hp / damage, story TP, quest rewards
    var DIFFICULTY = {
        EASY: { hp: 0.75, dmg: 0.5, tp: 1.25, reward: 1.0, tier: 1 },
        NORMAL: { hp: 1.0, dmg: 1.0, tp: 1.0, reward: 1.0, tier: 2 },
        HARD: { hp: 2.0, dmg: 1.5, tp: 1.25, reward: 1.25, tier: 3 }
    };

    function entry(key) { return BY_KEY[key] || null; }
    function rec(view, key) { return (view && view.q && view.q[key]) || null; }
    function status(view, key) { var r = rec(view, key); return r ? r.s : 0; }
    function completed(view, key) { return status(view, key) === COMPLETED; }
    function progress(view, key, i) { var r = rec(view, key); return r && r.p && typeof r.p[i] === "number" ? r.p[i] : 0; }
    function claimed(view, key, i) { var r = rec(view, key); return !!(r && r.c && r.c.indexOf(i) >= 0); }
    function questDifficulty(view, key) { var r = rec(view, key); return (r && r.d) || (view && view.d) || "NORMAL"; }

    /** QuestObjective.getRequired (solo party). */
    function required(o) {
        switch (o.type) {
            case "KILL": case "ITEM": case "DELIVER": return Math.max(1, o.count || 1);
            case "SKILL": return Math.max(1, o.level || 1);
            case "SURVIVE_WAVES": return Math.max(1, o.waves || 1);
            default: return 1;
        }
    }

    function isPositional(type) { return type === "BIOME" || type === "DIMENSION" || type === "STRUCTURE" || type === "TIME"; }

    /** One condition. positional(cond) answers BIOME/DIMENSION/STRUCTURE/TIME (null = unknown -> passes). */
    function evalCond(c, view, positional) {
        if (!c) return false;
        if (c.conditions) return evalGroup(c, view, positional);
        switch (c.type) {
            case "SAGA_QUEST": return completed(view, c.sagaId + ":" + c.questId);
            case "QUEST": return completed(view, c.questId);
            case "LEVEL": return (view.level || 1) >= (c.minLevel || 0);
            case "SKILL": return view.skill(c.skill) >= (c.minLevel || 0);
            case "ALIGNMENT":
                var a = typeof view.alignment === "number" ? view.alignment : 100;
                return (c.min === undefined || a >= c.min) && (c.max === undefined || a <= c.max);
            case "RACE": return String(c.race || "").toLowerCase() === String(view.race || "");
            case "CLASS": return String(c["class"] || "").toLowerCase() === String(view.cls || "");
            default:
                if (isPositional(c.type)) { var r = positional ? positional(c) : null; return r === null || r === undefined ? true : !!r; }
                return false;
        }
    }
    function evalGroup(g, view, positional) {
        if (!g || !g.conditions || !g.conditions.length) return true;
        if (g.operator === "OR") { for (var i = 0; i < g.conditions.length; i++) if (evalCond(g.conditions[i], view, positional)) return true; return false; }
        for (var j = 0; j < g.conditions.length; j++) if (!evalCond(g.conditions[j], view, positional)) return false;
        return true;
    }
    /** First failing condition of a group (for blocker text). */
    function firstFailing(g, view, positional) {
        if (!g || !g.conditions) return null;
        var first = null;
        for (var i = 0; i < g.conditions.length; i++) {
            var c = g.conditions[i];
            var f = c.conditions ? firstFailing(c, view, positional) : (evalCond(c, view, positional) ? null : c);
            if (g.operator !== "OR") { if (f) return f; }
            else { if (!f) return null; if (!first) first = f; }
        }
        return first;
    }

    function isAvailable(q, view) { return !q.prerequisites || evalGroup(q.prerequisites, view, null); }
    function isSagaQuestAvailable(e, view) {
        if (e.index === 0 && e.saga.custom && !sagaUnlocked(e.saga, view)) return false;
        if (e.index > 0) {
            var prev = e.saga.quests[e.index - 1];
            if (!completed(view, e.saga.id + ":" + prev.id)) return false;
        }
        return isAvailable(e.quest, view);
    }
    function startable(e, view) {
        var s = status(view, e.key);
        if (s === ACCEPTED) return false;
        if (s === COMPLETED && !(isRepeatable(e.quest) && repeatReady(view, e))) return false;
        return e.side ? isAvailable(e.quest, view) : isSagaQuestAvailable(e, view);
    }
    /** Seconds before a completed quest can be taken again, or -1 = one-shot (sdu_repeat_interval, DMZ repeatable / DAILY / EVENT). */
    function repeatSeconds(q) {
        var s = Number(q.sdu_repeat_interval) || 0;
        if (s > 0) return s;
        if (q.repeatable) return q.repeat_cooldown_seconds || 0;
        if (q.type === "DAILY" || q.type === "EVENT") return 0;
        return -1;
    }
    function isRepeatable(q) { return repeatSeconds(q) >= 0; }
    function repeatReady(view, e) {
        var r = rec(view, e.key);
        if (!r || !r.at) return false;
        return Date.now() - r.at >= Math.max(0, repeatSeconds(e.quest)) * 1000 && !hasUnclaimed(view, e);
    }
    function repeatLeft(view, e) {
        var r = rec(view, e.key);
        if (!r || !r.at || !isRepeatable(e.quest)) return 0;
        return Math.max(0, Math.max(0, repeatSeconds(e.quest)) * 1000 - (Date.now() - r.at)) / 1000;
    }
    /** Seconds left on a timed quest (sdu_time_limit), or -1 when untimed / not running. */
    function timeLeft(view, e) {
        var r = rec(view, e.key), lim = Number(e.quest.sdu_time_limit) || 0;
        if (!r || r.s !== ACCEPTED || lim <= 0 || !r.ts) return -1;
        return Math.max(0, lim - (Date.now() - r.ts) / 1000);
    }

    function rewardUnlocked(r, diff) { return !r.difficulty || !r.difficulty.length || r.difficulty.indexOf(diff || "NORMAL") >= 0; }
    function hasUnclaimed(view, e) {
        var diff = questDifficulty(view, e.key), rw = e.quest.rewards || [];
        for (var i = 0; i < rw.length; i++) if (rewardUnlocked(rw[i], diff) && !claimed(view, e.key, i)) return true;
        return false;
    }

    /** QuestTreeScreen.computeNodeStatus: "COMPLETED" | "CLAIMABLE" | "ACTIVE" | "AVAILABLE" | "LOCKED" */
    function nodeStatus(e, view) {
        var s = status(view, e.key);
        if (s === COMPLETED) {
            if (hasUnclaimed(view, e)) return "CLAIMABLE";
            return startable(e, view) ? "AVAILABLE" : "COMPLETED";      // a repeatable quest whose cooldown is over
        }
        if (s === ACCEPTED) return "ACTIVE";
        if (s === FAILED) return "AVAILABLE";
        if (!e.side) return isSagaQuestAvailable(e, view) ? "AVAILABLE" : "LOCKED";
        return isAvailable(e.quest, view) ? "AVAILABLE" : "LOCKED";
    }

    /** QuestTreeScreen.isSagaUnlockedByPreviousCompletion */
    function sagaUnlocked(saga, view) {
        // addon gate (SagaData.prereqQuestSaga / prereqQuestId): a named quest must be done as well
        if (saga.sdu_prereq_saga && saga.sdu_prereq_quest && !completed(view, saga.sdu_prereq_saga + ":" + saga.sdu_prereq_quest)) return false;
        if (!saga.prev) return true;
        var prev = SAGAS[saga.prev];
        if (!prev) return true;
        for (var i = 0; i < saga.quests.length; i++) if (status(view, saga.id + ":" + saga.quests[i].id)) return true;
        for (var j = 0; j < prev.quests.length; j++) if (!completed(view, prev.id + ":" + prev.quests[j].id)) return false;
        return true;
    }

    /** QuestTreeLayoutHelper.belongsToSaga */
    function belongsToSaga(q, sagaId) {
        var queue = [q], visited = {};
        while (queue.length) {
            var cur = queue.shift();
            var conds = cur.prerequisites && cur.prerequisites.conditions;
            if (!conds) continue;
            for (var i = 0; i < conds.length; i++) {
                var c = conds[i];
                if (c.type === "SAGA_QUEST" && c.sagaId === sagaId) return true;
                if (c.type === "QUEST" && c.questId && !visited[c.questId]) {
                    visited[c.questId] = 1;
                    var parent = BY_KEY[c.questId];
                    if (parent && parent.side) queue.push(parent.quest);
                }
            }
        }
        return false;
    }

    /** QuestService.isTurnInTalk */
    function isTurnInTalk(q, o) { return o.type === "TALK_TO" && !!q.turn_in && String(o.npcId || "").toLowerCase() === String(q.turn_in).toLowerCase(); }
    function hasKill(q) { return q.objectives.some(function (o) { return o.type === "KILL" || o.type === "SPAR"; }); }

    /** PlayerQuestData.rewardMultiplierFor */
    function rewardMultiplier(view, key, r) {
        var m = (DIFFICULTY[questDifficulty(view, key)] || DIFFICULTY.NORMAL).reward;
        var scaled = r.type === "TPS" || r.type === "ATTRIBUTES" || r.type === "ATTRIBUTE_POINTS" || r.type === "ITEM" || r.type === "GENERIC_ITEM";
        return scaled ? m * Math.pow(0.5, (view && view.resets) || 0) : m;
    }

    return { DATA: D, BY_KEY: BY_KEY, SAGAS: SAGAS, SAGA_LIST: SAGA_LIST, SIDE: SIDE, DIFFICULTY: DIFFICULTY, ACCEPTED: ACCEPTED, COMPLETED: COMPLETED, FAILED: FAILED,
        entry: entry, rec: rec, status: status, completed: completed, progress: progress, claimed: claimed, questDifficulty: questDifficulty,
        required: required, isPositional: isPositional, evalCond: evalCond, evalGroup: evalGroup, firstFailing: firstFailing, isAvailable: isAvailable,
        isSagaQuestAvailable: isSagaQuestAvailable, startable: startable, rewardUnlocked: rewardUnlocked, hasUnclaimed: hasUnclaimed,
        nodeStatus: nodeStatus, sagaUnlocked: sagaUnlocked, belongsToSaga: belongsToSaga, isTurnInTalk: isTurnInTalk, hasKill: hasKill,
        rewardMultiplier: rewardMultiplier, repeatSeconds: repeatSeconds, isRepeatable: isRepeatable, repeatReady: repeatReady, repeatLeft: repeatLeft,
        timeLeft: timeLeft, BASE_SAGAS: BASE_SAGAS, BASE_SIDE: BASE_SIDE, CUSTOM: CUSTOM, setCustom: setCustom, compileSaga: compileSaga,
        normalizeSaga: normalizeSaga, normalizeSide: normalizeSide, bundleOf: bundleOf, cleanId: cleanId, clone: clone };
})();
