// =====================================================================================
//  19_dbr_ragnarok_combat.js - DMZ Ragnarok's combat maths, run the same on both sides
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0): DashMode, DashPath (the curve a dash flies: the server
//  plans it, the dasher's computer flies it from the same numbers) and ClashRhythm (the melee
//  clash rhythm chart: both fighters build the same chart from one seed, the server checks
//  the scores against it). Vectors are plain {x, y, z}.
// =====================================================================================
var DBR_RC = (function () {
    // ---- vectors ----
    function V(x, y, z) { return { x: x, y: y, z: z }; }
    function add(a, b) { return V(a.x + b.x, a.y + b.y, a.z + b.z); }
    function sub(a, b) { return V(a.x - b.x, a.y - b.y, a.z - b.z); }
    function mul(a, k) { return V(a.x * k, a.y * k, a.z * k); }
    function dot(a, b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
    function cross(a, b) { return V(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x); }
    function lenSq(a) { return dot(a, a); }
    function len(a) { return Math.sqrt(dot(a, a)); }
    function norm(a) { var l = len(a); return l < 1e-9 ? V(0, 0, 0) : mul(a, 1 / l); }
    function dist(a, b) { return len(sub(a, b)); }
    var UP = V(0, 1, 0);

    // ---- DashMode: W/none straight (the only one that hits and stops, the only one that clashes), A left arc,
    //      D right arc, S over the top ----
    var MODE = { STRAIGHT: 0, LEFT_ARC: 1, RIGHT_ARC: 2, OVER_TOP: 3 };
    function stopsOnContact(m) { return m === MODE.STRAIGHT; }
    function canClash(m) { return m === MODE.STRAIGHT; }
    function modeById(id) { id = Math.floor(Number(id) || 0); return id < 0 || id > 3 ? MODE.STRAIGHT : id; }

    // ---- DashPath ----
    var ROUTE_SPEED = 3.5, MIN_TRAVEL_TICKS = 5, MAX_TRAVEL_TICKS = 30, CONTACT_STANDOFF = 1.85, OVER_TOP_HEIGHT = 4.5;
    /** Quadratic curve from -> to bent toward control; t clamped to 0..1. */
    function sample(from, control, to, t) {
        var u = Math.max(0, Math.min(1, t)), inv = 1 - u, a = inv * inv, b = 2 * inv * u, c = u * u;
        return V(a * from.x + b * control.x + c * to.x, a * from.y + b * control.y + c * to.y, a * from.z + b * control.z + c * to.z);
    }
    // the dasher's left (-1) or right (+1) as they close in, flattened
    function flank(approach, sign) {
        var travel = V(-approach.x, 0, -approach.z);
        if (lenSq(travel) < 1e-6) return approach;
        var right = cross(norm(travel), UP);
        if (lenSq(right) < 1e-6) return approach;
        return mul(norm(right), sign);
    }
    // straight behind the target by its own body facing
    function back(approach, facing) {
        if (!facing || lenSq(facing) < 1e-6) return approach;
        var flat = V(-facing.x, 0, -facing.z);
        return lenSq(flat) < 1e-6 ? approach : norm(flat);
    }
    /** Which side of the target the dash finishes on, decided once when it is planned. */
    function pinnedSide(sourceEye, targetEye, targetFacing, mode) {
        var approach = sub(sourceEye, targetEye);
        approach = lenSq(approach) < 1e-6 ? V(0, 0, 1) : norm(approach);
        if (mode === MODE.LEFT_ARC) return flank(approach, -1);
        if (mode === MODE.RIGHT_ARC) return flank(approach, 1);
        if (mode === MODE.OVER_TOP) return back(approach, targetFacing);
        return approach;
    }
    /** Where the dash ends, eye to eye, recomputed every tick; radius / halfHeight: half the target's width / height. */
    function destination(sourceEye, targetEye, targetFacing, radius, halfHeight, mode, side) {
        var standoff = CONTACT_STANDOFF + Math.max(0, radius);
        var approach = sub(sourceEye, targetEye);
        approach = lenSq(approach) < 1e-6 ? null : norm(approach);
        if (mode === MODE.STRAIGHT && approach) side = approach;
        else if (mode === MODE.OVER_TOP) side = back(approach || side, targetFacing);
        if (!side || lenSq(side) < 1e-6) side = V(0, 0, 1);
        var point = add(targetEye, mul(norm(side), standoff));
        return mode === MODE.OVER_TOP ? add(point, V(0, Math.max(0, halfHeight) * 0.5, 0)) : point;
    }
    /** The body facing as a flat unit vector from a yaw in degrees. */
    function facing(yaw) { var r = yaw * Math.PI / 180; return V(-Math.sin(r), 0, Math.cos(r)); }
    /** The curve's one control point: the midpoint for a straight dash, placed around the target for the arcs. */
    function control(origin, dest, targetEye, side, mode, radius, halfHeight) {
        if (mode === MODE.STRAIGHT) return mul(add(origin, dest), 0.5);
        var standoff = CONTACT_STANDOFF + Math.max(0, radius), trip = dist(origin, dest);
        var approach = sub(origin, targetEye);
        approach = V(approach.x, 0, approach.z);
        approach = lenSq(approach) < 1e-6 ? V(0, 0, 1) : norm(approach);
        if (mode === MODE.OVER_TOP)
            return add(add(targetEye, mul(UP, 2 * (Math.max(0, halfHeight) + OVER_TOP_HEIGHT) + Math.min(3, trip * 0.06))), mul(approach, standoff * 0.6));
        if (!side || lenSq(side) < 1e-6) return mul(add(origin, dest), 0.5);
        side = norm(side);
        var lean = Math.max(1.2, Math.min(5, trip * 0.18));
        var corner = norm(add(mul(approach, 0.75), side));
        return add(add(targetEye, mul(corner, standoff + lean)), mul(UP, lean * 0.2));
    }
    function curveLength(from, ctrl, to) {
        var total = 0, prev = from;
        for (var i = 1; i <= 8; i++) { var p = sample(from, ctrl, to, i / 8); total += dist(p, prev); prev = p; }
        return total;
    }
    function travelTicks(length) { return Math.max(MIN_TRAVEL_TICKS, Math.min(MAX_TRAVEL_TICKS, Math.ceil(Math.max(0, length) / ROUTE_SPEED))); }

    // ---- a small seeded generator, the same on both sides (mulberry32) ----
    function rng(seed) {
        var s = (Number(seed) | 0) >>> 0;
        function next() {
            s = (s + 0x6D2B79F5) | 0;
            var t = Math.imul(s ^ (s >>> 15), 1 | s);
            t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        }
        return { next: next, int: function (n) { return Math.floor(next() * n); }, bool: function () { return next() < 0.5; } };
    }

    // ---- ClashRhythm: ten seconds of arrows (up/left/down/right = W/A/S/D or the arrow keys) ----
    var R = {
        DURATION_TICKS: 200, LEAD_TICKS: 14, FIRST_NOTE_TICK: 22, MIN_GAP_TICKS: 8, MAX_GAP_TICKS: 15, POST_SUSTAIN_GAP: 6,
        DOUBLE_CHANCE: 0.18, SUSTAIN_CHANCE: 0.22, MIN_SUSTAIN_TICKS: 12, MAX_SUSTAIN_TICKS: 26,
        PERFECT_WINDOW: 3, GOOD_WINDOW: 7, PERFECT_SCORE: 2, GOOD_SCORE: 1, SUSTAIN_TICKS_PER_POINT: 6, SUSTAIN_RELEASE_GRACE: 3,
        DIR_UP: 0, DIR_LEFT: 1, DIR_DOWN: 2, DIR_RIGHT: 3
    };
    R.LAST_NOTE_TICK = R.DURATION_TICKS - 16;
    function note(hit, dir, hold) { return { hit: hit, dir: dir, hold: hold }; }
    function bonus(n) { return Math.floor(n.hold / R.SUSTAIN_TICKS_PER_POINT); }
    /** The chart for a seed: notes {hit, dir, hold} sorted by hit tick. */
    function timeline(seed) {
        var r = rng(seed), notes = [], used = [false, false, false, false], prev = -1, tick = R.FIRST_NOTE_TICK;
        while (tick <= R.LAST_NOTE_TICK) {
            var d = r.int(4);
            if (d === prev) d = (d + 1 + r.int(3)) % 4;
            prev = d; used[d] = true;
            var roll = r.next(), gap;
            if (roll < R.DOUBLE_CHANCE) {
                var second = (d + 1 + r.int(3)) % 4;
                used[second] = true;
                notes.push(note(tick, d, 0), note(tick, second, 0));
                gap = R.MIN_GAP_TICKS + 2 + r.int(R.MAX_GAP_TICKS - R.MIN_GAP_TICKS);
                prev = second;
            } else if (roll < R.DOUBLE_CHANCE + R.SUSTAIN_CHANCE) {
                var hold = R.MIN_SUSTAIN_TICKS + r.int(R.MAX_SUSTAIN_TICKS - R.MIN_SUSTAIN_TICKS + 1);
                hold = Math.min(hold, Math.max(R.MIN_SUSTAIN_TICKS, R.DURATION_TICKS - 6 - tick));
                notes.push(note(tick, d, hold));
                gap = hold + R.POST_SUSTAIN_GAP + r.int(R.MAX_GAP_TICKS - R.MIN_GAP_TICKS);
            } else {
                notes.push(note(tick, d, 0));
                gap = R.MIN_GAP_TICKS + r.int(R.MAX_GAP_TICKS - R.MIN_GAP_TICKS + 1);
            }
            tick += gap;
        }
        // every lane gets at least one arrow
        for (var lane = 0; lane < 4; lane++) {
            if (!used[lane] && notes.length) {
                var i = r.int(notes.length), old = notes[i];
                notes[i] = note(old.hit, lane, old.hold);
            }
        }
        notes.sort(function (a, b) { return a.hit - b.hit; });
        return notes;
    }
    function maxScore(seed) { var t = 0; timeline(seed).forEach(function (n) { t += R.PERFECT_SCORE + bonus(n); }); return t; }
    /** A press in lane `dir` at `tick` against one note: 2 perfect, 1 good, 0 miss. */
    function judge(n, dir, tick) {
        if (!n || n.dir !== dir) return 0;
        var off = Math.abs(tick - n.hit);
        return off <= R.PERFECT_WINDOW ? R.PERFECT_SCORE : off <= R.GOOD_WINDOW ? R.GOOD_SCORE : 0;
    }
    /** An NPC (or the training dummy) playing the same chart, as accurate as it is strong next to the player. */
    function npcScore(seed, npcPower, playerPower) {
        var notes = timeline(seed), ratio = playerPower <= 0 ? 1 : npcPower / playerPower;
        var acc = Math.max(0.45, Math.min(0.95, 0.75 * Math.sqrt(Math.max(0.05, ratio))));
        var r = rng((Number(seed) | 0) * 31 + 17), score = 0;
        notes.forEach(function (n) {
            var roll = r.next();
            if (roll < acc * 0.6) score += R.PERFECT_SCORE + bonus(n);
            else if (roll < acc) { score += R.GOOD_SCORE; if (r.bool()) score += bonus(n); }
        });
        return score;
    }

    return {
        V: V, add: add, sub: sub, mul: mul, dot: dot, cross: cross, len: len, lenSq: lenSq, norm: norm, dist: dist,
        MODE: MODE, stopsOnContact: stopsOnContact, canClash: canClash, modeById: modeById,
        CONTACT_STANDOFF: CONTACT_STANDOFF, sample: sample, pinnedSide: pinnedSide, destination: destination, facing: facing,
        control: control, curveLength: curveLength, travelTicks: travelTicks,
        R: R, rng: rng, timeline: timeline, maxScore: maxScore, judge: judge, npcScore: npcScore, sustainBonus: bonus
    };
})();
