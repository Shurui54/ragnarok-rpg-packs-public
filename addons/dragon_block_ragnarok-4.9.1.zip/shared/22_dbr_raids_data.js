// =====================================================================================
//  22_dbr_raids_data.js - DMZ Ragnarok raids: shared data model (server + client editor)
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0) shuruis_raid_bosses: raid/RaidBossDef, RaidType, EnemyWave, BossStage,
//  AllySpawn, KiMove, reward/Reward, rift/RiftDef. Field names, defaults and the pipe-delimited token formats
//  are DMZ Ragnarok's own, so a raid exported from DMZR reads the same here.
//
//  Server: scripts/92_dbr_raids.js (raids) and scripts/92_dbr_raids_rifts.js (dimensional tears).
//  Client: client/scripts/82_dbr_raids.js (HUD, sign-up, browser) and 82_dbr_raids_editor.js (editors).
// =====================================================================================
var DBR_RAIDS_DATA = (function () {
    var TYPES = ["STANDARD", "PARALLEL_QUEST", "BOSS_RUSH"];
    var TYPE_LABELS = { STANDARD: "Standard", PARALLEL_QUEST: "Parallel Quest", BOSS_RUSH: "Boss Rush" };
    // KiMove.TYPES: DBSagasEntity.KiSkillType in declaration order (index + 1 = the DMZ saga skill number)
    var KI_TYPES = ["KAMEHAMEHA", "GALICK_GUN", "MAKANKOSAPPO", "KI_LASER", "KI_EXPLOSION",
        "KI_BARRIER", "OOZARU_ROAR", "GENERIC_KI_WAVE", "OOZARU_BEAM", "KI_VOLLEY",
        "KI_SMALL", "BLUE_HURRICANE", "TRIPLE_LASER", "KIENZAN", "DEATH_BALL",
        "MASENKO", "BIG_BANG", "FINAL_FLASH", "MAJIN_CANDY", "KI_AIR_VOLLEY", "DOUBLE_SUNDAY"];
    var REWARD_TYPES = ["COMMAND", "ITEM", "SKILL", "TP", "MESSAGE"];
    // RiftDef.arenaTheme: the dungeon themes; here each picks the arena floor
    var THEMES = ["overworld", "namek", "kaio", "stony", "otherworld", "nether", "end", "vegeta", "beerus"];
    var LOOKS = ["default", "halloween"];
    var STATES = ["IDLE", "SIGNUP", "COUNTDOWN", "ACTIVE", "FINISHED"];

    function num(s, fb) { var n = Number(String(s === undefined || s === null ? "" : s).trim()); return s === "" || isNaN(n) ? fb : n; }
    function int(s, fb) { var n = parseInt(String(s === undefined || s === null ? "" : s).trim(), 10); return isNaN(n) ? fb : n; }
    function trim(v) { v = Number(v) || 0; return v === Math.round(v) ? String(Math.round(v)) : String(v); }
    function shortId(id) { id = String(id || ""); var c = id.indexOf(":"); return c >= 0 ? id.substring(c + 1) : id; }
    function fmtD(v) { v = Number(v) || 0; return v === Math.round(v) ? v.toFixed(1) : String(v); }   // Java's Double.toString look

    // ---- RaidBossDef defaults (the Java field initialisers) ----
    function defaults(id, name) {
        return {
            id: id || "", name: name || "Raid", raidType: "STANDARD", category: "General", showInNpcMenu: true, eventOnly: false,
            arena: null, playerSpawn: null, randomPool: [],
            bossEntityType: "minecraft:warden", bossModelId: "", bossName: "Raid Boss",
            baseHealth: 500, healthPerPlayer: 250, maxHealthCap: 0, scaleDamage: false, damagePerPlayer: 2, maxDamagePercentPerHit: 2.5,
            parallelBoss: false, battlePower: 0, kiBlastDamage: 0, moveSpeed: 0, baseMeleeDamage: 0, baseDefense: 0, bossScale: 0, aiTier: 0,
            kiMoves: [], useDefaultTransform: true, enemies: [], mvpKillWeight: 500, rushStages: [], allies: [],
            signupMinutes: 5, signupReminderSeconds: 30, minParticipants: 1, maxParticipants: 10, requireCharacter: true,
            pvpInArena: false, preventReentry: false, vanillaDrops: false, healOnStart: true, countdownSeconds: 5, fightTimeLimit: 600,
            npcName: "Raid Master", npcEntityType: "dmz_ragnarok:raid_npc", npcModelId: "", useTitles: true,
            announceSound: "minecraft:ui.toast.challenge_complete", bossMusic: "", spawnOnObsidian: false, spawnAnchorBlock: "minecraft:obsidian",
            msgSignupOpen: "&c[Raid] &fSign-ups OPEN for {name}! Talk to {npc} or /rg raid join {name}.",
            msgStarting: "&6[Raid] &f{name} begins with {count} fighters!",
            msgBossSpawn: "&4[Raid] &f{boss} has appeared with &c{health} &fHP!",
            msgVictory: "&6[Raid] &f{boss} has been defeated! Top damage: &e{top} &f({top_percent}%)",
            msgTimeout: "&c[Raid] &fTime is up. {boss} escaped. Better luck next time!",
            scheduleEnabled: false, scheduleHour: 20, scheduleMinute: 0, scheduleDayOfWeek: 0, scheduleDayOfMonth: 0,
            scheduleIntervalMinutes: 0, scheduleTimes: [],
            participantRewards: [], topRewards: [], runnerUpRewards: []
        };
    }
    var LIST_FIELDS = ["randomPool", "kiMoves", "enemies", "rushStages", "allies", "scheduleTimes", "participantRewards", "topRewards", "runnerUpRewards"];

    /** A def from untrusted JSON (saved data, the editor): every field present, of the right type. */
    function normalize(src) {
        var d = defaults(), k;
        src = src || {};
        for (k in d) {
            if (!Object.prototype.hasOwnProperty.call(src, k) || src[k] === undefined || src[k] === null) continue;
            var dv = d[k], v = src[k];
            if (LIST_FIELDS.indexOf(k) >= 0) d[k] = (v && v.length !== undefined ? Array.prototype.slice.call(v) : []).map(String).filter(function (x) { return x.length; });
            else if (k === "arena" || k === "playerSpawn") d[k] = region(v);
            else if (typeof dv === "number") d[k] = num(v, dv);
            else if (typeof dv === "boolean") d[k] = v === true || v === "true";
            else d[k] = String(v);
        }
        d.id = String(d.id || "").toLowerCase();
        if (TYPES.indexOf(d.raidType) < 0) d.raidType = "STANDARD";
        if (!d.category) d.category = "General";
        if (d.aiTier < 0) d.aiTier = 0;
        ["signupMinutes", "signupReminderSeconds", "minParticipants", "maxParticipants", "countdownSeconds", "fightTimeLimit",
            "scheduleHour", "scheduleMinute", "scheduleDayOfWeek", "scheduleDayOfMonth", "scheduleIntervalMinutes", "aiTier", "battlePower"].forEach(function (f) { d[f] = Math.round(d[f]); });
        return d;
    }
    /** Region: {dim, x1, y1, z1, x2, y2, z2} (min/max), optional cylinder {cx, cz, r}. */
    function region(v) {
        if (!v || typeof v !== "object" || !v.dim) return null;
        var r = { dim: String(v.dim), x1: Math.min(int(v.x1, 0), int(v.x2, 0)), y1: Math.min(int(v.y1, 0), int(v.y2, 0)), z1: Math.min(int(v.z1, 0), int(v.z2, 0)),
            x2: Math.max(int(v.x1, 0), int(v.x2, 0)), y2: Math.max(int(v.y1, 0), int(v.y2, 0)), z2: Math.max(int(v.z1, 0), int(v.z2, 0)) };
        if (num(v.r, 0) > 0) { r.cx = num(v.cx, 0); r.cz = num(v.cz, 0); r.r = num(v.r, 0); }
        return r;
    }
    function regionText(r) { return r ? "(" + r.x1 + ", " + r.y1 + ", " + r.z1 + ") -> (" + r.x2 + ", " + r.y2 + ", " + r.z2 + ") " + shortId(r.dim) : ""; }

    // ---- EnemyWave: entityType|count|health|legacyBattlePower|scale|meleeDamage|kiPower|wave|defense|rgModelId ----
    function wave(token) {
        var w = { entityType: "minecraft:zombie", count: 3, health: 0, meleeDamage: 0, kiPower: 0, defense: 0, scale: 0, wave: 1, rgModelId: "" };
        if (!token) return w;
        var p = String(token).split("|");
        if (p.length >= 1 && p[0].trim()) w.entityType = p[0].trim();
        if (p.length >= 2) w.count = Math.max(1, int(p[1], w.count));
        if (p.length >= 3) w.health = num(p[2], w.health);
        if (p.length >= 5) w.scale = num(p[4], w.scale);
        if (p.length >= 6) w.meleeDamage = num(p[5], w.meleeDamage);
        if (p.length >= 7) w.kiPower = num(p[6], w.kiPower);
        if (p.length >= 8) w.wave = Math.max(1, int(p[7], w.wave));
        if (p.length >= 9) w.defense = num(p[8], w.defense);
        if (p.length >= 10) w.rgModelId = p[9].trim();
        return w;
    }
    function waveToken(w) {
        return w.entityType + "|" + w.count + "|" + fmtD(w.health) + "|0|" + fmtD(w.scale) + "|" + fmtD(w.meleeDamage) + "|" + fmtD(w.kiPower) + "|" + w.wave + "|" + fmtD(w.defense) + "|" + (w.rgModelId || "").trim();
    }
    function waveSummary(w) {
        var s = "§bW" + w.wave + " §f" + w.count + "§7x §e" + shortId(w.entityType), bits = [];
        if (w.rgModelId) s += " §d" + w.rgModelId;
        if (w.health > 0) bits.push(trim(w.health) + " HP");
        if (w.meleeDamage > 0) bits.push("M" + trim(w.meleeDamage));
        if (w.kiPower > 0) bits.push("K" + trim(w.kiPower));
        if (w.defense > 0) bits.push("D" + trim(w.defense));
        return bits.length ? s + " §7(" + bits.join(", ") + ")" : s;
    }

    // ---- AllySpawn: entityType|count|health|legacyBP|scale|meleeDamage|kiPower|defense|rgModelId|name|kiCsv ----
    var NESTED_FIELD_SEP = "^", NESTED_ENTRY_SEP = ";";
    function ally(token) {
        var a = { entityType: "dmz_ragnarok:raid_npc", count: 1, health: 0, meleeDamage: 0, kiPower: 0, defense: 0, scale: 0, rgModelId: "", name: "", kiMoves: [] };
        if (!token) return a;
        var p = String(token).split("|");
        if (p.length >= 1 && p[0].trim()) a.entityType = p[0].trim();
        if (p.length >= 2) a.count = Math.max(1, int(p[1], a.count));
        if (p.length >= 3) a.health = num(p[2], a.health);
        if (p.length >= 5) a.scale = num(p[4], a.scale);
        if (p.length >= 6) a.meleeDamage = num(p[5], a.meleeDamage);
        if (p.length >= 7) a.kiPower = num(p[6], a.kiPower);
        if (p.length >= 8) a.defense = num(p[7], a.defense);
        if (p.length >= 9) a.rgModelId = p[8].trim();
        if (p.length >= 10) a.name = p[9];
        if (p.length >= 11) a.kiMoves = p[10].split(",").map(function (x) { return x.trim(); }).filter(function (x) { return x; });
        return a;
    }
    function safeName(n) { return String(n || "").replace(/[|^;]/g, " "); }
    function allyToken(a) {
        return a.entityType + "|" + a.count + "|" + fmtD(a.health) + "|0|" + fmtD(a.scale) + "|" + fmtD(a.meleeDamage) + "|" + fmtD(a.kiPower) + "|" + fmtD(a.defense)
            + "|" + (a.rgModelId || "").trim() + "|" + safeName(a.name) + "|" + (a.kiMoves || []).join(",");
    }
    function allySummary(a) {
        var s = "§aALLY §f" + a.count + "§7x §e" + shortId(a.entityType), bits = [];
        if (a.rgModelId) s += " §d" + a.rgModelId;
        if (a.name) s += " §f\"" + a.name + "\"";
        if (a.health > 0) bits.push(trim(a.health) + " HP");
        if (a.meleeDamage > 0) bits.push("M" + trim(a.meleeDamage));
        if (a.kiPower > 0) bits.push("K" + trim(a.kiPower));
        if (a.defense > 0) bits.push("D" + trim(a.defense));
        return bits.length ? s + " §7(" + bits.join(", ") + ")" : s;
    }

    // ---- BossStage: entityType|bossName|health|legacyBP|scale|delaySeconds|kiCsv|meleeDamage|kiPower|defense|rgModelId|allies|swapSides ----
    function stage(token) {
        var s = { entityType: "minecraft:warden", bossName: "Boss", health: 0, meleeDamage: 0, kiPower: 0, defense: 0, scale: 0, delaySeconds: 10, kiMoves: [], rgModelId: "", allies: [], swapSides: false };
        if (!token) return s;
        var p = String(token).split("|");
        if (p.length >= 1 && p[0].trim()) s.entityType = p[0].trim();
        if (p.length >= 2 && p[1].trim()) s.bossName = p[1];
        if (p.length >= 3) s.health = num(p[2], s.health);
        if (p.length >= 5) s.scale = num(p[4], s.scale);
        if (p.length >= 6) s.delaySeconds = Math.max(0, int(p[5], s.delaySeconds));
        if (p.length >= 7 && p[6].trim()) s.kiMoves = p[6].split(",").map(function (x) { return x.trim(); }).filter(function (x) { return x; });
        if (p.length >= 8) s.meleeDamage = num(p[7], s.meleeDamage);
        if (p.length >= 9) s.kiPower = num(p[8], s.kiPower);
        if (p.length >= 10) s.defense = num(p[9], s.defense);
        if (p.length >= 11) s.rgModelId = p[10].trim();
        if (p.length >= 12 && p[11].trim()) s.allies = p[11].split(NESTED_ENTRY_SEP).filter(function (x) { return x.trim(); }).map(function (x) { return x.split(NESTED_FIELD_SEP).join("|"); });
        if (p.length >= 13) s.swapSides = p[12].trim().toLowerCase() === "true";
        return s;
    }
    function stageToken(s) {
        var allies = (s.allies || []).filter(function (a) { return a; }).map(function (a) { return String(a).split("|").join(NESTED_FIELD_SEP); }).join(NESTED_ENTRY_SEP);
        return s.entityType + "|" + String(s.bossName || "").replace(/\|/g, " ") + "|" + fmtD(s.health) + "|0|" + fmtD(s.scale) + "|" + s.delaySeconds + "|" + (s.kiMoves || []).join(",")
            + "|" + fmtD(s.meleeDamage) + "|" + fmtD(s.kiPower) + "|" + fmtD(s.defense) + "|" + (s.rgModelId || "").trim() + "|" + allies + "|" + (!!s.swapSides);
    }
    function stageSummary(s) {
        var t = "§e" + shortId(s.entityType);
        if (s.rgModelId) t += " §d" + s.rgModelId;
        if (s.bossName) t += " §f\"" + s.bossName + "\"";
        t += " §7(+" + s.delaySeconds + "s";
        if (s.health > 0) t += ", " + trim(s.health) + " HP";
        if (s.meleeDamage > 0) t += ", M" + trim(s.meleeDamage);
        if (s.kiPower > 0) t += ", K" + trim(s.kiPower);
        if (s.defense > 0) t += ", D" + trim(s.defense);
        if (s.kiMoves.length) t += ", " + s.kiMoves.length + " ki";
        t += ")";
        if (s.allies.length) t += " §a+" + s.allies.length + " ally";
        if (s.swapSides) t += " §dSWAP";
        return t;
    }

    // ---- KiMove: TYPE:cooldown:size ----
    function ki(token) {
        var m = { type: "KI_LASER", cooldown: 100, size: 1.0 };
        if (!token) return m;
        var p = String(token).split(":");
        if (p.length >= 1 && p[0].trim()) m.type = p[0].trim().toUpperCase();
        if (p.length >= 2) m.cooldown = int(p[1], m.cooldown);
        if (p.length >= 3) m.size = num(p[2], m.size);
        return m;
    }
    function kiToken(m) { return m.type + ":" + m.cooldown + ":" + fmtD(m.size); }
    function kiSummary(m) { return m.type + "  §7(cd " + m.cooldown + "t, size " + trim(m.size) + ")"; }

    // ---- Reward: command:<cmd> item:<id>:<n> skill:<id>:<n> tp:<n> message:<text> (chance:<pct>:<token> wraps any) ----
    function reward(token) {
        var r = { type: "COMMAND", item: "minecraft:diamond", count: 1, command: "give %player% minecraft:diamond 1", tp: "100", skill: "", level: 1, message: "&aWell fought!", chance: 0 };
        if (token === undefined || token === null) return r;
        token = String(token);
        var cm = /^chance:([0-9.]+):(.*)$/i.exec(token);
        if (cm) { var inner = reward(cm[2]); inner.chance = num(cm[1], 0); return inner; }
        var c = token.indexOf(":");
        if (c < 0) { r.type = "MESSAGE"; r.message = token; return r; }
        var type = token.substring(0, c).toLowerCase(), arg = token.substring(c + 1);
        if (type === "item") {
            r.type = "ITEM";
            var parts = arg.split(":");
            if (parts.length >= 3) { r.item = parts[0] + ":" + parts[1]; r.count = int(parts[2], 1); }
            else if (parts.length === 2 && /^\d+$/.test(parts[1])) { r.item = parts[0]; r.count = int(parts[1], 1); }
            else r.item = arg;
        } else if (type === "command") { r.type = "COMMAND"; r.command = arg; }
        else if (type === "tp") { r.type = "TP"; r.tp = arg.trim(); }
        else if (type === "skill" || type === "form") { r.type = "SKILL"; var sp = arg.split(":"); r.skill = sp[0]; r.level = sp.length >= 2 ? int(sp[1], 1) : 1; }
        else if (type === "message") { r.type = "MESSAGE"; r.message = arg; }
        else { r.type = "MESSAGE"; r.message = token; }
        return r;
    }
    function rewardToken(r) {
        var t = r.type === "ITEM" ? "item:" + r.item + ":" + r.count : r.type === "TP" ? "tp:" + r.tp : r.type === "SKILL" ? "skill:" + r.skill + ":" + r.level
            : r.type === "MESSAGE" ? "message:" + r.message : "command:" + r.command;
        return r.chance > 0 && r.chance < 100 ? "chance:" + trim(r.chance) + ":" + t : t;
    }
    function rewardSummary(r) {
        var t = r.type === "ITEM" ? "Item: " + r.count + "x " + r.item : r.type === "TP" ? "Training Points: +" + r.tp : r.type === "SKILL" ? "Skill: " + r.skill + " +" + r.level
            : r.type === "MESSAGE" ? "Message: " + r.message : "Command: /" + r.command;
        return r.chance > 0 && r.chance < 100 ? "§d" + trim(r.chance) + "% §f" + t : t;
    }

    // ---- RiftDef ----
    function riftDefaults(id) {
        return { id: String(id || "").toLowerCase(), name: "Dimensional Tear", enabled: true, eventOnly: false, look: "", encounter: null, raidId: "",
            regions: [], minSpawnMinutes: 45, maxSpawnMinutes: 90, tearLifetimeSeconds: 600, tearLabel: "", arenaTheme: "otherworld",
            msgOpened: "&5[Tear] &fA dimensional tear has opened in &d{region}&f: &5{name}",
            msgFailed: "&5[Tear] &f{player} was lost to &5{name}&f.",
            msgVictory: "&5[Tear] &f{player} tore their way out of &5{name}&f!" };
    }
    function normalizeRift(src) {
        var d = riftDefaults(), k;
        src = src || {};
        for (k in d) {
            if (!Object.prototype.hasOwnProperty.call(src, k) || src[k] === undefined || src[k] === null) continue;
            var dv = d[k], v = src[k];
            if (k === "regions") d[k] = (v && v.length !== undefined ? Array.prototype.slice.call(v) : []).map(String).filter(function (x) { return x.trim().length; });
            else if (k === "encounter") d[k] = v ? normalize(v) : null;
            else if (typeof dv === "number") d[k] = Math.round(num(v, dv));
            else if (typeof dv === "boolean") d[k] = v === true || v === "true";
            else d[k] = String(v);
        }
        d.id = String(d.id || "").toLowerCase();
        if (!d.arenaTheme) d.arenaTheme = "otherworld";
        return d;
    }

    return { TYPES: TYPES, TYPE_LABELS: TYPE_LABELS, KI_TYPES: KI_TYPES, REWARD_TYPES: REWARD_TYPES, THEMES: THEMES, LOOKS: LOOKS, STATES: STATES,
        defaults: defaults, normalize: normalize, region: region, regionText: regionText, LIST_FIELDS: LIST_FIELDS,
        wave: wave, waveToken: waveToken, waveSummary: waveSummary, ally: ally, allyToken: allyToken, allySummary: allySummary,
        stage: stage, stageToken: stageToken, stageSummary: stageSummary, ki: ki, kiToken: kiToken, kiSummary: kiSummary,
        reward: reward, rewardToken: rewardToken, rewardSummary: rewardSummary, riftDefaults: riftDefaults, normalizeRift: normalizeRift,
        num: num, int: int, trim: trim, shortId: shortId };
})();
