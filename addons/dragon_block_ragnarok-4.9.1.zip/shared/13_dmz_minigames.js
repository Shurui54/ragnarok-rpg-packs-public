// =====================================================================================
//  13_dmz_minigames.js - DragonMine Z's training minigames: the game rules, shared by the
//  server (scripts/67_dmz_minigames.js replays the inputs and pays the rewards) and the
//  client (client/scripts/53_dmz_minigames.js draws them and plays them live).
// =====================================================================================
//  Ported from DragonMine Z (GPL-3.0): common/training/MinigameLogic, RhythmLogic,
//  KiControlLogic, MemoryLogic, PrecisionLogic, GravityLogic, RhythmChart, MinigameEvent,
//  MinigameLogics, BuiltinSongs and common/config/TrainingConfig (the defaults below).
//
//  Both sides run the very same code with the same seed and the same inputs, tick by tick, so
//  the server's replay ends exactly where the player's game ended (DMZ's anti-cheat design).
//  ES5 only (it also runs in client scripts). Random numbers: a seeded 32-bit generator
//  (mulberry32) instead of java.util.Random; both sides use it, so they stay in step.
// =====================================================================================
var DMZ_MG = (function () {
    var TICKS_PER_MINUTE = 1200;

    // ---- MinigameEvent ----
    var KEY_DOWN = 0, KEY_UP = 1, CLICK = 2;
    var LEFT = 0, DOWN = 1, UP = 2, RIGHT = 3, ACTION = 4, CHAR_BASE = 5, CHAR_COUNT = 36, KEY_COUNT = CHAR_BASE + CHAR_COUNT;
    var FRAC_STEPS = 256, POS_STEPS = 4;
    function quantizeFrac(partial) { return Math.floor(Math.max(0, Math.min(0.999, partial)) * FRAC_STEPS); }
    /** [tick, type, key, frac, x, y] */
    function keyEvent(tick, down, key, partial) { return [tick, down ? KEY_DOWN : KEY_UP, key, quantizeFrac(partial), 0, 0]; }
    function clickEvent(tick, fx, fy, partial) { return [tick, CLICK, 0, quantizeFrac(partial), Math.round(fx * POS_STEPS), Math.round(fy * POS_STEPS)]; }
    function validEvent(e) {
        if (!e || e.length < 6) return false;
        for (var i = 0; i < 6; i++) if (typeof e[i] !== "number" || e[i] !== e[i] || Math.floor(e[i]) !== e[i]) return false;
        if (e[0] < 0 || e[3] < 0 || e[3] >= FRAC_STEPS) return false;
        if (e[1] === KEY_DOWN || e[1] === KEY_UP) return e[2] >= 0 && e[2] < KEY_COUNT;
        if (e[1] === CLICK) return e[4] >= -32768 && e[4] <= 32767 && e[5] >= -32768 && e[5] <= 32767;
        return false;
    }

    // ---- MinigameLogics ----
    var IDS = ["rhythm", "control", "memory", "precision", "gravity"];
    var CHALLENGE_STAGES = ["control", "gravity", "memory", "precision", "rhythm"];
    function isValidId(id) { return IDS.indexOf(id) >= 0; }

    // ---- BuiltinSongs ----
    var SONGS = [
        { key: "song:ill_forget_about_you_in_time", sound: "dmzpack:minigame.ill_forget_about_you_in_time", title: "I'll Forget About You (In Time)", artist: "Laufey", durationMs: 252169 },
        { key: "song:oh_yeah", sound: "dmzpack:minigame.oh_yeah", title: "oh yeah?", artist: "Steve Lacy", durationMs: 169685 }
    ];
    function findSong(key) { for (var i = 0; i < SONGS.length; i++) if (SONGS[i].key === key) return SONGS[i]; return null; }
    function isBuiltinSong(key) { return String(key || "").indexOf("song:") === 0; }

    // ---- TrainingConfig (defaults; the server's config/dbr_training.json overrides them and sends them along) ----
    function songDifficulty(si, ei, st, et, rm) { return { startIntensity: si, endIntensity: ei, startTravelMs: st, endTravelMs: et, rewardMultiplier: rm }; }
    var DEFAULTS = {
        tpPerMinuteCoefficient: 62.0, rewardCostExponent: 0.6, minLevelRewardMultiplier: 0.5,
        minPerformanceRewardMultiplier: 0.75, maxPerformanceRewardMultiplier: 1.25, mentorBonus: 0.25,
        learnRequiredLevel: 5, learnRequiredRuns: 3, challengeTargetLevels: 10,
        rhythm: {
            rewardMultiplier: 1.0, tpsLimitPerGame: 0, unlockedByDefault: false, masterName: "popo", difficultyCapLevel: 10, challengeTargetLevels: 6,
            requireDiscInInventory: true, baseTravelMs: 1700, travelMsDecreasePerLevel: 90, minTravelMs: 900, perfectWindowMs: 50, goodWindowMs: 115,
            holdReleaseGraceMs: 140, densityTierEveryLevels: 2, recommendedMaxNotesPerSecond: 3.0, learnSongAccuracy: 0.75,
            easy: songDifficulty(0.20, 0.42, 1700, 1400, 0.8), normal: songDifficulty(0.35, 0.65, 1550, 1150, 1.1),
            hard: songDifficulty(0.55, 0.88, 1350, 950, 1.25), expert: songDifficulty(0.75, 1.0, 1150, 780, 1.45),
            progressMax: 100.0, progressOnLevelUp: 20.0, targetSecondsPerLevel: 12.0, goodProgressFactor: 0.7, holdProgressFactor: 0.5,
            progressDecayPerTick: 0.02, progressLossOnMiss: 4.0, startingHealth: 0.6, healthGainPerfect: 0.03, healthGainGood: 0.015,
            healthLossOnMiss: 0.08, healthLossOnGhost: 0.02, freeBaseBpm: 110.0, freeBpmPerLevel: 5.0, freeMaxBpm: 160.0,
            freeHoldChance: 0.12, freeChordChance: 0.06, songRewardMultiplier: 1.05
        },
        control: {
            rewardMultiplier: 1.0, tpsLimitPerGame: 0, unlockedByDefault: false, masterName: "krillin", difficultyCapLevel: 20, challengeTargetLevels: 0,
            trackHeight: 200, baseBarHeight: 70.0, barHeightDecreasePerLevel: 1.3, minBarHeight: 46.0, liftAcceleration: 0.45,
            fallAcceleration: 0.40, maxBarSpeed: 6.0, bounceDamping: 0.35, orbSize: 12.0, baseOrbSpeed: 0.9, orbSpeedPerLevel: 0.06,
            orbAcceleration: 0.12, minRetargetTicks: 14, maxRetargetTicks: 44, baseDartChance: 0.003, dartChancePerLevel: 0.0008,
            dartSpeedMultiplier: 2.2, initialProgress: 0.30, progressOnLevelUp: 0.35, progressFillPerTick: 0.011,
            baseProgressDrainPerTick: 0.005, progressDrainPerLevel: 0.00015
        },
        memory: {
            rewardMultiplier: 1.0, tpsLimitPerGame: 0, unlockedByDefault: false, masterName: "gohan", difficultyCapLevel: 20, challengeTargetLevels: 0,
            baseSequenceLength: 3, lengthEveryLevels: 2, maxSequenceLength: 8, baseTicksPerKey: 30, ticksPerKeyDecreasePerLevel: 0.9,
            minTicksPerKey: 13, keyTimeMultiplier: 2.2, wrongKeyDrainTicks: 8, fastDrainRate: 3, feedbackTicks: 10, lives: 3
        },
        precision: {
            rewardMultiplier: 1.0, tpsLimitPerGame: 0, unlockedByDefault: false, masterName: "trunks", difficultyCapLevel: 20, challengeTargetLevels: 0,
            outerRingRadius: 40, targetRadius: 14, baseRingSpeed: 0.42, ringSpeedPerLevel: 0.03, spawnIntervalTicks: 16, maxCircles: 3,
            startingMaxCircles: 2, maxCirclesFullLevel: 8, perfectWindow: 5, goodWindow: 13, perfectPoints: 2, goodPoints: 1, missPenalty: 2,
            fadeOutTicks: 20, startingScore: 6, burstChance: 0.5, scorePerLevel: 12, loseMissThreshold: 5, loseMissWindow: 10
        },
        gravity: {
            rewardMultiplier: 1.0, tpsLimitPerGame: 0, unlockedByDefault: false, masterName: "vegeta", difficultyCapLevel: 20, challengeTargetLevels: 0,
            gravityAcceleration: 0.40, flapVelocity: 4.9, maxFallSpeed: 8.0, baseScrollSpeed: 3.25, scrollSpeedPerLevel: 0.035,
            baseGap: 72.0, gapDecreasePerLevel: 0.95, minGap: 54.0, baseSpacing: 150.0, spacingDecreasePerLevel: 2.0, minSpacing: 116.0,
            spacingRandom: 20.0, baseMaxGapShift: 50.0, maxGapShiftPerLevel: 1.5, pillarsPerLevel: 3, lives: 3, invulnerabilityTicks: 30
        }
    };
    /** a full config: defaults with any given values on top (numbers/booleans/strings of the right type only) */
    function mergeCfg(over) {
        function merge(def, o) {
            var out = {};
            for (var k in def) {
                var d = def[k], v = o ? o[k] : undefined;
                if (d && typeof d === "object") out[k] = merge(d, v && typeof v === "object" ? v : null);
                else out[k] = (v !== undefined && v !== null && typeof v === typeof d && (typeof v !== "number" || isFinite(v))) ? v : d;
            }
            return out;
        }
        return merge(DEFAULTS, over || null);
    }
    function settingsOf(cfg, id) { return cfg[id] || cfg.rhythm; }
    function computeTpsPerMinute(cfg, singleStatCost, settings) {
        var tpc = Math.max(1, singleStatCost);
        var perMinute = cfg.tpPerMinuteCoefficient * Math.pow(tpc, cfg.rewardCostExponent);
        return Math.max(0, perMinute * (settings ? settings.rewardMultiplier : 1));
    }
    function challengeTargetLevels(cfg, id) { var s = settingsOf(cfg, id); return s.challengeTargetLevels > 0 ? s.challengeTargetLevels : cfg.challengeTargetLevels; }
    function difficultyOf(rc, index) { return index === 0 ? rc.easy : index === 2 ? rc.hard : index === 3 ? rc.expert : rc.normal; }

    // ---- seeded random (mulberry32) ----
    function imul(a, b) {
        var ah = (a >>> 16) & 0xffff, al = a & 0xffff, bh = (b >>> 16) & 0xffff, bl = b & 0xffff;
        return ((al * bl) + (((ah * bl + al * bh) << 16) >>> 0)) | 0;
    }
    function Rng(seed) { this.a = seed | 0; }
    Rng.prototype.nextDouble = function () {
        this.a = (this.a + 0x6D2B79F5) | 0;
        var t = imul(this.a ^ (this.a >>> 15), 1 | this.a);
        t = (t + imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    Rng.prototype.nextInt = function (n) { return Math.floor(this.nextDouble() * n); };

    // ---- RhythmChart (compact JSON: {sound, bpm, durationMs, notes: [t, lane, len, tier, sub, ...], vocal: [...]}) ----
    var SUB_STEPS = 256, VARIANT_INSTRUMENTAL = 0, VARIANT_VOCAL = 1, MAX_NOTES = 8192, MAX_DURATION_MS = 20 * 60 * 1000;
    function clampVariant(v) { return v === VARIANT_VOCAL ? VARIANT_VOCAL : VARIANT_INSTRUMENTAL; }
    // notes [from, to) of a flat list onto out (stops at MAX_NOTES)
    function parseRange(flat, duration, out, from, to) {
        for (var i = from; i + 4 < flat.length && i < to && out.length < MAX_NOTES; i += 5) {
            var t = Math.floor(Number(flat[i])), lane = Math.floor(Number(flat[i + 1])), len = Math.floor(Number(flat[i + 2])) || 0;
            var tier = Math.max(0, Math.min(3, Math.floor(Number(flat[i + 3])) || 0)), sub = Math.max(0, Math.min(SUB_STEPS - 1, Math.floor(Number(flat[i + 4])) || 0));
            if (!(t >= 0) || t > duration || !(lane >= 0) || lane >= 4) continue;
            out.push({ timeMs: t, lane: lane, lengthMs: Math.max(0, len), tier: tier, sub: sub, level: (tier + sub / SUB_STEPS) / 4.0 });
        }
        return out;
    }
    // charts are written in order: only sort when one isn't (sorting 1-2 thousand notes took a tick's worth of time)
    function orderNotes(out) {
        var ordered = true;
        for (var k = 1; k < out.length && ordered; k++) {
            var p = out[k - 1], q = out[k];
            if (p.timeMs > q.timeMs || (p.timeMs === q.timeMs && p.lane > q.lane)) ordered = false;
        }
        if (!ordered) out.sort(function (a, b) { return a.timeMs !== b.timeMs ? a.timeMs - b.timeMs : a.lane - b.lane; });
        return out;
    }
    function parseNotes(flat, duration) {
        if (!flat || !flat.length) return [];
        return orderNotes(parseRange(flat, duration, [], 0, flat.length));
    }
    // every level is (tier + sub / SUB_STEPS) / 4 with whole tier and sub: count them instead of sorting (same list)
    function levelsOf(list) {
        var counts = [], i, n, l = [];
        for (i = 0; i < 4 * SUB_STEPS; i++) counts.push(0);
        for (i = 0; i < list.length; i++) counts[list[i].tier * SUB_STEPS + list[i].sub]++;
        for (i = 0; i < counts.length; i++) {
            if (!counts[i]) continue;
            var tier = Math.floor(i / SUB_STEPS), sub = i % SUB_STEPS, level = (tier + sub / SUB_STEPS) / 4.0;
            for (n = 0; n < counts[i]; n++) l.push(level);
        }
        return l;
    }
    function chartDuration(json) { return Math.max(0, Math.min(MAX_DURATION_MS, Math.floor(Number(json.durationMs) || 0))); }
    function Chart(json, notes, vocal) {
        var d = chartDuration(json);
        this.sound = String(json.sound || "");
        this.bpm = Number(json.bpm) || 120;
        this.durationMs = d;
        this.notes = notes || parseNotes(json.notes, d);
        this.vocalNotes = vocal || parseNotes(json.vocal, d);
        this.levels = levelsOf(this.notes);
        this.vocalLevels = levelsOf(this.vocalNotes);
    }
    // Builds the same Chart a few hundred notes per call, for background work that must not stall a tick:
    // call step() until it returns the chart.
    function ChartBuild(json) {
        this.json = json; this.d = chartDuration(json);
        this.lists = [json.notes || [], json.vocal || []]; this.outs = [[], []]; this.part = 0; this.i = 0;
    }
    ChartBuild.prototype.step = function (notesPerStep) {
        var n = Math.max(1, notesPerStep || 400) * 5;
        while (this.part < 2) {
            var flat = this.lists[this.part], out = this.outs[this.part];
            if (this.i < flat.length && out.length < MAX_NOTES) {
                parseRange(flat, this.d, out, this.i, this.i + n);
                this.i += n;
                return null;
            }
            orderNotes(out);
            this.part++; this.i = 0;
            return null;
        }
        return new Chart(this.json, this.outs[0], this.outs[1]);
    };
    Chart.prototype.hasVocals = function () { return this.vocalNotes.length > 0; };
    Chart.prototype.effectiveVariant = function (v) { return clampVariant(v) === VARIANT_VOCAL && this.hasVocals() ? VARIANT_VOCAL : VARIANT_INSTRUMENTAL; };
    Chart.prototype.notesFor = function (v) { return this.effectiveVariant(v) === VARIANT_VOCAL ? this.vocalNotes : this.notes; };
    Chart.prototype.playableSeconds = function (v) {
        var list = this.notesFor(v);
        if (!list.length) return Math.max(10, this.durationMs / 1000);
        return Math.max(10, (list[list.length - 1].timeMs - list[0].timeMs) / 1000);
    };
    Chart.prototype.countAt = function (intensity, v) {
        var levels = this.effectiveVariant(v) === VARIANT_VOCAL ? this.vocalLevels : this.levels, lo = 0, hi = levels.length;
        while (lo < hi) { var mid = (lo + hi) >>> 1; if (levels[mid] <= intensity) lo = mid + 1; else hi = mid; }
        return lo;
    };
    Chart.prototype.densityAt = function (intensity, v) { return this.countAt(intensity, v) / this.playableSeconds(v); };
    function recommendedDifficulty(chart, rc, variant) {
        if (!chart) return 1;
        var limit = Math.max(0.5, rc.recommendedMaxNotesPerSecond);
        for (var d = 3; d > 0; d--) if (chart.densityAt(difficultyOf(rc, d).endIntensity, variant) <= limit) return d;
        return 0;
    }

    // ===================================================================================
    //  MinigameLogic (the base every game shares)
    // ===================================================================================
    function Base(id, cfg, settings, seed) {
        this.id = id; this.cfg = cfg; this.settings = settings; this.random = new Rng(seed);
        this.tickN = 0; this.levelsCleared = 0; this.finished = false; this.targetReached = false; this.targetLevels = -1;
        this.held = []; for (var i = 0; i < KEY_COUNT; i++) this.held.push(false);
        this.performance = 0.5; this.rewardUnits = 0;
    }
    Base.prototype.setTargetLevelsCleared = function (n) { this.targetLevels = n; };
    Base.prototype.applyEvent = function (e) {
        if (this.finished) return;
        var type = e[1], key = e[2], frac = e[3] / FRAC_STEPS;
        if (type === KEY_DOWN) { if (this.held[key]) return; this.held[key] = true; this.onKeyDown(key, frac); }
        else if (type === KEY_UP) { if (!this.held[key]) return; this.held[key] = false; this.onKeyUp(key, frac); }
        else if (type === CLICK) this.onClick(e[4] / POS_STEPS, e[5] / POS_STEPS, frac);
    };
    Base.prototype.tick = function () {
        if (this.finished) return;
        this.tickN++;
        this.tickGame();
        if (!this.finished) this.rewardUnits += this.rewardRate() / TICKS_PER_MINUTE;
    };
    Base.prototype.baseRewardRate = function () {
        var cap = Math.max(2, this.settings.difficultyCapLevel);
        var levelProgress = Math.min(1, this.levelsCleared / (cap - 1));
        var minLevel = this.cfg.minLevelRewardMultiplier, levelMult = minLevel + (1 - minLevel) * levelProgress;
        var minPerf = this.cfg.minPerformanceRewardMultiplier, maxPerf = this.cfg.maxPerformanceRewardMultiplier;
        var perfMult = minPerf + (maxPerf - minPerf) * this.performance;
        return Math.max(0, levelMult * perfMult);
    };
    Base.prototype.rewardRate = function () { return this.baseRewardRate(); };
    Base.prototype.difficulty = function () { return Math.min(this.levelsCleared, Math.max(0, this.settings.difficultyCapLevel - 1)); };
    Base.prototype.levelUp = function () {
        this.levelsCleared++;
        if (this.targetLevels > 0 && this.levelsCleared >= this.targetLevels) { this.targetReached = true; this.finished = true; return; }
        this.onLevelUp();
    };
    Base.prototype.fail = function () { this.finished = true; };
    Base.prototype.complete = function () { this.finished = true; };
    Base.prototype.forceFinish = function () { this.finished = true; };
    Base.prototype.samplePerformance = function (sample, weight) { this.performance += weight * (Math.max(0, Math.min(1, sample)) - this.performance); };
    Base.prototype.isHeld = function (key) { return !!this.held[key]; };
    Base.prototype.level = function () { return this.levelsCleared + 1; };
    Base.prototype.onKeyDown = function () {};
    Base.prototype.onKeyUp = function () {};
    Base.prototype.onClick = function () {};
    Base.prototype.onLevelUp = function () {};
    Base.prototype.tickGame = function () {};
    function extend(Ctor) { Ctor.prototype = Object.create(Base.prototype); Ctor.prototype.constructor = Ctor; return Ctor; }

    // ===================================================================================
    //  KiControlLogic ("control", Krillin)
    // ===================================================================================
    var Control = extend(function (cfg, seed) {
        Base.call(this, "control", cfg, cfg.control, seed);
        var c = this.c = cfg.control;
        this.trackHeight = Math.max(60, c.trackHeight);
        this.barY = 0; this.barVelocity = 0;
        this.orbY = this.barHeight() * 0.5; this.orbVelocity = 0; this.orbTarget = this.orbY;
        this.retargetTimer = c.minRetargetTicks; this.darting = false;
        this.progress = c.initialProgress; this.inside = true;
    });
    Control.prototype.barHeight = function () { return Math.max(this.c.minBarHeight, this.c.baseBarHeight - this.difficulty() * this.c.barHeightDecreasePerLevel); };
    Control.prototype.orbSpeed = function () { return this.c.baseOrbSpeed + this.difficulty() * this.c.orbSpeedPerLevel; };
    Control.prototype.dartChance = function () { return this.c.baseDartChance + this.difficulty() * this.c.dartChancePerLevel; };
    Control.prototype.tickGame = function () {
        this.tickBar(); this.tickOrb();
        var h = this.barHeight(), c = this.c;
        this.inside = this.orbY >= this.barY && this.orbY <= this.barY + h;
        this.samplePerformance(this.inside ? 1 : 0, 0.01);
        if (this.inside) {
            this.progress += c.progressFillPerTick;
            if (this.progress >= 1) this.levelUp();
        } else {
            this.progress -= c.baseProgressDrainPerTick + this.difficulty() * c.progressDrainPerLevel;
            if (this.progress <= 0) { this.progress = 0; this.fail(); }
        }
    };
    Control.prototype.tickBar = function () {
        var h = this.barHeight(), c = this.c;
        if (this.isHeld(ACTION)) this.barVelocity += c.liftAcceleration; else this.barVelocity -= c.fallAcceleration;
        var max = c.maxBarSpeed;
        this.barVelocity = Math.max(-max, Math.min(max, this.barVelocity));
        this.barY += this.barVelocity;
        if (this.barY < 0) {
            this.barY = 0;
            this.barVelocity = this.barVelocity < 0 ? -this.barVelocity * c.bounceDamping : this.barVelocity;
            if (this.barVelocity < 0.4) this.barVelocity = 0;
        } else if (this.barY + h > this.trackHeight) {
            this.barY = this.trackHeight - h;
            if (this.barVelocity > 0) this.barVelocity = -this.barVelocity * c.bounceDamping;
        }
    };
    Control.prototype.tickOrb = function () {
        var c = this.c, half = c.orbSize / 2, min = half, max = this.trackHeight - half, r = this.random;
        if (!this.darting && r.nextDouble() < this.dartChance()) {
            this.darting = true;
            var span = max - min;
            this.orbTarget = this.orbY - min > span / 2 ? min + r.nextDouble() * span * 0.3 : max - r.nextDouble() * span * 0.3;
            this.retargetTimer = c.maxRetargetTicks;
        } else if (--this.retargetTimer <= 0 || Math.abs(this.orbTarget - this.orbY) < 1.5) {
            this.darting = false;
            this.orbTarget = min + r.nextDouble() * (max - min);
            var lo = c.minRetargetTicks, hi = Math.max(lo + 1, c.maxRetargetTicks);
            this.retargetTimer = lo + r.nextInt(hi - lo);
        }
        var maxSpeed = this.orbSpeed() * (this.darting ? c.dartSpeedMultiplier : 1);
        var desired = Math.max(-maxSpeed, Math.min(maxSpeed, (this.orbTarget - this.orbY) * 0.15));
        var accel = c.orbAcceleration * (this.darting ? 2 : 1);
        this.orbVelocity += Math.max(-accel, Math.min(accel, desired - this.orbVelocity));
        this.orbY += this.orbVelocity;
        if (this.orbY < min) { this.orbY = min; this.orbVelocity = 0; }
        else if (this.orbY > max) { this.orbY = max; this.orbVelocity = 0; }
    };
    Control.prototype.onLevelUp = function () { this.progress = this.c.progressOnLevelUp; };

    // ===================================================================================
    //  MemoryLogic ("memory", Gohan: Shadow Boxing)
    // ===================================================================================
    var CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", DEV_NAMES = ["YUSE", "SHOKKOH"];
    var TYPING = 0, SUCCESS = 1, TIMEOUT = 2;
    var Memory = extend(function (cfg, seed) {
        Base.call(this, "memory", cfg, cfg.memory, seed);
        this.c = cfg.memory;
        this.sequence = []; this.phase = TYPING; this.index = 0; this.totalTicks = 0; this.totalRemaining = 0;
        this.keyTicks = 0; this.keyRemaining = 0; this.fastDrain = 0; this.phaseTimer = 0;
        this.lives = Math.max(1, this.c.lives); this.wrongTick = -100; this.wrongChar = -1; this.hitTick = -100; this.remapCount = 0;
        this.buildSequence();
    });
    Memory.prototype.sequenceLength = function () {
        var every = Math.max(1, this.c.lengthEveryLevels);
        var len = this.c.baseSequenceLength + Math.floor(this.difficulty() / every);
        return Math.max(1, Math.min(this.c.maxSequenceLength, len));
    };
    Memory.prototype.ticksPerKey = function () { return Math.max(this.c.minTicksPerKey, Math.round(this.c.baseTicksPerKey - this.difficulty() * this.c.ticksPerKeyDecreasePerLevel)); };
    Memory.prototype.rollDevName = function (len) {
        if (this.random.nextDouble() >= 0.01) return null;
        var eligible = DEV_NAMES.filter(function (n) { return n.length <= len + 3; });
        if (!eligible.length) return null;
        return eligible[this.random.nextInt(eligible.length)];
    };
    Memory.prototype.buildSequence = function () {
        var len = this.sequenceLength(), dev = this.rollDevName(len), i;
        if (dev) {
            len = dev.length; this.sequence = [];
            for (i = 0; i < len; i++) this.sequence.push(CHARACTERS.indexOf(dev.charAt(i)));
        } else {
            this.sequence = [];
            for (i = 0; i < len; i++) {
                var ch;
                do { ch = this.random.nextInt(CHAR_COUNT); } while (i > 0 && ch === this.sequence[i - 1]);
                this.sequence.push(ch);
            }
        }
        var perKey = this.ticksPerKey();
        this.totalTicks = perKey * len; this.totalRemaining = this.totalTicks;
        this.keyTicks = Math.round(perKey * this.c.keyTimeMultiplier); this.keyRemaining = this.keyTicks;
        this.fastDrain = 0; this.index = 0; this.phase = TYPING; this.remapCount++;
    };
    Memory.prototype.tickGame = function () {
        var c = this.c;
        if (this.phase === TYPING) {
            var drain = this.fastDrain > 0 ? Math.max(1, c.fastDrainRate) : 1;
            if (this.fastDrain > 0) this.fastDrain--;
            this.totalRemaining -= drain;
            if (--this.keyRemaining <= 0) { this.mistake(-1); this.keyRemaining = this.keyTicks; }
            if (this.totalRemaining <= 0) {
                this.totalRemaining = 0; this.lives--;
                this.samplePerformance(0, 0.16);
                this.phase = TIMEOUT; this.phaseTimer = Math.max(1, c.feedbackTicks * 2);
            }
        } else if (this.phase === SUCCESS) {
            if (--this.phaseTimer <= 0) { this.levelUp(); if (!this.finished) this.buildSequence(); }
        } else if (--this.phaseTimer <= 0) {
            if (this.lives <= 0) this.fail(); else this.buildSequence();
        }
    };
    Memory.prototype.onKeyDown = function (key) {
        if (this.phase !== TYPING) return;
        var ch = key - CHAR_BASE;
        if (ch < 0 || ch >= CHAR_COUNT) return;
        if (ch === this.sequence[this.index]) {
            this.index++; this.hitTick = this.tickN; this.keyRemaining = this.keyTicks;
            this.samplePerformance(1, 0.08);
            if (this.index >= this.sequence.length) { this.phase = SUCCESS; this.phaseTimer = Math.max(1, this.c.feedbackTicks); }
        } else this.mistake(ch);
    };
    Memory.prototype.mistake = function (ch) {
        this.wrongTick = this.tickN; this.wrongChar = ch;
        this.fastDrain += Math.max(0, this.c.wrongKeyDrainTicks);
        this.samplePerformance(0, 0.08);
    };

    // ===================================================================================
    //  PrecisionLogic ("precision", Trunks)
    // ===================================================================================
    var FIELD_WIDTH = 480, FIELD_HEIGHT = 270;
    var Precision = extend(function (cfg, seed) {
        Base.call(this, "precision", cfg, cfg.precision, seed);
        var c = this.c = cfg.precision;
        this.targets = []; this.outcomes = []; this.score = c.startingScore; this.levelStartScore = this.score;
        this.nextThreshold = this.score + Math.max(1, c.scorePerLevel); this.spawnTimer = 0; this.nextCircleId = 1;
    });
    Precision.prototype.ringSpeed = function () { return this.c.baseRingSpeed + this.difficulty() * this.c.ringSpeedPerLevel; };
    Precision.prototype.maxCirclesNow = function () {
        var full = Math.max(1, this.c.maxCirclesFullLevel), t = Math.min(1, this.difficulty() / full);
        return Math.round(this.c.startingMaxCircles + (this.c.maxCircles - this.c.startingMaxCircles) * t);
    };
    Precision.prototype.countActive = function () { var n = 0; this.targets.forEach(function (t) { if (!t.fading) n++; }); return n; };
    Precision.prototype.spawnCircle = function () {
        var mx = Math.max(50, Math.floor(FIELD_WIDTH / 6)), my = Math.max(50, Math.floor(FIELD_HEIGHT / 6));
        var x = mx + this.random.nextInt(Math.max(1, FIELD_WIDTH - 2 * mx)), y = my + this.random.nextInt(Math.max(1, FIELD_HEIGHT - 2 * my));
        this.targets.push({ id: this.nextCircleId++, x: x, y: y, ringRadius: this.c.outerRingRadius, fading: false, fadeRemaining: 0 });
    };
    Precision.prototype.tickGame = function () {
        var c = this.c, maxCircles = this.maxCirclesNow();
        if (--this.spawnTimer <= 0 && this.countActive() < maxCircles) {
            this.spawnCircle();
            if (this.countActive() < maxCircles && this.random.nextDouble() < c.burstChance) this.spawnCircle();
            this.spawnTimer = c.spawnIntervalTicks;
        }
        var speed = this.ringSpeed(), keep = [], i = 0;
        for (; i < this.targets.length && !this.finished; i++) {
            var t = this.targets[i];
            if (t.fading) { if (--t.fadeRemaining > 0) keep.push(t); continue; }
            t.ringRadius -= speed;
            if (t.ringRadius <= c.targetRadius - c.goodWindow) this.missCircle(t);
            keep.push(t);
        }
        for (; i < this.targets.length; i++) keep.push(this.targets[i]);
        this.targets = keep;
    };
    Precision.prototype.onClick = function (mx, my, frac) {
        var c = this.c, target = null, best = Infinity, half = c.targetRadius, speed = this.ringSpeed();
        this.targets.forEach(function (t) {
            if (t.fading) return;
            if (Math.abs(mx - t.x) <= half && Math.abs(my - t.y) <= half) {
                var timing = Math.abs(t.ringRadius - speed * frac - c.targetRadius);
                if (timing < best) { best = timing; target = t; }
            }
        });
        if (!target) return;
        if (best <= c.perfectWindow) this.hit(target, c.perfectPoints, 1.0);
        else if (best <= c.goodWindow) this.hit(target, c.goodPoints, 0.6);
        else this.missCircle(target);
    };
    Precision.prototype.hit = function (t, points, quality) {
        this.score += points;
        this.targets = this.targets.filter(function (x) { return x !== t; });
        this.record(true, quality);
        if (!this.finished && this.score >= this.nextThreshold) this.levelUp();
    };
    Precision.prototype.missCircle = function (t) {
        t.fading = true; t.fadeRemaining = this.c.fadeOutTicks;
        this.score -= this.c.missPenalty;
        this.record(false, 0);
        if (this.score < 0) this.fail();
    };
    Precision.prototype.onLevelUp = function () { this.levelStartScore = this.nextThreshold; this.nextThreshold += Math.max(1, this.c.scorePerLevel); };
    Precision.prototype.record = function (hit, quality) {
        this.samplePerformance(quality, 0.08);
        this.outcomes.push(hit);
        while (this.outcomes.length > this.c.loseMissWindow) this.outcomes.shift();
        var misses = 0;
        this.outcomes.forEach(function (o) { if (!o) misses++; });
        if (misses >= this.c.loseMissThreshold) this.fail();
    };

    // ===================================================================================
    //  GravityLogic ("gravity", Vegeta)
    // ===================================================================================
    var G = { VIEW_WIDTH: 560, VIEW_HEIGHT: 180, GROUND_HEIGHT: 22, PLAYER_X: 120, POD_SPRITE_SIZE: 22, POD_HITBOX_RADIUS: 8,
        BODY_WIDTH: 26, BODY_TILE_HEIGHT: 16, CAP_WIDTH: 38, CAP_HEIGHT: 18, BODY_INSET: 2, CAP_INSET_X: 3, CAP_INSET_EDGE: 3 };
    var Gravity = extend(function (cfg, seed) {
        Base.call(this, "gravity", cfg, cfg.gravity, seed);
        this.c = cfg.gravity;
        this.pillars = []; this.worldX = 0; this.podY = (G.VIEW_HEIGHT - G.GROUND_HEIGHT) / 2; this.velocity = 0;
        this.lives = Math.max(1, this.c.lives); this.invulnerable = 0; this.flapTick = -100; this.passedThisLevel = 0; this.totalPassed = 0;
        this.nextPillarX = G.VIEW_WIDTH + 40; this.lastGapCenter = (G.VIEW_HEIGHT - G.GROUND_HEIGHT) / 2;
        this.fillPillars();
    });
    Gravity.prototype.scrollSpeed = function () { return this.c.baseScrollSpeed + this.difficulty() * this.c.scrollSpeedPerLevel; };
    Gravity.prototype.gapSize = function () { return Math.max(this.c.minGap, this.c.baseGap - this.difficulty() * this.c.gapDecreasePerLevel); };
    Gravity.prototype.spacing = function () { return Math.max(this.c.minSpacing, this.c.baseSpacing - this.difficulty() * this.c.spacingDecreasePerLevel); };
    Gravity.prototype.maxGapShift = function () { return this.c.baseMaxGapShift + this.difficulty() * this.c.maxGapShiftPerLevel; };
    Gravity.prototype.fillPillars = function () {
        var playable = G.VIEW_HEIGHT - G.GROUND_HEIGHT;
        while (this.nextPillarX < this.worldX + G.VIEW_WIDTH + 80) {
            var gap = this.gapSize(), margin = G.CAP_HEIGHT + 8 + gap / 2, shift = this.maxGapShift();
            var lo = Math.max(margin, this.lastGapCenter - shift), hi = Math.min(playable - margin, this.lastGapCenter + shift);
            var center = lo + this.random.nextDouble() * Math.max(0, hi - lo);
            this.pillars.push({ x: this.nextPillarX, gapCenter: center, gap: gap, variant: this.random.nextInt(4), hit: false, passed: false });
            this.lastGapCenter = center;
            this.nextPillarX += this.spacing() + this.random.nextDouble() * this.c.spacingRandom;
        }
    };
    Gravity.prototype.onKeyDown = function (key) {
        if (key !== ACTION) return;
        this.velocity = -this.c.flapVelocity; this.flapTick = this.tickN;
    };
    Gravity.prototype.tickGame = function () {
        var c = this.c;
        if (this.invulnerable > 0) this.invulnerable--;
        this.velocity = Math.min(c.maxFallSpeed, this.velocity + c.gravityAcceleration);
        this.podY += this.velocity;
        if (this.podY < G.POD_HITBOX_RADIUS) { this.podY = G.POD_HITBOX_RADIUS; this.velocity = Math.max(0, this.velocity); }
        var groundTop = G.VIEW_HEIGHT - G.GROUND_HEIGHT;
        if (this.podY + G.POD_HITBOX_RADIUS > groundTop) {
            this.podY = groundTop - G.POD_HITBOX_RADIUS; this.velocity = -c.flapVelocity;
            this.hit();
            if (this.finished) return;
        }
        this.worldX += this.scrollSpeed();
        var podWorldX = this.worldX + G.PLAYER_X, keep = [], i = 0;
        for (; i < this.pillars.length && !this.finished; i++) {
            var p = this.pillars[i];
            if (!p.hit && this.invulnerable <= 0 && collides(p, podWorldX, this.podY)) {
                p.hit = true; this.hit();
                if (this.finished) { keep.push(p); i++; break; }
            }
            if (!p.passed && p.x + G.CAP_WIDTH / 2 < podWorldX - G.POD_HITBOX_RADIUS) {
                p.passed = true;
                this.samplePerformance(p.hit ? 0 : 1, 0.2);
                this.totalPassed++;
                if (++this.passedThisLevel >= Math.max(1, c.pillarsPerLevel)) this.levelUp();
            }
            if (!(p.x + G.CAP_WIDTH < this.worldX - 20)) keep.push(p);
        }
        for (; i < this.pillars.length; i++) keep.push(this.pillars[i]);
        this.pillars = keep;
        if (!this.finished) this.fillPillars();
    };
    Gravity.prototype.hit = function () {
        if (this.invulnerable > 0) return;
        this.lives--; this.invulnerable = this.c.invulnerabilityTicks;
        this.samplePerformance(0, 0.2);
        if (this.lives <= 0) this.fail();
    };
    Gravity.prototype.onLevelUp = function () { this.passedThisLevel = 0; };
    function gapTop(p) { return p.gapCenter - p.gap / 2; }
    function gapBottom(p) { return p.gapCenter + p.gap / 2; }
    function circleRect(cx, cy, x0, y0, x1, y1) {
        if (x1 <= x0 || y1 <= y0) return false;
        var nx = Math.max(x0, Math.min(cx, x1)), ny = Math.max(y0, Math.min(cy, y1)), dx = cx - nx, dy = cy - ny;
        return dx * dx + dy * dy < G.POD_HITBOX_RADIUS * G.POD_HITBOX_RADIUS;
    }
    function collides(p, px, py) {
        var top = gapTop(p), bottom = gapBottom(p), bodyHalf = G.BODY_WIDTH / 2 - G.BODY_INSET, capHalf = G.CAP_WIDTH / 2 - G.CAP_INSET_X;
        var groundTop = G.VIEW_HEIGHT - G.GROUND_HEIGHT;
        return circleRect(px, py, p.x - capHalf, bottom + G.CAP_INSET_EDGE, p.x + capHalf, bottom + G.CAP_HEIGHT)
            || circleRect(px, py, p.x - bodyHalf, bottom + G.CAP_HEIGHT, p.x + bodyHalf, groundTop)
            || circleRect(px, py, p.x - capHalf, top - G.CAP_HEIGHT, p.x + capHalf, top - G.CAP_INSET_EDGE)
            || circleRect(px, py, p.x - bodyHalf, -40, p.x + bodyHalf, top - G.CAP_HEIGHT);
    }

    // ===================================================================================
    //  RhythmLogic ("rhythm", Mr. Popo)
    // ===================================================================================
    var LANES = 4, LEAD_IN_TICKS = 60, MS_PER_TICK = 50, SONG_END_GRACE_MS = 1500, FREE_FIRST_NOTE_MS = 800, REST_MIN_MS = 3000, REST_SETTLE_MS = 300;
    var PENDING = 0, HOLDING = 1, DONE = 2, JUDGE_MISS = 0, JUDGE_GOOD = 1, JUDGE_PERFECT = 2;
    var FREE_NOTES_PER_BEAT = [0.425, 0.85, 1.30, 1.66];
    function clampDifficulty(d) { return Math.max(0, Math.min(3, Math.floor(Number(d)) || 0)); }
    function songTimeMs(tick, frac) { return (tick - LEAD_IN_TICKS + frac) * MS_PER_TICK; }
    var Rhythm = extend(function (cfg, seed, chart, difficulty, variant) {
        Base.call(this, "rhythm", cfg, cfg.rhythm, seed);
        var c = this.c = cfg.rhythm;
        this.chart = chart || null;
        this.variant = chart ? chart.effectiveVariant(variant) : VARIANT_INSTRUMENTAL;
        this.chartNotes = chart ? chart.notesFor(this.variant) : [];
        this.difficultyIndex = clampDifficulty(difficulty === undefined ? 1 : difficulty);
        this.songDifficulty = difficultyOf(c, this.difficultyIndex);
        this.notes = []; this.laneJudgeTick = [-100, -100, -100, -100]; this.laneJudge = [0, 0, 0, 0];
        this.chartIndex = 0; this.freeStepTimeMs = FREE_FIRST_NOTE_MS; this.freeStep = 0; this.freeLaneBusyUntil = [0, 0, 0, 0]; this.freeLastLane = -1;
        this.progress = 0; this.health = c.startingHealth; this.combo = 0; this.maxCombo = 0; this.perfects = 0; this.goods = 0; this.misses = 0;
        this.holdsCompleted = 0; this.lastJudgement = -1; this.lastJudgementTick = -100; this.lastSpawnedEndMs = -Infinity;
        this.resting = false; this.restRemainingMs = 0; this.songCompleted = false;
    });
    Rhythm.prototype.rewardRate = function () {
        var rate = this.baseRewardRate();
        if (!this.chart) return rate;
        return rate * Math.max(0, this.c.songRewardMultiplier) * Math.max(0, this.songDifficulty.rewardMultiplier);
    };
    Rhythm.prototype.songTimeMs = function () { return songTimeMs(this.tickN, 0); };
    Rhythm.prototype.songProgress = function () {
        if (!this.chart || this.chart.durationMs <= 0) return 0;
        return Math.max(0, Math.min(1, this.songTimeMs() / this.chart.durationMs));
    };
    Rhythm.prototype.intensity = function () {
        if (!this.chart) return (this.allowedTier() + 1) / 4;
        var s = this.songDifficulty.startIntensity;
        return s + (this.songDifficulty.endIntensity - s) * this.songProgress();
    };
    Rhythm.prototype.travelMs = function () {
        if (this.chart) { var s = this.songDifficulty.startTravelMs; return Math.round(s + (this.songDifficulty.endTravelMs - s) * this.songProgress()); }
        return Math.max(this.c.minTravelMs, this.c.baseTravelMs - this.difficulty() * this.c.travelMsDecreasePerLevel);
    };
    Rhythm.prototype.allowedTier = function () {
        if (this.chart) return Math.max(0, Math.min(3, Math.floor(this.intensity() * 4)));
        return Math.min(3, Math.floor(this.difficulty() / Math.max(1, this.c.densityTierEveryLevels)));
    };
    Rhythm.prototype.tickGame = function () {
        var now = this.songTimeMs(), c = this.c;
        this.progress = Math.max(0, this.progress - c.progressDecayPerTick);
        this.spawnNotes(now);
        var keep = [], i = 0;
        for (; i < this.notes.length && !this.finished; i++) {
            var n = this.notes[i];
            if (n.state === HOLDING) {
                if (now >= n.timeMs + n.lengthMs) {
                    n.state = DONE; this.holdsCompleted++;
                    this.progress += this.noteProgress() * c.holdProgressFactor;
                    this.samplePerformance(1, 0.06);
                    this.checkLevel();
                }
            } else if (n.state === PENDING && now > n.timeMs + c.goodWindowMs) {
                n.state = DONE; this.miss(n.lane);
            }
            if (!(n.state === DONE && now > n.timeMs + n.lengthMs + 400)) keep.push(n);
        }
        for (; i < this.notes.length; i++) keep.push(this.notes[i]);
        this.notes = keep;
        if (this.finished) return;
        if (this.chart) this.updateRest(now);
        if (this.chart && this.chartIndex >= this.chartNotes.length && now > this.chart.durationMs + SONG_END_GRACE_MS) {
            var pending = this.notes.some(function (x) { return x.state !== DONE; });
            if (!pending) { this.songCompleted = true; this.complete(); }
        }
    };
    Rhythm.prototype.updateRest = function (now) {
        this.resting = false; this.restRemainingMs = 0;
        if (this.lastSpawnedEndMs === -Infinity || now < this.lastSpawnedEndMs + REST_SETTLE_MS) return;
        for (var j = 0; j < this.notes.length; j++) if (this.notes[j].state !== DONE) return;
        var intensity = this.intensity(), next = -1;
        for (var i = this.chartIndex; i < this.chartNotes.length; i++) if (this.chartNotes[i].level <= intensity) { next = this.chartNotes[i].timeMs; break; }
        if (next < 0 || next - this.lastSpawnedEndMs < REST_MIN_MS) return;
        var visibleAt = next - this.travelMs();
        if (visibleAt <= now) return;
        this.resting = true; this.restRemainingMs = Math.ceil(visibleAt - now);
    };
    Rhythm.prototype.spawnNotes = function (now) {
        var travel = this.travelMs();
        if (this.chart) {
            var intensity = this.intensity();
            while (this.chartIndex < this.chartNotes.length && this.chartNotes[this.chartIndex].timeMs - travel <= now + MS_PER_TICK) {
                var n = this.chartNotes[this.chartIndex++];
                if (n.level <= intensity) {
                    this.notes.push({ timeMs: n.timeMs, lane: n.lane, lengthMs: n.lengthMs, travelMs: travel, state: PENDING, hitTick: -1, dropped: false });
                    this.lastSpawnedEndMs = Math.max(this.lastSpawnedEndMs, n.timeMs + n.lengthMs);
                }
            }
            return;
        }
        var tier = this.allowedTier();
        while (this.freeStepTimeMs - travel <= now + MS_PER_TICK) this.generateFreeStep(travel, tier);
    };
    Rhythm.prototype.freeBpm = function () { return Math.min(this.c.freeMaxBpm, this.c.freeBaseBpm + this.difficulty() * this.c.freeBpmPerLevel); };
    Rhythm.prototype.generateFreeStep = function (travel, tier) {
        var c = this.c, r = this.random, beatMs = 60000 / this.freeBpm(), position = this.freeStep % 4, chance, noteTier;
        if (position === 0) { chance = 0.85; noteTier = Math.floor(this.freeStep / 4) % 2 === 0 ? 0 : 1; }
        else if (position === 2) { chance = 0.45; noteTier = 2; }
        else { chance = 0.18; noteTier = 3; }
        var time = Math.round(this.freeStepTimeMs);
        if (noteTier <= tier && r.nextDouble() < chance) {
            var lane = this.pickFreeLane(time);
            if (lane >= 0) {
                var length = 0;
                if (position === 0 && r.nextDouble() < c.freeHoldChance) length = Math.round(beatMs * (1 + r.nextInt(2)) - 80);
                this.notes.push({ timeMs: time, lane: lane, lengthMs: length, travelMs: travel, state: PENDING, hitTick: -1, dropped: false });
                this.freeLaneBusyUntil[lane] = time + length + 150;
                this.freeLastLane = lane;
                if (position === 0 && length === 0 && tier >= 2 && r.nextDouble() < c.freeChordChance) {
                    var partner = (lane + 2) % LANES;
                    if (this.freeLaneBusyUntil[partner] <= time) {
                        this.notes.push({ timeMs: time, lane: partner, lengthMs: 0, travelMs: travel, state: PENDING, hitTick: -1, dropped: false });
                        this.freeLaneBusyUntil[partner] = time + 150;
                    }
                }
            }
        }
        this.freeStep++;
        this.freeStepTimeMs += beatMs / 4;
    };
    Rhythm.prototype.pickFreeLane = function (time) {
        var start = this.random.nextInt(LANES), lane, i;
        for (i = 0; i < LANES; i++) {
            lane = (start + i) % LANES;
            if (this.freeLaneBusyUntil[lane] > time) continue;
            if (lane === this.freeLastLane && this.random.nextDouble() < 0.7) continue;
            return lane;
        }
        for (lane = 0; lane < LANES; lane++) if (this.freeLaneBusyUntil[lane] <= time) return lane;
        return -1;
    };
    Rhythm.prototype.onKeyDown = function (key, frac) {
        if (key < 0 || key >= LANES || this.resting) return;
        var c = this.c, press = songTimeMs(this.tickN, frac), best = null, bestDist = Infinity;
        this.notes.forEach(function (n) {
            if (n.state !== PENDING || n.lane !== key) return;
            var d = Math.abs(press - n.timeMs);
            if (d <= c.goodWindowMs && d < bestDist) { bestDist = d; best = n; }
        });
        if (!best) { this.ghost(); return; }
        var perfect = bestDist <= c.perfectWindowMs;
        if (perfect) this.perfects++; else this.goods++;
        this.combo++; this.maxCombo = Math.max(this.maxCombo, this.combo);
        this.progress += this.noteProgress() * (perfect ? 1 : c.goodProgressFactor);
        this.health = Math.min(1, this.health + (perfect ? c.healthGainPerfect : c.healthGainGood));
        this.samplePerformance(perfect ? 1 : 0.6, 0.06);
        this.judge(key, perfect ? JUDGE_PERFECT : JUDGE_GOOD);
        best.hitTick = this.tickN;
        best.state = best.lengthMs > 0 ? HOLDING : DONE;
        this.checkLevel();
    };
    Rhythm.prototype.onKeyUp = function (key, frac) {
        if (key < 0 || key >= LANES) return;
        var release = songTimeMs(this.tickN, frac);
        for (var i = 0; i < this.notes.length; i++) {
            var n = this.notes[i];
            if (n.state !== HOLDING || n.lane !== key) continue;
            n.state = DONE;
            if (release >= n.timeMs + n.lengthMs - this.c.holdReleaseGraceMs) {
                this.holdsCompleted++;
                this.progress += this.noteProgress() * this.c.holdProgressFactor;
                this.samplePerformance(1, 0.06);
                this.checkLevel();
            } else { n.dropped = true; this.miss(key); }
            return;
        }
    };
    Rhythm.prototype.currentDensity = function () {
        if (this.chart) return Math.max(0.3, this.chart.densityAt(this.intensity(), this.variant));
        return FREE_NOTES_PER_BEAT[this.allowedTier()] * this.freeBpm() / 60;
    };
    Rhythm.prototype.noteProgress = function () {
        var needed = this.c.progressMax - this.c.progressOnLevelUp;
        return needed / (Math.max(1, this.c.targetSecondsPerLevel) * this.currentDensity());
    };
    Rhythm.prototype.ghost = function () {
        this.combo = 0; this.health -= this.c.healthLossOnGhost;
        if (this.health <= 0) this.fail();
    };
    Rhythm.prototype.miss = function (lane) {
        this.misses++; this.combo = 0;
        this.progress = Math.max(0, this.progress - this.c.progressLossOnMiss);
        this.health -= this.c.healthLossOnMiss;
        this.samplePerformance(0, 0.06);
        this.judge(lane, JUDGE_MISS);
        if (this.health <= 0) { this.health = 0; this.fail(); }
    };
    Rhythm.prototype.judge = function (lane, v) { this.lastJudgement = v; this.lastJudgementTick = this.tickN; this.laneJudge[lane] = v; this.laneJudgeTick[lane] = this.tickN; };
    Rhythm.prototype.checkLevel = function () { if (!this.finished && this.progress >= this.c.progressMax) this.levelUp(); };
    Rhythm.prototype.onLevelUp = function () { this.progress = this.c.progressOnLevelUp; };
    Rhythm.prototype.judgedNotes = function () { return this.perfects + this.goods + this.misses; };
    Rhythm.prototype.accuracy = function () { var j = this.judgedNotes(); return j === 0 ? 1 : (this.perfects + this.goods * 0.6) / j; };

    /** MinigameLogics.create */
    function create(id, cfg, seed, chart, difficulty, variant) {
        switch (id) {
            case "control": return new Control(cfg, seed);
            case "memory": return new Memory(cfg, seed);
            case "precision": return new Precision(cfg, seed);
            case "gravity": return new Gravity(cfg, seed);
            default: return new Rhythm(cfg, seed, chart, difficulty, variant);
        }
    }

    /** "Music Disc - Dragon Ball - Bulma is Happy by Shunsuke Kikuchi" -> [title, artist, source] (RythmGameScreen.parseDiscInfo) */
    function parseDiscInfo(displayName) {
        var text = String(displayName || "").replace(/&[0-9a-fk-or]/gi, "").trim();
        if (text.toLowerCase().indexOf("music disc - ") === 0) text = text.substring(13).trim();
        var artist = null, by = text.lastIndexOf(" by ");
        if (by > 0) { artist = text.substring(by + 4).trim(); text = text.substring(0, by).trim(); }
        var source = null, title = text, sep = text.lastIndexOf(" - ");
        if (sep > 0) { source = text.substring(0, sep).trim(); title = text.substring(sep + 3).trim(); }
        if (!title) title = displayName;
        return [title, artist, source];
    }

    return {
        KEY_DOWN: KEY_DOWN, KEY_UP: KEY_UP, CLICK: CLICK, LEFT: LEFT, DOWN: DOWN, UP: UP, RIGHT: RIGHT, ACTION: ACTION,
        CHAR_BASE: CHAR_BASE, CHAR_COUNT: CHAR_COUNT, KEY_COUNT: KEY_COUNT, CHARACTERS: CHARACTERS,
        keyEvent: keyEvent, clickEvent: clickEvent, validEvent: validEvent,
        IDS: IDS, CHALLENGE_STAGES: CHALLENGE_STAGES, isValidId: isValidId, SONGS: SONGS, findSong: findSong, isBuiltinSong: isBuiltinSong,
        DEFAULTS: DEFAULTS, mergeCfg: mergeCfg, settingsOf: settingsOf, computeTpsPerMinute: computeTpsPerMinute,
        challengeTargetLevels: challengeTargetLevels, difficultyOf: difficultyOf, clampDifficulty: clampDifficulty, clampVariant: clampVariant,
        Chart: Chart, ChartBuild: ChartBuild, recommendedDifficulty: recommendedDifficulty, create: create, parseDiscInfo: parseDiscInfo,
        MEMORY: { TYPING: TYPING, SUCCESS: SUCCESS, TIMEOUT: TIMEOUT },
        PRECISION: { FIELD_WIDTH: FIELD_WIDTH, FIELD_HEIGHT: FIELD_HEIGHT },
        GRAVITY: G, gapTop: gapTop, gapBottom: gapBottom,
        RHYTHM: { LANES: LANES, LEAD_IN_TICKS: LEAD_IN_TICKS, MS_PER_TICK: MS_PER_TICK, PENDING: PENDING, HOLDING: HOLDING, DONE: DONE,
            JUDGE_MISS: JUDGE_MISS, JUDGE_GOOD: JUDGE_GOOD, JUDGE_PERFECT: JUDGE_PERFECT, songTimeMs: songTimeMs, VARIANT_VOCAL: VARIANT_VOCAL }
    };
})();
