// =====================================================================================
//  16_dbr_space_gen.js - the generated universe (server and client)
// =====================================================================================
//  Port of DMZ Ragnarok's GeneratedSystems, GeneratedPlanets (system planets), StarPositions
//  and BlackHolePositions (GPL-3.0). Everything is a pure function of grid cells and
//  64-bit hashes (bit-identical to DMZR's Java), so the server and every client derive
//  the same stars, planets and black holes with nothing stored or synced:
//    - star systems: one candidate per sector cell (density 0.5), a sun of radius 62..82
//      with 5..9 planets on rings 500 + 360*i blocks, each orbiting with wall-clock time;
//      planet size 100..500 (surface) -> body radius 32..96; tint per planet.
//    - lone stars (3072 grid, 3D, density 0.24) that burn whoever flies close;
//    - black holes (6144 grid, 3D, density 0.2): pull 30x their radius, kill at the horizon.
//  DBR scale: the sector size follows distanceScale (never under 12000 so systems keep
//  apart), and the systems' vertical spread is scaled like the main system's rings.
// =====================================================================================
var DBR_SPACE_GEN = (function () {
    var O = DBR_SPACE_ORBITS, U = O.u64;
    var C_CY = U.make(0xC2B2AE3D, 0x27D4EB4F), C_CZ = U.make(0x165667B1, 0x9E3779F9), C_MIX = U.make(0xD6E8FEB8, 0x6659FD93);

    /** GeneratedSystems/StarPositions/BlackHolePositions.hash(cx, cy, cz) */
    function cellHash(cx, cy, cz) {
        var z = U.xor(U.xor(U.mul(U.fromInt(cx), U.C1), U.mul(U.fromInt(cy), C_CY)), U.mul(U.fromInt(cz), C_CZ));
        return U.finish(z);
    }
    function mix(h, index) {
        return U.finish(U.xor(h, U.mul(U.fromInt(index + 1), C_MIX)));
    }
    var unit = U.unit;

    // ---- settings (both sides read the same config values) ----
    var cfg = { scale: 0.25, planeY: 0 };
    function configure(scale, planeY) { cfg.scale = scale; cfg.planeY = planeY; CACHE = {}; }
    function systemSector() { return Math.max(12000, Math.round(20000 * cfg.scale)); }

    // ---- star systems (GeneratedSystems.systemAt) ----
    var INNER_RING = 500, RING_STEP = 360, MIN_PLANETS = 5, MAX_PLANETS = 9, MAX_OUTER_RING = INNER_RING + (MAX_PLANETS - 1) * RING_STEP;
    var STAR_MIN_R = 62, STAR_MAX_R = 82, ORIGIN_CLEAR = 1200, INNER_CLEAR = 5000;
    var MIN_SURFACE = 100, MAX_SURFACE = 500, MIN_BODY_R = 32, MAX_BODY_R = 96;
    var BODY_FLOOR_Y = -11744, BODY_CEILING_Y = 11936;
    var CACHE = {};

    var SIZE_MEMO = {};
    function surfaceSizeForId(id) {
        if (SIZE_MEMO[id] !== undefined) return SIZE_MEMO[id];
        return (SIZE_MEMO[id] = surfaceSizeRaw(id));
    }
    function surfaceSizeRaw(id) {
        var h = O.hash(id + "#surface");
        var s = MIN_SURFACE + Math.floor((U.shr(h, 20).lo & 0xFFFFFF) / 16777216 * (MAX_SURFACE - MIN_SURFACE));
        return s - (s & 1);
    }
    function bodyRadiusForSurface(size) {
        var f = Math.max(0, Math.min(1, (size - MIN_SURFACE) / (MAX_SURFACE - MIN_SURFACE)));
        return MIN_BODY_R + f * (MAX_BODY_R - MIN_BODY_R);
    }
    function starTint(h) {
        return ((235 + Math.floor(unit(h, 16) * 20)) << 16) | ((180 + Math.floor(unit(h, 24) * 55)) << 8) | (90 + Math.floor(unit(h, 8) * 70));
    }
    function planetTint(h) {
        return ((96 + Math.floor(unit(h, 16) * 150)) << 16) | ((96 + Math.floor(unit(h, 40) * 150)) << 8) | (96 + Math.floor(unit(h, 8) * 150));
    }

    // lazy lookups (the client's sky) compute at most `budget` new cells per tick and fill the rest in later
    var lazy = { on: false, left: 0 };
    function setBudget(n) { lazy.on = n > 0; lazy.left = n; }
    // cost: cells a lookup may need under it (a star checks the black holes and systems round it), so nothing is cached half-checked
    function spend(cost) { if (!lazy.on) return true; if (lazy.left < (cost || 1)) return false; lazy.left--; return true; }
    function systemAt(cx, cz) {
        var key = cx + "," + cz;
        if (CACHE.hasOwnProperty(key)) return CACHE[key];
        if (!spend()) return null;
        var sys = null, h = cellHash(cx, 0, cz);
        if (unit(h, 0) < 0.5) {
            var sector = systemSector();
            var sx = cx * sector + (0.3 + unit(h, 24) * 0.4) * sector, sz = cz * sector + (0.3 + unit(h, 8) * 0.4) * sector;
            var hyp = Math.sqrt(sx * sx + sz * sz);
            if (hyp > ORIGIN_CLEAR + MAX_OUTER_RING && hyp > INNER_CLEAR + MAX_OUTER_RING) {
                var count = Math.min(MAX_PLANETS, MIN_PLANETS + Math.floor(unit(h, 32) * (MAX_PLANETS - MIN_PLANETS + 1)));
                var reach = MAX_BODY_R;                                    // flat orbits: no lift
                var lowY = BODY_FLOOR_Y + reach, highY = BODY_CEILING_Y - reach;
                var sy = cfg.planeY + (lowY + unit(h, 40) * (highY - lowY)) * cfg.scale;
                var starKey = "sustar:" + U.hex48(h);
                sys = { key: starKey, cx: cx, cz: cz, x: sx, y: sy, z: sz, radius: STAR_MIN_R + unit(h, 16) * (STAR_MAX_R - STAR_MIN_R),
                    tint: starTint(h), planets: [] };
                for (var i = 0; i < count; i++) {
                    var ph = mix(h, i), id = "sugen:" + U.hex48(ph), size = surfaceSizeForId(id);
                    sys.planets.push({ id: id, ring: INNER_RING + i * RING_STEP, phase0: (ph.lo / 4294967296) * Math.PI * 2, surface: size,
                        radius: bodyRadiusForSurface(size), tint: planetTint(ph), system: sys, index: i });
                }
            }
        }
        CACHE[key] = sys;
        return sys;
    }
    function planetPos(p, epoch) {
        var s = p.system, a = O.angle(p.phase0, O.periodMillis(p.ring), epoch);
        return { x: s.x + Math.cos(a) * p.ring, y: s.y, z: s.z + Math.sin(a) * p.ring };
    }
    function systemsNear(x, z, range) {
        var out = [], sector = systemSector(), reach = range + MAX_OUTER_RING + MAX_BODY_R;
        var c0 = Math.floor((x - reach) / sector), c1 = Math.floor((x + reach) / sector);
        var d0 = Math.floor((z - reach) / sector), d1 = Math.floor((z + reach) / sector);
        for (var cx = c0; cx <= c1; cx++) for (var cz = d0; cz <= d1; cz++) { var s = systemAt(cx, cz); if (s) out.push(s); }
        return out;
    }
    /** The system planet whose cube (radius + margin) holds the point, or null (GeneratedSystems.planetContaining). */
    function planetContaining(p, margin, epoch) {
        var list = systemsNear(p.x, p.z, MAX_OUTER_RING + margin + MAX_BODY_R);
        for (var i = 0; i < list.length; i++) for (var j = 0; j < list[i].planets.length; j++) {
            var pl = list[i].planets[j], pp = planetPos(pl, epoch), r = pl.radius + margin;
            if (Math.abs(p.x - pp.x) <= r && Math.abs(p.y - pp.y) <= r && Math.abs(p.z - pp.z) <= r) return { planet: pl, pos: pp };
        }
        return null;
    }
    /** A cached system by its sun's key ("sustar:..."), or null. */
    function findSystem(key) { for (var k in CACHE) { var s = CACHE[k]; if (s && s.key === key) return s; } return null; }
    var BY_ID = {};
    function findPlanet(id) {
        if (BY_ID[id]) return BY_ID[id];
        for (var k in CACHE) { var s = CACHE[k]; if (s) for (var j = 0; j < s.planets.length; j++) if (s.planets[j].id === id) return (BY_ID[id] = s.planets[j]); }
        return null;
    }
    function nearSystemBody(x, y, z, pad) {
        var list = systemsNear(x, z, pad);
        for (var i = 0; i < list.length; i++) {
            var s = list[i], dx = x - s.x, dz = z - s.z;
            if (Math.sqrt(dx * dx + dz * dz) <= MAX_OUTER_RING + MAX_BODY_R + pad && Math.abs(y - s.y) <= MAX_BODY_R + pad) return true;
        }
        return false;
    }

    // ---- lone stars (StarPositions) ----
    var STAR_SECTOR = 3072, STAR_DENSITY = 0.24, STAR_MIN_Y = -1776, STAR_MAX_Y = 1968, LS_MIN_R = 36, LS_MAX_R = 82;
    var STAR_CACHE = {};
    function loneStarTint(h) {
        var cls = unit(h, 40), r, g, b;
        if (cls < 0.12) { r = 30 + Math.floor(unit(h, 16) * 55); g = 90 + Math.floor(unit(h, 24) * 70); b = 205 + Math.floor(unit(h, 8) * 50); }
        else if (cls < 0.62) { r = 235 + Math.floor(unit(h, 16) * 20); g = 120 + Math.floor(unit(h, 24) * 45); b = 20 + Math.floor(unit(h, 8) * 30); }
        else { r = 200 + Math.floor(unit(h, 16) * 55); g = 40 + Math.floor(unit(h, 24) * 55); b = 25 + Math.floor(unit(h, 8) * 35); }
        return (r << 16) | (g << 8) | b;
    }
    function insideInner(x, z, pad) { return Math.abs(x) <= ORIGIN_CLEAR + pad && Math.abs(z) <= ORIGIN_CLEAR + pad || Math.sqrt(x * x + z * z) <= INNER_CLEAR + pad; }
    function loneStarAt(cx, cy, cz) {
        var key = cx + "," + cy + "," + cz;
        if (STAR_CACHE.hasOwnProperty(key)) return STAR_CACHE[key];
        if (!spend(12)) return null;
        var st = null, h = cellHash(cx, cy, cz);
        if (unit(h, 0) < STAR_DENSITY) {
            var r = LS_MIN_R + unit(h, 32) * (LS_MAX_R - LS_MIN_R);
            var x = cx * STAR_SECTOR + unit(h, 24) * STAR_SECTOR, y = cy * STAR_SECTOR + unit(h, 40) * STAR_SECTOR, z = cz * STAR_SECTOR + unit(h, 8) * STAR_SECTOR;
            if (y - r >= STAR_MIN_Y && y + r <= STAR_MAX_Y && !insideInner(x, z, r) && !blackHoleNear(x, y + cfg.planeY, z, r + 256) && !nearSystemBody(x, y + cfg.planeY, z, r))
                st = { key: "sustar:" + U.hex48(h), x: x, y: y + cfg.planeY, z: z, radius: r, tint: loneStarTint(h) };
        }
        STAR_CACHE[key] = st;
        return st;
    }
    function grid3(x, y, z, range, sector, minY, maxY, fn) {
        var out = [];
        var c0 = Math.floor((x - range) / sector), c1 = Math.floor((x + range) / sector);
        var d0 = Math.floor((z - range) / sector), d1 = Math.floor((z + range) / sector);
        var e0 = Math.floor((Math.max(y - cfg.planeY - range, minY)) / sector), e1 = Math.floor((Math.min(y - cfg.planeY + range, maxY)) / sector);
        for (var cx = c0; cx <= c1; cx++) for (var cy = e0; cy <= e1; cy++) for (var cz = d0; cz <= d1; cz++) { var v = fn(cx, cy, cz); if (v) out.push(v); }
        return out;
    }
    function loneStarsNear(x, y, z, range) {
        return grid3(x, y, z, range, STAR_SECTOR, STAR_MIN_Y, STAR_MAX_Y, loneStarAt).filter(function (s) { var dx = s.x - x, dy = s.y - y, dz = s.z - z; return dx * dx + dy * dy + dz * dz <= range * range; });
    }

    // ---- black holes (BlackHolePositions) ----
    var BH_SECTOR = 6144, BH_DENSITY = 0.2, BH_MIN_Y = -1520, BH_MAX_Y = 1840, BH_MIN_R = 40, BH_MAX_R = 80;
    var BH_CACHE = {};
    function blackHoleAt(cx, cy, cz) {
        var key = cx + "," + cy + "," + cz;
        if (BH_CACHE.hasOwnProperty(key)) return BH_CACHE[key];
        if (!spend(6)) return null;
        var bh = null, h = cellHash(cx, cy, cz);
        if (unit(h, 0) < BH_DENSITY) {
            var r = BH_MIN_R + unit(h, 32) * (BH_MAX_R - BH_MIN_R);
            var x = cx * BH_SECTOR + unit(h, 24) * BH_SECTOR, y = cy * BH_SECTOR + unit(h, 40) * BH_SECTOR, z = cz * BH_SECTOR + unit(h, 8) * BH_SECTOR;
            if (y >= BH_MIN_Y && y <= BH_MAX_Y && !insideInner(x, z, r * 50) && !nearSystemBody(x, y + cfg.planeY, z, r))
                bh = { key: "subh:" + U.hex48(h), x: x, y: y + cfg.planeY, z: z, radius: r, pull: r * 30, horizon: r * 0.55 };
        }
        BH_CACHE[key] = bh;
        return bh;
    }
    function blackHoleNear(x, y, z, pad) {
        var cx = Math.floor(x / BH_SECTOR), cy = Math.floor((y - cfg.planeY) / BH_SECTOR), cz = Math.floor(z / BH_SECTOR);
        for (var a = -1; a <= 1; a++) for (var b = -1; b <= 1; b++) for (var c = -1; c <= 1; c++) {
            var bh = blackHoleAt(cx + a, cy + b, cz + c);
            if (bh && Math.abs(bh.x - x) <= bh.radius + pad && Math.abs(bh.y - y) <= bh.radius + pad && Math.abs(bh.z - z) <= bh.radius + pad) return true;
        }
        return false;
    }
    function blackHolesNear(x, y, z, range) {
        return grid3(x, y, z, range, BH_SECTOR, BH_MIN_Y, BH_MAX_Y, blackHoleAt).filter(function (s) { var dx = s.x - x, dy = s.y - y, dz = s.z - z; return dx * dx + dy * dy + dz * dz <= range * range; });
    }
    function trim() {
        // keep the caches small on long flights
        var n = 0; for (var k in CACHE) n++;
        if (n > 4000) { CACHE = {}; BY_ID = {}; }
        n = 0; for (k in STAR_CACHE) n++;
        if (n > 20000) STAR_CACHE = {};
        n = 0; for (k in BH_CACHE) n++;
        if (n > 20000) BH_CACHE = {};
    }

    return { configure: configure, systemAt: systemAt, systemsNear: systemsNear, planetPos: planetPos, planetContaining: planetContaining,
        findPlanet: findPlanet, findSystem: findSystem, loneStarsNear: loneStarsNear, blackHolesNear: blackHolesNear, surfaceSizeForId: surfaceSizeForId,
        sector: systemSector, MAX_OUTER_RING: MAX_OUTER_RING, cellHash: cellHash, trim: trim, setBudget: setBudget };
})();
