// =====================================================================================
//  20_dbr_dungeons_data.js - DMZ Ragnarok's Dungeons: data shared by server and client
// =====================================================================================
//  Port of DMZ Ragnarok's shuruis_dmz_dungeons module (GPL-3.0, by Shurui): the floor model
//  (DungeonFloorConfig), the spawner model (SpawnerConfig / SpawnerPreset / CustomDrop), the
//  crate loot model (DungeonCrateLoot, CrateTier, CrateMetal, DungeonCrateDefaults), the layout
//  styles (LayoutStyle) and the floor grid maths (DungeonFloorLayout). Same field names and
//  defaults, so a floor reads the way it did in DMZ Ragnarok.
//  The server half is scripts/90_dbr_dungeons*.js, the screens client/scripts/80_dbr_dungeons.js.
// =====================================================================================
var DBRD = (function () {
    var THEMES = ["OVERWORLD", "NAMEK", "NETHER", "END", "KAIO", "OTHERWORLD", "VEGETA", "BEERUS"];
    var RETAINED_THEMES = ["STONY"];
    var TYPES = ["NORMAL", "BOSS"];
    // LayoutStyle(sealsOutward, defaultSizeBlocks, minSizeBlocks, maxSizeBlocks)
    var STYLES = {
        SPINE_AND_RIBS: { seals: true, def: 256, min: 192, max: 448 },
        ROADS_AND_BUILDINGS: { seals: false, def: 1056, min: 1024, max: 1120 },
        INSUFFERABLE_CRYPT: { seals: true, def: 320, min: 256, max: 512 }
    };
    var STYLE_NAMES = ["SPINE_AND_RIBS", "ROADS_AND_BUILDINGS", "INSUFFERABLE_CRYPT"];
    var MIN_SIZE = 64, MAX_SIZE = 1120, MIN_DEPTH = 16, MAX_DEPTH = 124;
    var CELL = 16, CELL_SPACING = 100000, MAX_FLOOR_INDEX = 299, SURFACE_Y = 128;

    // theme -> dimension (DungeonDimensions.levelForTheme; KAIO lives in the "kai" dimension)
    function dimFor(theme) {
        switch (String(theme || "").toUpperCase()) {
            case "NAMEK": return "dbr:dungeon_namek";
            case "KAIO": case "KAI": return "dbr:dungeon_kai";
            case "STONY": return "dbr:dungeon_stony";
            case "OTHERWORLD": return "dbr:dungeon_otherworld";
            case "NETHER": return "dbr:dungeon_nether";
            case "END": return "dbr:dungeon_end";
            case "VEGETA": case "SAIYAN": return "dbr:dungeon_vegeta";
            case "BEERUS": return "dbr:dungeon_beerus";
            default: return "dbr:dungeon_overworld";
        }
    }
    var DIMS = ["overworld", "namek", "kai", "stony", "otherworld", "nether", "end", "vegeta", "beerus"].map(function (d) { return "dbr:dungeon_" + d; });
    function isDungeonDim(dim) { return DIMS.indexOf(String(dim)) >= 0; }
    // palette file for a theme (data/dbr_dungeons/palettes/<name>.json)
    function paletteFor(theme) {
        var t = String(theme || "").toUpperCase();
        if (t === "KAIO") return "kai";
        if (t === "SAIYAN") return "vegeta";
        var all = { OVERWORLD: 1, NAMEK: 1, NETHER: 1, END: 1, OTHERWORLD: 1, VEGETA: 1, BEERUS: 1, STONY: 1, KAI: 1 };
        return all[t] ? t.toLowerCase() : "overworld";
    }
    function canonicalTheme(s) {
        var u = String(s || "").toUpperCase(), i;
        for (i = 0; i < THEMES.length; i++) if (THEMES[i] === u) return u;
        for (i = 0; i < RETAINED_THEMES.length; i++) if (RETAINED_THEMES[i] === u) return u;
        return "OVERWORLD";
    }
    function canonicalType(s) { return String(s || "").toUpperCase() === "BOSS" ? "BOSS" : "NORMAL"; }
    function canonicalStyle(s) { var u = String(s || "").toUpperCase(); return STYLES[u] ? u : ""; }
    function defaultTheme(n) {
        var rot = ["OVERWORLD", "VEGETA", "NAMEK", "NETHER", "KAIO", "END"];
        return rot[((n - 1) % rot.length + rot.length) % rot.length];
    }

    // ---- floor grid (DungeonFloorLayout) ----
    function clampedIndex(n) { return Math.max(1, Math.min(MAX_FLOOR_INDEX, n)); }
    function clampedEpoch(e) { return Math.max(0, Math.min(MAX_FLOOR_INDEX, e | 0)); }
    function cellCentre(floor, epoch) { return { x: clampedIndex(floor) * CELL_SPACING, y: SURFACE_Y, z: clampedEpoch(epoch) * CELL_SPACING }; }
    function floorForX(x) { return Math.round(x / CELL_SPACING); }

    // ---- deterministic hashing (stands in for DMZR's 64-bit splitmix mixer) ----
    function mix() {
        var h = 0x811C9DC5 | 0;
        for (var i = 0; i < arguments.length; i++) {
            var v = arguments[i];
            if (typeof v === "string") { for (var c = 0; c < v.length; c++) h = Math.imul(h ^ v.charCodeAt(c), 0x01000193); }
            else { v = Math.floor(v) | 0; h = Math.imul(h ^ v, 0x9E3779B1); h ^= Math.floor(arguments[i] / 4294967296) | 0; }
            h = Math.imul(h ^ (h >>> 15), 0x85EBCA77); h ^= h >>> 13;
        }
        h = Math.imul(h ^ (h >>> 16), 0x7FEB352D); h = Math.imul(h ^ (h >>> 15), 0x846CA68B);
        return (h ^ (h >>> 16)) >>> 0;
    }
    function rng(seed) {                               // mulberry32
        var s = seed >>> 0;
        return function () {
            s = (s + 0x6D2B79F5) >>> 0;
            var t = Math.imul(s ^ (s >>> 15), 1 | s);
            t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    }
    function floorSeed(n) { return mix(n, 0x2545F491, 0x9E3779B9); }
    function rollSizeBlocks(style, r) {
        var s = STYLES[style] || STYLES.SPINE_AND_RIBS;
        var span = Math.max(0, Math.floor((s.max - s.min) / (2 * CELL)));
        return s.min + (span <= 0 ? 0 : Math.floor(r() * (span + 1))) * 2 * CELL;
    }

    // ---- crates (CrateTier / CrateMetal / DungeonCrateLoot) ----
    var TIERS = [
        { key: "common", color: "#9E9E9E", pitch: 0.85 }, { key: "uncommon", color: "#3FA34D", pitch: 1.0 },
        { key: "rare", color: "#3B6FE0", pitch: 1.15 }, { key: "mythic", color: "#E0862B", pitch: 1.3 }];
    var METALS = [{ key: "bronze", color: "#B87333" }, { key: "iron", color: "#C7C9CC" }, { key: "gold", color: "#E6B422" }];
    var TIER_WEIGHTS = [60, 25, 12, 3], METAL_WEIGHTS = [60, 30, 10];
    var TICKS_PER_HOUR = 72000;
    function epoch(gameTime, refreshHours) { return refreshHours <= 0 ? 0 : Math.floor(gameTime / (refreshHours * TICKS_PER_HOUR)); }
    function weighted(weights, defaults, pick01) {
        var w = (weights && weights.length >= defaults.length) ? weights.map(function (v) { return Math.max(0, v | 0); }) : defaults;
        var total = 0; w.forEach(function (v) { total += v; });
        if (total <= 0) { w = defaults; total = 0; w.forEach(function (v) { total += v; }); }
        var p = Math.floor(pick01 * total), acc = 0;
        for (var i = 0; i < w.length; i++) { acc += w[i]; if (p < acc) return i; }
        return 0;
    }
    function rollTier(posKey, ep, viewer, weights) { return weighted(weights, TIER_WEIGHTS, rng(mix(posKey, ep, viewer || "", 0x9E3779B9))()); }
    function rollMetal(posKey, ep, viewer, weights) { return weighted(weights, METAL_WEIGHTS, rng(mix(posKey, ep, viewer || "", 0x6A09E667))()); }
    function selected(posKey, pct, salt) {
        pct = Math.max(0, Math.min(100, pct | 0));
        if (pct <= 0) return false;
        if (pct >= 100) return true;
        return Math.floor(rng(mix(posKey, salt))() * 100) < pct;
    }
    function barrelSelected(posKey, pct) { return selected(posKey, pct, 0xC2B2AE3D); }
    function chestSelected(posKey, pct) { return selected(posKey, pct, 0xD6E8FEB8); }
    function posKey(x, y, z) { return x + "," + y + "," + z; }

    function tierPool(weight) { return { drops: [], zeniMin: 0, zeniMax: 0, weight: weight }; }
    function newCrateLoot() {
        var c = { tiers: [], metals: [], tierMetals: [], refreshHours: 0, barrelChancePercent: 5, chestChancePercent: 100 };
        for (var i = 0; i < 4; i++) { c.tiers.push(tierPool(TIER_WEIGHTS[i])); c.tierMetals.push([tierPool(0), tierPool(0), tierPool(0)]); }
        for (var m = 0; m < 3; m++) c.metals.push(tierPool(METAL_WEIGHTS[m]));
        return c;
    }
    // DungeonCrateDefaults: per theme, per tier (the real tables; DMZR's "testing nether star" switch is off)
    var BASE_DROPS = {
        STONY: [["minecraft:coal", 3, 6, 60], ["minecraft:iron_ingot", 2, 4, 50], ["minecraft:gold_ingot", 1, 3, 30], ["minecraft:diamond", 1, 1, 8]],
        NAMEK: [["minecraft:emerald", 2, 5, 55], ["minecraft:gold_ingot", 2, 4, 40], ["minecraft:lapis_lazuli", 3, 6, 30], ["minecraft:diamond", 1, 2, 18]],
        NETHER: [["minecraft:gold_ingot", 3, 6, 55], ["minecraft:quartz", 4, 8, 50], ["minecraft:diamond", 1, 2, 22], ["minecraft:netherite_scrap", 1, 1, 5]],
        END: [["minecraft:ender_pearl", 1, 3, 45], ["minecraft:emerald", 3, 6, 45], ["minecraft:diamond", 2, 4, 30], ["minecraft:netherite_scrap", 1, 1, 8]],
        KAIO: [["minecraft:emerald", 4, 8, 45], ["minecraft:diamond", 2, 5, 40], ["minecraft:gold_block", 1, 2, 20], ["minecraft:netherite_ingot", 1, 1, 6]],
        OTHERWORLD: [["minecraft:emerald", 5, 10, 45], ["minecraft:diamond", 3, 6, 45], ["minecraft:netherite_scrap", 1, 2, 15], ["minecraft:netherite_ingot", 1, 1, 8], ["minecraft:enchanted_golden_apple", 1, 1, 4]],
        OVERWORLD: [["minecraft:bread", 2, 5, 60], ["minecraft:iron_ingot", 1, 3, 45], ["minecraft:gold_ingot", 1, 2, 25], ["minecraft:emerald", 1, 2, 15]]
    };
    var BASE_ZENI = { STONY: [100, 300], NAMEK: [200, 500], NETHER: [300, 700], END: [500, 1200], KAIO: [800, 1800], OTHERWORLD: [1000, 2500], OVERWORLD: [50, 200] };
    function themeKey(theme) { var t = String(theme || "OVERWORLD").toUpperCase(); return t === "KAI" ? "KAIO" : t; }
    function defaultDrops(theme, tier) {
        var base = BASE_DROPS[themeKey(theme)] || BASE_DROPS.OVERWORLD;
        var out = base.map(function (d) { return { itemId: d[0], minCount: d[1] + tier, maxCount: d[2] + tier, chance: d[3] }; });
        var topper = [null, "minecraft:diamond", "minecraft:netherite_scrap", "minecraft:netherite_ingot"][tier];
        if (topper) out.push({ itemId: topper, minCount: 1, maxCount: 1 + tier, chance: [0, 35, 25, 18][tier] });
        if (tier === 3) out.push({ itemId: "minecraft:enchanted_golden_apple", minCount: 1, maxCount: 1, chance: 6 });
        return out;
    }
    function defaultZeni(theme, tier) { var b = BASE_ZENI[themeKey(theme)] || BASE_ZENI.OVERWORLD; var m = 1 << tier; return [b[0] * m, b[1] * m]; }
    function crateSource(loot, tier, metal, theme) {
        var src = metal >= 0 && loot.tierMetals[tier] ? loot.tierMetals[tier][metal].drops : [];
        if (!src || !src.length) src = loot.tiers[tier].drops;
        if (!src || !src.length) src = defaultDrops(theme, tier);
        return src;
    }
    function crateZeniRange(loot, tier, metal, theme) {
        var p = metal >= 0 && loot.tierMetals[tier] ? loot.tierMetals[tier][metal] : loot.tiers[tier];
        if (!p || p.zeniMax <= 0) p = loot.tiers[tier];
        if (p.zeniMax <= 0) return defaultZeni(theme, tier);
        return [Math.min(p.zeniMin, p.zeniMax), Math.max(p.zeniMin, p.zeniMax)];
    }

    // ---- spawner model (SpawnerConfig) ----
    // DMZR spawns dmz_ragnarok:dmz_fighter; here the entity is any DBR mob/boss id or a vanilla entity id.
    function newSpawner(over) {
        var s = {
            entityTypeId: "red_ribbon_soldier", displayName: "", maxHealth: 20, attackDamage: 3, moveSpeed: 0.25, defense: 0,
            aiTier: 0, kiEnabled: false, kiDmgMin: 0, kiDmgMax: 0, behavior: 6, scale: 1.0,
            maxSpawns: 6, cooldownTicks: 200, wanderDistance: 16, enabled: true, timeCondition: 0, weatherCondition: 0, redstoneMode: 0,
            bossEnabled: false, bossEntityTypeId: "raditz", bossName: "", bossChance: 10, bossHealth: 100, bossDamage: 10,
            bossKiDmgMin: 0, bossKiDmgMax: 0, bossScale: 1.5,
            tpMin: 0, tpMax: 0, balMin: 0, balMax: 0, killCommands: "", vanillaDrops: false, drops: [], disguise: "",
            levelScaling: true, scaleMaxLevel: 100000,
            tpMinAtMax: null, tpMaxAtMax: null, balMinAtMax: null, balMaxAtMax: null, maxHealthAtMax: null, attackDamageAtMax: null, defenseAtMax: null
        };
        for (var k in over || {}) s[k] = over[k];
        return s;
    }
    // DungeonFloorConfig.defaultBossConfig / defaultEnemyConfig
    function defaultBossConfig() {
        return newSpawner({ entityTypeId: "raditz", maxHealth: 300, attackDamage: 15, moveSpeed: 0.28, defense: 8, behavior: 6, aiTier: 2,
            scale: 1.3, tpMin: 5000, tpMax: 12000, balMin: 500, balMax: 1500 });
    }
    function defaultEnemyConfig() {
        return newSpawner({ entityTypeId: "red_ribbon_soldier", maxHealth: 60, attackDamage: 6, moveSpeed: 0.28, defense: 3, behavior: 6, aiTier: 1,
            scale: 1.0, tpMin: 500, tpMax: 1500, balMin: 50, balMax: 200 });
    }
    // LevelScale: autoMax = DEFAULT_MULTIPLE (100) x the level 1 value
    var LEVEL_MULTIPLE = 100;
    function atMax(s, field) { var v = s[field + "AtMax"]; return v === null || v === undefined || v === "" ? s[field] * LEVEL_MULTIPLE : Number(v); }
    function lerp(a, b, level, maxLevel) { var f = maxLevel <= 1 ? 1 : Math.max(0, Math.min(1, (level - 1) / (maxLevel - 1))); return a + (b - a) * f; }

    function newFloor(n, cfgSize, cfgDepth) {
        return {
            theme: defaultTheme(n), size: cfgSize, depth: cfgDepth, layoutStyle: "", crateLoot: newCrateLoot(),
            bossEnabled: true, boss: defaultBossConfig(), type: "NORMAL", enemiesEnabled: false, enemies: defaultEnemyConfig(),
            enemyPresets: [{ weight: 1, config: defaultEnemyConfig() }], requireTicket: false, inRotation: true
        };
    }
    // fills in fields a stored floor lacks (older saves, hand edits), like DungeonFloorConfig.load
    function normalizeFloor(f, n, cfgSize, cfgDepth) {
        var d = newFloor(n, cfgSize, cfgDepth);
        if (!f || typeof f !== "object") return d;
        for (var k in d) if (f[k] === undefined || f[k] === null) f[k] = d[k];
        f.theme = canonicalTheme(f.theme); f.type = canonicalType(f.type); f.layoutStyle = canonicalStyle(f.layoutStyle);
        f.size = Math.max(MIN_SIZE, Math.min(MAX_SIZE, Number(f.size) || cfgSize));
        f.depth = Math.max(MIN_DEPTH, Math.min(MAX_DEPTH, Number(f.depth) || cfgDepth));
        f.boss = newSpawner(f.boss); f.enemies = newSpawner(f.enemies);
        if (!Array.isArray(f.enemyPresets)) f.enemyPresets = [];
        f.enemyPresets = f.enemyPresets.map(function (p) { return { weight: Math.max(1, (p && p.weight) | 0), config: newSpawner(p && p.config) }; });
        if (!f.enemyPresets.length) f.enemyPresets.push({ weight: 1, config: newSpawner(f.enemies) });
        var cl = newCrateLoot(), l = f.crateLoot || {};
        ["refreshHours", "barrelChancePercent", "chestChancePercent"].forEach(function (k) { if (typeof l[k] === "number") cl[k] = l[k]; });
        for (var i = 0; i < 4; i++) {
            if (l.tiers && l.tiers[i]) cl.tiers[i] = fixPool(l.tiers[i], TIER_WEIGHTS[i]);
            for (var m = 0; m < 3; m++) if (l.tierMetals && l.tierMetals[i] && l.tierMetals[i][m]) cl.tierMetals[i][m] = fixPool(l.tierMetals[i][m], 0);
        }
        for (var mm = 0; mm < 3; mm++) if (l.metals && l.metals[mm]) cl.metals[mm] = fixPool(l.metals[mm], METAL_WEIGHTS[mm]);
        f.crateLoot = cl;
        return f;
    }
    function fixPool(p, w) {
        return { drops: Array.isArray(p.drops) ? p.drops.filter(function (d) { return d && d.itemId; }) : [], zeniMin: p.zeniMin | 0, zeniMax: p.zeniMax | 0,
            weight: typeof p.weight === "number" ? p.weight : w };
    }
    // TP gems (TpGemItem): the fourteen DMZR values, each with its own icon
    var TP_GEMS = [1000, 5000, 10000, 50000, 100000, 250000, 500000, 1000000, 2500000, 5000000, 10000000, 25000000, 50000000, 100000000];
    // option lists the editors show (SpawnerConfig enums)
    var OPTS = {
        aiTier: ["simple", "tactical", "advanced"],
        behavior: ["passive", "wander", "dialogue", "follower", "guard", "hostile", "dmz_fighter"],
        time: ["any", "day", "night", "morning", "dusk"],
        weather: ["any", "clear", "rain", "thunder"],
        redstone: ["ignore", "requires_signal", "requires_no_signal"]
    };

    return {
        THEMES: THEMES, RETAINED_THEMES: RETAINED_THEMES, TYPES: TYPES, STYLES: STYLES, STYLE_NAMES: STYLE_NAMES,
        MIN_SIZE: MIN_SIZE, MAX_SIZE: MAX_SIZE, MIN_DEPTH: MIN_DEPTH, MAX_DEPTH: MAX_DEPTH, CELL: CELL, CELL_SPACING: CELL_SPACING,
        SURFACE_Y: SURFACE_Y, DIMS: DIMS, TIERS: TIERS, METALS: METALS, TIER_WEIGHTS: TIER_WEIGHTS, METAL_WEIGHTS: METAL_WEIGHTS,
        TP_GEMS: TP_GEMS, OPTS: OPTS, LEVEL_MULTIPLE: LEVEL_MULTIPLE,
        dimFor: dimFor, isDungeonDim: isDungeonDim, paletteFor: paletteFor, canonicalTheme: canonicalTheme, canonicalType: canonicalType,
        canonicalStyle: canonicalStyle, defaultTheme: defaultTheme, clampedIndex: clampedIndex, cellCentre: cellCentre, floorForX: floorForX,
        mix: mix, rng: rng, floorSeed: floorSeed, rollSizeBlocks: rollSizeBlocks, epoch: epoch, rollTier: rollTier, rollMetal: rollMetal,
        barrelSelected: barrelSelected, chestSelected: chestSelected, posKey: posKey, newCrateLoot: newCrateLoot, defaultDrops: defaultDrops,
        defaultZeni: defaultZeni, crateSource: crateSource, crateZeniRange: crateZeniRange, newSpawner: newSpawner,
        defaultBossConfig: defaultBossConfig, defaultEnemyConfig: defaultEnemyConfig, atMax: atMax, lerp: lerp, newFloor: newFloor,
        normalizeFloor: normalizeFloor
    };
})();
