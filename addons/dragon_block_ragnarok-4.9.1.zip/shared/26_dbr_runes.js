// =====================================================================================
//  26_dbr_runes.js - DMZ Ragnarok's armour runes: the rules both sides share
// =====================================================================================
//  A port of DMZR's runes package (RuneStat, RuneTier, RuneGrade, ArmorRunes,
//  RuneExtraction, RuneUpgradeRecipe, RuneTooltip). The server rolls and sockets
//  (scripts/19_dbr_runes.js), the client draws the tooltips (client/scripts/45_dbr_runes.js),
//  and both read the same numbers from here so the display and the effect can never
//  disagree about what a row means.
//
//  Where the state lives:
//    armour piece  stack.data.dbr_runes = { tier, aff: {STR: arrows, ...}, slots: [{stat, tier, delta}] }
//                  (DMZR's "SUArmorRunes" compound, one key on any armour item from any mod)
//    rune item     stack.data.runeTier = "HIGH"   (DMZR's "SURuneTier")
// =====================================================================================
var DBR_RUNES = (function () {
    // ---- RuneStat: the six stats, in tooltip order, with the artist's colours -----------------
    var STATS = ["STR", "SKP", "RES", "VIT", "PWR", "ENE"];
    var STAT_INFO = {
        STR: { key: "str", colour: "&c", name: "Strength" },
        SKP: { key: "skp", colour: "&e", name: "Skill" },
        RES: { key: "res", colour: "&9", name: "Resistance" },
        VIT: { key: "vit", colour: "&a", name: "Vitality" },
        PWR: { key: "pwr", colour: "&d", name: "Power" },
        ENE: { key: "ene", colour: "&6", name: "Energy" }
    };
    // raw melee against ki output, hit speed against ki to spend, punishment taken against shrugging it off
    var OPPOSITE = { STR: "PWR", PWR: "STR", SKP: "ENE", ENE: "SKP", VIT: "RES", RES: "VIT" };
    var PAIR_LEADERS = ["STR", "SKP", "VIT"];

    // ---- RuneTier: the ceiling on how many arrows one stat may show -------------------------------
    var TIERS = ["LOW", "MEDIUM", "HIGH", "LEGENDARY", "MYTHICAL"];
    var TIER_INFO = {
        LOW: { arrows: 1, colour: "&7", weight: 60 },
        MEDIUM: { arrows: 2, colour: "&f", weight: 25 },
        HIGH: { arrows: 3, colour: "&b", weight: 10 },
        LEGENDARY: { arrows: 4, colour: "&6", weight: 4 },
        MYTHICAL: { arrows: 5, colour: "&d", weight: 1 }
    };

    // ---- RuneGrade: how good a rune is as an item; each weights the same five tiers ----------------
    var GRADES = ["LESSER", "NORMAL", "GREATER", "ADMIN"];
    var GRADE_INFO = {
        LESSER: { suffix: "_lesser", colour: "&c", weights: [45, 45, 10, 0, 0], prefix: "Lesser " },
        NORMAL: { suffix: "", colour: "&a", weights: [5, 30, 45, 20, 0], prefix: "" },
        GREATER: { suffix: "_greater", colour: "&b", weights: [0, 5, 25, 40, 30], prefix: "Greater " },
        ADMIN: { suffix: "_admin", colour: "&6", weights: [0, 0, 0, 0, 100], prefix: "Admin " }
    };

    // ---- ArmorRunes constants ---------------------------------------------------------------------
    var MAX_ARROWS = 5, ARROW_STEP = 0.025, SOCKETS = 2, MAX_IMBALANCE_ARROWS = 5;
    var INITIAL_MAX_ARROWS = Math.floor(MAX_ARROWS / 2), GAIN_SPREAD = 4, DOWNSIDE_COST_RATIO = 0.5;
    // RuneExtraction: one roll decides degrade (or break at the bottom) against intact
    var DAMAGE_CHANCE = 0.90;

    function label(s) { s = String(s).toLowerCase(); return s.charAt(0).toUpperCase() + s.substring(1); }
    function rnd(n) { return Math.floor(Math.random() * n); }
    function tierOf(n) { n = String(n || "").trim().toUpperCase(); return TIER_INFO[n] ? n : "LOW"; }
    function clampArrows(v) { v = Math.round(Number(v) || 0); return Math.max(-MAX_ARROWS, Math.min(MAX_ARROWS, v)); }

    function rollFrom(weights) {
        var total = 0, i;
        for (i = 0; i < weights.length; i++) total += weights[i];
        if (total <= 0) return "LOW";
        var pick = rnd(total);
        for (i = 0; i < weights.length; i++) { pick -= weights[i]; if (pick < 0) return TIERS[i]; }
        return "LOW";
    }
    /** RuneTier.roll: the piece's own tier when it is first seen. */
    function rollTier() { return rollFrom(TIERS.map(function (t) { return TIER_INFO[t].weight; })); }
    /** RuneGrade.rollTier: a tier from the grade's weighted band. */
    function rollGradeTier(grade) { return rollFrom((GRADE_INFO[grade] || GRADE_INFO.NORMAL).weights); }
    function promote(t) { var i = TIERS.indexOf(tierOf(t)); return i >= TIERS.length - 1 ? null : TIERS[i + 1]; }
    function degrade(t) { var i = TIERS.indexOf(tierOf(t)); return i <= 0 ? null : TIERS[i - 1]; }
    function wouldRiskDestruction(t) { return degrade(t) === null; }

    // ---- rune items: name -> {stat, grade}; the server registers them, the client learns the ids ------
    /** Every rune item, dormant first: [name, stat (null), grade, allStats]. */
    function itemList() {
        var out = [["rune_dormant", null, null, false], ["rune_all_admin", null, "ADMIN", true]];
        GRADES.forEach(function (g) { STATS.forEach(function (s) { out.push(["rune_" + STAT_INFO[s].key + GRADE_INFO[g].suffix, s, g, false]); }); });
        return out;
    }
    function itemName(stat, grade, allStats) {
        if (allStats) return "Admin Rune of All Stats";
        if (!stat) return "Dormant Rune";
        return GRADE_INFO[grade].prefix + "Rune of " + STAT_INFO[stat].name;
    }

    // ---- the piece's record (ArmorRunes) ----------------------------------------------------------
    function rec(stack) { return stack && stack.data && typeof stack.data === "object" && stack.data.dbr_runes ? stack.data.dbr_runes : null; }
    function has(stack) { return !!rec(stack); }
    function arrows(stack, stat) { var r = rec(stack); return r && r.aff ? clampArrows(r.aff[stat]) : 0; }
    function setArrows(r, stat, v) { r.aff = r.aff || {}; r.aff[stat] = clampArrows(v); }
    function sockets(stack) {
        var r = rec(stack), out = [];
        if (!r || !r.slots) return out;
        for (var i = 0; i < r.slots.length && out.length < SOCKETS; i++) {
            var e = r.slots[i];
            if (e && STAT_INFO[e.stat]) out.push({ stat: e.stat, tier: tierOf(e.tier), delta: e.delta || {} });
        }
        return out;
    }
    function freeSockets(stack) { return Math.max(0, SOCKETS - sockets(stack).length); }
    function upside(r) { var s = 0; STATS.forEach(function (k) { s += Math.max(0, clampArrows(r.aff[k])); }); return s; }
    function downside(r) { var s = 0; STATS.forEach(function (k) { s += Math.max(0, -clampArrows(r.aff[k])); }); return s; }

    /** ensureRolled: give a piece its tier and starting affinity, one opposing pair at a time. */
    function ensureRolled(stack) {
        if (has(stack)) return false;
        if (!stack.data || typeof stack.data !== "object") stack.data = {};
        // a rolled piece is indestructible, with the vanilla "Unbreakable" line hidden (HideFlags bit 4)
        stack.unbreakable = true;
        stack.hideFlags = (Number(stack.hideFlags) || 0) | 4;
        var tier = rollTier(), r = { tier: tier, aff: {}, slots: [] };
        var cap = Math.max(1, Math.min(TIER_INFO[tier].arrows, INITIAL_MAX_ARROWS));
        var slack = rnd(MAX_IMBALANCE_ARROWS + 1);
        PAIR_LEADERS.forEach(function (leader) {
            var winner = Math.random() < 0.5 ? leader : OPPOSITE[leader], loser = OPPOSITE[winner];
            var gain = 1 + rnd(cap);
            var price = Math.max(1, Math.ceil(gain * DOWNSIDE_COST_RATIO));
            // the discount is part of the bill: what the budget can't cover goes back on the price
            var discount = gain - price, afford = Math.min(slack, discount);
            slack -= afford;
            price += discount - afford;
            var shave = Math.min(slack, price);
            slack -= shave;
            setArrows(r, winner, gain);
            setArrows(r, loser, -(price - shave));
        });
        stack.data.dbr_runes = r;
        return true;
    }

    /** Take up to want arrows off one stat without passing the floor; returns what could NOT be taken. */
    function drain(r, stat, want, delta) {
        if (!stat || want <= 0) return Math.max(0, want);
        var now = clampArrows(r.aff[stat]), take = Math.min(want, Math.max(0, now + MAX_ARROWS));
        if (take > 0) { setArrows(r, stat, now - take); delta[stat] = (delta[stat] || 0) - take; }
        return want - take;
    }

    /** socket: the rune's stat goes up, half the gain (rounded up) comes off its opposite, the rest spills over. */
    function socket(stack, rune, runeTier) {
        if (!stack || !STAT_INFO[rune] || freeSockets(stack) <= 0) return false;
        ensureRolled(stack);
        var r = rec(stack), delta = {};
        var ceiling = Math.max(1, TIER_INFO[tierOf(runeTier)].arrows);
        var gain = Math.max(1, ceiling - rnd(GAIN_SPREAD));
        var before = clampArrows(r.aff[rune]);
        setArrows(r, rune, before + gain);
        delta[rune] = clampArrows(r.aff[rune]) - before;
        var applied0 = Math.max(0, delta[rune] || 0);
        var cost = applied0 <= 0 ? 0 : Math.max(1, Math.ceil(applied0 * DOWNSIDE_COST_RATIO));
        var owed = drain(r, OPPOSITE[rune], cost, delta);
        var others = STATS.filter(function (s) { return s !== rune && s !== OPPOSITE[rune]; });
        while (owed > 0 && others.length) {
            var victim = others[rnd(others.length)];
            if (drain(r, victim, 1, delta) > 0) { others.splice(others.indexOf(victim), 1); continue; }
            owed--;
        }
        // whatever the piece could not pay for, the rune gives back (measured on the whole piece)
        var appliedNow = delta[rune] || 0;
        var excess = (upside(r) - downside(r)) - MAX_IMBALANCE_ARROWS;
        var give = Math.min(Math.max(0, excess), Math.max(0, appliedNow));
        if (give > 0) {
            var b = clampArrows(r.aff[rune]);
            setArrows(r, rune, b - give);
            delta[rune] = (delta[rune] || 0) + (clampArrows(r.aff[rune]) - b);
        }
        var clean = {};
        Object.keys(delta).forEach(function (k) { if (delta[k]) clean[k] = delta[k]; });
        r.slots = sockets(stack).map(function (s) { return { stat: s.stat, tier: s.tier, delta: s.delta }; });
        r.slots.push({ stat: rune, tier: tierOf(runeTier), delta: clean });
        return true;
    }

    /** socketAdmin: fill one stat (or every stat) to the ceiling, free, without a socket. */
    function socketAdmin(stack, stat) {
        if (!stack) return false;
        ensureRolled(stack);
        var r = rec(stack), changed = false;
        STATS.forEach(function (s) {
            if (stat && s !== stat) return;
            if (clampArrows(r.aff[s]) !== MAX_ARROWS) { setArrows(r, s, MAX_ARROWS); changed = true; }
        });
        return changed;
    }

    /** unsocket: undo exactly the affinity the rune applied; returns the removed socket or null. */
    function unsocket(stack, index) {
        var cur = sockets(stack);
        if (index < 0 || index >= cur.length) return null;
        var r = rec(stack), removed = cur.splice(index, 1)[0];
        Object.keys(removed.delta).forEach(function (k) { if (STAT_INFO[k]) setArrows(r, k, clampArrows(r.aff[k]) - (Number(removed.delta[k]) || 0)); });
        r.slots = cur.map(function (s) { return { stat: s.stat, tier: s.tier, delta: s.delta }; });
        return removed;
    }

    // ---- tooltips (RuneTooltip and RuneItem.appendHoverText) ---------------------------------------
    var UP = "↑", DOWN = "↓", PIP_FULL = "◆", PIP_EMPTY = "◇";
    function statLabel(s) { return STAT_INFO[s].colour + s; }
    function removeWarning(so) {
        var pct = Math.round(DAMAGE_CHANCE * 100);
        return "&8Removing the " + statLabel(so.stat) + "&8 rune: &c" + pct + "%&8 chance to " +
            (wouldRiskDestruction(so.tier) ? "DESTROY it" : "degrade it");
    }
    function armorTooltip(stack) {
        if (!has(stack)) return null;
        var out = [], so = sockets(stack), pips = "";
        for (var i = 0; i < SOCKETS; i++) pips += i < so.length ? STAT_INFO[so[i].stat].colour + PIP_FULL + " " : "&8" + PIP_EMPTY + " ";
        out.push("&6Rune Slots: " + pips);
        out.push("&6Armor Affinity");
        STATS.forEach(function (s) {
            var a = arrows(stack, s), filled = Math.min(MAX_ARROWS, Math.abs(a)), neg = a < 0, line = "";
            for (var j = 0; j < MAX_ARROWS; j++) line += (j < filled ? (neg ? "&c" : STAT_INFO[s].colour) : "&8") + (neg ? DOWN : UP) + " ";
            out.push(line + "&f" + s);
        });
        var t = tierOf(rec(stack).tier);
        out.push("&6Equipment Tier: " + TIER_INFO[t].colour + label(t));
        so.forEach(function (x) { out.push(removeWarning(x)); });
        return out;
    }
    /** info: {stat, grade, allStats} for the rune item, tier from its data (LOW until rolled). */
    function runeTooltip(info, stack) {
        if (!info.stat && !info.allStats) return ["&8Dormant. Awaken it to choose a stat."];
        var g = GRADE_INFO[info.grade] || GRADE_INFO.NORMAL, grade = g.colour + label(info.grade);
        if (info.grade === "ADMIN") {
            return [info.allStats ? "&6Fills every stat to the maximum" : "&6Fills " + statLabel(info.stat) + "&6 to the maximum",
                "&7Costs nothing and uses no socket", "&7Grade: " + grade];
        }
        var t = tierOf(stack && stack.data && stack.data.runeTier);
        return ["&7Favours " + statLabel(info.stat), "&7Weakens &c" + OPPOSITE[info.stat], "&7Grade: " + grade,
            "&7Rune Tier: " + TIER_INFO[t].colour + label(t), "&8Socket at a rune bench"];
    }

    return {
        STATS: STATS, STAT_INFO: STAT_INFO, OPPOSITE: OPPOSITE, TIERS: TIERS, TIER_INFO: TIER_INFO, GRADES: GRADES, GRADE_INFO: GRADE_INFO,
        MAX_ARROWS: MAX_ARROWS, ARROW_STEP: ARROW_STEP, SOCKETS: SOCKETS, DAMAGE_CHANCE: DAMAGE_CHANCE,
        label: label, tierOf: tierOf, rollTier: rollTier, rollGradeTier: rollGradeTier, promote: promote, degrade: degrade,
        wouldRiskDestruction: wouldRiskDestruction, itemList: itemList, itemName: itemName,
        rec: rec, has: has, arrows: arrows, sockets: sockets, freeSockets: freeSockets,
        ensureRolled: ensureRolled, socket: socket, socketAdmin: socketAdmin, unsocket: unsocket,
        armorTooltip: armorTooltip, runeTooltip: runeTooltip, removeWarning: removeWarning, statLabel: statLabel
    };
})();
