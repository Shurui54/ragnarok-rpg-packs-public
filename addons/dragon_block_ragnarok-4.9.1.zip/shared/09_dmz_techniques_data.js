// =====================================================================================
//  DMZ techniques data (PredefinedTechniques, KiAttackData types, StrikeAttackData,
//  EvasionAttackData, ReviveTechniqueData, Techniques), shared by the server
//  (scripts/41_dmz_techniques.js) and the client (HUD, skills screen).
//  Numbers are DragonMine Z's defaults. Credits: DragonMine Z (GPL-3.0).
// =====================================================================================
var DMZ_TECH_DATA = (function () {
    var SLOT_COUNT = 8, BAR_SLOTS = 4, MAX_UNLOCKED = 256, OVERCHARGE_MAX = 175;
    var REVIVE_ID = "worldboss_revive";
    var OOZARU_LOADOUT = ["mouth_blast", "oozaru_slam", "rage_scream"];
    var STRIKE_GLOBAL_COOLDOWN = 60;            // CombatConfig.strikeGlobalCooldownTicks
    var SHARED_EVASION_COOLDOWN = 60;           // EvasionAttackHandler.SHARED_EVASION_COOLDOWN_TICKS
    var LEVEL_STEP = 0.025, LEVEL_LIMIT = 0.5;  // upgrade step / cap (strikes, evasions)
    var MIN_XP_COST = 100;                      // TechniqueTypeConfig / StrikeAttackConfig / EvasionAttackConfig minXPCost

    // KiType: cast = ticks to 100 % (0 = instant), mult = cost/TP multiplier, cap = [base, transformed] size cap,
    // life = base max life (x charge), full = requiresFullCharge (auto-fires at the ceiling),
    // restrict = movement locked while charging/firing, home = can home on the lock-on target.
    var TYPES = {
        SMALL_BALL: { cast: 0, mult: 1.0, cap: [0, 0], life: 90, full: true, restrict: false, home: true },
        MEDIUM_BALL: { cast: 30, mult: 1.4, cap: [4.5, 7.0], life: 90, full: true, restrict: false, home: true },
        GIANT_BALL: { cast: 60, mult: 2.2, cap: [15, 25], life: 300, full: true, restrict: true, home: false },
        WAVE: { cast: 50, mult: 1.6, cap: [2.0, 5.0], life: 80, full: false, restrict: true, home: true },
        LASER: { cast: 0, mult: 0.8, cap: [0, 0], life: 80, full: true, restrict: false, home: false },
        BEAM: { cast: 50, mult: 1.4, cap: [1.2, 2.3], life: 80, full: false, restrict: true, home: false },
        DISK: { cast: 30, mult: 1.2, cap: [1.2, 2.3], life: 70, full: false, restrict: false, home: true },
        EXPLOSION: { cast: 60, mult: 2.6, cap: [12, 25], life: 300, full: false, restrict: true, home: false },
        SHIELD: { cast: 40, mult: 1.6, cap: [0, 0], life: 90, full: false, restrict: false, home: false },
        BARRAGE: { cast: 40, mult: 1.4, cap: [1.5, 2.5], life: 50, full: false, restrict: true, home: false },
        AREA: { cast: 40, mult: 1.8, cap: [0, 0], life: 90, full: false, restrict: false, home: false }
    };

    // PredefinedTechniques.registerKi: id, name key, author, type, damage x, colours (core, border, outline),
    // size, speed, cooldown seconds, animation prefix; plus charge/fire sounds (TechniqueDispatcher / entities)
    var KI = {}, KI_IDS = [];
    function ki(id, nameKey, author, type, dmg, cin, cb, cout, size, speed, cd, anim, chargeSnd, fireSnd) {
        KI[id] = { id: id, kind: "ki", name: "technique.dragonminez." + nameKey, author: author, type: type, dmg: dmg,
            colors: { core: hx(cin), border: hx(cb), outline: hx(cout) }, size: size, speed: speed, cd: cd, anim: anim,
            chargeSound: chargeSnd || "ki_explosion_charge", fireSound: fireSnd || "kiblast_shoot" };
        KI_IDS.push(id);
    }
    function hx(n) { return "#" + ("000000" + n.toString(16).toUpperCase()).slice(-6); }
    ki("spiritbomb", "spiritbomb", "Goku", "GIANT_BALL", 3.00, 0xC4FFFD, 0x00F8FF, 0xFFFFFF, 10.0, 0.5, 10, "ki.large_ball", "ki_spiritbomb_charge", "ki_spiritbomb_fire");
    ki("supernova", "supernova", "Frieza", "GIANT_BALL", 3.00, 0xFF7438, 0xC92620, 0x800E0E, 10.0, 0.5, 10, "ki.large_ball", "ki_supernova_charge", "ki_supernova_fire");
    ki("supernova_cooler", "supernova_cooler", "Cooler", "GIANT_BALL", 3.50, 0xFF3866, 0xA3143A, 0x4A0316, 10.5, 0.5, 10, "ki.supernova_cooler", "ki_supernova_charge", "ki_supernova_fire");
    ki("big_bang", "big_bang", "Vegeta", "MEDIUM_BALL", 2.00, 0xE3FFFF, 0xE3FFFF, 0x889999, 2.5, 1.7, 10, "ki.bigbang");
    ki("burning_attack", "burning_attack", "Trunks", "MEDIUM_BALL", 1.50, 0xFFF3D0, 0xFF7A1A, 0xC43A00, 2.5, 1.5, 10, "ki.burning_attack", "ki_burning_charge", "ki_burning_fire");
    ki("sokidan", "sokidan", "Yamcha", "MEDIUM_BALL", 1.25, 0xFCFC5D, 0xF7F723, 0xF7B736, 1.5, 1.0, 12, "ki.bigbang");
    ki("final_flash", "final_flash", "Vegeta", "WAVE", 2.50, 0xFFFCD6, 0xFFEB52, 0xF5C020, 0.7, 1.2, 10, "ki.finalflash", "ki_finalflash_charge", "ki_finalflash_fire");
    ki("kamehameha", "kamehameha", "Goku", "WAVE", 2.00, 0xEDF4FF, 0x29D8FF, 0x0077FF, 0.6, 1.2, 10, "ki.kameha", "ki_kame_charge", "ki_kame_fire");
    ki("galick_gun", "galick_gun", "Vegeta", "WAVE", 2.00, 0xFAE5FF, 0xA63EF0, 0x7106BD, 0.6, 1.2, 10, "ki.galick", "ki_explosion_charge", "ki_kame_fire");
    ki("heat_dome", "heat_dome", "Trunks", "WAVE", 2.25, 0xFFF6C2, 0xFFD23F, 0xF29E0C, 1.0, 1.8, 12, "ki.cupula", "ki_explosion_charge", "ki_kame_fire");
    ki("kikoho", "kikoho", "Tien", "LASER", 2.00, 0xFFFBD6, 0xFFE45C, 0xF2A900, 0.9, 1.8, 12, "ki.kikohu", "ki_explosion_charge", "ki_beam_fire");
    ki("neo_kikoho", "neo_kikoho", "Tien", "MEDIUM_BALL", 2.50, 0xFFF4B0, 0xFFB22E, 0xFF6F00, 0.9, 1.6, 15, "ki.neo_kikohu", "ki_explosion_charge", "ki_beam_fire");
    ki("masenko", "masenko", "Gohan", "WAVE", 1.50, 0xFFFC85, 0xFCE062, 0xFFFFFF, 0.4, 1.2, 10, "ki.masenko", "ki_explosion_charge", "ki_kame_fire");
    ki("kienzan", "kienzan", "Krilin", "DISK", 1.50, 0xFFFB7D, 0xFFEA00, 0xFFFFFF, 1.0, 1.5, 10, "ki.kienzan", "ki_disk_charge", "ki_disk_fire");
    ki("kienzan_doble", "double_kienzan", "Krilin", "DISK", 1.75, 0xFF00AA, 0xFF00AA, 0xA30070, 1.0, 1.5, 10, "ki.kienzandoble", "ki_disk_charge", "ki_disk_fire");
    ki("death_beam", "death_beam", "Frieza", "LASER", 0.75, 0xFF59FF, 0xD859FF, 0x9238F2, 0.5, 2.0, 10, "ki.laser", "laserbeam", "laserbeam");
    ki("emperor_death_beam", "emperor_death_beam", "Frieza", "LASER", 1.25, 0xFF6B6B, 0xFF1A1A, 0xB00000, 0.6, 2.0, 14, "ki.emperor_laser", "laserbeam", "laserbeam");
    ki("dodonpa", "dodonpa", "Tien", "LASER", 1.00, 0xFFF7B0, 0xFFE657, 0xF5B800, 0.5, 2.5, 8, "ki.dodonpa", "laserbeam", "laserbeam");
    ki("makkanko", "makkankosanpo", "Piccolo", "BEAM", 0.75, 0xFFE657, 0xF5A627, 0x8B17CF, 1.0, 2.0, 14, "ki.makkako", "ki_beam_charge", "ki_beam_fire");
    ki("ki_barrage", "barrage", "Vegeta", "BARRAGE", 0.50, 0xFFFF00, 0xFFFF00, 0xC8A000, 0.4, 1.5, 10, "ki.barrage", "ki_explosion_charge", "kiblast_shoot");
    ki("final_explosion", "final_explosion", "Vegeta", "EXPLOSION", 2.25, 0xFFFA99, 0xFCF56A, 0xFFFFFC, 25.0, 0.0, 10, "ki.explosion", "ki_explosion_charge", "ki_explosion_impact");
    ki("soul_punisher", "soul_punisher", "Gogeta", "MEDIUM_BALL", 3.50, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 3.5, 0.5, 45, "ki.soul_punisher", "ki_spiritbomb_charge", "ki_spiritbomb_fire");
    ki("mouth_blast", "mouth_blast", "Oozaru", "WAVE", 1.75, 0xF3C9FF, 0xC523DE, 0x7A0FA0, 0.8, 1.2, 12, "ki.mouth_blast", "oozaru_growl_player", "ki_kame_fire");
    ki("fake_moon", "fake_moon", "Vegeta", "MEDIUM_BALL", 0.00, 0xF5F3D0, 0xFFFFFF, 0xFFFFFF, 2.0, 0.8, 45, "ki.bigbang");
    ki("assault_rain", "assault_rain", "Super Buu", "BARRAGE", 0.70, 0xFFB8F4, 0x8A2BE2, 0xFF38D4, 0.4, 1.5, 15, "ki.assault_rain", "ki_explosion_charge", "kiblast_shoot");
    ki("blaster_meteor", "blaster_meteor", "Broly", "BARRAGE", 0.70, 0x9DFF8A, 0x3DF54A, 0x0FBF1B, 0.4, 1.5, 15, "ki.blaster_meteor", "ki_explosion_charge", "ki_explosion_impact");
    ki("kill_driver", "kill_driver", "Turles", "DISK", 2.25, 0xFFF3A0, 0xFFC400, 0xE08A00, 1.0, 1.2, 12, "ki.kill_driver", "ki_disk_charge", "ki_beam_fire");
    ki("hellzone_grenade", "hellzone_grenade", "Piccolo", "BARRAGE", 2.50, 0xFFF6B8, 0xFFB52E, 0xFF5A14, 0.8, 1.5, 15, "ki.hellzone_grenade", "ki_sparks", "kiblast_shoot");

    // DMZ's ki.animation.json has no *_cast for these (the fire animation is the whole move)
    var NO_CAST_ANIM = { "ki.kikohu": 1, "ki.laser": 1, "ki.emperor_laser": 1, "ki.dodonpa": 1 };

    // PredefinedTechniques.registerStrike (id, damage x, duration) + TechniqueConfig.defaultStrikeCooldownTicks
    var STRIKE = {}, STRIKE_IDS = [];
    function strike(id, dmg, dur, cd, extra) {
        STRIKE[id] = { id: id, kind: "strike", name: "technique.dragonminez." + id, dmg: dmg, dur: dur, cdTicks: cd, anim: "skp." + id };
        if (extra) for (var k in extra) STRIKE[id][k] = extra[k];
        STRIKE_IDS.push(id);
    }
    strike("meteor", 1.25, 40, 160);
    strike("dragon_fist", 2.5, 50, 320, { targetless: true, sound: "dragon_fist" });
    strike("deadly_dance_vegetto", 1.5, 30, 200, { targetless: true });
    strike("deadly_dance", 1.25, 30, 160, { targetless: true });
    strike("kaioken_attack", 1.75, 45, 180);
    strike("wolf_fang", 1.25, 35, 140, { targetless: true });
    strike("oozaru_fist", 2.25, 35, 280, { sound: "oozaru_fist" });
    strike("super_god_fist", 2.0, 25, 300, { targetless: true });
    strike("oozaru_slam", 1.5, 15, 180, { targetless: true, sound: "oozaru_fist" });
    strike("gum_punch", 1.5, 20, 260, { range: 16 });
    strike("blue_hurricane", 1.75, 95, 260, { targetless: true });
    strike("dimensional_punch", 2.4, 70, 340, { stationary: true });
    strike("dimensional_sword_attack", 2.6, 41, 380, { heldItemOk: true, sound: "katana_slash" });
    strike("spirit_breaking_cannon", 2.2, 47, 330);
    strike("grab", 1.6, 50, 210);
    strike("shining_sword_attack", 2.4, 66, 320, { needsItem: "brave_sword", sound: "sword_out" });
    strike("combo_meteor", 2.2, 90, 290);
    strike("meteor_burst", 2.6, 201, 600, { kiRatio: 1.5 });
    strike("mystic_ball", 2.4, 96, 320);
    strike("darkness_eye_beam", 2.6, 102, 410, { kiRatio: 0.5 });
    strike("death_chaser", 2.4, 72, 320);
    strike("android_combo", 2.4, 82, 380, { kiRatio: 0.5 });
    strike("beam_sword_slash", 2.6, 112, 350);
    strike("perfect_rush", 2.5, 92, 330);
    strike("spirit_breaker", 2.8, 148, 370);

    // PredefinedTechniques.registerEvasion (id, damage x, duration, cooldown ticks, uses strike power)
    var EVASION = {}, EVASION_IDS = [];
    function evasion(id, dmg, dur, cd, skp) {
        EVASION[id] = { id: id, kind: "evasion", name: "technique.dragonminez." + id, dmg: dmg, dur: dur, cdTicks: cd, skp: !!skp, anim: "evs." + id };
        EVASION_IDS.push(id);
    }
    evasion("taiyoken", 0, 30, 900, false);
    evasion("rage_scream", 1.2, 60, 80, true);
    evasion("afterimage", 0, 60, 200, false);
    evasion("sleep_recovery", 0, 140, 1200, false);
    evasion("dimensional_teleport", 0, 30, 320, false);
    evasion("candy_beam", 0, 28, 600, false);
    evasion("gum_bind", 0, 26, 900, false);

    // English names for server text (the client translates the name keys from the DMZ language file)
    var EN = { spiritbomb: "Spirit Bomb", supernova: "Supernova", supernova_cooler: "Supernova (Cooler)", big_bang: "Big Bang Attack",
        burning_attack: "Burning Attack", sokidan: "Spirit Ball", final_flash: "Final Flash", kamehameha: "Kamehame Ha", galick_gun: "Galick Gun",
        heat_dome: "Heat Dome Attack", kikoho: "Tri-Beam", neo_kikoho: "Neo Tri-Beam", masenko: "Masenko", kienzan: "Kienzan",
        kienzan_doble: "Double Kienzan", death_beam: "Death Beam", emperor_death_beam: "Emperor's Death Beam", dodonpa: "Dodon Ray",
        makkanko: "Special Beam Cannon", ki_barrage: "Barrage", final_explosion: "Final Explosion", soul_punisher: "Soul Punisher",
        mouth_blast: "Mouth Blast", fake_moon: "Fake Moon", assault_rain: "Assault Rain", blaster_meteor: "Blaster Meteor",
        kill_driver: "Kill Driver", hellzone_grenade: "Hellzone Grenade", taiyoken: "Solar Flare", rage_scream: "Rage Scream",
        afterimage: "Afterimage", sleep_recovery: "Sleep Recovery", dimensional_teleport: "Dimensional Warp", candy_beam: "Candy Beam",
        gum_bind: "Gum Bind", meteor: "Meteor", dragon_fist: "Dragon Fist", deadly_dance_vegetto: "Deadly Dance (Vegetto)",
        deadly_dance: "Deadly Dance", kaioken_attack: "Kaioken Attack", wolf_fang: "Wolf Fang", oozaru_fist: "Oozaru Fist",
        super_god_fist: "Super God Fist", oozaru_slam: "Oozaru Slam", gum_punch: "Gum Punch", blue_hurricane: "Blue Hurricane",
        dimensional_punch: "Dimensional Fist", dimensional_sword_attack: "Dimensional Slash", spirit_breaking_cannon: "Spirit Breaking Cannon",
        grab: "Grab Throw", shining_sword_attack: "Shining Sword Attack", combo_meteor: "Meteor Combo", meteor_burst: "Meteor Burst",
        mystic_ball: "Mystic Ball Attack", darkness_eye_beam: "Darkness Eye Beam", death_chaser: "Death Chaser", android_combo: "Android Combo",
        beam_sword_slash: "Beam Sword Slash", perfect_rush: "Perfect Rush", spirit_breaker: "Spirit Breaker", worldboss_revive: "Revive" };

    function get(id) { return KI[id] || STRIKE[id] || EVASION[id] || (id === REVIVE_ID ? { id: REVIVE_ID, kind: "revive", name: "technique.dragonminez.worldboss_revive" } : null); }
    function kind(id) { var t = get(id); return t ? t.kind : null; }
    function exists(id) { return !!get(id); }
    function nameKey(id) { var t = get(id); return t ? t.name : null; }
    function english(id) { return EN[id] || String(id); }
    function all() { return KI_IDS.concat(STRIKE_IDS, EVASION_IDS); }
    function isInstant(id) { var t = KI[id]; return !!t && TYPES[t.type].cast === 0; }
    function castAnim(id) { var t = KI[id]; return t && !NO_CAST_ANIM[t.anim] ? t.anim + "_cast" : null; }

    // ---- formulas (KiAttackData / StrikeAttackData / EvasionAttackData) ----
    function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }
    /** KiAttackData.getCostMultiplier: 100 % -> 1, 175 % -> 2. */
    function costMultiplier(p) { return p <= 100 ? p / 100 : 1 + (p - 100) / (OVERCHARGE_MAX - 100); }
    function overload(type, dmg) { return (type === "GIANT_BALL" || type === "EXPLOSION") && dmg > 2 ? Math.min(3, 1 + (dmg - 2) * 2) : 1; }
    /** Base ki cost of a ki technique (getCalculatedCost); kiNoForms = DMZ kiDamage without form multipliers. */
    function kiCost(id, kiNoForms) {
        var t = KI[id]; if (!t) return 0;
        var y = TYPES[t.type];
        return Math.max(5, ((kiNoForms * t.dmg * 0.5 + t.size * 5 + t.speed * 5) * y.mult * overload(t.type, t.dmg)) / 2);
    }
    /** resolveCastSize: grows from the base size toward the type cap as raw PWR climbs to 1,000,000. */
    function castSize(id, pwr, transformed) {
        var t = KI[id]; if (!t) return 1;
        var y = TYPES[t.type], cap = transformed ? y.cap[1] : y.cap[0];
        if (cap <= 0) return t.size;
        var base = Math.min(t.size, cap), f = clamp(Math.log(Math.max(1, pwr) / 100) / Math.log(1e6 / 100), 0, 1);
        return base + (cap - base) * f;
    }
    /** Cooldown ticks after a release at `charge` (1 = 100 %); level = cooldown upgrades. */
    function kiCooldown(id, charge, level) {
        var t = KI[id]; if (!t) return 20;
        return Math.max(1, Math.ceil(t.cd * 20 * Math.max(0.5, 1 - 0.025 * (level || 0)) * (charge === undefined ? 1 : charge)));
    }
    function strikeDamageMult(id, dl) { var t = STRIKE[id]; return t ? (t.dmg + Math.max(0, dl || 0) * 0.075) : 0; }
    function strikeActualMult(id, dl) { return strikeDamageMult(id, dl) * (1 + Math.min(LEVEL_LIMIT, Math.max(0, dl || 0) * LEVEL_STEP)); }
    function reduction(level) { return Math.max(1 - LEVEL_LIMIT, 1 - Math.max(0, level || 0) * LEVEL_STEP); }
    function strikeCooldown(id, cl) { var t = STRIKE[id]; return t ? Math.max(1, Math.round(t.cdTicks * reduction(cl))) : 20; }
    /** StrikeAttackData.getCalculatedCost: strikeNoForms = DMZ strike damage without form multipliers. */
    function strikeCost(id, strikeNoForms, dl) { return Math.max(5, (strikeNoForms * strikeDamageMult(id, dl) * 0.35) / 2); }
    function evasionDuration(id, rl) {
        var t = EVASION[id]; if (!t) return 20;
        if (id === "sleep_recovery") return 140;
        return Math.max(1, Math.round(t.dur * (1 + Math.min(LEVEL_LIMIT, Math.max(0, rl || 0) * LEVEL_STEP))));
    }
    function evasionCooldown(id, cl) { var t = EVASION[id]; return t ? Math.max(1, Math.round(t.cdTicks * reduction(cl))) : 20; }
    /** 0.10 x (SKP or PWR stat) x damage x. */
    function evasionHit(id, skpStat, pwrStat) { var t = EVASION[id]; return t ? 0.10 * (t.skp ? skpStat : pwrStat) * t.dmg : 0; }
    function evasionCost(id, skpStat, pwrStat, rl) { return Math.max(5, evasionDuration(id, rl) * 0.5 + evasionHit(id, skpStat, pwrStat) * 2); }
    function canUpgrade(id, stat) {
        var k = kind(id);
        if (k === "strike") return stat === "damage" || stat === "cooldown";
        if (k === "evasion") return (stat === "duration" && id !== "sleep_recovery") || stat === "cooldown";
        return false;                                       // predefined ki attacks can't be upgraded
    }
    /** Predefined ki attacks gain no experience (Techniques.addExperienceToTechnique). */
    function gainsXp(id) { var k = kind(id); return k === "strike" || k === "evasion"; }

    return { SLOT_COUNT: SLOT_COUNT, BAR_SLOTS: BAR_SLOTS, MAX_UNLOCKED: MAX_UNLOCKED, OVERCHARGE_MAX: OVERCHARGE_MAX, REVIVE_ID: REVIVE_ID,
        OOZARU_LOADOUT: OOZARU_LOADOUT, STRIKE_GLOBAL_COOLDOWN: STRIKE_GLOBAL_COOLDOWN, SHARED_EVASION_COOLDOWN: SHARED_EVASION_COOLDOWN,
        MIN_XP_COST: MIN_XP_COST, TYPES: TYPES, KI: KI, STRIKE: STRIKE, EVASION: EVASION, KI_IDS: KI_IDS, STRIKE_IDS: STRIKE_IDS, EVASION_IDS: EVASION_IDS,
        get: get, kind: kind, exists: exists, nameKey: nameKey, english: english, all: all, isInstant: isInstant, castAnim: castAnim,
        costMultiplier: costMultiplier, kiCost: kiCost, castSize: castSize, kiCooldown: kiCooldown, strikeDamageMult: strikeDamageMult,
        strikeActualMult: strikeActualMult, strikeCooldown: strikeCooldown, strikeCost: strikeCost, evasionDuration: evasionDuration,
        evasionCooldown: evasionCooldown, evasionHit: evasionHit, evasionCost: evasionCost, canUpgrade: canUpgrade, gainsXp: gainsXp, clamp: clamp };
})();
