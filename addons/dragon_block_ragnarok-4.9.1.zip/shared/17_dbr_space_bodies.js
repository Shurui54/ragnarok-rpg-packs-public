// =====================================================================================
//  17_dbr_space_bodies.js - every body in space, planet surfaces and their weather
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0): MoonBody (every main planet has a moon, a quarter of its
//  size, 2.6 radii out, one degree a second), SurfaceDimension (each generated planet and
//  moon is a square cell of the one planet_surface dimension, 65536 blocks apart on a
//  900 x 900 grid), SurfaceStamp's themes (stony, overworld, Namek, nether, end, Kai) with
//  their relief profiles, sea levels and ground layers, and PlanetWeather (each planet's
//  weather walks through hour-long blocks of 3..10 minute episodes picked from its theme).
// =====================================================================================
var DBR_SPACE_BODIES = (function () {
    var O = DBR_SPACE_ORBITS, G = DBR_SPACE_GEN, U = O.u64;
    var SURFACE = "ragnarok_rpg:planet_surface";
    var S = { scale: 0.25, planeY: 0 };
    function configure(scale, planeY) { S.scale = scale; S.planeY = planeY; G.configure(scale, planeY); }

    // ---- the main system ----
    function fixedPos(b, epoch) { return O.position(b.id, epoch, S.scale, S.planeY); }
    function sunPos() { return { x: 0, y: S.planeY, z: 0 }; }
    /** MoonBody.position, driven by the wall clock (1 degree a second, DMZR's 0.05 degrees a tick). */
    function moonPos(parent, epoch) {
        var p = fixedPos(parent, epoch), a = ((epoch / 1000) % 360) * Math.PI / 180, r = parent.radius * 2.6;
        return { x: p.x + Math.cos(a) * r, y: p.y, z: p.z - Math.sin(a) * r };
    }
    var MOONS = O.BODIES.map(function (b) { return { id: "moon_" + b.id, key: "sumoon:" + b.key, parent: b, radius: b.radius * 0.25, surface: 400 }; });
    var MOON_BY_ID = {};
    MOONS.forEach(function (m) { MOON_BY_ID[m.id] = m; MOON_BY_ID[m.key] = m; });

    // ---- the seven Super Dragon Ball bodies (SuperPlanetPositions): each on its own orbit round the sun, in a band
    // between two main rings (two bands in each of the four inner gaps); orbit elements chosen once by the server ----
    var SUPER = [];                                    // [{star, ring (DMZR radius), phase0, y (DMZR height)}]
    var SUPER_RADIUS = 4 * 88;                         // 4x Namek
    function setSuper(list) { SUPER = (list || []).map(function (e) { return { star: Number(e.star), ring: Number(e.ring), phase0: Number(e.phase0), y: Number(e.y) }; }); }
    // the bands in WORLD distances: the rings are scaled (distanceScale), the keep-outs (body sizes) are not, so a Super
    // body never overlaps a planet, its moon or another Super body however small the system is drawn
    function superBand(band) {
        var keep = 92 * (1 + 2.6 + 0.25) + SUPER_RADIUS + 256, gapW = 2 * SUPER_RADIUS + 256, gap = Math.floor(band / 2), half = band % 2;
        var inner = (6000 + gap * 15000) * S.scale + keep, outer = (6000 + (gap + 1) * 15000) * S.scale - keep, w = Math.max(0, (outer - inner - gapW) / 2);
        var lo = inner + half * (w + gapW);
        return [lo, lo + w];
    }
    function superPos(e, epoch) {
        var a = O.angle(e.phase0, O.periodMillis(e.ring / S.scale), epoch);
        return { x: Math.cos(a) * e.ring, y: S.planeY + e.y, z: Math.sin(a) * e.ring };
    }
    // ---- destroyed bodies (PlanetDestruction): gone from space for everyone ----
    var DESTROYED = {};
    function setDestroyed(list) { DESTROYED = {}; (list || []).forEach(function (id) { DESTROYED[id] = true; }); }
    function isDestroyed(id) { return !!DESTROYED[id]; }

    /**
     * Everything landable or dangerous near a point: {kind: "fixed"|"moon"|"planet"|"star"|"sun"|"hole", id, pos, radius, ...}.
     * range = how far to look for generated things (the main system is always included).
     */
    function near(p, range, epoch) {
        var out = [];
        O.BODIES.forEach(function (b) { out.push({ kind: "fixed", id: b.id, body: b, pos: fixedPos(b, epoch), radius: b.radius }); });
        MOONS.forEach(function (m) { out.push({ kind: "moon", id: m.key, moon: m, pos: moonPos(m.parent, epoch), radius: m.radius, surface: m.surface }); });
        out.push({ kind: "sun", id: "sun", pos: sunPos(), radius: O.SUN.radius, tint: O.SUN.tint });
        G.systemsNear(p.x, p.z, range).forEach(function (s) {
            out.push({ kind: "star", id: s.key, pos: { x: s.x, y: s.y, z: s.z }, radius: s.radius, tint: s.tint, system: s });
            s.planets.forEach(function (pl) { out.push({ kind: "planet", id: pl.id, planet: pl, pos: G.planetPos(pl, epoch), radius: pl.radius, tint: pl.tint, surface: pl.surface }); });
        });
        G.loneStarsNear(p.x, p.y, p.z, Math.min(range, 4096)).forEach(function (s) { out.push({ kind: "star", id: s.key, pos: { x: s.x, y: s.y, z: s.z }, radius: s.radius, tint: s.tint, lone: true }); });
        G.blackHolesNear(p.x, p.y, p.z, Math.min(range, 6000)).forEach(function (h) { out.push({ kind: "hole", id: h.key, pos: { x: h.x, y: h.y, z: h.z }, radius: h.radius, hole: h }); });
        SUPER.forEach(function (e) { out.push({ kind: "super", id: "susuper:" + e.star, star: e.star, sup: e, pos: superPos(e, epoch), radius: SUPER_RADIUS }); });
        // a generated planet that would sit inside a main planet, its moon or a Super body is not there (DMZR rejects
        // generated bodies overlapping the fixed ones)
        var solid = out.filter(function (b) { return b.kind === "fixed" || b.kind === "super"; });
        return out.filter(function (b) {
            if (DESTROYED[b.id] || b.kind === "planet" && DESTROYED[b.planet.system.key]) return false;
            if (b.kind !== "planet" && b.kind !== "star") return true;
            for (var i = 0; i < solid.length; i++) {
                var f = solid[i], reach = (f.kind === "fixed" ? f.radius * (1 + 2.6 + 0.25) : f.radius) + b.radius * (b.kind === "star" ? 3 : 1) + 128;
                var dx = b.pos.x - f.pos.x, dy = b.pos.y - f.pos.y, dz = b.pos.z - f.pos.z;
                if (dx * dx + dy * dy + dz * dz < reach * reach) return false;
            }
            return true;
        });
    }
    /** A landable body by id at an instant (fixed id, moon key, or sugen: planet). */
    function find(id, epoch) {
        var b = O.byId(id);
        if (b) return { kind: "fixed", id: id, body: b, pos: fixedPos(b, epoch), radius: b.radius };
        var m = MOON_BY_ID[id];
        if (m) return { kind: "moon", id: m.key, moon: m, pos: moonPos(m.parent, epoch), radius: m.radius, surface: m.surface };
        if (String(id).indexOf("susuper:") === 0) {
            var st = Number(String(id).substring(8));
            for (var i = 0; i < SUPER.length; i++) if (SUPER[i].star === st) return { kind: "super", id: id, star: st, sup: SUPER[i], pos: superPos(SUPER[i], epoch), radius: SUPER_RADIUS };
            return null;
        }
        var pl = G.findPlanet(id);
        if (pl) return { kind: "planet", id: pl.id, planet: pl, pos: G.planetPos(pl, epoch), radius: pl.radius, tint: pl.tint, surface: pl.surface };
        return null;
    }

    // ---- surfaces (SurfaceDimension) ----
    var CELL_SPACING = 65536, GRID_HALF = 450;
    // Math.floorMod(signed 64-bit h, n) for small n
    function floorMod64(h, n) {
        var two32 = 4294967296 % n;
        var r = ((h.hi % n) * two32 + (h.lo % n)) % n;
        if (h.hi >= 0x80000000) {
            var two64 = (two32 * two32) % n;                       // 2^64 mod n
            r = ((r - two64) % n + n) % n;
        }
        return r;
    }
    function cellCentre(id) {
        var cx = floorMod64(O.hash(id), GRID_HALF * 2) - GRID_HALF, cz = floorMod64(O.hash(id + "#z"), GRID_HALF * 2) - GRID_HALF;
        return { x: cx * CELL_SPACING + 0.5, y: 96, z: cz * CELL_SPACING + 0.5 };
    }
    function surfaceSize(id) { var m = MOON_BY_ID[id]; return m ? m.surface : G.surfaceSizeForId(id); }

    // ---- themes (SurfaceStamp.Theme, profileFor, liquidFor, seaFractionFor, paletteFor) ----
    var THEMES = [
        { id: "stony", weight: 12, amp: 52, oct: 5, pers: 0.55, ridge: 0.70, warp: 12, sea: 0, layers: ["stone", "andesite"], deep: "deepslate" },
        { id: "overworld", weight: 34, amp: 40, oct: 4, pers: 0.50, ridge: 0.35, warp: 16, sea: 0.34, fluid: "water", layers: ["grass_block", "dirt"], deep: "stone", shore: "sand" },
        { id: "namek", weight: 21, amp: 44, oct: 4, pers: 0.50, ridge: 0.40, warp: 16, sea: 0.33, fluid: "water", layers: ["@namek_grass_block", "@namek_dirt"], deep: "@namek_stone", shore: "sand" },
        { id: "nether", weight: 12, amp: 46, oct: 5, pers: 0.55, ridge: 0.60, warp: 12, sea: 0.16, fluid: "lava", layers: ["netherrack", "soul_soil"], deep: "basalt" },
        { id: "end", weight: 8, amp: 34, oct: 4, pers: 0.50, ridge: 0.50, warp: 10, sea: 0.20, fluid: "packed_ice", layers: ["end_stone", "end_stone"], deep: "purpur_block" },
        { id: "kaio", weight: 13, amp: 22, oct: 3, pers: 0.45, ridge: 0.20, warp: 12, sea: 0, layers: ["@sacred_planet_grass_block", "@rocky_dirt"], deep: "@rocky_stone" }
    ];
    var THEME_BY_ID = {};
    THEMES.forEach(function (t) { THEME_BY_ID[t.id] = t; });
    var THEME_MEMO = {};
    function themeFor(id) {
        if (THEME_MEMO[id]) return THEME_MEMO[id];
        return (THEME_MEMO[id] = themeRaw(id));
    }
    function themeRaw(id) {
        if (MOON_BY_ID[id] || String(id).indexOf("susuper:") === 0) return THEME_BY_ID.stony;
        var total = 0;
        THEMES.forEach(function (t) { total += t.weight; });
        var h = O.hash(id + "#surfaceTheme"), roll = Math.floor((U.shr(h, 24).lo & 0xFFFFFF) / 16777216 * total), acc = 0;
        for (var i = 0; i < THEMES.length; i++) { acc += THEMES[i].weight; if (roll < acc) return THEMES[i]; }
        return THEME_BY_ID.overworld;
    }
    /** The RPG.edit.terrain spec for a planet's surface (DMZR v4 tileable terrain: periodic relief, sea, dry landing plateau). */
    function terrainSpec(id, resolveBlock) {
        var t = themeFor(id), c = cellCentre(id), size = surfaceSize(id), half = size / 2;
        var seed = O.hash(id + "#stamp");
        var blk = function (n) { return n.charAt(0) === "@" ? (resolveBlock(n.substring(1)) || "stone") : n; };
        var seaY = t.fluid ? Math.round(96 + t.amp * (0.18 + t.sea * 0.75)) : -1;
        var spec = {
            x: Math.floor(c.x - half), z: Math.floor(c.z - half), width: size, length: size, seed: seed.lo + (seed.hi & 0x1FFFFF) * 4294967296,
            base: 96 + t.amp / 2, relief: t.amp / 2, octaves: t.oct, cells: 4, persistence: t.pers, ridge: t.ridge, warp: t.warp, periodic: true,
            floor: 64, layers: [{ block: blk(t.layers[0]), depth: 1 }, { block: blk(t.layers[1]), depth: 3 }], deep: blk(t.deep),
            plateau: { x: Math.floor(c.x), z: Math.floor(c.z), radius: 10, blend: 22, y: (seaY > 0 ? seaY + 3 : 96 + Math.round(t.amp * 0.55)) },
            clearAbove: false,
            // v4 (SEAS_COMPACT): a 4-chunk periodic margin past every edge, so the far side shows across the wrap seam
            margin: 64
        };
        if (t.fluid) spec.fluid = { block: t.fluid, level: seaY };
        if (t.shore) spec.shore = { block: t.shore, range: 1 };
        return spec;
    }

    // ---- weather (PlanetWeather) ----
    var BLOCK_MS = 3600000, EP_MIN = 180000, EP_MAX = 600000, FADE = 20000;
    var GOLD = U.make(0x9E3779B9, 0x7F4A7C15), C2 = U.make(0xBF58476D, 0x1CE4E5B9);
    function add(a, b) {
        var lo = (a.lo >>> 0) + (b.lo >>> 0), carry = lo >= 4294967296 ? 1 : 0;
        return U.make((a.hi + b.hi + carry) >>> 0, lo >>> 0);
    }
    function step(s) { return U.finish(add(s, GOLD)); }
    function mixw(a, b) { return U.finish(U.xor(a, U.mul(b, C2))); }
    function unitw(s) { return (s.hi * 2097152 + Math.floor(s.lo / 2048)) / 9007199254740992; }   // (s >>> 11) * 2^-53
    function salted(key, salt) {
        var h = U.make(0x0003FFFF, 0xFFFFFFE5 | 0), s = key + "#" + salt, k31 = U.fromInt(31);    // 1125899906842597
        for (var i = 0; i < s.length; i++) h = add(U.mul(h, k31), U.fromInt(s.charCodeAt(i)));
        return h;
    }
    function weighted(u, bag) {
        var total = 0, i;
        for (i = 1; i < bag.length; i += 2) total += bag[i];
        var target = Math.floor(u * total), acc = 0;
        for (i = 0; i < bag.length; i += 2) { acc += bag[i + 1]; if (target < acc) return bag[i]; }
        return bag[0];
    }
    function pickWeather(theme, cold, u) {
        switch (theme) {
            case "overworld": return cold ? weighted(u, ["clear", 55, "snow", 30, "blizzard", 15]) : weighted(u, ["clear", 55, "rain", 30, "storm", 15]);
            case "namek": return weighted(u, ["clear", 50, "rain", 33, "storm", 17]);
            case "kaio": return weighted(u, ["clear", 85, "rain", 15]);
            case "stony": return cold ? weighted(u, ["clear", 55, "snow", 30, "blizzard", 15]) : weighted(u, ["clear", 55, "dust", 30, "meteor", 15]);
            case "nether": return weighted(u, ["clear", 55, "ash", 45]);
            case "end": return weighted(u, ["clear", 65, "meteor", 35]);
        }
        return "clear";
    }
    var CLIMATE = {};
    /** {state, intensity 0..1} for a planet at a wall-clock instant. */
    function weather(id, epoch) {
        var theme = themeFor(id).id;
        if (CLIMATE[id] === undefined) {
            var ch = salted(id, "climate");
            CLIMATE[id] = { cold: floorMod64(ch, 3) === 0, seed: U.mul(salted(id, "weather"), GOLD) };
        }
        var c = CLIMATE[id], block = Math.floor(epoch / BLOCK_MS), offset = epoch - block * BLOCK_MS;
        var st = mixw(c.seed, U.fromInt(block)), cursor = 0;
        for (var i = 0; i < 64; i++) {
            st = step(st);
            var dur = EP_MIN + Math.floor(unitw(st) * (EP_MAX - EP_MIN));
            st = step(st);
            var s = pickWeather(theme, c.cold, unitw(st)), end = cursor + dur;
            if (offset < end || i === 63) {
                var into = offset - cursor, remain = end - offset;
                return { state: s, intensity: s === "clear" ? 0 : Math.max(0, Math.min(1, into / FADE, remain / FADE)) };
            }
            cursor = end;
        }
        return { state: "clear", intensity: 0 };
    }


    // ---- asteroids (AsteroidPositions + AsteroidStamp): rock lumps stamped as blocks, one per populated 384-block cell ----
    // Bit-identical to DMZR: the cell hash, density 0.6, offsets, radius 3..18, theme weights and y band 0..256 (the space
    // dimension's build column, unscaled like the lone stars), the origin and inner-system cut-outs; and the stamp's
    // wobbled shape, three stones per body and the ore tables, all from the same per-block hash.
    var AST = { SECTOR: 384, DENSITY: 0.6, MIN_Y: 0, MAX_Y: 256, MIN_R: 3, MAX_R: 18, PLANET_CLEAR: 24, ORIGIN_CLEAR: 1200, INNER_CLEAR: 5000, WOBBLE: 0.35, ORE: 0.06 };
    var AST_THEMES = [["stone", 60], ["namek", 15], ["nether", 15], ["end", 10]];
    function astTheme(h) {
        var roll = Math.floor(U.unit(h, 48) * 100), acc = 0;
        for (var i = 0; i < AST_THEMES.length; i++) { acc += AST_THEMES[i][1]; if (roll < acc) return AST_THEMES[i][0]; }
        return "stone";
    }
    function asteroidAt(cx, cy, cz, epoch) {
        var h = G.cellHash(cx, cy, cz);
        if (U.unit(h, 0) >= AST.DENSITY) return null;
        var r = Math.fround(AST.MIN_R + Math.fround(U.unit(h, 32) * (AST.MAX_R - AST.MIN_R)));          // Java float maths
        var x = cx * AST.SECTOR + U.unit(h, 24) * AST.SECTOR, y = cy * AST.SECTOR + U.unit(h, 40) * AST.SECTOR, z = cz * AST.SECTOR + U.unit(h, 8) * AST.SECTOR;
        if (y - r < AST.MIN_Y || y + r > AST.MAX_Y) return null;
        if (Math.abs(x) <= AST.ORIGIN_CLEAR && Math.abs(z) <= AST.ORIGIN_CLEAR) return null;
        if (Math.sqrt(x * x + z * z) <= AST.INNER_CLEAR) return null;
        for (var i = 0; i < O.BODIES.length; i++) {
            var c = fixedPos(O.BODIES[i], epoch), half = O.BODIES[i].radius + AST.PLANET_CLEAR + r;
            if (Math.abs(x - c.x) <= half && Math.abs(y - c.y) <= half && Math.abs(z - c.z) <= half) return null;
        }
        return { key: "ast:" + cx + ":" + cy + ":" + cz, x: x, y: y, z: z, radius: r, theme: astTheme(h), seed: h };
    }
    /** Every asteroid whose centre is within range of the point (AsteroidPositions.asteroidsNear). */
    function asteroidsNear(px, py, pz, range, epoch) {
        var out = [], S0 = AST.SECTOR;
        var c0 = Math.floor(Math.floor(px - range) / S0), c1 = Math.floor(Math.floor(px + range) / S0);
        var e0 = Math.floor(Math.floor(py - range) / S0), e1 = Math.floor(Math.floor(py + range) / S0);
        var d0 = Math.floor(Math.floor(pz - range) / S0), d1 = Math.floor(Math.floor(pz + range) / S0);
        for (var cx = c0; cx <= c1; cx++) for (var cy = e0; cy <= e1; cy++) for (var cz = d0; cz <= d1; cz++) {
            var a = asteroidAt(cx, cy, cz, epoch);
            if (!a) continue;
            var dx = a.x - px, dy = a.y - py, dz = a.z - pz;
            if (dx * dx + dy * dy + dz * dz <= range * range) out.push(a);
        }
        return out;
    }
    var C_BY = U.make(0xC2B2AE3D, 0x27D4EB4F), C_BZ = U.make(0x165667B1, 0x9E3779F9);
    function blockHash(seed, dx, dy, dz) {
        return U.finish(U.xor(U.xor(U.xor(seed, U.mul(U.fromInt(dx), U.C1)), U.mul(U.fromInt(dy), C_BY)), U.mul(U.fromInt(dz), C_BZ)));
    }
    var AST_PAL = {
        stone: ["stone", "deepslate", "andesite", "diorite", "granite", "tuff", "calcite", "basalt", "blackstone"],
        namek: ["@namek_stone|stone", "@namek_deepslate|deepslate", "@namek_cobblestone|cobblestone", "@rocky_stone|stone"],
        nether: ["netherrack", "basalt", "blackstone", "soul_soil"],
        end: ["end_stone", "purpur_block", "purpur_pillar"]
    };
    function oreFor(theme, roll, deep) {
        var d = function (a, b) { return deep ? a : b; };
        if (theme === "nether") return roll < 0.60 ? "nether_quartz_ore" : roll < 0.90 ? "nether_gold_ore" : "ancient_debris";
        if (theme === "end") return roll < 0.15 ? "crying_obsidian" : "obsidian";
        if (theme === "namek") {
            if (roll < 0.28) return d("@namek_deepslate_coal_ore|deepslate_coal_ore", "@namek_coal_ore|coal_ore");
            if (roll < 0.50) return d("@namek_deepslate_copper_ore|deepslate_copper_ore", "@namek_copper_ore|copper_ore");
            if (roll < 0.70) return d("@namek_deepslate_iron_ore|deepslate_iron_ore", "@namek_iron_ore|iron_ore");
            if (roll < 0.82) return d("@namek_deepslate_redstone_ore|deepslate_redstone_ore", "@namek_redstone_ore|redstone_ore");
            if (roll < 0.90) return d("@namek_deepslate_lapis_ore|deepslate_lapis_ore", "@namek_lapis_ore|lapis_ore");
            if (roll < 0.95) return d("@namek_deepslate_gold_ore|deepslate_gold_ore", "@namek_gold_ore|gold_ore");
            if (roll < 0.97) return d("@namek_deepslate_emerald_ore|deepslate_emerald_ore", "@namek_emerald_ore|emerald_ore");
            if (roll < 0.98) return d("@namek_deepslate_diamond_ore|deepslate_diamond_ore", "@namek_diamond_ore|diamond_ore");
            if (roll < 0.995) return "@namek_kikono_ore|emerald_ore";
            if (roll < 0.9985) return "@gete_debris_ore|ancient_debris";
            return "ancient_debris";                  // DMZR: Katchin ores (a block DBR does not have; DMZR's own fallback)
        }
        if (roll < 0.28) return d("deepslate_coal_ore", "coal_ore");
        if (roll < 0.50) return d("deepslate_copper_ore", "copper_ore");
        if (roll < 0.70) return d("deepslate_iron_ore", "iron_ore");
        if (roll < 0.82) return d("deepslate_redstone_ore", "redstone_ore");
        if (roll < 0.90) return d("deepslate_lapis_ore", "lapis_ore");
        if (roll < 0.95) return d("deepslate_gold_ore", "gold_ore");
        if (roll < 0.97) return d("deepslate_emerald_ore", "emerald_ore");
        if (roll < 0.995) return d("deepslate_diamond_ore", "diamond_ore");
        if (roll < 0.9975) return "nether_quartz_ore";
        return "ancient_debris";                      // ancient debris, then DMZR's Katchin ores (ancient debris here)
    }
    /**
     * The blocks of one asteroid (AsteroidStamp.stampLump) as a job: job.step(ms) adds x-slabs until ms have passed and
     * returns true when done; job.out is {palette, blocks} for RPG.edit.place, in world coordinates.
     * resolve("name") turns an addon block name into its id ("@name|fallback" falls back to vanilla when it has none).
     */
    function asteroidJob(a, resolve) {
        var seed = a.seed, cx = Math.floor(a.x), cy = Math.floor(a.y), cz = Math.floor(a.z), r = Math.ceil(a.radius);
        var lim = a.radius * a.radius * (1 + AST.WOBBLE) * (1 + AST.WOBBLE);
        var pal = AST_PAL[a.theme] || AST_PAL.stone, want = Math.min(3, pal.length), stones = [], attempt = 0;
        while (stones.length < want && attempt < 32) {
            var c = pal[floorMod64(U.shr(blockHash(seed, attempt + 1, 0, 0), 16), pal.length)];
            if (stones.indexOf(c) < 0) stones.push(c);
            attempt++;
        }
        while (stones.length < want) stones.push(pal[0]);
        var palette = [], index = {}, blocks = [], wob = {}, dx = -r;
        function idx(n) {
            if (index[n] === undefined) {
                var id;
                if (n.charAt(0) === "@") { var parts = n.substring(1).split("|"); id = resolve(parts[0]) || "minecraft:" + parts[1]; }
                else id = "minecraft:" + n;
                index[n] = palette.length; palette.push(id);
            }
            return index[n];
        }
        function slab(dx) {
            for (var dy = -r; dy <= r; dy++) for (var dz = -r; dz <= r; dz++) {
                var d2 = dx * dx + dy * dy + dz * dz;
                if (d2 > lim) continue;
                if (d2 >= 1) {
                    var qx = Math.floor(dx / 3), qy = Math.floor(dy / 3), qz = Math.floor(dz / 3), qk = qx + "," + qy + "," + qz, w = wob[qk];
                    if (w === undefined) w = wob[qk] = 1 - AST.WOBBLE * U.unit(blockHash(seed, qx, qy, qz), 0);
                    var surf = a.radius * w;
                    if (d2 > surf * surf) continue;
                }
                var bh = blockHash(seed, dx, dy, dz), stone = stones[floorMod64(U.shr(bh, 8), stones.length)];
                var deep = stone === "deepslate" || stone.indexOf("@namek_deepslate") === 0;
                blocks.push(cx + dx, cy + dy, cz + dz, idx(U.unit(bh, 24) < AST.ORE ? oreFor(a.theme, U.unit(bh, 40), deep) : stone));
            }
        }
        var job = { out: { palette: palette, blocks: blocks }, key: a.key,
            step: function (ms) {
                var t0 = Date.now();
                while (dx <= r) { slab(dx++); if (Date.now() - t0 >= ms) break; }
                return dx > r;
            } };
        return job;
    }
    function asteroidBlocks(a, resolve) { var j = asteroidJob(a, resolve); while (!j.step(1e9)) { } return j.out; }

    return { SURFACE: SURFACE, configure: configure, setSuper: setSuper, superBand: superBand, superPos: superPos, SUPER_RADIUS: SUPER_RADIUS,
        superList: function () { return SUPER; }, setDestroyed: setDestroyed, isDestroyed: isDestroyed, near: near, find: find, fixedPos: fixedPos, moonPos: moonPos, sunPos: sunPos, MOONS: MOONS,
        moonById: function (id) { return MOON_BY_ID[id] || null; }, cellCentre: cellCentre, surfaceSize: surfaceSize, themeFor: themeFor,
        terrainSpec: terrainSpec, weather: weather, floorMod64: floorMod64, settings: S,
        asteroidsNear: asteroidsNear, asteroidBlocks: asteroidBlocks, asteroidJob: asteroidJob, WRAP_MARGIN: 64, WRAP_TRIGGER_INSET: 6 };
})();
