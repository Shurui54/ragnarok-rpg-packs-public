// =====================================================================================
//  86_dbr_space.js - space travel (port of DMZ Ragnarok's Space module, GPL-3.0)
// =====================================================================================
//  Fly (or ride a space pod) above entryAltitude on a planet and you are in space, next to
//  the planet you left. Space is a zero-g void (ragnarok_rpg:space, datapack/) with the sun
//  at the centre, the main planets and their moons on their rings, and beyond them the
//  generated universe: star systems with landable planets, lone stars and black holes
//  (shared/15..17). Fly into a planet or moon to land on it: main planets are their own
//  worlds, generated planets and moons are stamped squares of ragnarok_rpg:planet_surface
//  that wrap round at their edges (DMZR v4: a 64-block copy of the far side is stamped past
//  every edge; walk 6 blocks onto it and you are moved one planet width, onto the same ground);
//  fly up past y 260 there to return to space. Asteroids (AsteroidPositions/AsteroidStamp) are
//  stamped as rock lumps within 384 blocks of players in space. Planet destruction:
//  87_dbr_space_buster.js (destroy() below is the one entry point). Sink far
//  below the planets and you drop to the nearest planet in range (or home).
//  Picking a planet in the pod's list (or the star map, M) arms the autopilot.
//  Stars burn, black holes pull and kill at the horizon.
//  Settings: ragnarok_rpg/config/dbr_space.json or /rpg config dbr_space.
// =====================================================================================
var DBR_SPACE_CFG = RPG.config.define("dbr_space", {
    enabled:            { default: true, comment: "Space travel on (needs the ragnarok_rpg:space dimension: restart the world once after installing)" },
    entryAltitude:      { default: 1000, min: 64, max: 4096, client: true, comment: "Fly above this height on a planet to reach space (DMZ Ragnarok entryAltitude)" },
    distanceScale:      { default: 0.25, min: 0.02, max: 1, client: true, comment: "Distances x this (ring radii, the systems' spread, the return depth). 1 = DMZ Ragnarok's (Earth 6000, Namek 21000 blocks from the sun)" },
    bodyPlaneY:         { default: 0, min: -2000, max: 4000, client: true, comment: "Height of the main planets' plane in space (DMZ Ragnarok PLANET_Y 0)" },
    returnDepth:        { default: 11808, min: 200, max: 20000, client: true, comment: "Sink this far below the plane (x distanceScale) to drop out of space (DMZ Ragnarok returnAltitude -11808)" },
    nearestPlanetRange: { default: 6144, min: 0, max: 100000, comment: "Dropping out of space lands you on a planet this close (x distanceScale), else back home" },
    podAutopilot:       { default: true, comment: "Picking a planet in the space pod flies there through space (otherwise the pod jumps straight there)" },
    ascentSpeed:        { default: 4, min: 0.5, max: 9.5, client: true, comment: "Autopilot climb speed to entryAltitude (blocks per tick)" },
    cruiseSpeed:        { default: 9, min: 1, max: 9.5, client: true, comment: "Autopilot speed in space (blocks per tick; servers refuse vehicle moves over 10)" },
    sunDamage:          { default: true, comment: "Burn near the sun and stars (DMZ Ragnarok)" },
    starDamageOuter:    { default: 0.05, min: 0, max: 1, comment: "Share of max health a star burns per half second at the edge of its field (12.5x its radius)" },
    starDamageInner:    { default: 0.40, min: 0, max: 2, comment: "... and at its surface" },
    blackHoles:         { default: true, comment: "Black holes pull you in (30x their radius) and kill at the horizon" },
    blackHolePullOuter: { default: 0.25, min: 0, max: 5, client: true, comment: "Pull at the edge of a black hole's reach (blocks per tick)" },
    blackHolePullInner: { default: 6, min: 0, max: 40, client: true, comment: "Pull near the point of no return" },
    surfaceLeaveAltitude: { default: 260, min: 140, max: 316, client: true, comment: "Fly above this on a generated planet or moon to return to space (DMZ Ragnarok 260)" },
    asteroids:          { default: true, comment: "Asteroid lumps (stone, Namek, nether and end rock with ores) stamped into space near players (DMZ Ragnarok asteroidsEnabled)" },
    asteroidSpawnRange: { default: 384, min: 64, max: 4096, comment: "Asteroids within this many blocks of a player in space are stamped (DMZ Ragnarok asteroidSpawnRange)" }
});

// space is weightless and endless downwards (DMZ Ragnarok: no gravity, no void kill); the engine applies both
RPG.dimensions.setGravity(DBR_SPACE_ORBITS.SPACE, 0);
RPG.dimensions.setVoidDamage(DBR_SPACE_ORBITS.SPACE, false);

var DBR_SPACE = (function () {
    var C = DBR_SPACE_CFG, O = DBR_SPACE_ORBITS, B = DBR_SPACE_BODIES, G = DBR_SPACE_GEN, SPACE = O.SPACE, SURFACE = B.SURFACE;
    var LANDING_MARGIN = 8, STANDOFF = 40;
    function applyCfg() { B.configure(C.get("distanceScale"), C.get("bodyPlaneY")); }
    applyCfg();
    C.onChange(applyCfg);

    function on() { return C.get("enabled") && RPG.server.hasDimension(SPACE); }
    function now() { return Date.now(); }
    function returnY() { return C.get("bodyPlaneY") - C.get("returnDepth") * C.get("distanceScale"); }
    function dist(a, b) { var dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z; return Math.sqrt(dx * dx + dy * dy + dz * dz); }
    function inPod(p) { var v = p.getVehicle(); return v && v.getVehicleId() === "spacepod" ? v : null; }
    function msg(p, text) { p.actionbar(text); }
    function loaded(b) { return b.kind !== "fixed" || RPG.server.hasDimension(b.body.dim); }
    function landable(b) { return b.kind === "fixed" || b.kind === "moon" || b.kind === "planet" || b.kind === "super"; }

    // ---- the seven Super bodies: orbit elements chosen once per world (SuperPlanetData) ----
    function superElems() {
        var raw = RPG.server.getData("dbr_super_elems2", "");
        if (raw) { try { var o = JSON.parse(String(raw)); if (o.scale === C.get("distanceScale")) return o.list; } catch (e) { } }
        var bands = [0, 1, 2, 3, 4, 5, 6, 7], out = [];
        for (var i = bands.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = bands[i]; bands[i] = bands[j]; bands[j] = t; }
        for (var star = 1; star <= 7; star++) {
            var bd = B.superBand(bands[star - 1]);
            out.push({ star: star, ring: bd[0] + Math.random() * (bd[1] - bd[0]), phase0: Math.random() * Math.PI * 2, y: (Math.random() * 2 - 1) * 1100 * C.get("distanceScale") });
        }
        RPG.server.setData("dbr_super_elems2", JSON.stringify({ scale: C.get("distanceScale"), list: out }));
        return out;
    }
    B.setSuper(superElems());
    function hasSuperRadar(p) { try { return p.hasItem("super_dball_radar", 1); } catch (e) { return false; } }
    var radarSeen = {};
    function superBallsDropped() { var o = []; for (var k = 1; k <= 7; k++) if (RPG.server.getData("dbr_super_ball_" + k, 0)) o.push(k); return o; }
    function destroyedList() { var r = String(RPG.server.getData("dbr_destroyed", "") || ""); return r ? r.split(",") : []; }
    B.setDestroyed(destroyedList());

    var NAMES = { overworld: "Earth", namek: "Planet Namek", sacredkaiplanet: "Sacred World of the Kais", demon_realm: "Demon Realm", planet_vegeta: "Planet Vegeta" };
    function nameOf(b) {
        if (!b) return "?";
        if (b.kind === "fixed") return NAMES[b.id] || b.id;
        if (b.kind === "moon") return (NAMES[b.moon.parent.id] || b.moon.parent.id) + " Moon";
        if (b.kind === "planet") return "Planet " + b.id.substring(6, 12).toUpperCase();
        if (b.kind === "super") return "Super Dragon Ball Planet " + b.star;
        return b.id;
    }

    // ---- autopilot state (player var, like DMZR's persistent su_space_autopilot tag) ----
    function autopilot(p) { return String(p.getVar("dbr_space_autopilot", "") || ""); }
    function setAutopilot(p, id) { p.setVar("dbr_space_autopilot", id || ""); sendState(p); }
    function sendState(p) {
        RPG.net.send(p, "dbr_space_state", { autopilot: autopilot(p), epoch: Date.now(), inSpace: p.dimension === SPACE,
            origin: String(p.getVar("dbr_space_origin", "") || ""), surface: String(p.getVar("dbr_surface", "") || ""),
            surfaceCell: String(p.getVar("dbr_surface_cell", "") || ""), supers: B.superList(), destroyed: destroyedList(),
            superBalls: superBallsDropped(), superRadar: hasSuperRadar(p) });
    }

    // ---- moving players (and their pod) ----
    var cooldown = {}, pending = {}, grace = {};
    // generate/load the destination chunks first (in the background), so the teleport itself stays cheap
    function preload(p, dim, x, z, go, tries) {
        tries = tries === undefined ? 200 : tries;                 // up to 20 s: noise worlds (Namek, Vegeta) generate slowly
        var fx = Math.floor(x), fz = Math.floor(z);
        // the chunks round the arrival point too (the teleport otherwise loads them on the spot)
        var ready = RPG.world.isLoaded(dim, fx, fz) && RPG.world.isLoaded(dim, fx + 40, fz + 40) && RPG.world.isLoaded(dim, fx - 40, fz - 40)
            && RPG.world.isLoaded(dim, fx + 40, fz - 40) && RPG.world.isLoaded(dim, fx - 40, fz + 40);
        if (tries <= 0 || ready) { delete pending[p.uuid]; go(); return; }
        pending[p.uuid] = true;
        if (tries === 200) RPG.world.requestChunks(dim, fx, fz, 4);
        RPG.schedule(2, () => { if (p.alive) preload(p, dim, x, z, go, tries - 1); else delete pending[p.uuid]; });
    }
    function dropY() { return Math.min(220, C.get("entryAltitude") - 24); }
    function carry(p, dim, x, y, z, after) {
        cooldown[p.uuid] = RPG.server.getTick() + 40;
        var pod = inPod(p);
        if (pod) p.dismount();
        var ok = p.teleportTo(dim, x, y, z);
        if (ok === false || p.dimension !== dim) {
            if (pod) p.mount(pod);
            msg(p, "&cThat world isn't loaded. Restart the world once so it loads.");
            return false;
        }
        if (pod) {
            pod.remove();
            RPG.schedule(1, () => {
                if (!p.alive || p.dimension !== dim) return;
                var np = RPG.world.spawnVehicle(dim, "spacepod", p.x, p.y, p.z, p.yaw);
                if (np) { DBR_POD_ARRIVING[p.uuid] = true; p.mount(np); }
                if (after) after(!!np);
            });
        } else if (after) RPG.schedule(1, () => after(false));
        return true;
    }
    // A pod is driven by its rider's computer, so a server teleport of it snaps back: the client flies it down instead
    // (DMZR's landing descent). On foot the player is simply put on the ground.
    function settle(p, dim, x, z, pod, fixedY) {
        preload(p, dim, x, z, () => {
            if (!p.alive || p.dimension !== dim) return;
            var y = fixedY;
            if (y === undefined) { var sy = RPG.world.surfaceY(dim, Math.floor(x), Math.floor(z)); y = (sy > -9999 ? sy : 100) + 0.3; }
            if (pod && inPod(p)) RPG.net.send(p, "dbr_space_descend", { x: x, y: y, z: z });
            else p.teleportTo(dim, x, y, z);
        });
    }

    /** Arrive in space beside a body (DMZR enterSpace / leaving a surface): on its far side from its sun. */
    function toSpaceBeside(p, b, title) {
        var bp = b.pos, s = B.sunPos();
        if (b.kind === "planet") s = { x: b.planet.system.x, y: b.planet.system.y, z: b.planet.system.z };
        // outside the body's whole cube (its landing volume), plus the standoff; and a grace before it can land you again
        var ox = bp.x - s.x, oz = bp.z - s.z, ol = Math.sqrt(ox * ox + oz * oz) || 1, d = b.radius * 1.75 + LANDING_MARGIN + STANDOFF;
        grace[p.uuid] = { id: b.id, until: RPG.server.getTick() + 300 };
        var x = bp.x + ox / ol * d, z = bp.z + oz / ol * d, y = bp.y;
        preload(p, SPACE, x, z, () => {
            if (!carry(p, SPACE, x, y, z, () => sendState(p))) return;
            p.setVar("dbr_surface", "");
            p.lookAt(bp.x, bp.y, bp.z);
            p.playSound(DMZ + "ui_nave_takeoff", 1, 0.8);
            if (title) p.title("&bSpace", "&7Fly into a planet to land. M: star map");
        });
    }
    function enterSpace(p, body) {
        p.setVar("dbr_space_origin", p.dimension + " " + p.x.toFixed(1) + " " + p.y.toFixed(1) + " " + p.z.toFixed(1));
        p.setVar("dbr_space_last_" + body.id, p.x.toFixed(1) + " " + p.z.toFixed(1));
        toSpaceBeside(p, B.find(body.id, now()), true);
    }

    /** Touching a main planet: down to its surface (DMZR landOnPlanet), at your last spot there if you have one. */
    function landFixed(p, body) {
        var x = 0.5, z = 0.5;
        var origin = String(p.getVar("dbr_space_origin", "") || "").split(" ");
        var last = String(p.getVar("dbr_space_last_" + body.id, "") || "").split(" ");
        if (origin[0] === body.dim) { x = Number(origin[1]); z = Number(origin[3]); }
        else if (last.length === 2 && !isNaN(Number(last[0]))) { x = Number(last[0]); z = Number(last[1]); }
        else if (body.landing) { x = body.landing[0]; z = body.landing[2]; }
        var fixedY = body.landing && body.landing[1] > 300 ? body.landing[1] : undefined;
        setAutopilot(p, "");
        cooldown[p.uuid] = RPG.server.getTick() + 200;
        preload(p, body.dim, x, z, () => {
            var hadPod = !!inPod(p);
            if (!carry(p, body.dim, x, fixedY || dropY(), z, (pod) => {
                if (!fixedY) settle(p, body.dim, x, z, pod);
                if (pod) p.playSound(DMZ + "ship_landing_open", 1, 1);
                sendState(p);
            })) return;
            p.title("&a" + nameOf({ kind: "fixed", id: body.id }), "");
            if (!hadPod) p.setVelocity(0, 0, 0);
        });
    }
    O.byId("demon_realm").landing = [160.5, 745, 0.5];
    O.byId("planet_vegeta").landing = [155, 65, -75];

    // ---- generated planets and moons: stamped squares of the surface dimension ----
    var STAMPING = {}, STAMP_COUNT = 0;
    function stamped(id) { return !!RPG.server.getData("dbr_stamp_" + id, 0); }
    /** 1 = an older stamp without the wrap margin (keeps the old wrap), 2 = DMZR v4 (64-block periodic margin). */
    function stampVersion(id) { return Number(RPG.server.getData("dbr_stamp_" + id, 0)) || 0; }
    function stamp(id, done) {
        if (stamped(id)) { done(true); return; }
        if (STAMPING[id]) { STAMPING[id].push(done); return; }
        STAMPING[id] = [done];
        var spec = B.terrainSpec(id, blockRef);
        RPG.log("[DBR] space: stamping " + id + " (" + B.themeFor(id).id + ", " + spec.width + " blocks)");
        var finish = (ok) => {
            if (ok) {
                RPG.server.setData("dbr_stamp_" + id, 2);                // 2: stamped with the wrap margin (DMZR v4)
                var cc = B.cellCentre(id);
                RPG.server.setData("dbr_cell_" + Math.round(cc.x / 65536) + "_" + Math.round(cc.z / 65536), id);
            }
            var cbs = STAMPING[id] || [];
            delete STAMPING[id];
            cbs.forEach((f) => { try { f(ok); } catch (err) { RPG.log("[DBR] space stamp: " + err); } });
            if (ok) { decorate(id, spec); placeBlackStar(id, spec); }
        };
        try {
            STAMP_COUNT++;
            if (STAMP_COUNT === 1) { try { RPG.edit.settings({ budgetMs: 24 }); } catch (e) { } }
            RPG.edit.terrain(null, SURFACE, spec, { history: false, progress: false, label: "Planet " + id }).then((t) => {
                if (--STAMP_COUNT === 0) { try { RPG.edit.settings({ budgetMs: 12 }); } catch (e) { } }
                finish(true);
            });
        } catch (err) { RPG.log("[DBR] space: stamp failed: " + err); finish(false); }
    }
    // vegetation and rock features over the fresh ground (DMZR SurfaceStamp vegetation tables), a few per tick
    var VEG = {
        overworld: { features: [["minecraft:oak", 4], ["minecraft:birch", 2], ["minecraft:spruce", 2]], cover: [["grass", 30], ["fern", 10], ["poppy", 4], ["dandelion", 4]] },
        namek: { features: [["dbr:namek_ajissa_tree", 4], ["dbr:namek_sacred_tree", 1], ["dbr:namek_plains_grass", 22], ["dbr:namek_plains_flowers", 8]] },
        kaio: { features: [["dbr:namek_sacred_tree", 1], ["dbr:sacredkai_grass_patch", 22], ["dbr:sacredkai_flowers", 8], ["dbr:sacredkai_rock_cluster", 4]] },
        end: { features: [["minecraft:chorus_plant", 1]] },
        nether: { cover: [["crimson_roots", 6], ["warped_roots", 6], ["nether_sprouts", 6]] },
        stony: { cover: [["cobblestone", 3], ["mossy_cobblestone", 1]] }
    };
    function decorate(id, spec) {
        var theme = B.themeFor(id).id, v = VEG[theme];
        if (!v) return;
        var rnd = dmzRng(O.javaHash(id + "#veg"), 0), n = Math.floor(spec.width * spec.length / 500), list = [];
        for (var i = 0; i < n; i++) list.push([spec.x + Math.floor(rnd() * spec.width), spec.z + Math.floor(rnd() * spec.length), rnd()]);
        var pick = (tbl, u) => { var total = 0; tbl.forEach((e) => total += e[1]); var t = u * total; for (var k = 0; k < tbl.length; k++) { t -= tbl[k][1]; if (t < 0) return tbl[k][0]; } return tbl[0][0]; };
        var at = 0;
        var task = RPG.every(1, () => {
            for (var k = 0; k < 6 && at < list.length; k++, at++) {
                var c = list[at];
                if (!RPG.world.isLoaded(SURFACE, c[0], c[1])) continue;
                var y = RPG.world.surfaceY(SURFACE, c[0], c[1]);
                if (y <= -9999) continue;
                var ground = String(RPG.world.getBlock(SURFACE, c[0], y - 1, c[1]));
                if (ground.indexOf("water") >= 0 || ground.indexOf("lava") >= 0 || ground.indexOf("ice") >= 0) continue;
                if (v.features && (!v.cover || c[2] < 0.5)) RPG.server.runCommand("execute in " + SURFACE + " run place feature " + pick(v.features, c[2] * (v.cover ? 2 : 1)) + " " + c[0] + " " + y + " " + c[1]);
                else if (v.cover) RPG.world.setBlock(SURFACE, c[0], y, c[1], "minecraft:" + pick(v.cover, (c[2] - (v.features ? 0.5 : 0)) * (v.features ? 2 : 1)));
            }
            if (at >= list.length) RPG.cancel(task);
        });
    }
    function landSurface(p, b) {
        var id = b.id, c = B.cellCentre(id);
        setAutopilot(p, "");
        cooldown[p.uuid] = RPG.server.getTick() + 400;
        msg(p, "&7Approaching " + nameOf(b) + "...");
        pending[p.uuid] = true;
        var landed = false;
        var go = (ok) => {
            if (landed) return;
            landed = true;
            if (!p.alive) { delete pending[p.uuid]; return; }
            var spec = B.terrainSpec(id, blockRef);
            var y = RPG.edit.terrainHeight(spec, Math.floor(c.x), Math.floor(c.z)) + 1;
            if (spec.fluid) y = Math.max(y, spec.fluid.level + 1);
            delete pending[p.uuid];
            preload(p, SURFACE, c.x, c.z, () => {
                if (!carry(p, SURFACE, c.x, y + 6, c.z, (pod) => { settle(p, SURFACE, c.x, c.z, pod, y + 0.3); sendState(p); })) return;
                p.setVar("dbr_surface", id);
                p.setVar("dbr_surface_cell", b.kind === "planet" ? b.planet.system.cx + "," + b.planet.system.cz : "");
                var th = B.themeFor(id).id;
                p.title("&a" + nameOf(b), "&7" + th.charAt(0).toUpperCase() + th.substring(1) + " world, " + B.surfaceSize(id) + " blocks across. Fly up to leave.");
                p.setVelocity(0, 0, 0);
            });
        };
        stamp(id, go);
        // the stamp builds outward from the centre: land as soon as the ground under the landing spot is there
        var spec0 = B.terrainSpec(id, blockRef), want = RPG.edit.terrainHeight(spec0, Math.floor(c.x), Math.floor(c.z));
        var poll = (n) => {
            if (landed || n <= 0) return;
            if (n % 20 === 0) RPG.world.requestChunks(SURFACE, Math.floor(c.x), Math.floor(c.z), 3);   // keep the landing area loaded
            var ready = RPG.world.isLoaded(SURFACE, Math.floor(c.x) + 24, Math.floor(c.z) + 24) && RPG.world.isLoaded(SURFACE, Math.floor(c.x) - 24, Math.floor(c.z) - 24)
                && RPG.world.surfaceY(SURFACE, Math.floor(c.x), Math.floor(c.z)) >= want && RPG.world.surfaceY(SURFACE, Math.floor(c.x) + 24, Math.floor(c.z) + 24) > 64
                && RPG.world.surfaceY(SURFACE, Math.floor(c.x) - 24, Math.floor(c.z) - 24) > 64;
            if (ready) go(true); else RPG.schedule(10, () => poll(n - 1));
        };
        RPG.schedule(10, () => poll(600));
    }
    function land(p, b) {
        if (b.kind === "fixed") landFixed(p, b.body);
        else landSurface(p, b);
    }

    /** Far below the planets: the nearest planet in range, else where you took off (DMZR descend-out). */
    function leaveSpace(p) {
        var range = C.get("nearestPlanetRange") * C.get("distanceScale"), best = null, bestD = 1e18;
        B.near(p, range, now()).forEach((b) => {
            if (!landable(b) || !loaded(b)) return;
            var d = dist(p, b.pos) - b.radius;
            if (d < range && d < bestD) { best = b; bestD = d; }
        });
        if (best) { land(p, best); return; }
        var o = String(p.getVar("dbr_space_origin", "") || "").split(" ");
        setAutopilot(p, "");
        var dim = o.length === 4 && RPG.server.hasDimension(o[0]) ? o[0] : "minecraft:overworld";
        var x = o.length === 4 ? Number(o[1]) : 0.5, z = o.length === 4 ? Number(o[3]) : 0.5;
        preload(p, dim, x, z, () => carry(p, dim, x, dropY(), z, (pod) => { settle(p, dim, x, z, pod); sendState(p); }));
        msg(p, "&7You drift back home.");
    }

    // ---- hazards (SpaceHazardModule): stars burn, black holes pull and kill ----
    var lastBurn = {};
    function hazards(p, list) {
        if (p.getGameMode() === "creative") return;
        var t = RPG.server.getTick(), best = null, bestT = -1;
        list.forEach((b) => {
            if (b.kind !== "star" && b.kind !== "sun") return;
            var d = dist(p, b.pos), outer = b.kind === "sun" ? O.SUN.danger : b.radius * 12.5;
            if (d >= outer) return;
            var tt = Math.max(0, Math.min(1, (outer - d) / (outer - b.radius)));
            if (tt > bestT) { bestT = tt; best = b; }
            if (d < b.radius * 3 + 12) {                                         // inside the drawn star: thrown back out
                var k = 1.2 / (d || 1);
                if (!inPod(p)) p.setVelocity((p.x - b.pos.x) * k, (p.y - b.pos.y) * k, (p.z - b.pos.z) * k);
            }
        });
        if (best && C.get("sunDamage") && t - (lastBurn[p.uuid] || 0) >= 10) {
            lastBurn[p.uuid] = t;
            var frac = C.get("starDamageOuter") + (C.get("starDamageInner") - C.get("starDamageOuter")) * bestT;
            p.damage(Math.max(1, frac * p.maxHealth));
            p.setFire(3);
            msg(p, "&6The star is burning you!");
        }
        if (!C.get("blackHoles")) return;
        list.forEach((b) => {
            if (b.kind !== "hole") return;
            var d = dist(p, b.pos);
            if (d <= b.hole.horizon) {
                setAutopilot(p, "");
                p.damage(1e9);
                if (p.alive) p.setHealth(0);
                return;
            }
            if (d >= b.hole.pull) return;
            var horizon = b.hole.horizon, pnr = Math.max(Math.min(horizon * 3, b.hole.pull * 0.5), horizon + 0.001);
            msg(p, d <= pnr ? "&4The black hole has you. There is no escaping now." : "&cA black hole's gravity has you. Break away before you are pulled in.");
            if (inPod(p)) return;                                                // the rider's computer pulls the pod (61_dbr_space.js)
            var step = pullStep(d, C.get("blackHolePullOuter"), Math.max(C.get("blackHolePullInner"), 18), pnr, b.hole.pull);
            step = Math.min(step, d);
            p.teleportTo(SPACE, p.x + (b.pos.x - p.x) / d * step, p.y + (b.pos.y - p.y) / d * step, p.z + (b.pos.z - p.z) / d * step);
        });
    }
    function pullStep(d, outer, inner, pnr, influence) {
        var denom = 1 / (pnr * pnr) - 1 / (influence * influence);
        if (denom <= 1e-12) return outer + (inner - outer) * Math.max(0, Math.min(1, (influence - d) / Math.max(influence - pnr, 1e-6)));
        var a = (inner - outer) / denom, b = outer - a / (influence * influence);
        var pull = Math.max(a / (d * d) + b, outer);
        return d <= pnr ? Math.max(pull, inner) : pull;
    }

    // ---- the per-player check (DMZR SpaceTravelModule player tick) ----
    var nearCache = {};
    function check(p) {
        if (!p.alive || p.getGameMode() === "spectator") return;
        if (pending[p.uuid] || RPG.server.getTick() < (cooldown[p.uuid] || 0)) return;
        var dim = p.dimension;
        if (dim === SPACE) {
            var ap = autopilot(p);
            if (ap && !inPod(p)) { setAutopilot(p, ""); msg(p, "&7Autopilot off."); ap = ""; }
            if (p.y < returnY()) { leaveSpace(p); return; }
            // the body list barely changes from one check to the next: rebuild it once a second
            var nc = nearCache[p.uuid], t = RPG.server.getTick();
            if (!nc || t - nc.t > 20 || dist(p, nc.at) > 400) {
                // a few new sectors per check (a long jump fills in over the next checks instead of stalling a tick)
                G.setBudget(24);
                nc = nearCache[p.uuid] = { t: t, at: { x: p.x, y: p.y, z: p.z }, list: B.near(p, 3600, now()) };
                G.setBudget(0);
            }
            var list = nc.list, ep = now();
            for (var i = 0; i < list.length; i++) {
                var b = list[i];
                if (!landable(b)) continue;
                if (ap && ap !== b.id) continue;                       // on autopilot only the target body lands you
                var gr = grace[p.uuid];
                if (gr && gr.id === b.id && RPG.server.getTick() < gr.until) continue;   // just left it
                var pos = b.kind === "fixed" ? B.fixedPos(b.body, ep) : b.kind === "moon" ? B.moonPos(b.moon.parent, ep) : b.kind === "super" ? B.superPos(b.sup, ep) : G.planetPos(b.planet, ep);
                if (Math.abs(p.x - pos.x) <= b.radius + LANDING_MARGIN && Math.abs(p.y - pos.y) <= b.radius + LANDING_MARGIN && Math.abs(p.z - pos.z) <= b.radius + LANDING_MARGIN && loaded(b)) {
                    b.pos = pos;
                    land(p, b);
                    return;
                }
            }
            hazards(p, list);
            return;
        }
        if (dim === SURFACE) { surfaceTick(p); return; }
        var body = O.byDim(dim);
        if (!body || p.y < C.get("entryAltitude")) return;
        if (!on()) {
            // a data-pack dimension only exists after the world starts again: say so instead of nothing happening
            if (C.get("enabled") && RPG.server.getTick() % 100 < 5) msg(p, "&eSpace isn't loaded in this world yet: save, quit and reopen the world once.");
            return;
        }
        enterSpace(p, body);
    }
    // on a generated planet or moon: wrap round at the edges, fall-catch, leave upwards (DMZR surface boundary + wrap)
    function surfaceTick(p) {
        var id = String(p.getVar("dbr_surface", "") || "");
        if (!id) {
            // lost track (old save): back to space beside Earth
            if (on()) toSpaceBeside(p, B.find("overworld", now()), true);
            return;
        }
        var cell = String(p.getVar("dbr_surface_cell", "") || "").split(",");
        if (cell.length === 2) G.systemAt(Number(cell[0]), Number(cell[1]));     // that planet's system (after a reload the cache is empty)
        var c = B.cellCentre(id), half = B.surfaceSize(id) / 2;
        if (p.y > C.get("surfaceLeaveAltitude")) {
            var b = B.find(id, now());
            if (b) { toSpaceBeside(p, b, true); return; }
        }
        if (p.y < 20) { var y0 = RPG.edit.terrainHeight(B.terrainSpec(id, blockRef), Math.floor(c.x), Math.floor(c.z)) + 2; p.teleportTo(SURFACE, c.x, y0, c.z); return; }
        if (RPG.server.getTick() % 40 < 5) { guardian(p, id, c); garrison(p, id, c); }
        var dx = p.x - c.x, dz = p.z - c.z, nx = p.x, nz = p.z, size = B.surfaceSize(id), ver = stampVersion(id);
        if (ver === 1) {
            // an older stamp has no margin past its edge: wrap just inside it (as before)
            if (dx > half - 2) nx -= half * 2 - 6; else if (dx < -half + 2) nx += half * 2 - 6;
            if (dz > half - 2) nz -= half * 2 - 6; else if (dz < -half + 2) nz += half * 2 - 6;
        } else {
            // DMZR seamWrapTarget: walk WRAP_TRIGGER_INSET (6) blocks onto the margin (the far side, pre-stamped), then
            // move exactly one planet width: the same ground, strictly inside the square, so it never ping-pongs
            var trig = half + B.WRAP_TRIGGER_INSET;
            if (dx > trig) nx -= size; else if (dx < -trig) nx += size;
            if (dz > trig) nz -= size; else if (dz < -trig) nz += size;
            if ((nx !== p.x || nz !== p.z) && !stamped(id)) {
                // the surface is still being stamped: hold at the wall (half + 6, pushed back 3) instead of wrapping
                var lim = half + 6, wx = p.x, wz = p.z;
                if (dx > lim) wx = c.x + lim - 3; else if (dx < -lim) wx = c.x - lim + 3;
                if (dz > lim) wz = c.z + lim - 3; else if (dz < -lim) wz = c.z - lim + 3;
                if ((wx !== p.x || wz !== p.z) && !inPod(p)) { p.teleportTo(SURFACE, wx, p.y, wz); p.setVelocity(0, 0, 0); msg(p, "&7The edge of this world is still forming."); }
                return;
            }
        }
        if (nx !== p.x || nz !== p.z) {
            preload(p, SURFACE, nx, nz, () => {
                var pod = inPod(p), y = p.y;
                if (pod) { p.dismount(); pod.teleportTo(SURFACE, nx, pod.y, nz); }
                p.teleportTo(SURFACE, nx, y, nz);
                if (pod) RPG.schedule(2, () => { DBR_POD_ARRIVING[p.uuid] = true; p.mount(pod); });
            });
        }
    }

    // ---- the wrap margin mirrors the far side of the planet: editing it would break the illusion (DMZR protectMargin) ----
    function marginGuard(player, block, x, y, z, dim) {
        if (dim !== SURFACE || player.isOp() || String(player.getGameMode()) === "creative") return;
        var id = String(player.getVar("dbr_surface", "") || "");
        if (!id || stampVersion(id) < 2) return;
        var c = B.cellCentre(id), half = B.surfaceSize(id) / 2;
        if (Math.abs(x - c.x) <= half && Math.abs(z - c.z) <= half) return;
        msg(player, "&7This ground mirrors the far side of the planet: build inside it.");
        return false;
    }
    RPG.on("blockBreak", marginGuard);
    RPG.on("blockPlace", marginGuard);

    // ---- asteroids (PlanetSpawnModule + AsteroidStamp): once a second, the lumps within asteroidSpawnRange of each
    // player in space are stamped into blocks, each cell exactly once (the "stamped" flag is the only state) ----
    var AST_QUEUE = [], AST_QUEUED = {}, AST_JOB = null;
    function asteroidSweep() {
        if (!C.get("asteroids")) return;
        var ep = now(), range = C.get("asteroidSpawnRange");
        RPG.server.players().forEach((p) => {
            if (p.dimension !== SPACE) return;
            B.asteroidsNear(p.x, p.y, p.z, range, ep).forEach((a) => {
                if (AST_QUEUED[a.key] || RPG.server.getData("dbr_ast_" + a.key, 0)) return;
                AST_QUEUED[a.key] = true;
                AST_QUEUE.push(a);
            });
        });
    }
    // one lump at a time, its blocks worked out a few milliseconds a tick, then written through the budgeted editor
    function asteroidWork() {
        if (!AST_JOB) {
            var a = AST_QUEUE.shift();
            if (!a) return;
            AST_JOB = B.asteroidJob(a, blockRef);
        }
        if (!AST_JOB.step(4)) return;
        var job = AST_JOB;
        AST_JOB = null;
        delete AST_QUEUED[job.key];
        try {
            RPG.edit.place(null, SPACE, job.out, { history: false, progress: false, label: "Asteroid " + job.key });
            RPG.server.setData("dbr_ast_" + job.key, 1);
        } catch (err) { RPG.log("[DBR] space: asteroid " + job.key + ": " + err); }
    }
    RPG.every(1, () => { if (AST_JOB || AST_QUEUE.length) { try { asteroidWork(); } catch (err) { AST_JOB = null; RPG.log("[DBR] space asteroids: " + err); } } });
    RPG.every(20, () => { try { if (on()) asteroidSweep(); } catch (err) { RPG.log("[DBR] space asteroids: " + err); } });

    RPG.every(40, () => {
        // the Super bodies show only to players carrying the Super Dragon Radar: resend when that changes
        RPG.server.players().forEach((p) => { var h = hasSuperRadar(p); if (radarSeen[p.uuid] !== h) { radarSeen[p.uuid] = h; sendState(p); } });
    });
    RPG.every(5, () => {
        if (!C.get("enabled")) return;
        RPG.server.players().forEach((p) => { try { check(p); } catch (err) { RPG.log("[DBR] space: " + err); } });
        if (RPG.server.getTick() % 1200 === 0) G.trim();
    });
    RPG.on("playerJoin", (p) => { RPG.schedule(20, () => sendState(p)); });
    RPG.on("playerLeave", (p) => { delete nearCache[p.uuid]; delete pending[p.uuid]; delete cooldown[p.uuid]; });
    RPG.on("death", (p) => { if (autopilot(p)) p.setVar("dbr_space_autopilot", ""); });   // dying cancels the trip

    // ---- autopilot (the pod's destination list, 56_vehicles.js, and the star map) ----
    function startAutopilot(p, targetId) {
        if (!C.get("podAutopilot") || !on() || !inPod(p)) return false;
        var b = B.find(targetId, now()) || (O.byDim(targetId) ? B.find(O.byDim(targetId).id, now()) : null);
        if (!b || !loaded(b)) return false;
        if (b.kind === "fixed" && p.dimension === b.body.dim) return false;
        if (p.dimension !== SPACE && p.dimension !== SURFACE && !O.byDim(p.dimension)) return false;   // rooms jump as before
        setAutopilot(p, b.id);
        p.playSound(DMZ + "ui_nave_takeoff", 1, 1);
        msg(p, "&bAutopilot: " + nameOf(b) + (p.dimension === SPACE ? "" : " (climbing out)"));
        return true;
    }
    RPG.net.on("dbr_space_autopilot", (p, d) => {
        var id = String(d && d.id || "");
        if (!id) { if (autopilot(p)) { setAutopilot(p, ""); msg(p, "&7Autopilot off."); } return; }
        if (!inPod(p)) { msg(p, "&cThe autopilot needs a space pod."); return; }
        if (d.cx !== undefined) G.systemAt(Math.floor(Number(d.cx)), Math.floor(Number(d.cz)));    // a far system's planets
        if (!startAutopilot(p, id)) msg(p, "&cThe autopilot can't reach that.");
    });
    RPG.net.on("dbr_space_hello", (p) => sendState(p));

    // ---- planet info (DMZR PlanetInfoServer: who is on each world) ----
    RPG.net.on("dbr_space_info", (p, d) => {
        var id = String(d && d.id || "");
        if (d && d.cx !== undefined) G.systemAt(Math.floor(Number(d.cx)), Math.floor(Number(d.cz)));
        var b = B.find(id, now());
        if (!b) return;
        var here = RPG.server.players().filter((q) => b.kind === "fixed" ? q.dimension === b.body.dim : String(q.getVar("dbr_surface", "")) === id).map((q) => q.name);
        RPG.net.send(p, "dbr_space_info", { id: id, name: nameOf(b), loaded: loaded(b), players: here.slice(0, 8), count: here.length,
            owner: claimOf(id), theme: b.kind === "fixed" ? "" : B.themeFor(id).id, size: b.kind === "fixed" ? 0 : B.surfaceSize(id), stamped: b.kind === "fixed" || stamped(id),
            visited: b.kind === "fixed" ? (!!p.getVar("dbr_space_last_" + b.id, "") || String(p.getVar("dbr_space_origin", "")).indexOf(b.body.dim + " ") === 0) : !!p.getVar("dbr_visited_" + id, 0) });
        if (String(p.getVar("dbr_surface", "")) === id) p.setVar("dbr_visited_" + id, 1);
    });

    // ---- Black Star Dragon Balls: one each on seven generated planets (DMZ Ragnarok) ----
    function placeBlackStar(id, spec) {
        if (typeof dbrPlaceDragonBall !== "function" || typeof DB_SETS === "undefined" || !DB_SETS.blackstar) return;
        if (id.indexOf("sugen:") !== 0) return;
        var placed = RPG.server.getData("dbr_blackstar_planets", "") || "", taken = placed ? String(placed).split(",") : [];
        if (taken.length >= 7 || taken.some((e) => e.split("=")[1] === id)) return;
        if ((O.javaHash(id + "#blackstar") & 1) === 1 && taken.length > 0) return;   // about every other new planet
        var star = 1;
        while (taken.some((e) => Number(e.split("=")[0]) === star)) star++;
        var rnd = dmzRng(O.javaHash(id + "#ball"), 0), tries = 0;
        var tryPlace = () => {
            var x = spec.x + 16 + Math.floor(rnd() * (spec.width - 32)), z = spec.z + 16 + Math.floor(rnd() * (spec.length - 32));
            if (!RPG.world.isLoaded(SURFACE, x, z)) { RPG.world.requestChunks(SURFACE, x, z, 0); if (++tries < 40) RPG.schedule(10, tryPlace); return; }
            var y = RPG.world.surfaceY(SURFACE, x, z);
            if (y <= -9999) { if (++tries < 40) RPG.schedule(10, tryPlace); return; }
            dbrPlaceDragonBall("blackstar", star, SURFACE, x, y, z);
            taken.push(star + "=" + id);
            RPG.server.setData("dbr_blackstar_planets", taken.join(","));
            RPG.log("[DBR] space: Black Star ball " + star + " placed on " + id + " at " + x + " " + y + " " + z);
        };
        RPG.schedule(40, tryPlace);
    }
    if (typeof DB_SETS !== "undefined" && DB_SETS.super) DB_SETS.super.dim = SURFACE;
    if (typeof DB_SETS !== "undefined" && DB_SETS.blackstar) {
        DB_SETS.blackstar.dim = SURFACE;
        DB_SETS.blackstar.natural = false;
        DB_SETS.blackstar.summonDims = [SURFACE];
    }

    // ---- Destroyer Gods on the Super bodies (SuperPlanetGod / SuperPlanetGodRoster) ----
    var GODS = [["beerus", "saga_beerus", "Beerus"], ["champa", "saga_u6_champa", "Champa"], ["godbelmod", "saga_god_belmod", "Belmod"], ["godsidra", "saga_god_sidra", "Sidra"],
                ["godheles", "saga_god_heles", "Heles"], ["godquitela", "saga_god_quitela", "Quitela"], ["godrumsshi", "saga_god_rumsshi", "Rumsshi"], ["godmosco", "saga_god_mosco", "Mosco"]];
    GODS.forEach((g) => {
        var r = typeof RG_NPC_INDEX !== "undefined" ? RG_NPC_INDEX[g[1]] : null;
        if (!r) return;
        RPG.mobs.define("dbr_destroyer_" + g[0], {
            name: "&5" + g[2] + ", God of Destruction",
            geo: dmzSagaStates({ model: "dbr:geo/entity/rgnpc/" + r[1] + ".geo.json", texture: "dbr:textures/entity/rgnpc/" + r[2] + ".png",
                   animation: DMZ_ANIM + "sagas/saga_base.animation.json", idle: "idle", walk: "walk", attack: "attack1_1", scale: 1.0 }),
            width: r[3], height: r[4], health: 6000, damage: 120, armor: 20, speed: 0.32, followRange: 48, xp: 20000, hostile: true, persistent: true,
            onDeath(mob, killer) {
                try {
                    var star = 0;
                    for (var k = 1; k <= 7; k++) if (mob.hasTag("dbr_super_" + k)) star = k;
                    if (!star) return;
                    RPG.server.setData("dbr_super_ball_" + star, 1);
                    RPG.server.setData("dbr_super_god_" + star, "");
                    // the ball on the ground under where the god fell (it may have died in the air or over a hole)
                    var dim = String(mob.dimension), bx = Math.floor(mob.x), bz = Math.floor(mob.z), by = Math.floor(mob.y);
                    var sy = RPG.world.isLoaded(dim, bx, bz) ? RPG.world.surfaceY(dim, bx, bz) : -9999;
                    if (sy > -9999) by = sy;
                    if (typeof dbrPlaceDragonBall === "function") {
                        try { dbrPlaceDragonBall("super", star, dim, bx, by, bz); }
                        catch (e2) { RPG.log("[DBR] space: placing Super ball " + star + " failed: " + e2); }
                    }
                    RPG.server.players().forEach((q) => { if (q.dimension === SURFACE) { q.title("&e" + star + "-Star Super Dragon Ball", "&7The God of Destruction has fallen."); sendState(q); } });
                } catch (err) { RPG.log("[DBR] space: Destroyer God death: " + err); }
            }
        });
    });
    function guardian(p, id, c) {
        if (id.indexOf("susuper:") !== 0) return;
        var star = Number(id.substring(8));
        if (!star || RPG.server.getData("dbr_super_ball_" + star, 0)) return;
        var uuid = String(RPG.server.getData("dbr_super_god_" + star, "") || "");
        var god = uuid ? RPG.world.entityByUuid(uuid) : null;
        if (god && god.alive) return;
        if (uuid && !god && !RPG.world.isLoaded(SURFACE, Math.floor(c.x), Math.floor(c.z))) return;
        var g = GODS[(star - 1) % GODS.length], gx = c.x + 24, gz = c.z + 6;
        var y = RPG.world.surfaceY(SURFACE, Math.floor(gx), Math.floor(gz));
        if (y <= -9999) return;
        var m = RPG.world.spawnMob(SURFACE, "dbr_destroyer_" + g[0], gx, y + 0.5, gz);
        if (!m) return;
        m.addTag("dbr_super_" + star);
        RPG.server.setData("dbr_super_god_" + star, m.uuid);
        p.title("&5" + g[2], "&7guards the " + star + "-Star Super Dragon Ball");
    }

    // ---- garrisons and conquest (PlanetGarrison / PlanetConquest / GeneratedPlanetClaims) ----
    var DEFENDERS = { overworld: ["red_ribbon_soldier", "bandit"], namek: ["frieza_soldier", "frieza_soldier_heavy", "frieza_soldier_elite"],
        kaio: ["namek_warrior"], stony: ["saibaman", "saibaman_2", "saibaman_3"], nether: ["saibaman_4", "saibaman_5"], end: ["saibaman_6", "frieza_soldier_elite"] };
    function claimOf(id) { return String(RPG.server.getData("dbr_claim_" + id, "") || ""); }
    function garrison(p, id, c) {
        if (id.indexOf("sugen:") !== 0 || claimOf(id)) return;
        var raw = String(RPG.server.getData("dbr_garrison_" + id, "") || "");
        if (!raw) {
            if (RPG.server.getTick() < Number(RPG.server.getData("dbr_garrison_wait_" + id, 0))) return;
            if (!RPG.world.isLoaded(SURFACE, Math.floor(c.x), Math.floor(c.z))) return;
            var list = DEFENDERS[B.themeFor(id).id] || DEFENDERS.stony, size = B.surfaceSize(id), n = 3 + Math.floor(size / 120), ids = [];
            var rnd = dmzRng(O.javaHash(id + "#garrison") + RPG.server.getTick(), 0);
            for (var i = 0; i < n; i++) {
                var a = rnd() * Math.PI * 2, d = 18 + rnd() * 30, x = c.x + Math.cos(a) * d, z = c.z + Math.sin(a) * d;
                var y = RPG.world.surfaceY(SURFACE, Math.floor(x), Math.floor(z));
                if (y <= -9999) continue;
                var m = RPG.world.spawnMob(SURFACE, list[Math.floor(rnd() * list.length)], x, y + 0.5, z);
                if (m) { m.addTag("dbr_garrison"); m.addTag("dbr_g_" + id.substring(6)); ids.push(m.uuid); }
            }
            if (!ids.length) return;
            RPG.server.setData("dbr_garrison_" + id, ids.join(","));
            RPG.server.setData("dbr_garrison_kills_" + id, 0);
            p.title("&cGarrison", "&7Defeat the " + ids.length + " defenders to claim this planet.");
            return;
        }
        var all = raw.split(","), alive = all.filter((u) => { var e = RPG.world.entityByUuid(u); return e && e.alive; });
        if (alive.length) return;
        if (Number(RPG.server.getData("dbr_garrison_kills_" + id, 0)) >= all.length) {
            RPG.server.setData("dbr_claim_" + id, p.name);
            RPG.server.players().forEach((q) => { if (String(q.getVar("dbr_surface", "")) === id) q.title("&6Planet conquered", "&7" + p.name + " claims " + nameOf(B.find(id, now()))); });
        } else {
            // the defenders left without a fight (peaceful, unloaded): a new garrison in a minute
            RPG.server.setData("dbr_garrison_" + id, "");
            RPG.server.setData("dbr_garrison_wait_" + id, RPG.server.getTick() + 1200);
        }
    }
    RPG.on("kill", (player, victim) => {
        if (!player || !victim || !victim.hasTag("dbr_garrison")) return;
        var id = String(player.getVar("dbr_surface", "") || "");
        if (!id || !victim.hasTag("dbr_g_" + id.substring(6))) return;
        RPG.server.setData("dbr_garrison_kills_" + id, Number(RPG.server.getData("dbr_garrison_kills_" + id, 0)) + 1);
    });

    // ---- planet destruction (PlanetDestruction.apply): the one entry point (the planet buster, Apophis, the command) ----
    // A system sun takes its whole system with it; a moon's slot heals after planetDebrisSeconds (DMZR's debris timer:
    // the moon forms again with fresh ground); a generated planet is gone for good (DMZR: system planets leave no rubble
    // and never re-form). Main planets are permanent.
    function destructible(id) { id = String(id || ""); return id.indexOf("sugen:") === 0 || id.indexOf("sumoon:") === 0 || id.indexOf("sustar:") === 0 || id.indexOf("susuper:") === 0; }
    function destroy(id, credit, quiet) {
        id = String(id || "");
        if (!destructible(id)) { RPG.log("[DBR] space: can't destroy " + id + " (main planets are permanent)"); return false; }
        var list = destroyedList();
        if (list.indexOf(id) >= 0) return false;
        var b = id.indexOf("sustar:") === 0 ? null : B.find(id, now());
        var label = b ? nameOf(b) : (id.indexOf("sustar:") === 0 ? "Sun " + id.substring(7, 11).toUpperCase() : id);
        // the owner before the unclaim below forgets it: a claimed world's loss is partly recovered (PlanetSalvage)
        var owner = claimOf(id);
        list.push(id);
        RPG.server.setData("dbr_destroyed", list.join(","));
        RPG.server.setData("dbr_destroyed_at_" + id, RPG.world.gameTime("minecraft:overworld"));
        B.setDestroyed(list);
        if (id.indexOf("sustar:") === 0) {
            // a system sun: every planet of its system goes with it, each through the ordinary destroy
            var sys = G.findSystem(id);
            if (sys) sys.planets.forEach((pl) => { try { destroy(pl.id, null, true); } catch (err) { RPG.log("[DBR] space: " + err); } });
        } else {
            RPG.server.setData("dbr_claim_" + id, "");
            // everyone standing on it dies with it (DMZR "was destroyed along with their planet"); a survivor is put home
            RPG.server.players().forEach((q) => {
                if (q.dimension !== SURFACE || String(q.getVar("dbr_surface", "")) !== id) return;
                q.title("&4" + label + " is destroyed!", "");
                RPG.server.broadcast("&7" + q.name + " was destroyed along with their planet");
                try { q.damageFrom(1e9, null, { kind: "planet_destroyed", ignoreIFrames: true }); } catch (e) { q.damage(1e9); }
                if (q.alive) q.setHealth(0);
                q.setVar("dbr_surface", ""); q.setVar("dbr_surface_cell", "");
                if (q.alive) {
                    var sp = RPG.world.spawnPoint();
                    q.teleportTo("minecraft:overworld", Number(sp.x) + 0.5, Number(sp.y) + 1, Number(sp.z) + 0.5);
                }
            });
            if (owner && typeof DBR_SPACE_SALVAGE !== "undefined") DBR_SPACE_SALVAGE.capture(id, owner);
            RPG.server.setData("dbr_stamp_" + id, 0);                      // a moon that re-forms is stamped fresh
            // the wild garrison goes too (no defender left floating over a dead world)
            String(RPG.server.getData("dbr_garrison_" + id, "") || "").split(",").forEach((u) => { var e = u ? RPG.world.entityByUuid(u) : null; if (e && e.alive) e.kill(); });
            RPG.server.setData("dbr_garrison_" + id, "");
        }
        // no course may point at rubble
        RPG.server.players().forEach((q) => { if (autopilot(q) === id) { q.setVar("dbr_space_autopilot", ""); msg(q, "&7Autopilot off: " + label + " is gone."); } });
        // blowing up a world is an evil act: the credited destroyer's alignment drops (PlanetBuster alignmentPenalty)
        var pen = typeof DBR_BUSTER_CFG !== "undefined" ? DBR_BUSTER_CFG.get("alignmentPenalty") : 10;
        if (credit && pen > 0 && !quiet) {
            var a = Number(credit.getVar("dmz_alignment", 100));
            credit.setVar("dmz_alignment", Math.max(0, Math.min(100, (isNaN(a) ? 100 : a) - pen)));
            msg(credit, "&cDestroying a world is an evil act. Your alignment dropped by " + pen + ".");
        }
        RPG.server.players().forEach((q) => sendState(q));
        RPG.log("[DBR] space: destroyed " + id + (credit ? " (by " + credit.name + ")" : ""));
        return true;
    }
    /** Admin restore (PlanetDestruction.restore): the same body comes back. */
    function restore(id) {
        var list = destroyedList(), i = list.indexOf(id);
        if (i < 0) return false;
        list.splice(i, 1);
        RPG.server.setData("dbr_destroyed", list.join(","));
        B.setDestroyed(list);
        RPG.server.players().forEach((q) => sendState(q));
        return true;
    }
    // the debris timer (PlanetSpawnModule.sweepDebris, every 30 s): a destroyed moon's slot re-forms after the window
    RPG.every(600, () => {
        var secs = typeof DBR_BUSTER_CFG !== "undefined" ? DBR_BUSTER_CFG.get("planetDebrisSeconds") : 604800, t = RPG.world.gameTime("minecraft:overworld");
        destroyedList().forEach((id) => {
            if (id.indexOf("sumoon:") !== 0) return;
            var at = Number(RPG.server.getData("dbr_destroyed_at_" + id, 0)) || 0;
            if (t - at >= secs * 20) { restore(id); RPG.log("[DBR] space: " + id + " has re-formed from its debris"); }
        });
    });
    function planetAt(dim, x, z) {
        if (dim !== SURFACE || x === undefined) return "";
        return String(RPG.server.getData("dbr_cell_" + Math.round(Number(x) / 65536) + "_" + Math.round(Number(z) / 65536), "") || "");
    }

    return { on: on, destroy: destroy, restore: restore, destructible: destructible, destroyedList: destroyedList, sendState: sendState, stamped: stamped, planetAt: planetAt, claimOf: claimOf, startAutopilot: startAutopilot, name: nameOf, enterSpace: enterSpace, land: land, stamp: stamp, toSpaceBeside: toSpaceBeside };
})();

function dbrSpaceAvailable() { return DBR_SPACE.on(); }
/**
 * Destroys a generated planet, moon or Super body (dragon balls: Apophis' timer). (dim, x, z) names the spot (a
 * surface square of ragnarok_rpg:planet_surface); a planet id ("sugen:...") works as dim too. Main planets survive.
 */
function dbrDestroyPlanet(dim, x, z) {
    var id = String(dim || "").indexOf(":") > 0 && String(dim).indexOf("ragnarok_rpg:") !== 0 && String(dim).indexOf("minecraft:") !== 0 ? String(dim) : DBR_SPACE.planetAt(dim, x, z);
    if (!id) { RPG.log("[DBR] space: dbrDestroyPlanet(" + dim + ") - no planet there (pass x, z on the planet surface)"); return false; }
    return DBR_SPACE.destroy(id);
}
function dbrSpaceAutopilot(p, dim) { return DBR_SPACE.startAutopilot(p, dim); }

// /rpgc space: enter space from where you stand (ops: testing; DMZR /space)
RPG.commands.register("space", {
    permission: 2, description: "/rpgc space [planet|moon|pod|<id>] - go to space beside this planet, or land on a body (testing)",
    run(p, args) {
        if (!p) return;
        if (!DBR_SPACE.on()) { p.sendMessage("&cThe space dimension isn't loaded: restart the world once."); return; }
        if (args && args[0] === "auto" && args[1]) { p.sendMessage(DBR_SPACE.startAutopilot(p, args[1]) ? "&aAutopilot on" : "&cCan't"); return; }
        if (args && args[0] === "pod") {
            // a space pod under you, ridden (testing)
            var v = RPG.world.spawnVehicle(p.dimension, "spacepod", p.x, p.y, p.z, p.yaw);
            if (v) { DBR_POD_ARRIVING[p.uuid] = true; p.mount(v); }
            return;
        }
        if (args && args[0]) {
            var b = null;
            if (args[0] === "planet" || args[0] === "moon") {
                // the nearest generated planet (or main-planet moon) to you: testing
                var best = 1e18;
                DBR_SPACE_BODIES.near(p, 20000, Date.now()).forEach((e) => {
                    if (e.kind !== args[0]) return;
                    var dx = e.pos.x - p.x, dz = e.pos.z - p.z, d = dx * dx + dz * dz;
                    if (d < best) { best = d; b = e; }
                });
                if (b) p.sendMessage("&7" + b.id);
            } else b = DBR_SPACE_BODIES.find(args[0], Date.now());
            if (!b) { p.sendMessage("&cNo body " + args[0]); return; }
            DBR_SPACE.land(p, b);
            return;
        }
        var fb = DBR_SPACE_ORBITS.byDim(p.dimension);
        if (fb) { DBR_SPACE.enterSpace(p, fb); return; }
        var s = String(p.getVar("dbr_surface", "") || "");
        if (p.dimension === DBR_SPACE_BODIES.SURFACE && s) { DBR_SPACE.toSpaceBeside(p, DBR_SPACE_BODIES.find(s, Date.now()), true); return; }
        p.sendMessage("&cYou're not on a planet.");
    }
});
