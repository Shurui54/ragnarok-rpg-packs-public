// =====================================================================================
//  57_dragon_balls.js - DMZ's Dragon Balls (DragonBallsHandler, DragonBallBlock, DefaultWishes)
// =====================================================================================
//  Three sets of placeable balls: Earth (7, overworld, Shenron, 1 wish), Namek (7, Namek,
//  Porunga, 3 wishes) and Demon Realm (3, dropped by the Tamagami bosses, Porunga Daima,
//  3 wishes). Earth and Namek balls are scattered within 1000 blocks of spawn and tracked;
//  radars show them. Put every ball of a set within 5 blocks and right-click one to summon
//  the dragon; right-click the dragon to choose your wishes. Then the balls scatter again.
//
//  DMZ Ragnarok's three sets (SuDragonBallDefinitions, GPL-3.0) are here too:
//   Super (7, Super Shenron, 1 wish, summon radius 16): the 4x balls. In DMZ Ragnarok each one is
//     dropped by the Destroyer God guarding a Super Dragon Ball body in space; never scattered.
//   Black Star (7, Apophis, 1 wish): one ball on each of seven random generated planets. Apophis
//     can only be summoned on a generated planet, and arms a one-week timer: gather all seven
//     again in time or that planet is destroyed.
//   Cerulean (2, Cerulean Shenron, 1 wish): scatters only on Planet Cereal (not built yet, so
//     like in DMZ Ragnarok it doesn't scatter at all for now).
//  TODO (space): generated planets, Super bodies and Planet Cereal aren't in DBR yet. The hooks are
//  DB_SETS.<set>.dim / .summonDims, dbrPlaceDragonBall(setId, star, dim, x, y, z) (a Destroyer
//  God's drop, or a ball onto a planet) and dbrDestroyPlanet(dim) (Apophis' timer runs out).
//
//  Dormancy (DMZ Ragnarok BallDormancy / BallDormancyEvents / MixinDmzRadarDormant, GPL-3.0): summoning a
//  dragon spends its set, which then turns to stone for one Minecraft week of game time (7 x 24000 ticks of
//  the overworld's game time, so /time set and server downtime don't count), or one real day (wall clock) for
//  the Super set. The balls still scatter as usual, as stone: they can be picked up, carried and placed, but
//  can't summon a dragon, and radars don't show them (a radar's right-click tells how long is left). When the
//  timer runs out every player is told and the balls come back to life wherever they are. Stone balls are
//  their own blocks (<ball>_stone: the same faceted shape with the stone texture, no glass, stars or rim),
//  swapped in and out as the set falls dormant and wakes. Ops: /rpgc dragonballs <set> awaken | dormant.
// =====================================================================================
var DB_SETS = {
    earth: { stars: 7, dim: "minecraft:overworld", dragon: "shenron", wishes: 1, natural: true, block: (n) => "dball" + n,
             name: (n) => n + "-Star Dragon Ball", color: "&6" },
    namek: { stars: 7, dim: "ragnarok_rpg:namek", dragon: "porunga", wishes: 3, natural: true, block: (n) => "dball" + n + "_namek",
             name: (n) => n + "-Star Namekian Dragon Ball", color: "&a" },
    demon: { stars: 3, dim: "ragnarok_rpg:demon_realm", dragon: "porunga_daima", wishes: 3, natural: false, block: (n) => "dball" + n + "_demon",
             name: (n) => n + "-Star Demon Realm Dragon Ball", color: "&5" },
    // TODO (space): DMZ Ragnarok keeps these balls on the Super Dragon Ball bodies (planet_surface). Space is the
    // closest DBR has; the balls only appear through dbrPlaceDragonBall("super", ...) or /rpgc dragonballs super give.
    super: { stars: 7, dim: "ragnarok_rpg:space", dragon: "super_shenron", wishes: 1, natural: false, summonRadius: 16,
             block: (n) => "dball" + n + "_super", name: (n) => n + "-Star Super Dragon Ball", color: "&e", icon: "dbr:rpg/item/",
             minSpacing: 3 },
    // TODO (space): DMZ Ragnarok puts one ball on each of seven random generated planets (within 45000 blocks of Earth)
    // and lets Apophis appear only there. Until generated planets exist the set scatters on the Sacred Kai Planet,
    // the closest existing world, and summonDims follows dim.
    blackstar: { stars: 7, dim: "ragnarok_rpg:sacredkaiplanet", dragon: "apophis", wishes: 1, natural: true, range: 3000,
                 summonDims: null, block: (n) => "dball" + n + "_blackstar", name: (n) => n + "-Star Black Star Dragon Ball",
                 color: "&8", icon: "dbr:rpg/item/" },
    // DMZ Ragnarok: Planet Cereal only (dmz_ragnarok:planet_cereal); while that world doesn't exist the set never scatters.
    cerulean: { stars: 2, dim: "ragnarok_rpg:planet_cereal", dragon: "cerulean_shenron", wishes: 1, natural: true, range: 3000,
                block: (n) => "dball" + n + "_cerulean", name: (n) => n + "-Star Cerulean Dragon Ball", color: "&b", icon: "dbr:rpg/item/" }
};
DB_SETS.blackstar.summonDims = [DB_SETS.blackstar.dim];
var dbrPlaceDragonBall = null;     // set below: dbrPlaceDragonBall(setId, star, dim, x, y, z)
var DB_CFG = { spawnRange: 1000, summonRadius: 5, dragonWaitTicks: 12000, despawnDelay: 100, fadeTicks: 50 };
// BallDormancy: WEEK_TICKS on the overworld's game time; SUPER_WALL_MILLIS on the real clock for WALL_CLOCK_SET
var DB_DORMANCY = { weekTicks: 7 * 24000, wallMillis: 24 * 3600 * 1000, wallSets: { super: true } };
var DB_SET_TITLES = { earth: "Earth", namek: "Namek", demon: "Demon Realm", super: "Super", blackstar: "Black Star", cerulean: "Cerulean" };
var dbrBallsDormant = null;        // set below: dbrBallsDormant(setId) -> true while the set is stone

// ---- wishes (DefaultWishes.java; names/descriptions are DMZ's lang keys) ----------------
var DB_WISHES = {
    shenron: [
        { key: "senzu", items: [["senzu_bean", 16]] },
        { key: "attributes", attributes: 100 },
        { key: "powerpole", items: [["power_pole", 1]] },
        { key: "mightfruit", items: [["might_tree_fruit", 16]] },
        { key: "namekcpu", items: [["t2_radar_cpu", 4]] },
        { key: "saiyanship", items: [["saiyan_ship", 1]] },
        { key: "racialskillreset", passiveReset: true },
        { key: "customization", recustomize: true },
        { key: "changedifficulty", changeDifficulty: true },
        { key: "resetstory", resetStory: true },
        { key: "revive", revive: 3 },
        { key: "materials", items: [["kikono_shard", 32], ["minecraft:iron_ingot", 64]] },
        { key: "strongest", items: [["strongest_armor_chestplate", 1], ["strongest_armor_leggings", 1], ["strongest_armor_boots", 1]] }
    ],
    porunga: [
        { key: "senzu", items: [["senzu_bean", 32]] },
        { key: "attributes", attributes: 75 },
        { key: "bravesword", items: [["brave_sword", 1]] },
        { key: "frieza_capsule", items: [["frieza_capsule", 1]] },
        { key: "racialskillreset", passiveReset: true },
        { key: "customization", recustomize: true },
        { key: "relocatestats", relocate: true },
        { key: "changedifficulty", changeDifficulty: true },
        { key: "resetstory", resetStory: true },
        { key: "revive", revive: 1, repeatable: true },
        { key: "materials", items: [["kikono_shard", 64], ["minecraft:iron_ingot", 128]] },
        { key: "invincible", items: [["invencible_armor_helmet", 1], ["invencible_armor_chestplate", 1], ["invencible_armor_leggings", 1], ["invencible_armor_boots", 1]] },
        { key: "invincible_blue", items: [["invencible_blue_armor_helmet", 1], ["invencible_blue_armor_chestplate", 1], ["invencible_blue_armor_leggings", 1], ["invencible_blue_armor_boots", 1]] },
        { key: "pothala_yellow", items: [["pothala_pair", 1]] },
        { key: "pothala_green", items: [["green_pothala_pair", 1]] }
    ]
};
DB_WISHES.porunga_daima = DB_WISHES.porunga;
// DMZ Ragnarok's dragons (SuDragonBallDefinitions.wishesFor, SuperWishes). lang = the wish's lang key prefix.
DB_WISHES.apophis = [
    { key: "tps", lang: "wish.apophis.tps", tp: 5000 },
    { key: "senzu", lang: "wish.apophis.senzu", items: [["senzu_bean", 16]] }
];
DB_WISHES.super_shenron = [
    { key: "tps", lang: "wish.super_shenron.tps", tp: 20000 },
    { key: "senzu", lang: "wish.super_shenron.senzu", items: [["senzu_bean", 16]] },
    { key: "release", lang: "wish.dmz_ragnarok.release", releaseBoost: 25 },      // ReleaseBoostStore: +25, at most +100
    { key: "relocate", lang: "wish.dmz_ragnarok.relocate", relocate: true, say: true },
    { key: "zeni", lang: "wish.dmz_ragnarok.zeni", money: 1000000 },
    { key: "superpower", lang: "wish.dmz_ragnarok.superpower", superPower: true }  // last: hidden once used up
];
DB_WISHES.cerulean_shenron = [
    { key: "tps", lang: "wish.cerulean_shenron.tps", tp: 20000 },
    { key: "senzu", lang: "wish.cerulean_shenron.senzu", items: [["senzu_bean", 16]] }
];
var DB_RELEASE_BOOST = { perWish: 25, max: 100, varName: "dmzr_release_boost" };
var DB_SUPERPOWER = { tp: 100000000, statShare: 0.25, maxUses: 3, varName: "dmzr_superpower_wishes" };

(function () {
    // ---- the ball blocks (DragonBallBlock: small, on the ground, amethyst sounds) ----
    // (Rhino shares one variable across loop passes, so each ball gets its own function call)
    function defineBall(setId, set, n) {
            let id = set.block(n);
            RPG.blocks.define(id, {
                name: (set.color || "&6") + set.name(n),
                model: "dbr:rpg/block/" + id,
                itemModel: (set.icon || DMZ + "rpg/item/") + id,  // the flat icon in the inventory (DMZ's, or DMZ Ragnarok's)
                decor: true, hardness: 0.5, light: 4,
                // DMZ Ragnarok's see-through glass balls (models from convert_dragon_balls.py); Demon Realm balls use
                // the Namek ball's size.
                shape: ballShape(setId),
                onUse(p, x, y, z) { trySummon(p, setId, x, y, z); },
                onPlace(p, x, y, z) { ballPlaced(setId, n, p.dimension, x, y, z, p); },
                onBreak(p, x, y, z) { ballTaken(setId, n, p.dimension, x, y, z); }
            });
            // the dormant twin (DormantBallRender): the same shape in stone; its item is the stone ball itself
            RPG.blocks.define(id + "_stone", {
                name: "&7" + set.name(n) + " (Dormant)",
                model: "dbr:rpg/block/" + id + "_stone",
                decor: true, hardness: 0.5, renderType: "solid",
                shape: ballShape(setId),
                onUse(p) { p.actionbar("&7These dragon balls are dormant. They have turned to stone and cannot be used until they wake."); },
                onPlace(p, x, y, z) { ballPlaced(setId, n, p.dimension, x, y, z, p); },
                onBreak(p, x, y, z) { ballTaken(setId, n, p.dimension, x, y, z); }
            });
    }
    // DMZ Ragnarok's sizes: Earth / Black Star (dball geo), Namek / Demon (dballnamek), Cerulean (half), and the Super
    // ball's near-sphere (SuperDragonBallCollision: semi-axes 1.4375 / 1.40625 blocks, centre 1.40625 up, cut at 2
    // blocks, in 0.2 block bands)
    function ballShape(setId) {
        if (setId === "earth" || setId === "blackstar") return [4, 0, 4, 12, 8, 12];
        if (setId === "cerulean") return [6, 0, 6, 10, 4, 10];
        if (setId !== "super") return [3, 0, 3, 13, 12, 13];
        let out = [], H = 1.4375, V = 1.40625, CY = 1.40625;
        for (let y0 = 0; y0 < 2 - 1e-9; y0 += 0.2) {
            let y1 = Math.min(y0 + 0.2, 2), t = ((y0 + y1) / 2 - CY) / V, hw = H * Math.sqrt(Math.max(0, 1 - t * t));
            out.push([(0.5 - hw) * 16, y0 * 16, (0.5 - hw) * 16, (0.5 + hw) * 16, y1 * 16, (0.5 + hw) * 16].map((v) => Math.round(v * 100) / 100));
        }
        return out;
    }
    Object.keys(DB_SETS).forEach((setId) => {
        for (let n = 1; n <= DB_SETS[setId].stars; n++) defineBall(setId, DB_SETS[setId], n);
    });
    function dimReady(dim) { try { return RPG.server.hasDimension(dim); } catch (e) { return true; } }
    // the live ball block, its stone twin, and the one the set should show right now
    function liveName(setId, n) { return DB_SETS[setId].block(n); }
    function stoneName(setId, n) { return DB_SETS[setId].block(n) + "_stone"; }
    function blockName(setId, n) { return isDormant(setId) ? stoneName(setId, n) : liveName(setId, n); }

    // ---- saved state: active balls (placed in the world), pending (waiting for their chunk) ----
    function state(setId) {
        let s = RPG.data.get("db_" + setId, null);
        if (!s || typeof s !== "object") s = { active: {}, pending: {}, first: false };
        if (!s.active) s.active = {};
        if (!s.pending) s.pending = {};
        return s;
    }
    function save(setId, s) { RPG.data.set("db_" + setId, s); RADAR_DIRTY = true; }
    var RADAR_DIRTY = true;

    function scatter(setId) {
        let set = DB_SETS[setId];
        if (!set.natural || !dimReady(set.dim)) return;
        let s = state(setId), sp = RPG.world.spawnPoint(), r = set.range || DB_CFG.spawnRange;
        for (let n = 1; n <= set.stars; n++) {
            if (s.active[n] || s.pending[n] || s.held && s.held[n]) continue;
            s.pending[n] = { x: Math.floor((sp.x || 0) + (Math.random() * 2 - 1) * r), z: Math.floor((sp.z || 0) + (Math.random() * 2 - 1) * r) };
        }
        s.first = true;
        save(setId, s);
    }

    var DB_SINK = /^minecraft:(water|air|cave_air|kelp|kelp_plant|seagrass|tall_seagrass|bubble_column)$/;

    // drop pending balls once their chunk is loaded (DMZ: maintain every 20 ticks)
    function maintain() {
        for (let setId in DB_SETS) {
            let set = DB_SETS[setId];
            if (!set.natural || !dimReady(set.dim)) continue;
            let s = state(setId), changed = false;
            if (!s.first) { scatter(setId); s = state(setId); }
            for (let n in s.pending) {
                let pnd = s.pending[n];
                if (!RPG.world.isLoaded(set.dim, pnd.x, pnd.z)) continue;
                let y = RPG.world.surfaceY(set.dim, pnd.x, pnd.z);
                if (y < -9000) continue;
                // the surface height counts water: sink through it (and kelp/seagrass) to the sea bed. Only ever going
                // down from the open surface keeps balls out of caves.
                let guard = 0;
                while (guard++ < 320 && DB_SINK.test(String(RPG.world.getBlock(set.dim, pnd.x, y - 1, pnd.z)))) y--;
                RPG.world.setBlock(set.dim, pnd.x, y, pnd.z, RPG.blocks.id(blockName(setId, Number(n))));
                s.active[n] = { x: pnd.x, y: y, z: pnd.z, dim: set.dim };
                delete s.pending[n];
                changed = true;
            }
            if (changed) save(setId, s);
        }
    }

    // a tracked ball missing from the world (and not carried) goes back to pending
    function validate() {
        for (let setId in DB_SETS) {
            let set = DB_SETS[setId], s = state(setId), changed = false;
            for (let n in s.active) {
                let a = s.active[n];
                if (!RPG.world.isLoaded(a.dim, a.x, a.z)) continue;
                let b = RPG.world.getBlock(a.dim, a.x, a.y, a.z), want = RPG.blocks.id(blockName(setId, Number(n)));
                let live = RPG.blocks.id(liveName(setId, Number(n))), stone = RPG.blocks.id(stoneName(setId, Number(n)));
                if (b === want) continue;
                // the other twin: the set fell dormant or woke while this chunk was away
                if (b === live || b === stone) { RPG.world.setBlock(a.dim, a.x, a.y, a.z, want); continue; }
                delete s.active[n];
                changed = true;
            }
            if (changed) { save(setId, s); scatter(setId); }
        }
    }

    function ballPlaced(setId, n, dim, x, y, z, p) {
        let set = DB_SETS[setId];
        // SuSuperBallPlacementHandler: no Super ball within (minSpacing - 1) blocks of another, so the 4x balls never overlap
        if (p && set.minSpacing > 1 && superTooClose(setId, dim, x, y, z, set.minSpacing - 1)) {
            RPG.world.setBlock(dim, x, y, z, "minecraft:air");
            p.giveItem(set.block(n), 1);
            p.tell("&cToo close to another Super Dragon Ball. Leave at least " + set.minSpacing + " blocks between them.");
            return;
        }
        // a live ball placed while its set sleeps turns to stone, a stone one placed after it woke comes alive
        let want = RPG.blocks.id(blockName(setId, n));
        if (RPG.world.getBlock(dim, x, y, z) !== want) RPG.world.setBlock(dim, x, y, z, want);
        let s = state(setId);
        s.active[n] = { x: x, y: y, z: z, dim: dim };
        delete s.pending[n];
        if (s.held) delete s.held[n];
        save(setId, s);
        if (gathered(setId, dim, x, y, z)) RPG.world.sound(dim, DMZ + "dragonballssound", x, y, z, 1, 1);
    }
    function superTooClose(setId, dim, x, y, z, r) {
        let set = DB_SETS[setId], ids = {};
        for (let k = 1; k <= set.stars; k++) { ids[RPG.blocks.id(liveName(setId, k))] = true; ids[RPG.blocks.id(stoneName(setId, k))] = true; }
        for (let dx = -r; dx <= r; dx++) for (let dy = -r; dy <= r; dy++) for (let dz = -r; dz <= r; dz++) {
            if ((dx || dy || dz) && ids[RPG.world.getBlock(dim, x + dx, y + dy, z + dz)]) return true;
        }
        return false;
    }
    function ballTaken(setId, n, dim, x, y, z) {
        if (setId === "blackstar") apophisFound(n);
        let s = state(setId);
        delete s.active[n];
        s.held = s.held || {};
        s.held[n] = true;                           // carried: the radar loses it until it's placed again
        save(setId, s);
    }

    // every star of the set within the summon radius (a cube, like DMZ)
    function findSet(setId, dim, x, y, z) {
        let set = DB_SETS[setId], r = set.summonRadius || DB_CFG.summonRadius, found = {};
        let ids = {};
        for (let n = 1; n <= set.stars; n++) ids[RPG.blocks.id(set.block(n))] = n;
        for (let dx = -r; dx <= r; dx++) for (let dy = -r; dy <= r; dy++) for (let dz = -r; dz <= r; dz++) {
            let b = RPG.world.getBlock(dim, x + dx, y + dy, z + dz), n = ids[b];
            if (n && !found[n]) found[n] = { x: x + dx, y: y + dy, z: z + dz };
        }
        let count = 0;
        for (let k in found) count++;
        return count === set.stars ? found : null;
    }
    function gathered(setId, dim, x, y, z) { return findSet(setId, dim, x, y, z) !== null; }

    // ---- summoning ----
    var SUMMONS = {};                                // dragon uuid -> { set, owner, expires, granted, entity }

    function trySummon(p, setId, x, y, z) {
        let set = DB_SETS[setId];
        // MixinDmzDragonBallBlock.su$gateDormantSummon: a dormant set grants no wish
        if (isDormant(setId)) { p.actionbar("&7These dragon balls are dormant. They have turned to stone and cannot be used until they wake."); return; }
        let found = findSet(setId, p.dimension, x, y, z);
        if (!found) return;
        // Black Star: Apophis appears only on a generated planet (MixinDmzDragonBallBlock.su$gateBlackStarSummon)
        if (set.summonDims && set.summonDims.indexOf(p.dimension) < 0) { p.actionbar("&cThe red dragon can only be summoned on a generated planet."); return; }
        for (let k in SUMMONS) if (SUMMONS[k].dim === p.dimension) { p.actionbar("&eThe Eternal Dragon is already here."); return; }
        for (let n in found) RPG.world.setBlock(p.dimension, found[n].x, found[n].y, found[n].z, "minecraft:air");
        let s = state(setId);
        for (let n = 1; n <= set.stars; n++) { delete s.active[n]; if (s.held) delete s.held[n]; }
        save(setId, s);
        RPG.world.lightning(p.dimension, x, y, z, true);
        let dragon = RPG.world.spawnMob(p.dimension, set.dragon, x + 0.5, y, z + 0.5);
        if (!dragon) { p.tell("&cThe dragon couldn't appear here."); return; }
        SUMMONS[dragon.uuid] = { set: setId, owner: p.uuid, ownerName: p.name, expires: RPG.server.getTick() + DB_CFG.dragonWaitTicks,
                                 granted: false, entity: dragon, dim: p.dimension, x: x, y: y, z: z };
        RPG.world.sound(p.dimension, DMZ + "shenron", x, y, z, 4, 1);
        markDormant(setId);                          // BallDormancyEvents.onDragonSummoned: the set is spent
        skyFor(p.dimension, true);
        if (setId === "blackstar") apophisArm(p.dimension, p.x, p.z);
        p.tell("&6Right-click the dragon to make your wish" + (set.wishes > 1 ? "es" : "") + ".");
    }

    function skyFor(dim, on) {
        RPG.server.players().forEach((pl) => { if (pl.dimension === dim) RPG.net.send(pl, "dmz_dragon_sky", { on: on ? 1 : 0 }); });
    }

    // right-click the dragon (owner only) -> the wish screen
    RPG.on("entityInteract", (p, e) => {
        if (!e) return;
        let s = SUMMONS[e.uuid];
        if (!s) return;
        if (s.owner !== p.uuid) { p.actionbar("&eOnly " + s.ownerName + " can make the wish."); return false; }
        if (s.granted) return false;
        let list = DB_WISHES[DB_SETS[s.set].dragon] || [];
        let dead = typeof dmzDeadPlayers === "function" ? dmzDeadPlayers().map((d) => ({ id: d.uuid, name: d.name })) : [];
        s.visible = visibleWishes(p, list);
        RPG.net.send(p, "dmz_wishes", {
            dragon: e.uuid, type: DB_SETS[s.set].dragon, count: DB_SETS[s.set].wishes, dead: dead,
            wishes: s.visible.map((i) => list[i]).map((w) => ({ key: w.key, lang: w.lang || null, repeatable: !!w.repeatable, targets: w.revive || 0 }))
        });
        return false;
    });

    RPG.net.on("dmz_grant", (p, d) => {
        let s = SUMMONS[d && d.dragon];
        if (!s || s.granted || s.owner !== p.uuid) return;
        let e = s.entity;
        if (!e || !e.isAlive() || Math.sqrt((p.x - e.x) * (p.x - e.x) + (p.z - e.z) * (p.z - e.z)) > 50) return;
        let set = DB_SETS[s.set], list = DB_WISHES[set.dragon] || [], vis = s.visible || visibleWishes(p, list);
        let picks = (d.picks || []).map((i) => Math.floor(Number(i))).filter((i) => i >= 0 && i < vis.length).map((i) => vis[i]);
        if (picks.length !== set.wishes) return;
        let seen = {};
        for (let i = 0; i < picks.length; i++) {
            let w = list[picks[i]];
            if (!w.repeatable && seen[picks[i]]) return;          // non-repeatable wishes once
            seen[picks[i]] = true;
        }
        s.granted = true;
        picks.forEach((i, k) => grant(p, list[i], (d.targets && d.targets[k]) || []));
        RPG.world.sound(s.dim, DMZ + "shenron", e.x, e.y, e.z, 3, 1.1);
        p.tell("&6&lYOUR WISH HAS BEEN GRANTED.");
        RPG.schedule(DB_CFG.despawnDelay, () => leave(e.uuid));
    });

    // the rows this player is offered (indices into the dragon's list): the Super power wish drops off once a character
    // has used its three (SuSsj5Wish.visibleTo)
    function visibleWishes(p, list) {
        let out = [];
        list.forEach((w, i) => {
            if (w.superPower && (Number(p.getVar(DB_SUPERPOWER.varName, 0)) || 0) >= DB_SUPERPOWER.maxUses) return;
            out.push(i);
        });
        return out;
    }

    function giveAll(p, items) {
        items.forEach((it) => {
            try { p.giveItem(it[0], it[1]); }
            catch (err) { p.tell("&c(" + it[0] + " isn't in this game yet)"); }
        });
    }

    function grant(p, w, targets) {
        let v = dmzView(p);
        if (w.items) giveAll(p, w.items);
        if (w.tp) p.addTp(w.tp, { raw: true, events: false, source: "script" });          // DMZ TPSWish
        if (w.money) {                                                                       // ZeniWishCommand
            p.addMoney(w.money);
            p.tell("&6Shenron showers you with " + w.money + " zeni. Your balance is now " + p.money + ".");
        }
        if (w.releaseBoost) {                                                                // ReleaseBoostCommand
            let have = Number(p.getVar(DB_RELEASE_BOOST.varName, 0)) || 0;
            if (have >= DB_RELEASE_BOOST.max) p.tell("&eYour power is already unbound to its very peak. Shenron can loosen the seal no further.");
            else {
                p.setVar(DB_RELEASE_BOOST.varName, Math.min(DB_RELEASE_BOOST.max, have + w.releaseBoost));
                p.tell("&6Shenron loosens the seal on your power. You may now release +" + w.releaseBoost + " beyond your old limit.");
            }
        }
        if (w.superPower) {                                                                  // SuperPowerWishCommand
            let used = Number(p.getVar(DB_SUPERPOWER.varName, 0)) || 0;
            if (used >= DB_SUPERPOWER.maxUses) p.tell("&eSuper Shenron will not grant this power again: a warrior may ask for it only " + DB_SUPERPOWER.maxUses + " times.");
            else {
                p.addTp(DB_SUPERPOWER.tp, { raw: true, events: false, source: "script" });
                DMZ_DATA.STATS.forEach((k) => {
                    let id = DMZ_DATA.STAT_IDS[k], add = Math.floor(p.allocated(id) * DB_SUPERPOWER.statShare);
                    if (add > 0) p.addStat(id, add);
                });
                p.refreshStats();
                p.setVar(DB_SUPERPOWER.varName, used + 1);
                p.tell("&6Super Shenron grants your wish. You gain " + DB_SUPERPOWER.tp + " training points and every stat rises by a quarter.");
                p.tell("&eSuper Shenron can grant you this power " + (DB_SUPERPOWER.maxUses - used - 1) + " more time(s) out of " + DB_SUPERPOWER.maxUses + ".");
            }
        }
        if (w.attributes) {
            // half as AP, half as the TP those attributes would cost right now
            let half = Math.floor(w.attributes / 2);
            p.setStatPoints(p.statPoints + half);
            p.addTp(DMZ_F.cost(DMZ_F.total(v), half, (DMZ_DATA.CLASSES[p.playerClass] || DMZ_DATA.CLASSES.warrior).tpCost), { raw: true, events: false, source: "script" });
        }
        if (w.passiveReset) {
            ["dmz_zenkai_release", "dmz_zenkai_count", "dmz_absorptions", "dmz_assimilations", "dmz_cell_jrs"].forEach((k) => p.setVar(k, 0));
        }
        if (w.recustomize) {
            p.setVar("dmz_recustomize", 1);                       // the creator keeps your race
            RPG.schedule(20, () => RPG.net.send(p, "dmz_open_creator", { recustomize: true, race: p.race }));
        }
        if (w.relocate) {
            let c = DMZ_DATA.CLASSES[p.playerClass] || DMZ_DATA.CLASSES.warrior, refund = 0;
            DMZ_DATA.STATS.forEach((k) => {
                let id = DMZ_DATA.STAT_IDS[k], have = p.allocated(id), base = c.base[k] || 0;
                if (have > base) { refund += have - base; p.addStat(id, base - have); }
            });
            p.setStatPoints(p.statPoints + Math.floor(refund));
            p.refreshStats();
            if (w.say) p.tell(refund > 0 ? "&6Shenron unwinds your training. " + Math.floor(refund) + " points return to you, yours to spend again."
                                         : "&eYou have nothing above your natural gifts for Shenron to give back.");
        }
        if (w.changeDifficulty) p.setVar("dmz_reselect_difficulty", 1);
        if (w.resetStory) {
            p.setVar("dmz_story_resets", (Number(p.getVar("dmz_story_resets", 0)) || 0) + 1);
            p.setVar("dmz_reset_story", 1);                       // the quest system wipes progress on its next check
            if (typeof dmzResetStory === "function") dmzResetStory(p);
        }
        if (w.revive) {
            (targets || []).slice(0, w.revive).forEach((uuid) => {
                let t = RPG.server.players().filter((x) => x.uuid === uuid)[0];
                if (t && typeof dmzRevive === "function" && (typeof dmzIsDead !== "function" || dmzIsDead(t))) dmzRevive(t);
            });
        }
    }

    // the dragon fades (end rod particles), the sky clears and the balls scatter
    function leave(uuid) {
        let s = SUMMONS[uuid];
        if (!s) return;
        let e = s.entity, steps = Math.floor(DB_CFG.fadeTicks / 5);
        for (let i = 0; i < steps; i++) RPG.schedule(i * 5, () => {
            if (e && e.isAlive()) RPG.world.particle(s.dim, "minecraft:end_rod", e.x, e.y + 6, e.z, 40, 3, 0.05);
        });
        RPG.schedule(DB_CFG.fadeTicks, () => {
            if (e && e.isAlive()) e.kill();
            delete SUMMONS[uuid];
            skyFor(s.dim, false);
            RPG.world.setWeather(s.dim, "clear", 6000);
            scatter(s.set);
        });
    }

    // ---- timers ----
    RPG.every(20, () => {
        maintain();
        let now = RPG.server.getTick();
        for (let k in SUMMONS) {
            let s = SUMMONS[k];
            if (!s.granted && (now > s.expires || !s.entity || !s.entity.isAlive())) { s.granted = true; leave(k); }
        }
    });
    RPG.every(200, validate);

    // ---- dormancy (BallDormancy / BallDormancyStorage): set -> { clock: "game" | "wall", until } ----
    var DORMANT = null;
    function dormantMap() {
        if (DORMANT === null) {
            let d = RPG.data.get("db_dormant", null);
            DORMANT = d && typeof d === "object" ? d : {};
        }
        return DORMANT;
    }
    function saveDormant() { RPG.data.set("db_dormant", DORMANT || {}); RADAR_DIRTY = true; }
    // the overworld's game time: only goes forward and doesn't count server downtime (BallDormancy.overworldGameTime)
    function gameNow() {
        try { return Number(RPG.world.gameTime("")) || 0; } catch (e) { return Number(RPG.world.getTime("")) || 0; }
    }
    function isDormant(setId) { return !!dormantMap()[setId]; }
    dbrBallsDormant = isDormant;
    // milliseconds until the set wakes, or -1 while it is active (game ticks at 50 ms)
    function remainingMs(setId) {
        let d = dormantMap()[setId];
        if (!d) return -1;
        return d.clock === "wall" ? Math.max(0, d.until - Date.now()) : Math.max(0, (d.until - gameNow()) * 50);
    }
    function hoursMinutes(ms) {
        let m = Math.max(1, Math.ceil(ms / 60000));
        return Math.floor(m / 60) + "h " + (m % 60) + "m";
    }
    function setNoun(setId) { return (DB_SET_TITLES[setId] || setId) + " dragon balls"; }
    function dormancyLine(setId) {
        let ms = remainingMs(setId);
        return ms < 0 ? "&b" + setNoun(setId) + " active" : "&6" + setNoun(setId) + " dormant: " + hoursMinutes(ms) + " left";
    }
    // markDormant: idempotent, a set already asleep keeps its deadline
    function markDormant(setId) {
        let d = dormantMap();
        if (d[setId] || !DB_SETS[setId]) return;
        d[setId] = DB_DORMANCY.wallSets[setId] ? { clock: "wall", until: Date.now() + DB_DORMANCY.wallMillis }
                                               : { clock: "game", until: gameNow() + DB_DORMANCY.weekTicks };
        saveDormant();
        RPG.log("[dragon balls] the " + setId + " set is dormant (" + hoursMinutes(remainingMs(setId)) + ")");
        refreshBalls(setId);
    }
    // forceWake / the scheduled wake; announce = the network-wide line and title (BallDormancy.announceWake)
    function wake(setId, announce) {
        let d = dormantMap();
        if (!d[setId]) return false;
        delete d[setId];
        saveDormant();
        refreshBalls(setId);
        if (announce) {
            let name = DB_SET_TITLES[setId] || setId;
            RPG.server.players().forEach((pl) => pl.title("&bDragon Balls Awoken", "&7The " + name + " set stirs back to life."));
            RPG.server.broadcast("&bThe " + name + " dragon balls have awoken from their slumber.");
        }
        RPG.log("[dragon balls] the " + setId + " set woke");
        return true;
    }
    // swap the set's placed balls to the right twin where their chunks are loaded (validate() does the rest later)
    // and the balls players carry
    function refreshBalls(setId) {
        let s = state(setId);
        for (let n in s.active) {
            let a = s.active[n];
            if (!RPG.world.isLoaded(a.dim, a.x, a.z)) continue;
            let b = RPG.world.getBlock(a.dim, a.x, a.y, a.z), want = RPG.blocks.id(blockName(setId, Number(n)));
            if (b !== want && (b === RPG.blocks.id(liveName(setId, Number(n))) || b === RPG.blocks.id(stoneName(setId, Number(n)))))
                RPG.world.setBlock(a.dim, a.x, a.y, a.z, want);
        }
        RPG.server.players().forEach((pl) => refreshCarried(pl, setId));
    }
    function refreshCarried(pl, setId) {
        let set = DB_SETS[setId], sleep = isDormant(setId);
        for (let n = 1; n <= set.stars; n++) {
            let from = sleep ? liveName(setId, n) : stoneName(setId, n), to = sleep ? stoneName(setId, n) : liveName(setId, n);
            try {
                let c = pl.countItem(from);
                if (c > 0 && pl.takeItem(from, c)) pl.giveItem(to, c);
            } catch (e) { }
        }
    }
    // BallDormancyEvents.onServerTick: sweep for wakes every 100 ticks; carried balls caught up as players join
    RPG.every(100, () => {
        let d = dormantMap(), now = Date.now(), g = gameNow();
        Object.keys(d).forEach((setId) => {
            let r = d[setId];
            if (!DB_SETS[setId]) { delete d[setId]; saveDormant(); return; }
            // BallDormancy.sanitize: a deadline further away than a fresh mark could set came from another clock
            if (r.clock !== "wall" && r.until > g + DB_DORMANCY.weekTicks) r.until = g + DB_DORMANCY.weekTicks;
            if (r.clock === "wall" ? now >= r.until : g >= r.until) wake(setId, true);
        });
    });
    RPG.on("playerJoin", (p) => RPG.schedule(60, () => { Object.keys(DB_SETS).forEach((setId) => refreshCarried(p, setId)); }));

    // ---- Black Star: Apophis' planet timer (ApophisSummonModule) ----
    // Summoning Apophis arms a one-week (real time) countdown on the planet it was summoned on; collecting all seven
    // Black Star balls again (breaking each placed ball) spares it, otherwise the planet is destroyed. Warnings go out
    // at 3 days, 1 day, 6 h, 1 h and 10 min left.
    var APOPHIS_WEEK = 7 * 24 * 3600 * 1000, APOPHIS_WARN = [3 * 86400000, 86400000, 6 * 3600000, 3600000, 600000];
    function apophisState() {
        let a = RPG.data.get("db_apophis", null);
        return a && typeof a === "object" ? a : { armed: false };
    }
    function planetName(dim) {
        let id = String(dim || "").replace(/^.*:/, "").replace(/_/g, " ");
        return id.replace(/\b\w/g, (c) => c.toUpperCase());
    }
    function apophisArm(dim, x, z) {
        // TODO (space): DMZ Ragnarok arms the generated planet the summoner stands on; here it is the summon dimension
        RPG.data.set("db_apophis", { armed: true, planet: dim, x: Math.floor(x || 0), z: Math.floor(z || 0), deadline: Date.now() + APOPHIS_WEEK, warn: 0, found: {} });
        RPG.server.broadcast("&4The Black Star Dragon was summoned on " + planetName(dim) + ". If all seven Black Star Balls are not gathered within one week, the planet will be destroyed.");
    }
    function apophisFound(n) {
        let a = apophisState();
        if (!a.armed) return;
        a.found = a.found || {};
        a.found[n] = true;
        let all = true;
        for (let k = 1; k <= DB_SETS.blackstar.stars; k++) if (!a.found[k]) all = false;
        if (all) { RPG.server.broadcast("&aAll seven Black Star Balls were found. " + planetName(a.planet) + " is safe."); a = { armed: false }; }
        RPG.data.set("db_apophis", a);
    }
    function apophisSweep() {
        let a = apophisState();
        if (!a.armed) return;
        let left = a.deadline - Date.now();
        if (left <= 0) {
            RPG.data.set("db_apophis", { armed: false });
            if (typeof dbrDestroyPlanet === "function") {
                dbrDestroyPlanet(a.planet, a.x, a.z);   // which generated planet: the surface position where Apophis was summoned
                RPG.server.broadcast("&4The Black Star Balls were not gathered in time. " + planetName(a.planet) + " has been destroyed.");
            } else RPG.log("[dragon balls] Apophis' timer ran out on " + a.planet + " (TODO: no dbrDestroyPlanet yet, nothing destroyed)");
            return;
        }
        let stage = a.warn || 0, changed = false;
        while (stage < APOPHIS_WARN.length && left <= APOPHIS_WARN[stage]) {
            let ms = APOPHIS_WARN[stage], txt = ms >= 86400000 ? (ms / 86400000) + "d" : ms >= 3600000 ? (ms / 3600000) + "h" : (ms / 60000) + "m";
            RPG.server.broadcast("&c" + planetName(a.planet) + " will be destroyed in " + txt + " unless all seven Black Star Balls are found.");
            stage++; changed = true;
        }
        if (changed) { a.warn = stage; RPG.data.set("db_apophis", a); }
    }
    RPG.every(200, apophisSweep);

    // ---- hook for other scripts: put a ball of a set into the world (a Destroyer God's Super ball drop, a Black Star
    // ball onto a generated planet). Tracked like a placed ball, so radars and the rim see it.
    dbrPlaceDragonBall = function (setId, n, dim, x, y, z) {
        let set = DB_SETS[setId];
        if (!set || n < 1 || n > set.stars) return false;
        RPG.world.setBlock(dim, x, y, z, RPG.blocks.id(blockName(setId, n)));
        let s = state(setId);
        s.active[n] = { x: x, y: y, z: z, dim: dim };
        delete s.pending[n];
        if (s.held) delete s.held[n];
        save(setId, s);
        return true;
    };

    // ---- radar data (RadarSyncS2C every 100 ticks): every known position per set ----
    function radarPacket() {
        let out = { ids: {}, sets: {} };
        out.ids.dball_radar = RPG.items.id("dball_radar");
        out.ids.namekdball_radar = RPG.items.id("namekdball_radar");
        out.ids.fused_dball_radar = RPG.items.id("fused_dball_radar");
        out.ids.super_dball_radar = RPG.items.id("super_dball_radar");
        out.ids.blackstar_dball_radar = RPG.items.id("blackstar_dball_radar");
        out.ids.cerulean_dball_radar = RPG.items.id("cerulean_dball_radar");
        for (let setId in DB_SETS) {
            let s = state(setId), list = [], home = DB_SETS[setId].dim;
            out.sets[setId] = list;
            if (isDormant(setId)) continue;           // MixinDmzRadarDormant: stone balls are off every radar
            for (let n in s.active) list.push({ x: s.active[n].x, z: s.active[n].z, d: s.active[n].dim || home });
            for (let n in s.pending) list.push({ x: s.pending[n].x, z: s.pending[n].z, d: s.pending[n].dim || home });
        }
        return out;
    }
    RPG.every(100, () => {
        let pkt = radarPacket();
        RPG.server.players().forEach((p) => RPG.net.send(p, "dmz_radar", pkt));
        RADAR_DIRTY = false;
    });
    // ---- placed balls near each player, for the glowing rim (client/scripts/72_dball_rims.js) ----
    var RIM_SENT = {};
    RPG.every(40, () => {
        RPG.server.players().forEach((p) => {
            let list = [];
            for (let setId in DB_SETS) {
                let s = state(setId), stone = isDormant(setId) ? 1 : 0;
                for (let n in s.active) {
                    let a = s.active[n];
                    if ((a.dim || DB_SETS[setId].dim) !== p.dimension) continue;
                    if (Math.abs(a.x - p.x) > 96 || Math.abs(a.z - p.z) > 96) continue;
                    list.push([a.x, a.y, a.z, setId, Number(n), stone]);   // n: star count, for the billboarded stars; stone: dormant
                }
            }
            let key = JSON.stringify(list);
            if (RIM_SENT[p.uuid] === key) return;
            RIM_SENT[p.uuid] = key;
            RPG.net.send(p, "dbr_ball_rims", { list: list });
        });
    });
    RPG.on("playerJoin", (p) => RPG.schedule(40, () => {
        delete RIM_SENT[p.uuid];
        RPG.net.send(p, "dmz_radar", radarPacket());
        for (let k in SUMMONS) if (SUMMONS[k].dim === p.dimension) RPG.net.send(p, "dmz_dragon_sky", { on: 1 });
    }));

    // ---- radars (DragonRadarItem: right-click switches range 150/300, fused 150/300/600) ----
    // DMZ Ragnarok's radars (DragonRadarDefinition, ranges 150/300/600): Super and Black Star work everywhere, Cerulean
    // in the overworld only (as in DMZ Ragnarok); see client/scripts/58_dragon_balls.js
    // r[4]: the sets it reports on, for the dormancy line (RadarDormancyMessage)
    [["dball_radar", "&eDragon Radar", [150, 300], null, ["earth"]], ["namekdball_radar", "&aNamek Dragon Radar", [150, 300], null, ["namek"]],
     ["fused_dball_radar", "&bBi-Dimensional Radar", [150, 300, 600], null, ["earth", "namek"]],
     ["super_dball_radar", "&eSuper Radar", [150, 300, 600], "dbr:rpg/item/", ["super"]],
     ["blackstar_dball_radar", "&8Black Star Radar", [150, 300, 600], "dbr:rpg/item/", ["blackstar"]],
     ["cerulean_dball_radar", "&bCerulean Radar", [150, 300, 600], "dbr:rpg/item/", ["cerulean"]]].forEach((r) => {
        RPG.items.define(r[0], {
            name: r[1], model: (r[3] || DMZ + "rpg/item/") + r[0], type: "tool", rarity: "rare", maxStack: 1,
            lore: ["Hold it to see the Dragon Balls.", "Right-click to change the range."],
            onUse(p) {
                let ranges = r[2], cur = Number(p.getVar("dmz_radar_range", ranges[0])) || ranges[0];
                let next = ranges[(ranges.indexOf(cur) + 1) % ranges.length];
                p.setVar("dmz_radar_range", next);
                p.playSound(DMZ + "dragonradar", 0.6, 1);
                // RadarDormancyMessage: the range, then each set's state ("dormant: 3h 12m left" / "active")
                p.actionbar("&eRadar range: &f" + next + " blocks" + r[4].map((id) => "&7  |  " + dormancyLine(id)).join(""));
            }
        });
    });

    // ops: /rpgc dragonballs [set] - where the balls are; /rpgc dragonballs scatter <set>
    RPG.commands.register("dragonballs", {
        permission: 2, description: "/rpgc dragonballs [earth|namek|demon|super|blackstar|cerulean] [scatter|give|awaken|dormant] - Dragon Ball positions / rescatter / give a set / wake it / turn it to stone",
        run(p, args) {
            let setId = DB_SETS[args[0]] ? args[0] : "earth", s = state(setId);
            // BallSetCommands: /scatter and /gather wake the set first; /awaken wakes it; /unawaken turns it to stone
            if (args[1] === "scatter") { wake(setId, false); s = state(setId); s.active = {}; s.pending = {}; s.held = {}; save(setId, s); scatter(setId); p.tell("&aScattered the " + setId + " set."); return; }
            if (args[1] === "give") { wake(setId, false); for (let n = 1; n <= DB_SETS[setId].stars; n++) p.giveItem(DB_SETS[setId].block(n), 1); return; }
            if (args[1] === "awaken") { p.tell(wake(setId, false) ? "&aWoke the " + setId + " set." : "&eThe " + setId + " set was not dormant."); return; }
            if (args[1] === "dormant") { wake(setId, false); markDormant(setId); p.tell("&7Turned the " + setId + " set to stone (" + dormancyLine(setId) + "&7)."); return; }
            p.tell(dormancyLine(setId));
            for (let n = 1; n <= DB_SETS[setId].stars; n++) {
                let a = s.active[n], q = s.pending[n];
                p.tell("&e" + n + "★ &f" + (a ? "at " + a.x + " " + a.y + " " + a.z : q ? "waiting at " + q.x + " ~ " + q.z + " (chunk not loaded)" : s.held && s.held[n] ? "carried" : "?"));
            }
        }
    });
})();
