// =====================================================================================
//  87_dbr_space_buster.js - destroying planets (port of DMZ Ragnarok, GPL-3.0)
// =====================================================================================
//  PlanetBusterModule + PlanetClash + PlanetDestruction + PlanetSalvage:
//  - In space, charge a GIANT BALL ki attack (Spirit Bomb, Supernova...) and fire it at a
//    generated planet, moon or sun whose name is showing (within 300 blocks of its surface).
//    Too weak a blast (under minBlastKiDamage) fizzles. The ball flies to the target.
//  - The planet defends itself (PlanetClash): when the ball comes within max(50, 2 x radius) of
//    its centre the planet fires back and a BEAM CLASH starts - DragonMine Z's clash meter: right
//    click when the sweeping marker crosses the window. Your weight is a blend of the blast and
//    your battle power (0.15 x ki damage + battle power x 0.05); the planet's is its toughness
//    (wild 5000, a claimed world 5000 + 2000 per owner, at least 8000) x 0.05. Lose and the ball
//    is gone and you are exhausted (stunned 3.5 s); win and the ball breaks through.
//  - When it lands, the planet glows red for redRampTicks, then shatters (shatterTicks) and is
//    gone: everyone on it dies with it, its claim and garrison go, a sun takes its whole system,
//    a moon re-forms after planetDebrisSeconds, the destroyer's alignment drops by 10.
//  - A claimed planet can only be broken by its owner (DMZR: only with a raid entitlement,
//    which this addon has no raids for). When a claimed planet is destroyed (by anything),
//    PlanetSalvage recovers every container's contents and half of the blocks its owner's side
//    placed there into the owner's salvage vault: /rpgc salvage.
//  Settings: /rpg config dbr_space_buster.
// =====================================================================================
var DBR_BUSTER_CFG = RPG.config.define("dbr_space_buster", {
    enabled:               { default: true, comment: "Giant ki balls fired in space can destroy generated planets, moons and suns (DMZ Ragnarok PlanetBuster)" },
    redRampTicks:          { default: 60, min: 0, max: 600, client: true, comment: "Ticks the doomed planet glows red before it breaks" },
    shatterTicks:          { default: 40, min: 0, max: 600, client: true, comment: "Ticks the planet takes to shatter" },
    alignmentPenalty:      { default: 10, min: 0, max: 100, comment: "Alignment the destroyer loses (0 = none)" },
    minBlastKiDamage:      { default: 3000, min: 0, max: 100000000, comment: "A blast weaker than this cannot break a planet at all (0 = no floor)" },
    clashEnabled:          { default: true, comment: "The planet fires back: a beam clash decides whether the ball breaks it" },
    clashTriggerRadiusMultiplier: { default: 2.0, min: 1, max: 20, comment: "The clash starts this many planet radii from its centre..." },
    clashTriggerMinDistance: { default: 50, min: 0, max: 1000, comment: "...or this many blocks, whichever is further" },
    clashWildToughness:    { default: 5000, min: 1, max: 100000000, comment: "Toughness of an unclaimed world" },
    clashOwnedToughnessBase: { default: 5000, min: 0, max: 100000000, comment: "Toughness of a claimed world: base..." },
    clashOwnedToughnessPerMember: { default: 2000, min: 0, max: 100000000, comment: "...plus this per owner..." },
    clashOwnedBattlePowerDivisor: { default: 100, min: 0, max: 100000000, comment: "...plus the owner's battle power / this, while online (0 = ignore)..." },
    clashOwnedToughnessFloor: { default: 8000, min: 0, max: 100000000, comment: "...but never below this" },
    clashBattlePowerEnabled: { default: true, comment: "Your clash weight blends ki damage with battle power (otherwise ki damage alone)" },
    clashKiDamageWeight:   { default: 0.15, min: 0, max: 10, comment: "Weight of the blast's ki damage" },
    clashBattlePowerWeight: { default: 1.0, min: 0, max: 10, comment: "Weight of your battle power..." },
    clashBattlePowerScale: { default: 0.05, min: 0, max: 10, comment: "...after scaling it by this" },
    clashDefenderWeight:   { default: 0.05, min: 0.01, max: 10, comment: "The planet pushes back with its toughness x this" },
    planetDebrisSeconds:   { default: 604800, min: 0, max: 100000000, comment: "A destroyed moon re-forms after this many seconds of game time (DMZ Ragnarok's debris timer; one week)" },
    salvageContainerRate:  { default: 1.0, min: 0, max: 1, comment: "Share of container contents recovered when a claimed planet is destroyed" },
    salvageBlockRate:      { default: 0.5, min: 0, max: 1, comment: "Share of player-placed blocks recovered (as items)" }
});

var DBR_SPACE_BUSTER = (function () {
    var C = DBR_BUSTER_CFG, O = DBR_SPACE_ORBITS, B = DBR_SPACE_BODIES, K = DBR_CLASH, SPACE = O.SPACE, SURFACE = B.SURFACE;
    var LABEL_DISTANCE = 300, MAX_RECORD_TICKS = 20 * 60, VIEW = 900;
    function now() { return Date.now(); }
    function dist(a, b) { var dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z; return Math.sqrt(dx * dx + dy * dy + dz * dz); }
    function playerBy(uuid) { var l = RPG.server.players(); for (var i = 0; i < l.length; i++) if (l[i].uuid === uuid) return l[i]; return null; }
    function refuse(p, text) { p.actionbar("&c" + text); }
    function battlePower(p) { try { return typeof DMZ_F !== "undefined" && typeof dmzView === "function" ? DMZ_F.battlePower(dmzView(p)) : 0; } catch (e) { return 0; } }

    /** Where a ray from eye along dir enters a body's cube (DMZR rayCubeEntry): distance, 0 when inside, -1 for a miss. */
    function rayCubeEntry(eye, dir, c, r, max) {
        var t0 = 0, t1 = max, o = [eye.x, eye.y, eye.z], d = [dir.x, dir.y, dir.z], lo = [c.x - r, c.y - r, c.z - r], hi = [c.x + r, c.y + r, c.z + r];
        for (var i = 0; i < 3; i++) {
            if (Math.abs(d[i]) < 1e-9) { if (o[i] < lo[i] || o[i] > hi[i]) return -1; continue; }
            var a = (lo[i] - o[i]) / d[i], b = (hi[i] - o[i]) / d[i];
            if (a > b) { var t = a; a = b; b = t; }
            t0 = Math.max(t0, a); t1 = Math.min(t1, b);
            if (t0 > t1) return -1;
        }
        return t0;
    }
    function lookDir(p) {
        var yaw = p.yaw * Math.PI / 180, pitch = p.pitch * Math.PI / 180;
        return { x: -Math.sin(yaw) * Math.cos(pitch), y: -Math.sin(pitch), z: Math.cos(yaw) * Math.cos(pitch) };
    }
    function bustable(b) { return b.kind === "planet" || b.kind === "moon" || b.kind === "star"; }
    function toughness(id) {
        var owner = DBR_SPACE.claimOf(id);
        if (!owner) return C.get("clashWildToughness");
        var t = C.get("clashOwnedToughnessBase") + C.get("clashOwnedToughnessPerMember"), op = RPG.server.player(owner), div = C.get("clashOwnedBattlePowerDivisor");
        if (op && div > 0) t += battlePower(op) / div;
        return Math.max(C.get("clashOwnedToughnessFloor"), t);
    }

    // ---- fire: the hook 41_dmz_techniques.js calls when a giant ball is released (DMZ KiAttackFireEvent) ----
    var flights = [], seq = 0, dooms = [];
    function onFire(p, proj, dmg, T) {
        if (!C.get("enabled") || !p || p.dimension !== SPACE || !proj) return;
        var eye = { x: p.x, y: p.y + 1.6, z: p.z }, dir = lookDir(p), maxRay = LABEL_DISTANCE + 96 * 3;
        var best = null, bestT = 1e18;
        B.near(eye, 4000, now()).forEach(function (b) {
            if (!bustable(b) && b.kind !== "super" && b.kind !== "fixed") return;
            var r = b.kind === "star" ? b.radius * 3 : b.radius, t = rayCubeEntry(eye, dir, b.pos, r, maxRay + r);
            if (t >= 0 && t < bestT) { bestT = t; best = b; }
        });
        if (!best) return;                                            // not aimed at anything: an ordinary blast
        var radius = best.kind === "star" ? best.radius * 3 : best.radius;
        if (dist(eye, best.pos) - radius > LABEL_DISTANCE) { refuse(p, "You are too far from the planet to destroy it. Get close enough to see its name."); return; }
        if (!bustable(best)) { refuse(p, "That world cannot be destroyed."); return; }
        if (DBR_SPACE.destroyedList().indexOf(best.id) >= 0) { refuse(p, "That planet is already gone."); return; }
        var owner = DBR_SPACE.claimOf(best.id);
        if (owner && owner !== p.name) { refuse(p, "This world is claimed by " + owner + ": only its owner can break it."); return; }
        if (C.get("minBlastKiDamage") > 0 && dmg < C.get("minBlastKiDamage")) {
            refuse(p, "Your blast is too weak to shatter a planet. Grow far stronger before you try.");
            try { DMZ_TECH_PROJ.burst(p, proj.x, proj.y, proj.z, proj, true); } catch (e) { }
            proj.discard();
            return;
        }
        // the ball is now a planet attack: it flies on as the space renderer's ball (its entity would stop ticking
        // once it outruns the loaded area round the firer)
        var col = T && T.colors ? [T.colors.core || "#C4FFFD", T.colors.border || "#00F8FF"] : ["#C4FFFD", "#00F8FF"];
        var f = { n: ++seq, id: best.id, kind: best.kind, owner: p.uuid, name: p.name, dmg: dmg, x: proj.x, y: proj.y, z: proj.z,
            speed: Math.max(0.8, Number(T && T.speed) || 1), size: Math.max(2, Number(proj.size) || 4), color: col, t0: RPG.server.getTick(),
            claimed: !!owner, clash: null, attempted: false, won: false };
        proj.discard();
        flights.push(f);
    }

    function targetOf(f) {
        if (f.kind === "star") {
            var hit = null;
            B.near(f, 2000, now()).forEach(function (b) { if (b.id === f.id) hit = b; });
            return hit ? { pos: hit.pos, radius: hit.radius * 3 } : null;
        }
        var b = B.find(f.id, now());
        return b ? { pos: b.pos, radius: b.radius } : null;
    }
    function viewers(f) { return RPG.server.players().filter(function (q) { return q.dimension === SPACE && dist(q, f) < VIEW; }); }
    function show(f, extra) {
        var d = { n: f.n, x: f.x, y: f.y, z: f.z, size: f.size, color: f.color[0], border: f.color[1] };
        if (extra) for (var k in extra) d[k] = extra[k];
        viewers(f).forEach(function (q) { RPG.net.send(q, "dbr_buster", d); });
    }

    // ---- the clash (PlanetClash + DragonMine Z's BeamClash/ClashParticipant) ----
    function startClash(f, p) {
        var kiW = C.get("clashKiDamageWeight"), bp = battlePower(p);
        var power = C.get("clashBattlePowerEnabled") ? kiW * f.dmg + C.get("clashBattlePowerWeight") * bp * C.get("clashBattlePowerScale") : f.dmg;
        var def = toughness(f.id) * C.get("clashDefenderWeight");
        var seed = O.u64.make(Math.floor(Math.random() * 4294967296), Math.floor(Math.random() * 4294967296));
        f.clash = { seed: seed, age: 0, bias: 0.5,
            a: { power: Math.max(1, power), momentum: 0, idle: 0, consumed: -1, last: -1e9, offsets: [], strikes: 0 },
            b: { power: Math.max(1, def), momentum: 0, idle: 0, consumed: -1, acc: K.npcAccuracy(Math.max(1, def)) } };
        RPG.net.send(p, "dbr_clash", { start: true, hi: seed.hi, lo: seed.lo, self: f.color[1], foe: "#66CCFF", adv: 0.5 });
        p.actionbar("&eThe planet is defending itself. Overpower its blast to break it.");
        p.playSound(DMZ + "ki_explosion_impact", 1, 0.6);
    }
    function npcPress(c, b) {
        var s = K.sample(c.seed, c.age);
        if (s.cycle.index <= b.consumed || s.grade === "MISS") return;
        var nx = K.sample(c.seed, c.age + 1);
        if (nx.cycle.index === s.cycle.index && nx.distance < s.distance) return;   // the closest tick of this sweep
        b.consumed = s.cycle.index;
        b.momentum += s.efficiency * (b.acc || 1) * (b.acc ? 0.7 + Math.random() * 0.3 : 1);
        b.idle = 0;
    }
    RPG.net.on("dbr_clash_press", function (p, d) {
        var f = null;
        flights.forEach(function (x) { if (x.owner === p.uuid && x.clash) f = x; });
        if (!f || !d) return;
        var c = f.clash, a = c.a, t = Number(d.t);
        // ClashParticipant.registerPlayerPress: a press stamped outside the lag tolerance is clamped (and counted)
        if (isNaN(t)) t = c.age;
        if (t < c.age - 12 || t > c.age + 3) { a.strikes++; t = Math.max(c.age - 12, Math.min(c.age + 3, t)); }
        if (t <= a.last) return;
        a.last = t; a.idle = 0;
        var s = K.sample(c.seed, t);
        if (Math.abs(s.marker - Number(d.m)) > 0.06) a.strikes++;
        if (s.cycle.index <= a.consumed) return;
        a.consumed = s.cycle.index;
        if (s.grade === "MISS") return;
        var off = (s.marker - s.cycle.center) / s.cycle.halfWidth, eff = s.efficiency;
        a.offsets.push(off);
        if (a.offsets.length > 6) a.offsets.shift();
        if (a.offsets.length === 6) {
            // a bot presses the same offset every time: dampened (botConsistencyPenalty)
            var lo = Math.min.apply(null, a.offsets), hi = Math.max.apply(null, a.offsets);
            if (hi - lo < 0.12) eff *= 0.4;
        }
        if (a.strikes >= 4) eff *= 0.4;
        a.momentum += eff;
    });
    /** One clash tick: "on", "win", "lose" (DMZR: dissolve hands the ball the win). */
    function clashTick(f, p) {
        var c = f.clash;
        c.age++;
        c.a.momentum *= K.DECAY; c.b.momentum *= K.DECAY;
        c.a.idle++; c.b.idle++;
        npcPress(c, c.b);
        if (f.autoPress) npcPress(c, c.a);                           // /rpgc spacebust ... win: the tester presses perfectly
        c.bias = K.advanceBias(c.bias, c.a, c.b);
        if (c.age % 2 === 0) RPG.net.send(p, "dbr_clash", { adv: K.visualBias(c.bias) });
        if (c.bias >= K.WIN) return "win";
        if (c.bias <= 1 - K.WIN) return "lose";
        if (Math.min(c.a.idle, c.b.idle) >= K.IDLE_DISSOLVE) return "win";
        if (c.age >= K.MAX_DURATION) return c.bias < 0.5 ? "lose" : "win";
        return "on";
    }

    // ---- the flight, every tick ----
    function step(f) {
        var p = playerBy(f.owner), tick = RPG.server.getTick();
        if (DBR_SPACE.destroyedList().indexOf(f.id) >= 0) return false;
        var tg = targetOf(f);
        if (!tg) return false;
        if (!f.clash && tick - f.t0 > MAX_RECORD_TICKS) return false;
        if (f.clash) {
            if (!p || !p.alive || p.dimension !== SPACE) { f.clash = null; f.won = true; return true; }   // the struggle dissolves
            var r = clashTick(f, p);
            if (r === "on") { if (f.clash.age % 2 === 0) show(f, { clash: true }); return true; }
            RPG.net.send(p, "dbr_clash", { end: true, exhaust: r === "lose" ? K.LOSER_EXHAUST : 0 });
            f.clash = null;
            if (r === "lose") {
                p.actionbar("&cThe planet overpowered your blast. It still stands.");
                p.addEffect("stunned", K.LOSER_EXHAUST);
                show(f, { end: true, boom: true });
                return false;
            }
            f.won = true;
            p.playSound(DMZ + "ki_explosion_impact", 1, 1.2);
            return true;
        }
        var d = dist(f, tg.pos);
        if (C.get("clashEnabled") && !f.attempted && p && p.alive) {
            var trigger = Math.max(C.get("clashTriggerMinDistance"), tg.radius * C.get("clashTriggerRadiusMultiplier"));
            if (d <= trigger) { f.attempted = true; startClash(f, p); show(f, { clash: true }); return true; }
        }
        // inside the body's cube: impact
        if (Math.abs(f.x - tg.pos.x) <= tg.radius && Math.abs(f.y - tg.pos.y) <= tg.radius && Math.abs(f.z - tg.pos.z) <= tg.radius) {
            show(f, { end: true, boom: true });
            doom(f, p);
            return false;
        }
        var sp = Math.min(f.speed, d);
        f.x += (tg.pos.x - f.x) / d * sp; f.y += (tg.pos.y - f.y) / d * sp; f.z += (tg.pos.z - f.z) / d * sp;
        if (tick % 2 === 0) show(f);
        return true;
    }
    // ---- the doom sequence: red ramp, then the destroy and the shatter ----
    function doom(f, p) {
        var ramp = C.get("redRampTicks");
        dooms.push({ id: f.id, credit: f.owner, at: RPG.server.getTick() + ramp });
        RPG.server.players().forEach(function (q) { if (q.dimension === SPACE || q.dimension === SURFACE) RPG.net.send(q, "dbr_planet_doom", { id: f.id, phase: "ramp", ticks: ramp }); });
        RPG.server.players().forEach(function (q) { if (q.dimension === SURFACE && String(q.getVar("dbr_surface", "")) === f.id) q.title("&4The planet is breaking apart!", "&7Get off it now!"); });
    }
    function doomTick() {
        var t = RPG.server.getTick();
        dooms = dooms.filter(function (d) {
            if (t < d.at) return true;
            var credit = playerBy(d.credit), name = DBR_SPACE.name(B.find(d.id, now()) || { kind: "?", id: d.id });
            RPG.server.players().forEach(function (q) { if (q.dimension === SPACE || q.dimension === SURFACE) RPG.net.send(q, "dbr_planet_doom", { id: d.id, phase: "shatter", ticks: C.get("shatterTicks") }); });
            if (DBR_SPACE.destroy(d.id, credit) && credit) credit.actionbar("&6" + name + " has been destroyed by your ki blast.");
            return false;
        });
    }
    RPG.every(1, function () {
        if (!flights.length && !dooms.length) return;
        flights = flights.filter(function (f) { try { return step(f); } catch (err) { RPG.log("[DBR] buster: " + err); return false; } });
        doomTick();
    });
    RPG.on("playerLeave", function (p) { flights.forEach(function (f) { if (f.owner === p.uuid && f.clash) { f.clash = null; f.won = true; } }); });

    return { onFire: onFire, flights: function () { return flights; }, rayCubeEntry: rayCubeEntry };
})();
// /rpgc spacebust [kiDamage]: throw a test giant ball along your look (ops; testing the buster without charging one)
RPG.commands.register("spacebust", {
    permission: 2, description: "/rpgc spacebust [kiDamage] - a test giant ball at the planet you look at",
    run: function (p, args) {
        if (!p) return;
        if (args && args[1] === "near") {
            // aim at the nearest generated planet first
            var best = null, bd = 1e18;
            DBR_SPACE_BODIES.near(p, 3000, Date.now()).forEach(function (b) { if (b.kind !== "planet" && b.kind !== "moon") return; var d = Math.hypot(b.pos.x - p.x, b.pos.y - p.y, b.pos.z - p.z); if (d < bd) { bd = d; best = b; } });
            if (best) {
                var ox = best.pos.x + best.radius + 140;
                p.teleportTo(DBR_SPACE_ORBITS.SPACE, ox, best.pos.y, best.pos.z, 90, 0);
                p.tell("&7Aiming at " + best.id + " (140 blocks)");
            }
        }
        var fake = { x: p.x - 3, y: p.y + 1.6, z: p.z, size: 6, discard: function () { } };
        DBR_SPACE_BUSTER.onFire(p, fake, Number(args && args[0]) || 50000, { speed: 2, colors: { core: "#C4FFFD", border: "#00F8FF" } });
        var fl = DBR_SPACE_BUSTER.flights();
        if (args && args[2] === "win" && fl.length) fl[fl.length - 1].autoPress = true;
        p.tell("&7Flights: " + fl.length);
    }
});
/** Called by 41_dmz_techniques.js when a GIANT_BALL is released (DMZ's KiAttackFireEvent). */
function dbrSpaceKiFired(p, proj, dmg, T) { try { DBR_SPACE_BUSTER.onFire(p, proj, dmg, T); } catch (err) { RPG.log("[DBR] buster: " + err); } }

// =====================================================================================
//  PlanetSalvage: what a destroyed claimed world's owner gets back
// =====================================================================================
//  Blocks players place on a generated planet are remembered (that is DMZR's "differs from the
//  natural terrain" test, kept exactly instead of re-derived). When the planet is destroyed, the
//  owner's vault gets every container's contents (salvageContainerRate) and that share of the
//  placed blocks (salvageBlockRate) as items, a few hundred spots a tick; containers first, so a
//  full vault drops bulk stone, not loot. /rpgc salvage opens the vault.
var DBR_SPACE_SALVAGE = (function () {
    var C = DBR_BUSTER_CFG, B = DBR_SPACE_BODIES, SURFACE = B.SURFACE, MAX_PLACED = 30000, MAX_STACKS = 270;
    var placedMem = {};
    function placed(id) { if (!placedMem[id]) placedMem[id] = RPG.data.get("dbr_placed_" + id, null) || {}; return placedMem[id]; }
    var dirty = {}, counts = {};
    function planetOf(p) { return p.dimension === SURFACE ? String(p.getVar("dbr_surface", "") || "") : ""; }
    RPG.on("blockPlace", function (p, block, x, y, z, dim) {
        if (dim !== SURFACE) return;
        var id = planetOf(p);
        if (!id) return;
        var m = placed(id), k = x + "," + y + "," + z;
        if (!m[k]) {
            if (counts[id] === undefined) counts[id] = Object.keys(m).length;
            if (counts[id] >= MAX_PLACED) return;
            m[k] = 1; counts[id]++; dirty[id] = true;
        }
    });
    RPG.on("blockBreak", function (p, block, x, y, z, dim) {
        if (dim !== SURFACE) return;
        var id = planetOf(p);
        if (!id) return;
        var m = placed(id), k = x + "," + y + "," + z;
        if (m[k]) { delete m[k]; if (counts[id] !== undefined) counts[id]--; dirty[id] = true; }
    });
    RPG.every(200, function () { for (var id in dirty) RPG.data.set("dbr_placed_" + id, placedMem[id]); dirty = {}; });

    function vault(owner) { return RPG.data.get("dbr_salvage_" + owner, null) || []; }
    function deposit(owner, items) {
        var v = vault(owner), dropped = 0;
        items.forEach(function (st) {
            if (!st || !st.id) return;
            for (var i = 0; i < v.length; i++) if (v[i].id === st.id && !v[i].nbt && !st.nbt && v[i].count < 64) {
                var room = 64 - v[i].count, put = Math.min(room, st.count);
                v[i].count += put; st.count -= put;
                if (st.count <= 0) return;
            }
            while (st.count > 0) {
                if (v.length >= MAX_STACKS) { dropped += st.count; return; }
                var c = Math.min(64, st.count), o = { id: st.id, count: c };
                if (st.nbt) o.nbt = st.nbt;
                v.push(o); st.count -= c;
            }
        });
        RPG.data.set("dbr_salvage_" + owner, v);
        return dropped;
    }
    /** Walk the destroyed planet's remembered blocks (spread over ticks), centre outward. */
    function capture(id, owner) {
        if (!owner) return;
        var m = placed(id), keys = Object.keys(m), c = B.cellCentre(id);
        delete placedMem[id]; delete counts[id]; delete dirty[id];
        RPG.data.set("dbr_placed_" + id, null);
        keys.sort(function (a, b) { var pa = a.split(","), pb = b.split(","); return (Math.abs(pa[0] - c.x) + Math.abs(pa[2] - c.z)) - (Math.abs(pb[0] - c.x) + Math.abs(pb[2] - c.z)); });
        var cr = C.get("salvageContainerRate"), br = C.get("salvageBlockRate"), loot = [], bulk = {}, at = 0, containers = 0;
        var task = RPG.every(1, function () {
            for (var n = 0; n < 300 && at < keys.length; n++, at++) {
                var k = keys[at].split(","), x = Number(k[0]), y = Number(k[1]), z = Number(k[2]);
                if (!RPG.world.isLoaded(SURFACE, x, z)) { RPG.world.requestChunks(SURFACE, x, z, 0); if (n > 0) break; continue; }
                var inv = RPG.world.containerItems(SURFACE, x, y, z, true);
                if (inv) {
                    containers++;
                    inv.forEach(function (st) { var cnt = Math.floor(st.count * cr + Math.random()); if (cnt > 0) { st.count = Math.min(st.count, cnt); loot.push(st); } });
                }
                var b = String(RPG.world.getBlock(SURFACE, x, y, z));
                if (b !== "minecraft:air" && b.indexOf("water") < 0 && b.indexOf("lava") < 0) bulk[b] = (bulk[b] || 0) + 1;
            }
            if (at < keys.length) return;
            RPG.cancel(task);
            var items = loot.slice();
            for (var bid in bulk) { var cnt = Math.floor(bulk[bid] * br); if (cnt > 0) items.push({ id: bid, count: cnt }); }
            var dropped = deposit(owner, items);
            RPG.log("[DBR] salvage: " + id + " -> " + owner + ": " + items.length + " stacks from " + keys.length + " placed blocks (" + containers + " containers)" + (dropped ? ", " + dropped + " items over the vault's cap" : ""));
            var op = RPG.server.player(owner);
            if (op && items.length) op.tell("&6Some of what you had on your lost world was recovered: &e/rpgc salvage");
        });
    }
    RPG.commands.register("salvage", {
        permission: 0, description: "/rpgc salvage - what was recovered from your destroyed planets",
        run: function (p) {
            if (!p) return;
            var v = vault(p.name);
            if (!v.length) { p.tell("&7Your salvage vault is empty."); return; }
            RPG.ui.container(p, {
                title: "Salvage Vault", rows: 6, items: v.slice(0, 54),
                onClose: function (pl, items) {
                    var rest = items.filter(function (s) { return s; }).concat(v.slice(54));
                    RPG.data.set("dbr_salvage_" + pl.name, rest);
                }
            });
        }
    });
    RPG.on("playerJoin", function (p) { RPG.schedule(60, function () { if (vault(p.name).length) p.tell("&6Your salvage vault holds items: &e/rpgc salvage"); }); });
    return { capture: capture, vault: vault, placed: placed };
})();
