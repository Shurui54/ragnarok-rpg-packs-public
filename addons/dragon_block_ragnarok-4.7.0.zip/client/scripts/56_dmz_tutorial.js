// =====================================================================================
//  56_dmz_tutorial.js - DragonMine Z's first-time tutorials (TutorialManager + TutorialOverlay)
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): the first time a menu opens (and while the "Tutorials" option
//  is on), the screen dims except the parts a step talks about and a popup explains them, with
//  Next / Got it / Skip (Enter or Space = next). A tutorial counts as seen once it ends; "Show
//  Tutorials Again" in the options screen forgets them (DMZ_OPTS.tutorials).
//
//  Screens use it like this (30_stats_screen.js):
//    open:      DMZ_TUTORIAL.request("dmz_stats", "stats_menu", steps)
//    onRender:  DMZ_TUTORIAL.render(ctx)                 (last, above everything)
//    onMouse:   if (DMZ_TUTORIAL.active("dmz_stats")) return DMZ_TUTORIAL.mouse(x, y, button, action);
//    onKey:     same with DMZ_TUTORIAL.key(name, action)
//    onClose:   DMZ_TUTORIAL.closed("dmz_stats")
//  A step: { text, title, args: fn -> [..], rects: fn(ctx) -> [[x, y, w, h], ...], padding, centered,
//            buttons: [{ icon: "minus"|"plus", run: fn }] (icon buttons keep the step open) }.
// =====================================================================================
var DMZ_TUTORIAL = (function () {
    var U = DMZ_UI, FONT = U.FONT, BUTTONS = U.BUTTONS;
    var POPUP_W = 184, PAD = 10, GAP = 8, MARGIN = 4, LINE = 10, TITLE_H = 13, BTN_W = 74, BTN_H = 20, BTN_GAP = 4;
    var DIM = 0.74, ACCENT = "#7CFDD6";
    var ICONS = { minus: { u: 142, v: 0 }, plus: { u: 0, v: 0 } };   // characterbuttons' -/+ (10x10, hover row below)
    var T = null;

    function opts() { return typeof DMZ_OPTS !== "undefined" ? DMZ_OPTS.tutorials : null; }
    function tr(key, args) {
        var s = U.tr.apply(null, [key].concat(args || []));
        return s.replace(/%%/g, "%");
    }

    /** Starts tutorial id on screen screenId unless it was seen or tutorials are off. */
    function request(screenId, id, steps, onEnd) {
        var o = opts();
        if (T && T.id === id) { T.screen = screenId; return true; }
        if (!o || !o.shouldRun(id) || !steps || !steps.length) return false;
        T = { id: id, screen: screenId, steps: steps, index: 0, onEnd: onEnd || null, boxes: [], start: RPG.nowMs(), keep: false };
        return true;
    }
    function active(screenId) { return !!T && (!screenId || T.screen === screenId); }
    function current() { return T ? T.steps[T.index] : null; }
    function finish() {
        if (!T) return;
        var t = T;
        T = null;
        var o = opts();
        if (o) o.markSeen(t.id);
        if (t.onEnd) try { t.onEnd(); } catch (e) { RPG.log("tutorial end: " + e); }
        RPG.sound("dmzpack:pip_menu", 1, 1);
    }
    function next() {
        if (!T) return;
        if (T.index + 1 >= T.steps.length) { finish(); return; }
        T.index++; T.start = RPG.nowMs();
        RPG.sound("dmzpack:pip_menu", 1, 1.2);
    }
    /** The hosting screen closed: stop without marking it seen (DMZ shows it again next time). keep() first to survive a reopen. */
    function closed(screenId) {
        if (!T || T.screen !== screenId) return;
        if (T.keep) { T.keep = false; return; }
        T = null;
    }
    function keep() { if (T) T.keep = true; }
    function turnOff() { if (typeof DMZ_OPTS !== "undefined") DMZ_OPTS.set(DMZ_OPTS.KEYS.tutorialsEnabled, false); T = null; }

    // ---- drawing (TutorialOverlay) ----
    function padRect(r, p) { return [r[0] - p, r[1] - p, r[2] + 2 * p, r[3] + 2 * p]; }
    function union(rs) {
        if (!rs.length) return null;
        var x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
        rs.forEach(function (r) { x0 = Math.min(x0, r[0]); y0 = Math.min(y0, r[1]); x1 = Math.max(x1, r[0] + r[2]); y1 = Math.max(y1, r[1] + r[3]); });
        return [x0, y0, x1 - x0, y1 - y0];
    }
    /** Darken everything outside the rectangles: horizontal bands between their edges, gaps filled. */
    function dim(ctx, rs, alpha) {
        var W = ctx.width, H = ctx.height, ys = [0, H];
        rs.forEach(function (r) { ys.push(Math.max(0, Math.min(H, r[1]))); ys.push(Math.max(0, Math.min(H, r[1] + r[3]))); });
        ys.sort(function (a, b) { return a - b; });
        for (var i = 0; i + 1 < ys.length; i++) {
            var top = ys[i], bottom = ys[i + 1];
            if (bottom - top <= 0) continue;
            var mid = (top + bottom) / 2, runs = [];
            rs.forEach(function (r) { if (mid >= r[1] && mid < r[1] + r[3]) runs.push([Math.max(0, r[0]), Math.min(W, r[0] + r[2])]); });
            runs.sort(function (a, b) { return a[0] - b[0]; });
            var x = 0;
            runs.forEach(function (run) { if (run[0] > x) ctx.fill(x, top, run[0] - x, bottom - top, "#000000", alpha); x = Math.max(x, run[1]); });
            if (x < W) ctx.fill(x, top, W - x, bottom - top, "#000000", alpha);
        }
    }
    function outline(ctx, r, alpha) {
        ctx.fill(r[0], r[1], r[2], 1, ACCENT, alpha); ctx.fill(r[0], r[1] + r[3] - 1, r[2], 1, ACCENT, alpha);
        ctx.fill(r[0], r[1] + 1, 1, r[3] - 2, ACCENT, alpha); ctx.fill(r[0] + r[2] - 1, r[1] + 1, 1, r[3] - 2, ACCENT, alpha);
    }
    function place(target, w, h, W, H) {
        if (!target) return [(W - w) / 2, (H - h) / 2];
        var cx = target[0] + target[2] / 2, x = Math.max(MARGIN, Math.min(W - w - MARGIN, cx - w / 2));
        if (target[1] + target[3] + GAP + h <= H - MARGIN) return [x, target[1] + target[3] + GAP];
        if (target[1] - GAP - h >= MARGIN) return [x, target[1] - GAP - h];
        var y = Math.max(MARGIN, Math.min(H - h - MARGIN, target[1] + target[3] / 2 - h / 2));
        if (target[0] + target[2] + GAP + w <= W - MARGIN) return [target[0] + target[2] + GAP, y];
        if (target[0] - GAP - w >= MARGIN) return [target[0] - GAP - w, y];
        return [(W - w) / 2, H - h - MARGIN];
    }

    function render(ctx) {
        if (!T || RPG.screen.getOpen() !== T.screen) return;
        var step = current(), mx = ctx.mouseX, my = ctx.mouseY, W = ctx.width, H = ctx.height;
        var appear = Math.min(1, (RPG.nowMs() - T.start) / 220);
        var pad = step.padding === undefined ? 2 : step.padding;
        var rects = (step.rects ? step.rects(ctx) : []).map(function (r) { return padRect(r, pad); });
        dim(ctx, rects, DIM);
        rects.forEach(function (r) { outline(ctx, r, 0.55 + 0.35 * Math.sin(RPG.nowMs() / 260)); });

        var pw = Math.min(POPUP_W, W - MARGIN * 2), tw = pw - PAD * 2;
        var lines = U.wrap(ctx, tr(step.text, step.args ? step.args() : []), tw);
        var title = step.title ? tr(step.title) : null;
        var ph = PAD + (title ? TITLE_H : 0) + lines.length * LINE + 6 + BTN_H + PAD - 2;
        var at = place(step.centered ? null : union(rects), pw, ph, W, H), x = at[0], y = at[1] + (1 - appear) * 6;
        ctx.alpha(appear);
        ctx.fill(x, y, pw, ph, "#0A0A16", 0.95);
        outline(ctx, [x, y, pw, ph], 0.9);
        var cy = y + PAD;
        if (title) { ctx.textStyled("§l" + title, x + PAD, cy, 1, "#FFD700", 1, 0, FONT, "#000000"); cy += TITLE_H; }
        ctx.textStyled((T.index + 1) + "/" + T.steps.length, x + pw - PAD, y + PAD, 1, "#9FB8AE", 1, 1, FONT, null);
        lines.forEach(function (l) { ctx.textStyled(l, x + PAD, cy, 1, "#FFFFFF", 1, 0, FONT, null); cy += LINE; });

        // buttons, right to left: Next / Got it, then the step's own, Skip on the left when there is room
        T.boxes = [];
        var rowY = y + ph - PAD - BTN_H + 2, cursor = x + pw - PAD;
        cursor -= BTN_W;
        T.boxes.push({ x: cursor, y: rowY, w: BTN_W, h: BTN_H, kind: "next" });
        cursor -= BTN_GAP;
        (step.buttons || []).slice().reverse().forEach(function (b) {
            cursor -= 14;
            T.boxes.push({ x: cursor, y: rowY + (BTN_H - 11) / 2, w: 14, h: 11, kind: "custom", b: b });
            cursor -= BTN_GAP;
        });
        if (step.skippable !== false && T.steps.length > 1 && cursor - (x + PAD) >= BTN_W) T.boxes.push({ x: x + PAD, y: rowY, w: BTN_W, h: BTN_H, kind: "skip" });
        if (step.turnOff && cursor - (x + PAD) >= BTN_W) T.boxes.push({ x: x + PAD, y: rowY, w: BTN_W, h: BTN_H, kind: "off" });
        T.boxes.forEach(function (b) {
            var over = U.inside(mx, my, b.x, b.y, b.w, b.h);
            if (b.kind === "custom") {
                var ic = ICONS[b.b.icon] || ICONS.plus;
                ctx.image(BUTTONS, b.x + 2, b.y, 10, 10, ic.u, ic.v + (over ? 10 : 0), 10, 10, 256, 256);
                return;
            }
            ctx.image(BUTTONS, b.x, b.y, b.w, b.h, 0, over ? 48 : 28, 74, 20, 256, 256);
            var key = b.kind === "skip" ? "gui.dragonminez.tutorial.skip" : b.kind === "off" ? "gui.dragonminez.tutorial.disable"
                : T.index + 1 >= T.steps.length ? "gui.dragonminez.tutorial.done" : "gui.dragonminez.tutorial.next";
            ctx.textStyled(tr(key), b.x + b.w / 2, b.y + 6, 1, over ? ACCENT : "#FFFFFF", 1, 0.5, FONT, null);
        });
        ctx.alpha(1);
    }

    /** While active the tutorial takes every click (nothing under the dim reacts). Returns false (swallowed). */
    function mouse(x, y, button, action) {
        if (!T) return;
        if (action !== "down" || button !== 0) return false;
        for (var i = 0; i < T.boxes.length; i++) {
            var b = T.boxes[i];
            if (!U.inside(x, y, b.x, b.y, b.w, b.h)) continue;
            if (b.kind === "next") next();
            else if (b.kind === "skip") finish();
            else if (b.kind === "off") turnOff();
            else if (b.kind === "custom") { RPG.sound("dmzpack:ui_nave_cooldown", 1, 1); b.b.run(); }
            return false;
        }
        return false;
    }
    function key(name, action) {
        if (!T) return;
        if (action !== "down") return false;
        var k = String(name || "");
        if (/escape/.test(k)) finish();
        else if (/enter|space/.test(k)) next();
        return false;
    }

    return { request: request, active: active, render: render, mouse: mouse, key: key, closed: closed, keep: keep, finish: finish };
})();
