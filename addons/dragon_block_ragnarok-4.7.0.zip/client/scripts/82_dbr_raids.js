// =====================================================================================
//  82_dbr_raids.js - DMZ Ragnarok raids on the client: raid bar, boss music, tears, sign-up and browser
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0) shuruis_raid_bosses client: RaidHudOverlay + RaidHudState (the raid bar in
//  DragonMine Z's alternativehud.png art: NPCs left during waves, boss HP once one boss is the fight; eased fill,
//  loss chip, hit flash; movable "Raid Bar" in the HUD editor), BossMusicClient, DimensionalTearRenderer (the
//  24-frame swirl, a tint per tear, the Halloween look with its glowing face), RaidSignupScreen and
//  RaidBrowserScreen (collapsible categories). Server: scripts/92_dbr_raids.js / 92_dbr_raids_rifts.js.
//  Editors: 82_dbr_raids_editor.js.
// =====================================================================================
var DBR_RAIDS_UI = (function () {
    var U = DMZ_UI, FONT = U.FONT;
    var HUD_TEX = "dmzpack:textures/gui/hud/alternativehud.png", ATLAS = 128;
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png", BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var TEAR_TEX = "dbr:textures/entity/raids/dimensional_tear.png", FACE_TEX = "dbr:textures/entity/raids/haunted_tear_face.png";

    // ---- raid bar (RaidHudState + RaidHudOverlay + RagnarokBarAnim) ----
    var H = { active: false, mode: 0, label: "", cur: 0, max: 1, at: 0 };
    var A = { front: 1, ghost: 1, impact: 0, healing: false, lastMax: -1, lastTarget: 1, ghostHold: 0 };
    RPG.net.on("dbr_raid_hud", function (d) {
        d = d || {};
        H.active = !!d.active; H.mode = d.mode || 0; H.label = String(d.label || ""); H.cur = Number(d.cur) || 0; H.max = Math.max(1, Number(d.max) || 1); H.at = RPG.nowMs();
    });
    function visible() { return H.active && RPG.nowMs() - H.at < 3000; }
    function fmtN(v) { return String(Math.round(v)).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
    var last = RPG.nowMs();
    function drawBar(ctx) {
        var editing = ctx.isEditing(), live = visible();
        if (!live && !editing) return;
        var nowMs = RPG.nowMs(), dt = Math.min(0.1, (nowMs - last) / 1000);
        last = nowMs;
        var cur = live ? H.cur : 7, max = live ? H.max : 10, target = Math.max(0, Math.min(1, cur / max));
        if (max !== A.lastMax) { A.front = A.ghost = target; A.lastMax = max; A.impact = 0; }
        if (target < A.lastTarget - 1e-4) { A.impact = 1; A.ghostHold = 0.35; A.healing = false; }
        else if (target > A.lastTarget + 0.05) { A.healing = true; A.ghost = target; }
        A.lastTarget = target;
        A.front += (target - A.front) * Math.min(1, dt * 12);
        if (A.ghostHold > 0) A.ghostHold -= dt; else A.ghost += (A.front - A.ghost) * Math.min(1, dt * 4);
        if (A.ghost < A.front) A.ghost = A.front;
        A.impact = Math.max(0, A.impact - dt * 4);
        var S = 2, W = 83 * S, LABEL = 11, BH = LABEL + 9 * S + 12, x = (ctx.width - W) / 2, y = 36 - LABEL;
        if (!ctx.group("dbr_raid_bar", "Raid Bar", x, y, W, BH)) return;
        var fy = y + LABEL + 2 * S, fx = x + 2 * S, fw = 79 * S, fh = 4 * S;
        ctx.image(HUD_TEX, fx, fy, fw, fh, 2, 22, 79, 4, ATLAS, ATLAS);                          // depleted strip
        if (A.ghost > A.front + 0.001) ctx.fill(fx + fw * A.front, fy, fw * (A.ghost - A.front), fh, A.healing ? "#57FF6B" : "#E4E8FF", A.healing ? 0.55 : 0.74);
        var w = Math.round(fw * A.front);
        if (w > 0) {
            ctx.quad(HUD_TEX, fx, fy, w, fh, 2 / ATLAS, 11 / ATLAS, (2 + 79 * A.front) / ATLAS, 15 / ATLAS, "#FFFFFF", 1);
            if (A.impact > 0.02) ctx.fill(fx, fy, w, fh, "#FFFFFF", A.impact * 0.35);
        }
        ctx.image(HUD_TEX, x, y + LABEL, W, 9 * S, 0, 0, 83, 9, ATLAS, ATLAS);                  // frame
        var label = live ? H.label : "Raid", value = live && H.mode === 1 ? fmtN(cur) + " / " + fmtN(max) : Math.round(cur) + " enemies remaining";
        if (label) ctx.textStyled(label, x + W / 2, y, 1, "#F6E27A", 1, 0.5, FONT, "#000000");
        ctx.textStyled(value, x + W / 2, y + LABEL + 9 * S + 3, 1, "#FFFFFF", 1, 0.5, FONT, "#000000");
        ctx.endGroup();
    }

    // ---- boss music (BossMusicClient) ----
    RPG.net.on("dbr_raid_music", function (d) {
        var id = d && d.id ? String(d.id) : "";
        if (!id) { RPG.music("", 1, false); return; }
        RPG.music(id, 1, true);
    });
    RPG.net.on("dbr_raid_msg", function (d) { if (d) U.showStatus(String(d.text || ""), d.color || "#FFFFFF"); });

    // ---- dimensional tears (DimensionalTearRenderer) ----
    var TINTS = ["#B65CFF", "#FF5CE1", "#5CE1FF", "#38F2B0", "#5C8CFF", "#8CFF5C", "#FFC24D", "#FF6B4D", "#FF4D6B", "#E0E0FF"];
    var TEARS = [], SHOWN = {}, SHOWN_DIM = "";
    function hash(s) { var h = 7; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); }
    RPG.net.on("dbr_rift_tears", function (d) { TEARS = (d && d.tears) || []; syncTears(); });
    function syncTears() {
        var dim = RPG.player.dimension, want = {};
        TEARS.forEach(function (t) {
            if (t.dim !== dim) return;
            want[t.key] = true;
            if (SHOWN[t.key] && SHOWN_DIM === dim) return;
            var halloween = String(t.look || "").toLowerCase() === "halloween", cy = t.y + 0.5 + 1.5;
            RPG.world3d.billboard("dbr_tear_" + t.key, { x: t.x, y: cy, z: t.z, size: 3, texture: TEAR_TEX, uv: [0, 0, 1, 1 / 24], frames: 24, frameTime: 2,
                color: halloween ? "#FF7518" : TINTS[hash(t.key) % TINTS.length], alpha: 1, emissive: true });
            if (halloween) RPG.world3d.billboard("dbr_tear_face_" + t.key, { x: t.x, y: cy, z: t.z, size: 3 * 0.55, texture: FACE_TEX, alpha: 1, emissive: true, blend: "additive" });
            RPG.hud.set("dbr_tear_lbl_" + t.key, { type: "text", text: "§5" + t.label, world: { x: t.x, y: t.y + 3.6, z: t.z }, align: "center", color: "#E0B0FF", shadow: true });
            SHOWN[t.key] = t;
        });
        Object.keys(SHOWN).forEach(function (k) {
            if (want[k] && SHOWN_DIM === dim) return;
            if (want[k]) return;
            RPG.world3d.remove("dbr_tear_" + k); RPG.world3d.remove("dbr_tear_face_" + k); RPG.hud.remove("dbr_tear_lbl_" + k);
            delete SHOWN[k];
        });
        SHOWN_DIM = dim;
    }
    var tk = 0;
    RPG.on("tick", function () {
        if (RPG.player.dimension !== SHOWN_DIM) {
            Object.keys(SHOWN).forEach(function (k) { RPG.world3d.remove("dbr_tear_" + k); RPG.world3d.remove("dbr_tear_face_" + k); RPG.hud.remove("dbr_tear_lbl_" + k); });
            SHOWN = {};
            syncTears();
        }
        if ((++tk) % 2) return;
        Object.keys(SHOWN).forEach(function (k) {
            var t = SHOWN[k], dx = RPG.player.x - t.x, dz = RPG.player.z - t.z;
            if (dx * dx + dz * dz > 48 * 48) return;
            var halloween = String(t.look || "").toLowerCase() === "halloween";
            for (var i = 0; i < 2; i++) RPG.particle(halloween ? "minecraft:soul" : "minecraft:portal", t.x + (Math.random() - 0.5) * 1.6, t.y + 0.5 + Math.random() * 2.6, t.z + (Math.random() - 0.5) * 1.6, 1, 0, 0.05);
            if (Math.random() < 0.08) RPG.particle(halloween ? "minecraft:sculk_soul" : "minecraft:dragon_breath", t.x, t.y + 1 + Math.random() * 2, t.z, 1, 0.4, 0.01);
        });
    });

    // ---- shared drawing: DmzTextures.panel (nine-sliced menubig) and the gold title strip ----
    function panel(ctx, x, y, w, h) {
        var b = 7, PW = 141, PH = 213;
        function q(sx, sy, sw, sh, dx, dy, dw, dh) { ctx.quad(MENU_BIG, dx, dy, dw, dh, sx / 256, sy / 256, (sx + sw) / 256, (sy + sh) / 256, "#FFFFFF", 1); }
        q(0, 0, b, b, x, y, b, b); q(PW - b, 0, b, b, x + w - b, y, b, b); q(0, PH - b, b, b, x, y + h - b, b, b); q(PW - b, PH - b, b, b, x + w - b, y + h - b, b, b);
        q(b, 0, PW - 2 * b, b, x + b, y, w - 2 * b, b); q(b, PH - b, PW - 2 * b, b, x + b, y + h - b, w - 2 * b, b);
        q(0, b, b, PH - 2 * b, x, y + b, b, h - 2 * b); q(PW - b, b, b, PH - 2 * b, x + w - b, y + b, b, h - 2 * b);
        q(b, b, PW - 2 * b, PH - 2 * b, x + b, y + b, w - 2 * b, h - 2 * b);
    }
    function title(ctx, cx, y, text) {
        // the plate grows to fit a long title (its 20 px ends kept, the middle stretched), up to 300 px
        var t = U.ellipsis(ctx, "§l" + text, 280), w = Math.max(107, Math.ceil(U.width(ctx, t)) + 20), x = Math.round(cx - w / 2);
        if (w <= 107) ctx.image(MENU_BIG, cx - 54, y, 107, 21, 142, 22, 107, 21, 256, 256);
        else {
            ctx.image(MENU_BIG, x, y, 20, 21, 142, 22, 20, 21, 256, 256);
            ctx.image(MENU_BIG, x + 20, y, w - 40, 21, 162, 22, 67, 21, 256, 256);
            ctx.image(MENU_BIG, x + w - 20, y, 20, 21, 229, 22, 20, 21, 256, 256);
        }
        U.bordered(ctx, t, cx, y + 7, "#FFD700", 0.5);
    }
    function btn(id, x, y, w, h, label, onClick, extra) {
        var b = { id: id, type: "button", anchor: "center", x: x, y: y, w: w, h: h || 18, texture: BUTTONS, texW: 256, texH: 256, u: 0, v: 28, uw: 74, vh: 20, hoverU: 0, hoverV: 48, slice: 4,
            label: label, font: FONT, onClick: onClick };
        for (var k in extra || {}) b[k] = extra[k];
        return b;
    }

    // ---- RaidSignupScreen ----
    var SG = null;
    var STATE_LABEL = ["No raid running", "Raid starting", "Raid starting", "Boss fight in progress", "Raid finished"];
    RPG.net.on("dbr_raid_open_signup", function (d) { openSignup(d); });
    function openSignup(d) {
        SG = d;
        function act(a) { return function () { RPG.net.send("dbr_raid_signup_action", { id: d.id, action: a }); if (a !== "status") RPG.screen.close(); }; }
        var els = [
            btn("join", -65, -32, 130, 18, "Sign Up", act("join"), { disabled: !d.open || d.signedUp }),
            btn("leave", -65, -8, 130, 18, "Withdraw", act("leave"), { disabled: !d.signedUp }),
            btn("tp", -65, 16, 130, 18, "To Arena", act("tp")),
            btn("status", -65, 40, 130, 18, "Raid Status", act("status"))
        ];
        if (d.party > 1) els.push(btn("party", -65, 64, 130, 18, "Sign Up Party (" + d.party + ")", act("party"), { disabled: !d.open, tooltip: "Sign up every online member of your party" }));
        els.push(btn("close", -65, d.party > 1 ? 92 : 68, 130, 18, "Close", function () { RPG.screen.close(); }));
        RPG.screen.open({ id: "dbr_raid_signup", referenceHeight: 300, background: "dim", elements: els, onBackground: function (ctx) {
            if (!SG) return;
            var cx = ctx.width / 2, cy = ctx.height / 2, x = cx - 95, y = cy - 100;
            panel(ctx, x, y, 190, 210);
            title(ctx, cx, y + 6, U.strip(SG.name.replace(/&([0-9a-fk-or])/gi, "§$1")));
            var st = SG.open ? "§aSign-ups are OPEN" : "§7" + (STATE_LABEL[SG.state] || STATE_LABEL[0]);
            U.bordered(ctx, st, cx, y + 36, "#FFFFFF", 0.5);
            U.bordered(ctx, "§fFighters signed up: §e" + SG.count, cx, y + 48, "#FFFFFF", 0.5);
            U.drawStatus(ctx, cx, y + 196);
        }, onClose: function () { SG = null; } });
    }

    // ---- RaidBrowserScreen ----
    var BR = null, COLLAPSED = {};
    var BSTATE = ["§7Idle", "§aSign-ups open", "§eStarting", "§cIn progress", "§7Finishing"];
    RPG.net.on("dbr_raid_open_browser", function (d) { openBrowser((d && d.entries) || []); });
    function openBrowser(entries) {
        var groups = {};
        entries.forEach(function (e) { (groups[e.category] = groups[e.category] || []).push(e); });
        Object.keys(groups).forEach(function (g) { groups[g].sort(function (a, b) { return U.strip(a.name).toLowerCase() < U.strip(b.name).toLowerCase() ? -1 : 1; }); });
        BR = { groups: groups, scroll: 0, rows: [] };
        RPG.screen.open({ id: "dbr_raid_browser", referenceHeight: 300, background: "dim",
            elements: [btn("close", -45, 104, 90, 18, "Close", function () { RPG.screen.close(); })],
            onBackground: renderBrowser, onMouse: mouseBrowser, onScroll: function (x, y, d) { if (BR) BR.scroll = Math.max(0, BR.scroll - (d > 0 ? 1 : -1)); }, onClose: function () { BR = null; } });
    }
    function browserRows() {
        var out = [];
        Object.keys(BR.groups).sort(function (a, b) { return a.toLowerCase() < b.toLowerCase() ? -1 : 1; }).forEach(function (g) {
            out.push({ header: true, cat: g });
            if (!COLLAPSED[g]) BR.groups[g].forEach(function (e) { out.push({ header: false, cat: g, e: e }); });
        });
        return out;
    }
    var ROW = 16, VIS = 11;
    function renderBrowser(ctx) {
        if (!BR) return;
        var cx = ctx.width / 2, cy = ctx.height / 2, x = cx - 150, y = cy - 120, rows = browserRows();
        panel(ctx, x, y, 300, 250);
        title(ctx, cx, y + 6, "Raid Bosses");
        BR.scroll = Math.min(BR.scroll, Math.max(0, rows.length - VIS));
        BR.x = x; BR.y = y; BR.rows = rows;
        if (!rows.length) U.bordered(ctx, "§7No raids are available right now.", cx, y + 50, "#FFFFFF", 0.5);
        for (var i = 0; i < VIS && i + BR.scroll < rows.length; i++) {
            var r = rows[i + BR.scroll], ry = y + 32 + i * ROW, hov = U.inside(ctx.mouseX, ctx.mouseY, x + 12, ry, 276, ROW - 2);
            if (r.header) {
                ctx.fill(x + 12, ry, 276, ROW - 2, "#FFFFFF", hov ? 0.19 : 0.11);
                U.bordered(ctx, (COLLAPSED[r.cat] ? "§7▶ " : "§e▼ ") + "§l" + r.cat.replace(/&([0-9a-fk-or])/gi, "§$1") + " §8(" + BR.groups[r.cat].length + ")", x + 18, ry + 4, "#FFD700", 0);
            } else {
                if (hov) ctx.fill(x + 12, ry, 276, ROW - 2, "#FFFFFF", 0.06);
                U.bordered(ctx, U.ellipsis(ctx, "§f" + r.e.name.replace(/&([0-9a-fk-or])/gi, "§$1") + " §8· §7" + DBR_RAIDS_DATA.TYPE_LABELS[r.e.type], 130), x + 24, ry + 4, "#FFFFFF", 0);
                U.bordered(ctx, BSTATE[r.e.state] || BSTATE[0], x + 172, ry + 4, "#FFFFFF", 0);
                var jx = x + 244, jh = U.inside(ctx.mouseX, ctx.mouseY, jx, ry, 44, ROW - 2);
                U.buttonArt(ctx, jx, ry, 44, ROW - 2, jh);
                U.bordered(ctx, "Join", jx + 22, ry + 3, jh ? "#FFFFA0" : "#FFFFFF", 0.5);
            }
        }
        if (rows.length > VIS) {
            var th = Math.max(12, VIS * ROW * VIS / rows.length), ty = y + 32 + (VIS * ROW - th) * BR.scroll / (rows.length - VIS);
            ctx.fill(x + 290, y + 32, 2, VIS * ROW, "#000000", 0.35); ctx.fill(x + 290, ty, 2, th, "#D2D7F1", 1);
        }
    }
    function mouseBrowser(mx, my, button, action) {
        if (!BR || action !== "down" || button !== 0) return;
        for (var i = 0; i < VIS && i + BR.scroll < BR.rows.length; i++) {
            var r = BR.rows[i + BR.scroll], ry = BR.y + 32 + i * ROW;
            if (!U.inside(mx, my, BR.x + 12, ry, 276, ROW - 2)) continue;
            if (r.header) { COLLAPSED[r.cat] = !COLLAPSED[r.cat]; RPG.sound("dmzpack:pip_menu", 1, 1); return false; }
            if (U.inside(mx, my, BR.x + 244, ry, 44, ROW - 2)) { RPG.sound("dmzpack:pip_menu", 1, 1); RPG.net.send("dbr_raid_req", { what: "signup", id: r.e.id }); return false; }
        }
    }

    RPG.on("load", function () { RPG.hud.onRender(drawBar); });
    return { panel: panel, title: title, btn: btn, BUTTONS: BUTTONS, MENU_BIG: MENU_BIG };
})();
