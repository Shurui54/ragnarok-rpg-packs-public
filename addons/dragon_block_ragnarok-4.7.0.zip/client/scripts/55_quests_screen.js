// =====================================================================================
//  DMZ QuestTreeScreen: the saga tree (pan with the mouse, scroll to zoom), the saga /
//  quest navigator on the left, the quest sheet on the right (status, rewards,
//  description, objectives and requirements, Start / Claim / Track), Claim All, the
//  difficulty picker and DMZ's story toasts. Quest state comes from the server
//  (scripts/47_dmz_quests.js, "dmz_quests_state"); the quests are DMZ's own data.
// =====================================================================================
var DMZ_QUEST_NAMES = (function () {
    var U = DMZ_UI, QL = DMZ_QL;
    function title(e) { return e ? U.tr(e.quest.title) : "?"; }
    function label(key) { var e = QL.entry(key); return e ? title(e) : U.humanize(key); }
    /** SkillsMenuScreen.getQuestsGrantingForm */
    function grantingSkill(skill, level) {
        var out = [];
        QL.SAGA_LIST.forEach(function (s) {
            s.quests.forEach(function (q, i) {
                (q.rewards || []).forEach(function (r) {
                    if (r.type === "SKILL" && String(r.skill).toLowerCase() === skill && r.level === level) {
                        var ref = U.tr("gui.dragonminez.skills.quest_ref", U.tr(s.name), i + 1);
                        if (out.indexOf(ref) < 0) out.push(ref);
                    }
                });
            });
        });
        QL.SIDE.forEach(function (q) {
            (q.rewards || []).forEach(function (r) {
                if (r.type === "SKILL" && String(r.skill).toLowerCase() === skill && r.level === level && out.indexOf(U.tr(q.title)) < 0) out.push(U.tr(q.title));
            });
        });
        return out;
    }
    return { title: title, label: label, grantingSkill: grantingSkill };
})();

var QUESTS_SCREEN = (function () {
    var U = DMZ_UI, QL = DMZ_QL, FONT = U.FONT, BUTTONS = U.BUTTONS;
    var NAV = "dmzpack:textures/gui/buttons/menubuttons.png";
    var EXCLAMATION = "dmzpack:textures/gui/quest/exclamation_mark_quest.png", REWARD_GENERIC = "dmzpack:textures/gui/quest/reward_generic.png";
    var NODE = 18, SX = 55, SY = 45, HEADER_H = 15, ROW_H = 13, LINE = 10;
    var ITEM_TEX = {};
    (QL.DATA.itemTex || []).forEach(function (i) { ITEM_TEX[i] = 1; });
    var CATALOG = [["classic_saga", "Classic Saga"], ["saiyan_saga", "Saiyan Saga"], ["frieza_saga", "Frieza Saga"], ["android_saga", "Cell Saga"],
        ["future_saga", "Future Saga"], ["buu_saga", "Buu Saga"], ["movies_saga", "Movies Saga"], ["daima_saga", "Daima Saga"], ["gt_saga", "GT Saga"]];   // DMZ's "coming soon" sagas (Beerus, RoF, U7vsU6) are left out until they have quests
    /** DMZ's sagas, then the custom ones from the saga editor (69_saga_editor.js) */
    function catalog() {
        var known = {};
        CATALOG.forEach(function (c) { known[c[0]] = 1; });
        return CATALOG.concat(QL.SAGA_LIST.filter(function (s) { return !known[s.id]; }).map(function (s) { return [s.id, s.label || U.tr(s.name)]; }));
    }
    var STRUCTURES = { "dragonminez:goku_house": "Goku's House", "dragonminez:roshi_house": "Kame House", "dragonminez:elder_guru": "Guru's House",
        "dragonminez:timechamber": "Hyperbolic Time Chamber", "dragonminez:kamilookout": "Kami's Lookout", "dragonminez:gero_lab": "Dr. Gero's Laboratory",
        "dragonminez:village_ajissa": "Ajissa Village", "dragonminez:village_sacred": "Sacred Village" };
    var DIMENSIONS = { "minecraft:overworld": "Earth", "minecraft:the_nether": "Nether", "minecraft:the_end": "The End", "dragonminez:namek": "Namek",
        "dragonminez:time_chamber": "Hyperbolic Time Chamber" };
    var DIFF_LABEL = { EASY: "gui.dragonminez.quest_tree.difficulty.easy", NORMAL: "gui.dragonminez.quest_tree.difficulty.normal", HARD: "gui.dragonminez.quest_tree.difficulty.hard" };
    var DIFF_COLOR = { EASY: ["#66BB66", "#88DD88"], NORMAL: ["#EEDD55", "#FFFF88"], HARD: ["#FF5555", "#FF8080"] };
    var STATUS_COLOR = { COMPLETED: "#00FF00", CLAIMABLE: "#FFAA00", ACTIVE: "#3399FF", AVAILABLE: "#FFCC00", LOCKED: "#888888" };

    var data = { q: {}, d: null, resets: 0, tr: null, skills: {}, alignment: 100, dim: "" };
    var st = null, resummonAt = {}, sagaIndex = 0, persistKey = null;

    function view() {
        return { q: data.q, d: data.d, resets: data.resets, skill: function (s) { return data.skills[s] || 0; }, level: RPG.player.level,
            alignment: data.alignment, race: DMZ_DATA.DMZ[RPG.player.race] || RPG.player.race, cls: RPG.player.playerClass };
    }

    // ---- names (QuestTextFormatter) ----
    function trOr(key, fallback) { return U.hasTr(key) ? U.tr(key) : fallback; }
    function pathOf(id) { var v = String(id || "").replace(/^#/, ""), c = v.indexOf(":"); return c >= 0 ? v.substring(c + 1) : v; }
    function entityName(id) {
        if (String(id).charAt(0) === "#") return trOr("entity.dragonminez.tag." + pathOf(id), U.humanize(id));
        var ns = String(id).split(":")[0];
        return trOr("entity." + ns + "." + pathOf(id), U.humanize(id));
    }
    function itemName(id) {
        var ns = String(id).split(":")[0], p = pathOf(id);
        return trOr("item." + ns + "." + p, trOr("block." + ns + "." + p, U.humanize(id)));
    }
    function npcName(id) {
        var n = pathOf(id), base = n.replace(/_\d+$/, "");
        return trOr("entity.dragonminez.questnpc." + n, trOr("gui.dragonminez.lines." + n + ".name",
            trOr("entity.dragonminez.questnpc." + base, trOr("gui.dragonminez.lines." + base + ".name", U.humanize(n)))));
    }
    function skillName(s) { var n = pathOf(s); return trOr(n.indexOf(".") >= 0 ? n : "skill.dragonminez." + n.toLowerCase(), U.humanize(n)); }
    function biomeName(b) {
        if (b === "#dragonminez:is_plains") return U.tr("gui.dragonminez.quests.biome.any_plains");
        if (String(b).charAt(0) === "#") return U.humanize(b);
        if (String(b).indexOf("minecraft:") === 0) return U.tr("biome.minecraft." + pathOf(b));
        return U.humanize(b);
    }
    function dimName(d) { return DIMENSIONS[d] || U.humanize(d); }
    function structureName(s) { return STRUCTURES[s] || U.humanize(s); }

    function describeObjective(o) {
        switch (o.type) {
            case "SPAR": return U.tr("dmz.quest.spar.obj", entityName(o.entity));
            case "KILL": return U.tr("dmz.quest.defeat.obj", entityName(o.entity));
            case "SURVIVE_WAVES": return U.tr("dmz.quest.waves.obj", o.waves, entityName(o.entity));
            case "ITEM": return U.tr("dmz.quest.obtain.obj", itemName(o.item));
            case "TALK_TO": return U.tr("dmz.quest.talk_to.obj", npcName(o.npcId));
            case "DRAGON_SUMMON": return U.tr("dmz.quest.summon_dragon.obj", o.dragon ? entityName(o.dragon.indexOf(":") >= 0 ? o.dragon : "dragonminez:" + o.dragon) : "the dragon");
            case "SKILL": return U.tr("dmz.quest.skill.obj", skillName(o.skill), o.level);
            case "STRUCTURE": return U.tr("dmz.quest.go_to.obj", structureName(o.structure));
            case "BIOME": return U.tr("dmz.quest.go_to.obj", biomeName(o.biome));
            case "DIMENSION": return U.tr("dmz.quest.go_to.obj", dimName(o.dimension));
            case "DELIVER": return U.tr("dmz.quest.deliver.obj", itemName(o.item), npcName(o.npcId));
            case "COORDS": return "Go to " + o.x + ", " + o.y + ", " + o.z;
            default: return U.humanize(o.type);
        }
    }
    function fmtSeconds(t) {
        t = Math.max(1, Math.floor(t));
        var h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = t % 60;
        if (h > 0) return m > 0 ? h + "h " + m + "m" : h + "h";
        if (m > 0) return s > 0 ? m + "m " + s + "s" : m + "m";
        return s + "s";
    }
    function describeRequirement(c, key) {
        switch (c.type) {
            case "SAGA_QUEST": var e = QL.entry(c.sagaId + ":" + c.questId); return U.tr("gui.dragonminez.quests.requirement.complete_saga", e ? DMZ_QUEST_NAMES.title(e) : U.humanize(c.sagaId) + " " + c.questId);
            case "QUEST": return U.tr("gui.dragonminez.quests.requirement.complete_quest", DMZ_QUEST_NAMES.label(c.questId));
            case "STAT": return U.tr("gui.dragonminez.quests.requirement.stat", c.minValue, U.humanize(c.stat));
            case "LEVEL": return U.tr("gui.dragonminez.quests.requirement.level", c.minLevel);
            case "BIOME": return U.tr("gui.dragonminez.quests.requirement.biome", biomeName(c.biome));
            case "STRUCTURE": return U.tr("gui.dragonminez.quests.requirement.structure", structureName(c.structure));
            case "DIMENSION": return U.tr("gui.dragonminez.quests.requirement.dimension", dimName(c.dimension));
            case "SKILL": return U.tr("gui.dragonminez.quests.requirement.skill", skillName(c.skill), c.minLevel);
            case "ALIGNMENT":
                if (c.min !== undefined && c.max !== undefined) return U.tr("gui.dragonminez.quests.requirement.alignment_range", c.min, c.max);
                if (c.min !== undefined) return U.tr("gui.dragonminez.quests.requirement.alignment_min", c.min);
                if (c.max !== undefined) return U.tr("gui.dragonminez.quests.requirement.alignment_max", c.max);
                return U.tr("gui.dragonminez.quests.requirement.alignment");
            case "TIME":
                var real = c.mode === "REAL_TIME", dur = real ? (c.milliseconds || 0) / 1000 : (c.ticks || 0) / 20;
                var base = U.tr(real ? "gui.dragonminez.quests.requirement.time_real" : "gui.dragonminez.quests.requirement.time_game", fmtSeconds(dur));
                var r = QL.rec(data, key), t = r && r.t;
                if (t && real) {
                    var left = dur - (Date.now() - t.r) / 1000;
                    return base + " (" + (left > 0 ? U.tr("gui.dragonminez.quests.requirement.remaining", fmtSeconds(left)) : U.tr("gui.dragonminez.quests.requirement.ready")) + ")";
                }
                return base;
            default: return U.humanize(c.type);
        }
    }

    // ---- rewards ----
    function rewardAmount(key, r) { return Math.round((r.amount || 0) * QL.rewardMultiplier(data, key, r)); }
    function rewardText(key, r) {
        var m = QL.rewardMultiplier(data, key, r);
        switch (r.type) {
            case "ATTRIBUTES": return U.tr("gui.dragonminez.quests.rewards.attributes", rewardAmount(key, r));
            case "ATTRIBUTE_POINTS": return U.tr("gui.dragonminez.quests.rewards.attribute_points", rewardAmount(key, r));
            case "TPS": return U.tr("gui.dragonminez.quests.rewards.tps", rewardAmount(key, r));
            case "ITEM": return U.tr("gui.dragonminez.quests.rewards.item", Math.max(1, Math.round((r.count || 1) * m)), itemName(r.item));
            case "SKILL": return U.tr("gui.dragonminez.quests.rewards.skill", skillName(r.skill), r.level);
            case "ALIGNMENT": return U.tr("gui.dragonminez.quests.rewards.alignment", r.amount);
            case "COMMAND": return r.translationKey ? U.tr(r.translationKey) : "/" + r.command;
            case "TECHNIQUE": case "KI_TECHNIQUE": var tid = String(r.technique || r.id || ""); return "Technique: " + trOr("technique.dragonminez." + tid, U.humanize(tid));
            case "FORM_PURCHASE": return "Unlocks buying " + U.humanize(String(r.form || "").replace(".", " "));
            default: return U.humanize(r.type);
        }
    }
    function rewardTooltip(key, r) {
        var lines = [[rewardText(key, r), "#FFFFFF"]];
        if (r.type === "ATTRIBUTES") {
            var attrs = rewardAmount(key, r), points = Math.floor(attrs * 0.5), p = RPG.player, c = DMZ_DATA.CLASSES[p.playerClass] || DMZ_DATA.CLASSES.warrior;
            var total = 0;
            DMZ_DATA.STATS.forEach(function (k) { total += p.stat(DMZ_DATA.STAT_IDS[k]); });
            var tp = DMZ_F.cost(total + p.statPoints + points, attrs - points, c.tpCost);
            lines.push([U.tr("gui.dragonminez.quests.rewards.attributes.breakdown", points, attrs - points), "#AAAAAA"]);
            lines.push([U.tr("gui.dragonminez.quests.rewards.attributes.tp_now", DMZ_F.sci(tp)), "#55FFFF"]);
        }
        return lines;
    }
    function drawRewardIcon(ctx, r, x, y) {
        var tex = { ATTRIBUTES: "gete_yellow_capsule", TPS: "red_capsule", ATTRIBUTE_POINTS: "gete_purple_capsule", SKILL: "gete_blue_capsule" }[r.type];
        if (r.type === "ITEM") {
            if (String(r.item).indexOf("minecraft:") === 0) { ctx.item(r.item, x, y); return; }
            if (ITEM_TEX[pathOf(r.item)]) tex = pathOf(r.item);
        }
        if (tex) ctx.image("dmzpack:textures/item/" + tex + ".png", x, y, 16, 16, 0, 0, 16, 16, 16, 16);
        else ctx.image(REWARD_GENERIC, x, y, 16, 16, 0, 0, 16, 16, 16, 16);
    }

    // ---- layout (QuestTreeLayoutHelper.computeLayout) ----
    function sideKey(q) { return q.id; }
    function computeLayout(saga) {
        var nodes = [], conns = [], sagaNode = {}, occupied = {};
        saga.quests.forEach(function (q, i) {
            var n = { e: QL.entry(saga.id + ":" + q.id), col: i, row: 0, side: false };
            nodes.push(n); sagaNode[q.id] = n; occupied[i + ":0"] = 1;
        });
        saga.quests.forEach(function (q, i) {
            var from = null;
            ((q.prerequisites && q.prerequisites.conditions) || []).forEach(function (c) {
                if (!from && c.type === "SAGA_QUEST" && c.sagaId === saga.id && sagaNode[c.questId]) from = sagaNode[c.questId];
            });
            if (!from && i > 0) from = sagaNode[saga.quests[i - 1].id];
            if (from) conns.push([from, sagaNode[q.id]]);
        });
        var sideNode = {}, sideDir = {}, nextDir = {};
        var sorted = QL.SIDE.filter(function (q) { return !q.secret && QL.belongsToSaga(q, saga.id); })
            .sort(function (a, b) { return a.id < b.id ? -1 : a.id > b.id ? 1 : 0; });
        sorted.forEach(function (sq) {
            var conds = (sq.prerequisites && sq.prerequisites.conditions) || [], parent = null, attach = -1, i;
            for (i = 0; i < conds.length && !parent; i++) if (conds[i].type === "QUEST" && sideNode[conds[i].questId]) parent = sideNode[conds[i].questId];
            for (i = 0; i < conds.length && !parent; i++) if (conds[i].type === "SAGA_QUEST" && conds[i].sagaId === saga.id) parent = sagaNode[conds[i].questId] || null;
            for (i = 0; i < conds.length && attach < 0; i++) {
                if (conds[i].type === "SAGA_QUEST" && conds[i].sagaId === saga.id && sagaNode[conds[i].questId]) attach = sagaNode[conds[i].questId].col;
                if (conds[i].type === "QUEST" && sideNode[conds[i].questId]) attach = sideNode[conds[i].questId].col;
            }
            if (attach < 0) attach = 0;
            var anchor = parent ? (parent.side ? parent.e.key : parent.e.key) : "saga:" + attach, dir;
            if (parent && parent.side) dir = sideDir[anchor] || 1;
            else { dir = nextDir[anchor] || 1; nextDir[anchor] = -dir; }
            var col, row;
            if (parent) { col = parent.col + 1; row = parent.row + dir; }
            else { col = attach + 1; row = dir; }
            while (occupied[col + ":" + row]) row += dir;
            var n = { e: QL.entry(sq.id), col: col, row: row, side: true };
            nodes.push(n); occupied[col + ":" + row] = 1;
            sideNode[sq.id] = n; sideDir[sq.id] = dir;
            if (parent) conns.push([parent, n]);
        });
        var secret = QL.SIDE.filter(function (q) { return q.secret && QL.belongsToSaga(q, saga.id); }).sort(function (a, b) { return a.id < b.id ? -1 : 1; });
        if (secret.length) {
            var lowest = 0;
            nodes.forEach(function (n) { lowest = Math.max(lowest, n.row); });
            secret.forEach(function (sq, c) {
                var row = lowest + 2;
                while (occupied[c + ":" + row]) row++;
                nodes.push({ e: QL.entry(sq.id), col: c, row: row, side: true, secret: true }); occupied[c + ":" + row] = 1;
            });
        }
        var minRow = 0;
        nodes.forEach(function (n) { minRow = Math.min(minRow, n.row); });
        nodes.forEach(function (n) { n.x = n.col * SX; n.y = (n.row - minRow) * SY; });
        return { nodes: nodes, conns: conns };
    }

    function currentSaga() { return QL.SAGA_LIST[sagaIndex] || QL.SAGA_LIST[0]; }

    // ---- visibility / status ----
    var cache = { vis: {}, st: {}, at: 0, secrets: {} };
    function fresh_cache() { cache.vis = {}; cache.st = {}; cache.at = RPG.nowMs(); }
    function visibility(e) {
        if (RPG.nowMs() - cache.at > 2000) fresh_cache();
        var c = cache.vis[e.key];
        if (c === undefined) c = cache.vis[e.key] = computeVisibility(e);
        return c;
    }
    function computeVisibility(e) {
        var v = view(), s = QL.status(v, e.key);
        if (s === QL.COMPLETED || s === QL.ACCEPTED || s === QL.FAILED) return "VISIBLE";
        if (!e.side) return QL.isSagaQuestAvailable(e, v) ? "VISIBLE" : "BLURRED";
        if (e.quest.secret) return "HIDDEN";
        return QL.isAvailable(e.quest, v) ? "VISIBLE" : "BLURRED";
    }
    function status(e) {
        var c = cache.st[e.key];
        if (c === undefined) c = cache.st[e.key] = QL.nodeStatus(e, view());
        return c;
    }
    function reachable(e) { return visibility(e) === "VISIBLE" && status(e) !== "LOCKED"; }
    function statusText(s) {
        return { COMPLETED: ["gui.dragonminez.quests.status.complete", "#00AA00"], CLAIMABLE: ["gui.dragonminez.quests.claim_rewards", "#FFAA00"],
            ACTIVE: ["gui.dragonminez.quest_tree.status.active", "#55FFFF"], AVAILABLE: ["gui.dragonminez.quest_tree.status.available", "#55FF55"],
            LOCKED: ["gui.dragonminez.quest_tree.status.locked", "#FF5555"] }[s];
    }

    // ---- open ----
    function fresh() {
        return { layout: null, selected: null, pan: [0, 0], target: null, zoom: 1, drag: null, last: RPG.nowMs(), leftT: 0, rightT: 0,
            navScroll: 0, rewScroll: 0, objScroll: 0, descScroll: 0, collapsed: false, expanded: {}, rects: {}, pendingClose: null, lastClick: 0 };
    }
    function open() {
        st = fresh();
        var els = [];
        var nav = [[-110, 120, "party"], [-70, 0, "stats"], [-30, 20, "skills"], [10, 60, "quests"], [50, 140, "minigames"], [90, 100, "config"]];
        nav.forEach(function (n) {
            els.push({ id: "nav_" + n[2], type: "button", anchor: "bottom", x: n[0], y: -30, w: 20, h: 20, texture: NAV, texW: 256, texH: 256,
                u: n[1], v: 0, uw: 20, vh: 20, hoverU: n[1], hoverV: 20, tooltip: n[2].charAt(0).toUpperCase() + n[2].slice(1),
                onClick: function () { navigate(n[2]); } });
        });
        if (data.op) els.push({ id: "saga_editor", type: "button", anchor: "top", x: -37, y: 0, w: 74, h: 18, texture: BUTTONS, texW: 256, texH: 256,
            u: 0, v: 28, uw: 74, vh: 20, hoverU: 0, hoverV: 48, label: "Saga Editor", font: FONT, tooltip: "Operators: edit custom sagas and side quests",
            onClick: function () { RPG.sound("dmzpack:pip_menu", 1, 1); RPG.net.send("dbr_saga", { action: "open" }); } });
        RPG.screen.open({ id: "dmz_quests", referenceHeight: DMZ_OPTS.menuRef(), background: "dim", elements: els, onRender: render, onMouse: mouse, onScroll: scroll,
            onClose: function () { if (st && st.selected) persistKey = st.selected.key; st = null; } });
        rebuild(true);
    }
    function navigate(where) {
        RPG.sound("dmzpack:ui_menu_switch", 1, 1);
        if (where === "quests") return;
        RPG.net.send("dmz_menu", { tab: where });
    }
    function rebuild(center) {
        st.layout = computeLayout(currentSaga());
        if (persistKey) {
            var n = findNode(persistKey);
            if (n) st.selected = n.e;
            persistKey = null;
        }
        if (center) st.needCenter = true;
    }
    function findNode(key) {
        if (!st.layout) return null;
        for (var i = 0; i < st.layout.nodes.length; i++) if (st.layout.nodes[i].e.key === key) return st.layout.nodes[i];
        return null;
    }
    // QuestTreeScreen.centerViewOnProgress
    function centerOnProgress(W, H) {
        var saga = currentSaga(), target = null, v = view();
        for (var i = 0; i < saga.quests.length; i++) {
            target = findNode(saga.id + ":" + saga.quests[i].id);
            if (!QL.completed(v, saga.id + ":" + saga.quests[i].id)) break;
        }
        if (!target && st.layout.nodes.length) target = st.layout.nodes[0];
        st.zoom = 1;
        if (target) st.pan = [W / 2 - target.x - NODE / 2, H / 2 - target.y - NODE / 2];
    }
    function slideTo(n) { st.target = [st.W / 2 - n.x * st.zoom - NODE / 2 * st.zoom, st.H / 2 - n.y * st.zoom - NODE / 2 * st.zoom]; }

    // ---- panels ----
    function baseLeft(W, H) { var w = Math.max(140, Math.floor(W / 3 * 0.9)), h = Math.min(H, Math.max(120, Math.floor(H * 0.9))); return [0, Math.max(0, Math.floor((H - h) / 2)), w, h]; }
    function baseRight(W, H) { var r = baseLeft(W, H); return [W - r[2], r[1], r[2], r[3]]; }
    function leftRect() { var b = baseLeft(st.W, st.H); return [b[0] + Math.floor(-(1 - U.ease(st.leftT)) * Math.max(0, b[2] - 24)), b[1], b[2], b[3]]; }
    function rightRect() { var b = baseRight(st.W, st.H); return [b[0] + Math.floor((1 - U.ease(st.rightT)) * b[2]), b[1], b[2], b[3]]; }
    function inRect(x, y, r) { return x >= r[0] && y >= r[1] && x < r[0] + r[2] && y < r[1] + r[3]; }

    // ---- navigator entries (rebuildNavigatorEntries) ----
    function sideBranches(saga) {
        if (st.layout.branches) return st.layout.branches;
        var by = st.layout.branches = {};
        st.layout.conns.forEach(function (c) {
            if (!c[1].side) return;
            (by[c[0].e.key] = by[c[0].e.key] || []).push(c[1].e);
        });
        Object.keys(by).forEach(function (k) { by[k].sort(function (a, b) { return a.key < b.key ? -1 : 1; }); });
        return by;
    }
    function hasReachableBranch(br, key) {
        var kids = br[key];
        if (!kids) return false;
        for (var i = 0; i < kids.length; i++) if (reachable(kids[i]) || hasReachableBranch(br, kids[i].key)) return true;
        return false;
    }
    function navEntries() {
        var out = [], cur = currentSaga(), br = sideBranches(cur), v = view();
        function addSide(parentKey, depth) {
            (br[parentKey] || []).forEach(function (e) {
                if (!reachable(e)) return;
                out.push({ type: "side", depth: depth, e: e, expandable: hasReachableBranch(br, e.key) });
                if (st.expanded[e.key]) addSide(e.key, depth + 1);
            });
        }
        catalog().forEach(function (c) {
            var saga = QL.SAGAS[c[0]];
            if (!saga) return;                                    // no quests for it: not listed
            out.push({ type: "saga", id: c[0], label: c[1], saga: saga });
            if (saga === cur && !st.collapsed) {
                saga.quests.forEach(function (q) {
                    var e = QL.entry(saga.id + ":" + q.id);
                    if (!reachable(e)) return;
                    out.push({ type: "main", depth: 1, e: e, expandable: hasReachableBranch(br, e.key) });
                    if (st.expanded[e.key]) addSide(e.key, 2);
                });
                if (!cache.secrets[saga.id]) cache.secrets[saga.id] = QL.SIDE.filter(function (q) { return q.secret && QL.belongsToSaga(q, saga.id); });
                var secrets = cache.secrets[saga.id].filter(function (q) { return QL.status(v, q.id); });
                if (secrets.length) {
                    out.push({ type: "secrets", depth: 1, label: U.tr("gui.dragonminez.quest_tree.secret_sidequests") });
                    secrets.forEach(function (q) { out.push({ type: "side", depth: 2, e: QL.entry(q.id) }); });
                }
            }
        });
        return out;
    }
    function sagaCounter(saga) {
        var done = 0, v = view();
        saga.quests.forEach(function (q) { if (QL.completed(v, saga.id + ":" + q.id)) done++; });
        return done + "/" + saga.quests.length;
    }

    // ---- render ----
    function render(ctx) {
        if (!st) return;
        var W = ctx.width, H = ctx.height, mx = ctx.mouseX, my = ctx.mouseY, now = RPG.nowMs(), dt = Math.min(0.1, (now - st.last) / 1000);
        st.last = now; st.W = W; st.H = H;
        if (st.needCenter && st.layout) { centerOnProgress(W, H); st.needCenter = false; }
        if (st.drag) { st.pan = [st.drag.px + mx - st.drag.x, st.drag.py + my - st.drag.y]; st.target = null; }
        if (st.target) {
            var a = 1 - Math.exp(-14 * dt);
            st.pan[0] += (st.target[0] - st.pan[0]) * a; st.pan[1] += (st.target[1] - st.pan[1]) * a;
            if (Math.abs(st.target[0] - st.pan[0]) < 0.35 && Math.abs(st.target[1] - st.pan[1]) < 0.35) { st.pan = st.target; st.target = null; }
        }
        var speed = 10 * dt, diffOpen = !data.d;
        st.leftT = U.approach(st.leftT, mx <= 36 || inRect(mx, my, leftRect()) ? 1 : 0, speed);
        st.rightT = U.approach(st.rightT, st.selected ? 1 : 0, speed);
        st.hoverReward = null;

        renderTree(ctx, W, H, mx, my, diffOpen);
        renderLeft(ctx, mx, my);
        renderRight(ctx, mx, my);
        if (st.selected) U.drawStatus(ctx, rightRect()[0] + rightRect()[2] / 2, rightRect()[1] + rightRect()[3] - 40);
        else U.drawStatus(ctx, W / 2, H - 48);
        if (diffOpen) renderDifficulty(ctx, W, H, mx, my);
        else if (st.tooltip) U.tooltip(ctx, st.tooltip[0], mx, my, st.tooltip[1]);
        st.tooltip = null;

        // DMZ closes the menu once a quest that summons an enemy has really started
        if (st.pendingClose && RPG.time() > st.pendingClose.until) st.pendingClose = null;
        if (st.pendingClose && QL.status(data, st.pendingClose.key) === QL.ACCEPTED) { st.pendingClose = null; RPG.screen.close(); }
    }

    function renderTree(ctx, W, H, mx, my, overlay) {
        var spacing = 20, ox = Math.floor(st.pan[0]) % spacing, oy = Math.floor(st.pan[1]) % spacing;
        for (var x = ox; x < W; x += spacing) ctx.fill(x, 0, 1, H, "#222244", 1);
        for (var y = oy; y < H; y += spacing) ctx.fill(0, y, W, 1, "#222244", 1);
        if (!st.layout) { U.bordered(ctx, U.tr("gui.dragonminez.quest_tree.no_sagas"), W / 2, H / 2, "#AAAAAA", 0.5); return; }
        var z = st.zoom, v = view();
        ctx.push();
        ctx.translate(st.pan[0], st.pan[1]);
        ctx.scale(z, z);
        st.layout.conns.forEach(function (c) {
            var fv = visibility(c[0].e), tv = visibility(c[1].e);
            if (fv === "HIDDEN" || tv === "HIDDEN") return;
            var color = QL.completed(v, c[0].e.key) && QL.completed(v, c[1].e.key) ? "#00AA00" : "#444444", alpha = 1;
            if (fv === "BLURRED" || tv === "BLURRED") { color = "#444444"; alpha = 0.33; }
            var x1 = c[0].x + NODE / 2, y1 = c[0].y + NODE / 2, x2 = c[1].x + NODE / 2, y2 = c[1].y + NODE / 2;
            if (y1 === y2) ctx.fill(Math.min(x1, x2) - 1, y1 - 1, Math.abs(x2 - x1) + 2, 2, color, alpha);
            else if (x1 === x2) ctx.fill(x1 - 1, Math.min(y1, y2) - 1, 2, Math.abs(y2 - y1) + 2, color, alpha);
            else {
                var len = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
                ctx.push(); ctx.translate(x1, y1); ctx.rotate(Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI);
                ctx.fill(0, -1, len, 2, color, alpha); ctx.pop();
            }
        });
        var zx = (mx - st.pan[0]) / z, zy = (my - st.pan[1]) / z, blocked = overlay || inRect(mx, my, leftRect()) || (st.selected && inRect(mx, my, rightRect())) || my > H - 34;
        st.hoverNode = null;
        st.layout.nodes.forEach(function (n) {
            var vis = visibility(n.e);
            if (vis === "HIDDEN") return;
            var sx = st.pan[0] + n.x * z, sy = st.pan[1] + n.y * z;
            if (sx + (NODE + 18) * z < 0 || sx - 18 * z > W || sy + (NODE + 20) * z < 0 || sy - 18 * z > H) return;
            var hov = !blocked && zx >= n.x && zx <= n.x + NODE && zy >= n.y && zy <= n.y + NODE;
            if (hov) st.hoverNode = n;
            renderNode(ctx, n, vis === "BLURRED", hov);
        });
        ctx.pop();
        if (st.hoverNode) nodeTooltip(st.hoverNode);
        U.bordered(ctx, "§l" + (currentSaga() ? CATALOG.filter(function (c) { return c[0] === currentSaga().id; })[0][1] : ""), W / 2, 8, "#FFD700", 0.5);
        U.bordered(ctx, Math.round(z * 100) + "%", 6, H - 12, "#888888");
        // difficulty indicator (bottom right)
        var diff = data.d || "NORMAL", lbl = U.tr("gui.dragonminez.quest_tree.difficulty.label"), stt = U.tr(DIFF_LABEL[diff]);
        var tw = U.width(ctx, lbl) + 3 + U.width(ctx, stt), dx = W - tw - 6, dy = H - 12, dh = U.inside(mx, my, dx, dy - 1, tw, 10);
        U.bordered(ctx, lbl, dx, dy, dh ? "#FFFFFF" : "#AAAAAA");
        U.bordered(ctx, stt, dx + U.width(ctx, lbl) + 3, dy, DIFF_COLOR[diff][0]);
        if (dh && data.d) {
            var dd = QL.DIFFICULTY[diff];
            st.tooltip = [[["§l" + U.tr("gui.dragonminez.quest_tree.difficulty.tooltip.title"), "#FFFFFF"],
                [U.tr("gui.dragonminez.quest_tree.difficulty.tooltip.current", stt), "#AAAAAA"],
                [U.tr("gui.dragonminez.quest_tree.difficulty.tooltip.desc"), "#AAAAAA"],
                [U.tr("gui.dragonminez.quest_tree.difficulty.tooltip.stats", fmtMult(dd.hp), fmtMult(dd.dmg)), "#55FFFF"],
                [U.tr("gui.dragonminez.quest_tree.difficulty.tooltip.rewards", fmtMult(dd.tp), fmtMult(dd.reward)), "#55FFFF"],
                [U.tr("gui.dragonminez.quest_tree.difficulty.tooltip.locked"), "#555555"]], "#FFFFFF"];
        }
        // Claim All
        st.rects.claimAll = null;
        if (anyClaimable()) {
            var bx = Math.floor((W - 74) / 2);
            U.button(ctx, U.tr("gui.dragonminez.quests.claim_all"), bx, 22, true);
            st.rects.claimAll = [bx, 22, 74, 20];
        }
    }
    function fmtMult(v) { return v === Math.round(v) ? String(v) : String(v); }

    function renderNode(ctx, n, blurred, hov) {
        var x = n.x, y = n.y, s = status(n.e), sel = st.selected && st.selected.key === n.e.key;
        var bg, border, icon, iconColor;
        if (blurred) { bg = ["#555555", 0.33]; border = ["#333333", 0.33]; icon = "?"; iconColor = ["#999999", 0.33]; }
        else {
            var t = { COMPLETED: ["#00CC00", "#009900", "§l✓", "#55FF55"], CLAIMABLE: ["#00CC00", "#009900", "§l✓", "#55FF55"], ACTIVE: ["#3399FF", "#2266CC", "§l!", "#FFFF00"],
                AVAILABLE: ["#FFCC00", "#CC9900", "?", "#FFFFFF"], LOCKED: ["#555555", "#333333", "§l✕", "#FF5555"] }[s];
            bg = [t[0], 1]; border = [t[1], 1]; icon = t[2]; iconColor = [t[3], 1];
        }
        if (sel && !blurred) ctx.fill(x - 2, y - 2, NODE + 4, NODE + 4, "#FFFFFF", 0.67);
        if (hov && !blurred) ctx.fill(x - 1, y - 1, NODE + 2, NODE + 2, "#FFFFFF", 0.4);
        ctx.fill(x, y, NODE, NODE, border[0], border[1]);
        ctx.fill(x + 1, y + 1, NODE - 2, NODE - 2, bg[0], bg[1]);
        ctx.textStyled(icon, x + NODE / 2, y + (NODE - 8) / 2, 1, iconColor[0], iconColor[1], 0.5, null, null);
        if (!blurred && n.side) {
            ctx.fill(x - 4, y - 4, 8, 8, "#6644AA", 1);
            ctx.textStyled("S", x - 3, y - 4, 1, "#FFFFFF", 1, 0, null, null);
        } else if (blurred) U.bordered(ctx, "???", x + NODE / 2, y + NODE + 2, "#888888", 0.5, 0.33);
        else U.bordered(ctx, String(n.col + 1), x + NODE / 2, y + NODE + 2, "#CCCCCC", 0.5);
        if (s === "CLAIMABLE" && !blurred) {
            var pulse = Math.sin(RPG.nowMs() / 350) * 0.5 + 0.5;
            ctx.quad(EXCLAMATION, x + NODE - 2, y - 11, 6, 15, 0, 0, 1, 1, "#FFFFFF", 0.3 + pulse * 0.7);
        }
    }

    function blockerLines(e, includeParty) {
        var v = view(), fail = e.quest.prerequisites ? QL.firstFailing(e.quest.prerequisites, v, null) : null, out = [];
        if (!e.side && e.index > 0 && !QL.completed(v, e.saga.id + ":" + e.saga.quests[e.index - 1].id))
            out.push([U.tr("gui.dragonminez.quests.requirement.complete_saga", DMZ_QUEST_NAMES.title(QL.entry(e.saga.id + ":" + e.saga.quests[e.index - 1].id))), "#FF5555"]);
        else if (fail) out.push([describeRequirement(fail, e.key), "#FF5555"]);
        return out;
    }
    function nodeTooltip(n) {
        var vis = visibility(n.e), lines;
        if (vis === "BLURRED") lines = [["§kUnknown Quest", "#888888"], [U.tr("gui.dragonminez.quest_tree.status.locked"), "#888888"]];
        else {
            var s = status(n.e), t = statusText(s);
            lines = [["§l" + DMZ_QUEST_NAMES.title(n.e), STATUS_COLOR[s]]];
            if (s === "CLAIMABLE" && n.e.quest.claim_mode === "NPC_ONLY") {
                lines.push([U.tr("gui.dragonminez.quests.claim_from_npc"), "#AAAAAA"]); lines.push([U.tr("gui.dragonminez.quests.claim_from_npc.tooltip"), "#AAAAAA"]);
            } else lines.push([U.tr(t[0]), t[1]]);
            if (s === "LOCKED") lines = lines.concat(blockerLines(n.e, false));
        }
        st.tooltip = [lines, vis === "BLURRED" ? "#888888" : STATUS_COLOR[status(n.e)]];
    }

    function anyClaimable() {
        var v = view();
        return Object.keys(data.q).some(function (k) {
            var e = QL.entry(k);
            return e && QL.status(v, k) === QL.COMPLETED && e.quest.claim_mode !== "NPC_ONLY" && QL.hasUnclaimed(v, e);
        });
    }

    function renderLeft(ctx, mx, my) {
        var r = leftRect(), x = r[0], y = r[1], w = r[2], h = r[3];
        U.QUEST_PANEL.draw(ctx, x - 3, y, w + 3, h);
        U.bordered(ctx, "§l" + U.tr("gui.dragonminez.quest_tree.title"), x + w / 2, y + 10, "#FFD700", 0.5);
        var lx = x + 10, ly = y + 28, lw = w - 20, lh = Math.max(32, h - 38), list = navEntries(), total = 0;
        list.forEach(function (e) { total += e.type === "saga" ? HEADER_H : ROW_H; });
        st.navScroll = Math.max(0, Math.min(st.navScroll, Math.max(0, total - lh)));
        st.navRows = [];
        var cy = ly - st.navScroll, cur = currentSaga(), hoverEntry = null;
        list.forEach(function (e) {
            var rh = e.type === "saga" ? HEADER_H : ROW_H, top = cy;
            cy += rh;
            if (top < ly - 1 || top + rh > ly + lh + 1) return;
            var hov = U.inside(mx, my, lx, top, lw, rh) && inRect(mx, my, r);
            if (hov) hoverEntry = e;
            st.navRows.push([lx, top, lw, rh, e]);
            var uw = lw - 6;
            if (e.type === "saga") {
                var unlocked = !e.placeholder && QL.sagaUnlocked(e.saga, view()), selected = !e.placeholder && e.saga === cur;
                ctx.fill(lx - 3, top + 1, uw + 3, HEADER_H - 2, "#FFFFFF", !unlocked ? 0.055 : hov ? 0.19 : 0.11);
                var counter = unlocked ? sagaCounter(e.saga) : "[L]", cw = U.width(ctx, counter);
                U.bordered(ctx, counter, lx + uw - 3 - cw, top + 3, unlocked ? "#9FB8AE" : "#666666");
                if (unlocked) arrow(ctx, lx + 3, top + 7.5, 0.55, selected && !st.collapsed ? 1 : 0, hov);
                var color = !unlocked ? (hov && e.soon ? "#AAAAAA" : e.placeholder ? "#666666" : "#888888") : hov ? "#7CFDD6" : selected ? "#FFD700" : "#FFFFFF";
                U.bordered(ctx, "§l" + U.ellipsis(ctx, e.label, Math.max(24, uw - 10 - cw - 12)), lx + 10, top + 3, color);
            } else if (e.type === "secrets") {
                var ind = e.depth * 10;
                ctx.fill(lx + ind - 3, top + 1, uw - ind + 3, ROW_H - 2, "#FFFFFF", hov ? 0.15 : 0.08);
                U.bordered(ctx, "§l" + U.ellipsis(ctx, e.label, Math.max(24, uw - ind - 8)), lx + ind, top + 2, hov ? "#FFE08A" : "#FFCC55");
            } else {
                var indent = e.depth * 10, tx = lx + indent;
                if (hov) ctx.fill(lx + indent - 3, top, uw - indent + 3, ROW_H - 1, "#FFFFFF", 0.086);
                if (e.expandable) { arrow(ctx, lx + indent + 2.5, top + 6, 0.45, st.expanded[e.e.key] ? 1 : 0, hov); tx += 8; }
                var label = e.e.side ? "- " + DMZ_QUEST_NAMES.title(e.e) : (e.e.index + 1) + ". " + DMZ_QUEST_NAMES.title(e.e);
                var c = STATUS_COLOR[status(e.e)];
                if (st.selected && st.selected.key === e.e.key) c = "#FFFFFF";
                if (hov) c = "#FFD070";
                U.bordered(ctx, U.ellipsis(ctx, label, Math.max(24, uw - (tx - lx) - 4)), tx, top + 2, c);
            }
        });
        if (total > lh) {
            var thumb = Math.max(10, lh * lh / total), ty = ly + (lh - thumb) * (st.navScroll / (total - lh));
            ctx.fill(lx + lw - 3, ly, 2, lh, "#000000", 0.4);
            ctx.fill(lx + lw - 3, ty, 2, thumb, "#FFFFFF", 0.7);
        }
        if (hoverEntry) {
            if (hoverEntry.soon) st.tooltip = [[["Coming soon... Follow development in Discord!", "#FFFFFF"]], "#5000FF"];
            else if (hoverEntry.type === "saga" && !hoverEntry.placeholder && !QL.sagaUnlocked(hoverEntry.saga, view()) && QL.SAGAS[hoverEntry.saga.prev])
                st.tooltip = [[[U.tr("gui.dragonminez.quest_tree.saga_locked.tooltip", (catalog().filter(function (c) { return c[0] === hoverEntry.saga.prev; })[0] || [0, hoverEntry.saga.prev])[1]), "#FFFFFF"]], "#5000FF"];
            else if (hoverEntry.type === "secrets") st.tooltip = [[[U.tr("gui.dragonminez.quest_tree.secret_sidequests.tooltip"), "#FFFFFF"]], "#5000FF"];
        }
    }
    function arrow(ctx, cx, cy, scale, progress, hov) {
        ctx.push(); ctx.translate(cx, cy); ctx.rotate(90 * U.ease(progress)); ctx.scale(scale, scale);
        ctx.image(BUTTONS, -4, -7, 8, 14, 20, hov ? 14 : 0, 8, 14, 256, 256);
        ctx.pop();
    }

    // ---- right panel (renderRightDetailPanel) ----
    function objectiveLines(ctx, e, width) {
        var lines = [], q = e.quest, v = view(), left = QL.timeLeft(data, e);
        if (left >= 0) lines.push(["Time left: " + fmtSeconds(left), left < 30 ? "#FF5555" : "#FFAA00"]);
        if (QL.status(v, e.key) === QL.COMPLETED && QL.isRepeatable(q) && QL.repeatLeft(data, e) > 0) lines.push(["Repeatable in " + fmtSeconds(QL.repeatLeft(data, e)), "#55FFFF"]);
        if (q.requirements && q.requirements.conditions && q.requirements.conditions.length) {
            lines.push([U.tr("gui.dragonminez.quests.requirements") + ":", "#CCCCCC"]);
            reqLines(ctx, lines, q.requirements, e.key, 0, width);
            if (q.objectives.length) lines.push([U.tr("gui.dragonminez.quests.objectives") + ":", "#CCCCCC"]);
        }
        q.objectives.forEach(function (o, i) {
            var cur = QL.progress(v, e.key, i), req = QL.required(o), ok = cur >= req;
            var text = describeObjective(o);
            if (o.type === "KILL" || o.type === "ITEM" || o.type === "DELIVER" || o.type === "SKILL") text += " (" + Math.min(cur, req) + "/" + req + ")";
            var wrapped = U.wrap(ctx, text, Math.max(12, width - 10));
            wrapped.forEach(function (l, j) { lines.push([(j === 0 ? (ok ? "+ " : "x ") : "  ") + l, "#CCCCCC", j === 0 ? (ok ? "#55FF55" : "#FF5555") : null]); });
        });
        return lines;
    }
    function reqLines(ctx, lines, group, key, depth, width) {
        if (!group || !group.conditions || !group.conditions.length) return;
        var indent = function (d) { return new Array(d + 1).join("  "); };
        if (depth > 0 || group.conditions.length > 1) {
            lines.push([indent(depth) + U.tr(group.operator === "OR" ? "gui.dragonminez.quests.requirements_any" : "gui.dragonminez.quests.requirements_all"), "#CCCCCC"]);
            depth++;
        }
        group.conditions.forEach(function (c) {
            if (c.conditions) { reqLines(ctx, lines, c, key, depth, width); return; }
            var w = U.wrap(ctx, describeRequirement(c, key), Math.max(12, width - U.width(ctx, indent(depth) + "- ")));
            w.forEach(function (l, j) { lines.push([(j === 0 ? indent(depth) + "- " : indent(depth + 1)) + l, "#CCCCCC", j === 0 ? "#FFFF00" : null]); });
        });
    }
    function section(ctx, x, y, w, h) { ctx.fill(x, y, w, h, "#111122", 0.27); ctx.fill(x, y, w, 1, "#444466", 0.53); ctx.fill(x, y + h - 1, w, 1, "#444466", 0.53); ctx.fill(x, y, 1, h, "#444466", 0.53); ctx.fill(x + w - 1, y, 1, h, "#444466", 0.53); }
    function scrollbar(ctx, x, y, h, total, offset) {
        if (total <= h) return;
        var thumb = Math.max(10, h * h / total), ty = y + (h - thumb) * (offset / (total - h));
        ctx.fill(x, y, 2, h, "#000000", 0.4); ctx.fill(x, ty, 2, thumb, "#FFFFFF", 0.7);
    }

    function renderRight(ctx, mx, my) {
        st.rects.action = null; st.rects.rew = st.rects.obj = st.rects.desc = null;
        if (st.rightT <= 0.001 && !st.selected) return;
        var r = rightRect(), px = r[0], py = r[1], pw = r[2], ph = r[3];
        U.QUEST_PANEL.draw(ctx, px, py, pw + 3, ph);
        var e = st.selected;
        if (!e) return;
        var x = px + 10, y = py + 10, w = pw - 20, totalH = ph - 40, q = e.quest, s = status(e);
        // title
        var titleLines = U.wrap(ctx, DMZ_QUEST_NAMES.title(e), w - 10).slice(0, 2);
        var titleH = Math.max(32, 16 + titleLines.length * LINE + 8);
        // rewards
        var shown = (q.rewards || []).map(function (rw, i) { return [rw, i]; }).filter(function (a) { return a[0].type !== "COMMAND"; });
        var rewBlocks = shown.map(function (a) { var lines = U.wrap(ctx, rewardText(e.key, a[0]), Math.max(20, w - 40)); return { r: a[0], i: a[1], lines: lines, h: Math.max(18, lines.length * LINE) + 4 }; });
        var rewContent = 0; rewBlocks.forEach(function (b) { rewContent += b.h; });
        var objLines = objectiveLines(ctx, e, w - 30), hasObj = objLines.length > 0;
        var rewMin = shown.length ? Math.max(36, LINE + 24) : 24, objMin = hasObj ? Math.max(36, LINE + 24) : 24, descMin = Math.max(66, LINE * 3 + 26);
        var rewH = Math.min(Math.max(rewMin, Math.floor(totalH * 0.35)), Math.max(rewMin, shown.length ? 22 + rewContent + 4 : 28));
        var objH = Math.min(Math.max(objMin, Math.floor(totalH * 0.35)), Math.max(objMin, hasObj ? 24 + objLines.length * LINE + 6 : 28));
        var descH = totalH - titleH - rewH - objH;
        if (descH < descMin) {
            var deficit = descMin - descH, take = Math.min(deficit, Math.max(0, rewH - rewMin));
            rewH -= take; deficit -= take; objH -= Math.min(deficit, Math.max(0, objH - objMin));
        }
        descH = Math.max(40, totalH - titleH - rewH - objH);

        section(ctx, x, y, w, titleH);
        titleLines.forEach(function (l, i) { U.bordered(ctx, "§l" + l, x + w / 2, y + 6 + i * LINE, "#FFFFFF", 0.5); });
        var stt = statusText(s);
        U.bordered(ctx, U.ellipsis(ctx, U.tr(stt[0]), w - 12), x + w / 2, titleH >= 40 ? y + titleH - LINE - 4 : y + 20, STATUS_COLOR[s], 0.5);

        var ry = y + titleH;
        section(ctx, x, ry, w, rewH);
        U.bordered(ctx, "§l" + U.tr("gui.dragonminez.quests.rewards"), x + 6, ry + 4, "#FFD700");
        st.rects.rew = [x, ry, w, rewH];
        if (!rewBlocks.length) U.bordered(ctx, "-", x + 8, ry + 18, "#999999");
        else {
            var view_h = Math.max(16, rewH - 22);
            st.rewScroll = Math.max(0, Math.min(st.rewScroll, Math.max(0, rewContent - view_h)));
            var by = ry + 18 - st.rewScroll, diff = QL.questDifficulty(data, e.key);
            rewBlocks.forEach(function (b) {
                var top = by; by += b.h;
                if (top < ry + 16 || top + 16 > ry + 18 + view_h) return;
                var locked = !QL.rewardUnlocked(b.r, diff), claimed = QL.claimed(data, e.key, b.i);
                drawRewardIcon(ctx, b.r, x + 8, top);
                b.lines.forEach(function (l, j) { U.bordered(ctx, l, x + 28, top + j * LINE, locked ? "#777777" : claimed ? "#88AA88" : "#CCCCCC"); });
                if (U.inside(mx, my, x + 8, top, Math.max(16, w - 16), Math.max(16, b.h - 4))) st.tooltip = [rewardTooltip(e.key, b.r), "#FFFFFF"];
            });
            scrollbar(ctx, x + w - 6, ry + 18, view_h, rewContent, st.rewScroll);
        }

        var dy = ry + rewH;
        section(ctx, x, dy, w, descH);
        U.bordered(ctx, "§l" + U.tr("gui.dragonminez.quest_tree.description"), x + 6, dy + 4, "#FFD700");
        st.rects.desc = [x, dy, w, descH];
        var dl = U.wrap(ctx, U.tr(q.description), w - 14), dvh = descH - 24, dLine = 11;
        st.descScroll = Math.max(0, Math.min(st.descScroll, Math.max(0, dl.length * dLine - dvh)));
        dl.forEach(function (l, i) {
            var ly = dy + 18 + i * dLine - st.descScroll;
            if (ly < dy + 17 || ly + 9 > dy + 18 + dvh) return;
            U.plain(ctx, l, x + 6, ly, "#CCCCCC");
        });
        scrollbar(ctx, x + w - 5, dy + 18, dvh, dl.length * dLine, st.descScroll);

        var oy = dy + descH;
        section(ctx, x, oy, w, objH);
        var otitle = q.requirements && q.requirements.conditions && q.requirements.conditions.length ? U.tr("gui.dragonminez.quests.objectives_requirements") : U.tr("gui.dragonminez.quests.objectives");
        U.bordered(ctx, "§l" + U.ellipsis(ctx, otitle, w - 14), x + 6, oy + 4, "#FFD700");
        st.rects.obj = [x, oy, w, objH];
        if (!objLines.length) U.bordered(ctx, "-", x + 8, oy + 18, "#999999");
        else {
            var ovh = objH - 24;
            st.objScroll = Math.max(0, Math.min(st.objScroll, Math.max(0, objLines.length * LINE - ovh)));
            objLines.forEach(function (l, i) {
                var ly = oy + 18 + i * LINE - st.objScroll;
                if (ly < oy + 17 || ly + 9 > oy + 18 + ovh) return;
                var text = l[0];
                if (l[2]) {
                    var lead = text.match(/^\s*/)[0], marker = text.substring(lead.length, lead.length + 2), rest = text.substring(lead.length + 2);
                    var mxp = x + 8 + U.width(ctx, lead);
                    if (lead) U.bordered(ctx, lead, x + 8, ly, l[1]);
                    ctx.textStyled("§l" + marker, mxp, ly, 1, l[2], 1, 0, null, "#000000");
                    U.bordered(ctx, rest, mxp + ctx.textWidthIn("§l" + marker, null), ly, l[1]);
                } else U.bordered(ctx, text, x + 8, ly, l[1]);
            });
            scrollbar(ctx, x + w - 4, oy + 18, ovh, objLines.length * LINE, st.objScroll);
        }

        // action button (initActionButton)
        var act = actionFor(e);
        if (act && st.rightT > 0.15) {
            var bx = px + Math.floor((pw - 74) / 2), byy = py + ph - 28;
            if (act.active) {
                var pulse = Math.sin(RPG.nowMs() / 500) * 0.5 + 0.5;
                ctx.fill(bx - 2, byy - 2, 78, 24, "#FFD700", 0.15 + pulse * 0.25);
            }
            var over = U.button(ctx, U.tr(act.label), bx, byy, act.active);
            st.rects.action = [bx, byy, 74, 20, act];
            if (U.inside(mx, my, bx, byy, 74, 20) && act.tip && act.tip.length) st.tooltip = [act.tip, "#FFFFFF"];
        }
    }

    function remainingSpawns(e) {
        var v = view();
        return e.quest.objectives.some(function (o, i) { return (o.type === "KILL" || o.type === "SPAR") && o.spawn === "QUEST" && QL.progress(v, e.key, i) < QL.required(o); });
    }
    function actionFor(e) {
        var v = view(), s = QL.status(v, e.key), ns = status(e);
        if (s === QL.COMPLETED && ns !== "AVAILABLE") {         // AVAILABLE again: a repeatable quest whose cooldown is over
            if (!QL.hasUnclaimed(v, e)) return null;
            if (e.quest.claim_mode === "NPC_ONLY") return { kind: "none", label: "gui.dragonminez.quests.claim_from_npc", active: false, tip: [[U.tr("gui.dragonminez.quests.claim_from_npc.tooltip"), "#AAAAAA"]] };
            return { kind: "claim", label: "gui.dragonminez.quests.claim_rewards", active: true };
        }
        if (ns === "AVAILABLE") {
            var tip = [];
            if (e.quest.requirements && e.quest.requirements.conditions) {
                var f = QL.firstFailing(e.quest.requirements, v, function (c) { return c.type === "DIMENSION" ? dimOk(c.dimension) : null; });
                if (f) tip.push([describeRequirement(f, e.key), "#FF5555"]);
            }
            return { kind: "start", label: "gui.dragonminez.quests.start", active: true, tip: tip };
        }
        if (s === QL.ACCEPTED && remainingSpawns(e) && (!resummonAt[e.key] || RPG.nowMs() >= resummonAt[e.key])) return { kind: "resummon", label: "gui.dragonminez.quests.start", active: true };
        if (s === QL.ACCEPTED && data.tr !== e.key) return { kind: "track", label: "gui.dragonminez.quests.track", active: true };
        return null;
    }
    function dimOk(dim) {
        var map = { "dragonminez:namek": "ragnarok_rpg:namek", "dragonminez:otherworld": "ragnarok_rpg:otherworld", "dragonminez:time_chamber": "ragnarok_rpg:time_chamber" };
        if (map[dim]) return RPG.player.dimension === map[dim];
        if (dim.indexOf("minecraft:") === 0) return RPG.player.dimension === dim;
        return null;
    }

    // ---- difficulty picker (renderDifficultySelectOverlay) ----
    var DIFFS = ["EASY", "NORMAL", "HARD"];
    function renderDifficulty(ctx, W, H, mx, my) {
        ctx.fill(0, 0, W, H, "#000000", 0.67);
        var pw = 220, ph = 196, px = Math.floor((W - pw) / 2), py = Math.floor((H - ph) / 2);
        ctx.fill(px, py, pw, ph, "#0F1020", 0.8);
        U.QUEST_PANEL.draw(ctx, px, py, pw, ph);
        U.bordered(ctx, "§l" + U.tr("gui.dragonminez.quest_tree.difficulty.select.title"), px + pw / 2, py + 4, "#FFD700", 0.5);
        U.wrap(ctx, U.tr("gui.dragonminez.quest_tree.difficulty.select.intro"), pw - 26).slice(0, 2).forEach(function (l, i) { U.plain(ctx, l, px + 10, py + 16 + i * 11, "#AAAAAA"); });
        st.rects.diff = [];
        DIFFS.forEach(function (d, i) {
            var x = px + 12, y = py + 46 + i * 47, w = pw - 24, h = 42, hov = U.inside(mx, my, x, y, w, h), dd = QL.DIFFICULTY[d];
            ctx.fill(x, y, w, h, hov ? "#FFFFFF" : "#000000", hov ? 0.4 : 0.2);
            ctx.fill(x, y, w, 1, hov ? "#CCDDFF" : "#444466", hov ? 1 : 0.33); ctx.fill(x, y + h - 1, w, 1, hov ? "#CCDDFF" : "#444466", hov ? 1 : 0.33);
            U.bordered(ctx, "§l" + U.tr(DIFF_LABEL[d]), x + 6, y + 4, DIFF_COLOR[d][hov ? 1 : 0]);
            var lines = U.wrap(ctx, U.tr("gui.dragonminez.quest_tree.difficulty.tooltip.stats", fmtMult(dd.hp), fmtMult(dd.dmg)), w - 18)
                .concat(U.wrap(ctx, U.tr("gui.dragonminez.quest_tree.difficulty.tooltip.rewards", fmtMult(dd.tp), fmtMult(dd.reward)), w - 18));
            lines.slice(0, 2).forEach(function (l, j) { U.plain(ctx, l, x + 6, y + 15 + j * 11, "#DCE6FF"); });
            st.rects.diff.push([x, y, w, h, d]);
        });
    }

    // ---- input ----
    function mouse(x, y, button, action) {
        if (!st) return;
        if (action === "up") { st.drag = null; return; }
        if (!data.d) {
            (st.rects.diff || []).forEach(function (r) {
                if (button === 0 && U.inside(x, y, r[0], r[1], r[2], r[3])) { RPG.net.send("dmz_quest", { action: "difficulty", difficulty: r[4] }); RPG.sound("dmzpack:pip_menu", 1, 1); }
            });
            return false;
        }
        if (button !== 0) return;
        if (st.rects.action && U.inside(x, y, st.rects.action[0], st.rects.action[1], 74, 20)) {
            var act = st.rects.action[4], now = RPG.nowMs();
            if (!act.active || now - st.lastClick < 500) return false;
            st.lastClick = now;
            var key = st.selected.key;
            if (act.kind === "claim") RPG.net.send("dmz_quest", { action: "claim", key: key });
            else if (act.kind === "track") RPG.net.send("dmz_quest", { action: "track", key: key });
            else if (act.kind === "resummon") { RPG.net.send("dmz_quest", { action: "resummon", key: key }); resummonAt[key] = now + 60000; }
            else if (act.kind === "start") {
                RPG.net.send("dmz_quest", { action: "start", key: key });
                resummonAt[key] = now + 60000;
                if (remainingSpawns(st.selected)) st.pendingClose = { key: key, until: RPG.time() + 60 };
            }
            return false;
        }
        if (st.rects.claimAll && U.inside(x, y, st.rects.claimAll[0], st.rects.claimAll[1], 74, 20)) {
            var t = RPG.nowMs();
            if (t - st.lastClick >= 500) { st.lastClick = t; RPG.net.send("dmz_quest", { action: "claim_all" }); }
            return false;
        }
        var lr = leftRect();
        if (inRect(x, y, lr)) { navClick(x, y); return false; }
        if (st.selected && inRect(x, y, rightRect())) return false;
        if (y > st.H - 34 && Math.abs(x - st.W / 2) < 130) return;        // the navigation row
        if (st.hoverNode) {
            if (visibility(st.hoverNode.e) === "BLURRED") return false;
            select(st.hoverNode.e);
            slideTo(st.hoverNode);
            return false;
        }
        st.drag = { x: x, y: y, px: st.pan[0], py: st.pan[1] };
        st.target = null;
        return false;
    }
    function select(e) {
        st.selected = e; st.objScroll = 0; st.rewScroll = 0; st.descScroll = 0;
        RPG.sound("dmzpack:pip_menu", 1, 1);
    }
    function navClick(x, y) {
        var row = null;
        (st.navRows || []).forEach(function (r) { if (U.inside(x, y, r[0], r[1], r[2], r[3])) row = r[4]; });
        if (!row) return;
        RPG.sound("dmzpack:pip_menu", 1, 1);
        if (row.type === "saga") {
            if (row.placeholder || !QL.sagaUnlocked(row.saga, view())) return;
            var idx = QL.SAGA_LIST.indexOf(row.saga);
            if (idx === sagaIndex) { st.collapsed = !st.collapsed; return; }
            sagaIndex = idx; st.collapsed = false; st.selected = null; st.objScroll = 0;
            rebuild(true);
            return;
        }
        if (row.type === "secrets" || !row.e) return;
        if (row.expandable) st.expanded[row.e.key] = !st.expanded[row.e.key];
        select(row.e);
        var n = findNode(row.e.key);
        if (n) slideTo(n);
    }
    function scroll(x, y, delta) {
        if (!st || !data.d) return;
        var d = delta > 0 ? 1 : -1;
        if (inRect(x, y, leftRect())) { st.navScroll = Math.max(0, st.navScroll - d * 26); return; }
        if (st.rects.rew && inRect(x, y, st.rects.rew)) { st.rewScroll = Math.max(0, st.rewScroll - d * LINE * 2); return; }
        if (st.rects.obj && inRect(x, y, st.rects.obj)) { st.objScroll = Math.max(0, st.objScroll - d * LINE * 2); return; }
        if (st.rects.desc && inRect(x, y, st.rects.desc)) { st.descScroll = Math.max(0, st.descScroll - d * 22); return; }
        if (st.selected && inRect(x, y, rightRect())) return;
        var old = st.zoom;
        st.zoom = Math.max(0.25, Math.min(2, st.zoom + d * 0.1));
        if (st.zoom !== old) {
            var k = st.zoom / old;
            st.pan = [x - k * (x - st.pan[0]), y - k * (y - st.pan[1])];
            st.target = null;
        }
    }

    RPG.net.on("dmz_quests_state", function (d) {
        if (!d) return;
        data.q = d.q || {}; data.d = d.d || null; data.resets = d.resets || 0; data.tr = d.tr || null;
        data.skills = d.skills || {}; data.alignment = typeof d.alignment === "number" ? d.alignment : 100; data.dim = d.dim || ""; data.op = !!d.op;
        fresh_cache();
    });
    RPG.net.on("dmz_quest_blocker", function (d) {
        if (d && d.cond) U.showStatus(describeRequirement(d.cond, ""), "#FF5555");
    });

    return { open: open, describeRequirement: describeRequirement, data: data };
})();

// ---- DMZ story toasts (StoryNotificationManager -> NotificationHUD, 47_dmz_notifications.js) ----
(function () {
    RPG.net.on("dmz_quest_toast", function (d) {
        if (!d || typeof DMZ_NOTIFY === "undefined") return;
        var U = DMZ_UI, P = DMZ_NOTIFY.PRIORITY, name = DMZ_QUEST_NAMES.label(d.key);
        if (d.kind === "started") DMZ_NOTIFY.push({ title: U.tr("toast.dragonminez.story.quest_started.title"), subtitle: name }, P.NORMAL);
        else if (d.kind === "failed") DMZ_NOTIFY.push({ title: U.tr("toast.dragonminez.story.quest_failed.title"), subtitle: name,
            description: U.tr("toast.dragonminez.story.quest_failed.hint") }, P.HIGH);
        else if (d.kind === "completed") DMZ_NOTIFY.push({ title: U.tr("toast.dragonminez.story.quest_complete.title"), subtitle: name,
            description: U.tr("toast.dragonminez.story.quest_complete.hint") }, P.HIGH);
        else if (d.kind === "objective") {
            var e = DMZ_QL.entry(d.key), o = e && e.quest.objectives[d.index], desc = name;
            if (o) desc = U.tr("toast.dragonminez.story.objective_complete.desc", name, DMZ_QL.required(o), DMZ_QL.required(o));
            DMZ_NOTIFY.push({ title: U.tr("toast.dragonminez.story.objective_complete.title"), subtitle: name, description: desc }, P.NORMAL);
        }
    });
})();

RPG.net.on("dmz_open_quests", function () { QUESTS_SCREEN.open(); });
