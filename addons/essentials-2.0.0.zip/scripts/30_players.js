// =====================================================================================
//  Essentials - messages, nicknames, AFK, player info and admin tools
// =====================================================================================

// ---- private messages (/m, /r; vanilla's /msg keeps working too) ----
var ESS_REPLY = {};
function essWhisper(p, t, text) {
    if (!text) { essMsg(p, "&cSay something."); return; }
    p.tell("&7[me -> &f" + t.getDisplayName() + "&7] &f" + text);
    t.tell("&7[&f" + p.getDisplayName() + "&7 -> me] &f" + text);
    t.playSound("minecraft:entity.experience_orb.pickup", 0.4, 1.6);
    ESS_REPLY[t.uuid] = p.name;
    ESS_REPLY[p.uuid] = t.name;
}
essCmd("m", { desc: "Private message: /m <player> <message>", perm: "msg", aliases: ["whisper", "pm"] }, (p, args) => {
    let t = essFind(p, args[0]);
    if (t) essWhisper(p, t, args.slice(1).join(" "));
});
essCmd("r", { desc: "Reply to your last message", perm: "msg", aliases: ["reply"], suggest: () => [] }, (p, args) => {
    let name = ESS_REPLY[p.uuid], t = name ? RPG.server.player(name) : null;
    if (!t) { essMsg(p, "&cNobody to reply to."); return; }
    essWhisper(p, t, args.join(" "));
});

// ---- nicknames ----
essCmd("nick", { desc: "/nick <name> | off  (& colours)", suggest: () => ["off"] }, (p, args) => {
    let target = p, nick = args.join(" ");
    if (args.length > 1 && essHas(p, "essentials.nick.others") && RPG.server.player(args[0])) { target = RPG.server.player(args[0]); nick = args.slice(1).join(" "); }
    if (!nick || nick === "off") { target.setNick(""); essMsg(p, "&7Nickname removed."); return; }
    if (nick.replace(/&./g, "").length > 16) { essMsg(p, "&cNicknames are at most 16 letters."); return; }
    target.setNick(nick + "&r");
    essMsg(p, "&7Nickname set to &f" + nick);
});

// ---- AFK: /afk, or idle for a while; moving or chatting brings you back ----
var ESS_AFK = {};    // uuid -> {x, z, idle seconds, afk}
function essSetAfk(p, on) {
    let s = ESS_AFK[p.uuid] || (ESS_AFK[p.uuid] = { x: p.x, z: p.z, idle: 0, afk: false });
    if (s.afk === on) return;
    s.afk = on; s.idle = 0;
    RPG.server.broadcast("&7* " + p.getDisplayName() + (on ? " is now AFK" : " is back"));
}
essCmd("afk", { desc: "Toggle away from keyboard", suggest: () => [] }, (p) => essSetAfk(p, !(ESS_AFK[p.uuid] && ESS_AFK[p.uuid].afk)));
RPG.on("playerTick", (p) => {
    let s = ESS_AFK[p.uuid] || (ESS_AFK[p.uuid] = { x: p.x, z: p.z, idle: 0, afk: false });
    if (Math.abs(p.x - s.x) + Math.abs(p.z - s.z) > 0.1) { s.x = p.x; s.z = p.z; if (s.afk) essSetAfk(p, false); s.idle = 0; return; }
    if (++s.idle >= ESS_CFG.get("afkMinutes") * 60 && !s.afk) essSetAfk(p, true);
});
RPG.on("chat", (p) => { if (ESS_AFK[p.uuid] && ESS_AFK[p.uuid].afk) essSetAfk(p, false); });
RPG.on("playerLeave", (p) => { delete ESS_AFK[p.uuid]; RPG.data.set("ess.seen." + p.name.toLowerCase(), Date.now()); });

// ---- join message ----
// a tick later, so the name shows the rank it has now (ranks sync on join too)
RPG.on("playerJoin", (p) => { RPG.schedule(1, () => { if (!RPG.server.player(p.name)) return; (ESS_CFG.get("motd") || []).forEach((l) => p.tell(String(l).replace("{name}", p.getDisplayName()))); }); });

// ---- info ----
essCmd("near", { desc: "Players near you", suggest: () => [] }, (p) => {
    let list = RPG.server.players().filter((q) => q.uuid !== p.uuid && q.dimension === p.dimension)
        .map((q) => ({ n: q.getDisplayName(), d: Math.sqrt((q.x - p.x) * (q.x - p.x) + (q.z - p.z) * (q.z - p.z)) }))
        .filter((e) => e.d <= 200).sort((a, b) => a.d - b.d);
    essMsg(p, list.length ? "&7Nearby: " + list.map((e) => "&f" + e.n + " &7(" + Math.round(e.d) + "m)").join(", ") : "&7Nobody within 200 blocks.");
});
essCmd("ping", { desc: "Your connection speed" }, (p, args) => {
    let t = args.length ? essFind(p, args[0]) : p;
    if (t) essMsg(p, "&7" + (t === p ? "Your" : t.name + "'s") + " ping: &f" + t.getPing() + " ms");
});
essCmd("seen", { desc: "When a player was last online" }, (p, args) => {
    if (!args.length) { essMsg(p, "&c/seen <player>"); return; }
    if (RPG.server.player(args[0])) { essMsg(p, "&f" + args[0] + " &ais online now."); return; }
    let t = RPG.data.get("ess.seen." + args[0].toLowerCase());
    if (!t) { essMsg(p, "&7Never seen &f" + args[0]); return; }
    let mins = Math.floor((Date.now() - t) / 60000);
    essMsg(p, "&f" + args[0] + " &7was last online " + (mins < 60 ? mins + " minutes" : mins < 2880 ? Math.floor(mins / 60) + " hours" : Math.floor(mins / 1440) + " days") + " ago.");
});
essCmd("commands", { desc: "Commands you can use", perm: "help", aliases: ["ehelp", "cmds"], suggest: () => [] }, (p) => {
    essMsg(p, "&6Commands you can use:");
    ESS_HELP.forEach((h) => { if (essHas(p, h[3] ? h[2] : "essentials." + h[2])) p.tell("  &e/" + h[0] + " &7" + h[1]); });
});
var ESS_HELP = [
    ["spawn", "go to spawn", "spawn"], ["home [name]", "go home", "home"], ["sethome [name]", "save a home", "sethome"], ["homes", "list homes", "homes"],
    ["warp <name>", "go to a warp", "warp"], ["tpa <player>", "ask to teleport", "tpa"], ["tpaccept / tpdeny", "answer requests", "tpaccept"],
    ["back", "where you were or died", "back"], ["m <player> <msg> / r", "private messages", "msg"], ["bal / pay / baltop", "money", "bal"],
    ["kits / kit <name>", "browse and claim kits", "kits.use", true], ["rank [player]", "your rank", "ranks.info", true], ["afk", "away from keyboard", "afk"], ["near / seen / ping", "player info", "near"],
    ["nick <name>", "nickname", "nick"], ["hat", "wear what you hold", "hat"], ["ec", "your ender chest", "enderchest"], ["top", "highest block", "top"],
    ["fly / god / heal / feed", "admin powers", "fly"], ["gmc / gms / gma / gmsp", "game modes", "gamemode"], ["invsee <player>", "look in an inventory", "invsee"],
    ["rank", "rank editor (ranks and permissions)", "ranks.manage", true], ["kitadmin", "kit editor", "kits.admin", true]
];

// ---- powers (self, or another player with essentials.<cmd>.others) ----
function essTarget(p, args, cmd) {
    if (!args.length) return p;
    if (!essHas(p, "essentials." + cmd + ".others")) { essMsg(p, "&cYou can only do that to yourself."); return null; }
    return essFind(p, args[0]);
}
essCmd("heal", { desc: "Full health and food" }, (p, args) => { let t = essTarget(p, args, "heal"); if (!t) return; t.health = t.maxHealth; t.setFood(20); t.setSaturation(10); essMsg(t, "&aHealed."); });
essCmd("feed", { desc: "Fill your hunger" }, (p, args) => { let t = essTarget(p, args, "feed"); if (!t) return; t.setFood(20); t.setSaturation(10); essMsg(t, "&aFed."); });
essCmd("fly", { desc: "Toggle flight" }, (p, args) => { let t = essTarget(p, args, "fly"); if (!t) return; let on = !t.isFlying() && !t.getVar("ess_fly", 0); t.setVar("ess_fly", on ? 1 : 0); t.setFlying(on); essMsg(t, on ? "&aYou can fly." : "&7Flight off."); });
essCmd("god", { desc: "Toggle god mode" }, (p, args) => { let t = essTarget(p, args, "god"); if (!t) return; let on = !t.isInvulnerable(); t.setInvulnerable(on); essMsg(t, on ? "&aGod mode on." : "&7God mode off."); });
[["gmc", "creative"], ["gms", "survival"], ["gma", "adventure"], ["gmsp", "spectator"]].forEach((g) => {
    essCmd(g[0], { desc: "Game mode " + g[1], perm: "gamemode" }, (p, args) => {
        let t = essTarget(p, args, "gamemode"); if (!t) return;
        t.setGameMode(g[1]); essMsg(t, "&7Game mode: &f" + g[1]);
    });
});
essCmd("day", { desc: "Make it day", perm: "time", suggest: () => [] }, (p) => { RPG.server.runCommand("execute in " + p.dimension + " run time set day"); essMsg(p, "&7It's day."); });
essCmd("night", { desc: "Make it night", perm: "time", suggest: () => [] }, (p) => { RPG.server.runCommand("execute in " + p.dimension + " run time set night"); essMsg(p, "&7It's night."); });
essCmd("sun", { desc: "Clear weather", perm: "weather", suggest: () => [] }, () => RPG.server.runCommand("weather clear"));
essCmd("broadcast", { desc: "Announce to everyone", aliases: ["bc"], suggest: () => [] }, (p, args) => RPG.server.broadcast("&6[&eAnnouncement&6] &f" + args.join(" ")));
essCmd("enderchest", { desc: "Open your ender chest", aliases: ["ec"], suggest: () => [] }, (p) => RPG.ui.enderChest(p));
essCmd("suicide", { desc: "Respawn the hard way", suggest: () => [] }, (p) => { p.health = 0; });
essCmd("hat", { desc: "Wear what you're holding", suggest: () => [] }, (p) => {
    let held = p.getHeldStack(), head = p.getStack(39);
    if (!held) { essMsg(p, "&cHold something first."); return; }
    let one = JSON.parse(JSON.stringify(held)); one.count = 1;
    p.setStack(39, one);
    held.count -= 1;
    p.setHeldStack(held.count > 0 ? held : null);
    if (head) p.giveStack(head);
    essMsg(p, "&aNice hat.");
});
essCmd("repair", { desc: "Repair what you're holding", aliases: ["fix"], suggest: () => [] }, (p) => {
    let held = p.getHeldStack();
    if (!held || held.maxDamage === undefined) { essMsg(p, "&cHold a tool or armour."); return; }
    held.damage = 0; p.setHeldStack(held); essMsg(p, "&aRepaired.");
});
essCmd("invsee", { desc: "Look in (and edit) a player's inventory" }, (p, args) => {
    let t = essFind(p, args[0]);
    if (!t) return;
    let items = [];
    for (let i = 0; i < 41; i++) items.push(t.getStack(i));
    RPG.ui.container(p, {
        title: "&8" + t.name + " (hotbar first, armour + off hand last)", rows: 5, items: items,
        onClose(viewer, now) { for (let i = 0; i < 41; i++) t.setStack(i, now[i]); }
    });
});
