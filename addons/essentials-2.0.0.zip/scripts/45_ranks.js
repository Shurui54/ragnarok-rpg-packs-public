// =====================================================================================
//  Essentials - ranks (the one ranks and permissions model)
// =====================================================================================
//  A rank IS a permission group (RPG.perms) plus how it looks: display name, chat prefix
//  and suffix, name and chat colours, badge, weight (the heaviest rank a player has is the
//  one shown), tab-list order, kit access and a kit cooldown multiplier. Its nodes and its
//  parent live in RPG.perms, so the rank editor (/rank), /rank perm and /rpg perm always agree.
//
//  Saved with the world (RPG.data):
//    rk.ranks              { id: rank }                     how ranks look
//    rk.p.<uuid>           { name, ranks: { id: expiresAt } } who has which rank (0 = forever)
//    rk.pending.<name>     { name, ranks }                  ranks given to someone who never joined yet
// =====================================================================================

var RK_RANKS = RPG.data.get("rk.ranks", null);
var RK_COLORS = { "0": "black", "1": "dark_blue", "2": "dark_green", "3": "dark_aqua", "4": "dark_red", "5": "dark_purple",
    "6": "gold", "7": "gray", "8": "dark_gray", "9": "blue", "a": "green", "b": "aqua", "c": "red", "d": "light_purple", "e": "yellow", "f": "white" };

function rkCleanRank(id, r) {
    r = r || {};
    let num = (v, d) => { let n = parseFloat(v); return isNaN(n) ? d : n; };
    let code = (v, d) => { let s = String(v || ""); return /^&[0-9a-fk-or]+$/i.test(s) ? s.toLowerCase() : d; };
    // the chat colour may also be any colour, "&#RRGGBB" (the name colour stays a chat colour: it is the team colour)
    let chat = (v, d) => { let s = String(v || ""); return /^&#[0-9a-f]{6}(&[k-or])*$/i.test(s) ? "&#" + s.substring(2, 8).toUpperCase() + s.substring(8).toLowerCase() : code(v, d); };
    return {
        id: id,
        name: String(r.name || id).substring(0, 32),
        prefix: String(r.prefix === undefined ? "" : r.prefix).substring(0, 48),
        suffix: String(r.suffix === undefined ? "" : r.suffix).substring(0, 48),
        nameColor: code(r.nameColor, "&f"),
        chatColor: chat(r.chatColor, "&f"),
        weight: Math.round(RPG.clamp(num(r.weight, 0), -9999, 9999)),
        tab: r.tab === undefined || r.tab === null || r.tab === "" ? null : Math.round(RPG.clamp(num(r.tab, 0), 0, 9999)),
        isDefault: !!r.isDefault,
        kits: Array.isArray(r.kits) ? r.kits.map(String).slice(0, 200) : [],
        kitMult: RPG.clamp(num(r.kitMult, 1), 0, 100),
        icon: String(r.icon || ""),
        badge: rkCleanBadge(r.badge)
    };
}

/** A badge picture: "ns:path" under textures/ (no .png), e.g. "mypack:badges/owner"; "" for none. */
function rkCleanBadge(b) {
    let s = String(b || "").trim().toLowerCase().replace(/^([a-z0-9_.\-]+):textures\//, "$1:").replace(/\.png$/, "");
    return /^[a-z0-9_.\-]{1,32}:[a-z0-9_.\-\/]{1,120}$/.test(s) ? s : "";
}

/** The & token drawing a rank's badge (with a space after it), or "" (height 0: auto). */
function rkBadge(r, height) {
    if (!r || !r.badge) return "";
    return "&{icon:" + r.badge + (height > 0 ? "," + height : "") + "} ";
}

// a new world: one rank per default group (00_config.js)
if (!RK_RANKS) {
    RK_RANKS = {};
    Object.keys(ESS_SEED_RANKS).forEach((g) => { RK_RANKS[g] = rkCleanRank(g, ESS_SEED_RANKS[g]); });
    RPG.data.set("rk.ranks", RK_RANKS);
}
Object.keys(RK_RANKS).forEach((id) => { RK_RANKS[id] = rkCleanRank(id, RK_RANKS[id]); RPG.perms.group(id, []); });

function rkSaveRanks() { RPG.data.set("rk.ranks", RK_RANKS); }
function rkRank(id) { return id ? RK_RANKS[String(id).toLowerCase()] || null : null; }
function rkIds() { return Object.keys(RK_RANKS).sort((a, b) => RK_RANKS[b].weight - RK_RANKS[a].weight || (a < b ? -1 : 1)); }
function rkDefaultRank() {
    let ids = Object.keys(RK_RANKS), d = ids.filter((id) => RK_RANKS[id].isDefault)[0];
    return RK_RANKS[d || "default"] || null;
}
function rkTabOrder(r) { return r.tab === null || r.tab === undefined ? RPG.clamp(r.weight, 0, 9999) : r.tab; }
function rkColorName(code) { let m = /&([0-9a-f])/i.exec(code || ""); return m ? RK_COLORS[m[1].toLowerCase()] : "white"; }

// ---- who has which rank ---------------------------------------------------------------------------

function rkRec(uuid) { return RPG.data.get("rk.p." + uuid, null); }
function rkSaveRec(uuid, rec) {
    // players without a rank get no key (keeps RPG.data small); "removed" remembers ranks taken while they were
    // offline, so their next join also takes the permission group (see rkSync)
    let removed = rec.removed && Object.keys(rec.removed).length ? rec.removed : null;
    if ((!rec.ranks || !Object.keys(rec.ranks).length) && !removed) { RPG.data.remove("rk.p." + uuid); return; }
    let out = { name: rec.name, ranks: rec.ranks || {} };
    if (removed) out.removed = removed;
    RPG.data.set("rk.p." + uuid, out);
}
function rkNow() { return Date.now(); }
function rkLive(exp) { return !exp || exp > rkNow(); }

/** Online player, a saved record or a pending entry for a name: {uuid|null, name, player|null}. */
function rkLookup(name) {
    name = String(name || "").trim();
    if (!/^[A-Za-z0-9_]{1,16}$/.test(name)) return null;
    let p = RPG.server.player(name);
    if (p) return { uuid: p.uuid, name: p.name, player: p };
    let low = name.toLowerCase(), hit = null;
    RPG.data.keys("rk.p.").forEach((k) => {
        if (hit) return;
        let rec = RPG.data.get(k, null);
        if (rec && rec.name && rec.name.toLowerCase() === low) hit = { uuid: k.substring(5), name: rec.name, player: null };
    });
    return hit || { uuid: null, name: name, player: null };
}

/** The ranks (ids -> expiry) of a looked-up player, live only. */
function rkRanksOf(who) {
    let rec = who.uuid ? rkRec(who.uuid) : RPG.data.get("rk.pending." + who.name.toLowerCase(), null);
    let out = {};
    if (rec && rec.ranks) Object.keys(rec.ranks).forEach((id) => { if (RK_RANKS[id] && rkLive(rec.ranks[id])) out[id] = rec.ranks[id]; });
    return out;
}

/** Give (days > 0: for that long; 0: forever) or take a rank. replace: drop every other rank first. */
function rkAssign(who, id, days, replace) {
    let key = who.uuid ? "rk.p." + who.uuid : "rk.pending." + who.name.toLowerCase();
    let rec = RPG.data.get(key, null) || { name: who.name, ranks: {} };
    rec.name = who.name;
    let dropped = replace ? Object.keys(rec.ranks).filter((o) => o !== id) : [];
    if (days === null) dropped.push(id);
    if (who.uuid && !who.player) {
        // offline: their permission group goes on their next join
        rec.removed = rec.removed || {};
        dropped.forEach((o) => { rec.removed[o] = true; });
        if (days !== null) delete rec.removed[id];
    }
    dropped.forEach((o) => { delete rec.ranks[o]; });
    if (days !== null) {
        let old = rec.ranks[id], add = days > 0 ? Math.round(days * 86400000) : 0;
        if (add === 0) rec.ranks[id] = 0;                                    // forever
        else if (old === 0) rec.ranks[id] = 0;                               // forever stays forever
        else rec.ranks[id] = (old && old > rkNow() ? old : rkNow()) + add;   // more time on a timed rank adds up
    }
    if (who.uuid) rkSaveRec(who.uuid, rec);
    else if (Object.keys(rec.ranks).length) RPG.data.set(key, rec); else RPG.data.remove(key);
    if (who.player) {
        let before = rkPrimary(who.player);
        rkSync(who.player);
        let after = rkPrimary(who.player);
        if (ESS_CFG.get("ranks.announce") && days !== null && RK_RANKS[id])
            essMsg(who.player, "&7You are now &f" + RK_RANKS[id].name + (days > 0 ? " &7for &f" + essDuration(days * 86400) : "") + "&7.");
        else if (ESS_CFG.get("ranks.announce") && days === null && RK_RANKS[id]) essMsg(who.player, "&7You lost the rank &f" + RK_RANKS[id].name + "&7.");
        if (before !== after && after) who.player.playSound("minecraft:ui.toast.challenge_complete", 0.5, 1.4);
    }
}

/** Every rank a player has right now, heaviest first (the default rank included). */
function rkPlayerRanks(p) {
    let rec = rkRec(p.uuid), out = [];
    if (rec && rec.ranks) Object.keys(rec.ranks).forEach((id) => { if (RK_RANKS[id] && rkLive(rec.ranks[id])) out.push(RK_RANKS[id]); });
    let d = rkDefaultRank();
    if (d && out.indexOf(d) < 0) out.push(d);
    return out.sort((a, b) => b.weight - a.weight);
}
function rkPrimary(p) { return rkPlayerRanks(p)[0] || null; }

/** Make RPG.perms groups, the team and the name match the player's ranks. */
function rkSync(p) {
    let rec = rkRec(p.uuid);
    let pend = RPG.data.get("rk.pending." + p.name.toLowerCase(), null);
    let changed = false;
    if (!rec) rec = { name: p.name, ranks: {} };
    // one model: a rank group given with /rpg perm (or another addon's RPG.perms.addGroup) is that rank, for good;
    // a rank taken while they were offline takes the group now
    let removed = rec.removed || {}, dflt = rkDefaultRank();
    RPG.perms.groupsOf(p).forEach((g) => {
        g = String(g);
        if (RK_RANKS[g] && (!dflt || g !== dflt.id) && rec.ranks[g] === undefined && !removed[g]) { rec.ranks[g] = 0; changed = true; }
    });
    if (rec.removed) { delete rec.removed; changed = true; }
    if (pend && pend.ranks) {
        Object.keys(pend.ranks).forEach((id) => { rec.ranks[id] = pend.ranks[id]; });
        RPG.data.remove("rk.pending." + p.name.toLowerCase());
        changed = true;
    }
    if (rec.name !== p.name) { rec.name = p.name; changed = true; }
    // expired ranks
    Object.keys(rec.ranks).forEach((id) => {
        if (!RK_RANKS[id]) { delete rec.ranks[id]; changed = true; return; }
        if (!rkLive(rec.ranks[id])) {
            delete rec.ranks[id]; changed = true;
            if (ESS_CFG.get("ranks.announce")) essMsg(p, "&7Your rank &f" + RK_RANKS[id].name + "&7 ran out.");
        }
    });
    if (changed) rkSaveRec(p.uuid, rec);

    let want = {};
    Object.keys(rec.ranks).forEach((id) => { want[id] = true; });
    let d = rkDefaultRank();
    if (d && d.id !== "default") want[d.id] = true;
    let have = RPG.perms.groupsOf(p).map(String);
    Object.keys(RK_RANKS).forEach((id) => {
        if (want[id] && have.indexOf(id) < 0) RPG.perms.addGroup(p, id);
        else if (!want[id] && have.indexOf(id) >= 0) RPG.perms.removeGroup(p, id);
    });
    rkApplyLook(p);
}

// ---- how ranks look: teams (tab + over heads) and chat ----------------------------------------------

function rkTeamId(r) { let n = String(9999 - rkTabOrder(r)); while (n.length < 4) n = "0" + n; return "rk" + n + "_" + r.id; }
function rkIsRankTeam(t) { return !!t && /^rk\d{4}_/.test(t); }

function rkDefineTeams() {
    let keep = {};
    if (ESS_CFG.get("tab.teams")) Object.keys(RK_RANKS).forEach((id) => {
        let r = RK_RANKS[id], t = rkTeamId(r);
        keep[t] = true;
        RPG.teams.define(t, { name: r.name.replace(/&./g, ""), color: rkColorName(r.nameColor), prefix: (ESS_CFG.get("badges.tab") ? rkBadge(r, 0) : "") + r.prefix, suffix: r.suffix,
            friendlyFire: true, seeInvisible: false, nametags: "always", collision: "always" });
    });
    RPG.teams.list().forEach((t) => { t = String(t); if (rkIsRankTeam(t) && !keep[t]) RPG.teams.remove(t); });
}

function rkApplyLook(p) {
    if (!ESS_CFG.get("tab.teams")) {
        let cur = RPG.teams.get(p);
        if (rkIsRankTeam(cur ? String(cur) : null)) RPG.teams.leave(p);
        return;
    }
    let r = rkPrimary(p), cur = RPG.teams.get(p);
    cur = cur ? String(cur) : null;
    if (cur && !rkIsRankTeam(cur) && ESS_CFG.get("tab.respectOtherTeams")) return;
    if (!r) { if (rkIsRankTeam(cur)) RPG.teams.leave(p); return; }
    let t = rkTeamId(r);
    if (!RPG.teams.exists(t)) rkDefineTeams();
    if (cur !== t) RPG.teams.join(p, t);
}

function rkSyncAll() { rkDefineTeams(); RPG.server.players().forEach(rkSync); }

/** A chat line for a player and message (also used by the editor preview). */
function rkChatLine(r, name, message) {
    r = r || { prefix: "", suffix: "", nameColor: "&f", chatColor: "&f", name: "", badge: "" };
    let fmt = String(ESS_CFG.get("chat.format"));
    let badge = ESS_CFG.get("badges.chat") ? rkBadge(r, ESS_CFG.get("badges.chatHeight")) : "";
    if (fmt.indexOf("{badge}") < 0) fmt = "{badge}" + fmt;
    return fmt.replace(/\{badge\}/g, badge).replace(/\{prefix\}/g, r.prefix).replace(/\{suffix\}/g, r.suffix)
        .replace(/\{color\}/g, r.nameColor).replace(/\{rank\}/g, r.name).replace(/\{chatcolor\}/g, r.chatColor)
        .replace(/\{name\}/g, name).split("{message}").join(message);
}

// Builds on any chat format set before it (a title tag from another addon): that one is given our line as its
// built-in line, so it can add to it.
(function () {
    let prev = null;
    let mine = (p, message, builtIn) => {
        if (!ESS_CFG.get("chat.enabled")) return prev ? prev(p, message, builtIn) : null;
        let msg = essHas(p, ESS_CFG.get("chat.colorNode")) ? String(message) : String(message).replace(/&/g, "&&");
        let nick = p.getNick();
        let line = rkChatLine(rkPrimary(p), nick ? nick : p.name, msg);
        if (!prev) return line;
        let out = prev(p, message, line);
        return out === null || out === undefined || String(out) === "" ? line : out;
    };
    prev = RPG.override("chatFormat", mine) || null;
    if (prev === mine) prev = null;
})();

RPG.on("playerJoin", (p) => rkSync(p));
RPG.schedule(1, rkSyncAll);
(function () {
    let left = 0;
    RPG.every(20, () => {
        if (--left > 0) return;
        left = ESS_CFG.get("ranks.checkSeconds");
        RPG.server.players().forEach((p) => {
            let rec = rkRec(p.uuid);
            if (rec && rec.ranks && Object.keys(rec.ranks).some((id) => !rkLive(rec.ranks[id]))) rkSync(p);
        });
    });
})();
ESS_CFG.onChange((key) => { if (key.indexOf("tab.") === 0 || key.indexOf("badges.") === 0) rkSyncAll(); });

// ---- changing ranks (shared by commands and the editor) ----------------------------------------------

function rkCreate(id, name) {
    id = String(id || "").toLowerCase().trim();
    if (!/^[a-z0-9_\-]{1,24}$/.test(id)) return "Rank ids are 1-24 letters, digits, - or _ (no spaces).";
    if (RK_RANKS[id]) return "There already is a rank called " + id + ".";
    let top = rkIds().length ? RK_RANKS[rkIds()[0]].weight : 0;
    RK_RANKS[id] = rkCleanRank(id, { name: name || (id.charAt(0).toUpperCase() + id.substring(1)), prefix: "&7[" + (name || id) + "] ", weight: Object.keys(RK_RANKS).length ? Math.min(9999, top + 10) : 0 });
    RPG.perms.group(id, []);
    let d = rkDefaultRank();
    if (d && d.id !== id) RPG.perms.setGroupParent(id, d.id, true);      // new ranks start with the default rank's nodes
    rkSaveRanks();
    rkSyncAll();
    return null;
}

function rkDelete(id) {
    if (!RK_RANKS[id]) return "No rank called " + id + ".";
    delete RK_RANKS[id];
    rkSaveRanks();
    Object.keys(RK_RANKS).forEach((o) => { if (RPG.perms.groupInfo(o).savedParents.map(String).indexOf(id) >= 0) RPG.perms.setGroupParent(o, id, false); });
    if (id !== "default") RPG.perms.deleteGroup(id);
    RPG.data.keys("rk.p.").concat(RPG.data.keys("rk.pending.")).forEach((k) => {
        let rec = RPG.data.get(k, null);
        if (rec && rec.ranks && rec.ranks[id] !== undefined) { delete rec.ranks[id]; RPG.data.set(k, rec); }
    });
    rkSyncAll();
    return null;
}

function rkUpdate(id, d) {
    let r = RK_RANKS[id];
    if (!r) return "No rank called " + id + ".";
    let merged = JSON.parse(JSON.stringify(r));
    ["name", "prefix", "suffix", "nameColor", "chatColor", "weight", "tab", "isDefault", "kits", "kitMult", "icon", "badge"].forEach((k) => { if (d[k] !== undefined) merged[k] = d[k]; });
    let n = rkCleanRank(id, merged);
    if (n.isDefault && !r.isDefault) Object.keys(RK_RANKS).forEach((o) => { RK_RANKS[o].isDefault = false; });
    RK_RANKS[id] = n;
    if (d.parent !== undefined) {
        // one editable parent: the saved one (parents an addon script declares stay)
        let info = RPG.perms.groupInfo(id);
        info.savedParents.map(String).forEach((pa) => { if (pa !== d.parent) RPG.perms.setGroupParent(id, pa, false); });
        if (d.parent && RK_RANKS[d.parent] && d.parent !== id && !rkInheritsFrom(d.parent, id)) RPG.perms.setGroupParent(id, d.parent, true);
    }
    rkSaveRanks();
    rkSyncAll();
    return null;
}

/** Gives a rank a new id: its look, nodes, parents, children, members and kits move over. */
function rkRename(id, nid) {
    nid = String(nid || "").toLowerCase().trim();
    if (!RK_RANKS[id]) return "No rank called " + id + ".";
    if (id === "default") return "The default group keeps its id (everyone is in it); change its display name instead.";
    if (!/^[a-z0-9_\-]{1,24}$/.test(nid)) return "Rank ids are 1-24 letters, digits, - or _ (no spaces).";
    if (nid === id) return null;
    if (RK_RANKS[nid] || RPG.perms.groups().map(String).indexOf(nid) >= 0) return "There already is a rank or group called " + nid + ".";
    let info = RPG.perms.groupInfo(id), saved = info.savedNodes;
    RPG.perms.group(nid, []);
    Object.keys(saved).forEach((n) => RPG.perms.setGroupNode(nid, n, saved[n]));
    info.savedParents.map(String).forEach((pa) => RPG.perms.setGroupParent(nid, pa, true));
    Object.keys(RK_RANKS).forEach((o) => {
        if (o !== id && RPG.perms.groupInfo(o).savedParents.map(String).indexOf(id) >= 0) { RPG.perms.setGroupParent(o, id, false); RPG.perms.setGroupParent(o, nid, true); }
    });
    RK_RANKS[nid] = rkCleanRank(nid, RK_RANKS[id]);
    delete RK_RANKS[id];
    RPG.data.keys("rk.p.").concat(RPG.data.keys("rk.pending.")).forEach((k) => {
        let rec = RPG.data.get(k, null);
        if (rec && rec.ranks && rec.ranks[id] !== undefined) { rec.ranks[nid] = rec.ranks[id]; delete rec.ranks[id]; RPG.data.set(k, rec); }
    });
    if (typeof KT_KITS === "object") Object.keys(KT_KITS).forEach((k) => { if (KT_KITS[k].rank === id) { KT_KITS[k].rank = nid; ktSave(KT_KITS[k]); } });
    rkSaveRanks();
    RPG.perms.deleteGroup(id);
    rkSyncAll();
    return null;
}

/** Moves a rank one place up (dir -1: heavier) or down (+1) the list by trading weights with its neighbour. */
function rkMove(id, dir) {
    let ids = rkIds(), i = ids.indexOf(id), j = i + (dir < 0 ? -1 : 1);
    if (i < 0) return "No rank called " + id + ".";
    if (j < 0 || j >= ids.length) return null;
    let a = RK_RANKS[id], b = RK_RANKS[ids[j]];
    let wa = a.weight, wb = b.weight;
    if (wa === wb) wa = dir < 0 ? wb + 1 : wb - 1; else { a.weight = wb; b.weight = wa; wa = a.weight; }
    a.weight = Math.round(RPG.clamp(wa, -9999, 9999));
    rkSaveRanks();
    rkSyncAll();
    return null;
}

/** Whether group a (directly or not) inherits b: stops loops in the parent picker. */
function rkInheritsFrom(a, b) {
    let seen = {}, queue = [a];
    while (queue.length) {
        let g = queue.shift();
        if (g === b) return true;
        if (seen[g]) continue;
        seen[g] = true;
        RPG.perms.groupInfo(g).parents.map(String).forEach((x) => queue.push(x));
    }
    return false;
}

/** Everyone holding a rank (records and pending), for the Members tab and /rank info. */
function rkMembers(id) {
    let out = [];
    RPG.data.keys("rk.p.").forEach((k) => {
        let rec = RPG.data.get(k, null);
        if (rec && rec.ranks && rec.ranks[id] !== undefined && rkLive(rec.ranks[id]))
            out.push({ name: rec.name, exp: rec.ranks[id], online: !!RPG.server.player(rec.name), pending: false });
    });
    RPG.data.keys("rk.pending.").forEach((k) => {
        let rec = RPG.data.get(k, null);
        if (rec && rec.ranks && rec.ranks[id] !== undefined) out.push({ name: rec.name, exp: rec.ranks[id], online: false, pending: true });
    });
    return out.sort((a, b) => (b.online - a.online) || (a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1));
}

function rkMemberCounts() {
    let c = {};
    RPG.data.keys("rk.p.").concat(RPG.data.keys("rk.pending.")).forEach((k) => {
        let rec = RPG.data.get(k, null);
        if (rec && rec.ranks) Object.keys(rec.ranks).forEach((id) => { if (rkLive(rec.ranks[id])) c[id] = (c[id] || 0) + 1; });
    });
    return c;
}

// ---- the editor (client/scripts/ess_30_ranks.js draws it) ----------------------------------------------

function rkListState(p) {
    let counts = rkMemberCounts();
    return {
        ranks: rkIds().map((id) => { let r = RK_RANKS[id]; return { id: id, name: r.name, prefix: r.prefix, suffix: r.suffix, nameColor: r.nameColor, weight: r.weight, isDefault: r.isDefault, badge: r.badge, members: counts[id] || 0 }; }),
        can: { manage: essHas(p, "ranks.manage"), assign: essHas(p, "ranks.assign") }
    };
}

function rkRankState(p, id) {
    let r = RK_RANKS[id];
    if (!r) return null;
    let info = RPG.perms.groupInfo(id);
    let saved = info.savedParents.map(String).filter((x) => RK_RANKS[x]);
    return {
        rank: r,
        parent: saved[0] || "",
        fixedParents: info.scriptParents.map(String),
        script: info.scriptNodes, saved: info.savedNodes,
        known: RPG.perms.knownNodes().map(String),
        members: rkMembers(id),
        ranks: rkIds().map((o) => ({ id: o, name: RK_RANKS[o].name })),
        kits: typeof ktListIds === "function" ? ktListIds().map((k) => ({ id: k, name: KT_KITS[k].name, icon: KT_KITS[k].icon })) : [],
        online: essOnlineNames(),
        format: String(ESS_CFG.get("chat.format")),
        badges: { tab: !!ESS_CFG.get("badges.tab"), chat: !!ESS_CFG.get("badges.chat"), chatHeight: ESS_CFG.get("badges.chatHeight") },
        can: { manage: essHas(p, "ranks.manage"), assign: essHas(p, "ranks.assign") }
    };
}

function rkOpenGui(p) { RPG.net.send(p, "rk_list", { open: true, state: rkListState(p) }); }
function rkSendRank(p, id, open, note) {
    let st = rkRankState(p, id);
    if (!st) { RPG.net.send(p, "rk_list", { open: true, state: rkListState(p), note: note || "" }); return; }
    RPG.net.send(p, "rk_rank", { open: !!open, state: st, note: note || "" });
}
function rkNote(p, text, bad) { RPG.net.send(p, "rk_note", { text: text, bad: !!bad }); }

RPG.net.on("rk", (p, d) => {
    if (!d || typeof d.a !== "string") return;
    let id = d.id ? String(d.id).toLowerCase() : "";
    let manage = essHas(p, "ranks.manage"), assign = essHas(p, "ranks.assign");
    if (!manage && !assign) { rkNote(p, "You can't edit ranks.", true); return; }
    let err;
    switch (d.a) {
        case "list": RPG.net.send(p, "rk_list", { open: !!d.open, state: rkListState(p) }); return;
        case "get": rkSendRank(p, id, true); return;
        case "create":
            if (!manage) break;
            err = rkCreate(d.id, d.name ? String(d.name).substring(0, 32) : "");
            if (err) { rkNote(p, err, true); return; }
            rkSendRank(p, String(d.id).toLowerCase(), true, "Rank created.");
            return;
        case "delete":
            if (!manage) break;
            err = rkDelete(id);
            RPG.net.send(p, "rk_list", { open: true, state: rkListState(p), note: err || "Rank deleted." });
            return;
        case "rename":
            if (!manage) break;
            err = rkRename(id, d.to);
            if (err) { rkNote(p, err, true); return; }
            rkSendRank(p, String(d.to).toLowerCase().trim(), true, "Rank id changed.");
            return;
        case "move":
            if (!manage) break;
            err = rkMove(id, Number(d.dir) || 1);
            if (err) { rkNote(p, err, true); return; }
            rkSendRank(p, id, false, "");
            return;
        case "save":
            if (!manage) break;
            err = rkUpdate(id, d.rank || {});
            if (err) { rkNote(p, err, true); return; }
            rkSendRank(p, id, false, d.quiet ? "" : "Saved.");
            return;
        case "node": {
            if (!manage || !RK_RANKS[id]) break;
            let node = String(d.node || "").trim().toLowerCase();
            if (!/^-?[a-z0-9_\-.*]{1,96}$/.test(node)) { rkNote(p, "Nodes look like plugin.command or plugin.* (no spaces).", true); return; }
            if (node.charAt(0) === "-") { node = node.substring(1); d.value = false; }
            RPG.perms.setGroupNode(id, node, d.value === true ? true : d.value === false ? false : null);
            rkSendRank(p, id, false, "");
            return;
        }
        case "assign":
        case "unassign": {
            if (!assign || !RK_RANKS[id]) break;
            let who = rkLookup(d.player);
            if (!who) { rkNote(p, "That isn't a player name.", true); return; }
            let days = d.a === "unassign" ? null : parseFloat(d.days || 0);
            if (days !== null && (isNaN(days) || days < 0 || days > 36500)) { rkNote(p, "Days: a number (empty = forever).", true); return; }
            rkAssign(who, id, days, false);
            rkSendRank(p, id, false, d.a === "assign" ? who.name + (who.uuid ? "" : " (gets it on their first join)") + " is now " + RK_RANKS[id].name + "." : who.name + " lost " + RK_RANKS[id].name + ".");
            return;
        }
    }
    rkNote(p, "You don't have permission for that.", true);
});

// ---- /rank -----------------------------------------------------------------------------------------

function rkLine(p, text) { if (p) p.tell(text); else RPG.log(String(text).replace(/&./g, "")); }

function rkInfoLines(asker, name) {
    if (name && RK_RANKS[name.toLowerCase()]) {
        let r = RK_RANKS[name.toLowerCase()], info = RPG.perms.groupInfo(r.id);
        essMsg(asker, "&7Rank &f" + r.id + "&7: " + r.prefix + r.nameColor + "Name" + r.suffix + " &7weight &f" + r.weight + (r.isDefault ? " &a(default)" : ""));
        if (info.parents.length) essMsg(asker, "&7Inherits: &f" + info.parents.map(String).join(", "));
        let nodes = Object.keys(info.nodes);
        if (nodes.length) essMsg(asker, "&7Nodes: " + nodes.map((n) => (info.nodes[n] ? "&a" : "&c-") + n).join("&7, "));
        let m = rkMembers(r.id);
        essMsg(asker, "&7Members (" + m.length + "): &f" + (m.map((e) => e.name).slice(0, 30).join(", ") || "none"));
        return;
    }
    let who = name ? rkLookup(name) : { uuid: asker.uuid, name: asker.name, player: asker };
    if (!who) { essMsg(asker, "&cNo rank or player called &f" + name); return; }
    let ranks = rkRanksOf(who), ids = Object.keys(ranks).sort((a, b) => RK_RANKS[b].weight - RK_RANKS[a].weight);
    let d = rkDefaultRank();
    essMsg(asker, "&f" + who.name + "&7: " + (ids.length ? ids.map((id) => "&f" + RK_RANKS[id].name + (ranks[id] ? " &7(" + essDuration((ranks[id] - rkNow()) / 1000) + " left)" : "")).join("&7, ") : "&f" + (d ? d.name : "no rank")));
}

RPG.commands.register("rank", {
    root: true, aliases: ["ranks"], permission: "ranks.info",
    description: "Ranks: /rank (editor) | create | delete | set | add | remove | list | info",
    suggest(p, args) {
        let subs = ["gui", "create", "delete", "set", "add", "remove", "list", "info", "perm"];
        if (args.length <= 1) return subs;
        let s = String(args[0]).toLowerCase();
        if (["set", "add", "remove"].indexOf(s) >= 0) return args.length === 2 ? essOnlineNames() : args.length === 3 ? rkIds() : args.length === 4 && s !== "remove" ? ["1", "7", "30"] : [];
        if (s === "info") return args.length === 2 ? rkIds().concat(essOnlineNames()) : [];
        if (s === "delete") return args.length === 2 ? rkIds() : [];
        if (s === "perm") return args.length === 2 ? rkIds() : args.length === 3 ? RPG.perms.knownNodes().map(String) : args.length === 4 ? ["true", "false", "clear"] : [];
        return [];
    },
    run(p, args) {
        let sub = args.length ? String(args[0]).toLowerCase() : (p && (essHas(p, "ranks.manage") || essHas(p, "ranks.assign")) ? "gui" : "info");
        let need = (node) => { if (essHas(p, node)) return true; essMsg(p, "&cYou don't have permission (" + node + ")."); return false; };
        let err;
        switch (sub) {
            case "gui":
            case "edit":
                if (!p) return;
                if (!essHas(p, "ranks.manage") && !essHas(p, "ranks.assign")) { essMsg(p, "&cYou can't edit ranks."); return; }
                if (args[1] && RK_RANKS[String(args[1]).toLowerCase()]) rkSendRank(p, String(args[1]).toLowerCase(), true); else rkOpenGui(p);
                return;
            case "create":
                if (!need("ranks.manage")) return;
                if (!args[1]) { essMsg(p, "&c/rank create <id> [display name]"); return; }
                err = rkCreate(args[1], args.slice(2).join(" "));
                essMsg(p, err ? "&c" + err : "&aRank &f" + String(args[1]).toLowerCase() + "&a created. &7/rank gui to style it.");
                return;
            case "delete":
                if (!need("ranks.manage")) return;
                err = rkDelete(String(args[1] || "").toLowerCase());
                essMsg(p, err ? "&c" + err : "&7Rank deleted.");
                return;
            case "set":
            case "add":
            case "remove": {
                if (!need("ranks.assign")) return;
                let who = rkLookup(args[1]), id = String(args[2] || "").toLowerCase();
                if (!who || !RK_RANKS[id]) { essMsg(p, "&c/rank " + sub + " <player> <rank>" + (sub === "remove" ? "" : " [days]")); return; }
                let days = sub === "remove" ? null : parseFloat(args[3] || 0);
                if (days !== null && (isNaN(days) || days < 0)) { essMsg(p, "&cDays must be a number."); return; }
                rkAssign(who, id, days, sub === "set");
                essMsg(p, "&f" + who.name + (sub === "remove" ? " &7lost &f" : " &7is now &f") + RK_RANKS[id].name + (days ? " &7for &f" + essDuration(days * 86400) : "") +
                    (who.uuid ? "" : " &8(never joined: they get it on their first join)"));
                return;
            }
            case "perm": {
                if (!need("ranks.manage")) return;
                let id = String(args[1] || "").toLowerCase(), node = String(args[2] || ""), v = String(args[3] || "true").toLowerCase();
                if (!RK_RANKS[id] || !node) { essMsg(p, "&c/rank perm <rank> <node> [true|false|clear]"); return; }
                RPG.perms.setGroupNode(id, node, v === "clear" ? null : v !== "false");
                essMsg(p, "&7" + id + ": &f" + node + " &7= &f" + v);
                return;
            }
            case "list":
                if (!need("ranks.list")) return;
                essMsg(p, "&7Ranks (heaviest first):");
                rkIds().forEach((id) => { let r = RK_RANKS[id]; rkLine(p, "  &f" + id + " &8- " + r.prefix + r.nameColor + r.name + r.suffix + " &8w" + r.weight + (r.isDefault ? " &a(default)" : "")); });
                return;
            case "info":
                if (!p && !args[1]) return;
                if (args[1] && !essHas(p, "ranks.list")) { essMsg(p, "&cYou can only see your own rank."); return; }
                rkInfoLines(p, args[1] ? String(args[1]) : null);
                return;
        }
        essMsg(p, "&7/rank &f[gui] &8| &7create <id> [name] &8| &7delete <id> &8| &7set/add <player> <rank> [days] &8| &7remove <player> <rank> &8| &7perm <rank> <node> [true|false|clear] &8| &7list &8| &7info [player|rank]");
    }
});
