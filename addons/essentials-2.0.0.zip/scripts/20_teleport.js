// =====================================================================================
//  Essentials - spawn, homes, warps, /tpa, /back, /top
// =====================================================================================

// ---- spawn ----
essCmd("setspawn", { desc: "Set the server spawn here" }, (p) => { RPG.data.set("ess.spawn", essLoc(p)); essMsg(p, "&aSpawn set."); });
essCmd("spawn", { desc: "Go to spawn" }, (p, args) => {
    let s = RPG.data.get("ess.spawn");
    if (!s) { essMsg(p, "&cNo spawn has been set (/setspawn)."); return; }
    let who = args.length && essHas(p, "essentials.spawn.others") ? essFind(p, args[0]) : p;
    if (who) essTeleport(who, s, "spawn");
});
RPG.on("firstJoin", (p) => {
    p.setMoney(ESS_CFG.get("startingMoney"));
    let s = RPG.data.get("ess.spawn");
    if (ESS_CFG.get("spawnOnFirstJoin") && s) RPG.schedule(5, () => p.teleportTo(s.dim, s.x, s.y, s.z, s.yaw, s.pitch));
});

// ---- homes ----
function essHomes(p) { return p.getVar("ess_homes", {}) || {}; }
function essMaxHomes(p) {
    if (essHas(p, "essentials.homes.unlimited")) return 9999;
    let max = ESS_CFG.get("homes.max");
    [5, 10, 20, 50, 100].forEach((n) => { if (essHas(p, "essentials.homes." + n)) max = Math.max(max, n); });
    return max;
}
essCmd("sethome", { desc: "Save a home here: /sethome [name]", suggest: () => [] }, (p, args) => {
    let homes = essHomes(p), name = (args[0] || "home").toLowerCase();
    if (!homes[name] && Object.keys(homes).length >= essMaxHomes(p)) { essMsg(p, "&cYou already have " + essMaxHomes(p) + " homes. /delhome one first."); return; }
    homes[name] = essLoc(p);
    p.setVar("ess_homes", homes);
    essMsg(p, "&aHome &f" + name + "&a set.");
});
function homeNames(p) { return Object.keys(essHomes(p)); }
essCmd("home", { desc: "Go home: /home [name]", aliases: ["h"], suggest: (p) => homeNames(p) }, (p, args) => {
    let homes = essHomes(p), names = Object.keys(homes);
    if (!names.length) { essMsg(p, "&cNo homes yet. /sethome first."); return; }
    let name = (args[0] || (homes.home ? "home" : names[0])).toLowerCase();
    if (!homes[name]) { essMsg(p, "&cNo home called &f" + name + "&c. Yours: &f" + names.join(", ")); return; }
    essTeleport(p, homes[name], "home " + name);
});
essCmd("delhome", { desc: "Delete a home", suggest: (p) => homeNames(p) }, (p, args) => {
    let homes = essHomes(p), name = (args[0] || "home").toLowerCase();
    if (!homes[name]) { essMsg(p, "&cNo home called &f" + name); return; }
    delete homes[name];
    p.setVar("ess_homes", homes);
    essMsg(p, "&7Home &f" + name + "&7 deleted.");
});
essCmd("homes", { desc: "List your homes" }, (p) => {
    let names = homeNames(p);
    let max = essMaxHomes(p) >= 9999 ? "\u221e" : essMaxHomes(p);
    essMsg(p, names.length ? "&7Homes (" + names.length + "/" + max + "): &f" + names.join(", ") : "&7No homes yet.");
});

// ---- warps ----
function essWarps() { return RPG.data.get("ess.warps", {}) || {}; }
essCmd("setwarp", { desc: "Create a warp here", suggest: () => [] }, (p, args) => {
    if (!args.length) { essMsg(p, "&c/setwarp <name>"); return; }
    let w = essWarps(); w[args[0].toLowerCase()] = essLoc(p); RPG.data.set("ess.warps", w);
    essMsg(p, "&aWarp &f" + args[0] + "&a set.");
});
essCmd("delwarp", { desc: "Delete a warp", suggest: () => Object.keys(essWarps()) }, (p, args) => {
    let w = essWarps(), n = (args[0] || "").toLowerCase();
    if (!w[n]) { essMsg(p, "&cNo warp called &f" + n); return; }
    delete w[n]; RPG.data.set("ess.warps", w); essMsg(p, "&7Warp &f" + n + "&7 deleted.");
});
essCmd("warp", { desc: "Go to a warp", suggest: () => Object.keys(essWarps()) }, (p, args) => {
    let w = essWarps(), n = (args[0] || "").toLowerCase();
    if (!n) { essMsg(p, "&7Warps: &f" + (Object.keys(w).join(", ") || "none")); return; }
    if (!w[n]) { essMsg(p, "&cNo warp called &f" + n); return; }
    essTeleport(p, w[n], "warp " + n);
});
essCmd("warps", { desc: "List warps" }, (p) => essMsg(p, "&7Warps: &f" + (Object.keys(essWarps()).join(", ") || "none")));

// ---- /tpa ----
var ESS_TPA = {};       // target uuid -> {from uuid, here: bool, at}
function essRequest(p, args, here) {
    let t = essFind(p, args[0]);
    if (!t || t.uuid === p.uuid) { if (t) essMsg(p, "&cThat's you."); return; }
    ESS_TPA[t.uuid] = { from: p.uuid, name: p.name, here: here, at: RPG.server.getTick() };
    essMsg(p, "&7Request sent to &f" + t.name + "&7.");
    essMsg(t, "&f" + p.name + (here ? " &7wants you to teleport to them." : " &7wants to teleport to you.") + " &a/tpaccept &7or &c/tpdeny");
    t.playSound("minecraft:block.note_block.pling", 0.7, 1.4);
}
essCmd("tpa", { desc: "Ask to teleport to someone" }, (p, args) => essRequest(p, args, false));
essCmd("tpahere", { desc: "Ask someone to teleport to you" }, (p, args) => essRequest(p, args, true));
essCmd("tpaccept", { desc: "Accept a teleport request", aliases: ["tpyes"] }, (p) => {
    let r = ESS_TPA[p.uuid];
    delete ESS_TPA[p.uuid];
    if (!r || RPG.server.getTick() - r.at > ESS_CFG.get("teleport.tpaTimeout") * 20) { essMsg(p, "&cNo request (or it ran out)."); return; }
    let from = RPG.server.players().filter((q) => q.uuid === r.from)[0];
    if (!from) { essMsg(p, "&c" + r.name + " left."); return; }
    essMsg(from, "&a" + p.name + " accepted.");
    if (r.here) essTeleport(p, essLoc(from), from.name); else essTeleport(from, essLoc(p), p.name);
});
essCmd("tpdeny", { desc: "Refuse a teleport request", aliases: ["tpno"] }, (p) => {
    let r = ESS_TPA[p.uuid];
    delete ESS_TPA[p.uuid];
    essMsg(p, r ? "&7Request refused." : "&cNo request.");
    let from = r ? RPG.server.players().filter((q) => q.uuid === r.from)[0] : null;
    if (from) essMsg(from, "&c" + p.name + " refused your request.");
});
essCmd("tpacancel", { desc: "Cancel your teleport request" }, (p) => {
    Object.keys(ESS_TPA).forEach((k) => { if (ESS_TPA[k].from === p.uuid) delete ESS_TPA[k]; });
    essMsg(p, "&7Requests cancelled.");
});

// ---- back / top ----
essCmd("back", { desc: "Go back to where you were (or died)" }, (p) => {
    let b = p.getVar("ess_back");
    if (!b) { essMsg(p, "&cNowhere to go back to."); return; }
    essTeleport(p, b, "your last location");
});
essCmd("top", { desc: "Go to the highest block above you" }, (p) => {
    let r = RPG.world.raycast(p.dimension, p.x, 319, p.z, 0, -1, 0, 400, { entities: false });
    if (r.hit !== "block") { essMsg(p, "&cNothing above."); return; }
    essTeleport(p, { dim: p.dimension, x: p.x, y: r.blockY + 1, z: p.z, yaw: p.yaw, pitch: p.pitch }, "the top");
});
