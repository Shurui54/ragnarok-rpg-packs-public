// =====================================================================================
//  Essentials - settings, permission groups and ranks defaults
// =====================================================================================
//  Settings: ragnarok_rpg/config/essentials.json, or in game /rpg config essentials <key> <value>.
//  Ranks and kits are made in game and saved with the world:
//      /rank       rank editor (every rank IS a permission group: weight, parent, prefix,
//                  colours, badge, permission toggles, members, timed ranks)
//      /kitadmin   kit editor (capture your inventory or drag items in, cooldowns, costs,
//                  one-time and first-join kits, rank access)
//  Every command checks a permission node. The groups below are the defaults and the
//  first ranks of a new world; change them in the rank editor (/rank, Permissions tab)
//  or with /rpg perm. Operators have every node.
// =====================================================================================

var ESS_CFG = RPG.config.define("essentials", {
    prefix: { default: "&6[&eEss&6] &r", comment: "Put before this addon's chat messages" },
    currency: { default: "", comment: "Money symbol for /bal, /pay and kit prices (empty: the project's currency symbol)" },
    startingMoney: { default: 100, min: 0, max: 1e12, comment: "Money a player starts with on their first join" },
    spawnOnFirstJoin: { default: true, comment: "Send new players to /spawn on their first join" },
    motd: { default: ["&6Welcome, &e{name}&6!", "&7Type &f/commands&7 to see what you can do."], comment: "Lines shown on join ({name}: the player's name)" },
    homes: {
        max: { default: 3, min: 0, max: 9999, integer: true, comment: "Homes per player (more with essentials.homes.<n>, e.g. essentials.homes.10, or essentials.homes.unlimited)" }
    },
    teleport: {
        delay: { default: 3, min: 0, max: 60, integer: true, comment: "Seconds standing still before a teleport (essentials.teleport.instant skips it)" },
        tpaTimeout: { default: 60, min: 5, max: 3600, integer: true, comment: "Seconds a /tpa request stays open" }
    },
    afkMinutes: { default: 5, min: 1, max: 1440, integer: true, comment: "Idle minutes before someone is marked AFK" },
    chat: {
        enabled: { default: true, comment: "Format chat lines with the sender's rank" },
        format: { default: "{badge}{prefix}{color}{name}{suffix}&8 » {chatcolor}{message}",
            comment: "Tokens: {badge} (the rank's badge picture; put in front when the format has no {badge}) {prefix} {suffix} {color} (name colour) {name} (nickname or name) {rank} (rank name) {chatcolor} {message}" },
        colorNode: { default: "ranks.chat.color", comment: "Players with this node may use & colour codes in chat" }
    },
    tab: {
        teams: { default: true, comment: "Put players in a scoreboard team per rank: prefix/suffix and colour over heads and in the tab list, tab list sorted by rank" },
        respectOtherTeams: { default: true, comment: "Leave players alone who are in a team another addon or /team made" }
    },
    badges: {
        tab: { default: true, comment: "Show a rank's badge picture before names in the tab list and over heads (part of the rank team's prefix)" },
        chat: { default: true, comment: "Show a rank's badge picture in chat ({badge} in chat.format)" },
        chatHeight: { default: 0, min: 0, max: 32, integer: true, comment: "Badge height in chat in pixels (0: one chat row, 9; taller badges overlap the lines around them)" }
    },
    ranks: {
        checkSeconds: { default: 30, min: 5, max: 3600, integer: true, comment: "How often timed ranks are checked for expiry" },
        announce: { default: true, comment: "Tell a player when they get or lose a rank" }
    },
    kits: {
        firstJoinDelay: { default: 40, min: 0, max: 1200, integer: true, comment: "Ticks after a first join before first-join kits are given" }
    }
});

// The default permission groups. Each is also a rank (made on a world's first start, styled in /rank).
RPG.perms.group("default", [
    "essentials.help", "essentials.spawn", "essentials.home", "essentials.sethome", "essentials.delhome", "essentials.homes",
    "essentials.warp", "essentials.warps", "essentials.tpa", "essentials.tpahere", "essentials.tpaccept", "essentials.tpdeny",
    "essentials.tpacancel", "essentials.back", "essentials.msg", "essentials.bal", "essentials.pay", "essentials.baltop",
    "essentials.afk", "essentials.near", "essentials.ping", "essentials.seen", "essentials.suicide",
    "ranks.info", "ranks.list", "kits.use"
]);
RPG.perms.group("vip", [
    "essentials.homes.10", "essentials.nick", "essentials.hat", "essentials.enderchest", "essentials.feed",
    "essentials.top", "essentials.teleport.instant", "ranks.chat.color"
], ["default"]);
RPG.perms.group("admin", ["essentials.*", "ranks.*", "kits.*"], ["vip"]);

// The first ranks of a new world (one per default group) and the first kits. Only used once per world.
var ESS_SEED_RANKS = {
    "default": { name: "Member", prefix: "&7", nameColor: "&7", weight: 0, isDefault: true },
    "vip": { name: "VIP", prefix: "&a[VIP] ", nameColor: "&f", weight: 50, kitMult: 0.5 },
    "admin": { name: "Admin", prefix: "&c[Admin] ", nameColor: "&f", chatColor: "&f", weight: 100, kitMult: 0 }
};
var ESS_SEED_KITS = {
    starter: { name: "&aStarter", icon: "minecraft:stone_sword", once: true, firstJoin: true,
        items: ["minecraft:stone_sword", "minecraft:stone_pickaxe", "minecraft:stone_axe", { id: "minecraft:bread", count: 16 }, { id: "minecraft:torch", count: 16 }] },
    tools: { name: "&bTools", icon: "minecraft:iron_pickaxe", cooldown: 86400,
        items: ["minecraft:iron_pickaxe", "minecraft:iron_shovel", "minecraft:iron_axe"] },
    food: { name: "&6Food", icon: "minecraft:cooked_beef", cooldown: 3600,
        items: [{ id: "minecraft:cooked_beef", count: 16 }, { id: "minecraft:golden_carrot", count: 8 }] },
    vip: { name: "&dVIP", icon: "minecraft:diamond", cooldown: 604800, rank: "vip",
        items: [{ id: "minecraft:diamond", count: 3 }, { id: "minecraft:golden_apple", count: 2 }, { id: "minecraft:experience_bottle", count: 16 }] }
};
