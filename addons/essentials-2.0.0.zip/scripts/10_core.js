// =====================================================================================
//  Essentials - shared helpers (used by the other files of this addon)
// =====================================================================================

/** A message with this addon's prefix (the server log when p is null: the console). */
function essMsg(p, text) { if (p) p.tell(ESS_CFG.get("prefix") + text); else RPG.log(String(text).replace(/&./g, "")); }
/** Whether a player has a permission node (the console has every node). */
function essHas(p, node) { return !p || RPG.perms.has(p, node); }
function essMoney(n) {
    let sym = ESS_CFG.get("currency") || ((RPG.currency.get() || {}).symbol) || "$";
    return sym + (Math.round(n * 100) / 100).toLocaleString();
}

/** "1d 2h 30m", "90m", "45s", "3600" (seconds) -> seconds; NaN when unreadable. */
function essParseDuration(text) {
    let s = String(text === undefined || text === null ? "" : text).trim().toLowerCase();
    if (s === "" || s === "0" || s === "none" || s === "off") return 0;
    if (/^\d+(\.\d+)?$/.test(s)) return Math.round(parseFloat(s));
    let total = 0, any = false, re = /(\d+(?:\.\d+)?)\s*(w|d|h|m|s)/g, m;
    while ((m = re.exec(s)) !== null) {
        any = true;
        total += parseFloat(m[1]) * { w: 604800, d: 86400, h: 3600, m: 60, s: 1 }[m[2]];
    }
    return any && s.replace(re, "").trim() === "" ? Math.round(total) : NaN;
}

/** Seconds -> "1d 2h", "5m 10s", "0s". */
function essDuration(sec) {
    sec = Math.max(0, Math.ceil(sec));
    if (sec < 60) return sec + "s";
    let d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
    if (d) return d + "d" + (h ? " " + h + "h" : "");
    if (h) return h + "h" + (m ? " " + m + "m" : "");
    return m + "m" + (s ? " " + s + "s" : "");
}

/** Where a player is right now (for homes, warps, /back). */
function essLoc(p) { return { dim: p.dimension, x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch }; }

/** An online player by exact or partial name, or null (and tells `asker` why). */
function essFind(asker, name) {
    if (!name) { essMsg(asker, "&cWho? Give a player name."); return null; }
    let exact = RPG.server.player(name);
    if (exact) return exact;
    let low = name.toLowerCase(), hits = RPG.server.players().filter((q) => q.name.toLowerCase().indexOf(low) === 0);
    if (hits.length === 1) return hits[0];
    essMsg(asker, hits.length ? "&cMore than one player matches &f" + name : "&cNo player online called &f" + name);
    return null;
}

function essOnlineNames() { return RPG.server.players().map((q) => q.name); }

/** Teleport with a short stand-still warm-up; remembers where they were for /back. */
var ESS_WARMUP = {};
function essTeleport(p, loc, what) {
    let go = () => {
        p.setVar("ess_back", essLoc(p));
        p.teleportTo(loc.dim, loc.x, loc.y, loc.z, loc.yaw || 0, loc.pitch || 0);
        p.playSound("minecraft:entity.enderman.teleport", 0.6, 1.2);
        essMsg(p, "&7Teleported to &f" + what + "&7.");
    };
    let delay = ESS_CFG.get("teleport.delay");
    if (delay <= 0 || essHas(p, "essentials.teleport.instant")) { go(); return; }
    let start = essLoc(p), serial = (ESS_WARMUP[p.uuid] || 0) + 1, left = delay * 20;
    ESS_WARMUP[p.uuid] = serial;
    essMsg(p, "&7Teleporting in &f" + delay + "&7s, don't move...");
    let tick = () => {
        if (ESS_WARMUP[p.uuid] !== serial) return;
        if (Math.abs(p.x - start.x) + Math.abs(p.y - start.y) + Math.abs(p.z - start.z) > 0.6) { essMsg(p, "&cTeleport cancelled: you moved."); return; }
        left -= 5;
        if (left <= 0) go(); else RPG.schedule(5, tick);
    };
    RPG.schedule(5, tick);
}

/** Registers a top-level command guarded by essentials.<name>. */
function essCmd(name, opts, run) {
    RPG.commands.register(name, {
        root: true,
        aliases: opts.aliases || [],
        description: opts.desc || "",
        permission: "essentials." + (opts.perm || name),
        suggest: opts.suggest || ((p, args) => args.length <= 1 ? essOnlineNames() : []),
        run(p, args) { if (!p && !opts.console) return; run(p, args); }
    });
}

// remember where players died, for /back
RPG.on("death", (p) => { p.setVar("ess_back", essLoc(p)); });
