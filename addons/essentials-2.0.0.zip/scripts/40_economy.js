// =====================================================================================
//  Essentials - money: /bal, /pay, /baltop, /eco
// =====================================================================================
//  Uses the player's money (player.getMoney / addMoney). /baltop reads a leaderboard that
//  is updated whenever money changes here, and on join/leave.

function essBoard(p) { RPG.data.setScore("ess.money", p, p.getMoney()); }
RPG.on("playerJoin", essBoard);
RPG.on("playerLeave", essBoard);

essCmd("bal", { desc: "Your money", aliases: ["balance", "money"] }, (p, args) => {
    let t = args.length && essHas(p, "essentials.bal.others") ? essFind(p, args[0]) : p;
    if (t) essMsg(p, "&7" + (t === p ? "Balance" : t.name + "'s balance") + ": &a" + essMoney(t.getMoney()));
});
essCmd("pay", { desc: "Give money: /pay <player> <amount>" }, (p, args) => {
    let t = essFind(p, args[0]), amt = parseFloat(args[1]);
    if (!t) return;
    if (t.uuid === p.uuid) { essMsg(p, "&cYou can't pay yourself."); return; }
    if (!(amt > 0)) { essMsg(p, "&c/pay <player> <amount>"); return; }
    amt = Math.floor(amt * 100) / 100;
    if (!p.takeMoney(amt)) { essMsg(p, "&cYou don't have " + essMoney(amt) + "."); return; }
    t.addMoney(amt);
    essBoard(p); essBoard(t);
    essMsg(p, "&7Sent &a" + essMoney(amt) + "&7 to &f" + t.name);
    essMsg(t, "&f" + p.name + " &7sent you &a" + essMoney(amt));
});
essCmd("baltop", { desc: "The richest players", suggest: () => [] }, (p) => {
    RPG.server.players().forEach(essBoard);
    essMsg(p, "&6Richest players:");
    RPG.data.top("ess.money", 10).forEach((e) => p.tell("  &e" + e.rank + ". &f" + e.name + " &a" + essMoney(e.score)));
});
essCmd("eco", { desc: "/eco give|take|set <player> <amount>", suggest: (p, args) => args.length <= 1 ? ["give", "take", "set"] : essOnlineNames() }, (p, args) => {
    let t = essFind(p, args[1]), amt = parseFloat(args[2]);
    if (!t || isNaN(amt)) { if (t) essMsg(p, "&c/eco give|take|set <player> <amount>"); return; }
    if (args[0] === "give") t.addMoney(amt); else if (args[0] === "take") t.setMoney(Math.max(0, t.getMoney() - amt)); else if (args[0] === "set") t.setMoney(amt);
    else { essMsg(p, "&c/eco give|take|set <player> <amount>"); return; }
    essBoard(t);
    essMsg(p, "&f" + t.name + "&7 now has &a" + essMoney(t.getMoney()));
});
