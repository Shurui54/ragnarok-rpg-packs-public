# Essentials

Server basics for Ragnarok worlds, with ranks and kits made in game.

- **Teleports**: `/spawn` `/setspawn`, `/home` `/sethome` `/delhome` `/homes`, `/warp` `/warps` `/setwarp` `/delwarp`,
  `/tpa` `/tpahere` `/tpaccept` `/tpdeny` `/tpacancel`, `/back` (also to where you died), `/top`. Teleports wait a few
  seconds standing still unless you have `essentials.teleport.instant`.
- **Players**: `/m` (`/whisper`, `/pm`) and `/r`, `/nick`, `/afk` (and idle AFK), `/near`, `/ping`, `/seen`, `/commands`.
- **Money**: `/bal`, `/pay`, `/baltop`, `/eco give|take|set`.
- **Admin tools**: `/heal` `/feed` `/fly` `/god`, `/gmc` `/gms` `/gma` `/gmsp`, `/day` `/night` `/sun`, `/broadcast`,
  `/enderchest`, `/hat`, `/repair`, `/invsee`, `/suicide`.
- **Ranks** (`/rank`, also `/ranks`): one ranks and permissions model. Every rank is a permission group with its look
  (chat and tab prefix and suffix, name and chat colours with colour pickers, a badge picture), a weight (the heaviest
  rank a player has is the one shown), a parent to inherit from, permission toggles and members. Ranks can be given
  for a time (`/rank add Steve vip 30` = 30 days), also to players who are offline or never joined.
  `/rank create|delete|set|add|remove|perm|list|info`; `/rank` alone opens the editor.
  Players in a rank's group through `/rpg perm` have that rank: both always agree.
- **Kits** (`/kitadmin`, also `/kitedit`): capture your inventory (armour, off hand and all item data) or drag items in;
  cooldowns (a rank can shorten them), costs, one-time and first-join kits, a needed rank or permission node.
  Players browse and preview them with `/kits` and claim with a right click or `/kit <name>`.

A new world starts with the ranks Member (everyone), VIP and Admin (each is also the permission group of that name)
and the kits Starter, Tools, Food and VIP.

## Permissions

Commands check `essentials.<command>` (`essentials.<command>.others` to use one on someone else), plus:
`ranks.info` (own rank), `ranks.list`, `ranks.manage` (edit ranks), `ranks.assign` (give and take ranks),
`ranks.chat.color` (& colours in chat), `kits.use`, `kits.admin`, `kits.kit.<id>` (always allowed that kit),
`essentials.homes.<n>` / `essentials.homes.unlimited`, `essentials.teleport.instant`. Operators have every node.

## Settings

`ragnarok_rpg/config/essentials.json`, or in game `/rpg config essentials <key> <value>`.
