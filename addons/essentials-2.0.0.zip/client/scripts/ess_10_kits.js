// =====================================================================================
//  Essentials - kit editor screens (/kitadmin); the rank editor (/rank) is ess_30_ranks.js
// =====================================================================================
//  Everything here only draws and sends requests; the server checks permissions and
//  saves. Enter saves (or does the screen's main action), Escape goes back.
// =====================================================================================

var RKC = { list: null, rank: null, kits: null, kit: null, money: "$" };
var RKC_HEX = { "0": "#000000", "1": "#0000AA", "2": "#00AA00", "3": "#00AAAA", "4": "#AA0000", "5": "#AA00AA", "6": "#FFAA00", "7": "#AAAAAA",
    "8": "#555555", "9": "#5555FF", "a": "#55FF55", "b": "#55FFFF", "c": "#FF5555", "d": "#FF55FF", "e": "#FFFF55", "f": "#FFFFFF" };
var RKC_CODES = ["f", "7", "8", "0", "c", "4", "6", "e", "a", "2", "b", "3", "9", "1", "d", "5"];
// vanilla look: the grey window, dark grey text (#404040) on it; list rows are light washes over the grey
var RKC_UI = { text: "#404040", row: "#14000000", rowHover: "#50FFFFFF" };
/** & text written for dark panels, readable on the grey window: white becomes the window's dark grey, light colours their dark twins. */
function rkcW(s) {
    return String(s === undefined || s === null ? "" : s).replace(/&([0-9a-fk-or])/gi, function (m, c) {
        var to = { f: "r", "7": "8", c: "4", a: "2", e: "6", b: "3", d: "5" }[c.toLowerCase()];
        return "&" + (to || c);
    });
}

// ---- small helpers ------------------------------------------------------------------------------------

function rkcClamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function rkcPlain(s) { return String(s || "").replace(/&[0-9a-fk-or]/gi, ""); }
function rkcVal(id) { let v = RPG.screen.value(id); return v === null || v === undefined ? "" : String(v); }
function rkcDur(sec) {
    sec = Math.max(0, Math.ceil(sec));
    if (sec < 60) return sec + "s";
    let d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
    if (d) return d + "d" + (h ? " " + h + "h" : "");
    if (h) return h + "h" + (m ? " " + m + "m" : "");
    return m + "m" + (s ? " " + s + "s" : "");
}
function rkcSend(ch, d) { RPG.net.send(ch, d); }

/** A panel with a header strip; returns {L, T, W, H} for placing the rest. */
function rkcFrame(els, W, H, title, sub) {
    let L = -W / 2, T = -H / 2;
    els.push({ id: "panel", type: "panel", anchor: "center", x: L, y: T, w: W, h: H });
    els.push({ id: "head", type: "rect", anchor: "center", x: L + 4, y: T + 19, w: W - 8, h: 1, color: "#FF555555" });
    els.push({ id: "headline", type: "rect", anchor: "center", x: L + 4, y: T + 20, w: W - 8, h: 1, color: "#FFFFFFFF" });
    els.push({ id: "title", type: "text", anchor: "center", x: L + 8, y: T + 6, text: rkcW(title), color: RKC_UI.text, shadow: false });
    if (sub) els.push({ id: "sub", type: "text", anchor: "center", x: L + W - 8, y: T + 6, w: 0, text: rkcW(sub), align: "right", color: RKC_UI.text, shadow: false });
    // status line, left of the footer buttons (two short lines at most)
    els.push({ id: "note", type: "text", anchor: "center", x: L + 8, y: T + H - 22, text: "", scale: 0.75, wrap: W - 185, color: RKC_UI.text, shadow: false });
    return { L: L, T: T, W: W, H: H };
}
function rkcText(els, id, x, y, text, extra) {
    // on the grey window: dark text, no shadow (extra.light keeps the light colours for text on a black inset)
    let light = extra && extra.light;
    let e = light ? { id: id, type: "text", anchor: "center", x: x, y: y, text: text }
        : { id: id, type: "text", anchor: "center", x: x, y: y, text: rkcW(text), color: RKC_UI.text, shadow: false };
    if (extra) Object.keys(extra).forEach((k) => { if (k !== "light") e[k] = extra[k]; });
    if (e.align && e.w === undefined) e.w = 0;          // centre/right align around x itself
    els.push(e); return e;
}
function rkcButton(els, id, x, y, w, h, label, fn, extra) {
    let e = { id: id, type: "button", anchor: "center", x: x, y: y, w: w, h: h, label: label, onClick: fn };
    if (extra) Object.keys(extra).forEach((k) => { e[k] = extra[k]; });
    els.push(e); return e;
}
function rkcInput(els, id, x, y, w, value, max, extra) {
    let e = { id: id, type: "input", anchor: "center", x: x, y: y, w: w, h: 16, value: value === undefined || value === null ? "" : String(value), maxLength: max || 32 };
    if (extra) Object.keys(extra).forEach((k) => { e[k] = extra[k]; });
    els.push(e); return e;
}
function rkcLabel(els, id, x, y, text) { return rkcText(els, id, x, y, "&7" + text); }

var RKC_NOTE = { text: "", bad: false, at: 0 };
function rkcNote(text, bad) {
    RKC_NOTE = { text: text || "", bad: !!bad, at: RPG.time() };
    if (rkcOwnScreen()) RPG.screen.update("note", { text: text ? (bad ? "&4" : "&2") + text : "" });
}
RPG.every(20, () => {
    if (RKC_NOTE.text && RPG.time() - RKC_NOTE.at > 100) { RKC_NOTE.text = ""; if (rkcOwnScreen()) RPG.screen.update("note", { text: "" }); }
});
/** One of the kit screens (they have a "note" line; the rank editor draws its own). */
function rkcOwnScreen() { let o = RPG.screen.getOpen(); return !!o && (o.indexOf("kt") === 0 || o === "rk_ask"); }
function rkcShowNote() { if (rkcOwnScreen() && RKC_NOTE.text && RPG.time() - RKC_NOTE.at < 100) RPG.screen.update("note", { text: (RKC_NOTE.bad ? "&4" : "&2") + RKC_NOTE.text }); }

/** Outline (2 px) around a rect given in center-anchored coordinates, from onRender. */
function rkcOutline(ctx, x, y, w, h, color) {
    let x0 = ctx.width / 2 + x, y0 = ctx.height / 2 + y;
    ctx.fill(x0 - 1, y0 - 1, w + 2, 1, color, 1); ctx.fill(x0 - 1, y0 + h, w + 2, 1, color, 1);
    ctx.fill(x0 - 1, y0, 1, h, color, 1); ctx.fill(x0 + w, y0, 1, h, color, 1);
}

// ---- a small "name it" dialog (new rank / new kit) ------------------------------------------------------

var RKC_ASK = null;
function rkcAsk(title, fields, buttons, back) {
    RKC_ASK = { fields: fields, buttons: buttons, back: back };
    let els = [], W = 280, H = 78 + fields.length * 34;
    let f = rkcFrame(els, W, H, title, "");
    els.forEach((e) => { if (e.id === "note") { e.y = f.T + H - 40; e.wrap = W - 20; } });
    fields.forEach((fd, i) => {
        rkcLabel(els, "l_" + fd.id, f.L + 10, f.T + 28 + i * 34, fd.label);
        rkcInput(els, fd.id, f.L + 10, f.T + 38 + i * 34, W - 20, fd.value || "", fd.max || 32, { autofocus: i === 0, hint: fd.hint || "" });
    });
    let bw = Math.floor((W - 20 - (buttons.length) * 4) / (buttons.length + 1));
    buttons.forEach((b, i) => {
        rkcButton(els, "b" + i, f.L + 10 + i * (bw + 4), f.T + H - 26, bw, 18, b.label, () => rkcAskDo(i));
    });
    rkcButton(els, "back", f.L + W - 10 - bw, f.T + H - 26, bw, 18, "Back", () => { RKC_ASK = null; back(); });
    RPG.screen.open({ id: "rk_ask", background: "dim", elements: els, onKey: (k, action) => {
        if (action !== "down") return;
        if (k === "key.keyboard.enter" || k === "key.keyboard.keypad.enter") { rkcAskDo(0); return false; }
        if (k === "key.keyboard.escape") { let b = RKC_ASK && RKC_ASK.back; RKC_ASK = null; if (b) b(); return false; }
    } });
}
function rkcAskDo(i) {
    if (!RKC_ASK) return;
    let vals = {};
    RKC_ASK.fields.forEach((fd) => { vals[fd.id] = rkcVal(fd.id).trim(); });
    RKC_ASK.buttons[i].fn(vals);
}

// The rank editor (/rank) is in rk_20_editor.js.

// =====================================================================================
//  Kit list and kit editor (/kitadmin)
// =====================================================================================
var KTL = { scroll: 0, confirm: null, rows: 9 };

function ktcList() {
    let kits = RKC.kits || [];
    KTL.rows = rkcClamp(Math.floor((RPG.screenHeight - 100) / 22), 4, 10);
    let RH = 22, W = 340, H = 58 + KTL.rows * RH + 24, els = [];
    let f = rkcFrame(els, W, H, "&fKits", "&8/kits is the players' menu");
    rkcText(els, "hint", f.L + 8, f.T + 26, "&7Click a kit to edit it. New kits can start from your inventory.", { scale: 0.75 });
    for (let i = 0; i < KTL.rows; i++) {
        (function (row) {
            let y = f.T + 38 + row * RH;
            els.push({ id: "row" + row, type: "rect", anchor: "center", x: f.L + 6, y: y, w: W - 40, h: RH - 2, color: RKC_UI.row, hoverColor: RKC_UI.rowHover,
                onClick: () => ktcListAct(row, "edit") });
            els.push({ id: "ic" + row, type: "item", anchor: "center", x: f.L + 9, y: y + 2, w: 16, h: 16, item: "minecraft:chest" });
            rkcText(els, "nm" + row, f.L + 30, y + 6, "");
            rkcText(els, "meta" + row, f.L + W - 40, y + 7, "", { align: "right", scale: 0.75 });
            rkcButton(els, "del" + row, f.L + W - 30, y, 24, RH - 2, "&cX", () => ktcListAct(row, "del"), { tooltip: "Delete this kit" });
        })(i);
    }
    rkcText(els, "empty", 0, f.T + 60, "&7No kits yet. Make one with New kit.", { align: "center", visible: false });
    rkcButton(els, "new", f.L + W - 168, f.T + H - 22, 80, 18, "New kit", ktcNewKit, { tooltip: "Enter" });
    rkcButton(els, "close", f.L + W - 84, f.T + H - 22, 78, 18, "Close", () => RPG.screen.close());
    RPG.screen.open({ id: "kt_list", background: "dim", elements: els,
        onScroll: (x, y, delta) => { KTL.scroll += delta < 0 ? 1 : -1; ktcListRefresh(); },
        onKey: (k, action) => { if (action === "down" && (k === "key.keyboard.enter" || k === "key.keyboard.keypad.enter")) { ktcNewKit(); return false; } } });
    ktcListRefresh();
    rkcShowNote();
}

function ktcListRefresh() {
    if (RPG.screen.getOpen() !== "kt_list") return;
    let all = RKC.kits || [];
    KTL.scroll = rkcClamp(KTL.scroll, 0, Math.max(0, all.length - KTL.rows));
    RPG.screen.update("empty", { visible: all.length === 0 });
    for (let i = 0; i < KTL.rows; i++) {
        let k = all[i + KTL.scroll], show = !!k;
        ["row", "ic", "nm", "meta", "del"].forEach((n) => RPG.screen.update(n + i, { visible: show }));
        if (!k) continue;
        let tags = [];
        tags.push(k.once ? "one time" : k.cooldown ? "every " + rkcDur(k.cooldown) : "no cooldown");
        if (k.cost > 0) tags.push(RKC.money + k.cost);
        if (k.firstJoin) tags.push("first join");
        if (k.rank || k.permission) tags.push("locked");
        RPG.screen.update("ic" + i, { item: k.icon || "minecraft:chest" });
        RPG.screen.update("nm" + i, { text: rkcW("&f" + k.name) });
        RPG.screen.update("meta" + i, { text: rkcW("&7" + k.count + " stacks &8· &7" + tags.join(" &8· &7")) });
        RPG.screen.update("del" + i, { label: KTL.confirm === k.id ? "&c?" : "&cX" });
    }
}

function ktcListAct(row, what) {
    let k = (RKC.kits || [])[row + KTL.scroll];
    if (!k) return;
    if (what === "edit") { rkcSend("kt", { a: "get", id: k.id }); return; }
    if (KTL.confirm !== k.id) { KTL.confirm = k.id; rkcNote("Click ? again to delete " + rkcPlain(k.name) + ".", true); ktcListRefresh(); return; }
    KTL.confirm = null;
    rkcSend("kt", { a: "delete", id: k.id });
}

function ktcNewKit() {
    let make = (v, capture) => { if (!v.kid) { rkcNote("Give it an id.", true); return; } rkcSend("kt", { a: "create", id: v.kid.toLowerCase(), name: v.kname, capture: capture }); };
    rkcAsk("&fNew kit", [
        { id: "kid", label: "Id (players type /kit <id>)", max: 24, hint: "warrior" },
        { id: "kname", label: "Display name (& colours)", max: 40, hint: "&cWarrior" }
    ], [{ label: "From inventory", fn: (v) => make(v, true) }, { label: "Empty", fn: (v) => make(v, false) }],
    () => rkcSend("kt", { a: "list", open: true }));
}

// ---- kit editor ------------------------------------------------------------------------------------------------
var KTE = { id: null, d: null, dirty: false, escArmed: false };
var KTE_W = 384, KTE_H = 262;

function ktcEdit(kit, ranks, keep) {
    RKC.kit = kit; RKC.kitRanks = ranks;
    if (!keep || KTE.id !== kit.id || !KTE.d) {
        KTE.id = kit.id;
        KTE.d = JSON.parse(JSON.stringify(kit));
        KTE.d.cooldownText = kit.cooldown ? rkcDur(kit.cooldown) : "0";
        KTE.dirty = false;
    } else {
        KTE.d.items = kit.items; KTE.d.count = kit.count; KTE.d.icon = kit.icon;
    }
    KTE.escArmed = false;
    let d = KTE.d, els = [];
    let f = rkcFrame(els, KTE_W, KTE_H, "&fKit: " + d.name, "&8/kit " + d.id);
    let L = f.L + 8, y0 = f.T + 28;
    let ch = () => { ktcRead(); KTE.dirty = true; KTE.escArmed = false; ktcPreview(); };

    rkcLabel(els, "l_name", L, y0, "Display name");
    rkcInput(els, "name", L, y0 + 10, 170, d.name, 40, { autofocus: true, onChange: ch });
    rkcLabel(els, "l_icon", L + 180, y0, "Icon");
    els.push({ id: "icon_box", type: "panel", style: "slot", anchor: "center", x: L + 180, y: y0 + 9, w: 18, h: 18 });
    els.push({ id: "icon_it", type: "item", anchor: "center", x: L + 181, y: y0 + 10, w: 16, h: 16, item: d.icon });
    rkcInput(els, "icon", L + 202, y0 + 10, 112, d.icon, 96, { onChange: ch });
    rkcButton(els, "held", L + 318, y0 + 9, KTE_W - 16 - 318, 18, "Held", () => { ktcSaveKit(true); rkcSend("kt", { a: "held", id: KTE.id }); },
        { tooltip: "Use the item in your hand as the icon" });

    rkcLabel(els, "l_cd", L, y0 + 32, "Cooldown");
    rkcInput(els, "cooldown", L, y0 + 42, 70, d.cooldownText, 20, { hint: "1d 6h", onChange: ch });
    rkcLabel(els, "l_cost", L + 78, y0 + 32, "Cost (" + RKC.money + ")");
    rkcInput(els, "cost", L + 78, y0 + 42, 54, d.cost || "", 12, { hint: "free", onChange: ch });
    rkcLabel(els, "l_perm", L + 140, y0 + 32, "Needs permission");
    rkcInput(els, "perm", L + 140, y0 + 42, KTE_W - 16 - 140, d.permission || "", 96, { hint: "none (anyone)", onChange: ch });

    rkcLabel(els, "l_rank", L, y0 + 66, "Needs rank");
    // the rank: a searchable pick list (lightest first, like the old arrows)
    els.push({ id: "rank", type: "dropdown", anchor: "center", x: L + 56, y: y0 + 62, w: 112, h: 16, value: d.rank || "",
        options: [{ value: "", label: "&8anyone" }].concat((RKC.kitRanks || []).slice().reverse().map((r) => ({ value: r.id, label: "&f" + rkcPlain(r.name) }))),
        onChange: (id, v) => { KTE.d.rank = String(v || ""); KTE.dirty = true; KTE.escArmed = false; ktcPreview(); } });
    rkcText(els, "rank2", L + 172, y0 + 67, "&8or heavier", { scale: 0.75 });
    let tw = Math.floor((KTE_W - 16 - 8) / 3);
    rkcButton(els, "once", L, y0 + 84, tw, 16, "", () => { d.once = !d.once; KTE.dirty = true; ktcPreview(); }, { tooltip: "Each player can claim it only once" });
    rkcButton(els, "equip", L + tw + 4, y0 + 84, tw, 16, "", () => { d.autoEquip = !d.autoEquip; KTE.dirty = true; ktcPreview(); }, { tooltip: "Put armour and the off-hand item on when the slot is empty" });
    rkcButton(els, "first", L + 2 * (tw + 4), y0 + 84, tw, 16, "", () => { d.firstJoin = !d.firstJoin; KTE.dirty = true; ktcPreview(); }, { tooltip: "Given free to new players on their first join" });

    // contents
    els.push({ id: "items_box", type: "panel", style: "inset", anchor: "center", x: L, y: y0 + 106, w: KTE_W - 16, h: 64 });
    rkcText(els, "items_l", L + 4, y0 + 109, "", { scale: 0.75, light: true });
    for (let i = 0; i < 40; i++) {
        els.push({ id: "it" + i, type: "item", anchor: "center", x: L + 4 + (i % 20) * 18, y: y0 + 119 + Math.floor(i / 20) * 24, w: 16, h: 16, item: "minecraft:air", visible: false });
    }
    let bw = Math.floor((KTE_W - 16 - 12) / 4);
    rkcButton(els, "capture", L, y0 + 176, bw, 18, "Take inventory", () => { ktcSaveKit(true); rkcSend("kt", { a: "capture", id: KTE.id }); },
        { tooltip: ["Replace the contents with your inventory,", "armour and off hand (enchantments and names kept)"] });
    rkcButton(els, "items", L + bw + 4, y0 + 176, bw, 18, "Edit items...", () => { ktcSaveKit(true); RPG.screen.close(); rkcSend("kt", { a: "items", id: KTE.id }); },
        { tooltip: "Drag items in and out of a chest; close it to save" });
    rkcButton(els, "preview", L + 2 * (bw + 4), y0 + 176, bw, 18, "Preview", () => { ktcSaveKit(true); RPG.screen.close(); rkcSend("kt", { a: "preview", id: KTE.id }); },
        { tooltip: "What players see in /kits" });
    rkcButton(els, "give", L + 3 * (bw + 4), y0 + 176, bw, 18, "Give me", () => rkcSend("kt", { a: "give", id: KTE.id }), { tooltip: "Get the kit now (no cost or cooldown)" });

    rkcButton(els, "save", f.L + KTE_W - 172, f.T + KTE_H - 22, 80, 18, "Save", () => ktcSaveKit(false), { tooltip: "Enter" });
    rkcButton(els, "back", f.L + KTE_W - 88, f.T + KTE_H - 22, 80, 18, "Back", ktcBack, { tooltip: "Escape" });
    RPG.screen.open({ id: "kt_edit", background: "dim", elements: els, onKey: (k, action) => {
        if (action !== "down") return;
        if (k === "key.keyboard.enter" || k === "key.keyboard.keypad.enter") { ktcSaveKit(false); return false; }
        if (k === "key.keyboard.escape") { ktcBack(); return false; }
    } });
    ktcPreview();
    rkcShowNote();
}

function ktcRead() {
    if (RPG.screen.getOpen() !== "kt_edit" || !KTE.d) return;
    let d = KTE.d;
    d.name = rkcVal("name") || d.name;
    d.icon = rkcVal("icon").trim() || "minecraft:chest";
    d.cooldownText = rkcVal("cooldown");
    d.cost = rkcVal("cost").trim();
    d.permission = rkcVal("perm").trim();
}

function ktcPreview() {
    if (RPG.screen.getOpen() !== "kt_edit") return;
    let d = KTE.d, r = (RKC.kitRanks || []).filter((x) => x.id === d.rank)[0];
    RPG.screen.update("title", { text: rkcW("&fKit: " + d.name + (KTE.dirty ? " &e*" : "")) });
    RPG.screen.update("icon_it", { item: d.icon || "minecraft:chest" });
    RPG.screen.update("rank", { value: d.rank || "" });
    RPG.screen.update("once", { label: d.once ? "&eOne time only" : "&7Repeatable" });
    RPG.screen.update("equip", { label: d.autoEquip ? "&aAuto-equip armour" : "&7Armour to inventory" });
    RPG.screen.update("first", { label: d.firstJoin ? "&aFirst-join kit" : "&7Not on first join" });
    let items = d.items || [];
    RPG.screen.update("items_l", { text: "&7Contents: &f" + items.length + " &7stack" + (items.length === 1 ? "" : "s") + (items.length > 40 ? " &8(first 40 shown)" : "") +
        (items.length ? "" : "  &8- take your inventory or edit items") });
    for (let i = 0; i < 40; i++) {
        let it = items[i];
        RPG.screen.update("it" + i, it ? { visible: true, item: it.id, count: it.count, tooltip: it.id.replace(/^minecraft:/, "") + " x" + it.count } : { visible: false });
    }
}

function ktcSaveKit(quiet) {
    ktcRead();
    let d = KTE.d;
    rkcSend("kt", { a: "save", id: KTE.id, kit: { name: d.name, icon: d.icon, cooldown: d.cooldownText, cost: d.cost, permission: d.permission,
        rank: d.rank || "", once: d.once, autoEquip: d.autoEquip, firstJoin: d.firstJoin } });
    KTE.dirty = false; KTE.escArmed = false;
    if (!quiet) rkcNote("Saving...", false);
    ktcPreview();
}

function ktcBack() {
    ktcRead();
    if (KTE.dirty && !KTE.escArmed) { KTE.escArmed = true; rkcNote("Unsaved changes: Enter saves, Esc again discards them.", true); return; }
    KTE.d = null; KTE.dirty = false;
    rkcSend("kt", { a: "list", open: true });
}

// =====================================================================================
//  Messages from the server
// =====================================================================================

RPG.net.on("kt_list", (m) => {
    RKC.kits = m.kits;
    if (m.note) RKC_NOTE = { text: m.note, bad: /^no |can't|already/i.test(m.note), at: RPG.time() };
    if (m.open || RPG.screen.getOpen() === "kt_list") { KTL.confirm = null; ktcList(); }
});
RPG.net.on("kt_kit", (m) => {
    RKC.money = m.money || RKC.money;
    if (m.note) RKC_NOTE = { text: m.note, bad: false, at: RPG.time() };
    let open = RPG.screen.getOpen();
    if (m.open || open === "rk_ask") { ktcEdit(m.kit, m.ranks, open === "kt_edit"); return; }
    if (open !== "kt_edit" || KTE.id !== m.kit.id) return;
    RKC.kit = m.kit; RKC.kitRanks = m.ranks;
    KTE.d.items = m.kit.items; KTE.d.count = m.kit.count; KTE.d.icon = m.kit.icon;
    RPG.screen.update("icon", { value: m.kit.icon });
    ktcPreview();
    rkcShowNote();
});
RPG.net.on("rk_note", (m) => { let o = RPG.screen.getOpen(); if (o && (o.indexOf("kt") === 0 || o === "rk_ask")) rkcNote(m.text, m.bad); });
