# Changelog

Essentials, newest first. Keep the heading as `## <version> (YYYY-MM-DD)` and the bullets short.

## 2.0.0 (2026-11-25)

- Ranks & Kits is now part of Essentials. One ranks and permissions model: every rank is a permission group (RPG.perms) with its look (prefix, suffix, name and chat colours, badge), weight, parent, permission toggles and members, made in the rank editor (`/rank`). Giving a rank's group with `/rpg perm` gives that rank, so the editor and `/rpg perm` always agree. Timed ranks run out online and offline. A new world starts with the ranks Member (default), VIP and Admin.
- One kit system: the kit editor (`/kitadmin`) captures your inventory or takes dragged-in items, with cooldowns, costs, rank access, one-time and first-join kits; players browse, preview and claim them with `/kits` (or `/kit`, `/kit <name>`). A new world starts with the kits Starter (given on the first join), Tools, Food and VIP (VIP rank and above). The old fixed kit list in the script is gone.
- Settings moved from the script into `ragnarok_rpg/config/essentials.json` (`/rpg config essentials ...`): message prefix, currency (empty: the project's symbol), starting money, homes, teleport delay, /tpa timeout, AFK time, join message, and the rank chat, tab, badge and kit settings.
- `/commands` lists the rank and kit commands too.

## 1.0.0

- First release: spawn, homes, warps, /tpa, /back, messages, nicknames, kits, economy, AFK and admin tools, with permission groups.
