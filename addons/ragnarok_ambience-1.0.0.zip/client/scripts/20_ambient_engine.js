// =====================================================================================
//  Ragnarok Ambience: the soundscape engine (client side)
//  A port of Ambient Sounds' engine (https://github.com/CreativeMD/AmbientSounds, LGPL-3.0, by CreativeMD) to the
//  toolkit's RPG.audio API. The original's classes are named in the comments (AmbientEngine, AmbientCondition,
//  AmbientSound, ...); the behaviour, numbers and timings follow it:
//    - every 40 ticks (environment-tick-time) the surroundings are surveyed: terrain heights, nearby biomes, and a
//      space scan of the air around the listener (open air, sky, light on the walls, block groups -> features);
//    - every 4 ticks (sound-tick-time) the conditions of every dimension, region, category and sound are evaluated;
//    - every tick the playing sounds fade towards their volumes (fade-volume per tick), cross over between files,
//      play for their length and pause, and louder sounds mute quieter ones (mute, mute-priority).
//  Sounds are the addon's own (ambiencepack). They play through the engine's voices, which follow the listener and go
//  through the sound physics like any other sound (cave beds get the cave's reverb).
// =====================================================================================
(function () {
    if (typeof RAGNAROK_AMBIENCE_DATA === "undefined" || !RPG.audio || !RPG.audio.ambience.voice) return;
    var D = RAGNAROK_AMBIENCE_DATA;
    var A = RPG.audio.ambience;

    // ---- engine settings (AmbientEngine fields and their defaults) -------------------------------------------------
    var E = D.engine;
    function num(v, d) { return v === undefined || v === null ? d : Number(v); }
    var ENG = {
        environmentTickTime: num(E["environment-tick-time"], 40), soundTickTime: num(E["sound-tick-time"], 4),
        averageHeightScanDistance: num(E["average-height-scan-distance"], 2), averageHeightScanCount: num(E["average-height-scan-count"], 5),
        biomeScanDistance: num(E["biome-scan-distance"], 5), biomeScanCount: num(E["biome-scan-count"], 3),
        airPocketCount: num(E["air-pocket-count"], 50000), airDistance: num(E["air-distance"], 25),
        airSkyDistance: num(E["air-sky-distance"], 13), airSkyWeight: num(E["air-sky-weight"], 50),
        airMin: num(E["air-min"], 0.1), airMax: num(E["air-max"], 0.5), skyDistance: num(E["sky-distance"], 20),
        skyMinCount: num(E["sky-min-count"], 10), skyMaxCount: num(E["sky-max-count"], 100),
        fadeVolume: num(E["fade-volume"], 0.005), fadePitch: num(E["fade-pitch"], 0.005),
        defaultBiomeType: E["default-biome-type"], biomeTypes: E["biome-types"] || []
    };
    ENG.squaredBiomeDistance = Math.pow(ENG.biomeScanCount * ENG.biomeScanDistance * 2, 2);
    // AmbientEngine.airPocketVolume, kept exactly as written
    ENG.maxAirPocketCount = (function (r) {
        var res = 0;
        for (var i = r; r > 0; r--) {
            var f;
            if (i === r) f = 1; else if (i === r - 1) f = 4; else if (i === r - 2) f = 7; else f = 8;
            res += Math.floor(f * r * (r + 1) * 0.5);
        }
        return res;
    })(ENG.airDistance);

    // ---- settings (server config "ragnarok_ambience", per world) ----------------------------------------------------
    function cfg(key, d) {
        try { var v = RPG.config.get("ragnarok_ambience", key, d); return v === undefined || v === null ? d : v; } catch (e) { return d; }
    }

    // ---- the space scan (AirPocketScanner) and block groups -----------------------------------------------------------
    var groups = {};
    for (var g = 0; g < D.blockgroups.length; g++) groups[D.blockgroups[g][0]] = D.blockgroups[g][1];
    A.scanOptions({
        count: ENG.airPocketCount, bands: E["air-pocket-groups"] || [], airDistance: ENG.airDistance,
        airSkyDistance: ENG.airSkyDistance, airSkyWeight: ENG.airSkyWeight, skyDistance: ENG.skyDistance,
        solids: E.solids || [], groups: groups, stepsPerTick: 2500
    });

    // features (AmbientFeatureSelection.volume)
    var FEATURES = {};
    for (var f = 0; f < D.features.length; f++) FEATURES[D.features[f][0]] = D.features[f][1];
    function featureVolume(sel, dist) {
        var volume = 1;
        if (sel["low-weight"] != null || sel["high-weight"] != null || sel["low-count"] != null || sel["high-count"] != null) {
            var count = 0, pct = 0;
            var gs = sel.groups || [];
            for (var i = 0; i < gs.length; i++) { var r = dist[gs[i]]; if (r) { count += r.count; pct += r.percentage; } }
            var lw = sel["low-weight"], hw = sel["high-weight"], lc = sel["low-count"], hc = sel["high-count"];
            if (lw != null || hw != null) {
                if (lw != null && lw > pct) return 0;
                if (!(hw == null || hw < pct)) volume *= (pct - (lw == null ? 0 : lw)) / (hw - (lw == null ? 0 : lw));
            }
            if (lc != null || hc != null) {
                if (lc != null && lc > count) return 0;
                if (!(hc == null || hc < count)) volume *= (count - (lc == null ? 0 : lc)) / (hc - (lc == null ? 0 : lc));
            }
        }
        var k;
        if (sel.and) for (k = 0; k < sel.and.length; k++) volume *= featureVolume(sel.and[k], dist);
        if (sel.or) { var o = 0; for (k = 0; k < sel.or.length; k++) o = Math.max(o, featureVolume(sel.or[k], dist)); volume *= o; }
        if (sel.not) for (k = 0; k < sel.not.length; k++) if (featureVolume(sel.not[k], dist) > 0) return 0;
        return volume;
    }

    // AirPocket: default (before the first scan) is all open
    var pocket = { features: {}, light: 15, blockLight: 15, skyLight: 15, air: 1, sky: 1 };
    function takeScan(r) {
        var air = r.air / ENG.maxAirPocketCount;
        var p = { features: {}, light: r.light, blockLight: r.blockLight, skyLight: r.skyLight };
        p.air = air < ENG.airMin ? 0 : air > ENG.airMax ? 1 : (air - ENG.airMin) / (ENG.airMax - ENG.airMin);
        p.sky = r.sky < ENG.skyMinCount ? 0 : r.sky > ENG.skyMaxCount ? 1 : (r.sky - ENG.skyMinCount) / (ENG.skyMaxCount - ENG.skyMinCount);
        for (var name in FEATURES) { var v = featureVolume(FEATURES[name], r.groups || {}); if (v > 0) p.features[name] = v; }
        pocket = p;
    }
    function pocketVolume(names) { var v = 0; for (var i = 0; i < names.length; i++) v = Math.max(v, pocket.features[names[i]] || 0); return v; }

    // ---- volumes and selections (AmbientVolume, AmbientSelection, AmbientSelectionMulti) ----------------------------
    function Vol(c, s) { this.c = c; this.s = s; }
    Vol.prototype.cond = function () { return this.c; };
    Vol.prototype.set = function () { return this.s; };
    Vol.prototype.vol = function () { return this.c * this.s; };
    Vol.prototype.mulCond = function (v) { if (!this.fixed) this.c *= v; };
    Vol.prototype.mulSet = function (v) { if (!this.fixed) this.s *= v; };
    Vol.prototype.mulVol = function (o) { this.mulCond(o.cond()); this.mulSet(o.set()); };
    Vol.prototype.copy = function () { return new Vol(this.c, this.s); };
    var SILENT = new Vol(0, 0); SILENT.fixed = true;
    var MAX = new Vol(1, 1); MAX.fixed = true;

    function Sel(condition) { this.c = 1; this.s = condition.volume; this.condition = condition; this.sub = null; this.multi = null; }
    Sel.prototype = Object.create(Vol.prototype);
    Sel.prototype.cond = function () {
        var v = this.c; if (this.sub) v *= this.sub.cond();
        if (this.multi) for (var i = 0; i < this.multi.length; i++) v *= this.multi[i].cond();
        return v;
    };
    Sel.prototype.set = function () {
        var v = this.s; if (this.sub) v *= this.sub.set();
        if (this.multi) for (var i = 0; i < this.multi.length; i++) v *= this.multi[i].set();
        return v;
    };
    Sel.prototype.vol = function () { return this.cond() * this.set(); };
    Sel.prototype.last = function () { return this.sub ? this.sub.last() : this; };
    var PROPS = ["transition", "pitch", "fade-volume", "fade-in-volume", "fade-out-volume", "fade-pitch", "fade-in-pitch", "fade-out-pitch",
        "mute", "mute-priority", "random-offset", "pause", "length", "underwater-pitch", "channel"];
    Sel.prototype.assignProps = function (p) {
        var i;
        if (this.multi) for (i = 0; i < this.multi.length; i++) this.multi[i].assignProps(p);
        var raw = this.condition.raw;
        for (i = 0; i < PROPS.length; i++) if (raw[PROPS[i]] !== undefined && raw[PROPS[i]] !== null) p[PROPS[i]] = raw[PROPS[i]];
        if (this.sub) this.sub.assignProps(p);
    };
    Sel.prototype.props = function () { var p = { pitch: 1 }; this.assignProps(p); return p; };

    // ---- properties (AmbientSoundProperties) ----
    function fadeIn(p) { return p["fade-in-volume"] != null ? p["fade-in-volume"] : p["fade-volume"] != null ? p["fade-volume"] : ENG.fadeVolume; }
    function fadeOut(p) { return p["fade-out-volume"] != null ? p["fade-out-volume"] : p["fade-volume"] != null ? p["fade-volume"] : ENG.fadeVolume; }
    function fadeInPitch(p) { return p["fade-in-pitch"] != null ? p["fade-in-pitch"] : p["fade-pitch"] != null ? p["fade-pitch"] : ENG.fadePitch; }
    function fadeOutPitch(p) { return p["fade-out-pitch"] != null ? p["fade-out-pitch"] : p["fade-pitch"] != null ? p["fade-pitch"] : ENG.fadePitch; }
    function pitchOf(p, env) {
        var base = p.pitch != null ? p.pitch : 1;
        var up = p["underwater-pitch"];
        if (up) {
            var min = up.min || 0, max = up.max || 0, df = up["distance-factor"] != null ? up["distance-factor"] : 1;
            if (max <= min) max = min + 1;
            return base + env.underwater / (max - min) * df;
        }
        return base;
    }
    function randomValue(mm) {
        if (mm.max == null) return mm.min == null ? 0 : mm.min;
        var min = mm.min == null ? 0 : mm.min;
        return Math.random() * (mm.max - min) + min;
    }

    // ---- min/max/fade conditions ----
    function fadeVol(c, v) {
        if (c.min != null && v < c.min) return 0;
        if (c.max != null && v > c.max) return 0;
        if (c.fade == null) return 1;
        var vol = 1;
        if (c.min != null) vol = Math.max(0, Math.min(1, Math.abs(v - c.min) / c.fade));
        if (c.max != null) vol = Math.min(vol, Math.max(0, Math.min(1, Math.abs(v - c.max) / c.fade)));
        return vol;
    }
    function fadeSpecial(c, min, v, max) {
        if (c.fade == null) return (c.min != null && v < c.min) || (c.max != null && v > c.max) ? 0 : 1;
        var vol = fadeVol(c, v);
        if (vol === 1) return vol;
        return Math.max(fadeVol(c, min), fadeVol(c, max));
    }

    // ---- time (AmbientTime): hour curves with linear interpolation, premade day/night/... ----
    function hourCurve(times, wrap) {
        var pts = [];
        if (wrap === "angle") { pts.push([times[times.length - 2] - 360, times[times.length - 1]]); }
        else if (times[times.length - 2] < 24) pts.push([times[times.length - 2] - 24, times[times.length - 1]]);
        for (var i = 0; i < times.length; i += 2) pts.push([times[i], times[i + 1]]);
        if (wrap === "angle") pts.push([times[0] + 360, times[1]]);
        else if (times[0] > 0) pts.push([times[0] + 24, times[1]]);
        return function (x) {
            if (x <= pts[0][0]) return pts[0][1];
            for (var j = 1; j < pts.length; j++) if (x <= pts[j][0]) {
                var a = pts[j - 1], b = pts[j];
                return b[0] === a[0] ? b[1] : a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0]);
            }
            return pts[pts.length - 1][1];
        };
    }
    function premade(fade, begin, end) { return hourCurve([begin, 0, begin + fade, 1, end - fade, 1, end, 0]); }
    var PREMADE = {
        day: premade(1, 6, 18), night: hourCurve([0, 1, 4, 1, 5, 0, 19, 0, 19, 1, 24, 1]),
        sunrise: premade(1, 5, 6), sunset: premade(1, 18, 19), noon: premade(0.5, 10.5, 13.5),
        midnight: hourCurve([0, 1, 1, 1, 1.5, 0, 22.5, 0, 23, 1, 24, 1])
    };
    function compileTime(t) {
        if (t == null) return null;
        if (typeof t === "string") { var p = PREMADE[t]; return p ? function (env) { return p(env.dayTimeHour); } : null; }
        if (t.length !== undefined) {
            if (t.length === 0) return function () { return 0; };
            var fns = []; for (var i = 0; i < t.length; i++) if (PREMADE[t[i]]) fns.push(PREMADE[t[i]]);
            return function (env) { var v = 0; for (var k = 0; k < fns.length; k++) v = Math.max(v, fns[k](env.dayTimeHour)); return v; };
        }
        var list = [], keys = Object.keys(t);
        for (var j = 0; j < keys.length; j++) { var n = Number(keys[j]); if (!isNaN(n)) { list.push(n); list.push(Number(t[keys[j]])); } }
        if (String(t.type || "").toLowerCase() === "angle") { var a = hourCurve(list, "angle"); return function (env) { return a(env.sunAngle); }; }
        var h = hourCurve(list); return function (env) { return h(env.dayTimeHour); };
    }

    // ---- biome conditions (BiomeCondition: ".*name.*" with * wildcards, "#..." against tags) ----
    var MATCH_CACHE = {};
    function biomeConds(names) {
        if (!names) return null;
        var out = [];
        for (var i = 0; i < names.length; i++) {
            var n = String(names[i]), tag = n.charAt(0) === "#";
            var body = (tag ? n.substring(1) : n).replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*");
            out.push({ tag: tag, re: new RegExp("^.*" + body + ".*$"), key: n });
        }
        return out;
    }
    function rmatch(c, s) {
        var k = c.key + "|" + s;
        var v = MATCH_CACHE[k];
        if (v === undefined) v = MATCH_CACHE[k] = c.re.test(s);
        return v;
    }
    function checkBiome(b, conds) {
        for (var i = 0; i < conds.length; i++) {
            var c = conds[i];
            if (c.tag) { for (var t = 0; t < b.tags.length; t++) if (rmatch(c, b.tags[t])) return true; }
            else if (rmatch(c, b.id)) return true;
        }
        return false;
    }

    // ---- conditions (AmbientCondition) ----
    var REGIONS = {};   // full name -> region
    function Cond(raw, ownName) {
        this.raw = raw;
        this.ownName = ownName;
        this.always = raw.always;
        this.volume = Math.max(0, Math.min(1, num(raw.volume, 1)));
        this.nightVolume = Math.max(0, Math.min(1, num(raw.night, 1)));
        this.dayVolume = Math.max(0, Math.min(1, num(raw.day, 1)));
        this.time = compileTime(raw.time);
        this.biomeType = raw["biome-type"] || ENG.defaultBiomeType;
        this.biomes = biomeConds(raw.biomes);
        this.badBiomes = biomeConds(raw["bad-biomes"]);
        this.variants = null;
        if (raw.variants) { this.variants = []; for (var i = 0; i < raw.variants.length; i++) this.variants.push(new Cond(raw.variants[i], ownName)); }
    }
    Cond.prototype.link = function () {
        var self = this, i;
        function resolve(names) {
            if (!names) return null;
            var out = [];
            for (var k = 0; k < names.length; k++) { var r = REGIONS[names[k]]; if (r && names[k] !== self.ownName) out.push(r); }
            return out;
        }
        this.regionList = resolve(this.raw.regions);
        this.badRegionList = resolve(this.raw["bad-regions"]);
        if (this.variants) for (i = 0; i < this.variants.length; i++) this.variants[i].link();
    };
    Cond.prototype.value = function (env) {
        var r = this.raw, v, i;
        if (env.muted) return null;
        if (this.always !== undefined && this.always !== null) return this.always ? new Sel(this) : null;
        if (this.volume <= 0) return null;
        if (env.night ? this.nightVolume <= 0 : this.dayVolume <= 0) return null;
        if (r.raining != null && r.raining !== env.raining) return null;
        if (r["overall-raining"] != null && r["overall-raining"] !== (env.rainSurfaceVolume > 0)) return null;
        if (r.snowing != null && r.snowing !== env.snowing) return null;
        if (r.storming != null && env.thundering !== r.storming) return null;
        if (r["bad-features"] && pocketVolume(r["bad-features"]) > 0) return null;
        var sel = new Sel(this);
        sel.mulCond(env.night ? this.nightVolume : this.dayVolume);
        if (this.time) { v = this.time(env); if (v <= 0) return null; sel.mulCond(v); }
        if (this.badRegionList) for (i = 0; i < this.badRegionList.length; i++) if (this.badRegionList[i].active) return null;
        if (this.regionList) {
            var best = null;
            for (i = 0; i < this.regionList.length; i++) {
                var s = this.regionList[i].value(env);
                if (s && (!best || s.vol() > best.vol())) best = s;
                if (best && best.vol() === 1) break;
            }
            if (!best) return null;
            sel.mulVol(best);
        }
        if (this.biomes || this.badBiomes) {
            var high = null;
            for (i = 0; i < env.biome.length; i++) {
                var pair = env.biome[i];
                if (this.biomes && !checkBiome(pair.b, this.biomes)) continue;
                if (this.badBiomes && checkBiome(pair.b, this.badBiomes)) return null;
                if (this.biomes) {
                    var bv = pair.v.copy();
                    bv.mulVol(env.biomeTypeVolumes[this.biomeType] || MAX);
                    if (!high || high.vol() < bv.vol()) high = bv;
                    if (high && high.vol() === 1) break;
                }
            }
            if (!high && this.biomes) return null;
            else if (high) sel.mulVol(high);
        }
        if (r["overall-raining"] === true) sel.mulCond(env.rainSurfaceVolume);
        if (r.underwater) { v = fadeVol(r.underwater, env.underwater); if (v <= 0) return null; sel.mulCond(v); }
        if (r["relative-height"]) { v = fadeSpecial(r["relative-height"], env.relativeMinHeight, env.relativeHeight, env.relativeMaxHeight); if (v <= 0) return null; sel.mulCond(v); }
        if (r["min-height-relative"]) { v = fadeVol(r["min-height-relative"], env.relativeMinHeight); if (v <= 0) return null; sel.mulCond(v); }
        if (r["max-height-relative"]) { v = fadeVol(r["max-height-relative"], env.relativeMaxHeight); if (v <= 0) return null; sel.mulCond(v); }
        if (r["absolute-height"]) { v = fadeVol(r["absolute-height"], env.absoluteHeight); if (v <= 0) return null; sel.mulCond(v); }
        if (r.light) { v = fadeVol(r.light, pocket.light); if (v <= 0) return null; sel.mulCond(v); }
        if (r["block-light"]) { v = fadeVol(r["block-light"], pocket.blockLight); if (v <= 0) return null; sel.mulCond(v); }
        if (r["sky-light"]) { v = fadeVol(r["sky-light"], pocket.skyLight); if (v <= 0) return null; sel.mulCond(v); }
        if (r.air) { v = fadeVol(r.air, pocket.air); if (v <= 0) return null; sel.mulCond(v); }
        if (r.sky) { v = fadeVol(r.sky, pocket.sky); if (v <= 0) return null; sel.mulCond(v); }
        if (r.features) { v = pocketVolume(r.features); if (v <= 0) return null; sel.mulCond(v); }
        if (r.temperature) { v = fadeVol(r.temperature, env.temperature); if (v <= 0) return null; sel.mulCond(v); }
        if (r.entity) { v = entityValue(r.entity, env); if (v <= 0) return null; sel.mulCond(v); }
        if (this.variants) {
            var bestC = null;
            for (i = 0; i < this.variants.length; i++) {
                var sub = this.variants[i].value(env);
                if (sub && (!bestC || bestC.vol() < sub.vol())) bestC = sub;
            }
            if (!bestC) return null;
            sel.sub = bestC;
        }
        return sel;
    };

    // AmbientEntityCondition: only type + distance are used by the data; count and the rest follow the same shape
    var ENTITY_TYPES = [];
    function entityValue(c, env) {
        var types = [].concat(c.type || []);
        var highest = 0, counted = 0;
        for (var t = 0; t < types.length; t++) {
            var list = env.entities[types[t]] || [];
            for (var i = 0; i < list.length; i++) {
                var cur = 1;
                if (c.distance) cur *= fadeVol(c.distance, list[i]);
                counted++;
                if (cur === 1 && !c.count) return 1;
                highest = Math.max(highest, cur);
            }
        }
        if (c.count) return highest * fadeVol(c.count, counted);
        return highest;
    }

    // ---- sound categories (AmbientSoundCategory) ----
    var CATS = {}, CAT_ROOTS = [];
    for (var ci = 0; ci < D.categories.length; ci++) {
        var cat = new Cond(D.categories[ci][1], null);
        cat.name = D.categories[ci][0]; cat.parent = D.categories[ci][1].parent; cat.children = []; cat.volumeSetting = 1; cat.selection = null;
        CATS[cat.name] = cat;
    }
    for (var cn in CATS) {
        var c2 = CATS[cn];
        if (c2.parent && CATS[c2.parent]) CATS[c2.parent].children.push(c2);
        else if (!c2.parent) CAT_ROOTS.push(c2);
    }
    function catTick(cat, env, parentSel) {
        cat.selection = cat.value(env);
        if (cat.selection) {
            if (parentSel) cat.selection.last().sub = parentSel;
            cat.selection.mulSet(cat.volumeSetting);
        }
        for (var i = 0; i < cat.children.length; i++) catTick(cat.children[i], env, cat.selection);
    }

    // ---- the sound engine (AmbientSoundEngine) over RPG.audio voices ----
    var STREAMS = [];
    function Stream(sound, index) {
        this.sound = sound; this.index = index; this.file = sound.files[index];
        this.transitionVolume = 1; this.pitch = 1; this.duration = -1; this.ticksPlayed = 0;
        this.finished = false; this.playedOnce = false; this.handle = 0;
        this.effectiveVolume = this.combined();
    }
    Stream.prototype.combined = function () { return this.sound.currentOutputVolume * this.transitionVolume; };
    Stream.prototype.remaining = function () { return this.duration - this.ticksPlayed; };
    Stream.prototype.mute = function () { var m = this.sound.props.mute; return m == null ? 0 : Math.max(0, Math.min(1, m)) * this.sound.currentConditionVolume; };
    Stream.prototype.mutePriority = function () { var p = this.sound.props["mute-priority"]; return p == null ? 0 : p; };
    function enginePlay(st) {
        st.handle = A.voice(st.file, { volume: st.effectiveVolume, pitch: st.pitch, loop: st.sound.loop() });
        st.finished = false; st.playedOnce = false;
        STREAMS.push(st);
    }
    function engineStop(st) {
        if (st.handle) A.voiceStop(st.handle);
        var i = STREAMS.indexOf(st); if (i >= 0) STREAMS.splice(i, 1);
    }
    function engineTick(env) {
        // mutes by priority, highest first (AmbientSoundEngine.tick)
        var mutes = {}, prios = [], i, st;
        for (i = 0; i < STREAMS.length; i++) {
            var m = STREAMS[i].mute();
            if (m > 0) { var p = STREAMS[i].mutePriority(); if (mutes[p] === undefined) { mutes[p] = m; prios.push(p); } else mutes[p] = Math.max(mutes[p], m); }
        }
        prios.sort(function (a, b) { return b - a; });
        for (i = 0; i < STREAMS.length; i++) {
            st = STREAMS[i];
            var state = st.handle ? A.voiceState(st.handle) : 0;
            var playing;
            if (state !== 2) { if (st.playedOnce || state === 0) playing = false; else continue; }
            else playing = true;
            if ((st.playedOnce || state === 0) && !playing) {
                st.finished = true;
                st.sound.onSoundFinished(st);
                if (st.handle) A.voiceStop(st.handle);
                STREAMS.splice(i, 1); i--;
                continue;
            } else if (!st.playedOnce && playing) st.playedOnce = true;
            if (prios.length === 0) st.effectiveVolume = st.combined();
            else {
                var mute = 0;
                for (var k = 0; k < prios.length; k++) {
                    if (st.mutePriority() < prios[k] || st.mute() === 0) mute = Math.max(mutes[prios[k]], mute);
                    else break;
                }
                st.effectiveVolume = st.combined() * (1 - mute);
            }
        }
        for (i = 0; i < STREAMS.length; i++) {
            st = STREAMS[i];
            if (st.handle) A.voiceSet(st.handle, st.effectiveVolume * MASTER, st.pitch, st.sound.muffle(env));
        }
    }

    // ---- sounds (AmbientSound) ----
    function Sound(raw, regionName) {
        Cond.call(this, raw, regionName);
        this.name = raw.name;
        this.files = raw.files || [];
        this.categories = null;
        var cats = raw.category == null ? [] : [].concat(raw.category);
        if (cats.length) { this.categories = []; for (var i = 0; i < cats.length; i++) if (CATS[cats[i]]) this.categories.push(CATS[cats[i]]); }
        this.volumeSetting = 1;
        this.stream1 = null; this.stream2 = null; this.active = false;
        this.aimedCond = 0; this.aimedOut = 0; this.currentConditionVolume = 0; this.currentOutputVolume = 0;
        this.aimedPitch = 1; this.transition = 0; this.transitionTime = 0; this.pauseTimer = -1; this.props = { pitch: 1 };
        this.weather = cats.indexOf("weather") >= 0;
    }
    Sound.prototype = Object.create(Cond.prototype);
    Sound.prototype.randomFile = function () { return this.files.length === 1 ? 0 : Math.floor(Math.random() * this.files.length); };
    Sound.prototype.randomFileExcept = function (i) {
        if (this.files.length === 2) return i === 0 ? 1 : 0;
        var idx = Math.floor(Math.random() * (this.files.length - 1));
        return idx >= i ? idx + 1 : idx;
    };
    Sound.prototype.loop = function () { return this.props.length != null || (this.props.pause == null && this.files.length === 1); };
    Sound.prototype.muffle = function (env) {
        // rain and storms heard through a roof: muffled by how closed-in the listener is (sound physics' estimate)
        if (!this.weather || !PHYS_MUFFLE) return 0;
        return Math.max(0, 1 - pocket.sky) * Math.max(0, 1 - pocket.air) * 1.5;
    };
    Sound.prototype.value = function (env) {
        if (this.volumeSetting === 0) return null;
        var v = Cond.prototype.value.call(this, env);
        if (v && this.categories) {
            var col = [];
            for (var i = 0; i < this.categories.length; i++) { if (!this.categories[i].selection) return null; col.push(this.categories[i].selection); }
            var m = new Sel(this);
            m.c = v.c; m.s = v.s; m.sub = v.sub; m.multi = col;
            v = m;
        }
        return v;
    };
    Sound.prototype.audible = function () { return this.aimedCond > 0 || this.currentConditionVolume > 0 || this.currentOutputVolume > 0; };
    Sound.prototype.tick = function (env, selection) {
        if (selection) {
            var ss = this.value(env);
            if (ss) {
                var last = selection.last();
                last.sub = ss;
                this.aimedCond = selection.cond();
                this.aimedOut = selection.vol() * this.volumeSetting * env.dimension.volumeSetting * cfg("volume", 1);
                this.props = selection.props();
                last.sub = null;
                this.aimedPitch = Math.max(0.5, Math.min(2, pitchOf(this.props, env)));
            } else this.aimedCond = this.aimedOut = 0;
        } else this.aimedCond = this.aimedOut = 0;
        return this.audible();
    };
    Sound.prototype.play = function (index, transition) {
        var st = new Stream(this, index);
        st.pitch = this.aimedPitch;
        if (this.props.length != null) st.duration = Math.floor(randomValue(this.props.length));
        if (transition) { st.transitionVolume = 0; st.effectiveVolume = st.combined(); }
        enginePlay(st);
        return st;
    };
    Sound.prototype.fastTick = function (env) {
        var p = this.props;
        if (this.currentConditionVolume < this.aimedCond) this.currentConditionVolume += Math.min(fadeIn(p), this.aimedCond - this.currentConditionVolume);
        else if (this.currentConditionVolume > this.aimedCond) this.currentConditionVolume -= Math.min(fadeOut(p), this.currentConditionVolume - this.aimedCond);
        if (this.currentOutputVolume < this.aimedOut) this.currentOutputVolume += Math.min(fadeIn(p), this.aimedOut - this.currentOutputVolume);
        else if (this.currentOutputVolume > this.aimedOut) this.currentOutputVolume -= Math.min(fadeOut(p), this.currentOutputVolume - this.aimedOut);
        if (this.stream1) {
            if (this.stream1 && this.stream2) {
                this.stream1.transitionVolume = 1 - this.transition / this.transitionTime;
                this.stream2.transitionVolume = this.transition / this.transitionTime;
                if (this.transition >= this.transitionTime) { engineStop(this.stream1); this.stream1 = this.stream2; this.stream2 = null; }
                this.transition++;
            } else {
                var s1 = this.stream1;
                if (s1.duration === -1 && p.length != null) s1.duration = Math.floor(randomValue(p.length));
                else if (s1.duration > 0 && p.length == null) s1.duration = -1;
                s1.transitionVolume = 1;
                if (p.length != null) {
                    if (p.pause == null && this.files.length > 1) {
                        if (s1.remaining() <= 0) {
                            this.transition = 0;
                            this.stream2 = this.play(this.randomFileExcept(s1.index), true);
                            this.transitionTime = p.transition != null ? p.transition : 60;
                        }
                    } else {
                        var fadeOutTime = Math.ceil(this.aimedCond / fadeOut(p));
                        if (s1.remaining() <= 0) { engineStop(s1); this.stream1 = null; this.pauseTimer = -1; }
                        else if (fadeOutTime > s1.remaining()) s1.transitionVolume = s1.remaining() / fadeOutTime;
                    }
                }
            }
            var all = [this.stream1, this.stream2];
            for (var i = 0; i < 2; i++) {
                var st = all[i];
                if (!st) continue;
                if (st.pitch < this.aimedPitch) st.pitch += Math.min(fadeInPitch(p), this.aimedPitch - st.pitch);
                else if (st.pitch > this.aimedPitch) st.pitch -= Math.min(fadeOutPitch(p), st.pitch - this.aimedPitch);
                st.ticksPlayed++;
            }
        } else {
            if (this.stream2) { engineStop(this.stream2); this.stream2 = null; }
            if (this.pauseTimer === -1 && p.pause != null) this.pauseTimer = Math.floor(randomValue(p.pause));
            if (this.pauseTimer <= 0) this.stream1 = this.play(this.randomFile(), false);
            else this.pauseTimer--;
        }
        return this.audible();
    };
    Sound.prototype.activate = function () { this.active = true; };
    Sound.prototype.deactivate = function () {
        this.active = false;
        if (this.stream1) { engineStop(this.stream1); this.stream1 = null; }
        if (this.stream2) { engineStop(this.stream2); this.stream2 = null; }
    };
    Sound.prototype.onSoundFinished = function (st) {
        if (this.stream1 && this.stream1 === st) { this.stream1 = null; this.pauseTimer = -1; }
        else if (this.stream2 === st) this.stream2 = null;
    };

    // ---- regions (AmbientRegion) ----
    var COLLECTIONS = {};
    for (var co = 0; co < D.collections.length; co++) COLLECTIONS[D.collections[co][0]] = D.collections[co][1];
    function Region(raw, name, dimension) {
        Cond.call(this, raw, raw.name || name);
        this.name = raw.name || name;
        this.dimension = dimension || null;
        this.volumeSetting = 1; this.active = false; this.playing = []; this.sounds = [];
        var i;
        if (raw.sounds) for (i = 0; i < raw.sounds.length; i++) this.sounds.push(new Sound(raw.sounds[i], this.name));
        if (raw["sound-collections"])
            for (i = 0; i < raw["sound-collections"].length; i++) {
                var col = COLLECTIONS[raw["sound-collections"][i]];
                if (col && col.sounds) for (var k = 0; k < col.sounds.length; k++) {
                    var copy = JSON.parse(JSON.stringify(col.sounds[k]));
                    copy.name = raw["sound-collections"][i] + "." + copy.name;
                    this.sounds.push(new Sound(copy, this.name));
                }
            }
    }
    Region.prototype = Object.create(Cond.prototype);
    Region.prototype.value = function (env) {
        if (this.dimension && this.dimension !== env.dimension) return null;
        if (this.volumeSetting === 0) return null;
        var s = Cond.prototype.value.call(this, env);
        if (s) s.mulSet(this.volumeSetting);
        return s;
    };
    Region.prototype.tick = function (env) {
        if (!this.sounds.length) return false;
        var sel = this.value(env);
        for (var i = 0; i < this.sounds.length; i++) {
            var snd = this.sounds[i];
            if (snd.tick(env, sel)) { if (!snd.active) { snd.activate(); this.playing.push(snd); } }
            else if (snd.active) { snd.deactivate(); this.playing.splice(this.playing.indexOf(snd), 1); }
        }
        return this.playing.length > 0;
    };
    Region.prototype.fastTick = function (env) {
        for (var i = 0; i < this.playing.length; i++) {
            if (!this.playing[i].fastTick(env)) { this.playing[i].deactivate(); this.playing.splice(i, 1); i--; }
        }
        return this.playing.length > 0;
    };
    Region.prototype.activate = function () { this.active = true; };
    Region.prototype.deactivate = function () {
        this.active = false;
        for (var i = 0; i < this.playing.length; i++) this.playing[i].deactivate();
        this.playing = [];
    };

    // ---- dimensions (AmbientDimension) ----
    function dimPatterns(list) {
        if (!list) return null;
        var out = [];
        for (var i = 0; i < list.length; i++)
            out.push(new RegExp("^.*" + String(list[i]).toLowerCase().replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, "\\?") + ".*$"));
        return out;
    }
    var DIMS = [], GENERAL = [];
    for (var di = 0; di < D.dimensions.length; di++) {
        var raw = D.dimensions[di][1];
        var dim = { name: D.dimensions[di][0], raw: raw, volumeSetting: 1, mute: !!raw.mute, night: raw.night, rain: raw.rain, storm: raw.storm,
            averageHeight: raw["average-height"], patterns: dimPatterns(raw["dimension-names"]), badPatterns: dimPatterns(raw["bad-dimension-names"]),
            disableAll: !!raw["disable-all"],
            biomeSelector: raw["biome-selector"] ? new Cond(raw["biome-selector"], null) : null, typeSelectors: {}, regions: [] };
        for (var bt = 0; bt < ENG.biomeTypes.length; bt++) {
            var selRaw = raw[ENG.biomeTypes[bt] + "-selector"];
            if (selRaw) dim.typeSelectors[ENG.biomeTypes[bt]] = new Cond(selRaw, null);
        }
        if (raw.regions) for (var ri = 0; ri < raw.regions.length; ri++) {
            var reg = new Region(raw.regions[ri], raw.regions[ri].name, dim);
            dim.regions.push(reg);
            if (reg.name) REGIONS[dim.name + "." + reg.name] = reg;
        }
        DIMS.push(dim);
    }
    var SILENT_DIM = { name: "silent", volumeSetting: 0, mute: true, regions: [], typeSelectors: {}, biomeSelector: null, patterns: null, badPatterns: null };
    for (var gi = 0; gi < D.regions.length; gi++) {
        var greg = new Region(D.regions[gi][1], D.regions[gi][0], null);
        greg.name = D.regions[gi][0];
        REGIONS[greg.name] = greg;
        GENERAL.push(greg);
    }
    for (var rn in REGIONS) REGIONS[rn].link();
    for (var dl = 0; dl < DIMS.length; dl++) {
        if (DIMS[dl].biomeSelector) DIMS[dl].biomeSelector.link();
        for (var ts in DIMS[dl].typeSelectors) DIMS[dl].typeSelectors[ts].link();
    }
    for (var cl in CATS) CATS[cl].link();
    for (var r2 in REGIONS) for (var s2 = 0; s2 < REGIONS[r2].sounds.length; s2++) REGIONS[r2].sounds[s2].link();
    // entity types the data asks about
    for (var r3 in REGIONS) {
        var ent = REGIONS[r3].raw.entity;
        if (ent && ent.type) [].concat(ent.type).forEach(function (t) { if (ENTITY_TYPES.indexOf(t) < 0) ENTITY_TYPES.push(t); });
    }

    function dimensionFor(id) {
        for (var i = 0; i < DIMS.length; i++) {
            var d = DIMS[i], j, bad = false;
            if (d.badPatterns) for (j = 0; j < d.badPatterns.length; j++) if (d.badPatterns[j].test(id)) bad = true;
            if (bad) continue;
            if (d.patterns) { for (j = 0; j < d.patterns.length; j++) if (d.patterns[j].test(id)) return d; continue; }
            return d;
        }
        return SILENT_DIM;
    }
    function manipulate(d, env) {
        env.muted = d.mute || !!d.disableAll;
        if (d.night != null) env.night = d.night;
        if (d.rain != null) env.raining = d.rain;
        if (d.storm != null) env.thundering = d.storm;
        if (d.biomeSelector) { var s = d.biomeSelector.value(env); env.biomeVolume = s ? s : SILENT; }
        env.biomeTypeVolumes = {};
        for (var t in d.typeSelectors) { var v = d.typeSelectors[t].value(env); env.biomeTypeVolumes[t] = v ? v : SILENT; }
    }

    // ---- the environment (AmbientEnvironment, TerrainEnvironment, BiomeEnvironment) ----
    var env = { dimension: null, muted: false, night: false, sunAngle: 0, dayTimeHour: 0, rainSurfaceVolume: 0, raining: false, snowing: false,
        thundering: false, biome: [], biomeVolume: SILENT, biomeTypeVolumes: {}, absoluteHeight: 0, relativeHeight: 0, relativeMinHeight: 0,
        relativeMaxHeight: 0, underwater: 0, temperature: 0, entities: {} };
    var terrain = { average: 60, min: 60, max: 60 };
    var ACTIVE = [];
    function setActive(region, on) {
        if (on) { if (!region.active) { region.activate(); ACTIVE.push(region); } }
        else if (region.active) { region.deactivate(); ACTIVE.splice(ACTIVE.indexOf(region), 1); }
    }
    function stopEngine() {
        for (var i = 0; i < ACTIVE.length; i++) ACTIVE[i].deactivate();
        ACTIVE = [];
        for (var k = STREAMS.length - 1; k >= 0; k--) engineStop(STREAMS[k]);
    }

    function analyzeSlow(e) {
        // terrain heights
        if (env.dimension.averageHeight != null) terrain = { average: env.dimension.averageHeight, min: env.dimension.averageHeight, max: env.dimension.averageHeight };
        else { var h = A.heights(ENG.averageHeightScanCount, ENG.averageHeightScanDistance); if (h.average !== undefined) terrain = { average: h.average, min: h.min, max: h.max }; }
        // the space scan: a new one starts once the last has finished
        if (!A.scanning()) { if (scanStarted) takeScan(A.scanResult()); A.scan(); scanStarted = true; }
        // biomes around, with their distance volume
        var list = [], rain = 0;
        var bv = env.biomeVolume;
        if (bv.vol() > 0) {
            var bs = A.biomes(ENG.biomeScanCount, ENG.biomeScanDistance);
            for (var i = 0; i < bs.length; i++) {
                var b = bs[i];
                var cv = (1 - b.distSq / ENG.squaredBiomeDistance) * bv.cond();
                if (b.rain) rain = Math.max(rain, (1 - b.rainDistSq / ENG.squaredBiomeDistance) * bv.cond() * bv.set());
                list.push({ b: { id: String(b.id), tags: b.tags.map(String) }, v: new Vol(cv, bv.set()) });
            }
            list.sort(function (x, y) { return y.v.vol() - x.v.vol(); });
        }
        env.biome = list;
        env.rainSurfaceVolume = rain;
    }
    var scanStarted = false;

    function analyzeFast(e) {
        env.raining = !!e.rainingHere;
        env.snowing = !!e.snowing;
        env.thundering = !!e.thundering && !env.snowing;
        env.absoluteHeight = e.eyeY;
        env.relativeHeight = e.eyeY - terrain.average;
        env.relativeMinHeight = e.eyeY - terrain.max;
        env.relativeMaxHeight = e.eyeY - terrain.min;
        env.temperature = e.temperature;
        env.underwater = e.waterDepth;
        env.sunAngle = e.sunAngle;
        env.night = env.sunAngle < 90 || env.sunAngle > 270;
        env.dayTimeHour = env.sunAngle * 24 / 360;
        env.entities = ENTITY_TYPES.length ? A.entities(ENTITY_TYPES, 64) : {};
    }

    function engineTickAll() {
        var i;
        for (i = 0; i < CAT_ROOTS.length; i++) catTick(CAT_ROOTS[i], env, null);
        for (i = 0; i < env.dimension.regions.length; i++) setActive(env.dimension.regions[i], env.dimension.regions[i].tick(env));
        for (i = 0; i < GENERAL.length; i++) setActive(GENERAL[i], GENERAL[i].tick(env));
    }

    // ---- settings -> volume settings ----
    var MASTER = 1, PHYS_MUFFLE = false;
    function applySettings() {
        MASTER = Number(cfg("volume", 1));
        function catVol(name, v) { if (CATS[name]) CATS[name].volumeSetting = v; }
        catVol("animal", Number(cfg("animals", 1)));
        catVol("bird", Number(cfg("birds", 1)));
        catVol("cricket", Number(cfg("insects", 1)));
        catVol("cicadas", Number(cfg("insects", 1)));
        catVol("wind", Number(cfg("wind", 1)));
        catVol("weather", Number(cfg("weather", 1)));
        catVol("cave", Number(cfg("caves", 1)));
        catVol("suspense", Number(cfg("suspense", 1)));
        ["ocean", "ocean_deep", "beach", "underwater"].forEach(function (n) { if (REGIONS[n]) REGIONS[n].volumeSetting = Number(cfg("water", 1)); });
        PHYS_MUFFLE = !!cfg("rainMuffle", true);
    }

    // ---- the tick (AmbientTickHandler.onTick) ----
    var timer = 0, lastDimId = null;
    A.onUpdate(function (e) { lastEnv = e; });   // the engine's own survey (sun angle, rain, water depth...), refreshed every 5 ticks
    A.options({ updateTicks: ENG.soundTickTime, maxSources: 16 });
    var lastEnv = null;
    applySettings();
    RPG.on("config", function (name) { if (String(name) === "ragnarok_ambience") applySettings(); });

    RPG.on("tick", function () {
        if (!A.enabled() || !cfg("enabled", true)) { if (ACTIVE.length || STREAMS.length) stopEngine(); return; }
        if (!lastEnv) return;
        var e = lastEnv;
        var dimId = String(e.dimension);
        var d = dimensionFor(dimId);
        if (env.dimension !== d) {
            if (env.dimension) for (var i = 0; i < env.dimension.regions.length; i++) setActive(env.dimension.regions[i], false);
            env.dimension = d;
        }
        if (lastDimId !== null && lastDimId !== dimId) stopEngine();
        lastDimId = dimId;
        if (timer % ENG.environmentTickTime === 0) analyzeSlow(e);
        if (timer % ENG.soundTickTime === 0) {
            analyzeFast(e);
            manipulate(env.dimension, env);
            engineTickAll();
        }
        engineTick(env);
        for (var k = 0; k < ACTIVE.length; k++) if (!ACTIVE[k].fastTick(env)) { ACTIVE[k].deactivate(); ACTIVE.splice(k, 1); k--; }
        timer++;
    });

    // debugging and tests: what plays now
    RAGNAROK_AMBIENCE = {
        active: function () {
            var out = [];
            for (var i = 0; i < ACTIVE.length; i++) for (var j = 0; j < ACTIVE[i].playing.length; j++) {
                var s = ACTIVE[i].playing[j];
                out.push(ACTIVE[i].name + "." + s.name + " " + s.currentOutputVolume.toFixed(3) + (s.stream1 ? " " + s.stream1.file : ""));
            }
            return out;
        },
        env: function () { return { dim: env.dimension && env.dimension.name, night: env.night, hour: env.dayTimeHour, rain: env.raining, rainVol: env.rainSurfaceVolume,
            rel: env.relativeHeight, air: pocket.air, sky: pocket.sky, features: pocket.features, biomes: env.biome.map(function (b) { return b.b.id + ":" + b.v.vol().toFixed(2); }) }; },
        streams: function () { return STREAMS.length; }
    };
})();
var RAGNAROK_AMBIENCE;
