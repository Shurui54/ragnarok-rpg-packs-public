# Ragnarok Ambience changelog

## 1.0.0 (2026-11-18)
- First release: Ambient Sounds' soundscape engine and data and Sound Physics Remastered's tuning, ported to the
  toolkit's RPG.audio API, with synthesized sounds (ambiencepack 1.0.0).
