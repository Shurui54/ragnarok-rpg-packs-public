// =====================================================================================
//  90_hooks.js - reacting to game events, changing core formulas, custom commands
// =====================================================================================
//  RPG.on("event", fn)        run code when something happens (README lists every event)
//  RPG.override("name", fn)   replace a built-in formula; fn gets the normal arguments
//                             plus the built-in result LAST, and returns the value to use
//  RPG.commands.register      add /rpgc <name> commands
//  RPG.schedule / RPG.every   run code later / repeatedly (20 ticks = 1 second)
// =====================================================================================

// ---- Joining ------------------------------------------------------------------------
RPG.on("firstJoin", (player) => {
    player.startQuest("tutorial_basics");
    player.startQuest("first_lesson");
});

// DMZ levels come from your stats and change silently (09_dmz_stats.js).

// ---- Weighted training (Korin's Sacred Water quest counts kills made in weighted clothing) ----
RPG.on("kill", (player, victim) => {
    if (player.stat("weight") > 0) player.progressQuest("weighted_kill", 1);
});

RPG.on("death", (player, killer) => {
    player.setVar("lock_uuid", null);
    player.clearHudText("lock");
});

// Kill rewards are DMZ's TP (09_dmz_stats.js): there is no XP in DMZ.

// ---- Race passives ------------------------------------------------------------------
// playerTick runs once a second for every player.
RPG.on("playerTick", (player) => {
    if (player.health < player.maxHealth && player.hasSkill("regeneration")) {
        let race = player.getRace();
        // A share of max health per second, so regeneration keeps up as Vitality grows.
        let share = race === "majin" ? 0.02 : race === "bio_android" ? 0.015 : 0.01;
        player.heal(Math.max(0.5, player.maxHealth * share));
    }
});

// Zenkai: Saiyans come back stronger after every death (the passive skill in 40_skills.js).
RPG.on("respawn", (player) => {
    if (player.hasSkill("zenkai")) {
        player.addStat("strength", 1);
        player.addStat("vitality", 1);
        player.addEffect("zenkai_boost", 1200);
        player.actionbar("&6Zenkai! &e+1 Strength, +1 Vitality");
        sfx(player, "aura_start", 1, 0.8);
    }
});

// ---- Combat -------------------------------------------------------------------------
var HURT_ANIMATIONS = ["base.hurt_left", "base.hurt_right", "base.hurt_top", "base.hurt_down"];

RPG.on("hurt", (event) => {
    let p = event.target.asPlayer();
    if (!p) return;
    if (p.hasEffect("ki_barrier")) {                       // 40_skills.js
        event.amount = event.amount * 0.3;
        sfx(p, "block2", 0.8, 1.2);
    } else if (p.hasEffect("guarding")) {                  // 45_keys.js
        event.amount = event.amount * 0.4;
        sfx(p, "block1", 0.8, 1);
        p.addResource("stamina", -3);
    } else if (event.amount >= 6 && !p.hasEffect("flight") && !p.hasEffect("ki_charge")) {
        act(p, HURT_ANIMATIONS[RPG.randomInt(0, HURT_ANIMATIONS.length - 1)], 10);   // big hits stagger you
    }
});

// Casting techniques counts for the tutorial quest.
RPG.on("skillCast", (player, skill, level) => {
    player.progressQuest("cast_technique", 1);
});

// ---- TP multipliers -----------------------------------------------------------------
// One tpGain handler for everything: when several handlers return a value, only the first
// counts, so all the multipliers live here.
RPG.on("tpGain", (player, amount, source) => {
    let m = 1;
    if (RPG.randomEvents.isActive("double_tp")) m *= 2;            // 80_spawns_events.js
    if (player.dimension === TIME_CHAMBER) m *= 2;                  // 85_world.js
    if (player.stat("weight") > 0) m *= 1.5;                        // weighted clothing, 50_items.js
    if (m !== 1) return amount * m;
    // Returning nothing keeps the amount unchanged.
});

// ---- Overrides: change built-in formulas --------------------------------------------
// (Stat prices and TP are DMZ's: 09_dmz_stats.js.)

// More overrides you can try (see README > Overrides):
// RPG.override("xpForLevel", (level, builtIn) => builtIn * 2);
// RPG.override("skillCooldown", (player, skillId, level, builtIn) => builtIn * 0.5);
// RPG.override("damage", (event, builtIn) => event.target.isPlayer() ? builtIn * 0.5 : builtIn);
// RPG.override("appearance", (player, builtIn) => player.hasEffect("potara_fusion") ? "effect:super_saiyan_blue" : builtIn);

// ---- Custom commands: /rpgc <name> --------------------------------------------------
RPG.commands.register("power", {
    description: "Show your power level and stats",
    run(player, args) {
        if (!player) return;                       // typed from the server console
        player.tell("&6=== " + player.name + " === &ePower level: &f" + grouped(powerLevel(player)));
        COMBAT_STATS.forEach((id) => {             // 10_stats.js
            player.tell("&7" + RPG.stats.name(id) + ": &f" + Math.floor(player.stat(id)));
        });
        player.tell("&7Level &f" + player.getLevel() + "&7  TP &b" + grouped(player.getTp()) + "&7  Zeni &6" + grouped(player.getMoney()));
    }
});

RPG.commands.register("help", (player, args) => {
    // Short form: just a function. Players type /rpgc help
    if (!player) return;
    player.tell("&6=== Dragon Block Ragnarok ===");
    player.tell("&fK &7menu   &fAlt+1..4 / Ctrl+1..4 &7techniques   &fC &7(hold) charge ki");
    player.tell("&fV &7fly   &fR &7dash   &fG &7(hold) descend / meditate   &fH &7ascend / jump   &fZ &7lock on");
    player.tell("&6/rpgc power &7your power level   &6/rpgc color &7your colours   &6/rpgc leave &7leave another world");
    player.tell("&7Buy stats with TP on the Status tab. Masters teach techniques - start with &6Master Roshi&7.");
});

// Ops only (permission 2): /rpgc arena  spawns a Saibaman wave around you.
RPG.commands.register("arena", {
    description: "Spawn a wave of Saibamen (ops)",
    permission: 2,
    run(player, args) {
        if (!player) return;
        let count = args.length > 0 ? Number(args[0]) : 5;
        spawnAround(player, "saibaman", Math.min(20, count || 5));   // helper from 80_spawns_events.js
    }
});

// Ops: /rpgc setup  places the core NPCs around you (a quick test town).
RPG.commands.register("setup", {
    description: "Place Roshi, Korin, Bulma, Popo, King Yemma and friends around you (ops)",
    permission: 2,
    run(player, args) {
        if (!player) return;
        ["master_roshi", "korin", "bulma", "mr_popo", "enma", "master_krillin", "master_goku", "master_piccolo", "master_vegeta",
         "fortune_teller_baba", "world_tournament_announcer", "punch_machine", "toribot", "nimbus_cloud"].forEach((id, i) => {
            let a = i / 14 * Math.PI * 2;
            RPG.world.spawnNpc(player.dimension, id, player.x + Math.cos(a) * 8, player.y, player.z + Math.sin(a) * 8);
        });
        player.tell("&aTown placed. Remove an NPC by hitting it in creative mode.");
    }
});

// ---- Timers -------------------------------------------------------------------------
// Every 5 minutes, remind players in the Time Chamber how long they've been there.
RPG.every(20 * 60 * 5, () => {
    RPG.server.players().forEach((p) => {
        if (p.dimension === TIME_CHAMBER) p.actionbar("&7A year passes in the chamber... (TP x2)");
    });
});

RPG.on("reload", () => RPG.log("Dragon Block Ragnarok loaded: " + RPG.skills.list().length + " techniques, " + RPG.quests.list().length + " quests, "
    + RPG.bosses.list().length + " bosses."));
