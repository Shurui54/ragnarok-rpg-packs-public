# Dragon Block Ragnarok

A Dragon Ball game for the Ragnarok RPG Toolkit, written entirely in its scripting API. Licensed GPL-3.0-or-later (see `LICENSE`); credits for the original game and art are in `NOTICE.md`.

## Keys

DMZ's default keys (rebind them in Options > Controls > "Ragnarok RPG"):

| Key | Action |
|---|---|
| Alt+1..4 / Ctrl+1..4 | technique slots 1-8 |
| C (hold) | charge ki: power release climbs, ki refills faster |
| Alt+C (hold) | lower power release |
| V | stats menu (the character creator if you haven't made one) |
| F | fly |
| R | dash |
| Z | lock on |

Being rebuilt to DMZ's exact behaviour next: G (transform), H (instant transmission), X (utility menu), F4 (ki sense), right click (block), Alt+right click (ki blast).

## What matches DragonMine Z now

- The character creator: race carousel with DMZ's panoramas and racial skills, then the Body / Hair / Eyes / Face / Tattoo / Class tabs.
- The Xenoverse HUD, the stats screen (V), DMZ's eight classes and six stats, and DMZ's formulas for health, ki, stamina, damage, defence, power release, power level, TP gains, stat prices and level.

## Animations

Every player plays DragonMine Z's own animations, chosen the way DMZ chooses them (its 10 animation
controllers, ported to `client/scripts/40_animator.js`): walking and running at your speed, crouching,
swimming, climbing, the landing after a long fall, flying in every direction, the per-race ki charge,
surge, blocking, shields, punches and tool swings, eating, dashes and dodges, techniques (cast and fire),
transformations and the tail, which gets livelier the faster you move.

What other players are doing comes from the server (`scripts/12_anim_state.js`), so everyone sees the
same thing. Addons can change any of it:

```js
// client script: spin while a server flag is set
DBR_ANIMATOR.extend((pl, out) => { if (pl.shared("spinning")) out.layers.extra = "skp.meteor"; });
// a weapon stance
DBR_ANIMATOR.poses["minecraft:diamond_sword"] = "combat.pose_two_handed_sword";
// procedural bones: wag the tail harder
DBR_ANIMATOR.extend((pl, out) => { out.bones.tail1 = { ry: Math.sin(pl.tick / 3) * 15 }; });
```

## The scripts

The files are in `addons/dragon_block_ragnarok/scripts/` (open them in the F8 editor under `addons/`).

| File | What's in it |
|---|---|
| `00_project.js` | Project id/name, leveling mode **"both"** (levels give skill points, TP buys stats), XP curve, TP earning and prices, Zeni, combat formulas |
| `06_hud_dmz.js` | The DMZ HUD as a script-defined layout (players can move/resize it) |
| `07_creator_dmz.js` | The DMZ character creator: race, body, skin, hair, eyes, nose, mouth, class |
| `01_toolbox.js` | Shared helpers: `sfx()` (pack sounds), `act()` (play an avatar animation, then return to flying/charging), damage formulas, `lookPoint()`, lock-on, `times()` |
| `05_ui.js` | Ragnarok theme, HUD (ki/stamina bars, portrait), race + class picker, DMZ menu tab names, colours |
| `10_stats.js` | STR, SKP, RES, VIT, PWR, ENE, three hidden "marker" stats for gear, and `powerLevel()` |
| `15_resources.js` | Ki (grows with Energy) and Stamina (grows with Vitality) |
| `20_races.js` | The six races with **avatars** built from DMZ's layered textures, their default colours, the `raceChange` hook that applies them, and `/rpgc color` |
| `25_classes.js` | Warrior and Spiritualist (each with a starting gi and technique) |
| `29_dmz_auras.js` | How auras look: 2D or DMZ's 3D styles (Smooth / Sparking / God, picked in V > Config), each form's 3D tuning, the flight lean and the ki surge's swelling aura (options in `client/scripts/43_dmz_auras.js`) |
| `30_forms.js` | `defineForm()` and 30+ forms: Kaioken x2-x20, Oozaru, Super Saiyan 1/G2/G3/2/3/4/God/Blue, Golden Oozaru, Giant/Super/Orange Namekian, the Frost Demon forms up to Golden and Metal, Semi-Perfect to Xeno, Super/Evil/Kid Majin, Super Janemba. Each swaps the avatar, adds an aura and plays a DMZ transformation animation |
| `35_projectiles.js` | Every ball, beam, laser, disk, sprite and thrown item (30 projectiles) |
| `41_dmz_techniques.js` | DMZ's techniques (data in `shared/09_dmz_techniques_data.js`): learned from masters/quests/`/rpgc dmztech`, a pop-up when learned, Bind to Slot (V > Skills), 8 slots on Alt/Ctrl+1..4, ki charge to 175 %, strikes and evasions; HUD in `client/scripts/47_dmz_notifications.js` and `49_dmz_techniques.js` |
| `40_skills.js` | `kiTechnique()` / `strikeTechnique()` recipes and ~50 techniques: beams, volleys, disks, DMZ "skp" strikes, Zanzoken, Instant Transmission, Solar Flare, barriers, Absorb, Fusion Dance, passives |
| `45_keys.js` | The DMZ controls: charge ki, flight, dash, descend/meditate, lock-on, ascend, guard, power strike |
| `50_items.js` | Senzu beans (and farmable coloured beans), food, medicine, capsules, Gete stat capsules, scouters, three Dragon Ball sets and radars, weapons and guns, weights, Potara earrings, Nimbus, 40 music discs |
| `52_armor.js` | 47 DMZ outfits (skin64 armour model) and a sewing pattern for each |
| `55_blocks.js` | Namek terrain, ores and trees, Earth/Hell/Demon Realm blocks, flowers, herbs, growing Senzu crops, the Time Chamber floor, a Dragon Altar |
| `60_npcs_dialogue.js` | `teacher()` and 25 DMZ masters who teach techniques, townsfolk, Namekian villagers, vehicle props, the punch machine, Shenron and Porunga |
| `65_shops.js` | Kame House, Korin, Capsule Corp., Namek, Frieza Force, Babidi, Yajirobe, Toribot's jukebox |
| `70_quests.js` | Tutorial, the Saiyan / Namek / Android / Buu sagas (21 chained quests) and side quests (tournaments, Baba, Old Kai's ritual...) |
| `75_mobs_bosses.js` | ~100 mobs (Saibamen, soldiers, robots, dinosaurs, frogs, ogres, the training shadow, the dragons) and 57 bosses, including Frieza's four forms in a row and DMZ's world bosses with their music |
| `80_spawns_events.js` | Natural spawns on Earth, Namek, the Other World and in the Time Chamber; random events (invasions, radar pings, Double TP, world bosses) |
| `85_world.js` | The Time Chamber, Namek and Other World dimensions, travel helpers and `/rpgc leave` |
| `90_hooks.js` | Welcome, level-ups, kill streaks, regeneration, Zenkai, barrier/guard damage reduction, hurt animations, TP multipliers, overrides, and `/rpgc power`, `help`, `arena`, `setup` |

**To try it:** join, pick a race and a class, and type `/rpgc setup` (op) to place Roshi, Korin, Bulma, Mr. Popo, King Yemma and other masters around you. Talk to Roshi to start the saga. Quick tests: `/rpg learn @s kamehameha`, `/rpg learn @s super_saiyan`, `/rpg mob saibaman`, `/rpg boss frieza_first`, `/rpg event start world_boss`, `/rpgc color hair #FF0000`. After the first start, **restart once** so the three dimensions load.
