// =====================================================================================
//  57_dragon_balls.js - DMZ's Dragon Balls (DragonBallsHandler, DragonBallBlock, DefaultWishes)
// =====================================================================================
//  Three sets of placeable balls: Earth (7, overworld, Shenron, 1 wish), Namek (7, Namek,
//  Porunga, 3 wishes) and Demon Realm (3, dropped by the Tamagami bosses, Porunga Daima,
//  3 wishes). Earth and Namek balls are scattered within 1000 blocks of spawn and tracked;
//  radars show them. Put every ball of a set within 5 blocks and right-click one to summon
//  the dragon; right-click the dragon to choose your wishes. Then the balls scatter again.
// =====================================================================================
var DB_SETS = {
    earth: { stars: 7, dim: "minecraft:overworld", dragon: "shenron", wishes: 1, natural: true, block: (n) => "dball" + n,
             name: (n) => n + "-Star Dragon Ball" },
    namek: { stars: 7, dim: "ragnarok_rpg:namek", dragon: "porunga", wishes: 3, natural: true, block: (n) => "dball" + n + "_namek",
             name: (n) => n + "-Star Namekian Dragon Ball" },
    demon: { stars: 3, dim: "ragnarok_rpg:demon_realm", dragon: "porunga_daima", wishes: 3, natural: false, block: (n) => "dball" + n + "_demon",
             name: (n) => n + "-Star Demon Realm Dragon Ball" }
};
var DB_CFG = { spawnRange: 1000, summonRadius: 5, dragonWaitTicks: 12000, despawnDelay: 100, fadeTicks: 50 };

// ---- wishes (DefaultWishes.java; names/descriptions are DMZ's lang keys) ----------------
var DB_WISHES = {
    shenron: [
        { key: "senzu", items: [["senzu_bean", 16]] },
        { key: "attributes", attributes: 100 },
        { key: "powerpole", items: [["power_pole", 1]] },
        { key: "mightfruit", items: [["might_tree_fruit", 16]] },
        { key: "namekcpu", items: [["t2_radar_cpu", 4]] },
        { key: "saiyanship", items: [["saiyan_ship", 1]] },
        { key: "racialskillreset", passiveReset: true },
        { key: "customization", recustomize: true },
        { key: "changedifficulty", changeDifficulty: true },
        { key: "resetstory", resetStory: true },
        { key: "revive", revive: 3 },
        { key: "materials", items: [["kikono_shard", 32], ["minecraft:iron_ingot", 64]] },
        { key: "strongest", items: [["strongest_armor_chestplate", 1], ["strongest_armor_leggings", 1], ["strongest_armor_boots", 1]] }
    ],
    porunga: [
        { key: "senzu", items: [["senzu_bean", 32]] },
        { key: "attributes", attributes: 75 },
        { key: "bravesword", items: [["brave_sword", 1]] },
        { key: "frieza_capsule", items: [["frieza_capsule", 1]] },
        { key: "racialskillreset", passiveReset: true },
        { key: "customization", recustomize: true },
        { key: "relocatestats", relocate: true },
        { key: "changedifficulty", changeDifficulty: true },
        { key: "resetstory", resetStory: true },
        { key: "revive", revive: 1, repeatable: true },
        { key: "materials", items: [["kikono_shard", 64], ["minecraft:iron_ingot", 128]] },
        { key: "invincible", items: [["invencible_armor_helmet", 1], ["invencible_armor_chestplate", 1], ["invencible_armor_leggings", 1], ["invencible_armor_boots", 1]] },
        { key: "invincible_blue", items: [["invencible_blue_armor_helmet", 1], ["invencible_blue_armor_chestplate", 1], ["invencible_blue_armor_leggings", 1], ["invencible_blue_armor_boots", 1]] },
        { key: "pothala_yellow", items: [["pothala_pair", 1]] },
        { key: "pothala_green", items: [["green_pothala_pair", 1]] }
    ]
};
DB_WISHES.porunga_daima = DB_WISHES.porunga;

(function () {
    // ---- the ball blocks (DragonBallBlock: small, on the ground, amethyst sounds) ----
    // (Rhino shares one variable across loop passes, so each ball gets its own function call)
    function defineBall(setId, set, n) {
            let id = set.block(n);
            RPG.blocks.define(id, {
                name: (setId === "earth" ? "&6" : setId === "namek" ? "&a" : "&5") + set.name(n),
                model: "dbr:rpg/block/" + id,
                itemModel: DMZ + "rpg/item/" + id,          // DMZ's flat icon in the inventory
                decor: true, hardness: 0.5, light: 4,
                shape: setId === "namek" ? [3, 0, 3, 13, 12, 13] : [4, 0, 4, 12, 8, 12],
                onUse(p, x, y, z) { trySummon(p, setId, x, y, z); },
                onPlace(p, x, y, z) { ballPlaced(setId, n, p.dimension, x, y, z); },
                onBreak(p, x, y, z) { ballTaken(setId, n, p.dimension, x, y, z); }
            });
    }
    Object.keys(DB_SETS).forEach((setId) => {
        for (let n = 1; n <= DB_SETS[setId].stars; n++) defineBall(setId, DB_SETS[setId], n);
    });

    // ---- saved state: active balls (placed in the world), pending (waiting for their chunk) ----
    function state(setId) {
        let s = RPG.data.get("db_" + setId, null);
        if (!s || typeof s !== "object") s = { active: {}, pending: {}, first: false };
        if (!s.active) s.active = {};
        if (!s.pending) s.pending = {};
        return s;
    }
    function save(setId, s) { RPG.data.set("db_" + setId, s); RADAR_DIRTY = true; }
    var RADAR_DIRTY = true;

    function scatter(setId) {
        let set = DB_SETS[setId];
        if (!set.natural) return;
        let s = state(setId), sp = RPG.world.spawnPoint(), r = DB_CFG.spawnRange;
        for (let n = 1; n <= set.stars; n++) {
            if (s.active[n] || s.pending[n] || s.held && s.held[n]) continue;
            s.pending[n] = { x: Math.floor((sp.x || 0) + (Math.random() * 2 - 1) * r), z: Math.floor((sp.z || 0) + (Math.random() * 2 - 1) * r) };
        }
        s.first = true;
        save(setId, s);
    }

    var DB_SINK = /^minecraft:(water|air|cave_air|kelp|kelp_plant|seagrass|tall_seagrass|bubble_column)$/;

    // drop pending balls once their chunk is loaded (DMZ: maintain every 20 ticks)
    function maintain() {
        for (let setId in DB_SETS) {
            let set = DB_SETS[setId];
            if (!set.natural) continue;
            let s = state(setId), changed = false;
            if (!s.first) { scatter(setId); s = state(setId); }
            for (let n in s.pending) {
                let pnd = s.pending[n];
                if (!RPG.world.isLoaded(set.dim, pnd.x, pnd.z)) continue;
                let y = RPG.world.surfaceY(set.dim, pnd.x, pnd.z);
                if (y < -9000) continue;
                // the surface height counts water: sink through it (and kelp/seagrass) to the sea bed. Only ever going
                // down from the open surface keeps balls out of caves.
                let guard = 0;
                while (guard++ < 320 && DB_SINK.test(String(RPG.world.getBlock(set.dim, pnd.x, y - 1, pnd.z)))) y--;
                RPG.world.setBlock(set.dim, pnd.x, y, pnd.z, RPG.blocks.id(set.block(Number(n))));
                s.active[n] = { x: pnd.x, y: y, z: pnd.z, dim: set.dim };
                delete s.pending[n];
                changed = true;
            }
            if (changed) save(setId, s);
        }
    }

    // a tracked ball missing from the world (and not carried) goes back to pending
    function validate() {
        for (let setId in DB_SETS) {
            let set = DB_SETS[setId], s = state(setId), changed = false;
            for (let n in s.active) {
                let a = s.active[n];
                if (!RPG.world.isLoaded(a.dim, a.x, a.z)) continue;
                if (RPG.world.getBlock(a.dim, a.x, a.y, a.z) !== RPG.blocks.id(set.block(Number(n)))) {
                    delete s.active[n];
                    changed = true;
                }
            }
            if (changed) { save(setId, s); scatter(setId); }
        }
    }

    function ballPlaced(setId, n, dim, x, y, z) {
        let s = state(setId);
        s.active[n] = { x: x, y: y, z: z, dim: dim };
        delete s.pending[n];
        if (s.held) delete s.held[n];
        save(setId, s);
        if (gathered(setId, dim, x, y, z)) RPG.world.sound(dim, DMZ + "dragonballssound", x, y, z, 1, 1);
    }
    function ballTaken(setId, n, dim, x, y, z) {
        let s = state(setId);
        delete s.active[n];
        s.held = s.held || {};
        s.held[n] = true;                           // carried: the radar loses it until it's placed again
        save(setId, s);
    }

    // every star of the set within the summon radius (a cube, like DMZ)
    function findSet(setId, dim, x, y, z) {
        let set = DB_SETS[setId], r = DB_CFG.summonRadius, found = {};
        let ids = {};
        for (let n = 1; n <= set.stars; n++) ids[RPG.blocks.id(set.block(n))] = n;
        for (let dx = -r; dx <= r; dx++) for (let dy = -r; dy <= r; dy++) for (let dz = -r; dz <= r; dz++) {
            let b = RPG.world.getBlock(dim, x + dx, y + dy, z + dz), n = ids[b];
            if (n && !found[n]) found[n] = { x: x + dx, y: y + dy, z: z + dz };
        }
        let count = 0;
        for (let k in found) count++;
        return count === set.stars ? found : null;
    }
    function gathered(setId, dim, x, y, z) { return findSet(setId, dim, x, y, z) !== null; }

    // ---- summoning ----
    var SUMMONS = {};                                // dragon uuid -> { set, owner, expires, granted, entity }

    function trySummon(p, setId, x, y, z) {
        let set = DB_SETS[setId];
        let found = findSet(setId, p.dimension, x, y, z);
        if (!found) return;
        for (let k in SUMMONS) if (SUMMONS[k].dim === p.dimension) { p.actionbar("&eThe Eternal Dragon is already here."); return; }
        for (let n in found) RPG.world.setBlock(p.dimension, found[n].x, found[n].y, found[n].z, "minecraft:air");
        let s = state(setId);
        for (let n = 1; n <= set.stars; n++) { delete s.active[n]; if (s.held) delete s.held[n]; }
        save(setId, s);
        RPG.world.lightning(p.dimension, x, y, z, true);
        let dragon = RPG.world.spawnMob(p.dimension, set.dragon, x + 0.5, y, z + 0.5);
        if (!dragon) { p.tell("&cThe dragon couldn't appear here."); return; }
        SUMMONS[dragon.uuid] = { set: setId, owner: p.uuid, ownerName: p.name, expires: RPG.server.getTick() + DB_CFG.dragonWaitTicks,
                                 granted: false, entity: dragon, dim: p.dimension, x: x, y: y, z: z };
        RPG.world.sound(p.dimension, DMZ + "shenron", x, y, z, 4, 1);
        skyFor(p.dimension, true);
        p.tell("&6Right-click the dragon to make your wish" + (set.wishes > 1 ? "es" : "") + ".");
    }

    function skyFor(dim, on) {
        RPG.server.players().forEach((pl) => { if (pl.dimension === dim) RPG.net.send(pl, "dmz_dragon_sky", { on: on ? 1 : 0 }); });
    }

    // right-click the dragon (owner only) -> the wish screen
    RPG.on("entityInteract", (p, e) => {
        if (!e) return;
        let s = SUMMONS[e.uuid];
        if (!s) return;
        if (s.owner !== p.uuid) { p.actionbar("&eOnly " + s.ownerName + " can make the wish."); return false; }
        if (s.granted) return false;
        let list = DB_WISHES[DB_SETS[s.set].dragon] || [];
        let dead = typeof dmzDeadPlayers === "function" ? dmzDeadPlayers().map((d) => ({ id: d.uuid, name: d.name })) : [];
        RPG.net.send(p, "dmz_wishes", {
            dragon: e.uuid, type: DB_SETS[s.set].dragon, count: DB_SETS[s.set].wishes, dead: dead,
            wishes: list.map((w) => ({ key: w.key, repeatable: !!w.repeatable, targets: w.revive || 0 }))
        });
        return false;
    });

    RPG.net.on("dmz_grant", (p, d) => {
        let s = SUMMONS[d && d.dragon];
        if (!s || s.granted || s.owner !== p.uuid) return;
        let e = s.entity;
        if (!e || !e.isAlive() || Math.sqrt((p.x - e.x) * (p.x - e.x) + (p.z - e.z) * (p.z - e.z)) > 50) return;
        let set = DB_SETS[s.set], list = DB_WISHES[set.dragon] || [];
        let picks = (d.picks || []).map((i) => Math.floor(Number(i))).filter((i) => i >= 0 && i < list.length);
        if (picks.length !== set.wishes) return;
        let seen = {};
        for (let i = 0; i < picks.length; i++) {
            let w = list[picks[i]];
            if (!w.repeatable && seen[picks[i]]) return;          // non-repeatable wishes once
            seen[picks[i]] = true;
        }
        s.granted = true;
        picks.forEach((i, k) => grant(p, list[i], (d.targets && d.targets[k]) || []));
        RPG.world.sound(s.dim, DMZ + "shenron", e.x, e.y, e.z, 3, 1.1);
        p.tell("&6&lYOUR WISH HAS BEEN GRANTED.");
        RPG.schedule(DB_CFG.despawnDelay, () => leave(e.uuid));
    });

    function giveAll(p, items) {
        items.forEach((it) => {
            try { p.giveItem(it[0], it[1]); }
            catch (err) { p.tell("&c(" + it[0] + " isn't in this game yet)"); }
        });
    }

    function grant(p, w, targets) {
        let v = dmzView(p);
        if (w.items) giveAll(p, w.items);
        if (w.attributes) {
            // half as AP, half as the TP those attributes would cost right now
            let half = Math.floor(w.attributes / 2);
            p.setStatPoints(p.statPoints + half);
            p.addTp(DMZ_F.cost(DMZ_F.total(v), half, (DMZ_DATA.CLASSES[p.playerClass] || DMZ_DATA.CLASSES.warrior).tpCost), { raw: true, events: false, source: "script" });
        }
        if (w.passiveReset) {
            ["dmz_zenkai_release", "dmz_zenkai_count", "dmz_absorptions", "dmz_assimilations", "dmz_cell_jrs"].forEach((k) => p.setVar(k, 0));
        }
        if (w.recustomize) {
            p.setVar("dmz_recustomize", 1);                       // the creator keeps your race
            RPG.schedule(20, () => RPG.net.send(p, "dmz_open_creator", { recustomize: true, race: p.race }));
        }
        if (w.relocate) {
            let c = DMZ_DATA.CLASSES[p.playerClass] || DMZ_DATA.CLASSES.warrior, refund = 0;
            DMZ_DATA.STATS.forEach((k) => {
                let id = DMZ_DATA.STAT_IDS[k], have = p.allocated(id), base = c.base[k] || 0;
                if (have > base) { refund += have - base; p.addStat(id, base - have); }
            });
            p.setStatPoints(p.statPoints + Math.floor(refund));
            p.refreshStats();
        }
        if (w.changeDifficulty) p.setVar("dmz_reselect_difficulty", 1);
        if (w.resetStory) {
            p.setVar("dmz_story_resets", (Number(p.getVar("dmz_story_resets", 0)) || 0) + 1);
            p.setVar("dmz_reset_story", 1);                       // the quest system wipes progress on its next check
            if (typeof dmzResetStory === "function") dmzResetStory(p);
        }
        if (w.revive) {
            (targets || []).slice(0, w.revive).forEach((uuid) => {
                let t = RPG.server.players().filter((x) => x.uuid === uuid)[0];
                if (t && typeof dmzRevive === "function" && (typeof dmzIsDead !== "function" || dmzIsDead(t))) dmzRevive(t);
            });
        }
    }

    // the dragon fades (end rod particles), the sky clears and the balls scatter
    function leave(uuid) {
        let s = SUMMONS[uuid];
        if (!s) return;
        let e = s.entity, steps = Math.floor(DB_CFG.fadeTicks / 5);
        for (let i = 0; i < steps; i++) RPG.schedule(i * 5, () => {
            if (e && e.isAlive()) RPG.world.particle(s.dim, "minecraft:end_rod", e.x, e.y + 6, e.z, 40, 3, 0.05);
        });
        RPG.schedule(DB_CFG.fadeTicks, () => {
            if (e && e.isAlive()) e.kill();
            delete SUMMONS[uuid];
            skyFor(s.dim, false);
            RPG.world.setWeather(s.dim, "clear", 6000);
            scatter(s.set);
        });
    }

    // ---- timers ----
    RPG.every(20, () => {
        maintain();
        let now = RPG.server.getTick();
        for (let k in SUMMONS) {
            let s = SUMMONS[k];
            if (!s.granted && (now > s.expires || !s.entity || !s.entity.isAlive())) { s.granted = true; leave(k); }
        }
    });
    RPG.every(200, validate);

    // ---- radar data (RadarSyncS2C every 100 ticks): every known position per set ----
    function radarPacket() {
        let out = { ids: {}, sets: {} };
        out.ids.dball_radar = RPG.items.id("dball_radar");
        out.ids.namekdball_radar = RPG.items.id("namekdball_radar");
        out.ids.fused_dball_radar = RPG.items.id("fused_dball_radar");
        for (let setId in DB_SETS) {
            let s = state(setId), list = [];
            for (let n in s.active) list.push({ x: s.active[n].x, z: s.active[n].z });
            for (let n in s.pending) list.push({ x: s.pending[n].x, z: s.pending[n].z });
            out.sets[setId] = list;
        }
        return out;
    }
    RPG.every(100, () => {
        let pkt = radarPacket();
        RPG.server.players().forEach((p) => RPG.net.send(p, "dmz_radar", pkt));
        RADAR_DIRTY = false;
    });
    RPG.on("playerJoin", (p) => RPG.schedule(40, () => {
        RPG.net.send(p, "dmz_radar", radarPacket());
        for (let k in SUMMONS) if (SUMMONS[k].dim === p.dimension) RPG.net.send(p, "dmz_dragon_sky", { on: 1 });
    }));

    // ---- radars (DragonRadarItem: right-click switches range 150/300, fused 150/300/600) ----
    [["dball_radar", "&eDragon Radar", [150, 300]], ["namekdball_radar", "&aNamek Dragon Radar", [150, 300]],
     ["fused_dball_radar", "&bBi-Dimensional Radar", [150, 300, 600]]].forEach((r) => {
        RPG.items.define(r[0], {
            name: r[1], model: DMZ + "rpg/item/" + r[0], type: "tool", rarity: "rare", maxStack: 1,
            lore: ["Hold it to see the Dragon Balls.", "Right-click to change the range."],
            onUse(p) {
                let ranges = r[2], cur = Number(p.getVar("dmz_radar_range", ranges[0])) || ranges[0];
                let next = ranges[(ranges.indexOf(cur) + 1) % ranges.length];
                p.setVar("dmz_radar_range", next);
                p.playSound(DMZ + "dragonradar", 0.6, 1);
                p.actionbar("&eRadar range: &f" + next + " blocks");
            }
        });
    });

    // ops: /rpgc dragonballs [set] - where the balls are; /rpgc dragonballs scatter <set>
    RPG.commands.register("dragonballs", {
        permission: 2, description: "/rpgc dragonballs [earth|namek] [scatter|give] - Dragon Ball positions / rescatter / give a set",
        run(p, args) {
            let setId = DB_SETS[args[0]] ? args[0] : "earth", s = state(setId);
            if (args[1] === "scatter") { s.active = {}; s.pending = {}; s.held = {}; save(setId, s); scatter(setId); p.tell("&aScattered the " + setId + " set."); return; }
            if (args[1] === "give") { for (let n = 1; n <= DB_SETS[setId].stars; n++) p.giveItem(DB_SETS[setId].block(n), 1); return; }
            for (let n = 1; n <= DB_SETS[setId].stars; n++) {
                let a = s.active[n], q = s.pending[n];
                p.tell("&e" + n + "★ &f" + (a ? "at " + a.x + " " + a.y + " " + a.z : q ? "waiting at " + q.x + " ~ " + q.z + " (chunk not loaded)" : s.held && s.held[n] ? "carried" : "?"));
            }
        }
    });
})();
