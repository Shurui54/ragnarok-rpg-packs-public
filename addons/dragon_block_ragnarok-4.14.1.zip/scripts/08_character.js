// =====================================================================================
//  08_character.js - original character creation (server side)
// =====================================================================================
//  New players get the original's creator (client/scripts/20_creator.js): race carousel, then the
//  customization tabs. Pressing Confirm sends "dmz_create" here, which checks the picks
//  and creates the character the way the original's CreateCharacterC2S does.
// =====================================================================================
(function () {
    var COLOR_KEYS = ["body1", "body2", "body3", "hair", "eyes", "eye2", "aura"];
    var LOOK_OK = ["bodyType", "bodyModel", "eyeStyle", "nose", "mouth", "hairStyle", "tattoo", "headBone"];
    var HEX = /^#?[0-9A-Fa-f]{6}$/;

    function created(p) { return !!p.getVar("dmz_created", 0); }

    function openCreator(p) { RPG.net.send(p, "dmz_open_creator", {}); }

    RPG.on("playerJoin", (p) => {
        if (!created(p)) RPG.schedule(30, () => { if (!created(p)) openCreator(p); });
    });
    // killed before the creator could be used (a mob at the spawn): the death screen replaced it, so ask again
    RPG.on("respawn", (p) => {
        if (!created(p)) RPG.schedule(10, () => { if (!created(p) && p.alive) openCreator(p); });
    });

    RPG.net.on("dmz_create", (p, data) => {
        if (created(p) || !data) return;
        let race = String(data.race || ""), cls = String(data.cls || "warrior");
        if (RPG.races.list().indexOf(race) < 0) { openCreator(p); return; }       // unknown race: ask again
        let locked = typeof DBR_PRESTIGE !== "undefined" ? DBR_PRESTIGE.raceLocked(p, race) : null;   // prestige / operator race gates
        if (locked) { p.tell("&c" + locked); openCreator(p); return; }
        if (!DMZ_DATA.CLASSES[cls]) cls = "warrior";
        p.race = race;
        p.playerClass = cls;
        let looks = data.looks || {}, defaults = DBR_RACE_DEFAULTS[race] || {};
        COLOR_KEYS.forEach((k) => { let v = String(looks[k] || defaults[k] || ""); if (HEX.test(v)) p.setColor(k, v.charAt(0) === "#" ? v : "#" + v); });
        LOOK_OK.forEach((k) => {
            let v = looks[k] !== undefined ? String(looks[k]) : defaults[k];
            if (v !== undefined && /^[a-z0-9_]{1,24}$/i.test(String(v))) p.setColor(k, String(v));
        });
        p.setVar("dmz_created", 1);
        p.setVar("dmz_release", 0);
        p.refreshStats();
        RPG.schedule(2, () => {
            ["ki", "stamina"].forEach((r) => p.setResource(r, p.maxResource(r)));
            p.health = p.maxHealth;
        });
        uiSfx(p, "dmzpack:ui_menu_switch", 1, 1);
    });

    // the navigation row of the original's menu screens (stats, skills 46_dmz_skills.js, quests 47_dmz_quests.js)
    RPG.net.on("dmz_menu", (p, d) => {
        let tab = String(d && d.tab);
        if (tab === "stats") RPG.net.send(p, "dmz_open_stats", {});
        else if (tab === "skills") DMZ_SKILLS.open(p);
        else if (tab === "quests") DMZ_QUESTS.open(p);
        else if (tab === "config") RPG.net.send(p, "dmz_open_config", { op: p.isOp() }); // The original's options screen (client/scripts/54_dmz_config_menu.js); ops also get its Server rows
        else if (tab === "engine_settings") p.openMenu("settings");                     // its "More settings" / "HUD Layout" buttons
        else if (tab === "minigames" && typeof DMZ_MINIGAMES !== "undefined") DMZ_MINIGAMES.openHub(p);   // 67_dmz_minigames.js
        else if (tab === "party" && typeof DMZ_PARTY !== "undefined") DMZ_PARTY.open(p);
        else p.actionbar("&7Coming soon");
    });

    // The original's per-player options that need the server (client/scripts/09_dmz_options.js): "Reserve First Hotbar Slot"
    // (the original ReserveFirstHotbarSlotC2S + InventoryMixin: picked-up items skip slot 1). Sent on join and when toggled.
    RPG.net.on("dmz_user_opts", (p, d) => {
        if (d && typeof d.reserve === "boolean" && typeof p.setFirstSlotReserved === "function") p.setFirstSlotReserved(d.reserve);
    });

    // ops: /rpgc recreate <player> lets someone make their character again (the original: the Re-Customize wish)
    RPG.commands.register("recreate", {
        permission: 2, description: "/rpgc recreate [player] - open the character creator again",
        run(p, args) {
            let target = args[0] ? RPG.server.player(args[0]) : p;
            if (!target) return;
            target.setVar("dmz_created", 0);
            openCreator(target);
        }
    });
})();
