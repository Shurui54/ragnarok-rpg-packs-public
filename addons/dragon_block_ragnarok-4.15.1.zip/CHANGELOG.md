# Changelog

Dragon Block Ragnarok, newest first. The section for the published version is posted on Discord, so keep the heading
as `## <version> (YYYY-MM-DD)` and the bullets short.

## 4.15.1 (2026-11-17)

- Hair editor: the original's editor, with its layout, controls and art: strands per face, length, segments, falloff, width, depth, taper, angles, bends, twist, per-segment tweaks, colours, mirror, undo/redo and Generate from Base. Opens from the creator's hair tab (Edit), Mr. Popo's Haircut, the Dragon Block menu and `/dmzhair edit`.
- Hair codes: Import and Export (Style / Full) use the original 2.2's hair codes, old and new versions; a code copied from the original gives the same hair here, and a code exported here is exactly what the original would export. `/dmzhair export` copies yours from chat.
- Your own hairstyles are saved with each character; presets still work as before.
- The hair now grows into the next form while a transformation charges, falls back when you let go and fades over a second when you power down, like the original.
- Majins can wear hair (made in the hair editor), like the original.
- `/dmzhair resync` and `/dmzhair reset` like the original.
- On engines before 0.28.1 the hair editor and hair codes are switched off (the creator, Mr. Popo and the Dragon Block menu keep the presets) instead of failing to save.
- Hair saves are rate limited like the original (one per 10 ticks).

- Final Explosion looks like the original: a glowing sphere lifts you while it charges, then swells round you and keeps hitting for its whole duration.
- Ki attacks throw off their original sparks, flecks and splashes; small ki blasts leave a glowing streak; ki explosions animate at their real size.
- Melee hits, blocks, parries and guard breaks show the original's hit flashes, and bare-handed hits play the punch sounds.
- Ki surge / overcharge flame border hugs your real hair and body instead of showing a boxy shape like different hair or a cape (with engine 0.28.1).
- The ki surge flame border now shows for everyone, not only after you had charged ki yourself; the Dragon Block menu lists the Hair Editor.
- JEI: `@dragon`, `@dragon_block_ragnarok` or `@dragonblock` finds every Dragon Block item (with engine 0.28.1).

## 4.15.0 (2026-11-17)

- Dragon Block menu: `/dbrgui` or the "Dragon Block menu" key (default `` ` ``) opens one hub that reaches every Dragon Block screen.
- Key binds are grouped under their own Controls category.
- Space: the cereal village lookup works again.
- The world boss contribution panel recognises your own row reliably.
- The creator opens correctly when the art finishes downloading after you join.
- Works on engine 0.27 as well (the menu's back-to-hub needs 0.28).

## 4.14.1 (2026-11-16)

- Neutral wording in in-game text.

## 4.14.0 (2026-11-15)

- Ki attacks reworked: charging, placement, movement holds, fixed beams and the plain ki blast.
- Wild planet garrisons and the conquest defender.
- Masters can't be hurt or pushed and respawn at once.
- Auras: the God aura draws properly and the ki surge has a flame border.
- Space: planet dressing spread over ticks so servers don't stall.
- The character creator comes back after dying before it was used.
- Techniques say why a slot key did nothing.
- Guard works even when the window focus flag is wrong.
- False Super Saiyan, Super Saiyan 5, Super Saiyan God and Primal Namekian can be found and used.

## 4.13.0 (2026-11-14)

- Per-form dodge and damage-taken buffs; the form editor has its Dodge and Buffs tabs back.
- Transformation outlines on bosses and the Demon Eye.

## 4.12.0 (2026-11-14)

- Saibaman seeds: plant them on Rocky Dirt, grow them faster by charging ki nearby, and hatch a tamed Saibaman whose strength depends on how much of its growth was charged (3 per player).
- Buried seeds in the Saibamen huts on Planet Vegeta and on generated planets.
- The ki surge draws a flame outline round the body.
- 3D auras show again: round the body, leaning in fast flight and in the air.
- The Form Menu (X) follows the real key and no longer stays open after a quick hold.
- The placeholder charging particles are gone.

## 4.11.0 (2026-11-13)

- Planet Cereal: mesas, canyons, crystal fields, Cerealian villages and ruins, Granolah and Monaito with Monaito's quests, and the home of the Cerulean Dragon Balls.
- Beerus' planet in its own dimension, and the Vegeta capital round the landing spot; generated planets get craters, beaches, vegetation and Saibamen huts.
- Rituals: Ki sharing and the Super Saiyan God ritual (solo in single player), the Super Saiyan God charge ritual, the Super Saiyan 5 wish and the Namekian god ritual.
- Raids at raid sites: scouts, an omen, five waves, a boss bar, music and rewards.
- NPC-hosted tournaments: Fortuneteller Baba, the Cell Games, the World Martial Arts Tournament and the Otherworld Tournament.
- Racial skills: Human Adrenaline, Frost Demon Power Reserve, Saiyan Zenkai, Bio-Android Self-Destruct and Cell Jr., and Namekian assimilation requests.
- 3D auras with their original shaders; the form editor picks aura sheets, 3D styles, overlays and custom GeckoLib models.
- Every Dragon Radar is craftable, outfits and cosmetics are sewn in the Pattern and Kikono stations, and machine recipes show in the Recipe Viewer.
- The Dragon Ball-Sack accessory; one ball of each star per server, and lost balls go home. Graves are headstones, and a grave holding only balls shows them.
- Every command under `/rpgc` with permission nodes and tab completion; old command names still work; `/rpgc grantall` replaces `testall`.
- Tab list and rank badges.
- Capes sway and leg-covering outfit parts keep clear of the legs (outfitpack 1.0.1).
- Ground item clear, off by default (`/rpgc clearitems`).
- Every block has its proper sound, plants follow their ground rules, and Dragon Balls can be placed on any block again.
- Super Dragon Balls are solid and clickable from every side. Dragon Balls can be traded but not auctioned or put in vaults.
- Harder ki clashes.
- Menus: private sounds, one action per click, smoother panning, slide and fade transitions, and form editor saves that apply at once.
- Timed random events are gone (invasions, radar pings, Double TP Hour); the mobs and their spawns stay.

## 4.10.0 (2026-11-12)

- One-per-world landmarks keep 500 blocks from each other and 3 chunks from other structures, and pick their spot from the surface biome. New chunks only.
- The landmark search tries nearer rings again, and the Tree of Might and the Big Gete Star fall back to any clear ground after a long search.

## 4.9.3 (2026-11-12)

- Partial keep inventory and death graves: below level 100 you keep everything; from then on the hotbar, armour, off hand and accessories stay and the rest goes into a grave where you died. Dragon Balls are never kept. Settings in `dbr_keep_inventory`.
- Quest and forms trees stop panning as soon as the button is released.

## 4.9.2 (2026-11-12)

- The K menu keeps only Options; Status, Techniques and Sagas live in Dragon Block's own screens.

## 4.9.1 (2026-11-12)

- Outfit and cosmetic art moves to its own art pack (outfitpack), asked for automatically. Item ids are unchanged.

## 4.9.0 (2026-11-12)

- Quests count kills of NPCs made in the NPC editor, and quest marks show over NPCs (! to start, ? to hand in).
- Creator face and hair cards are still close-ups framed on the head.
- Rhythm charts are built over several ticks instead of stalling one.

## 4.8.1 (2026-11-12)

- 165 cosmetics in four cosmetic accessory slots, drawn on every race, with a creative tab and a Cosmetics page in the tailor's catalogue.
- Fixed invisible bodies after a race change.

## 4.8.0 (2026-11-11)

- Combat: dash, sonic crash through terrain, melee clashes with a rhythm panel, and NPC lunges.
- Lightning bolts around players.
- New crosshair and quest tracker; party, fusion, world boss and tournament HUDs redrawn.
- Used Dragon Ball sets sleep as stone for a Minecraft week.
- Beams in space, planet clashes with beams, and planet names on look.
- Searchable entity and model lists in the tournament and dungeon editors.
- HARD saga difficulty unlocks at prestige 1; buying a stat at its cap is refused.

## 4.7.0 (2026-11-10)

- Dragon Balls: clear faceted balls with camera-facing stars, and dormant stone balls after a wish.
- Space: Saiyan settlements on Vegeta, asteroid fields, planet destruction with the clash meter, traders and salvage.
- Tournament fighter characters and raid Z-Souls.
- Auras at their proper size, scaling with the player's model.
- Disguised dungeon spawners stay spawners.
- Searchable dropdowns and panel art in the raid, dungeon, tournament, saga, form, creator and config screens.

## 4.6.1 (2026-11-10)

- Dungeon room credits corrected.

## 4.6.0 (2026-11-10)

- A generated universe: star systems with landable planets, lone stars, black holes, animated suns, clouds, moons and rings, and Planet Vegeta.
- Planet garrisons, pod trails, the star map on M in space and a space radar under the minimap.
- Super, Black Star and Cerulean Dragon Balls.
- Dungeons: themed floors, three layout styles, boss floors, a gate and portals, crates, spawners, guardians, tickets and editor screens.
- Raids: standard, wave and boss rush raids, rifts, sign-ups, schedules, raid souls and an editor.
- Tournaments: 1v1 to 3v3 brackets and free-for-all, sign-ups, schedules, titles, rewards and an editor.

## 4.5.0 (2026-11-10)

- Space travel: a space dimension, orbits, landing, a star map with autopilot and a radar.
- See-through Dragon Balls with a glowing rim.

## 4.4.0 (2026-11-10)

- Saga and form editors, 3D auras, a new HUD and new NPCs.
- Instant-use capsules and Dragon Balls on the sea bed.
- The Other World rebuilds missing structures and holds spirits until Yemma's palace is ready.

## 4.3.0 (2026-11-10)

- Ki craters that heal, an options screen and training minigames.

## 4.2.2 (2026-11-10)

- The 3D Dragon Ball models are back; the space pod lands on the destination's surface.

## 4.2.1 (2026-11-10)

- Quest rewards give the right items; settings can be changed in game.

## 4.2.0 (2026-11-10)

- 28 hair presets with Super Saiyan shapes in the creator, and Popo's haircut.
- Flight modes, dash, perfect evasion, lock-on, ki sense, the scouter, Instant Transmission and Ki Surge.
- Potara and dance fusion.
- Saga enemy AI, 7 world bosses with lairs and rewards, and parties.
- Machines: stations, a fuel generator, energy cables, the gravity device and gravity training.
- Sacred Kai Planet and Demon Realm dimensions.

## 4.1.0 (2026-11-10)

- Techniques: a pop-up when learned, Bind to Slot with 8 slots, a slot hotbar and a charge bar.
- The radial utility menu (X), transformations (hold G) and masters with dialogue and skill shops.
- The Saiyan tail can wrap round the waist.

## 4.0.0 (2026-11-10)

- Vehicles and the space pod, the Other World and King Yemma, structures and world events.

## 3.2.0 (2026-11-10)

- Fist combo, guard, parry, poise and stun.

## 3.1.0 (2026-11-09)

- Player animations for walking, flying, charging, blocking, techniques and transformations, the same for everyone.

## 3.0.0 (2026-11-09)

- New character creator, HUD, stats screen, classes and formulas.

## 2.1.2 (2026-11-09)

- First release as a separate download, installed from the online addon list.
