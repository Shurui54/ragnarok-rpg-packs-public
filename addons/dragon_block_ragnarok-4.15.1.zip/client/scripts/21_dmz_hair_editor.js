// =====================================================================================
//  21_dmz_hair_editor.js - the original's hair editor (client/gui/hair/*)
// =====================================================================================
//  Port of the original 2.2's HairEditorScreen, HairOutlinerPanel, HairInspectorPanel / HairInspectorRows,
//  HairEditorState, HairEditHistory, HairViewportTool, HairEditorUi / HairEditorTextures / HairEditorSounds
//  (GPL-3.0, see NOTICE.md): the same layout (outliner left, viewport in the middle, inspector right, top bar),
//  the same controls, limits, sounds, texts (the original's lang keys) and its GUI art (menubig, characterbuttons).
//    outliner    style tabs B S1 S2 S3 S4, face tabs F B L R T, the strand grid, Hide/Lock, the segment list,
//                and the code buttons: Style / Full x Import (paste) / Export (copy) - the original's hair codes
//    inspector   no strand: Preset, Hair color, style info, Copy from, Clear style, Generate from Base, help;
//                a strand: Copy/Paste/To all/Clear, Transform, Shape, Curve, Color; a segment: its overrides
//    viewport    drag: orbit, right drag: pan, wheel: zoom, click: select (Alt: segment), Shift/Alt/Ctrl+drag:
//                grow / rotate / curve, right click: +segment (Shift: -segment), right click empty: show/hide body
//    top bar     Cancel, Undo, Redo, Mirror, Physics, Hairbase; Save and Hair Salon under the viewport
//  Opened from the creator's hair tab ("Edit"), Mr. Popo ("Haircut"), the Dragon Block menu and /hairedit.
//  Saving sends the five styles as one full-set code to scripts/21_dmz_hair.js (or back to the creator).
// =====================================================================================
var DMZ_HAIR_EDITOR = (function () {
    var H = DMZ_HAIR, F = Math.fround, ID = "dmz_hair_editor";
    var FONT = "dmzpack:smooth";
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png", MENU_SMALL = "dmzpack:textures/gui/menu/menusmall.png";
    var BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var PANORAMA = "dmzpack:textures/gui/background/roshi", HAIR_SALON_URL = "https://dragonminez.com/hairsalon";
    // HairEditorUi colours
    var C = { TITLE: "#FFD700", TEXT: "#FFFFFF", HOVER_TEXT: "#7CFDD6", MUTED: "#B9D6B4", DISABLED: "#6E7F6E", WARNING: "#FF5555",
              SUCCESS: "#55FF55", DIVIDER: "#8D9BC6", AXIS_X: "#E05252", AXIS_Y: "#52C45A", AXIS_Z: "#5272E0", SECTION: "#FFC04D" };
    // HairEditorScreen
    var MARGIN = 8, GAP = 6, TOP_BAR_HEIGHT = 16, PANEL_TOP = 28, CLICK_DRAG_THRESHOLD = 3;
    var MIN_ZOOM = 95, MAX_ZOOM = 260, ZOOM_STEP = 20, ORBIT_SPEED = 1, STATUS_MS = 3000;
    // HairOutlinerPanel
    var O_HEADER = 27, O_INSET = 9, TAB_HEIGHT = 14, TAB_GAP = 2, CELL = 20, CELL_GAP = 3, O_ROW = 12, BUTTON_HEIGHT = 14;
    var CODE_HEADER = 11, CODE_BUTTON = 20, CODE_AREA = CODE_HEADER + 2 * CODE_BUTTON + TAB_GAP;
    // HairInspectorPanel / Rows
    var I_HEADER = 27, I_INSET = 8, SCROLL_STEP = 14, SCROLLBAR = 4, ROW_H = 13, SECTION_H = 15, LABEL_W = 62, VALUE_W = 38, SCRUB_PIXELS = 240;
    var OFFSET_STEP = 0.05, ANGLE_STEP = 1, MAX_BEND = 720, MAX_TWIST = 360, MAX_SEGMENT_SCALE = 4;
    // HairViewportTool
    var CURVE_DEGREES_PER_PIXEL = 1.5, MIN_SCREEN_LENGTH = 2;
    var HISTORY_MAX = 64;
    var SLOTS = H.SLOTS, FACES = H.FACES, L = H.LIMITS;

    // ---- the original's PanelSkin pieces (HairEditorTextures) ----------------------------------------------------
    function sg(kind, length, period, priority) { return { kind: kind, length: length, period: period, priority: priority || 0 }; }
    function fixed(n) { return sg("fixed", n, 1); }
    function tile(n) { return sg("tile", n, 7); }
    function stretch(n) { return sg("tile", n, 1); }
    function decor(n, p) { return sg("decor", n, 1, p); }
    function band(n) { return sg("band", n, 7); }
    function shrink(n) { return sg("band", n, 1); }
    var SKIN = null;
    function skins() {
        if (SKIN) return SKIN;
        var S = DMZ_UI.Skin;
        function button(v) { return S(BUTTONS, 256, 256, 0, v, [fixed(4), shrink(9), stretch(49), shrink(9), fixed(3)], [fixed(4), stretch(10), shrink(2), fixed(4)]); }
        function wide(v) { return S(BUTTONS, 256, 256, 0, v, [fixed(3), shrink(9), stretch(124), shrink(11), fixed(3)], [fixed(3), stretch(13), fixed(4)]); }
        function field(v) { return S(BUTTONS, 256, 256, 0, v, [fixed(3), stretch(101), fixed(3)], [fixed(3), stretch(11), fixed(4)]); }
        SKIN = {
            PANEL: S(MENU_BIG, 256, 256, 0, 0, [fixed(14), tile(63), decor(28, 0), tile(21), fixed(15)],
                [fixed(14), band(21), fixed(7), decor(28, 2), tile(28), decor(21, 1), tile(77), fixed(17)]),
            SMALL: S(MENU_SMALL, 256, 256, 0, 0, [fixed(14), tile(63), decor(28, 0), tile(21), fixed(15)],
                [fixed(14), band(21), fixed(7), decor(28, 0), tile(7), fixed(17)]),
            BUTTON: button(28), BUTTON_HOVER: button(48), BUTTON_ACTIVE: wide(68), BUTTON_ACCENT: wide(88), FIELD: field(108), FIELD_EDITING: field(126)
        };
        return SKIN;
    }

    // ---- small helpers ------------------------------------------------------------------------------------------
    function T(key) { return DMZ_UI.tr.apply(null, ["gui.dragonminez.hair_editor." + key].concat(Array.prototype.slice.call(arguments, 1))); }
    function inside(mx, my, x, y, w, h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    function txt(ctx, s, x, y, color, align) { ctx.textStyled(String(s), x, y, 1, color, 1, align || 0, FONT, "#000000"); }
    function tw(ctx, s) { return ctx.textWidthIn(String(s), FONT); }
    function trim(ctx, s, w) {
        s = String(s);
        if (tw(ctx, s) <= w) return s;
        while (s.length && tw(ctx, s + "..") > w) s = s.substring(0, s.length - 1);
        return s + "..";
    }
    function sound(id, pitch) { try { RPG.sound(id, 1, pitch || 1); } catch (e) { } }
    // HairEditorSounds
    var lastLimit = 0;
    var SND = {
        click: function () { sound("dmzpack:pip_menu", 1); },
        toggle: function (on) { sound(on ? "dmzpack:switch_on" : "dmzpack:switch_off", 1); },
        select: function () { sound("dmzpack:ui_menu_switch", 1); },
        deselect: function () { sound("dmzpack:ui_menu_switch", 0.8); },
        limit: function () { var n = RPG.nowMs(); if (n - lastLimit < 120) return; lastLimit = n; sound("dmzpack:ui_nave_cooldown", 1); }
    };
    function keyDown(k) { return RPG.isKeyDown("key.keyboard.left." + k) || RPG.isKeyDown("key.keyboard.right." + k); }
    function shift() { return keyDown("shift"); }
    function ctrl() { return keyDown("control"); }
    function alt() { return keyDown("alt"); }
    function round2(v) { return Math.round(v * 100) / 100; }
    function fmt(v, step, integer) {
        if (integer) return String(Math.round(v));
        if (step >= 1) return String(Math.round(v));
        if (step >= 0.1) return (Math.round(v * 10) / 10).toFixed(1);
        return (Math.round(v * 100) / 100).toFixed(2);
    }
    function parseHex(h) { var c = H.normColor(h); return c ? parseInt(c.substring(1), 16) : -1; }
    function hex(n) { var s = (n & 0xFFFFFF).toString(16).toUpperCase(); while (s.length < 6) s = "0" + s; return "#" + s; }
    function lighten(h, k) {
        var n = parseHex(h); if (n < 0) n = 0xFFFFFF;
        var r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
        return hex((Math.round(r + (255 - r) * k) << 16) | (Math.round(g + (255 - g) * k) << 8) | Math.round(b + (255 - b) * k));
    }
    function clone(o) { return JSON.parse(JSON.stringify(o)); }
    // generating, importing and saving can take longer than one call may (50 ms): they run on the next tick with more time
    function heavy(fn) { if (RPG.runLong) RPG.runLong(function () { if (S) fn(); }, 1000); else fn(); }
    function visible(s) { return !!s && s.sg > 0 && s.ln > 0; }

    // =====================================================================================
    //  State (HairEditorState)
    // =====================================================================================
    var S = null;

    function strandAt(style, fi, i) {
        var list = style.faces[FACES[fi].key] || (style.faces[FACES[fi].key] = []);
        if (!list[i]) list[i] = H.defaultStrand(fi, i);
        return list[i];
    }
    function style() { return S.styles[S.slot]; }
    function selected() { return S.sel ? strandAt(style(), S.sel.fi, S.sel.i) : null; }
    function flat(fi, i) { return fi * 100 + i; }
    function colorless(st) { var o = clone(st); delete o.gc; delete o.name; return normalize(o); }
    // a comparable text of a style (only visible strands, like CustomHair.save)
    function normalize(st) {
        var out = {};
        FACES.forEach(function (f) { out[f.key] = (st.faces[f.key] || []).map(function (s) { return visible(s) ? s : null; }); });
        return JSON.stringify(out);
    }
    function record() {
        S.undo.push(clone(S.styles));
        while (S.undo.length > HISTORY_MAX) S.undo.shift();
        S.redo = [];
    }
    function beginGesture() { if (S.gesture) return; record(); S.gesture = true; }
    function endGesture() { S.gesture = false; }
    function undo() { if (!S.undo.length) return false; S.redo.push(clone(S.styles)); S.styles = S.undo.pop(); clampSeg(); changed(); return true; }
    function redo() { if (!S.redo.length) return false; S.undo.push(clone(S.styles)); S.styles = S.redo.pop(); clampSeg(); changed(); return true; }
    function clampSeg() {
        var s = selected();
        if (!s || !visible(s)) { if (S.sel) S.sel.seg = -1; return; }
        if (S.sel.seg >= s.sg) S.sel.seg = s.sg - 1;
    }
    function changed() { S.rev++; S.slotRev[S.slot] = (S.slotRev[S.slot] || 0) + 1; S.dirtyKey = null; S.rebuild = true; }
    function modifySelected(fn) {
        var s = selected();
        if (!s) return;
        fn(s);
        propagateMirror();
        clampSeg();
        changed();
    }
    function propagateMirror() {
        if (!S.mirror || !S.sel) return;
        var fi = S.sel.fi, i = S.sel.i, mf = H.mirrorFace(fi), mi = H.mirrorIndex(fi, i);
        if (mf === fi && mi === i) return;
        var src = selected(), copy = clone(src);
        copy.i = flat(mf, mi);
        H.mirrorStrand(copy);
        style().faces[FACES[mf].key][mi] = copy;
    }
    // HairEditorState.isDirty: compared slot by slot, each only again after it changed (a style is a big text to build)
    function isDirty() {
        if (S.forceDirty || S.hairBase !== S.initialHairBase || S.styles.base.gc !== S.initialColor) return true;
        if (S.dirtyKey === S.rev) return S.dirtyCache;
        S.dirtyKey = S.rev;
        S.dirtyCache = SLOTS.some(function (slot) {
            var c = S.slotCache[slot];
            if (!c || c.obj !== S.styles[slot] || c.rev !== S.slotRev[slot]) c = S.slotCache[slot] = { obj: S.styles[slot], rev: S.slotRev[slot], dirty: colorless(S.styles[slot]) !== S.initial[slot] };
            return c.dirty;
        });
        return S.dirtyCache;
    }
    function setGlobalColor(h) {
        var c = H.normColor(h) || S.initialColor;
        SLOTS.forEach(function (slot) { S.styles[slot].gc = c; });
        changed();
    }
    function keepJoints(target, previous) {
        FACES.forEach(function (f) {
            (target.faces[f.key] || []).forEach(function (s, i) {
                var b = previous.faces[f.key] && previous.faces[f.key][i];
                if (visible(s) && visible(b) && b.js) s.js = b.js;
            });
        });
    }
    function applyPreset(id) {
        if (!H.exists(id)) return false;
        record();
        var color = S.styles.base.gc;
        SLOTS.forEach(function (slot) {
            var src = H.preset(id, slot), prev = S.styles[slot];
            var next = src ? clone(src) : H.emptyHair();
            keepJoints(next, prev);
            next.gc = color;
            S.styles[slot] = next;
        });
        S.presetId = id;
        clampSeg(); changed();
        return true;
    }
    function generate(target) {
        var base = S.styles.base;
        if (H.isEmpty(base) || target === "base" || typeof DMZ_HAIR_GEN === "undefined") return false;
        record();
        var color = base.gc, out = target ? {} : DMZ_HAIR_GEN.generateAll(base, L);
        if (target) out[target] = DMZ_HAIR_GEN.generate(base, target, L);
        Object.keys(out).forEach(function (slot) {
            var prev = S.styles[slot], next = out[slot];
            keepJoints(next, prev);
            next.gc = color;
            S.styles[slot] = next;
        });
        setSlot(target || "ssj");
        clampSeg(); changed();
        return true;
    }
    function setSlot(slot) { if (slot === S.slot) return; S.slot = slot; clampSeg(); changed(); }
    function select(fi, i) { S.sel = { fi: fi, i: i, seg: -1 }; S.face = fi; changed(); }
    function clearSelection() { S.sel = null; changed(); }

    // =====================================================================================
    //  Open / save / close
    // =====================================================================================
    // opts: {creator: {styles, color, hairBase, presetId, onSave(result)}} or nothing (the player's own hair)
    // the editor saves and shares hair codes: engine 0.28.1+ (RPG.codec.deflateBytes, RPG.clipboard)
    function supported() { return H.canEncode() && !!RPG.clipboard; }
    function open(opts) {
        opts = opts || {};
        if (!supported()) { RPG.chat("&e[Hair]&7 The hair editor needs Ragnarok Modding Toolkit 0.28.1 or newer; the hair presets still work."); return; }
        if (RPG.runLong && !opts.now) { opts.now = true; RPG.runLong(function () { open(opts); }, 1000); return; }
        var styles = {}, presetId = 0, color = "#000000", hairBase = true, cr = opts.creator;
        if (cr) {
            presetId = cr.presetId | 0;
            color = H.normColor(cr.color) || "#000000";
            hairBase = cr.hairBase !== false;
            SLOTS.forEach(function (slot) { styles[slot] = cr.styles && cr.styles[slot] ? clone(cr.styles[slot]) : null; });
        } else {
            var hs = String(RPG.player.color("hairStyle", "") || ""), race = RPG.player.race;
            color = H.normColor(RPG.player.color("hair", "")) || "#000000";
            hairBase = Number(RPG.getVar ? RPG.getVar("dmz_hair_base", 1) : 1) !== 0;       // the original's RenderHairBase
            var m = /^c([0-9a-f]{8})$/.exec(hs), set = m ? H.customSet(m[1]) : null;
            if (!set && RPG.getVar) { var code = RPG.getVar("dmz_hair_custom", ""); if (code) set = H.decodeFullSet(code, true); }
            presetId = m ? 0 : H.presetOf(hs, race);
            SLOTS.forEach(function (slot) {
                var src = presetId > 0 ? H.preset(presetId, slot) : set ? set[slot] : null;
                styles[slot] = src ? clone(src) : null;
            });
        }
        SLOTS.forEach(function (slot) {
            if (!styles[slot]) styles[slot] = H.emptyHair();
            styles[slot].gc = color;
            if (styles[slot].name === undefined || styles[slot].name === "") styles[slot].name = "Custom";
        });
        S = {
            styles: styles, slot: "base", face: 0, sel: null, hover: null, mirror: false, physics: true, hairBase: hairBase,
            initialHairBase: hairBase, initialColor: color, presetId: presetId, forceDirty: presetId > 0, bodyHidden: false,
            hidden: {}, locked: {}, undo: [], redo: [], gesture: false, clipboard: null, initial: {}, rev: 1, dirtyKey: null, dirtyCache: false,
            yaw: 180, pitch: 0, zoom: 150, targetZoom: 150, panX: 0, panY: 0, rows: [], rebuild: true, scroll: 0, segScroll: 0,
            editing: null, editText: "", dragRow: null, press: null, tool: null, status: null, confirm: false, closing: false,
            copySource: "ssj", genTarget: null, opts: opts, previewId: null, layoutKey: "", race: (cr && cr.race) || RPG.player.race || "human",
            looks: (cr && cr.looks) || null, slotRev: {}, slotCache: {}
        };
        SLOTS.forEach(function (slot) { S.initial[slot] = colorless(styles[slot]); });
        RPG.screen.open({
            id: ID, title: T("title"), referenceHeight: typeof DMZ_OPTS !== "undefined" && DMZ_OPTS.menuRef ? DMZ_OPTS.menuRef() : 270, pause: false, closeOnEsc: false, background: { panorama: PANORAMA },
            elements: [{ id: "pv", type: "entity", anchor: "topleft", x: 0, y: 0, w: 1, h: 1, rotation: 180, followMouse: false, size: 150, clip: true }],
            onBackground: background, onRender: render, onMouse: mouse, onScroll: scroll, onKey: key,
            onClose: function () { dropPreview(); S = null; }
        });
        changed();
    }

    function save() {
        commitText();
        var payload = { code: H.toFullSetCode(S.styles, true), hairBase: S.hairBase, color: S.styles.base.gc };
        if (S.opts.creator && S.opts.creator.onSave) {
            var cr = S.opts.creator, styles = clone(S.styles);
            close();
            cr.onSave({ code: payload.code, styles: styles, hairBase: payload.hairBase, color: payload.color });
            return;
        }
        sendCode(payload.code, payload.hairBase, payload.color, false);
        close();
    }
    // the code in pieces (a message to the server holds 30 KB at most)
    function sendCode(code, hairBase, color, creator) {
        var id = String(RPG.nowMs()), n = Math.max(1, Math.ceil(code.length / 24000));
        for (var p = 0; p < n; p++) {
            var m = { id: id, part: p, total: n, data: code.substring(p * 24000, (p + 1) * 24000) };
            if (p === n - 1) { m.hairBase = hairBase; m.color = color; if (creator) m.creator = true; }
            RPG.net.send("dmz_hair_save", m);
        }
    }
    function close() {
        if (!S || S.closing) return;
        S.closing = true;
        var back = S.opts.onClosed;
        RPG.screen.close();
        if (back) back();
    }
    function requestClose() {
        if (S.tool) cancelTool();
        if (isDirty()) { S.confirm = true; return; }
        close();
    }
    function status(text, color) { S.status = { text: text, color: color, until: RPG.nowMs() + STATUS_MS }; }

    // =====================================================================================
    //  Preview: the player wearing the style being edited (a client-side look: hairStyle "e<n>")
    // =====================================================================================
    var previewSeq = 0;
    function previewStrands() {
        var st = clone(style()), sel = S.sel, hov = S.hover;
        FACES.forEach(function (f, fi) {
            var list = st.faces[f.key] || [];
            for (var i = 0; i < list.length; i++) {
                var s = list[i];
                if (!visible(s)) continue;
                if (S.hidden[flat(fi, i)]) { list[i] = null; continue; }
                var k = 0;
                if (sel && sel.fi === fi && sel.i === i) k = sel.seg < 0 ? 0.55 : -1;
                else if (hov && hov.fi === fi && hov.i === i) k = 0.12;
                if (k > 0) { s.c = lighten(s.c || st.gc, k); if (s.tc) s.tc = lighten(s.tc, k); s.so.forEach(function (o) { if (o.c) o.c = lighten(o.c, k); }); }
                else if (k < 0) {                                  // a segment selected: it lights up, the rest of the strand a little
                    for (var g = 0; g < s.sg; g++) {
                        var o = H.getOrCreateOverride(s, g), base = o.c || s.c || st.gc;
                        o.c = lighten(base, g === sel.seg ? 0.55 : 0.2);
                    }
                }
            }
        });
        return H.toStrands(st, true);
    }
    function refreshPreview() {
        var id = "dmzhe" + (++previewSeq) + "_base", old = S.previewId;
        RPG.avatar.defineHair(id, previewStrands());
        S.previewId = id;
        if (old) RPG.avatar.defineHair(old, null);
        S.previewRev = S.rev;
        S.previewHover = S.hover ? S.hover.fi + ":" + S.hover.i : "";
    }
    function dropPreview() { if (S && S.previewId) { RPG.avatar.defineHair(S.previewId, null); S.previewId = null; } }
    function previewLook() {
        var colors = { hairStyle: S.previewId ? S.previewId.substring(4, S.previewId.length - 5) : "0", hair: S.styles.base.gc,
            dmzHairCap: S.hairBase && H.visibleCount(S.styles.base) > 0 ? "1" : "0" };
        if (S.looks) { var all = {}; Object.keys(S.looks).forEach(function (k) { all[k] = S.looks[k]; }); Object.keys(colors).forEach(function (k) { all[k] = colors[k]; }); colors = all; }
        return { key: "race:" + S.race, colors: colors };
    }

    // =====================================================================================
    //  Layout and drawing
    // =====================================================================================
    var LY = {};
    function layout(w, h) {
        var available = w - MARGIN * 2 - GAP * 2;
        var ow = Math.max(120, Math.min(150, Math.round(available * 0.26))), iw = Math.max(140, Math.min(190, Math.round(available * 0.32)));
        var ph = h - PANEL_TOP - MARGIN;
        LY = { w: w, h: h, ox: MARGIN, oy: PANEL_TOP, ow: ow, oh: ph, ix: w - MARGIN - iw, iy: PANEL_TOP, iw: iw, ih: ph };
        LY.vx0 = LY.ox + ow + GAP; LY.vx1 = LY.ix - GAP; LY.vy0 = PANEL_TOP; LY.vy1 = h - MARGIN;
    }
    function panel(ctx, x, y, w, h) { skins().PANEL.draw(ctx, x, y, w, h); }
    function header(ctx, title, x, y, w) {
        var plate = w - 14 >= 107 ? [142, 22, 107, 21] : [142, 0, 79, 21];
        ctx.image(MENU_BIG, x + Math.floor((w - plate[2]) / 2), y + 6, plate[2], plate[3], plate[0], plate[1], plate[2], plate[3], 256, 256);
        txt(ctx, title, x + w / 2, y + 13, C.TITLE, 0.5);
    }
    function button(ctx, label, x, y, w, h, hovered, active, enabled) {
        var k = skins(), sk = active ? k.BUTTON_ACTIVE : hovered && enabled ? k.BUTTON_HOVER : k.BUTTON;
        sk.draw(ctx, x, y, w, h, 1);
        if (!enabled) ctx.fill(x, y, w, h, "#000000", 0.4);
        var color = !enabled ? C.DISABLED : hovered && !active ? C.HOVER_TEXT : C.TEXT;
        txt(ctx, label, x + w / 2, y + Math.floor((h - 8) / 2) + 1, color, 0.5);
    }
    function divider(ctx, x0, x1, y) { if (x1 > x0) ctx.rect(x0, y, x1 - x0, 1, C.DIVIDER); }
    function outline(ctx, x, y, w, h, color) { ctx.rect(x, y, w, 1, color); ctx.rect(x, y + h - 1, w, 1, color); ctx.rect(x, y, 1, h, color); ctx.rect(x + w - 1, y, 1, h, color); }

    function background(ctx) {
        // HairEditorScreen.renderCinematicBars (in GUI pixels: 12% of the height, 60 px gradients)
        var h = ctx.height, w = ctx.width, bar = h * 0.12, g = Math.min(60 * 270 / Math.max(1, RPG.screenHeight || 270), bar);
        if (bar - g > 0) ctx.rect(0, 0, w, bar - g, "#FF000000");
        ctx.gradient(0, bar - g, w, g, "#FF000000", "#00000000");
        ctx.gradient(0, h - bar, w, g, "#00000000", "#FF000000");
        if (bar - g > 0) ctx.rect(0, h - bar + g, w, bar - g, "#FF000000");
    }

    function render(ctx) {
        if (!S) return;
        layout(ctx.width, ctx.height);
        var mx = ctx.mouseX, my = ctx.mouseY;
        S.zoom = S.zoom + (S.targetZoom - S.zoom) * 0.3;
        if (S.rebuild) rebuildRows();
        updateHover(mx, my);
        if (S.previewRev !== S.rev || S.previewHover !== (S.hover ? S.hover.fi + ":" + S.hover.i : "")) refreshPreview();
        placePreview();
        if (DEBUG_PICK) debugPick(ctx);
        renderOutliner(ctx, mx, my);
        renderInspector(ctx, mx, my);
        renderTopBar(ctx, mx, my);
        renderViewportOverlay(ctx, mx, my);
        renderBottomButtons(ctx, mx, my);
        if (S.confirm) renderConfirm(ctx, mx, my);
        else renderCodeTooltip(ctx, mx, my);
    }

    var DEBUG_PICK = false;
    function debugPick(ctx) {
        var st = style();
        FACES.forEach(function (f, fi) {
            for (var i = 0; i < f.max; i++) {
                var pts = strandPoints(st, fi, i);
                if (!pts) continue;
                for (var k = 0; k < pts.length; k++) { var q = project(pts[k]); ctx.rect(q[0] - 1, q[1] - 1, 2, 2, k === 0 ? "#FF00FF00" : "#FFFF0000"); }
            }
        });
    }
    function viewBase() {
        var cx = (LY.vx0 + LY.vx1) / 2 + S.panX;
        var by = LY.h / 2 + 112 + (S.zoom - MIN_ZOOM) * 2.436 + S.panY;
        return { cx: cx, by: by };
    }
    function placePreview() {
        var b = viewBase(), size = Math.round(S.zoom);
        var key = [LY.vx0, LY.vy0, LY.vx1, LY.vy1, Math.round(b.cx), Math.round(b.by), size, S.yaw, S.pitch, S.previewId, S.hairBase, S.styles.base.gc, S.bodyHidden].join(",");
        if (key === S.layoutKey) return;
        S.layoutKey = key;
        RPG.screen.update("pv", { x: LY.vx0, y: LY.vy0, w: LY.vx1 - LY.vx0, h: LY.vy1 - LY.vy0, modelX: b.cx - LY.vx0, modelY: b.by - LY.vy0,
            size: size, rotation: S.yaw, tilt: S.pitch, look: previewLook(), visible: true });
    }

    // ---- projection of hair points into the viewport (for picking and the drag tools) -----------------------------
    // The preview draws the player like the inventory does: feet at (cx, by), size pixels a block, turned to `yaw`
    // (180 faces you) and tilted by `pitch`. Hair positions are head pixels from the head pivot (24 px up, model scale).
    var MODEL_SCALE = 0.9375, HEAD_PIVOT = 24;
    function project(p) {
        var b = viewBase(), s = S.zoom, k = MODEL_SCALE / 16;
        var x = p[0] * k, y = (HEAD_PIVOT + p[1]) * k, z = p[2] * k;
        var a = (S.yaw - 180) * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a);
        var vx = -(x * ca - z * sa), vz = -(x * sa + z * ca), vy = y;          // yaw 180: the model's front faces you
        var t = S.pitch * Math.PI / 180, ct = Math.cos(t), st = Math.sin(t);
        var y2 = vy * ct - vz * st, z2 = vy * st + vz * ct;
        return [b.cx + vx * s, b.by - y2 * s, z2];
    }
    function strandPoints(st, fi, i) {
        var s = st.faces[FACES[fi].key][i];
        if (!visible(s)) return null;
        var p = H._pose(s, fi, i), pts = [];
        for (var k = 0; k < p.seg; k++) pts.push(p.restStart[k]);
        pts.push(p.tip);
        return pts;
    }
    function pick(mx, my, allowLocked) {
        if (!inside(mx, my, LY.vx0, LY.vy0, LY.vx1 - LY.vx0, LY.vy1 - LY.vy0)) return null;
        var st = style(), best = null, bestD = 6;
        FACES.forEach(function (f, fi) {
            for (var i = 0; i < f.max; i++) {
                if (S.hidden[flat(fi, i)] || (!allowLocked && S.locked[flat(fi, i)])) continue;
                var pts = strandPoints(st, fi, i);
                if (!pts) continue;
                var w = Math.max(2, st.faces[f.key][i].w) * MODEL_SCALE / 16 * S.zoom / 2;
                for (var k = 0; k + 1 < pts.length; k++) {
                    var a = project(pts[k]), b = project(pts[k + 1]);
                    var d = segDist(mx, my, a[0], a[1], b[0], b[1]) - w;
                    var depth = (a[2] + b[2]) / 2;
                    if (d < bestD || (best && Math.abs(d - bestD) < 0.5 && depth > best.depth)) { bestD = Math.max(d, 0); best = { fi: fi, i: i, seg: k, depth: depth }; }
                }
            }
        });
        return best;
    }
    function segDist(px, py, ax, ay, bx, by) {
        var dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy, t = l > 0 ? ((px - ax) * dx + (py - ay) * dy) / l : 0;
        t = Math.max(0, Math.min(1, t));
        var x = ax + t * dx - px, y = ay + t * dy - py;
        return Math.sqrt(x * x + y * y);
    }
    function updateHover(mx, my) {
        if (S.tool || S.confirm || S.press) return;
        var hit = pick(mx, my, false);
        var cur = S.hover ? S.hover.fi + ":" + S.hover.i : "", next = hit ? hit.fi + ":" + hit.i : "";
        if (cur !== next) S.hover = hit ? { fi: hit.fi, i: hit.i } : null;
    }

    // ---- outliner ----
    function tabWidth(count) { return Math.floor((LY.ow - O_INSET * 2 - TAB_GAP * (count - 1)) / count); }
    function gridX(fi) { var f = FACES[fi], gw = f.cols * CELL + (f.cols - 1) * CELL_GAP; return LY.ox + Math.floor((LY.ow - gw) / 2); }
    function gridHeight(fi) { var f = FACES[fi]; return f.rows * CELL + (f.rows - 1) * CELL_GAP; }
    function codeTop() { return LY.oy + LY.oh - CODE_AREA - O_INSET; }
    function codeColumnWidth() { return Math.floor((LY.ow - O_INSET * 2 - TAB_GAP) / 2); }
    var CODE_ACTIONS = [{ id: "paste_style", col: 0, exp: false }, { id: "copy_style", col: 0, exp: true }, { id: "paste_full", col: 1, exp: false }, { id: "copy_full", col: 1, exp: true }];
    function codeButton(a) {
        var cw = codeColumnWidth();
        return { x: LY.ox + O_INSET + a.col * (cw + TAB_GAP) + Math.floor((cw - CODE_BUTTON) / 2), y: codeTop() + CODE_HEADER + (a.exp ? CODE_BUTTON + TAB_GAP : 0) };
    }
    function codeActionAt(mx, my) {
        for (var i = 0; i < CODE_ACTIONS.length; i++) { var b = codeButton(CODE_ACTIONS[i]); if (inside(mx, my, b.x, b.y, CODE_BUTTON, CODE_BUTTON)) return CODE_ACTIONS[i]; }
        return null;
    }
    function renderOutliner(ctx, mx, my) {
        var x = LY.ox, y = LY.oy, w = LY.ow, k = skins();
        panel(ctx, x, y, w, LY.oh);
        header(ctx, T("outliner"), x, y, w);
        var cur = y + O_HEADER + 2, tw5 = tabWidth(5);
        SLOTS.forEach(function (slot, i) {
            var tx = x + O_INSET + i * (tw5 + TAB_GAP);
            button(ctx, T("style.short." + i), tx, cur, tw5, TAB_HEIGHT, inside(mx, my, tx, cur, tw5, TAB_HEIGHT), S.slot === slot, true);
            if (!H.isEmpty(S.styles[slot])) ctx.rect(tx + tw5 - 4, cur + 2, 2, 2, C.TITLE);
        });
        cur += TAB_HEIGHT + 3;
        FACES.forEach(function (f, i) {
            var tx = x + O_INSET + i * (tw5 + TAB_GAP);
            button(ctx, T("face." + f.name.toLowerCase()), tx, cur, tw5, TAB_HEIGHT, inside(mx, my, tx, cur, tw5, TAB_HEIGHT), S.face === i, true);
        });
        cur += TAB_HEIGHT + 4;
        // the strand grid
        var fi = S.face, f = FACES[fi], gx = gridX(fi), st = style();
        for (var i = 0; i < f.max; i++) {
            var cx = gx + (i % f.cols) * (CELL + CELL_GAP), cy = cur + Math.floor(i / f.cols) * (CELL + CELL_GAP);
            var s = (st.faces[f.key] || [])[i], vis = visible(s), sel = S.sel && S.sel.fi === fi && S.sel.i === i;
            var hov = inside(mx, my, cx, cy, CELL, CELL), hid = !!S.hidden[flat(fi, i)];
            var sk = sel ? k.BUTTON_ACTIVE : hov ? k.BUTTON_HOVER : vis ? k.BUTTON_ACCENT : k.BUTTON;
            sk.draw(ctx, cx, cy, CELL, CELL, 1);
            if (hid) ctx.fill(cx, cy, CELL, CELL, "#000000", 0.45);
            var n = String(i + 1);
            txt(ctx, n, cx + Math.floor((CELL - tw(ctx, n)) / 2) + 1, cy + Math.floor((CELL - 8) / 2) + 1, hid ? C.DISABLED : vis || sel ? C.TEXT : C.MUTED);
            if (hid) ctx.rect(cx + 3, cy + CELL / 2, CELL - 6, 1, C.WARNING);
            if (S.locked[flat(fi, i)]) ctx.rect(cx + CELL - 5, cy + 2, 3, 3, C.SECTION);
        }
        cur += gridHeight(fi) + 4;
        // Hide / Lock
        var bw = Math.floor((w - O_INSET * 2 - TAB_GAP) / 2);
        if (!S.sel) { txt(ctx, T("no_selection"), x + O_INSET, cur + 3, C.MUTED); cur += BUTTON_HEIGHT; }
        else {
            var hidden = !!S.hidden[flat(S.sel.fi, S.sel.i)], locked = !!S.locked[flat(S.sel.fi, S.sel.i)];
            button(ctx, T(hidden ? "show" : "hide"), x + O_INSET, cur, bw, BUTTON_HEIGHT, inside(mx, my, x + O_INSET, cur, bw, BUTTON_HEIGHT), hidden, true);
            var lx = x + O_INSET + bw + TAB_GAP;
            button(ctx, T(locked ? "unlock" : "lock"), lx, cur, bw, BUTTON_HEIGHT, inside(mx, my, lx, cur, bw, BUTTON_HEIGHT), locked, true);
            cur += BUTTON_HEIGHT;
        }
        // the segment list
        S.segListTop = cur + 3;
        var sel = selected(), bottom = codeTop() - 3;
        if (sel && visible(sel) && bottom - S.segListTop >= O_ROW) {
            var rows = sel.sg + 1, top = S.segListTop, viewH = bottom - top, content = rows * O_ROW;
            S.segScroll = Math.max(0, Math.min(S.segScroll, Math.max(0, content - viewH)));
            var rw = w - O_INSET * 2 - (content > viewH ? SCROLLBAR + 2 : 0);
            ctx.clip(x + O_INSET, top, w - O_INSET * 2 + 2, viewH);
            for (var r = 0; r < rows; r++) {
                var ry = top + r * O_ROW - S.segScroll;
                if (ry + O_ROW < top || ry > bottom) continue;
                var isSel = r === 0 ? S.sel.seg < 0 : S.sel.seg === r - 1;
                var hovered = inside(mx, my, x + O_INSET, ry, rw, O_ROW) && my >= top && my < bottom;
                if (isSel) k.BUTTON_ACTIVE.draw(ctx, x + O_INSET, ry, rw, O_ROW, 1);
                else if (hovered) ctx.rect(x + O_INSET, ry, rw, O_ROW, "#30FFFFFF");
                var label = r === 0 ? T("strand", FACES[S.sel.fi].key, S.sel.i + 1) : T("segment", r);
                txt(ctx, label, x + O_INSET + (r === 0 ? 8 : 18) - 4, ry + 2, C.TEXT);
                var o = r > 0 ? H.getOverride(sel, r - 1) : null;
                if (o && !H.isIdentity(o)) ctx.rect(x + O_INSET + rw - 1, ry + 4, 3, 3, C.SECTION);
            }
            ctx.unclip();
            if (content > viewH) {
                var bx = x + w - O_INSET - SCROLLBAR + 2, th = Math.max(12, Math.round(viewH * viewH / content));
                var ty = top + Math.round((viewH - th) * S.segScroll / Math.max(1, content - viewH));
                ctx.rect(bx, top, SCROLLBAR, viewH, "#60000000");
                ctx.rect(bx, ty, SCROLLBAR, th, inside(mx, my, bx, top, SCROLLBAR, viewH) ? C.HOVER_TEXT : C.DIVIDER);
            }
        }
        // code buttons
        var ct = codeTop(), cw = codeColumnWidth();
        divider(ctx, x + O_INSET, x + w - O_INSET, ct - 3);
        for (var col = 0; col < 2; col++) {
            var hx = x + O_INSET + col * (cw + TAB_GAP), head = T(col === 0 ? "code.style" : "code.full");
            txt(ctx, head, hx + Math.floor((cw - tw(ctx, head)) / 2), ct + 1, C.SECTION);
        }
        CODE_ACTIONS.forEach(function (a) {
            var b = codeButton(a), hov = inside(mx, my, b.x, b.y, CODE_BUTTON, CODE_BUTTON);
            ctx.image(BUTTONS, b.x, b.y, 20, 20, a.exp ? 182 : 162, hov ? 20 : 0, 20, 20, 256, 256);
        });
    }
    function renderCodeTooltip(ctx, mx, my) {
        var a = codeActionAt(mx, my);
        if (a) DMZ_UI.tooltip(ctx, [[T("code.tooltip." + a.id), "#FFFFFF"]], mx, my);
    }

    function outlinerClick(mx, my, btn) {
        if (!inside(mx, my, LY.ox, LY.oy, LY.ow, LY.oh)) return false;
        if (btn !== 0) return true;
        var x = LY.ox, cur = LY.oy + O_HEADER + 2, tw5 = tabWidth(5), i;
        for (i = 0; i < 5; i++) {
            var tx = x + O_INSET + i * (tw5 + TAB_GAP);
            if (inside(mx, my, tx, cur, tw5, TAB_HEIGHT)) { setSlot(SLOTS[i]); SND.click(); S.rebuild = true; return true; }
        }
        cur += TAB_HEIGHT + 3;
        for (i = 0; i < 5; i++) {
            var fx = x + O_INSET + i * (tw5 + TAB_GAP);
            if (inside(mx, my, fx, cur, tw5, TAB_HEIGHT)) { S.face = i; SND.click(); return true; }
        }
        cur += TAB_HEIGHT + 4;
        var fi = S.face, f = FACES[fi], gx = gridX(fi);
        for (i = 0; i < f.max; i++) {
            var cx = gx + (i % f.cols) * (CELL + CELL_GAP), cy = cur + Math.floor(i / f.cols) * (CELL + CELL_GAP);
            if (inside(mx, my, cx, cy, CELL, CELL)) {
                if (S.sel && S.sel.fi === fi && S.sel.i === i) { clearSelection(); SND.deselect(); }
                else { select(fi, i); SND.select(); }
                S.rebuild = true;
                return true;
            }
        }
        cur += gridHeight(fi) + 4;
        if (S.sel) {
            var bw = Math.floor((LY.ow - O_INSET * 2 - TAB_GAP) / 2), key = flat(S.sel.fi, S.sel.i);
            if (inside(mx, my, x + O_INSET, cur, bw, BUTTON_HEIGHT)) { if (S.hidden[key]) delete S.hidden[key]; else S.hidden[key] = 1; SND.toggle(!!S.hidden[key]); changed(); return true; }
            if (inside(mx, my, x + O_INSET + bw + TAB_GAP, cur, bw, BUTTON_HEIGHT)) { if (S.locked[key]) delete S.locked[key]; else S.locked[key] = 1; SND.toggle(!!S.locked[key]); return true; }
            var s = selected(), top = S.segListTop, bottom = codeTop() - 3;
            if (s && visible(s) && my >= top && my < bottom && mx < x + LY.ow - O_INSET) {
                var row = Math.floor((my - top + S.segScroll) / O_ROW);
                if (row === 0) { S.sel.seg = -1; SND.select(); changed(); }
                else if (row - 1 < s.sg) { S.sel.seg = row - 1; SND.select(); changed(); }
                S.rebuild = true;
                return true;
            }
        }
        var a = codeActionAt(mx, my);
        if (a) { SND.click(); var id = a.id; heavy(function () { codeAction(id); }); }
        return true;
    }

    // HairEditorScreen.handleCodeAction: the clipboard holds the original's codes
    function codeAction(id) {
        var name = T("style." + SLOTS.indexOf(S.slot));
        try {
            if (id === "copy_style") {
                var c = H.toCode(style());
                if (!c) { status(T("status.error"), C.WARNING); return; }
                RPG.clipboard.set(c); status(T("status.copied_style", name), C.SUCCESS);
            } else if (id === "copy_full") {
                var f = H.toFullSetCode(S.styles, false);
                if (!f) { status(T("status.error"), C.WARNING); return; }
                RPG.clipboard.set(f); status(T("status.copied_full"), C.SUCCESS);
            } else if (id === "paste_style") {
                var code = String(RPG.clipboard.get() || "").trim();
                var imp = H.isFullSetCode(code) ? (H.decodeFullSet(code) || {})[S.slot] : H.decode(code);
                if (!imp) { status(T("status.error"), C.WARNING); return; }
                H.sanitize(imp, L);
                record();
                keepJoints(imp, style());                // replaceCurrentStyle: copyFrom takes the code's own colour too
                S.styles[S.slot] = imp;
                clampSeg(); changed(); S.rebuild = true;
                status(T("status.imported_style", name), C.SUCCESS);
            } else if (id === "paste_full") {
                var all = H.decodeFullSet(String(RPG.clipboard.get() || "").trim());
                if (!all) { status(T("status.error"), C.WARNING); return; }
                record();
                SLOTS.forEach(function (slot) {
                    if (!all[slot]) return;
                    H.sanitize(all[slot], L);
                    keepJoints(all[slot], S.styles[slot]);
                    S.styles[slot] = all[slot];
                });
                clampSeg(); changed(); S.rebuild = true;
                status(T("status.imported_full"), C.SUCCESS);
            }
        } catch (e) { status(T("status.error"), C.WARNING); }
    }

    // ---- top bar ----
    var TOP = [{ id: "hairbase", w: 58 }, { id: "physics", w: 52 }, { id: "mirror", w: 48 }, { id: "redo", w: 36 }, { id: "undo", w: 36 }];
    function renderTopBar(ctx, mx, my) {
        var top = 6;
        button(ctx, T("cancel"), MARGIN, top, 60, TOP_BAR_HEIGHT, inside(mx, my, MARGIN, top, 60, TOP_BAR_HEIGHT), false, true);
        txt(ctx, T("title") + (isDirty() ? " *" : ""), LY.w / 2, top + 4, C.TITLE, 0.5);
        var x = LY.w - MARGIN;
        TOP.forEach(function (c) {
            x -= c.w;
            var active = c.id === "hairbase" ? S.hairBase : c.id === "physics" ? S.physics : c.id === "mirror" ? S.mirror : false;
            var enabled = c.id === "undo" ? S.undo.length > 0 : c.id === "redo" ? S.redo.length > 0 : true;
            button(ctx, T(c.id), x, top, c.w, TOP_BAR_HEIGHT, inside(mx, my, x, top, c.w, TOP_BAR_HEIGHT), active, enabled);
            x -= 3;
        });
    }
    function topBarClick(mx, my) {
        var top = 6;
        if (inside(mx, my, MARGIN, top, 60, TOP_BAR_HEIGHT)) { SND.click(); requestClose(); return true; }
        var x = LY.w - MARGIN;
        for (var i = 0; i < TOP.length; i++) {
            var c = TOP[i];
            x -= c.w;
            if (inside(mx, my, x, top, c.w, TOP_BAR_HEIGHT)) {
                if (c.id === "undo") { if (undo()) { SND.click(); S.rebuild = true; } }
                else if (c.id === "redo") { if (redo()) { SND.click(); S.rebuild = true; } }
                else if (c.id === "mirror") { S.mirror = !S.mirror; SND.toggle(S.mirror); }
                else if (c.id === "physics") { S.physics = !S.physics; SND.toggle(S.physics); }
                else if (c.id === "hairbase") { S.hairBase = !S.hairBase; SND.toggle(S.hairBase); S.layoutKey = ""; }
                return true;
            }
            x -= 3;
        }
        return false;
    }

    // ---- viewport overlay: view presets, status, hint ----
    var VIEWS = [{ id: "front", yaw: 180 }, { id: "back", yaw: 0 }, { id: "left", yaw: 90 }, { id: "right", yaw: 270 }, { id: "reset", yaw: 180 }];
    function viewButtons(ctx) {
        var x = LY.vx0 + 2, out = [];
        VIEWS.forEach(function (v) { var w = Math.max(26, tw(ctx, T("view." + v.id)) + 8); out.push({ v: v, x: x, y: LY.vy0 + 2, w: w }); x += w + 2; });
        return out;
    }
    function renderViewportOverlay(ctx, mx, my) {
        S.views = viewButtons(ctx);
        S.views.forEach(function (b) { button(ctx, T("view." + b.v.id), b.x, b.y, b.w, 13, inside(mx, my, b.x, b.y, b.w, 13), false, true); });
        if (S.status && RPG.nowMs() < S.status.until) txt(ctx, S.status.text, (LY.vx0 + LY.vx1) / 2, LY.vy0 + 20, S.status.color, 0.5);
        var hint = trim(ctx, T(S.tool ? "hint.tool" : "hint.viewport"), LY.vx1 - LY.vx0 - 160);
        ctx.textStyled(hint, LY.vx0 + 3, LY.vy1 - 11, 1, C.MUTED, 1, 0, FONT, null);
    }
    function viewClick(mx, my) {
        if (!S.views) return false;
        for (var i = 0; i < S.views.length; i++) {
            var b = S.views[i];
            if (inside(mx, my, b.x, b.y, b.w, 13)) {
                SND.click();
                S.yaw = b.v.yaw; S.pitch = 0;
                if (b.v.id === "reset") { S.panX = 0; S.panY = 0; S.targetZoom = 150; }
                return true;
            }
        }
        return false;
    }
    // Save and Hair Salon (TexturedTextButton 74x20, characterbuttons 0,28 / 0,48)
    function bottomButtons() { var y = LY.vy1 - 24; return [{ id: "save", x: LY.vx1 - 152, y: y }, { id: "hair_salon", x: LY.vx1 - 76, y: y }]; }
    function renderBottomButtons(ctx, mx, my) {
        bottomButtons().forEach(function (b) {
            var over = inside(mx, my, b.x, b.y, 74, 20);
            ctx.image(BUTTONS, b.x, b.y, 74, 20, 0, over ? 48 : 28, 74, 20, 256, 256);
            txt(ctx, T(b.id), b.x + 37, b.y + 6, over ? "#FFFFA0" : "#FFFFFF", 0.5);
        });
    }
    function bottomClick(mx, my) {
        var bs = bottomButtons();
        for (var i = 0; i < bs.length; i++) {
            if (!inside(mx, my, bs[i].x, bs[i].y, 74, 20)) continue;
            SND.click();
            if (bs[i].id === "save") heavy(save);
            else { RPG.clipboard.set(HAIR_SALON_URL); status(HAIR_SALON_URL, C.HOVER_TEXT); }
            return true;
        }
        return false;
    }

    // ---- confirm close ----
    function confirmBox() { var w = 220, h = 64; return { x: Math.floor((LY.w - w) / 2), y: Math.floor((LY.h - h) / 2), w: w, h: h, bw: Math.floor((w - 24) / 3) }; }
    var CHOICES = ["save", "discard", "keep_editing"];
    function renderConfirm(ctx, mx, my) {
        ctx.fill(0, 0, LY.w, LY.h, "#000000", 0.56);
        var b = confirmBox();
        skins().SMALL.draw(ctx, b.x, b.y, b.w, b.h, 1);
        txt(ctx, T("confirm_close"), b.x + b.w / 2, b.y + 12, C.TITLE, 0.5);
        CHOICES.forEach(function (c, i) {
            var bx = b.x + 6 + i * (b.bw + 6);
            button(ctx, T(c), bx, b.y + 38, b.bw, 16, inside(mx, my, bx, b.y + 38, b.bw, 16), false, true);
        });
    }
    function confirmClick(mx, my) {
        var b = confirmBox();
        for (var i = 0; i < 3; i++) {
            var bx = b.x + 6 + i * (b.bw + 6);
            if (!inside(mx, my, bx, b.y + 38, b.bw, 16)) continue;
            SND.click();
            S.confirm = false;
            if (CHOICES[i] === "save") heavy(save);
            else if (CHOICES[i] === "discard") close();
            return true;
        }
        return true;
    }

    // =====================================================================================
    //  Inspector (HairInspectorPanel + HairInspectorRows)
    // =====================================================================================
    function section(label) { return { kind: "section", h: SECTION_H, label: label }; }
    function info(fn, color) { return { kind: "info", h: ROW_H, text: fn, color: color }; }
    function action(label, run, enabled) { return { label: label, run: run, enabled: enabled }; }
    function actions(list) { return { kind: "actions", h: ROW_H + 3, list: list }; }
    function choice(label, value, next, reset) { return { kind: "choice", h: ROW_H, label: label, value: value, next: next, reset: reset }; }
    function presetRow(label, value, step) { return { kind: "preset", h: ROW_H, label: label, value: value, step: step }; }
    function colorRow(label, get, fallback, set) { return { kind: "color", h: ROW_H, label: label, get: get, fallback: fallback, set: set }; }
    function number(key, axis, min, max, step, integer, get, set, def) {
        return { kind: "number", h: ROW_H, label: T("property." + key), axis: axis, min: min, max: max, step: step, integer: integer, get: get, set: set, def: def };
    }
    function strandNumber(key, axis, min, max, step, integer, getter, setter, def) {
        return number(key, axis, min, max, step, integer, function () { var s = selected(); return s ? getter(s) : def; },
            function (v) { modifySelected(function (s) { setter(s, v); }); }, def);
    }
    function segmentNumber(key, axis, min, max, step, getter, setter, def) {
        return number(key, axis, min, max, step, false, function () {
            var s = selected(), o = s && S.sel.seg >= 0 ? H.getOverride(s, S.sel.seg) : null;
            return o ? getter(o) : def;
        }, function (v) {
            modifySelected(function (s) {
                var o = H.getOrCreateOverride(s, S.sel.seg);
                setter(o, v);
                if (H.isIdentity(o)) H.removeOverride(s, o.k);
            });
        }, def);
    }
    function cf(v, lo, hi) { return H.clampFF(F(v), lo, hi, F(lo)); }
    function nextSlot(cur, excluded) {
        var i = SLOTS.indexOf(cur);
        for (var n = 0; n < 5; n++) { i = (i + 1) % 5; if (SLOTS[i] !== excluded) return SLOTS[i]; }
        return cur;
    }

    function rebuildRows() {
        S.rebuild = false;
        S.editing = null;
        S.dragRow = null;
        var rows = [], s = selected();
        if (!s) buildStyleRows(rows);
        else if (!visible(s)) buildEmptyRows(rows);
        else { buildStrandRows(rows); if (S.sel.seg >= 0) buildSegmentRows(rows); }
        S.rows = rows;
    }
    function buildStyleRows(rows) {
        var slot = S.slot, idx = SLOTS.indexOf(slot);
        rows.push(section(T("section.hair")));
        rows.push(presetRow(T("preset"), function () {
            return S.presetId <= 0 ? T("preset.custom") : S.presetId === H.BALD ? T("preset.bald") : T("preset.named", S.presetId);
        }, function (dir) {
            var ids = H.presetIds();
            if (!ids.length) return;
            var i = ids.indexOf(S.presetId), n = i < 0 ? (dir > 0 ? 0 : ids.length - 1) : ((i + dir) % ids.length + ids.length) % ids.length;
            applyPreset(ids[n]);
        }));
        rows.push(colorRow(T("global_color"), function () { return S.styles.base.gc; }, function () { return S.styles.base.gc; }, setGlobalColor));
        rows.push(section(T("style." + idx)));
        rows.push(info(function () { return T("info.strands", H.visibleCount(style())); }, C.TEXT));
        rows.push(info(function () { return T("info.segments", H.segmentCount(style()), L.maxTotalSegments); }, function () { return H.segmentCount(style()) > L.maxTotalSegments ? C.WARNING : C.TEXT; }));
        if (S.copySource === slot) S.copySource = nextSlot(slot, slot);
        rows.push(choice(T("copy_from"), function () { return T("style." + SLOTS.indexOf(S.copySource)); }, function () { S.copySource = nextSlot(S.copySource, S.slot); }, null));
        rows.push(actions([
            action(T("action.copy_style"), function () { if (S.copySource === S.slot) return; record(); var c = clone(S.styles[S.copySource]); c.gc = style().gc; S.styles[S.slot] = c; clampSeg(); changed(); }),
            action(T("action.clear_style"), function () { record(); var e = H.emptyHair(); e.gc = style().gc; e.name = style().name; S.styles[S.slot] = e; if (S.sel) S.sel.seg = -1; changed(); })]));
        rows.push(section(T("section.generate")));
        rows.push(info(function () { return T("info.generate"); }, C.MUTED));
        rows.push(choice(T("generate_target"), function () { return S.genTarget ? T("style." + SLOTS.indexOf(S.genTarget)) : T("generate_target.all"); },
            function () { S.genTarget = S.genTarget === null ? "ssj" : SLOTS[SLOTS.indexOf(S.genTarget) + 1] || null; }, function () { S.genTarget = null; }));
        rows.push(actions([action(T("action.generate"), function () { var t = S.genTarget; heavy(function () { generate(t); S.rebuild = true; }); }, function () { return !H.isEmpty(S.styles.base) && typeof DMZ_HAIR_GEN !== "undefined"; })]));
        rows.push(section(T("help")));
        ["select", "grow", "rotate", "curve", "segments", "remove_segment", "orbit", "body", "reset"].forEach(function (k) { rows.push(info(function () { return T("help." + k); }, C.MUTED)); });
    }
    function strandTitle() { return T("strand", S.sel ? FACES[S.sel.fi].key : "-", S.sel ? S.sel.i + 1 : 0); }
    function buildEmptyRows(rows) {
        rows.push(section(strandTitle()));
        rows.push(info(function () { return T("info.empty_slot"); }, C.MUTED));
        rows.push(actions([action(T("action.add_strand"), function () { record(); modifySelected(H.makeVisible); }),
            action(T("action.paste"), pasteStrand, function () { return !!S.clipboard; })]));
    }
    function pasteStrand() {
        if (!S.clipboard || !S.sel) return;
        record();
        var fi = S.sel.fi, i = S.sel.i, c = clone(S.clipboard);
        c.i = flat(fi, i);
        style().faces[FACES[fi].key][i] = c;
        propagateMirror(); clampSeg(); changed();
    }
    function baseRot(axis) { return S.sel ? H.BASE_ROT[FACES[S.sel.fi].key][axis] : 0; }
    function buildStrandRows(rows) {
        var mo = L.maxRootOffset, mw = L.maxWidth, ms = L.maxSegments, ml = L.maxLength;
        rows.push(section(strandTitle()));
        rows.push(actions([
            action(T("action.copy"), function () { S.clipboard = clone(selected()); }),
            action(T("action.paste"), pasteStrand, function () { return !!S.clipboard; }),
            action(T("action.to_all_styles"), copyToAll),
            action(T("action.clear"), clearStrand)]));
        rows.push(section(T("section.transform")));
        rows.push(strandNumber("offset_x", C.AXIS_X, -mo, mo, OFFSET_STEP, false, function (s) { return s.ox; }, function (s, v) { s.ox = cf(v, -4, 4); }, 0));
        rows.push(strandNumber("offset_y", C.AXIS_Y, -mo, mo, OFFSET_STEP, false, function (s) { return s.oy; }, function (s, v) { s.oy = cf(v, -4, 4); }, 0));
        rows.push(strandNumber("offset_z", C.AXIS_Z, -mo, mo, OFFSET_STEP, false, function (s) { return s.oz; }, function (s, v) { s.oz = cf(v, -4, 4); }, 0));
        rows.push(strandNumber("rotation_x", C.AXIS_X, -180, 180, ANGLE_STEP, false, function (s) { return s.rx; }, function (s, v) { s.rx = H.wrapF(F(v)); }, baseRot(0)));
        rows.push(strandNumber("rotation_y", C.AXIS_Y, -180, 180, ANGLE_STEP, false, function (s) { return s.ry; }, function (s, v) { s.ry = H.wrapF(F(v)); }, baseRot(1)));
        rows.push(strandNumber("rotation_z", C.AXIS_Z, -180, 180, ANGLE_STEP, false, function (s) { return s.rz; }, function (s, v) { s.rz = H.wrapF(F(v)); }, baseRot(2)));
        rows.push(section(T("section.shape")));
        rows.push(strandNumber("segments", 0, 1, ms, 1, true, function (s) { return s.sg; }, function (s, v) { H.resizeSegments(s, Math.round(v), ms, ml); }, 4));
        rows.push(strandNumber("length", 0, 1, ml, 0.1, false, function (s) { return s.ln; }, function (s, v) { H.resizeLength(s, v, ms, ml); }, 6));
        rows.push(strandNumber("length_falloff", 0, 0.1, 2, 0.01, false, function (s) { return s.lr; }, function (s, v) { s.lr = cf(v, 0.1, 4); }, 1));
        rows.push(strandNumber("width", 0, 0.25, mw, OFFSET_STEP, false, function (s) { return s.w; }, function (s, v) { s.w = cf(v, 0.1, 16); }, 2));
        rows.push(strandNumber("depth", 0, 0.25, mw, OFFSET_STEP, false, function (s) { return s.d; }, function (s, v) { s.d = cf(v, 0.1, 16); }, 2));
        rows.push(strandNumber("taper", 0, 0.05, 2, 0.01, false, function (s) { return s.tp; }, function (s, v) { s.tp = cf(v, 0.05, 2); }, 1));
        rows.push(strandNumber("taper_curve", 0, 0.25, 4, 0.05, false, function (s) { return s.tg; }, function (s, v) { s.tg = cf(v, 0.25, 4); }, 1));
        rows.push(choice(T("joints"), function () { var s = selected(); return T("joints." + (s && s.js ? "connected" : "blocks")); },
            function () { modifySelected(function (s) { s.js = s.js ? 0 : 1; }); }, function () { modifySelected(function (s) { s.js = 0; }); }));
        rows.push(section(T("section.curve")));
        rows.push(strandNumber("bend_x", C.AXIS_X, -MAX_BEND, MAX_BEND, ANGLE_STEP, false, function (s) { return s.bx; }, function (s, v) { s.bx = cf(v, -3600, 3600); }, 0));
        rows.push(strandNumber("bend_y", C.AXIS_Y, -MAX_BEND, MAX_BEND, ANGLE_STEP, false, function (s) { return s.by; }, function (s, v) { s.by = cf(v, -3600, 3600); }, 0));
        rows.push(strandNumber("bend_z", C.AXIS_Z, -MAX_BEND, MAX_BEND, ANGLE_STEP, false, function (s) { return s.bz; }, function (s, v) { s.bz = cf(v, -3600, 3600); }, 0));
        rows.push(strandNumber("twist", 0, -MAX_TWIST, MAX_TWIST, ANGLE_STEP, false, function (s) { return s.tw; }, function (s, v) { s.tw = cf(v, -3600, 3600); }, 0));
        rows.push(section(T("section.color")));
        rows.push(colorRow(T("color"), function () { var s = selected(); return s ? s.c : null; }, function () { return style().gc; },
            function (h) { modifySelected(function (s) { s.c = H.normColor(h); }); }));
        rows.push(colorRow(T("tip_color"), function () { var s = selected(); return s ? s.tc : null; }, function () { var s = selected(); return (s && s.c) || style().gc; },
            function (h) { modifySelected(function (s) { s.tc = H.normColor(h); }); }));
    }
    function buildSegmentRows(rows) {
        var seg = S.sel.seg, mo = 2;
        rows.push(section(T("segment", seg + 1)));
        rows.push(actions([action(T("action.reset_segment"), function () { record(); modifySelected(function (s) { H.removeOverride(s, S.sel.seg); }); })]));
        rows.push(segmentNumber("offset_x", C.AXIS_X, -mo, mo, OFFSET_STEP, function (o) { return o.ox; }, function (o, v) { o.ox = cf(v, -2, 2); }, 0));
        rows.push(segmentNumber("offset_y", C.AXIS_Y, -mo, mo, OFFSET_STEP, function (o) { return o.oy; }, function (o, v) { o.oy = cf(v, -2, 2); }, 0));
        rows.push(segmentNumber("offset_z", C.AXIS_Z, -mo, mo, OFFSET_STEP, function (o) { return o.oz; }, function (o, v) { o.oz = cf(v, -2, 2); }, 0));
        rows.push(segmentNumber("rotation_x", C.AXIS_X, -180, 180, ANGLE_STEP, function (o) { return o.rx; }, function (o, v) { o.rx = cf(v, -180, 180); }, 0));
        rows.push(segmentNumber("rotation_y", C.AXIS_Y, -180, 180, ANGLE_STEP, function (o) { return o.ry; }, function (o, v) { o.ry = cf(v, -180, 180); }, 0));
        rows.push(segmentNumber("rotation_z", C.AXIS_Z, -180, 180, ANGLE_STEP, function (o) { return o.rz; }, function (o, v) { o.rz = cf(v, -180, 180); }, 0));
        rows.push(segmentNumber("length_scale", 0, 0.1, MAX_SEGMENT_SCALE, 0.01, function (o) { return o.ls; }, function (o, v) { o.ls = cf(v, 0.1, 16); }, 1));
        rows.push(segmentNumber("width_scale", 0, 0.1, MAX_SEGMENT_SCALE, 0.01, function (o) { return o.ws; }, function (o, v) { o.ws = cf(v, 0.1, 16); }, 1));
        rows.push(segmentNumber("depth_scale", 0, 0.1, MAX_SEGMENT_SCALE, 0.01, function (o) { return o.ds; }, function (o, v) { o.ds = cf(v, 0.1, 16); }, 1));
        rows.push(colorRow(T("color"), function () { var s = selected(), o = s ? H.getOverride(s, S.sel.seg) : null; return o ? o.c : null; },
            function () { var s = selected(); return (s && s.c) || style().gc; },
            function (h) { modifySelected(function (s) { var o = H.getOrCreateOverride(s, S.sel.seg); o.c = H.normColor(h); if (H.isIdentity(o)) H.removeOverride(s, o.k); }); }));
    }
    function copyToAll() {
        var s = selected();
        if (!s) return;
        record();
        SLOTS.forEach(function (other) {
            if (other === S.slot) return;
            var c = clone(s); c.i = flat(S.sel.fi, S.sel.i);
            strandAt(S.styles[other], S.sel.fi, S.sel.i);
            S.styles[other].faces[FACES[S.sel.fi].key][S.sel.i] = c;
            if (S.mirror) {
                var mf = H.mirrorFace(S.sel.fi), mi = H.mirrorIndex(S.sel.fi, S.sel.i);
                if (mf !== S.sel.fi || mi !== S.sel.i) { var m = clone(s); m.i = flat(mf, mi); H.mirrorStrand(m); strandAt(S.styles[other], mf, mi); S.styles[other].faces[FACES[mf].key][mi] = m; }
            }
            S.slotRev[other] = (S.slotRev[other] || 0) + 1;
        });
        changed();
    }
    function clearStrand() {
        if (!S.sel) return;
        record();
        var fi = S.sel.fi, i = S.sel.i;
        modifySelected(function (s) { var d = H.defaultStrand(fi, i); Object.keys(s).forEach(function (k) { delete s[k]; }); Object.keys(d).forEach(function (k) { s[k] = d[k]; }); });
        S.sel.seg = -1;
    }

    function rowX() { return LY.ix + I_INSET; }
    function rowW() { return LY.iw - I_INSET * 2 - SCROLLBAR - 2; }
    function visibleH() { return LY.ih - I_HEADER - I_INSET; }
    function contentH() { var t = 0; S.rows.forEach(function (r) { t += r.h; }); return t; }
    function barX(x) { return x + LABEL_W; }
    function barW(w) { return Math.max(10, w - LABEL_W - VALUE_W - 8); }
    function renderInspector(ctx, mx, my) {
        var x = LY.ix, y = LY.iy, w = LY.iw, k = skins();
        panel(ctx, x, y, w, LY.ih);
        header(ctx, T("inspector"), x, y, w);
        var top = y + I_HEADER, vh = visibleH(), ch = contentH();
        S.scroll = Math.max(0, Math.min(S.scroll, Math.max(0, ch - vh)));
        ctx.clip(x + I_INSET, top, w - I_INSET * 2, vh);
        var ry = top - S.scroll, rx = rowX(), rw = rowW();
        S.rows.forEach(function (r) {
            if (ry + r.h >= top && ry <= top + vh) renderRow(ctx, r, rx, ry, rw, mx, my, k);
            ry += r.h;
        });
        ctx.unclip();
        if (ch > vh) {
            var bx = x + w - I_INSET - SCROLLBAR, th = Math.max(12, Math.round(vh * vh / ch)), ty = top + Math.round((vh - th) * S.scroll / Math.max(1, ch - vh));
            ctx.rect(bx, top, SCROLLBAR, vh, "#60000000");
            ctx.rect(bx, ty, SCROLLBAR, th, inside(mx, my, bx, top, SCROLLBAR, vh) ? C.HOVER_TEXT : C.DIVIDER);
        }
    }
    function renderRow(ctx, r, x, y, w, mx, my, k) {
        if (r.kind === "section") {
            txt(ctx, r.label, x + 4, y + 5, C.SECTION);
            divider(ctx, x + 8 + tw(ctx, r.label), x + w - 4, y + 9);
        } else if (r.kind === "info") {
            txt(ctx, trim(ctx, r.text(), w - 8), x + 4, y + 3, typeof r.color === "function" ? r.color() : r.color);
        } else if (r.kind === "number") {
            var hov = inside(mx, my, x, y, w, ROW_H);
            if (hov || S.dragRow === r) ctx.rect(x + 1, y, w - 2, ROW_H, "#30FFFFFF");
            if (r.axis) ctx.rect(x + 2, y + 2, 2, ROW_H - 4, r.axis);
            txt(ctx, trim(ctx, r.label, LABEL_W - 8), x + 6, y + 3, S.dragRow === r && S.dragMode === "scrub" ? C.TITLE : C.MUTED);
            var v = r.get(), bx = barX(x), bw = barW(w);
            k.BUTTON.draw(ctx, bx, y + 2, bw, ROW_H - 4, 1);
            var ratio = r.max > r.min ? (Math.max(r.min, Math.min(r.max, v)) - r.min) / (r.max - r.min) : 0;
            if (r.min < 0 && r.max > 0) {
                var zero = bx + Math.round(-r.min / (r.max - r.min) * bw), cur = bx + Math.round(ratio * bw);
                if (Math.abs(cur - zero) > 0) k.BUTTON_ACTIVE.draw(ctx, Math.min(zero, cur), y + 3, Math.abs(cur - zero), ROW_H - 6, 1);
                ctx.rect(zero, y + 2, 1, ROW_H - 4, C.DIVIDER);
            } else if (Math.round(ratio * bw) > 0) k.BUTTON_ACTIVE.draw(ctx, bx, y + 3, Math.round(ratio * bw), ROW_H - 6, 1);
            var handle = bx + Math.round(ratio * (bw - 2));
            ctx.rect(handle, y + 2, 2, ROW_H - 4, C.TEXT);
            var vx = x + w - VALUE_W - 3, editing = S.editing === r;
            (editing ? k.FIELD_EDITING : k.FIELD).draw(ctx, vx, y, VALUE_W, ROW_H, 1);
            var t = editing ? S.editText + (Math.floor(RPG.nowMs() / 400) % 2 === 0 ? "_" : "") : fmt(v, r.step, r.integer);
            t = trim(ctx, t, VALUE_W - 4);
            txt(ctx, t, vx + VALUE_W - 3 - tw(ctx, t), y + 3, C.TEXT);
        } else if (r.kind === "choice") {
            txt(ctx, trim(ctx, r.label, LABEL_W - 8), x + 6, y + 3, C.MUTED);
            var cx = x + LABEL_W, cw = w - LABEL_W - 3;
            button(ctx, r.value(), cx, y + 1, cw, ROW_H - 2, inside(mx, my, cx, y + 1, cw, ROW_H - 2), false, true);
        } else if (r.kind === "preset") {
            txt(ctx, trim(ctx, r.label, LABEL_W - 8), x + 6, y + 3, C.MUTED);
            var px = x + LABEL_W, nx = x + w - 3 - 12;
            button(ctx, "<", px, y + 1, 12, ROW_H - 2, inside(mx, my, px, y + 1, 12, ROW_H - 2), false, true);
            button(ctx, ">", nx, y + 1, 12, ROW_H - 2, inside(mx, my, nx, y + 1, 12, ROW_H - 2), false, true);
            var ta = px + 12, taw = nx - ta, s2 = trim(ctx, r.value(), taw - 4);
            txt(ctx, s2, ta + Math.floor((taw - tw(ctx, s2)) / 2), y + 3, C.TEXT);
        } else if (r.kind === "color") {
            if (inside(mx, my, x, y, w, ROW_H)) ctx.rect(x + 1, y, w - 2, ROW_H, "#30FFFFFF");
            txt(ctx, trim(ctx, r.label, LABEL_W - 8), x + 6, y + 3, C.MUTED);
            var h = r.get(), shown = h || r.fallback(), sx = x + LABEL_W;
            ctx.rect(sx, y + 2, 18, ROW_H - 4, "#FF" + (H.normColor(shown) || "#FFFFFF").substring(1));
            outline(ctx, sx, y + 2, 18, ROW_H - 4, C.DIVIDER);
            txt(ctx, h ? h : T("color_auto"), sx + 23, y + 3, h ? C.TEXT : C.MUTED);
        } else if (r.kind === "actions") {
            var bw2 = Math.floor((w - 8 - 3 * (r.list.length - 1)) / Math.max(1, r.list.length));
            r.list.forEach(function (a, i) {
                var ax = x + 4 + i * (bw2 + 3), en = !a.enabled || a.enabled();
                button(ctx, trim(ctx, a.label, bw2 - 4), ax, y + 1, bw2, ROW_H, inside(mx, my, ax, y + 1, bw2, ROW_H), false, en);
            });
        }
    }
    function rowAt(my) {
        var ry = LY.iy + I_HEADER - S.scroll;
        for (var i = 0; i < S.rows.length; i++) { var r = S.rows[i]; if (my >= ry && my < ry + r.h) return { r: r, y: ry }; ry += r.h; }
        return null;
    }
    function inspectorClick(mx, my, btn) {
        if (!inside(mx, my, LY.ix, LY.iy, LY.iw, LY.ih)) { commitText(); return false; }
        var top = LY.iy + I_HEADER;
        if (my < top) return true;
        var ch = contentH(), vh = visibleH(), bx = LY.ix + LY.iw - I_INSET - SCROLLBAR;
        if (ch > vh && inside(mx, my, bx, top, SCROLLBAR, vh)) { S.dragScroll = true; commitText(); return true; }
        var hit = rowAt(my);
        if (!hit) { commitText(); return true; }
        var r = hit.r, x = rowX(), w = rowW(), y = hit.y, prevEdit = S.editing;
        if (S.editing && S.editing !== r) commitText();
        if (r.kind === "number") {
            if (btn === 1) { record(); applyNumber(r, r.def, "reset"); SND.click(); return true; }
            if (btn !== 0) return true;
            if (mx >= x + w - VALUE_W - 3) { S.editing = r; S.editText = fmt(r.get(), r.step, r.integer); return true; }
            beginGesture();
            S.dragRow = r;
            if (mx >= barX(x)) { S.dragMode = "bar"; applyBar(r, mx, x, w); }
            else { S.dragMode = "scrub"; S.dragStartX = mx; S.dragStartValue = r.get(); }
        } else if (r.kind === "choice") {
            record();
            if (btn === 1 && r.reset) r.reset(); else if (btn === 0) r.next();
            SND.click(); S.rebuild = true;
        } else if (r.kind === "preset") {
            if (btn !== 0) return true;
            var dir = inside(mx, my, x + LABEL_W, y + 1, 12, ROW_H - 2) ? -1 : inside(mx, my, x + w - 15, y + 1, 12, ROW_H - 2) ? 1 : 0;
            if (dir) { r.step(dir); SND.click(); S.rebuild = true; }
        } else if (r.kind === "color") {
            record();
            if (btn === 1) { r.set(null); SND.click(); return true; }
            if (btn === 0) {
                SND.click();
                var start = r.get() || r.fallback();
                RPG.screen.pickColor({ x: x + LABEL_W, y: y + ROW_H, w: 18, h: 1, value: start }, function (v) { r.set(v); }, function (v, cancelled) { if (cancelled) r.set(start === r.fallback() && !r.get() ? null : start); });
            }
        } else if (r.kind === "actions") {
            if (btn !== 0) return true;
            var bw2 = Math.floor((w - 8 - 3 * (r.list.length - 1)) / Math.max(1, r.list.length));
            for (var i = 0; i < r.list.length; i++) {
                var ax = x + 4 + i * (bw2 + 3);
                if (!inside(mx, my, ax, y + 1, bw2, ROW_H)) continue;
                var a = r.list[i];
                if (a.enabled && !a.enabled()) return true;
                a.run(); SND.click(); S.rebuild = true;
                return true;
            }
        }
        return true;
    }
    function applyBar(r, mx, x, w) { var ratio = (mx - barX(x)) / Math.max(1, barW(w)); applyNumber(r, r.min + Math.max(0, Math.min(1, ratio)) * (r.max - r.min), "drag"); }
    function applyNumber(r, value, mode) {
        if (!isFinite(value)) return;
        var before = r.get(), v = Math.max(r.min, Math.min(r.max, value));
        if (r.step > 0 && !shift()) v = Math.round(v / r.step) * r.step;
        if (r.integer) v = Math.round(v);
        r.set(Math.max(r.min, Math.min(r.max, v)));
        if (mode === "reset") return;
        var after = r.get(), tol = r.integer ? 0.5 : Math.max(1e-3, (r.max - r.min) * 1e-4);
        var lim = function (x) { return Math.abs(x - r.min) <= tol || Math.abs(x - r.max) <= tol; };
        if (lim(after) && ((mode === "commit" && (value < r.min || value > r.max)) || !lim(before))) SND.limit();
    }
    function commitText() {
        if (!S || !S.editing) return;
        var r = S.editing, t = S.editText;
        S.editing = null;
        var v = parseFloat(String(t).trim().replace(",", "."));
        if (isFinite(v)) { record(); applyNumber(r, v, "commit"); }
    }

    // =====================================================================================
    //  Mouse, keys, scroll (HairEditorScreen)
    // =====================================================================================
    function inViewport(x, y) { return x >= LY.vx0 && x < LY.vx1 && y >= LY.vy0 && y < LY.vy1; }
    function mouse(x, y, btn, act) {
        if (!S) return;
        if (act === "down") return mouseDown(x, y, btn);
        if (act === "drag") return mouseDrag(x, y, btn);
        if (act === "up") return mouseUp(x, y, btn);
    }
    function mouseDown(x, y, btn) {
        if (S.confirm) return confirmClick(x, y);
        if (RPG.screen.colorPickerOpen()) return;
        if (bottomClick(x, y)) return false;
        if (topBarClick(x, y)) return false;
        if (outlinerClick(x, y, btn)) return false;
        if (inspectorClick(x, y, btn)) return false;
        if (viewClick(x, y)) return false;
        if (!inViewport(x, y)) return;
        S.press = { x: x, y: y, lx: x, ly: y, btn: btn, orbit: false, pan: btn === 2, secondary: btn === 1,
            tool: btn === 0 ? (shift() ? "grow" : ctrl() ? "curve" : alt() ? "rotate" : null) : null };
        return false;
    }
    function mouseDrag(x, y) {
        if (S.confirm || RPG.screen.colorPickerOpen()) return;
        if (S.tool) { dragTool(x, y); return false; }
        if (S.dragScroll) {
            var top = LY.iy + I_HEADER, vh = visibleH(), ch = contentH();
            S.scroll = Math.max(0, Math.min(ch - vh, (y - top) / vh * ch - vh / 2));
            return false;
        }
        if (S.dragRow) {
            var r = S.dragRow;
            if (S.dragMode === "bar") applyBar(r, x, rowX(), rowW());
            else {
                var sens = shift() ? 0.1 : ctrl() ? 5 : 1;
                applyNumber(r, S.dragStartValue + (x - S.dragStartX) * (r.max - r.min) / SCRUB_PIXELS * sens, "drag");
            }
            return false;
        }
        var p = S.press;
        if (!p) return;
        var moved = Math.sqrt((x - p.x) * (x - p.x) + (y - p.y) * (y - p.y)) > CLICK_DRAG_THRESHOLD;
        if (p.btn === 0 && p.tool) {
            if (moved) { beginTool(p.tool, p.x, p.y); p.tool = null; if (S.tool) dragTool(x, y); }
            return false;
        }
        if (p.secondary && moved) { p.secondary = false; p.pan = true; }
        if (p.btn === 0) {
            if (!p.orbit && moved) p.orbit = true;
            if (p.orbit) { S.yaw -= (x - p.lx) * ORBIT_SPEED; S.pitch = Math.max(-90, Math.min(90, S.pitch + (y - p.ly) * ORBIT_SPEED)); }
        } else if (p.pan) { S.panX += Math.round(x - p.lx); S.panY += Math.round(y - p.ly); }
        p.lx = x; p.ly = y;
        return false;
    }
    function mouseUp(x, y) {
        S.dragScroll = false;
        if (S.tool) { S.tool = null; S.press = null; S.rebuild = true; return false; }
        if (S.dragRow) { endGesture(); S.dragRow = null; S.dragMode = null; return false; }
        var p = S.press;
        S.press = null;
        if (!p) return;
        if (p.btn === 0 && !p.orbit) pickSelection(x, y);
        if (p.btn === 1 && p.secondary) secondaryClick(x, y);
        return false;
    }
    function pickSelection(x, y) {
        var hit = pick(x, y, false);
        if (!hit) { if (S.sel) SND.deselect(); clearSelection(); }
        else if (S.sel && S.sel.fi === hit.fi && S.sel.i === hit.i && alt()) { S.sel.seg = hit.seg; clampSeg(); changed(); SND.select(); }
        else { select(hit.fi, hit.i); if (alt()) { S.sel.seg = hit.seg; clampSeg(); } SND.select(); }
        S.rebuild = true;
    }
    function secondaryClick(x, y) {
        var hit = pick(x, y, true);
        if (!hit) { S.bodyHidden = !S.bodyHidden; SND.toggle(!S.bodyHidden); return; }
        if (!S.sel || hit.fi !== S.sel.fi || hit.i !== S.sel.i || S.locked[flat(hit.fi, hit.i)]) return;
        var s = selected();
        if (!visible(s)) return;
        var copy = clone(s), ok = shift() ? H.removeSegment(copy) : H.addSegment(copy, L.maxSegments, L.maxLength);
        if (!ok) { SND.limit(); return; }
        record();
        modifySelected(function (t) { Object.keys(copy).forEach(function (k) { t[k] = copy[k]; }); });
        SND.click(); S.rebuild = true;
    }
    function scroll(x, y, delta) {
        if (!S || S.confirm || RPG.screen.colorPickerOpen()) return;
        if (inside(x, y, LY.ix, LY.iy, LY.iw, LY.ih)) { S.scroll = Math.max(0, S.scroll - delta * SCROLL_STEP); return; }
        if (inside(x, y, LY.ox, LY.oy, LY.ow, LY.oh)) { S.segScroll = Math.max(0, S.segScroll - delta * O_ROW); return; }
        if (inViewport(x, y)) S.targetZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, S.targetZoom + delta * ZOOM_STEP));
    }
    var DIGITS = { "key.keyboard.period": ".", "key.keyboard.keypad.decimal": ".", "key.keyboard.comma": ",", "key.keyboard.minus": "-", "key.keyboard.keypad.subtract": "-" };
    function key(name, act) {
        if (!S || act !== "down") return;
        if (S.confirm) { if (name === "key.keyboard.escape") S.confirm = false; return false; }
        if (RPG.screen.colorPickerOpen()) return;
        if (S.editing) {
            var m = /^key\.keyboard\.(?:keypad\.)?(\d)$/.exec(name), ch = m ? m[1] : DIGITS[name];
            if (ch && S.editText.length < 12) S.editText += ch;
            else if (name === "key.keyboard.backspace") S.editText = S.editText.substring(0, Math.max(0, S.editText.length - 1));
            else if (name === "key.keyboard.enter" || name === "key.keyboard.keypad.enter" || name === "key.keyboard.tab") commitText();
            else if (name === "key.keyboard.escape") S.editing = null;
            return false;
        }
        if (name === "key.keyboard.escape") {
            if (S.tool) { cancelTool(); S.rebuild = true; }
            else if (S.sel) { clearSelection(); S.rebuild = true; }
            else requestClose();
            return false;
        }
        if (ctrl() && name === "key.keyboard.z") { if (shift() ? redo() : undo()) S.rebuild = true; return false; }
        if (ctrl() && name === "key.keyboard.y") { if (redo()) S.rebuild = true; return false; }
        if (ctrl() && name === "key.keyboard.c" && S.sel) { S.clipboard = clone(selected()); status(T("status.copied"), C.SUCCESS); return false; }
        if (ctrl() && name === "key.keyboard.v" && S.sel) { pasteStrand(); S.rebuild = true; return false; }
        if (name === "key.keyboard.delete" && S.sel) { clearStrand(); S.rebuild = true; return false; }
    }

    // ---- viewport tools (HairViewportTool): grow along the strand, rotate around the view axis, curve ----
    function beginTool(mode, px, py) {
        var hit = pick(px, py, false);
        if (hit && (!S.sel || hit.fi !== S.sel.fi || hit.i !== S.sel.i)) { select(hit.fi, hit.i); SND.select(); }
        if (!S.sel || S.locked[flat(S.sel.fi, S.sel.i)]) return;
        var s = selected();
        if (!visible(s)) return;
        record();
        var pose = H._pose(s, S.sel.fi, S.sel.i), root = project(pose.root), tip = project(pose.tip);
        S.tool = { mode: mode, original: clone(s), startX: px, startY: py, root: root, tip: tip, px: MODEL_SCALE / 16 * S.zoom, atLimit: false };
        if (mode === "rotate") {                         // which way a turn about the view axis moves the tip on screen
            S.tool.sign = 1;
        }
        S.rebuild = true;
    }
    function cancelTool() {
        if (!S.tool) return;
        var o = S.tool.original;
        S.tool = null;
        modifySelected(function (t) { Object.keys(t).forEach(function (k) { delete t[k]; }); Object.keys(o).forEach(function (k) { t[k] = clone(o[k]); }); });
    }
    function dragTool(mx, my) {
        var t = S.tool, o = t.original;
        modifySelected(function (s) {
            Object.keys(s).forEach(function (k) { delete s[k]; });
            Object.keys(o).forEach(function (k) { s[k] = clone(o[k]); });
            if (t.mode === "grow") {
                var dx = t.tip[0] - t.root[0], dy = t.tip[1] - t.root[1], l = Math.sqrt(dx * dx + dy * dy);
                if (l < MIN_SCREEN_LENGTH) { dx = 0; dy = -1; } else { dx /= l; dy /= l; }
                var projected = (mx - t.startX) * dx + (my - t.startY) * dy, len = o.ln + projected / t.px;
                H.resizeLength(s, len, L.maxSegments, L.maxLength);
                var limited = len >= L.maxLength || len <= 1;
                if (limited && !t.atLimit) SND.limit();
                t.atLimit = limited;
            } else if (t.mode === "rotate") {
                // a turn about the axis pointing out of the screen, applied before the strand's own rotation
                var a0 = Math.atan2(t.startY - t.root[1], t.startX - t.root[0]), a1 = Math.atan2(my - t.root[1], mx - t.root[0]);
                var ang = (a1 - a0) * t.sign, axis = viewAxisModel();
                var q = qAxis(axis, ang), base = qEuler(o.rx, o.ry, o.rz), r = qMul(q, base), e = eulerXYZ(r);
                s.rx = H.wrapF(F(e[0])); s.ry = H.wrapF(F(e[1])); s.rz = H.wrapF(F(e[2]));
            } else {
                var drag = screenToModelDir(mx - t.startX, my - t.startY), pixels = Math.sqrt((mx - t.startX) * (mx - t.startX) + (my - t.startY) * (my - t.startY));
                if (pixels < 1e-3) return;
                var inv = qConj(qEuler(o.rx, o.ry, o.rz)), d = qApply(inv, drag), deg = pixels * CURVE_DEGREES_PER_PIXEL;
                s.bx = cf(o.bx + d[2] * deg, -3600, 3600); s.bz = cf(o.bz - d[0] * deg, -3600, 3600);
            }
        });
    }
    // view directions in head space (inverse of project's rotation)
    function unrotate(v) {
        var t = -S.pitch * Math.PI / 180, ct = Math.cos(t), st = Math.sin(t);
        var y = v[1] * ct - v[2] * st, z = v[1] * st + v[2] * ct, x = v[0];
        var a = -(S.yaw - 180) * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a);
        x = -x; z = -z;
        return [x * ca - z * sa, y, x * sa + z * ca];
    }
    function viewAxisModel() { var v = unrotate([0, 0, 1]); var l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; }
    function screenToModelDir(dx, dy) { var v = unrotate([dx, -dy, 0]); var l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; }
    function qAxis(a, ang) { var h = ang / 2, s = Math.sin(h); return [a[0] * s, a[1] * s, a[2] * s, Math.cos(h)]; }
    function qMul(a, b) {
        return [a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1], a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
                a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3], a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]];
    }
    function qConj(q) { return [-q[0], -q[1], -q[2], q[3]]; }
    function qEuler(rx, ry, rz) {
        var d = Math.PI / 180, q = [0, 0, 0, 1];
        q = qMul(q, [Math.sin(rx * d / 2), 0, 0, Math.cos(rx * d / 2)]);
        q = qMul(q, [0, Math.sin(ry * d / 2), 0, Math.cos(ry * d / 2)]);
        return qMul(q, [0, 0, Math.sin(rz * d / 2), Math.cos(rz * d / 2)]);
    }
    function qApply(q, v) {
        var x = q[0], y = q[1], z = q[2], w = q[3], tx = 2 * (y * v[2] - z * v[1]), ty = 2 * (z * v[0] - x * v[2]), tz = 2 * (x * v[1] - y * v[0]);
        return [v[0] + w * tx + (y * tz - z * ty), v[1] + w * ty + (z * tx - x * tz), v[2] + w * tz + (x * ty - y * tx)];
    }
    // Quaternionf.getEulerAnglesXYZ (degrees)
    function eulerXYZ(q) {
        var x = q[0], y = q[1], z = q[2], w = q[3], r = 180 / Math.PI;
        var ex = Math.atan2(x * w - y * z, 0.5 - x * x - y * y);
        var ey = Math.asin(Math.max(-1, Math.min(1, 2 * (x * z + y * w))));
        var ez = Math.atan2(z * w - x * y, 0.5 - y * y - z * z);
        return [ex * r, ey * r, ez * r];
    }

    // ---- ways in: /hairedit and the Dragon Block menu (90_dbr_hub.js); the creator and Popo call open() --------------
    RPG.net.on("dmz_hair_open", function () { open({}); });

    return { open: open, supported: supported, sendCode: sendCode, isOpen: function () { return !!S; }, _state: function () { return S; } };
})();
