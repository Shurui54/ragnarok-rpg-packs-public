// =====================================================================================
//  Original melee and guard input (MinecraftMixin / CombatAttackRequestC2S, BLOCK_KEY)
//  Left click with empty hands: the next step of the fist combo, animated at once on your
//  screen and sent to the server (which shows it to everyone and applies the damage).
//  Hold right click with empty hands: guard (a quick press is a parry).
// =====================================================================================
(function () {
    var C = DMZ_COMBAT, st = { count: 0, last: -1000, guarding: false, relock: 0 };

    function emptyHands() {
        var h = RPG.player.heldItem;
        return !h || h === "minecraft:air";
    }
    function created() { return !!RPG.getVar("dmz_created", 0); }
    // a ki weapon out (scripts/79_dmz_kiweapon.js): Ki Manipulation on, hands empty -> its table entry, else null
    function kiWeapon() {
        var on = RPG.getVar("dmz_skill_active", null), t = String(RPG.getVar("dmz_kiweapon", "") || "");
        return on && typeof on === "object" && on.kimanipulation && C.KI_WEAPONS[t] ? C.KI_WEAPONS[t] : null;
    }
    function now() { return RPG.nowMs(); }

    RPG.on("mouse", function (button, down) {
        if (RPG.screen.getOpen() || !created()) return;
        if (button === 0 && down) {
            if (!emptyHands() || st.guarding || RPG.player.hasEffect("stunned")) return;
            var kw = kiWeapon(), t = C.timing(4 + (kw ? kw.attackSpeed : 0)), ms = now();
            if (ms - st.last < t.cooldown * 50) return;                     // still recovering
            if (ms - st.last > (t.cooldown + C.CFG.comboResetExtra) * 50) st.count = 0;
            if (kw !== st.weapon) { st.weapon = kw; st.count = 0; }         // a new combo with a new weapon
            var infusion = RPG.player.hasEffect("ki_infusion") && RPG.player.level >= 5;
            var atk = kw ? kw.attacks[st.count % kw.attacks.length] : C.attackFor(st.count, infusion);
            st.last = ms;
            DBR_ANIMATOR.playMelee(atk.anim, t.speed);
            RPG.net.send("dmz_melee", { c: st.count, a: atk.anim, s: t.speed });
            st.count++;
        }
    });

    // ---- guard (ClientStatsEvents: BLOCK_KEY = right mouse, polled every tick) ----
    // The real button state is read every tick instead of trusting press/release events: a release while a screen is
    // open, the window is in the background or the packet order shuffles must never leave the guard (and its pose) on.
    // While guarding, the client repeats {on: true} every 10 ticks; the server drops a guard that stops hearing it.
    var GUARD_KEY = "key.mouse.right", HEARTBEAT = 10, CONFIRM_MS = 600;
    function guardHeld() {
        // Left Alt + right click is the ki blast (51_dmz_ki_render.js), not a guard
        // (GLFW lets go of every held button when the window loses focus, so alt-tab already reads as released;
        // isWindowFocused is false on some window systems even while playing)
        return !RPG.screen.getOpen() && RPG.isKeyDown(GUARD_KEY) && !RPG.isKeyDown("key.keyboard.left.alt");
    }
    function setGuard(on) {
        st.guarding = on;
        st.sentAt = now();
        st.beat = 0;
        DBR_ANIMATOR.setLocalGuard(on);
        RPG.net.send("dmz_guard", { on: on });
    }
    RPG.on("tick", function () {
        var held = guardHeld();
        if (!held) st.needRelease = false;
        var can = created() && emptyHands() && !RPG.player.hasEffect("stunned") && now() >= st.relock && !st.needRelease;
        if (!st.guarding) {
            if (held && can) setGuard(true);
            return;
        }
        if (!held || !can) {
            setGuard(false);
            st.relock = now() + 250;                                       // 5-tick relock after release (BLOCK_REACTIVATION_LOCK_TICKS)
            return;
        }
        // the server ended it (guard break, stun, refused): stand down until the button is let go
        if (!RPG.player.hasEffect("guarding") && now() - st.sentAt > CONFIRM_MS) {
            setGuard(false);
            st.needRelease = true;
            return;
        }
        if (++st.beat >= HEARTBEAT) { st.beat = 0; RPG.net.send("dmz_guard", { on: true, beat: 1 }); }
    });

    // ---- the original's melee hit particles (scripts/11_dmz_combat.js sends "dmz_hitfx") ----
    //  punch  PunchParticle: punch_particle_0-4 over 10 ticks, 0.8 growing 0.05 a tick, white, 0.8 alpha fading out
    //  block  BlockParticle: block_0-2 over 3 ticks, size 1, fading out, tinted by the poise left
    //  parry  GuardBlockParticle (white) + 15 SPARKS (KiSplashParticle on spark1-5) + 15 tiny KI_TRAIL flecks
    //  break  GuardBlockParticle in red
    //  (all drawn at full brightness, like the original's getLightColor)
    var PX = "dmzpack:";
    function seq(names) { return names.map(function (n) { return PX + n; }); }
    var PUNCH = seq(["punch_particle_0", "punch_particle_1", "punch_particle_2", "punch_particle_3", "punch_particle_4"]);
    var BLOCK = seq(["block_0", "block_1", "block_2"]), GUARD = seq(["block_0", "punch_particle_2", "ki_exp5", "ki_exp6"]);
    var SPARKS = seq(["spark1", "spark2", "spark3", "spark4", "spark5"]);
    var TRAIL = seq(["ki_trail0", "ki_trail1", "ki_trail2", "ki_trail3", "ki_trail4", "ki_trail5"]);
    function hex(c) {
        function h(v) { var s = Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16); return s.length < 2 ? "0" + s : s; }
        return "#" + h(c[0]) + h(c[1]) + h(c[2]);
    }
    function sprite(o) { try { RPG.particles.sprite(o); } catch (e) { } }
    RPG.net.on("dmz_hitfx", function (d) {
        if (!d || !RPG.particles || !RPG.player.present) return;
        var x = d.x, y = d.y, z = d.z;
        if (d.k === "punch") {
            sprite({ texture: PUNCH, animate: true, x: x, y: y, z: z, size: 0.8, grow: 0.05, life: 10, alpha: 0.8, fade: "life",
                collide: false, fullbright: true });
        } else if (d.k === "block") {
            sprite({ texture: BLOCK, animate: true, x: x, y: y, z: z, size: 1, life: 3, fade: "life", collide: false, fullbright: true,
                color: hex(d.c || [0.2, 0.9, 1]) });
        } else if (d.k === "parry" || d.k === "break") {
            sprite({ texture: GUARD, animate: true, x: x, y: y, z: z, size: 1, grow: 0.1, life: 10, collide: false, fullbright: true,
                color: d.k === "break" ? hex([1, 0.1, 0.1]) : "#FFFFFF" });
            if (d.k === "parry") {
                for (var i = 0; i < 15; i++) {
                    sprite({ texture: SPARKS, animate: true, x: x, y: y, z: z, size: 1, grow: 0.1, life: 10, collide: false, fullbright: true, blend: "opaque" });
                    sprite({ texture: TRAIL, animate: true, x: x, y: y, z: z, vx: 1, vy: 1, vz: 1, friction: 0.9, size: 0.05, growMul: 0.97,
                        life: [25, 35], fade: "life", collide: false, fullbright: true, blend: "additive" });
                }
            }
        }
    });
})();
