// =====================================================================================
//  Upgraded Chests & Furnaces - chests by tier.
//  Up to 6 rows of 9 they open a chest screen; bigger ones a vanilla-style panel with the slots in a wide grid, at
//  most 7 rows and 18 columns, so the whole screen fits at every automatic GUI scale (at least 320 x 240).
//  Hoppers and other mods' pipes reach every slot from every side; comparators read how full they are.
// =====================================================================================
TS.CHESTS = {
    copper:    { name: "Copper Chest",    slots: 45,  cols: 9,  hardness: 3,  blast: 6,    sound: "copper",          map: "terracotta_orange" },
    iron:      { name: "Iron Chest",      slots: 54,  cols: 9,  hardness: 5,  blast: 6,    sound: "metal",           map: "metal" },
    gold:      { name: "Gold Chest",      slots: 81,  cols: 14, hardness: 3,  blast: 6,    sound: "metal",           map: "gold" },
    diamond:   { name: "Diamond Chest",   slots: 108, cols: 18, hardness: 5,  blast: 6,    sound: "metal",           map: "diamond" },
    crystal:   { name: "Crystal Chest",   slots: 108, cols: 18, hardness: 3,  blast: 6,    sound: "glass",           map: "none" },
    obsidian:  { name: "Obsidian Chest",  slots: 108, cols: 18, hardness: 12, blast: 1200, sound: "stone",           map: "color_black" },
    netherite: { name: "Netherite Chest", slots: 126, cols: 18, hardness: 12, blast: 1200, sound: "netherite_block", map: "color_black" },
    dirt:      { name: "Dirt Chest",      slots: 1,   cols: 1,  hardness: 0.5, blast: 0.5, sound: "rooted_dirt",     map: "dirt" }
};
TS.CHEST_ORDER = ["copper", "iron", "gold", "diamond", "crystal", "obsidian", "netherite", "dirt"];
TS.CRYSTAL_TAG = "ts_crystal";
TS.CRYSTAL_LOOK = 1;   // bump when the displays change, so chests already placed respawn theirs

// The screen for a chest's slots: a chest screen up to 6 rows of 9, else a panel sized to the grid.
TS.chestScreen = function (tier) {
    var c = TS.CHESTS[tier];
    if (tier === "dirt") {
        return { title: c.name, width: 176, height: 132, slots: [{ x: 80, y: 20 }], inventory: { x: 8, y: 50 } };
    }
    if (c.cols === 9 && c.slots <= 54) return { title: c.name, rows: c.slots / 9 };
    var rows = Math.ceil(c.slots / c.cols), slots = [];
    var width = Math.max(176, 14 + c.cols * 18);
    var gx = Math.floor((width - c.cols * 18) / 2) + 1;
    for (var i = 0; i < c.slots; i++) slots.push({ x: gx + (i % c.cols) * 18, y: 18 + Math.floor(i / c.cols) * 18 });
    var height = 18 + rows * 18 + 96;
    return { title: c.name, width: width, height: height, slots: slots,
             inventory: { x: Math.floor((width - 162) / 2) + 1, y: height - 82 } };
};

// Like a vanilla chest: the lid opens with the first player who opens the chest and closes when the last one leaves
// (the engine swings it, BlockDef.blockEntity.lid), and the sounds go with the lid. be.viewers counts the open screens.
TS.LIDS = RPG.platform.has("blockLid");

TS.openChest = function (player, x, y, z, tier) {
    var dim = player.dimension;
    var be = RPG.blocks.entityAt(dim, x, y, z);
    if (!be) return null;
    var spec = TS.chestScreen(tier);
    var openSound = tier === "dirt" ? "minecraft:block.rooted_dirt.place" : "minecraft:block.chest.open";
    var closeSound = tier === "dirt" ? "minecraft:block.rooted_dirt.break" : "minecraft:block.chest.close";
    // onClose runs once the closing player no longer counts
    spec.onClose = function () { if (!TS.LIDS || be.viewers === 0) TS.sound(dim, x, y, z, closeSound, 0.5, 0.9 + Math.random() * 0.1); };
    var first = !TS.LIDS || be.viewers === 0;
    var screen = be.open(player, spec);
    if (screen && first) TS.sound(dim, x, y, z, openSound, 0.5, 0.9 + Math.random() * 0.1);
    return screen;
};

// ---- crystal chest: the most plentiful items stand inside the glass ---------------------------------------------
// They are vanilla item display entities (tagged ts_crystal), so every loader and client draws them without client
// code. The chest checks its contents once a second and only touches the entities when the top items change.
TS.CRYSTAL_SPOTS = [[0.32, 0.22, 0.32], [0.68, 0.22, 0.32], [0.32, 0.22, 0.68], [0.68, 0.22, 0.68],
                    [0.32, 0.58, 0.32], [0.68, 0.58, 0.32], [0.32, 0.58, 0.68], [0.68, 0.58, 0.68]];

TS.crystalTop = function (be) {
    var counts = {}, order = [], items = be.items();
    for (var i = 0; i < items.length; i++) {
        var s = items[i];
        if (!s) continue;
        if (counts[s.id] === undefined) { counts[s.id] = 0; order.push(s.id); }
        counts[s.id] += s.count;
    }
    order.sort(function (a, b) { return counts[b] - counts[a]; });
    return order.slice(0, 8);
};

TS.crystalClear = function (dim, x, y, z) {
    var ids = RPG.world.entityIdsNear(dim, x + 0.5, y + 0.4, z + 0.5, 0.9, "minecraft:item_display", TS.CRYSTAL_TAG);
    for (var i = 0; i < ids.length; i++) RPG.world.removeEntity(ids[i]);
};

TS.crystalTick = function (be) {
    var d = be.data, top = TS.crystalTop(be), key = top.join(",");
    var dim = be.dimension, x = be.x, y = be.y, z = be.z;
    var near = RPG.world.entityIdsNear(dim, x + 0.5, y + 0.4, z + 0.5, 0.9, "minecraft:item_display", TS.CRYSTAL_TAG);
    if (key === (d.shown || "") && near.length === top.length && d.look === TS.CRYSTAL_LOOK) return;
    for (var i = 0; i < near.length; i++) RPG.world.removeEntity(near[i]);
    for (var k = 0; k < top.length; k++) {
        var p = TS.CRYSTAL_SPOTS[k];
        RPG.world.spawnEntity(dim, "minecraft:item_display", x + p[0], y + p[1], z + p[2],
            "{item:{id:\"" + top[k] + "\",Count:1b},item_display:\"ground\",billboard:\"vertical\",Tags:[\"" + TS.CRYSTAL_TAG + "\"]," +
            "brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]," +
            "translation:[0f,0f,0f],scale:[0.75f,0.75f,0.75f]}}");
    }
    d.shown = key; d.look = TS.CRYSTAL_LOOK;
    be.save();
};

// Displays left behind by a crystal chest that went some other way than a player breaking it (an explosion, a piston
// of another mod, /setblock): every 10 seconds, the tagged displays near players that have no crystal chest around them go.
RPG.every(200, function () {
    var crystal = TS.blocks.ts_crystal_chest;
    if (!crystal) return;
    var players = RPG.server.players();
    for (var i = 0; i < players.length; i++) {
        var p = players[i];
        var ids = RPG.world.entityIdsNear(p.dimension, p.x, p.y, p.z, 48, "minecraft:item_display", TS.CRYSTAL_TAG);
        for (var k = 0; k < ids.length; k++) {
            var e = RPG.world.entityByUuid(ids[k]);
            if (!e) continue;
            if (RPG.world.getBlock(e.dimension, Math.floor(e.x), Math.floor(e.y), Math.floor(e.z)) !== crystal) RPG.world.removeEntity(ids[k]);
        }
    }
});

// ---- the chest blocks --------------------------------------------------------------------------------------------
TS.CHEST_ORDER.forEach(function (tier) {
    var c = TS.CHESTS[tier];
    var key = "ts_" + tier + "_chest";
    var lore = ["&7" + c.slots + " slot" + (c.slots === 1 ? "" : "s")];
    if (tier === "crystal") lore.push("&7Shows its most plentiful items through the glass");
    if (c.blast >= 1200) lore.push("&7Blast resistant");
    if (tier === "dirt") lore.push("&7It's a chest. Made of dirt.");
    var be = { inventory: { size: c.slots } };
    if (tier === "crystal") {
        be.tickInterval = 20;
        be.onTick = TS.crystalTick;
    }
    // with lids the block draws the base and the engine the lid; the whole chest is the item (and the block without lids)
    if (TS.LIDS) be.lid = { model: TS.model(tier + "_chest_lid"), pivot: [8, 9, 15], axis: "x", angle: 90, ticks: 10 };
    var def = {
        family: "horizontal", name: c.name, model: TS.model(tier + (TS.LIDS ? "_chest_base" : "_chest")),
        itemModel: TS.model(tier + "_chest"),
        shape: [1, 0, 1, 15, 14, 15], solid: false, renderType: tier === "crystal" ? "translucent" : "cutout",
        hardness: c.hardness, explosionResistance: c.blast, tool: tier === "dirt" ? "shovel" : "pickaxe",
        sound: c.sound, mapColor: c.map, drops: "self", lore: lore,
        blockEntity: be,
        onUse: function (player, x, y, z) {
            if (TS.tryChestUpgrade && TS.tryChestUpgrade(player, x, y, z)) return;
            TS.openChest(player, x, y, z, tier);
        }
    };
    if (tier === "crystal") def.onBreak = function (player, x, y, z) { TS.crystalClear(player.dimension, x, y, z); };
    TS.chestByBlock[TS.block(key, def)] = tier;
});
