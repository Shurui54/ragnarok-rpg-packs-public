# Upgraded Chests & Furnaces

An official addon for the Ragnarok Modding Toolkit: chests that hold more by tier, and furnaces, blast furnaces and
smokers that work faster by tier, with upgrade kits that turn a placed block into the next tier without emptying it.
Turn it on per world in the Addon Manager or with `/rpg addons enable tiered_storage`. No restart needed.

All content (names, art, code and numbers) is this addon's own. Works the same on Forge, NeoForge and Fabric.

## Chests

| Chest | Slots | Screen | Recipe (around the center) | Notes |
|---|---|---|---|---|
| Copper Chest | 45 | 5 rows | 8 copper ingots around a chest | |
| Iron Chest | 54 | 6 rows | 8 iron ingots around a chest or a Copper Chest | |
| Gold Chest | 81 | 14 wide, 6 rows | 8 gold ingots around an Iron Chest | |
| Diamond Chest | 108 | 18 x 6 | glass row, diamond + Gold Chest + diamond, glass row | |
| Crystal Chest | 108 | 18 x 6 | 8 glass around a Diamond Chest | its 8 most plentiful items stand inside the glass |
| Obsidian Chest | 108 | 18 x 6 | 8 obsidian around a Diamond Chest | blast resistant |
| Netherite Chest | 126 | 18 x 7 | smithing table: netherite upgrade template + Diamond, Crystal or Obsidian Chest + netherite ingot | blast resistant |
| Dirt Chest | 1 | 1 slot | 8 dirt around a chest | it's a chest, made of dirt |

The big chests' screens are wide rather than tall (at most 7 rows), so they fit on screen at every automatic GUI
scale. Chests open with a right-click, and like a vanilla chest the lid swings open while anyone has the chest open
(engine 0.30.1 or newer). They drop themselves and everything in them when broken. Hoppers and other mods'
pipes reach every slot from every side, and a comparator reads how full a chest is.

## Furnaces, blast furnaces and smokers

Every tier comes as a furnace, a blast furnace and a smoker. Each runs the vanilla block of its kind faster: fuel
burns faster by the same factor, so a piece of coal still smelts 8 items in a furnace (and 4 in a blast furnace or
smoker, like vanilla). They burn whatever vanilla burns (other mods' fuels too), and only smelt what the vanilla block
of their kind takes: a blast furnace only blasting recipes (ores, raw metals, metal tools), a smoker only smoking
recipes (food), from the game itself, data packs and other mods alike.

| Tier | Speed | Furnace, per item | Blast furnace / smoker, per item | Recipe |
|---|---|---|---|---|
| Copper | 1.11x | 9 s | 4.5 s | 8 copper ingots around the vanilla block |
| Iron | 1.25x | 8 s | 4 s | 8 iron ingots around the vanilla block or the copper one |
| Gold | 1.67x | 6 s | 3 s | 8 gold ingots around the iron one |
| Diamond | 2.5x | 4 s | 2 s | glass in the corners, diamonds on the sides, the gold one in the middle |
| Emerald | 5x | 2 s | 1 s | 8 emeralds around the diamond one |
| Obsidian | 6.67x | 1.5 s | 0.75 s | 8 obsidian around the emerald one (blast resistant) |
| Crystal | 10x | 1 s | 0.5 s | glass in the corners, amethyst shards on the sides, the obsidian one in the middle |
| Netherite | 40x | 0.25 s | 0.125 s | smithing table: netherite upgrade template + the crystal one + netherite ingot (blast resistant) |

A tier's blast furnace or smoker can also be made from that tier's furnace the way vanilla makes them (5 iron ingots
and 3 smooth stone for a blast furnace, 4 logs for a smoker).

The screens are the vanilla furnace, blast furnace and smoker screens, with the flame and the arrow. Hoppers work
like vanilla: items from above go into the input, from the sides into the fuel slot, and a hopper below takes the
output. A lava bucket leaves its bucket behind. The front lights up and glows while it burns, and the experience of
what it smelted goes to the next player who takes from the output, like vanilla.

## Upgrade kits

Right-click a placed chest or furnace with a kit to turn it into the next tier where it stands. Everything inside
stays, the block keeps facing the same way, and a furnace keeps its burning fuel and its cooking progress.

| Chest kit | Turns | Recipe |
|---|---|---|
| Wooden to Copper | a (single) wooden chest into a Copper Chest | 8 copper ingots around any planks |
| Wooden to Iron | a wooden chest into an Iron Chest | 8 iron ingots around any planks |
| Copper to Iron | a Copper Chest into an Iron Chest | 8 iron ingots around a copper ingot |
| Iron to Gold | an Iron Chest into a Gold Chest | 8 gold ingots around an iron ingot |
| Gold to Diamond | a Gold Chest into a Diamond Chest | glass row, diamond + gold ingot + diamond, glass row |
| Diamond to Crystal | a Diamond Chest into a Crystal Chest | 8 glass around an amethyst shard |
| Diamond to Obsidian | a Diamond Chest into an Obsidian Chest | 8 obsidian around glass |
| Diamond to Netherite | a Diamond, Crystal or Obsidian Chest into a Netherite Chest | netherite upgrade template + netherite ingot + obsidian |

| Furnace kit | Turns (furnace, blast furnace or smoker, which it stays) | Recipe |
|---|---|---|
| Copper | a vanilla one into the copper one | 8 copper ingots around cobblestone |
| Iron | a vanilla or copper one into the iron one | 8 iron ingots around cobblestone |
| Gold | an iron one into the gold one | 8 gold ingots around cobblestone |
| Diamond | a gold one into the diamond one | glass in the corners, diamonds on the sides, cobblestone in the middle |
| Emerald | a diamond one into the emerald one | 8 emeralds around cobblestone |
| Obsidian | an emerald one into the obsidian one | 8 obsidian around cobblestone |
| Crystal | an obsidian one into the crystal one | glass in the corners, amethyst shards on the sides, cobblestone in the middle |
| Netherite | a crystal one into the netherite one | netherite upgrade template + netherite ingot + cobblestone |

On this addon's own chests and furnaces a plain right-click with a kit upgrades them; on vanilla chests and furnaces
(which open on a right-click) sneak and right-click. Land claims and other protection are honoured.

## Notes

- Ticks per item follow the vanilla recipe type's usual time (200 for smelting, 100 for blasting and smoking) divided
  by the tier's speed. A furnace works in steps of 5 ticks and catches up within each step, so even the netherite
  tier costs one script call per 5 ticks per furnace, and an idle one almost nothing.
- The experience per item follows vanilla's recipes for the vanilla results (ores, food, glass...); other results
  give 0.1 each.
- Crystal Chest items are vanilla item displays inside the glass, so every client draws them with no client code;
  they update only when the most plentiful items change.
