// =====================================================================================
//  WorldEdit (client): draws your selection in the world. Position 1 red, position 2
//  blue, the whole box purple. Settings: config worldedit showOutline / outlineGrid.
// =====================================================================================
var WE_CLIENT_SEL = null;

function weDrawSel() {
    RPG.world.removeBox("we_sel");
    RPG.world.removeBox("we_p1");
    RPG.world.removeBox("we_p2");
    let s = WE_CLIENT_SEL;
    if (!s || s.hide || !RPG.config.get("worldedit", "showOutline", true) || s.dim !== RPG.player.dimension) return;
    if (s.p1) RPG.world.box("we_p1", s.p1[0], s.p1[1], s.p1[2], s.p1[0], s.p1[1], s.p1[2], "#FF4444", { alpha: 1 });
    if (s.p2) RPG.world.box("we_p2", s.p2[0], s.p2[1], s.p2[2], s.p2[0], s.p2[1], s.p2[2], "#4488FF", { alpha: 1 });
    if (s.p1 && s.p2)
        RPG.world.box("we_sel", s.p1[0], s.p1[1], s.p1[2], s.p2[0], s.p2[1], s.p2[2], "#CC66FF",
            { alpha: 0.9, grid: RPG.config.get("worldedit", "outlineGrid", 0) });
}

RPG.on("load", () => weDrawSel());
RPG.net.on("we_sel", (d) => { WE_CLIENT_SEL = d; weDrawSel(); });
RPG.on("config", (name) => { if (name === "worldedit") weDrawSel(); });

// hide it in other dimensions
var WE_LAST_DIM = "";
RPG.on("tick", () => {
    let d = RPG.player.dimension;
    if (d !== WE_LAST_DIM) { WE_LAST_DIM = d; weDrawSel(); }
});
