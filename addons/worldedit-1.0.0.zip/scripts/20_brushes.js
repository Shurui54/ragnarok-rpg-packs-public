// =====================================================================================
//  WorldEdit - brushes and tools bound to the item in your hand
//    /brush sphere <pattern> [radius] [-h]        /brush cylinder <pattern> [radius] [height] [-h]
//    /brush set <shape> [radius] <pattern>         /brush smooth [radius] [iterations]
//    /brush gravity [radius]                       /brush clipboard [-a] [-o]
//    /brush extinguish [radius]                    /brush butcher [radius] [flags]
//    /brush forest [shape] [radius] [density] [type]   /brush snow [shape] [radius] [-s]
//    /brush none          /size /mat /range /mask  (settings of the held brush)
//    /tool none|info|repl|tree|farwand|selwand|navwand|floodfill|lrbuild
//  Brushes apply at once (a few ms) and the rest finishes in the background; //undo works.
// =====================================================================================
WE_CAT = "Brushes & tools";

function weBrushes(p) { return p.getVar("we_brushes", {}) || {}; }
function weBrushSave(p, all) { p.setVar("we_brushes", all); }

function weMerge(a, b) { Object.keys(b).forEach((k) => { a[k] = b[k]; }); return a; }
function weBrushOpts(p, b) {
    let o = { now: 8, progress: false, label: "Brush", limit: weLimit(p) };
    let g = p.getVar("we_gmask", "") || "";
    let m = [g, b.mask || ""].filter((x) => x).join(" ");
    if (m) o.mask = m;
    return o;
}

/** Uses the brush bound to `item`, if any. Returns true when one was used (or refused). */
function weBrushUse(p, item) {
    let b = weBrushes(p)[item];
    if (!b || b.tool) return false;
    if (!RPG.perms.has(p, "worldedit.brush.use")) return false;
    let at = p.lookBlock(b.range || WE_CFG.get("brushRange"));
    if (!at) { p.actionbar("&cNo block in range."); return true; }
    let x = at[0], y = at[1], z = at[2], r = b.r, o = weBrushOpts(p, b);
    let cube = { type: "cuboid", x1: x - r, y1: y - r, z1: z - r, x2: x + r, y2: y + r, z2: z + r };
    let shape = (s) => s === "cuboid" || s === "cube" ? cube : s === "cylinder" || s === "cyl"
        ? { type: "cylinder", x: x, y: y - Math.floor(r), z: z, r: r, h: 2 * Math.floor(r) + 1 } : { type: "sphere", x: x, y: y, z: z, r: r };
    try {
        if (b.type === "sphere") RPG.edit.set(p, p.dimension, { type: "sphere", x: x, y: y, z: z, r: r, hollow: !!b.hollow }, b.pattern, o);
        else if (b.type === "cyl") RPG.edit.set(p, p.dimension, { type: "cylinder", x: x, y: y - Math.floor((b.h || 1) / 2), z: z, r: r, h: b.h || 1, hollow: !!b.hollow }, b.pattern, o);
        else if (b.type === "set") RPG.edit.set(p, p.dimension, shape(b.shape), b.pattern, o);
        else if (b.type === "smooth") RPG.edit.smooth(p, p.dimension, cube, b.it || 2, o);
        else if (b.type === "gravity") RPG.edit.gravity(p, p.dimension, cube, o);
        else if (b.type === "extinguish") RPG.edit.replace(p, p.dimension, { type: "sphere", x: x, y: y, z: z, r: r }, "fire,soul_fire", "air", o);
        else if (b.type === "snow") RPG.edit.snow(p, p.dimension, shape(b.shape), weMerge(o, { stack: !!b.stack }));
        else if (b.type === "forest") RPG.edit.forest(p, p.dimension, shape(b.shape), b.tree || "tree", b.density, o);
        else if (b.type === "butcher") p.actionbar("&d" + weButcher(p, x, y, z, r, b.flags || "") + " killed");
        else if (b.type === "clipboard") {
            let c = RPG.edit.clipboard(p);
            if (!c) { p.actionbar("&cYour clipboard is empty."); return true; }
            let px = x, py = y, pz = z;
            if (!b.origin) { px = x - c.offsetX - Math.floor(c.width / 2); py = y - c.offsetY; pz = z - c.offsetZ - Math.floor(c.length / 2); }
            let max = WE_CFG.get("maxClipboard"), unl = RPG.perms.has(p, "worldedit.limit.unlimited");
            if (!unl && c.width * c.height * c.length > max) { p.actionbar("&cClipboard too big to paste."); return true; }
            o.skipAir = !!b.skipAir;
            o.limit = unl ? 0 : max;
            RPG.edit.paste(p, p.dimension, px, py, pz, o);
        }
    } catch (e) { weErr(p, String(e && e.message ? e.message : e)); }
    return true;
}

function weBrushSize(p, v, d) {
    let r = v === undefined ? d : Number(v);
    if (isNaN(r) || r < 0) throw new Error("Bad size: " + v);
    let max = WE_CFG.get("maxBrushSize");
    if (r > max && !RPG.perms.has(p, "worldedit.limit.unlimited")) throw new Error("Brush too big (max " + max + ")");
    return r;
}
function weHeldForTool(p) {
    let item = p.getHeldItem();
    if (item === "minecraft:air") throw new Error("Hold the item to bind it to.");
    if (item === WE_CFG.get("wand")) throw new Error("That's the selection wand; hold something else.");
    return item;
}
var WE_SHAPES = ["sphere", "cylinder", "cuboid"];
function weShapeArg(args) {
    let s = String(args[0] || "").toLowerCase();
    if (s === "cyl") s = "cylinder";
    if (s === "cube") s = "cuboid";
    if (WE_SHAPES.indexOf(s) >= 0) { args.shift(); return s; }
    return "sphere";
}
var WE_BRUSH_TYPES = ["sphere", "cylinder", "set", "smooth", "gravity", "clipboard", "extinguish", "butcher", "forest", "snow", "none"];

weCmd("brush", { desc: "Bind a brush to your held item: //brush sphere|cylinder|set|smooth|gravity|clipboard|extinguish|butcher|forest|snow|none",
    perm: "brush", aliases: ["br", "/brush", "/br"],
    suggest: (p, a) => a.length <= 1 ? WE_BRUSH_TYPES : (a[0] === "forest" && a.length >= 4) ? weTreeTypes() : [] }, (p, args) => {
    let item = weHeldForTool(p);
    let type = String(args.shift() || "").toLowerCase(), all = weBrushes(p), hollow = weFlag(args, "-h"), b;
    let need = (n) => { if (!RPG.perms.has(p, "worldedit.brush." + n)) throw new Error("You don't have permission (worldedit.brush." + n + ")."); };
    if (type === "none" || type === "unbind") { delete all[item]; weBrushSave(p, all); weMsg(p, "&7Brush removed from " + item + "."); return; }
    if (type === "sphere" || type === "s") {
        need("sphere");
        if (!args[0]) throw new Error("Use: //brush sphere <pattern> [radius] [-h]");
        RPG.edit.checkPattern(args[0]);
        b = { type: "sphere", pattern: args[0], r: weBrushSize(p, args[1], 2), hollow: hollow };
    } else if (type === "cylinder" || type === "cyl" || type === "c") {
        need("cylinder");
        if (!args[0]) throw new Error("Use: //brush cylinder <pattern> [radius] [height] [-h]");
        RPG.edit.checkPattern(args[0]);
        b = { type: "cyl", pattern: args[0], r: weBrushSize(p, args[1], 2), h: Math.max(1, Math.floor(Number(args[2])) || 1), hollow: hollow };
    } else if (type === "set") {
        need("set");
        let shape = weShapeArg(args);
        let r = !isNaN(Number(args[0])) ? weBrushSize(p, args.shift(), 2) : 2;
        if (!args[0]) throw new Error("Use: //brush set <sphere|cylinder|cuboid> [radius] <pattern>");
        RPG.edit.checkPattern(args[0]);
        b = { type: "set", shape: shape, r: r, pattern: args[0] };
    } else if (type === "smooth") {
        need("smooth");
        b = { type: "smooth", r: weBrushSize(p, args[0], 3), it: Math.max(1, Math.min(10, Math.floor(Number(args[1])) || 2)) };
    } else if (type === "gravity" || type === "grav") {
        need("gravity");
        b = { type: "gravity", r: weBrushSize(p, args[0], 4) };
    } else if (type === "clipboard" || type === "copy") {
        need("clipboard");
        if (!RPG.edit.clipboard(p)) throw new Error("Your clipboard is empty (//copy first).");
        b = { type: "clipboard", r: 0, skipAir: weFlag(args, "-a"), origin: weFlag(args, "-o") };
    } else if (type === "extinguish" || type === "ex") {
        need("ex");
        b = { type: "extinguish", r: weBrushSize(p, args[0], 5) };
    } else if (type === "butcher" || type === "kill") {
        need("butcher");
        let flags = args.filter((a) => a.charAt(0) === "-").join(" ");
        b = { type: "butcher", r: weBrushSize(p, args.filter((a) => a.charAt(0) !== "-")[0], 5), flags: flags };
    } else if (type === "forest") {
        need("forest");
        let shape = weShapeArg(args);
        b = { type: "forest", shape: shape, r: weBrushSize(p, args[0], 5), density: weDensity(args[1], 5), tree: args[2] || "tree" };
        weTreeCheck(b.tree);
    } else if (type === "snow") {
        need("snow");
        let stack = weFlag(args, "-s"), shape = weShapeArg(args);
        b = { type: "snow", shape: shape, r: weBrushSize(p, args[0], 5), stack: stack };
    } else throw new Error("Use: //brush " + WE_BRUSH_TYPES.join("|"));
    if (all[item] && all[item].mask) b.mask = all[item].mask;
    if (all[item] && all[item].range) b.range = all[item].range;
    all[item] = b;
    weBrushSave(p, all);
    weMsg(p, "&d" + b.type + " brush bound to &f" + item + "&d. Right-click to use it.");
});

/** The brush in hand, for /size /mat /range /mask. */
function weHeldBrush(p) {
    let item = p.getHeldItem(), all = weBrushes(p);
    if (!all[item]) throw new Error("No brush or tool on this item (/brush or /tool first).");
    return { item: item, all: all, b: all[item] };
}
weCmd("/size", { desc: "Radius of the held brush: /size <radius>", perm: "brush.options.size" }, (p, args) => {
    let h = weHeldBrush(p);
    h.b.r = weBrushSize(p, args[0], h.b.r);
    weBrushSave(p, h.all);
    weMsg(p, "&dBrush size: &f" + h.b.r);
});
weCmd("/material", { desc: "Pattern of the held brush: /mat <pattern>", perm: "brush.options.material", aliases: ["/mat"] }, (p, args) => {
    let h = weHeldBrush(p);
    if (!args.length) throw new Error("Use: /mat <pattern>");
    RPG.edit.checkPattern(args[0]);
    h.b.pattern = args[0];
    weBrushSave(p, h.all);
    weMsg(p, "&dBrush material: &f" + args[0]);
});
weCmd("/range", { desc: "How far the held brush reaches: /range <blocks>", perm: "brush.options.range" }, (p, args) => {
    let h = weHeldBrush(p), n = Math.floor(Number(args[0]));
    if (isNaN(n) || n < 1) throw new Error("Use: /range <blocks>");
    h.b.range = Math.min(n, 512);
    weBrushSave(p, h.all);
    weMsg(p, "&dBrush range: &f" + h.b.range);
});
weCmd("mask", { desc: "Mask of the held brush: /mask [mask]  (no mask = clear)", perm: "brush.options.mask", aliases: ["/mask"] }, (p, args) => {
    let h = weHeldBrush(p);
    let m = args.join(" ").trim();
    if (m) RPG.edit.checkMask(m);
    h.b.mask = m || undefined;
    weBrushSave(p, h.all);
    weMsg(p, m ? "&dBrush mask set: &f" + m : "&7Brush mask cleared.");
});

// ---- tools -------------------------------------------------------------------------------------
var WE_TOOLS = ["none", "info", "repl", "tree", "farwand", "selwand", "navwand", "floodfill", "lrbuild"];
weCmd("/tool", { desc: "Bind a tool to your held item: /tool none|info|repl <pattern>|tree [type]|farwand|selwand|navwand|floodfill <pattern> <range>|lrbuild <left> <right>",
    perm: "tool", suggest: (p, a) => a.length <= 1 ? WE_TOOLS : a[0] === "tree" ? weTreeTypes() : [] }, (p, args) => {
    let item = weHeldForTool(p), all = weBrushes(p), type = String(args[0] || "").toLowerCase(), t;
    if (!RPG.perms.has(p, "worldedit.tool." + (type === "none" ? "none" : type))) throw new Error("You don't have permission (worldedit.tool." + type + ").");
    if (type === "none") { delete all[item]; weBrushSave(p, all); weMsg(p, "&7Tool removed from " + item + "."); return; }
    if (type === "info") t = { tool: "info" };
    else if (type === "repl") {
        if (!args[1]) throw new Error("Use: /tool repl <pattern>");
        RPG.edit.checkPattern(args[1]);
        t = { tool: "repl", pattern: args[1] };
    } else if (type === "tree") {
        let tree = args[1] || "tree";
        weTreeCheck(tree);
        t = { tool: "tree", tree: tree };
    } else if (type === "farwand" || type === "selwand" || type === "navwand") t = { tool: type };
    else if (type === "floodfill" || type === "flood") {
        if (!args[1]) throw new Error("Use: /tool floodfill <pattern> <range>");
        RPG.edit.checkPattern(args[1]);
        t = { tool: "floodfill", pattern: args[1], range: Math.max(1, Math.min(WE_CFG.get("maxRadius"), Math.floor(Number(args[2])) || 5)) };
    } else if (type === "lrbuild") {
        if (args.length < 3) throw new Error("Use: /tool lrbuild <left-click pattern> <right-click pattern>");
        RPG.edit.checkPattern(args[1]); RPG.edit.checkPattern(args[2]);
        t = { tool: "lrbuild", left: args[1], right: args[2] };
    } else throw new Error("Use: /tool " + WE_TOOLS.join("|") + "  (deltree, cycler and stacker aren't available)");
    all[item] = t;
    weBrushSave(p, all);
    weMsg(p, "&d" + type + " tool bound to &f" + item + "&d.");
});

/** The block next to (x, y, z) on `face` ("up", "north"...). */
function weBeside(x, y, z, face) {
    let d = WE_DIRS[String(face || "up").toLowerCase()] || [0, 1, 0];
    return [x + d[0], y + d[1], z + d[2]];
}
function weOneBlock(at) { return { type: "cuboid", x1: at[0], y1: at[1], z1: at[2], x2: at[0], y2: at[1], z2: at[2] }; }

/** Tools: button "left"/"right" on a block, or "air" (right-click in the air). True when handled. */
function weToolClick(p, button, item, x, y, z, face) {
    let t = weBrushes(p)[item];
    if (!t || !t.tool) return false;
    if (!RPG.perms.has(p, "worldedit.tool.use")) return false;
    let range = WE_CFG.get("brushRange");
    let far = () => p.lookBlock(range);
    let target = button === "air" ? far() : [x, y, z];
    try {
        switch (t.tool) {
            case "info":
                if (button === "left") return false;
                if (!target) { p.actionbar("&cNo block in range."); return true; }
                weMsg(p, "&d@(" + target.join(", ") + ") &f" + RPG.world.getBlockState(p.dimension, target[0], target[1], target[2]));
                return true;
            case "repl":
                if (!target) { p.actionbar("&cNo block in range."); return true; }
                if (button === "left") {
                    t.pattern = RPG.world.getBlockState(p.dimension, target[0], target[1], target[2]);
                    let all = weBrushes(p); all[item] = t; weBrushSave(p, all);
                    weMsg(p, "&dReplacer tool now places &f" + t.pattern);
                } else RPG.edit.set(p, p.dimension, weOneBlock(target), t.pattern, weBrushOpts(p, t));
                return true;
            case "tree":
                if (button === "left" || !target) return false;
                RPG.edit.forest(p, p.dimension, { type: "cuboid", x1: target[0], y1: target[1], z1: target[2], x2: target[0], y2: target[1] + 1, z2: target[2] },
                    t.tree, 1, weBrushOpts(p, t)).then((tk) => { if (!tk.error && !tk.changed) p.actionbar("&cA tree can't grow there."); });
                return true;
            case "selwand":
                if (button === "air") return false;
                weSetPos(p, button === "left" ? "p1" : "p2", x, y, z);
                return true;
            case "farwand": {
                let at = far();
                if (!at) { p.actionbar("&cNo block in range."); return true; }
                weSetPos(p, button === "left" ? "p1" : "p2", at[0], at[1], at[2]);
                return true;
            }
            case "navwand":
                if (button === "left") { if (!weJumpTo(p, 300)) p.actionbar("&cNo block in sight."); }
                else { let at = weThru(p); if (at) weGo(p, at[0] + 0.5, at[1], at[2] + 0.5, ""); else p.actionbar("&cNothing to pass through."); }
                return true;
            case "floodfill": {
                if (button === "left" || !target) return false;
                let st = RPG.world.getBlockState(p.dimension, target[0], target[1], target[2]);
                RPG.edit.fill(p, p.dimension, target[0], target[1], target[2], t.pattern,
                    weMerge(weBrushOpts(p, t), { radius: t.range, depth: t.range, recursive: true, up: true, through: st }));
                return true;
            }
            case "lrbuild": {
                let pat = button === "left" ? t.left : t.right;
                let hit = button === "air" ? far() : [x, y, z];
                if (!hit) { p.actionbar("&cNo block in range."); return true; }
                let f = face;
                if (!f) {   // far click: the face toward you
                    let d = [p.x - hit[0] - 0.5, p.y + 1.6 - hit[1] - 0.5, p.z - hit[2] - 0.5], a = d.map(Math.abs), i = a.indexOf(Math.max(a[0], a[1], a[2]));
                    f = i === 0 ? (d[0] > 0 ? "east" : "west") : i === 1 ? (d[1] > 0 ? "up" : "down") : (d[2] > 0 ? "south" : "north");
                }
                let at = /^(minecraft:)?(air|cave_air|void_air)$/.test(pat) ? hit : weBeside(hit[0], hit[1], hit[2], f);
                RPG.edit.set(p, p.dimension, weOneBlock(at), pat, weBrushOpts(p, t));
                return true;
            }
        }
    } catch (e) { weErr(p, String(e && e.message ? e.message : e)); return true; }
    return false;
}
