// =====================================================================================
//  WorldEdit - settings, permissions, selection and shared helpers
// =====================================================================================
//  Commands are typed like WorldEdit: //set stone, //copy, //paste ... (also /rpgc /set ...).
//  Each needs the node "worldedit.<command>" (e.g. worldedit.set). Operators have them all;
//  give builders the "builder" group:  /rpg perm user Steve group add builder
//  The heavy lifting is the engine's RPG.edit (fast chunk writes, a few ms per tick).
// =====================================================================================

var WE_CFG = RPG.config.define("worldedit", {
    wand:          { default: "minecraft:wooden_axe", comment: "Selection wand: left-click = position 1, right-click = position 2" },
    navWand:       { default: "minecraft:compass", comment: "Navigation wand (//wand -n): left-click = /jumpto, right-click = /thru" },
    butcherRadius: { default: 100, min: 1, max: 1000, integer: true, comment: "Radius /butcher and /remove use when none is given" },
    platform:      { default: "minecraft:glass", comment: "Block /up and /ceil put under you when there is nothing to stand on" },
    maxBlocks:     { default: 5000000, min: 1, integer: true, comment: "Most blocks one edit may change (worldedit.limit.unlimited ignores this)" },
    maxClipboard:  { default: 4000000, min: 1, integer: true, comment: "Most blocks a copy/paste/schematic may hold" },
    maxRadius:     { default: 100, min: 1, max: 1000, integer: true, comment: "Largest radius for //sphere, //cyl, //drain..." },
    maxBrushSize:  { default: 12, min: 1, max: 64, integer: true, comment: "Largest brush radius" },
    brushRange:    { default: 200, min: 8, max: 512, integer: true, comment: "How far brushes reach" },
    budgetMs:      { default: 12, min: 1, max: 45, comment: "Server time per tick for edits (all players together)" },
    maxUndo:       { default: 30, min: 0, max: 1000, integer: true, comment: "Undo steps kept per player" },
    maxHistoryMB:  { default: 96, min: 1, comment: "Undo memory per player (compressed)" },
    showOutline:   { default: true, client: true, comment: "Draw the selection box in the world" },
    outlineGrid:   { default: 0, min: 0, max: 64, integer: true, client: true, comment: "Grid lines on the selection every N blocks (0 = none)" }
});

function weApplySettings() {
    RPG.edit.settings({ budgetMs: WE_CFG.get("budgetMs"), maxUndo: WE_CFG.get("maxUndo"), maxHistoryMB: WE_CFG.get("maxHistoryMB") });
}
weApplySettings();
WE_CFG.onChange(() => weApplySettings());

RPG.perms.group("builder", ["worldedit.*"]);

var WE_PREFIX = "&5[&dWE&5] &r";
function weMsg(p, t) { if (p) p.tell(WE_PREFIX + t); }
function weErr(p, t) { if (p) p.tell(WE_PREFIX + "&c" + t); }
function weNum(n) { return Math.round(Number(n) || 0).toLocaleString(); }

/** Limit for this player's edits (blocks, 0 = none): the config's maxBlocks, or lower with //limit. */
function weLimit(p) {
    let own = Number(p.getVar("we_limit", -1));
    if (RPG.perms.has(p, "worldedit.limit.unlimited")) return own > 0 ? own : 0;
    let max = WE_CFG.get("maxBlocks");
    return own > 0 ? Math.min(own, max) : max;
}

/** Every command, for //help: {typed, aliases, desc, perm, cat}. */
var WE_CMDS = [];
var WE_CAT = "General";

/**
 * Registers a WorldEdit command guarded by worldedit.<perm>. `name` is typed form ("/up", "//set") or a bare name
 * ("set" = "//set"); aliases likewise ("//1", "/asc", or bare = "//" + it).
 */
function weCmd(name, opts, run) {
    let typed = name.charAt(0) === "/" ? name : "//" + name;
    let als = (opts.aliases || []).map((a) => a.charAt(0) === "/" ? a : "//" + a);
    let bare = typed.replace(/^\/+/, "");
    WE_CMDS.push({ typed: typed, aliases: als, desc: opts.desc || "", perm: "worldedit." + (opts.perm || bare), cat: opts.cat || WE_CAT });
    RPG.commands.register(typed.substring(1), {
        root: true,
        aliases: als.map((a) => a.substring(1)),
        description: opts.desc || "",
        permission: "worldedit." + (opts.perm || bare),
        suggest: opts.suggest || (() => []),
        run(p, args) {
            if (!p) return;
            try { run(p, args); }
            catch (e) { weErr(p, String(e && e.message ? e.message : e).replace(/^.*Exception: /, "")); }
        }
    });
}

/** Reports a running edit when it ends. */
function weTask(p, task, what) {
    task.then((t) => {
        if (t.error) { weErr(p, t.error); return; }
        if (t.cancelled) { weMsg(p, "&e" + what + " cancelled after " + weNum(t.changed) + " blocks (undo still works)."); return; }
        if (what) weMsg(p, "&a" + what + ": &f" + weNum(t.changed) + "&a blocks changed &7(" + t.seconds.toFixed(2) + "s)");
    });
    return task;
}

// ---- directions -------------------------------------------------------------------------
var WE_DIRS = {
    north: [0, 0, -1], south: [0, 0, 1], east: [1, 0, 0], west: [-1, 0, 0], up: [0, 1, 0], down: [0, -1, 0],
    n: [0, 0, -1], s: [0, 0, 1], e: [1, 0, 0], w: [-1, 0, 0], u: [0, 1, 0], d: [0, -1, 0]
};
/** A direction word or the way the player looks ("me", "forward", none). */
function weDir(p, word) {
    let w = String(word || "me").toLowerCase();
    if (WE_DIRS[w]) return WE_DIRS[w];
    if (w === "back" || w === "backward" || w === "behind") { let f = weDir(p, "me"); return [-f[0], -f[1], -f[2]]; }
    if (p.pitch < -50) return [0, 1, 0];
    if (p.pitch > 50) return [0, -1, 0];
    let yaw = ((p.yaw % 360) + 360) % 360;
    if (yaw >= 45 && yaw < 135) return [-1, 0, 0];
    if (yaw >= 135 && yaw < 225) return [0, 0, -1];
    if (yaw >= 225 && yaw < 315) return [1, 0, 0];
    return [0, 0, 1];
}
function weIsDir(w) { return w !== undefined && (WE_DIRS[String(w).toLowerCase()] || ["me", "forward", "back", "backward", "behind"].indexOf(String(w).toLowerCase()) >= 0); }

// ---- selection ---------------------------------------------------------------------------
var WE_SEL = {};
function weSel(p) {
    let s = WE_SEL[p.uuid];
    if (!s) { s = p.getVar("we_sel", null) || {}; WE_SEL[p.uuid] = s; }
    return s;
}
function weSendSel(p) {
    let s = weSel(p);
    RPG.net.send(p, "we_sel", { dim: s.dim || "", p1: s.p1 || null, p2: s.p2 || null, hide: !!p.getVar("we_nodraw", false) });
}
function weSetPos(p, which, x, y, z) {
    let s = weSel(p);
    if (s.dim && s.dim !== p.dimension) { s.p1 = null; s.p2 = null; }
    s.dim = p.dimension;
    let at = [Math.floor(x), Math.floor(y), Math.floor(z)];
    if (s.mode === "extend") {
        // extend: position 1 starts a new box on that block, position 2 grows the box to take the block in
        if (which === "p1" || !s.p1 || !s.p2) { s.p1 = at; s.p2 = at.slice(); }
        else {
            let lo = [0, 1, 2].map((i) => Math.min(s.p1[i], s.p2[i], at[i])), hi = [0, 1, 2].map((i) => Math.max(s.p1[i], s.p2[i], at[i]));
            s.p1 = lo; s.p2 = hi;
        }
        p.setVar("we_sel", s);
        weSendSel(p);
        weMsg(p, "&d" + (which === "p1" ? "Started selection at" : "Extended selection to") + " &f(" + at.join(", ") + ") &7(" + weNum(RPG.edit.volume(weRegionOrNull(p))) + " blocks)");
        return;
    }
    s[which] = at;
    p.setVar("we_sel", s);
    weSendSel(p);
    let r = weRegionOrNull(p);
    weMsg(p, "&d" + (which === "p1" ? "First" : "Second") + " position &f(" + s[which].join(", ") + ")" + (r ? " &7(" + weNum(RPG.edit.volume(r)) + " blocks)" : ""));
}
/** The cuboid selection as an RPG.edit region, or null. */
function weRegionOrNull(p) {
    let s = weSel(p);
    if (!s.p1 || !s.p2 || s.dim !== p.dimension) return null;
    return { type: "cuboid", x1: s.p1[0], y1: s.p1[1], z1: s.p1[2], x2: s.p2[0], y2: s.p2[1], z2: s.p2[2] };
}
function weRegion(p) {
    let r = weRegionOrNull(p);
    if (!r) throw new Error("Make a selection first (wand: " + WE_CFG.get("wand") + ", or //pos1 and //pos2).");
    return r;
}
function weSaveSel(p, r) {
    let s = weSel(p);
    s.dim = p.dimension;
    s.p1 = [r.x1, r.y1, r.z1]; s.p2 = [r.x2, r.y2, r.z2];
    p.setVar("we_sel", s);
    weSendSel(p);
}
/** Options for an edit: the player's limit and global mask (//gmask) plus `extra` (a mask there is combined). */
function weOpts(p, extra) {
    let o = { limit: weLimit(p) };
    let g = p.getVar("we_gmask", "") || "";
    if (extra) Object.keys(extra).forEach((k) => { o[k] = extra[k]; });
    if (g) o.mask = o.mask ? g + " " + o.mask : g;
    return o;
}
/** Removes a flag ("-a") from args; also finds it inside combined flags ("-as"). */
function weFlag(args, f) {
    let i = args.indexOf(f);
    if (i >= 0) { args.splice(i, 1); return true; }
    let c = f.charAt(1);
    for (let k = 0; k < args.length; k++) {
        let a = args[k];
        if (/^-[a-z]{2,}$/.test(a) && a.indexOf(c) > 0) { args[k] = a.replace(c, ""); if (args[k] === "-") args.splice(k, 1); return true; }
    }
    return false;
}
/** The value after a flag ("-m stone"), removed from args; undefined when absent. */
function weFlagValue(args, f) {
    let i = args.indexOf(f);
    if (i < 0 || i + 1 >= args.length) return undefined;
    let v = args[i + 1];
    args.splice(i, 2);
    return v;
}
/** Where shapes and utilities centre: your feet, or position 1 after /toggleplace. */
function wePlace(p) {
    let s = weSel(p);
    if (p.getVar("we_place_pos1", false) && s.p1 && s.dim === p.dimension) return [s.p1[0], s.p1[1], s.p1[2]];
    return [Math.floor(p.x), Math.floor(p.y), Math.floor(p.z)];
}
/** The world's build range in this dimension. */
function weHeights(dim) { return RPG.world.heightRange(dim) || { min: -64, max: 319 }; }

RPG.on("playerJoin", (p) => { RPG.schedule(40, () => weSendSel(p)); });
RPG.on("respawn", (p) => weSendSel(p));

// ---- the wand -----------------------------------------------------------------------------
var WE_CLICK = {};                // brush debounce: right-click on a block also fires itemClick
RPG.on("blockClick", (p, button, item, x, y, z, face, dim) => {
    if (item === WE_CFG.get("wand") && RPG.perms.has(p, "worldedit.wand.use")) {
        weSetPos(p, button === "left" ? "p1" : "p2", x, y, z);
        return false;
    }
    if (typeof weToolClick === "function" && weToolClick(p, button, item, x, y, z, face)) { if (button === "right") WE_CLICK[p.uuid] = RPG.server.getTick(); return false; }
    if (button === "right" && typeof weBrushUse === "function" && weBrushUse(p, item)) { WE_CLICK[p.uuid] = RPG.server.getTick(); return false; }
});
RPG.on("itemClick", (p, item) => {
    if (WE_CLICK[p.uuid] !== undefined && RPG.server.getTick() - WE_CLICK[p.uuid] < 3) return;
    if (typeof weToolClick === "function" && weToolClick(p, "air", item)) return false;
    if (typeof weBrushUse === "function" && weBrushUse(p, item)) return false;
});
