// =====================================================================================
//  WorldEdit - utilities around you (or position 1 after /toggleplace), entities, //calc, //help
// =====================================================================================
WE_CAT = "Utility";

function weFillCmd(recursive) {
    return (p, args) => {
        let name = recursive ? "//fillr" : "//fill";
        if (args.length < 2) throw new Error("Use: " + name + " <pattern> <radius> [depth]");
        RPG.edit.checkPattern(args[0]);
        let r = weRadii(p, args[1])[0];
        let depth = args[2] !== undefined ? Math.max(1, Math.floor(Number(args[2])) || 1) : (recursive ? Math.ceil(r) : 1);
        let at = wePlace(p);
        weTask(p, RPG.edit.fill(p, p.dimension, at[0], at[1], at[2], args[0], weOpts(p, { radius: r, depth: depth, recursive: recursive })), recursive ? "Fill (recursive)" : "Fill");
    };
}
weCmd("fill", { desc: "Fill a hole around you: //fill <pattern> <radius> [depth]", perm: "fill" }, weFillCmd(false));
weCmd("fillr", { desc: "Fill a hole, spreading down too: //fillr <pattern> <radius> [depth]", perm: "fill.recursive" }, weFillCmd(true));

function weBall(p, r) { let at = wePlace(p); return { type: "sphere", x: at[0], y: at[1], z: at[2], r: r }; }
weCmd("drain", { desc: "Remove water/lava around you: //drain <radius> [-w waterlogged too]", perm: "utility.drain" }, (p, args) => {
    let wl = weFlag(args, "-w");
    let r = weRadii(p, args[0] || "10")[0];
    weTask(p, RPG.edit.drain(p, p.dimension, weBall(p, r), weOpts(p, { waterlogged: wl })), "Drain");
});
weCmd("fixwater", { desc: "Make flowing water still: //fixwater <radius>", perm: "utility.fixwater" }, (p, args) => {
    weTask(p, RPG.edit.fixWater(p, p.dimension, weBall(p, weRadii(p, args[0] || "10")[0]), weOpts(p)), "Fix water");
});
weCmd("fixlava", { desc: "Make flowing lava still: //fixlava <radius>", perm: "utility.fixlava" }, (p, args) => {
    weTask(p, RPG.edit.fixWater(p, p.dimension, weBall(p, weRadii(p, args[0] || "10")[0]), weOpts(p, { lava: true })), "Fix lava");
});

function weSizeHeight(p, args, defSize, name) {
    let size = args[0] !== undefined ? Math.floor(Number(args[0])) : defSize;
    if (isNaN(size) || size < 1) throw new Error("Use: //" + name + " [size] [height]");
    weRadii(p, String(size));
    let h = weHeights(p.dimension);
    let height = args[1] !== undefined ? Math.floor(Number(args[1])) : undefined;
    if (height !== undefined && (isNaN(height) || height < 1)) throw new Error("Use: //" + name + " [size] [height]");
    return { size: size, height: height, world: h };
}
weCmd("removeabove", { desc: "Clear blocks above you: //removeabove [size] [height]", perm: "removeabove" }, (p, args) => {
    let o = weSizeHeight(p, args, 1, "removeabove"), at = wePlace(p), s = o.size - 1;
    let top = o.height === undefined ? o.world.max : at[1] + o.height - 1;
    weTask(p, RPG.edit.set(p, p.dimension, { type: "cuboid", x1: at[0] - s, y1: at[1], z1: at[2] - s, x2: at[0] + s, y2: top, z2: at[2] + s }, "air", weOpts(p)), "Remove above");
});
weCmd("removebelow", { desc: "Clear blocks below you: //removebelow [size] [height]", perm: "removebelow" }, (p, args) => {
    let o = weSizeHeight(p, args, 1, "removebelow"), at = wePlace(p), s = o.size - 1;
    let bottom = o.height === undefined ? o.world.min : at[1] - o.height + 1;
    weTask(p, RPG.edit.set(p, p.dimension, { type: "cuboid", x1: at[0] - s, y1: bottom, z1: at[2] - s, x2: at[0] + s, y2: at[1], z2: at[2] + s }, "air", weOpts(p)), "Remove below");
});
function weCube(p, r) { let at = wePlace(p); return { type: "cuboid", x1: at[0] - r, y1: at[1] - r, z1: at[2] - r, x2: at[0] + r, y2: at[1] + r, z2: at[2] + r }; }
weCmd("removenear", { desc: "Remove blocks near you: //removenear <mask> [radius]", perm: "removenear" }, (p, args) => {
    if (!args.length) throw new Error("Use: //removenear <mask> [radius]");
    let r = weRadii(p, args[1] || "50")[0];
    weTask(p, RPG.edit.replace(p, p.dimension, weCube(p, Math.floor(r)), args[0], "air", weOpts(p)), "Remove near");
});
weCmd("replacenear", { desc: "Replace blocks near you: //replacenear <radius> [from] <to>", perm: "replacenear" }, (p, args) => {
    if (args.length < 2) throw new Error("Use: //replacenear <radius> [from-mask] <to-pattern>");
    let r = weRadii(p, args[0])[0];
    let from = args.length > 2 ? args.slice(1, -1).join(" ") : "", to = args[args.length - 1];
    weTask(p, RPG.edit.replace(p, p.dimension, weCube(p, Math.floor(r)), from, to, weOpts(p)), "Replace near");
});
/** A cylinder around you for //snow //thaw //green: size = radius, height up and down (default: the whole world). */
function weCylAround(p, o) {
    let at = wePlace(p);
    let y1 = o.height === undefined ? o.world.min : at[1] - o.height, y2 = o.height === undefined ? o.world.max : at[1] + o.height;
    return { type: "cylinder", x: at[0], y: y1, z: at[2], r: o.size, h: y2 - y1 + 1 };
}
weCmd("snow", { desc: "Snowfall around you: //snow [size] [height] [-s stack layers]", perm: "snow" }, (p, args) => {
    let stack = weFlag(args, "-s"), o = weSizeHeight(p, args, 10, "snow");
    weTask(p, RPG.edit.snow(p, p.dimension, weCylAround(p, o), weOpts(p, { stack: stack })), "Snow");
});
weCmd("thaw", { desc: "Melt snow and ice around you: //thaw [size] [height]", perm: "thaw" }, (p, args) => {
    weTask(p, RPG.edit.thaw(p, p.dimension, weCylAround(p, weSizeHeight(p, args, 10, "thaw")), weOpts(p)), "Thaw");
});
weCmd("green", { desc: "Grass over the dirt around you: //green [size] [height] [-f coarse dirt too]", perm: "green" }, (p, args) => {
    let coarse = weFlag(args, "-f");
    weTask(p, RPG.edit.green(p, p.dimension, weCylAround(p, weSizeHeight(p, args, 10, "green")), weOpts(p, { coarse: coarse })), "Green");
});
weCmd("extinguish", { desc: "Put out fires around you: //extinguish [radius]", perm: "extinguish", aliases: ["ex", "ext", "exti"] }, (p, args) => {
    let r = weRadii(p, args[0] || "40")[0];
    weTask(p, RPG.edit.replace(p, p.dimension, weBall(p, r), "fire,soul_fire", "air", weOpts(p)), "Extinguish");
});

// ---- entities ----------------------------------------------------------------------------------
var WE_GOLEMS = ["minecraft:iron_golem", "minecraft:snow_golem"];
var WE_NPCS = ["minecraft:villager", "minecraft:wandering_trader"];
var WE_AMBIENT = ["minecraft:bat"];
/**
 * Removes mobs around (x, y, z): hostile ones, plus with flags -p pets, -n NPCs/villagers, -g golems, -a animals,
 * -b ambient (bats), -t named, -r armor stands, -f all friendly ones (-p -n -g -a -b). Players never. -l: lightning.
 */
function weButcher(p, x, y, z, radius, flags) {
    let has = (c) => (" " + flags).match(new RegExp("\\s-[a-z]*" + c)) !== null;
    let all = has("f");
    let n = 0;
    RPG.world.entitiesNear(p.dimension, x, y, z, radius).forEach((e) => {
        if (e.isPlayer()) return;
        let info = RPG.world.entityInfo(e.uuid);
        if (!info || info.carriesPlayer || info.boss) return;
        let type = String(e.type);
        let ok;
        if (type === "minecraft:armor_stand") ok = has("r");
        else if (info.customName && !has("t")) ok = false;
        else if (info.owner) ok = has("p") || all;
        else if (info.npc || WE_NPCS.indexOf(type) >= 0) ok = has("n") || all;
        else if (WE_GOLEMS.indexOf(type) >= 0) ok = has("g") || all;
        else if (WE_AMBIENT.indexOf(type) >= 0) ok = has("b") || all;
        else if (e.isHostile()) ok = true;
        else ok = info.living && (has("a") || all);
        if (!ok) return;
        if (has("l")) RPG.world.lightning(p.dimension, e.x, e.y, e.z, true);
        if (RPG.world.removeEntity(e.uuid) !== null) n++;
    });
    return n;
}
weCmd("/butcher", { desc: "Kill hostile mobs near you: /butcher [radius] [-p pets] [-n npcs] [-g golems] [-a animals] [-b ambient] [-t named] [-r armor stands] [-f all friendly] [-l lightning]",
    perm: "butcher", suggest: () => ["-p", "-n", "-g", "-a", "-b", "-t", "-r", "-f", "-l"] }, (p, args) => {
    let flags = args.filter((a) => a.charAt(0) === "-" && isNaN(Number(a))).join(" ");
    let nums = args.filter((a) => !(a.charAt(0) === "-" && isNaN(Number(a))));
    let r = nums.length ? Number(nums[0]) : WE_CFG.get("butcherRadius");
    if (isNaN(r)) throw new Error("Use: /butcher [radius] [flags]");
    if (r < 0) r = 1000;
    let max = WE_CFG.get("maxRadius");
    if (r > max && !RPG.perms.has(p, "worldedit.limit.unlimited")) throw new Error("Radius too big (max " + max + ")");
    ["p", "n", "g", "a", "b", "t", "r", "f", "l"].forEach((c) => {
        if (new RegExp("-[a-z]*" + c).test(flags) && !RPG.perms.has(p, "worldedit.butcher." + c))
            throw new Error("You don't have permission for -" + c + " (worldedit.butcher." + c + ").");
    });
    let at = wePlace(p);
    weMsg(p, "&dKilled &f" + weButcher(p, at[0] + 0.5, at[1], at[2] + 0.5, r, flags) + "&d mobs.");
});
var WE_REMOVE_TYPES = {
    items: ["minecraft:item"], arrows: ["minecraft:arrow", "minecraft:spectral_arrow", "minecraft:trident"],
    xp: ["minecraft:experience_orb"], boats: ["minecraft:boat", "minecraft:chest_boat"],
    minecarts: ["minecraft:minecart", "minecraft:chest_minecart", "minecraft:furnace_minecart", "minecraft:hopper_minecart", "minecraft:tnt_minecart", "minecraft:command_block_minecart", "minecraft:spawner_minecart"],
    tnt: ["minecraft:tnt"], paintings: ["minecraft:painting"], itemframes: ["minecraft:item_frame", "minecraft:glow_item_frame"],
    fallingblocks: ["minecraft:falling_block"]
};
WE_REMOVE_TYPES.all = [].concat(WE_REMOVE_TYPES.items, WE_REMOVE_TYPES.arrows, WE_REMOVE_TYPES.xp, WE_REMOVE_TYPES.boats,
    WE_REMOVE_TYPES.minecarts, WE_REMOVE_TYPES.tnt, WE_REMOVE_TYPES.fallingblocks);
weCmd("/remove", { desc: "Remove entities: /remove <items|arrows|xp|boats|minecarts|tnt|paintings|itemframes|fallingblocks|all> <radius>",
    perm: "remove", aliases: ["/rem", "/rement"], suggest: (p, a) => a.length <= 1 ? Object.keys(WE_REMOVE_TYPES) : [] }, (p, args) => {
    let kinds = WE_REMOVE_TYPES[String(args[0] || "").toLowerCase()];
    if (!kinds || args.length < 2) throw new Error("Use: /remove <" + Object.keys(WE_REMOVE_TYPES).join("|") + "> <radius>");
    let r = Number(args[1]);
    if (isNaN(r)) throw new Error("Bad radius: " + args[1]);
    if (r < 0) r = 1000;
    let max = WE_CFG.get("maxRadius");
    if (r > max && !RPG.perms.has(p, "worldedit.limit.unlimited")) throw new Error("Radius too big (max " + max + ")");
    let at = wePlace(p), n = 0;
    kinds.forEach((t) => RPG.world.entityIdsNear(p.dimension, at[0] + 0.5, at[1], at[2] + 0.5, r, t).forEach((id) => { if (RPG.world.removeEntity(id) !== null) n++; }));
    weMsg(p, "&dRemoved &f" + n + "&d entities.");
});

// ---- calculator and help ---------------------------------------------------------------------
WE_CAT = "General";
weCmd("calc", { desc: "Evaluate a math expression: //calc <expression>", perm: "calc", aliases: ["eval", "evaluate", "calculate"] }, (p, args) => {
    let e = weNeed(args, "//calc <expression>  (e.g. //calc 2^10 + sqrt(16))");
    let v = RPG.edit.calc(e);
    weMsg(p, "&7" + e + " &f= &d" + (Math.abs(v - Math.round(v)) < 1e-9 ? Math.round(v) : Number(v.toPrecision(12))));
});
weCmd("help", { desc: "WorldEdit commands: //help [page | command]", perm: "help", aliases: ["we", "worldedit", "/we", "/worldedit"] }, (p, args) => {
    let mine = WE_CMDS.filter((c) => RPG.perms.has(p, c.perm));
    let q = String(args[0] || "").toLowerCase().replace(/^\/+/, "");
    if (q && isNaN(Number(q))) {
        let c = mine.filter((c) => c.typed.replace(/^\/+/, "") === q || c.aliases.some((a) => a.replace(/^\/+/, "") === q))[0];
        if (!c) {
            let hits = mine.filter((c) => c.typed.indexOf(q) >= 0 || c.desc.toLowerCase().indexOf(q) >= 0);
            if (!hits.length) throw new Error("No command matches " + q + ".");
            weMsg(p, "&dCommands matching &f" + q + "&d:");
            hits.slice(0, 16).forEach((c) => p.tell("&f" + c.typed + " &7- " + c.desc));
            return;
        }
        weMsg(p, "&f" + c.typed + (c.aliases.length ? " &7(also " + c.aliases.join(", ") + ")" : ""));
        p.tell("&7" + c.desc + "  &8[" + c.perm + "]");
        return;
    }
    let per = 12, pages = Math.max(1, Math.ceil(mine.length / per)), page = Math.min(pages, Math.max(1, Math.floor(Number(q)) || 1));
    if (page === 1) weMsg(p, "&dWorldEdit &7- wand: &f" + WE_CFG.get("wand") + "&7 (left = pos1, right = pos2). Patterns: &fstone&7, &f50%stone,50%dirt&7; masks: &f!air&7, &f#solid&7, &f>grass&7, &fstone !air");
    p.tell("&5--- &dWorldEdit help &7(page " + page + "/" + pages + ", //help <page|command>) &5---");
    let last = "";
    mine.slice((page - 1) * per, page * per).forEach((c) => {
        if (c.cat !== last) { last = c.cat; p.tell("&5" + c.cat + ":"); }
        p.tell(" &f" + c.typed + " &7- " + c.desc);
    });
});
