// =====================================================================================
//  WorldEdit - selection, region, generation, clipboard, history and schematic commands
//  Names, arguments, flags and aliases follow WorldEdit 7's commands.
// =====================================================================================

// ---- selection ----------------------------------------------------------------------------
WE_CAT = "Selection";

/** "x y z", "x,y,z" or "~ ~1 ~" (relative to you) from the start of args; null when there are none. */
function weCoords(p, args) {
    let parts = args.length === 1 && args[0].indexOf(",") >= 0 ? args[0].split(",") : args.slice(0, 3);
    if (parts.length < 3) return null;
    let c = parts.map((a, i) => a.charAt(0) === "~" ? Math.floor([p.x, p.y, p.z][i]) + (Number(a.substring(1)) || 0) : Number(a));
    if (c.some(isNaN)) return null;
    return c;
}
function wePosCmd(which) {
    return (p, args) => {
        if (args.length) {
            let c = weCoords(p, args);
            if (!c) throw new Error("Use: //" + (which === "p1" ? "pos1" : "pos2") + " [x,y,z]");
            weSetPos(p, which, c[0], c[1], c[2]);
        } else weSetPos(p, which, p.x, p.y, p.z);
    };
}
weCmd("pos1", { desc: "Selection corner 1 here (or at x,y,z)", perm: "selection.pos", aliases: ["1"] }, wePosCmd("p1"));
weCmd("pos2", { desc: "Selection corner 2 here (or at x,y,z)", perm: "selection.pos", aliases: ["2"] }, wePosCmd("p2"));
function weHpos(which) {
    return (p) => {
        let at = p.lookBlock(WE_CFG.get("brushRange"));
        if (!at) throw new Error("No block in sight.");
        weSetPos(p, which, at[0], at[1], at[2]);
    };
}
weCmd("hpos1", { desc: "Corner 1 at the block you look at", perm: "selection.pos" }, weHpos("p1"));
weCmd("hpos2", { desc: "Corner 2 at the block you look at", perm: "selection.pos" }, weHpos("p2"));
weCmd("wand", { desc: "Get the selection wand (//wand -n: the navigation wand)", perm: "wand" }, (p, args) => {
    if (weFlag(args, "-n")) {
        let item = WE_CFG.get("navWand");
        p.giveItem(item, 1);
        let all = weBrushes(p);
        all[item] = { tool: "navwand" };
        p.setVar("we_brushes", all);
        weMsg(p, "&dNavigation wand: left-click a block = /jumpto, right-click = /thru.");
        return;
    }
    p.giveItem(WE_CFG.get("wand"), 1);
    weMsg(p, "&dLeft-click a block: position 1. Right-click: position 2.");
});
function weDesel(p) {
    let mode = weSel(p).mode;
    WE_SEL[p.uuid] = mode ? { mode: mode } : {};
    p.setVar("we_sel", WE_SEL[p.uuid]);
    weSendSel(p);
    weMsg(p, "&7Selection cleared.");
}
weCmd("desel", { desc: "Clear your selection", perm: "selection.pos", aliases: ["deselect"] }, (p) => weDesel(p));
var WE_SEL_MODES = ["cuboid", "extend"];
weCmd("sel", { desc: "//sel [cuboid|extend] [-d]: selection mode (no mode = clear the selection)", perm: "selection.sel",
    suggest: () => WE_SEL_MODES.concat(["list", "-d"]) }, (p, args) => {
    let def = weFlag(args, "-d");
    let mode = String(args[0] || (def ? p.getVar("we_selmode", "cuboid") : "")).toLowerCase();
    if (!mode) { weDesel(p); return; }
    if (mode === "list") { weMsg(p, "&dSelection modes: &fcuboid&7 (two corners), &fextend&7 (position 2 grows the box)"); return; }
    if (WE_SEL_MODES.indexOf(mode) < 0)
        throw new Error("Selection mode " + mode + " isn't available here; use cuboid or extend (shapes: //sphere, //cyl, //generate).");
    let s = weSel(p);
    s.mode = mode === "cuboid" ? undefined : mode;
    if (def) p.setVar("we_selmode", mode);
    p.setVar("we_sel", s);
    weMsg(p, "&dSelection mode: &f" + mode + (mode === "extend" ? "&7 (left-click starts, right-click extends)" : "&7 (left-click = pos1, right-click = pos2)") + (def ? " &7(default)" : ""));
});
RPG.on("playerJoin", (p) => {
    let def = p.getVar("we_selmode", "");
    if (def && def !== "cuboid") { let s = weSel(p); if (!s.mode) { s.mode = def; p.setVar("we_sel", s); } }
});
weCmd("size", { desc: "Selection size (//size -c: the clipboard)", perm: "selection.size" }, (p, args) => {
    if (weFlag(args, "-c")) {
        let c = RPG.edit.clipboard(p);
        if (!c) throw new Error("Your clipboard is empty.");
        weMsg(p, "&dClipboard &f" + c.width + " x " + c.height + " x " + c.length + " &7= &f" + weNum(c.width * c.height * c.length) +
            "&7 blocks, offset (" + [c.offsetX, c.offsetY, c.offsetZ].join(", ") + ")" + (c.transformed ? ", rotated/flipped" : ""));
        return;
    }
    let r = weRegion(p), b = RPG.edit.bounds(r);
    weMsg(p, "&dSize &f" + (b.maxX - b.minX + 1) + " x " + (b.maxY - b.minY + 1) + " x " + (b.maxZ - b.minZ + 1)
        + " &7= &f" + weNum(RPG.edit.volume(r)) + "&7 blocks, from (" + [b.minX, b.minY, b.minZ].join(", ") + ") to (" + [b.maxX, b.maxY, b.maxZ].join(", ") + ")");
});
weCmd("chunk", { desc: "Select the chunk you are in (//chunk [x,z] [-c chunk coords] [-s add to the selection])", perm: "selection.chunk" }, (p, args) => {
    let extend = weFlag(args, "-s"), chunkCoords = weFlag(args, "-c");
    let x = Math.floor(p.x), z = Math.floor(p.z);
    if (args.length) {
        let c = args[0].indexOf(",") >= 0 ? args[0].split(",").map(Number) : [Number(args[0]), Number(args[1])];
        if (c.length < 2 || c.some(isNaN)) throw new Error("Use: //chunk [x,z] [-c] [-s]");
        x = chunkCoords ? c[0] * 16 : c[0]; z = chunkCoords ? c[c.length - 1] * 16 : c[c.length - 1];
    }
    let h = weHeights(p.dimension);
    let box = { x1: x >> 4 << 4, y1: h.min, z1: z >> 4 << 4, x2: (x >> 4 << 4) + 15, y2: h.max, z2: (z >> 4 << 4) + 15 };
    let r = extend ? weRegionOrNull(p) : null;
    if (r) {
        let b = RPG.edit.bounds(r);
        box = { x1: Math.min(box.x1, b.minX >> 4 << 4), y1: h.min, z1: Math.min(box.z1, b.minZ >> 4 << 4),
            x2: Math.max(box.x2, (b.maxX >> 4 << 4) + 15), y2: h.max, z2: Math.max(box.z2, (b.maxZ >> 4 << 4) + 15) };
    }
    weSaveSel(p, box);
    weMsg(p, "&dChunk selected: &f" + (box.x1 >> 4) + ", " + (box.z1 >> 4) + (r ? " &7to &f" + (box.x2 >> 4) + ", " + (box.z2 >> 4) : "") +
        " &7(" + weNum(RPG.edit.volume(weRegion(p))) + " blocks)");
});
weCmd("drawsel", { desc: "Show or hide your selection outline", perm: "drawsel" }, (p) => {
    let hide = !p.getVar("we_nodraw", false);
    p.setVar("we_nodraw", hide);
    weSendSel(p);
    weMsg(p, hide ? "&7Selection outline hidden." : "&dSelection outline shown.");
});
weCmd("toggleplace", { desc: "Shapes and utilities centre on position 1 instead of you (toggle)", perm: "toggleplace", aliases: ["/toggleplace"] }, (p) => {
    let on = !p.getVar("we_place_pos1", false);
    p.setVar("we_place_pos1", on);
    weMsg(p, on ? "&dNow placing at position 1." : "&dNow placing at your feet.");
});

/** The selection's box as [minX, minY, minZ, maxX, maxY, maxZ]. */
function weBox(p) { let b = RPG.edit.bounds(weRegion(p)); return [b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ]; }
function weBoxSave(p, box, what) {
    if (box[0] > box[3] || box[1] > box[4] || box[2] > box[5]) throw new Error("That would make the selection empty.");
    weSaveSel(p, { x1: box[0], y1: box[1], z1: box[2], x2: box[3], y2: box[4], z2: box[5] });
    weMsg(p, "&dSelection " + what + " &7(" + weNum(RPG.edit.volume(weRegion(p))) + " blocks)");
}
/** Directions: one word, several with commas ("north,east"), or the way you look. */
function weDirs(p, word) {
    return String(word || "me").split(",").map((w) => weDir(p, w));
}

/** Grows/shrinks/moves the selection box along directions. */
function weResize(p, args, mode) {
    let box = weBox(p);
    if (mode === "expand" && String(args[0]).toLowerCase() === "vert") {
        let h = weHeights(p.dimension);
        box[1] = h.min; box[4] = h.max;
        weBoxSave(p, box, "expanded vertically");
        return;
    }
    let n = Math.floor(Number(args[0]));
    if (isNaN(n) || n < 0) throw new Error("Use: //" + mode + " <amount> " + (mode === "shift" ? "" : "[reverse-amount] ") + "[direction]");
    let rest = args.slice(1), back = 0;
    if (mode !== "shift" && rest.length && !isNaN(Number(rest[0]))) { back = Math.floor(Number(rest[0])) || 0; rest = rest.slice(1); }
    weDirs(p, rest[0]).forEach((d) => {
        for (let i = 0; i < 3; i++) {
            if (d[i] === 0) continue;
            if (mode === "shift") { box[i] += d[i] * n; box[i + 3] += d[i] * n; continue; }
            let s = mode === "expand" ? 1 : -1;
            if (d[i] > 0) { box[i + 3] += s * n; box[i] -= s * back; } else { box[i] -= s * n; box[i + 3] += s * back; }
        }
    });
    weBoxSave(p, box, mode === "expand" ? "expanded" : mode === "contract" ? "contracted" : "shifted");
}
var WE_DIR_WORDS = ["north", "south", "east", "west", "up", "down", "me", "back"];
weCmd("expand", { desc: "Grow the selection: //expand <n> [reverse] [dir] | //expand vert", perm: "selection.expand", suggest: (p, a) => a.length === 1 ? ["vert"] : WE_DIR_WORDS }, (p, a) => weResize(p, a, "expand"));
weCmd("contract", { desc: "Shrink the selection: //contract <n> [reverse] [dir]", perm: "selection.contract", suggest: (p, a) => a.length > 1 ? WE_DIR_WORDS : [] }, (p, a) => weResize(p, a, "contract"));
weCmd("shift", { desc: "Move the selection box: //shift <n> [dir]", perm: "selection.shift", suggest: (p, a) => a.length > 1 ? WE_DIR_WORDS : [] }, (p, a) => weResize(p, a, "shift"));
function weOutset(sign) {
    return (p, args) => {
        let h = weFlag(args, "-h"), v = weFlag(args, "-v");
        let n = Math.floor(Number(args[0]));
        if (isNaN(n) || n < 0) throw new Error("Use: //" + (sign > 0 ? "outset" : "inset") + " <amount> [-h horizontal only] [-v vertical only]");
        let box = weBox(p);
        for (let i = 0; i < 3; i++) {
            if ((i === 1 && h) || (i !== 1 && v)) continue;
            box[i] -= sign * n; box[i + 3] += sign * n;
        }
        weBoxSave(p, box, sign > 0 ? "outset" : "inset");
    };
}
weCmd("outset", { desc: "Grow the selection on every side: //outset <n> [-h] [-v]", perm: "selection.outset" }, weOutset(1));
weCmd("inset", { desc: "Shrink the selection on every side: //inset <n> [-h] [-v]", perm: "selection.inset" }, weOutset(-1));

// ---- information ---------------------------------------------------------------------------
weCmd("count", { desc: "Count blocks: //count <mask>", perm: "analysis.count" }, (p, args) => {
    if (!args.length) throw new Error("Use: //count <mask>  (e.g. //count stone,dirt)");
    RPG.edit.count(p, p.dimension, weRegion(p), args.join(" "), { limit: weLimit(p), progress: true }).then((t) => {
        if (t.error) weErr(p, t.error); else weMsg(p, "&dCounted &f" + weNum(t.result) + "&d blocks.");
    });
});
weCmd("distr", { desc: "Block distribution of the selection: //distr [-d states] [-p page]", perm: "analysis.distr" }, (p, args) => {
    let states = weFlag(args, "-d"), page = Math.max(1, Math.floor(Number(weFlagValue(args, "-p"))) || 1);
    RPG.edit.distr(p, p.dimension, weRegion(p), { limit: weLimit(p), states: states }).then((t) => {
        if (t.error) { weErr(p, t.error); return; }
        let all = t.result || [], pages = Math.max(1, Math.ceil(all.length / 15));
        weMsg(p, "&dBlock distribution &7(page " + Math.min(page, pages) + "/" + pages + "):");
        all.slice((Math.min(page, pages) - 1) * 15, Math.min(page, pages) * 15).forEach((e) => p.tell("&7" + e.percent.toFixed(2) + "%  &f" + weNum(e.count) + "  &d" + e.block));
    });
});

// ---- region edits ---------------------------------------------------------------------------
WE_CAT = "Region";
function weNeed(args, use) { if (!args.length) throw new Error("Use: " + use); return args.join(" ").trim(); }
weCmd("set", { desc: "Fill the selection: //set <pattern>  (stone | 50%stone,50%dirt)", perm: "region.set" }, (p, args) => {
    weTask(p, RPG.edit.set(p, p.dimension, weRegion(p), weNeed(args, "//set <pattern>"), weOpts(p)), "Set");
});
weCmd("replace", { desc: "//replace [from] <to>  (no from = any non-air)", perm: "region.replace", aliases: ["re", "rep"] }, (p, args) => {
    if (!args.length) throw new Error("Use: //replace [from-mask] <to-pattern>");
    let from = args.length > 1 ? args.slice(0, -1).join(" ") : "", to = args[args.length - 1];
    weTask(p, RPG.edit.replace(p, p.dimension, weRegion(p), from, to, weOpts(p)), "Replace");
});
function weBoxShape(type, label) {
    return (p, args) => {
        let r = weRegion(p);
        r.type = type;
        weTask(p, RPG.edit.set(p, p.dimension, r, weNeed(args, "//" + (type === "faces" ? "faces" : type) + " <pattern>"), weOpts(p)), label);
    };
}
weCmd("walls", { desc: "Four walls of the selection: //walls <pattern>", perm: "region.walls" }, weBoxShape("walls", "Walls"));
weCmd("faces", { desc: "All six faces of the selection: //faces <pattern>", perm: "region.faces", aliases: ["outline"] }, weBoxShape("faces", "Faces"));
weCmd("center", { desc: "The centre block(s) of the selection: //center <pattern>", perm: "region.center", aliases: ["middle"] }, (p, args) => {
    let b = weBox(p), c = [0, 1, 2].map((i) => [Math.floor((b[i] + b[i + 3]) / 2), Math.ceil((b[i] + b[i + 3]) / 2)]);
    weTask(p, RPG.edit.set(p, p.dimension, { type: "cuboid", x1: c[0][0], y1: c[1][0], z1: c[2][0], x2: c[0][1], y2: c[1][1], z2: c[2][1] },
        weNeed(args, "//center <pattern>"), weOpts(p)), "Center");
});
weCmd("line", { desc: "A line from position 1 to position 2: //line <pattern> [thickness] [-h]", perm: "region.line" }, (p, args) => {
    let hollow = weFlag(args, "-h");
    if (!args.length) throw new Error("Use: //line <pattern> [thickness] [-h]");
    let s = weSel(p);
    weRegion(p);
    let t = Math.max(0, Math.floor(Number(args[1])) || 0);
    if (t > WE_CFG.get("maxRadius") && !RPG.perms.has(p, "worldedit.limit.unlimited")) throw new Error("Too thick (max " + WE_CFG.get("maxRadius") + ")");
    weTask(p, RPG.edit.set(p, p.dimension, { type: "line", x1: s.p1[0] + 0.5, y1: s.p1[1] + 0.5, z1: s.p1[2] + 0.5,
        x2: s.p2[0] + 0.5, y2: s.p2[1] + 0.5, z2: s.p2[2] + 0.5, r: t + 0.5, hollow: hollow && t > 0 }, args[0], weOpts(p)), "Line");
});
weCmd("overlay", { desc: "Put a layer on top: //overlay <pattern>", perm: "region.overlay" }, (p, args) => {
    weTask(p, RPG.edit.overlay(p, p.dimension, weRegion(p), weNeed(args, "//overlay <pattern>"), weOpts(p)), "Overlay");
});
weCmd("naturalize", { desc: "Grass, 3 dirt, then stone", perm: "region.naturalize" }, (p) => {
    weTask(p, RPG.edit.naturalize(p, p.dimension, weRegion(p), weOpts(p)), "Naturalize");
});
weCmd("smooth", { desc: "Smooth the terrain: //smooth [iterations]", perm: "region.smooth" }, (p, args) => {
    if (args.length > 1) weMsg(p, "&7(//smooth smooths the ground's height map; a mask argument is ignored.)");
    weTask(p, RPG.edit.smooth(p, p.dimension, weRegion(p), Math.max(1, Math.floor(Number(args[0])) || 1), weOpts(p)), "Smooth");
});
weCmd("regen", { desc: "Regenerate the selection's terrain from the world generator (no trees/ores/caves)", perm: "regen" }, (p) => {
    weTask(p, RPG.edit.regen(p, p.dimension, weRegion(p), weOpts(p)), "Regen");
});
/** Drops flags WorldEdit has that this engine doesn't do (entities, biomes), saying so. */
function weIgnoreFlags(p, args, flags) {
    let gone = flags.filter((f) => weFlag(args, f));
    if (gone.length) weMsg(p, "&7(" + gone.join(" ") + ": entities and biomes are not copied here; ignored.)");
}
weCmd("stack", { desc: "Repeat the selection: //stack [count] [dir] [-s move selection] [-a skip air]", perm: "region.stack", suggest: () => WE_DIR_WORDS.concat(["-a", "-s"]) }, (p, args) => {
    let skip = weFlag(args, "-a"), shiftSel = weFlag(args, "-s");
    weIgnoreFlags(p, args, ["-e", "-b"]);
    let n = Math.max(1, Math.floor(Number(args[0])) || 1);
    let d = weDir(p, isNaN(Number(args[0])) ? args[0] : args[1]);
    let r = weRegion(p), b = weBox(p);
    weTask(p, RPG.edit.stack(p, p.dimension, r, n, d[0], d[1], d[2], weOpts(p, { skipAir: skip })), "Stack");
    if (shiftSel) {
        let size = [b[3] - b[0] + 1, b[4] - b[1] + 1, b[5] - b[2] + 1];
        for (let i = 0; i < 3; i++) { b[i] += d[i] * size[i] * n; b[i + 3] += d[i] * size[i] * n; }
        weSaveSel(p, { x1: b[0], y1: b[1], z1: b[2], x2: b[3], y2: b[4], z2: b[5] });
    }
});
weCmd("move", { desc: "Move the selection's blocks: //move [n] [dir] [leave-pattern] [-s move selection] [-a skip air]", perm: "region.move", suggest: () => WE_DIR_WORDS }, (p, args) => {
    let shiftSel = weFlag(args, "-s"), skip = weFlag(args, "-a");
    weIgnoreFlags(p, args, ["-e", "-b"]);
    let n = Math.floor(Number(args[0]));
    if (isNaN(n)) n = 1; else args = args.slice(1);
    let d = weDir(p, weIsDir(args[0]) ? args.shift() : undefined);
    let r = weRegion(p);
    weTask(p, RPG.edit.move(p, p.dimension, r, d[0] * n, d[1] * n, d[2] * n, weOpts(p, { fill: args[0] || "minecraft:air", skipAir: skip })), "Move");
    if (shiftSel) {
        let b = weBox(p);
        weSaveSel(p, { x1: b[0] + d[0] * n, y1: b[1] + d[1] * n, z1: b[2] + d[2] * n, x2: b[3] + d[0] * n, y2: b[4] + d[1] * n, z2: b[5] + d[2] * n });
    }
});
weCmd("hollow", { desc: "Hollow out what's in the selection: //hollow [thickness] [pattern] [-m solid-mask]", perm: "region.hollow" }, (p, args) => {
    let solid = weFlagValue(args, "-m");
    let t = 1, pat = "minecraft:air";
    if (args.length && !isNaN(Number(args[0]))) { t = Math.max(1, Math.floor(Number(args[0]))); args = args.slice(1); }
    if (args.length) pat = args.join(" ");
    let o = weOpts(p);
    if (solid) o.solid = solid;
    weTask(p, RPG.edit.hollow(p, p.dimension, weRegion(p), t, pat, o), "Hollow");
});
/** Tree names //forest and /tool tree take, as a script array. */
function weTreeTypes() {
    let l = RPG.edit.treeTypes(), out = [], n = l.length !== undefined ? l.length : l.size();
    for (let i = 0; i < n; i++) out.push(String(l[i] !== undefined ? l[i] : l.get(i)));
    return out;
}
function weTreeCheck(type) {
    if (weTreeTypes().indexOf(String(type).toLowerCase()) < 0 && String(type).toLowerCase() !== "dark_oak")
        throw new Error("Unknown tree type " + type + ". Types: " + weTreeTypes().join(", "));
}
function weDensity(text, def) {
    let d = text === undefined ? def : Number(text);
    if (isNaN(d) || d < 0 || d > 100) throw new Error("Density is a percentage, 0 to 100.");
    return d / 100;
}
weCmd("forest", { desc: "Plant trees in the selection: //forest [type] [density 0-100, default 5]", perm: "region.forest",
    suggest: (p, a) => a.length <= 1 ? weTreeTypes() : [] }, (p, args) => {
    let type = args.length && isNaN(Number(args[0])) ? args.shift() : "tree";
    weTreeCheck(type);
    weTask(p, RPG.edit.forest(p, p.dimension, weRegion(p), type, weDensity(args[0], 5), weOpts(p)), "Forest");
});
weCmd("flora", { desc: "Grass and flowers on grass, dead bushes and cacti on sand: //flora [density 0-100, default 10]", perm: "region.flora" }, (p, args) => {
    weTask(p, RPG.edit.flora(p, p.dimension, weRegion(p), weDensity(args[0], 10), weOpts(p)), "Flora");
});
/** -r raw world coordinates, -o from your placement position, -c from the selection's centre (default: -1..1 across it). */
function weExprFrame(p, args, o) {
    if (weFlag(args, "-r")) o.frame = "raw";
    else if (weFlag(args, "-c")) o.frame = "center";
    else if (weFlag(args, "-o")) { let at = wePlace(p); o.frame = "origin"; o.ox = at[0]; o.oy = at[1]; o.oz = at[2]; }
    return o;
}
weCmd("deform", { desc: "Move blocks by an expression on x, y, z: //deform <expression> [-r] [-o] [-c]  (e.g. y-=0.2)", perm: "region.deform" }, (p, args) => {
    let o = weExprFrame(p, args, weOpts(p));
    weTask(p, RPG.edit.deform(p, p.dimension, weRegion(p), weNeed(args, "//deform <expression>"), o), "Deform");
});

// ---- generation (around you, or position 1 after /toggleplace) ---------------------------------
WE_CAT = "Generation";
function weRadii(p, text) {
    let rs = String(text || "").split(",").map(Number);
    if (!rs.length || rs.some((n) => isNaN(n) || n < 0)) throw new Error("Bad radius: " + text);
    let max = WE_CFG.get("maxRadius");
    if (rs.some((n) => n > max) && !RPG.perms.has(p, "worldedit.limit.unlimited")) throw new Error("Radius too big (max " + max + ")");
    return rs;
}
function weSphere(hollowCmd) {
    return (p, args) => {
        let raise = weFlag(args, "-r"), hollow = weFlag(args, "-h") || hollowCmd;
        if (args.length < 2) throw new Error("Use: //" + (hollowCmd ? "h" : "") + "sphere <pattern> <radius>[,ry,rz] [-r]" + (hollowCmd ? "" : " [-h]"));
        let rs = weRadii(p, args[1]), rx = rs[0], ry = rs.length > 1 ? rs[1] : rx, rz = rs.length > 2 ? rs[2] : rx;
        let at = wePlace(p);
        let y = at[1] + (raise ? Math.ceil(ry) : 0);
        weTask(p, RPG.edit.set(p, p.dimension, { type: "sphere", x: at[0], y: y, z: at[2], rx: rx, ry: ry, rz: rz, hollow: hollow }, args[0], weOpts(p)), hollow ? "Hollow sphere" : "Sphere");
    };
}
weCmd("sphere", { desc: "//sphere <pattern> <r>[,ry,rz] [-r raised] [-h hollow]", perm: "generation.sphere" }, weSphere(false));
weCmd("hsphere", { desc: "Hollow sphere: //hsphere <pattern> <r>[,ry,rz] [-r]", perm: "generation.sphere" }, weSphere(true));
function weCyl(hollowCmd) {
    return (p, args) => {
        let hollow = weFlag(args, "-h") || hollowCmd;
        if (args.length < 2) throw new Error("Use: //" + (hollowCmd ? "h" : "") + "cyl <pattern> <radius>[,rz] [height]");
        let rs = weRadii(p, args[1]), h = Math.floor(Number(args[2])) || 1, at = wePlace(p);
        weTask(p, RPG.edit.set(p, p.dimension, { type: "cylinder", x: at[0], y: at[1], z: at[2], rx: rs[0], rz: rs.length > 1 ? rs[1] : rs[0], h: h, hollow: hollow }, args[0], weOpts(p)), hollow ? "Hollow cylinder" : "Cylinder");
    };
}
weCmd("cyl", { desc: "//cyl <pattern> <r>[,rz] [height] [-h hollow]", perm: "generation.cylinder" }, weCyl(false));
weCmd("hcyl", { desc: "Hollow cylinder: //hcyl <pattern> <r>[,rz] [height]", perm: "generation.cylinder" }, weCyl(true));
function wePyramid(hollowCmd) {
    return (p, args) => {
        let hollow = weFlag(args, "-h") || hollowCmd;
        if (args.length < 2) throw new Error("Use: //" + (hollowCmd ? "h" : "") + "pyramid <pattern> <size>");
        let size = weRadii(p, args[1])[0], at = wePlace(p);
        weTask(p, RPG.edit.set(p, p.dimension, { type: "pyramid", x: at[0], y: at[1], z: at[2], size: size, hollow: hollow }, args[0], weOpts(p)), hollow ? "Hollow pyramid" : "Pyramid");
    };
}
weCmd("pyramid", { desc: "//pyramid <pattern> <size> [-h hollow]", perm: "generation.pyramid" }, wePyramid(false));
weCmd("hpyramid", { desc: "Hollow pyramid: //hpyramid <pattern> <size>", perm: "generation.pyramid" }, wePyramid(true));
weCmd("generate", { desc: "Shape from an expression in the selection: //generate <pattern> <expression> [-h] [-r] [-o] [-c]", perm: "generation.shape", aliases: ["gen", "g"] }, (p, args) => {
    let o = weExprFrame(p, args, weOpts(p));
    if (weFlag(args, "-h")) o.hollow = true;
    if (args.length < 2) throw new Error("Use: //generate <pattern> <expression>  (e.g. //g stone x^2+y^2+z^2<1)");
    weTask(p, RPG.edit.generate(p, p.dimension, weRegion(p), args[0], args.slice(1).join(" "), o), "Generate");
});
function weAround(p, size, height) {
    let at = wePlace(p), h = weHeights(p.dimension);
    return { type: "cuboid", x1: at[0] - size, y1: height === undefined ? h.min : at[1] - height, z1: at[2] - size,
        x2: at[0] + size, y2: height === undefined ? h.max : at[1] + height, z2: at[2] + size };
}
weCmd("/forestgen", { desc: "Trees around you: /forestgen [size] [type] [density 0-100]", perm: "generation.forest",
    suggest: (p, a) => a.length === 2 ? weTreeTypes() : [] }, (p, args) => {
    let size = weRadii(p, args[0] || "10")[0];
    weTreeCheck(args[1] || "tree");
    weTask(p, RPG.edit.forest(p, p.dimension, weAround(p, size), args[1] || "tree", weDensity(args[2], 5), weOpts(p)), "Forest");
});
weCmd("/pumpkins", { desc: "Pumpkin patches around you: /pumpkins [size] [density 0-100]", perm: "generation.pumpkins" }, (p, args) => {
    let size = weRadii(p, args[0] || "10")[0];
    weTask(p, RPG.edit.flora(p, p.dimension, weAround(p, size), weDensity(args[1], 2), weOpts(p, { pumpkins: true })), "Pumpkins");
});

// ---- clipboard ----------------------------------------------------------------------------------
WE_CAT = "Clipboard";
function weClipLimit(p, r) {
    if (!RPG.perms.has(p, "worldedit.limit.unlimited") && RPG.edit.volume(r) > WE_CFG.get("maxClipboard"))
        throw new Error("Too big for the clipboard (max " + weNum(WE_CFG.get("maxClipboard")) + " blocks)");
}
function weCopyArgs(p, args) {
    weIgnoreFlags(p, args, ["-e", "-b"]);
    if (weFlagValue(args, "-m") !== undefined) weMsg(p, "&7(-m: copies take the whole selection; mask ignored.)");
}
weCmd("copy", { desc: "Copy the selection (relative to where you stand)", perm: "clipboard.copy" }, (p, args) => {
    weCopyArgs(p, args);
    let r = weRegion(p);
    weClipLimit(p, r);
    let at = [Math.floor(p.x), Math.floor(p.y), Math.floor(p.z)];
    weTask(p, RPG.edit.copy(p, p.dimension, r, at[0], at[1], at[2], { limit: weLimit(p), progress: true }), "")
        .then((t) => { if (!t.error && !t.cancelled) { p.setVar("we_clip_origin", at); weMsg(p, "&d" + weNum(t.result) + " blocks copied."); } });
});
weCmd("cut", { desc: "Cut the selection: //cut [leave-pattern]", perm: "clipboard.cut" }, (p, args) => {
    weCopyArgs(p, args);
    let r = weRegion(p);
    weClipLimit(p, r);
    let at = [Math.floor(p.x), Math.floor(p.y), Math.floor(p.z)];
    weTask(p, RPG.edit.copy(p, p.dimension, r, at[0], at[1], at[2], weOpts(p, { cut: args[0] || "minecraft:air" })), "Cut")
        .then((t) => { if (!t.error && !t.cancelled) p.setVar("we_clip_origin", at); });
});
weCmd("paste", { desc: "Paste: //paste [-a skip air] [-o at the copy spot] [-s select it] [-n select only]", perm: "clipboard.paste" }, (p, args) => {
    let skip = weFlag(args, "-a"), sel = weFlag(args, "-s"), orig = weFlag(args, "-o"), only = weFlag(args, "-n");
    weCopyArgs(p, args);
    let info = RPG.edit.clipboard(p);
    if (!info) throw new Error("Your clipboard is empty (//copy or //schem load first).");
    let at = [Math.floor(p.x), Math.floor(p.y), Math.floor(p.z)];
    if (orig) {
        let o = p.getVar("we_clip_origin", null);
        if (!o) throw new Error("This clipboard has no copy position (it came from a schematic); paste without -o.");
        at = o;
    }
    let x = at[0], y = at[1], z = at[2];
    if (sel || only) weSaveSel(p, { x1: x + info.offsetX, y1: y + info.offsetY, z1: z + info.offsetZ,
        x2: x + info.offsetX + info.width - 1, y2: y + info.offsetY + info.height - 1, z2: z + info.offsetZ + info.length - 1 });
    if (only) { weMsg(p, "&dSelected where the clipboard would paste."); return; }
    let vol = info.width * info.height * info.length, max = WE_CFG.get("maxClipboard");
    if (vol > max && !RPG.perms.has(p, "worldedit.limit.unlimited"))
        throw new Error("Clipboard too big to paste: " + weNum(vol) + " blocks (counting air), the limit is " + weNum(max) +
            ". An op can raise it with /rpg config worldedit maxClipboard <blocks>, or give you worldedit.limit.unlimited (ops have it).");
    weTask(p, RPG.edit.paste(p, p.dimension, x, y, z, weOpts(p, { skipAir: skip, limit: RPG.perms.has(p, "worldedit.limit.unlimited") ? 0 : max })), "Paste");
});
weCmd("rotate", { desc: "Rotate the clipboard: //rotate <y-degrees> (90, 180, 270, -90)", perm: "clipboard.rotate", suggest: () => ["90", "180", "270", "-90"] }, (p, args) => {
    let d = Math.round((Number(args[0]) || 0) / 90) * 90;
    if ((Number(args[1]) || 0) % 360 || (Number(args[2]) || 0) % 360) throw new Error("Only rotation around the vertical axis is supported (//rotate <degrees>); use //flip up for upside down.");
    if (!d) throw new Error("Use: //rotate <90|180|270>");
    if (!RPG.edit.rotate(p, d)) throw new Error("Your clipboard is empty.");
    weMsg(p, "&dClipboard rotated " + d + " degrees.");
});
weCmd("flip", { desc: "Mirror the clipboard: //flip [dir]  (default: the way you look)", perm: "clipboard.flip", suggest: () => WE_DIR_WORDS }, (p, args) => {
    let d = weDir(p, args[0]), axis = d[1] !== 0 ? "y" : d[0] !== 0 ? "x" : "z";
    if (!RPG.edit.flip(p, axis)) throw new Error("Your clipboard is empty.");
    weMsg(p, "&dClipboard flipped along " + axis + ".");
});
weCmd("/clearclipboard", { desc: "Empty your clipboard", perm: "clipboard.clear", aliases: ["//clearclipboard"] }, (p) => {
    RPG.edit.clearClipboard(p); p.setVar("we_clip_origin", null); weMsg(p, "&7Clipboard cleared.");
});

// ---- history ------------------------------------------------------------------------------------
WE_CAT = "History";
weCmd("undo", { desc: "Undo your last edits: //undo [times]", perm: "history.undo", aliases: ["/undo"] }, (p, args) => {
    let n = Math.max(1, Math.floor(Number(args[0])) || 1);
    RPG.edit.undo(p, n, {}).then((t) => { if (t.error && !t.changed) weErr(p, t.error); else weMsg(p, "&dUndid " + weNum(t.changed) + " blocks."); });
});
weCmd("redo", { desc: "Redo: //redo [times]", perm: "history.redo", aliases: ["/redo"] }, (p, args) => {
    let n = Math.max(1, Math.floor(Number(args[0])) || 1);
    RPG.edit.redo(p, n, {}).then((t) => { if (t.error && !t.changed) weErr(p, t.error); else weMsg(p, "&dRedid " + weNum(t.changed) + " blocks."); });
});
weCmd("clearhistory", { desc: "Forget your undo history", perm: "history.clear", aliases: ["/clearhistory"] }, (p) => { RPG.edit.clearHistory(p); weMsg(p, "&7History cleared."); });

// ---- general --------------------------------------------------------------------------------------
WE_CAT = "General";
weCmd("cancel", { desc: "Stop your running edits", perm: "cancel" }, (p) => { weMsg(p, "&e" + RPG.edit.cancel(p) + " edit(s) cancelled."); });
weCmd("limit", { desc: "Your own block change limit: //limit [blocks]  (no number = back to the default)", perm: "limit" }, (p, args) => {
    let max = WE_CFG.get("maxBlocks"), unl = RPG.perms.has(p, "worldedit.limit.unlimited");
    if (!args.length || args[0] === "default") { p.setVar("we_limit", -1); weMsg(p, "&dBlock change limit back to the default (" + (unl ? "none" : weNum(max)) + ")."); return; }
    let n = Math.floor(Number(args[0]));
    if (isNaN(n) || n < -1) throw new Error("Use: //limit [blocks]  (0 or -1 = as high as you are allowed)");
    if (n > max && !unl) throw new Error("Your maximum is " + weNum(max) + " (worldedit.limit.unlimited lifts it).");
    p.setVar("we_limit", n <= 0 ? -1 : n);
    weMsg(p, "&dBlock change limit: &f" + (n <= 0 ? (unl ? "none" : weNum(max)) : weNum(n)));
});
weCmd("gmask", { desc: "Global mask for your edits: //gmask [mask]  (no mask = off)", perm: "global-mask", aliases: ["/gmask"] }, (p, args) => {
    let m = args.join(" ").trim();
    if (m) RPG.edit.checkMask(m);
    p.setVar("we_gmask", m);
    weMsg(p, m ? "&dGlobal mask set: &f" + m + "&7 (//set, //replace, //walls, shapes, //generate, brushes...)" : "&7Global mask off.");
});

// ---- schematics ---------------------------------------------------------------------------------
WE_CAT = "Clipboard";
weCmd("schem", { desc: "//schem save|load|list|delete <name>  (ragnarok_rpg/schematics/)", perm: "schematic", aliases: ["schematic"],
    suggest: (p, a) => a.length <= 1 ? ["save", "load", "list", "delete"] : RPG.edit.schemList() }, (p, args) => {
    let sub = String(args[0] || "list").toLowerCase(), name = args[1];
    if (sub === "list") {
        let l = RPG.edit.schemList();
        weMsg(p, l.length ? "&dSchematics: &f" + l.join("&7, &f") : "&7No schematics yet (//schem save <name>).");
        return;
    }
    if (!name) throw new Error("Use: //schem " + sub + " <name>");
    if (!RPG.perms.has(p, "worldedit.schematic." + sub)) throw new Error("You don't have permission (worldedit.schematic." + sub + ").");
    if (sub === "save") {
        if (RPG.edit.schemExists(name) && !weFlag(args, "-f")) throw new Error(name + " exists; add -f to overwrite.");
        RPG.edit.schemSave(p, name, (r) => r.ok ? weMsg(p, "&aSaved &f" + name + ".schem &7(" + weNum(r.bytes / 1024) + " KB)") : weErr(p, "Could not save: " + r.error));
    } else if (sub === "load") {
        RPG.edit.schemLoad(p, name, (r) => {
            if (!r.ok) { weErr(p, "Could not load: " + r.error); return; }
            p.setVar("we_clip_origin", null);
            weMsg(p, "&aLoaded &f" + name + "&a into your clipboard (" + r.width + "x" + r.height + "x" + r.length + "). //paste it.");
        });
    } else if (sub === "delete") {
        weMsg(p, RPG.edit.schemDelete(name) ? "&7Deleted " + name + "." : "&cNo schematic called " + name);
    } else throw new Error("Use: //schem save|load|list|delete <name>");
});
