// =====================================================================================
//  WorldEdit - navigation: /unstuck /ascend /descend /ceil /thru /jumpto /up
//  (WorldEdit has no /top; the Essentials addon's /top does that.)
// =====================================================================================
WE_CAT = "Navigation";

function weSolid(dim, x, y, z) { return RPG.edit.test(dim, x, y, z, "#solid"); }
/** A spot a player fits in: two non-solid blocks. */
function weFree(dim, x, y, z) { return !weSolid(dim, x, y, z) && !weSolid(dim, x, y + 1, z); }
function weGo(p, x, y, z, msg) {
    p.teleport(x, y, z);
    p.fallDistance = 0;
    if (msg) weMsg(p, msg);
}
/** Puts the platform block under (x, y, z) when there is nothing there (not recorded in //undo, like WorldEdit). */
function wePlatform(p, x, y, z) {
    if (!weSolid(p.dimension, x, y - 1, z)) RPG.world.setBlock(p.dimension, x, y - 1, z, WE_CFG.get("platform"));
}

weCmd("/unstuck", { desc: "Get out of blocks you are stuck in", perm: "navigation.unstuck", aliases: ["/!"] }, (p) => {
    let x = Math.floor(p.x), z = Math.floor(p.z), h = weHeights(p.dimension);
    for (let y = Math.floor(p.y); y < h.max; y++) {
        if (weFree(p.dimension, x, y, z)) {
            if (y === Math.floor(p.y)) { weMsg(p, "&7You're not stuck."); return; }
            weGo(p, p.x, y, p.z, "&dThere you go!");
            return;
        }
    }
    throw new Error("No free spot above you.");
});

/** The feet height of the next floor above (levels times), or null. */
function weAscend(p, levels) {
    // standing on a thin block (carpet, slab) counts as being in the block above it
    let y = p.y > Math.floor(p.y) + 0.001 ? Math.floor(p.y) + 1 : Math.floor(p.y);
    let x = Math.floor(p.x), z = Math.floor(p.z), h = weHeights(p.dimension), found = null;
    for (let l = 0; l < levels; l++) {
        let next = null;
        for (let yy = y + 1; yy < h.max; yy++)
            if (weSolid(p.dimension, x, yy - 1, z) && yy - 1 >= y && weFree(p.dimension, x, yy, z)) { next = yy; break; }
        if (next === null) break;
        found = y = next;
    }
    return found;
}
function weDescend(p, levels) {
    let x = Math.floor(p.x), z = Math.floor(p.z), h = weHeights(p.dimension), y = Math.floor(p.y), found = null;
    for (let l = 0; l < levels; l++) {
        let next = null;
        for (let yy = y - 3; yy > h.min; yy--)
            if (weSolid(p.dimension, x, yy - 1, z) && weFree(p.dimension, x, yy, z)) { next = yy; break; }
        if (next === null) break;
        found = y = next;
    }
    return found;
}
weCmd("/ascend", { desc: "Go up a floor: /ascend [levels]", perm: "navigation.ascend", aliases: ["/asc"] }, (p, args) => {
    let n = Math.max(1, Math.floor(Number(args[0])) || 1), y = weAscend(p, n);
    if (y === null) throw new Error("No free spot above you found.");
    weGo(p, Math.floor(p.x) + 0.5, y, Math.floor(p.z) + 0.5, "&dAscended " + (n > 1 ? n + " levels." : "a level."));
});
weCmd("/descend", { desc: "Go down a floor: /descend [levels]", perm: "navigation.descend", aliases: ["/desc"] }, (p, args) => {
    let n = Math.max(1, Math.floor(Number(args[0])) || 1), y = weDescend(p, n);
    if (y === null) throw new Error("No free spot below you found.");
    weGo(p, Math.floor(p.x) + 0.5, y, Math.floor(p.z) + 0.5, "&dDescended " + (n > 1 ? n + " levels." : "a level."));
});
weCmd("/ceil", { desc: "Go up to the ceiling: /ceil [clearance] [-f fly] [-g platform]", perm: "navigation.ceiling" }, (p, args) => {
    let fly = weFlag(args, "-f"); weFlag(args, "-g");
    let clear = Math.max(0, Math.floor(Number(args[0])) || 0);
    let x = Math.floor(p.x), z = Math.floor(p.z), y0 = Math.floor(p.y), h = weHeights(p.dimension);
    for (let y = y0 + 2; y <= h.max; y++) {
        if (!weSolid(p.dimension, x, y, z)) continue;
        let feet = y - 2 - clear;
        if (feet <= y0) throw new Error("No room under the ceiling.");
        if (fly && RPG.perms.has(p, "worldedit.navigation.ceiling.fly")) p.setFlying(true); else wePlatform(p, x, feet, z);
        weGo(p, x + 0.5, feet, z + 0.5, "&dWoosh!");
        return;
    }
    throw new Error("No ceiling above you.");
});
weCmd("/up", { desc: "Go straight up: /up <distance> [-f fly] [-g platform]", perm: "navigation.up" }, (p, args) => {
    let fly = weFlag(args, "-f"); weFlag(args, "-g");
    let d = Math.floor(Number(args[0]));
    if (isNaN(d) || d < 1) throw new Error("Use: /up <distance>");
    let x = Math.floor(p.x), z = Math.floor(p.z), y0 = Math.floor(p.y), h = weHeights(p.dimension), feet = y0 + d;
    if (feet + 1 > h.max) throw new Error("That's above the build limit.");
    for (let y = y0 + 2; y <= feet + 1; y++) if (weSolid(p.dimension, x, y, z)) throw new Error("You would hit something above you.");
    if (fly && RPG.perms.has(p, "worldedit.navigation.up.fly")) p.setFlying(true); else wePlatform(p, x, feet, z);
    weGo(p, x + 0.5, feet, z + 0.5, "&dWoosh!");
});

/** The first spot past the wall in front of you (up/down: the next floor), or null. */
function weThru(p) {
    let d = weDir(p, "me");
    if (d[1] > 0) { let y = weAscend(p, 1); return y === null ? null : [Math.floor(p.x), y, Math.floor(p.z)]; }
    if (d[1] < 0) { let y = weDescend(p, 1); return y === null ? null : [Math.floor(p.x), y, Math.floor(p.z)]; }
    let x = Math.floor(p.x), y = Math.floor(p.y), z = Math.floor(p.z), wall = false;
    for (let i = 1; i <= 64; i++) {
        x += d[0]; z += d[2];
        let free = weFree(p.dimension, x, y, z);
        if (!free) wall = true;
        else if (wall) return [x, y, z];
    }
    return null;
}
weCmd("/thru", { desc: "Pass through the wall in front of you", perm: "navigation.thru.command" }, (p) => {
    let at = weThru(p);
    if (!at) throw new Error("Nothing to pass through (or no free spot past it).");
    weGo(p, at[0] + 0.5, at[1], at[2] + 0.5, "&dWhoosh!");
});
/** Stands you on top of the block you look at. */
function weJumpTo(p, range) {
    let at = p.lookBlock(range || 300);
    if (!at) return false;
    let h = weHeights(p.dimension);
    for (let y = at[1] + 1; y < h.max; y++)
        if (weFree(p.dimension, at[0], y, at[2])) { weGo(p, at[0] + 0.5, y, at[2] + 0.5, "&dPoof!"); return true; }
    return false;
}
weCmd("/jumpto", { desc: "Teleport to the block you look at", perm: "navigation.jumpto.command", aliases: ["/j"] }, (p) => {
    if (!weJumpTo(p, 300)) throw new Error("No block in sight (or no room on top of it).");
});
