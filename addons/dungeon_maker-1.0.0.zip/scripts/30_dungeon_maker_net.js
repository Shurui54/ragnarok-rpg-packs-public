// =====================================================================================
//  Dungeon Maker - what the menus and editors ask for, and the /dungeons command
// =====================================================================================
//  Everything from client screens comes in on one channel ("dmk", {op, ...}) and is checked
//  here: staff actions need DungeonMaker.isAdmin, values are clamped, item fields are read
//  from the player's own hand or inventory on the server, never trusted from the message.
// =====================================================================================
(function () {
    var DM = DungeonMaker, RUNS = DM.runs;
    var UPLOADS = {};                  // uuid -> {id, n, got, s: []} card pictures arriving in pieces
    var MAX_IMG = 240000;              // base64 characters (~180 KB of PNG)

    function deny(p) { p.actionbar("&cOnly dungeon staff can do that"); }
    function editable(p, id) {
        if (!DM.isAdmin(p)) { deny(p); return null; }
        var d = DM.worldDef(id);
        if (!d) { p.actionbar(DM.isFile(id) ? "&cThis dungeon was loaded from a file and can't be edited here" : "&cNo such dungeon"); return null; }
        return d;
    }
    function result(p, ok, msg) { RPG.net.send(p, "dmk_msg", { ok: !!ok, msg: String(msg) }); if (!ok) p.actionbar("&c" + msg); }

    // ---- the editable card (what the card editor screen gets) ----
    function cardData(p, d) {
        return {
            id: d.id, name: d.name, description: d.description || "", level: d.level || "", time: d.time || "", difficulty: d.difficulty | 0,
            timeLimit: d.timeLimit | 0, cooldown: d.cooldown | 0, status: d.status, icon: d.icon, image: d.image,
            imageHash: (DM.image(d.id) || {}).h || "",
            requirements: (d.requirements || []).map(function (r) { var c = JSON.parse(JSON.stringify(r)); c.text = DM.requirementText(r); return c; }),
            objectives: (d.objectives || []).map(function (o, i) { var c = JSON.parse(JSON.stringify(o)); c.text = DM.objectiveText(o); c.was = i; return c; }),
            // puzzle and room goals pick from the dungeon's puzzles and rooms (Puzzle / Room Wand)
            puzzles: DM.wands ? Object.keys(DM.wands.get(d.id).puzzles).map(function (k) { var z = DM.wands.get(d.id).puzzles[k]; return { id: z.id, name: z.name }; }) : [],
            rooms: DM.wands ? Object.keys(DM.wands.get(d.id).rooms).map(function (k) { var r = DM.wands.get(d.id).rooms[k]; return { id: r.id, name: r.name }; }) : [],
            dungeons: DM.allIds().filter(function (i) { return i !== d.id; }).map(function (i) { var o = DM.def(i); return { id: i, name: o ? o.name : i }; }),
            levelName: DM.hooks.levelName, xpLevelRule: !!DM.hooks.xpLevelRule, held: DM.cleanStack(p.getHeldStack()),
            heldName: p.getHeldStack() ? DM.itemName(p.getHeldStack().id) : ""
        };
    }

    function saveCard(p, msg) {
        var d = editable(p, msg.id);
        if (!d) return;
        var c = msg.card || {};
        var name = DM.str(c.name, 48).trim();
        if (!name) { result(p, false, "Enter a dungeon name"); return; }
        d.name = name;
        d.description = DM.str(c.description, 400);
        d.level = DM.str(c.level, 16);
        d.time = DM.str(c.time, 24);
        d.difficulty = DM.clampInt(c.difficulty, 0, 4, 1);
        d.timeLimit = DM.clampInt(c.timeLimit, 0, 86400, 0);
        d.cooldown = DM.clampInt(c.cooldown, 0, 86400 * 30, 0);
        if (c.iconFromHand) { var h = DM.cleanStack(p.getHeldStack()); if (h) d.icon = { id: h.id, count: 1, nbt: h.nbt }; }
        if (c.clearIcon) d.icon = null;
        if (c.imagePath !== undefined) {
            var path = DM.str(c.imagePath, 160).trim();
            if (path) d.image = { kind: "path", path: path };
            else if (d.image && d.image.kind === "path") d.image = null;
        }
        if (c.status === "published" || c.status === "draft") d.status = c.status;
        // requirements: items come from what the client says was in hand when added, re-read here
        var held = DM.cleanStack(p.getHeldStack());
        d.requirements = (Array.isArray(c.requirements) ? c.requirements : []).slice(0, 12).map(function (r) {
            switch (r && r.type) {
                case "item": {
                    var it = r.fromHand && held && r.item && held.id === r.item.id ? held : DM.cleanStack(r.item);
                    if (!it) return null;
                    return { type: "item", item: { id: it.id, nbt: it.nbt }, count: DM.clampInt(r.count, 1, 2304, 1), consume: !!r.consume };
                }
                case "level": return { type: "level", level: DM.clampInt(r.level, 1, 100000000, 1) };
                case "xp_level": return { type: "xp_level", level: DM.clampInt(r.level, 1, 100000, 1) };
                case "completed": { var id = DM.str(r.id, 48); return id && id !== d.id ? { type: "completed", id: id } : null; }
                case "cooldown": return { type: "cooldown", seconds: DM.clampInt(r.seconds, 1, 86400 * 30, 60) };
            }
            return null;
        }).filter(function (r) { return r; });
        // goals (shared with the Puzzle Wand's goals tab): checked in 35_dungeon_maker_wands.js, rewards kept
        d.objectives = DM.wands.cleanObjectives(d.id, c.objectives, d.objectives, held);
        DM.saveDef(d);
        result(p, true, "Dungeon '" + d.name + "' saved");
        DM.sendBig(p, "card", cardData(p, d));
    }

    // ---- card pictures: uploads in pieces, then shared with everyone who asks ----
    function imageUpload(p, m) {
        var d = editable(p, m.id);
        if (!d) return;
        var u = DM.uid(p), n = DM.clampInt(m.n, 1, 20, 1), i = DM.clampInt(m.i, 0, n - 1, 0);
        var box = UPLOADS[u];
        if (!box || box.id !== m.id || box.tag !== m.tag) box = UPLOADS[u] = { id: m.id, tag: m.tag, n: n, got: 0, s: [] };
        if (box.s[i] === undefined) { box.s[i] = String(m.s || ""); box.got++; }
        if (box.got < box.n) return;
        delete UPLOADS[u];
        var png = box.s.join("");
        if (png.length > MAX_IMG || !/^[A-Za-z0-9+/=]+$/.test(png) || png.indexOf("iVBORw0KGgo") !== 0) { result(p, false, "Could not store the picture (PNG, at most ~180 KB)"); return; }
        var h = DM.hashOf(png);
        RPG.data.set("dmk_img_" + d.id, { h: h, png: png, w: DM.clampInt(m.w, 1, 4096, 320), ht: DM.clampInt(m.h, 1, 4096, 180) });
        d.image = { kind: "upload" };
        DM.saveDef(d);
        result(p, true, "Picture uploaded: everyone sees it now");
        DM.sendBig(p, "card", cardData(p, d));
    }
    function sendImage(p, id) {
        var img = DM.image(id);
        if (!img || !img.png) return;
        DM.sendBig(p, "img", { id: id, h: img.h, png: img.png });
    }

    // ---- anchors ----
    /** {d, A, a, save(), open(p)} for the anchor ops; m.paint: a module painted in the dungeon painter (keyed by its cell). */
    function anchorAt(p, m) {
        if (!DM.isAdmin(p)) { deny(p); return null; }
        if (m.paint) {
            var pa = DM.paint ? DM.paint.anchorAt(p, m) : null;
            if (!pa) result(p, false, "That painted module is gone");
            return pa;
        }
        var d = DM.worldDef(m.dungeon);
        if (!d) return null;
        var A = DM.anchors(d.id), a = A[m.key];
        if (!a) { result(p, false, "That anchor is gone"); return null; }
        return { d: d, A: A, a: a, save: function () { DM.saveAnchors(d.id); }, open: function (pl) { DM.openAnchor(pl, d, m.key); } };
    }
    function anchorBlockPos(d, key) { var r = DM.parseKey(key), o = DM.plotOrigin(d.plot); return { x: o.x + r.dx, y: o.y + r.dy, z: o.z + r.dz }; }

    RPG.net.on("dmk", function (p, m) {
        if (!m || typeof m.op !== "string") return;
        switch (m.op) {
            case "menu": DM.sendMenu(p); break;
            case "entities": DM.sendBig(p, "entities", DM.entityChoices()); break;
            case "enter": if (RUNS.start(p, String(m.id))) RPG.net.send(p, "dmk_close", {}); break;
            case "leave": if (RUNS.leave(p)) RPG.net.send(p, "dmk_close", {}); break;
            case "img_get": sendImage(p, String(m.id)); break;

            // ---- admin ----
            case "create": {
                if (!DM.isAdmin(p)) { deny(p); return; }
                var r = DM.create(p, m.name);
                if (r.error) result(p, false, r.error);
                else { p.tell("&6[Dungeons] &eDungeon '" + r.def.name + "' created (id " + r.def.id + "). Build it on this plot, place anchors, then publish it from the menu."); RPG.net.send(p, "dmk_close", {}); }
                break;
            }
            case "card": { var d = editable(p, String(m.id)); if (d) DM.sendBig(p, "card", cardData(p, d)); break; }
            case "save_card": saveCard(p, m); break;
            case "publish": {
                var d2 = editable(p, String(m.id));
                if (!d2) return;
                d2.status = d2.status === "published" ? "draft" : "published";
                DM.saveDef(d2);
                p.tell("&6[Dungeons] &e'" + d2.name + "' " + (d2.status === "published" ? "published" : "moved back to draft"));
                DM.sendMenu(p, { select: d2.id });
                break;
            }
            case "plot": { var d3 = editable(p, String(m.id)); if (d3) { DM.goToPlot(p, d3.id); RPG.net.send(p, "dmk_close", {}); } break; }
            case "back": {
                if (!DM.isAdmin(p)) { deny(p); return; }
                if (p.dimension !== DM.WORKSHOP) { p.actionbar("&7You are not in the workshop"); return; }
                DM.sendBack(p); RPG.net.send(p, "dmk_close", {});
                break;
            }
            case "delete": {
                var d4 = editable(p, String(m.id));
                if (!d4) return;
                DM.remove(d4.id);
                p.tell("&6[Dungeons] &eDungeon '" + d4.name + "' deleted (its build stays on the workshop plot)");
                DM.sendMenu(p);
                break;
            }
            case "export": {
                var d5 = editable(p, String(m.id));
                if (!d5) return;
                p.actionbar("&eExporting " + d5.name + "...");
                DM.exportDungeon(p, d5.id, function (res) {
                    if (res.error) { result(p, false, "Export failed: " + res.error); return; }
                    p.tell("&6[Dungeons] &eExported '" + d5.name + "' to &f" + res.path + "&e. Other worlds pick it up after /rpg reload.");
                    result(p, true, "Exported");
                });
                break;
            }
            case "img_up": imageUpload(p, m); break;
            case "img_clear": {
                var d6 = editable(p, String(m.id));
                if (!d6) return;
                RPG.data.remove("dmk_img_" + d6.id);
                if (d6.image && d6.image.kind === "upload") d6.image = null;
                DM.saveDef(d6);
                result(p, true, "Picture removed");
                DM.sendBig(p, "card", cardData(p, d6));
                break;
            }

            // ---- anchors ----
            case "anchor_type": {
                var at = anchorAt(p, m);
                if (!at || at.paint || DM.TYPES.indexOf(m.type) < 0) return;
                var pos = anchorBlockPos(at.d, m.key);
                RPG.world.setBlock(DM.WORKSHOP, pos.x, pos.y, pos.z, DM.BLOCK[m.type]);
                at.A[m.key] = { type: m.type, cfg: DM.defaultConfig(m.type) };
                DM.saveAnchors(at.d.id);
                DM.openAnchor(p, at.d, m.key);
                break;
            }
            case "anchor_save": {
                var as = anchorAt(p, m);
                if (!as) return;
                var cfg = DM.sanitizeConfig(as.a.type, m.cfg, as.a.cfg, m.key);
                if ((as.a.type === "spawner" || as.a.type === "boss") && cfg.nbt && !RPG.server.isValidNbt(cfg.nbt)) { result(p, false, "That spawn NBT is not valid: not saved"); return; }
                if (as.paint && DM.DOOR_TYPES[as.a.type]) { cfg.zone = as.a.cfg.zone; cfg.c1 = as.a.cfg.c1; cfg.c2 = as.a.cfg.c2; }
                as.a.cfg = cfg;
                as.save();
                result(p, true, "Anchor saved");
                if (m.reopen) as.open(p);
                break;
            }
            case "door_key": {
                var dk = anchorAt(p, m);
                if (!dk || dk.a.type !== "door") return;
                var held = DM.cleanStack(p.getHeldStack());
                dk.a.cfg.key = m.clear ? null : held ? { id: held.id, count: 1, nbt: held.nbt } : dk.a.cfg.key;
                if (!m.clear && !held) result(p, false, "Hold the key item in your main hand");
                dk.save();
                dk.open(p);
                break;
            }
            case "door_marker": {
                var dm = anchorAt(p, m);
                if (!dm || dm.paint || !DM.ZONE_TYPES[dm.a.type]) return;
                var o = DM.plotOrigin(dm.d.plot), n = m.n === 2 ? "c2" : "c1";
                if (m.clear) { dm.a.cfg[n] = null; if (!dm.a.cfg.c1 && !dm.a.cfg.c2 && dm.a.cfg.zone === "box") dm.a.cfg.zone = "radius"; }
                else {
                    var bx = Math.floor(p.x), by = Math.floor(p.y), bz = Math.floor(p.z);
                    if (p.dimension !== DM.WORKSHOP || DM.plotAt(bx, bz) !== dm.d.plot) { result(p, false, "Stand on this dungeon's plot"); return; }
                    dm.a.cfg[n] = [bx - o.x, by - o.y, bz - o.z];
                    if (dm.a.cfg.zone !== "self") dm.a.cfg.zone = "box";
                }
                DM.saveAnchors(dm.d.id);
                DM.openAnchor(p, dm.d, m.key);
                break;
            }
            case "loot_items": {
                var li = anchorAt(p, m);
                if (!li || !DM.CHEST_TYPES[li.a.type]) return;
                RPG.ui.container(p, { title: DM.typeName(li.a.type) + ": items", rows: 3, items: li.a.cfg.items || [], mode: "storage",
                    onClose: function (pl, items) {
                        li.a.cfg.items = (items || []).slice(0, 27).map(function (s) { return DM.cleanStack(s); });
                        li.save();
                        RPG.schedule(1, function () { li.open(pl); });
                    } });
                break;
            }
            case "inventory": RPG.net.send(p, "dmk_inv", DM.inventoryOf(p)); break;
            case "link_pick": { var lp = anchorAt(p, m); if (!lp || lp.paint || !DM.SOURCE_TYPES[lp.a.type]) return; DM.startPick(p, lp.d, m.key); RPG.net.send(p, "dmk_close", {}); break; }
            case "link_toggle": {
                var lt = anchorAt(p, m);
                if (!lt || !DM.SOURCE_TYPES[lt.a.type] || !DM.KEY_RE.test(String(m.to))) return;
                if (lt.paint) DM.paint.toggleLink(p, lt.d, m.key, String(m.to)); else DM.toggleLink(p, lt.d, m.key, String(m.to));
                lt.open(p);
                break;
            }
            case "blocks": {
                if (!DM.isAdmin(p)) { deny(p); return; }
                DM.sendBig(p, "blocks", { blocks: Object.keys(DM.blockIds()).sort(),
                    items: DM.tools.itemChoices() });
                break;
            }
            case "wands": if (!DM.isAdmin(p)) { deny(p); return; } DM.wands.give(p, "all"); result(p, true, "Building wands given: they work on a dungeon's workshop plot"); break;
            case "import": {
                if (!DM.isAdmin(p)) { deny(p); return; }
                var fid = String(m.id || "");
                if (!DM.isFile(fid) && !DM.files()[fid]) { result(p, false, "That dungeon is not an exported file"); return; }
                DM.importFile(p, fid, function (res) {
                    if (res.error) { result(p, false, "Import failed: " + res.error); return; }
                    p.tell("&6[Dungeons] &eImported '" + res.def.name + "' as &f" + res.def.id + "&e (a draft with its own plot). Taking you there...");
                    DM.goToPlot(p, res.def.id);
                    RPG.net.send(p, "dmk_close", {});
                });
                break;
            }
            case "kit": if (!DM.isAdmin(p)) { deny(p); return; } DM.tools.giveKit(p); result(p, true, "Dungeon items given (they work inside runs)"); break;
            case "anchors": if (!DM.isAdmin(p)) { deny(p); return; } DM.giveAnchors(p); result(p, true, "Anchor blocks given: they work on a dungeon plot in the workshop"); break;
        }
    });

    // ---- /dungeons -------------------------------------------------------------------------------------------
    function list(p, tell) {
        var ids = DM.allIds();
        if (!ids.length) { tell("&7No dungeons yet. Make one with /dungeons create <name>."); return; }
        tell("&6Dungeons (" + ids.length + "):");
        ids.forEach(function (id) { var d = DM.def(id); tell("&7 - &f" + id + "&7: " + (d ? d.name : "?") + " [" + (d ? d.status : "?") + (DM.isFile(id) ? ", file" : "") + "]"); });
    }
    function run(p, args) {
        var tell = function (s) { if (p) p.tell(s); else RPG.log(s.replace(/&./g, "")); };
        var sub = (args[0] || "").toLowerCase(), rest = args.slice(1).join(" ");
        if (!sub || sub === "menu") { if (p) DM.sendMenu(p, { open: true }); return; }
        if (sub === "leave") { if (p) RUNS.leave(p); return; }
        if (sub === "list") { list(p, tell); return; }
        if (p && !DM.isAdmin(p)) { tell("&cOnly dungeon staff can use /dungeons " + sub); return; }
        var d = rest ? DM.def(rest) : null;
        switch (sub) {
            case "create": { if (!p) return; var r = DM.create(p, rest); tell(r.error ? "&c" + r.error : "&eDungeon '" + r.def.name + "' created (id " + r.def.id + "). Teleporting to the workshop..."); return; }
            case "tp": case "plot": if (!p) return; if (!d || !DM.worldDef(rest)) { tell("&cNo dungeon with id '" + rest + "'"); return; } DM.goToPlot(p, rest); tell("&eTeleported to '" + d.name + "'"); return;
            case "back": if (!p) return; tell(DM.sendBack(p) ? "&eTeleported back" : "&7No return point stored: sent to spawn"); return;
            case "delete": if (!DM.worldDef(rest)) { tell("&cNo dungeon with id '" + rest + "'"); return; } DM.remove(rest); tell("&eDungeon '" + rest + "' deleted"); return;
            case "publish": case "unpublish": {
                var w = DM.worldDef(rest);
                if (!w) { tell("&cNo dungeon with id '" + rest + "'"); return; }
                w.status = sub === "publish" ? "published" : "draft"; DM.saveDef(w); tell("&e'" + w.name + "' is now " + w.status); return;
            }
            case "export": {
                if (!DM.worldDef(rest)) { tell("&cNo dungeon with id '" + rest + "'"); return; }
                DM.exportDungeon(p, rest, function (res) { tell(res.error ? "&cExport failed: " + res.error : "&eExported to " + res.path + ". Other worlds load it after /rpg reload."); });
                return;
            }
            case "paint": if (!p) return; if (!DM.worldDef(rest)) { tell("&cNo dungeon made in this world with id '" + rest + "'"); return; } DM.paint.open(p, rest); return;
            case "anchors": if (!p) return; DM.giveAnchors(p); tell("&eAnchor blocks given. Place them on a dungeon plot in the workshop and right-click them."); return;
            case "wand": case "wands": {
                if (!p) return;
                var which = (args[1] || "all").toLowerCase();
                if (which !== "all" && DM.wands.WANDS.indexOf(which) < 0) { tell("&c/dungeons wand <dungeon|room|puzzle|connection|all>"); return; }
                DM.wands.give(p, which);
                tell("&eWand" + (which === "all" ? "s" : "") + " given. They work on a dungeon's workshop plot; right-click the air with one for its screen (? there explains it).");
                return;
            }
            case "import": {
                if (!DM.files()[rest]) { tell("&cNo exported dungeon '" + rest + "' (see /dungeons list; files are marked 'file')"); return; }
                DM.importFile(p, rest, function (res) {
                    if (res.error) { tell("&cImport failed: " + res.error); return; }
                    tell("&eImported '" + res.def.name + "' as " + res.def.id + " (a draft with its own workshop plot)");
                    if (p) DM.goToPlot(p, res.def.id);
                });
                return;
            }
            case "kit": if (!p) return; DM.tools.giveKit(p); tell("&eDungeon items given: bow, bombs, grapple claw, lantern, keys and hearts (they work inside runs)."); return;
            case "reload": DM.loadFiles(); tell("&eExported dungeons read again (" + Object.keys(DM.files()).length + ")"); return;
            case "enter": if (!p) return; if (!d) { tell("&cNo dungeon with id '" + rest + "'"); return; } RUNS.start(p, rest); return;
            case "runs": { var rs = RUNS.list(); tell("&6Runs (" + rs.length + "):"); rs.forEach(function (r) { tell("&7 - " + r.id + " " + r.name + " slot " + r.slot + ", " + r.members + " player(s), " + r.state); }); return; }
            case "stop": tell(RUNS.stop(rest) ? "&eRun " + rest + " stopped" : "&cNo run " + rest); return;
        }
        tell("&7/dungeons [menu|list|leave|create <name>|tp <id>|paint <id>|back|anchors|kit|wand <type>|import <file id>|publish <id>|unpublish <id>|delete <id>|export <id>|enter <id>|runs|stop <run>|reload]");
    }
    function suggest(p, args) {
        if (args.length <= 1) return ["menu", "list", "leave"].concat(p && !DM.isAdmin(p) ? [] : ["create", "tp", "paint", "back", "anchors", "kit", "wand", "import", "publish", "unpublish", "delete", "export", "enter", "runs", "stop", "reload"]);
        if (["tp", "plot", "paint", "delete", "publish", "unpublish", "export", "enter"].indexOf(String(args[0]).toLowerCase()) >= 0) return DM.allIds();
        if (String(args[0]).toLowerCase() === "wand") return DM.wands.WANDS.concat(["all"]);
        if (String(args[0]).toLowerCase() === "import") return Object.keys(DM.files());
        return [];
    }
    DM.command = run;
    DM.suggest = suggest;
    RPG.commands.register("dungeons", {
        root: true, aliases: ["dungeonmaker"], permission: 0, description: "Dungeon Selection menu and dungeon staff tools", run: run,
        suggest: suggest
    });

    // addons that load before this one (lower loadOrder) leave their settings in DUNGEON_MAKER_SETUP:
    //   var DUNGEON_MAKER_SETUP = (typeof DUNGEON_MAKER_SETUP !== "undefined" ? DUNGEON_MAKER_SETUP : []);
    //   DUNGEON_MAKER_SETUP.push(function (DM) { DM.hooks.levelName = "Power"; });
    if (typeof DUNGEON_MAKER_SETUP !== "undefined" && DUNGEON_MAKER_SETUP && DUNGEON_MAKER_SETUP.forEach)
        DUNGEON_MAKER_SETUP.forEach(function (fn) { try { fn(DM); } catch (e) { RPG.log("[Dungeon Maker] setup: " + e); } });
})();
