// =====================================================================================
//  Dungeon Maker - core: settings, saved dungeons, workshop plots, anchor blocks, export
// =====================================================================================
//  How it fits together:
//   - Staff (operators, or the "dungeonmaker.admin" permission) create a dungeon in the Dungeon
//     Selection menu (Admin > + New) or with /dungeons create <name>. It gets its own plot in the
//     private workshop dimension (ragnarok_rpg:dungeon_workshop, built into the engine) and they
//     are teleported there to build it with normal blocks.
//   - Anchor blocks (only placeable in the workshop) give the build its game rules: Mob Spawner,
//     Entry Point, Exit Point, Locked Door and Loot Point. Right-click one to set it up.
//   - The card (name, level, difficulty, time limit, cooldown, description, icon, picture), the
//     completion goals and the entry rules are edited from the menu. Publish = players see it.
//   - A run copies the plot's blocks into a fresh slot of the arena dimension
//     (ragnarok_rpg:dungeon_arena) for that player or party (20_dungeon_maker_runs.js).
//   - Export writes the dungeon to <game dir>/ragnarok_rpg/shared/dungeons/ and its blocks to
//     ragnarok_rpg/schematics/, so it shows up in every world on this computer/server.
//
//  Other scripts can adjust it through the DungeonMaker object, e.g. a game with its own level:
//     DungeonMaker.hooks.levelOf = function (p) { return myLevel(p); };
//     DungeonMaker.hooks.partyOf = function (p) { return myPartyOnlinePlayers(p); };
//     DungeonMaker.hooks.onComplete = function (def, players, run) { ... rewards ... };
// =====================================================================================
// the art (anchor blocks, menu panels, cards, icons) is the "dungeonpack" art pack: players are asked to download it
RPG.project.configure({ assetPacks: ["dungeonpack@1.1.0"] });

var DungeonMaker = (function () {
    var WORKSHOP = "ragnarok_rpg:dungeon_workshop", ARENA = "ragnarok_rpg:dungeon_arena";
    var SPACING = 1024, PLATFORM_Y = 64, MIN_Y = -64, MAX_Y = 319;
    var DIFFICULTIES = ["Easy", "Medium", "Hard", "Very Hard", "Epic"];
    var DIFF_COLORS = ["#7CD66B", "#E6D25A", "#E8963C", "#E05048", "#B060F0"];
    var COLORS = ["black", "dark_blue", "dark_green", "dark_aqua", "dark_red", "dark_purple", "gold", "gray", "dark_gray",
        "blue", "green", "aqua", "red", "light_purple", "yellow", "white"];
    // module types: the first five are the original anchors; new ones are only ever appended
    var TYPES = ["spawner", "entry", "exit", "door", "loot", "switch", "logic", "sk_door", "bk_door", "pz_door", "sk_chest", "bk_chest", "pz_chest", "bridge", "boss"];
    var DOOR_TYPES = { door: 1, sk_door: 1, bk_door: 1, pz_door: 1 };
    var CHEST_TYPES = { loot: 1, sk_chest: 1, bk_chest: 1, pz_chest: 1 };
    var ZONE_TYPES = { door: 1, sk_door: 1, bk_door: 1, pz_door: 1, bridge: 1 };
    /** Modules that send a signal down their links (switches, logic, a spawner whose mobs are all down, a defeated boss). */
    var SOURCE_TYPES = { "switch": 1, logic: 1, spawner: 1, boss: 1 };
    /** Modules a link can point at. */
    var INPUT_TYPES = { logic: 1, pz_door: 1, pz_chest: 1, bridge: 1, spawner: 1, boss: 1 };

    var CFG = RPG.config.define("dungeon_maker", {
        plotSize: { default: 192, min: 32, max: 960, integer: true, comment: "Width and length (blocks) of each dungeon's workshop plot. Only what is built inside it is copied into runs." },
        arenaSlots: { default: 64, min: 1, max: 512, integer: true, comment: "How many dungeon runs can be going at the same time." },
        maxBlocks: { default: 6000000, min: 10000, max: 50000000, integer: true, comment: "Largest build (blocks in its bounding box) a run may copy." },
        exitCountdown: { default: 10, min: 0, max: 120, integer: true, comment: "Seconds between finishing a dungeon and being sent back." },
        respawnInside: { default: true, comment: "Players who die in a run come back at its entry point while the run lasts (false: they are out)." },
        partyEntry: { default: true, comment: "Party members near the player who enters come along into the same run." },
        partyRange: { default: 32, min: 0, max: 512, integer: true, comment: "How close (blocks) a party member must be to come along." },
        arenaBlockEditing: { default: false, comment: "Let ordinary players break and place blocks inside runs." },
        arenaPvp: { default: false, comment: "Let players hurt each other inside runs." },
        emptyRunSeconds: { default: 60, min: 5, max: 3600, integer: true, comment: "A run nobody is online in is closed after this many seconds." },
        recoveryHeartPercent: { default: 20, min: 1, max: 100, integer: true, comment: "How much of a player's max health a Recovery Heart gives back (%, at least two hearts)." },
        heartContainerBonus: { default: 0, min: 0, max: 40, integer: true, comment: "Max health a Heart Container adds for good (0 = it only heals fully)." },
        bombDamage: { default: 8, min: 0, max: 100000, comment: "Damage a Bomb deals to mobs in its blast (players near it take 2)." },
        bossKeyUsedUp: { default: true, comment: "The boss door uses up the Boss Key like a Small Key (the big chest only needs it shown, and opens without it once the boss door took it). false: the Boss Key is kept for the whole run." },
        logDrops: { default: false, comment: "Write every mob drop roll to the log (for checking drop chances)." },
        menuKey: { default: true, client: true, comment: "Players get the Dungeon Selection key (O by default) and a button on the inventory screen." }
    });

    var hooks = {
        /** The level shown on cards and checked by "level" entry rules. */
        levelOf: function (p) { return p.getLevel(); },
        levelName: "Level",
        /** Whether staff may pick the vanilla XP level as an entry rule. */
        xpLevelRule: true,
        /** Online party members to bring along (the player not included). */
        partyOf: function (p) { try { return p.partyMembers() || []; } catch (e) { return []; } },
        /** After a run is completed (rewards, leaderboards...). */
        onComplete: null,
        /** Return false (or a message) to keep a player out. */
        canEnter: null,
        /** Heals a player by a share (0-1) of their max health (Recovery Hearts, Heart Containers); games with their own health replace it. */
        heal: function (p, share) { var max = p.maxHealth || 20; p.heal(Math.max(4, max * share)); },
        /** A Heart Container's lasting bonus (max health) when heartContainerBonus is above 0. */
        addMaxHealth: function (p, amount) { var m = (p.getVar("dmk_hearts", 0) | 0) + amount; p.setVar("dmk_hearts", m); p.setAttributeBase("generic.max_health", p.getAttributeBase("generic.max_health") + amount); p.heal(amount); }
    };

    // ---- small helpers -------------------------------------------------------------------
    function uid(p) { return String(p.uuid); }
    function now() { return Date.now(); }
    function tick() { return RPG.server.getTick(); }
    function isAdmin(p) { return !!p && (p.isOp() || (RPG.perms && RPG.perms.has(p, "dungeonmaker.admin"))); }
    function clampInt(v, a, b, d) { v = Math.floor(Number(v)); return isNaN(v) ? d : Math.max(a, Math.min(b, v)); }
    function str(v, max) { return String(v === undefined || v === null ? "" : v).replace(/[\u0000-\u001f]/g, "").substring(0, max || 64); }
    function online(u) { var l = RPG.server.players(); for (var i = 0; i < l.length; i++) if (String(l[i].uuid) === u) return l[i]; return null; }
    function human(secs) {
        secs = Math.max(0, Math.round(secs));
        var h = Math.floor(secs / 3600), m = Math.floor(secs % 3600 / 60), s = secs % 60, out = [];
        if (h) out.push(h + "h"); if (m) out.push(m + "m"); if (s || !out.length) out.push(s + "s");
        return out.join(" ");
    }
    function clock(secs) { secs = Math.max(0, Math.ceil(secs)); var m = Math.floor(secs / 60), s = secs % 60; return m + ":" + (s < 10 ? "0" : "") + s; }
    function slug(name) {
        var s = String(name || "").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "").substring(0, 32);
        return s || "dungeon";
    }
    function itemName(id) { try { return RPG.items.name(id); } catch (e) { return String(id); } }
    function entityName(id) {
        id = String(id || "");
        if (id.indexOf("rpgmob:") === 0) { try { return RPG.mobs.name(id.substring(7)); } catch (e) { } }
        if (id.indexOf("rpgnpc:") === 0) { try { return RPG.npcs.name(id.substring(7)); } catch (e) { } }
        if (id.indexOf("rpgboss:") === 0) { try { return RPG.bosses.name(id.substring(8)); } catch (e) { } }
        var p = id.split(":"), n = p[p.length - 1].replace(/_/g, " ");
        return n.charAt(0).toUpperCase() + n.substring(1);
    }
    function cleanStack(st) {
        if (!st || !st.id || st.id === "minecraft:air") return null;
        var o = { id: String(st.id), count: Math.max(1, Math.min(64, st.count | 0 || 1)) };
        if (st.nbt) o.nbt = String(st.nbt).substring(0, 8000);
        return o;
    }

    // Big payloads (menus, cards, pictures) go in pieces: RPG.net messages are ~30 KB at most.
    var CHUNK = 24000, sendSeq = 0;
    function sendBig(p, kind, obj) {
        var s = typeof obj === "string" ? obj : JSON.stringify(obj), n = Math.max(1, Math.ceil(s.length / CHUNK)), id = "b" + (++sendSeq);
        for (var i = 0; i < n; i++) RPG.net.send(p, "dmk_big", { kind: kind, id: id, i: i, n: n, s: s.substring(i * CHUNK, (i + 1) * CHUNK), str: typeof obj === "string" });
    }

    // ---- saved dungeons -------------------------------------------------------------------
    //  dmk_index {ids, nextPlot}; dmk_def_<id> the card, goals and rules; dmk_anc_<id> the anchors
    //  (keyed "dx,dy,dz" from the plot origin); dmk_img_<id> an uploaded card picture.
    var INDEX = null, DEFS = {}, ANCHORS = {}, FILES = {};
    function index() {
        if (!INDEX) INDEX = RPG.data.get("dmk_index", null) || { ids: [], nextPlot: 1 };
        return INDEX;
    }
    function saveIndex() { RPG.data.set("dmk_index", index()); }
    function worldDef(id) {
        if (DEFS[id] === undefined) DEFS[id] = index().ids.indexOf(id) >= 0 ? RPG.data.get("dmk_def_" + id, null) : null;
        return DEFS[id];
    }
    function def(id) { return worldDef(id) || (FILES[id] ? FILES[id].def : null); }
    function saveDef(d) { DEFS[d.id] = d; RPG.data.set("dmk_def_" + d.id, d); }
    function anchors(id) {
        if (FILES[id] && !worldDef(id)) return FILES[id].anchors || {};
        if (!ANCHORS[id]) ANCHORS[id] = migrateAll(RPG.data.get("dmk_anc_" + id, null) || {});
        return ANCHORS[id];
    }
    function saveAnchors(id) { RPG.data.set("dmk_anc_" + id, anchors(id)); if (DungeonMaker.sendLinksFor) DungeonMaker.sendLinksFor(id); }
    function allIds() {
        var out = index().ids.slice();
        Object.keys(FILES).forEach(function (k) { if (out.indexOf(k) < 0) out.push(k); });
        return out;
    }
    function isFile(id) { return !worldDef(id) && !!FILES[id]; }

    function newDef(id, name, author, plot) {
        return { id: id, name: name, description: "", author: author, icon: null, image: null, difficulty: 1, level: "", time: "",
            timeLimit: 0, cooldown: 0, status: "draft", plot: plot, requirements: [], objectives: [], created: now() };
    }

    // exported dungeons: <game dir>/ragnarok_rpg/shared/dungeons/<id>.json (+ schematics/dmk_<id>.schem)
    function loadFiles() {
        FILES = {};
        var list = [];
        try { list = RPG.files.listShared("dungeons"); } catch (e) { }
        list.forEach(function (f) {
            if (!/\.json$/.test(f)) return;
            try {
                var o = RPG.files.readShared(f);
                if (!o || !o.def || !o.def.id || !o.schem) return;
                o.def.source = "file";
                migrateAll(o.anchors || (o.anchors = {}));
                FILES[o.def.id] = o;
            } catch (e) { RPG.log("[Dungeon Maker] could not read " + f + ": " + e); }
        });
    }
    loadFiles();

    // ---- plots ------------------------------------------------------------------------------
    function plotOrigin(n) { return { x: n * SPACING, y: PLATFORM_Y, z: 0 }; }
    function plotBox(n) {
        var o = plotOrigin(n), h = Math.floor(CFG.get("plotSize") / 2);
        return { x1: o.x - h, y1: MIN_Y, z1: o.z - h, x2: o.x + h, y2: MAX_Y, z2: o.z + h };
    }
    function plotAt(x, z) {
        var n = Math.round(x / SPACING);
        if (n < 1) return 0;
        var b = plotBox(n);
        return x >= b.x1 && x <= b.x2 && z >= b.z1 && z <= b.z2 ? n : 0;
    }
    function dungeonOfPlot(n) {
        var ids = index().ids;
        for (var i = 0; i < ids.length; i++) { var d = worldDef(ids[i]); if (d && d.plot === n) return d; }
        return null;
    }
    /** The starting floor in the middle of a plot (only where there is nothing yet); then() once it is there. */
    function buildPlatform(n, then) {
        var o = plotOrigin(n);
        RPG.edit.set(null, WORKSHOP, { type: "cuboid", x1: o.x - 8, y1: o.y - 1, z1: o.z - 8, x2: o.x + 8, y2: o.y - 1, z2: o.z + 8 }, "minecraft:polished_andesite",
            { mask: "air", history: false, progress: false, label: "Workshop plot" }).then(function () {
                RPG.edit.set(null, WORKSHOP, { type: "walls", x1: o.x - 8, y1: o.y - 1, z1: o.z - 8, x2: o.x + 8, y2: o.y - 1, z2: o.z + 8 }, "minecraft:stone_bricks",
                    { mask: "minecraft:polished_andesite", history: false, progress: false, label: "Workshop plot" }).then(function () { if (then) then(); });
            });
    }
    function sendPlotOutline(p) {
        if (!p || p.dimension !== WORKSHOP) { RPG.net.send(p, "dmk_plot", null); return; }
        var n = plotAt(p.x, p.z), d = n ? dungeonOfPlot(n) : null;
        if (!n) { RPG.net.send(p, "dmk_plot", null); return; }
        var b = plotBox(n);
        var out = { x1: b.x1, z1: b.z1, x2: b.x2, z2: b.z2, y: PLATFORM_Y, name: d ? d.name : "Free plot", id: d ? d.id : "" };
        if (d && isAdmin(p)) { var L = linksPayload(d); out.lines = L.lines; out.zones = L.zones; }
        RPG.net.send(p, "dmk_plot", out);
        if (DungeonMaker.wands) DungeonMaker.wands.sendTo(p);
    }

    // ---- return points ----------------------------------------------------------------------
    function rememberReturn(p) {
        if (p.dimension === WORKSHOP || p.dimension === ARENA) return;
        p.setVar("dmk_ret", { d: p.dimension, x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch });
    }
    function sendBack(p) {
        var r = p.getVar("dmk_ret", null);
        if (r && r.d) { if (p.teleportTo(r.d, r.x, r.y, r.z, r.yaw || 0, r.pitch || 0)) return true; }
        var s = RPG.world.spawnPoint();
        p.teleportTo("minecraft:overworld", s.x + 0.5, s.y, s.z + 0.5);
        return false;
    }

    // ---- creating / deleting -------------------------------------------------------------------
    function create(p, name) {
        name = str(name, 48).trim();
        if (!name) return { error: "Enter a dungeon name" };
        var base = slug(name), id = base, k = 2;
        while (def(id)) id = base + "_" + (k++);
        var I = index(), plot = I.nextPlot++;
        I.ids.push(id);
        saveIndex();
        var d = newDef(id, name, p ? p.name : "server", plot);
        saveDef(d);
        ANCHORS[id] = {}; saveAnchors(id);
        if (p) goToPlot(p, id);
        return { def: d };
    }
    function goToPlot(p, id) {
        var d = worldDef(id);
        if (!d) return false;
        rememberReturn(p);
        var o = plotOrigin(d.plot);
        p.actionbar("&eOpening the workshop plot...");
        buildPlatform(d.plot, function () {
            p.teleportTo(WORKSHOP, o.x + 0.5, o.y, o.z + 0.5, 180, 0);
            if (p.getGameMode() === "survival" || p.getGameMode() === "adventure") p.setGameMode("creative");
            RPG.schedule(10, function () { sendPlotOutline(p); });
        });
        return true;
    }
    function remove(id) {
        var I = index(), i = I.ids.indexOf(id);
        if (i < 0) return false;
        I.ids.splice(i, 1);
        saveIndex();
        RPG.data.remove("dmk_def_" + id); RPG.data.remove("dmk_anc_" + id); RPG.data.remove("dmk_img_" + id);
        delete DEFS[id]; delete ANCHORS[id];
        if (DungeonMaker.paint) DungeonMaker.paint.forget(id);
        if (DungeonMaker.wands) DungeonMaker.wands.forget(id);
        return true;
    }

    // ---- anchor (module) blocks ----------------------------------------------------------------
    //  In the workshop every module is a marker block staff click to set up. In a run none of them
    //  shows: each is swapped for air, the block it is set to look like, or what it is in play (a
    //  chest, a lever, a floor switch...) by 20_dungeon_maker_runs.js.
    var BLOCK = {}, BLOCK_TYPE = {};
    var BLOCK_INFO = {
        anchor: { name: "&dDungeon Anchor", model: "dungeonpack:rpg/block/anchor" },
        spawner: { name: "&cDungeon Mob Spawner", model: "dungeonpack:rpg/block/spawner" },
        entry: { name: "&aDungeon Entry Point", model: "dungeonpack:rpg/block/entry" },
        exit: { name: "&bDungeon Exit Point", model: "dungeonpack:rpg/block/exit" },
        door: { name: "&6Dungeon Key Door", model: "dungeonpack:rpg/block/door" },
        loot: { name: "&eDungeon Loot Chest", model: "dungeonpack:rpg/block/loot" },
        "switch": { name: "&eDungeon Switch", model: "dungeonpack:rpg/block/switch" },
        logic: { name: "&dDungeon Logic Gate", model: "dungeonpack:rpg/block/logic" },
        sk_door: { name: "&7Dungeon Small Key Door", model: "dungeonpack:rpg/block/sk_door" },
        bk_door: { name: "&cDungeon Boss Key Door", model: "dungeonpack:rpg/block/bk_door" },
        pz_door: { name: "&9Dungeon Puzzle Door", model: "dungeonpack:rpg/block/pz_door" },
        sk_chest: { name: "&7Dungeon Small Key Chest", model: "dungeonpack:rpg/block/sk_chest" },
        bk_chest: { name: "&6Dungeon Big Key Chest", model: "dungeonpack:rpg/block/bk_chest" },
        pz_chest: { name: "&9Dungeon Puzzle Chest", model: "dungeonpack:rpg/block/pz_chest" },
        bridge: { name: "&bDungeon Bridge", model: "dungeonpack:rpg/block/bridge" },
        boss: { name: "&4Dungeon Boss Spawner", model: "dungeonpack:rpg/block/boss" }
    };
    Object.keys(BLOCK_INFO).forEach(function (t) {
        var info = BLOCK_INFO[t];
        var id = RPG.blocks.define("dmk_" + t, {
            name: info.name, model: info.model, hardness: 1.5, light: t === "exit" || t === "entry" ? 6 : 0,
            drops: [{ item: "dmk_" + t, count: 1 }],
            onUse: function (p, x, y, z) { useAnchor(p, t, x, y, z); },
            onPlace: function (p, x, y, z) { placedAnchor(p, t, x, y, z); },
            onBreak: function (p, x, y, z) { brokeAnchor(p, x, y, z); }
        });
        BLOCK[t] = "ragnarok_rpg:" + id;
        BLOCK_TYPE[BLOCK[t]] = t;
    });
    /** One of each anchor block, for staff. */
    function giveAnchors(p) {
        Object.keys(BLOCK_INFO).forEach(function (t) { p.giveItem("dmk_" + t, t === "spawner" || t === "switch" ? 4 : 1); });
        if (DungeonMaker.tools) DungeonMaker.tools.giveBlocks(p);
    }
    function anchorTypeOf(blockId) { return BLOCK_TYPE[String(blockId).split("[")[0]] || null; }
    function relKey(n, x, y, z) { var o = plotOrigin(n); return (x - o.x) + "," + (y - o.y) + "," + (z - o.z); }
    function parseKey(k) { var a = String(k).split(","); return { dx: a[0] | 0, dy: a[1] | 0, dz: a[2] | 0 }; }
    var KEY_RE = /^-?\d{1,4},-?\d{1,4},-?\d{1,4}$/;
    var BLOCK_RE = /^[a-z0-9_.\-]+:[a-z0-9_.\-\/]+$/;

    function zoneDefaults(o) { o.zone = "radius"; o.radius = 2; o.blocks = []; o.c1 = null; o.c2 = null; return o; }
    function defaultConfig(type) {
        switch (type) {
            case "spawner": return { name: "", groups: [], radius: 8, trigger: "radius", glow: false, glowColor: "red", stats: {}, equip: {}, nbt: "", drops: [], links: [], disguise: "auto" };
            case "entry": return { facing: "south", disguise: "auto" };
            case "exit": return { radius: 3, disguise: "auto" };
            case "door": return zoneDefaults({ name: "", key: null, consume: true, disguise: "auto" });
            case "sk_door": case "bk_door": return zoneDefaults({ name: "", disguise: "auto" });
            case "pz_door": return zoneDefaults({ name: "", closeOff: false, disguise: "auto" });
            case "loot": case "sk_chest": case "bk_chest": return { name: "", items: [], chances: [], facing: "south" };
            case "pz_chest": return { name: "", items: [], chances: [], facing: "south", disguise: "auto" };
            case "switch": return { name: "", kind: "lever", mode: "toggle", time: 5, face: "floor", startOn: false, links: [] };
            case "logic": return { name: "", op: "and", order: [], latch: false, links: [], disguise: "auto" };
            case "bridge": return zoneDefaults({ name: "", start: "hidden", latch: true, disguise: "auto" });
            case "boss": return { name: "", entity: "", bossName: "", trigger: "radius", radius: 10, lock: true, lockRadius: 16, bar: true, barColor: "red",
                stats: {}, equip: {}, nbt: "", drops: [], heart: true, links: [], disguise: "auto" };
        }
        return {};
    }
    // old Locked Door modules (before zones): their two corners are the door, or with no corners the module itself
    function migrate(a) {
        if (!a || !a.cfg) return a;
        var c = a.cfg;
        if (a.type === "door" && c.zone === undefined) { c.zone = c.c1 && c.c2 ? "box" : "self"; c.radius = 2; c.blocks = []; }
        if (c.disguise === undefined && a.type !== "switch" && !CHEST_TYPES[a.type] || a.type === "pz_chest" && c.disguise === undefined) c.disguise = "auto";
        return a;
    }
    function migrateAll(A) { Object.keys(A).forEach(function (k) { migrate(A[k]); }); return A; }

    function cleanLinks(list, self) {
        var out = [];
        (Array.isArray(list) ? list : []).forEach(function (k) { k = String(k); if (KEY_RE.test(k) && k !== self && out.indexOf(k) < 0 && out.length < 16) out.push(k); });
        return out;
    }
    function cleanDisguise(v) {
        v = str(v, 96).trim();
        if (v === "auto" || v === "air" || v === "") return v || "auto";
        if (v === "minecraft:air") return "air";
        return BLOCK_RE.test(v) && blockIds()[v] ? v : "auto";
    }
    function cleanBlockList(list) {
        var out = [];
        (Array.isArray(list) ? list : []).forEach(function (b) { b = str(b, 96); if (BLOCK_RE.test(b) && out.indexOf(b) < 0 && out.length < 16) out.push(b); });
        return out;
    }
    function cleanDrops(list) {
        return (Array.isArray(list) ? list : []).slice(0, 24).map(function (d) {
            var it = cleanStack(d && d.item);
            if (!it) return null;
            var min = clampInt(d.min, 1, 64, 1), max = clampInt(d.max, 1, 64, min);
            var ch = Number(d.chance);
            return { item: { id: it.id, nbt: it.nbt }, chance: isNaN(ch) ? 100 : Math.max(0, Math.min(100, Math.round(ch * 10) / 10)), min: Math.min(min, max), max: Math.max(min, max) };
        }).filter(function (d) { return d; });
    }
    function cleanStats(c, out) {
        var st = c.stats || {};
        ["health", "speed", "damage", "armor"].forEach(function (k) {
            var v = Number(st[k]);
            if (st[k] !== undefined && st[k] !== null && st[k] !== "" && !isNaN(v)) out.stats[k] = Math.max(0, Math.min(k === "speed" ? 5 : 100000000, v));
        });
        var eq = c.equip || {};
        ["mainhand", "offhand", "head", "chest", "legs", "feet"].forEach(function (k) { var s = cleanStack(eq[k]); if (s) out.equip[k] = s; });
        out.nbt = str(c.nbt, 4000).trim();
    }
    function cleanZone(c, out, old) {
        out.zone = ["radius", "box", "self"].indexOf(c.zone) >= 0 ? c.zone : "radius";
        if (out.zone === "self" && !(old && old.zone === "self")) out.zone = "radius";     // "the module itself" only stays for old doors
        out.radius = clampInt(c.radius, 1, 6, 2);
        out.blocks = cleanBlockList(c.blocks);
        out.c1 = old ? old.c1 || null : null; out.c2 = old ? old.c2 || null : null;
    }
    var FACINGS = ["north", "south", "east", "west"];
    function sanitizeConfig(type, c, old, selfKey) {
        c = c || {};
        var out = defaultConfig(type);
        if (out.name !== undefined) out.name = str(c.name, 32).trim();
        if (out.disguise !== undefined) out.disguise = cleanDisguise(c.disguise);
        if (out.links !== undefined) out.links = cleanLinks(c.links, selfKey);
        if (type === "spawner") {
            out.groups = (Array.isArray(c.groups) ? c.groups : []).slice(0, 16).map(function (g) {
                return { entity: str(g && g.entity, 96), count: clampInt(g && g.count, 1, 64, 1) };
            }).filter(function (g) { return g.entity; });
            out.radius = clampInt(c.radius, 1, 128, 8);
            out.trigger = ["radius", "click", "redstone", "signal"].indexOf(c.trigger) >= 0 ? c.trigger : "radius";
            out.glow = !!c.glow;
            out.glowColor = COLORS.indexOf(c.glowColor) >= 0 ? c.glowColor : "red";
            cleanStats(c, out);
            out.drops = cleanDrops(c.drops);
        } else if (type === "entry") {
            out.facing = FACINGS.indexOf(c.facing) >= 0 ? c.facing : "south";
        } else if (type === "exit") {
            out.radius = clampInt(c.radius, 1, 64, 3);
        } else if (DOOR_TYPES[type] || type === "bridge") {
            cleanZone(c, out, old);
            if (type === "door") { out.key = old ? old.key : null; out.consume = c.consume !== false; }
            if (type === "pz_door") out.closeOff = !!c.closeOff;
            if (type === "bridge") { out.start = c.start === "shown" ? "shown" : "hidden"; out.latch = c.latch !== false; }
        } else if (CHEST_TYPES[type]) {
            out.items = old ? old.items || [] : [];
            out.chances = [];
            for (var i = 0; i < 27; i++) {
                var raw = c.chances ? c.chances[i] : null, v = raw === null || raw === undefined || raw === "" ? NaN : Number(raw);
                out.chances.push(isNaN(v) ? null : Math.max(0, Math.min(100, Math.round(v))));
            }
            out.facing = FACINGS.indexOf(c.facing) >= 0 ? c.facing : "south";
        } else if (type === "switch") {
            out.kind = ["lever", "plate", "crystal", "eye", "torch"].indexOf(c.kind) >= 0 ? c.kind : "lever";
            out.mode = ["toggle", "once", "timed", "hold"].indexOf(c.mode) >= 0 ? c.mode : "toggle";
            if (out.mode === "hold" && out.kind !== "plate") out.mode = "toggle";
            out.time = clampInt(c.time, 1, 600, 5);
            out.face = ["floor", "ceiling", "north", "south", "east", "west"].indexOf(c.face) >= 0 ? c.face : "floor";
            out.startOn = !!c.startOn;
        } else if (type === "logic") {
            out.op = ["and", "or", "xor", "not", "seq"].indexOf(c.op) >= 0 ? c.op : "and";
            out.order = cleanLinks(c.order, selfKey);
            out.latch = !!c.latch;
        } else if (type === "boss") {
            out.entity = str(c.entity, 96);
            out.bossName = str(c.bossName, 48);
            out.trigger = ["radius", "click", "signal"].indexOf(c.trigger) >= 0 ? c.trigger : "radius";
            out.radius = clampInt(c.radius, 1, 128, 10);
            out.lock = c.lock !== false;
            out.lockRadius = clampInt(c.lockRadius, 3, 128, 16);
            out.bar = c.bar !== false;
            out.barColor = ["pink", "blue", "red", "green", "yellow", "purple", "white"].indexOf(c.barColor) >= 0 ? c.barColor : "red";
            cleanStats(c, out);
            out.drops = cleanDrops(c.drops);
            out.heart = c.heart !== false;
        }
        return out;
    }
    var BLOCK_IDS = null;
    function blockIds() {
        if (!BLOCK_IDS) { BLOCK_IDS = {}; try { RPG.server.registryIds("block").forEach(function (b) { BLOCK_IDS[String(b)] = 1; }); } catch (e) { } }
        return BLOCK_IDS;
    }

    function inWorkshopPlot(dim, x, z) { return dim === WORKSHOP ? plotAt(x, z) : 0; }

    function placedAnchor(p, type, x, y, z) {
        var n = inWorkshopPlot(p.dimension, x, z), d = n ? dungeonOfPlot(n) : null;
        if (!d) return;
        var A = anchors(d.id), k = relKey(n, x, y, z);
        A[k] = { type: type, cfg: defaultConfig(type) };
        saveAnchors(d.id);
        if (type === "anchor") p.actionbar("&dRight-click the anchor to choose what it is");
        else p.actionbar("&a" + BLOCK_INFO[type].name.replace(/&./g, "") + " placed &7- right-click it to set it up");
    }
    function brokeAnchor(p, x, y, z) {
        var n = inWorkshopPlot(p.dimension, x, z), d = n ? dungeonOfPlot(n) : null;
        if (!d) return;
        var A = anchors(d.id), k = relKey(n, x, y, z);
        if (A[k]) { delete A[k]; saveAnchors(d.id); }
    }
    // only staff place anchors, and only on a dungeon's plot in the workshop
    RPG.on("blockPlace", function (p, block, x, y, z, dim) {
        var t = anchorTypeOf(block);
        if (!t) return;
        if (!isAdmin(p)) { p.actionbar("&cOnly dungeon staff can place anchors"); return false; }
        var n = inWorkshopPlot(dim, x, z);
        if (!n || !dungeonOfPlot(n)) { p.actionbar("&cAnchors only work on a dungeon plot in the workshop (/dungeons)"); return false; }
    });

    // anchor clicks: in the workshop they open the settings (or finish a "pick a link in the world");
    // in a run modules are hidden and runs.js handles the blocks that stand in for them
    var PICK = {};      // uuid -> {dungeon, key, until}: the next module this admin clicks is linked to `key`
    function useAnchor(p, type, x, y, z) {
        if (p.dimension === ARENA) { if (DungeonMaker.runs) DungeonMaker.runs.useAnchor(p, type, x, y, z); return; }
        if (p.dimension !== WORKSHOP) return;
        if (!isAdmin(p)) { p.actionbar("&cOnly dungeon staff can set up anchors"); return; }
        var n = plotAt(x, z), d = n ? dungeonOfPlot(n) : null;
        if (!d) { p.actionbar("&cThis anchor is not on a dungeon plot"); return; }
        var A = anchors(d.id), k = relKey(n, x, y, z);
        if (!A[k] || A[k].type !== type) { A[k] = { type: type, cfg: defaultConfig(type) }; saveAnchors(d.id); }
        var pick = PICK[uid(p)];
        if (pick && pick.dungeon === d.id && tick() < pick.until && A[pick.key] && pick.key !== k) {
            delete PICK[uid(p)];
            toggleLink(p, d, pick.key, k);
            openAnchor(p, d, pick.key);
            return;
        }
        openAnchor(p, d, k);
    }
    function startPick(p, d, key) { PICK[uid(p)] = { dungeon: d.id, key: key, until: tick() + 20 * 60 }; p.actionbar("&eRight-click the module to link (or unlink) within a minute"); }
    function toggleLink(p, d, from, to) {
        var A = anchors(d.id), a = A[from], b = A[to];
        if (!a || !b || !SOURCE_TYPES[a.type]) return false;
        if (!INPUT_TYPES[b.type]) { p.actionbar("&c" + typeName(b.type) + " can't take a signal"); return false; }
        var L = a.cfg.links || (a.cfg.links = []), i = L.indexOf(to);
        if (i >= 0) { L.splice(i, 1); p.actionbar("&7Unlinked from " + moduleLabel(b, to)); }
        else if (L.length >= 16) { p.actionbar("&cAt most 16 links"); return false; }
        else { L.push(to); p.actionbar("&aLinked to " + moduleLabel(b, to)); }
        saveAnchors(d.id);
        return true;
    }
    function typeName(t) { return BLOCK_INFO[t] ? BLOCK_INFO[t].name.replace(/&./g, "").replace(/^Dungeon /, "") : t; }
    function moduleLabel(a, k) { return (a.cfg && a.cfg.name ? a.cfg.name : typeName(a.type)) + " (" + k + ")"; }

    /** The blocks a door / bridge zone covers in the workshop: [{x, y, z, id}] (module blocks and air left out). */
    function zoneOf(dim, origin, a, ax, ay, az, isModule) {
        var c = a.cfg, out = [], x1, y1, z1, x2, y2, z2;
        if (c.zone === "self") return out;
        if (c.zone === "box" && c.c1 && c.c2) {
            x1 = origin.x + Math.min(c.c1[0], c.c2[0]); x2 = origin.x + Math.max(c.c1[0], c.c2[0]);
            y1 = origin.y + Math.min(c.c1[1], c.c2[1]); y2 = origin.y + Math.max(c.c1[1], c.c2[1]);
            z1 = origin.z + Math.min(c.c1[2], c.c2[2]); z2 = origin.z + Math.max(c.c1[2], c.c2[2]);
            if ((x2 - x1 + 1) * (y2 - y1 + 1) * (z2 - z1 + 1) > 8192) return out;
        } else {
            var r = c.radius || 2;
            x1 = ax - r; x2 = ax + r; y1 = ay - r; y2 = ay + r; z1 = az - r; z2 = az + r;
        }
        var only = c.blocks && c.blocks.length ? {} : null;
        if (only) c.blocks.forEach(function (b) { only[b] = 1; });
        for (var x = x1; x <= x2; x++) for (var y = y1; y <= y2; y++) for (var z = z1; z <= z2; z++) {
            if (x === ax && y === ay && z === az) continue;
            var id = RPG.world.getBlock(dim, x, y, z);
            if (!id || id === "minecraft:air" || id === "minecraft:cave_air" || id === "minecraft:void_air" || anchorTypeOf(id) || (isModule && isModule(x, y, z))) continue;
            if (only && !only[id.split("[")[0]]) continue;
            out.push({ x: x, y: y, z: z, id: id.split("[")[0] });
        }
        return out;
    }
    function zoneBox(origin, a, ax, ay, az) {
        var c = a.cfg;
        if (c.zone === "self") return { x1: ax, y1: ay, z1: az, x2: ax, y2: ay, z2: az };
        if (c.zone === "box" && c.c1 && c.c2) return { x1: origin.x + c.c1[0], y1: origin.y + c.c1[1], z1: origin.z + c.c1[2], x2: origin.x + c.c2[0], y2: origin.y + c.c2[1], z2: origin.z + c.c2[2] };
        var r = c.radius || 2;
        return { x1: ax - r, y1: ay - r, z1: az - r, x2: ax + r, y2: ay + r, z2: az + r };
    }

    function anchorPayload(p, d, k) {
        var A = anchors(d.id), a = A[k], pos = parseKey(k), o = plotOrigin(d.plot);
        var ax = o.x + pos.dx, ay = o.y + pos.dy, az = o.z + pos.dz;
        var out = { dungeon: d.id, dungeonName: d.name, key: k, type: a.type, cfg: a.cfg, x: ax, y: ay, z: az };
        if (a.type === "door") out.keyName = a.cfg.key ? itemName(a.cfg.key.id) : "";
        if (ZONE_TYPES[a.type]) {
            out.c1 = a.cfg.c1 ? { x: o.x + a.cfg.c1[0], y: o.y + a.cfg.c1[1], z: o.z + a.cfg.c1[2] } : null;
            out.c2 = a.cfg.c2 ? { x: o.x + a.cfg.c2[0], y: o.y + a.cfg.c2[1], z: o.z + a.cfg.c2[2] } : null;
            out.box = zoneBox(o, a, ax, ay, az);
            // what is in the zone without the block filter, so staff can tick which kinds are the door
            var all = zoneOf(WORKSHOP, o, { cfg: { zone: a.cfg.zone, radius: a.cfg.radius, c1: a.cfg.c1, c2: a.cfg.c2, blocks: [] } }, ax, ay, az), counts = {};
            all.forEach(function (b) { counts[b.id] = (counts[b.id] | 0) + 1; });
            out.zoneBlocks = Object.keys(counts).sort(function (x, y) { return counts[y] - counts[x]; }).slice(0, 16).map(function (id) { return { id: id, n: counts[id], name: itemName(id) }; });
        }
        if (a.type === "spawner" || a.type === "boss") out.inventory = inventoryOf(p);
        if (SOURCE_TYPES[a.type]) {
            out.linkables = Object.keys(A).filter(function (j) { return j !== k && INPUT_TYPES[A[j].type]; }).map(function (j) {
                var r = parseKey(j); return { key: j, type: A[j].type, name: moduleLabel(A[j], j), x: o.x + r.dx, y: o.y + r.dy, z: o.z + r.dz };
            });
        }
        if (INPUT_TYPES[a.type]) out.inputs = inputsOf(A, k).map(function (j) { return { key: j, type: A[j].type, name: moduleLabel(A[j], j) }; });
        return out;
    }
    /** The modules whose links point at `key` (logic gates: in their saved order first). */
    function inputsOf(A, key) {
        var list = Object.keys(A).filter(function (j) { return SOURCE_TYPES[A[j].type] && (A[j].cfg.links || []).indexOf(key) >= 0; });
        var a = A[key], order = a && a.type === "logic" ? a.cfg.order || [] : [];
        list.sort(function (x, y) { var i = order.indexOf(x), j = order.indexOf(y); return (i < 0 ? 999 : i) - (j < 0 ? 999 : j) || (x < y ? -1 : 1); });
        return list;
    }
    function openAnchor(p, d, k) { sendBig(p, "anchor", anchorPayload(p, d, k)); }
    function inventoryOf(p) {
        var out = [];
        for (var i = 0; i < 41; i++) { var s = null; try { s = cleanStack(p.getStack(i)); } catch (e) { } if (s) s.name = itemName(s.id); out.push(s); }
        return out;
    }

    // ---- link lines and zones drawn in the workshop (staff on the plot) ----------------------------
    var LINK_COLORS = { "switch": "#FFD040", logic: "#C070FF", spawner: "#FF5050", boss: "#FF2020" };
    function linksPayload(d) {
        var A = anchors(d.id), o = plotOrigin(d.plot), lines = [], zones = [];
        Object.keys(A).forEach(function (k) {
            var a = A[k], r = parseKey(k), ax = o.x + r.dx, ay = o.y + r.dy, az = o.z + r.dz;
            (SOURCE_TYPES[a.type] ? a.cfg.links || [] : []).forEach(function (t) {
                if (!A[t]) return;
                var q = parseKey(t);
                lines.push({ a: [ax + 0.5, ay + 0.5, az + 0.5], b: [o.x + q.dx + 0.5, o.y + q.dy + 0.5, o.z + q.dz + 0.5], c: LINK_COLORS[a.type] || "#FFFFFF" });
            });
            if (ZONE_TYPES[a.type] && zones.length < 48) { var b = zoneBox(o, a, ax, ay, az); b.c = a.type === "bridge" ? "#40D0FF" : a.type === "bk_door" ? "#FF4040" : a.type === "pz_door" ? "#6080FF" : "#FFAA00"; zones.push(b); }
        });
        return { lines: lines.slice(0, 200), zones: zones };
    }
    function sendLinksFor(id) {
        var d = worldDef(id);
        if (!d) return;
        RPG.server.players().forEach(function (p) { if (p.dimension === WORKSHOP && isAdmin(p) && plotAt(p.x, p.z) === d.plot) sendPlotOutline(p); });
    }

    // ---- entity choices for spawners and goals (sent once per player) --------------------------------
    var ENTITY_CACHE = null;
    function entityChoices() {
        if (ENTITY_CACHE) return ENTITY_CACHE;
        var out = [];
        try { RPG.server.registryIds("living").forEach(function (id) { if (id !== "minecraft:player" && id.indexOf("ragnarok_rpg:") !== 0) out.push(String(id)); }); } catch (e) { }
        try { RPG.mobs.list().forEach(function (id) { out.push("rpgmob:" + id); }); } catch (e) { }
        try { RPG.npcs.list().forEach(function (id) { out.push("rpgnpc:" + id); }); } catch (e) { }
        try { RPG.bosses.list().forEach(function (id) { out.push("rpgboss:" + id); }); } catch (e) { }
        ENTITY_CACHE = out.map(function (id) { return { id: id, name: entityName(id) }; });
        return ENTITY_CACHE;
    }

    // ---- export / card pictures ---------------------------------------------------------------------
    function image(id) { return RPG.data.get("dmk_img_" + id, null) || (FILES[id] && FILES[id].image) || null; }
    function hashOf(s) { var h = 0; for (var i = 0; i < s.length; i += Math.max(1, Math.floor(s.length / 4000))) h = (h * 31 + s.charCodeAt(i)) | 0; return (h >>> 0).toString(16) + s.length.toString(16); }

    function exportDungeon(p, id, done) {
        var d = worldDef(id);
        if (!d) { done({ error: "Only dungeons made in this world can be exported" }); return; }
        // the dungeon's bounds (Dungeon Wand) when it has them, else the whole plot
        var b = DungeonMaker.wands ? DungeonMaker.wands.copyBox(d) : plotBox(d.plot), o = plotOrigin(d.plot);
        RPG.edit.extent(null, WORKSHOP, { type: "cuboid", x1: b.x1, y1: b.y1, z1: b.z1, x2: b.x2, y2: b.y2, z2: b.z2 }, { progress: false, history: false }).then(function (t) {
            var e = t.result;
            if (t.error || !e) { done({ error: t.error || "The plot is empty" }); return; }
            var schem = "dmk_" + id;
            RPG.edit.schemSaveRegion(WORKSHOP, { type: "cuboid", x1: e.minX, y1: e.minY, z1: e.minZ, x2: e.maxX, y2: e.maxY, z2: e.maxZ },
                e.minX, e.minY, e.minZ, schem, function (r) {
                    if (!r.ok) { done({ error: r.error || "Could not save the blocks" }); return; }
                    var copy = JSON.parse(JSON.stringify(d));
                    delete copy.plot; copy.status = d.status;
                    var file = "dungeons/" + id + ".json";
                    try {
                        RPG.files.writeShared(file, { format: 1, exported: now(), def: copy, anchors: anchors(id), image: image(id), schem: schem,
                            paint: DungeonMaker.paint ? DungeonMaker.paint.get(id) : null,
                            layout: DungeonMaker.wands ? DungeonMaker.wands.get(id) : null,
                            offset: { x: e.minX - o.x, y: e.minY - o.y, z: e.minZ - o.z }, size: { x: e.maxX - e.minX + 1, y: e.maxY - e.minY + 1, z: e.maxZ - e.minZ + 1 } });
                    } catch (err) { done({ error: String(err) }); return; }
                    done({ ok: true, path: RPG.files.sharedPath(file) });
                });
        });
    }

    /**
     * Turns an exported dungeon (a file in ragnarok_rpg/shared/dungeons) into one of this world's own, editable in its
     * own workshop plot: the blocks, modules, rooms, puzzles, links, painted map, card and picture. done({def} | {error}).
     */
    function importFile(p, fileId, done) {
        var f = FILES[fileId];
        if (!f || !f.def) { done({ error: "No exported dungeon '" + fileId + "'" }); return; }
        var r = create(null, f.def.name);
        if (r.error) { done(r); return; }
        var d = r.def, src = JSON.parse(JSON.stringify(f.def));
        ["description", "icon", "image", "difficulty", "level", "time", "timeLimit", "cooldown", "requirements", "objectives"].forEach(function (k) { if (src[k] !== undefined) d[k] = src[k]; });
        d.author = src.author || d.author; d.status = "draft"; d.importedFrom = fileId;
        saveDef(d);
        ANCHORS[d.id] = migrateAll(JSON.parse(JSON.stringify(f.anchors || {}))); RPG.data.set("dmk_anc_" + d.id, ANCHORS[d.id]);
        if (f.image) RPG.data.set("dmk_img_" + d.id, f.image);
        if (f.paint) { RPG.data.set("dmk_paint_" + d.id, f.paint); if (DungeonMaker.paint) DungeonMaker.paint.forgetCache(d.id); }
        if (f.layout && DungeonMaker.wands) DungeonMaker.wands.put(d.id, f.layout);
        var o = plotOrigin(d.plot);
        if (p) p.actionbar("&eBuilding the imported dungeon...");
        RPG.edit.schemPlace(null, f.schem, WORKSHOP, o.x + f.offset.x, o.y + f.offset.y, o.z + f.offset.z, { history: false, progress: false, label: "Dungeon import " + d.name }).then(function (t) {
            if (t.error) { done({ error: "Could not place the blocks: " + t.error, def: d }); return; }
            done({ def: d });
        });
    }

    // ---- the menu's cards ----------------------------------------------------------------------------
    function requirementText(r) {
        switch (r.type) {
            case "item": return (r.consume ? "Uses up: " : "Item: ") + itemName(r.item && r.item.id) + " x" + (r.count || 1);
            case "level": return hooks.levelName + " " + r.level + "+";
            case "xp_level": return "XP level " + r.level + "+";
            case "completed": { var o = def(r.id); return "Finished: " + (o ? o.name : r.id); }
            case "cooldown": return "Extra cooldown: " + human(r.seconds || 0);
        }
        return "?";
    }
    function objectiveText(o) {
        switch (o.type) {
            case "kill_count": return "Defeat " + o.count + " enemies";
            case "kill_entity": return "Defeat " + (o.count > 1 ? o.count + "x " : "") + entityName(o.entity);
            case "obtain_item": return "Get " + itemName(o.item && o.item.id) + " x" + (o.count || 1);
            case "puzzle": return "Solve " + (o.name || "a puzzle");
            case "room_clear": return "Clear " + (o.name || "a room");
            case "room_enter": return "Reach " + (o.name || "a room");
        }
        return "?";
    }
    function cooldownLeft(p, id) { var cd = p.getVar("dmk_cd", null) || {}; return Math.max(0, ((cd[id] || 0) - now()) / 1000); }
    function completions(p, id) { var c = p.getVar("dmk_done", null) || {}; return c[id] | 0; }
    function requirementMet(p, r) {
        switch (r.type) {
            case "item": return !!(r.item && p.hasItem(r.item.id, r.count || 1));
            case "level": return hooks.levelOf(p) >= (r.level | 0);
            case "xp_level": return p.getXpLevel() >= (r.level | 0);
            case "completed": return completions(p, r.id) > 0;
            case "cooldown": return true;
        }
        return true;
    }
    function totalCooldown(d) {
        var s = d.cooldown | 0;
        (d.requirements || []).forEach(function (r) { if (r.type === "cooldown") s += r.seconds | 0; });
        return s;
    }
    function rewardsOf(id) {
        var seen = {}, out = [], A = anchors(id);
        Object.keys(A).forEach(function (k) {
            var a = A[k];
            var list = CHEST_TYPES[a.type] ? a.cfg.items || [] : (a.cfg.drops || []).map(function (d) { return d.item; });
            list.forEach(function (s) { if (s && !seen[s.id] && out.length < 14 && !(DungeonMaker.tools && DungeonMaker.tools.isRunKey(s.id))) { seen[s.id] = 1; out.push({ id: s.id, nbt: s.nbt || "" }); } });
        });
        return out;
    }
    function card(p, id) {
        var d = def(id);
        if (!d) return null;
        var A = anchors(id), counts = {};
        Object.keys(A).forEach(function (k) { counts[A[k].type] = (counts[A[k].type] | 0) + 1; });
        return {
            id: d.id, name: d.name, description: d.description || "", author: d.author || "", level: d.level || "", time: d.time || "",
            difficulty: d.difficulty | 0, timeLimit: d.timeLimit | 0, cooldown: totalCooldown(d), status: d.status, source: isFile(id) ? "file" : "world",
            icon: d.icon, image: d.image && d.image.kind === "upload" ? { kind: "upload", h: (image(id) || {}).h || "", w: (image(id) || {}).w || 0, ht: (image(id) || {}).ht || 0 } : d.image,
            rewards: rewardsOf(id), anchors: counts,
            reqs: (d.requirements || []).map(function (r) { return { text: requirementText(r), ok: requirementMet(p, r) }; }),
            goals: (d.objectives || []).map(objectiveText),
            cdLeft: Math.ceil(cooldownLeft(p, id)), completed: completions(p, id)
        };
    }
    function menuFor(p, extra) {
        var admin = isAdmin(p), cards = [];
        allIds().forEach(function (id) {
            var d = def(id);
            if (!d || (d.status !== "published" && !admin)) return;
            var c = card(p, id);
            if (c) cards.push(c);
        });
        cards.sort(function (a, b) { return (a.status === b.status ? 0 : a.status === "published" ? -1 : 1) || a.name.localeCompare(b.name); });
        var out = { admin: admin, cards: cards, inRun: !!(DungeonMaker.runs && DungeonMaker.runs.runOf(p)), levelName: hooks.levelName, level: hooks.levelOf(p),
            inWorkshop: p.dimension === WORKSHOP, hasReturn: !!p.getVar("dmk_ret", null) };
        if (extra) Object.keys(extra).forEach(function (k) { out[k] = extra[k]; });
        return out;
    }
    function sendMenu(p, extra) { sendBig(p, "menu", menuFor(p, extra)); }

    return {
        WORKSHOP: WORKSHOP, ARENA: ARENA, SPACING: SPACING, PLATFORM_Y: PLATFORM_Y, DIFFICULTIES: DIFFICULTIES, DIFF_COLORS: DIFF_COLORS, COLORS: COLORS, TYPES: TYPES,
        DOOR_TYPES: DOOR_TYPES, CHEST_TYPES: CHEST_TYPES, ZONE_TYPES: ZONE_TYPES, SOURCE_TYPES: SOURCE_TYPES, INPUT_TYPES: INPUT_TYPES, tools: null,
        migrate: migrate, zoneOf: zoneOf, inputsOf: inputsOf, startPick: startPick, toggleLink: toggleLink, typeName: typeName, moduleLabel: moduleLabel,
        sendLinksFor: sendLinksFor, blockIds: blockIds, KEY_RE: KEY_RE,
        CFG: CFG, hooks: hooks, BLOCK: BLOCK, BLOCK_INFO: BLOCK_INFO, runs: null,
        uid: uid, now: now, tick: tick, isAdmin: isAdmin, clampInt: clampInt, str: str, online: online, human: human, clock: clock, itemName: itemName,
        entityName: entityName, cleanStack: cleanStack, sendBig: sendBig,
        index: index, saveIndex: saveIndex, def: def, worldDef: worldDef, saveDef: saveDef, anchors: anchors, saveAnchors: saveAnchors, allIds: allIds,
        isFile: isFile, files: function () { return FILES; }, loadFiles: loadFiles,
        plotOrigin: plotOrigin, plotBox: plotBox, plotAt: plotAt, dungeonOfPlot: dungeonOfPlot, buildPlatform: buildPlatform, sendPlotOutline: sendPlotOutline,
        rememberReturn: rememberReturn, sendBack: sendBack, create: create, goToPlot: goToPlot, remove: remove,
        anchorTypeOf: anchorTypeOf, giveAnchors: giveAnchors, relKey: relKey, parseKey: parseKey, defaultConfig: defaultConfig, sanitizeConfig: sanitizeConfig,
        openAnchor: openAnchor, anchorPayload: anchorPayload, inventoryOf: inventoryOf, entityChoices: entityChoices,
        image: image, hashOf: hashOf, exportDungeon: exportDungeon, importFile: importFile,
        requirementText: requirementText, objectiveText: objectiveText, requirementMet: requirementMet, cooldownLeft: cooldownLeft, completions: completions,
        totalCooldown: totalCooldown, card: card, sendMenu: sendMenu
    };
})();
