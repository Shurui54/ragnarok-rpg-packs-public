// =====================================================================================
//  Dungeon Maker - the dungeon painter (server side): painted maps, checks, generating, importing
// =====================================================================================
//  Staff paint a dungeon as a top-down map in the painter screen (client/scripts/50_dmk_painter.js):
//  one cell is one block column, floors are layers with their own height, wall height and ceiling.
//  The map is kept with the dungeon (dmk_paint_<id>), goes into exports, and "Generate" builds it
//  into the dungeon's workshop plot: the painted area is cleared (saved first for Undo), every floor
//  is placed through RPG.edit (budgeted, a few ms a tick), then the stairs, and the anchor tiles
//  become real module blocks configured with the settings staff gave them in the same module
//  screens the workshop uses. "Import from plot" reads a build back into a map (best effort).
//
//  Map: {v, w, h, ox, oz, theme: {floor, wall, ceiling, pillar, light, stairs, door, deco, preset},
//        floors: [{name, y, height, ceiling, cells}], anchors: {"f,x,z": {type, cfg}}, extras: [...]}
//   - cells: w*h characters, row by row (z then x); (ox, oz) is cell 0,0 from the plot origin.
//   - y is the floor blocks' level from the plot origin (-1 = the starting platform); walls stand on
//     it `height` blocks tall and the ceiling (if any) lies on top.
//   - anchors are keyed by their cell ("floor,x,z", a locked door by its door's first cell); links
//     between painted modules use those keys and become real block keys when generated.
//  Everything the client sends is checked again here: staff only, sizes, characters, block ids,
//  plot bounds and module settings (DungeonMaker.sanitizeConfig).
// =====================================================================================
DungeonMaker.paint = (function () {
    var DM = DungeonMaker, WORKSHOP = DM.WORKSHOP;
    var MAX_SIDE = 128, MAX_FLOORS = 8, MIN_Y = -64, MAX_Y = 319;
    // tiles: . empty  f floor  w wall  o pit  d doorway  L locked door  C chest  S spawner  B boss  E entry  X exit
    //        U stairs up  D stairs down (landing)  P pillar  T light  ~ water  ^ lava  * decoration
    var TILES = ".fwodLCSBEXUDPT~^*";
    var KINDS = { L: ["sk_door", "bk_door", "door", "pz_door"], C: ["loot", "sk_chest", "bk_chest", "pz_chest"], S: ["spawner"], B: ["boss"], E: ["entry"], X: ["exit"] };
    var TILE_OF_TYPE = {};
    Object.keys(KINDS).forEach(function (t) { KINDS[t].forEach(function (ty) { TILE_OF_TYPE[ty] = t; }); });
    var PRESETS = {
        stone_brick: { name: "Stone Brick", floor: "minecraft:stone_bricks", wall: "minecraft:stone_bricks", ceiling: "minecraft:stone_bricks", pillar: "minecraft:chiseled_stone_bricks",
            light: "minecraft:lantern", stairs: "minecraft:stone_brick_stairs", door: "minecraft:iron_bars", deco: "minecraft:cobweb" },
        deepslate: { name: "Deepslate", floor: "minecraft:deepslate_tiles", wall: "minecraft:deepslate_bricks", ceiling: "minecraft:polished_deepslate", pillar: "minecraft:chiseled_deepslate",
            light: "minecraft:soul_lantern", stairs: "minecraft:deepslate_brick_stairs", door: "minecraft:iron_bars", deco: "minecraft:cobweb" },
        sandstone: { name: "Sandstone Temple", floor: "minecraft:smooth_sandstone", wall: "minecraft:cut_sandstone", ceiling: "minecraft:smooth_sandstone", pillar: "minecraft:chiseled_sandstone",
            light: "minecraft:lantern", stairs: "minecraft:sandstone_stairs", door: "minecraft:oak_fence", deco: "minecraft:decorated_pot" },
        nether: { name: "Nether Fortress", floor: "minecraft:nether_bricks", wall: "minecraft:nether_bricks", ceiling: "minecraft:nether_bricks", pillar: "minecraft:chiseled_nether_bricks",
            light: "minecraft:soul_lantern", stairs: "minecraft:nether_brick_stairs", door: "minecraft:nether_brick_fence", deco: "minecraft:wither_skeleton_skull" },
        prismarine: { name: "Prismarine", floor: "minecraft:prismarine_bricks", wall: "minecraft:prismarine", ceiling: "minecraft:dark_prismarine", pillar: "minecraft:dark_prismarine",
            light: "minecraft:sea_lantern", stairs: "minecraft:prismarine_brick_stairs", door: "minecraft:iron_bars", deco: "minecraft:sea_pickle" }
    };
    var THEME_KEYS = ["floor", "wall", "ceiling", "pillar", "light", "stairs", "door", "deco"];
    var DENY_BLOCKS = /command_block|structure_block|structure_void|jigsaw|moving_piston|piston_head|end_portal|end_gateway|nether_portal|^minecraft:(air|cave_air|void_air|light|barrier|spawner|bedrock|reinforced_deepslate|tnt|fire|soul_fire)$/;
    var STATE_RE = /^[a-z0-9_.\-]+:[a-z0-9_.\-\/]+$/;

    function cellKey(f, x, z) { return f + "," + x + "," + z; }
    function parseCell(k) { var a = String(k).split(","); return { f: a[0] | 0, x: a[1] | 0, z: a[2] | 0 }; }
    function clone(o) { return o === undefined ? undefined : JSON.parse(JSON.stringify(o)); }
    function plotHalf() { return Math.floor(DM.CFG.get("plotSize") / 2); }
    function maxSide() { return Math.min(MAX_SIDE, plotHalf() * 2 + 1); }
    function allowedBlock(id) {
        id = String(id || "");
        return STATE_RE.test(id) && !DENY_BLOCKS.test(id) && !DM.anchorTypeOf(id) && !!DM.blockIds()[id];
    }
    function emptyCells(n) { var s = ""; while (s.length < n) s += "........................................................................................................................"; return s.substring(0, n); }

    // ---- storage ------------------------------------------------------------------------------------------
    var MAPS = {};
    function get(id) {
        if (MAPS[id] === undefined) {
            MAPS[id] = DM.worldDef(id) ? RPG.data.get("dmk_paint_" + id, null) : null;
            if (!MAPS[id] && DM.isFile(id)) MAPS[id] = (DM.files()[id] || {}).paint || null;
        }
        return MAPS[id];
    }
    function store(id, map) { map.updated = DM.now(); MAPS[id] = map; RPG.data.set("dmk_paint_" + id, map); }
    function forget(id) { delete MAPS[id]; RPG.data.remove("dmk_paint_" + id); RPG.data.remove("dmk_pundo_" + id); }

    function newMap(w, h) {
        w = w || 48; h = h || 48;
        var t = clone(PRESETS.stone_brick); delete t.name; t.preset = "stone_brick";
        return { v: 1, w: w, h: h, ox: -Math.floor(w / 2), oz: -Math.floor(h / 2), theme: t,
            floors: [{ name: "Floor 1", y: -1, height: 4, ceiling: true, cells: emptyCells(w * h) }], anchors: {} };
    }

    /** A new map the size and place of the dungeon's bounds (Dungeon Wand), or null without bounds. */
    function boundsMap(id) {
        var b = DM.wands ? DM.wands.boundsRel(id) : null;
        if (!b) return null;
        var side = maxSide(), w = Math.max(4, Math.min(side, b.x2 - b.x1 + 1)), h = Math.max(4, Math.min(side, b.z2 - b.z1 + 1)), hf = plotHalf();
        var m = newMap(w, h);
        m.ox = Math.max(-hf, Math.min(hf - w + 1, b.x1)); m.oz = Math.max(-hf, Math.min(hf - h + 1, b.z1));
        m.floors[0].y = Math.max(-1, Math.min(b.y2 - 4, b.y1));
        return m;
    }

    // ---- checking what the client sent --------------------------------------------------------------------
    /** A clean copy of a map from the client (or null + error). Anchor settings come from `old` (the server's copy). */
    function clean(raw, old) {
        if (!raw || typeof raw !== "object") return { error: "No map" };
        var w = DM.clampInt(raw.w, 4, maxSide(), 0), h = DM.clampInt(raw.h, 4, maxSide(), 0);
        if (!w || !h || w !== (raw.w | 0) || h !== (raw.h | 0)) return { error: "The map must be 4 to " + maxSide() + " cells a side" };
        var half = plotHalf(), ox = Math.floor(Number(raw.ox)), oz = Math.floor(Number(raw.oz));
        if (isNaN(ox) || isNaN(oz) || ox < -half || oz < -half || ox + w - 1 > half || oz + h - 1 > half) return { error: "The map does not fit inside the plot (" + (half * 2 + 1) + " blocks wide)" };
        var floors = Array.isArray(raw.floors) ? raw.floors : [];
        if (!floors.length || floors.length > MAX_FLOORS) return { error: "A map has 1 to " + MAX_FLOORS + " floors" };
        var out = { v: 1, w: w, h: h, ox: ox, oz: oz, theme: {}, floors: [], anchors: {} };
        var ok = /^[.fwodLCSBEXUDPT~^*]*$/;
        for (var i = 0; i < floors.length; i++) {
            var f = floors[i] || {}, cells = String(f.cells || "");
            if (cells.length !== w * h || !ok.test(cells)) return { error: "Floor " + (i + 1) + ": the cells are damaged" };
            var y = Math.floor(Number(f.y)), height = DM.clampInt(f.height, 2, 12, 4);
            if (isNaN(y)) return { error: "Floor " + (i + 1) + ": no height" };
            var abs = DM.PLATFORM_Y + y;
            if (abs - 4 < MIN_Y || abs + height + 4 > MAX_Y) return { error: "Floor " + (i + 1) + " is outside the world's height" };
            if (i > 0) {
                var below = out.floors[i - 1];
                if (y < below.y + below.height + 1) return { error: "Floor " + (i + 1) + " must be at least " + (below.height + 1) + " blocks above floor " + i };
            }
            out.floors.push({ name: DM.str(f.name, 24).trim() || "Floor " + (i + 1), y: y, height: height, ceiling: f.ceiling !== false, cells: cells });
        }
        var th = raw.theme || {};
        var base = PRESETS[th.preset] || PRESETS.stone_brick;
        THEME_KEYS.forEach(function (k) { var b = DM.str(th[k], 96).trim(); out.theme[k] = allowedBlock(b) ? b : base[k]; });
        out.theme.preset = PRESETS[th.preset] ? th.preset : "custom";
        // anchors: one per anchor cell (a locked door: one per door, on its first cell); settings stay the server's
        var oldA = old && old.anchors ? old.anchors : {}, rawA = raw.anchors && typeof raw.anchors === "object" ? raw.anchors : {};
        anchorCells(out).forEach(function (c) {
            var k = c.key, r = rawA[k] || {}, from = typeof r.from === "string" && oldA[r.from] ? oldA[r.from] : null, prev = oldA[k];
            var type = KINDS[c.t].indexOf(r.type) >= 0 ? r.type : prev && TILE_OF_TYPE[prev.type] === c.t ? prev.type : from && TILE_OF_TYPE[from.type] === c.t ? from.type : KINDS[c.t][0];
            var src = from && from.type === type ? from : prev && prev.type === type ? prev : null;
            out.anchors[k] = { type: type, cfg: src ? clone(src.cfg) : defaultCfg(type) };
        });
        // links may only point at painted modules
        Object.keys(out.anchors).forEach(function (k) {
            var c = out.anchors[k].cfg;
            if (c.links) c.links = c.links.filter(function (j) { return !!out.anchors[j]; });
            if (c.order) c.order = c.order.filter(function (j) { return !!out.anchors[j]; });
        });
        if (old && old.generated) out.generated = old.generated;
        return { map: out };
    }
    function defaultCfg(type) {
        var c = DM.defaultConfig(type);
        if (type === "entry" || type === "exit" || type === "spawner" || type === "boss") c.disguise = "air";
        return c;
    }
    /** Every anchor cell of a map: [{key, f, x, z, t}], doors once per connected door (its first cell in row order). */
    function anchorCells(map) {
        var out = [];
        map.floors.forEach(function (fl, f) {
            var seen = {}, re = /[LCSBEX]/g, m;
            while ((m = re.exec(fl.cells))) {
                var t = m[0], x = m.index % map.w, z = Math.floor(m.index / map.w);
                if (t === "L") {
                    if (seen[z * map.w + x]) continue;
                    doorGroup(map, fl, x, z).forEach(function (i) { seen[i] = 1; });
                }
                out.push({ key: cellKey(f, x, z), f: f, x: x, z: z, t: t });
            }
        });
        return out;
    }
    /** The cells (indexes) of the locked door that (x, z) belongs to, first cell first. */
    function doorGroup(map, fl, x, z) {
        var w = map.w, start = z * w + x, out = [], seen = {}, q = [start];
        seen[start] = 1;
        while (q.length) {
            var i = q.pop(), cx = i % w, cz = Math.floor(i / w);
            out.push(i);
            [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (s) {
                var nx = cx + s[0], nz = cz + s[1], j = nz * w + nx;
                if (nx < 0 || nz < 0 || nx >= w || nz >= map.h || seen[j] || fl.cells.charAt(j) !== "L") return;
                seen[j] = 1; q.push(j);
            });
        }
        out.sort(function (a, b) { return a - b; });
        return out;
    }

    // ---- validating a map before it is built ------------------------------------------------------------------
    function cellName(f, x, z) { return "floor " + (f + 1) + " at " + x + ", " + z; }
    /** Stair flights: [{f, cells: [index...] bottom to top, dir: [dx, dz], hdiff}] plus problems. */
    function stairs(map, errors) {
        var flights = [];
        map.floors.forEach(function (fl, f) {
            var w = map.w, seen = {};
            for (var i = fl.cells.indexOf("U"); i >= 0; i = fl.cells.indexOf("U", i + 1)) {
                if (seen[i]) continue;
                var group = [], q = [i]; seen[i] = 1;
                while (q.length) {
                    var j = q.pop(), cx = j % w, cz = Math.floor(j / w);
                    group.push(j);
                    [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (s) {
                        var nx = cx + s[0], nz = cz + s[1], k = nz * w + nx;
                        if (nx < 0 || nz < 0 || nx >= w || nz >= map.h || seen[k] || fl.cells.charAt(k) !== "U") return;
                        seen[k] = 1; q.push(k);
                    });
                }
                group.sort(function (a, b) { return a - b; });
                var x0 = group[0] % w, z0 = Math.floor(group[0] / w), where = cellName(f, x0, z0);
                var sameZ = group.every(function (j) { return Math.floor(j / w) === z0; }), sameX = group.every(function (j) { return j % w === x0; });
                if (!sameZ && !sameX) { errors.push("Stairs up on " + where + " must be one straight line"); continue; }
                if (f === map.floors.length - 1) { errors.push("Stairs up on " + where + " lead nowhere: there is no floor above"); continue; }
                var up = map.floors[f + 1], hdiff = up.y - fl.y;
                // the landing (stairs down) on the floor above sits next to the top end
                var ends = [group[0], group[group.length - 1]], dirs = sameZ && group.length > 1 ? [[-1, 0], [1, 0]] : sameX && group.length > 1 ? [[0, -1], [0, 1]] : null, top = -1, dir = null;
                var tryEnd = function (e, d) {
                    var ex = e % w, ez = Math.floor(e / w), nx = ex + d[0], nz = ez + d[1];
                    if (nx < 0 || nz < 0 || nx >= w || nz >= map.h) return false;
                    return up.cells.charAt(nz * w + nx) === "D";
                };
                if (dirs) {
                    if (tryEnd(ends[1], dirs[1])) { top = 1; dir = dirs[1]; }
                    else if (tryEnd(ends[0], dirs[0])) { top = 0; dir = dirs[0]; }
                } else {
                    [[1, 0], [-1, 0], [0, 1], [0, -1]].some(function (d) { if (tryEnd(group[0], d)) { top = 1; dir = d; return true; } return false; });
                }
                if (top < 0) { errors.push("Stairs up on " + where + " need a 'stairs down' landing on floor " + (f + 2) + " right after their top end"); continue; }
                var ordered = top === 1 ? group : group.slice().reverse();
                if (ordered.length < hdiff) { errors.push("Stairs up on " + where + " climb " + hdiff + " blocks to floor " + (f + 2) + ": draw " + hdiff + " stair cells in a row (now " + ordered.length + ")"); continue; }
                // the stairwell opens into the floor above over the steps whose head room reaches it: that floor must be there
                var open = ordered.slice(Math.max(0, ordered.length - Math.min(hdiff, 4))).filter(function (j) { var c = up.cells.charAt(j); return c === "." || c === "w" || c === "P"; });
                if (open.length) { errors.push("Stairs up on " + where + ": paint floor " + (f + 2) + " (floor, not wall) over the top " + Math.min(hdiff, 4) + " stair cells, where the stairwell opens (" + open.length + " cell(s) missing)"); continue; }
                var e = ordered[ordered.length - 1];
                flights.push({ f: f, cells: ordered, dir: dir, hdiff: hdiff, landing: (Math.floor(e / w) + dir[1]) * w + (e % w) + dir[0] });
            }
        });
        // every landing has a flight
        map.floors.forEach(function (fl, f) {
            for (var i = fl.cells.indexOf("D"); i >= 0; i = fl.cells.indexOf("D", i + 1)) {
                var used = flights.some(function (fl2) { return fl2.f === f - 1 && fl2.landing === i; });
                if (!used) errors.push("Stairs down on " + cellName(f, i % map.w, Math.floor(i / map.w)) + " have no stairs up below them (draw them on floor " + f + ", ending next to this cell)");
            }
        });
        return flights;
    }
    function countOf(cells, re) { var m = cells.match(re); return m ? m.length : 0; }
    function check(map, id) {
        var errors = [], warnings = [], count = { E: 0, X: 0, L: 0, C: 0 };
        map.floors.forEach(function (fl) { count.E += countOf(fl.cells, /E/g); count.X += countOf(fl.cells, /X/g); count.L += countOf(fl.cells, /L/g); count.C += countOf(fl.cells, /C/g); });
        var painted = map.floors.some(function (fl) { return /[^.]/.test(fl.cells); });
        if (!painted) errors.push("The map is empty: paint some rooms first");
        if ((count.E | 0) !== 1) errors.push((count.E | 0) ? "There are " + count.E + " entry points: a dungeon has exactly one" : "Place an entry point (where players appear)");
        if (!(count.X | 0)) errors.push("Place at least one exit point (where the run ends)");
        stairs(map, errors);
        Object.keys(map.anchors).forEach(function (k) {
            var a = map.anchors[k], c = parseCell(k), where = cellName(c.f, c.x, c.z);
            if (a.type === "spawner" && !(a.cfg.groups || []).length) warnings.push("The mob spawner on " + where + " has no mobs yet");
            if (a.type === "boss" && !a.cfg.entity) warnings.push("The boss spawner on " + where + " has no boss picked yet");
            if (a.type === "door" && !a.cfg.key) warnings.push("The key door on " + where + " has no key item (it opens for anyone)");
            if ((a.type === "loot" || a.type === "sk_chest" || a.type === "bk_chest") && !(a.cfg.items || []).some(function (s) { return s; })) warnings.push("The chest on " + where + " is empty");
        });
        if ((count.L | 0) && !(count.C | 0) && !Object.keys(map.anchors).some(function (k) { return (map.anchors[k].cfg.drops || []).length; }))
            warnings.push("There are locked doors but no chest or drops to find keys in");
        // the dungeon's bounds (Dungeon Wand): runs and exports only copy what is inside them
        var bd = id && DM.wands ? DM.wands.boundsRel(id) : null;
        if (bd) {
            var outside = 0;
            map.floors.forEach(function (fl) {
                for (var i = 0; i < fl.cells.length; i++) {
                    if (fl.cells.charAt(i) === ".") continue;
                    var bx = map.ox + i % map.w, bz = map.oz + Math.floor(i / map.w);
                    if (bx < bd.x1 || bx > bd.x2 || bz < bd.z1 || bz > bd.z2 || fl.y < bd.y1 - 1 || fl.y + fl.height + 1 > bd.y2 + 1) outside++;
                }
            });
            if (outside) warnings.unshift(outside + " painted cell(s) lie outside the dungeon's bounds: runs and exports leave them out (Map > Fit to bounds, or widen the bounds with the Dungeon Wand)");
        }
        if (warnings.length > 12) warnings = warnings.slice(0, 11).concat(["...and " + (warnings.length - 11) + " more like these"]);
        return { errors: errors, warnings: warnings };
    }

    // ---- building ---------------------------------------------------------------------------------------------------
    var JOBS = {};
    function isObjectLight(id) { return /lantern|torch|candle|end_rod|campfire/.test(id) && !/sea_lantern|jack_o_lantern/.test(id); }
    function bounds(map) {
        var x1 = 1e9, z1 = 1e9, x2 = -1e9, z2 = -1e9;
        map.floors.forEach(function (fl) {
            for (var i = 0; i < fl.cells.length; i++) {
                if (fl.cells.charAt(i) === ".") continue;
                var x = i % map.w, z = Math.floor(i / map.w);
                if (x < x1) x1 = x; if (x > x2) x2 = x; if (z < z1) z1 = z; if (z > z2) z2 = z;
            }
        });
        return x1 > x2 ? null : { x1: x1, z1: z1, x2: x2, z2: z2 };
    }
    function worldBox(d, map) {
        var b = bounds(map);
        if (!b) return null;
        var o = DM.plotOrigin(d.plot), lo = 1e9, hi = -1e9;
        map.floors.forEach(function (fl) { lo = Math.min(lo, o.y + fl.y - 3); hi = Math.max(hi, o.y + fl.y + fl.height + 1); });
        return { x1: o.x + map.ox + b.x1, z1: o.z + map.oz + b.z1, x2: o.x + map.ox + b.x2, z2: o.z + map.oz + b.z2, y1: Math.max(MIN_Y, lo), y2: Math.min(MAX_Y, hi) };
    }
    function inBox(b, x, y, z) { return x >= b.x1 && x <= b.x2 && y >= b.y1 && y <= b.y2 && z >= b.z1 && z <= b.z2; }

    /** Where each painted module's block goes: {cellKey: {x, y, z, rel}} (world positions and plot keys). */
    function anchorSpots(d, map) {
        var o = DM.plotOrigin(d.plot), out = {};
        Object.keys(map.anchors).forEach(function (k) {
            var c = parseCell(k), fl = map.floors[c.f];
            if (!fl) return;
            var t = fl.cells.charAt(c.z * map.w + c.x), X = o.x + map.ox + c.x, Z = o.z + map.oz + c.z;
            var Y = o.y + fl.y + (t === "L" ? 0 : 1);
            out[k] = { x: X, y: Y, z: Z, rel: DM.relKey(d.plot, X, Y, Z) };
        });
        return out;
    }

    /** One floor's blocks as a palette + x, y, z, index list. */
    /** Rows z0..z1 of one floor as x, y, z, palette-index entries appended to list. */
    function floorSpec(d, map, f, P, z0, z1, list) {
        var o = DM.plotOrigin(d.plot), fl = map.floors[f], th = map.theme;
        var Y0 = o.y + fl.y, H = fl.height, door = Math.min(3, H), lowest = f === 0;
        var hang = isObjectLight(th.light) && fl.ceiling, objLight = isObjectLight(th.light);
        function put(x, y, z, b) { list.push(x, y, z, P.idx(b)); }
        for (var z = z0; z <= z1; z++) for (var x = 0; x < map.w; x++) {
            var t = fl.cells.charAt(z * map.w + x);
            if (t === ".") continue;
            var X = o.x + map.ox + x, Z = o.z + map.oz + z, y;
            // the floor layer
            if (t === "o") {
                put(X, Y0, Z, "minecraft:air");
                if (lowest) put(X, Y0 - 3, Z, th.floor);
            } else if (t === "~" || t === "^") {
                put(X, Y0 - 1, Z, th.floor);
                put(X, Y0, Z, t === "~" ? "minecraft:water" : "minecraft:lava");
            } else if (t === "L") {
                put(X, Y0, Z, th.floor);      // the anchor of the door's first cell replaces it below
            } else if (t === "T" && !objLight) {
                put(X, Y0, Z, th.light);
            } else put(X, Y0, Z, th.floor);
            // the column
            switch (t) {
                case "w": for (y = 1; y <= H; y++) put(X, Y0 + y, Z, th.wall); break;
                case "P": for (y = 1; y <= H; y++) put(X, Y0 + y, Z, th.pillar); break;
                case "d": for (y = door + 1; y <= H; y++) put(X, Y0 + y, Z, th.wall); break;
                case "L": {
                    // small key and boss doors are the 2-block-tall door blocks; other locked doors use the theme's door
                    var tall = tallDoor(map, f, x, z);
                    if (tall) { put(X, Y0 + 1, Z, tall[0]); put(X, Y0 + 2, Z, tall[1]); for (y = 3; y <= H; y++) put(X, Y0 + y, Z, th.wall); break; }
                    for (y = 1; y <= door; y++) put(X, Y0 + y, Z, th.door);
                    for (y = door + 1; y <= H; y++) put(X, Y0 + y, Z, th.wall);
                    break;
                }
                case "T": if (objLight) put(X, hang ? Y0 + H : Y0 + 1, Z, hang ? th.light + "[hanging=true]" : th.light); break;
                case "*": put(X, Y0 + 1, Z, th.deco); break;
            }
            if (fl.ceiling && t !== "o") put(X, Y0 + H + 1, Z, t === "T" && !objLight ? th.light : th.ceiling);
        }
        return list;
    }
    function stairSpec(d, map, flights, P) {
        var o = DM.plotOrigin(d.plot), th = map.theme, list = [];
        var FACE = { "1,0": "east", "-1,0": "west", "0,1": "south", "0,-1": "north" };
        flights.forEach(function (fl) {
            var floor = map.floors[fl.f], Y0 = o.y + floor.y, n = fl.cells.length, facing = FACE[fl.dir[0] + "," + fl.dir[1]];
            fl.cells.forEach(function (i, j) {
                var k = fl.hdiff - (n - 1 - j);                     // the last hdiff cells climb, the rest is flat
                var X = o.x + map.ox + i % map.w, Z = o.z + map.oz + Math.floor(i / map.w);
                if (k < 1) return;
                for (var y = 1; y < k; y++) list.push(X, Y0 + y, Z, P.idx(th.wall));
                list.push(X, Y0 + k, Z, P.idx(th.stairs + "[facing=" + facing + ",half=bottom]"));
                for (var a = 1; a <= 3; a++) list.push(X, Y0 + k + a, Z, P.idx("minecraft:air"));     // head room (3: stepping up from the step below)
            });
        });
        return list;
    }
    /** [lower, upper] door blocks for a painted small key / boss key door cell, else null (the theme's door). */
    function tallDoor(map, f, x, z) {
        var fl = map.floors[f], g = doorGroup(map, fl, x, z), a = map.anchors[cellKey(f, g[0] % map.w, Math.floor(g[0] / map.w))], K = DM.tools.BLOCKS;
        if (!a || fl.height < 2) return null;
        return a.type === "sk_door" ? [K.door_small, K.door_small_top] : a.type === "bk_door" ? [K.door_boss, K.door_boss_top] : null;
    }
    function palette() {
        var pal = [], at = {};
        return { list: pal, idx: function (b) { var i = at[b]; if (i === undefined) { i = at[b] = pal.length; pal.push(b); } return i; } };
    }

    /** A painted module's settings as the plot's module block gets them (links to block keys, a door's zone = its doorway). */
    function builtModule(d, map, k, spots, relOf) {
        var o = DM.plotOrigin(d.plot);
        var a = map.anchors[k], s = spots[k], cfg = DM.sanitizeConfig(a.type, a.cfg, a.cfg, s.rel);
        cfg.items = clone(a.cfg.items || cfg.items);
        if (a.cfg.key !== undefined) cfg.key = clone(a.cfg.key);
        var mapKeys = function (l) { return (l || []).map(function (j) { return relOf[j]; }).filter(function (j) { return j && j !== s.rel; }); };
        if (cfg.links) cfg.links = mapKeys(a.cfg.links);
        if (cfg.order) cfg.order = mapKeys(a.cfg.order);
        if (DM.DOOR_TYPES[a.type]) {
            // the zone is exactly the painted doorway (every cell of this door), the door blocks only
            var c = parseCell(k), fl = map.floors[c.f], cells = doorGroup(map, fl, c.x, c.z), door = Math.min(3, fl.height);
            var xs = cells.map(function (i) { return i % map.w; }), zs = cells.map(function (i) { return Math.floor(i / map.w); });
            var bx1 = o.x + map.ox + Math.min.apply(null, xs), bx2 = o.x + map.ox + Math.max.apply(null, xs);
            var bz1 = o.z + map.oz + Math.min.apply(null, zs), bz2 = o.z + map.oz + Math.max.apply(null, zs), by = o.y + fl.y;
            var tall = tallDoor(map, c.f, c.x, c.z);
            cfg.zone = "box"; cfg.radius = 2; cfg.blocks = tall || [map.theme.door];
            cfg.c1 = [bx1 - o.x, by + 1 - o.y, bz1 - o.z]; cfg.c2 = [bx2 - o.x, by + (tall ? 2 : door) - o.y, bz2 - o.z];
        }
        return { type: a.type, cfg: cfg };
    }

    /** Builds the map into the plot. done({ok, error, seconds, blocks}). */
    function generate(p, d, done) {
        var map = get(d.id);
        if (!map) { done({ error: "Paint a map first" }); return; }
        var chk = check(map, d.id);
        if (chk.errors.length) { done({ error: chk.errors[0], problems: chk }); return; }
        if (JOBS[d.id]) { done({ error: "This dungeon is already being built" }); return; }
        var box = worldBox(d, map), errs = [], flights = stairs(map, errs);
        if (!box) { done({ error: "The map is empty" }); return; }
        JOBS[d.id] = { started: DM.now(), blocks: 0 };
        var job = JOBS[d.id], A = DM.anchors(d.id), o = DM.plotOrigin(d.plot);
        var fail = function (msg) { delete JOBS[d.id]; done({ error: msg }); };
        var say = function (msg) { if (p) p.actionbar("&e" + msg); };
        // 1. keep what is there for Undo (blocks and the module settings in the box)
        say("Saving the plot for Undo...");
        var keep = {};
        Object.keys(A).forEach(function (k) { var r = DM.parseKey(k); if (inBox(box, o.x + r.dx, o.y + r.dy, o.z + r.dz)) keep[k] = clone(A[k]); });
        RPG.edit.schemSaveRegion(WORKSHOP, { type: "cuboid", x1: box.x1, y1: box.y1, z1: box.z1, x2: box.x2, y2: box.y2, z2: box.z2 }, box.x1, box.y1, box.z1, "dmk_pundo_" + d.id, function (r) {
            if (!r.ok) { fail("Could not save the plot for Undo: " + (r.error || "?")); return; }
            RPG.data.set("dmk_pundo_" + d.id, { box: box, anchors: keep, at: DM.now() });
            // modules the painter can't draw (switches, logic gates, bridges...) stay where they are
            var extras = [];
            Object.keys(keep).forEach(function (k) { if (!TILE_OF_TYPE[keep[k].type]) { var r2 = DM.parseKey(k); extras.push({ key: k, x: o.x + r2.dx, y: o.y + r2.dy, z: o.z + r2.dz, a: keep[k] }); } });
            // 2. clear the painted area
            say("Clearing the painted area...");
            RPG.edit.set(null, WORKSHOP, { type: "cuboid", x1: box.x1, y1: box.y1, z1: box.z1, x2: box.x2, y2: box.y2, z2: box.z2 }, "minecraft:air",
                { history: false, progress: false, label: "Dungeon painter: clear" }).then(function (t) {
                    if (t.error) { fail("Clearing failed: " + t.error); return; }
                    nextFloor(0, extras);
                });
        });
        // 3. floor by floor: each floor's block list is made a few rows a tick (under ~8 ms), then RPG.edit places it a few ms a tick
        function nextFloor(f, extras) {
            if (f >= map.floors.length) { finish(extras); return; }
            var P = palette(), list = [], z = 0;
            say("Building " + map.floors[f].name + " (" + (f + 1) + "/" + map.floors.length + ")...");
            var rows = function () {
                var t0 = DM.now();
                while (z < map.h && DM.now() - t0 < 8) { var z1 = Math.min(map.h - 1, z + 3); floorSpec(d, map, f, P, z, z1, list); z = z1 + 1; }
                if (z < map.h) { RPG.schedule(1, rows); return; }
                job.blocks += list.length / 4;
                RPG.edit.place(null, WORKSHOP, { palette: P.list, blocks: list }, { history: false, progress: false, label: "Dungeon painter: floor " + (f + 1) }).then(function (t) {
                    if (t.error) { fail("Building floor " + (f + 1) + " failed: " + t.error); return; }
                    RPG.schedule(1, function () { nextFloor(f + 1, extras); });
                });
            };
            RPG.schedule(1, rows);
        }
        // 4. stairs, then the module blocks and their settings
        function finish(extras) {
            var P = palette(), list = stairSpec(d, map, flights, P);
            var spots = anchorSpots(d, map), relOf = {};
            Object.keys(spots).forEach(function (k) { relOf[k] = spots[k].rel; });
            Object.keys(spots).forEach(function (k) { var s = spots[k]; list.push(s.x, s.y, s.z, P.idx(DM.BLOCK[map.anchors[k].type])); });
            extras.forEach(function (e) { list.push(e.x, e.y, e.z, P.idx(DM.BLOCK[e.a.type] || DM.BLOCK.anchor)); });
            job.blocks += list.length / 4;
            RPG.edit.place(null, WORKSHOP, { palette: P.list, blocks: list }, { history: false, progress: false, label: "Dungeon painter: stairs and modules" }).then(function (t) {
                if (t.error) { fail("Placing the modules failed: " + t.error); return; }
                // the plot's module list: modules in the box go, the painted ones (and the kept extras) come in
                Object.keys(A).forEach(function (k) { var r = DM.parseKey(k); if (inBox(box, o.x + r.dx, o.y + r.dy, o.z + r.dz)) delete A[k]; });
                extras.forEach(function (e) { A[e.key] = e.a; });
                // the modules' settings a hundred a tick, then the saves one a tick (big maps have hundreds of modules)
                var keys = Object.keys(spots), ki = 0;
                var configure = function () {
                    for (var n = 0; n < 100 && ki < keys.length; n++) {
                        var k = keys[ki++];
                        A[spots[k].rel] = builtModule(d, map, k, spots, relOf);
                    }
                    if (ki < keys.length) { RPG.schedule(1, configure); return; }
                    RPG.schedule(1, saveAll);
                };
                var saveAll = function () {
                    DM.saveAnchors(d.id);
                    RPG.schedule(1, last);
                };
                var last = function () {
                    var secs = (DM.now() - job.started) / 1000;
                    map.generated = { at: DM.now(), box: box, seconds: secs, blocks: job.blocks };
                    store(d.id, map);
                    delete JOBS[d.id];
                    // staff standing in the rebuilt area go to the entry point (the floor under them may be gone)
                    var entry = null;
                    Object.keys(spots).forEach(function (k) { if (map.anchors[k].type === "entry") entry = spots[k]; });
                    if (entry) RPG.server.players().forEach(function (pl) {
                        if (pl.dimension === WORKSHOP && pl.x >= box.x1 && pl.x < box.x2 + 1 && pl.z >= box.z1 && pl.z < box.z2 + 1 && pl.y >= box.y1 - 2 && pl.y <= box.y2 + 2)
                            pl.teleportTo(WORKSHOP, entry.x + 0.5, entry.y, entry.z + 0.5, pl.yaw, pl.pitch);
                    });
                    RPG.log("[Dungeon Maker] painted '" + d.id + "' built: " + job.blocks + " blocks in " + secs.toFixed(2) + " s");
                    done({ ok: true, seconds: (DM.now() - job.started) / 1000, blocks: job.blocks, warnings: chk.warnings });
                };
                configure();
            });
        }
    }

    /** Puts back what the last Generate replaced (blocks and the module settings in that box). */
    function undo(p, d, done) {
        var u = RPG.data.get("dmk_pundo_" + d.id, null);
        if (!u || !RPG.edit.schemExists("dmk_pundo_" + d.id)) { done({ error: "Nothing to undo" }); return; }
        if (JOBS[d.id]) { done({ error: "This dungeon is being built" }); return; }
        JOBS[d.id] = { started: DM.now() };
        var b = u.box, o = DM.plotOrigin(d.plot);
        RPG.edit.set(null, WORKSHOP, { type: "cuboid", x1: b.x1, y1: b.y1, z1: b.z1, x2: b.x2, y2: b.y2, z2: b.z2 }, "minecraft:air", { history: false, progress: false }).then(function () {
            RPG.edit.schemPlace(null, "dmk_pundo_" + d.id, WORKSHOP, b.x1, b.y1, b.z1, { history: false, progress: false, label: "Dungeon painter: undo" }).then(function (t) {
                delete JOBS[d.id];
                if (t.error) { done({ error: t.error }); return; }
                var A = DM.anchors(d.id);
                Object.keys(A).forEach(function (k) { var r = DM.parseKey(k); if (inBox(b, o.x + r.dx, o.y + r.dy, o.z + r.dz)) delete A[k]; });
                Object.keys(u.anchors || {}).forEach(function (k) { A[k] = u.anchors[k]; });
                DM.saveAnchors(d.id);
                RPG.data.remove("dmk_pundo_" + d.id);
                RPG.edit.schemDelete("dmk_pundo_" + d.id);
                var map = get(d.id);
                if (map) { delete map.generated; store(d.id, map); }
                done({ ok: true });
            });
        });
    }

    // ---- importing a build ------------------------------------------------------------------------------------------
    var PASSABLE = /torch|lantern|cobweb|flower|sapling|^minecraft:(short_)?grass$|fern|carpet|button|lever|pressure_plate|rail|sign|banner|candle|chain$|end_rod|skull|_head$|potted_|flower_pot|mushroom$|dead_bush|snow$|campfire|decorated_pot|sea_pickle|ladder|vine|scaffolding/;
    function isAir(b) { return !b || b === "minecraft:air" || b === "minecraft:cave_air" || b === "minecraft:void_air"; }
    function isLiquid(b) { return b === "minecraft:water" || b === "minecraft:lava"; }
    function isLight(b) { return /lantern|torch|glowstone|shroomlight|froglight|candle|end_rod|redstone_lamp|beacon/.test(b); }
    var KLASS = {};      // block id -> 0 air, 1 liquid, 2 passable, 3 module, 4 solid (asked once per id)
    function klass(b) {
        var k = KLASS[b];
        if (k === undefined) KLASS[b] = k = isAir(b) ? 0 : isLiquid(b) ? 1 : DM.anchorTypeOf(b) ? 3 : PASSABLE.test(b) ? 2 : 4;
        return k;
    }
    function solid(b) { return klass(b) === 4; }
    function walkOk(b) { var k = klass(b); return k === 0 || k === 2 || k === 3; }

    /** Reads the plot's build into a map (best effort): floors, walls, doors, stairs, lights, hazards and the modules. */
    function importPlot(p, d, done) {
        if (JOBS[d.id]) { done({ error: "This dungeon is being built" }); return; }
        // only what is inside the dungeon's bounds (Dungeon Wand), when it has them
        var b = DM.wands ? DM.wands.copyBox(d) : DM.plotBox(d.plot), o = DM.plotOrigin(d.plot), A = DM.anchors(d.id);
        RPG.edit.extent(null, WORKSHOP, { type: "cuboid", x1: b.x1, y1: b.y1, z1: b.z1, x2: b.x2, y2: b.y2, z2: b.z2 }, { history: false, progress: false }).then(function (t) {
            var e = t.result;
            if (t.error || !e) { done({ error: t.error || "The plot is empty" }); return; }
            var notes = [];
            var w = e.maxX - e.minX + 1, h = e.maxZ - e.minZ + 1, x0 = e.minX, z0 = e.minZ, side = maxSide();
            if (w > side) { x0 += Math.floor((w - side) / 2); w = side; notes.push("The build is wider than " + side + " cells: only the middle was read"); }
            if (h > side) { z0 += Math.floor((h - side) / 2); h = side; notes.push("The build is longer than " + side + " cells: only the middle was read"); }
            w = Math.max(4, w); h = Math.max(4, h);
            var y1 = Math.max(MIN_Y, e.minY - 1), y2 = Math.min(MAX_Y, e.maxY + 1), H = y2 - y1 + 1;
            if (w * h * H > 2500000) { done({ error: "The build is too tall to read (" + H + " blocks)" }); return; }
            JOBS[d.id] = { started: DM.now() };
            var col = new Array(w * h), score = [], floorBlocks = {}, levels = [], map = null;
            for (var s0 = 0; s0 < H; s0++) score.push(0);
            var walls = {}, ceilings = {}, lights = {}, stairsB = {}, doors = {}, decos = {}, pillars = {};
            // everything runs as small tasks, ~10 ms of them a tick, so a big plot never stalls the server
            var tasks = [], ti = 0;
            var run = function () {
                var t0 = DM.now();
                try { while (ti < tasks.length && DM.now() - t0 < 10) tasks[ti++](); }
                catch (err) { delete JOBS[d.id]; done({ error: "Import failed: " + err }); return; }
                if (p && ti < tasks.length) p.actionbar("&eWorking out the map... " + Math.floor(ti * 100 / tasks.length) + "%");
                if (ti < tasks.length) RPG.schedule(1, run);
            };
            // 1. read the columns chunk by chunk (and count walkable levels while at it): each chunk is held loaded
            //    (a few at a time) and read once it is in memory, so reading never makes the server wait for a chunk
            var readCol = function (n) {
                var x = x0 + n % w, z = z0 + Math.floor(n / w), c = new Array(H);
                for (var y = 0; y < H; y++) { var id = RPG.world.getBlock(WORKSHOP, x, y1 + y, z); c[y] = id ? String(id).split("[")[0] : "minecraft:air"; }
                col[n] = c;
                for (var y3 = 0; y3 < H - 2; y3++) if (solid(c[y3]) && walkOk(c[y3 + 1]) && walkOk(c[y3 + 2])) { score[y3]++; floorBlocks[c[y3]] = (floorBlocks[c[y3]] | 0) + 1; }
            };
            var chunks = [], byChunk = {};
            for (var n0 = 0; n0 < w * h; n0++) {
                var ck = ((x0 + n0 % w) >> 4) + "," + ((z0 + Math.floor(n0 / w)) >> 4);
                if (!byChunk[ck]) { byChunk[ck] = { cx: (x0 + n0 % w) >> 4, cz: (z0 + Math.floor(n0 / w)) >> 4, cols: [], at: 0 }; chunks.push(byChunk[ck]); }
                byChunk[ck].cols.push(n0);
            }
            var readDone = 0, asked = 0, waited = 0;
            var readStep = function () {
                var t0 = DM.now();
                // the chunks load in the background (RPG.world.preload); each is read once it is in
                if (DM.now() - asked > 8000) { asked = DM.now(); RPG.world.preload(WORKSHOP, x0, z0, x0 + w - 1, z0 + h - 1); }
                try {
                    var progress = false;
                    for (var k = 0; k < chunks.length && DM.now() - t0 < 10; k++) {
                        var c2 = chunks[k];
                        if (c2.at >= c2.cols.length) continue;
                        if (!RPG.world.isLoaded(WORKSHOP, c2.cx * 16, c2.cz * 16) && waited < 400) continue;      // after ~20 s read it anyway
                        progress = true;
                        while (c2.at < c2.cols.length && DM.now() - t0 < 10) readCol(c2.cols[c2.at++]);
                        if (c2.at >= c2.cols.length) readDone++;
                    }
                    if (!progress) waited++;
                } catch (err) { delete JOBS[d.id]; done({ error: "Import failed: " + err }); return; }
                if (p) p.actionbar("&eReading the plot... " + Math.floor(readDone * 100 / chunks.length) + "%");
                if (readDone < chunks.length) { RPG.schedule(1, readStep); return; }
                RPG.schedule(1, run);
            };
            // 2. the floors: levels with many walkable surfaces, then each floor's cells a few rows a task
            tasks.push(function () {
                var best = Math.max.apply(null, score.concat([0]));
                if (!best) throw "No floor found to stand on";
                score.map(function (s1, y) { return { s: s1, y: y }; }).sort(function (a, c2) { return c2.s - a.s; }).forEach(function (l) {
                    if (l.s < Math.max(6, best * 0.12) || levels.length >= MAX_FLOORS) return;
                    if (levels.every(function (y) { return Math.abs(y - l.y) >= 3; })) levels.push(l.y);
                });
                levels.sort(function (a, c2) { return a - c2; });
                map = { v: 1, w: w, h: h, ox: x0 - o.x, oz: z0 - o.z, theme: {}, floors: [], anchors: {} };
                levels.forEach(function (ly, f) { floorTasks(ly, f); });
                tasks.push(finish);
            });
            RPG.schedule(1, readStep);

            function floorTasks(ly, f) {
                var st = { arr: new Array(w * h), roofed: [], ceilN: 0, roomN: 0, height: 4 };
                // wall height: how tall this floor's walls commonly are
                tasks.push(function () {
                    var top = f + 1 < levels.length ? levels[f + 1] : H - 1, height = DM.clampInt(top - ly - 1, 2, 12, 4), hs = {};
                    for (var i2 = 0; i2 < col.length; i2 += Math.max(1, Math.floor(col.length / 4000))) {
                        var c = col[i2];
                        if (!solid(c[ly]) || !solid(c[ly + 1])) continue;
                        var n = 0; while (ly + 1 + n < H && n < 13 && solid(c[ly + 1 + n])) n++;
                        hs[n] = (hs[n] | 0) + 1;
                    }
                    var hk = Object.keys(hs).sort(function (a, c2) { return hs[c2] - hs[a]; });
                    if (hk.length) height = DM.clampInt(Number(hk[0]) - (f + 1 < levels.length ? 0 : 1), 2, 12, height);
                    if (f + 1 < levels.length) height = Math.min(height, levels[f + 1] - ly - 1);
                    st.height = DM.clampInt(height, 2, 12, 4);
                });
                for (var r0 = 0; r0 < h; r0 += 4) (function (za) { tasks.push(function () { classifyRows(ly, f, st, za, Math.min(h - 1, za + 3)); }); })(r0);
                tasks.push(function () { finishFloor(ly, f, st); });
            }
            function classifyRows(ly, f, st, za, zb) {
                var height = st.height, arr = st.arr;
                for (var z = za; z <= zb; z++) for (var x = 0; x < w; x++) {
                        var cc = col[z * w + x], t = ".", fb = cc[ly], a1 = cc[ly + 1] || "minecraft:air", a2 = cc[ly + 2] || "minecraft:air", stairB = null;
                        if (f + 1 < levels.length) for (var sy = ly + 1; sy <= levels[f + 1] && sy < H; sy++) if (/_stairs$/.test(cc[sy])) { stairB = cc[sy]; break; }
                        if (isLiquid(fb)) { t = fb === "minecraft:water" ? "~" : "^"; if (ly + height + 1 < H && solid(cc[ly + height + 1])) st.roofed[z * w + x] = 1; }
                        else if (solid(fb)) {
                            if (stairB) { t = "U"; stairsB[stairB] = (stairsB[stairB] | 0) + 1; }
                            else if (solid(a1) && solid(a2)) {
                                t = "w"; walls[a1] = (walls[a1] | 0) + 1;
                                if (/fence|bars|pane|door/.test(a1)) { t = "d"; doors[a1] = (doors[a1] | 0) + 1; }
                            }
                            else if (isLight(a1) || isLight(fb) || (ly + height < H && isLight(cc[ly + height]))) { t = "T"; lights[isLight(a1) ? a1 : isLight(fb) ? fb : cc[ly + height]] = 1; }
                            else if (!isAir(a1) && !DM.anchorTypeOf(a1) && walkOk(a2)) { t = "*"; decos[a1] = (decos[a1] | 0) + 1; }
                            else if (/fence|bars|pane/.test(a1)) { t = "d"; doors[a1] = (doors[a1] | 0) + 1; }
                            else t = "f";
                            if (ly + height + 1 < H && solid(cc[ly + height + 1])) { st.roofed[z * w + x] = 1; if (t !== "w") { st.ceilN++; ceilings[cc[ly + height + 1]] = (ceilings[cc[ly + height + 1]] | 0) + 1; } }
                            if (t !== "w") st.roomN++;
                        } else if (isAir(fb)) {
                            var below = false;
                            for (var k2 = 1; k2 <= 4 && ly - k2 >= 0; k2++) if (solid(cc[ly - k2])) { below = true; break; }
                            if (below || f > 0) {
                                // a pit only when something walkable is next to it on this floor
                                var near = [[1, 0], [-1, 0], [0, 1], [0, -1]].some(function (s) {
                                    var nx = x + s[0], nz = z + s[1];
                                    if (nx < 0 || nz < 0 || nx >= w || nz >= h) return false;
                                    var n2 = col[nz * w + nx]; return solid(n2[ly]) && walkOk(n2[ly + 1]);
                                });
                                if (near) t = "o";
                            }
                        }
                        st.arr[z * w + x] = t;
                    }
            }
            function finishFloor(ly, f, st) {
                    var arr = st.arr, roofed = st.roofed, ceilN = st.ceilN, roomN = st.roomN, height = st.height;
                    // a floor with ceilings: what has no ceiling over it is outside (the roofs of the floor below, a platform)
                    var hasCeiling = ceilN >= Math.max(8, roomN * 0.1);
                    if (hasCeiling) {
                        for (var q = 0; q < arr.length; q++) if (!roofed[q] && /[fdT*~\^]/.test(arr[q])) arr[q] = ".";
                        var insideNear = function (q2, re) {
                            var qx = q2 % w, qz = Math.floor(q2 / w);
                            return [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]].some(function (s2) {
                                var nx = qx + s2[0], nz = qz + s2[1]; return nx >= 0 && nz >= 0 && nx < w && nz < h && re.test(arr[nz * w + nx]);
                            });
                        };
                        for (var q3 = 0; q3 < arr.length; q3++) if ((arr[q3] === "w" || arr[q3] === "o") && !insideNear(q3, /[fdT*~\^UD]/)) arr[q3] = ".";
                    }
                    // isolated wall columns are pillars
                    for (var j = 0; j < arr.length; j++) {
                        if (arr[j] !== "w") continue;
                        var jx = j % w, jz = Math.floor(j / w), alone = [[1, 0], [-1, 0], [0, 1], [0, -1]].every(function (s) {
                            var nx = jx + s[0], nz = jz + s[1]; return nx < 0 || nz < 0 || nx >= w || nz >= h || arr[nz * w + nx] !== "w";
                        });
                        if (alone) { arr[j] = "P"; var pb = col[j][ly + 1]; pillars[pb] = (pillars[pb] | 0) + 1; }
                    }
                    map.floors.push({ name: "Floor " + (f + 1), y: y1 + ly - o.y, height: height, ceiling: hasCeiling, cells: arr.join("") });
                    st.arr = null;
            }
            function finish() {
                delete JOBS[d.id];
                // stairs landings: each flight's top step (its highest stairs block) leads on, in the flight's direction, to the floor above
                map.floors.forEach(function (fl, f) {
                    if (f + 1 >= map.floors.length) return;
                    var up = map.floors[f + 1].cells.split(""), seen = {};
                    var topOf = function (i4) { var hcol = col[i4], hy = -1; for (var yy = levels[f] + 1; yy <= levels[f + 1] && yy < H; yy++) if (/_stairs$/.test(hcol[yy])) hy = yy; return hy; };
                    for (var i3 = fl.cells.indexOf("U"); i3 >= 0; i3 = fl.cells.indexOf("U", i3 + 1)) {
                        if (seen[i3]) continue;
                        var run = [], qq = [i3]; seen[i3] = 1;
                        while (qq.length) {
                            var c3 = qq.pop(); run.push(c3);
                            [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (s3) {
                                var nx = c3 % w + s3[0], nz = Math.floor(c3 / w) + s3[1], j3 = nz * w + nx;
                                if (nx >= 0 && nz >= 0 && nx < w && nz < h && !seen[j3] && fl.cells.charAt(j3) === "U") { seen[j3] = 1; qq.push(j3); }
                            });
                        }
                        var top = run[0];
                        run.forEach(function (c4) { if (topOf(c4) > topOf(top)) top = c4; });
                        var tx = top % w, tz = Math.floor(top / w), dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
                        // the direction: away from the run's other cells (a lone stair: towards walkable floor above)
                        var dir = null;
                        dirs.forEach(function (d4) { var bx = tx - d4[0], bz = tz - d4[1]; if (!dir && run.indexOf(bz * w + bx) >= 0) dir = d4; });
                        if (!dir) dirs.forEach(function (d4) { var nx = tx + d4[0], nz = tz + d4[1]; if (!dir && nx >= 0 && nz >= 0 && nx < w && nz < h && /[f.]/.test(up[nz * w + nx])) dir = d4; });
                        if (!dir) continue;
                        var lx = tx + dir[0], lz = tz + dir[1];
                        if (lx >= 0 && lz >= 0 && lx < w && lz < h && up[lz * w + lx] !== "w" && fl.cells.charAt(lz * w + lx) !== "U") up[lz * w + lx] = "D";
                    }
                    map.floors[f + 1].cells = up.join("");
                });
                // the theme: what is used most
                var pick = function (m, fallback) { var k = Object.keys(m).sort(function (a, c2) { return m[c2] - m[a]; })[0]; return k && allowedBlock(k) ? k : fallback; };
                var base = PRESETS.stone_brick;
                map.theme = { preset: "custom", floor: pick(floorBlocks, base.floor), wall: pick(walls, base.wall), ceiling: pick(ceilings, base.ceiling), pillar: pick(pillars, base.pillar),
                    light: pick(lights, base.light), stairs: pick(stairsB, base.stairs), door: pick(doors, base.door), deco: pick(decos, base.deco) };
                // the modules: painted where the painter draws them, the rest kept as they are
                var relToCell = {}, kept = 0;
                Object.keys(A).forEach(function (k) {
                    var a = A[k], r = DM.parseKey(k), X = o.x + r.dx, Y = o.y + r.dy, Z = o.z + r.dz, cx = X - x0, cz = Z - z0, tile = TILE_OF_TYPE[a.type];
                    if (cx < 0 || cz < 0 || cx >= w || cz >= h) return;
                    var f = -1;
                    map.floors.forEach(function (fl, i4) { var fy = o.y + fl.y; if (tile === "L" ? Y === fy || (Y > fy && Y <= fy + fl.height) : Y === fy + 1) f = i4; });
                    if (!tile || f < 0) { kept++; return; }
                    var fl = map.floors[f], arr = fl.cells.split("");
                    if (tile === "L") {
                        // the door's zone cells become the painted door
                        var c1 = a.cfg.c1, c2 = a.cfg.c2, cellsL = [];
                        if (a.cfg.zone === "box" && c1 && c2) {
                            for (var zx = Math.min(c1[0], c2[0]); zx <= Math.max(c1[0], c2[0]); zx++) for (var zz = Math.min(c1[2], c2[2]); zz <= Math.max(c1[2], c2[2]); zz++) cellsL.push([o.x + zx - x0, o.z + zz - z0]);
                        } else cellsL.push([cx, cz]);
                        cellsL.forEach(function (q) { if (q[0] >= 0 && q[1] >= 0 && q[0] < w && q[1] < h) arr[q[1] * w + q[0]] = "L"; });
                        fl.cells = arr.join("");
                        var g = doorGroup(map, fl, cellsL[0][0], cellsL[0][1]);
                        var first = cellKey(f, g[0] % w, Math.floor(g[0] / w));
                        relToCell[k] = first;
                        map.anchors[first] = { type: a.type, cfg: clone(a.cfg) };
                    } else {
                        arr[cz * w + cx] = tile;
                        fl.cells = arr.join("");
                        relToCell[k] = cellKey(f, cx, cz);
                        map.anchors[cellKey(f, cx, cz)] = { type: a.type, cfg: clone(a.cfg) };
                    }
                });
                Object.keys(map.anchors).forEach(function (k) {
                    var c = map.anchors[k].cfg;
                    ["links", "order"].forEach(function (f2) { if (c[f2]) c[f2] = c[f2].map(function (j) { return relToCell[j]; }).filter(function (j) { return !!j; }); });
                });
                if (kept) notes.push(kept + " module(s) the painter can't draw (switches, logic gates, bridges...) stay in the plot as they are");
                if (!map.floors.length) { done({ error: "No floor found to stand on" }); return; }
                var res = clean(map, map);
                if (res.error) { done({ error: res.error }); return; }
                done({ map: res.map, notes: notes });
            }
        });
    }

    // ---- the painted modules' settings: the workshop's module screens edit them ------------------------------------
    /** Like DungeonMaker.anchorPayload, for a painted module (its key is its cell). */
    function anchorPayload(p, d, key) {
        var map = get(d.id), a = map && map.anchors[key];
        if (!a) return null;
        var c = parseCell(key), o = DM.plotOrigin(d.plot), fl = map.floors[c.f] || map.floors[0];
        var out = { dungeon: d.id, dungeonName: d.name, key: key, type: a.type, cfg: a.cfg, paint: true, cell: c,
            x: o.x + map.ox + c.x, y: o.y + fl.y + 1, z: o.z + map.oz + c.z, where: "Painted, " + (fl.name || "floor " + (c.f + 1)) + " · cell " + c.x + ", " + c.z };
        if (a.type === "door") out.keyName = a.cfg.key ? DM.itemName(a.cfg.key.id) : "";
        if (a.type === "spawner" || a.type === "boss") out.inventory = DM.inventoryOf(p);
        var label = function (j) { var b = map.anchors[j], q = parseCell(j); return (b.cfg && b.cfg.name ? b.cfg.name : DM.typeName(b.type)) + " (floor " + (q.f + 1) + ", " + q.x + ", " + q.z + ")"; };
        if (DM.SOURCE_TYPES[a.type]) out.linkables = Object.keys(map.anchors).filter(function (j) { return j !== key && DM.INPUT_TYPES[map.anchors[j].type]; }).map(function (j) {
            var q = parseCell(j); return { key: j, type: map.anchors[j].type, name: label(j), x: o.x + map.ox + q.x, y: o.y + (map.floors[q.f] || fl).y + 1, z: o.z + map.oz + q.z };
        });
        if (DM.INPUT_TYPES[a.type]) out.inputs = Object.keys(map.anchors).filter(function (j) { var b = map.anchors[j]; return DM.SOURCE_TYPES[b.type] && (b.cfg.links || []).indexOf(key) >= 0; })
            .map(function (j) { return { key: j, type: map.anchors[j].type, name: label(j) }; });
        return out;
    }
    function openAnchor(p, d, key) { var pl = anchorPayload(p, d, key); if (pl) DM.sendBig(p, "anchor", pl); }
    /** For the anchor ops of 30_dungeon_maker_net.js: {d, A, a} of a painted module, or null. */
    function anchorAt(p, m) {
        var d = DM.worldDef(String(m.dungeon || "")), map = d && get(d.id);
        if (!map) return null;
        var a = map.anchors[m.key];
        if (!a) return null;
        return { d: d, A: map.anchors, a: a, paint: true, save: function () { store(d.id, map); syncBuilt(d, map, m.key); }, open: function (pl) { openAnchor(pl, d, m.key); } };
    }
    /**
     * After Generate the plot has the module blocks: a painted module set up later (Set up in the painter) updates its
     * built block too, so a run uses the new settings without regenerating (only when that block is still the one
     * Generate put there).
     */
    function syncBuilt(d, map, key) {
        if (!map.generated || JOBS[d.id] || !map.anchors[key]) return;
        var spots = anchorSpots(d, map), s = spots[key], A = DM.anchors(d.id);
        if (!s || !A[s.rel] || A[s.rel].type !== map.anchors[key].type) return;
        var relOf = {};
        Object.keys(spots).forEach(function (k) { relOf[k] = spots[k].rel; });
        A[s.rel] = builtModule(d, map, key, spots, relOf);
        DM.saveAnchors(d.id);
    }
    function toggleLink(p, d, from, to) {
        var map = get(d.id), a = map && map.anchors[from], b = map && map.anchors[to];
        if (!a || !b || !DM.SOURCE_TYPES[a.type]) return false;
        if (!DM.INPUT_TYPES[b.type]) { p.actionbar("&c" + DM.typeName(b.type) + " can't take a signal"); return false; }
        var L = a.cfg.links || (a.cfg.links = []), i = L.indexOf(to);
        if (i >= 0) L.splice(i, 1); else if (L.length < 16) L.push(to); else { p.actionbar("&cAt most 16 links"); return false; }
        store(d.id, map);
        syncBuilt(d, map, from);
        return true;
    }

    // ---- messages -------------------------------------------------------------------------------------------------------
    var UPLOADS = {};
    function result(p, ok, msg) { RPG.net.send(p, "dmk_msg", { ok: !!ok, msg: String(msg) }); if (!ok) p.actionbar("&c" + msg); }
    function editable(p, id) {
        if (!DM.isAdmin(p)) { p.actionbar("&cOnly dungeon staff can do that"); return null; }
        var d = DM.worldDef(id);
        if (!d) { p.actionbar(DM.isFile(id) ? "&cThis dungeon was loaded from a file and can't be edited here" : "&cNo such dungeon"); return null; }
        return d;
    }
    function sendMap(p, d, extra) {
        var map = get(d.id) || boundsMap(d.id) || newMap(Math.min(48, maxSide()), Math.min(48, maxSide()));
        // the dungeon's bounds and rooms (wands) are drawn over the map
        var bd = DM.wands ? DM.wands.boundsRel(d.id) : null, rooms = [];
        if (DM.wands) { var lay = DM.wands.get(d.id); Object.keys(lay.rooms).forEach(function (k) { var r = lay.rooms[k], b = DM.wands.roomBox(r); rooms.push({ name: r.name, type: r.type, shape: r.shape, box: b, c: r.c, r: r.r }); }); }
        var out = { id: d.id, name: d.name, map: map, saved: !!get(d.id), plotHalf: plotHalf(), maxSide: maxSide(), maxFloors: MAX_FLOORS, presets: PRESETS,
            canUndo: !!RPG.data.get("dmk_pundo_" + d.id, null), busy: !!JOBS[d.id], problems: get(d.id) ? check(map, d.id) : null, bounds: bd, rooms: rooms };
        if (extra) Object.keys(extra).forEach(function (k) { out[k] = extra[k]; });
        DM.sendBig(p, "paint", out);
    }
    /** Opens the painter for a dungeon (menu button, /dungeons paint <id>). */
    function open(p, id) { var d = editable(p, id); if (d) sendMap(p, d, { open: true }); return !!d; }

    RPG.net.on("dmk_paint", function (p, m) {
        if (!m || typeof m.op !== "string") return;
        var d = editable(p, String(m.id || ""));
        if (!d) return;
        switch (m.op) {
            case "open": sendMap(p, d, { open: true }); break;
            case "up": {
                // the map arrives in pieces (RPG.net messages are ~30 KB)
                var u = DM.uid(p), n = DM.clampInt(m.n, 1, 64, 1), i = DM.clampInt(m.i, 0, n - 1, 0), box = UPLOADS[u];
                if (!box || box.id !== d.id || box.tag !== m.tag) box = UPLOADS[u] = { id: d.id, tag: m.tag, n: n, got: 0, s: [] };
                if (box.s[i] === undefined) { box.s[i] = String(m.s || "").substring(0, 30000); box.got++; }
                if (box.got < box.n) return;
                delete UPLOADS[u];
                var raw = null;
                try { raw = JSON.parse(box.s.join("")); } catch (e) { result(p, false, "The map arrived damaged"); return; }
                var res = clean(raw, get(d.id));
                if (res.error) { result(p, false, res.error); sendMap(p, d); return; }
                store(d.id, res.map);
                var then = raw.then || {};
                if (then.anchor && res.map.anchors[then.anchor]) { openAnchor(p, d, String(then.anchor)); return; }
                if (then.generate) { build(p, d); sendMap(p, d, { busy: true }); return; }
                sendMap(p, d, { savedMsg: true });
                if (!then.quiet) result(p, true, "Map saved");
                break;
            }
            case "generate": if (m.confirm === true) build(p, d); break;
            case "undo":
                undo(p, d, function (r) { if (r.error) result(p, false, "Undo: " + r.error); else { result(p, true, "The plot is back as it was before Generate"); p.actionbar("&aUndone"); } sendMap(p, d); });
                break;
            case "import":
                importPlot(p, d, function (r) {
                    if (r.error) { result(p, false, "Import: " + r.error); return; }
                    store(d.id, r.map);
                    sendMap(p, d, { imported: r.notes || [] });
                    result(p, true, "Imported " + r.map.floors.length + " floor(s) from the plot" + (r.notes && r.notes.length ? " (" + r.notes.length + " note(s))" : ""));
                });
                break;
            case "reset": forget(d.id); sendMap(p, d); result(p, true, "Map cleared"); break;
            case "plot": DM.goToPlot(p, d.id); RPG.net.send(p, "dmk_close", {}); break;
            case "anchor": if (get(d.id) && get(d.id).anchors[m.key]) openAnchor(p, d, String(m.key)); break;
            case "blocks": DM.sendBig(p, "paint_blocks", { blocks: Object.keys(DM.blockIds()).filter(allowedBlock).sort(), items: DM.tools.itemChoices() }); break;
        }
    });
    function build(p, d) {
        p.actionbar("&eBuilding the painted dungeon...");
        generate(p, d, function (r) {
            if (r.error) { result(p, false, "Generate: " + r.error); sendMap(p, d); return; }
            p.tell("&6[Dungeons] &e'" + d.name + "' built from the painted map: " + r.blocks + " blocks in " + r.seconds.toFixed(1) + " s." + (r.warnings.length ? " &7(" + r.warnings.length + " warning(s))" : ""));
            p.actionbar("&aDungeon built");
            result(p, true, "Built: " + r.blocks + " blocks in " + r.seconds.toFixed(1) + " s");
            sendMap(p, d, { built: true });
        });
    }

    return { get: get, forget: forget, forgetCache: function (id) { delete MAPS[id]; }, clean: clean, check: check, generate: generate, undo: undo, importPlot: importPlot, open: open,
        anchorAt: anchorAt, openAnchor: openAnchor, toggleLink: toggleLink, PRESETS: PRESETS, TILES: TILES, KINDS: KINDS, newMap: newMap };
})();
