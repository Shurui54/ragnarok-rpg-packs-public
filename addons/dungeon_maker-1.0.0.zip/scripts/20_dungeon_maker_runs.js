// =====================================================================================
//  Dungeon Maker - runs: each player or party gets its own copy of a dungeon in the arena
// =====================================================================================
//  Entering: the requirements are checked (and items used up), the plot's build is measured
//  (RPG.edit.extent) and copied block for block into a free arena slot (RPG.edit.transfer, or
//  RPG.edit.schemPlace for exported dungeons), the modules come alive and everyone is
//  teleported to the Entry Point. A run ends when its goals are met (and someone reaches the
//  Exit Point, if it has one), when time runs out, or when everyone has left; its slot is then
//  wiped for the next run. Runs live in memory: after a restart players still inside are sent
//  back and the stale slots are wiped.
//
//  Modules in a run: no module block shows. Each becomes air or the block it is set to look like
//  ("auto": what surrounds it when it is built into a wall or floor), or what it is in play:
//  chests, levers, floor switches, crystal / eye switches, torches. Doors and bridges are the
//  blocks in their zone (a radius round the module, or two corners, optionally only some kinds of
//  block): players click those blocks to open a door. Signals: switches, logic gates, spawners
//  (once all their mobs are down) and bosses (once beaten) power what they are linked to: puzzle
//  doors, puzzle chests, bridges, spawners and bosses set to "signal", and other logic gates.
// =====================================================================================
DungeonMaker.runs = (function () {
    var DM = DungeonMaker, CFG = DM.CFG, ARENA = DM.ARENA, WORKSHOP = DM.WORKSHOP, T = DM.tools;
    var RUNS = {}, BY_PLAYER = {}, BUSY = {}, seq = 0;
    var FACING = { north: 180, south: 0, east: -90, west: 90 };
    function pk(x, y, z) { return x + "," + y + "," + z; }
    function isAir(b) { return !b || b === "minecraft:air" || b === "minecraft:cave_air" || b === "minecraft:void_air"; }

    // ---- arena slots: slot n's origin is (n * SPACING, PLATFORM_Y, 0); boxes still to wipe are saved -------------
    function slotOrigin(n) { return { x: n * DM.SPACING, y: DM.PLATFORM_Y, z: 0 }; }
    function slotState() { return RPG.data.get("dmk_slots", null) || {}; }
    function setSlotBox(n, box) { var s = slotState(); if (box) s[n] = box; else delete s[n]; RPG.data.set("dmk_slots", s); }
    function usedSlots() { var u = {}; Object.keys(RUNS).forEach(function (k) { u[RUNS[k].slot] = 1; }); return u; }
    function freeSlot() {
        var used = usedSlots(), max = CFG.get("arenaSlots");
        for (var i = 1; i <= max; i++) if (!used[i]) return i;
        return 0;
    }
    function wipe(box, then) {
        if (!box) { if (then) then(); return; }
        try {
            RPG.edit.set(null, ARENA, { type: "cuboid", x1: box.x1, y1: box.y1, z1: box.z1, x2: box.x2, y2: box.y2, z2: box.z2 }, "minecraft:air",
                { history: false, progress: false, label: "Dungeon cleanup" }).then(function () { if (then) then(); });
        } catch (e) { RPG.log("[Dungeon Maker] cleanup failed: " + e); if (then) then(); }
    }
    // stale boxes from before a restart
    RPG.schedule(40, function () {
        var s = slotState();
        Object.keys(s).forEach(function (n) { if (!usedSlots()[n]) wipe(s[n], function () { setSlotBox(n, null); }); });
    });

    function runOf(p) { var id = BY_PLAYER[DM.uid(p)]; return id ? RUNS[id] || null : null; }
    function members(run) { return run.members.map(DM.online).filter(function (p) { return p && p.dimension === ARENA; }); }
    function tellAll(run, msg) { members(run).forEach(function (p) { p.tell(msg); }); }
    /** The clicking player first, then the rest of the party in the run (who a key is taken from). */
    function keyHolders(run, p) { var l = members(run).filter(function (m) { return DM.uid(m) !== DM.uid(p); }); l.unshift(p); return l; }

    // ---- entering --------------------------------------------------------------------------------------
    function checkEntry(p, d, quiet) {
        var why = null;
        if (d.status !== "published" && !DM.isAdmin(p)) why = "This dungeon is not published yet";
        else if (runOf(p) || BUSY[DM.uid(p)]) why = "You are already in a dungeon";
        else if (p.dimension === ARENA) why = "You are already in a dungeon";
        else {
            var cd = DM.cooldownLeft(p, d.id);
            if (cd > 0 && !DM.isAdmin(p)) why = "On cooldown: " + DM.human(cd) + " left";
            else if (!(d.requirements || []).every(function (r) { return DM.requirementMet(p, r); })) why = "Entry requirements are not met";
            else if (DM.hooks.canEnter) { var r = DM.hooks.canEnter(p, d); if (r === false || typeof r === "string") why = typeof r === "string" ? r : "You can't enter this dungeon"; }
        }
        if (why && !quiet) p.actionbar("&c" + why);
        return why;
    }
    function payEntry(p, d) {
        (d.requirements || []).forEach(function (r) { if (r.type === "item" && r.consume && r.item) p.takeItem(r.item.id, r.count || 1); });
    }
    function start(p, id) {
        var d = DM.def(id);
        if (!d) { p.actionbar("&cNo such dungeon"); return false; }
        if (checkEntry(p, d)) return false;
        var slot = freeSlot();
        if (!slot) { p.actionbar("&cEvery dungeon arena is busy, try again in a moment"); return false; }
        var group = [p];
        if (CFG.get("partyEntry")) {
            var range = CFG.get("partyRange");
            (DM.hooks.partyOf(p) || []).forEach(function (m) {
                if (!m || DM.uid(m) === DM.uid(p) || m.dimension !== p.dimension || m.distanceTo(p) > range) return;
                var why = checkEntry(m, d, true);
                if (why) { m.tell("&7[Dungeons] You stay behind: " + why); return; }
                group.push(m);
            });
        }
        // the id is also written on the run's keys, so it is never reused (not even after a restart)
        var rid = "r" + (++seq) + "_" + Math.floor(Math.random() * 2176782336).toString(36);
        var run = { id: rid, def: id, name: d.name, slot: slot, origin: slotOrigin(slot), members: group.map(DM.uid), state: "building",
            started: 0, endsAt: 0, kills: { total: 0, by: {} }, fired: {}, doorState: {}, loot: {}, unlocked: {}, bossKeyUsed: false, viewing: {}, appeared: {}, done: false, exitAt: 0,
            box: null, emptySince: 0, anchors: [], byKey: {}, byPos: {}, doorAt: {}, protect: {}, zones: {}, node: {}, inputs: {}, powered: {}, logic: [], targets: [],
            mobs: {}, alive: {}, bosses: {}, lock: null, anims: [], puzzle: false };
        RUNS[run.id] = run;
        group.forEach(function (m) { BUSY[DM.uid(m)] = run.id; payEntry(m, d); DM.rememberReturn(m); m.actionbar("&ePreparing " + d.name + "..."); });
        build(run, d);
        return true;
    }

    function fail(run, msg) {
        run.members.forEach(function (u) { delete BUSY[u]; var m = DM.online(u); if (m) m.tell("&c[Dungeons] " + msg); });
        delete RUNS[run.id];
        if (run.box) wipe(run.box, function () { setSlotBox(run.slot, null); }); else setSlotBox(run.slot, null);
    }

    function build(run, d) {
        var stale = slotState()[run.slot];
        var go = function () {
            var files = DM.files(), f = DM.isFile(run.def) ? files[run.def] : null;
            if (f) {
                var o = run.origin, x = o.x + f.offset.x, y = o.y + f.offset.y, z = o.z + f.offset.z;
                run.box = { x1: x, y1: y, z1: z, x2: x + f.size.x - 1, y2: y + f.size.y - 1, z2: z + f.size.z - 1 };
                setSlotBox(run.slot, run.box);
                RPG.edit.schemPlace(null, f.schem, ARENA, x, y, z, { history: false, progress: false, label: "Dungeon " + run.name }).then(function (t) {
                    if (t.error) { fail(run, "Could not build the dungeon: " + t.error); return; }
                    activate(run);
                });
                return;
            }
            // the dungeon's bounds (Dungeon Wand), else the whole plot
            var b = DM.wands ? DM.wands.copyBox(d) : DM.plotBox(d.plot), po = DM.plotOrigin(d.plot);
            RPG.edit.extent(null, WORKSHOP, { type: "cuboid", x1: b.x1, y1: b.y1, z1: b.z1, x2: b.x2, y2: b.y2, z2: b.z2 }, { history: false, progress: false }).then(function (t) {
                var e = t.result;
                if (!RUNS[run.id]) return;
                if (t.error || !e) { fail(run, t.error || "The dungeon's plot is empty"); return; }
                var vol = (e.maxX - e.minX + 1) * (e.maxY - e.minY + 1) * (e.maxZ - e.minZ + 1);
                if (vol > CFG.get("maxBlocks")) { fail(run, "The dungeon is too big to copy (" + vol + " blocks)"); return; }
                var o = run.origin, tx = o.x + (e.minX - po.x), ty = o.y + (e.minY - po.y), tz = o.z + (e.minZ - po.z);
                run.box = { x1: tx, y1: ty, z1: tz, x2: tx + e.maxX - e.minX, y2: ty + e.maxY - e.minY, z2: tz + e.maxZ - e.minZ };
                setSlotBox(run.slot, run.box);
                RPG.edit.transfer(null, WORKSHOP, { type: "cuboid", x1: e.minX, y1: e.minY, z1: e.minZ, x2: e.maxX, y2: e.maxY, z2: e.maxZ }, ARENA, tx, ty, tz,
                    { history: false, progress: false, label: "Dungeon " + run.name }).then(function (t2) {
                        if (t2.error) { fail(run, "Could not build the dungeon: " + t2.error); return; }
                        activate(run);
                    });
            });
        };
        if (stale) wipe(stale, go); else go();
    }

    function worldPos(run, k) { var r = DM.parseKey(k), o = run.origin; return { x: o.x + r.dx, y: o.y + r.dy, z: o.z + r.dz }; }

    // ---- what each module turns into in the run ------------------------------------------------------------
    var SIDES = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
    /** "auto": a module built into a wall or floor (3+ solid neighbours) takes the look of its commonest neighbour, else air. */
    function disguiseOf(run, a) {
        var d = a.cfg.disguise || "auto";
        if (d === "air") return "minecraft:air";
        if (d !== "auto") return d;
        var counts = {}, solid = 0, best = null;
        SIDES.forEach(function (s) {
            var x = a.x + s[0], y = a.y + s[1], z = a.z + s[2];
            if (run.byPos[pk(x, y, z)]) return;
            var b = RPG.world.getBlockState(ARENA, x, y, z);
            if (isAir(b.split("[")[0])) return;
            solid++;
            counts[b] = (counts[b] | 0) + 1;
            if (!best || counts[b] > counts[best]) best = b;
        });
        if (solid >= 3 && best) return best;
        // something has to be there to click
        if ((a.type === "spawner" || a.type === "boss") && a.cfg.trigger === "click") return "minecraft:chiseled_stone_bricks";
        return "minecraft:air";
    }
    function switchBlock(a, on) {
        var c = a.cfg, K = T.BLOCKS;
        switch (c.kind) {
            case "plate": return on ? K.plate_down : K.plate_up;
            case "crystal": return on ? K.crystal_on : K.crystal_off;
            case "eye": return on ? K.eye_open : K.eye_shut;
            case "torch": return "minecraft:campfire[lit=" + !!on + ",signal_fire=false,facing=north]";
        }
        var face = c.face === "floor" ? "face=floor,facing=north" : c.face === "ceiling" ? "face=ceiling,facing=north" : "face=wall,facing=" + c.face;
        return "minecraft:lever[" + face + ",powered=" + !!on + "]";
    }
    function chestBlock(a) {
        var f = "[facing=" + (a.cfg.facing || "south") + "]";
        if (a.type === "sk_chest" && !a.open) return T.BLOCKS.chest_locked + f;
        if (a.type === "bk_chest") return T.BLOCKS.chest_big + f;
        return "minecraft:chest" + f;
    }

    function activate(run) {
        if (!RUNS[run.id]) return;
        var d = DM.def(run.def), A = DM.anchors(run.def), entry = null, o = run.origin;
        run.anchors = [];
        Object.keys(A).forEach(function (k) {
            var a = A[k], pos = worldPos(run, k);
            // anchors removed from the build by other means are skipped
            var here = DM.anchorTypeOf(RPG.world.getBlock(ARENA, pos.x, pos.y, pos.z));
            if (!here) return;
            var ia = { key: k, type: a.type, cfg: a.cfg, x: pos.x, y: pos.y, z: pos.z };
            run.anchors.push(ia);
            run.byKey[k] = ia;
            run.byPos[pk(pos.x, pos.y, pos.z)] = ia;
            if (a.type === "entry" && !entry) entry = ia;
        });
        var isModule = function (x, y, z) { return !!run.byPos[pk(x, y, z)]; };
        // zones are read from the untouched copy: the blocks there (with their states) are the door / bridge
        run.anchors.forEach(function (a) {
            if (!DM.ZONE_TYPES[a.type]) return;
            var list = a.cfg.zone === "self" ? [{ x: a.x, y: a.y, z: a.z }] : DM.zoneOf(ARENA, o, a, a.x, a.y, a.z, isModule);
            list.forEach(function (b) {
                b.s = RPG.world.getBlockState(ARENA, b.x, b.y, b.z);
                var key = pk(b.x, b.y, b.z);
                run.protect[key] = 1;
                if (DM.DOOR_TYPES[a.type]) run.doorAt[key] = a.key;
            });
            run.zones[a.key] = list;
        });
        // every module block goes: the stand-ins are worked out first (auto looks at the neighbours), then placed
        var place = [];
        run.anchors.forEach(function (a) {
            var b;
            if (a.type === "switch") b = switchBlock(a, false);
            else if (DM.CHEST_TYPES[a.type] && a.type !== "pz_chest") b = chestBlock(a);
            else if (DM.ZONE_TYPES[a.type] && a.cfg.zone === "self") b = null;     // an old-style door: the module block is the door
            else b = disguiseOf(run, a);
            run.protect[pk(a.x, a.y, a.z)] = 1;
            if (b) place.push([a, b]);
        });
        place.forEach(function (e) { RPG.world.setBlock(ARENA, e[0].x, e[0].y, e[0].z, e[1]); });
        // signals: who feeds whom
        run.anchors.forEach(function (a) {
            var n = run.node[a.key] = { on: false, until: 0, idx: 0, prev: {}, last: -100 };
            if (a.type === "switch" && a.cfg.startOn) { n.on = true; RPG.world.setBlock(ARENA, a.x, a.y, a.z, switchBlock(a, true)); }
            if (DM.INPUT_TYPES[a.type]) {
                run.inputs[a.key] = DM.inputsOf(A, a.key).filter(function (j) { return run.byKey[j]; });
                if (a.type === "logic") run.logic.push(a);
                else if (run.inputs[a.key].length) run.targets.push(a);
            }
            if (a.type === "switch" || a.type === "logic" || a.type === "bridge" || a.type === "pz_door" || a.type === "pz_chest") run.puzzle = true;
            if (a.type === "bridge" && a.cfg.start === "hidden") (run.zones[a.key] || []).forEach(function (b) { RPG.world.setBlock(ARENA, b.x, b.y, b.z, "minecraft:air"); });
        });
        var pm = DM.paint ? DM.paint.get(run.def) : null;
        run.mapInfo = pm ? { ox: pm.ox, oz: pm.oz } : null; run.seen = {};
        run.hasExit = run.anchors.some(function (a) { return a.type === "exit"; });
        // rooms, puzzles and wireless links (the wands) are laid over the modules
        if (DM.wands) { try { DM.wands.activate(run); } catch (e) { RPG.log("[Dungeon Maker] wands in run: " + e); run.w = null; } }
        run.goals = (d.objectives || []).map(function (o2) { return { o: o2, cur: 0, max: Math.max(1, o2.count | 0 || 1), done: false }; });
        run.state = "active";
        run.started = DM.tick();
        run.endsAt = d.timeLimit > 0 ? run.started + d.timeLimit * 20 : 0;
        propagate(run);
        var spot = entry ? { x: entry.x + 0.5, y: entry.y, z: entry.z + 0.5, yaw: FACING[entry.cfg.facing] || 0 }
            : { x: run.origin.x + 0.5, y: run.origin.y, z: run.origin.z + 0.5, yaw: 0 };
        run.spawn = spot;
        run.members.forEach(function (u) {
            delete BUSY[u];
            var m = DM.online(u);
            if (!m) return;
            BY_PLAYER[u] = run.id;
            m.teleportTo(ARENA, spot.x, spot.y, spot.z, spot.yaw, 0);
            m.title("&6" + run.name, "&7Good luck!");
            m.playSound("minecraft:block.end_portal_frame.fill", 0.8, 0.8);
            if (run.goals.length) { m.tell("&6[Dungeons] &eGoals:"); run.goals.forEach(function (g) { m.tell("&7 - " + DM.objectiveText(g.o)); }); }
        });
        run.members = run.members.filter(function (u) { return BY_PLAYER[u] === run.id; });
        if (!run.members.length) dispose(run);
        hud(run);
    }

    // ---- leaving / ending --------------------------------------------------------------------------------
    function goHome(p) { T.stripKeys(p, null); RPG.net.send(p, "dmk_hud", null); if (p.dimension === ARENA) DM.sendBack(p); }
    function leave(p, quiet) {
        var u = DM.uid(p), run = runOf(p);
        if (!run) { if (!quiet) p.actionbar("&cYou are not in a dungeon"); return false; }
        delete BY_PLAYER[u];
        run.members = run.members.filter(function (x) { return x !== u; });
        barsFor(run, p, false);
        goHome(p);
        if (!run.members.length) dispose(run);
        return true;
    }
    function sendEveryoneHome(run) {
        run.members.slice().forEach(function (u) {
            delete BY_PLAYER[u];
            var m = DM.online(u);
            if (m) goHome(m);
        });
        run.members = [];
    }
    function dispose(run) {
        if (!RUNS[run.id]) return;
        sendEveryoneHome(run);
        Object.keys(run.bosses).forEach(function (k) { try { RPG.ui.removeBossBar(run.bosses[k].bar); } catch (e) { } });
        delete RUNS[run.id];
        if (run.box) {
            var b = run.box, cx = (b.x1 + b.x2) / 2, cy = (b.y1 + b.y2) / 2, cz = (b.z1 + b.z2) / 2;
            var r = Math.sqrt(Math.pow(b.x2 - b.x1, 2) + Math.pow(b.y2 - b.y1, 2) + Math.pow(b.z2 - b.z1, 2)) / 2 + 24;
            try {
                RPG.world.entitiesNear(ARENA, cx, cy, cz, Math.min(r, 1024)).forEach(function (e) { if (!e.isPlayer()) { try { RPG.teams.leave(e); } catch (x) { } e.remove(); } });
            } catch (e) { }
            wipe(run.box, function () { setSlotBox(run.slot, null); });
        } else setSlotBox(run.slot, null);
    }
    function setCooldown(p, d) {
        var secs = DM.totalCooldown(d);
        if (secs <= 0) return;
        var cd = p.getVar("dmk_cd", null) || {};
        cd[d.id] = DM.now() + secs * 1000;
        p.setVar("dmk_cd", cd);
    }
    function complete(run) {
        if (run.done) return;
        run.done = true;
        var d = DM.def(run.def), players = members(run), secs = CFG.get("exitCountdown");
        players.forEach(function (m) {
            var c = m.getVar("dmk_done", null) || {};
            c[run.def] = (c[run.def] | 0) + 1;
            m.setVar("dmk_done", c);
            if (d) setCooldown(m, d);
            m.title("&6Dungeon complete!", "&7" + run.name);
            m.playSound("minecraft:ui.toast.challenge_complete", 1, 1);
        });
        if (DM.hooks.onComplete && d) { try { DM.hooks.onComplete(d, players, run); } catch (e) { RPG.log("[Dungeon Maker] onComplete: " + e); } }
        run.exitAt = DM.tick() + secs * 20;
        if (secs <= 0) dispose(run);
    }
    function timeUp(run) {
        var d = DM.def(run.def);
        members(run).forEach(function (m) { m.title("&cTime's up!", "&7" + run.name); m.playSound("minecraft:entity.wither.spawn", 0.5, 1.4); if (d) setCooldown(m, d); });
        run.done = true; run.failed = true;
        run.exitAt = DM.tick() + 60;
    }

    // ---- finding runs and modules by block ------------------------------------------------------------------
    function inBox(run, x, y, z) { var b = run.box; return !!b && x >= b.x1 && x <= b.x2 && y >= b.y1 && y <= b.y2 && z >= b.z1 && z <= b.z2; }
    function runAtBlock(x, y, z) {
        for (var k in RUNS) { var r = RUNS[k]; if (r.state === "active" && inBox(r, x, y, z)) return r; }
        return null;
    }
    function isProtected(run, x, y, z) { var k = pk(x, y, z); return !!(run.protect[k] || run.doorAt[k]); }
    // Module blocks are swapped out when a run starts; an old-style door (the module itself is the door) is the
    // only one left, and the blockInteract handler below answers it first.
    function useAnchor(p, type, x, y, z) { }

    // ---- block animations (doors sliding, bridges forming), a step every 2 ticks ------------------------------------
    function animate(run, blocks, toState, order, sound) {
        var groups = {}, keys = [];
        blocks.forEach(function (b) { var g = order(b); if (!groups[g]) { groups[g] = []; keys.push(g); } groups[g].push(b); });
        keys.sort(function (a, b) { return a - b; });
        run.anims.push({ steps: keys.map(function (g) { return groups[g]; }), i: 0, to: toState, sound: sound });
    }
    function stepAnims(run) {
        run.anims = run.anims.filter(function (an) {
            var step = an.steps[an.i++];
            if (!step) return false;
            step.forEach(function (b) { RPG.world.setBlock(ARENA, b.x, b.y, b.z, an.to(b)); });
            var b0 = step[0];
            if (an.sound && an.i % 2 === 1) RPG.world.sound(ARENA, an.sound, b0.x + 0.5, b0.y + 0.5, b0.z + 0.5, 0.7, 0.9 + Math.random() * 0.2);
            return an.i < an.steps.length;
        });
    }
    function occupied(run, b) {
        return members(run).some(function (m) { return Math.floor(m.x) === b.x && Math.floor(m.z) === b.z && (Math.floor(m.y) === b.y || Math.floor(m.y + 1.2) === b.y); });
    }

    // ---- doors -------------------------------------------------------------------------------------------------
    function centre(run, a) {
        var z = run.zones[a.key] || [];
        if (!z.length) return { x: a.x + 0.5, y: a.y + 0.5, z: a.z + 0.5 };
        var s = { x: 0, y: 0, z: 0 };
        z.forEach(function (b) { s.x += b.x; s.y += b.y; s.z += b.z; });
        return { x: s.x / z.length + 0.5, y: s.y / z.length + 0.5, z: s.z / z.length + 0.5 };
    }
    function tryDoor(p, run, a) {
        if (run.doorState[a.key] === "open") return;
        if (run.w && DM.wands.isLocked(run, a.key)) { p.actionbar("&cThe doors are sealed until the room is cleared"); p.playSound("minecraft:block.iron_door.close", 0.6, 0.6); return; }
        var c = a.cfg;
        if (a.type === "door") {
            var k = c.key;
            if (k && !p.hasItem(k.id, k.count || 1)) { p.actionbar("&cYou need a key: " + DM.itemName(k.id)); p.playSound("minecraft:block.iron_door.close", 0.6, 1.4); return; }
            if (k && c.consume) p.takeItem(k.id, k.count || 1);
        } else if (a.type === "sk_door") {
            var who = T.takeKey(keyHolders(run, p), run.id, T.ITEMS.small_key);
            if (!who) { p.actionbar("&cIt's locked. You need a Small Key."); p.playSound("minecraft:block.chest.locked", 0.8, 1); return; }
            p.actionbar("&fUnlocked with a Small Key" + (DM.uid(who) !== DM.uid(p) ? " &7(" + who.name + "'s)" : ""));
            RPG.world.sound(ARENA, "minecraft:block.iron_trapdoor.open", p.x, p.y, p.z, 1, 1.2);
        } else if (a.type === "bk_door") {
            // the Boss Key is used up by the boss door like a Small Key (bossKeyUsedUp); once turned in, the run's other
            // boss locks (a second boss door, the big chest) take it as given
            if (!run.bossKeyUsed) {
                if (DM.CFG.get("bossKeyUsedUp")) {
                    var bw = T.takeKey(keyHolders(run, p), run.id, T.ITEMS.boss_key);
                    if (!bw) { p.actionbar("&cThis door needs the Boss Key."); p.playSound("minecraft:block.chest.locked", 0.8, 0.7); return; }
                    run.bossKeyUsed = true;
                } else if (T.keyCount(members(run), run.id, T.ITEMS.boss_key) <= 0) { p.actionbar("&cThis door needs the Boss Key."); p.playSound("minecraft:block.chest.locked", 0.8, 0.7); return; }
            }
            p.actionbar("&6The Boss Key turns in the lock...");
            RPG.world.sound(ARENA, "minecraft:block.end_portal_frame.fill", p.x, p.y, p.z, 1, 0.6);
        } else if (a.type === "pz_door") {
            p.actionbar("&7It's sealed tight. Something nearby must open it."); p.playSound("minecraft:block.stone.hit", 0.7, 0.6); return;
        }
        openDoor(run, a);
        hud(run);
    }
    function openDoor(run, a) {
        if (run.doorState[a.key] === "open") return;
        run.doorState[a.key] = "open";
        var blocks = run.zones[a.key] || [], c = centre(run, a);
        animate(run, blocks, function () { return "minecraft:air"; }, function (b) { return b.y; }, "minecraft:block.piston.contract");
        RPG.world.sound(ARENA, a.type === "bk_door" ? "minecraft:block.iron_door.open" : "minecraft:block.iron_door.open", c.x, c.y, c.z, 1, a.type === "bk_door" ? 0.5 : 0.8);
        RPG.world.particle(ARENA, "minecraft:cloud", c.x, c.y, c.z, 16, 0.8, 0.02);
        if (a.type === "pz_door" || a.type === "bk_door") members(run).forEach(function (m) { m.playSound("minecraft:block.note_block.chime", 0.8, 1.2); });
    }
    function closeDoor(run, a) {
        if (run.doorState[a.key] !== "open") return;
        run.doorState[a.key] = "closed";
        var blocks = (run.zones[a.key] || []).filter(function (b) { return !occupied(run, b); });
        animate(run, blocks, function (b) { return b.s; }, function (b) { return -b.y; }, "minecraft:block.piston.extend");
    }
    function setBridge(run, a, shown) {
        var st = run.doorState[a.key] === "shown";
        if (st === shown) return;
        run.doorState[a.key] = shown ? "shown" : "hidden";
        var blocks = (run.zones[a.key] || []).filter(function (b) { return !shown || !occupied(run, b); });
        animate(run, blocks, shown ? function (b) { return b.s; } : function () { return "minecraft:air"; },
            function (b) { return Math.round(Math.sqrt(Math.pow(b.x - a.x, 2) + Math.pow(b.y - a.y, 2) + Math.pow(b.z - a.z, 2))); },
            shown ? "minecraft:block.amethyst_block.place" : "minecraft:block.amethyst_block.break");
    }

    // ---- chests ---------------------------------------------------------------------------------------------------
    function rollLoot(run, cfg) {
        var out = [];
        for (var i = 0; i < 27; i++) {
            var s = (cfg.items || [])[i], ch = (cfg.chances || [])[i];
            if (!s) { out.push(null); continue; }
            var c = ch === null || ch === undefined ? 100 : ch;
            out.push(Math.random() * 100 < c ? T.stamp(JSON.parse(JSON.stringify(s)), run.id) : null);
        }
        return out;
    }
    function openChest(p, run, a) {
        var k = a.key;
        if (a.type === "pz_chest" && !run.appeared[k]) return;
        if (!run.unlocked[k]) {
            if (a.type === "sk_chest") {
                var who = T.takeKey(keyHolders(run, p), run.id, T.ITEMS.small_key);
                if (!who) { p.actionbar("&cIt's locked. You need a Small Key."); p.playSound("minecraft:block.chest.locked", 0.8, 1); return; }
                a.open = true;
                RPG.world.setBlock(ARENA, a.x, a.y, a.z, chestBlock(a));
                RPG.world.sound(ARENA, "minecraft:block.iron_trapdoor.open", a.x, a.y, a.z, 1, 1.3);
                hud(run);
            } else if (a.type === "bk_chest") {
                if (!run.bossKeyUsed && T.keyCount(members(run), run.id, T.ITEMS.boss_key) <= 0) { p.actionbar("&cThe big chest needs the Boss Key."); p.playSound("minecraft:block.chest.locked", 0.8, 0.7); return; }
                members(run).forEach(function (m) { m.playSound("minecraft:ui.toast.challenge_complete", 0.7, 1.2); });
            }
            run.unlocked[k] = true;
        }
        var v = run.viewing[k];
        if (v && v !== DM.uid(p) && DM.online(v) && DM.online(v).dimension === ARENA) { p.actionbar("&7" + DM.online(v).name + " is looking in this chest"); return; }
        if (!run.loot[k]) { run.loot[k] = rollLoot(run, a.cfg); RPG.world.sound(ARENA, "minecraft:block.chest.open", a.x, a.y, a.z, 0.8, 1); }
        run.viewing[k] = DM.uid(p);
        RPG.ui.container(p, { title: a.type === "bk_chest" ? "Big Chest" : "Chest", rows: 3, items: run.loot[k], mode: "storage",
            onClose: function (pl, items) { if (RUNS[run.id]) { run.loot[k] = items; delete run.viewing[k]; } } });
    }
    function appearChest(run, a) {
        if (run.appeared[a.key]) return;
        run.appeared[a.key] = true;
        RPG.world.setBlock(ARENA, a.x, a.y, a.z, chestBlock(a));
        RPG.world.particle(ARENA, "minecraft:end_rod", a.x + 0.5, a.y + 0.6, a.z + 0.5, 24, 0.5, 0.05);
        RPG.world.sound(ARENA, "minecraft:block.amethyst_block.resonate", a.x, a.y, a.z, 1, 1.2);
        members(run).forEach(function (m) { m.playSound("minecraft:entity.player.levelup", 0.5, 1.6); m.actionbar("&eA chest appeared!"); });
    }

    // ---- switches and signals ----------------------------------------------------------------------------------------
    var ACCEPTS = { lever: { use: 1, hit: 1 }, crystal: { use: 1, hit: 1, arrow: 1 }, eye: { arrow: 1 }, torch: { light: 1 }, plate: { press: 1 } };
    var SOUNDS = { lever: ["minecraft:block.lever.click", 0.6, 0.5], crystal: ["minecraft:block.amethyst_block.chime", 1.3, 0.8], eye: ["minecraft:block.end_portal_frame.fill", 1.4, 0.8],
        torch: ["minecraft:item.firecharge.use", 1.0, 1.0], plate: ["minecraft:block.stone_pressure_plate.click_on", 0.7, 0.6] };
    function setSwitch(run, a, on) {
        var n = run.node[a.key];
        if (n.on === on) return;
        n.on = on;
        if (!on) n.until = 0;
        RPG.world.setBlock(ARENA, a.x, a.y, a.z, switchBlock(a, on));
        var s = SOUNDS[a.cfg.kind] || SOUNDS.lever;
        if (a.cfg.kind === "torch" && !on) RPG.world.sound(ARENA, "minecraft:block.fire.extinguish", a.x + 0.5, a.y + 0.5, a.z + 0.5, 0.6, 1.2);
        else RPG.world.sound(ARENA, s[0], a.x + 0.5, a.y + 0.5, a.z + 0.5, 0.9, on ? s[1] : s[2]);
        if (a.cfg.kind === "crystal") RPG.world.particle(ARENA, "minecraft:electric_spark", a.x + 0.5, a.y + 0.7, a.z + 0.5, 10, 0.3, 0.05);
    }
    /** A switch is hit (how: use, hit, arrow, light, press). Returns whether it took it. */
    function hit(run, a, how, p) {
        var c = a.cfg, n = run.node[a.key], t = DM.tick();
        if (!(ACCEPTS[c.kind] || {})[how]) return false;
        if (how !== "press" && t - n.last < 6) return true;
        n.last = t;
        if (c.mode === "once") { if (n.on) return true; setSwitch(run, a, true); }
        else if (c.mode === "timed") { n.until = t + c.time * 20; setSwitch(run, a, true); }
        else if (c.mode === "hold") setSwitch(run, a, true);
        else setSwitch(run, a, !n.on);
        propagate(run);
        return true;
    }
    function impact(run, x, y, z, how, p) {
        var a = run.byPos[pk(x, y, z)];
        if (a && a.type === "switch") return hit(run, a, how, p);
        return false;
    }
    function out(run, k) { var n = run.node[k]; return !!(n && n.on); }
    function seqStep(run, a, n, ins) {
        for (var i = 0; i < ins.length; i++) {
            var k = ins[i], cur = out(run, k), was = !!n.prev[k];
            n.prev[k] = cur;
            if (!cur || was || n.idx >= ins.length) continue;
            if (i === n.idx) { n.idx++; continue; }
            if (i < n.idx) continue;
            // out of order: everything in the sequence goes back off
            n.idx = 0;
            ins.forEach(function (j) { var s = run.byKey[j]; if (s && s.type === "switch" && s.cfg.mode !== "hold") { setSwitch(run, s, false); } n.prev[j] = false; });
            members(run).forEach(function (m) { m.playSound("minecraft:block.note_block.bass", 1, 0.5); });
            return false;
        }
        return ins.length > 0 && n.idx >= ins.length;
    }
    function propagate(run) {
        for (var pass = 0; pass < 8; pass++) {
            var changed = false;
            run.logic.forEach(function (a) {
                var n = run.node[a.key], ins = run.inputs[a.key] || [], v;
                if (a.cfg.op === "seq") v = seqStep(run, a, n, ins);
                else {
                    var cnt = 0;
                    ins.forEach(function (k) { if (out(run, k)) cnt++; });
                    v = !ins.length ? false : a.cfg.op === "and" ? cnt === ins.length : a.cfg.op === "or" ? cnt > 0 : a.cfg.op === "xor" ? cnt % 2 === 1 : cnt === 0;
                }
                if (a.cfg.latch && n.on) v = true;
                if (v !== n.on) { n.on = v; changed = true; }
            });
            if (!changed) break;
        }
        run.targets.forEach(function (a) {
            var on = (run.inputs[a.key] || []).some(function (k) { return out(run, k); });
            if (on === !!run.powered[a.key]) return;
            run.powered[a.key] = on;
            signal(run, a, on);
        });
        if (run.w) DM.wands.afterPropagate(run);
    }
    function signal(run, a, on) {
        switch (a.type) {
            case "pz_door": if (on) { if (!(run.w && DM.wands.isLocked(run, a.key))) openDoor(run, a); } else if (a.cfg.closeOff) closeDoor(run, a); break;
            case "pz_chest": if (on) appearChest(run, a); break;
            case "bridge": {
                if (on) setBridge(run, a, a.cfg.start === "hidden");
                else if (!a.cfg.latch) setBridge(run, a, a.cfg.start === "shown");
                break;
            }
            case "spawner": if (on && a.cfg.trigger === "signal") fire(run, a); break;
            case "boss": if (on && a.cfg.trigger === "signal") fireBoss(run, a); break;
        }
    }

    // ---- mobs: spawners, drops, bosses --------------------------------------------------------------------------------
    function spawnOne(run, a, entity) {
        var dx = (Math.random() - 0.5) * 2.5, dz = (Math.random() - 0.5) * 2.5, x = a.x + 0.5 + dx, y = a.y, z = a.z + 0.5 + dz, e = null;
        if (a.type === "boss") { x = a.x + 0.5; z = a.z + 0.5; }
        if (entity.indexOf("rpgmob:") === 0) e = RPG.world.spawnMob(ARENA, entity.substring(7), x, y, z);
        else if (entity.indexOf("rpgnpc:") === 0) e = RPG.world.spawnNpc(ARENA, entity.substring(7), x, y, z);
        else if (entity.indexOf("rpgboss:") === 0) {
            var mk = RPG.world.spawn(ARENA, "minecraft:armor_stand", x, y, z);
            if (mk) { try { e = mk.spawnBoss(entity.substring(8)); } catch (x0) { } mk.remove(); }
        }
        else e = RPG.world.spawn(ARENA, entity, x, y, z);
        if (!e) return null;
        e.addTag("dmk_run"); e.addTag("dmk_" + run.id);
        var c = a.cfg, st = c.stats || {};
        try { e.mergeNbt("{PersistenceRequired:1b}"); } catch (x1) { }
        if (c.nbt) { try { e.mergeNbt(c.nbt); } catch (x2) { } }
        if (st.health > 0) { e.setMaxHealth(st.health); e.health = st.health; }
        if (st.speed > 0) e.setAttributeBase("generic.movement_speed", st.speed);
        if (st.damage > 0) e.setAttributeBase("generic.attack_damage", st.damage);
        if (st.armor >= 0 && st.armor !== undefined) e.setAttributeBase("generic.armor", st.armor);
        Object.keys(c.equip || {}).forEach(function (slot) { try { e.setEquipmentStack(slot, c.equip[slot]); } catch (x3) { } });
        if (c.glow) {
            var team = "dmk_glow_" + c.glowColor;
            if (!RPG.teams.exists(team)) RPG.teams.define(team, { color: c.glowColor, friendlyFire: true });
            RPG.teams.join(e, team);
            e.setGlowing(true);
        }
        run.mobs[String(e.uuid)] = { key: a.key, x: e.x, y: e.y, z: e.z };
        run.alive[a.key] = (run.alive[a.key] | 0) + 1;
        return e;
    }
    function fire(run, a) {
        if (run.fired[a.key]) return;
        run.fired[a.key] = true;
        (a.cfg.groups || []).forEach(function (g) { for (var i = 0; i < g.count; i++) spawnOne(run, a, g.entity); });
        if (!run.alive[a.key]) { run.node[a.key].on = true; propagate(run); }
        RPG.world.particle(ARENA, "minecraft:large_smoke", a.x + 0.5, a.y + 0.6, a.z + 0.5, 30, 0.8, 0.02);
        RPG.world.sound(ARENA, "minecraft:entity.evoker.prepare_summon", a.x, a.y, a.z, 0.8, 1);
    }
    function fireBoss(run, a) {
        if (run.fired[a.key] || !a.cfg.entity) return;
        run.fired[a.key] = true;
        var c = a.cfg, e = spawnOne(run, a, c.entity);
        if (!e) { tellAll(run, "&c[Dungeons] The boss (" + c.entity + ") could not be summoned"); run.node[a.key].on = true; propagate(run); return; }
        if (c.bossName) { e.setCustomName(c.bossName.replace(/&([0-9a-fk-or])/g, "§$1")); e.setNameVisible(true); }
        var name = c.bossName ? c.bossName.replace(/&./g, "") : DM.entityName(c.entity);
        var b = run.bosses[a.key] = { uuid: String(e.uuid), name: name, bar: "dmk_" + run.id + "_" + a.key.replace(/[^0-9a-z]/gi, "_"), hasBar: c.bar && c.entity.indexOf("rpgboss:") !== 0 };
        if (b.hasBar) RPG.ui.bossBar(b.bar, { name: name, color: c.barColor, progress: 1, players: members(run) });
        if (c.lock) run.lock = { x: a.x + 0.5, y: a.y, z: a.z + 0.5, r: c.lockRadius, key: a.key };
        members(run).forEach(function (m) { m.title("&4" + name, "&7" + (c.lock ? "There is no way out!" : "A boss appears!")); m.playSound("minecraft:entity.wither.spawn", 0.5, 0.9); });
        RPG.world.particle(ARENA, "minecraft:soul_fire_flame", a.x + 0.5, a.y + 1, a.z + 0.5, 40, 1.2, 0.05);
    }
    function barsFor(run, p, on) {
        Object.keys(run.bosses).forEach(function (k) { var b = run.bosses[k]; if (b.hasBar && !b.dead) { try { if (on) RPG.ui.bossBarAdd(b.bar, p); else RPG.ui.bossBarRemove(b.bar, p); } catch (e) { } } });
    }
    function rollDrops(run, list, x, y, z, what) {
        (list || []).forEach(function (d) {
            var roll = Math.random() * 100, won = roll < d.chance, n = d.min + Math.floor(Math.random() * (d.max - d.min + 1));
            if (CFG.get("logDrops")) RPG.log("[Dungeon Maker] drop roll " + run.id + " " + what + ": " + d.item.id + " " + d.chance + "% -> " + (won ? "DROP x" + n : "no") + " (rolled " + roll.toFixed(2) + ")");
            if (!won) return;
            var st = { id: d.item.id, count: n };
            if (d.item.nbt) st.nbt = d.item.nbt;
            // keys on the ground are the run's already (the arena holds nothing else); they are marked when picked up
            RPG.world.dropItem(ARENA, x, y + 0.3, z, st);
        });
    }
    function mobDied(run, uuid, x, y, z) {
        var m = run.mobs[uuid];
        if (!m) return;
        delete run.mobs[uuid];
        var a = run.byKey[m.key];
        if (!a) return;
        rollDrops(run, a.cfg.drops, x, y, z, a.type + " " + a.key);
        run.alive[a.key] = Math.max(0, (run.alive[a.key] | 0) - 1);
        if (a.type === "boss") { bossDefeated(run, a, x, y, z); if (run.w) DM.wands.mobDied(run, a); return; }
        if (!run.alive[a.key] && !run.node[a.key].on) {
            run.node[a.key].on = true;
            if ((a.cfg.links || []).length) members(run).forEach(function (m2) { m2.playSound("minecraft:block.note_block.chime", 0.8, 1.5); });
            propagate(run);
        }
        if (run.w) DM.wands.mobDied(run, a);
    }
    function bossDefeated(run, a, x, y, z) {
        var b = run.bosses[a.key];
        if (b) { b.dead = true; if (b.hasBar) { try { RPG.ui.removeBossBar(b.bar); } catch (e) { } } }
        if (run.lock && run.lock.key === a.key) run.lock = null;
        if (a.cfg.heart) RPG.world.dropItem(ARENA, x, y + 0.5, z, T.ITEMS.container, 1);
        run.node[a.key].on = true;
        members(run).forEach(function (m) { m.title("&6Boss defeated!", "&7" + (b ? b.name : "")); m.playSound("minecraft:ui.toast.challenge_complete", 1, 0.9); });
        propagate(run);
    }
    /** Mobs that died some other way than a player's kill (fire, falls, bombs without an owner). */
    function checkMobs(run) {
        var ps = null;
        Object.keys(run.mobs).forEach(function (u) {
            var m = run.mobs[u], e = RPG.world.entityByUuid(u);
            if (e && e.isAlive() && e.health > 0) { m.x = e.x; m.y = e.y; m.z = e.z; return; }
            if (e) { mobDied(run, u, e.x, e.y, e.z); return; }
            // gone without a trace: dead if a player is close enough for its chunk to be loaded
            ps = ps || members(run);
            if (ps.some(function (p) { return Math.abs(p.x - m.x) < 64 && Math.abs(p.z - m.z) < 64; })) mobDied(run, u, m.x, m.y, m.z);
        });
        Object.keys(run.bosses).forEach(function (k) {
            var b = run.bosses[k];
            if (b.dead || !b.hasBar) return;
            var e = RPG.world.entityByUuid(b.uuid);
            if (e && e.maxHealth > 0) RPG.ui.bossBarProgress(b.bar, Math.max(0, Math.min(1, e.health / e.maxHealth)));
            members(run).forEach(function (p) { try { RPG.ui.bossBarAdd(b.bar, p); } catch (x) { } });
        });
    }

    // ---- clicks and hits on blocks in a run --------------------------------------------------------------------------------
    var CLICK = {};
    RPG.on("blockInteract", function (p, block, x, y, z, dim) {
        if (dim !== ARENA) return;
        var run = runAtBlock(x, y, z);
        if (!run) return;
        var k = pk(x, y, z), t = DM.tick(), u = DM.uid(p), last = CLICK[u];
        if (last && last.t === t && last.k === k) return last.r;       // the off hand asks again in the same tick
        var r = use(p, run, x, y, z, k);
        CLICK[u] = { t: t, k: k, r: r };
        return r;
    });
    function use(p, run, x, y, z, k) {
        if (run.w) { var pr = DM.wands.partClicked(run, p, x, y, z, "use"); if (pr !== undefined) return pr; }
        if (run.doorAt[k]) { tryDoor(p, run, run.byKey[run.doorAt[k]]); return false; }
        var a = run.byPos[k];
        if (!a) return;
        if (a.type === "switch") {
            var c = a.cfg;
            if (c.kind === "torch") {
                if (run.node[a.key].on) return false;
                if (p.getHeldItem() === T.ITEMS.lantern) hit(run, a, "light", p);
                else p.actionbar("&7It needs a flame. A Dungeon Lantern would light it.");
            } else if (c.kind === "eye") p.actionbar("&7The eye stares back... It's out of reach of your hands.");
            else if (c.kind !== "plate") hit(run, a, "use", p);
            return false;
        }
        if (DM.CHEST_TYPES[a.type]) { if (a.type !== "pz_chest" || run.appeared[a.key]) openChest(p, run, a); return false; }
        if (a.type === "spawner" && a.cfg.trigger === "click") { fire(run, a); return false; }
        if (a.type === "boss" && a.cfg.trigger === "click") { fireBoss(run, a); return false; }
        return false;
    }
    RPG.on("blockBreak", function (p, block, x, y, z, dim) {
        if (dim !== ARENA) return;
        var run = runAtBlock(x, y, z);
        if (run) {
            var k = pk(x, y, z), a = run.byPos[k];
            if (a && a.type === "switch" && (a.cfg.kind === "crystal" || a.cfg.kind === "lever")) { hit(run, a, "hit", p); return false; }
            if (run.w && run.w.partAt[k]) { DM.wands.partClicked(run, p, x, y, z, "hit"); return false; }
            if (isProtected(run, x, y, z)) return false;
            if (run.w && p.getGameMode() !== "creative" && DM.wands.noBuild(run, x, y, z)) { p.actionbar("&cNo building in this room"); return false; }
        }
        if (p.getGameMode() === "creative") return;
        if (!CFG.get("arenaBlockEditing")) return false;
    });
    RPG.on("blockPlace", function (p, block, x, y, z, dim) {
        if (dim !== ARENA) return;
        var run = runAtBlock(x, y, z);
        if (run && isProtected(run, x, y, z)) return false;
        if (run && run.w && p.getGameMode() !== "creative" && DM.wands.noBuild(run, x, y, z)) { p.actionbar("&cNo building in this room"); return false; }
        if (p.getGameMode() === "creative") return;
        if (!CFG.get("arenaBlockEditing")) return false;
    });

    // ---- goals --------------------------------------------------------------------------------------------------
    RPG.on("kill", function (p, victim) {
        if (!victim || victim.isPlayer() || victim.dimension !== ARENA) return;
        var vr = runAtBlock(Math.floor(victim.x), Math.floor(victim.y), Math.floor(victim.z)) || runOf(p);
        if (vr && vr.mobs[String(victim.uuid)]) mobDied(vr, String(victim.uuid), victim.x, victim.y, victim.z);
        var run = runOf(p);
        if (!run || run.state !== "active" || run.done) return;
        var type = victim.rpgId ? (victim.type === "ragnarok_rpg:npc" ? "rpgnpc:" : "rpgmob:") + victim.rpgId : victim.type;
        run.kills.total++;
        run.kills.by[type] = (run.kills.by[type] | 0) + 1;
        if (victim.type !== type) run.kills.by[victim.type] = (run.kills.by[victim.type] | 0) + 1;
    });
    function updateGoals(run) {
        var ps = members(run);
        run.goals.forEach(function (g) {
            var o = g.o;
            if (o.type === "kill_count") g.cur = Math.min(g.max, run.kills.total);
            else if (o.type === "kill_entity") g.cur = Math.min(g.max, run.kills.by[o.entity] | 0);
            else if (o.type === "obtain_item" && o.item) {
                var best = 0;
                ps.forEach(function (m) { best = Math.max(best, m.countItem(o.item.id)); });
                g.cur = Math.min(g.max, best);
            }
            else if (DM.wands && (o.type === "puzzle" || o.type === "room_clear" || o.type === "room_enter")) g.cur = DM.wands.goal(run, o);
            if (!g.done && g.cur >= g.max) {
                g.done = true;
                ps.forEach(function (m) { m.playSound("minecraft:entity.experience_orb.pickup", 0.8, 1.2); });
                if (o.rewards && o.rewards.length && DM.wands && ps.length) {
                    DM.wands.reward(run, o.rewards, { x: Math.floor(ps[0].x), y: Math.floor(ps[0].y) - 1, z: Math.floor(ps[0].z) });
                    ps.forEach(function (m) { m.tell("&6[Dungeons] &eGoal reward: &f" + o.rewards.map(function (r) { return DM.wands.rewardText(r, DM.anchors(run.def)); }).join(", ")); });
                }
            }
        });
        return run.goals.every(function (g) { return g.done; });
    }

    // ---- the puzzle loop (every 2 ticks, runs with switches, doors moving or a boss lock) ----------------------------------------
    RPG.every(2, function () {
        for (var id in RUNS) {
            var run = RUNS[id];
            if (run.state !== "active") continue;
            if (run.anims.length) stepAnims(run);
            if (!run.puzzle && !run.lock) continue;
            var ps = members(run), t = DM.tick(), changed = false;
            if (run.puzzle) {
                run.anchors.forEach(function (a) {
                    if (a.type !== "switch") return;
                    var n = run.node[a.key];
                    if (a.cfg.kind === "plate") {
                        var pressed = RPG.world.getBlock(ARENA, a.x, a.y + 1, a.z) === T.BLOCKS.push || ps.some(function (m) {
                            return Math.floor(m.x) === a.x && Math.floor(m.z) === a.z && m.y >= a.y + 0.9 && m.y < a.y + 1.6;
                        });
                        if (pressed && !n.pressed) { n.pressed = true; if (!n.on || a.cfg.mode === "toggle") { hit(run, a, "press"); changed = true; } }
                        else if (!pressed && n.pressed) {
                            n.pressed = false;
                            if (a.cfg.mode === "hold") { setSwitch(run, a, false); changed = true; }
                        }
                    }
                    if (n.until && t >= n.until) { setSwitch(run, a, false); changed = true; }
                });
                if (changed) propagate(run);
            }
            if (run.lock) {
                var L = run.lock;
                ps.forEach(function (m) {
                    var dx = m.x - L.x, dz = m.z - L.z, d = Math.sqrt(dx * dx + dz * dz);
                    if (d <= L.r || d > L.r + 8 || Math.abs(m.y - L.y) > 16) return;
                    var k = (L.r - 1.2) / d;
                    m.teleport(L.x + dx * k, m.y, L.z + dz * k);
                    m.actionbar("&cThe way out is sealed until the boss falls!");
                    if (t % 10 === 0) for (var i = 0; i < 16; i++) { var an = Math.atan2(dz, dx) + (i - 8) * 0.06; RPG.world.particle(ARENA, "minecraft:soul_fire_flame", L.x + Math.cos(an) * L.r, m.y + 1, L.z + Math.sin(an) * L.r, 1, 0.1, 0); }
                });
            }
        }
    });

    // ---- the run loop (every 10 ticks) ---------------------------------------------------------------------------------
    var loop = 0;
    RPG.every(10, function () {
        loop++;
        Object.keys(RUNS).forEach(function (k) {
            var run = RUNS[k];
            if (!run || run.state !== "active") return;
            var t = DM.tick(), ps = members(run);
            // nobody here (everyone offline): close it after a while
            if (!ps.length) {
                if (!run.emptySince) run.emptySince = t;
                if (t - run.emptySince > CFG.get("emptyRunSeconds") * 20 && !run.members.some(function (u) { var m = DM.online(u); return m && m.dimension === ARENA; })) dispose(run);
                return;
            }
            run.emptySince = 0;
            // keys only ever belong to this run
            ps.forEach(function (m) { T.stripKeys(m, run.id); });
            if (run.done) {
                var left = Math.ceil((run.exitAt - t) / 20);
                if (left > 0) { if (!run.failed) ps.forEach(function (m) { m.actionbar("&eLeaving the dungeon in " + left + "..."); }); if (loop % 2 === 0) hud(run); }
                else dispose(run);
                return;
            }
            if (run.endsAt && t >= run.endsAt) { timeUp(run); return; }
            checkMobs(run);
            if (run.w) DM.wands.tick(run, ps);
            markSeen(run, ps);
            ps.forEach(function (m) { if (holding(m, T.ITEMS.compass)) compass(m, false); });
            // spawners and bosses
            run.anchors.forEach(function (a) {
                if ((a.type !== "spawner" && a.type !== "boss") || run.fired[a.key]) return;
                if (a.cfg.trigger === "radius") {
                    var r2 = a.cfg.radius * a.cfg.radius;
                    if (ps.some(function (m) { var dx = m.x - a.x - 0.5, dy = m.y - a.y, dz = m.z - a.z - 0.5; return dx * dx + dy * dy + dz * dz <= r2; })) { if (a.type === "boss") fireBoss(run, a); else fire(run, a); }
                } else if (a.type === "spawner" && a.cfg.trigger === "redstone" && RPG.world.redstonePower(ARENA, a.x, a.y, a.z) > 0) fire(run, a);
            });
            var allDone = updateGoals(run);
            if (allDone) {
                if (!run.hasExit) complete(run);
                else {
                    if (!run.toldExit) { run.toldExit = true; if (run.goals.length) tellAll(run, "&a[Dungeons] Every goal is done! Head to the exit."); }
                    run.anchors.forEach(function (a) {
                        if (a.type !== "exit") return;
                        if (loop % 2 === 0) RPG.world.particle(ARENA, "minecraft:happy_villager", a.x + 0.5, a.y + 0.6, a.z + 0.5, 12, a.cfg.radius * 0.4, 0);
                        var r2 = a.cfg.radius * a.cfg.radius;
                        if (ps.some(function (m) { var dx = m.x - a.x - 0.5, dy = m.y - a.y, dz = m.z - a.z - 0.5; return dx * dx + dy * dy + dz * dz <= r2; })) complete(run);
                    });
                }
            } else if (run.hasExit) {
                run.anchors.forEach(function (a) {
                    if (a.type !== "exit") return;
                    var r2 = a.cfg.radius * a.cfg.radius;
                    ps.forEach(function (m) {
                        var dx = m.x - a.x - 0.5, dy = m.y - a.y, dz = m.z - a.z - 0.5;
                        if (dx * dx + dy * dy + dz * dz <= r2 && loop % 4 === 0) m.actionbar("&cFinish every goal first");
                    });
                });
            }
            if (loop % 2 === 0) hud(run);
        });
    });

    function hud(run) {
        var t = DM.tick(), d = DM.def(run.def), ps = members(run);
        var data = { name: run.name, state: run.done ? (run.failed ? "failed" : "done") : run.state,
            left: run.endsAt ? Math.max(0, Math.ceil((run.endsAt - t) / 20)) : -1, elapsed: Math.floor((t - run.started) / 20),
            goals: (run.goals || []).map(function (g) { return { text: DM.objectiveText(g.o), cur: g.cur, max: g.max, done: g.done }; }),
            exit: !!run.hasExit, difficulty: d ? d.difficulty | 0 : 0,
            keys: T.keyCount(ps, run.id, T.ITEMS.small_key), bossKey: T.keyCount(ps, run.id, T.ITEMS.boss_key) > 0 };
        ps.forEach(function (m) { RPG.net.send(m, "dmk_hud", data); });
    }
    // ---- the Dungeon Compass and the Dungeon Map ------------------------------------------------------------
    function holding(p, id) { return p.getHeldItem() === id || p.getEquipped("offhand") === id; }
    function partyHas(run, id) { return members(run).some(function (m) { return T.keyCount([m], run.id, id) > 0; }); }
    /** Where the compass points: the boss until it falls, then the next puzzle / room goal, then the exit. */
    function compassTarget(run) {
        var t = null, o = run.origin;
        run.anchors.forEach(function (a) { if (!t && a.type === "boss" && !(run.bosses[a.key] && run.bosses[a.key].dead) && !run.node[a.key].on) t = { x: a.x + 0.5, y: a.y, z: a.z + 0.5, label: "Boss" }; });
        if (!t && run.w) (run.goals || []).forEach(function (g) {
            if (t || g.done) return;
            if (g.o.type === "puzzle" && run.w.puzzles[g.o.puzzle]) { var wz = run.w.puzzles[g.o.puzzle], q = wz.parts[0] || (wz.z.node ? { x: o.x + wz.z.node[0], y: o.y + wz.z.node[1], z: o.z + wz.z.node[2] } : null); if (q) t = { x: q.x + 0.5, y: q.y, z: q.z + 0.5, label: wz.z.name }; }
            else if ((g.o.type === "room_clear" || g.o.type === "room_enter") && run.w.rooms[g.o.room]) { var b = run.w.rooms[g.o.room].box; t = { x: (b.x1 + b.x2 + 1) / 2, y: b.y1 + 1, z: (b.z1 + b.z2 + 1) / 2, label: run.w.rooms[g.o.room].r.name }; }
        });
        if (!t) run.anchors.forEach(function (a) { if (!t && a.type === "exit") t = { x: a.x + 0.5, y: a.y, z: a.z + 0.5, label: "Exit" }; });
        return t;
    }
    var ARROWS = ["↑", "↗", "→", "↘", "↓", "↙", "←", "↖"];
    function compass(p, loud) {
        var run = runOf(p);
        if (!run || run.state !== "active") return;
        var t = compassTarget(run);
        if (!t) { p.actionbar("&7The needle spins: nothing to find"); return; }
        var dx = t.x - p.x, dz = t.z - p.z, dy = Math.round(t.y - p.y), dist = Math.round(Math.sqrt(dx * dx + dz * dz));
        var rel = ((Math.atan2(-dx, dz) * 180 / Math.PI - p.yaw) % 360 + 540) % 360 - 180;
        var arrow = dist < 2 ? "●" : ARROWS[(Math.round(rel / 45) + 8) % 8];
        p.actionbar("&c" + arrow + " &f" + t.label + " &7" + dist + " blocks" + (dy > 2 ? " (" + dy + " up)" : dy < -2 ? " (" + (-dy) + " down)" : ""));
        if (loud) { p.playSound("minecraft:item.lodestone_compass.lock", 0.7, 1.3); RPG.world.particleLine(ARENA, "minecraft:enchanted_hit", p.x, p.y + 1, p.z, p.x + dx / Math.max(1, dist) * 4, p.y + 1, p.z + dz / Math.max(1, dist) * 4, 0.4); }
    }
    /** The map's cells 4 x 4 at a time: which ones the party has walked over (every 10 ticks, only runs with a painted map). */
    var SEEN = 4;
    function markSeen(run, ps) {
        var mi = run.mapInfo;
        if (!mi) return;
        ps.forEach(function (m) { run.seen[Math.floor((Math.floor(m.x) - run.origin.x - mi.ox) / SEEN) + "," + Math.floor((Math.floor(m.z) - run.origin.z - mi.oz) / SEEN)] = 1; });
    }
    function openMap(p) {
        var run = runOf(p);
        if (!run || run.state !== "active") return;
        var map = DM.paint ? DM.paint.get(run.def) : null, L = DM.wands ? DM.wands.get(run.def) : null, o = run.origin, wc = run.w;
        var hasCompass = partyHas(run, T.ITEMS.compass);
        var out = { name: run.name, seenSize: SEEN, compass: hasCompass, markers: [], rooms: [] };
        if (map) out.map = { w: map.w, h: map.h, ox: map.ox, oz: map.oz, theme: map.theme, floors: map.floors.map(function (f) { return { name: f.name, y: f.y, height: f.height, cells: f.cells }; }) };
        if (L) Object.keys(L.rooms).forEach(function (k) { var r = L.rooms[k]; out.rooms.push({ name: r.name, type: r.type, box: DM.wands.roomBox(r), seen: !!(wc && wc.rooms[k] && wc.rooms[k].ev.enter) }); });
        if (L && L.bounds) out.bounds = DM.wands.boundsRel(run.def);
        run.anchors.forEach(function (a) {
            var show = a.type === "entry" || a.type === "exit" || (hasCompass && (a.type === "boss" || DM.CHEST_TYPES[a.type]));
            if (show) out.markers.push({ type: a.type, x: a.x - o.x, y: a.y - o.y, z: a.z - o.z, open: !!run.loot[a.key] });
        });
        DM.sendBig(p, "runmap", out);
        mapPos(p);
        p.playSound("minecraft:ui.cartography_table.take_result", 0.6, 1.1);
    }
    /** The live part (where everyone is, what has been seen), asked about once a second while the map is open. */
    function mapPos(p) {
        var run = runOf(p);
        if (!run) { RPG.net.send(p, "dmk_mappos", null); return; }
        var o = run.origin;
        RPG.net.send(p, "dmk_mappos", { seen: Object.keys(run.seen), me: [p.x - o.x, p.y - o.y, p.z - o.z, p.yaw],
            party: members(run).filter(function (m) { return m !== p; }).map(function (m) { return [m.x - o.x, m.y - o.y, m.z - o.z, m.name]; }) });
    }
    RPG.net.on("dmk_run", function (p, m) { if (m && m.op === "mappos" && runOf(p)) mapPos(p); });

    function keysChanged(p) { var run = runOf(p); if (run) { T.stripKeys(p, run.id); hud(run); } }

    // ---- players coming and going ------------------------------------------------------------------------------
    RPG.on("playerJoin", function (p) {
        RPG.schedule(20, function () {
            var run = runOf(p);
            if (p.dimension === ARENA && (!run || run.state !== "active")) { if (run) leave(p, true); else goHome(p); p.tell("&7[Dungeons] Your dungeon run has ended, you were sent back."); }
            else if (run) barsFor(run, p, true);
            DM.sendPlotOutline(p);
        });
    });
    RPG.on("death", function (p) { var run = runOf(p); if (run) run.deaths = (run.deaths | 0) + 1; });
    RPG.on("respawn", function (p) {
        var run = runOf(p);
        if (!run) return;
        if (CFG.get("respawnInside") && run.state === "active" && !run.done) {
            RPG.schedule(2, function () {
                if (!RUNS[run.id]) return;
                var s = (run.w && DM.wands.respawnFor(run, p)) || run.spawn;      // a parkour checkpoint, else the entry
                p.teleportTo(ARENA, s.x, s.y, s.z, s.yaw || 0, 0);
            });
        } else {
            delete BY_PLAYER[DM.uid(p)];
            run.members = run.members.filter(function (u) { return u !== DM.uid(p); });
            barsFor(run, p, false);
            T.stripKeys(p, null);
            RPG.net.send(p, "dmk_hud", null);
            if (!run.members.length) dispose(run);
        }
    });
    // walking out of the arena some other way (commands, portals) counts as leaving
    RPG.on("playerTick", function (p) {
        var run = runOf(p);
        if (run && run.state === "active" && p.dimension !== ARENA && p.isAlive()) {
            delete BY_PLAYER[DM.uid(p)];
            run.members = run.members.filter(function (u) { return u !== DM.uid(p); });
            barsFor(run, p, false);
            RPG.net.send(p, "dmk_hud", null);
            if (!run.members.length) dispose(run);
        }
        // run keys never leave the arena (staff may keep them in the workshop to fill chests)
        if (p.dimension !== ARENA && p.dimension !== WORKSHOP) T.stripKeys(p, null);
        if (p.dimension === WORKSHOP) {
            var n = DM.plotAt(p.x, p.z);
            if (p.getVar("dmk_lastplot", -1) !== n) { p.setVar("dmk_lastplot", n); DM.sendPlotOutline(p); }
        } else if (p.getVar("dmk_lastplot", -1) !== -1) { p.setVar("dmk_lastplot", -1); RPG.net.send(p, "dmk_plot", null); }
    });

    // ---- arena rules: no PvP unless allowed (building: see blockBreak / blockPlace above) --------------------------------------
    RPG.on("attack", function (e) {
        if (CFG.get("arenaPvp") || !e.target || !e.target.isPlayer() || !e.attacker || !e.attacker.isPlayer()) return;
        if (e.target.dimension === ARENA) e.cancel();
    });

    return {
        start: start, leave: leave, runOf: runOf, compass: compass, openMap: openMap, useAnchor: useAnchor, checkEntry: checkEntry,
        runAtBlock: runAtBlock, inBox: inBox, isProtected: isProtected, impact: impact, keysChanged: keysChanged,
        list: function () { return Object.keys(RUNS).map(function (k) { var r = RUNS[k]; return { id: r.id, def: r.def, name: r.name, slot: r.slot, members: r.members.length, state: r.state }; }); },
        stop: function (id) { var r = RUNS[id]; if (r) dispose(r); return !!r; },
        // for the wands (35_dungeon_maker_wands.js): the run internals they drive
        _: { all: function () { return RUNS; }, propagate: propagate, openDoor: openDoor, closeDoor: closeDoor, chestBlock: chestBlock, fire: fire, members: members, rollLoot: rollLoot }
    };
})();
