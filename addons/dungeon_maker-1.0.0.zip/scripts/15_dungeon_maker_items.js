// =====================================================================================
//  Dungeon Maker - dungeon items and blocks: keys, hearts, the puzzle tools, building blocks
// =====================================================================================
//  Items (art: dungeonpack):
//   - Small Key / Boss Key: found in a run (chests, mob drops). They belong to that run only:
//     each one remembers its run, keys from anywhere else vanish, and leaving the run takes them.
//     A party shares them: a locked door or chest takes a Small Key from whoever clicks it, else
//     from any other member of the run; the Boss Key opens the boss door and the big chest and
//     is never used up. The tracker shows how many the party holds.
//   - Recovery Heart (picked up = heals, recoveryHeartPercent of max health) and Heart Container
//     (heals fully, plus heartContainerBonus max health for good when that is above 0).
//   - Puzzle tools, which only work inside dungeon runs:
//       Dungeon Bow       right-click: an arrow; hits Crystal Switches and Eye Switches
//       Bomb              right-click: thrown, blows up after 2.5 s; breaks Cracked Dungeon Bricks
//       Grapple Claw      right-click: hooks a Grapple Target up to 18 blocks away and pulls you there
//       Dungeon Lantern   right-click an unlit torch switch to light it
//  Blocks staff build with (they behave only inside runs):
//   - Cracked Dungeon Bricks (bombs break them), Grapple Target, Push Block (right-click to shove
//     it one block; it slides off ledges and presses floor switches).
//  Blocks only runs place: Floor Switch, Crystal Switch, Eye Switch (raised/lowered, lit/unlit...),
//  Locked Chest and Big Chest.
// =====================================================================================
DungeonMaker.tools = (function () {
    var DM = DungeonMaker, CFG = DM.CFG, ARENA = DM.ARENA, WORKSHOP = DM.WORKSHOP;
    var NS = "ragnarok_rpg:";
    function M(n) { return "dungeonpack:rpg/item/" + n; }
    function B(n) { return "dungeonpack:rpg/block/" + n; }
    function inRun(p) { return p.dimension === ARENA && DM.runs && DM.runs.runOf(p); }
    function onlyInRuns(p) {
        if (inRun(p)) return true;
        p.actionbar("&7This only works inside a dungeon run");
        return false;
    }
    function look(p) {
        var yaw = p.yaw * Math.PI / 180, pitch = p.pitch * Math.PI / 180;
        return { x: -Math.sin(yaw) * Math.cos(pitch), y: -Math.sin(pitch), z: Math.cos(yaw) * Math.cos(pitch) };
    }
    function cooldown(p, key, ticks) {
        var t = DM.tick(), last = p.getVar(key, -1000) | 0;
        if (t - last < ticks && t >= last) return false;
        p.setVar(key, t);
        return true;
    }

    // ---- items ---------------------------------------------------------------------------------------
    var I = {};
    // art in the addon's own resources (assets/dungeon_maker): the small key, compass, map, wands and 2-tall doors
    function A(n) { return "dungeon_maker:rpg/item/" + n; }
    I.small_key = NS + RPG.items.define("dmk_small_key", { name: "&fSmall Key", model: A("small_key"), maxStack: 16, rarity: "uncommon", tab: "Dungeon Maker",
        lore: ["&7Opens one locked door or chest", "&7in the dungeon it was found in.", "&8Shared by your party; gone when you leave."] });
    I.boss_key = NS + RPG.items.define("dmk_boss_key", { name: "&6Boss Key", model: M("boss_key"), maxStack: 1, rarity: "epic", tab: "Dungeon Maker",
        lore: ["&7Opens the boss door and the big chest", "&7of the dungeon it was found in.", "&8Shared by your party; gone when you leave."] });
    I.heart = NS + RPG.items.define("dmk_recovery_heart", { name: "&cRecovery Heart", model: M("recovery_heart"), maxStack: 64, tab: "Dungeon Maker",
        lore: ["&7Heals you when picked up."], onUse: function (p) { useHeart(p, 1); return false; } });
    I.container = NS + RPG.items.define("dmk_heart_container", { name: "&cHeart Container", model: M("heart_container"), maxStack: 16, rarity: "rare", tab: "Dungeon Maker",
        lore: ["&7Heals you fully when picked up."], onUse: function (p) { useContainer(p); return false; } });
    I.bomb = NS + RPG.items.define("dmk_bomb", { name: "&fBomb", model: M("bomb"), maxStack: 16, type: "tool", tab: "Dungeon Maker",
        lore: ["&7Right-click to throw. Blows up after a moment,", "&7breaking cracked walls. &8Dungeons only."], onUse: function (p) { throwBomb(p); return false; } });
    I.bow = NS + RPG.items.define("dmk_bow", { name: "&fDungeon Bow", model: M("bow"), maxStack: 1, type: "tool", tab: "Dungeon Maker",
        lore: ["&7Right-click to shoot. Hits crystal and", "&7eye switches from afar. &8Dungeons only."], onUse: function (p) { shoot(p); return false; } });
    I.grapple = NS + RPG.items.define("dmk_grapple", { name: "&fGrapple Claw", model: M("grapple"), maxStack: 1, type: "tool", tab: "Dungeon Maker",
        lore: ["&7Right-click a Grapple Target to be", "&7pulled across. &8Dungeons only."], onUse: function (p) { grapple(p); return false; } });
    I.lantern = NS + RPG.items.define("dmk_lantern", { name: "&fDungeon Lantern", model: M("lantern"), maxStack: 1, type: "tool", tab: "Dungeon Maker",
        lore: ["&7Right-click an unlit torch to light it.", "&8Dungeons only."], onUse: function (p) { if (onlyInRuns(p)) p.actionbar("&7Hold it and right-click an unlit torch"); return false; } });
    // run items like the keys: found in a run (chests, drops), shared by nobody, gone when the run ends
    I.compass = NS + RPG.items.define("dmk_compass", { name: "&cDungeon Compass", model: A("compass"), maxStack: 1, rarity: "rare", tab: "Dungeon Maker",
        lore: ["&7Held: points the way to the boss,", "&7then to the next goal, then the exit.", "&7Shows the boss and chests on the map.", "&8Belongs to the dungeon it was found in."],
        onUse: function (p) { if (onlyInRuns(p) && DM.runs) DM.runs.compass(p, true); return false; } });
    I.map = NS + RPG.items.define("dmk_map", { name: "&6Dungeon Map", model: A("map"), maxStack: 1, rarity: "rare", tab: "Dungeon Maker",
        lore: ["&7Right-click: the dungeon's layout.", "&7Rooms show once you have been there.", "&8Belongs to the dungeon it was found in."],
        onUse: function (p) { if (onlyInRuns(p) && DM.runs) DM.runs.openMap(p); return false; } });

    // ---- blocks -----------------------------------------------------------------------------------------
    var K = {};
    function block(name, def) { def.drops = def.drops || "none"; K[name] = NS + RPG.blocks.define("dmk_" + name, def); return K[name]; }
    block("cracked", { name: "&7Cracked Dungeon Bricks", model: B("cracked"), hardness: 2, drops: "self" });
    block("grapple_target", { name: "&eGrapple Target", model: B("grapple_target"), hardness: 2, drops: "self", sound: "wood" });
    block("push", { name: "&7Push Block", model: B("push_block"), hardness: 2, drops: "self" });
    block("plate_up", { name: "&eFloor Switch", model: B("plate_up"), hardness: -1 });
    block("plate_down", { name: "&eFloor Switch (pressed)", model: B("plate_down"), hardness: -1 });
    block("crystal_off", { name: "&bCrystal Switch", model: B("crystal_off"), hardness: 0, light: 6, shape: [3, 0, 3, 13, 15, 13], sound: "amethyst_cluster" });
    block("crystal_on", { name: "&6Crystal Switch (on)", model: B("crystal_on"), hardness: 0, light: 10, shape: [3, 0, 3, 13, 15, 13], sound: "amethyst_cluster" });
    block("eye_shut", { name: "&eEye Switch", model: B("eye_shut"), hardness: -1 });
    block("eye_open", { name: "&eEye Switch (open)", model: B("eye_open"), hardness: -1, light: 5 });
    block("chest_locked", { name: "&7Locked Chest", model: B("chest_locked"), hardness: -1, shape: [1, 0, 1, 15, 14, 15], rotation: "horizontal", sound: "wood" });
    block("chest_big", { name: "&6Big Chest", model: B("chest_big"), hardness: -1, shape: [0, 0, 0, 16, 15, 16], rotation: "horizontal", sound: "wood" });
    // 2-block-tall doors (Small Key Door, Boss Door): staff place the lower half, the upper half comes with it; in a
    // run they are door blocks like any other (a door module's zone takes both halves)
    function tallDoor(name, title, tex) {
        var top = block(name + "_top", { name: title + " (top)", model: "dungeon_maker:rpg/block/" + tex + "_top", hardness: 3, sound: "metal",
            onBreak: function (p, x, y, z) { if (RPG.world.getBlock(p.dimension, x, y - 1, z) === K[name]) RPG.world.setBlock(p.dimension, x, y - 1, z, "minecraft:air"); } });
        block(name, { name: title, model: "dungeon_maker:rpg/block/" + tex + "_bottom", hardness: 3, sound: "metal", drops: "self",
            onPlace: function (p, x, y, z) {
                var up = RPG.world.getBlock(p.dimension, x, y + 1, z);
                if (up === "minecraft:air" || up === "minecraft:cave_air") RPG.world.setBlock(p.dimension, x, y + 1, z, top);
            },
            onBreak: function (p, x, y, z) { if (RPG.world.getBlock(p.dimension, x, y + 1, z) === top) RPG.world.setBlock(p.dimension, x, y + 1, z, "minecraft:air"); } });
    }
    tallDoor("door_small", "&7Small Key Door", "small_key_door");
    tallDoor("door_boss", "&cBoss Door", "boss_door");
    function giveBlocks(p) { p.giveItem("dmk_cracked", 16); p.giveItem("dmk_grapple_target", 2); p.giveItem("dmk_push", 2); p.giveItem("dmk_door_small", 2); p.giveItem("dmk_door_boss", 1); }
    /** Every dungeon item, for staff testing (/dungeons kit). */
    function giveKit(p) {
        p.giveItem("dmk_bow", 1); p.giveItem("dmk_bomb", 16); p.giveItem("dmk_grapple", 1); p.giveItem("dmk_lantern", 1);
        p.giveItem("dmk_small_key", 4); p.giveItem("dmk_boss_key", 1); p.giveItem("dmk_compass", 1); p.giveItem("dmk_map", 1); p.giveItem("dmk_recovery_heart", 4); p.giveItem("dmk_heart_container", 1);
    }

    // ---- run keys ------------------------------------------------------------------------------------------
    function isRunKey(id) { return id === I.small_key || id === I.boss_key || id === I.compass || id === I.map; }
    function runOfStack(s) { return s && s.data && s.data.dmk_run ? String(s.data.dmk_run) : ""; }
    /** The same stack marked as belonging to a run (keys only; anything else comes back as it was). */
    function stamp(stack, runId) {
        if (!stack || !isRunKey(stack.id)) return stack;
        var s = JSON.parse(JSON.stringify(stack));
        s.data = s.data || {}; s.data.dmk_run = runId;
        delete s.nbt;
        return s;
    }
    /** Removes keys not of runId (all keys when runId is null); unmarked keys inside a run become that run's. */
    function stripKeys(p, runId) {
        if (p.countItem(I.small_key) <= 0 && p.countItem(I.boss_key) <= 0) return;
        for (var i = 0; i < 41; i++) {
            var s = p.getStack(i);
            if (!s || !isRunKey(s.id)) continue;
            var r = runOfStack(s);
            if (runId && !r) p.setStack(i, stamp(s, runId));
            else if (!runId || r !== runId) p.setStack(i, null);
        }
    }
    function keyCount(players, runId, id) {
        var n = 0;
        players.forEach(function (p) {
            if (p.countItem(id) <= 0) return;
            for (var i = 0; i < 41; i++) { var s = p.getStack(i); if (s && s.id === id && runOfStack(s) === runId) n += s.count || 1; }
        });
        return n;
    }
    /** Uses one Small Key: the clicking player's first, then any other member's. */
    function takeKey(players, runId, id) {
        for (var k = 0; k < players.length; k++) {
            var p = players[k];
            if (p.countItem(id) <= 0) continue;
            for (var i = 0; i < 41; i++) {
                var s = p.getStack(i);
                if (!s || s.id !== id || runOfStack(s) !== runId) continue;
                if ((s.count || 1) > 1) { s.count = (s.count || 1) - 1; p.setStack(i, s); } else p.setStack(i, null);
                return p;
            }
        }
        return null;
    }

    // ---- hearts ------------------------------------------------------------------------------------------------
    function useHeart(p, n) {
        DM.hooks.heal(p, CFG.get("recoveryHeartPercent") / 100 * n);
        p.playSound("minecraft:entity.experience_orb.pickup", 0.7, 1.6);
        RPG.world.particle(p.dimension, "minecraft:heart", p.x, p.y + 1.2, p.z, 3 + n, 0.4, 0);
    }
    function useContainer(p) {
        var bonus = CFG.get("heartContainerBonus");
        if (bonus > 0) { try { DM.hooks.addMaxHealth(p, bonus); } catch (e) { } }
        DM.hooks.heal(p, 1);
        p.title("&cHeart Container!", bonus > 0 ? "&7Your life grows" : "&7Fully healed");
        p.playSound("minecraft:ui.toast.challenge_complete", 0.7, 1.4);
        RPG.world.particle(p.dimension, "minecraft:heart", p.x, p.y + 1.2, p.z, 12, 0.6, 0);
    }
    // picked-up hearts are used at once; keys found in a run are marked as that run's
    RPG.on("itemPickup", function (p, stack) {
        if (!stack) return;
        if (stack.id === I.heart || stack.id === I.container) {
            RPG.schedule(1, function () {
                var h = p.countItem(I.heart), c = p.countItem(I.container);
                if (h > 0) { p.takeItem(I.heart, h); useHeart(p, h); }
                if (c > 0) { p.takeItem(I.container, c); for (var i = 0; i < c; i++) useContainer(p); }
            });
        } else if (isRunKey(stack.id)) {
            var run = DM.runs && DM.runs.runOf(p);
            if (!run || p.dimension !== ARENA) { if (p.dimension !== WORKSHOP) return false; return; }
            if (runOfStack(stack) && runOfStack(stack) !== run.id) return false;
            RPG.schedule(1, function () { if (DM.runs) DM.runs.keysChanged(p); });
            p.title(" ", stack.id === I.boss_key ? "&6You got the Boss Key!" : stack.id === I.compass ? "&cYou got the Compass!" : stack.id === I.map ? "&6You got the Dungeon Map!" : "&fYou got a Small Key!");
            p.playSound("minecraft:entity.player.levelup", 0.6, 1.8);
        }
    });

    // ---- the bow --------------------------------------------------------------------------------------------------
    function uuidInts(u) {
        var h = String(u).replace(/-/g, ""), out = [];
        for (var i = 0; i < 4; i++) out.push(parseInt(h.substring(i * 8, i * 8 + 8), 16) | 0);
        return out;
    }
    function shoot(p) {
        if (!onlyInRuns(p) || !cooldown(p, "dmk_cd_bow", 12)) return;
        var d = look(p), ray = p.raycast(48, { blocks: true, entities: true });
        var ex = p.x + d.x * 0.4, ey = p.eyeY - 0.1, ez = p.z + d.z * 0.4;
        var a = RPG.world.spawn(ARENA, "minecraft:arrow", ex, ey, ez);
        if (a) {
            var id = uuidInts(p.uuid);
            try { a.mergeNbt("{pickup:0b,damage:3.0d,Owner:[I;" + id.join(",") + "]}"); } catch (e) { }
            a.setVelocity(d.x * 3, d.y * 3, d.z * 3);
            RPG.schedule(80, function () { try { a.remove(); } catch (e) { } });
        }
        p.playSound("minecraft:entity.arrow.shoot", 0.8, 1.1);
        if (ray && ray.hit === "block") {
            var bx = ray.blockX, by = ray.blockY, bz = ray.blockZ, delay = Math.max(1, Math.ceil((ray.distance || 1) / 3));
            RPG.schedule(delay, function () {
                var run = DM.runs && DM.runs.runAtBlock(bx, by, bz);
                if (run) DM.runs.impact(run, bx, by, bz, "arrow", p);
            });
        }
    }

    // ---- bombs ------------------------------------------------------------------------------------------------------
    var FUSE = 50, BOMBS = {};
    RPG.props.define("dmk_bomb", {
        item: "dmk_bomb", size: 0.45, bounce: 0.25, friction: 0.7, pushable: true, gravity: 0.05, lifetime: FUSE + 40,
        onBounce: function (prop) { RPG.world.sound(prop.dimension, "minecraft:block.stone.hit", prop.x, prop.y, prop.z, 0.5, 1.4); },
        onTick: function (prop) {
            var f = BOMBS[prop.uuid];
            if (!f) return;
            var t = DM.tick();
            if ((t - f.at) % 4 === 0) RPG.world.particle(prop.dimension, t >= f.at + FUSE - 15 ? "minecraft:flame" : "minecraft:smoke", prop.x, prop.y + 0.45, prop.z, 1, 0.02, 0.01);
            if (t < f.at + FUSE) return;
            delete BOMBS[prop.uuid];
            var x = prop.x, y = prop.y + 0.2, z = prop.z;
            prop.remove();
            blast(x, y, z, f.owner);
        }
    });
    function throwBomb(p) {
        if (!onlyInRuns(p) || !cooldown(p, "dmk_cd_bomb", 15)) return;
        if (p.getGameMode() !== "creative" && !p.takeItem(I.bomb, 1)) return;
        var d = look(p), g = RPG.world.spawnProp(ARENA, "dmk_bomb", p.x + d.x * 0.6, p.eyeY - 0.3, p.z + d.z * 0.6);
        if (!g) return;
        g.setVelocity(d.x * 0.6, d.y * 0.6 + 0.2, d.z * 0.6);
        BOMBS[g.uuid] = { at: DM.tick(), owner: String(p.uuid) };
        p.playSound("minecraft:entity.tnt.primed", 0.6, 1.5);
    }
    function blast(x, y, z, ownerUuid) {
        var owner = null;
        RPG.server.players().forEach(function (q) { if (String(q.uuid) === ownerUuid) owner = q; });
        RPG.world.particle(ARENA, "minecraft:explosion", x, y, z, 4, 1.0, 0);
        RPG.world.particle(ARENA, "minecraft:large_smoke", x, y, z, 20, 1.2, 0.05);
        RPG.world.sound(ARENA, "minecraft:entity.generic.explode", x, y, z, 1.2, 1.1);
        var dmg = CFG.get("bombDamage");
        RPG.world.entitiesNear(ARENA, x, y, z, 3.5).forEach(function (e) {
            if (!e.isAlive()) return;
            var dx = e.x - x, dz = e.z - z, l = Math.max(0.3, Math.sqrt(dx * dx + dz * dz));
            if (e.isPlayer()) { e.damage(2); e.push(dx / l * 0.6, 0.35, dz / l * 0.6); }
            else { e.damageFrom(dmg, owner); e.push(dx / l * 0.5, 0.3, dz / l * 0.5); }
        });
        // cracked bricks within 2.5 blocks break (inside runs only)
        var run = DM.runs && DM.runs.runAtBlock(Math.floor(x), Math.floor(y), Math.floor(z)), n = 0;
        if (!run) return;
        var bx = Math.floor(x), by = Math.floor(y), bz = Math.floor(z);
        for (var i = -3; i <= 3; i++) for (var j = -3; j <= 3; j++) for (var k = -3; k <= 3; k++) {
            if (i * i + j * j + k * k > 7) continue;
            if (RPG.world.getBlock(ARENA, bx + i, by + j, bz + k) !== K.cracked || !DM.runs.inBox(run, bx + i, by + j, bz + k)) continue;
            RPG.world.setBlock(ARENA, bx + i, by + j, bz + k, "minecraft:air");
            RPG.world.particle(ARENA, "minecraft:poof", bx + i + 0.5, by + j + 0.5, bz + k + 0.5, 6, 0.4, 0.02);
            n++;
        }
        if (n) { RPG.world.sound(ARENA, "minecraft:block.stone.break", x, y, z, 1, 0.7); RPG.world.sound(ARENA, "minecraft:block.note_block.chime", x, y, z, 0.7, 1.2); }
    }

    // ---- the grapple claw -------------------------------------------------------------------------------------------------
    var PULLS = {};
    var NORMAL = { north: [0, 0, -1], south: [0, 0, 1], east: [1, 0, 0], west: [-1, 0, 0], up: [0, 1, 0], down: [0, -1, 0] };
    function grapple(p) {
        if (!onlyInRuns(p) || !cooldown(p, "dmk_cd_grapple", 20)) return;
        var d = look(p), ray = p.raycast(18, { blocks: true, entities: false }), eyeY = p.eyeY;
        p.playSound("minecraft:entity.fishing_bobber.throw", 0.8, 0.8);
        if (!ray || ray.hit !== "block" || ray.block.split("[")[0] !== K.grapple_target) {
            var ex = ray && ray.hit === "block" ? ray.x : p.x + d.x * 18, ey = ray && ray.hit === "block" ? ray.y : eyeY + d.y * 18, ez = ray && ray.hit === "block" ? ray.z : p.z + d.z * 18;
            RPG.world.particleLine(ARENA, "minecraft:crit", p.x, eyeY - 0.2, p.z, ex, ey, ez, 0.6);
            RPG.world.sound(ARENA, "minecraft:block.chain.hit", ex, ey, ez, 0.8, 1.3);
            return;
        }
        var n = NORMAL[ray.face] || [0, 0, 0];
        var tx = ray.blockX + 0.5 + n[0] * 0.9, ty = ray.blockY + (n[1] > 0 ? 1.0 : n[1] < 0 ? -1.9 : -0.4), tz = ray.blockZ + 0.5 + n[2] * 0.9;
        RPG.world.sound(ARENA, "minecraft:block.chain.place", ray.x, ray.y, ray.z, 1, 0.9);
        PULLS[String(p.uuid)] = { p: p, x: tx, y: ty, z: tz, hx: ray.x, hy: ray.y, hz: ray.z, ticks: 0 };
    }
    RPG.every(1, function () {
        for (var u in PULLS) {
            var g = PULLS[u], p = g.p;
            var dx = g.x - p.x, dy = g.y - p.y, dz = g.z - p.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (++g.ticks > 40 || l < 1.0 || !p.isAlive() || p.dimension !== ARENA) {
                delete PULLS[u];
                p.setVelocity(0, 0.15, 0); p.fallDistance = 0;
                continue;
            }
            var sp = Math.min(1.2, l);
            p.setVelocity(dx / l * sp, dy / l * sp + 0.04, dz / l * sp);
            p.fallDistance = 0;
            if (g.ticks % 2 === 0) RPG.world.particleLine(ARENA, "minecraft:crit", p.x, p.y + 1.2, p.z, g.hx, g.hy, g.hz, 0.7);
        }
    });

    // ---- push blocks -------------------------------------------------------------------------------------------------------------
    RPG.on("blockInteract", function (p, block, x, y, z, dim) {
        if (dim !== ARENA || block !== K.push) return;
        var run = DM.runs && DM.runs.runAtBlock(x, y, z);
        if (!run) return;
        if (!cooldown(p, "dmk_cd_push", 6)) return false;
        var dx = x + 0.5 - p.x, dz = z + 0.5 - p.z, sx = 0, sz = 0;
        if (Math.abs(dx) > Math.abs(dz)) sx = dx > 0 ? 1 : -1; else sz = dz > 0 ? 1 : -1;
        var nx = x + sx, nz = z + sz, ny = y;
        if (!free(nx, ny, nz) || !DM.runs.inBox(run, nx, ny, nz) || DM.runs.isProtected(run, nx, ny, nz)) { p.playSound("minecraft:block.stone.hit", 0.6, 0.6); return false; }
        for (var i = 0; i < 16 && free(nx, ny - 1, nz) && DM.runs.inBox(run, nx, ny - 1, nz); i++) ny--;
        RPG.world.setBlock(ARENA, x, y, z, "minecraft:air");
        RPG.world.setBlock(ARENA, nx, ny, nz, K.push);
        RPG.world.sound(ARENA, "minecraft:block.piston.extend", x, y, z, 0.6, 0.7);
        RPG.world.particle(ARENA, "minecraft:poof", nx + 0.5, ny + 0.1, nz + 0.5, 4, 0.4, 0);
        return false;
    });
    function free(x, y, z) { var b = RPG.world.getBlock(ARENA, x, y, z); return b === "minecraft:air" || b === "minecraft:cave_air" || b === "minecraft:water"; }

    /** Every dungeon item, for the drop and loot pickers. */
    function itemChoices() {
        return [["small_key", "Small Key"], ["boss_key", "Boss Key"], ["heart", "Recovery Heart"], ["container", "Heart Container"], ["bomb", "Bomb"],
            ["bow", "Dungeon Bow"], ["grapple", "Grapple Claw"], ["lantern", "Dungeon Lantern"], ["compass", "Dungeon Compass"], ["map", "Dungeon Map"]].map(function (e) { return { id: I[e[0]], name: e[1] }; });
    }

    return { ITEMS: I, BLOCKS: K, isRunKey: isRunKey, stamp: stamp, stripKeys: stripKeys, keyCount: keyCount, takeKey: takeKey, runOfStack: runOfStack,
        giveBlocks: giveBlocks, giveKit: giveKit, itemChoices: itemChoices, useHeart: useHeart, useContainer: useContainer };
})();
