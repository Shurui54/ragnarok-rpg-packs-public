// =====================================================================================
//  Dungeon Maker - the building wands: dungeon bounds, rooms, puzzles / objectives / rewards, connections
// =====================================================================================
//  Four staff-only items that work on a dungeon's workshop plot (client side: client/scripts/60_dmk_wands.js):
//   - Dungeon Wand      left click = corner 1, right click = corner 2 of the dungeon's bounds; sneak + wheel (or
//                       + / -) moves the face you look at. Right-click the air: the bounds screen.
//   - Room Wand         the same selection for rooms (a box, or a centre and a radius in sphere mode); right-click
//                       the air: the rooms list (name, type, rules); sneak + right-click inside a room selects it.
//   - Puzzle Wand       right-click a block: its puzzle (or a module's own setup screen), or a new puzzle / part;
//                       right-click the air: a puzzle node there; sneak + right-click the air: puzzles, objectives.
//   - Connection Wand   right-click a source, then a target: a wireless link (sneak + right-click: removes one);
//                       right-click the air: the links list (NOT, delay, pulse, toggle).
//  Every click goes to the server as an intent ("dmk_wand" {op: "click", ...}); the server ray-casts from the
//  player, checks staff rights, the plot, ids and limits, and keeps the data. Clients only draw what they are sent.
//
//  Saved per dungeon in dmk_lay_<id> (and in exports as "layout"); all positions are [dx, dy, dz] from the plot
//  origin, like module keys, so runs place them the same way they place the blocks:
//   {v: 1, bounds: {c1, c2} | null,
//    rooms:   {id: {id, name, type, shape: "box" | "sphere", c1, c2 | c, r, rules: {lock, waves, timer, noBuild, music, ambience}}},
//    puzzles: {id: {id, name, type, room, node, parts: [[dx, dy, dz]...], cfg, rewards}},
//    links:   [{id, from: endpoint, to: endpoint, op: "direct" | "not" | "delay" | "pulse" | "toggle", time}], next}
//  Endpoints: {k: "a", key} a module, {k: "p", id} a puzzle, {k: "r", id, ev: "enter" | "clear" | "timer"} a room
//  event (sources only), {k: "b", pos, io} a block (sources: lever, button, plate, redstone; targets: redstone,
//  light, door). A module-to-module link with no options is kept as the module's own link (the Links tab's list).
//
//  In a run (20_dungeon_maker_runs.js calls in): links are evaluated when a source changes (never polled), through
//  a queue worked off at most LINK_CAP entries a tick; levers, buttons, plates and redstone at source blocks, rooms
//  and checkpoints are read every 10 ticks, only in runs that have them.
// =====================================================================================
DungeonMaker.wands = (function () {
    var DM = DungeonMaker, WORKSHOP = DM.WORKSHOP, ARENA = DM.ARENA, NS = "ragnarok_rpg:";
    var ROOM_TYPES = ["combat", "puzzle", "trap", "treasure", "boss", "safe"];
    var ROOM_COLORS = { combat: "#FF5050", puzzle: "#B070FF", trap: "#FF9930", treasure: "#FFD040", boss: "#D02828", safe: "#50E070" };
    var PUZZLE_TYPES = ["sequence", "plates", "offering", "room_clear", "survive", "hidden", "checkpoint", "combo", "logic"];
    var PUZZLE_NAMES = { sequence: "Levers / buttons in order", plates: "Pressure plates", offering: "Item offering", room_clear: "Defeat everything in a room",
        survive: "Survive a timer", hidden: "Find a hidden switch", checkpoint: "Parkour checkpoints", combo: "Colour / symbol combination", logic: "Logic node (AND / OR)" };
    var LINK_OPS = ["direct", "not", "delay", "pulse", "toggle"];
    var SRC_IO = { lever: 1, button: 1, plate: 1, redstone: 1 }, DST_IO = { redstone: 1, light: 1, door: 1 };
    var ROOM_EVENTS = ["enter", "clear", "timer"];
    var PALETTES = {
        wool: ["minecraft:red_wool", "minecraft:yellow_wool", "minecraft:lime_wool", "minecraft:light_blue_wool", "minecraft:white_wool", "minecraft:black_wool"],
        concrete: ["minecraft:red_concrete", "minecraft:orange_concrete", "minecraft:green_concrete", "minecraft:blue_concrete", "minecraft:purple_concrete", "minecraft:white_concrete"],
        glazed: ["minecraft:red_glazed_terracotta", "minecraft:yellow_glazed_terracotta", "minecraft:lime_glazed_terracotta", "minecraft:light_blue_glazed_terracotta", "minecraft:purple_glazed_terracotta", "minecraft:white_glazed_terracotta"],
        symbols: ["minecraft:chiseled_stone_bricks", "minecraft:chiseled_sandstone", "minecraft:chiseled_quartz_block", "minecraft:chiseled_deepslate", "minecraft:chiseled_red_sandstone", "minecraft:chiseled_polished_blackstone"]
    };
    var MAX_ROOMS = 48, MAX_PUZZLES = 64, MAX_LINKS = 160, MAX_PARTS = 16, MAX_REWARDS = 8, LINK_CAP = 64, PER_ENDPOINT = 16;
    var SOUND_RE = /^[a-z0-9_.\-]+:[a-z0-9_.\-\/]+$/;
    var WANDS = ["dungeon", "room", "puzzle", "connection"];

    function clone(o) { return o === undefined || o === null ? o : JSON.parse(JSON.stringify(o)); }
    function pk(x, y, z) { return x + "," + y + "," + z; }
    function half() { return Math.floor(DM.CFG.get("plotSize") / 2); }
    var YMIN = -64 - DM.PLATFORM_Y, YMAX = 319 - DM.PLATFORM_Y;
    /** A relative position, or null if it is not inside the plot. */
    function cleanPos(v) {
        if (!Array.isArray(v) || v.length !== 3) return null;
        var x = Math.floor(Number(v[0])), y = Math.floor(Number(v[1])), z = Math.floor(Number(v[2])), h = half();
        if (isNaN(x) || isNaN(y) || isNaN(z) || Math.abs(x) > h || Math.abs(z) > h || y < YMIN || y > YMAX) return null;
        return [x, y, z];
    }
    function clampPos(v) { var h = half(); return [Math.max(-h, Math.min(h, v[0] | 0)), Math.max(YMIN, Math.min(YMAX, v[1] | 0)), Math.max(-h, Math.min(h, v[2] | 0))]; }
    function relOf(d, x, y, z) { var o = DM.plotOrigin(d.plot); return [x - o.x, y - o.y, z - o.z]; }
    function boxOf(c1, c2) { return { x1: Math.min(c1[0], c2[0]), y1: Math.min(c1[1], c2[1]), z1: Math.min(c1[2], c2[2]), x2: Math.max(c1[0], c2[0]), y2: Math.max(c1[1], c2[1]), z2: Math.max(c1[2], c2[2]) }; }

    // ---- storage ----------------------------------------------------------------------------------------------
    var LAY = {};
    function normalize(L) {
        L = L && typeof L === "object" ? clone(L) : {};
        return { v: 1, bounds: L.bounds && cleanPos(L.bounds.c1) && cleanPos(L.bounds.c2) ? { c1: cleanPos(L.bounds.c1), c2: cleanPos(L.bounds.c2) } : null,
            rooms: L.rooms && typeof L.rooms === "object" ? L.rooms : {}, puzzles: L.puzzles && typeof L.puzzles === "object" ? L.puzzles : {},
            links: Array.isArray(L.links) ? L.links : [], next: Math.max(1, L.next | 0) };
    }
    function get(id) {
        if (LAY[id] === undefined) {
            var raw = DM.worldDef(id) ? RPG.data.get("dmk_lay_" + id, null) : DM.isFile(id) ? (DM.files()[id] || {}).layout || null : null;
            LAY[id] = normalize(raw);
        }
        return LAY[id];
    }
    function store(id) { if (!DM.worldDef(id)) return; RPG.data.set("dmk_lay_" + id, get(id)); syncDungeon(id); }
    function forget(id) { delete LAY[id]; RPG.data.remove("dmk_lay_" + id); }
    function put(id, layout) { LAY[id] = normalize(layout); RPG.data.set("dmk_lay_" + id, LAY[id]); }
    function nextId(L, prefix) { return prefix + (L.next++); }
    function isEmpty(L) { return !L || (!Object.keys(L.rooms).length && !Object.keys(L.puzzles).length && !L.links.length); }

    // ---- the dungeon's bounds: what runs copy, export writes and the painter and import use --------------------
    /** World box of the dungeon's bounds (clamped to the plot), or the whole plot without bounds. */
    function copyBox(d, plotNo) {
        var n = plotNo || d.plot, b = DM.plotBox(n), L = get(d.id);
        if (!L.bounds) return b;
        var o = DM.plotOrigin(n), r = boxOf(L.bounds.c1, L.bounds.c2);
        return { x1: Math.max(b.x1, o.x + r.x1), y1: Math.max(b.y1, o.y + r.y1), z1: Math.max(b.z1, o.z + r.z1),
            x2: Math.min(b.x2, o.x + r.x2), y2: Math.min(b.y2, o.y + r.y2), z2: Math.min(b.z2, o.z + r.z2) };
    }
    function boundsRel(id) { var L = get(id); return L.bounds ? boxOf(L.bounds.c1, L.bounds.c2) : null; }
    function sizeText(c1, c2) { var b = boxOf(c1, c2); return (b.x2 - b.x1 + 1) + " x " + (b.y2 - b.y1 + 1) + " x " + (b.z2 - b.z1 + 1); }

    // ---- rooms --------------------------------------------------------------------------------------------------
    function roomBox(r) {
        if (r.shape === "sphere") { var rr = Math.ceil(r.r); return { x1: r.c[0] - rr, y1: r.c[1] - rr, z1: r.c[2] - rr, x2: r.c[0] + rr, y2: r.c[1] + rr, z2: r.c[2] + rr }; }
        return boxOf(r.c1, r.c2);
    }
    /** Is the relative position inside the room? */
    function inRoom(r, x, y, z) {
        if (r.shape === "sphere") { var dx = x - r.c[0], dy = y - r.c[1], dz = z - r.c[2]; return dx * dx + dy * dy + dz * dz <= (r.r + 0.5) * (r.r + 0.5); }
        var b = boxOf(r.c1, r.c2);
        return x >= b.x1 && x <= b.x2 && y >= b.y1 && y <= b.y2 && z >= b.z1 && z <= b.z2;
    }
    function cleanRules(c) {
        c = c || {};
        var snd = function (v) { v = DM.str(v, 96).trim(); return SOUND_RE.test(v) ? v : ""; };
        return { lock: !!c.lock, waves: DM.clampInt(c.waves, 0, 10, 0), timer: DM.clampInt(c.timer, 0, 3600, 0), noBuild: !!c.noBuild,
            music: snd(c.music), ambience: snd(c.ambience), ambEvery: DM.clampInt(c.ambEvery, 2, 600, 12) };
    }
    function defaultRules(type) { return cleanRules({ lock: type === "combat" || type === "boss", noBuild: type !== "safe" }); }
    /** A room from a wand selection (or null + why). */
    function roomShape(sel) {
        if (!sel || !sel.c1) return { error: "Set the selection first (left click, then right click)" };
        if (sel.mode === "sphere") {
            var r = sel.c2 ? Math.round(Math.sqrt(Math.pow(sel.c2[0] - sel.c1[0], 2) + Math.pow(sel.c2[1] - sel.c1[1], 2) + Math.pow(sel.c2[2] - sel.c1[2], 2))) : 4;
            return { shape: "sphere", c: sel.c1.slice(), r: Math.max(1, Math.min(48, r)) };
        }
        if (!sel.c2) return { error: "Set the second corner (right click)" };
        var b = boxOf(sel.c1, sel.c2);
        if ((b.x2 - b.x1 + 1) * (b.y2 - b.y1 + 1) * (b.z2 - b.z1 + 1) > 4000000) return { error: "That room is too big" };
        return { shape: "box", c1: sel.c1.slice(), c2: sel.c2.slice() };
    }

    // ---- puzzles, rewards, objectives ---------------------------------------------------------------------------
    function cleanPuzzleCfg(type, c, old) {
        c = c || {}; old = old || {};
        switch (type) {
            case "sequence": return { reset: c.reset !== false };
            case "plates": return { mode: c.mode === "each" ? "each" : "all" };
            case "offering": return { item: old.item || null, count: DM.clampInt(c.count, 1, 64, 1), take: c.take !== false };
            case "survive": return { seconds: DM.clampInt(c.seconds, 3, 3600, 30), start: c.start === "signal" ? "signal" : "enter" };
            case "checkpoint": return { respawn: c.respawn !== false };
            case "combo": return { palette: PALETTES[c.palette] ? c.palette : "wool" };
            case "logic": return { op: c.op === "any" ? "any" : "all" };
        }
        return {};
    }
    /** Rewards from a client: item stacks only from the hand (fromHand) or kept from the saved copy, chests that exist. */
    function cleanRewards(list, old, held, A) {
        old = Array.isArray(old) ? old : [];
        var out = [];
        (Array.isArray(list) ? list : []).slice(0, MAX_REWARDS).forEach(function (r) {
            if (!r) return;
            if (r.type === "xp") out.push({ type: "xp", amount: DM.clampInt(r.amount, 1, 100000, 10) });
            else if (r.type === "money") out.push({ type: "money", amount: DM.clampInt(r.amount, 1, 1000000000, 10) });
            else if (r.type === "item") {
                var it = null;
                if (r.fromHand && held && r.item && held.id === String(r.item.id)) it = { id: held.id, nbt: held.nbt };
                else if (r.item) old.forEach(function (o) { if (!it && o.type === "item" && o.item && o.item.id === String(r.item.id) && (o.item.nbt || "") === (r.item.nbt || "")) it = clone(o.item); });
                if (it) out.push({ type: "item", item: it, count: DM.clampInt(r.count, 1, 64, 1) });
            } else if (r.type === "loot") {
                var k = String(r.key || "");
                if (A[k] && DM.CHEST_TYPES[A[k].type]) out.push({ type: "loot", key: k });
            }
        });
        return out;
    }
    function rewardText(r, A) {
        switch (r.type) {
            case "xp": return r.amount + " XP";
            case "money": return r.amount + " money";
            case "item": return DM.itemName(r.item.id) + " x" + r.count;
            case "loot": var a = A && A[r.key]; return "Loot of " + (a ? DM.moduleLabel(a, r.key) : r.key);
        }
        return "?";
    }
    /** The completion goals (shared with the card editor): the old kinds plus puzzles and rooms, each with rewards. */
    function cleanObjectives(id, list, oldList, held) {
        var L = get(id), A = DM.anchors(id);
        oldList = Array.isArray(oldList) ? oldList : [];
        return (Array.isArray(list) ? list : []).slice(0, 12).map(function (o, i) {
            if (!o) return null;
            var out = null;
            switch (o.type) {
                case "kill_count": out = { type: "kill_count", count: DM.clampInt(o.count, 1, 10000, 10) }; break;
                case "kill_entity": { var e = DM.str(o.entity, 96); out = e ? { type: "kill_entity", entity: e, count: DM.clampInt(o.count, 1, 10000, 1) } : null; break; }
                case "obtain_item": { var it = DM.cleanStack(o.item); out = it ? { type: "obtain_item", item: { id: it.id }, count: DM.clampInt(o.count, 1, 2304, 1) } : null; break; }
                case "puzzle": { var pz = L.puzzles[String(o.puzzle)]; out = pz ? { type: "puzzle", puzzle: pz.id, name: pz.name } : null; break; }
                case "room_clear": case "room_enter": { var rm = L.rooms[String(o.room)]; out = rm ? { type: o.type, room: rm.id, name: rm.name } : null; break; }
            }
            if (!out) return null;
            // rewards of the goal at the same place before (kept when the client sent none back)
            var prev = o.was !== undefined && o.was !== null ? oldList[DM.clampInt(o.was, 0, 11, 0)] || null : null;
            out.rewards = cleanRewards(o.rewards !== undefined ? o.rewards : prev && prev.rewards, prev ? prev.rewards : [], held, A);
            if (!out.rewards.length) delete out.rewards;
            return out;
        }).filter(function (o) { return o; });
    }

    // ---- links --------------------------------------------------------------------------------------------------
    function epKey(e) { return e.k === "a" ? "a:" + e.key : e.k === "p" ? "p:" + e.id : e.k === "r" ? "r:" + e.id + ":" + e.ev : "b:" + e.pos.join(",") + ":" + e.io; }
    function epTarget(e) { return e.k === "b" ? "b:" + e.pos.join(",") : epKey(e); }
    /** A clean endpoint, or null. side "from" | "to". */
    function cleanEp(id, e, side) {
        if (!e || typeof e !== "object") return null;
        var L = get(id), A = DM.anchors(id);
        if (e.k === "a") {
            var key = String(e.key || ""), a = A[key];
            if (!DM.KEY_RE.test(key) || !a) return null;
            if (side === "from" ? !DM.SOURCE_TYPES[a.type] : !(DM.INPUT_TYPES[a.type] || DM.DOOR_TYPES[a.type] || DM.CHEST_TYPES[a.type])) return null;
            return { k: "a", key: key };
        }
        if (e.k === "p") return L.puzzles[String(e.id)] ? { k: "p", id: String(e.id) } : null;
        if (e.k === "r") return side === "from" && L.rooms[String(e.id)] && ROOM_EVENTS.indexOf(e.ev) >= 0 ? { k: "r", id: String(e.id), ev: e.ev } : null;
        if (e.k === "b") {
            var pos = cleanPos(e.pos);
            if (!pos || !(side === "from" ? SRC_IO : DST_IO)[e.io]) return null;
            return { k: "b", pos: pos, io: e.io };
        }
        return null;
    }
    function epLabel(id, e) {
        var L = get(id), A = DM.anchors(id);
        if (e.k === "a") return A[e.key] ? DM.moduleLabel(A[e.key], e.key) : "Module " + e.key + " (gone)";
        if (e.k === "p") return L.puzzles[e.id] ? "Puzzle: " + L.puzzles[e.id].name : "Puzzle (gone)";
        if (e.k === "r") return (L.rooms[e.id] ? "Room " + L.rooms[e.id].name : "Room (gone)") + " - " + { enter: "a player enters", clear: "cleared", timer: "timer ends" }[e.ev];
        var io = { lever: "Lever", button: "Button", plate: "Pressure plate", redstone: "Redstone", light: "Light", door: "Door" }[e.io];
        return io + " at " + e.pos.join(", ");
    }
    /** What a plain block is as a link end, from its id. */
    function blockIo(blockId, side) {
        var b = String(blockId || "").split("[")[0];
        if (side === "from") return /lever$/.test(b) ? "lever" : /_button$/.test(b) ? "button" : /pressure_plate$/.test(b) ? "plate" : "redstone";
        return /door$|trapdoor$|fence_gate$/.test(b) ? "door" : /campfire$|candle|furnace$|smoker$/.test(b) ? "light" : "redstone";
    }
    /** Adds a link (or toggles a module's own link): {ok, msg} / {error}. */
    function addLink(p, d, from, to, op, time) {
        var L = get(d.id), A = DM.anchors(d.id);
        from = cleanEp(d.id, from, "from"); to = cleanEp(d.id, to, "to");
        if (!from) return { error: "That can't send a signal" };
        if (!to) return { error: "That can't take a signal" };
        if (epTarget(from) === epTarget(to)) return { error: "A link needs two different ends" };
        op = LINK_OPS.indexOf(op) >= 0 ? op : "direct";
        // a module powering a module with no options: the module's own link (shown in its Links tab, kept by the painter)
        if (from.k === "a" && to.k === "a" && op === "direct" && DM.INPUT_TYPES[A[to.key].type]) {
            var ls = A[from.key].cfg.links || [];
            if (ls.indexOf(to.key) >= 0) return { ok: true, msg: "Already linked" };
            if (DM.toggleLink(p, d, from.key, to.key)) return { ok: true, msg: "Linked " + epLabel(d.id, from) + " to " + epLabel(d.id, to) };
            return { error: "Could not link those" };
        }
        if (L.links.length >= MAX_LINKS) return { error: "At most " + MAX_LINKS + " links in a dungeon" };
        var fk = epKey(from), tk = epTarget(to), nf = 0, nt = 0, dup = false;
        L.links.forEach(function (l) {
            if (epKey(l.from) === fk) nf++;
            if (epTarget(l.to) === tk) nt++;
            if (epKey(l.from) === fk && epKey(l.to) === epKey(to)) dup = true;
        });
        if (dup) return { error: "Those are linked already" };
        if (nf >= PER_ENDPOINT || nt >= PER_ENDPOINT) return { error: "At most " + PER_ENDPOINT + " links on one end" };
        L.links.push({ id: nextId(L, "l"), from: from, to: to, op: op, time: DM.clampInt(time, 0, 600, op === "delay" || op === "pulse" ? 2 : 0) });
        store(d.id);
        return { ok: true, msg: "Linked " + epLabel(d.id, from) + " to " + epLabel(d.id, to) };
    }
    /** Drops links that point at things that are gone (after a delete). */
    function pruneLinks(id) {
        var L = get(id);
        L.links = L.links.filter(function (l) {
            var ok = function (e) { return e.k === "p" ? !!L.puzzles[e.id] : e.k === "r" ? !!L.rooms[e.id] : true; };
            return ok(l.from) && ok(l.to);
        });
    }

    // ---- what clients are sent (staff on the plot): synced once and on change -------------------------------------
    function centreOf(d, e) {
        var o = DM.plotOrigin(d.plot), L = get(d.id);
        var w = function (v) { return [o.x + v[0] + 0.5, o.y + v[1] + 0.5, o.z + v[2] + 0.5]; };
        if (e.k === "a") { var r = DM.parseKey(e.key); return w([r.dx, r.dy, r.dz]); }
        if (e.k === "b") return w(e.pos);
        if (e.k === "p") { var pz = L.puzzles[e.id]; if (!pz) return null; return pz.node ? w(pz.node) : pz.parts.length ? w(pz.parts[0]) : null; }
        if (e.k === "r") { var rm = L.rooms[e.id]; if (!rm) return null; var b = roomBox(rm); return [o.x + (b.x1 + b.x2 + 1) / 2, o.y + b.y2 + 1.2, o.z + (b.z1 + b.z2 + 1) / 2]; }
        return null;
    }
    var OP_COLORS = { direct: "#40E0FF", not: "#FF6060", delay: "#FFC040", pulse: "#FF80FF", toggle: "#80FF80" };
    function payload(p, d) {
        var L = get(d.id), A = DM.anchors(d.id), o = DM.plotOrigin(d.plot);
        var out = { dungeon: d.id, name: d.name, origin: [o.x, o.y, o.z], half: half(), ymin: YMIN, ymax: YMAX, bounds: L.bounds ? boxOf(L.bounds.c1, L.bounds.c2) : null,
            rooms: [], puzzles: [], links: [], modules: [], chests: [], types: { rooms: ROOM_TYPES, roomColors: ROOM_COLORS, puzzles: PUZZLE_TYPES, puzzleNames: PUZZLE_NAMES, palettes: Object.keys(PALETTES), ops: LINK_OPS },
            objectives: (d.objectives || []).map(function (ob) { var c = clone(ob); c.text = DM.objectiveText(ob); c.rewardText = (ob.rewards || []).map(function (r) { return rewardText(r, A); }); return c; }) };
        Object.keys(L.rooms).forEach(function (k) {
            var r = L.rooms[k];
            out.rooms.push({ id: r.id, name: r.name, type: r.type, shape: r.shape, c1: r.c1, c2: r.c2, c: r.c, r: r.r, rules: r.rules, box: roomBox(r), color: ROOM_COLORS[r.type] || "#FFFFFF" });
        });
        Object.keys(L.puzzles).forEach(function (k) {
            var z = L.puzzles[k];
            out.puzzles.push({ id: z.id, name: z.name, type: z.type, room: z.room || "", node: z.node, parts: z.parts, cfg: z.cfg,
                itemName: z.cfg && z.cfg.item ? DM.itemName(z.cfg.item.id) : "", rewards: z.rewards || [], rewardText: (z.rewards || []).map(function (r) { return rewardText(r, A); }) });
        });
        L.links.forEach(function (l) {
            var a = centreOf(d, l.from), b = centreOf(d, l.to);
            out.links.push({ id: l.id, from: l.from, to: l.to, op: l.op, time: l.time, a: a, b: b, c: OP_COLORS[l.op] || "#FFFFFF", fromName: epLabel(d.id, l.from), toName: epLabel(d.id, l.to) });
        });
        Object.keys(A).forEach(function (k) {
            var a = A[k], r = DM.parseKey(k);
            if (!a || !a.cfg) return;
            var m = { key: k, type: a.type, name: DM.moduleLabel(a, k), pos: [r.dx, r.dy, r.dz], src: !!DM.SOURCE_TYPES[a.type], dst: !!(DM.INPUT_TYPES[a.type] || DM.DOOR_TYPES[a.type] || DM.CHEST_TYPES[a.type]) };
            out.modules.push(m);
            if (DM.CHEST_TYPES[a.type]) out.chests.push({ key: k, name: m.name });
            // the module's own links, listed with the rest
            if (DM.SOURCE_TYPES[a.type]) (a.cfg.links || []).forEach(function (t) {
                if (!A[t]) return;
                out.links.push({ id: "m:" + k + ">" + t, module: true, from: { k: "a", key: k }, to: { k: "a", key: t }, op: "direct", time: 0, fromName: DM.moduleLabel(a, k), toName: DM.moduleLabel(A[t], t) });
            });
        });
        out.sel = SEL[DM.uid(p)] && SEL[DM.uid(p)].dungeon === d.id ? SEL[DM.uid(p)] : null;
        return out;
    }
    function plotDungeonOf(p) {
        if (!p || p.dimension !== WORKSHOP) return null;
        var n = DM.plotAt(p.x, p.z);
        return n ? DM.dungeonOfPlot(n) : null;
    }
    /** The wand data for the plot the player stands on (or null off a plot). */
    function sendTo(p) {
        sendIds(p);
        var d = plotDungeonOf(p);
        if (!d || !DM.isAdmin(p)) { RPG.net.send(p, "dmk_wnone", {}); return; }
        DM.sendBig(p, "wdata", payload(p, d));
    }
    function syncDungeon(id) {
        var d = DM.worldDef(id);
        if (!d) return;
        RPG.server.players().forEach(function (p) { if (p.dimension === WORKSHOP && DM.isAdmin(p) && DM.plotAt(p.x, p.z) === d.plot) sendTo(p); });
    }
    function sendSel(p) { RPG.net.send(p, "dmk_wsel", SEL[DM.uid(p)] || {}); }

    // ---- the wand items ---------------------------------------------------------------------------------------------
    var ITEM = {}, WAND_OF = {};
    var LORE = {
        dungeon: ["&7Sets the dungeon's overall size.", "&eLeft click&7: corner 1  &eRight click&7: corner 2", "&eSneak + wheel&7 or &e+ / -&7: move the face you look at",
            "&eRight-click the air&7: bounds screen", "&8Staff only, on a workshop plot"],
        room: ["&7Marks named rooms inside the dungeon.", "&eLeft / right click&7: corners (sphere: centre, radius)", "&eSneak + right click&7 in a room: select it",
            "&eSneak + wheel&7: move a face  &eRight-click the air&7: rooms list", "&8Staff only, on a workshop plot"],
        puzzle: ["&7Sets up puzzles, goals and rewards.", "&eRight click&7 a block: its puzzle, or a new one", "&eRight-click the air&7: a puzzle node there",
            "&eSneak + right-click the air&7: puzzles and goals", "&8Staff only, on a workshop plot"],
        connection: ["&7Links things together without wires.", "&eRight click&7 a source, then a target", "&eSneak + right click&7: remove a link  &eLeft click&7: cancel",
            "&eRight-click the air&7: links list (NOT, delay, pulse, toggle)", "&8Staff only, on a workshop plot"]
    };
    var TITLES = { dungeon: "&6Dungeon Wand", room: "&bRoom Wand", puzzle: "&dPuzzle Wand", connection: "&cConnection Wand" };
    WANDS.forEach(function (w) {
        ITEM[w] = NS + RPG.items.define("dmk_wand_" + w, { name: TITLES[w], model: "dungeon_maker:rpg/item/wand_" + w, maxStack: 1, rarity: "epic", tab: "Dungeon Maker", lore: LORE[w],
            // the client sends wand clicks itself (with the ray from the player); these only stop vanilla uses
            onUse: function () { return false; }, onUseOnBlock: function () { return true; } });
        WAND_OF[ITEM[w]] = w;
    });
    function give(p, which) {
        var list = which === "all" || !which ? WANDS : [which];
        list.forEach(function (w) { if (ITEM[w] && p.countItem(ITEM[w]) <= 0) p.giveItem("dmk_wand_" + w, 1); });
    }
    /** Script items get pooled ids (ragnarok_rpg:item_0123): clients learn which ones are the wands. */
    function sendIds(p) { RPG.net.send(p, "dmk_wids", ITEM); }
    RPG.on("playerJoin", function (p) { RPG.schedule(30, function () { sendIds(p); }); });
    function heldWand(p) { var h = p.getHeldItem(); return WAND_OF[String(h || "").split("[")[0]] || null; }
    // creative staff hitting a block with a wand never breaks it (the client normally stops the click first)
    RPG.on("blockBreak", function (p, block, x, y, z, dim) { if (dim === WORKSHOP && heldWand(p)) return false; });

    // ---- the per-player selection (Dungeon / Room Wand) and pending link source ------------------------------------
    var SEL = {};      // uuid -> {dungeon, mode, c1, c2, room, puzzle, src}
    function selOf(p, d) {
        var u = DM.uid(p), s = SEL[u];
        if (!s || s.dungeon !== d.id) s = SEL[u] = { dungeon: d.id, mode: "box", c1: null, c2: null, room: null, puzzle: null, src: null };
        return s;
    }
    function look(p) {
        var yaw = p.yaw * Math.PI / 180, pitch = p.pitch * Math.PI / 180;
        return { x: -Math.sin(yaw) * Math.cos(pitch), y: -Math.sin(pitch), z: Math.cos(yaw) * Math.cos(pitch) };
    }
    /** The face (axis, sign) the player looks towards. */
    function lookFace(p) {
        var v = look(p), ax = Math.abs(v.x), ay = Math.abs(v.y), az = Math.abs(v.z);
        if (ay >= ax && ay >= az) return { i: 1, s: v.y > 0 ? 1 : -1 };
        return ax >= az ? { i: 0, s: v.x > 0 ? 1 : -1 } : { i: 2, s: v.z > 0 ? 1 : -1 };
    }
    /** Moves the face of box (c1, c2) the player looks at by n (n > 0 grows it). */
    function nudgeBox(c1, c2, f, n) {
        var hi = c1[f.i] >= c2[f.i] ? c1 : c2, lo = hi === c1 ? c2 : c1;
        if (f.s > 0) hi[f.i] = Math.max(lo[f.i], hi[f.i] + n); else lo[f.i] = Math.min(hi[f.i], lo[f.i] - n);
        var a = clampPos(c1), b = clampPos(c2);
        c1[0] = a[0]; c1[1] = a[1]; c1[2] = a[2]; c2[0] = b[0]; c2[1] = b[1]; c2[2] = b[2];
    }
    var FACE_NAME = { "0,1": "east", "0,-1": "west", "1,1": "top", "1,-1": "bottom", "2,1": "south", "2,-1": "north" };

    /** The block the player points at (up to 64 blocks): {x, y, z, face, block} or null. */
    function aim(p) {
        var r = null;
        try { r = p.raycast(64, { blocks: true, entities: false, outline: true }); } catch (e) { }
        return r && r.hit === "block" ? { x: r.blockX, y: r.blockY, z: r.blockZ, face: r.face, block: String(r.block || "") } : null;
    }
    /** A puzzle node near the look ray (nodes have no block): its id or null. */
    function aimNode(p, d, maxDist) {
        var L = get(d.id), o = DM.plotOrigin(d.plot), v = look(p), best = null, bestT = maxDist || 64;
        Object.keys(L.puzzles).forEach(function (k) {
            var n = L.puzzles[k].node;
            if (!n) return;
            var cx = o.x + n[0] + 0.5 - p.x, cy = o.y + n[1] + 0.5 - p.eyeY, cz = o.z + n[2] + 0.5 - p.z, t = cx * v.x + cy * v.y + cz * v.z;
            if (t < 0 || t > bestT) return;
            var dx = cx - v.x * t, dy = cy - v.y * t, dz = cz - v.z * t;
            if (dx * dx + dy * dy + dz * dz <= 0.6 * 0.6) { best = k; bestT = t; }
        });
        return best;
    }
    function onPlot(d, x, z) { return DM.plotAt(x, z) === d.plot; }

    // ---- clicks -------------------------------------------------------------------------------------------------------
    function click(p, m) {
        var d = plotDungeonOf(p), w = heldWand(p);
        if (!w || w !== m.wand) return;
        if (!DM.isAdmin(p)) { p.actionbar("&cOnly dungeon staff can use the wands"); return; }
        if (!d) { p.actionbar("&cWands work on a dungeon's plot in the workshop (/dungeons)"); return; }
        var left = m.button === "left", sneak = !!m.sneak, hit = aim(p);
        if (hit && !onPlot(d, hit.x, hit.z)) { p.actionbar("&cThat is outside this dungeon's plot"); return; }
        var rel = hit ? relOf(d, hit.x, hit.y, hit.z) : null;
        if (w === "dungeon") clickBounds(p, d, left, rel);
        else if (w === "room") clickRoom(p, d, left, sneak, rel);
        else if (w === "puzzle") clickPuzzle(p, d, left, sneak, rel, hit);
        else clickLink(p, d, left, sneak, rel, hit);
    }
    function clickBounds(p, d, left, rel) {
        var L = get(d.id);
        if (!rel) { if (!left) DM.sendBig(p, "wscreen", { view: "bounds" }); return; }
        var b = L.bounds || { c1: rel.slice(), c2: rel.slice() };
        if (left) b.c1 = rel.slice(); else b.c2 = rel.slice();
        if (!L.bounds) { if (left) b.c2 = rel.slice(); else b.c1 = rel.slice(); }
        L.bounds = { c1: clampPos(b.c1), c2: clampPos(b.c2) };
        store(d.id);
        p.actionbar("&6Dungeon bounds &f" + sizeText(L.bounds.c1, L.bounds.c2) + " &7(corner " + (left ? 1 : 2) + " set)");
        p.playSound("minecraft:block.note_block.hat", 0.6, left ? 1.2 : 1.5);
    }
    function clickRoom(p, d, left, sneak, rel) {
        var s = selOf(p, d), L = get(d.id);
        if (!rel) { if (!left) DM.sendBig(p, "wscreen", { view: "rooms" }); return; }
        if (sneak && !left) {
            // select the (smallest) room the block is in, and load its shape into the selection
            var best = null, bestV = 1e18;
            Object.keys(L.rooms).forEach(function (k) {
                var r = L.rooms[k], b = roomBox(r), v = (b.x2 - b.x1 + 1) * (b.y2 - b.y1 + 1) * (b.z2 - b.z1 + 1);
                if (inRoom(r, rel[0], rel[1], rel[2]) && v < bestV) { best = r; bestV = v; }
            });
            if (!best) { p.actionbar("&7No room here"); return; }
            loadRoomSel(s, best);
            sendSel(p);
            DM.sendBig(p, "wscreen", { view: "rooms", room: best.id });
            return;
        }
        if (left) { s.c1 = rel.slice(); if (s.mode === "box" && !s.c2) s.c2 = rel.slice(); }
        else { s.c2 = rel.slice(); if (!s.c1) s.c1 = rel.slice(); }
        sendSel(p);
        var sh = roomShape(s);
        p.actionbar(sh.error ? "&7" + sh.error : sh.shape === "sphere" ? "&bRoom selection &fsphere r " + sh.r + " &7(right-click the air to save it)" : "&bRoom selection &f" + sizeText(sh.c1, sh.c2) + " &7(right-click the air to save it)");
        p.playSound("minecraft:block.note_block.hat", 0.6, left ? 1.2 : 1.5);
    }
    function loadRoomSel(s, r) {
        s.room = r.id;
        if (r.shape === "sphere") { s.mode = "sphere"; s.c1 = r.c.slice(); s.c2 = [r.c[0] + Math.round(r.r), r.c[1], r.c[2]]; }
        else { s.mode = "box"; s.c1 = r.c1.slice(); s.c2 = r.c2.slice(); }
    }
    function nudge(p, m) {
        var d = plotDungeonOf(p), w = heldWand(p);
        if (!d || !DM.isAdmin(p) || (w !== "dungeon" && w !== "room")) return;
        var n = m.dir > 0 ? 1 : -1, f = lookFace(p), name = FACE_NAME[f.i + "," + f.s];
        if (w === "dungeon") {
            var L = get(d.id);
            if (!L.bounds) { p.actionbar("&7Set the bounds' corners first"); return; }
            nudgeBox(L.bounds.c1, L.bounds.c2, f, n);
            store(d.id);
            p.actionbar("&6Dungeon bounds &f" + sizeText(L.bounds.c1, L.bounds.c2) + " &7(" + name + " face " + (n > 0 ? "out" : "in") + ")");
        } else {
            var s = selOf(p, d);
            if (!s.c1 || !s.c2) { p.actionbar("&7Set the selection first"); return; }
            if (s.mode === "sphere") {
                // the radius point moves out or in
                var r = Math.max(1, Math.min(48, Math.round(Math.sqrt(Math.pow(s.c2[0] - s.c1[0], 2) + Math.pow(s.c2[1] - s.c1[1], 2) + Math.pow(s.c2[2] - s.c1[2], 2))) + n));
                s.c2 = [s.c1[0] + r, s.c1[1], s.c1[2]];
                p.actionbar("&bRoom selection &fsphere r " + r);
            } else { nudgeBox(s.c1, s.c2, f, n); p.actionbar("&bRoom selection &f" + sizeText(s.c1, s.c2) + " &7(" + name + " face " + (n > 0 ? "out" : "in") + ")"); }
            sendSel(p);
        }
        p.playSound("minecraft:block.note_block.hat", 0.4, n > 0 ? 1.6 : 1.1);
    }

    function puzzleOfBlock(L, rel) {
        var found = null;
        Object.keys(L.puzzles).forEach(function (k) { var z = L.puzzles[k]; z.parts.forEach(function (q) { if (!found && q[0] === rel[0] && q[1] === rel[1] && q[2] === rel[2]) found = z; }); });
        return found;
    }
    function clickPuzzle(p, d, left, sneak, rel, hit) {
        var L = get(d.id), s = selOf(p, d);
        var node = !rel || !left ? aimNode(p, d, hit ? Math.sqrt(Math.pow(hit.x + 0.5 - p.x, 2) + Math.pow(hit.y + 0.5 - p.eyeY, 2) + Math.pow(hit.z + 0.5 - p.z, 2)) : 64) : null;
        if (node) { DM.sendBig(p, "wscreen", { view: "puzzles", puzzle: node }); return; }
        if (!rel) {
            if (left) return;
            if (s.puzzle) {
                // done adding parts: back to that puzzle's screen
                var done = s.puzzle; s.puzzle = null; sendSel(p);
                DM.sendBig(p, "wscreen", { view: "puzzles", puzzle: done });
                return;
            }
            if (sneak) { DM.sendBig(p, "wscreen", { view: "puzzles" }); return; }
            // a puzzle node in the empty space in front (3 blocks out)
            var v = look(p), o = DM.plotOrigin(d.plot);
            var np = clampPos(relOf(d, Math.floor(p.x + v.x * 3), Math.floor(p.eyeY + v.y * 3), Math.floor(p.z + v.z * 3)));
            if (!onPlot(d, o.x + np[0], o.z + np[2])) { p.actionbar("&cThat is outside this dungeon's plot"); return; }
            DM.sendBig(p, "wscreen", { view: "puzzles", pendingNode: np });
            return;
        }
        // adding parts: the picked puzzle takes (or drops) every block clicked
        if (s.puzzle && L.puzzles[s.puzzle]) {
            var z = L.puzzles[s.puzzle], i = -1;
            z.parts.forEach(function (q, j) { if (q[0] === rel[0] && q[1] === rel[1] && q[2] === rel[2]) i = j; });
            var other = puzzleOfBlock(L, rel);
            if (i >= 0) { z.parts.splice(i, 1); p.actionbar("&7Removed from " + z.name + " (" + z.parts.length + " part(s))"); }
            else if (other && other !== z) { p.actionbar("&cThat block belongs to " + other.name); return; }
            else if (DM.anchorTypeOf(hit.block)) { p.actionbar("&cModule blocks can't be puzzle parts"); return; }
            else if (z.parts.length >= MAX_PARTS) { p.actionbar("&cAt most " + MAX_PARTS + " parts"); return; }
            else { z.parts.push(rel.slice()); p.actionbar("&dAdded to " + z.name + " &7(" + z.parts.length + " part(s); right-click the air when done)"); }
            store(d.id);
            p.playSound("minecraft:block.note_block.bit", 0.6, i >= 0 ? 0.8 : 1.4);
            return;
        }
        if (left) return;
        var owner = puzzleOfBlock(L, rel);
        if (owner) { DM.sendBig(p, "wscreen", { view: "puzzles", puzzle: owner.id }); return; }
        var t = DM.anchorTypeOf(hit.block);
        if (t) {
            // a module: its own setup screen (the anchor screens, reused)
            var A = DM.anchors(d.id), k = DM.relKey(d.plot, hit.x, hit.y, hit.z);
            if (A[k]) { DM.openAnchor(p, d, k); return; }
        }
        DM.sendBig(p, "wscreen", { view: "puzzles", pendingPart: rel, block: hit.block.split("[")[0] });
    }
    function endpointAt(p, d, rel, hit, side, sneak) {
        var L = get(d.id), A = DM.anchors(d.id);
        var node = aimNode(p, d, hit ? Math.sqrt(Math.pow(hit.x + 0.5 - p.x, 2) + Math.pow(hit.y + 0.5 - p.eyeY, 2) + Math.pow(hit.z + 0.5 - p.z, 2)) : 64);
        if (node) return { k: "p", id: node };
        if (!rel) return null;
        var k = DM.relKey(d.plot, hit.x, hit.y, hit.z);
        if (A[k]) return { k: "a", key: k };
        var z = puzzleOfBlock(L, rel);
        if (z) return { k: "p", id: z.id };
        return { k: "b", pos: rel, io: blockIo(hit.block, side) };
    }
    function clickLink(p, d, left, sneak, rel, hit) {
        var s = selOf(p, d), L = get(d.id);
        if (left) { if (s.src) { s.src = null; sendSel(p); p.actionbar("&7Link cancelled"); } return; }
        var ep = endpointAt(p, d, rel, hit, s.src ? "to" : "from", sneak);
        if (!ep) { if (s.src) { s.src = null; sendSel(p); p.actionbar("&7Link cancelled"); } else DM.sendBig(p, "wscreen", { view: "links" }); return; }
        if (sneak) {
            // removes the newest link touching that end (a module's own link too)
            var key = ep.k === "b" ? "b:" + ep.pos.join(",") : epKey(ep), A = DM.anchors(d.id), idx = -1;
            L.links.forEach(function (l, i) { var f = l.from.k === "b" ? "b:" + l.from.pos.join(",") : epKey(l.from); if (f === key || epTarget(l.to) === key) idx = i; });
            if (idx >= 0) { var gone = L.links.splice(idx, 1)[0]; store(d.id); p.actionbar("&7Removed: " + epLabel(d.id, gone.from) + " > " + epLabel(d.id, gone.to)); p.playSound("minecraft:block.chain.break", 0.7, 1.2); return; }
            if (ep.k === "a") {
                var a = A[ep.key];
                if (a && (a.cfg.links || []).length) { var t = a.cfg.links[a.cfg.links.length - 1]; DM.toggleLink(p, d, ep.key, t); return; }
                var from = Object.keys(A).filter(function (j) { return (A[j].cfg.links || []).indexOf(ep.key) >= 0; });
                if (from.length) { DM.toggleLink(p, d, from[from.length - 1], ep.key); return; }
            }
            p.actionbar("&7No link here to remove");
            return;
        }
        if (!s.src) {
            var src = cleanEp(d.id, ep.k === "b" ? { k: "b", pos: ep.pos, io: blockIo(hit && hit.block, "from") } : ep, "from");
            if (!src) { p.actionbar("&c" + epLabel(d.id, ep) + " can't send a signal (it can be a target)"); return; }
            s.src = src; sendSel(p);
            p.actionbar("&cSource: &f" + epLabel(d.id, src) + " &7- now right-click the target (left click cancels)");
            p.playSound("minecraft:block.note_block.pling", 0.6, 1.0);
            return;
        }
        var res = addLink(p, d, s.src, ep.k === "b" ? { k: "b", pos: ep.pos, io: blockIo(hit && hit.block, "to") } : ep, "direct", 0);
        if (res.error) { p.actionbar("&c" + res.error); return; }
        s.src = null; sendSel(p);
        p.actionbar("&a" + res.msg);
        p.playSound("minecraft:block.note_block.pling", 0.6, 1.6);
    }

    // ---- screen ops -----------------------------------------------------------------------------------------------------
    function result(p, ok, msg) { RPG.net.send(p, "dmk_msg", { ok: !!ok, msg: String(msg) }); if (!ok) p.actionbar("&c" + msg); }
    RPG.net.on("dmk_wand", function (p, m) {
        if (!m || typeof m.op !== "string") return;
        if (m.op === "click") { click(p, m); return; }
        if (m.op === "nudge") { nudge(p, m); return; }
        if (m.op === "ids") { sendIds(p); return; }
        if (!DM.isAdmin(p)) { p.actionbar("&cOnly dungeon staff can do that"); return; }
        if (m.op === "give") { give(p, WANDS.indexOf(m.wand) >= 0 ? m.wand : "all"); result(p, true, "Wands given: they work on a dungeon's workshop plot"); return; }
        var d = plotDungeonOf(p);
        if (!d) { result(p, false, "Stand on a dungeon's workshop plot"); return; }
        var L = get(d.id), s = selOf(p, d), A = DM.anchors(d.id);
        switch (m.op) {
            case "data": sendTo(p); sendSel(p); return;
            // ---- bounds ----
            case "bounds_set": {
                var c1 = cleanPos(m.c1), c2 = cleanPos(m.c2);
                if (!c1 || !c2) { result(p, false, "Those corners are outside the plot"); return; }
                L.bounds = { c1: c1, c2: c2 }; store(d.id); result(p, true, "Bounds " + sizeText(c1, c2)); return;
            }
            case "bounds_clear": L.bounds = null; store(d.id); result(p, true, "Bounds cleared: the whole plot is the dungeon"); return;
            case "bounds_plot": { var h = half(); L.bounds = { c1: [-h, -16, -h], c2: [h, 48, h] }; store(d.id); result(p, true, "Bounds: the whole plot"); return; }
            case "bounds_fit": {
                var b = DM.plotBox(d.plot), o = DM.plotOrigin(d.plot);
                RPG.edit.extent(null, WORKSHOP, { type: "cuboid", x1: b.x1, y1: b.y1, z1: b.z1, x2: b.x2, y2: b.y2, z2: b.z2 }, { history: false, progress: false }).then(function (t) {
                    var e = t.result;
                    if (t.error || !e) { result(p, false, t.error || "The plot is empty"); return; }
                    L.bounds = { c1: clampPos([e.minX - o.x, e.minY - o.y, e.minZ - o.z]), c2: clampPos([e.maxX - o.x, e.maxY - o.y, e.maxZ - o.z]) };
                    store(d.id); result(p, true, "Bounds fit to the build: " + sizeText(L.bounds.c1, L.bounds.c2));
                });
                return;
            }
            // ---- rooms ----
            case "sel_mode": s.mode = m.mode === "sphere" ? "sphere" : "box"; s.c2 = s.mode === "sphere" && s.c1 ? [s.c1[0] + 4, s.c1[1], s.c1[2]] : s.c2; sendSel(p); return;
            case "sel_clear": s.c1 = null; s.c2 = null; s.room = null; s.puzzle = null; s.src = null; sendSel(p); return;
            case "room_select": { var rs = L.rooms[String(m.id)]; if (!rs) return; loadRoomSel(s, rs); sendSel(p); return; }
            case "room_save": {
                var r = m.id ? L.rooms[String(m.id)] : null;
                if (m.id && !r) { result(p, false, "That room is gone"); return; }
                if (!r && Object.keys(L.rooms).length >= MAX_ROOMS) { result(p, false, "At most " + MAX_ROOMS + " rooms"); return; }
                var type = ROOM_TYPES.indexOf(m.type) >= 0 ? m.type : r ? r.type : "combat";
                var shape = null;
                if (!r || m.fromSel) { shape = roomShape(s); if (shape.error) { result(p, false, shape.error); return; } }
                if (!r) { r = { id: nextId(L, "r"), name: "", type: type, rules: defaultRules(type) }; L.rooms[r.id] = r; }
                r.name = DM.str(m.name, 24).trim() || r.name || ("Room " + Object.keys(L.rooms).length);
                r.type = type;
                if (m.rules) r.rules = cleanRules(m.rules);
                if (shape) { delete r.c1; delete r.c2; delete r.c; delete r.r; Object.keys(shape).forEach(function (k) { r[k] = shape[k]; }); }
                s.room = r.id;
                store(d.id); sendSel(p);
                result(p, true, "Room '" + r.name + "' saved");
                return;
            }
            case "room_delete": {
                var rd = L.rooms[String(m.id)];
                if (!rd) return;
                delete L.rooms[rd.id];
                Object.keys(L.puzzles).forEach(function (k) { if (L.puzzles[k].room === rd.id) L.puzzles[k].room = ""; });
                pruneLinks(d.id);
                if (s.room === rd.id) s.room = null;
                store(d.id); result(p, true, "Room '" + rd.name + "' deleted");
                return;
            }
            // ---- puzzles ----
            case "puzzle_save": {
                var z = m.id ? L.puzzles[String(m.id)] : null;
                if (m.id && !z) { result(p, false, "That puzzle is gone"); return; }
                if (!z && Object.keys(L.puzzles).length >= MAX_PUZZLES) { result(p, false, "At most " + MAX_PUZZLES + " puzzles"); return; }
                var pt = PUZZLE_TYPES.indexOf(m.type) >= 0 ? m.type : z ? z.type : "sequence";
                var part = cleanPos(m.part), nd = cleanPos(m.node), owner = part ? puzzleOfBlock(L, part) : null;
                if (owner && owner !== z) { result(p, false, "That block belongs to " + owner.name); return; }
                if (part && z && !owner && z.parts.length >= MAX_PARTS) { result(p, false, "At most " + MAX_PARTS + " parts"); return; }
                if (!z) {
                    z = { id: nextId(L, "p"), name: "", type: pt, room: "", node: null, parts: [], cfg: cleanPuzzleCfg(pt, {}), rewards: [] };
                    if (nd) z.node = nd;
                    L.puzzles[z.id] = z;
                }
                if (part && !owner) z.parts.push(part);
                z.name = DM.str(m.name, 24).trim() || z.name || ("Puzzle " + Object.keys(L.puzzles).length);
                if (z.type !== pt) z.cfg = cleanPuzzleCfg(pt, {}, {});
                z.type = pt;
                z.room = L.rooms[String(m.room || "")] ? String(m.room) : "";
                var oldCfg = z.cfg || {};
                z.cfg = cleanPuzzleCfg(pt, m.cfg, oldCfg);
                if (pt === "offering" && m.cfg && m.cfg.itemFromHand) { var held = DM.cleanStack(p.getHeldStack()); if (held && !WAND_OF[held.id]) z.cfg.item = { id: held.id, nbt: held.nbt }; else result(p, false, "Hold the item to offer in your main hand (not a wand)"); }
                if (Array.isArray(m.order) && m.order.length === z.parts.length) {
                    // parts reordered or removed in the screen: indexes into the saved list
                    var seen = {}, np2 = [];
                    m.order.forEach(function (i) { i = i | 0; if (i >= 0 && i < z.parts.length && !seen[i]) { seen[i] = 1; np2.push(z.parts[i]); } });
                    if (np2.length === z.parts.length) z.parts = np2;
                }
                if (Array.isArray(m.remove)) { var rm = {}; m.remove.forEach(function (i) { rm[i | 0] = 1; }); z.parts = z.parts.filter(function (q, i) { return !rm[i]; }); }
                if (m.rewards !== undefined) z.rewards = cleanRewards(m.rewards, z.rewards, DM.cleanStack(p.getHeldStack()), A);
                if ((pt === "room_clear" || pt === "survive") && !z.room) p.actionbar("&ePick the room this puzzle watches");
                s.puzzle = m.addParts ? z.id : null;
                if (m.addParts) p.actionbar("&dRight-click blocks to add them to " + z.name + " (again to remove); right-click the air when done");
                store(d.id); sendSel(p);
                result(p, true, "Puzzle '" + z.name + "' saved");
                RPG.net.send(p, "dmk_wsaved", { puzzle: z.id });
                return;
            }
            case "puzzle_parts": { var zp = L.puzzles[String(m.id)]; s.puzzle = zp && m.on ? zp.id : null; sendSel(p); if (zp && m.on) { p.actionbar("&dRight-click blocks to add them to " + zp.name); RPG.net.send(p, "dmk_close", {}); } return; }
            case "puzzle_delete": {
                var zd = L.puzzles[String(m.id)];
                if (!zd) return;
                delete L.puzzles[zd.id]; pruneLinks(d.id);
                if (s.puzzle === zd.id) s.puzzle = null;
                d.objectives = (d.objectives || []).filter(function (o) { return !(o.type === "puzzle" && o.puzzle === zd.id); });
                DM.saveDef(d);
                store(d.id); result(p, true, "Puzzle '" + zd.name + "' deleted");
                return;
            }
            case "objectives_save": {
                d.objectives = cleanObjectives(d.id, m.list, d.objectives, DM.cleanStack(p.getHeldStack()));
                DM.saveDef(d); syncDungeon(d.id); result(p, true, "Goals saved (" + d.objectives.length + ")");
                return;
            }
            // ---- links ----
            case "link_add": {
                var res = addLink(p, d, m.from, m.to, m.opn, m.time);
                result(p, !res.error, res.error || res.msg);
                return;
            }
            case "link_save": {
                var lk = null;
                L.links.forEach(function (l) { if (l.id === String(m.id)) lk = l; });
                if (!lk) return;
                lk.op = LINK_OPS.indexOf(m.opn) >= 0 ? m.opn : lk.op;
                lk.time = DM.clampInt(m.time, 0, 600, lk.time);
                store(d.id); result(p, true, "Link saved");
                return;
            }
            case "link_delete": {
                var id = String(m.id || "");
                if (id.indexOf("m:") === 0) {
                    var parts = id.substring(2).split(">");
                    if (A[parts[0]] && (A[parts[0]].cfg.links || []).indexOf(parts[1]) >= 0) DM.toggleLink(p, d, parts[0], parts[1]);
                    syncDungeon(d.id);
                    return;
                }
                var before = L.links.length;
                L.links = L.links.filter(function (l) { return l.id !== id; });
                if (L.links.length !== before) { store(d.id); result(p, true, "Link removed"); }
                return;
            }
            case "link_cancel": s.src = null; sendSel(p); return;
        }
    });

    // =====================================================================================================================
    //  Runs: rooms, puzzles and links come alive in the arena copy (called from 20_dungeon_maker_runs.js)
    // =====================================================================================================================
    function R() { return DM.runs && DM.runs._; }
    function wpos(run, v) { return { x: run.origin.x + v[0], y: run.origin.y + v[1], z: run.origin.z + v[2] }; }
    function activate(run) {
        run.w = null;
        var L = get(run.def);
        if (isEmpty(L)) return;
        var o = run.origin, W = run.w = { rooms: {}, puzzles: {}, links: [], from: {}, into: {}, src: {}, q: [], partAt: {}, blockSrc: [], emit: {}, locked: {}, respawn: {}, plates: false, checkpoints: false };
        // rooms: world shapes, their spawners and doors
        Object.keys(L.rooms).forEach(function (k) {
            var r = clone(L.rooms[k]), b = roomBox(r);
            var wr = W.rooms[k] = { r: r, box: { x1: o.x + b.x1, y1: o.y + b.y1, z1: o.z + b.z1, x2: o.x + b.x2, y2: o.y + b.y2, z2: o.z + b.z2 }, spawners: [], doors: [],
                ev: { enter: false, clear: false, timer: false }, inside: {}, enteredAt: 0, wave: 1, ambAt: 0 };
            run.anchors.forEach(function (a) {
                var x = a.x - o.x, y = a.y - o.y, z = a.z - o.z;
                if ((a.type === "spawner" || a.type === "boss") && inRoom(r, x, y, z)) wr.spawners.push(a.key);
                if (DM.DOOR_TYPES[a.type]) {
                    // a door belongs to the room when its module or any of its blocks is in the room or right next to it
                    var near = function (bx, by, bz) { for (var i = -1; i <= 1; i++) for (var j = -1; j <= 1; j++) for (var q = -1; q <= 1; q++) if (inRoom(r, bx + i, by + j, bz + q)) return true; return false; };
                    var zone = run.zones[a.key] || [], isIn = near(x, y, z);
                    for (var zi = 0; zi < zone.length && !isIn; zi += Math.max(1, Math.floor(zone.length / 16))) isIn = near(zone[zi].x - o.x, zone[zi].y - o.y, zone[zi].z - o.z);
                    if (isIn) wr.doors.push(a.key);
                }
            });
        });
        // puzzles: parts in the arena; combination parts are scrambled away from the built solution
        Object.keys(L.puzzles).forEach(function (k) {
            var z = clone(L.puzzles[k]), wz = W.puzzles[k] = { z: z, parts: z.parts.map(function (v) { return wpos(run, v); }), solved: false, armed: true, step: 0, seen: {}, startAt: 0, sol: [] };
            wz.parts.forEach(function (q, i) { W.partAt[pk(q.x, q.y, q.z)] = { id: k, i: i }; run.protect[pk(q.x, q.y, q.z)] = 1; });
            if (z.type === "combo") {
                var pal = PALETTES[z.cfg.palette] || PALETTES.wool;
                wz.parts.forEach(function (q) {
                    var sol = RPG.world.getBlock(ARENA, q.x, q.y, q.z).split("[")[0];
                    wz.sol.push(sol);
                    var choices = pal.filter(function (b) { return b !== sol; });
                    RPG.world.setBlock(ARENA, q.x, q.y, q.z, choices[Math.floor(Math.random() * choices.length)]);
                });
                wz.pal = pal.slice();
                wz.sol.forEach(function (b) { if (wz.pal.indexOf(b) < 0) wz.pal.push(b); });
            }
            if (z.type === "sequence") wz.parts.forEach(function (q) { if (RPG.world.blockProperty(ARENA, q.x, q.y, q.z, "powered") === "true") RPG.world.setBlockProperty(ARENA, q.x, q.y, q.z, "powered", false); });
            if (z.type === "plates") W.plates = true;
            if (z.type === "checkpoint") W.checkpoints = true;
        });
        // links: sources keyed for edge detection, targets fed through virtual inputs (modules) or set directly
        L.links.forEach(function (l0) {
            var l = clone(l0);
            if (l.from.k === "a" && !run.byKey[l.from.key]) return;
            if (l.to.k === "a" && !run.byKey[l.to.key]) return;
            if (l.from.k === "p" && !W.puzzles[l.from.id] || l.to.k === "p" && !W.puzzles[l.to.id]) return;
            if (l.from.k === "r" && !W.rooms[l.from.id]) return;
            l.out = false; l.state = false;
            W.links.push(l);
            var fk = epKey(l.from);
            (W.from[fk] = W.from[fk] || []).push(l);
            var tk = epTarget(l.to);
            (W.into[tk] = W.into[tk] || []).push(l);
            if (l.from.k === "b") { var bp = wpos(run, l.from.pos); W.blockSrc.push({ key: fk, x: bp.x, y: bp.y, z: bp.z, io: l.from.io }); }
            if (l.to.k === "a") {
                var a = run.byKey[l.to.key], vk = "w:" + l.id;
                run.node[vk] = { on: false };
                if (DM.INPUT_TYPES[a.type]) {
                    (run.inputs[a.key] = run.inputs[a.key] || []).push(vk);
                    if (a.type !== "logic" && run.targets.indexOf(a) < 0) run.targets.push(a);
                }
            }
            if (l.to.k === "p") W.puzzles[l.to.id].armed = false;      // a puzzle with inputs waits for them (logic nodes are their inputs)
        });
        W.blockSrc.forEach(function (b) { W.src[b.key] = readBlock(b); });
        // first values: NOT links start on, module sources as they are now
        W.links.forEach(function (l) { var v = srcValue(run, l.from); W.src[epKey(l.from)] = v; edge(run, l, v, true); });
        run.wands = true;
    }
    function readBlock(b) {
        if (b.io === "redstone") return RPG.world.redstonePower(ARENA, b.x, b.y, b.z) > 0;
        var pw = RPG.world.blockProperty(ARENA, b.x, b.y, b.z, "powered");
        if (pw !== null) return pw === "true";
        var pow = RPG.world.blockProperty(ARENA, b.x, b.y, b.z, "power");
        return pow !== null ? Number(pow) > 0 : RPG.world.redstonePower(ARENA, b.x, b.y, b.z) > 0;
    }
    function srcValue(run, e) {
        var W = run.w;
        if (e.k === "a") { var n = run.node[e.key]; return !!(n && n.on); }
        if (e.k === "p") return !!(W.puzzles[e.id] && W.puzzles[e.id].solved);
        if (e.k === "r") return !!(W.rooms[e.id] && W.rooms[e.id].ev[e.ev]);
        return !!W.src[epKey(e)];
    }
    /** A source end changed: its links work out their output (queued, so a chain moves a step a tick). */
    function sourceChanged(run, key, v) {
        var W = run.w;
        if (!W || W.src[key] === v) return;
        W.src[key] = v;
        (W.from[key] || []).forEach(function (l) { edge(run, l, v, false); });
    }
    function edge(run, l, v, first) {
        var W = run.w, t = DM.tick(), rising = v && !l.state;
        l.state = v;
        switch (l.op) {
            case "not": queue(W, l, !v, t); break;
            case "delay": if (!first || v) queue(W, l, v, t + Math.max(1, l.time * 20)); break;
            case "pulse": if (rising) { queue(W, l, true, t); queue(W, l, false, t + Math.max(10, l.time * 20)); } break;
            case "toggle": if (rising) queue(W, l, !l.next, t, true); break;
            default: if (!first || v) queue(W, l, v, t);
        }
    }
    function queue(W, l, v, at, toggle) { if (toggle) l.next = v; W.q.push({ l: l, v: v, at: at }); }
    // the link queue: due entries only, at most LINK_CAP a tick over every run
    RPG.every(1, function () {
        var runs = DM.runs ? DM.runs._.all() : null, budget = LINK_CAP, t = DM.tick();
        if (!runs) return;
        for (var id in runs) {
            var run = runs[id], W = run.w;
            if (!W || !W.q.length || run.state !== "active") continue;
            var keep = [], dirty = false;
            for (var i = 0; i < W.q.length; i++) {
                var e = W.q[i];
                if (e.at > t || budget <= 0) { keep.push(e); continue; }
                budget--;
                if (apply(run, e.l, e.v)) dirty = true;
            }
            W.q = keep;
            if (dirty) R().propagate(run);
        }
    });
    /** A link's output changed: the target follows (any of its links on = on). True when modules need a propagate. */
    function apply(run, l, v) {
        var W = run.w;
        if (l.out === v) return false;
        l.out = v;
        var tk = epTarget(l.to), on = (W.into[tk] || []).some(function (x) { return x.out; });
        var e = l.to;
        if (e.k === "a") {
            var a = run.byKey[e.key];
            if (!a) return false;
            if (DM.INPUT_TYPES[a.type]) { run.node["w:" + l.id].on = v; return true; }
            if (DM.DOOR_TYPES[a.type]) { if (on) { if (!isLocked(run, a.key)) R().openDoor(run, a); } else if (a.cfg.closeOff) R().closeDoor(run, a); return false; }
            if (DM.CHEST_TYPES[a.type] && on) { run.unlocked[a.key] = true; if (a.type === "sk_chest" && !a.open) { a.open = true; RPG.world.setBlock(ARENA, a.x, a.y, a.z, R().chestBlock(a)); } RPG.world.particle(ARENA, "minecraft:end_rod", a.x + 0.5, a.y + 1, a.z + 0.5, 12, 0.4, 0.03); }
            return false;
        }
        if (e.k === "p") { puzzleInput(run, e.id, tk); return false; }
        if (e.k === "b") blockOut(run, wpos(run, e.pos), e.io, on, tk);
        return false;
    }
    // ---- wireless redstone and the other block outputs ----
    var EMITTER = NS + RPG.blocks.define("dmk_wireless", { name: "&cWireless Redstone Signal", model: "dungeon_maker:rpg/block/wireless", hardness: -1, collision: false, decor: true,
        shape: [6, 6, 6, 10, 10, 10], drops: "none", redstone: { dynamic: true, strong: true } });
    var SIDES = [[0, -1, 0], [0, 1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]];
    function blockOut(run, b, io, on, tk) {
        var W = run.w, id = RPG.world.getBlock(ARENA, b.x, b.y, b.z).split("[")[0];
        if (io === "door" && RPG.world.blockProperty(ARENA, b.x, b.y, b.z, "open") !== null) {
            RPG.world.setBlockProperty(ARENA, b.x, b.y, b.z, "open", on);
            RPG.world.sound(ARENA, on ? "minecraft:block.iron_door.open" : "minecraft:block.iron_door.close", b.x + 0.5, b.y + 0.5, b.z + 0.5, 0.8, 1);
            return;
        }
        if (io === "light" && id !== "minecraft:redstone_lamp" && RPG.world.blockProperty(ARENA, b.x, b.y, b.z, "lit") !== null) { RPG.world.setBlockProperty(ARENA, b.x, b.y, b.z, "lit", on); return; }
        // redstone: an invisible signal block in a free spot next to the target powers it (and what it touches) out of
        // the one side facing the target, so a neighbouring link's target next to the same spot isn't powered too
        var em = W.emit[tk];
        if (!em) {
            for (var i = 0; i < SIDES.length && !em; i++) {
                var x = b.x + SIDES[i][0], y = b.y + SIDES[i][1], z = b.z + SIDES[i][2], here = RPG.world.getBlock(ARENA, x, y, z);
                if ((here === "minecraft:air" || here === "minecraft:cave_air") && DM.runs.inBox(run, x, y, z)) em = { x: x, y: y, z: z };
            }
            if (!em) { RPG.log("[Dungeon Maker] no free spot next to " + b.x + "," + b.y + "," + b.z + " for a wireless signal"); return; }
            W.emit[tk] = em;
            RPG.world.setBlock(ARENA, em.x, em.y, em.z, EMITTER);
            run.protect[pk(em.x, em.y, em.z)] = 1;
        }
        RPG.blocks.setPower(ARENA, em.x, em.y, em.z, on ? 15 : 0, sideTowards(em, b));
    }
    function sideTowards(from, to) {
        var dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        return dy < 0 ? "down" : dy > 0 ? "up" : dz < 0 ? "north" : dz > 0 ? "south" : dx < 0 ? "west" : "east";
    }

    // ---- puzzles in play ----
    function members(run) { return R().members(run); }
    function tellRoom(run, msg) { members(run).forEach(function (m) { m.actionbar(msg); }); }
    function puzzleInput(run, id, tk) {
        var W = run.w, wz = W.puzzles[id];
        if (!wz || wz.solved) return;
        var ins = W.into[tk] || [], on = ins.some(function (l) { return l.out; });
        if (wz.z.type === "logic") {
            var all = ins.length > 0 && ins.every(function (l) { return l.out; });
            if (wz.z.cfg.op === "any" ? on : all) solve(run, id);
            return;
        }
        if (on && !wz.armed) {
            wz.armed = true;
            if (wz.z.type === "survive" && wz.z.cfg.start === "signal") wz.startAt = DM.tick();
            if (wz.parts[0]) RPG.world.particle(ARENA, "minecraft:enchant", wz.parts[0].x + 0.5, wz.parts[0].y + 1.2, wz.parts[0].z + 0.5, 20, 0.5, 0.2);
        }
    }
    function solve(run, id) {
        var W = run.w, wz = W.puzzles[id];
        if (!wz || wz.solved) return;
        wz.solved = true;
        var at = wz.parts[0] || (wz.z.node ? wpos(run, wz.z.node) : run.spawn);
        members(run).forEach(function (m) { m.title(" ", "&dPuzzle solved: &f" + wz.z.name); m.playSound("minecraft:block.note_block.chime", 0.9, 1.4); m.playSound("minecraft:entity.player.levelup", 0.5, 1.8); });
        RPG.world.particle(ARENA, "minecraft:happy_villager", at.x + 0.5, at.y + 1, at.z + 0.5, 24, 0.8, 0.1);
        reward(run, wz.z.rewards, at);
        sourceChanged(run, "p:" + id, true);
    }
    /** Rewards for everyone in the run (XP, money), or dropped where it happened (items, a chest's loot). */
    function reward(run, list, at) {
        if (!list || !list.length) return;
        var ps = members(run), A = DM.anchors(run.def);
        list.forEach(function (r) {
            try {
                if (r.type === "xp") ps.forEach(function (m) { DM.hooks.giveXp(m, r.amount); });
                else if (r.type === "money") ps.forEach(function (m) { DM.hooks.giveMoney(m, r.amount); });
                else if (r.type === "item") { var st = { id: r.item.id, count: r.count }; if (r.item.nbt) st.nbt = r.item.nbt; RPG.world.dropItem(ARENA, at.x + 0.5, at.y + 1.2, at.z + 0.5, st); }
                else if (r.type === "loot" && A[r.key]) R().rollLoot(run, A[r.key].cfg).forEach(function (s) { if (s) RPG.world.dropItem(ARENA, at.x + 0.5, at.y + 1.2, at.z + 0.5, s); });
            } catch (e) { RPG.log("[Dungeon Maker] reward: " + e); }
        });
        ps.forEach(function (m) { m.playSound("minecraft:entity.item.pickup", 0.6, 0.9); });
    }
    function partClicked(run, p, x, y, z, how) {
        var W = run.w, at = W && W.partAt[pk(x, y, z)];
        if (!at) return undefined;
        var wz = W.puzzles[at.id], c = wz.z.cfg, t = wz.z.type;
        if (wz.solved) return t === "sequence" ? undefined : false;
        if (!wz.armed) { if (t !== "sequence") { p.actionbar("&7Nothing happens... yet."); return false; } }
        switch (t) {
            case "sequence":
                if (!wz.armed) return false;
                RPG.schedule(1, function () { seqPress(run, at.id, at.i); });
                return undefined;     // the lever or button works as usual
            case "offering": {
                var need = c.item;
                if (!need) { p.actionbar("&7The altar wants nothing (set its item)"); return false; }
                if (!p.hasItem(need.id, c.count)) { p.actionbar("&7It wants " + DM.itemName(need.id) + (c.count > 1 ? " x" + c.count : "")); p.playSound("minecraft:block.stone.hit", 0.7, 0.6); return false; }
                if (c.take) p.takeItem(need.id, c.count);
                RPG.world.particle(ARENA, "minecraft:soul", x + 0.5, y + 1.1, z + 0.5, 10, 0.3, 0.02);
                solve(run, at.id);
                return false;
            }
            case "hidden": solve(run, at.id); return false;
            case "combo": {
                var cur = RPG.world.getBlock(ARENA, x, y, z).split("[")[0], i = wz.pal.indexOf(cur), nxt = wz.pal[(i + 1) % wz.pal.length];
                RPG.world.setBlock(ARENA, x, y, z, nxt);
                RPG.world.sound(ARENA, "minecraft:block.note_block.harp", x + 0.5, y + 0.5, z + 0.5, 0.7, 0.8 + 0.1 * ((i + 1) % wz.pal.length));
                if (wz.parts.every(function (q, j) { return RPG.world.getBlock(ARENA, q.x, q.y, q.z).split("[")[0] === wz.sol[j]; })) solve(run, at.id);
                return false;
            }
        }
        return undefined;
    }
    /** A lever or button of an in-order puzzle was used (a tick later, so its new state shows). */
    function seqPress(run, id, i) {
        var W = run.w, wz = W && W.puzzles[id];
        if (!wz || wz.solved) return;
        var q = wz.parts[i];
        if (RPG.world.blockProperty(ARENA, q.x, q.y, q.z, "powered") === "false") return;      // a lever switched back off
        if (i === wz.step) {
            wz.step++;
            RPG.world.sound(ARENA, "minecraft:block.note_block.bell", q.x + 0.5, q.y + 0.5, q.z + 0.5, 0.7, 0.8 + wz.step * 0.15);
            if (wz.step >= wz.parts.length) solve(run, id);
            return;
        }
        if (i < wz.step) return;
        // out of order: back to the start (levers go off again)
        wz.step = 0;
        if (wz.z.cfg.reset) RPG.schedule(6, function () {
            wz.parts.forEach(function (r) { if (/lever/.test(RPG.world.getBlock(ARENA, r.x, r.y, r.z)) && RPG.world.blockProperty(ARENA, r.x, r.y, r.z, "powered") === "true") RPG.world.setBlockProperty(ARENA, r.x, r.y, r.z, "powered", false); });
        });
        members(run).forEach(function (m) { m.playSound("minecraft:block.note_block.bass", 1, 0.5); m.actionbar("&cWrong order - it resets"); });
    }

    // ---- rooms in play ----
    function playerIn(run, wr, m) {
        var o = run.origin, x = Math.floor(m.x) - o.x, y = Math.floor(m.y) - o.y, z = Math.floor(m.z) - o.z;
        return inRoom(wr.r, x, y, z) || inRoom(wr.r, x, y + 1, z);
    }
    function roomCleared(run, wr) {
        if (!wr.spawners.length) return wr.ev.enter;
        return wr.spawners.every(function (k) { return run.fired[k] && !(run.alive[k] | 0); });
    }
    function setRoomEvent(run, id, ev) {
        var wr = run.w.rooms[id];
        if (wr.ev[ev]) return;
        wr.ev[ev] = true;
        sourceChanged(run, "r:" + id + ":" + ev, true);
        if (ev === "clear") {
            Object.keys(run.w.locked).forEach(function (k) {
                var lk = run.w.locked[k];
                if (lk.room !== id) return;
                delete run.w.locked[k];
                if (lk.wasOpen && run.byKey[k]) R().openDoor(run, run.byKey[k]);
            });
            Object.keys(run.w.puzzles).forEach(function (pid) { var wz = run.w.puzzles[pid]; if (wz.z.type === "room_clear" && wz.z.room === id && wz.armed) solve(run, pid); });
            if (wr.r.type !== "safe" && wr.spawners.length) members(run).forEach(function (m) { if (wr.inside[DM.uid(m)]) { m.title(" ", "&aRoom cleared"); m.playSound("minecraft:block.note_block.chime", 0.8, 1.2); } });
        }
    }
    function enterRoom(run, id, m) {
        var wr = run.w.rooms[id], r = wr.r;
        try { if (DM.hooks.roomEnter) DM.hooks.roomEnter(m, r, run); } catch (e) { }
        if (r.rules.music) m.playSound(r.rules.music, 1, 1);
        if (wr.ev.enter) return;
        wr.enteredAt = DM.tick();
        if (r.rules.lock && wr.spawners.length) {
            wr.doors.forEach(function (k) {
                var a = run.byKey[k];
                if (!a || run.w.locked[k]) return;
                var open = run.doorState[k] === "open";
                run.w.locked[k] = { room: id, wasOpen: open };
                if (open) R().closeDoor(run, a);
            });
            if (wr.doors.length) members(run).forEach(function (q) { if (wr.inside[DM.uid(q)] || q === m) { q.playSound("minecraft:block.iron_door.close", 1, 0.6); q.actionbar("&cThe doors slam shut!"); } });
        }
        Object.keys(run.w.puzzles).forEach(function (pid) { var wz = run.w.puzzles[pid]; if (wz.z.type === "survive" && wz.z.room === id && wz.z.cfg.start === "enter" && wz.armed && !wz.startAt) wz.startAt = DM.tick(); });
        setRoomEvent(run, id, "enter");
    }
    /** Every 10 ticks (runs with rooms, block sources, plates or checkpoints): who is where, timers, waves, sources. */
    function tick(run, ps) {
        var W = run.w;
        if (!W) return;
        var t = DM.tick();
        Object.keys(W.rooms).forEach(function (id) {
            var wr = W.rooms[id], r = wr.r;
            ps.forEach(function (m) {
                var u = DM.uid(m), inside = playerIn(run, wr, m);
                if (inside && !wr.inside[u]) { wr.inside[u] = true; enterRoom(run, id, m); }
                else if (!inside && wr.inside[u]) { delete wr.inside[u]; try { if (DM.hooks.roomLeave) DM.hooks.roomLeave(m, r, run); } catch (e) { } }
            });
            if (!wr.ev.enter) return;
            // waves: when every spawner of the room is down, they come again until the waves are done
            if (!wr.ev.clear && r.rules.waves > 1 && wr.spawners.length && roomCleared(run, wr) && wr.wave < r.rules.waves) {
                wr.wave++;
                wr.spawners.forEach(function (k) { var a = run.byKey[k]; if (!a || a.type !== "spawner") return; run.fired[k] = false; run.node[k].on = false; R().fire(run, a); });
                ps.forEach(function (m) { if (wr.inside[DM.uid(m)]) m.title(" ", "&cWave " + wr.wave + " / " + r.rules.waves); });
            } else if (!wr.ev.clear && roomCleared(run, wr)) setRoomEvent(run, id, "clear");
            if (r.rules.timer > 0 && !wr.ev.timer) {
                var left = Math.ceil((wr.enteredAt + r.rules.timer * 20 - t) / 20);
                if (left <= 0) setRoomEvent(run, id, "timer");
                else if (!wr.ev.clear) ps.forEach(function (m) { if (wr.inside[DM.uid(m)]) m.actionbar("&e" + r.name + ": &f" + DM.clock(left)); });
            }
            if (r.rules.ambience && t >= wr.ambAt) { wr.ambAt = t + r.rules.ambEvery * 20; ps.forEach(function (m) { if (wr.inside[DM.uid(m)]) m.playSound(r.rules.ambience, 0.8, 1); }); }
        });
        // survive timers
        Object.keys(W.puzzles).forEach(function (pid) {
            var wz = W.puzzles[pid];
            if (wz.solved || wz.z.type !== "survive" || !wz.startAt) return;
            var left = Math.ceil((wz.startAt + wz.z.cfg.seconds * 20 - t) / 20), wr = W.rooms[wz.z.room];
            if (left <= 0) { if (ps.length) solve(run, pid); return; }
            ps.forEach(function (m) { if (!wr || wr.inside[DM.uid(m)]) m.actionbar("&cSurvive: &f" + DM.clock(left)); });
        });
        // pressure plate puzzles and checkpoints
        if (W.plates || W.checkpoints) Object.keys(W.puzzles).forEach(function (pid) {
            var wz = W.puzzles[pid];
            if (wz.solved || !wz.armed) return;
            if (wz.z.type === "plates") {
                var down = wz.parts.map(function (q) { return readBlock({ x: q.x, y: q.y, z: q.z, io: "plate" }); });
                down.forEach(function (v, i) { if (v && !wz.seen[i]) { wz.seen[i] = true; RPG.world.sound(ARENA, "minecraft:block.note_block.bell", wz.parts[i].x + 0.5, wz.parts[i].y + 0.5, wz.parts[i].z + 0.5, 0.6, 1.2); } });
                if (wz.parts.length && (wz.z.cfg.mode === "each" ? wz.parts.every(function (q, i) { return wz.seen[i]; }) : down.every(function (v) { return v; }))) solve(run, pid);
                if (wz.z.cfg.mode === "all") down.forEach(function (v, i) { if (!v) wz.seen[i] = false; });
            } else if (wz.z.type === "checkpoint") {
                var q = wz.parts[wz.step];
                if (!q) return;
                ps.forEach(function (m) {
                    if (wz.parts[wz.step] !== q) return;
                    if (Math.abs(m.x - q.x - 0.5) < 1.2 && Math.abs(m.z - q.z - 0.5) < 1.2 && m.y >= q.y + 0.5 && m.y < q.y + 2.5) {
                        wz.step++;
                        if (wz.z.cfg.respawn) ps.forEach(function (o2) { W.respawn[DM.uid(o2)] = { x: q.x + 0.5, y: q.y + 1, z: q.z + 0.5, yaw: m.yaw }; });
                        m.playSound("minecraft:block.note_block.pling", 0.8, 0.9 + wz.step * 0.1);
                        m.actionbar("&aCheckpoint " + wz.step + " / " + wz.parts.length);
                        RPG.world.particle(ARENA, "minecraft:totem_of_undying", q.x + 0.5, q.y + 1.5, q.z + 0.5, 12, 0.4, 0.1);
                        if (wz.step >= wz.parts.length) solve(run, pid);
                    }
                });
            }
        });
        // levers, buttons, plates and redstone at link sources
        W.blockSrc.forEach(function (b) { var v = readBlock(b); if (v !== W.src[b.key]) sourceChanged(run, b.key, v); });
    }
    /** After the modules' signals settle: module sources of links that changed. */
    function afterPropagate(run) {
        var W = run.w;
        if (!W) return;
        W.links.forEach(function (l) { if (l.from.k === "a") { var k = epKey(l.from), v = srcValue(run, l.from); if (W.src[k] !== v) sourceChanged(run, k, v); } });
    }
    function mobDied(run, a) {
        var W = run.w;
        if (!W) return;
        Object.keys(W.rooms).forEach(function (id) { var wr = W.rooms[id]; if (wr.ev.enter && !wr.ev.clear && wr.spawners.indexOf(a.key) >= 0 && roomCleared(run, wr) && !(wr.r.rules.waves > 1 && wr.wave < wr.r.rules.waves)) setRoomEvent(run, id, "clear"); });
    }
    function isLocked(run, key) { return !!(run.w && run.w.locked[key]); }
    function noBuild(run, x, y, z) {
        var W = run.w;
        if (!W) return false;
        var o = run.origin;
        return Object.keys(W.rooms).some(function (id) { var r = W.rooms[id].r; return r.rules.noBuild && inRoom(r, x - o.x, y - o.y, z - o.z); });
    }
    function respawnFor(run, p) { return run.w ? run.w.respawn[DM.uid(p)] || null : null; }
    /** Goal progress for the puzzle and room goals (0 or 1). */
    function goal(run, o) {
        var W = run.w;
        if (!W) return 0;
        if (o.type === "puzzle") return W.puzzles[o.puzzle] && W.puzzles[o.puzzle].solved ? 1 : 0;
        if (o.type === "room_clear") return W.rooms[o.room] && W.rooms[o.room].ev.clear ? 1 : 0;
        if (o.type === "room_enter") return W.rooms[o.room] && W.rooms[o.room].ev.enter ? 1 : 0;
        return 0;
    }

    // rewards and room hooks other addons can replace
    DM.hooks.giveXp = DM.hooks.giveXp || function (p, n) { p.addXpPoints(n); };
    DM.hooks.giveMoney = DM.hooks.giveMoney || function (p, n) { p.addMoney(n); };
    DM.hooks.roomEnter = DM.hooks.roomEnter || null;
    DM.hooks.roomLeave = DM.hooks.roomLeave || null;

    return {
        ITEM: ITEM, WANDS: WANDS, ROOM_TYPES: ROOM_TYPES, PUZZLE_TYPES: PUZZLE_TYPES, get: get, put: put, forget: forget, store: store, copyBox: copyBox, boundsRel: boundsRel,
        sendTo: sendTo, give: give, heldWand: heldWand, cleanObjectives: cleanObjectives, rewardText: rewardText, reward: reward,
        activate: activate, tick: tick, afterPropagate: afterPropagate, mobDied: mobDied, partClicked: partClicked, isLocked: isLocked, noBuild: noBuild,
        respawnFor: respawnFor, goal: goal, inRoom: inRoom, roomBox: roomBox
    };
})();
