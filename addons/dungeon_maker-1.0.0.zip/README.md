# Dungeon Maker

Build dungeons in game, Zelda style: staff lay them out on private plots in the workshop dimension with
**module blocks**, publish them, and every player or party plays its own copy in a throwaway arena.
Art: the `dungeonpack` art pack (asked for automatically; 1.1.0 or newer for the puzzle modules and items).

## Playing

- **O** (or the Dungeons button in the inventory, or `/dungeons`) opens the Dungeon Selection menu. Party
  members near you come along into the same run.
- Module blocks never show in a run. Doors are the blocks the builder placed (iron bars, a wall, planks...):
  **right-click the door itself** to open it.
- **Small Key** / **Boss Key**: found in chests or dropped by mobs. They belong to that run only (keys from
  anywhere else vanish, leaving the run takes them) and are **shared by the party**: a locked door or chest
  takes a Small Key from whoever clicks it, else from any other member in the run. The Boss Key opens the
  big chest (kept) and the boss door, which uses it up like a Small Key (the setting `bossKeyUsedUp`; once it is
  turned in, the big chest opens without it). The tracker shows how many keys the party holds.
- **Recovery Heart** heals when picked up; **Heart Container** (bosses) heals fully.
- **Dungeon Compass** (found in a run like the keys): held, it points the way (action bar) to the boss, then the
  next puzzle or room goal, then the exit; with it the map also shows the boss and the chests.
- **Dungeon Map**: right-click for the layout of the floor you are on (from the painted map; rooms made with the
  Room Wand are outlined). Where the party has been is bright, the rest dim; you, your party, the entry and exit
  are marked. Compass and map belong to their run and vanish when you leave, like the keys.
- Puzzle tools (work inside runs only): **Dungeon Bow** (hits crystal and eye switches), **Bomb** (thrown,
  breaks Cracked Dungeon Bricks), **Grapple Claw** (pulls you to a Grapple Target), **Dungeon Lantern**
  (lights torch switches). **Push Blocks** move one block when right-clicked and press floor switches.

## Building (staff: operators or `dungeonmaker.admin`)

**Small Key Door** and **Boss Door** (in the Anchors kit) are 2-block-tall door blocks: place the lower half and the
upper half comes with it; put them in a small key / boss key door's zone. The painter builds painted small key and
boss key doors with them.

Admin > **+ New** (or `/dungeons create <name>`) makes a dungeon and its plot. **Anchors** (`/dungeons anchors`)
gives every module block plus Cracked Bricks, Grapple Targets and Push Blocks; `/dungeons kit` gives the
dungeon items to test with. Right-click a module to set it up; the plain Dungeon Anchor asks what to become.

| Module | What it does in a run |
|---|---|
| Mob Spawner | Spawns mob groups (radius, right-click, redstone or a linked signal). **Drops**: a list of items, each with its own % chance and count, rolled for every mob it spawned. Signals its links once every mob is down. |
| Boss Spawner | Any mob, script mob/NPC or script boss; boss name, boss bar, **arena lock** (nobody inside leaves until it falls), drops, Heart Container. Signals its links when beaten. |
| Entry / Exit Point | Where players appear / where the run ends once the goals are met. |
| Key Door | Its **zone** (a radius round the module, or two markers; optionally only some kinds of block) is the door; it opens for a key item you choose. |
| Small Key Door / Boss Key Door | The same, opened with a Small Key / the Boss Key (both used up). |
| Puzzle Door | Opens when a linked signal powers it (optionally closes again when it stops). |
| Loot Chest / Small Key Chest / Big Key Chest | A chest with a loot table (27 slots, each with a chance); locked ones need a Small Key / the Boss Key. |
| Puzzle Chest | Appears (with its loot) when a linked signal powers it. |
| Switch | Lever, floor switch, crystal switch, eye switch (bow only) or torch (lantern); toggle, stays on, timed or only while held. |
| Logic Gate | AND, OR, XOR, NOT or a sequence (inputs in order; a wrong one resets them); can stay on once solved. |
| Bridge | Blocks in its zone appear (or vanish) on a signal. |

**Links**: switches, logic gates, spawners and bosses send their signal down their links (Links tab: a
searchable list, or *Pick in world* and right-click the target). The workshop draws every link as a line
and every door / bridge zone as a box. **Look** tab: what the module turns into in a run (*Auto*: built into
a wall or floor it takes the look of its neighbours, otherwise air; or any block).

Old dungeons keep working: Locked Doors made before zones use their two corners as the door (or, with no
corners, the module block itself), and keep their key item.

## Building wands

Admin > **Wands** (or `/dungeons wand <dungeon|room|puzzle|connection|all>`) gives four staff-only wands. They work on
a dungeon's workshop plot; what they mark shows (outlines, labels, lines) only while one is held, and the hint line
above the hotbar says what the buttons do. **Right-click the air** with a wand for its screen; **?** there explains it.
Every click goes to the server, which checks staff rights, the plot, ids and limits.

- **Dungeon Wand**: left click a block = corner 1, right click = corner 2 of the dungeon's **bounds**; sneak + wheel
  (or + / -) moves the face you look at. The size shows above the hotbar. The bounds are what runs copy and Export
  writes; the painter starts new maps at their size and place (Map > *Fit to bounds*) and its Import only reads inside
  them. Its screen: exact numbers, *Fit to build*, *Whole plot*, *Clear*.
- **Room Wand**: the same selection for **rooms** (Box mode: two corners; Sphere mode: a centre and a point on the
  edge). Rooms list: *+ New* from the selection, name, type (combat, puzzle, trap, treasure, boss, safe), *Use
  selection* to resize, delete; sneak + right-click inside a room selects it. Rules: **lock the doors until cleared**
  (door modules in or next to the room close when a player walks in and open when its spawners' mobs are down),
  **spawn waves**, a **timer** (its end is a room event), **no building**, **music** on entering and repeating
  **ambience** (addons can also use `DungeonMaker.hooks.roomEnter` / `roomLeave`). Rooms show over the painter's map.
- **Puzzle Wand**: right-click a block for its puzzle (a module: its own setup screen; any other block: a new puzzle
  with it, or add it to one), the air for a puzzle node (logic), sneak + the air for the list. Types: levers / buttons
  **in order** (a wrong one resets them), **pressure plates** (all at once or each once), **item offering**, **defeat
  everything in a room**, **survive a timer**, **hidden switch**, **parkour checkpoints** (they set where players
  respawn), **colour / symbol combination** (build the solution; runs scramble it, right-click cycles a block) and
  **logic node** (AND / OR of its inputs). *Add in world* makes every block you right-click a part. **Rewards** when
  solved: XP, money, an item (from your hand), a chest module's loot; **Opens / triggers**: links to doors, bridges,
  spawners, chests and other puzzles. The **Goals** tab is the card's completion goals plus *solve a puzzle*, *clear a
  room* and *reach a room*, each goal with its own rewards (given the moment it is done).
- **Connection Wand**: right-click a **source**, then a **target**; sneak + right-click an end removes its newest link,
  left click cancels. Sources: switches, logic gates, spawners (all down), bosses, puzzles, room events (enter, cleared,
  timer), levers, buttons, pressure plates, redstone reaching a block. Targets: doors (any kind), bridges, spawners and
  bosses on *signal*, chests, logic gates, puzzles, and blocks: **wireless redstone** (an invisible signal next to the
  block powers it: lamps, pistons, doors), doors and trapdoors open, campfires and candles light. Link options: **NOT**,
  **Delay**, **Pulse**, **Toggle**; AND / OR through a Logic Gate module or a logic node. A plain module-to-module link
  is the module's own link (its Links tab shows it). Its screen lists every link and adds them from lists.

In a run, links are worked out when a source changes (never polled), at most 64 a tick; levers, plates, redstone at
sources, rooms and checkpoints are read every 10 ticks, only in runs that have them. Rooms, puzzles and links are saved
with the dungeon (`dmk_lay_<id>`) and go into its export; **Import** (Admin, on an exported dungeon, or `/dungeons
import <id>`) makes an editable copy with its own plot. Regenerating in the painter keeps them: positions stay, and a
link to a painted module still works when the module comes back on the same cell.

## Dungeon painter

Admin > **Paint** (or `/dungeons paint <id>`) paints a dungeon as a top-down map and builds it into its workshop plot.
One cell is one block column (up to 128 x 128, never past the plot); floors are layers with their own level, wall
height and ceiling, and the floor below shows faded. Press **?** in the painter for every shortcut.

- **Tiles:** floor, wall, empty, pit, doorway, locked door, chest, mob spawner, boss spawner, entry, exit, stairs up,
  stairs down (landing), pillar, light, water, lava, decoration.
- **Tools:** pencil (B), eraser (E), line (L), rectangle (U, Shift+U filled), room (R: floor with walls round it; walls
  only go on empty cells, so rooms merge), corridor (C: an L-shaped passage with walls along it, `[` `]` width), bucket
  (G), picker (I), select (M: move, Ctrl+C/X/V, Del, Shift+H/V flip, Shift+R rotate), mirror X / Y, undo / redo, wheel
  zoom, middle or Space drag to pan.
- **Modules:** click a door, chest, spawner, boss, entry or exit with the picker or select tool and press **Set up**:
  the same screen the workshop block opens (mobs, drops, loot items, key, links, look). Doors and chests pick their kind
  there (small key, boss key, key item, puzzle). A painted door's zone is the painted doorway.
- **Stairs:** draw *stairs up* as a straight line on the lower floor, one cell per block the next floor is higher, and
  a *stairs down* landing on the floor above right after the top end. Paint the floor above over the top four stair
  cells: the stairwell opens there.
- **Theme:** Stone Brick, Deepslate, Sandstone Temple, Nether Fortress and Prismarine presets, or any block for floor,
  wall, ceiling, pillar, light, stairs, door and decoration.
- **Generate / Regenerate** saves and checks the map (exactly one entry, at least one exit, stairs that connect), keeps
  the painted area for **Undo build**, clears it and builds floor by floor through the budgeted block editor, then the
  stairs and the module blocks with their settings. Modules the painter can't draw (switches, logic gates, bridges)
  stay where they are. Staff standing in the area are moved to the entry point.
- **Import** reads the plot's build back into a map (floors, walls, doorways, stairs, lights, hazards, pillars, modules
  with their settings; best effort).
- The map is kept with the dungeon and goes into its export. Everything is checked again on the server: staff only,
  sizes, tiles, allowed blocks (no command blocks, barriers or module blocks), plot bounds and module settings.

## Settings

`/rpg config dungeon_maker`: plot size, arena slots, party entry, PvP and block editing in runs,
`bossKeyUsedUp` (the boss door takes the Boss Key; false keeps it all run), `recoveryHeartPercent`, `heartContainerBonus` (lasting max health, 0 = heal only), `bombDamage`, `logDrops`
(write every drop roll to the log). Other addons hook in through `DungeonMaker.hooks` (level, party,
completion rewards, entry checks, `heal` / `addMaxHealth` for games with their own health).

## Credits

Dungeon wands, keys, doors, compass and map art by Kiba (ikiba_) (in the addon's own
`resources/assets/dungeon_maker`). The rest of the art is the dungeonpack art pack.
