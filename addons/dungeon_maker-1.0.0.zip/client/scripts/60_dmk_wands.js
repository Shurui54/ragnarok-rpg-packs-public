// =====================================================================================
//  Dungeon Maker (client) - the building wands: outlines, lines, clicks and their screens
// =====================================================================================
//  While a wand is held on a dungeon's workshop plot this draws (client side only, from data the server
//  sends once and on change): the dungeon's bounds (Dungeon Wand), the rooms as coloured outlines with
//  labels and the wand's selection (Room Wand), puzzle parts and nodes (Puzzle Wand), and the wireless
//  links as lines (Connection Wand). Wand clicks never break or use blocks: they go to the server as
//  intents ("dmk_wand"), which ray-casts, checks and answers. Sneak + wheel (or + / -) moves the face of
//  the bounds or the selection you look at. Right-clicking the air opens the wand's screen; each screen
//  has a ? overlay that explains it. The data lives on the server (scripts/35_dungeon_maker_wands.js).
// =====================================================================================
var DMK_WANDS = (function () {
    var U = DMK_UI, WS = "ragnarok_rpg:dungeon_workshop";
    var D = null, SEL = {}, held = null, dirty = true, drawn = { boxes: 0 }, lastSend = 0;
    var NAMES = { dungeon: "Dungeon Wand", room: "Room Wand", puzzle: "Puzzle Wand", connection: "Connection Wand" };
    var COLORS = { dungeon: "#E8C860", room: "#60D0FF", puzzle: "#D070FF", connection: "#FF6060" };
    // the wands' item ids (script items get pooled ids, so the server says which they are)
    var IDS = null, idsAsked = 0;
    RPG.net.on("dmk_wids", function (m) { IDS = {}; Object.keys(m || {}).forEach(function (w) { IDS[String(m[w])] = w; }); dirty = true; });
    function wandOf(id) { return IDS ? IDS[String(id || "").split("[")[0]] || null : null; }
    function onWorkshop() { return RPG.player.present && RPG.player.dimension === WS; }
    function send(op, data) { var m = data || {}; m.op = op; RPG.net.send("dmk_wand", m); }
    function clone(o) { return JSON.parse(JSON.stringify(o)); }

    // ---- data from the server ----
    U.onBig("wdata", function (d) { D = d; if (d.sel) SEL = d.sel; dirty = true; });
    RPG.net.on("dmk_wnone", function () { D = null; dirty = true; });
    RPG.net.on("dmk_wsel", function (s) { SEL = s || {}; dirty = true; });
    RPG.net.on("dmk_wsaved", function (m) { var S = U.state(); if (S && S.view === "w_puzzles" && m && m.puzzle) { S.selId = m.puzzle; S.e = null; S.pendingPart = null; S.pendingNode = null; } });

    // ---- drawing while a wand is held ----
    function W(v) { return [D.origin[0] + v[0], D.origin[1] + v[1], D.origin[2] + v[2]]; }
    function box(id, b, color, alpha, extra) {
        RPG.world.box(id, D.origin[0] + b.x1, D.origin[1] + b.y1, D.origin[2] + b.z1, D.origin[0] + b.x2, D.origin[1] + b.y2, D.origin[2] + b.z2, color, { alpha: alpha, maxDistance: 192, grid: extra || 0 });
        drawn.boxes = Math.max(drawn.boxes, (Number(id.substring(6)) || 0) + 1);
    }
    var BOXN = 0;
    function nbox(b, color, alpha, grid) { if (BOXN >= 180) return; box("dmk_wb" + (BOXN++), b, color, alpha, grid); }
    function label(id, x, y, z, text, scale) { RPG.world3d.text("dmk_wt" + id, { x: x, y: y, z: z, text: text, scale: scale || 1, seeThrough: true, maxDistance: 128, background: "#000000", dimension: WS }); }
    function line(id, a, b, color, width) { RPG.world3d.line("dmk_wl" + id, { from: a, to: b, width: width || 0.06, color: color, alpha: 0.9, seeThrough: true, dimension: WS }); }
    function dot(id, p, color, size) { RPG.world3d.billboard("dmk_wd" + id, { x: p[0], y: p[1], z: p[2], size: size || 0.3, color: color, alpha: 0.95, seeThrough: true, dimension: WS }); }
    var LN = 0;
    function circle(c, r, color, axis) {
        var n = 24, prev = null;
        for (var i = 0; i <= n; i++) {
            var a = i / n * Math.PI * 2, ca = Math.cos(a) * r, sa = Math.sin(a) * r;
            var p = axis === "y" ? [c[0] + ca, c[1], c[2] + sa] : axis === "x" ? [c[0], c[1] + ca, c[2] + sa] : [c[0] + ca, c[1] + sa, c[2]];
            if (prev) line(LN++, prev, p, color, 0.05);
            prev = p;
        }
    }
    function sphere(c, r, color) { var w = [D.origin[0] + c[0] + 0.5, D.origin[1] + c[1] + 0.5, D.origin[2] + c[2] + 0.5]; circle(w, r + 0.5, color, "y"); circle(w, r + 0.5, color, "x"); circle(w, r + 0.5, color, "z"); }
    function clear() {
        for (var i = 0; i < 200; i++) RPG.world.removeBox("dmk_wb" + i);
        try { RPG.world3d.removePrefix("dmk_wt"); RPG.world3d.removePrefix("dmk_wl"); RPG.world3d.removePrefix("dmk_wd"); } catch (e) { }
    }
    function boxOf(c1, c2) { return { x1: Math.min(c1[0], c2[0]), y1: Math.min(c1[1], c2[1]), z1: Math.min(c1[2], c2[2]), x2: Math.max(c1[0], c2[0]), y2: Math.max(c1[1], c2[1]), z2: Math.max(c1[2], c2[2]) }; }
    function selRadius() { return SEL.c1 && SEL.c2 ? Math.max(1, Math.round(Math.sqrt(Math.pow(SEL.c2[0] - SEL.c1[0], 2) + Math.pow(SEL.c2[1] - SEL.c1[1], 2) + Math.pow(SEL.c2[2] - SEL.c1[2], 2)))) : 4; }
    function topOf(b) { return [D.origin[0] + (b.x1 + b.x2 + 1) / 2, D.origin[1] + b.y2 + 1.6, D.origin[2] + (b.z1 + b.z2 + 1) / 2]; }
    function redraw() {
        clear();
        BOXN = 0; LN = 0;
        if (!held || !D || !onWorkshop()) return;
        var i = 0;
        if (held === "dungeon") {
            if (D.bounds) { nbox(D.bounds, "#E8C860", 0.95, 8); var t = topOf(D.bounds); label("b", t[0], t[1], t[2], "&6Dungeon bounds\n&f" + size(D.bounds), 1.3); }
        }
        if (held === "room" || held === "puzzle") {
            if (D.bounds) nbox(D.bounds, "#8A7A50", 0.35);
            D.rooms.forEach(function (r) {
                var sel = SEL.room === r.id, a = held === "room" ? (sel ? 1 : 0.75) : 0.35;
                if (r.shape === "sphere" && i < 10) { sphere(r.c, r.r, r.color); i++; }
                else nbox(r.box, r.color, a);
                var t = topOf(r.box);
                if (held === "room") label("r" + r.id, t[0], t[1], t[2], (sel ? "&e> " : "") + "&l" + r.name + "\n&7" + r.type + (r.shape === "sphere" ? " · r " + r.r : " · " + size(r.box)), 1.1);
            });
            if (held === "room" && SEL.c1) {
                if (SEL.mode === "sphere") { sphere(SEL.c1, selRadius(), "#FFFFFF"); var c = W(SEL.c1); label("sel", c[0] + 0.5, c[1] + 1.8, c[2] + 0.5, "&fSelection: sphere r " + selRadius(), 1); }
                else if (SEL.c2) { var sb = boxOf(SEL.c1, SEL.c2), st = topOf(sb); nbox(sb, "#FFFFFF", 1); label("sel", st[0], st[1] + 0.6, st[2], "&fSelection " + size(sb), 1); }
            }
        }
        if (held === "puzzle" || held === "connection") {
            D.puzzles.forEach(function (z) {
                var c = held === "puzzle" ? (SEL.puzzle === z.id ? "#FFFFFF" : "#D070FF") : "#9060C0";
                z.parts.forEach(function (q, j) {
                    nbox({ x1: q[0], y1: q[1], z1: q[2], x2: q[0], y2: q[1], z2: q[2] }, c, held === "puzzle" ? 0.95 : 0.5);
                    if (held === "puzzle" && (z.type === "sequence" || z.type === "checkpoint")) { var w = W(q); label("pn" + z.id + "_" + j, w[0] + 0.5, w[1] + 1.35, w[2] + 0.5, "&d" + (j + 1), 0.8); }
                });
                var at = z.node || z.parts[0];
                if (!at) return;
                var w2 = W(at);
                if (z.node) dot("n" + z.id, [w2[0] + 0.5, w2[1] + 0.5, w2[2] + 0.5], "#D070FF", 0.45);
                if (held === "puzzle" || z.node) label("p" + z.id, w2[0] + 0.5, w2[1] + (z.node ? 1.1 : 1.8), w2[2] + 0.5, "&d" + z.name + "\n&7" + (D.types.puzzleNames[z.type] || z.type), 0.9);
            });
        }
        if (held === "connection") {
            D.links.forEach(function (l, j) {
                if (l.module || !l.a || !l.b) return;
                line("k" + j, l.a, l.b, l.c, 0.06);
                dot("k" + j, [l.b[0], l.b[1] + 0.55, l.b[2]], l.c, 0.22);
                var mx = (l.a[0] + l.b[0]) / 2, my = (l.a[1] + l.b[1]) / 2 + 0.4, mz = (l.a[2] + l.b[2]) / 2;
                if (l.op !== "direct") label("k" + j, mx, my, mz, "&f" + l.op.toUpperCase() + (l.time ? " " + l.time + "s" : ""), 0.8);
            });
            D.rooms.forEach(function (r) { var t = topOf(r.box); label("r" + r.id, t[0], t[1], t[2], "&7" + r.name, 0.8); });
            if (SEL.src) {
                var e = SEL.src, p = e.k === "b" ? e.pos : e.k === "a" ? e.key.split(",").map(Number) : null;
                if (p) nbox({ x1: p[0], y1: p[1], z1: p[2], x2: p[0], y2: p[1], z2: p[2] }, "#FF4040", 1);
            }
        }
    }
    function size(b) { return (b.x2 - b.x1 + 1) + " x " + (b.y2 - b.y1 + 1) + " x " + (b.z2 - b.z1 + 1); }

    RPG.on("tick", function () {
        if (!IDS && RPG.player.present && RPG.nowMs() - idsAsked > 5000) { idsAsked = RPG.nowMs(); send("ids"); }
        var h = wandOf(RPG.player.heldItem);
        if (h && !onWorkshop()) h = null;
        if (h !== held) {
            if (h && !held && !D) send("data");          // first time a wand comes out on this plot
            held = h; dirty = true;
        }
        if (dirty) { dirty = false; try { redraw(); } catch (e) { RPG.log("[Dungeon Maker] wand outlines: " + e); } }
    });
    RPG.on("dimensionChange", function () { D = null; SEL = {}; dirty = true; });

    // ---- clicks, the wheel and + / - ----
    RPG.on("interact", function (kind, target, hand) {
        if (!held || kind === "pick") return;
        if (hand !== "main") return false;
        var t = RPG.nowMs();
        if (t - lastSend < 220) return false;          // "use" repeats while held
        lastSend = t;
        send("click", { wand: held, button: kind === "attack" ? "left" : "right", sneak: !!RPG.player.sneaking });
        return false;
    });
    RPG.on("scroll", function (delta) {
        if ((held === "dungeon" || held === "room") && RPG.player.sneaking && !RPG.screen.getOpen()) { send("nudge", { dir: delta > 0 ? 1 : -1 }); return false; }
    });
    RPG.on("key", function (name, state) {
        if (state !== "down" || (held !== "dungeon" && held !== "room") || RPG.screen.getOpen()) return;
        if (name === "key.keyboard.equal" || name === "key.keyboard.keypad.add") send("nudge", { dir: 1 });
        else if (name === "key.keyboard.minus" || name === "key.keyboard.keypad.subtract") send("nudge", { dir: -1 });
    });

    // ---- the hint line above the hotbar while a wand is held ----
    RPG.hud.onRender(function (ctx) {
        if (!held || RPG.screen.getOpen()) return;
        var txt = "", sub = "";
        if (!D) { txt = NAMES[held] + ": stand on a dungeon's plot"; }
        else if (held === "dungeon") { txt = D.bounds ? "Bounds " + size(D.bounds) : "No bounds yet: the whole plot"; sub = "L: corner 1  R: corner 2  Sneak+wheel / + -: move a face  R on air: screen"; }
        else if (held === "room") {
            txt = SEL.c1 ? (SEL.mode === "sphere" ? "Selection: sphere r " + selRadius() : SEL.c2 ? "Selection " + size(boxOf(SEL.c1, SEL.c2)) : "Corner 1 set") : "Rooms: " + D.rooms.length;
            sub = (SEL.mode === "sphere" ? "L: centre  R: radius" : "L: corner 1  R: corner 2") + "  Sneak+R: select room  R on air: rooms";
        } else if (held === "puzzle") {
            var z = null; D.puzzles.forEach(function (q) { if (q.id === SEL.puzzle) z = q; });
            txt = z ? "Adding parts to " + z.name + " (" + z.parts.length + ")" : "Puzzles: " + D.puzzles.length;
            sub = z ? "R: add / remove a block  R on air: done" : "R block: its puzzle / new  R air: node  Sneak+R air: list";
        } else {
            txt = SEL.src ? "Source picked: right-click the target" : "Links: " + D.links.length;
            sub = SEL.src ? "L: cancel" : "R: source, then target  Sneak+R: remove  R on air: links";
        }
        var y = ctx.height - 96;          // above the action bar and the item name
        U.text(ctx, txt, ctx.width / 2, y, COLORS[held], "center");
        if (sub) U.text(ctx, sub, ctx.width / 2, y + 10, "#C8C8C8", "center", 0.75);
    });

    // =================================================================================
    //  Screens
    // =================================================================================
    U.onBig("wscreen", function (m) {
        if (!m) return;
        if (!D) { send("data"); RPG.schedule(10, function () { if (D) openView(m); }); return; }
        openView(m);
    });
    function openView(m) {
        if (m.view === "bounds") openBounds();
        else if (m.view === "rooms") openRooms(m.room);
        else if (m.view === "puzzles") openPuzzles(m);
        else if (m.view === "links") openLinks();
    }
    var HELP = {
        bounds: { title: "Dungeon Wand", lines: [
            "• Left click a block: corner 1. Right click a block: corner 2. The box shows while you hold the wand, with its size above the hotbar.",
            "• Sneak + mouse wheel (or + and -): the face you look at moves out or in by one block.",
            "• The bounds are what a run copies into its arena and what Export writes. The painter starts new maps at their size and place, and Import (in the painter) only reads inside them.",
            "• Bounds never reach past the plot. Clear them to use the whole plot again."] },
        rooms: { title: "Room Wand", lines: [
            "• Box mode: left click corner 1, right click corner 2. Sphere mode: left click the centre, right click a point on its edge. Sneak + wheel (or + / -) moves the face you look at (sphere: the radius).",
            "• Right-click the air for this list. + New makes a room from the selection; Use selection resizes the picked one. Sneak + right-click inside a room picks it and loads its shape.",
            "• Types: combat, puzzle, trap, treasure, boss, safe. Rules: lock the doors until cleared, spawn waves, a timer, no building, music and ambience.",
            "• Rooms show as coloured outlines with their names while you hold the wand, and over the painter's map."] },
        puzzles: { title: "Puzzle Wand", lines: [
            "• Right-click a block: the puzzle it belongs to; a module: its own setup screen; any other block: start a puzzle with it (or add it to one). Right-click the air: a puzzle node there (for logic). Sneak + right-click the air: this screen.",
            "• Add parts in world: every block you right-click joins the puzzle (again: it leaves); right-click the air when done.",
            "• Types: levers / buttons in order, pressure plates, item offering, defeat everything in a room, survive a timer, hidden switch, parkour checkpoints, colour or symbol combination, logic node.",
            "• Rewards go to the party when it is solved: XP, money, an item, a chest module's loot. Opens / triggers: doors, bridges, spawners, chests and other puzzles it powers (more with the Connection Wand).",
            "• Goals: the dungeon's completion goals (also on its card): solve puzzles, clear or reach rooms, defeat enemies, each with its own rewards."] },
        links: { title: "Connection Wand", lines: [
            "• Right-click a source, then a target. Sources: switches, logic gates, spawners (all their mobs down), bosses, puzzles (solved), room events (enter, cleared, timer), levers, buttons, pressure plates, or redstone reaching a block.",
            "• Targets: puzzle doors and other doors, bridges, spawners and bosses set to 'signal', chests, logic gates, puzzles, and blocks: a lamp or any block gets a wireless redstone signal, doors and trapdoors open, campfires and candles light.",
            "• Sneak + right-click an end: removes its newest link. Left click: cancels a picked source. Lines show while you hold the wand.",
            "• Options: NOT (on while the source is off), Delay (seconds later), Pulse (on for a few seconds), Toggle (each new signal flips it). AND / OR: link into a Logic Gate module or a Puzzle Wand logic node.",
            "• A plain module-to-module link is the module's own link (its Links tab shows it too)."] }
    };
    /** A screen's draw with its ? overlay: while the overlay shows only it is drawn (the engine's text boxes and lists would sit on top). */
    function withHelp(S, key, draw) {
        return function (ctx) {
            if (S.help && D) { drawHelp(ctx, S, HELP[key].title, HELP[key].lines); return; }
            draw(ctx);
        };
    }
    function centred(ctx, w, h) { return { x: Math.floor((ctx.width - w) / 2), y: Math.floor((ctx.height - h) / 2) + 4 }; }
    function note(ctx, t, x, y, w, scale, color) { var s = scale || 0.75, l = U.wrap(ctx, t, w, s); l.forEach(function (ln, i) { U.text(ctx, ln, x, y + i * (10 * s + 1), color || "#A8A8A8", "left", s); }); return l.length * (10 * s + 1); }
    function helpButton(ctx, S, x, y) { U.button(ctx, "?", x, y, 14, 14, function () { S.help = !S.help; }, { tip: ["Help", "What this screen and its wand do"], selected: S.help }); }
    function drawHelp(ctx, S, title, lines) {
        if (!S.help) return;
        var w = Math.min(380, ctx.width - 20), x = Math.floor((ctx.width - w) / 2), body = [], h;
        lines.forEach(function (l) { U.wrap(ctx, l, w - 28, 0.8).forEach(function (q) { body.push(q); }); body.push(""); });
        h = 34 + body.length * 9 + 24;
        var y = Math.max(4, Math.floor((ctx.height - h) / 2));
        ctx.fill(0, 0, ctx.width, ctx.height, "#000000", 0.5);
        S.hits.length = 0;                         // the overlay takes every click
        U.panel(ctx, x, y, w, h, title);
        body.forEach(function (l, i) { U.text(ctx, l, x + 14, y + 18 + i * 9, l.charAt(0) === "•" ? "#E8E0C8" : "#C0C0C0", "left", 0.8); });
        U.button(ctx, "Got it", x + w / 2 - 40, y + h - 26, 80, 18, function () { S.help = false; });
    }
    function rowsList(ctx, S, key, x, y, w, h, rows) {
        var flat = [], yy = 0;
        rows.forEach(function (r) { flat.push({ r: r, y: yy }); yy += r.h; });
        var total = yy;
        S.scroll[key] = U.clamp(S.scroll[key] || 0, 0, Math.max(0, total - h));
        var pos = S.scroll[key];
        S.lists.push({ key: key, x: x, y: y, w: w, h: h, total: total, step: 16 });
        ctx.clip(x, y, w, h);
        S.clipTop = y; S.clipBottom = y + h;
        var first = S.hits.length;
        flat.forEach(function (f) { var ry = y + f.y - pos; if (ry + f.r.h >= y && ry <= y + h) f.r.draw(ry); });
        S.clipTop = null; S.clipBottom = null;
        ctx.unclip();
        for (var k = S.hits.length - 1; k >= first; k--) { var hb = S.hits[k]; if (hb.y + hb.h <= y || hb.y >= y + h) S.hits.splice(k, 1); }
        if (total > h) { var th = Math.max(14, h * h / total); ctx.fill(x + w + 2, y, 3, h, "#000000", 0.4); ctx.fill(x + w + 2, y + (h - th) * pos / (total - h), 3, th, "#C9B57A", 1); }
    }
    function head(t, x, w, extra) { return { h: 18, draw: function (ry) { var ctx = U.state().ctx; U.text(ctx, t, x, ry + 6, "#E8C860"); ctx.fill(x, ry + 16, w, 1, "#6B5A33", 0.8); if (extra) extra(ry); } }; }
    function noData(ctx, S) { if (D) return false; var p = centred(ctx, 260, 80); U.panel(ctx, p.x, p.y, 260, 80, "Wands"); U.text(ctx, "Stand on a dungeon's plot", p.x + 130, p.y + 34, "#C0C0C0", "center"); return true; }

    // ---- Dungeon Wand: the bounds ----
    function openBounds() {
        var S = { view: "w_bounds", b: null, help: false };
        S.draw = function (ctx) {
            if (noData(ctx, S)) return;
            var w = 320, h = 214, p = centred(ctx, w, h), x = p.x, y = p.y;
            U.panel(ctx, x, y, w, h, "Dungeon Bounds");
            helpButton(ctx, S, x + w - 26, y + 8);
            var bd = D.bounds;
            if (!S.b || S.bKey !== JSON.stringify(bd)) { S.bKey = JSON.stringify(bd); S.b = bd ? clone(bd) : { x1: -16, y1: -1, z1: -16, x2: 16, y2: 15, z2: 16 }; U.resetElements(); }
            U.text(ctx, D.name, x + 16, y + 18, "#FFE9A8");
            U.text(ctx, bd ? "Size " + size(bd) + " blocks" : "No bounds: runs copy the whole plot (" + (D.half * 2 + 1) + " wide)", x + 16, y + 30, bd ? "#9FE09F" : "#FFB040", "left", 0.85);
            var cols = [["x1", "West x"], ["y1", "Bottom y"], ["z1", "North z"], ["x2", "East x"], ["y2", "Top y"], ["z2", "South z"]];
            cols.forEach(function (c, i) {
                var cx = x + 16 + (i % 3) * 98, cy = y + 46 + Math.floor(i / 3) * 26;
                U.text(ctx, c[1], cx, cy, "#B8B0A0", "left", 0.8);
                U.numField(ctx, "wb_" + c[0], cx, cy + 8, 60, S.b[c[0]], function (v) { if (v !== null) S.b[c[0]] = Math.round(v); }, { int: true });
            });
            note(ctx, "From the plot centre (the plot reaches " + D.half + " blocks each way; y " + D.ymin + " to " + D.ymax + "). Runs, export, import and the painter's map use the bounds.", x + 16, y + 100, w - 32);
            var by = y + 128;
            U.button(ctx, "Apply", x + 16, by, 90, 18, function () { send("bounds_set", { c1: [S.b.x1, S.b.y1, S.b.z1], c2: [S.b.x2, S.b.y2, S.b.z2] }); }, { kind: "green", tip: ["Set the bounds to these numbers"] });
            U.button(ctx, "Fit to build", x + 112, by, 90, 18, function () { send("bounds_fit"); }, { tip: ["Shrink the bounds to what is built on the plot"] });
            U.button(ctx, "Whole plot", x + 208, by, 96, 18, function () { send("bounds_plot"); }, { tip: ["The whole plot, 16 below to 48 above the platform"] });
            U.button(ctx, "Clear", x + 16, by + 22, 90, 18, function () { send("bounds_clear"); }, { kind: "red", tip: ["No bounds: runs copy everything built on the plot"] });
            U.button(ctx, "Close", x + w - 106, y + h - 28, 90, 20, function () { U.close(); });
        };
        S.draw = withHelp(S, S.view.substring(2), S.draw);
        S.back = function () { if (S.help) { S.help = false; return; } U.close(); };
        U.open(S);
    }

    // ---- Room Wand: the rooms list ----
    var MUSIC = ["minecraft:music.overworld.deep_dark", "minecraft:music.nether.basalt_deltas", "minecraft:music.nether.soul_sand_valley", "minecraft:music.end", "minecraft:music.dragon",
        "minecraft:music_disc.pigstep", "minecraft:music_disc.otherside", "minecraft:music_disc.5", "minecraft:music_disc.13", "minecraft:music_disc.11"];
    var AMBIENCE = ["minecraft:ambient.cave", "minecraft:ambient.basalt_deltas.mood", "minecraft:ambient.soul_sand_valley.mood", "minecraft:ambient.warped_forest.mood",
        "minecraft:ambient.crimson_forest.mood", "minecraft:ambient.underwater.loop", "minecraft:block.beacon.ambient", "minecraft:block.portal.ambient", "minecraft:entity.warden.heartbeat"];
    function soundOpts(list) { return [{ value: "", label: "None" }].concat(list.map(function (s) { return { value: s, label: s.replace(/^minecraft:/, "") }; })); }
    function roomById(id) { var f = null; (D ? D.rooms : []).forEach(function (r) { if (r.id === id) f = r; }); return f; }
    function openRooms(roomId) {
        var S = { view: "w_rooms", selId: roomId || null, e: null, help: false };
        S.draw = function (ctx) {
            if (noData(ctx, S)) return;
            var w = 480, h = 276, p = centred(ctx, w, h), x = p.x, y = p.y;
            U.panel(ctx, x, y, w, h, "Rooms");
            helpButton(ctx, S, x + w - 26, y + 8);
            // left: selection tools and the list
            var lx = x + 14, ly = y + 18, lw = 170;
            U.button(ctx, SEL.mode === "sphere" ? "Mode: Sphere" : "Mode: Box", lx, ly, 82, 14, function () { send("sel_mode", { mode: SEL.mode === "sphere" ? "box" : "sphere" }); },
                { tip: ["Selection shape", "Box: two corners", "Sphere: left click the centre, right click a point on its edge"] });
            U.button(ctx, "+ New", lx + 86, ly, 84, 14, function () { S.selId = null; S.e = { id: null, name: "", type: "combat", rules: { lock: true, noBuild: true, waves: 0, timer: 0, music: "", ambience: "", ambEvery: 12 } }; U.resetElements(); },
                { kind: "green", disabled: !SEL.c1 || (SEL.mode !== "sphere" && !SEL.c2), tip: ["New room from the wand's selection", SEL.c1 ? "Selection ready" : "Select it first: left click, then right click"] });
            U.text(ctx, SEL.c1 ? (SEL.mode === "sphere" ? "Selection: sphere r " + selRadius() : SEL.c2 ? "Selection " + size(boxOf(SEL.c1, SEL.c2)) : "Selection: corner 1") : "No selection", lx, ly + 18, "#A8A8A8", "left", 0.75);
            U.inset(ctx, lx - 2, ly + 28, lw + 4, h - 80);
            if (!D.rooms.length) note(ctx, "No rooms yet. Select a box with the Room Wand (left click, right click), then + New.", lx + 4, ly + 34, lw - 8);
            U.list(ctx, "rooms", lx, ly + 30, lw - 6, h - 84, D.rooms, 16, function (r, i, ry) {
                var sel = r.id === S.selId;
                ctx.fill(lx, ry, lw - 6, 15, sel ? "#FFE070" : "#FFFFFF", sel ? 0.18 : i % 2 ? 0.04 : 0.08);
                ctx.fill(lx + 2, ry + 3, 8, 8, r.color, 1);
                U.text(ctx, U.fit(ctx, r.name, lw - 70), lx + 14, ry + 4, sel ? "#FFE9A8" : "#FFFFFF", "left", 0.85);
                U.text(ctx, r.type, lx + lw - 10, ry + 4, "#9A9A9A", "right", 0.7);
                U.hit(lx, ry, lw - 6, 15, function () { S.selId = r.id; S.e = null; send("room_select", { id: r.id }); U.resetElements(); }, [r.name, r.type + " room", r.shape === "sphere" ? "Sphere, radius " + r.r : "Box " + size(r.box), "Click: edit (and select it in the world)"]);
            });
            // right: the editor
            var rx = x + 200, rw = w - 214, cur = S.selId ? roomById(S.selId) : null;
            if (S.selId && !cur) { S.selId = null; S.e = null; }
            if (cur && (!S.e || S.e.id !== cur.id)) S.e = { id: cur.id, name: cur.name, type: cur.type, rules: clone(cur.rules) };
            var e = S.e;
            if (!e) { note(ctx, "Pick a room on the left, or make a selection in the world and press + New.", rx, y + 40, rw, 0.85); }
            else {
                var rows = [], fx = rx + 110, rl = function (lbl, draw, tip) { rows.push({ h: 17, draw: function (ry) { U.label(ctx, lbl, rx, ry, 106); if (tip) U.hit(rx, ry, 106, 12, null, tip); draw(ry); } }); };
                rows.push(head(e.id ? "Room: " + (cur ? cur.name : "") : "New room (from the selection)", rx, rw - 8));
                rl("Name", function (ry) { U.input(ctx, "rm_name_" + (e.id || "new"), fx, ry + 2, rw - 120, 10, e.name, function (t) { e.name = t; }, { maxLength: 24, hint: "e.g. Guard Hall" }); });
                rl("Type", function (ry) {
                    U.dropdown(ctx, "rm_type", fx, ry + 1, 110, 13, D.types.rooms.map(function (t) { return { value: t, label: t.charAt(0).toUpperCase() + t.substring(1) }; }), e.type, function (v) { e.type = v; }, { search: false });
                    ctx.fill(fx + 116, ry + 3, 9, 9, D.types.roomColors[e.type] || "#FFFFFF", 1);
                }, ["Room type", "Its colour in the workshop and painter; combat and boss", "rooms lock their doors by default"]);
                if (cur) rl("Shape", function (ry) { U.text(ctx, cur.shape === "sphere" ? "Sphere, radius " + cur.r : "Box " + size(cur.box), fx, ry + 3, "#D0D0D0", "left", 0.85); });
                rows.push(head("Rules", rx, rw - 8));
                rl("Lock doors until cleared", function (ry) { U.toggle(ctx, !!e.rules.lock, fx, ry + 2, function () { e.rules.lock = !e.rules.lock; }); },
                    ["Seal the room's doors", "When a player walks in, the door modules in or next to", "the room close and stay shut until its spawners' mobs are down"]);
                rl("Spawn waves", function (ry) { U.numField(ctx, "rm_waves", fx, ry, 40, e.rules.waves || "", function (v) { e.rules.waves = U.clamp((v | 0), 0, 10); }, { int: true, blank: 0, hint: "1" }); U.text(ctx, "times its spawners fire", fx + 46, ry + 4, "#909090", "left", 0.75); },
                    ["Waves", "When every mob from the room's spawners is down,", "they spawn again until this many waves are done"]);
                rl("Timer (seconds)", function (ry) { U.numField(ctx, "rm_timer", fx, ry, 40, e.rules.timer || "", function (v) { e.rules.timer = U.clamp((v | 0), 0, 3600); }, { int: true, blank: 0, hint: "0" }); U.text(ctx, e.rules.timer ? "counts down from entering" : "none", fx + 46, ry + 4, "#909090", "left", 0.75); },
                    ["Room timer", "Starts when the first player enters; when it ends the", "room's 'timer ends' event fires (link it with the Connection Wand)"]);
                rl("No building", function (ry) { U.toggle(ctx, !!e.rules.noBuild, fx, ry + 2, function () { e.rules.noBuild = !e.rules.noBuild; }); }, ["Players can't break or place blocks here,", "even when the server allows building in runs"]);
                rl("Music on entering", function (ry) { U.dropdown(ctx, "rm_music", fx, ry + 1, rw - 120, 13, soundOpts(MUSIC), e.rules.music || "", function (v) { e.rules.music = v; }, { search: true, custom: true, customLabel: "Use sound id", listWidth: 220 }); },
                    ["A sound played to a player who walks in", "Addons can also use DungeonMaker.hooks.roomEnter / roomLeave"]);
                rl("Ambience", function (ry) { U.dropdown(ctx, "rm_amb", fx, ry + 1, rw - 166, 13, soundOpts(AMBIENCE), e.rules.ambience || "", function (v) { e.rules.ambience = v; }, { search: true, custom: true, customLabel: "Use sound id", listWidth: 220 });
                    U.numField(ctx, "rm_amb_s", rx + rw - 48, ry, 30, e.rules.ambEvery || 12, function (v) { e.rules.ambEvery = U.clamp(v | 0, 2, 600); }, { int: true, blank: 12 }); U.text(ctx, "s", rx + rw - 14, ry + 4, "#909090", "left", 0.75); },
                    ["A sound repeated every few seconds while players are inside"]);
                rows.push({ h: 34, draw: function (ry) { note(ctx, "Rooms work as conditions: goals (clear / reach a room), Defeat-everything and Survive puzzles, and room events (enter, cleared, timer) as link sources in the Connection Wand's list.", rx, ry + 3, rw - 8, 0.7); } });
                rowsList(ctx, S, "room_ed", rx, y + 16, rw - 6, h - 72, rows);
                var by = y + h - 50;
                U.button(ctx, "Save", rx, by, 70, 18, function () { send("room_save", { id: e.id, name: e.name, type: e.type, rules: e.rules, fromSel: !e.id }); if (!e.id) S.e = null; }, { kind: "green" });
                if (e.id) {
                    U.button(ctx, "Use selection", rx + 74, by, 92, 18, function () { send("room_save", { id: e.id, name: e.name, type: e.type, rules: e.rules, fromSel: true }); },
                        { tip: ["Resize: the room takes the wand's current selection", "Sneak + right-click the room to load it, then nudge its faces"], disabled: !SEL.c1 });
                    U.button(ctx, "Delete", rx + rw - 66, by, 60, 18, function () { send("room_delete", { id: e.id }); S.selId = null; S.e = null; }, { kind: "red" });
                }
            }
            U.button(ctx, "Close", x + w - 106, y + h - 28, 90, 20, function () { U.close(); });
        };
        S.draw = withHelp(S, S.view.substring(2), S.draw);
        S.back = function () { if (S.help) { S.help = false; return; } U.close(); };
        U.open(S);
    }

    // ---- Puzzle Wand: puzzles, goals, rewards ----
    function puzzleById(id) { var f = null; (D ? D.puzzles : []).forEach(function (z) { if (z.id === id) f = z; }); return f; }
    var PUZZLE_HINT = {
        sequence: "Parts: levers or buttons, pressed in the order listed. A wrong one resets them.",
        plates: "Parts: pressure plates. All at once (stand on them or push blocks) or each pressed once.",
        offering: "Parts: the altar block(s). Right-click one holding the item to offer it.",
        room_clear: "Solved when every mob from the room's spawners is down.",
        survive: "Solved after the time runs out (from entering the room, or from a signal).",
        hidden: "Parts: blocks that hide a switch. Clicking or hitting one solves it.",
        checkpoint: "Parts: blocks to stand on, in order. Each sets where players respawn.",
        combo: "Parts: blocks built in the right pattern from the palette. Runs scramble them; right-click cycles a block.",
        logic: "Its inputs are links into it (Connection Wand): all of them on, or any one."
    };
    function rewardRow(ctx, rx, ry, rw, r, list, i, chests) {
        ctx.fill(rx, ry, rw - 8, 15, "#FFFFFF", 0.05);
        if (r.type === "xp" || r.type === "money") {
            U.text(ctx, r.type === "xp" ? "XP" : "Money", rx + 4, ry + 4, "#FFFFFF", "left", 0.85);
            U.numField(ctx, "rw_" + i + "_" + list.length + r.type, rx + 60, ry + 1, 60, r.amount, function (v) { r.amount = Math.max(1, v | 0); }, { int: true, blank: 10 });
            U.text(ctx, "each player", rx + 126, ry + 4, "#909090", "left", 0.75);
        } else if (r.type === "item") {
            U.itemSlot(ctx, r.item, rx + 2, ry - 2);
            U.text(ctx, "x", rx + 24, ry + 4, "#909090");
            U.numField(ctx, "rw_" + i + "_n" + list.length, rx + 32, ry + 1, 30, r.count, function (v) { r.count = U.clamp(v | 0, 1, 64); }, { int: true, blank: 1 });
            U.text(ctx, "dropped where it happens", rx + 70, ry + 4, "#909090", "left", 0.75);
        } else if (r.type === "loot") {
            U.text(ctx, "Loot of", rx + 4, ry + 4, "#FFFFFF", "left", 0.85);
            U.dropdown(ctx, "rw_" + i + "_l" + list.length, rx + 50, ry + 1, rw - 90, 13, chests.map(function (c) { return { value: c.key, label: c.name }; }), r.key || "", function (v) { r.key = v; }, { search: false, placeholder: chests.length ? "Pick a chest..." : "No chests" });
        }
        U.iconButton(ctx, "trash", rx + rw - 22, ry + 2, 11, function () { list.splice(i, 1); U.resetElements(); }, "Remove");
    }
    function addReward(list, v) {
        if (list.length >= 8) { U.status("At most 8 rewards", "#FF7070"); return; }
        if (v === "item") {
            var h = RPG.player.heldItem;
            if (!h || h === "minecraft:air" || wandOf(h)) { U.status("Hold the reward item in your main hand (put the wand in another slot)", "#FF7070"); return; }
            list.push({ type: "item", item: { id: h }, count: 1, fromHand: true });
        } else if (v === "loot") list.push({ type: "loot", key: D.chests[0] ? D.chests[0].key : "" });
        else list.push({ type: v, amount: v === "xp" ? 30 : 100 });
    }
    var REWARD_OPTS = [{ value: "xp", label: "XP" }, { value: "money", label: "Money" }, { value: "item", label: "Item in your hand" }, { value: "loot", label: "Loot of a chest module" }];
    function targetOpts() {
        var out = [];
        D.modules.forEach(function (m) { if (m.dst) out.push({ value: JSON.stringify({ k: "a", key: m.key }), label: m.name, tooltip: "Module" }); });
        D.puzzles.forEach(function (z) { out.push({ value: JSON.stringify({ k: "p", id: z.id }), label: "Puzzle: " + z.name }); });
        return out;
    }
    function sourceOpts() {
        var out = [];
        D.modules.forEach(function (m) { if (m.src) out.push({ value: JSON.stringify({ k: "a", key: m.key }), label: m.name, tooltip: "Module: " + m.type }); });
        D.puzzles.forEach(function (z) { out.push({ value: JSON.stringify({ k: "p", id: z.id }), label: "Puzzle solved: " + z.name }); });
        D.rooms.forEach(function (r) {
            out.push({ value: JSON.stringify({ k: "r", id: r.id, ev: "enter" }), label: "Room " + r.name + ": a player enters" });
            out.push({ value: JSON.stringify({ k: "r", id: r.id, ev: "clear" }), label: "Room " + r.name + ": cleared (all dead)" });
            out.push({ value: JSON.stringify({ k: "r", id: r.id, ev: "timer" }), label: "Room " + r.name + ": timer ends" });
        });
        return out;
    }
    function openPuzzles(m) {
        var S = { view: "w_puzzles", tab: "puzzles", selId: m.puzzle || null, e: null, pendingPart: m.pendingPart || null, pendingNode: m.pendingNode || null, block: m.block || "", help: false, goals: null };
        S.draw = function (ctx) {
            if (noData(ctx, S)) return;
            var w = 490, h = 280, p = centred(ctx, w, h), x = p.x, y = p.y;
            U.panel(ctx, x, y, w, h, "Puzzles & Goals");
            helpButton(ctx, S, x + w - 26, y + 8);
            [["puzzles", "Puzzles"], ["goals", "Goals"]].forEach(function (t, i) {
                U.button(ctx, t[1], x + 14 + i * 74, y + 14, 70, 14, function () { if (S.tab !== t[0]) { S.tab = t[0]; U.resetElements(); } }, { selected: S.tab === t[0], kind: S.tab === t[0] ? "gold" : "normal" });
            });
            if (S.tab === "puzzles") drawPuzzleTab(ctx, S, x, y, w, h); else drawGoalsTab(ctx, S, x, y, w, h);
            U.button(ctx, "Close", x + w - 96, y + h - 26, 80, 18, function () { U.close(); });
        };
        S.draw = withHelp(S, S.view.substring(2), S.draw);
        S.back = function () { if (S.help) { S.help = false; return; } U.close(); };
        U.open(S);
    }
    function drawPuzzleTab(ctx, S, x, y, w, h) {
        var lx = x + 14, ly = y + 34, lw = 160;
        U.inset(ctx, lx - 2, ly - 2, lw + 4, h - 66);
        if (!D.puzzles.length) note(ctx, "No puzzles yet. Right-click a lever, plate or other block with the Puzzle Wand, or the air for a logic node.", lx + 4, ly + 4, lw - 8);
        U.list(ctx, "puzzles", lx, ly, lw - 6, h - 70, D.puzzles, 16, function (z, i, ry) {
            var sel = z.id === S.selId;
            ctx.fill(lx, ry, lw - 6, 15, sel ? "#FFE070" : "#FFFFFF", sel ? 0.18 : i % 2 ? 0.04 : 0.08);
            U.text(ctx, U.fit(ctx, z.name, lw - 30), lx + 4, ry + 4, sel ? "#FFE9A8" : "#FFFFFF", "left", 0.85);
            U.text(ctx, String(z.parts.length || (z.node ? "•" : "")), lx + lw - 12, ry + 4, "#9A9A9A", "right", 0.7);
            U.hit(lx, ry, lw - 6, 15, function () { S.selId = z.id; S.e = null; S.pendingPart = null; S.pendingNode = null; U.resetElements(); }, [z.name, D.types.puzzleNames[z.type] || z.type, z.parts.length + " part(s)"]);
        });
        var rx = x + 186, rw = w - 200;
        var cur = S.selId ? puzzleById(S.selId) : null;
        if (S.selId && !cur) { S.selId = null; S.e = null; }
        if (cur && (!S.e || S.e.id !== cur.id)) S.e = { id: cur.id, name: cur.name, type: cur.type, room: cur.room, cfg: clone(cur.cfg || {}), rewards: clone(cur.rewards || []), order: cur.parts.map(function (q, i) { return i; }), remove: [] };
        if (!cur && (S.pendingPart || S.pendingNode) && !S.e) S.e = { id: null, name: "", type: S.pendingNode ? "logic" : /lever|button/.test(S.block) ? "sequence" : /pressure_plate/.test(S.block) ? "plates" : "hidden", room: "", cfg: {}, rewards: [], order: [], remove: [] };
        var e = S.e;
        if (!e) { note(ctx, "Pick a puzzle on the left, or right-click a block or the air with the Puzzle Wand.", rx, y + 44, rw, 0.85); return; }
        var rows = [], fx = rx + 96, rl = function (lbl, draw, tip, hh) { rows.push({ h: hh || 17, draw: function (ry) { U.label(ctx, lbl, rx, ry, 92); if (tip) U.hit(rx, ry, 92, 12, null, tip); draw(ry); } }); };
        if (!e.id) rows.push({ h: 34, draw: function (ry) {
            ctx.fill(rx, ry, rw - 8, 30, "#5A4A22", 0.35);
            U.text(ctx, S.pendingNode ? "New logic node at " + S.pendingNode.join(", ") : "Block at " + S.pendingPart.join(", ") + (S.block ? " (" + S.block.replace(/^minecraft:/, "") + ")" : ""), rx + 4, ry + 3, "#FFE9A8", "left", 0.8);
            if (S.pendingPart && D.puzzles.length) U.dropdown(ctx, "pz_addto", rx + 4, ry + 14, rw - 16, 13, D.puzzles.map(function (z) { return { value: z.id, label: "Add it to " + z.name }; }), "", function (v) {
                var z = puzzleById(v); if (!z) return;
                send("puzzle_save", { id: z.id, name: z.name, type: z.type, room: z.room, cfg: z.cfg, part: S.pendingPart }); S.pendingPart = null; S.selId = z.id; S.e = null;
            }, { search: false, placeholder: "...or add it to an existing puzzle" });
        } });
        rl("Name", function (ry) { U.input(ctx, "pz_name_" + (e.id || "new"), fx, ry + 2, rw - 106, 10, e.name, function (t) { e.name = t; }, { maxLength: 24, hint: "e.g. Lever Hall" }); });
        rl("Type", function (ry) { U.dropdown(ctx, "pz_type", fx, ry + 1, rw - 106, 13, D.types.puzzles.map(function (t) { return { value: t, label: D.types.puzzleNames[t] }; }), e.type, function (v) { e.type = v; e.cfg = {}; U.resetElements(); }, { search: false, listWidth: 200 }); });
        rl("Room", function (ry) { U.dropdown(ctx, "pz_room", fx, ry + 1, rw - 106, 13, [{ value: "", label: "None" }].concat(D.rooms.map(function (r) { return { value: r.id, label: r.name + " (" + r.type + ")" }; })), e.room || "", function (v) { e.room = v; }, { search: false }); },
            ["The room it belongs to", "Needed by Defeat everything and Survive"]);
        rows.push({ h: 22, draw: function (ry) { note(ctx, PUZZLE_HINT[e.type] || "", rx, ry + 2, rw - 8, 0.72, "#C8C0A8"); } });
        var c = e.cfg;
        if (e.type === "sequence") rl("Wrong order resets", function (ry) { U.toggle(ctx, c.reset !== false, fx, ry + 2, function () { c.reset = c.reset === false; }); });
        if (e.type === "plates") rl("Plates", function (ry) { U.dropdown(ctx, "pz_pm", fx, ry + 1, 140, 13, [{ value: "all", label: "All pressed at once" }, { value: "each", label: "Each pressed once" }], c.mode || "all", function (v) { c.mode = v; }, { search: false }); });
        if (e.type === "offering") {
            rl("Item", function (ry) {
                var it = cur && cur.cfg && cur.cfg.item;
                U.itemSlot(ctx, c.itemFromHand ? { id: RPG.player.heldItem } : it, fx, ry - 3);
                U.button(ctx, c.itemFromHand ? "From hand on save ✔" : "Take from hand", fx + 22, ry, 112, 13, function () { c.itemFromHand = !c.itemFromHand; }, { tip: ["On save, the item in your main hand is what the altar wants"] });
            });
            rl("How many", function (ry) { U.numField(ctx, "pz_oc", fx, ry, 40, c.count || 1, function (v) { c.count = U.clamp(v | 0, 1, 64); }, { int: true, blank: 1 });
                U.toggle(ctx, c.take !== false, fx + 50, ry + 2, function () { c.take = c.take === false; }, ["Whether the items are taken"]); U.text(ctx, "taken", fx + 76, ry + 4, "#909090", "left", 0.75); });
        }
        if (e.type === "survive") {
            rl("Seconds", function (ry) { U.numField(ctx, "pz_ss", fx, ry, 50, c.seconds || 30, function (v) { c.seconds = U.clamp(v | 0, 3, 3600); }, { int: true, blank: 30 }); });
            rl("Starts", function (ry) { U.dropdown(ctx, "pz_st", fx, ry + 1, 160, 13, [{ value: "enter", label: "When a player enters the room" }, { value: "signal", label: "When a link powers it" }], c.start || "enter", function (v) { c.start = v; }, { search: false }); });
        }
        if (e.type === "checkpoint") rl("Respawn there", function (ry) { U.toggle(ctx, c.respawn !== false, fx, ry + 2, function () { c.respawn = c.respawn === false; }); }, ["Players who die come back at the last checkpoint reached"]);
        if (e.type === "combo") rl("Palette", function (ry) { U.dropdown(ctx, "pz_pal", fx, ry + 1, 120, 13, D.types.palettes.map(function (k) { return { value: k, label: k.charAt(0).toUpperCase() + k.substring(1) }; }), c.palette || "wool", function (v) { c.palette = v; }, { search: false }); },
            ["Blocks a part cycles through", "Build the solution with them in the workshop"]);
        if (e.type === "logic") rl("Solved when", function (ry) { U.dropdown(ctx, "pz_op", fx, ry + 1, 140, 13, [{ value: "all", label: "All inputs on (AND)" }, { value: "any", label: "Any input on (OR)" }], c.op || "all", function (v) { c.op = v; }, { search: false }); });
        if (e.id && e.type !== "logic" && e.type !== "room_clear" && e.type !== "survive") {
            rows.push(head("Parts (" + e.order.length + ")" + (e.type === "sequence" || e.type === "checkpoint" ? ", in order" : ""), rx, rw - 8, function (ry) {
                U.button(ctx, "Add in world", rx + rw - 96, ry + 3, 86, 12, function () { send("puzzle_save", puzzleMsg(e, true)); U.close(); }, { tip: ["Saves, closes; then right-click blocks to add or remove them", "Right-click the air when done"] });
            }));
            if (!e.order.length) rows.push({ h: 12, draw: function (ry) { U.text(ctx, "No parts yet", rx + 6, ry + 2, "#909090", "left", 0.8); } });
            e.order.forEach(function (pi, j) {
                var q = cur.parts[pi];
                if (!q) return;
                rows.push({ h: 14, draw: function (ry) {
                    ctx.fill(rx, ry, rw - 8, 13, "#FFFFFF", j % 2 ? 0.03 : 0.07);
                    U.text(ctx, (j + 1) + ".  " + q.join(", "), rx + 4, ry + 3, "#FFFFFF", "left", 0.8);
                    U.iconButton(ctx, "up", rx + rw - 52, ry + 1, 10, function () { if (j > 0) { var t = e.order[j - 1]; e.order[j - 1] = pi; e.order[j] = t; } }, "Earlier", j === 0);
                    U.iconButton(ctx, "down", rx + rw - 38, ry + 1, 10, function () { if (j < e.order.length - 1) { var t = e.order[j + 1]; e.order[j + 1] = pi; e.order[j] = t; } }, "Later", j >= e.order.length - 1);
                    U.iconButton(ctx, "trash", rx + rw - 22, ry + 1, 10, function () { e.order.splice(j, 1); e.remove.push(pi); }, "Remove the part");
                } });
            });
        }
        rows.push(head("Rewards (" + e.rewards.length + ")", rx, rw - 8, function (ry) {
            U.dropdown(ctx, "pz_addrw", rx + rw - 120, ry + 2, 110, 13, REWARD_OPTS, "", function (v) { addReward(e.rewards, v); U.resetElements(); }, { search: false, placeholder: "+ Reward" });
        }));
        e.rewards.forEach(function (r, i) { rows.push({ h: 17, draw: function (ry) { rewardRow(ctx, rx, ry, rw, r, e.rewards, i, D.chests); } }); });
        if (e.id) {
            var outs = D.links.filter(function (l) { return l.from.k === "p" && l.from.id === e.id; });
            rows.push(head("Opens / triggers (" + outs.length + ")", rx, rw - 8, function (ry) {
                U.dropdown(ctx, "pz_out", rx + rw - 120, ry + 2, 110, 13, targetOpts().filter(function (o) { return o.value !== JSON.stringify({ k: "p", id: e.id }); }), "", function (v) {
                    send("link_add", { from: { k: "p", id: e.id }, to: JSON.parse(v), opn: "direct", time: 0 }); U.resetElements();
                }, { search: true, placeholder: "+ Link to...", listWidth: 220 });
            }));
            outs.forEach(function (l) { rows.push({ h: 14, draw: function (ry) {
                U.text(ctx, U.fit(ctx, "> " + l.toName + (l.op !== "direct" ? " (" + l.op + ")" : ""), rw - 30), rx + 4, ry + 3, "#9FE0FF", "left", 0.8);
                U.iconButton(ctx, "trash", rx + rw - 22, ry + 1, 10, function () { send("link_delete", { id: l.id }); }, "Unlink");
            } }); });
            rows.push({ h: 14, draw: function (ry) { note(ctx, "Doors, bridges, spawners (on 'signal'), chests, other puzzles. Blocks (lamps, redstone): Connection Wand.", rx, ry + 2, rw - 8, 0.68); } });
        }
        rowsList(ctx, S, "pz_ed", rx, y + 34, rw - 6, h - 92, rows);
        var by = y + h - 50;
        U.button(ctx, e.id ? "Save" : "Create", rx, by, 70, 18, function () { send("puzzle_save", puzzleMsg(e, false, S)); }, { kind: "green" });
        if (e.id) U.button(ctx, "Delete", rx + 74, by, 60, 18, function () { send("puzzle_delete", { id: e.id }); S.selId = null; S.e = null; }, { kind: "red" });
    }
    function puzzleMsg(e, addParts, S) {
        var m = { id: e.id, name: e.name, type: e.type, room: e.room, cfg: e.cfg, rewards: e.rewards, addParts: !!addParts };
        if (e.id) { m.order = e.order.concat(e.remove); m.remove = e.remove.map(function (pi) { return e.order.length + e.remove.indexOf(pi); }); }
        if (!e.id && S) { m.part = S.pendingPart; m.node = S.pendingNode; }
        return m;
    }
    function drawGoalsTab(ctx, S, x, y, w, h) {
        if (!S.goals || S.goalsKey !== JSON.stringify(D.objectives)) { S.goalsKey = JSON.stringify(D.objectives); S.goals = D.objectives.map(function (o, i) { var c = clone(o); c.was = i; delete c.text; delete c.rewardText; return c; }); U.resetElements(); }
        var G = S.goals, lx = x + 14, lw = w - 28, rows = [];
        var addOpts = [{ value: "kill_count", label: "Defeat a number of enemies" }];
        D.puzzles.forEach(function (z) { addOpts.push({ value: "puzzle:" + z.id, label: "Solve: " + z.name }); });
        D.rooms.forEach(function (r) { addOpts.push({ value: "room_clear:" + r.id, label: "Clear: " + r.name }); addOpts.push({ value: "room_enter:" + r.id, label: "Reach: " + r.name }); });
        rows.push(head("Completion goals (" + G.length + ")", lx, lw - 8, function (ry) {
            U.dropdown(ctx, "gl_add", lx + lw - 170, ry + 2, 160, 13, addOpts, "", function (v) {
                if (G.length >= 12) { U.status("At most 12 goals", "#FF7070"); return; }
                var a = String(v).split(":");
                if (a[0] === "kill_count") G.push({ type: "kill_count", count: 10, rewards: [] });
                else if (a[0] === "puzzle") G.push({ type: "puzzle", puzzle: a[1], name: (puzzleById(a[1]) || {}).name, rewards: [] });
                else G.push({ type: a[0], room: a[1], name: (roomById(a[1]) || {}).name, rewards: [] });
                U.resetElements();
            }, { search: true, placeholder: "+ Add goal", listWidth: 200 });
        }));
        if (!G.length) rows.push({ h: 14, draw: function (ry) { U.text(ctx, "No goals: reaching the exit ends the run", lx + 6, ry + 3, "#909090", "left", 0.8); } });
        G.forEach(function (g, i) {
            g.rewards = g.rewards || [];
            rows.push({ h: 18, draw: function (ry) {
                ctx.fill(lx, ry, lw - 8, 16, "#FFFFFF", 0.08);
                U.icon(ctx, "flag", lx + 3, ry + 3, 10);
                var t = g.type === "kill_count" ? "Defeat enemies:" : g.type === "kill_entity" ? "Defeat " + U.entityName(g.entity) + " x" + g.count : g.type === "obtain_item" ? "Get " + g.item.id + " x" + g.count
                    : g.type === "puzzle" ? "Solve " + ((puzzleById(g.puzzle) || {}).name || g.name || "?") : (g.type === "room_clear" ? "Clear " : "Reach ") + ((roomById(g.room) || {}).name || g.name || "?");
                U.text(ctx, U.fit(ctx, t, lw - 200), lx + 16, ry + 4, "#FFFFFF", "left", 0.85);
                if (g.type === "kill_count") U.numField(ctx, "gl_n" + i + "_" + G.length, lx + 120, ry + 1, 40, g.count, function (v) { g.count = Math.max(1, v | 0); }, { int: true, blank: 10 });
                U.dropdown(ctx, "gl_rw" + i + "_" + G.length, lx + lw - 150, ry + 1, 110, 13, REWARD_OPTS, "", function (v) { addReward(g.rewards, v); U.resetElements(); }, { search: false, placeholder: "+ Reward" });
                U.iconButton(ctx, "trash", lx + lw - 24, ry + 3, 11, function () { G.splice(i, 1); U.resetElements(); }, "Remove the goal");
            } });
            g.rewards.forEach(function (r, j) { rows.push({ h: 17, draw: function (ry) { rewardRow(ctx, lx + 20, ry, lw - 20, r, g.rewards, j, D.chests); } }); });
        });
        rows.push({ h: 24, draw: function (ry) { note(ctx, "The same goals as the card editor's. A goal's rewards go to the party the moment it is done; the run ends at the exit once every goal is done.", lx, ry + 4, lw - 8, 0.72); } });
        rowsList(ctx, S, "goals", lx, y + 34, lw - 6, h - 92, rows);
        U.button(ctx, "Save goals", lx, y + h - 50, 90, 18, function () { send("objectives_save", { list: G }); }, { kind: "green" });
    }

    // ---- Connection Wand: the links ----
    function openLinks() {
        var S = { view: "w_links", from: "", to: "", opn: "direct", time: 2, help: false };
        S.draw = function (ctx) {
            if (noData(ctx, S)) return;
            var w = 490, h = 280, p = centred(ctx, w, h), x = p.x, y = p.y;
            U.panel(ctx, x, y, w, h, "Connections");
            helpButton(ctx, S, x + w - 26, y + 8);
            var lx = x + 14, lw = w - 28, OPS = D.types.ops.map(function (o) { return { value: o, label: { direct: "Direct", not: "NOT (inverted)", delay: "Delay", pulse: "Pulse", toggle: "Toggle" }[o] }; });
            if (SEL.src) { U.text(ctx, "Picked source in the world - right-click the target with the wand (left click cancels)", lx, y + 18, "#FF9090", "left", 0.75); }
            U.inset(ctx, lx - 2, y + 28, lw + 4, h - 112);
            if (!D.links.length) note(ctx, "No links yet. Right-click a source with the Connection Wand, then the target, or add one below.", lx + 4, y + 34, lw - 8);
            U.list(ctx, "links", lx, y + 30, lw - 6, h - 116, D.links, 16, function (l, i, ry) {
                ctx.fill(lx, ry, lw - 6, 15, "#FFFFFF", i % 2 ? 0.04 : 0.08);
                ctx.fill(lx + 2, ry + 4, 6, 6, l.module ? "#C0C0C0" : l.c, 1);
                U.text(ctx, U.fit(ctx, l.fromName, 150), lx + 12, ry + 4, "#FFFFFF", "left", 0.75);
                U.text(ctx, ">", lx + 166, ry + 4, "#E8C860", "left", 0.8);
                U.text(ctx, U.fit(ctx, l.toName, 128), lx + 176, ry + 4, "#FFFFFF", "left", 0.75);
                if (l.module) U.text(ctx, "module link", lx + lw - 96, ry + 4, "#909090", "left", 0.7);
                else {
                    U.dropdown(ctx, "lk_op_" + l.id, lx + lw - 148, ry + 1, 92, 13, OPS, l.op, function (v) { send("link_save", { id: l.id, opn: v, time: l.time || (v === "delay" || v === "pulse" ? 2 : 0) }); }, { search: false });
                    if (l.op === "delay" || l.op === "pulse") U.numField(ctx, "lk_t_" + l.id, lx + lw - 52, ry + 2, 22, l.time, function (v) { if (v !== null) { l.time = U.clamp(v | 0, 0, 600); S.dirtyTime = l; S.dirtyAt = RPG.nowMs(); } }, { int: true, blank: 0 });
                }
                U.iconButton(ctx, "trash", lx + lw - 22, ry + 2, 11, function () { send("link_delete", { id: l.id }); }, "Remove the link");
            });
            if (S.dirtyTime && RPG.nowMs() - S.dirtyAt > 700) { var dl = S.dirtyTime; S.dirtyTime = null; send("link_save", { id: dl.id, opn: dl.op, time: dl.time }); }
            // a new link from the lists
            var ny = y + h - 78;
            U.text(ctx, "New link", lx, ny, "#E8C860");
            U.dropdown(ctx, "lk_from", lx, ny + 11, 170, 13, sourceOpts(), S.from, function (v) { S.from = v; }, { search: true, placeholder: "Source...", listWidth: 240 });
            U.text(ctx, ">", lx + 176, ny + 13, "#E8C860");
            U.dropdown(ctx, "lk_to", lx + 186, ny + 11, 140, 13, targetOpts(), S.to, function (v) { S.to = v; }, { search: true, placeholder: "Target...", listWidth: 240 });
            U.dropdown(ctx, "lk_opn", lx + 332, ny + 11, 92, 13, OPS, S.opn, function (v) { S.opn = v; }, { search: false });
            if (S.opn === "delay" || S.opn === "pulse") U.numField(ctx, "lk_time", lx + 430, ny + 12, 22, S.time, function (v) { S.time = U.clamp((v | 0) || 0, 0, 600); }, { int: true, blank: 2 });
            U.button(ctx, "Add", lx, ny + 28, 60, 16, function () {
                if (!S.from || !S.to) { U.status("Pick a source and a target", "#FF7070"); return; }
                send("link_add", { from: JSON.parse(S.from), to: JSON.parse(S.to), opn: S.opn, time: S.time });
            }, { kind: "green" });
            note(ctx, "Blocks (levers, buttons, plates, redstone in; lamps, doors, redstone out): pick them in the world.", lx + 66, ny + 30, lw - 170, 0.7);
            U.button(ctx, "Close", x + w - 96, y + h - 26, 80, 18, function () { U.close(); });
        };
        S.draw = withHelp(S, S.view.substring(2), S.draw);
        S.back = function () { if (S.help) { S.help = false; return; } U.close(); };
        U.open(S);
    }

    return { data: function () { return D; }, held: function () { return held; } };
})();
