// =====================================================================================
//  Dungeon Maker (client) - the run tracker (time left, goals) and the workshop plot outline
// =====================================================================================
(function () {
    var U = DMK_UI;
    var HUD = null, got = 0;

    RPG.net.on("dmk_hud", function (d) { HUD = d; got = RPG.nowMs(); });
    // workshop: the plot outline, every link as a line (source colour, a dot at the target) and door / bridge zones as boxes
    var ZONES = 0;
    function clearLinks() {
        try { RPG.world3d.removePrefix("dmk_ln"); } catch (e) { }
        for (var i = 0; i < ZONES; i++) RPG.world.removeBox("dmk_zn" + i);
        ZONES = 0;
    }
    RPG.net.on("dmk_plot", function (b) {
        clearLinks();
        if (!b) { RPG.world.removeBox("dmk_plot"); return; }
        RPG.world.box("dmk_plot", b.x1, b.y - 1, b.z1, b.x2, b.y - 1, b.z2, b.id ? "#E8C860" : "#808080", { alpha: 0.8, grid: 16, maxDistance: 512 });
        var dim = "ragnarok_rpg:dungeon_workshop";
        (b.lines || []).forEach(function (l, i) {
            RPG.world3d.line("dmk_ln" + i, { from: l.a, to: l.b, width: 0.05, color: l.c, alpha: 0.85, seeThrough: true, dimension: dim });
            RPG.world3d.billboard("dmk_ln_t" + i, { x: l.b[0], y: l.b[1] + 0.62, z: l.b[2], size: 0.22, color: l.c, alpha: 0.95, seeThrough: true, dimension: dim });
        });
        (b.zones || []).forEach(function (z, i) { RPG.world.box("dmk_zn" + i, z.x1, z.y1, z.z1, z.x2, z.y2, z.z2, z.c, { alpha: 0.45, maxDistance: 96 }); });
        ZONES = (b.zones || []).length;
    });

    function clock(s) { s = Math.max(0, Math.ceil(s)); var m = Math.floor(s / 60), x = s % 60; return m + ":" + (x < 10 ? "0" : "") + x; }

    RPG.hud.onRender(function (ctx) {
        if (!HUD) return;
        var age = (RPG.nowMs() - got) / 1000;
        if (age > 6) { HUD = null; return; }
        var keyRow = (HUD.keys | 0) > 0 || HUD.bossKey ? 12 : 0;
        var goals = HUD.goals || [], w = 150, lines = goals.length, h = 30 + keyRow + lines * 11 + (HUD.exit && HUD.state === "active" && goals.every(function (g) { return g.done; }) ? 11 : 0);
        var x = ctx.width - w - 6, y = Math.floor(ctx.height * 0.55);
        if (!ctx.group("dmk_tracker", "Dungeon tracker", x, y, w, h)) return;
        if (U.art()) U.slice(ctx, "hud.png", x, y, w, h, 0, 0, 16, 16, 16, 16, 4, 0.92);
        else { ctx.fill(x, y, w, h, "#0E0F14", 0.75); ctx.fill(x, y, 2, h, "#E8C860", 1); }
        U.text(ctx, U.fit(ctx, HUD.name, w - 56), x + 6, y + 5, "#FFE9A8");
        var left = HUD.left >= 0 ? Math.max(0, HUD.left - age) : -1;
        var t = left >= 0 ? clock(left) : clock(HUD.elapsed + age);
        U.icon(ctx, left >= 0 ? "hourglass" : "clock", x + w - 46, y + 3, 10);
        U.text(ctx, t, x + w - 6, y + 5, left >= 0 && left < 30 ? (Math.floor(RPG.nowMs() / 400) % 2 ? "#FF5050" : "#FFFFFF") : "#FFFFFF", "right");
        ctx.fill(x + 6, y + 16, w - 12, 1, "#6B5A33", 0.8);
        if (keyRow) {
            // the party's run keys (shared: any member's key opens a door)
            var kx = x + 6;
            if ((HUD.keys | 0) > 0) { U.icon(ctx, "smallkey", kx, y + 19, 10); U.text(ctx, "x" + HUD.keys, kx + 12, y + 20, "#FFFFFF", "left", 0.8); kx += 36; }
            if (HUD.bossKey) { U.icon(ctx, "bosskey", kx, y + 19, 10); U.text(ctx, "Boss Key", kx + 12, y + 20, "#FFD060", "left", 0.8); }
        }
        goals.forEach(function (g, i) {
            var gy = y + 20 + keyRow + i * 11;
            U.icon(ctx, g.done ? "check" : "flag", x + 6, gy, 9);
            U.text(ctx, U.fit(ctx, g.text, w - 52), x + 18, gy + 1, g.done ? "#9FE09F" : "#E0E0E0", "left", 0.8);
            U.text(ctx, Math.min(g.cur, g.max) + "/" + g.max, x + w - 6, gy + 1, g.done ? "#9FE09F" : "#C0C0C0", "right", 0.8);
        });
        var fy = y + 20 + keyRow + lines * 11;
        if (HUD.state === "done") U.text(ctx, "Complete!", x + w / 2, fy + 1, "#7CFF7C", "center", 0.9);
        else if (HUD.state === "failed") U.text(ctx, "Time's up!", x + w / 2, fy + 1, "#FF6060", "center", 0.9);
        else if (HUD.exit && goals.every(function (g) { return g.done; })) U.text(ctx, "Head to the exit!", x + w / 2, fy + 1, "#7CFFD0", "center", 0.9);
        else if (!goals.length) U.text(ctx, HUD.exit ? "Find the exit" : "", x + w / 2, fy + 1, "#C0C0C0", "center", 0.8);
        ctx.endGroup();
    });
})();
