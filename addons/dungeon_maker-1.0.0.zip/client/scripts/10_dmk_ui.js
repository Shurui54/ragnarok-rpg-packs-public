// =====================================================================================
//  Dungeon Maker (client) - the little toolkit every dungeon screen is drawn with
// =====================================================================================
//  Screens are drawn on the canvas every frame (panels, cards, buttons from the dungeonpack art
//  pack, plain colours when it isn't installed) with a list of click boxes, plus engine elements
//  for what needs typing or searching: text inputs and searchable dropdowns. Those are kept in
//  numbered slots and only updated when the row they belong to moves or changes.
//
//  A game can restyle the screens without touching this file (any client script, any time):
//     var DMK_CLIENT_THEME = { font: "mypack:smooth", click: "mypack:ui_click" };
// =====================================================================================
var DMK_UI = (function () {
    var TEX = "dungeonpack:textures/gui/";
    var SCREEN = "dmk";
    var S = null;                 // the open screen's state (null when closed)
    var IN_SIG = {};              // text boxes are kept per field (engine inputs keep their own text): element id -> last props
    var artChecked = 0, ART = false;

    function theme() { return typeof DMK_CLIENT_THEME !== "undefined" && DMK_CLIENT_THEME ? DMK_CLIENT_THEME : {}; }
    function art() {
        var t = RPG.nowMs();
        if (t - artChecked > 5000) { artChecked = t; try { ART = RPG.images.has(TEX + "panel.png"); } catch (e) { ART = false; } }
        return ART;
    }
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function inside(x, y, r) { return x >= r.x && y >= r.y && x < r.x + r.w && y < r.y + r.h; }

    // ---- big messages from the server arrive in pieces ----
    var parts = {}, bigHandlers = {};
    RPG.net.on("dmk_big", function (d) {
        if (!d || typeof d.s !== "string") return;
        var box = parts[d.kind];
        if (!box || box.id !== d.id) box = parts[d.kind] = { id: d.id, n: Number(d.n) || 1, got: 0, s: [] };
        if (box.s[d.i] === undefined) { box.s[d.i] = d.s; box.got++; }
        if (box.got < box.n) return;
        delete parts[d.kind];
        var text = box.s.join(""), obj = text;
        if (!d.str) { try { obj = JSON.parse(text); } catch (e) { return; } }
        var h = bigHandlers[d.kind];
        if (h) h(obj);
    });
    function onBig(kind, fn) { bigHandlers[kind] = fn; }
    function send(op, data) { var m = data || {}; m.op = op; RPG.net.send("dmk", m); }

    // ---- entity choices (asked once) ----
    var ENTITIES = null, entityWaiters = [];
    onBig("entities", function (list) { ENTITIES = list || []; var w = entityWaiters; entityWaiters = []; w.forEach(function (f) { f(ENTITIES); }); });
    function entities(fn) { if (ENTITIES) { if (fn) fn(ENTITIES); return ENTITIES; } if (fn) entityWaiters.push(fn); if (entityWaiters.length <= 1) send("entities"); return null; }
    function entityName(id) {
        if (ENTITIES) for (var i = 0; i < ENTITIES.length; i++) if (ENTITIES[i].id === id) return ENTITIES[i].name;
        var p = String(id || "?").split(":"), n = p[p.length - 1].replace(/_/g, " ");
        return n.charAt(0).toUpperCase() + n.substring(1);
    }
    function namespaceOf(id) { var s = String(id); return s.indexOf(":") > 0 ? s.substring(0, s.indexOf(":")) : "minecraft"; }

    // ---- card pictures: uploads arrive as PNG text and become textures ----
    var IMAGES = {}, asked = {};
    onBig("img", function (d) {
        if (!d || !d.id || !d.png) return;
        var tex = null;
        try { tex = RPG.images.register("dmk_card_" + d.id, d.png); } catch (e) { }
        if (tex) IMAGES[d.id] = { h: d.h, tex: tex };
    });
    /** The texture to draw for a card's picture ({kind: "upload"|"path"}), or null (asks the server for uploads). */
    function cardImage(id, img) {
        if (!img) return null;
        if (img.kind === "path") return img.path || null;
        if (img.kind !== "upload") return null;
        var have = IMAGES[id];
        if (have && have.h === img.h) return have.tex;
        var key = id + "@" + img.h;
        if (!asked[key]) { asked[key] = true; send("img_get", { id: id }); }
        return have ? have.tex : null;
    }
    function forgetImage(id) { delete IMAGES[id]; Object.keys(asked).forEach(function (k) { if (k.indexOf(id + "@") === 0) delete asked[k]; }); }

    // ---- the screen ----
    function open(state, opts) {
        var fresh = !S, old = S;
        S = state;
        S.hits = []; S.ddN = 0; S.inN = 0;
        S.ddMax = old ? old.ddMax : 0; S.inMax = old ? old.inMax : 0; S.ddSig = {}; S.inSig = {};
        for (var d = 0; d < S.ddMax; d++) S.ddSig["dd" + d] = "";        // re-sent (or hidden) on the next frame
        for (var i = 0; i < S.inMax; i++) S.inSig["in" + i] = "";
        S.scroll = S.scroll || {}; S.lists = []; S.msg = S.msg || ""; S.msgUntil = S.msgUntil || 0;
        if (fresh || RPG.screen.getOpen() !== SCREEN) {
            S.ddMax = 0; S.inMax = 0; S.ddSig = {}; S.inSig = {}; IN_SIG = {};
            RPG.screen.open({ id: SCREEN, referenceHeight: 300, background: "dim", pause: false, elements: [],
                onBackground: render, onRender: renderTop, onMouse: mouse, onScroll: scroll, onKey: key,
                onClose: function () { var c = S && S.onClose; S = null; if (c) c(); } });
        }
    }
    function close() { if (S) { S.onClose = null; } RPG.screen.close(); S = null; }
    function state() { return S; }
    function status(text, color) { if (!S) return; S.msg = String(text); S.msgColor = color || "#FFFFFF"; S.msgUntil = RPG.nowMs() + 4500; }

    function render(ctx) {
        if (!S) return;
        S.hits = []; S.lists = []; S.ddN = 0; S.inN = 0; S.tip = null; S.inUsed = {}; S.newEls = 0;
        S.ctx = ctx;
        try { if (S.draw) S.draw(ctx, S); } catch (e) { RPG.log("[Dungeon Maker] screen: " + e); }
        // engine elements no row used this frame are hidden
        for (var d = S.ddN; d < S.ddMax; d++) if (S.ddSig["dd" + d] !== "hidden") { RPG.screen.update("dmk_dd" + d, { visible: false }); S.ddSig["dd" + d] = "hidden"; }
        S.ddMax = Math.max(S.ddMax, S.ddN);
        for (var el in IN_SIG) if (!S.inUsed[el] && IN_SIG[el] !== "hidden") { RPG.screen.update(el, { visible: false }); IN_SIG[el] = "hidden"; }
        var left = S.msgUntil - RPG.nowMs();
        if (left > 0 && S.msg) text(ctx, S.msg, ctx.width / 2, ctx.height - 16, S.msgColor, "center", 1, Math.min(1, left / 600));
    }
    function renderTop(ctx) {
        if (!S) return;
        if (S.drawTop) { try { S.drawTop(ctx, S); } catch (e) { } }
        for (var i = S.hits.length - 1; i >= 0; i--) {
            var h = S.hits[i];
            if (h.tip && inside(ctx.mouseX, ctx.mouseY, h)) { tooltip(ctx, typeof h.tip === "string" ? [h.tip] : h.tip, ctx.mouseX, ctx.mouseY); break; }
        }
    }
    function mouse(x, y, button, action) {
        if (!S || action !== "down") return;
        for (var i = S.hits.length - 1; i >= 0; i--) {
            var h = S.hits[i];
            if ((h.fn || h.right) && inside(x, y, h)) {
                var f = button === 1 ? h.right || null : button === 0 ? h.fn : null;
                if (!f) continue;
                click();
                f(x, y);
                return false;
            }
        }
    }
    function scroll(x, y, delta) {
        if (!S) return;
        if (S.onScroll && S.onScroll(x, y, delta) === true) return;
        for (var i = S.lists.length - 1; i >= 0; i--) {
            var L = S.lists[i];
            if (inside(x, y, { x: L.x, y: L.y, w: L.w + 8, h: L.h })) {
                S.scroll[L.key] = clamp((S.scroll[L.key] || 0) - (delta > 0 ? 1 : -1) * L.step, 0, Math.max(0, L.total - L.h));
                return;
            }
        }
    }
    function key(name, action) {
        if (!S || action !== "down") return;
        if (name === "key.keyboard.escape" && S.back) { S.back(); return false; }
        if (S.onKey) return S.onKey(name);
    }
    function click() { try { RPG.sound(theme().click || "minecraft:ui.button.click", 0.25, 1.2); } catch (e) { } }

    // ---- drawing ----
    function font() { return theme().font || null; }
    function text(ctx, t, x, y, color, align, scale, alpha) {
        var a = align === "center" ? 0.5 : align === "right" ? 1 : 0;
        ctx.textStyled(String(t), x, y, scale || 1, color || "#FFFFFF", alpha === undefined ? 1 : alpha, a, font(), theme().outline || null);
    }
    function tw(ctx, t, scale) { return ctx.textWidthIn(String(t), font()) * (scale || 1); }
    function fit(ctx, t, w, scale) {
        t = String(t);
        if (tw(ctx, t, scale) <= w) return t;
        while (t.length > 1 && tw(ctx, t + "...", scale) > w) t = t.substring(0, t.length - 1);
        return t + "...";
    }
    /** Word-wraps text into lines no wider than w. */
    function wrap(ctx, t, w, scale) {
        var out = [];
        String(t || "").split("\n").forEach(function (para) {
            var line = "";
            para.split(" ").forEach(function (word) {
                var test = line ? line + " " + word : word;
                if (tw(ctx, test, scale) > w && line) { out.push(line); line = word; } else line = test;
            });
            out.push(line);
        });
        return out;
    }
    function hit(x, y, w, h, fn, tip, right) { var r = { x: x, y: y, w: w, h: h, fn: fn, tip: tip, right: right }; S.hits.push(r); return r; }
    function over(ctx, x, y, w, h) { return inside(ctx.mouseX, ctx.mouseY, { x: x, y: y, w: w, h: h }); }

    function slice(ctx, file, x, y, w, h, u, v, uw, vh, tw0, th0, border, alpha) {
        ctx.nineSlice(TEX + file, x, y, w, h, u, v, uw, vh, tw0, th0, border, border, alpha === undefined ? 1 : alpha);
    }
    /** The big stone panel with an optional title plaque. */
    function panel(ctx, x, y, w, h, title) {
        if (art()) slice(ctx, "panel.png", x, y, w, h, 0, 0, 32, 32, 32, 32, 8);
        else { ctx.fill(x, y, w, h, "#1B1D26", 0.96); ctx.fill(x, y, w, 2, "#8C7A4A", 1); ctx.fill(x, y + h - 2, w, 2, "#0A0B10", 1); }
        if (title) {
            var tw2 = Math.min(w - 40, Math.max(120, tw(ctx, title) + 40));
            if (art()) slice(ctx, "title.png", x + (w - tw2) / 2, y - 7, tw2, 20, 0, 0, 48, 20, 48, 20, 10);
            else ctx.fill(x + (w - tw2) / 2, y - 7, tw2, 20, "#5A3E1A", 1);
            text(ctx, title, x + w / 2, y - 1, "#FFE9A8", "center", 1);
        }
    }
    function inset(ctx, x, y, w, h, alpha) {
        if (art()) slice(ctx, "inset.png", x, y, w, h, 0, 0, 16, 16, 16, 16, 4, alpha);
        else { ctx.fill(x, y, w, h, "#0C0D12", 0.85); ctx.fill(x, y, w, 1, "#000000", 1); ctx.fill(x, y + h - 1, w, 1, "#3A3D4C", 1); }
    }
    /** A button: kind "normal" | "green" | "red" | "gold"; opt {disabled, tip, selected}. */
    function button(ctx, label, x, y, w, h, fn, opt) {
        opt = opt || {};
        var dis = !!opt.disabled, hov = !dis && over(ctx, x, y, w, h), kind = opt.kind || "normal";
        var row = dis ? 2 : hov || opt.selected ? 1 : 0;
        if (art()) slice(ctx, "button_" + kind + ".png", x, y, w, h, 0, row * 20, 48, 20, 48, 60, 4);
        else {
            var base = { normal: "#3C4050", green: "#2F6B33", red: "#7A2C2C", gold: "#7A5E22" }[kind] || "#3C4050";
            ctx.fill(x, y, w, h, dis ? "#2A2A2E" : base, 1);
            ctx.fill(x, y, w, 1, "#FFFFFF", hov ? 0.5 : 0.2);
            ctx.fill(x, y + h - 1, w, 1, "#000000", 0.6);
        }
        var col = dis ? "#8A8A8A" : hov ? "#FFF6C0" : "#FFFFFF";
        if (opt.icon !== undefined) {
            icon(ctx, opt.icon, x + 4, y + (h - 12) / 2, 12);
            text(ctx, fit(ctx, label, w - 22), x + 18 + (w - 22) / 2, y + (h - 8) / 2, col, "center");
        } else text(ctx, fit(ctx, label, w - 6), x + w / 2, y + (h - 8) / 2, col, "center");
        if (!dis) hit(x, y, w, h, fn, opt.tip);
        else if (opt.tip) hit(x, y, w, h, null, opt.tip);
    }
    /** 16x16 icons from icons.png, drawn at size. */
    var ICONS = { skull: 0, clock: 1, hourglass: 2, chest: 3, key: 4, lock: 5, star: 6, sword: 7, check: 8, cross: 9, plus: 10, trash: 11, pencil: 12, left: 13, right: 14, search: 15,
        spawner: 16, entry: 17, exit: 18, door: 19, loot: 20, anchor: 21, flag: 22, map: 23, eye: 24, export: 25, back: 26, up: 27, down: 28, info: 29, image: 30, user: 31 };
    // the second sheet (icons2.png, 16 more): the newer module types and run items
    var ICONS2 = { "switch": 0, logic: 1, sk_door: 2, bk_door: 3, pz_door: 4, sk_chest: 5, bk_chest: 6, pz_chest: 7, bridge: 8, boss: 9,
        smallkey: 10, bosskey: 11, heart: 12, link: 13, bomb: 14, zone: 15 };
    var art2Checked = 0, ART2 = false;
    function art2() {
        var t = RPG.nowMs();
        if (t - art2Checked > 5000) { art2Checked = t; try { ART2 = RPG.images.has(TEX + "icons2.png"); } catch (e) { ART2 = false; } }
        return ART2;
    }
    function icon(ctx, name, x, y, size, alpha) {
        var j = ICONS2[name];
        if (j !== undefined) {
            if (art2()) ctx.quad(TEX + "icons2.png", x, y, size, size, j / 16, 0, (j + 1) / 16, 1, "#FFFFFF", alpha === undefined ? 1 : alpha);
            else ctx.fill(x + 2, y + 2, size - 4, size - 4, "#C9B57A", 0.8 * (alpha === undefined ? 1 : alpha));
            return;
        }
        var i = ICONS[name];
        if (i === undefined) return;
        if (art()) ctx.quad(TEX + "icons.png", x, y, size, size, (i % 16) / 16, Math.floor(i / 16) / 2, (i % 16 + 1) / 16, (Math.floor(i / 16) + 1) / 2, "#FFFFFF", alpha === undefined ? 1 : alpha);
        else {
            var c = { check: "#6BD66B", cross: "#E05050", plus: "#6BD66B", trash: "#E05050" }[name] || "#C9B57A";
            ctx.fill(x + 2, y + 2, size - 4, size - 4, c, 0.8 * (alpha === undefined ? 1 : alpha));
        }
    }
    function iconButton(ctx, name, x, y, size, fn, tip, disabled) {
        var hov = !disabled && over(ctx, x, y, size, size);
        if (hov) ctx.fill(x - 1, y - 1, size + 2, size + 2, "#FFFFFF", 0.18);
        icon(ctx, name, x, y, size, disabled ? 0.35 : 1);
        if (!disabled) hit(x, y, size, size, fn, tip); else if (tip) hit(x, y, size, size, null, tip);
    }
    function toggle(ctx, on, x, y, fn, tip) {
        var w = 22, h = 11;
        ctx.fill(x, y, w, h, "#000000", 0.8);
        ctx.fill(x + 1, y + 1, w - 2, h - 2, on ? "#3E8E41" : "#5A2B2B", 1);
        ctx.fill(on ? x + w - 10 : x + 1, y + 1, 9, h - 2, "#E8E8E8", 1);
        hit(x, y, w, h, fn, tip);
    }
    function itemSlot(ctx, stack, x, y, opt) {
        opt = opt || {};
        if (art()) ctx.image(TEX + "slot.png", x, y, 18, 18, 0, 0, 18, 18, 18, 18);
        else { ctx.fill(x, y, 18, 18, "#000000", 0.55); ctx.fill(x + 1, y + 1, 16, 16, "#2B2B34", 1); }
        if (opt.selected) ctx.fill(x, y, 18, 18, "#FFE070", 0.35);
        if (stack && stack.id) {
            ctx.item(stack.id, x + 1, y + 1);
            if ((stack.count | 0) > 1) text(ctx, String(stack.count), x + 17, y + 10, "#FFFFFF", "right", 0.75);
        }
        if (over(ctx, x, y, 18, 18)) ctx.fill(x + 1, y + 1, 16, 16, "#FFFFFF", 0.25);
    }
    function difficultyPips(ctx, d, x, y) {
        var cols = ["#7CD66B", "#E6D25A", "#E8963C", "#E05048", "#B060F0"];
        for (var i = 0; i < 5; i++) {
            ctx.fill(x + i * 7, y, 6, 6, "#000000", 0.8);
            ctx.fill(x + i * 7 + 1, y + 1, 4, 4, i <= d ? cols[d] : "#3A3A44", 1);
        }
    }
    var DIFFICULTIES = ["Easy", "Medium", "Hard", "Very Hard", "Epic"];
    var DIFF_COLORS = ["#7CD66B", "#E6D25A", "#E8963C", "#E05048", "#B060F0"];
    function tooltip(ctx, lines, mx, my) {
        if (!lines || !lines.length) return;
        var w = 0;
        lines.forEach(function (l) { w = Math.max(w, tw(ctx, l, 1)); });
        var h = lines.length * 10 + 6, x = Math.min(mx + 10, ctx.width - w - 12), y = Math.min(my + 10, ctx.height - h - 4);
        if (art()) slice(ctx, "tooltip.png", x, y, w + 10, h, 0, 0, 16, 16, 16, 16, 4);
        else { ctx.fill(x, y, w + 10, h, "#100A18", 0.95); ctx.fill(x, y, w + 10, 1, "#5A2CA0", 1); ctx.fill(x, y + h - 1, w + 10, 1, "#28104A", 1); }
        lines.forEach(function (l, i) { text(ctx, l, x + 5, y + 4 + i * 10, i === 0 ? "#FFE070" : "#D0D0D0"); });
    }
    function scrollbar(ctx, x, top, h, total, pos) {
        if (total <= h) return;
        var th = Math.max(14, h * h / total), ty = top + (h - th) * pos / (total - h);
        ctx.fill(x, top, 3, h, "#000000", 0.4);
        ctx.fill(x, ty, 3, th, "#C9B57A", 1);
    }
    /** A clipped scrolling list; drawRow(row, i, y) draws each visible row. */
    function list(ctx, key, x, y, w, h, rows, rowH, drawRow) {
        var total = rows.length * rowH;
        S.scroll[key] = clamp(S.scroll[key] || 0, 0, Math.max(0, total - h));
        var pos = S.scroll[key];
        S.lists.push({ key: key, x: x, y: y, w: w, h: h, total: total, step: rowH * 2 });
        ctx.clip(x, y, w, h);
        var first = S.hits.length;
        S.clipTop = y; S.clipBottom = y + h;
        rows.forEach(function (r, i) {
            var ry = y + i * rowH - pos;
            if (ry + rowH < y || ry > y + h) return;
            drawRow(r, i, ry);
        });
        S.clipTop = null; S.clipBottom = null;
        ctx.unclip();
        for (var k = S.hits.length - 1; k >= first; k--) { var hb = S.hits[k]; if (hb.y + hb.h <= y || hb.y >= y + h) S.hits.splice(k, 1); }
        scrollbar(ctx, x + w + 2, y, h, total, pos);
    }
    function clipped(y, h) { return S.clipTop !== null && S.clipTop !== undefined && (y < S.clipTop || y + h > S.clipBottom); }

    // ---- engine elements in slots ----
    /** A searchable dropdown at (x, y). options: [{value, label, icon?, tooltip?}]; onChange(value). */
    function dropdown(ctx, key, x, y, w, h, options, value, onChange, opt) {
        opt = opt || {};
        if (clipped(y, h)) return;
        var id = "dd" + (S.ddN++), el = "dmk_" + id;
        var sig = [key, Math.round(x), Math.round(y), w, h, String(value), !!opt.disabled, options.length, options.length ? options[0].value + options[options.length - 1].value : ""].join("|");
        if (S.ddSig[id] === sig) return;
        if (S.newEls++ >= 4) return;
        S.ddSig[id] = sig;
        RPG.screen.update(el, { type: "dropdown", anchor: "topleft", x: x, y: y, w: w, h: h, visible: true, options: options, value: value,
            placeholder: opt.placeholder || "Choose...", search: opt.search, searchHint: opt.searchHint || "Search...", emptyText: "Nothing matches",
            custom: !!opt.custom, customLabel: opt.customLabel, disabled: !!opt.disabled, listWidth: Math.max(w, opt.listWidth || 160), maxVisible: opt.maxVisible || 10,
            bg: "#14151C", border: "#6B5A33", highlight: "#4A3E22", textColor: "#FFFFFF", listBg: "#101118", selectedBg: "#5A4A22", selectedText: "#FFE9A8",
            onChange: function (eid, v) { if (S) { try { onChange(v); } catch (e) { RPG.log("[Dungeon Maker] " + e); } } } });
    }
    /** A text box at (x, y). onChange(text) on every keystroke; the box keeps its own text until the key changes. */
    function input(ctx, key, x, y, w, h, value, onChange, opt) {
        opt = opt || {};
        if (clipped(y, h)) return;
        inset(ctx, x - 2, y - 2, w + 4, h + 4);
        var el = "dmk_in_" + String(key).replace(/[^A-Za-z0-9_]/g, "_");
        S.inUsed[el] = 1;
        var sig = [Math.round(x), Math.round(y), w, h].join("|");
        if (IN_SIG[el] === sig) return;
        if (IN_SIG[el] === undefined && S.newEls++ >= 2) { S.inUsed[el] = 0; return; }   // a few new boxes per frame
        IN_SIG[el] = sig;
        RPG.screen.update(el, { type: "input", anchor: "topleft", x: x, y: y, w: w, h: h, visible: true, value: value === undefined || value === null ? "" : String(value),
            maxLength: opt.maxLength || 64, hint: opt.hint || "", bordered: false, autofocus: !!opt.autofocus,
            onChange: function (eid, v) { if (S) onChange(String(v)); } });
    }
    /** Forget the slots (after a view change), so the next frame re-sends every element. */
    function resetElements() { if (!S) return; S.ddSig = {}; for (var d = 0; d < S.ddMax; d++) S.ddSig["dd" + d] = ""; for (var el in IN_SIG) if (IN_SIG[el] !== "hidden") IN_SIG[el] = ""; }

    // ---- labelled rows (num / text / choice / bool), like the form editor's ----
    function numField(ctx, key, x, y, w, value, onChange, opt) {
        opt = opt || {};
        input(ctx, key, x, y + 2, w, 10, value === undefined || value === null ? "" : String(value), function (t) {
            if (t.trim() === "") { onChange(opt.blank !== undefined ? opt.blank : null); return; }
            var n = Number(t);
            if (!isNaN(n)) onChange(opt.int ? Math.round(n) : n);
        }, { maxLength: 12, hint: opt.hint });
    }
    function label(ctx, t, x, y, w, color) { text(ctx, fit(ctx, t, w), x, y + 3, color || "#D8D2C0"); }

    return {
        TEX: TEX, DIFFICULTIES: DIFFICULTIES, DIFF_COLORS: DIFF_COLORS, art: art, clamp: clamp, inside: inside,
        onBig: onBig, send: send, entities: entities, entityName: entityName, namespaceOf: namespaceOf, cardImage: cardImage, forgetImage: forgetImage,
        open: open, close: close, state: state, status: status, resetElements: resetElements,
        text: text, tw: tw, fit: fit, wrap: wrap, hit: hit, over: over, panel: panel, inset: inset, button: button, icon: icon, iconButton: iconButton,
        toggle: toggle, itemSlot: itemSlot, difficultyPips: difficultyPips, tooltip: tooltip, list: list, dropdown: dropdown, input: input,
        numField: numField, label: label, slice: slice
    };
})();
