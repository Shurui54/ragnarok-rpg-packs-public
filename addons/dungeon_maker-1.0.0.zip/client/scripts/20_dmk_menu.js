// =====================================================================================
//  Dungeon Maker (client) - the Dungeon Selection menu, its admin tools and the card editor
// =====================================================================================
//  Menu: search, pages of cards (picture, level, difficulty), and the chosen dungeon's details:
//  information, entry requirements (green = met), goals, possible rewards, description, with
//  Enter / Leave. Staff switch on Admin for + New, Card, Publish, Plot, Delete, Export and Back.
//  Card editor: name, level, time, difficulty, time limit, cooldown, description, icon (item in
//  hand), picture (a texture path, or a picture from the computer's game folder, uploaded and
//  shared with everyone), entry requirements and completion goals.
// =====================================================================================
var DMK_MENU = (function () {
    var U = DMK_UI;
    var MENU = null, CARD = null, wantOpen = false, adminMode = false;
    var PER_PAGE = 6;

    U.onBig("menu", function (m) {
        MENU = m;
        var S = U.state();
        if ((m.open || wantOpen) && !(S && S.view === "menu")) { wantOpen = false; openMenu(m.select); return; }
        wantOpen = false;
        if (S && S.view === "menu") { if (m.select) S.sel = m.select; }
    });
    RPG.net.on("dmk_close", function () { var S = U.state(); if (S) U.close(); });
    RPG.net.on("dmk_msg", function (d) { if (d && U.state()) U.status(d.msg, d.ok ? "#7CFF7C" : "#FF7070"); });
    U.onBig("card", function (c) { CARD = c; var S = U.state(); if (S && S.view === "card" && S.card && S.card.id === c.id) S.card = editable(c); else openCard(c); });

    function request() { wantOpen = true; U.send("menu"); }

    // =================================================================================
    //  The menu
    // =================================================================================
    function cards() { return MENU ? MENU.cards : []; }
    function filtered(S) {
        var q = (S.search || "").toLowerCase().trim();
        return cards().filter(function (c) { return !q || c.name.toLowerCase().indexOf(q) >= 0 || c.id.indexOf(q) >= 0 || (c.description || "").toLowerCase().indexOf(q) >= 0; });
    }
    function selected(S) { var l = cards(); for (var i = 0; i < l.length; i++) if (l[i].id === S.sel) return l[i]; return null; }

    function openMenu(select) {
        var S = { view: "menu", search: "", page: 0, sel: select || (cards()[0] ? cards()[0].id : null), confirm: null };
        S.draw = drawMenu;
        S.back = function () { U.close(); };
        U.open(S);
    }

    function drawMenu(ctx, S) {
        var W = 500, H = 276, x = Math.floor((ctx.width - W) / 2), y = Math.floor((ctx.height - H) / 2) + 4;
        U.panel(ctx, x, y, W, H, "Dungeon Selection");
        if (!MENU) { U.text(ctx, "Loading...", x + W / 2, y + H / 2, "#D0D0D0", "center"); return; }
        var admin = MENU.admin && adminMode, per = admin ? 4 : PER_PAGE;
        var list = filtered(S), pages = Math.max(1, Math.ceil(list.length / per));
        S.page = U.clamp(S.page, 0, pages - 1);
        if (S.sel && !selected(S)) S.sel = list[0] ? list[0].id : null;
        // ---- left: search, cards, pages ----
        var lx = x + 14, ly = y + 18;
        U.icon(ctx, "search", lx, ly + 1, 12);
        U.input(ctx, "search", lx + 18, ly + 2, 220, 10, S.search, function (t) { S.search = t; S.page = 0; }, { hint: "Search...", maxLength: 40 });
        var cw = 120, ch = 60, gx = lx, gy = ly + 20;
        if (!list.length) {
            U.text(ctx, cards().length ? "Nothing matches the search" : "No dungeons available", gx + cw + 3, gy + 80, "#A0A0A0", "center");
            if (MENU.admin && !cards().length) U.text(ctx, "Switch on Admin and press + New to make one", gx + cw + 3, gy + 94, "#808080", "center", 0.8);
        }
        list.slice(S.page * per, S.page * per + per).forEach(function (c, i) {
            var cx = gx + (i % 2) * (cw + 6), cy = gy + Math.floor(i / 2) * (ch + 5);
            drawCard(ctx, c, cx, cy, cw, ch, c.id === S.sel, function () { S.sel = c.id; });
        });
        var py = y + H - 26;
        U.iconButton(ctx, "left", lx + 120, py, 12, function () { S.page = Math.max(0, S.page - 1); }, "Previous page", S.page <= 0);
        U.text(ctx, (S.page + 1) + " / " + pages, lx + 160, py + 2, "#D8D2C0", "center");
        U.iconButton(ctx, "right", lx + 188, py, 12, function () { S.page = Math.min(pages - 1, S.page + 1); }, "Next page", S.page >= pages - 1);
        // ---- right: details ----
        var rx = x + 268, ry = y + 18, rw = W - 268 - 14;
        var c = selected(S);
        U.inset(ctx, rx - 4, ry - 4, rw + 8, 216);
        if (c) drawDetails(ctx, S, c, rx, ry, rw, 208);
        else U.text(ctx, "Pick a dungeon", rx + rw / 2, ry + 90, "#909090", "center");
        // ---- bottom buttons ----
        var by = y + H - 30;
        if (MENU.inRun) U.button(ctx, "Leave Dungeon", rx, by, rw, 20, function () { U.send("leave"); }, { kind: "red", icon: "back", tip: ["Leave Dungeon", "Teleports you back; the run is thrown away for you"] });
        else U.button(ctx, "Enter Dungeon", rx, by, rw, 20, function () { if (c) U.send("enter", { id: c.id }); }, { kind: "green", icon: "entry", disabled: !c,
            tip: c ? enterTip(c) : null });
        if (MENU.admin) {
            U.button(ctx, adminMode ? "Admin ✔" : "Admin", lx, by, 60, 20, function () { adminMode = !adminMode; }, { kind: "gold", selected: adminMode, tip: ["Dungeon management", "Create, edit, publish and delete dungeons"] });
            if (adminMode) drawAdmin(ctx, S, c, lx, gy + 2 * (ch + 5) + 3);
        }
        if (S.confirm) drawConfirm(ctx, S, x, y, W, H);
    }
    function enterTip(c) {
        var lines = ["Enter " + c.name];
        if (c.status !== "published") lines.push("§cDraft: only staff can enter");
        if (c.cdLeft > 0) lines.push("§cOn cooldown: " + human(c.cdLeft));
        c.reqs.forEach(function (r) { if (!r.ok) lines.push("§c✘ " + r.text); });
        lines.push("§7Your party nearby comes along");
        return lines;
    }
    function human(s) { s = Math.max(0, Math.round(s)); var h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60, o = []; if (h) o.push(h + "h"); if (m) o.push(m + "m"); if (x || !o.length) o.push(x + "s"); return o.join(" "); }

    function banner(ctx, c, x, y, w, h) {
        var tex = U.cardImage(c.id, c.image);
        if (tex) coverImage(ctx, tex, c.image, x, y, w, h);
        else if (U.art()) ctx.image(U.TEX + "card_banner.png", x, y, w, h, 0, 0, 96, 32, 96, 32);
        else { ctx.gradient(x, y, w, h, "#2A2C3A", "#15161E"); }
        if (!tex && c.icon && c.icon.id) ctx.item(c.icon.id, x + w / 2 - 8, y + h / 2 - 8);
    }
    /** Draws a picture filling the box, cropping the middle when its shape differs (size known for uploads). */
    function coverImage(ctx, tex, img, x, y, w, h) {
        var iw = img && img.w, ih = img && img.ht;
        if (!iw || !ih) { ctx.image(tex, x, y, w, h, 0, 0, 1, 1, 1, 1); return; }
        var box = w / h, pic = iw / ih, u0 = 0, v0 = 0, u1 = 1, v1 = 1;
        if (pic > box) { var k = box / pic; u0 = (1 - k) / 2; u1 = 1 - u0; } else { var q = pic / box; v0 = (1 - q) / 2; v1 = 1 - v0; }
        ctx.quad(tex, x, y, w, h, u0, v0, u1, v1, "#FFFFFF", 1);
    }
    function drawCard(ctx, c, x, y, w, h, sel, fn) {
        var hov = U.over(ctx, x, y, w, h);
        if (U.art()) U.slice(ctx, sel ? "card_selected.png" : "card.png", x, y, w, h, 0, 0, 24, 24, 24, 24, 6);
        else { ctx.fill(x, y, w, h, sel ? "#3A3220" : "#20222C", 1); ctx.fill(x, y, w, 1, sel ? "#E8C860" : "#5A5E70", 1); }
        banner(ctx, c, x + 4, y + 4, w - 8, 32);
        if (c.icon && c.icon.id && U.cardImage(c.id, c.image)) ctx.item(c.icon.id, x + 6, y + 6);
        if (hov && !sel) ctx.fill(x + 4, y + 4, w - 8, h - 8, "#FFFFFF", 0.08);
        U.text(ctx, U.fit(ctx, c.name, w - 10), x + 5, y + 39, sel ? "#FFE9A8" : "#FFFFFF");
        U.text(ctx, c.level ? "Lv " + c.level : "Lv -", x + 5, y + 51, "#B8B0A0", "left", 0.8);
        U.difficultyPips(ctx, c.difficulty, x + w - 41, y + 52);
        if (c.status !== "published") { ctx.fill(x + w - 38, y + 6, 32, 9, "#000000", 0.6); U.text(ctx, "draft", x + w - 22, y + 7, "#FFB040", "center", 0.75); }
        else if (c.cdLeft > 0) { ctx.fill(x + w - 50, y + 6, 44, 9, "#000000", 0.6); U.text(ctx, human(c.cdLeft), x + w - 28, y + 7, "#FF8080", "center", 0.75); }
        if (c.completed > 0) U.icon(ctx, "check", x + w - 16, y + 39, 10);
        U.hit(x, y, w, h, fn, [c.name, U.DIFFICULTIES[c.difficulty] + (c.level ? " · level " + c.level : "")]);
    }

    function drawDetails(ctx, S, c, x, y, w, h) {
        var rows = [];
        rows.push({ h: 64, draw: function (ry) { banner(ctx, c, x, ry, w, 60); } });
        rows.push({ h: 24, draw: function (ry) {
            U.text(ctx, U.fit(ctx, c.name, w - 50), x, ry + 2, "#FFE9A8", "left", 1.15);
            U.text(ctx, U.DIFFICULTIES[c.difficulty], x + w, ry + 3, U.DIFF_COLORS[c.difficulty], "right");
            U.text(ctx, (c.source === "file" ? "from file" : "by " + (c.author || "?")) + (c.status !== "published" ? " · draft" : ""), x, ry + 14, "#8A8478", "left", 0.75);
        } });
        rows.push(head("Information"));
        rows.push(infoRow("sword", "Recommended level", c.level || "-"));
        rows.push(infoRow("hourglass", "Time limit", c.timeLimit > 0 ? human(c.timeLimit) : "none"));
        rows.push(infoRow("clock", "Time", c.time || "-"));
        rows.push(infoRow("lock", "Cooldown", c.cooldown > 0 ? human(c.cooldown) + (c.cdLeft > 0 ? "  (" + human(c.cdLeft) + " left)" : "") : "none"));
        if (c.completed > 0) rows.push(infoRow("check", "Finished", c.completed + "x"));
        rows.push(head("Requirements"));
        if (!c.reqs.length) rows.push(textRow("None", "#9A9A9A"));
        c.reqs.forEach(function (r) { rows.push({ h: 11, draw: function (ry) { U.icon(ctx, r.ok ? "check" : "cross", x, ry, 9); U.text(ctx, U.fit(ctx, r.text, w - 14), x + 12, ry + 1, r.ok ? "#9FE09F" : "#FF8A8A", "left", 0.85); } }); });
        if (c.goals.length) { rows.push(head("Goals")); c.goals.forEach(function (g) { rows.push(textRow("• " + g, "#D8D2C0")); }); }
        if (c.rewards.length) {
            rows.push(head("Possible rewards"));
            var perRow = Math.floor(w / 19);
            for (var i = 0; i < c.rewards.length; i += perRow) (function (slice) {
                rows.push({ h: 20, draw: function (ry) { slice.forEach(function (s, j) { U.itemSlot(ctx, s, x + j * 19, ry); if (U.over(ctx, x + j * 19, ry, 18, 18)) U.hit(x + j * 19, ry, 18, 18, null, [itemLabel(s.id)]); }); } });
            })(c.rewards.slice(i, i + perRow));
        }
        rows.push(head("Description"));
        U.wrap(ctx, c.description || "No description", w - 4, 0.85).forEach(function (l) { rows.push(textRow(l, c.description ? "#D0D0D0" : "#8A8A8A")); });
        if (MENU.admin && adminMode) {
            rows.push(head("Anchors"));
            var a = c.anchors || {};
            var doors = (a.door | 0) + (a.sk_door | 0) + (a.bk_door | 0) + (a.pz_door | 0), chests = (a.loot | 0) + (a.sk_chest | 0) + (a.bk_chest | 0) + (a.pz_chest | 0);
            rows.push(textRow("Spawners " + (a.spawner | 0) + " · Bosses " + (a.boss | 0) + " · Entry " + (a.entry | 0) + " · Exit " + (a.exit | 0), "#B0C8E0"));
            rows.push(textRow("Doors " + doors + " · Chests " + chests + " · Switches " + (a["switch"] | 0) + " · Gates " + (a.logic | 0) + " · Bridges " + (a.bridge | 0), "#B0C8E0"));
        }
        // flatten variable-height rows into a scroll list
        var flat = [], yy = 0;
        rows.forEach(function (r) { flat.push({ r: r, y: yy }); yy += r.h; });
        var key = "details_" + c.id, total = yy;
        S.scroll[key] = U.clamp(S.scroll[key] || 0, 0, Math.max(0, total - h));
        var pos = S.scroll[key];
        S.lists.push({ key: key, x: x, y: y, w: w, h: h, total: total, step: 20 });
        ctx.clip(x, y, w, h);
        flat.forEach(function (f) { var ry = y + f.y - pos; if (ry + f.r.h >= y && ry <= y + h) f.r.draw(ry); });
        ctx.unclip();
        if (total > h) { var th = Math.max(14, h * h / total); ctx.fill(x + w + 1, y, 2, h, "#000000", 0.4); ctx.fill(x + w + 1, y + (h - th) * pos / (total - h), 2, th, "#C9B57A", 1); }
        function head(t) { return { h: 15, draw: function (ry) { U.text(ctx, t, x, ry + 4, "#E8C860"); ctx.fill(x, ry + 13, w, 1, "#6B5A33", 0.8); } }; }
        function infoRow(ic, k, v) { return { h: 12, draw: function (ry) { U.icon(ctx, ic, x, ry, 10); U.text(ctx, k, x + 13, ry + 1, "#B8B0A0", "left", 0.85); U.text(ctx, U.fit(ctx, v, w / 2), x + w, ry + 1, "#FFFFFF", "right", 0.85); } }; }
        function textRow(t, col) { return { h: 10, draw: function (ry) { U.text(ctx, t, x, ry + 1, col, "left", 0.85); } }; }
    }
    function itemLabel(id) { var p = String(id).split(":"), n = p[p.length - 1].replace(/_/g, " "); return RPG.hasTranslation("item." + p[0] + "." + p[1]) ? RPG.translate("item." + p[0] + "." + p[1]) : RPG.hasTranslation("block." + p[0] + "." + p[1]) ? RPG.translate("block." + p[0] + "." + p[1]) : n; }

    function drawAdmin(ctx, S, c, x, y) {
        var file = c && c.source === "file", can = c && !file;
        var b = [
            ["+ New", function () { openCreate(); }, false, ["New dungeon", "Makes a draft, gives it a workshop plot and takes you there"]],
            ["Card", function () { U.send("card", { id: c.id }); }, !can, ["Edit the card", "Name, level, difficulty, timer, picture, rules, goals"]],
            [c && c.status === "published" ? "Unpubl." : "Publish", function () { U.send("publish", { id: c.id }); }, !can, ["Publish / unpublish", "Drafts are only shown to staff"]],
            ["Plot", function () { U.send("plot", { id: c.id }); }, !can, ["Go to its workshop plot"]],
            ["Paint", function () { DMK_PAINTER.open(c.id); }, !can, ["Dungeon painter", "Paint the dungeon as a top-down map", "and generate it into the plot"]],
            ["Delete", function () { S.confirm = c; }, !can, ["Delete the dungeon"]],
            ["Export", function () { U.send("export", { id: c.id }); U.status("Exporting...", "#FFE070"); }, !can, ["Export to a file", "Saved in ragnarok_rpg/shared/dungeons in the game folder:", "every world loads it after /rpg reload"]],
            ["Back", function () { U.send("back"); }, !MENU.inWorkshop, ["Back to where you were before the workshop"]],
            ["Wands", function () { U.send("wands"); }, false, ["Get the four building wands", "Dungeon Wand: the dungeon's bounds", "Room Wand: named rooms and their rules", "Puzzle Wand: puzzles, goals and rewards",
                "Connection Wand: wireless links and redstone", "Right-click the air with one for its screen (? explains it)", "Also /dungeons wand <dungeon|room|puzzle|connection>"]],
            ["Import", function () { U.send("import", { id: c.id }); U.status("Importing...", "#FFE070"); }, !file, ["Import into this world", "Makes an editable copy of an exported dungeon", "(blocks, modules, rooms, puzzles, links, painted map)", "with its own workshop plot"]],
            ["Anchors", function () { U.send("anchors"); }, false, ["Get the module blocks", "Spawners, boss, entry, exit, switches, logic gates,", "key / puzzle doors, chests, bridges, the plain anchor,", "Cracked Bricks, Grapple Targets, Push Blocks and the", "2-tall Small Key and Boss Doors.", "/dungeons kit gives the dungeon items to test with"]]
        ];
        b.forEach(function (e, i) {
            var col = i % 4, row = Math.floor(i / 4);
            U.button(ctx, e[0], x + col * 62, y + row * 23, 59, 20, e[1], { disabled: e[2], tip: e[3], kind: e[0] === "Delete" ? "red" : e[0] === "+ New" ? "green" : "normal" });
        });
    }
    function drawConfirm(ctx, S, x, y, W, H) {
        ctx.fill(x, y, W, H, "#000000", 0.55);
        var w = 260, h = 90, cx = x + (W - w) / 2, cy = y + (H - h) / 2;
        S.hits.length = 0;                        // the dialog takes every click
        U.panel(ctx, cx, cy, w, h, null);
        U.text(ctx, U.fit(ctx, "Delete '" + S.confirm.name + "'?", w - 20), cx + w / 2, cy + 14, "#FFE9A8", "center");
        U.wrap(ctx, "The dungeon is removed for good. Its build stays on the workshop plot.", w - 30, 0.8).forEach(function (l, i) { U.text(ctx, l, cx + w / 2, cy + 30 + i * 10, "#C0C0C0", "center", 0.8); });
        U.button(ctx, "Delete", cx + 20, cy + h - 28, 100, 20, function () { U.send("delete", { id: S.confirm.id }); S.confirm = null; }, { kind: "red" });
        U.button(ctx, "Cancel", cx + w - 120, cy + h - 28, 100, 20, function () { S.confirm = null; });
    }

    // =================================================================================
    //  New dungeon
    // =================================================================================
    function openCreate() {
        var S = { view: "create", name: "" };
        S.draw = function (ctx) {
            var w = 280, h = 110, x = Math.floor((ctx.width - w) / 2), y = Math.floor((ctx.height - h) / 2);
            U.panel(ctx, x, y, w, h, "New Dungeon");
            U.label(ctx, "Dungeon name", x + 16, y + 20, 120);
            U.input(ctx, "name", x + 16, y + 34, w - 32, 10, S.name, function (t) { S.name = t; }, { maxLength: 48, autofocus: true, hint: "e.g. The Sunken Vault" });
            U.wrap(ctx, "Creates a draft, gives it a plot in the workshop and takes you there.", w - 32, 0.8).forEach(function (l, i) { U.text(ctx, l, x + 16, y + 52 + i * 10, "#A8A8A8", "left", 0.8); });
            U.button(ctx, "Create", x + 16, y + h - 28, 110, 20, function () { if (!S.name.trim()) { U.status("Enter a dungeon name", "#FF7070"); return; } U.send("create", { name: S.name }); }, { kind: "green" });
            U.button(ctx, "Cancel", x + w - 126, y + h - 28, 110, 20, function () { openMenu(); });
        };
        S.back = function () { openMenu(); };
        S.onKey = function (k) { if (k === "key.keyboard.enter" && S.name.trim()) { U.send("create", { name: S.name }); return false; } };
        U.open(S);
    }

    // =================================================================================
    //  Card editor
    // =================================================================================
    function editable(c) {
        var e = JSON.parse(JSON.stringify(c));
        e.iconFromHand = false; e.clearIcon = false;
        e.imagePath = e.image && e.image.kind === "path" ? e.image.path : "";
        return e;
    }
    function openCard(c) {
        var S = { view: "card", card: editable(c) };
        S.draw = drawCardEditor;
        S.back = function () { request(); };
        U.open(S);
    }
    function heldId() { var h = RPG.player.heldItem; return h && h !== "minecraft:air" ? h : null; }

    function drawCardEditor(ctx, S) {
        var e = S.card, W = 440, H = 276, x = Math.floor((ctx.width - W) / 2), y = Math.floor((ctx.height - H) / 2) + 4;
        U.panel(ctx, x, y, W, H, "Dungeon Card");
        var rows = [], lw = 120, fx = x + 16 + lw, fw = W - 32 - lw - 10;
        function row(lbl, draw, tip) { rows.push({ h: 16, draw: function (ry) { U.label(ctx, lbl, x + 16, ry, lw - 4); if (tip) U.hit(x + 16, ry, lw - 6, 14, null, tip); draw(ry); } }); }
        function head(t, extra) { rows.push({ h: 18, draw: function (ry) { U.text(ctx, t, x + 16, ry + 6, "#E8C860"); ctx.fill(x + 16, ry + 16, W - 40, 1, "#6B5A33", 0.8); if (extra) extra(ry); } }); }
        head("Card");
        row("Name", function (ry) { U.input(ctx, "c_name", fx, ry + 2, fw, 10, e.name, function (t) { e.name = t; }, { maxLength: 48 }); });
        row("Recommended level", function (ry) { U.input(ctx, "c_level", fx, ry + 2, 80, 10, e.level, function (t) { e.level = t; }, { maxLength: 16, hint: "e.g. 20" }); }, ["Shown on the card", "Just text: use an entry requirement to enforce a level"]);
        row("Time", function (ry) { U.input(ctx, "c_time", fx, ry + 2, 120, 10, e.time, function (t) { e.time = t; }, { maxLength: 24, hint: "e.g. 15 min" }); }, ["How long a run usually takes (just text)"]);
        row("Difficulty", function (ry) {
            U.dropdown(ctx, "c_diff", fx, ry + 1, 120, 13, U.DIFFICULTIES.map(function (d, i) { return { value: i, label: d }; }), e.difficulty, function (v) { e.difficulty = Number(v) | 0; }, { search: false });
        });
        row("Time limit (sec)", function (ry) { U.numField(ctx, "c_tl", fx, ry, 80, e.timeLimit || "", function (v) { e.timeLimit = Math.max(0, v | 0); }, { int: true, blank: 0, hint: "0 = none" }); U.text(ctx, e.timeLimit > 0 ? human(e.timeLimit) : "no limit", fx + 90, ry + 4, "#9A9A9A", "left", 0.8); },
            ["Players are sent back when it runs out"]);
        row("Cooldown (sec)", function (ry) { U.numField(ctx, "c_cd", fx, ry, 80, e.cooldown || "", function (v) { e.cooldown = Math.max(0, v | 0); }, { int: true, blank: 0, hint: "0 = none" }); U.text(ctx, e.cooldown > 0 ? human(e.cooldown) : "none", fx + 90, ry + 4, "#9A9A9A", "left", 0.8); },
            ["Wait after a run before entering again"]);
        row("Description", function (ry) { U.input(ctx, "c_desc", fx, ry + 2, fw, 10, e.description, function (t) { e.description = t; }, { maxLength: 400, hint: "What awaits inside..." }); });
        row("Icon", function (ry) {
            var ic = e.clearIcon ? null : e.icon;
            U.itemSlot(ctx, e.iconFromHand && heldId() ? { id: heldId() } : ic, fx, ry - 2);
            U.button(ctx, e.iconFromHand ? "From hand on save ✔" : "Take from hand", fx + 22, ry, 110, 13, function () { if (!heldId()) { U.status("Hold the icon item in your main hand", "#FF7070"); return; } e.iconFromHand = !e.iconFromHand; e.clearIcon = false; },
                { tip: ["On save, the item in your main hand becomes the icon"] });
            U.button(ctx, "None", fx + 136, ry, 40, 13, function () { e.iconFromHand = false; e.clearIcon = true; });
        });
        row("Picture", function (ry) {
            var has = !!(e.image && (e.image.kind === "upload" || e.image.path)) || !!e.imagePath;
            U.button(ctx, has ? "Picture ✔" : "Picture...", fx, ry, 110, 13, function () { openPicture(S); }, { tip: ["Card picture (about 3:1)", has ? "Set" : "Not set"] });
        });
        row("Status", function (ry) {
            U.toggle(ctx, e.status === "published", fx, ry + 2, function () { e.status = e.status === "published" ? "draft" : "published"; });
            U.text(ctx, e.status === "published" ? "Published" : "Draft (staff only)", fx + 28, ry + 4, e.status === "published" ? "#9FE09F" : "#FFB040", "left", 0.85);
        });

        // ---- entry requirements ----
        var reqTypes = [{ value: "item", label: "Item in inventory" }, { value: "level", label: (CARD && CARD.levelName) || "Level" }, { value: "completed", label: "Finished another dungeon" }, { value: "cooldown", label: "Extra cooldown" }];
        if (e.xpLevelRule) reqTypes.splice(2, 0, { value: "xp_level", label: "XP level" });
        head("Entry requirements", function (ry) {
            U.dropdown(ctx, "c_addreq", x + W - 24 - 120, ry + 2, 120, 13, reqTypes, "", function (v) { addRequirement(e, v); S.addReq = ""; U.resetElements(); }, { placeholder: "+ Add", search: false });
        });
        if (!e.requirements.length) rows.push({ h: 12, draw: function (ry) { U.text(ctx, "None: anyone can enter", x + 24, ry + 2, "#8A8A8A", "left", 0.85); } });
        e.requirements.forEach(function (r, i) {
            rows.push({ h: 18, draw: function (ry) {
                ctx.fill(x + 16, ry, W - 40, 16, "#FFFFFF", 0.05);
                var rx = x + 20;
                if (r.type === "item") {
                    U.itemSlot(ctx, r.item, rx, ry - 1); U.text(ctx, U.fit(ctx, itemLabel(r.item.id), 110), rx + 22, ry + 4, "#FFFFFF", "left", 0.85);
                    U.text(ctx, "x", rx + 140, ry + 4, "#9A9A9A"); U.numField(ctx, "rq_n" + i, rx + 150, ry + 1, 40, r.count, function (v) { r.count = Math.max(1, v | 0); }, { int: true, blank: 1 });
                    U.button(ctx, r.consume ? "Uses up: yes" : "Uses up: no", rx + 200, ry + 1, 86, 13, function () { r.consume = !r.consume; }, { tip: ["Whether the items are taken on entering"] });
                } else if (r.type === "level" || r.type === "xp_level") {
                    U.text(ctx, (r.type === "level" ? (CARD && CARD.levelName) || "Level" : "XP level") + " at least", rx, ry + 4, "#FFFFFF", "left", 0.85);
                    U.numField(ctx, "rq_l" + i, rx + 150, ry + 1, 60, r.level, function (v) { r.level = Math.max(1, v | 0); }, { int: true, blank: 1 });
                } else if (r.type === "completed") {
                    U.text(ctx, "Finished", rx, ry + 4, "#FFFFFF", "left", 0.85);
                    U.dropdown(ctx, "rq_c" + i, rx + 60, ry + 1, 200, 13, (e.dungeons || []).map(function (d) { return { value: d.id, label: d.name + " (" + d.id + ")" }; }), r.id || "", function (v) { r.id = v; }, { custom: true, customLabel: "Use id" });
                } else if (r.type === "cooldown") {
                    U.text(ctx, "Extra cooldown (sec)", rx, ry + 4, "#FFFFFF", "left", 0.85);
                    U.numField(ctx, "rq_s" + i, rx + 150, ry + 1, 60, r.seconds, function (v) { r.seconds = Math.max(1, v | 0); }, { int: true, blank: 60 });
                }
                U.iconButton(ctx, "trash", x + W - 36, ry + 2, 12, function () { e.requirements.splice(i, 1); U.resetElements(); }, "Remove");
            } });
        });

        // ---- goals ----
        var goalTypes = [{ value: "kill_count", label: "Defeat enemies" }, { value: "kill_entity", label: "Defeat a specific enemy" }, { value: "obtain_item", label: "Get an item" }];
        // puzzles and rooms made with the Puzzle / Room Wand
        if ((e.puzzles || []).length) goalTypes.push({ value: "puzzle", label: "Solve a puzzle" });
        if ((e.rooms || []).length) { goalTypes.push({ value: "room_clear", label: "Clear a room" }); goalTypes.push({ value: "room_enter", label: "Reach a room" }); }
        head("Goals (" + e.objectives.length + ")", function (ry) {
            U.dropdown(ctx, "c_addgoal", x + W - 24 - 120, ry + 2, 120, 13, goalTypes, "", function (v) { addGoal(e, v); U.resetElements(); }, { placeholder: "+ Add goal", search: false });
        });
        if (!e.objectives.length) rows.push({ h: 12, draw: function (ry) { U.text(ctx, "None: reaching the exit point ends the run", x + 24, ry + 2, "#8A8A8A", "left", 0.85); } });
        var ents = U.entities();
        e.objectives.forEach(function (o, i) {
            rows.push({ h: 18, draw: function (ry) {
                ctx.fill(x + 16, ry, W - 40, 16, "#FFFFFF", 0.05);
                var rx = x + 20;
                if (o.type === "kill_count") {
                    U.text(ctx, "Defeat this many enemies", rx, ry + 4, "#FFFFFF", "left", 0.85);
                    U.numField(ctx, "ob_n" + i, rx + 170, ry + 1, 50, o.count, function (v) { o.count = Math.max(1, v | 0); }, { int: true, blank: 1 });
                } else if (o.type === "kill_entity") {
                    U.dropdown(ctx, "ob_e" + i, rx, ry + 1, 200, 13, (ents || []).map(function (en) { return { value: en.id, label: en.name, tooltip: en.id }; }), o.entity || "", function (v) { o.entity = v; },
                        { placeholder: ents ? "Pick an enemy..." : "Loading...", search: true, searchHint: "Search mob...", custom: true, customLabel: "Use id", listWidth: 220 });
                    U.text(ctx, "x", rx + 208, ry + 4, "#9A9A9A"); U.numField(ctx, "ob_c" + i, rx + 218, ry + 1, 40, o.count, function (v) { o.count = Math.max(1, v | 0); }, { int: true, blank: 1 });
                } else if (o.type === "obtain_item") {
                    U.itemSlot(ctx, o.item, rx, ry - 1); U.text(ctx, U.fit(ctx, "Get " + itemLabel(o.item.id), 130), rx + 22, ry + 4, "#FFFFFF", "left", 0.85);
                    U.text(ctx, "x", rx + 160, ry + 4, "#9A9A9A"); U.numField(ctx, "ob_i" + i, rx + 170, ry + 1, 40, o.count, function (v) { o.count = Math.max(1, v | 0); }, { int: true, blank: 1 });
                } else if (o.type === "puzzle" || o.type === "room_clear" || o.type === "room_enter") {
                    var pz = o.type === "puzzle", src = (pz ? e.puzzles : e.rooms) || [];
                    U.text(ctx, pz ? "Solve" : o.type === "room_clear" ? "Clear" : "Reach", rx, ry + 4, "#FFFFFF", "left", 0.85);
                    U.dropdown(ctx, "ob_w" + i, rx + 44, ry + 1, 170, 13, src.map(function (q) { return { value: q.id, label: q.name }; }), (pz ? o.puzzle : o.room) || "", function (v) { if (pz) o.puzzle = v; else o.room = v; }, { search: false });
                }
                if ((o.rewards || []).length) U.text(ctx, o.rewards.length + " reward(s)", x + W - 44, ry + 4, "#E8C860", "right", 0.7);
                U.iconButton(ctx, "trash", x + W - 36, ry + 2, 12, function () { e.objectives.splice(i, 1); U.resetElements(); }, "Remove");
            } });
        });

        // scroll list of variable rows
        var lx = x + 10, ly = y + 16, lh = H - 52, flat = [], yy = 0;
        rows.forEach(function (r) { flat.push({ r: r, y: yy }); yy += r.h; });
        var total = yy;
        S.scroll.card = U.clamp(S.scroll.card || 0, 0, Math.max(0, total - lh));
        var pos = S.scroll.card;
        S.lists.push({ key: "card", x: lx, y: ly, w: W - 20, h: lh, total: total, step: 18 });
        ctx.clip(lx, ly, W - 20, lh);
        S.clipTop = ly; S.clipBottom = ly + lh;
        var first = S.hits.length;
        flat.forEach(function (f) { var ry = ly + f.y - pos; if (ry + f.r.h >= ly && ry <= ly + lh) f.r.draw(ry); });
        S.clipTop = null; S.clipBottom = null;
        ctx.unclip();
        for (var k = S.hits.length - 1; k >= first; k--) { var hb = S.hits[k]; if (hb.y + hb.h <= ly || hb.y >= ly + lh) S.hits.splice(k, 1); }
        if (total > lh) { var th = Math.max(14, lh * lh / total); ctx.fill(x + W - 12, ly, 3, lh, "#000000", 0.4); ctx.fill(x + W - 12, ly + (lh - th) * pos / (total - lh), 3, th, "#C9B57A", 1); }

        var by = y + H - 30;
        U.button(ctx, "Save", x + 16, by, 100, 20, function () { save(e); }, { kind: "green", tip: ["Save the card, requirements and goals"] });
        U.button(ctx, "Back", x + W - 116, by, 100, 20, function () { request(); });
    }
    function addRequirement(e, type) {
        if (type === "item") {
            var h = heldId();
            if (!h) { U.status("Hold the required item in your main hand", "#FF7070"); return; }
            e.requirements.push({ type: "item", item: { id: h }, count: 1, consume: false, fromHand: true });
        } else if (type === "level" || type === "xp_level") e.requirements.push({ type: type, level: 10 });
        else if (type === "completed") e.requirements.push({ type: "completed", id: e.dungeons && e.dungeons[0] ? e.dungeons[0].id : "" });
        else if (type === "cooldown") e.requirements.push({ type: "cooldown", seconds: 300 });
    }
    function addGoal(e, type) {
        if (type === "obtain_item") {
            var h = heldId();
            if (!h) { U.status("Hold the item in your main hand: it is the one to get", "#FF7070"); return; }
            e.objectives.push({ type: "obtain_item", item: { id: h }, count: 1, fromHand: true });
        } else if (type === "kill_entity") e.objectives.push({ type: "kill_entity", entity: "", count: 1 });
        else if (type === "puzzle") e.objectives.push({ type: "puzzle", puzzle: e.puzzles[0].id });
        else if (type === "room_clear" || type === "room_enter") e.objectives.push({ type: type, room: e.rooms[0].id });
        else e.objectives.push({ type: "kill_count", count: 10 });
    }
    function save(e) {
        if (!String(e.name || "").trim()) { U.status("Enter a dungeon name", "#FF7070"); return; }
        if (e.objectives.some(function (o) { return o.type === "kill_entity" && !o.entity; })) { U.status("Pick the enemy for every 'defeat a specific enemy' goal", "#FF7070"); return; }
        var card = { name: e.name, description: e.description, level: e.level, time: e.time, difficulty: e.difficulty, timeLimit: e.timeLimit, cooldown: e.cooldown,
            status: e.status, iconFromHand: e.iconFromHand, clearIcon: e.clearIcon, imagePath: e.imagePath, requirements: e.requirements, objectives: e.objectives };
        var s = JSON.stringify(card);
        if (s.length > 28000) { U.status("Too much text to send", "#FF7070"); return; }
        U.send("save_card", { id: e.id, card: card });
        U.status("Saving...", "#FFE070");
    }

    // =================================================================================
    //  Card picture: a texture path, or a picture from this computer's game folder
    // =================================================================================
    function openPicture(parent) {
        var e = parent.card;
        var S = { view: "picture", path: e.imagePath || "" };
        S.draw = function (ctx) {
            var w = 360, h = 230, x = Math.floor((ctx.width - w) / 2), y = Math.floor((ctx.height - h) / 2);
            U.panel(ctx, x, y, w, h, "Card Picture");
            var cur = e.imagePath ? { kind: "path", path: e.imagePath } : e.image && e.image.kind === "upload" ? { kind: "upload", h: e.imageHash } : null;
            var tex = cur ? U.cardImage(e.id, cur) : null;
            U.inset(ctx, x + 16, y + 18, w - 32, (w - 32) / 3 + 4);
            if (tex) ctx.image(tex, x + 18, y + 20, w - 36, (w - 36) / 3, 0, 0, 1, 1, 1, 1);
            else U.text(ctx, "No picture", x + w / 2, y + 20 + (w - 36) / 6 - 4, "#808080", "center");
            var ry = y + 32 + (w - 32) / 3;
            U.label(ctx, "Texture path", x + 16, ry, 100);
            U.input(ctx, "p_path", x + 16, ry + 14, w - 100, 10, S.path, function (t) { S.path = t.trim(); }, { maxLength: 160, hint: "namespace:textures/gui/....png" });
            U.button(ctx, "Use", x + w - 76, ry + 12, 60, 14, function () {
                if (S.path && !RPG.images.has(S.path)) { U.status("No such texture in the loaded packs", "#FF7070"); return; }
                e.imagePath = S.path; e.image = S.path ? { kind: "path", path: S.path } : null; U.status("Picture set: save the card to keep it", "#7CFF7C");
            }, { tip: ["Any png from a resource pack or art pack", "e.g. minecraft:textures/gui/title/background/panorama_0.png"] });
            U.button(ctx, "From computer...", x + 16, ry + 34, 150, 20, function () { openFiles(parent, S); },
                { icon: "image", tip: ["Pick a picture from your game folder", "Put any picture in ragnarok_rpg/images first.", "It is shrunk, uploaded and shown to everyone", "right away (no need to save)."] });
            U.button(ctx, "No picture", x + 172, ry + 34, 90, 20, function () {
                e.imagePath = ""; e.image = null;
                if (e.imageHash) { U.send("img_clear", { id: e.id }); U.forgetImage(e.id); }
                U.status("Picture removed: save the card to keep it", "#FFE070");
            }, { kind: "red" });
            U.button(ctx, "Back", x + w - 86, y + h - 28, 70, 20, function () { U.open(parent); });
        };
        S.back = function () { U.open(parent); };
        U.open(S);
    }

    function openFiles(cardState, picState) {
        var e = cardState.card, folders = [];
        try { folders = RPG.images.folders(); } catch (x) { }
        var S = { view: "files", folder: folders.length ? folders[0].path : "", listing: null, pick: null, preview: null, scroll: {} };
        function go(f) { S.folder = f; S.pick = null; S.preview = null; try { S.listing = RPG.images.list(f); } catch (x) { S.listing = null; } S.scroll.files = 0; }
        go(S.folder);
        function choose(file) {
            S.pick = file;
            var img = null;
            try { img = RPG.images.load(file.path, 320, 180); } catch (x) { }
            if (!img) { S.preview = null; U.status("The file could not be read as a picture", "#FF7070"); return; }
            S.preview = img;
            S.previewTex = RPG.images.register("dmk_preview", img.png);
        }
        function upload() {
            var img = S.preview;
            if (!img) return;
            var sizes = [[320, 180], [256, 144], [192, 108], [160, 90]];
            for (var k = 0; k < sizes.length && img && img.png.length > 230000; k++) img = RPG.images.load(S.pick.path, sizes[k][0], sizes[k][1]);
            if (!img || img.png.length > 230000) { U.status("The picture is too big even when shrunk", "#FF7070"); return; }
            var s = img.png, n = Math.ceil(s.length / 24000), tag = "u" + Math.floor(RPG.nowMs());
            for (var i = 0; i < n; i++) U.send("img_up", { id: e.id, tag: tag, i: i, n: n, w: img.width, h: img.height, s: s.substring(i * 24000, (i + 1) * 24000) });
            e.imagePath = ""; e.image = { kind: "upload" };
            U.forgetImage(e.id);
            U.status("Uploading...", "#FFE070");
            U.open(picState);
        }
        S.draw = function (ctx) {
            var w = 440, h = 260, x = Math.floor((ctx.width - w) / 2), y = Math.floor((ctx.height - h) / 2);
            U.panel(ctx, x, y, w, h, "Pick a Picture");
            folders.forEach(function (f, i) { U.button(ctx, f.name, x + 16 + i * 74, y + 16, 70, 16, function () { go(f.path); }, { selected: S.folder === f.path }); });
            var L = S.listing;
            U.text(ctx, U.fit(ctx, "/" + (L ? L.path : S.folder), 200), x + 16, y + 38, "#B8B0A0", "left", 0.8);
            var rows = [];
            if (L && L.parent !== null && L.parent !== undefined) rows.push({ up: true, name: ".." });
            if (L) { L.dirs.forEach(function (d) { rows.push({ dir: d, name: d }); }); L.files.forEach(function (f) { rows.push({ file: f, name: f.name }); }); }
            U.inset(ctx, x + 14, y + 48, 202, h - 84);
            if (!L) U.text(ctx, "This folder can't be read", x + 115, y + 100, "#FF8080", "center", 0.85);
            else if (!rows.length) U.wrap(ctx, "No pictures here. Copy a png or jpg into the game folder's ragnarok_rpg/images folder.", 180, 0.8).forEach(function (l, i) { U.text(ctx, l, x + 115, y + 90 + i * 10, "#909090", "center", 0.8); });
            U.list(ctx, "files", x + 16, y + 50, 196, h - 88, rows, 12, function (r, i, ry) {
                var sel = S.pick && r.file && r.file.path === S.pick.path, hov = U.over(ctx, x + 16, ry, 196, 12);
                if (sel || hov) ctx.fill(x + 16, ry, 196, 12, sel ? "#E8C860" : "#FFFFFF", sel ? 0.25 : 0.1);
                U.text(ctx, U.fit(ctx, (r.file ? "" : "▸ ") + r.name, 186), x + 19, ry + 2, r.file ? "#FFFFFF" : "#C9B57A", "left", 0.85);
                U.hit(x + 16, ry, 196, 12, function () {
                    if (r.up) go(L.parent); else if (r.dir) go((L.path ? L.path + "/" : "") + r.dir); else choose(r.file);
                });
            });
            // preview
            var px = x + 228, pw = w - 244;
            U.inset(ctx, px, y + 48, pw, pw / 16 * 9 + 4);
            if (S.preview && S.previewTex) {
                var ph = pw / 16 * 9, ar = S.preview.width / S.preview.height, dw = pw - 4, dh = dw / ar;
                if (dh > ph) { dh = ph; dw = dh * ar; }
                ctx.image(S.previewTex, px + 2 + (pw - 4 - dw) / 2, y + 50 + (ph - dh) / 2, dw, dh, 0, 0, 1, 1, 1, 1);
                U.text(ctx, "Size: " + S.preview.srcWidth + "×" + S.preview.srcHeight, px, y + 56 + ph, "#C0C0C0", "left", 0.8);
                U.text(ctx, "Sent as " + S.preview.width + "×" + S.preview.height, px, y + 66 + ph, "#C0C0C0", "left", 0.8);
            } else U.wrap(ctx, "Pick a picture file (png, jpg, bmp, gif)", pw - 10, 0.8).forEach(function (l, i) { U.text(ctx, l, px + pw / 2, y + 90 + i * 10, "#909090", "center", 0.8); });
            U.button(ctx, "Use", px, y + h - 30, 80, 20, upload, { kind: "green", disabled: !S.preview, tip: ["Upload it as the card picture", "Everyone sees it right away"] });
            U.button(ctx, "Back", x + w - 86, y + h - 30, 70, 20, function () { U.open(picState); });
        };
        S.back = function () { U.open(picState); };
        U.open(S);
    }

    // ---- ways in: the key, the inventory button, /dungeons ----
    RPG.on("load", function () {
        try { RPG.keys.register("dmk_menu", { name: "Dungeon Selection", key: "o" }); } catch (x) { }
        var cfgOn = true;
        try { cfgOn = RPG.config.get("dungeon_maker", "menuKey", true) !== false; } catch (x2) { }
        if (cfgOn) try { RPG.screen.inventoryButton("dmk_menu", { label: "Dungeons", tooltip: "Dungeon Selection", x: 0, y: -22, w: 62, h: 18 }, function () { request(); }); } catch (x3) { }
    });
    RPG.on("keybind", function (id, down) { if (id === "dmk_menu" && down && !RPG.screen.getOpen()) request(); });

    return { open: request, menu: function () { return MENU; } };
})();
