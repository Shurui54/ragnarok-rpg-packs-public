// =====================================================================================
//  Dungeon Maker (client) - module settings screens (workshop, staff only)
// =====================================================================================
//  Right-click a module block in the workshop to set it up. Bigger modules have tabs:
//   Mob Spawner   General (mob groups, radius, trigger, glow, stats and gear, NBT) | Drops | Links | Look
//   Boss Spawner  General (boss, name, trigger, arena lock, boss bar, stats, heart container) | Drops | Links | Look
//   Doors         General (key / puzzle options) | Zone (radius or two corners, which kinds of block) | Look
//   Bridge        General (starts hidden or shown, stays) | Zone | Look
//   Chests        Items (a real chest screen, mouse wheel = each slot's chance) | Settings (facing, look)
//   Switch        General (lever, floor switch, crystal, eye, torch; toggle / once / timed / hold) | Links
//   Logic Gate    General (AND, OR, XOR, NOT, sequence; inputs in order) | Links | Look
//  Links: the targets a switch, logic gate, spawner (all its mobs down) or boss (beaten) powers; add
//  them from a searchable list or with "Pick in world" (then right-click the target). The workshop
//  draws every link as a line and every door / bridge zone as a box. "Look": what the module
//  turns into in a run (Auto blends into the wall or floor it is built into, else air).
// =====================================================================================
(function () {
    var U = DMK_UI;
    var NAMES = { anchor: "Dungeon Anchor", spawner: "Mob Spawner", entry: "Entry Point", exit: "Exit Point", door: "Key Door", loot: "Loot Chest",
        "switch": "Switch", logic: "Logic Gate", sk_door: "Small Key Door", bk_door: "Boss Key Door", pz_door: "Puzzle Door",
        sk_chest: "Small Key Chest", bk_chest: "Big Key Chest", pz_chest: "Puzzle Chest", bridge: "Bridge", boss: "Boss Spawner" };
    var TIPS = { spawner: "Spawns mob groups; with drops per mob", entry: "Where players appear", exit: "Ends the run once the goals are met",
        door: "Door blocks that open for a key item you choose", loot: "A chest with random rewards", "switch": "Lever, floor switch, crystal, eye or torch",
        logic: "Combines signals: AND, OR, XOR, NOT, in order", sk_door: "Opens with a Small Key (used up)", bk_door: "Opens with the Boss Key (used up)",
        pz_door: "Opens when a linked puzzle is solved", sk_chest: "Locked chest: a Small Key opens it", bk_chest: "The big chest: the Boss Key opens it",
        pz_chest: "Appears when a linked puzzle is solved", bridge: "Blocks that appear (or vanish) on a signal", boss: "A boss fight with a boss bar and arena lock" };
    var ZONE = { door: 1, sk_door: 1, bk_door: 1, pz_door: 1, bridge: 1 };
    var CHEST = { loot: 1, sk_chest: 1, bk_chest: 1, pz_chest: 1 };
    var COLORS = ["black", "dark_blue", "dark_green", "dark_aqua", "dark_red", "dark_purple", "gold", "gray", "dark_gray", "blue", "green", "aqua", "red", "light_purple", "yellow", "white"];
    var COLOR_HEX = { black: "#000000", dark_blue: "#0000AA", dark_green: "#00AA00", dark_aqua: "#00AAAA", dark_red: "#AA0000", dark_purple: "#AA00AA", gold: "#FFAA00", gray: "#AAAAAA",
        dark_gray: "#555555", blue: "#5555FF", green: "#55FF55", aqua: "#55FFFF", red: "#FF5555", light_purple: "#FF55FF", yellow: "#FFFF55", white: "#FFFFFF" };
    function colorName(c) { return c.split("_").map(function (w) { return w.charAt(0).toUpperCase() + w.substring(1); }).join(" "); }
    function clone(o) { return JSON.parse(JSON.stringify(o)); }
    var FACINGS = [{ value: "north", label: "North (-Z)" }, { value: "south", label: "South (+Z)" }, { value: "east", label: "East (+X)" }, { value: "west", label: "West (-X)" }];

    // ---- block and item lists (asked once) ----
    var LISTS = null, listWait = false;
    U.onBig("blocks", function (d) {
        LISTS = { blocks: [], items: d.items || [] };
        (d.blocks || []).forEach(function (id) { LISTS.blocks.push({ value: id, label: blockName(id), tooltip: id }); });
        LISTS.blocks.sort(function (a, b) { return a.label < b.label ? -1 : a.label > b.label ? 1 : 0; });
        U.resetElements();
    });
    function lists() { if (!LISTS && !listWait) { listWait = true; U.send("blocks"); } return LISTS; }
    function blockName(id) {
        var p = String(id).split(":"), key = "block." + p[0] + "." + p[1];
        try { if (RPG.hasTranslation(key)) return RPG.translate(key); } catch (e) { }
        var n = p[p.length - 1].replace(/_/g, " ");
        return n.charAt(0).toUpperCase() + n.substring(1);
    }
    function itemLabel(id) {
        var p = String(id).split(":"), k1 = "item." + p[0] + "." + p[1], k2 = "block." + p[0] + "." + p[1];
        try { if (RPG.hasTranslation(k1)) return RPG.translate(k1); if (RPG.hasTranslation(k2)) return RPG.translate(k2); } catch (e) { }
        if (LISTS) for (var i = 0; i < LISTS.items.length; i++) if (LISTS.items[i].id === id) return LISTS.items[i].name;
        var n = p[p.length - 1].replace(/_/g, " ");
        return n.charAt(0).toUpperCase() + n.substring(1);
    }

    U.onBig("anchor", function (a) {
        if (!a) return;
        if (a.type === "anchor") { openTypePicker(a); return; }
        if (a.type === "spawner" || a.type === "boss") U.entities();
        lists();
        var S = U.state();
        // re-sent after a link change or a marker: keep the tab and unsaved edits of the open screen
        if (S && S.view === "anchor" && S.a && S.a.key === a.key && S.a.dungeon === a.dungeon && S.keep) {
            S.a = a; S.cfg.links = clone(a.cfg.links || []); S.cfg.c1 = a.cfg.c1; S.cfg.c2 = a.cfg.c2; S.cfg.zone = a.cfg.zone; S.cfg.key = a.cfg.key; S.keep = false;
            showZone(a);
            return;
        }
        openAnchor(a);
    });
    function save(a, cfg, reopen) { U.send("anchor_save", { dungeon: a.dungeon, key: a.key, paint: !!a.paint, cfg: cfg, reopen: !!reopen }); }
    function centred(ctx, w, h) { return { x: Math.floor((ctx.width - w) / 2), y: Math.floor((ctx.height - h) / 2) }; }

    // ---- what the anchor becomes ----
    var PICK_ORDER = ["spawner", "boss", "entry", "exit", "switch", "logic", "door", "sk_door", "bk_door", "pz_door", "bridge", "loot", "sk_chest", "bk_chest", "pz_chest"];
    function openTypePicker(a) {
        var S = { view: "anchor_type" };
        S.draw = function (ctx) {
            var cols = 5, tw = 58, th = 58, w = 16 + cols * (tw + 4) + 12, h = 44 + Math.ceil(PICK_ORDER.length / cols) * (th + 4) + 40, p = centred(ctx, w, h);
            U.panel(ctx, p.x, p.y, w, h, "Choose the Module");
            PICK_ORDER.forEach(function (t, i) {
                var bx = p.x + 16 + (i % cols) * (tw + 4), by = p.y + 20 + Math.floor(i / cols) * (th + 4), hov = U.over(ctx, bx, by, tw, th);
                U.inset(ctx, bx, by, tw, th);
                if (hov) ctx.fill(bx + 2, by + 2, tw - 4, th - 4, "#FFE070", 0.15);
                U.icon(ctx, t, bx + (tw - 26) / 2, by + 6, 26);
                U.wrap(ctx, NAMES[t], tw - 4, 0.7).forEach(function (l, j) { U.text(ctx, l, bx + tw / 2, by + 36 + j * 8, "#FFFFFF", "center", 0.7); });
                U.hit(bx, by, tw, th, function () { U.send("anchor_type", { dungeon: a.dungeon, key: a.key, paint: !!a.paint, type: t }); }, [NAMES[t], TIPS[t]]);
            });
            U.text(ctx, "Dungeon: " + a.dungeonName, p.x + w / 2, p.y + h - 40, "#A8A8A8", "center", 0.8);
            U.button(ctx, "Close", p.x + w / 2 - 40, p.y + h - 28, 80, 20, function () { U.close(); });
        };
        S.back = function () { U.close(); };
        U.open(S);
    }

    // =================================================================================
    //  The tabbed module screen
    // =================================================================================
    /** Back where the screen came from: the dungeon painter for a painted module, else closed. */
    function done(a) {
        if (a && a.paint && typeof DMK_PAINTER !== "undefined") { U.close(); DMK_PAINTER.reopen(); return; }
        U.close();
    }
    function tabsFor(t, paint) {
        if (paint && ZONE[t]) return [["general", "General"], ["look", "Look"]];      // a painted door's zone is the painted doorway
        if (t === "spawner") return [["general", "General"], ["drops", "Drops"], ["links", "Links"], ["look", "Look"]];
        if (t === "boss") return [["general", "General"], ["drops", "Drops"], ["links", "Links"], ["look", "Look"]];
        if (ZONE[t]) return [["general", "General"], ["zone", "Zone"], ["look", "Look"]];
        if (CHEST[t]) return [["items", "Items"], ["settings", "Settings"]];
        if (t === "switch") return [["general", "General"], ["links", "Links"]];
        if (t === "logic") return [["general", "General"], ["links", "Links"], ["look", "Look"]];
        return [["general", "General"]];
    }
    var SIZE = { spawner: [390, 262], boss: [390, 262], entry: [300, 170], exit: [300, 170], "switch": [340, 230], logic: [340, 240] };
    function openAnchor(a) {
        var S = { view: "anchor", a: a, cfg: clone(a.cfg || {}) };
        var tabs = tabsFor(a.type, a.paint);
        S.tab = tabs[0][0];
        S.back = function () { done(a); };
        S.draw = function (ctx) { drawModule(ctx, S, tabs); };
        S.onScroll = function (x, y, d) { return S.tab === "items" ? lootScroll(S, x, y, d) : false; };
        if (CHEST[a.type]) S.onClose = function () { save(a, S.cfg); if (a.paint) RPG.schedule(1, function () { if (!U.state()) done(a); }); };
        if (ZONE[a.type] && !a.paint) showZone(a);
        U.open(S);
    }
    function drawModule(ctx, S, tabs) {
        var a = S.a, sz = SIZE[a.type] || [340, 240], w = sz[0], h = sz[1], p = centred(ctx, w, h), x = p.x, y = p.y;
        U.panel(ctx, x, y, w, h, NAMES[a.type] + (S.cfg.name ? ": " + S.cfg.name : ""));
        var cy = y + 16;
        if (tabs.length > 1) {
            var bw = Math.min(80, Math.floor((w - 32) / tabs.length) - 4);
            tabs.forEach(function (t, i) {
                U.button(ctx, t[1], x + 16 + i * (bw + 4), y + 14, bw, 14, function () { if (S.tab !== t[0]) { S.tab = t[0]; U.resetElements(); } }, { selected: S.tab === t[0], kind: S.tab === t[0] ? "gold" : "normal" });
            });
            cy = y + 34;
        }
        var body = { x: x + 16, y: cy, w: w - 32, h: h - (cy - y) - 48 };
        var draw = PAGES[a.type + ":" + S.tab] || PAGES["*:" + S.tab];
        if (draw) draw(ctx, S, body.x, body.y, body.w, body.h);
        U.button(ctx, "Save", x + 16, y + h - 28, 90, 20, function () { save(a, S.cfg); S.onClose = null; done(a); }, { kind: "green" });
        U.button(ctx, "Cancel", x + w - 106, y + h - 28, 90, 20, function () { S.onClose = null; done(a); });
        U.text(ctx, a.dungeonName + " · " + (a.paint ? a.where : a.x + ", " + a.y + ", " + a.z), x + w / 2, y + h - 40, "#808080", "center", 0.75);
    }
    function note(ctx, t, x, y, w, scale) { var s = scale || 0.75, l = U.wrap(ctx, t, w, s); l.forEach(function (line, i) { U.text(ctx, line, x, y + i * (10 * s + 1), "#A8A8A8", "left", s); }); return l.length * (10 * s + 1); }
    function nameRow(ctx, S, x, y, w) {
        U.label(ctx, "Name", x, y, 60);
        U.input(ctx, "m_name", x + 100, y + 2, Math.min(160, w - 100), 10, S.cfg.name || "", function (t) { S.cfg.name = t; }, { maxLength: 32, hint: "shown in link lists" });
        U.hit(x, y, 60, 12, null, ["Name (optional)", "Makes it easy to find in the link lists"]);
    }

    // ---- shared rows ----
    function lookRow(ctx, S, x, y, w) {
        var L = lists(), opts = [{ value: "auto", label: "Auto (blends in)", tooltip: "Built into a wall or floor: its commonest neighbour. Otherwise air." }, { value: "air", label: "Air (nothing)" }];
        if (L) opts = opts.concat(L.blocks);
        U.label(ctx, "In a run it is", x, y, 100);
        U.dropdown(ctx, "m_look", x + 100, y + 1, Math.min(200, w - 100), 13, opts, S.cfg.disguise || "auto", function (v) { S.cfg.disguise = v; },
            { search: true, searchHint: "Search blocks...", placeholder: L ? "Auto" : "Loading...", listWidth: 220, maxVisible: 12 });
        U.hit(x, y, 96, 12, null, ["What the module turns into in a run", "Module blocks never show while playing; only the workshop shows them."]);
    }
    function inputsRow(ctx, S, x, y, w) {
        var ins = S.a.inputs || [];
        U.label(ctx, "Powered by", x, y, 100);
        U.text(ctx, ins.length ? U.fit(ctx, ins.map(function (i) { return i.name; }).join(", "), w - 104) : "nothing yet: link a switch, gate, spawner or boss to it", x + 100, y + 3, ins.length ? "#9FE09F" : "#909090", "left", 0.8);
        if (ins.length) U.hit(x + 100, y, w - 100, 12, null, ["Powered by"].concat(ins.map(function (i) { return i.name; })));
        return 14;
    }
    var PAGES = {};
    PAGES["*:look"] = function (ctx, S, x, y, w, h) {
        nameRow(ctx, S, x, y, w);
        lookRow(ctx, S, x, y + 18, w);
        note(ctx, "Auto: a module built into a wall or floor (three or more solid blocks around it) takes the look of the block most of them are; one standing in the open becomes air. Pick a block to make it something else.", x, y + 40, w);
    };

    // ---- links ----
    PAGES["*:links"] = function (ctx, S, x, y, w, h) {
        var a = S.a, c = S.cfg, L = c.links = c.links || [], all = a.linkables || [];
        var what = { spawner: "once every mob it spawned is down", boss: "once the boss is beaten", "switch": "while it is on", logic: "while the gate is on" }[a.type];
        U.text(ctx, "Sends a signal " + what + " to:", x, y + 2, "#E8C860", "left", 0.85);
        U.inset(ctx, x - 2, y + 12, w + 4, h - 50);
        if (!L.length) U.text(ctx, "No links yet", x + w / 2, y + 30, "#909090", "center", 0.8);
        U.list(ctx, "links", x, y + 14, w - 8, h - 54, L, 13, function (k, i, ry) {
            var t = null;
            all.forEach(function (o) { if (o.key === k) t = o; });
            ctx.fill(x, ry, w - 8, 12, "#FFFFFF", i % 2 ? 0.04 : 0.08);
            if (t) U.icon(ctx, t.type, x + 2, ry + 1, 10);
            U.text(ctx, U.fit(ctx, t ? t.name : k + " (gone)", w - 120), x + 15, ry + 2, t ? "#FFFFFF" : "#FF8080", "left", 0.8);
            if (t) U.text(ctx, t.x + ", " + t.y + ", " + t.z, x + w - 70, ry + 2, "#808080", "right", 0.7);
            U.iconButton(ctx, "trash", x + w - 22, ry + 1, 10, function () { L.splice(i, 1); }, "Unlink");
        });
        var opts = all.filter(function (o) { return L.indexOf(o.key) < 0; }).map(function (o) { return { value: o.key, label: o.name + "  " + o.x + "," + o.y + "," + o.z, tooltip: NAMES[o.type] }; });
        var by = y + h - 34;
        U.dropdown(ctx, "lk_add", x, by + 1, w - 120, 13, opts, "", function (v) { if (v && L.indexOf(v) < 0 && L.length < 16) L.push(v); U.resetElements(); },
            { search: true, placeholder: opts.length ? "+ Link to..." : "No modules to link (doors, chests, bridges, gates...)", searchHint: "Search modules...", listWidth: 240 });
        if (!a.paint) U.button(ctx, "Pick in world", x + w - 112, by, 112, 15, function () { save(a, c); U.send("link_pick", { dungeon: a.dungeon, key: a.key }); },
            { tip: ["Pick in world", "Saves, closes, then right-click the target module", "(right-clicking a linked one unlinks it)"] });
        note(ctx, "Targets: Puzzle Doors, Puzzle Chests, Bridges, Logic Gates, and Mob / Boss Spawners set to the \"signal\" trigger.", x, by + 18, w, 0.7);
    };

    // ---- drops (mob loot pools) ----
    PAGES["*:drops"] = function (ctx, S, x, y, w, h) {
        var c = S.cfg, D = c.drops = c.drops || [];
        U.text(ctx, S.a.type === "boss" ? "The boss drops, each rolled on its own:" : "Each mob from this spawner drops, each rolled on its own:", x, y + 2, "#E8C860", "left", 0.85);
        U.inset(ctx, x - 2, y + 12, w + 4, h - 48);
        U.text(ctx, "Chance", x + w - 128, y + 14, "#B8B0A0", "left", 0.7); U.text(ctx, "Count", x + w - 72, y + 14, "#B8B0A0", "left", 0.7);
        if (!D.length) U.text(ctx, "Nothing: add drops below (e.g. Small Key 100%, Recovery Heart 10%)", x + w / 2, y + 36, "#909090", "center", 0.75);
        U.list(ctx, "drops", x, y + 24, w - 8, h - 62, D, 20, function (d, i, ry) {
            ctx.fill(x, ry, w - 8, 19, "#FFFFFF", i % 2 ? 0.04 : 0.08);
            U.itemSlot(ctx, d.item, x + 1, ry);
            U.text(ctx, U.fit(ctx, itemLabel(d.item.id), w - 170), x + 22, ry + 6, "#FFFFFF", "left", 0.8);
            U.numField(ctx, "dr_c" + i, x + w - 130, ry + 3, 32, d.chance, function (v) { d.chance = v === null ? 100 : U.clamp(v, 0, 100); }, { blank: 100 });
            U.text(ctx, "%", x + w - 95, ry + 6, "#B8B0A0", "left", 0.8);
            U.numField(ctx, "dr_n" + i, x + w - 74, ry + 3, 18, d.min, function (v) { d.min = U.clamp((v | 0) || 1, 1, 64); if (d.max < d.min) d.max = d.min; }, { int: true, blank: 1 });
            U.text(ctx, "-", x + w - 53, ry + 6, "#B8B0A0", "left", 0.8);
            U.numField(ctx, "dr_x" + i, x + w - 48, ry + 3, 18, d.max, function (v) { d.max = U.clamp((v | 0) || 1, 1, 64); }, { int: true, blank: 1 });
            U.iconButton(ctx, "trash", x + w - 22, ry + 4, 10, function () { D.splice(i, 1); U.resetElements(); }, "Remove");
        });
        var L = lists(), inv = S.a.inventory || [], seen = {}, opts = [];
        (L ? L.items : []).forEach(function (it) { seen[it.id] = 1; opts.push({ value: it.id, label: it.name, tooltip: "Dungeon item" }); });
        inv.forEach(function (s) { if (s && !seen[s.id]) { seen[s.id] = 1; opts.push({ value: s.id, label: s.name || itemLabel(s.id), tooltip: "From your inventory" }); } });
        U.dropdown(ctx, "dr_add", x, y + h - 32, w, 13, opts, "", function (v) {
            if (!v || D.length >= 24) return;
            var st = null; inv.forEach(function (s) { if (s && s.id === v && !st) st = { id: s.id, nbt: s.nbt }; });
            D.push({ item: st || { id: v }, chance: v.indexOf("small_key") >= 0 || v.indexOf("boss_key") >= 0 ? 100 : 25, min: 1, max: 1 });
            U.resetElements();
        }, { search: true, placeholder: "+ Add a drop (dungeon items, your inventory, or type an id)", searchHint: "Search items...", custom: true, customLabel: "Use id", listWidth: 240, maxVisible: 12 });
        note(ctx, "Keys dropped here belong to the run they drop in. Items from your inventory keep their name and enchantments.", x, y + h - 14, w, 0.7);
    };

    // ---- Mob Spawner ----
    var TRIGGERS = [{ value: "radius", label: "Player in radius" }, { value: "click", label: "Right-click" }, { value: "redstone", label: "Redstone signal" }, { value: "signal", label: "Linked signal" }];
    PAGES["spawner:general"] = function (ctx, S, x, y, w, h) {
        var c = S.cfg;
        c.groups = c.groups || [];
        U.text(ctx, "Mob groups", x, y + 2, "#E8C860");
        U.inset(ctx, x - 2, y + 12, w + 4, 62);
        if (!c.groups.length) U.text(ctx, "Empty: add at least one group", x + w / 2, y + 38, "#909090", "center", 0.85);
        U.list(ctx, "groups", x, y + 14, w - 8, 58, c.groups, 14, function (g, i, ry) {
            ctx.fill(x, ry, w - 8, 13, "#FFFFFF", i % 2 ? 0.04 : 0.08);
            U.text(ctx, U.fit(ctx, U.entityName(g.entity), 170), x + 4, ry + 3, "#FFFFFF", "left", 0.85);
            U.text(ctx, U.fit(ctx, g.entity, 110), x + 180, ry + 3, "#7A7A7A", "left", 0.7);
            U.text(ctx, "x" + g.count, x + w - 56, ry + 3, "#FFE9A8", "left", 0.85);
            U.iconButton(ctx, "pencil", x + w - 38, ry + 1, 11, function () { openGroup(S, i); }, "Edit");
            U.iconButton(ctx, "trash", x + w - 24, ry + 1, 11, function () { c.groups.splice(i, 1); }, "Remove");
        });
        U.button(ctx, "+ Group", x, y + 78, 70, 15, function () { openGroup(S, -1); }, { kind: "green" });
        var ry = y + 98, fx = x + 100;
        U.label(ctx, "Radius", x, ry, 90);
        U.numField(ctx, "sp_r", fx, ry, 40, c.radius, function (v) { c.radius = U.clamp(v | 0, 1, 128); }, { int: true, blank: 8 });
        U.label(ctx, "Trigger", x + 160, ry, 60);
        U.dropdown(ctx, "sp_t", x + 210, ry + 1, w - 210, 13, TRIGGERS, c.trigger || "radius", function (v) { c.trigger = v; }, { search: false });
        ry += 17;
        U.label(ctx, "Glow outline", x, ry, 90);
        U.toggle(ctx, !!c.glow, fx, ry + 2, function () { c.glow = !c.glow; }, ["Outline seen through walls, so a mob can't be lost", "Coloured by a scoreboard team (friendly fire stays on)"]);
        U.dropdown(ctx, "sp_gc", fx + 30, ry + 1, 96, 13, COLORS.map(function (k) { return { value: k, label: colorName(k) }; }), c.glowColor || "red", function (v) { c.glowColor = v; },
            { search: false, disabled: !c.glow, maxVisible: 8 });
        ctx.fill(fx + 132, ry + 3, 9, 9, "#000000", 1); ctx.fill(fx + 133, ry + 4, 7, 7, COLOR_HEX[c.glowColor || "red"], c.glow ? 1 : 0.35);
        ry += 17;
        statsRow(ctx, S, x, ry, fx);
        ry += 17;
        U.label(ctx, "Spawn NBT", x, ry, 90, "#D8D2C0");
        U.input(ctx, "sp_nbt", fx, ry + 2, w - 100, 10, c.nbt || "", function (t) { c.nbt = t; }, { maxLength: 4000, hint: "optional, e.g. {CustomName:'\"Guard\"'}" });
        U.hit(x, ry, 90, 12, null, ["Spawn NBT (optional)", "Extra NBT given to each spawned mob, e.g. {Health:40f}"]);
        ry += 16;
        U.text(ctx, (c.drops || []).length + " drop(s) · " + (c.links || []).length + " link(s)", x, ry + 2, "#909090", "left", 0.75);
    };
    function statsRow(ctx, S, x, ry, fx) {
        var c = S.cfg;
        U.label(ctx, "Stats & gear", x, ry, 100);
        var st = c.stats || {}, nStats = Object.keys(st).length, nEq = Object.keys(c.equip || {}).length;
        U.button(ctx, "Edit...", fx, ry, 60, 14, function () { openStats(S); }, { tip: ["Health, speed, damage, armour and worn items", "A readable stand-in for hand-written NBT"] });
        U.text(ctx, (nStats ? nStats + " stat(s)" : "mob's own stats") + " · " + (nEq ? nEq + " item(s)" : "no gear"), fx + 66, ry + 3, "#9A9A9A", "left", 0.8);
    }

    // ---- Boss Spawner ----
    var BAR_COLORS = ["pink", "blue", "red", "green", "yellow", "purple", "white"];
    PAGES["boss:general"] = function (ctx, S, x, y, w, h) {
        var c = S.cfg, fx = x + 100, ry = y;
        var ents = U.entities() || [];
        U.label(ctx, "Boss", x, ry, 90);
        var opts = ents.map(function (e) { return { value: e.id, label: e.name + (e.id.indexOf("rpgboss:") === 0 ? "  [script boss]" : ""), tooltip: e.id }; });
        opts.sort(function (a, b) { var ab = a.value.indexOf("rpgboss:") === 0, bb = b.value.indexOf("rpgboss:") === 0; return ab !== bb ? (ab ? -1 : 1) : a.label < b.label ? -1 : 1; });
        U.dropdown(ctx, "bs_ent", fx, ry + 1, w - 100, 13, opts, c.entity || "", function (v) { c.entity = v; },
            { search: true, placeholder: ents.length ? "Pick a mob or boss..." : "Loading...", custom: true, customLabel: "Use id", listWidth: 240, maxVisible: 12 });
        ry += 17;
        U.label(ctx, "Boss name", x, ry, 90);
        U.input(ctx, "bs_name", fx, ry + 2, 150, 10, c.bossName || "", function (t) { c.bossName = t; }, { maxLength: 48, hint: "optional, & colours" });
        ry += 17;
        U.label(ctx, "Trigger", x, ry, 90);
        U.dropdown(ctx, "bs_t", fx, ry + 1, 120, 13, [TRIGGERS[0], TRIGGERS[1], TRIGGERS[3]], c.trigger || "radius", function (v) { c.trigger = v; }, { search: false });
        U.label(ctx, "Radius", fx + 130, ry, 50);
        U.numField(ctx, "bs_r", fx + 172, ry, 34, c.radius, function (v) { c.radius = U.clamp(v | 0, 1, 128); }, { int: true, blank: 10 });
        ry += 17;
        U.label(ctx, "Arena lock", x, ry, 90);
        U.toggle(ctx, c.lock !== false, fx, ry + 2, function () { c.lock = c.lock === false; }, ["Players inside can't leave until the boss falls"]);
        U.label(ctx, "Lock radius", fx + 30, ry, 70);
        U.numField(ctx, "bs_lr", fx + 100, ry, 34, c.lockRadius, function (v) { c.lockRadius = U.clamp(v | 0, 3, 128); }, { int: true, blank: 16 });
        ry += 17;
        U.label(ctx, "Boss bar", x, ry, 90);
        U.toggle(ctx, c.bar !== false, fx, ry + 2, function () { c.bar = c.bar === false; }, ["A boss bar with its health for the party", "Script bosses show their own"]);
        U.dropdown(ctx, "bs_bc", fx + 30, ry + 1, 80, 13, BAR_COLORS.map(function (k) { return { value: k, label: colorName(k) }; }), c.barColor || "red", function (v) { c.barColor = v; }, { search: false, disabled: c.bar === false });
        ry += 17;
        U.label(ctx, "Heart Container", x, ry, 96);
        U.toggle(ctx, c.heart !== false, fx, ry + 2, function () { c.heart = c.heart === false; }, ["Drops a Heart Container when beaten"]);
        ry += 17;
        statsRow(ctx, S, x, ry, fx);
        ry += 17;
        U.label(ctx, "Spawn NBT", x, ry, 90);
        U.input(ctx, "bs_nbt", fx, ry + 2, w - 100, 10, c.nbt || "", function (t) { c.nbt = t; }, { maxLength: 4000, hint: "optional" });
    };

    // a mob group: searchable mob list, filtered by mod
    function openGroup(parent, index) {
        var c = parent.cfg, g = index >= 0 ? clone(c.groups[index]) : { entity: "", count: 1 };
        var S = { view: "group", ns: "" };
        S.draw = function (ctx) {
            var w = 300, h = 150, p = centred(ctx, w, h), x = p.x, y = p.y;
            U.panel(ctx, x, y, w, h, "Mob Group");
            var ents = U.entities() || [];
            var spaces = {};
            ents.forEach(function (e) { spaces[U.namespaceOf(e.id)] = 1; });
            var nsOpts = [{ value: "", label: "All mods" }].concat(Object.keys(spaces).sort().map(function (n) { return { value: n, label: n === "rpgmob" ? "Script mobs" : n === "rpgnpc" ? "Script NPCs" : n === "rpgboss" ? "Script bosses" : n }; }));
            U.label(ctx, "Mod", x + 16, y + 20, 60);
            U.dropdown(ctx, "g_ns", x + 70, y + 21, 130, 13, nsOpts, S.ns, function (v) { S.ns = v; U.resetElements(); }, { search: nsOpts.length > 8, placeholder: "All mods" });
            U.hit(x + 16, y + 20, 50, 12, null, ["Filter the mob list by mod"]);
            U.label(ctx, "Mob", x + 16, y + 40, 60);
            var opts = ents.filter(function (e) { return !S.ns || U.namespaceOf(e.id) === S.ns; }).map(function (e) { return { value: e.id, label: e.name, tooltip: e.id }; });
            U.dropdown(ctx, "g_ent_" + S.ns, x + 70, y + 41, w - 86, 13, opts, g.entity, function (v) { g.entity = v; },
                { search: true, searchHint: "Search...", placeholder: ents.length ? "Pick a mob..." : "Loading...", custom: true, customLabel: "Use id", listWidth: 220, maxVisible: 12 });
            U.label(ctx, "Count", x + 16, y + 60, 60);
            U.numField(ctx, "g_n", x + 70, y + 59, 50, g.count, function (v) { g.count = U.clamp(v | 0, 1, 64); }, { int: true, blank: 1 });
            if (g.entity) U.text(ctx, g.entity, x + 130, y + 63, "#8A8A8A", "left", 0.75);
            U.button(ctx, "OK", x + 16, y + h - 28, 90, 20, function () {
                if (!g.entity) { U.status("Pick a mob from the list", "#FF7070"); return; }
                if (index >= 0) c.groups[index] = g; else c.groups.push(g);
                U.open(parent);
            }, { kind: "green" });
            U.button(ctx, "Back", x + w - 106, y + h - 28, 90, 20, function () { U.open(parent); });
        };
        S.back = function () { U.open(parent); };
        U.open(S);
    }

    // stats and equipment: click an item in your inventory, then a slot; right-click a slot to clear it
    var SLOTS = [["head", "Head"], ["chest", "Chest"], ["legs", "Legs"], ["feet", "Feet"], ["mainhand", "Hand"], ["offhand", "Off"]];
    function openStats(parent) {
        var c = parent.cfg, inv = parent.a.inventory || [];
        c.stats = c.stats || {}; c.equip = c.equip || {};
        var S = { view: "stats", pick: -1 };
        S.draw = function (ctx) {
            var w = 330, h = 262, p = centred(ctx, w, h), x = p.x, y = p.y;
            U.panel(ctx, x, y, w, h, "Mob Stats and Equipment");
            [["health", "Health"], ["speed", "Speed"], ["damage", "Damage"], ["armor", "Armor"]].forEach(function (r, i) {
                var ry = y + 18 + i * 17;
                U.label(ctx, r[1], x + 16, ry, 60);
                U.numField(ctx, "st_" + r[0], x + 76, ry, 60, c.stats[r[0]], function (v) { if (v === null) delete c.stats[r[0]]; else c.stats[r[0]] = Math.max(0, v); }, { hint: "mob's own" });
            });
            U.text(ctx, "Equipment", x + 160, y + 20, "#E8C860");
            SLOTS.forEach(function (s, i) {
                var sx = x + 160 + (i % 3) * 52, sy = y + 32 + Math.floor(i / 3) * 30;
                U.text(ctx, s[1], sx + 9, sy, "#B8B0A0", "center", 0.7);
                U.itemSlot(ctx, c.equip[s[0]], sx, sy + 8);
                U.hit(sx, sy + 8, 18, 18, function () {
                    if (S.pick < 0 || !inv[S.pick]) { U.status("Click an item in your inventory first", "#FFB040"); return; }
                    c.equip[s[0]] = clone(inv[S.pick]); c.equip[s[0]].count = 1;
                }, c.equip[s[0]] ? [s[1] + ": " + c.equip[s[0]].id, "Right-click to clear"] : [s[1], "Empty"], function () { delete c.equip[s[0]]; });
            });
            U.text(ctx, "Your inventory", x + 16, y + 92, "#E8C860");
            var order = [];
            for (var r = 0; r < 3; r++) for (var k = 0; k < 9; k++) order.push(9 + r * 9 + k);
            for (var hb = 0; hb < 9; hb++) order.push(hb);
            order.push(39, 38, 37, 36, 40);
            order.forEach(function (slot, i) {
                var col = i < 36 ? i % 9 : i - 36, row = i < 27 ? Math.floor(i / 9) : i < 36 ? 3 : 4;
                var sx = x + 16 + col * 19, sy = y + 104 + row * 19 + (row === 3 ? 3 : row === 4 ? 6 : 0);
                U.itemSlot(ctx, inv[slot], sx, sy, { selected: S.pick === slot });
                if (inv[slot]) U.hit(sx, sy, 18, 18, function () { S.pick = slot; }, [inv[slot].name || inv[slot].id, inv[slot].id]);
            });
            U.wrap(ctx, "Click an item, then a slot. Right-click a slot to clear it. An empty field keeps the mob's own value; speed is usually 0.2-0.35. Gear never drops, and not every mob shows it.", 120, 0.7)
                .forEach(function (l, i) { U.text(ctx, l, x + 196, y + 104 + i * 8, "#9A9A9A", "left", 0.7); });
            U.button(ctx, "Done", x + w / 2 - 45, y + h - 28, 90, 20, function () { U.open(parent); }, { kind: "green" });
        };
        S.back = function () { U.open(parent); };
        U.open(S);
    }

    // ---- Entry / Exit ----
    PAGES["entry:general"] = function (ctx, S, x, y, w, h) {
        U.label(ctx, "Facing", x, y, 60);
        U.dropdown(ctx, "en_f", x + 100, y + 1, 120, 13, FACINGS, S.cfg.facing || "south", function (v) { S.cfg.facing = v; }, { search: false });
        lookRow(ctx, S, x, y + 18, w);
        note(ctx, "Players appear here, looking this way. Without an entry point they land on the plot's centre at platform height.", x, y + 40, w, 0.8);
    };
    PAGES["exit:general"] = function (ctx, S, x, y, w, h) {
        U.label(ctx, "Radius", x, y, 60);
        U.numField(ctx, "ex_r", x + 100, y, 40, S.cfg.radius, function (v) { S.cfg.radius = U.clamp(v | 0, 1, 64); }, { int: true, blank: 3 });
        lookRow(ctx, S, x, y + 18, w);
        note(ctx, "The run ends when a player comes this close, but only once every goal is met. Without an exit point it ends as soon as the goals are done.", x, y + 40, w, 0.8);
    };

    // ---- Doors and bridges ----
    function showZone(a) {
        if (a.box) RPG.world.box("dmk_door", a.box.x1, a.box.y1, a.box.z1, a.box.x2, a.box.y2, a.box.z2, "#FFAA00", { alpha: 0.9 });
        else RPG.world.removeBox("dmk_door");
        RPG.schedule(20 * 30, function () { RPG.world.removeBox("dmk_door"); });
    }
    var DOOR_TEXT = {
        door: "Players open it by right-clicking any of its blocks while carrying the key item.",
        sk_door: "Players open it by right-clicking any of its blocks: it takes one Small Key the party found in this run.",
        bk_door: "Players open it by right-clicking any of its blocks once the party has the Boss Key (used up, unless the bossKeyUsedUp setting is off).",
        pz_door: "Opens by itself when a linked switch, logic gate, spawner (all mobs down) or boss (beaten) powers it.",
        bridge: "Its blocks appear (or vanish) when a linked switch, gate, spawner or boss powers it."
    };
    function doorGeneral(ctx, S, x, y, w, h) {
        var a = S.a, c = S.cfg, ry = y;
        nameRow(ctx, S, x, ry, w); ry += 18;
        if (a.type === "door") {
            U.label(ctx, "Key item", x, ry + 2, 90);
            U.itemSlot(ctx, c.key, x + 100, ry - 2);
            U.text(ctx, c.key ? U.fit(ctx, a.keyName || c.key.id, 80) : "none (opens for anyone)", x + 122, ry + 3, c.key ? "#FFFFFF" : "#909090", "left", 0.8);
            U.button(ctx, "From hand", x + w - 98, ry, 60, 14, function () { save(a, c); S.keep = true; U.send("door_key", { dungeon: a.dungeon, key: a.key, paint: !!a.paint }); }, { tip: ["The item in your main hand becomes the key"] });
            U.button(ctx, "Clear", x + w - 34, ry, 34, 14, function () { save(a, c); S.keep = true; U.send("door_key", { dungeon: a.dungeon, key: a.key, paint: !!a.paint, clear: true }); });
            ry += 20;
            U.label(ctx, "Uses up the key", x, ry, 100);
            U.toggle(ctx, c.consume !== false, x + 100, ry + 1, function () { c.consume = c.consume === false; }, ["Whether the key is taken when the door opens"]);
            ry += 18;
        }
        if (a.type === "pz_door") {
            U.label(ctx, "Closes again", x, ry, 100);
            U.toggle(ctx, !!c.closeOff, x + 100, ry + 1, function () { c.closeOff = !c.closeOff; }, ["Closes when the signal stops (a floor switch let go)", "Off: once open it stays open"]);
            ry += 18;
        }
        if (a.type === "bridge") {
            U.label(ctx, "At the start", x, ry, 100);
            U.dropdown(ctx, "br_s", x + 100, ry + 1, 150, 13, [{ value: "hidden", label: "Hidden (appears on signal)" }, { value: "shown", label: "Shown (vanishes on signal)" }], c.start || "hidden", function (v) { c.start = v; }, { search: false });
            ry += 18;
            U.label(ctx, "Stays", x, ry, 100);
            U.toggle(ctx, c.latch !== false, x + 100, ry + 1, function () { c.latch = c.latch === false; }, ["Stays once changed", "Off: goes back when the signal stops"]);
            ry += 18;
        }
        if (a.type === "pz_door" || a.type === "bridge") ry += inputsRow(ctx, S, x, ry, w);
        var n = 0; (a.zoneBlocks || []).forEach(function (b) { if (!c.blocks || !c.blocks.length || c.blocks.indexOf(b.id) >= 0) n += b.n; });
        U.text(ctx, c.zone === "self" ? "Old-style door: the module block itself is the door." : "Zone: " + n + " block(s) " + (a.type === "bridge" ? "form the bridge" : "are the door") + " (see the Zone tab)", x, ry + 3, "#E8C860", "left", 0.8);
        ry += 14;
        note(ctx, DOOR_TEXT[a.type], x, ry + 2, w, 0.75);
    }
    ["door", "sk_door", "bk_door", "pz_door", "bridge"].forEach(function (t) { PAGES[t + ":general"] = doorGeneral; });
    PAGES["*:zone"] = function (ctx, S, x, y, w, h) {
        var a = S.a, c = S.cfg, ry = y;
        var modes = [{ value: "radius", label: "Radius round the module" }, { value: "box", label: "Between two markers" }];
        if (c.zone === "self") modes.push({ value: "self", label: "This block (old style)" });
        U.label(ctx, "Zone", x, ry, 60);
        U.dropdown(ctx, "zn_m", x + 60, ry + 1, 150, 13, modes, c.zone || "radius", function (v) { c.zone = v; }, { search: false });
        if (c.zone !== "box" && c.zone !== "self") {
            U.label(ctx, "Radius", x + 220, ry, 50);
            U.numField(ctx, "zn_r", x + 262, ry, 30, c.radius, function (v) { c.radius = U.clamp((v | 0) || 1, 1, 6); }, { int: true, blank: 2 });
        }
        ry += 17;
        if (c.zone === "box") {
            [1, 2].forEach(function (n) {
                var pos = n === 1 ? a.c1 : a.c2;
                U.text(ctx, pos ? "Marker " + n + ": " + pos.x + ", " + pos.y + ", " + pos.z : "Marker " + n + ": not set", x, ry + 3, pos ? "#FFFFFF" : "#909090", "left", 0.8);
                U.button(ctx, "Marker " + n + " = me", x + 150, ry, 84, 14, function () { save(a, c); S.keep = true; U.send("door_marker", { dungeon: a.dungeon, key: a.key, paint: !!a.paint, n: n }); },
                    { tip: ["Sets this corner to the block you stand on"] });
                U.iconButton(ctx, "trash", x + 240, ry + 1, 12, function () { save(a, c); S.keep = true; U.send("door_marker", { dungeon: a.dungeon, key: a.key, paint: !!a.paint, n: n, clear: true }); }, "Clear");
                ry += 16;
            });
        }
        U.text(ctx, "Which blocks count (none ticked = all of them):", x, ry + 2, "#E8C860", "left", 0.8);
        ry += 12;
        var Z = a.zoneBlocks || [], B = c.blocks = c.blocks || [];
        U.inset(ctx, x - 2, ry, w + 4, h - (ry - y) - 22);
        if (!Z.length) U.text(ctx, "Nothing in the zone yet: build the door, then reopen this", x + w / 2, ry + 12, "#909090", "center", 0.75);
        U.list(ctx, "zone", x, ry + 2, w - 8, h - (ry - y) - 26, Z, 12, function (b, i, yy) {
            var on = B.indexOf(b.id) >= 0;
            U.toggle(ctx, on, x + 2, yy, function () { var j = B.indexOf(b.id); if (j >= 0) B.splice(j, 1); else B.push(b.id); }, ["Only these kinds of block are the " + (a.type === "bridge" ? "bridge" : "door")]);
            U.text(ctx, U.fit(ctx, blockName(b.id), w - 110), x + 30, yy + 2, B.length && !on ? "#808080" : "#FFFFFF", "left", 0.8);
            U.text(ctx, "x" + b.n, x + w - 14, yy + 2, "#FFE9A8", "right", 0.8);
        });
        note(ctx, "Changes to the zone show after Save (reopen to see the new count). The orange box in the world is the zone.", x, y + h - 18, w, 0.7);
    };

    // ---- Chests ----
    function chanceOf(c, i) { var v = c.chances ? c.chances[i] : null; return v === null || v === undefined ? 100 : v; }
    PAGES["*:items"] = function (ctx, S, x, y, w, h) {
        var a = S.a, c = S.cfg;
        c.chances = c.chances || [];
        S.slots = [];
        var gx = x + Math.floor((w - 9 * 21) / 2);
        for (var i = 0; i < 27; i++) {
            var sx = gx + (i % 9) * 21, sy = y + 2 + Math.floor(i / 9) * 26, st = (c.items || [])[i];
            U.itemSlot(ctx, st, sx, sy);
            if (st) {
                var ch = chanceOf(c, i);
                U.text(ctx, ch + "%", sx + 9, sy + 19, ch >= 100 ? "#9FE09F" : ch >= 50 ? "#E6D25A" : "#FF8A8A", "center", 0.6);
                U.hit(sx, sy, 18, 18, null, [itemLabel(st.id), "Drop chance: " + ch + "%", "Wheel: ±5%, Shift: ±1%"]);
            }
            S.slots.push({ x: sx, y: sy, i: i });
        }
        U.button(ctx, "Edit items...", x + w / 2 - 50, y + 82, 100, 14, function () { save(a, c); S.onClose = null; U.send("loot_items", { dungeon: a.dungeon, key: a.key, paint: !!a.paint }); },
            { tip: ["Put the possible rewards in a chest screen", "Chances are kept per slot", "Small Keys and the Boss Key put here belong to each run"] });
        note(ctx, "Mouse wheel over a slot sets its chance (Shift = 1%). A slot left alone always drops. " + ({ sk_chest: "A Small Key opens it (used up).", bk_chest: "The Boss Key opens it.", pz_chest: "It appears when a linked puzzle powers it." }[a.type] || ""), x, y + 100, w, 0.7);
    };
    PAGES["*:settings"] = function (ctx, S, x, y, w, h) {
        var a = S.a, ry = y;
        nameRow(ctx, S, x, ry, w); ry += 18;
        U.label(ctx, "Facing", x, ry, 60);
        U.dropdown(ctx, "ch_f", x + 100, ry + 1, 120, 13, FACINGS, S.cfg.facing || "south", function (v) { S.cfg.facing = v; }, { search: false });
        ry += 18;
        if (a.type === "pz_chest") { lookRow(ctx, S, x, ry, w); ry += 18; ry += inputsRow(ctx, S, x, ry, w); }
        note(ctx, { loot: "In a run it is a plain chest.", sk_chest: "In a run it is a locked chest until a Small Key opens it.", bk_chest: "In a run it is the big chest; only the Boss Key opens it.",
            pz_chest: "Hidden until it is powered, then a chest appears here." }[a.type], x, ry + 4, w, 0.75);
    };
    ["loot", "sk_chest", "bk_chest", "pz_chest"].forEach(function (t) { SIZE[t] = [240, 200]; });
    ["door", "sk_door", "bk_door", "pz_door", "bridge"].forEach(function (t) { SIZE[t] = [330, 236]; });
    function lootScroll(S, x, y, d) {
        if (!S.slots) return false;
        for (var i = 0; i < S.slots.length; i++) {
            var s = S.slots[i];
            if (x >= s.x && y >= s.y && x < s.x + 18 && y < s.y + 18) {
                if (!(S.cfg.items || [])[s.i]) return true;
                var shift = RPG.isKeyDown("key.keyboard.left.shift") || RPG.isKeyDown("key.keyboard.right.shift");
                var v = chanceOf(S.cfg, s.i) + (d > 0 ? 1 : -1) * (shift ? 1 : 5);
                S.cfg.chances[s.i] = U.clamp(v, 0, 100);
                return true;
            }
        }
        return false;
    }

    // ---- Switch ----
    var KINDS = [{ value: "lever", label: "Lever", tooltip: "Right-click or hit it" }, { value: "plate", label: "Floor switch", tooltip: "Stand on it, or push a Push Block onto it" },
        { value: "crystal", label: "Crystal switch", tooltip: "Hit it, right-click it, or shoot it with the Dungeon Bow" },
        { value: "eye", label: "Eye switch", tooltip: "Only an arrow from the Dungeon Bow opens it" }, { value: "torch", label: "Torch", tooltip: "Lit with the Dungeon Lantern" }];
    var MODES = [{ value: "toggle", label: "Toggle", tooltip: "Each hit flips it" }, { value: "once", label: "Stays on", tooltip: "On for good once hit" },
        { value: "timed", label: "Timed", tooltip: "On for a few seconds (torches burn out)" }, { value: "hold", label: "Only while held", tooltip: "Floor switches: on while something stands on it" }];
    PAGES["switch:general"] = function (ctx, S, x, y, w, h) {
        var c = S.cfg, ry = y;
        nameRow(ctx, S, x, ry, w); ry += 18;
        U.label(ctx, "Kind", x, ry, 90);
        U.dropdown(ctx, "sw_k", x + 100, ry + 1, 130, 13, KINDS, c.kind || "lever", function (v) { c.kind = v; if (v !== "plate" && c.mode === "hold") c.mode = "toggle"; U.resetElements(); }, { search: false });
        ry += 18;
        U.label(ctx, "Works", x, ry, 90);
        U.dropdown(ctx, "sw_m" + c.kind, x + 100, ry + 1, 130, 13, MODES.filter(function (m) { return m.value !== "hold" || c.kind === "plate"; }), c.mode || "toggle", function (v) { c.mode = v; }, { search: false });
        if (c.mode === "timed") {
            U.label(ctx, "Seconds", x + 238, ry, 50);
            U.numField(ctx, "sw_t", x + w - 34, ry, 34, c.time, function (v) { c.time = U.clamp((v | 0) || 1, 1, 600); }, { int: true, blank: 5 });
        }
        ry += 18;
        if ((c.kind || "lever") === "lever") {
            U.label(ctx, "Mounted", x, ry, 90);
            U.dropdown(ctx, "sw_f", x + 100, ry + 1, 130, 13, [{ value: "floor", label: "On the floor" }, { value: "ceiling", label: "On the ceiling" }, { value: "north", label: "Wall, facing north" },
                { value: "south", label: "Wall, facing south" }, { value: "east", label: "Wall, facing east" }, { value: "west", label: "Wall, facing west" }], c.face || "floor", function (v) { c.face = v; }, { search: false });
            ry += 18;
        }
        U.label(ctx, "Starts on", x, ry, 90);
        U.toggle(ctx, !!c.startOn, x + 100, ry + 1, function () { c.startOn = !c.startOn; }, ["Already on when the run starts"]);
        ry += 18;
        U.text(ctx, (c.links || []).length + " link(s): see the Links tab", x, ry + 2, "#E8C860", "left", 0.8);
        note(ctx, (KINDS.filter(function (k) { return k.value === (c.kind || "lever"); })[0] || {}).tooltip + ". In a run the module becomes the switch itself.", x, ry + 16, w, 0.75);
    };

    // ---- Logic Gate ----
    var OPS = [{ value: "and", label: "AND: every input on" }, { value: "or", label: "OR: any input on" }, { value: "xor", label: "XOR: an odd number on" },
        { value: "not", label: "NOT: no input on" }, { value: "seq", label: "Sequence: inputs in order" }];
    PAGES["logic:general"] = function (ctx, S, x, y, w, h) {
        var a = S.a, c = S.cfg, ry = y;
        nameRow(ctx, S, x, ry, w); ry += 18;
        U.label(ctx, "Gate", x, ry, 90);
        U.dropdown(ctx, "lg_o", x + 100, ry + 1, 170, 13, OPS, c.op || "and", function (v) { c.op = v; }, { search: false });
        ry += 18;
        U.label(ctx, "Stays on", x, ry, 90);
        U.toggle(ctx, c.op === "seq" || !!c.latch, x + 100, ry + 1, function () { c.latch = !c.latch; }, ["Once on, it stays on (a solved puzzle stays solved)", "A sequence always stays solved"]);
        ry += 18;
        // inputs, in order (the order matters for sequences)
        var ins = a.inputs || [];
        if (!S.order) S.order = ins.map(function (i) { return i.key; });
        c.order = S.order;
        U.text(ctx, "Inputs" + (c.op === "seq" ? " (hit them in this order; a wrong one resets them)" : ""), x, ry + 2, "#E8C860", "left", 0.8);
        ry += 12;
        U.inset(ctx, x - 2, ry, w + 4, h - (ry - y) - 4);
        if (!ins.length) U.text(ctx, "None: link switches (their Links tab) to this gate", x + w / 2, ry + 12, "#909090", "center", 0.75);
        U.list(ctx, "lg_in", x, ry + 2, w - 8, h - (ry - y) - 8, S.order, 13, function (k, i, yy) {
            var t = null; ins.forEach(function (o) { if (o.key === k) t = o; });
            if (!t) return;
            U.text(ctx, (i + 1) + ".", x + 2, yy + 2, "#FFE9A8", "left", 0.8);
            U.icon(ctx, t.type, x + 14, yy, 10);
            U.text(ctx, U.fit(ctx, t.name, w - 80), x + 27, yy + 2, "#FFFFFF", "left", 0.8);
            U.iconButton(ctx, "up", x + w - 36, yy, 10, function () { if (i > 0) { var o = S.order[i - 1]; S.order[i - 1] = k; S.order[i] = o; } }, "Earlier", i === 0);
            U.iconButton(ctx, "down", x + w - 22, yy, 10, function () { if (i < S.order.length - 1) { var o = S.order[i + 1]; S.order[i + 1] = k; S.order[i] = o; } }, "Later", i === S.order.length - 1);
        });
    };
})();
