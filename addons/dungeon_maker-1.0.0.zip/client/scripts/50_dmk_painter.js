// =====================================================================================
//  Dungeon Maker (client) - the dungeon painter: paint a dungeon as a top-down map
// =====================================================================================
//  Opened from the Dungeon Selection admin tools (Paint) or /dungeons paint <id>. One cell is one
//  block column of the dungeon's workshop plot; floors are layers (the one below shows faded).
//  Tools like the sprite creator's: pencil (B), eraser (E), line (L), rectangle (U, Shift+U filled),
//  room (R), corridor (C), bucket (G), picker (I), select (M: move, copy, paste, flip, rotate), mirror
//  X / Y, undo / redo, wheel zoom, middle or Space drag to pan, ? for every shortcut.
//
//  The map is drawn from two RPG.images.canvas textures (one pixel per cell: the floor and the faded
//  floor below), scaled up, so even 128 x 128 is one quad; close up, visible cells get their block
//  textures and the module icons. The server (scripts/40_dungeon_maker_paint.js) checks and keeps
//  the map, builds it into the plot and reads plots back.
// =====================================================================================
var DMK_PAINTER = (function () {
    var U = DMK_UI;
    var SCREEN = "dmk_paint";
    var TILES = [
        { c: "f", name: "Floor", key: "1", tip: "Walkable floor" },
        { c: "w", name: "Wall", key: "2", tip: "A wall as tall as the floor's wall height" },
        { c: ".", name: "Empty", key: "0", tip: "Nothing: left as air when generated" },
        { c: "o", name: "Pit", tip: "A hole: no floor (into the floor below, or a pit)" },
        { c: "d", name: "Doorway", key: "3", tip: "An open doorway in a wall" },
        { c: "L", name: "Locked door", key: "4", tip: "A door module: small key, boss key, key item or puzzle door", anchor: true },
        { c: "C", name: "Chest", key: "5", tip: "A loot chest module (loot, small key, big key or puzzle chest)", anchor: true },
        { c: "S", name: "Mob spawner", key: "6", tip: "A mob spawner module: pick its mobs and drops", anchor: true },
        { c: "B", name: "Boss spawner", tip: "A boss fight module", anchor: true },
        { c: "E", name: "Entry point", key: "7", tip: "Where players appear (exactly one)", anchor: true },
        { c: "X", name: "Exit point", key: "8", tip: "Where the run ends (at least one)", anchor: true },
        { c: "U", name: "Stairs up", key: "9", tip: "A straight flight climbing to the floor above:\none cell per block of height, ending next to a 'stairs down'" },
        { c: "D", name: "Stairs down", tip: "The landing on the upper floor where stairs arrive" },
        { c: "P", name: "Pillar", tip: "A column of the pillar block" },
        { c: "T", name: "Light", tip: "A lantern or torch (or a glowing floor and ceiling block)" },
        { c: "~", name: "Water", tip: "A water hazard" },
        { c: "^", name: "Lava", tip: "A lava hazard" },
        { c: "*", name: "Decoration", tip: "The theme's decoration block" }
    ];
    var TILE = {};
    TILES.forEach(function (t) { TILE[t.c] = t; });
    var ANCHOR = { L: 1, C: 1, S: 1, B: 1, E: 1, X: 1 };
    var KINDS = { L: [["sk_door", "Small key door"], ["bk_door", "Boss key door"], ["door", "Key item door"], ["pz_door", "Puzzle door"]],
        C: [["loot", "Loot chest"], ["sk_chest", "Small key chest"], ["bk_chest", "Big key chest"], ["pz_chest", "Puzzle chest"]] };
    var ICON_OF = { S: "spawner", B: "boss", E: "entry", X: "exit", sk_door: "sk_door", bk_door: "bk_door", door: "door", pz_door: "pz_door",
        loot: "loot", sk_chest: "sk_chest", bk_chest: "bk_chest", pz_chest: "pz_chest", U: "up", D: "down" };
    var TOOLS = [
        ["pencil", "Pencil", "B", "Paint the tile; right-click erases\nShift+click: a line from the last point\nAlt+click: pick the tile under the cursor"],
        ["eraser", "Eraser", "E", "Back to empty"],
        ["line", "Line", "L", "Drag a line of the tile\nShift: snap to straight and 45 degrees"],
        ["rect", "Rectangle", "U", "Drag a rectangle outline\nShift+U: the filled rectangle"],
        ["frect", "Filled rectangle", "Shift+U", "Drag a filled rectangle"],
        ["room", "Room", "R", "Drag a room: floor inside, walls round it\n(walls only go on empty cells, so rooms merge)"],
        ["corridor", "Corridor", "C", "Drag a corridor (an L shape) with walls along both sides\n[ ] change its width"],
        ["fill", "Bucket fill", "G", "Fill the connected area of one tile"],
        ["picker", "Picker", "I", "Pick a tile; click a module to select it"],
        ["select", "Select", "M", "Drag to select, drag inside to move (Ctrl: a copy)\nCtrl+C/X/V, Del, Shift+H/V flip, Shift+R rotate\nEnter drops, Esc cancels; click a module to set it up"]
    ];
    // 12x12 tool icons in the sprite creator's style, drawn once into a pixel canvas
    var ICON_ART = {
        pencil: ["..........r.", ".........rrr", "........#rr.", ".......###..", "......###...", ".....###....", "....###.....", "...###......", "..###.......", "..o#........", ".oo.........", "............"],
        eraser: ["............", "............", "............", ".##########.", ".#rrrrr#oo#.", ".#rrrrr#oo#.", ".#rrrrr#oo#.", ".##########.", "............", "............", ".#########..", "............"],
        line: ["............", ".........##.", ".........##.", "........#...", ".......#....", "......#.....", ".....#......", "....#.......", "...#........", ".##.........", ".##.........", "............"],
        rect: ["............", "............", ".##########.", ".#........#.", ".#........#.", ".#........#.", ".#........#.", ".#........#.", ".#........#.", ".##########.", "............", "............"],
        frect: ["............", "............", ".##########.", ".##########.", ".##########.", ".##########.", ".##########.", ".##########.", ".##########.", ".##########.", "............", "............"],
        room: ["............", ".##########.", ".#oooooooo#.", ".#oooooooo#.", ".#oooooooo#.", ".#oooooooo#.", ".#oooooooo#.", ".#oooooooo#.", ".#oooooooo#.", ".##########.", "............", "............"],
        corridor: ["............", "############", "oooooooooooo", "oooooooooooo", "#######oooo#", "......#oooo#", "......#oooo#", "......#oooo#", "......#oooo#", "......#oooo#", "......#oooo#", "............"],
        fill: ["............", "....#.......", "...#.#......", "..#...#.....", ".#.bbb.#....", "#bbbbbbb#...", ".#bbbbb#.b..", "..#bbb#..b..", "...#b#...bb.", "....#....bb.", "............", "............"],
        picker: ["............", ".........##.", "........####", ".......####.", "......#.##..", ".....#.#....", "....#.#.....", "...#.#......", "..#.#.......", ".#b#........", ".b#.........", "............"],
        select: ["............", "............", ".##.##.##.#.", "............", ".#........#.", "............", ".#........#.", "............", ".#........#.", "............", ".##.##.##.#.", "............"],
        mirrorx: [".....##.....", ".....##.....", ".#...##...#.", ".##..##..##.", ".###.##.###.", ".####..####.", ".###.##.###.", ".##..##..##.", ".#...##...#.", ".....##.....", ".....##.....", "............"],
        mirrory: ["............", ".#########..", "..#######...", "...#####....", "....###.....", "##########..", "##########..", "....###.....", "...#####....", "..#######...", ".#########..", "............"],
        undo: ["............", "...#........", "..##........", ".#########..", "..##......#.", "...#.......#", "...........#", "...........#", "..........#.", "......####..", "............", "............"],
        redo: ["............", "........#...", "........##..", "..#########.", ".#......##..", "#.......#...", "#...........", "#...........", ".#..........", "..####......", "............", "............"]
    };
    var ICON_KEYS = Object.keys(ICON_ART), ICON_COL = { "#": 0xFFE8E8E8, r: 0xFFE07070, o: 0xFF9AA0B0, b: 0xFF60A0F0 };
    var iconTex = null;
    function icons() {
        if (iconTex) return iconTex;
        try {
            var cv = RPG.images.canvas("dmk_paint_icons", 12 * ICON_KEYS.length, 12), px = [];
            for (var y = 0; y < 12; y++) for (var i = 0; i < ICON_KEYS.length; i++) for (var x = 0; x < 12; x++) px.push(ICON_COL[ICON_ART[ICON_KEYS[i]][y].charAt(x)] || 0);
            cv.setPixels(0, 0, 12 * ICON_KEYS.length, 12, px);
            iconTex = cv.texture;
        } catch (e) { iconTex = ""; }
        return iconTex;
    }
    function toolIcon(ctx, name, x, y, size, alpha) {
        var t = icons(), i = ICON_KEYS.indexOf(name);
        if (!t || i < 0) return;
        ctx.quad(t, x, y, size, size, i / ICON_KEYS.length, 0, (i + 1) / ICON_KEYS.length, 1, "#FFFFFF", alpha === undefined ? 1 : alpha);
    }

    // ---- state ------------------------------------------------------------------------------------------
    var P = null;          // the open map: {id, name, w, h, ox, oz, theme, floors: [{name, y, height, ceiling, a: [chars]}], A: {key: {type, cfg}}, moved: {}}
    var V = { floor: 0, zoom: 8, panX: 0, panY: 0, tool: "pencil", tile: "f", brush: 1, mirrorX: false, mirrorY: false, onion: true, grid: true, fitted: false };
    var undoStack = [], redoStack = [], dirty = false, info = null, problems = null, dialog = null, help = false, msg = "", msgColor = "#FFFFFF", msgUntil = 0;
    var drag = null, hits = [], sel = null, floating = null, clip = null, selected = null, lastCell = null, spaceHeld = false, busy = false;
    var wantCheck = false, dismissed = "";
    var blockList = null, blocksAsked = false, ddShown = {}, presets = {};
    var mapCv = null, onionCv = null, floatCv = null, colorCache = {};

    function say(t, c) { msg = String(t); msgColor = c || "#FFFFFF"; msgUntil = RPG.nowMs() + 4500; }
    function send(op, data) { var m = data || {}; m.op = op; m.id = P ? P.id : m.id; RPG.net.send("dmk_paint", m); }
    function clone(o) { return JSON.parse(JSON.stringify(o)); }
    function shiftDown() { return RPG.isKeyDown("key.keyboard.left.shift") || RPG.isKeyDown("key.keyboard.right.shift"); }
    function ctrlDown() { return RPG.isKeyDown("key.keyboard.left.control") || RPG.isKeyDown("key.keyboard.right.control"); }
    function altDown() { return RPG.isKeyDown("key.keyboard.left.alt") || RPG.isKeyDown("key.keyboard.right.alt"); }
    function inside(x, y, r) { return x >= r.x && y >= r.y && x < r.x + r.w && y < r.y + r.h; }

    // ---- messages from the server -------------------------------------------------------------------------
    U.onBig("paint", function (d) {
        if (!d || !d.map) return;
        var keepView = P && P.id === d.id;
        var m = d.map;
        P = { id: d.id, name: d.name, w: m.w, h: m.h, ox: m.ox, oz: m.oz, theme: m.theme, A: m.anchors || {}, moved: {}, generated: m.generated || null,
            floors: m.floors.map(function (f) { return { name: f.name, y: f.y, height: f.height, ceiling: f.ceiling !== false, a: f.cells.split("") }; }) };
        info = { plotHalf: d.plotHalf, maxSide: d.maxSide, maxFloors: d.maxFloors, canUndo: d.canUndo, saved: d.saved, bounds: d.bounds || null, rooms: d.rooms || [] };
        presets = d.presets || presets;
        problems = d.problems && (d.problems.errors.length || d.problems.warnings.length) ? d.problems : null;
        if (problems && !wantCheck && !problems.errors.length && JSON.stringify(problems) === dismissed) problems = null;
        busy = !!d.busy;
        if (!keepView) { V.floor = 0; V.fitted = false; undoStack = []; redoStack = []; sel = null; floating = null; selected = null; }
        V.floor = Math.min(V.floor, P.floors.length - 1);
        if (selected && !P.A[selected]) selected = null;
        dirty = false;
        colorCache = {};
        if (d.imported && d.imported.length) problems = { errors: [], warnings: d.imported };
        if (d.built) say("Built into the plot", "#7CFF7C");
        if (wantCheck && !problems) say("No problems found: ready to generate", "#7CFF7C");
        wantCheck = false;
        redrawAll();
        if (d.open || RPG.screen.getOpen() !== SCREEN) openScreen();
    });
    U.onBig("paint_blocks", function (d) {
        blockList = (d.blocks || []).map(function (id) { return { value: id, label: blockName(id), icon: id, tooltip: id }; });
        blockList.sort(function (a, b) { return a.label < b.label ? -1 : a.label > b.label ? 1 : 0; });
        ddShown = {};
    });
    RPG.net.on("dmk_msg", function (d) { if (d && RPG.screen.getOpen() === SCREEN) say(d.msg, d.ok ? "#7CFF7C" : "#FF7070"); });
    function blockName(id) {
        var p = String(id).split(":"), key = "block." + p[0] + "." + p[1];
        try { if (RPG.hasTranslation(key)) return RPG.translate(key); } catch (e) { }
        var n = p[p.length - 1].replace(/_/g, " ");
        return n.charAt(0).toUpperCase() + n.substring(1);
    }

    // ---- colours and textures ---------------------------------------------------------------------------------
    function shade(c, f) {
        var r = Math.min(255, Math.round(((c >> 16) & 255) * f)), g = Math.min(255, Math.round(((c >> 8) & 255) * f)), b = Math.min(255, Math.round((c & 255) * f));
        return (0xFF000000 + (r << 16) + (g << 8) + b);
    }
    function bcol(id, fallback) {
        if (colorCache[id] !== undefined) return colorCache[id];
        var c = 0;
        try { c = RPG.images.blockColor(id); } catch (e) { }
        return colorCache[id] = c || fallback;
    }
    var FIXED = { L: 0xFFD8A838, C: 0xFFC88A30, S: 0xFFD84848, B: 0xFF9030C0, E: 0xFF48D048, X: 0xFF40B8F0, U: 0xFFE8E8E8, D: 0xFFA8A8B8, T: 0xFFFFE070, "~": 0xFF3F76E4, "^": 0xFFE86010, o: 0xFF0A0A0E };
    function mix(c, to, k) {
        var r = ((c >> 16) & 255) * (1 - k) + ((to >> 16) & 255) * k, g = ((c >> 8) & 255) * (1 - k) + ((to >> 8) & 255) * k, b = (c & 255) * (1 - k) + (to & 255) * k;
        return 0xFF000000 + (Math.round(r) << 16) + (Math.round(g) << 8) + Math.round(b);
    }
    // the map keeps the theme's hues but always reads: floors light, walls dark
    function tileColor(c) {
        if (c === ".") return 0;
        if (FIXED[c]) return FIXED[c];
        var th = P.theme;
        switch (c) {
            case "f": return mix(bcol(th.floor, 0xFF7A7A7A), 0xFFE0E0E0, 0.45);
            case "w": return mix(bcol(th.wall, 0xFF5A5A5A), 0xFF464650, 0.55);
            case "P": return mix(bcol(th.pillar, 0xFF6A6A6A), 0xFF0C0C10, 0.3);
            case "d": return mix(bcol(th.floor, 0xFF7A7A7A), 0xFFFFFFFF, 0.6);
            case "*": return mix(bcol(th.floor, 0xFF7A7A7A), 0xFFE0E0E0, 0.2);
        }
        return 0xFFFF00FF;
    }
    var texCache = {};
    function btex(id) {
        if (texCache[id] !== undefined) return texCache[id];
        var t = null;
        try { t = RPG.images.blockTexture(id); } catch (e) { }
        var v1 = 1;
        if (t) { var s = RPG.images.size(t); if (s && s.h > s.w) v1 = s.w / s.h; }
        return texCache[id] = t ? { t: t, v1: v1 } : null;
    }
    function drawTex(ctx, id, x, y, s, tint, alpha) {
        var t = btex(id);
        if (!t) { ctx.fill(x, y, s, s, "#808080", alpha === undefined ? 1 : alpha); return; }
        ctx.quad(t.t, x, y, s, s, 0, 0, 1, t.v1, tint || "#FFFFFF", alpha === undefined ? 1 : alpha);
    }

    // ---- the map pixels ---------------------------------------------------------------------------------------
    function redrawAll() {
        if (!P) return;
        try {
            mapCv = RPG.images.canvas("dmk_paint_map", P.w, P.h);
            onionCv = RPG.images.canvas("dmk_paint_onion", P.w, P.h);
        } catch (e) { mapCv = onionCv = null; return; }
        var fl = P.floors[V.floor], px = new Array(P.w * P.h), i;
        for (i = 0; i < px.length; i++) px[i] = tileColor(fl.a[i]);
        mapCv.setPixels(0, 0, P.w, P.h, px);
        if (V.floor > 0) {
            var lo = P.floors[V.floor - 1].a;
            for (i = 0; i < px.length; i++) px[i] = tileColor(lo[i]);
            onionCv.setPixels(0, 0, P.w, P.h, px);
        }
    }
    function setCell(f, x, z, c) {
        if (x < 0 || z < 0 || x >= P.w || z >= P.h) return false;
        var fl = P.floors[f], i = z * P.w + x;
        if (fl.a[i] === c) return false;
        var old = fl.a[i];
        fl.a[i] = c;
        if (ANCHOR[old] && !ANCHOR[c]) delete P.A[f + "," + x + "," + z];
        if (f === V.floor && mapCv) mapCv.set(x, z, tileColor(c));
        dirty = true;
        return true;
    }
    function getCell(f, x, z) { return x < 0 || z < 0 || x >= P.w || z >= P.h ? null : P.floors[f].a[z * P.w + x]; }
    /** Paint with mirrors. */
    function paint(x, z, c) {
        var f = V.floor, ch = setCell(f, x, z, c);
        if (V.mirrorX) ch = setCell(f, P.w - 1 - x, z, c) || ch;
        if (V.mirrorY) ch = setCell(f, x, P.h - 1 - z, c) || ch;
        if (V.mirrorX && V.mirrorY) ch = setCell(f, P.w - 1 - x, P.h - 1 - z, c) || ch;
        return ch;
    }

    // ---- undo ---------------------------------------------------------------------------------------------------
    function snapshot() {
        return { w: P.w, h: P.h, ox: P.ox, oz: P.oz, theme: clone(P.theme), A: clone(P.A), moved: clone(P.moved), floor: V.floor,
            floors: P.floors.map(function (f) { return { name: f.name, y: f.y, height: f.height, ceiling: f.ceiling, cells: f.a.join("") }; }) };
    }
    function restore(s) {
        P.w = s.w; P.h = s.h; P.ox = s.ox; P.oz = s.oz; P.theme = clone(s.theme); P.A = clone(s.A); P.moved = clone(s.moved);
        P.floors = s.floors.map(function (f) { return { name: f.name, y: f.y, height: f.height, ceiling: f.ceiling, a: f.cells.split("") }; });
        V.floor = Math.min(s.floor, P.floors.length - 1);
        colorCache = {};
        redrawAll();
        dirty = true;
    }
    var pending = null;
    /** Call before a change: the state before it goes on the undo stack. */
    function begin() { pending = snapshot(); }
    function commit() {
        if (!pending) return;
        undoStack.push(pending); pending = null; redoStack = [];
        while (undoStack.length > 100) undoStack.shift();
    }
    function undo() { if (drag || !undoStack.length) return; dropFloat(true); redoStack.push(snapshot()); restore(undoStack.pop()); say("Undo", "#C0C0C0"); }
    function redo() { if (drag || !redoStack.length) return; undoStack.push(snapshot()); restore(redoStack.pop()); say("Redo", "#C0C0C0"); }

    // ---- shapes -----------------------------------------------------------------------------------------------
    function lineCells(x0, z0, x1, z1) {
        var out = [], dx = Math.abs(x1 - x0), dz = -Math.abs(z1 - z0), sx = x0 < x1 ? 1 : -1, sz = z0 < z1 ? 1 : -1, err = dx + dz;
        for (var n = 0; n < 1000; n++) {
            out.push([x0, z0]);
            if (x0 === x1 && z0 === z1) break;
            var e2 = 2 * err;
            if (e2 >= dz) { err += dz; x0 += sx; }
            if (e2 <= dx) { err += dx; z0 += sz; }
        }
        return out;
    }
    function snap(a, b) {
        if (!shiftDown()) return b;
        var dx = b[0] - a[0], dz = b[1] - a[1], ax = Math.abs(dx), az = Math.abs(dz);
        if (ax > az * 2) return [b[0], a[1]];
        if (az > ax * 2) return [a[0], b[1]];
        var d = Math.max(ax, az);
        return [a[0] + (dx < 0 ? -d : d), a[1] + (dz < 0 ? -d : d)];
    }
    /** The cells a shape tool would paint: [[x, z, tile]...] (room / corridor walls only where empty). */
    function shapeCells(tool, a, b) {
        var out = [], x0 = Math.min(a[0], b[0]), x1 = Math.max(a[0], b[0]), z0 = Math.min(a[1], b[1]), z1 = Math.max(a[1], b[1]), x, z, t = V.tile;
        var put = function (x2, z2, c) { if (x2 >= 0 && z2 >= 0 && x2 < P.w && z2 < P.h) out.push([x2, z2, c]); };
        if (tool === "line") { lineCells(a[0], a[1], b[0], b[1]).forEach(function (p) { put(p[0], p[1], t); }); }
        else if (tool === "rect" || tool === "frect") {
            for (z = z0; z <= z1; z++) for (x = x0; x <= x1; x++) if (tool === "frect" || x === x0 || x === x1 || z === z0 || z === z1) put(x, z, t);
        } else if (tool === "room") {
            for (z = z0; z <= z1; z++) for (x = x0; x <= x1; x++) {
                var edge = x === x0 || x === x1 || z === z0 || z === z1, cur = getCell(V.floor, x, z);
                if (!edge) { if (cur === "." || cur === "w" || cur === "o" || cur === "f") put(x, z, "f"); }
                else if (cur === "." || cur === "o") put(x, z, "w");
            }
        } else if (tool === "corridor") {
            // an L: along the longer axis first, then the other; floor `brush` wide, walls along both sides
            var path = [], wdt = Math.max(1, V.brush), r = Math.floor((wdt - 1) / 2), corner = Math.abs(b[0] - a[0]) >= Math.abs(b[1] - a[1]) ? [b[0], a[1]] : [a[0], b[1]];
            lineCells(a[0], a[1], corner[0], corner[1]).concat(lineCells(corner[0], corner[1], b[0], b[1])).forEach(function (p) { path.push(p); });
            var floor = {}, key = function (x2, z2) { return x2 + "," + z2; };
            path.forEach(function (p) { for (var i = -r; i < wdt - r; i++) for (var j = -r; j < wdt - r; j++) floor[key(p[0] + i, p[1] + j)] = [p[0] + i, p[1] + j]; });
            var walls = {};
            Object.keys(floor).forEach(function (k) {
                var c = floor[k];
                for (var i = -1; i <= 1; i++) for (var j = -1; j <= 1; j++) { var k2 = key(c[0] + i, c[1] + j); if (!floor[k2]) walls[k2] = [c[0] + i, c[1] + j]; }
            });
            Object.keys(floor).forEach(function (k) { var c = floor[k], cur = getCell(V.floor, c[0], c[1]); if (cur === "." || cur === "w" || cur === "o" || cur === "f") put(c[0], c[1], "f"); });
            Object.keys(walls).forEach(function (k) { var c = walls[k], cur = getCell(V.floor, c[0], c[1]); if (cur === "." || cur === "o") put(c[0], c[1], "w"); });
        }
        return out;
    }
    function bucket(x, z, c) {
        var f = V.floor, target = getCell(f, x, z);
        if (target === null || target === c) return;
        var q = [[x, z]], seen = {}, n = 0;
        seen[z * P.w + x] = 1;
        while (q.length && n < 20000) {
            var p = q.pop(); n++;
            setCell(f, p[0], p[1], c);
            [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (s) {
                var nx = p[0] + s[0], nz = p[1] + s[1], i = nz * P.w + nx;
                if (nx < 0 || nz < 0 || nx >= P.w || nz >= P.h || seen[i] || P.floors[f].a[i] !== target) return;
                seen[i] = 1; q.push([nx, nz]);
            });
        }
    }

    // ---- selection ----------------------------------------------------------------------------------------------
    function lift(copy) {
        if (!sel || floating) return;
        var f = V.floor, cells = [], A = {};
        for (var z = 0; z < sel.h; z++) for (var x = 0; x < sel.w; x++) {
            var cx = sel.x + x, cz = sel.z + z, c = getCell(f, cx, cz), k = f + "," + cx + "," + cz;
            cells.push(c);
            if (P.A[k]) A[x + "," + z] = { type: P.A[k].type, from: P.moved[k] || k, cfg: P.A[k].cfg };
            if (!copy) setCell(f, cx, cz, ".");
        }
        floating = { x: sel.x, z: sel.z, w: sel.w, h: sel.h, cells: cells, A: A };
        floatTexture();
    }
    function floatTexture() {
        if (!floating) return;
        try {
            floatCv = RPG.images.canvas("dmk_paint_float", floating.w, floating.h);
            floatCv.setPixels(0, 0, floating.w, floating.h, floating.cells.map(function (c) { return c === "." ? 0 : tileColor(c); }));
        } catch (e) { floatCv = null; }
    }
    function dropFloat(cancel) {
        if (!floating) return;
        if (!cancel) {
            var f = V.floor;
            for (var z = 0; z < floating.h; z++) for (var x = 0; x < floating.w; x++) {
                var c = floating.cells[z * floating.w + x], cx = floating.x + x, cz = floating.z + z;
                if (c === "." || cx < 0 || cz < 0 || cx >= P.w || cz >= P.h) continue;
                setCell(f, cx, cz, c);
                var a = floating.A[x + "," + z], k = f + "," + cx + "," + cz;
                if (a) { P.A[k] = { type: a.type, cfg: a.cfg }; if (a.from !== k) P.moved[k] = a.from; }
            }
            sel = { x: floating.x, z: floating.z, w: floating.w, h: floating.h };
        }
        floating = null;
        commit();
    }
    function transform(op) {
        if (sel && !floating) { begin(); lift(false); }
        if (!floating) { say("Select an area first (M)", "#FFB050"); return; }
        var F = floating, out = [], A2 = {}, w = F.w, h = F.h, nw = op === 2 ? h : w, nh = op === 2 ? w : h;
        for (var z = 0; z < h; z++) for (var x = 0; x < w; x++) {
            var nx = op === 0 ? w - 1 - x : op === 1 ? x : h - 1 - z, nz = op === 0 ? z : op === 1 ? h - 1 - z : x;
            out[nz * nw + nx] = F.cells[z * w + x];
            if (F.A[x + "," + z]) A2[nx + "," + nz] = F.A[x + "," + z];
        }
        // stairs keep running the same way relative to the copy only roughly: they are re-checked on save
        F.cells = out; F.A = A2; F.w = nw; F.h = nh;
        floatTexture();
    }
    function copySel(cut) {
        if (floating) { clip = clone({ w: floating.w, h: floating.h, cells: floating.cells, A: floating.A }); if (cut) { floating = null; commit(); } say("Copied " + clip.w + " x " + clip.h); return; }
        if (!sel) { say("Select an area first (M)", "#FFB050"); return; }
        var f = V.floor, cells = [], A = {};
        for (var z = 0; z < sel.h; z++) for (var x = 0; x < sel.w; x++) {
            var k = f + "," + (sel.x + x) + "," + (sel.z + z);
            cells.push(getCell(f, sel.x + x, sel.z + z));
            if (P.A[k]) A[x + "," + z] = { type: P.A[k].type, from: P.moved[k] || k, cfg: P.A[k].cfg };
        }
        clip = { w: sel.w, h: sel.h, cells: cells, A: A };
        if (cut) { begin(); for (var z2 = 0; z2 < sel.h; z2++) for (var x2 = 0; x2 < sel.w; x2++) setCell(f, sel.x + x2, sel.z + z2, "."); commit(); }
        say((cut ? "Cut " : "Copied ") + clip.w + " x " + clip.h);
    }
    function pasteClip() {
        if (!clip) return;
        dropFloat();
        V.tool = "select";
        begin();
        var at = lastCell || [0, 0];
        floating = { x: at[0], z: at[1], w: clip.w, h: clip.h, cells: clip.cells.slice(), A: clone(clip.A) };
        floatTexture();
    }
    function deleteSel() {
        if (floating) { floating = null; commit(); return; }
        if (!sel) return;
        begin();
        for (var z = 0; z < sel.h; z++) for (var x = 0; x < sel.w; x++) setCell(V.floor, sel.x + x, sel.z + z, ".");
        commit();
    }

    // ---- anchors on the client: keys like the server's ("floor,x,z"; a door by its first cell) --------------------------
    function doorFirst(f, x, z) {
        var w = P.w, a = P.floors[f].a, best = z * w + x, seen = {}, q = [best];
        seen[best] = 1;
        while (q.length) {
            var i = q.pop(), cx = i % w, cz = Math.floor(i / w);
            if (i < best) best = i;
            [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (s) {
                var nx = cx + s[0], nz = cz + s[1], j = nz * w + nx;
                if (nx < 0 || nz < 0 || nx >= w || nz >= P.h || seen[j] || a[j] !== "L") return;
                seen[j] = 1; q.push(j);
            });
        }
        return f + "," + (best % w) + "," + Math.floor(best / w);
    }
    function anchorKey(f, x, z) { var c = getCell(f, x, z); if (!ANCHOR[c]) return null; return c === "L" ? doorFirst(f, x, z) : f + "," + x + "," + z; }
    function exportMap() {
        var anchors = {};
        P.floors.forEach(function (fl, f) {
            for (var i = 0; i < fl.a.length; i++) {
                var c = fl.a[i];
                if (!ANCHOR[c]) continue;
                var x = i % P.w, z = Math.floor(i / P.w), k = anchorKey(f, x, z);
                if (anchors[k]) continue;
                var own = P.A[k] || P.A[f + "," + x + "," + z];
                anchors[k] = { type: own ? own.type : null };
                var from = P.moved[k] || (own && !P.A[k] ? f + "," + x + "," + z : null);
                if (from) anchors[k].from = from;
            }
        });
        return { w: P.w, h: P.h, ox: P.ox, oz: P.oz, theme: P.theme, anchors: anchors,
            floors: P.floors.map(function (f) { return { name: f.name, y: f.y, height: f.height, ceiling: f.ceiling, cells: f.a.join("") }; }) };
    }
    var upSeq = 0;
    function upload(then) {
        dropFloat();
        var o = exportMap();
        o.then = then || {};
        var s = JSON.stringify(o), n = Math.max(1, Math.ceil(s.length / 24000)), tag = "u" + (++upSeq) + "_" + RPG.nowMs();
        for (var i = 0; i < n; i++) RPG.net.send("dmk_paint", { op: "up", id: P.id, tag: tag, i: i, n: n, s: s.substring(i * 24000, (i + 1) * 24000) });
        dirty = false;
    }
    function setupAnchor(k) {
        if (!k) return;
        say("Opening the module settings...", "#FFE070");
        upload({ anchor: k, quiet: true });
    }

    // ---- the screen -----------------------------------------------------------------------------------------------
    var L = {};    // layout of the last frame
    function openScreen() {
        RPG.screen.open({ id: SCREEN, referenceHeight: 360, background: "#101116", pause: false, closeOnEsc: false, elements: [],
            onBackground: draw, onRender: drawTop, onMouse: mouse, onScroll: scroll, onKey: key,
            onClose: function () { ddShown = {}; hideDropdowns(); } });
        ddShown = {};
    }
    function close() {
        if (dirty) { dialog = { kind: "leave" }; return; }
        RPG.screen.close();
    }
    function reopen() { if (P) send("open", { id: P.id }); }

    function layout(ctx) {
        var W = ctx.width, H = ctx.height;
        L = { W: W, H: H, top: 22, left: 56, right: 152, bottom: 16 };
        L.cx = L.left; L.cy = L.top + 2; L.cw = W - L.left - L.right; L.ch = H - L.top - L.bottom - 4;
    }
    function fit() {
        var z = Math.min(L.cw / P.w, L.ch / P.h) * 0.92;
        var steps = [1, 1.5, 2, 3, 4, 5, 6, 8, 10, 12, 14, 16, 20, 24, 28, 32];
        V.zoom = steps[0];
        steps.forEach(function (s) { if (s <= z) V.zoom = s; });
        V.panX = Math.round((L.cw - P.w * V.zoom) / 2); V.panY = Math.round((L.ch - P.h * V.zoom) / 2);
        V.fitted = true;
    }
    function zoomStep(dir, mx, my) {
        var steps = [1, 1.5, 2, 3, 4, 5, 6, 8, 10, 12, 14, 16, 20, 24, 28, 32], i = 0;
        while (i < steps.length - 1 && steps[i] < V.zoom) i++;
        var nz = dir > 0 ? steps[Math.min(steps.length - 1, steps[i] > V.zoom ? i : i + 1)] : steps[Math.max(0, i - 1)];
        if (nz === V.zoom) return;
        var ax = mx - L.cx, ay = my - L.cy;
        V.panX = ax - (ax - V.panX) * nz / V.zoom; V.panY = ay - (ay - V.panY) * nz / V.zoom;
        V.zoom = nz;
    }
    function cellAt(mx, my) { return [Math.floor((mx - L.cx - V.panX) / V.zoom), Math.floor((my - L.cy - V.panY) / V.zoom)]; }
    function inCanvas(mx, my) { return mx >= L.cx && my >= L.cy && mx < L.cx + L.cw && my < L.cy + L.ch; }

    function hit(x, y, w, h, fn, tip, right) { hits.push({ x: x, y: y, w: w, h: h, fn: fn, tip: tip, right: right }); }
    function over(ctx, x, y, w, h) { return inside(ctx.mouseX, ctx.mouseY, { x: x, y: y, w: w, h: h }); }
    function button(ctx, label, x, y, w, h, fn, opt) {
        opt = opt || {};
        var dis = !!opt.disabled, hov = !dis && over(ctx, x, y, w, h), kind = opt.kind || "normal", row = dis ? 2 : hov || opt.selected ? 1 : 0;
        if (U.art()) U.slice(ctx, "button_" + kind + ".png", x, y, w, h, 0, row * 20, 48, 20, 48, 60, 4);
        else { ctx.fill(x, y, w, h, dis ? "#2A2A2E" : { normal: "#3C4050", green: "#2F6B33", red: "#7A2C2C", gold: "#7A5E22" }[kind], 1); ctx.fill(x, y, w, 1, "#FFFFFF", hov ? 0.5 : 0.2); }
        U.text(ctx, U.fit(ctx, label, w - 4, opt.scale || 0.85), x + w / 2, y + (h - 8 * (opt.scale || 0.85)) / 2, dis ? "#8A8A8A" : hov ? "#FFF6C0" : "#FFFFFF", "center", opt.scale || 0.85);
        hit(x, y, w, h, dis ? null : fn, opt.tip);
    }
    function iconBtn(ctx, draw, x, y, s, fn, tip, on) {
        var hov = over(ctx, x, y, s, s);
        ctx.fill(x, y, s, s, on ? "#5A4A22" : "#000000", on ? 0.9 : 0.35);
        if (on) { ctx.fill(x, y, s, 1, "#E8C860", 1); ctx.fill(x, y + s - 1, s, 1, "#E8C860", 1); ctx.fill(x, y, 1, s, "#E8C860", 1); ctx.fill(x + s - 1, y, 1, s, "#E8C860", 1); }
        if (hov) ctx.fill(x, y, s, s, "#FFFFFF", 0.15);
        draw(x, y, s);
        hit(x, y, s, s, fn, tip);
    }

    // a tile's swatch: block texture (or the module's icon over the floor)
    function tileSwatch(ctx, c, x, y, s, kindType) {
        var th = P.theme;
        switch (c) {
            case ".": ctx.fill(x, y, s, s, "#2A2C34", 1); ctx.fill(x, y, s / 2, s / 2, "#34363F", 1); ctx.fill(x + s / 2, y + s / 2, s / 2, s / 2, "#34363F", 1); return;
            case "o": ctx.fill(x, y, s, s, "#050507", 1); ctx.fill(x + 1, y + 1, s - 2, 2, "#202028", 1); return;
            case "f": drawTex(ctx, th.floor, x, y, s); return;
            case "w": drawTex(ctx, th.wall, x, y, s); ctx.fill(x, y, s, s, "#000000", 0.35); ctx.fill(x, y, s, Math.max(1, s / 8), "#FFFFFF", 0.25); return;
            case "P": drawTex(ctx, th.floor, x, y, s); drawTex(ctx, th.pillar, x + s * 0.18, y + s * 0.18, s * 0.64); ctx.fill(x + s * 0.18, y + s * 0.18, s * 0.64, s * 0.64, "#000000", 0.25); return;
            case "d": drawTex(ctx, th.floor, x, y, s); ctx.fill(x, y, s * 0.18, s, "#000000", 0.45); ctx.fill(x + s * 0.82, y, s * 0.18, s, "#000000", 0.45); return;
            case "T": drawTex(ctx, th.floor, x, y, s); itemAt(ctx, th.light, x, y, s); return;
            case "*": drawTex(ctx, th.floor, x, y, s); itemAt(ctx, th.deco, x, y, s); return;
            case "~": drawTex(ctx, "minecraft:water", x, y, s, "#3F76E4"); return;
            case "^": drawTex(ctx, "minecraft:lava", x, y, s); return;
            case "U": case "D":
                drawTex(ctx, th.floor, x, y, s); drawTex(ctx, th.stairs, x + s * 0.1, y + s * 0.1, s * 0.8, "#FFFFFF", 0.9);
                U.icon(ctx, c === "U" ? "up" : "down", x + s * 0.2, y + s * 0.2, s * 0.6); return;
            case "L":
                drawTex(ctx, th.floor, x, y, s); drawTex(ctx, th.door, x, y, s, "#FFFFFF", 0.9);
                U.icon(ctx, ICON_OF[kindType || "sk_door"] || "sk_door", x + s * 0.25, y + s * 0.25, s * 0.5); return;
            case "C": drawTex(ctx, th.floor, x, y, s); U.icon(ctx, ICON_OF[kindType || "loot"] || "loot", x + s * 0.08, y + s * 0.08, s * 0.84); return;
            default: drawTex(ctx, th.floor, x, y, s); U.icon(ctx, ICON_OF[c], x + s * 0.08, y + s * 0.08, s * 0.84);
        }
    }
    function itemAt(ctx, id, x, y, s) { ctx.push(); ctx.translate(x, y); ctx.scale(s / 16, s / 16); ctx.item(id, 0, 0); ctx.pop(); }

    // ---- drawing ---------------------------------------------------------------------------------------------------
    function draw(ctx) {
        if (!P) return;
        hits = [];
        layout(ctx);
        if (!V.fitted) fit();
        if (!drag && inCanvas(ctx.mouseX, ctx.mouseY)) lastCell = cellAt(ctx.mouseX, ctx.mouseY);
        drawCanvasArea(ctx);
        // frames
        ctx.fill(0, 0, L.W, L.top, "#1E2028", 1); ctx.fill(0, L.top - 1, L.W, 1, "#3A3D4C", 1);
        ctx.fill(0, L.top, L.left - 2, L.H, "#191B22", 1);
        ctx.fill(L.W - L.right + 2, L.top, L.right, L.H, "#191B22", 1);
        ctx.fill(0, L.H - L.bottom, L.W, L.bottom, "#1E2028", 1);
        drawTopBar(ctx);
        drawTools(ctx);
        drawSide(ctx);
        drawStatus(ctx);
        if (problems) drawProblems(ctx);
        if (dialog) drawDialog(ctx); else hideDropdowns();
        if (help) drawHelp(ctx);
    }
    function drawTop(ctx) {
        if (!P) return;
        for (var i = hits.length - 1; i >= 0; i--) {
            var h = hits[i];
            if (h.tip && inside(ctx.mouseX, ctx.mouseY, h)) { tooltip(ctx, typeof h.tip === "string" ? h.tip.split("\n") : h.tip, ctx.mouseX, ctx.mouseY); break; }
        }
    }
    /** A tooltip that stays on screen: left of the cursor near the right edge, lines wrapped. */
    function tooltip(ctx, lines, mx, my) {
        var out = [], s = 0.8;
        lines.forEach(function (l, i) { U.wrap(ctx, l, 230, s).forEach(function (t) { out.push([t, i === 0 ? "#FFE070" : "#D0D0D0"]); }); });
        var w = 0;
        out.forEach(function (l) { w = Math.max(w, U.tw(ctx, l[0], s)); });
        w = Math.ceil(w) + 12;
        var h = out.length * 9 + 6, x = mx + 12, y = my + 10;
        if (x + w > L.W - 2) x = mx - w - 6;
        if (y + h > L.H - 2) y = L.H - h - 2;
        x = Math.max(2, x);
        ctx.fill(x, y, w, h, "#100A18", 0.96); ctx.fill(x, y, w, 1, "#5A2CA0", 1); ctx.fill(x, y + h - 1, w, 1, "#28104A", 1);
        out.forEach(function (l, i) { U.text(ctx, l[0], x + 6, y + 4 + i * 9, l[1], "left", s); });
    }
    function drawTopBar(ctx) {
        U.text(ctx, "Dungeon Painter", 6, 4, "#FFE9A8", "left", 1);
        U.text(ctx, U.fit(ctx, P.name + (dirty ? " *" : ""), 120, 0.75), 6, 13, "#A8A8A8", "left", 0.75);
        var x = 140, y = 3, h = 16;
        var b = function (label, w, fn, opt) { button(ctx, label, x, y, w, h, fn, opt); x += w + 3; };
        b("Save", 38, function () { upload(); }, { tip: ["Save the map (Ctrl+S)", "Kept with the dungeon and its export"], kind: dirty ? "gold" : "normal" });
        b("Check", 40, function () { wantCheck = true; upload({ quiet: true }); say("Checking...", "#FFE070"); }, { tip: ["Save and check", "Exactly one entry, at least one exit, stairs that connect"] });
        b(P.generated ? "Regenerate" : "Generate", 62, function () { dialog = { kind: "generate" }; }, { kind: "green", disabled: busy, tip: ["Build the map into the plot", "Clears the painted area first (kept for Undo)"] });
        b("Undo build", 56, function () { dialog = { kind: "undo" }; }, { disabled: !info.canUndo || busy, tip: ["Put back what the last Generate replaced"] });
        b("Import", 44, function () { dialog = { kind: "import" }; }, { disabled: busy, tip: ["Import from plot", "Reads the plot's build back into this map (best effort)"] });
        b("Theme", 42, function () { dialog = { kind: "theme" }; ddShown = {}; }, { tip: ["The blocks the dungeon is built with", "Presets and any block"] });
        b("Map", 32, function () { dialog = { kind: "map", w: P.w, h: P.h, ox: P.ox, oz: P.oz }; }, { tip: ["Map size and where it sits on the plot"] });
        b("Plot", 34, function () { if (dirty) upload({ quiet: true }); send("plot"); }, { tip: ["Go to the dungeon's workshop plot"] });
        x = L.W - 60;
        button(ctx, "?", x, y, 16, h, function () { help = !help; }, { tip: ["Help and shortcuts (?)"] });
        button(ctx, "Close", x + 19, y, 38, h, close, { kind: "red" });
    }
    function drawTools(ctx) {
        var x0 = 4, y0 = L.top + 4, s = 22;
        TOOLS.forEach(function (t, i) {
            var x = x0 + (i % 2) * (s + 2), y = y0 + Math.floor(i / 2) * (s + 2);
            iconBtn(ctx, function (bx, by) { toolIcon(ctx, t[0], bx + 2, by + 2, s - 4); }, x, y, s, function () { setTool(t[0]); }, [t[1] + "  (" + t[2] + ")"].concat(t[3].split("\n")), V.tool === t[0]);
        });
        var y = y0 + 5 * (s + 2) + 6;
        U.text(ctx, "Mirror", x0, y, "#909090", "left", 0.7); y += 9;
        iconBtn(ctx, function (bx, by) { toolIcon(ctx, "mirrorx", bx + 2, by + 2, s - 4); }, x0, y, s, function () { V.mirrorX = !V.mirrorX; }, ["Mirror X (X)", "Paints mirrored left-right too"], V.mirrorX);
        iconBtn(ctx, function (bx, by) { toolIcon(ctx, "mirrory", bx + 2, by + 2, s - 4); }, x0 + s + 2, y, s, function () { V.mirrorY = !V.mirrorY; }, ["Mirror Y (Y)", "Paints mirrored top-bottom too"], V.mirrorY);
        y += s + 6;
        U.text(ctx, V.tool === "corridor" ? "Width" : "Brush", x0, y, "#909090", "left", 0.7); y += 9;
        button(ctx, "-", x0, y, 14, 14, function () { V.brush = Math.max(1, V.brush - 1); }, { tip: ["Smaller ( [ )"] });
        U.text(ctx, String(V.brush), x0 + 23, y + 3, "#FFE9A8", "center", 0.9);
        button(ctx, "+", x0 + 32, y, 14, 14, function () { V.brush = Math.min(7, V.brush + 1); }, { tip: ["Bigger ( ] )"] });
        y += 22;
        iconBtn(ctx, function (bx, by) { toolIcon(ctx, "undo", bx + 2, by + 2, s - 4, undoStack.length ? 1 : 0.35); }, x0, y, s, undo, ["Undo (Ctrl+Z)"]);
        iconBtn(ctx, function (bx, by) { toolIcon(ctx, "redo", bx + 2, by + 2, s - 4, redoStack.length ? 1 : 0.35); }, x0 + s + 2, y, s, redo, ["Redo (Ctrl+Y)"]);
        y += s + 6;
        button(ctx, V.grid ? "Grid ✔" : "Grid", x0, y, 46, 13, function () { V.grid = !V.grid; }, { scale: 0.7, tip: ["Cell grid when zoomed in"] });
        button(ctx, V.onion ? "Below ✔" : "Below", x0, y + 15, 46, 13, function () { V.onion = !V.onion; }, { scale: 0.7, tip: ["Show the floor below, faded (Tab)"] });
        button(ctx, "Fit", x0, y + 30, 46, 13, fit, { scale: 0.7, tip: ["Fit the map (F)"] });
    }
    function drawSide(ctx) {
        var x0 = L.W - L.right + 8, w = L.right - 14, y = L.top + 4, s = 21, cols = 6;
        U.text(ctx, "Tiles", x0, y, "#E8C860", "left", 0.85); y += 11;
        TILES.forEach(function (t, i) {
            var x = x0 + (i % cols) * (s + 2), ty = y + Math.floor(i / cols) * (s + 2), on = V.tile === t.c;
            ctx.fill(x - 1, ty - 1, s + 2, s + 2, on ? "#E8C860" : "#000000", on ? 1 : 0.6);
            tileSwatch(ctx, t.c, x, ty, s);
            if (over(ctx, x, ty, s, s)) ctx.fill(x, ty, s, s, "#FFFFFF", 0.2);
            hit(x, ty, s, s, function () { V.tile = t.c; if (V.tool === "eraser" || V.tool === "picker" || V.tool === "select") setTool("pencil"); },
                [t.name + (t.key ? "  (" + t.key + ")" : "")].concat(t.tip.split("\n")));
        });
        y += Math.ceil(TILES.length / cols) * (s + 2) + 2;
        U.text(ctx, U.fit(ctx, TILE[V.tile].name, w, 0.8), x0, y, "#FFFFFF", "left", 0.8); y += 12;
        // floors
        ctx.fill(x0 - 4, y, w + 6, 1, "#3A3D4C", 1); y += 4;
        U.text(ctx, "Floors", x0, y, "#E8C860", "left", 0.85);
        button(ctx, "+", x0 + w - 30, y - 2, 14, 12, addFloor, { scale: 0.8, tip: ["Add a floor above", "PageUp / PageDown switch floors"], disabled: P.floors.length >= info.maxFloors });
        button(ctx, "-", x0 + w - 14, y - 2, 14, 12, function () { dialog = { kind: "delfloor" }; }, { scale: 0.8, tip: ["Delete this floor"], disabled: P.floors.length <= 1 });
        y += 12;
        for (var i = P.floors.length - 1; i >= 0; i--) {
            (function (i) {
                var fl = P.floors[i], on = i === V.floor;
                button(ctx, (i + 1) + ": " + fl.name + "   y " + (fl.y >= 0 ? "+" : "") + fl.y, x0, y, w, 12, function () { setFloor(i); }, { kind: on ? "gold" : "normal", selected: on, scale: 0.7 });
            })(i);
            y += 13;
        }
        var fl = P.floors[V.floor];
        y += 2;
        y = stepper(ctx, "Floor level", fl.y, x0, y, w, function (d) { setFloorY(V.floor, fl.y + d); }, ["Floor level", "The floor blocks' height from the plot's", "starting platform (-1 = on it)"]);
        y = stepper(ctx, "Wall height", fl.height, x0, y, w, function (d) { setHeight(V.floor, fl.height + d); }, ["Wall height", "How tall the walls are (2-12)"]);
        U.text(ctx, "Ceiling", x0, y + 2, "#D8D2C0", "left", 0.75);
        toggle(ctx, fl.ceiling, x0 + w - 22, y, function () { begin(); fl.ceiling = !fl.ceiling; dirty = true; commit(); }, ["Ceiling", "A ceiling of the ceiling block over the rooms"]);
        y += 15;
        // the selected module
        ctx.fill(x0 - 4, y, w + 6, 1, "#3A3D4C", 1); y += 4;
        var a = selected && P.A[selected];
        if (selected && !a) selected = null;
        if (!selected) {
            U.text(ctx, "Module", x0, y, "#E8C860", "left", 0.85); y += 11;
            U.wrap(ctx, "Click a module tile (door, chest, spawner, boss, entry, exit) with the picker or select tool to set it up.", w, 0.68).forEach(function (l, i2) { U.text(ctx, l, x0, y + i2 * 8, "#909090", "left", 0.68); });
            return;
        }
        var c = selected.split(","), tch = getCell(c[0] | 0, c[1] | 0, c[2] | 0);
        U.text(ctx, U.fit(ctx, (a.cfg && a.cfg.name ? a.cfg.name : TILE[tch] ? TILE[tch].name : a.type), w, 0.85), x0, y, "#E8C860", "left", 0.85); y += 10;
        U.text(ctx, "Floor " + (Number(c[0]) + 1) + " · cell " + c[1] + ", " + c[2], x0, y, "#909090", "left", 0.7); y += 10;
        if (KINDS[tch]) {
            KINDS[tch].forEach(function (k, i3) {
                button(ctx, k[1], x0 + (i3 % 2) * (w / 2 + 1), y + Math.floor(i3 / 2) * 13, w / 2 - 1, 12, function () {
                    if (a.type === k[0]) return; begin(); a.type = k[0]; a.cfg = null; dirty = true; commit();
                }, { kind: a.type === k[0] ? "gold" : "normal", selected: a.type === k[0], scale: 0.62 });
            });
            y += 28;
        }
        U.text(ctx, summary(a), x0, y, "#B8B0A0", "left", 0.68); y += 10;
        button(ctx, "Set up...", x0, y, w, 15, function () { setupAnchor(selected); }, { kind: "green", tip: ["Open the module's settings", "(the same screen the workshop block opens)"] });
    }
    function summary(a) {
        var c = a.cfg || {};
        switch (a.type) {
            case "spawner": return (c.groups || []).length ? (c.groups || []).map(function (g) { return g.count + "x " + U.entityName(g.entity); }).join(", ") : "No mobs yet";
            case "boss": return c.entity ? U.entityName(c.entity) : "No boss picked yet";
            case "entry": return "Faces " + (c.facing || "south");
            case "exit": return "Radius " + (c.radius || 3);
            case "door": return c.key ? "Key: " + c.key.id : "No key item yet";
        }
        if (/chest|loot/.test(a.type)) { var n = (c.items || []).filter(function (s) { return s; }).length; return n ? n + " item stack(s)" : "Empty"; }
        return "";
    }
    function stepper(ctx, label, value, x, y, w, fn, tip) {
        U.text(ctx, label, x, y + 2, "#D8D2C0", "left", 0.75);
        hit(x, y, 60, 12, null, tip);
        button(ctx, "-", x + w - 46, y, 12, 12, function () { fn(shiftDown() ? -5 : -1); }, { scale: 0.8 });
        U.text(ctx, String(value), x + w - 23, y + 2, "#FFE9A8", "center", 0.8);
        button(ctx, "+", x + w - 12, y, 12, 12, function () { fn(shiftDown() ? 5 : 1); }, { scale: 0.8 });
        return y + 14;
    }
    function toggle(ctx, on, x, y, fn, tip) {
        ctx.fill(x, y, 22, 11, "#000000", 0.8);
        ctx.fill(x + 1, y + 1, 20, 9, on ? "#3E8E41" : "#5A2B2B", 1);
        ctx.fill(on ? x + 12 : x + 1, y + 1, 9, 9, "#E8E8E8", 1);
        hit(x, y, 22, 11, fn, tip);
    }
    function drawStatus(ctx) {
        var y = L.H - L.bottom + 4, parts = [P.floors[V.floor].name];
        if (lastCell && lastCell[0] >= 0 && lastCell[1] >= 0 && lastCell[0] < P.w && lastCell[1] < P.h) {
            var c = getCell(V.floor, lastCell[0], lastCell[1]);
            parts.push("cell " + lastCell[0] + ", " + lastCell[1] + "  (block " + (lastCell[0] + P.ox) + ", " + (lastCell[1] + P.oz) + " from the plot centre)");
            parts.push(TILE[c] ? TILE[c].name : c);
        }
        parts.push(P.w + " x " + P.h);
        parts.push(Math.round(V.zoom * 100) + "%");
        if (sel) parts.push("selection " + sel.w + " x " + sel.h);
        if (busy) parts.push("building...");
        U.text(ctx, parts.join("  ·  "), 6, y, "#B0B0B0", "left", 0.72);
        if (msg && RPG.nowMs() < msgUntil) {
            var t = U.fit(ctx, msg, L.cw - 10, 0.8), tw = U.tw(ctx, t, 0.8);
            ctx.fill(L.cx + 4, L.cy + L.ch - 16, tw + 8, 12, "#000000", 0.7);
            U.text(ctx, t, L.cx + 8, L.cy + L.ch - 14, msgColor, "left", 0.8);
        }
    }
    function drawProblems(ctx) {
        var lines = [], w = Math.min(320, L.cw - 20);
        problems.errors.forEach(function (e) { lines.push(["✖ " + e, "#FF8080"]); });
        problems.warnings.forEach(function (e) { lines.push(["• " + e, "#E8D080"]); });
        var wrapped = [];
        lines.forEach(function (l) { U.wrap(ctx, l[0], w - 12, 0.72).forEach(function (t2) { wrapped.push([t2, l[1]]); }); });
        wrapped = wrapped.slice(0, 14);
        var h = 18 + wrapped.length * 9, x = L.cx + 6, y = L.cy + L.ch - h - 20;
        ctx.fill(x, y, w, h, "#0C0D12", 0.92); ctx.fill(x, y, w, 1, problems.errors.length ? "#E05050" : "#E8C860", 1);
        U.text(ctx, problems.errors.length ? problems.errors.length + " problem(s) to fix before generating" : "Notes", x + 5, y + 4, problems.errors.length ? "#FF9090" : "#E8C860", "left", 0.78);
        wrapped.forEach(function (l, i) { U.text(ctx, l[0], x + 6, y + 15 + i * 9, l[1], "left", 0.72); });
        hit(x, y, w, h, function () { });
        button(ctx, "x", x + w - 13, y + 2, 11, 10, function () { dismissed = JSON.stringify(problems); problems = null; }, { scale: 0.7, tip: ["Hide (Check shows it again)"] });
    }

    function drawCanvasArea(ctx) {
        var x0 = L.cx + V.panX, y0 = L.cy + V.panY, z = V.zoom, mw = P.w * z, mh = P.h * z;
        ctx.clip(L.cx, L.cy, L.cw, L.ch);
        ctx.fill(L.cx, L.cy, L.cw, L.ch, "#15171D", 1);
        ctx.fill(x0, y0, mw, mh, "#18191F", 1);
        if (V.onion && V.floor > 0 && onionCv) ctx.quad(onionCv.texture, x0, y0, mw, mh, 0, 0, 1, 1, "#9AA6C8", 0.3);
        // the cells we can see
        var cx0 = Math.max(0, Math.floor(-V.panX / z)), cz0 = Math.max(0, Math.floor(-V.panY / z));
        var cx1 = Math.min(P.w - 1, Math.floor((L.cw - V.panX) / z)), cz1 = Math.min(P.h - 1, Math.floor((L.ch - V.panY) / z));
        var visible = (cx1 - cx0 + 1) * (cz1 - cz0 + 1), fl = P.floors[V.floor];
        if (z >= 10 && visible <= 1800) {
            for (var cz = cz0; cz <= cz1; cz++) for (var cx = cx0; cx <= cx1; cx++) {
                var c = fl.a[cz * P.w + cx];
                if (c === ".") continue;
                var kt = null;
                if (c === "L" || c === "C") { var k = anchorKey(V.floor, cx, cz), a = P.A[k]; kt = a ? a.type : null; }
                tileSwatch(ctx, c, x0 + cx * z, y0 + cz * z, z, kt);
            }
        } else if (mapCv) {
            ctx.quad(mapCv.texture, x0, y0, mw, mh, 0, 0, 1, 1, "#FFFFFF", 1);
            if (z >= 5) {
                // module icons stay readable from afar
                for (var cz2 = cz0; cz2 <= cz1; cz2++) for (var cx2 = cx0; cx2 <= cx1; cx2++) {
                    var c2 = fl.a[cz2 * P.w + cx2];
                    if (!ANCHOR[c2] && c2 !== "U" && c2 !== "D") continue;
                    var ic = c2 === "L" || c2 === "C" ? (P.A[anchorKey(V.floor, cx2, cz2)] || {}).type || (c2 === "L" ? "sk_door" : "loot") : c2;
                    U.icon(ctx, ICON_OF[ic] || ICON_OF[c2], x0 + cx2 * z, y0 + cz2 * z, z);
                }
            }
        }
        // grid
        if (V.grid && z >= 6) {
            for (var gx = cx0; gx <= cx1 + 1; gx++) ctx.fill(x0 + gx * z, y0 + cz0 * z, 1, (cz1 - cz0 + 1) * z, "#FFFFFF", gx % 8 === 0 ? 0.16 : 0.06);
            for (var gz = cz0; gz <= cz1 + 1; gz++) ctx.fill(x0 + cx0 * z, y0 + gz * z, (cx1 - cx0 + 1) * z, 1, "#FFFFFF", gz % 8 === 0 ? 0.16 : 0.06);
        }
        // the dungeon's bounds and rooms (Dungeon / Room Wand) over the map: outlines and names only
        overlays(ctx, x0, y0, z);
        // the map's edge and the plot centre
        ctx.lines([x0, y0, x0 + mw, y0, x0 + mw, y0 + mh, x0, y0 + mh], 1, "#6B5A33", 1, true);
        var pcx = x0 + (-P.ox + 0.5) * z, pcz = y0 + (-P.oz + 0.5) * z;
        if (pcx > x0 && pcx < x0 + mw && pcz > y0 && pcz < y0 + mh) { ctx.line(pcx - 4, pcz, pcx + 4, pcz, 1, "#E8C860", 0.6); ctx.line(pcx, pcz - 4, pcx, pcz + 4, 1, "#E8C860", 0.6); }
        if (V.mirrorX) ctx.fill(x0 + mw / 2 - 0.5, y0 - 6, 1, mh + 12, "#E8C860", 0.7);
        if (V.mirrorY) ctx.fill(x0 - 6, y0 + mh / 2 - 0.5, mw + 12, 1, "#E8C860", 0.7);
        // the shape being dragged
        if (drag && drag.preview) drag.preview.forEach(function (p) { ctx.fill(x0 + p[0] * z, y0 + p[1] * z, z, z, hex(tileColor(p[2]) || 0xFF202020), 0.75); });
        // selection
        if (floating) {
            if (floatCv) ctx.quad(floatCv.texture, x0 + floating.x * z, y0 + floating.z * z, floating.w * z, floating.h * z, 0, 0, 1, 1, "#FFFFFF", 0.9);
            ants(ctx, x0 + floating.x * z, y0 + floating.z * z, floating.w * z, floating.h * z);
        } else if (sel) ants(ctx, x0 + sel.x * z, y0 + sel.z * z, sel.w * z, sel.h * z);
        if (selected) {
            var sc = selected.split(",");
            if ((sc[0] | 0) === V.floor) { var sx = x0 + (sc[1] | 0) * z, sy = y0 + (sc[2] | 0) * z; ctx.lines([sx - 1, sy - 1, sx + z + 1, sy - 1, sx + z + 1, sy + z + 1, sx - 1, sy + z + 1], 2, "#FFE070", 1, true); }
        }
        // cursor
        if ((lastCell && inCanvas(ctx.mouseX, ctx.mouseY) && !dialog && !drag) || (drag && drag.kind === "draw")) {
            var n = V.tool === "pencil" || V.tool === "eraser" ? V.brush : 1, r = Math.floor((n - 1) / 2), cc = lastCell || [0, 0];
            var bx = x0 + (cc[0] - r) * z, by = y0 + (cc[1] - r) * z;
            ctx.lines([bx, by, bx + n * z, by, bx + n * z, by + n * z, bx, by + n * z], 1, "#000000", 0.9, true);
            ctx.lines([bx + 1, by + 1, bx + n * z - 1, by + 1, bx + n * z - 1, by + n * z - 1, bx + 1, by + n * z - 1], 1, "#FFFFFF", 0.9, true);
        }
        ctx.unclip();
    }
    var ROOM_COL = { combat: "#FF5050", puzzle: "#B070FF", trap: "#FF9930", treasure: "#FFD040", boss: "#D02828", safe: "#50E070" };
    function overlays(ctx, x0, y0, z) {
        var fl = P.floors[V.floor], b = info.bounds;
        if (b) {
            var bx = x0 + (b.x1 - P.ox) * z, by = y0 + (b.z1 - P.oz) * z, bw = (b.x2 - b.x1 + 1) * z, bh = (b.z2 - b.z1 + 1) * z;
            ctx.lines([bx, by, bx + bw, by, bx + bw, by + bh, bx, by + bh], 2, "#E8C860", 0.8, true);
        }
        (info.rooms || []).forEach(function (r) {
            var rb = r.box;
            if (rb.y2 < fl.y || rb.y1 > fl.y + fl.height + 1) return;            // not on this floor
            var col = ROOM_COL[r.type] || "#FFFFFF", rx = x0 + (rb.x1 - P.ox) * z, ry = y0 + (rb.z1 - P.oz) * z, rw = (rb.x2 - rb.x1 + 1) * z, rh = (rb.z2 - rb.z1 + 1) * z;
            if (r.shape === "sphere") {
                var pts = [], cx = x0 + (r.c[0] - P.ox + 0.5) * z, cz = y0 + (r.c[2] - P.oz + 0.5) * z, dy = Math.max(0, Math.abs(fl.y + 1 - r.c[1]) - 0.5), rad = Math.sqrt(Math.max(0, (r.r + 0.5) * (r.r + 0.5) - dy * dy)) * z;
                for (var i = 0; i < 32; i++) { var a = i / 32 * Math.PI * 2; pts.push(cx + Math.cos(a) * rad, cz + Math.sin(a) * rad); }
                ctx.lines(pts, 2, col, 0.85, true);
            } else {
                ctx.fill(rx, ry, rw, rh, col, 0.08);
                ctx.lines([rx, ry, rx + rw, ry, rx + rw, ry + rh, rx, ry + rh], 2, col, 0.85, true);
            }
            if (z >= 3) U.text(ctx, r.name, rx + 3, ry + 3, col, "left", 0.75);
        });
    }
    function hex(c) { var s = ((c >>> 0) & 0xFFFFFF).toString(16); while (s.length < 6) s = "0" + s; return "#" + s; }
    function ants(ctx, x, y, w, h) {
        var ph = Math.floor(RPG.nowMs() / 120) % 8;
        ctx.lines([x, y, x + w, y, x + w, y + h, x, y + h], 1, "#000000", 1, true);
        for (var i = -ph; i < w; i += 8) { var a = Math.max(0, i), b = Math.min(w, i + 4); if (b > a) { ctx.fill(x + a, y, b - a, 1, "#FFFFFF", 1); ctx.fill(x + a, y + h - 1, b - a, 1, "#FFFFFF", 1); } }
        for (var j = -ph; j < h; j += 8) { var c = Math.max(0, j), d = Math.min(h, j + 4); if (d > c) { ctx.fill(x, y + c, 1, d - c, "#FFFFFF", 1); ctx.fill(x + w - 1, y + c, 1, d - c, "#FFFFFF", 1); } }
    }

    // ---- floors, size, theme -----------------------------------------------------------------------------------------
    function setFloor(i) { if (i < 0 || i >= P.floors.length || i === V.floor) return; dropFloat(); sel = null; V.floor = i; redrawAll(); }
    function addFloor() {
        if (P.floors.length >= info.maxFloors) return;
        begin();
        var top = P.floors[P.floors.length - 1], cells = [];
        for (var i = 0; i < P.w * P.h; i++) cells.push(".");
        P.floors.push({ name: "Floor " + (P.floors.length + 1), y: top.y + top.height + 1, height: top.height, ceiling: true, a: cells });
        commit(); dirty = true;
        setFloor(P.floors.length - 1);
        say("Floor " + P.floors.length + " added " + (top.height + 1) + " blocks above: stairs from below climb that much", "#7CFF7C");
    }
    function deleteFloor() {
        if (P.floors.length <= 1) return;
        begin();
        var f = V.floor, A2 = {}, M2 = {};
        Object.keys(P.A).forEach(function (k) { var c = k.split(","), cf = c[0] | 0; if (cf === f) return; A2[(cf > f ? cf - 1 : cf) + "," + c[1] + "," + c[2]] = P.A[k]; });
        Object.keys(P.moved).forEach(function (k) { var c = k.split(","), cf = c[0] | 0; if (cf === f) return; M2[(cf > f ? cf - 1 : cf) + "," + c[1] + "," + c[2]] = P.moved[k]; });
        P.floors.splice(f, 1); P.A = A2; P.moved = M2;
        V.floor = Math.max(0, f - 1);
        commit(); dirty = true; redrawAll();
    }
    function setFloorY(f, y) {
        var fl = P.floors[f], lo = f > 0 ? P.floors[f - 1].y + P.floors[f - 1].height + 1 : -120, hi = f + 1 < P.floors.length ? P.floors[f + 1].y - fl.height - 1 : 240;
        y = Math.max(lo, Math.min(hi, y));
        if (y === fl.y) { say(f > 0 || f + 1 < P.floors.length ? "Floors can't overlap" : "That's as far as it goes", "#FFB050"); return; }
        begin(); fl.y = y; dirty = true; commit();
    }
    function setHeight(f, h) {
        var fl = P.floors[f], max = f + 1 < P.floors.length ? P.floors[f + 1].y - fl.y - 1 : 12;
        h = Math.max(2, Math.min(12, Math.min(max, h)));
        if (h === fl.height) { say(max < 12 ? "The floor above is in the way: raise it first" : "Wall height is 2 to 12", "#FFB050"); return; }
        begin(); fl.height = h; dirty = true; commit();
    }
    function resize(w, h, ox, oz) {
        var maxS = info.maxSide, half = info.plotHalf;
        w = Math.max(4, Math.min(maxS, w)); h = Math.max(4, Math.min(maxS, h));
        ox = Math.max(-half, Math.min(half - w + 1, ox)); oz = Math.max(-half, Math.min(half - h + 1, oz));
        begin();
        // keep each cell over the same block of the plot
        var dx = ox - P.ox, dz = oz - P.oz, A2 = {}, M2 = {};
        P.floors.forEach(function (fl) {
            var a = [];
            for (var z = 0; z < h; z++) for (var x = 0; x < w; x++) { var sx = x + dx, sz = z + dz; a.push(sx >= 0 && sz >= 0 && sx < P.w && sz < P.h ? fl.a[sz * P.w + sx] : "."); }
            fl.a = a;
        });
        Object.keys(P.A).forEach(function (k) { var c = k.split(","), x = (c[1] | 0) - dx, z = (c[2] | 0) - dz; if (x >= 0 && z >= 0 && x < w && z < h) A2[c[0] + "," + x + "," + z] = P.A[k]; });
        Object.keys(P.moved).forEach(function (k) { var c = k.split(","), x = (c[1] | 0) - dx, z = (c[2] | 0) - dz; if (x >= 0 && z >= 0 && x < w && z < h) M2[c[0] + "," + x + "," + z] = P.moved[k]; });
        // a module whose cell moved keeps its settings
        Object.keys(A2).forEach(function (k) { var c = k.split(","), old = c[0] + "," + ((c[1] | 0) + dx) + "," + ((c[2] | 0) + dz); if (old !== k && !M2[k]) M2[k] = old; });
        P.w = w; P.h = h; P.ox = ox; P.oz = oz; P.A = A2; P.moved = M2;
        sel = null; floating = null; selected = null;
        commit(); dirty = true; redrawAll(); fit();
    }

    // ---- dialogs ---------------------------------------------------------------------------------------------------
    function hideDropdowns() { Object.keys(ddShown).forEach(function (k) { if (ddShown[k] !== "hidden") { RPG.screen.update(k, { visible: false }); ddShown[k] = "hidden"; } }); }
    function dropdown(id, x, y, w, h, value, onChange) {
        var sig = [x, y, w, value, blockList ? blockList.length : 0].join("|");
        if (ddShown[id] === sig) return;
        ddShown[id] = sig;
        RPG.screen.update(id, { type: "dropdown", anchor: "topleft", x: x, y: y, w: w, h: h, visible: true, options: blockList || [], value: value, placeholder: blockList ? "Pick a block" : "Loading...",
            search: true, searchHint: "Search blocks...", emptyText: "Nothing matches", listWidth: 200, maxVisible: 12, rowHeight: 14,
            bg: "#14151C", border: "#6B5A33", highlight: "#4A3E22", textColor: "#FFFFFF", listBg: "#101118", selectedBg: "#5A4A22", selectedText: "#FFE9A8",
            onChange: function (eid, v) { try { onChange(v); } catch (e) { RPG.log("[Dungeon Maker] " + e); } } });
    }
    function drawDialog(ctx) {
        var d = dialog;
        ctx.fill(0, 0, L.W, L.H, "#000000", 0.55);
        hits = [];
        hit(0, 0, L.W, L.H, function () { });
        var w = 300, h = 110, x, y;
        var box = function (title, ww, hh) { w = ww; h = hh; x = Math.floor((L.W - w) / 2); y = Math.floor((L.H - h) / 2); U.panel(ctx, x, y, w, h, title); };
        var lines = function (t, yy, col) { U.wrap(ctx, t, w - 32, 0.8).forEach(function (l, i) { U.text(ctx, l, x + 16, yy + i * 10, col || "#D8D2C0", "left", 0.8); }); };
        if (d.kind !== "theme") hideDropdowns();
        if (d.kind === "generate") {
            var cnt = 0; P.floors.forEach(function (fl) { fl.a.forEach(function (c) { if (c !== ".") cnt++; }); });
            box(P.generated ? "Regenerate" : "Generate", 320, 128);
            lines("Builds the map into the plot: the painted area (" + boundsText() + ") is cleared first, then " + P.floors.length + " floor(s) are placed a few milliseconds a tick, then the stairs and modules.", y + 20);
            lines("What was there is kept: Undo build puts it back.", y + 64, "#9FE09F");
            button(ctx, "Build it", x + 16, y + h - 28, 110, 20, function () { dialog = null; problems = null; busy = true; say("Saving and building...", "#FFE070"); upload({ generate: true, quiet: true }); }, { kind: "green" });
            button(ctx, "Cancel", x + w - 126, y + h - 28, 110, 20, function () { dialog = null; });
        } else if (d.kind === "undo") {
            box("Undo build", 300, 100);
            lines("Puts the plot back the way it was before the last Generate (blocks and module settings in that area).", y + 20);
            button(ctx, "Undo build", x + 16, y + h - 28, 110, 20, function () { dialog = null; send("undo"); }, { kind: "red" });
            button(ctx, "Cancel", x + w - 126, y + h - 28, 110, 20, function () { dialog = null; });
        } else if (d.kind === "import") {
            box("Import from plot", 320, 110);
            lines("Reads the plot's build back into this map: floors, walls, doorways, stairs, lights, hazards and the modules with their settings. Best effort: check it before generating. This replaces the painted map.", y + 20);
            button(ctx, "Import", x + 16, y + h - 28, 110, 20, function () { dialog = null; send("import"); say("Reading the plot...", "#FFE070"); }, { kind: "gold" });
            button(ctx, "Cancel", x + w - 126, y + h - 28, 110, 20, function () { dialog = null; });
        } else if (d.kind === "delfloor") {
            box("Delete floor", 280, 90);
            lines("Delete " + P.floors[V.floor].name + " and everything painted on it?", y + 22);
            button(ctx, "Delete", x + 16, y + h - 28, 100, 20, function () { dialog = null; deleteFloor(); }, { kind: "red" });
            button(ctx, "Cancel", x + w - 116, y + h - 28, 100, 20, function () { dialog = null; });
        } else if (d.kind === "leave") {
            box("Unsaved changes", 300, 90);
            lines("Save the map before closing?", y + 22);
            button(ctx, "Save", x + 16, y + h - 28, 80, 20, function () { dialog = null; upload({ quiet: true }); RPG.screen.close(); }, { kind: "green" });
            button(ctx, "Discard", x + 110, y + h - 28, 80, 20, function () { dialog = null; dirty = false; RPG.screen.close(); }, { kind: "red" });
            button(ctx, "Cancel", x + w - 96, y + h - 28, 80, 20, function () { dialog = null; });
        } else if (d.kind === "map") {
            box("Map size and place", 300, 150);
            var ry = y + 22;
            ry = stepper(ctx, "Width (cells)", d.w, x + 16, ry, w - 32, function (k) { d.w = Math.max(4, Math.min(info.maxSide, d.w + k * (shiftDown() ? 1 : 1))); }, ["Width", "4 to " + info.maxSide]);
            ry = stepper(ctx, "Length (cells)", d.h, x + 16, ry, w - 32, function (k) { d.h = Math.max(4, Math.min(info.maxSide, d.h + k)); }, ["Length", "4 to " + info.maxSide]);
            ry = stepper(ctx, "West edge (x from centre)", d.ox, x + 16, ry, w - 32, function (k) { d.ox += k; }, ["Where cell 0 sits on the plot", "The plot reaches " + info.plotHalf + " blocks from its centre"]);
            ry = stepper(ctx, "North edge (z from centre)", d.oz, x + 16, ry, w - 32, function (k) { d.oz += k; }, ["Where cell 0 sits on the plot"]);
            button(ctx, "Centre on the plot", x + 16, ry + 2, 120, 14, function () { d.ox = -Math.floor(d.w / 2); d.oz = -Math.floor(d.h / 2); }, { scale: 0.75 });
            var bnd = info.bounds;
            button(ctx, "Fit to bounds", x + 140, ry + 2, 100, 14, function () {
                d.w = Math.max(4, Math.min(info.maxSide, bnd.x2 - bnd.x1 + 1)); d.h = Math.max(4, Math.min(info.maxSide, bnd.z2 - bnd.z1 + 1)); d.ox = bnd.x1; d.oz = bnd.z1;
            }, { scale: 0.75, disabled: !bnd, tip: bnd ? ["The dungeon's bounds (Dungeon Wand)", (bnd.x2 - bnd.x1 + 1) + " x " + (bnd.z2 - bnd.z1 + 1)] : ["No bounds yet: set them with the Dungeon Wand"] });
            button(ctx, "Apply", x + 16, y + h - 28, 100, 20, function () { dialog = null; resize(d.w, d.h, d.ox, d.oz); }, { kind: "green" });
            button(ctx, "Cancel", x + w - 116, y + h - 28, 100, 20, function () { dialog = null; });
        } else if (d.kind === "theme") {
            if (!blockList && !blocksAsked) { blocksAsked = true; send("blocks"); }
            box("Theme", 330, 252);
            var ty = y + 18;
            U.text(ctx, "Presets", x + 16, ty, "#E8C860", "left", 0.8); ty += 10;
            Object.keys(presets).forEach(function (k, i) {
                button(ctx, presets[k].name, x + 16 + (i % 3) * 100, ty + Math.floor(i / 3) * 15, 96, 13, function () {
                    begin(); var p2 = presets[k]; ["floor", "wall", "ceiling", "pillar", "light", "stairs", "door", "deco"].forEach(function (b) { P.theme[b] = p2[b]; }); P.theme.preset = k; dirty = true; commit();
                    colorCache = {}; redrawAll(); ddShown = {};
                }, { kind: P.theme.preset === k ? "gold" : "normal", selected: P.theme.preset === k, scale: 0.72 });
            });
            ty += 34;
            [["floor", "Floor"], ["wall", "Wall"], ["ceiling", "Ceiling"], ["pillar", "Pillar"], ["light", "Light"], ["stairs", "Stairs"], ["door", "Locked door"], ["deco", "Decoration"]].forEach(function (r, i) {
                var ry2 = ty + i * 18;
                U.text(ctx, r[1], x + 16, ry2 + 4, "#D8D2C0", "left", 0.8);
                itemAt(ctx, P.theme[r[0]], x + 90, ry2, 15);
                dropdown("dmk_pt_" + r[0], x + 110, ry2 + 1, w - 126, 14, P.theme[r[0]], function (v) {
                    begin(); P.theme[r[0]] = v; P.theme.preset = "custom"; dirty = true; commit(); colorCache = {}; redrawAll();
                });
            });
            button(ctx, "Done", x + w / 2 - 50, y + h - 26, 100, 18, function () { dialog = null; hideDropdowns(); }, { kind: "green" });
        }
    }
    function boundsText() {
        var x1 = 1e9, z1 = 1e9, x2 = -1, z2 = -1;
        P.floors.forEach(function (fl) { for (var i = 0; i < fl.a.length; i++) if (fl.a[i] !== ".") { var x = i % P.w, z = Math.floor(i / P.w); x1 = Math.min(x1, x); x2 = Math.max(x2, x); z1 = Math.min(z1, z); z2 = Math.max(z2, z); } });
        if (x2 < 0) return "nothing yet";
        var lo = 1e9, hi = -1e9;
        P.floors.forEach(function (fl) { lo = Math.min(lo, fl.y - 3); hi = Math.max(hi, fl.y + fl.height + 1); });
        return (x2 - x1 + 1) + " x " + (z2 - z1 + 1) + " x " + (hi - lo + 1) + " blocks";
    }
    function drawHelp(ctx) {
        var rows = [
            ["Tools", "B pencil · E eraser · L line · U rectangle (Shift+U filled) · R room · C corridor · G bucket · I picker · M select"],
            ["Tiles", "1 floor · 2 wall · 3 doorway · 4 locked door · 5 chest · 6 spawner · 7 entry · 8 exit · 9 stairs up · 0 empty"],
            ["Painting", "Right-click erases · Alt+click picks · Shift+click: a line from the last point · [ ] brush / corridor width · X / Y mirror"],
            ["Selection", "Drag to select, drag inside to move (Ctrl: a copy) · Ctrl+C / X / V · Del · Shift+H / V flip · Shift+R rotate · Enter drop · Esc cancel"],
            ["Floors", "PageUp / PageDown switch floors · Tab shows the floor below · the panel sets each floor's level, wall height and ceiling"],
            ["View", "Wheel zoom · middle drag or Space+drag pan · F fit · + / - zoom"],
            ["Map", "Ctrl+Z undo · Ctrl+Y redo · Ctrl+S save · ? this help · Esc close"],
            ["Modules", "Click a door, chest, spawner, boss, entry or exit with the picker or select tool, then Set up: the same screen the workshop block opens"],
            ["Stairs", "Draw 'stairs up' as a straight line on the lower floor, one cell per block the next floor is higher, and a 'stairs down' landing on the upper floor right after the top end"],
            ["Generate", "Saves, checks (one entry, an exit, stairs that connect), clears the painted area (kept for Undo build) and builds floor by floor"]
        ];
        var w = Math.min(460, L.W - 40), lh = [], total = 30;
        rows.forEach(function (r) { var l = U.wrap(ctx, r[1], w - 90, 0.75); lh.push(l); total += l.length * 9 + 4; });
        var x = Math.floor((L.W - w) / 2), y = Math.floor((L.H - total) / 2);
        U.panel(ctx, x, y, w, total + 10, "Dungeon Painter help");
        var ry = y + 18;
        rows.forEach(function (r, i) {
            U.text(ctx, r[0], x + 14, ry, "#E8C860", "left", 0.8);
            lh[i].forEach(function (l, j) { U.text(ctx, l, x + 80, ry + j * 9, "#D8D2C0", "left", 0.75); });
            ry += lh[i].length * 9 + 4;
        });
        hits = [];
        hit(0, 0, L.W, L.H, function () { help = false; });
    }

    // ---- input -------------------------------------------------------------------------------------------------------
    function setTool(t) { if (t !== "select") dropFloat(); if (t !== "select") sel = null; V.tool = t; }
    function mouse(mx, my, button, action) {
        if (!P) return;
        if (action === "down") {
            if (RPG.screen.colorPickerOpen && RPG.screen.colorPickerOpen()) return;
            for (var i = hits.length - 1; i >= 0; i--) {
                var h = hits[i];
                if (inside(mx, my, h) && (h.fn || h.right)) {
                    var f = button === 1 ? h.right : button === 0 ? h.fn : null;
                    if (f) { try { RPG.uiSound("minecraft:ui.button.click", 0.25, 1.2); } catch (e) { } f(); }
                    return false;
                }
                if (inside(mx, my, h) && h.tip && !inCanvas(mx, my)) return false;
            }
            if (dialog || help || !inCanvas(mx, my)) return;
            press(mx, my, button);
            return false;
        }
        if (action === "drag") { if (drag) { dragTo(mx, my); return false; } return; }
        if (action === "up") { if (drag) { release(mx, my); return false; } }
    }
    function press(mx, my, btn) {
        var c = cellAt(mx, my);
        lastCell = c;
        if (btn === 2 || spaceHeld) { drag = { kind: "pan", sx: mx, sy: my, px: V.panX, py: V.panY }; return; }
        if (btn !== 0 && btn !== 1) return;
        var erase = btn === 1, tool = V.tool;
        if (altDown() && tool !== "select") { pickAt(c); return; }
        if (tool === "picker") { pickAt(c); return; }
        if (tool === "select") { selectPress(c); return; }
        if (tool === "fill") { begin(); bucket(c[0], c[1], erase ? "." : V.tile); commit(); return; }
        var tile = erase || tool === "eraser" ? "." : V.tile;
        if (tool === "pencil" || tool === "eraser") {
            // clicking a module with its own tile selects it
            if (!erase && tool === "pencil" && ANCHOR[tile] && getCell(V.floor, c[0], c[1]) === tile) { selected = anchorKey(V.floor, c[0], c[1]); return; }
            begin();
            if (shiftDown() && drag === null && lastStroke) lineCells(lastStroke[0], lastStroke[1], c[0], c[1]).forEach(function (p) { stamp(p[0], p[1], tile); });
            else stamp(c[0], c[1], tile);
            drag = { kind: "draw", tile: tile, last: c };
            lastStroke = c;
            return;
        }
        // shapes
        drag = { kind: "shape", tool: tool === "rect" && shiftDown() ? "frect" : tool, a: c, b: c, tile: erase ? "." : V.tile, erase: erase };
        drag.preview = previewOf(drag);
    }
    var lastStroke = null;
    function stamp(x, z, tile) {
        var n = V.brush, r = Math.floor((n - 1) / 2);
        for (var i = 0; i < n; i++) for (var j = 0; j < n; j++) paint(x - r + i, z - r + j, tile);
    }
    function previewOf(d) {
        var keep = V.tile;
        if (d.erase) V.tile = ".";
        var b = d.tool === "line" ? snap(d.a, d.b) : d.b, out = shapeCells(d.tool, d.a, b);
        V.tile = keep;
        if (out.length > 6000) out = out.slice(0, 6000);
        return out;
    }
    function dragTo(mx, my) {
        var c = cellAt(mx, my);
        lastCell = c;
        if (drag.kind === "pan") { V.panX = drag.px + mx - drag.sx; V.panY = drag.py + my - drag.sy; return; }
        if (drag.kind === "draw") {
            if (c[0] === drag.last[0] && c[1] === drag.last[1]) return;
            lineCells(drag.last[0], drag.last[1], c[0], c[1]).forEach(function (p) { stamp(p[0], p[1], drag.tile); });
            drag.last = c; lastStroke = c;
            return;
        }
        if (drag.kind === "shape") { if (c[0] !== drag.b[0] || c[1] !== drag.b[1]) { drag.b = c; drag.preview = previewOf(drag); } return; }
        if (drag.kind === "marquee") {
            var x0 = Math.max(0, Math.min(drag.a[0], c[0])), z0 = Math.max(0, Math.min(drag.a[1], c[1]));
            var x1 = Math.min(P.w - 1, Math.max(drag.a[0], c[0])), z1 = Math.min(P.h - 1, Math.max(drag.a[1], c[1]));
            sel = x1 >= x0 && z1 >= z0 ? { x: x0, z: z0, w: x1 - x0 + 1, h: z1 - z0 + 1 } : null;
            drag.moved = true;
            return;
        }
        if (drag.kind === "move" && floating) { floating.x = c[0] - drag.offX; floating.z = c[1] - drag.offZ; }
    }
    function release(mx, my) {
        var d = drag;
        drag = null;
        if (d.kind === "draw") { commit(); return; }
        if (d.kind === "shape") {
            begin();
            var keep = V.tile;
            if (d.erase) V.tile = ".";
            var b = d.tool === "line" ? snap(d.a, d.b) : d.b;
            shapeCells(d.tool, d.a, b).forEach(function (p) {
                paint(p[0], p[1], p[2]);
            });
            V.tile = keep;
            commit();
            return;
        }
        if (d.kind === "marquee" && !d.moved) {
            sel = null;
            var k = anchorKey(V.floor, d.a[0], d.a[1]);
            selected = k && P.A[k] ? k : k ? ensureAnchor(k) : null;
        }
    }
    function ensureAnchor(k) {
        var c = k.split(","), t = getCell(c[0] | 0, c[1] | 0, c[2] | 0);
        if (!ANCHOR[t]) return null;
        P.A[k] = { type: KINDS[t] ? KINDS[t][0][0] : { S: "spawner", B: "boss", E: "entry", X: "exit" }[t], cfg: null };
        dirty = true;
        return k;
    }
    function pickAt(c) {
        var t = getCell(V.floor, c[0], c[1]);
        if (t === null) return;
        V.tile = t;
        var k = anchorKey(V.floor, c[0], c[1]);
        selected = k ? (P.A[k] ? k : ensureAnchor(k)) : selected;
        say("Picked: " + TILE[t].name);
    }
    function selectPress(c) {
        if (floating && c[0] >= floating.x && c[1] >= floating.z && c[0] < floating.x + floating.w && c[1] < floating.z + floating.h) {
            if (ctrlDown()) { var keepF = clone(floating); dropFloat(); begin(); floating = keepF; floatTexture(); }
            drag = { kind: "move", offX: c[0] - floating.x, offZ: c[1] - floating.z };
            return;
        }
        if (!floating && sel && c[0] >= sel.x && c[1] >= sel.z && c[0] < sel.x + sel.w && c[1] < sel.z + sel.h) {
            begin(); lift(ctrlDown());
            drag = { kind: "move", offX: c[0] - floating.x, offZ: c[1] - floating.z };
            return;
        }
        dropFloat();
        sel = null;
        drag = { kind: "marquee", a: c, moved: false };
    }
    function scroll(mx, my, delta) {
        if (!P || dialog) return;
        if (inCanvas(mx, my)) zoomStep(delta > 0 ? 1 : -1, mx, my);
    }
    function key(name, action) {
        if (!P) return;
        var k = String(name).replace("key.keyboard.", "");
        if (k === "space") { spaceHeld = action === "down"; return false; }
        if (action !== "down") return;
        if (help) { help = false; return false; }
        if (dialog) { if (k === "escape") { dialog = null; hideDropdowns(); return false; } return; }
        var ctrl = ctrlDown(), shift = shiftDown();
        if (ctrl) {
            switch (k) {
                case "z": if (shift) redo(); else undo(); return false;
                case "y": redo(); return false;
                case "s": upload(); return false;
                case "c": copySel(false); return false;
                case "x": copySel(true); return false;
                case "v": pasteClip(); return false;
                case "a": dropFloat(); V.tool = "select"; sel = { x: 0, z: 0, w: P.w, h: P.h }; return false;
            }
            return;
        }
        if (shift) {
            if (k === "h") { transform(0); return false; }
            if (k === "v") { transform(1); return false; }
            if (k === "r") { transform(2); return false; }
            if (k === "u") { setTool("frect"); return false; }
            if (k === "slash") { help = !help; return false; }
        }
        var tools = { b: "pencil", e: "eraser", l: "line", u: "rect", r: "room", c: "corridor", g: "fill", i: "picker", m: "select" };
        if (tools[k]) { setTool(tools[k]); return false; }
        for (var i = 0; i < TILES.length; i++) if (TILES[i].key === k) { V.tile = TILES[i].c; if (V.tool === "eraser" || V.tool === "picker" || V.tool === "select") setTool("pencil"); return false; }
        switch (k) {
            case "escape": if (floating) { floating = null; restore(pending || snapshot()); pending = null; return false; } if (sel) { sel = null; return false; } if (selected) { selected = null; return false; } close(); return false;
            case "enter": dropFloat(); return false;
            case "delete": case "backspace": deleteSel(); return false;
            case "left.bracket": V.brush = Math.max(1, V.brush - 1); return false;
            case "right.bracket": V.brush = Math.min(7, V.brush + 1); return false;
            case "x": V.mirrorX = !V.mirrorX; return false;
            case "y": V.mirrorY = !V.mirrorY; return false;
            case "f": fit(); return false;
            case "tab": V.onion = !V.onion; return false;
            case "page.up": setFloor(V.floor + 1); return false;
            case "page.down": setFloor(V.floor - 1); return false;
            case "equal": case "keypad.add": zoomStep(1, L.cx + L.cw / 2, L.cy + L.ch / 2); return false;
            case "minus": case "keypad.subtract": zoomStep(-1, L.cx + L.cw / 2, L.cy + L.ch / 2); return false;
            case "slash": help = !help; return false;
        }
    }
    /** Opens the painter for a dungeon (the server checks staff rights and sends the map). */
    function open(id) { RPG.net.send("dmk_paint", { op: "open", id: id }); }
    return { open: open, reopen: reopen, state: function () { return P; } };
})();
