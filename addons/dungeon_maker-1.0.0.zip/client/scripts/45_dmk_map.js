// =====================================================================================
//  Dungeon Maker (client) - the Dungeon Map (a run item): the dungeon's layout from its painted map
// =====================================================================================
//  The painted map (one pixel per block column, RPG.images.canvas) of the floor you are on: places the
//  party has walked over are bright, the rest dim. Rooms made with the Room Wand are outlined (lit once
//  entered); a dungeon without a painted map shows just its rooms. Entry and exit are marked, and with the
//  Dungeon Compass the boss and the chests too. Where everyone is updates once a second while it is open.
// =====================================================================================
(function () {
    var U = DMK_UI;
    var M = null, POS = null, cv = null, cvKey = "", lastAsk = 0;
    var ROOM_COL = { combat: "#FF5050", puzzle: "#B070FF", trap: "#FF9930", treasure: "#FFD040", boss: "#D02828", safe: "#50E070" };
    var COL = { f: 0xFFB8B0A0, w: 0xFF4A4650, d: 0xFFE8D8A0, L: 0xFFD8A838, C: 0xFFC88A30, S: 0xFFB8B0A0, B: 0xFFB8B0A0, E: 0xFF58D058, X: 0xFF40B8F0,
        U: 0xFFF0F0F0, D: 0xFFC8C8D0, P: 0xFF3A3640, T: 0xFFFFE070, "~": 0xFF3F76E4, "^": 0xFFE86010, o: 0xFF0A0A0E, "*": 0xFFA8A090 };
    function dim(c) { return 0xFF000000 + (Math.round(((c >> 16) & 255) * 0.35) << 16) + (Math.round(((c >> 8) & 255) * 0.35) << 8) + Math.round((c & 255) * 0.35); }

    U.onBig("runmap", function (m) { M = m; cvKey = ""; open(); });
    RPG.net.on("dmk_mappos", function (p) { POS = p; cvKey = ""; if (!p) { var S = U.state(); if (S && S.view === "runmap") U.close(); } });

    function floorOf(map, y) {
        var f = 0;
        map.floors.forEach(function (fl, i) { if (y >= fl.y) f = i; });
        return f;
    }
    function paint(S) {
        var map = M.map, fl = map.floors[S.floor], seen = {};
        (POS ? POS.seen : []).forEach(function (k) { seen[k] = 1; });
        var key = S.floor + "|" + (POS ? POS.seen.length : 0);
        if (cv && cvKey === key) return;
        cvKey = key;
        if (!cv || cv.width !== map.w || cv.height !== map.h) { if (cv) cv.release(); cv = RPG.images.canvas("dmk_runmap", map.w, map.h); }
        var px = new Array(map.w * map.h), n = M.seenSize || 4;
        for (var i = 0; i < px.length; i++) {
            var c = COL[fl.cells.charAt(i)];
            if (!c) { px[i] = 0; continue; }
            var x = i % map.w, z = Math.floor(i / map.w);
            px[i] = seen[Math.floor(x / n) + "," + Math.floor(z / n)] ? c : dim(c);
        }
        cv.setPixels(0, 0, map.w, map.h, px);
    }
    function open() {
        var S = U.state();
        if (S && S.view === "runmap") return;
        S = { view: "runmap", floor: -1 };
        S.draw = function (ctx) {
            if (!M) return;
            if (RPG.nowMs() - lastAsk > 1000) { lastAsk = RPG.nowMs(); RPG.net.send("dmk_run", { op: "mappos" }); }
            var W = Math.min(ctx.width - 20, 360), H = Math.min(ctx.height - 20, 280), x = Math.floor((ctx.width - W) / 2), y = Math.floor((ctx.height - H) / 2);
            U.panel(ctx, x, y, W, H, M.name + " - Map");
            var me = POS && POS.me, map = M.map;
            // what the map covers (block columns from the plot centre)
            var ext;
            if (map) ext = { x1: map.ox, z1: map.oz, x2: map.ox + map.w - 1, z2: map.oz + map.h - 1 };
            else {
                ext = M.bounds ? { x1: M.bounds.x1, z1: M.bounds.z1, x2: M.bounds.x2, z2: M.bounds.z2 } : null;
                M.rooms.forEach(function (r) { var b = r.box; ext = ext ? { x1: Math.min(ext.x1, b.x1), z1: Math.min(ext.z1, b.z1), x2: Math.max(ext.x2, b.x2), z2: Math.max(ext.z2, b.z2) } : { x1: b.x1, z1: b.z1, x2: b.x2, z2: b.z2 }; });
            }
            if (!ext) { U.text(ctx, "This dungeon has no map", x + W / 2, y + H / 2, "#B0B0B0", "center"); U.button(ctx, "Close", x + W / 2 - 40, y + H - 28, 80, 18, function () { U.close(); }); return; }
            if (map && S.floor < 0) S.floor = me ? floorOf(map, Math.floor(me[1]) - 1) : 0;
            var aw = W - 28, ah = H - 64, ew = ext.x2 - ext.x1 + 1, eh = ext.z2 - ext.z1 + 1, z = Math.max(1, Math.floor(Math.min(aw / ew, ah / eh) * 4) / 4);
            var mx = x + 14 + Math.floor((aw - ew * z) / 2), my = y + 18 + Math.floor((ah - eh * z) / 2);
            U.inset(ctx, x + 10, y + 14, W - 20, ah + 8);
            var X = function (bx) { return mx + (bx - ext.x1) * z; }, Z = function (bz) { return my + (bz - ext.z1) * z; };
            if (map) { paint(S); ctx.quad(cv.texture, mx, my, ew * z, eh * z, 0, 0, 1, 1, "#FFFFFF", 1); }
            var fl = map ? map.floors[S.floor] : null;
            M.rooms.forEach(function (r) {
                var b = r.box;
                if (fl && (b.y2 < fl.y || b.y1 > fl.y + fl.height + 1)) return;
                var c = ROOM_COL[r.type] || "#FFFFFF", rx = X(b.x1), ry = Z(b.z1), rw = (b.x2 - b.x1 + 1) * z, rh = (b.z2 - b.z1 + 1) * z;
                if (!map) ctx.fill(rx, ry, rw, rh, r.seen ? c : "#404048", r.seen ? 0.35 : 0.5);
                ctx.lines([rx, ry, rx + rw, ry, rx + rw, ry + rh, rx, ry + rh], 1, r.seen ? c : "#707078", 0.9, true);
                if (r.seen && rw > 30) U.text(ctx, U.fit(ctx, r.name, rw - 4), rx + 2, ry + 2, c, "left", 0.6);
            });
            var onFloor = function (yy) { return !fl || (yy >= fl.y && yy <= fl.y + fl.height + 1); };
            M.markers.forEach(function (k) {
                if (!onFloor(k.y)) return;
                var ic = k.type === "entry" ? "entry" : k.type === "exit" ? "exit" : k.type === "boss" ? "skull" : "chest", s = Math.max(8, Math.min(12, z * 3));
                U.icon(ctx, ic, X(k.x) + z / 2 - s / 2, Z(k.z) + z / 2 - s / 2, s, k.open ? 0.45 : 1);
            });
            (POS && POS.party || []).forEach(function (q) { if (onFloor(Math.floor(q[1]) - 1)) { ctx.fill(X(q[0]) - 2, Z(q[2]) - 2, 4, 4, "#60C0FF", 1); } });
            if (me && onFloor(Math.floor(me[1]) - 1)) {
                var cx = X(me[0]), cz = Z(me[2]), a = me[3] * Math.PI / 180, fx = -Math.sin(a), fz = Math.cos(a);
                ctx.line(cx, cz, cx + fx * 7, cz + fz * 7, 2, "#FFFFFF", 1);
                ctx.fill(cx - 2.5, cz - 2.5, 5, 5, Math.floor(RPG.nowMs() / 400) % 2 ? "#FF4040" : "#FFFFFF", 1);
            }
            var by = y + H - 28;
            if (map && map.floors.length > 1) {
                U.iconButton(ctx, "down", x + 14, by + 3, 12, function () { S.floor = Math.max(0, S.floor - 1); }, "Floor below", S.floor <= 0);
                U.text(ctx, fl.name, x + 34, by + 5, "#FFE9A8", "left", 0.85);
                U.iconButton(ctx, "up", x + 120, by + 3, 12, function () { S.floor = Math.min(map.floors.length - 1, S.floor + 1); }, "Floor above", S.floor >= map.floors.length - 1);
            }
            U.text(ctx, M.compass ? "Compass: boss and chests shown" : "Bright: where you have been", x + W - 104, by + 5, "#A8A8A8", "right", 0.7);
            U.button(ctx, "Close", x + W - 96, by, 80, 18, function () { U.close(); });
        };
        S.back = function () { U.close(); };
        S.onClose = function () { POS = null; };
        U.open(S);
    }
})();
