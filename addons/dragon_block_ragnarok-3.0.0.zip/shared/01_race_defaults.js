// =====================================================================================
//  Default colours and looks per race (DragonMine Z's setupXCharacter defaults), used by
//  the race scripts on the server and the character creator on the client.
// =====================================================================================
var DBR_RACE_DEFAULTS = {
    human:       { body1: "#FFD3C9", body2: "#FFD3C9", body3: "#FFD3C9", hair: "#222629", eyes: "#222629", eye2: "#222629", aura: "#7FFFFF",
                   bodyType: "male_1", bodyModel: "human", eyeStyle: "0", nose: "0", mouth: "0", hairStyle: "base", tattoo: "none" },
    saiyan:      { body1: "#FFD3C9", body2: "#572117", body3: "#FFD3C9", hair: "#222629", eyes: "#222629", eye2: "#222629", aura: "#7FFFFF",
                   bodyType: "male_1", bodyModel: "human", eyeStyle: "0", nose: "0", mouth: "0", hairStyle: "base", tattoo: "none" },
    namekian:    { body1: "#1FAA24", body2: "#BB2024", body3: "#FF86A6", hair: "#80FF69", eyes: "#222629", eye2: "#222629", aura: "#7FFF00",
                   bodyType: "0", eyeStyle: "0", nose: "0", mouth: "0", tattoo: "none" },
    frost_demon: { body1: "#FFFFFF", body2: "#E8A2FF", body3: "#FF39A9", hair: "#8B1BCC", eyes: "#FF001D", eye2: "#FF001D", aura: "#5F00FF",
                   bodyType: "0", eyeStyle: "0", nose: "0", mouth: "0", tattoo: "none" },
    bio_android: { body1: "#396E14", body2: "#C7B022", body3: "#FA9A02", hair: "#38628F", eyes: "#2E2424", eye2: "#F06F6E", aura: "#1AA700",
                   bodyType: "0", tattoo: "none" },
    majin:       { body1: "#FFA4FF", body2: "#FFA4FF", body3: "#FFA4FF", hair: "#FFA4FF", eyes: "#B40000", eye2: "#B40000", aura: "#FF6DFF",
                   bodyType: "male_0", bodyModel: "majin", eyeStyle: "0", nose: "0", mouth: "0", tattoo: "none" },
    glind:       { body1: "#D2A3DA", body2: "#D2A3DA", body3: "#D2A3DA", hair: "#EDEDED", eyes: "#222629", eye2: "#222629", aura: "#E3C4FF",
                   bodyType: "male_1", bodyModel: "human", eyeStyle: "0", nose: "0", mouth: "0", hairStyle: "base", tattoo: "none" }
};
