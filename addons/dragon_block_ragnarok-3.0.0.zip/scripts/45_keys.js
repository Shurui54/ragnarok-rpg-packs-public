// =====================================================================================
//  45_keys.js - DMZ controls: charge ki, fly, dash, lock on
// =====================================================================================
//  Every player has 20 action keys (Options > Controls > "Ragnarok RPG"). Keys 1-8 cast
//  the skill bar unless you define them. The defaults follow DMZ:
//      1-4 Alt+1..4   5-8 Ctrl+1..4   9 C   10 V   11 R   12 G   13 Z   14 H   15-20 unbound
//
//  RPG.keys.define(n, {
//      name: "Charge Ki",                     shown in Controls and on the HUD
//      onPress(player)                        key went down
//      onHold(player, ticksHeld)              every holdInterval ticks while held
//      holdInterval: 5,
//      onRelease(player, ticksHeld)           key came up
//  })
//  Events keyPress(player, key) / keyRelease(player, key, ticks) fire for every key too.
//
//  A shooter would make key 9 "Reload" and key 11 "Sprint"; Zelda would make key 9
//  "Shield" and key 13 "Z-target". Nothing below is special to the engine.
// =====================================================================================

// ---- C: Charge Ki (hold) ---------------------------------------------------------------
// While held: the charge pose, your aura (in your own "aura" colour) and fast ki refill.
RPG.effects.define("ki_charge", {
    name: "&bCharging",
    color: "#7FFFFF",
    hidden: true,                                   // not listed on the HUD
    // color "aura" = the player's own aura colour (/rpgc color aura #FF0000)
    aura: { texture: AURA_KAKAROT, frames: 4, speed: 10, color: "aura", scale: 1.0, alpha: 0.75 },
    attributes: { "minecraft:generic.movement_speed": { amount: -0.6, operation: "multiply_total" } }
});

defineKey(9, {
    name: "Charge Ki",
    defaultKey: "c",
    holdInterval: 2,
    onPress(player) {
        player.addEffect("ki_charge", -1);
        player.setVar("dmz_charge_ticks", 0);
        player.playAnimationFor(chargeAnimation(player), 0);      // loop until release
        sfx(player, "aura_start", 1, 1);
    },
    // DMZ (TickHandler.chargePowerRelease): every 2 ticks the power release climbs, faster the
    // longer you hold, up to your cap; ki refills at 1.5x your normal rate while charging.
    onHold(player, ticks) {
        let v = dmzView(player), charge = (Number(player.getVar("dmz_charge_ticks", 0)) || 0) + 2;
        player.setVar("dmz_charge_ticks", charge);
        let max = DMZ_F.maxRelease(Number(player.getVar("dmz_potential", 0)), player.race === "saiyan" ? 1 + Math.min(0.15, Number(player.getVar("dmz_zenkai_release", 0)) || 0) : 1);
        let rel = Number(player.getVar("dmz_release", 0)) || 0;
        let step = DMZ_F.releaseStep(charge, Number(player.getVar("dmz_potential", 0)));
        rel = player.getVar("dmz_lowering", 0) ? Math.max(0, rel - step) : Math.min(max, rel + step);
        if (rel !== Number(player.getVar("dmz_release", 0))) player.setVar("dmz_release", rel);
        if (ticks % 20 === 0) {
            player.addResource("ki", Math.ceil(DMZ_F.kiRegen(v, true) * DMZ_F.foodMult(player.food) * 100) / 100);
            if (ticks % 40 === 0) sfx(player, "ki_charge_loop", 0.7, 1);
        }
        if (ticks % 10 === 0) burst(player, "minecraft:electric_spark", 4, 0.5, 0.05);
    },
    onRelease(player, ticks) {
        player.removeEffect("ki_charge");
        player.setVar("dmz_lowering", 0);
        resumeHeld(player);
    }
});

// ---- F: Fly (toggle) -------------------------------------------------------------------
// Real flight (player.setFlying): Space rises, Shift descends, sprint for full speed, like DMZ.
// G / H also nudge you down / up. Flying costs stamina, then ki; you land when both run out.
RPG.effects.define("flight", {
    name: "&fFlying",
    color: "#E0F0FF",
    tickInterval: 5,
    onApply(player, stacks) {
        player.setFlying(true);
        player.setFlySpeed(0.06);
        sfx(player, "aura_start", 0.6, 1.3);
    },
    onTick(player, stacks) {
        if (!player.isFlying()) player.setFlying(true);       // stay airborne (double-tapping Space can't drop you)
        player.setFlySpeed(player.getVar("fly_fast", 0) ? 0.14 : 0.06);
        // drain: stamina first, then ki; land when both run out
        if (RPG.server.getTick() % 20 < 5 && !player.consume("stamina", 2) && !player.consume("ki", 2)) {
            player.removeEffect("flight");
            player.actionbar("&cToo tired to fly!");
        }
    },
    onRemove(player, stacks) {
        player.setFlying(false);
        player.setFlySpeed(0.05);
        player.addPotion("minecraft:slow_falling", 80, 0);       // float down gently
        player.setVar("fly_mode", "hover");
        player.setVar("fly_fast", 0);
        resumeHeld(player);
    }
});

defineKey(16, {
    name: "Fly",
    defaultKey: "f",
    onPress(player) {
        if (player.hasEffect("flight")) {
            player.removeEffect("flight");
            player.actionbar("&7You land.");
            return;
        }
        if (player.getLevel() < 3) { player.actionbar("&7Reach level 3 to learn to fly (Bukujutsu)."); return; }
        player.push(0, 0.6, 0);                                  // take off
        player.addEffect("flight", -1);
        player.progressQuest("fly", 1);
        player.actionbar("&fFlying &7- Space up, Shift down, sprint or R for speed, V to land");
    }
});

// ---- R: Dash ---------------------------------------------------------------------------
// On the ground: a dash in the direction you look. Flying: a burst of full-speed flight.
// Locked on (Z): dash straight at your target.
function dashPress(player) {
    if (!player.consume("stamina", 10)) { player.actionbar("&cNo stamina!"); return; }
    let target = lockedTarget(player);
    if (target) pushToward(player, target, 2.2);
    else player.dash(player.hasEffect("flight") ? 2.4 : 1.6);
    if (player.hasEffect("flight")) {
        player.setVar("fly_fast", 1);
        act(player, "base.fly_fast", 20);
        RPG.schedule(20, () => player.setVar("fly_fast", 0));
    } else {
        act(player, "base.dash_front", 10);
    }
    sfx(player, "evasion1", 0.8, 1.1);
    burst(player, "minecraft:cloud", 10, 0.3, 0.05);
}

defineKey(11, {
    name: "Dash",
    onPress(player) { dashPress(player); }
});

// ---- G: Descend (flying) / Meditate (on the ground) -----------------------------------
RPG.effects.define("meditating", {
    name: "&3Meditating",
    color: "#5FA8D3",
    hidden: true,
    attributes: { "minecraft:generic.movement_speed": { amount: -0.9, operation: "multiply_total" } }
});

defineKey(12, {
    name: "Descend / Meditate",
    holdInterval: 20,
    onPress(player) {
        if (player.hasEffect("flight")) { player.push(0, -0.6, 0); return; }
        player.addEffect("meditating", -1);
        player.playAnimationFor("base.meditation", 0);
    },
    onHold(player, ticks) {
        if (!player.hasEffect("meditating") || ticks === 0) return;
        player.addResource("ki", player.maxResource("ki") * 0.02);
        player.addResource("stamina", player.maxResource("stamina") * 0.05);
        if (ticks % 100 === 0) { player.addTp(2 + Math.floor(player.getLevel() / 10)); player.progressQuest("meditate", 1); }
        burst(player, "minecraft:enchant", 6, 0.6, 0.3);
    },
    onRelease(player, ticks) {
        if (player.hasEffect("flight")) { player.setVar("fly_mode", "hover"); return; }
        player.removeEffect("meditating");
        resumeHeld(player);
    }
});

// ---- Z: Lock on ------------------------------------------------------------------------
// Press while looking at something: remember it (techniques aim at it, R dashes to it).
// Press again to release. The HUD shows the target's power level (10_stats.js).
defineKey(13, {
    name: "Lock On",
    onPress(player) {
        if (player.getVar("lock_uuid", "")) {
            player.setVar("lock_uuid", null);
            player.clearHudText("lock");
            player.actionbar("&7Lock released.");
            return;
        }
        let t = player.target(40);
        if (!t) { player.actionbar("&7Nothing to lock on to."); return; }
        player.setVar("lock_uuid", t.uuid);
        sfx(player, "lockon", 0.8, 1);
        showLock(player, t);
    }
});

function showLock(player, t) {
    player.hudText("lock", "&c◎ &f" + t.name + " &7PL &e" + grouped(powerLevel(t)), 0, 40, "top", 0xFFFFFF);
}

// Refresh the lock-on readout once a second, and drop it when the target is gone.
RPG.on("playerTick", (player) => {
    if (!player.getVar("lock_uuid", "")) return;
    let t = lockedTarget(player);
    if (!t || !t.isAlive()) {
        player.setVar("lock_uuid", null);
        player.clearHudText("lock");
        return;
    }
    showLock(player, t);
});

// ---- H: Ascend (flying) / Super Jump ---------------------------------------------------
defineKey(14, {
    name: "Ascend / Super Jump",
    onPress(player) {
        if (player.hasEffect("flight")) { player.push(0, 0.6, 0); return; }
        if (!player.consume("stamina", 8)) return;
        player.push(0, 1.1, 0);
        act(player, "base.jump", 15);
        sfx(player, "evasion2", 0.7, 1);
    },
    onRelease(player, ticks) {
        if (player.hasEffect("flight")) player.setVar("fly_mode", "hover");
    }
});

// ---- Alt+C: Lower power release (hold) ------------------------------------------------------
defineKey(15, {
    name: "Lower Release",
    defaultKey: "c", modifier: "alt", holdInterval: 2,
    onPress(player) { player.setVar("dmz_lowering", 1); DBR_KEYS[9].onPress(player); },
    onHold(player, ticks) { DBR_KEYS[9].onHold(player, ticks); },
    onRelease(player, ticks) { DBR_KEYS[9].onRelease(player, ticks); }
});

// ---- V: Stats menu (DMZ's CharacterStatsScreen; the creator if you have no character yet) ----
defineKey(10, {
    name: "Stats Menu",
    defaultKey: "v",
    onPress(player) {
        RPG.net.send(player, player.getVar("dmz_created", 0) ? "dmz_open_stats" : "dmz_open_creator", {});
        player.playSound("dmzpack:ui_menu_switch", 1, 1);
    }
});
