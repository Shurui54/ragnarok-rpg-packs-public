// =====================================================================================
//  DMZ quest rules shared by the server (scripts/47_dmz_quests.js) and the quest screen:
//  quest keys, unlock prerequisites, saga order, node status, objective counts, rewards
//  (QuestAvailabilityChecker, PlayerQuestData, QuestTreeScreen.computeNodeStatus).
//
//  A "view" of a player's quest state:
//    { q: { key: { s: 1 accepted | 2 completed | 3 failed, p: [progress], c: [claimed reward
//      indices], d: difficulty } }, d: chosen difficulty, resets: story resets }
//  plus skill(id) -> DMZ skill level, level -> character level, alignment.
// =====================================================================================
var DMZ_QL = (function () {
    var D = DMZ_QUEST_DATA;
    var BY_KEY = {}, SAGAS = {}, SAGA_LIST = D.sagas, SIDE = D.side;
    var ACCEPTED = 1, COMPLETED = 2, FAILED = 3;

    D.sagas.forEach(function (s) {
        SAGAS[s.id] = s;
        s.quests.forEach(function (q, i) { var k = s.id + ":" + q.id; BY_KEY[k] = { key: k, quest: q, saga: s, index: i, side: false }; });
    });
    D.side.forEach(function (q) { BY_KEY[q.id] = { key: q.id, quest: q, saga: null, index: -1, side: true }; });

    // Difficulty.java: enemy hp / damage, story TP, quest rewards
    var DIFFICULTY = {
        EASY: { hp: 0.75, dmg: 0.5, tp: 1.25, reward: 1.0, tier: 1 },
        NORMAL: { hp: 1.0, dmg: 1.0, tp: 1.0, reward: 1.0, tier: 2 },
        HARD: { hp: 2.0, dmg: 1.5, tp: 1.25, reward: 1.25, tier: 3 }
    };

    function entry(key) { return BY_KEY[key] || null; }
    function rec(view, key) { return (view && view.q && view.q[key]) || null; }
    function status(view, key) { var r = rec(view, key); return r ? r.s : 0; }
    function completed(view, key) { return status(view, key) === COMPLETED; }
    function progress(view, key, i) { var r = rec(view, key); return r && r.p && typeof r.p[i] === "number" ? r.p[i] : 0; }
    function claimed(view, key, i) { var r = rec(view, key); return !!(r && r.c && r.c.indexOf(i) >= 0); }
    function questDifficulty(view, key) { var r = rec(view, key); return (r && r.d) || (view && view.d) || "NORMAL"; }

    /** QuestObjective.getRequired (solo party). */
    function required(o) {
        switch (o.type) {
            case "KILL": case "ITEM": case "DELIVER": return Math.max(1, o.count || 1);
            case "SKILL": return Math.max(1, o.level || 1);
            case "SURVIVE_WAVES": return Math.max(1, o.waves || 1);
            default: return 1;
        }
    }

    function isPositional(type) { return type === "BIOME" || type === "DIMENSION" || type === "STRUCTURE" || type === "TIME"; }

    /** One condition. positional(cond) answers BIOME/DIMENSION/STRUCTURE/TIME (null = unknown -> passes). */
    function evalCond(c, view, positional) {
        if (!c) return false;
        if (c.conditions) return evalGroup(c, view, positional);
        switch (c.type) {
            case "SAGA_QUEST": return completed(view, c.sagaId + ":" + c.questId);
            case "QUEST": return completed(view, c.questId);
            case "LEVEL": return (view.level || 1) >= (c.minLevel || 0);
            case "SKILL": return view.skill(c.skill) >= (c.minLevel || 0);
            case "ALIGNMENT":
                var a = typeof view.alignment === "number" ? view.alignment : 100;
                return (c.min === undefined || a >= c.min) && (c.max === undefined || a <= c.max);
            case "RACE": return String(c.race || "").toLowerCase() === String(view.race || "");
            case "CLASS": return String(c["class"] || "").toLowerCase() === String(view.cls || "");
            default:
                if (isPositional(c.type)) { var r = positional ? positional(c) : null; return r === null || r === undefined ? true : !!r; }
                return false;
        }
    }
    function evalGroup(g, view, positional) {
        if (!g || !g.conditions || !g.conditions.length) return true;
        if (g.operator === "OR") { for (var i = 0; i < g.conditions.length; i++) if (evalCond(g.conditions[i], view, positional)) return true; return false; }
        for (var j = 0; j < g.conditions.length; j++) if (!evalCond(g.conditions[j], view, positional)) return false;
        return true;
    }
    /** First failing condition of a group (for blocker text). */
    function firstFailing(g, view, positional) {
        if (!g || !g.conditions) return null;
        var first = null;
        for (var i = 0; i < g.conditions.length; i++) {
            var c = g.conditions[i];
            var f = c.conditions ? firstFailing(c, view, positional) : (evalCond(c, view, positional) ? null : c);
            if (g.operator !== "OR") { if (f) return f; }
            else { if (!f) return null; if (!first) first = f; }
        }
        return first;
    }

    function isAvailable(q, view) { return !q.prerequisites || evalGroup(q.prerequisites, view, null); }
    function isSagaQuestAvailable(e, view) {
        if (e.index > 0) {
            var prev = e.saga.quests[e.index - 1];
            if (!completed(view, e.saga.id + ":" + prev.id)) return false;
        }
        return isAvailable(e.quest, view);
    }
    function startable(e, view) {
        var s = status(view, e.key);
        if (s === ACCEPTED) return false;
        if (s === COMPLETED && !(e.quest.repeatable && repeatReady(view, e))) return false;
        return e.side ? isAvailable(e.quest, view) : isSagaQuestAvailable(e, view);
    }
    function repeatReady(view, e) {
        var r = rec(view, e.key);
        if (!r || !r.at) return false;
        return Date.now() - r.at >= (e.quest.repeat_cooldown_seconds || 0) * 1000 && !hasUnclaimed(view, e);
    }

    function rewardUnlocked(r, diff) { return !r.difficulty || !r.difficulty.length || r.difficulty.indexOf(diff || "NORMAL") >= 0; }
    function hasUnclaimed(view, e) {
        var diff = questDifficulty(view, e.key), rw = e.quest.rewards || [];
        for (var i = 0; i < rw.length; i++) if (rewardUnlocked(rw[i], diff) && !claimed(view, e.key, i)) return true;
        return false;
    }

    /** QuestTreeScreen.computeNodeStatus: "COMPLETED" | "CLAIMABLE" | "ACTIVE" | "AVAILABLE" | "LOCKED" */
    function nodeStatus(e, view) {
        var s = status(view, e.key);
        if (s === COMPLETED) return hasUnclaimed(view, e) ? "CLAIMABLE" : "COMPLETED";
        if (s === ACCEPTED) return "ACTIVE";
        if (s === FAILED) return "AVAILABLE";
        if (!e.side) return isSagaQuestAvailable(e, view) ? "AVAILABLE" : "LOCKED";
        return isAvailable(e.quest, view) ? "AVAILABLE" : "LOCKED";
    }

    /** QuestTreeScreen.isSagaUnlockedByPreviousCompletion */
    function sagaUnlocked(saga, view) {
        if (!saga.prev) return true;
        var prev = SAGAS[saga.prev];
        if (!prev) return true;
        for (var i = 0; i < saga.quests.length; i++) if (status(view, saga.id + ":" + saga.quests[i].id)) return true;
        for (var j = 0; j < prev.quests.length; j++) if (!completed(view, prev.id + ":" + prev.quests[j].id)) return false;
        return true;
    }

    /** QuestTreeLayoutHelper.belongsToSaga */
    function belongsToSaga(q, sagaId) {
        var queue = [q], visited = {};
        while (queue.length) {
            var cur = queue.shift();
            var conds = cur.prerequisites && cur.prerequisites.conditions;
            if (!conds) continue;
            for (var i = 0; i < conds.length; i++) {
                var c = conds[i];
                if (c.type === "SAGA_QUEST" && c.sagaId === sagaId) return true;
                if (c.type === "QUEST" && c.questId && !visited[c.questId]) {
                    visited[c.questId] = 1;
                    var parent = BY_KEY[c.questId];
                    if (parent && parent.side) queue.push(parent.quest);
                }
            }
        }
        return false;
    }

    /** QuestService.isTurnInTalk */
    function isTurnInTalk(q, o) { return o.type === "TALK_TO" && !!q.turn_in && String(o.npcId || "").toLowerCase() === String(q.turn_in).toLowerCase(); }
    function hasKill(q) { return q.objectives.some(function (o) { return o.type === "KILL" || o.type === "SPAR"; }); }

    /** PlayerQuestData.rewardMultiplierFor */
    function rewardMultiplier(view, key, r) {
        var m = (DIFFICULTY[questDifficulty(view, key)] || DIFFICULTY.NORMAL).reward;
        var scaled = r.type === "TPS" || r.type === "ATTRIBUTES" || r.type === "ATTRIBUTE_POINTS" || r.type === "ITEM" || r.type === "GENERIC_ITEM";
        return scaled ? m * Math.pow(0.5, (view && view.resets) || 0) : m;
    }

    return { DATA: D, BY_KEY: BY_KEY, SAGAS: SAGAS, SAGA_LIST: SAGA_LIST, SIDE: SIDE, DIFFICULTY: DIFFICULTY, ACCEPTED: ACCEPTED, COMPLETED: COMPLETED, FAILED: FAILED,
        entry: entry, rec: rec, status: status, completed: completed, progress: progress, claimed: claimed, questDifficulty: questDifficulty,
        required: required, isPositional: isPositional, evalCond: evalCond, evalGroup: evalGroup, firstFailing: firstFailing, isAvailable: isAvailable,
        isSagaQuestAvailable: isSagaQuestAvailable, startable: startable, rewardUnlocked: rewardUnlocked, hasUnclaimed: hasUnclaimed,
        nodeStatus: nodeStatus, sagaUnlocked: sagaUnlocked, belongsToSaga: belongsToSaga, isTurnInTalk: isTurnInTalk, hasKill: hasKill,
        rewardMultiplier: rewardMultiplier };
})();
