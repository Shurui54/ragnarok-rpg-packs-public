// =====================================================================================
//  40_skills.js - techniques: ki attacks, strikes, evasions
// =====================================================================================
//  The DragonMine Z techniques are in 41_dmz_techniques.js (masters, Bind to Slot, Alt/Ctrl+1..4).
//  The skills here are this addon's extras; any of them can be bound to a DMZ technique slot
//  too (V > Skills), and the ones DMZ replaced can no longer be learned (dmzReplaced below).
//
//  Skill fields:
//    cost: { ki: 10 }            resources spent per cast (an amount can be a function)
//    cooldown: 40                ticks (20 = 1 second); can be a function (player, level)
//    maxLevel: 10                levels from skill points or from using it (mastery)
//    requires: { level, race, class, skills: { ki_blast: 3 } }
//    hidden: true                not shown in the menu until learned (master techniques)
//    passive: true               never cast; its effect lives in a hook (90_hooks.js)
//    onCast(ctx)                 ctx.player, ctx.level, ctx.target, ctx.skill
//                                return false = nothing happened (no cost, no cooldown)
//
//  Most techniques here come from three small "recipes" so each one is a few lines:
//    kiTechnique      charge animation -> fire animation + a projectile (35_projectiles.js)
//    strikeTechnique  rush the target, a DMZ "skp" striking animation, several hits
//    and a handful written out in full (evasions, healing, fusion...).
//  The animation names (ki.kameha_cast, skp.dragon_fist, evs.taiyoken...) come from
//  the DMZ avatar files: resources/dmzpack_catalog.json lists them all.
// =====================================================================================

// ---- DMZ techniques replace the matching skills here -------------------------------------
// DragonMine Z's techniques (Kamehameha, Kienzan, Solar Flare...) now live in 41_dmz_techniques.js:
// bought from masters, bound with "Bind to Slot" and fired from DMZ's 8 slots. Their old versions
// below stay defined (other scripts and old saves may name them) but can't be learned with skill
// points or shown in the menu any more. The other skills here (Zanzoken is DMZ's afterimage, so it
// goes too) still work and can sit in a technique slot.
function dmzReplaced(id) {
    if (typeof DMZ_SKILLS_DATA === "undefined" || typeof DMZ_TECH_DATA === "undefined") return false;
    var map = DMZ_SKILLS_DATA.TECHNIQUES;
    return Object.keys(map).some((k) => map[k] === id && DMZ_TECH_DATA.exists(k));
}

// ---- Recipe 1: ki techniques -------------------------------------------------------------
// spec: name, description, icon, race, level, requires {skill: level}, hidden, maxLevel,
//       skillPointCost, cost (ki), cooldown, projectile, cast/fire (animation names),
//       charge (ticks before a ball/volley flies; beams use their projectile's charge),
//       chargeSound / fireSound, damage: [base, per Ki Power, per skill level],
//       shots / shotDelay (volleys), size: grows per level, canCast(player).
function kiTechnique(id, spec) {
    let requires = { level: spec.level || 1 };
    if (spec.race) requires.race = spec.race;
    if (spec.requires) requires.skills = spec.requires;
    RPG.skills.define(id, {
        name: spec.name,
        description: spec.description,
        noLearn: dmzReplaced(id),
        icon: "dbr:textures/skill/" + id + ".png",   // generated art (resources/assets/dbr)
        kind: "ki", projectile: spec.projectile,
        requires: requires,
        hidden: !!spec.hidden || dmzReplaced(id),
        maxLevel: spec.maxLevel || 10,
        skillPointCost: spec.skillPointCost || 1,
        cost: { ki: (player, level) => kiCost(player, spec.cost) },
        cooldown: spec.cooldown || 60,
        masteryXp: 12,
        canCast(player, level) { return spec.canCast ? spec.canCast(player) : true; },
        onCast(ctx) { fireKi(ctx.player, ctx.level, spec); }
    });
}

function fireKi(p, level, spec) {
    let proj = PROJECTILES[spec.projectile];
    let beam = proj.shape === "beam" || proj.shape === "laser";
    let charge = beam ? (proj.charge || 0) : (spec.charge || 0);
    let dmg = kiDamage(p, spec.damage[0], spec.damage[1], level, spec.damage[2]);
    let size = proj.size * (1 + (level - 1) * (spec.size || 0.03));      // mastery makes it bigger
    let over = { damage: dmg, size: size };
    // ki_blast-type shots take the caster's own aura colour
    if (spec.auraColor && p.getColor("aura")) over.colors = { border: p.getColor("aura") };

    if (spec.cast && charge > 0) act(p, spec.cast, charge);
    if (spec.chargeSound) sfx(p, spec.chargeSound, 1, 1);

    if (beam) {
        // The beam entity shows its own charging orb in the hands, then fires by itself.
        p.shoot(spec.projectile, over);
        RPG.schedule(Math.max(1, charge), () => {
            if (spec.fire) act(p, spec.fire, (proj.duration || 20));
            if (spec.fireSound) sfx(p, spec.fireSound, 1.2, 1);
        });
        return;
    }
    let shots = spec.shots || 1;
    times(shots, (i) => {
        RPG.schedule(Math.max(1, charge + i * (spec.shotDelay || 3)), () => {
            if (!p.isAlive()) return;
            if (spec.fire) act(p, spec.fire, 10);
            if (spec.fireSound) sfx(p, spec.fireSound, 0.9, 0.9 + Math.random() * 0.3);
            p.shoot(spec.projectile, over);
        });
    });
}

// ---- Recipe 2: striking techniques -------------------------------------------------------
// spec: name, description, icon, race, level, requires, hidden, cost, cooldown, animation,
//       ticks (animation length), range (rush distance), hits, damage: [base, per Strike, per level],
//       sound, finalSound, knockback, needsEffect (e.g. "kaioken"), needsItem.
var PUNCH_SOUNDS = ["punch1", "punch2", "punch3", "punch4", "punch5", "punch6"];

function strikeTechnique(id, spec) {
    let requires = { level: spec.level || 1 };
    if (spec.race) requires.race = spec.race;
    if (spec.requires) requires.skills = spec.requires;
    RPG.skills.define(id, {
        name: spec.name,
        description: spec.description,
        noLearn: dmzReplaced(id),
        icon: "dbr:textures/skill/" + id + ".png",
        kind: "strike",
        requires: requires,
        hidden: !!spec.hidden || dmzReplaced(id),
        maxLevel: spec.maxLevel || 10,
        skillPointCost: spec.skillPointCost || 1,
        cost: { stamina: spec.stamina || 10, ki: (player, level) => kiCost(player, spec.cost || 0) },
        cooldown: spec.cooldown || 80,
        masteryXp: 12,
        range: spec.range || 10,
        canCast(player, level) {
            if (spec.needsEffect && !spec.needsEffect.some((e) => player.hasEffect(e))) return spec.needsMessage || "You can't do that in this form.";
            if (spec.needsItem && !holding(player, spec.needsItem)) return "Hold the " + (spec.needsItemName || spec.needsItem) + " first.";
            return true;
        },
        onCast(ctx) {
            let p = ctx.player;
            let target = aimTarget(p, spec.range || 10);
            if (!target) { p.actionbar("&7No target in range."); return false; }
            let hits = spec.hits || 3;
            let ticks = spec.ticks || 30;
            let each = strikeDamage(p, spec.damage[0], spec.damage[1], ctx.level, spec.damage[2]) / hits;
            pushToward(p, target, Math.min(2.5, p.distanceTo(target) * 0.25));
            act(p, spec.animation, ticks);
            if (spec.sound) sfx(p, spec.sound, 1, 1);
            // times() gives every hit its own `i` (closures made inside a plain for-loop would
            // all see the loop's last value in this JavaScript engine)
            times(hits, (i) => {
                let last = i === hits - 1;
                RPG.schedule(Math.max(1, Math.floor((i + 1) * ticks / (hits + 1))), () => {
                    if (!target.isAlive()) return;
                    target.damageFrom(each, p);
                    burst(target, last ? "minecraft:explosion" : "minecraft:crit", last ? 1 : 6, 0.3, 0.2);
                    sfx(target, last ? (spec.finalSound || "critic_punch1") : PUNCH_SOUNDS[i % PUNCH_SOUNDS.length], 0.9, 1);
                    if (last) { knockAway(p, target, spec.knockback || 1.2, 0.4); sfx(target, "knockback_character", 0.8, 1); }
                });
            });
        }
    });
}

// =====================================================================================
//  Starting techniques
// =====================================================================================
kiTechnique("ki_blast", {
    name: "Ki Blast", 
    description: "A quick ball of ki in your aura colour. Damage grows with Ki Power and level.",
    projectile: "ki_blast", fire: "ki.barrage_fire", fireSound: "kiblast_shoot",
    cost: 5, cooldown: 10, damage: [4, 0.3, 1], auraColor: true
});

kiTechnique("ki_barrage", {
    name: "Ki Barrage", 
    description: "A rapid volley of eight small blasts.",
    projectile: "ki_volley", cast: "ki.barrage_cast", fire: "ki.barrage_fire", fireSound: "kiblast_shoot",
    charge: 8, shots: 8, shotDelay: 3, cost: 14, cooldown: 80, damage: [2, 0.1, 0.4]
});

// The Warrior's opener: a dash straight into a three-hit combo.
strikeTechnique("dragon_rush", {
    name: "Dragon Rush", 
    description: "Rush the target and hit them three times. The Warrior's bread and butter.",
    animation: "base.combo_1", ticks: 24, range: 8, hits: 3, damage: [5, 0.5, 1], stamina: 12, cooldown: 60
});

// =====================================================================================
//  Beams and big ki (most are taught by masters: hidden until learned)
// =====================================================================================
kiTechnique("kamehameha", {
    name: "Kamehameha", hidden: true, level: 10,
    description: "KA... ME... HA... ME... HA! The Turtle School's signature beam (Master Roshi).",
    projectile: "kamehameha", cast: "ki.kameha_cast", fire: "ki.kameha_fire",
    chargeSound: "ki_kame_charge", fireSound: "ki_kame_fire",
    cost: 30, cooldown: 160, damage: [10, 0.6, 2]
});

kiTechnique("galick_gun", {
    name: "Galick Gun", race: "saiyan", level: 15,
    description: "Vegeta's violet beam, fired from both palms.",
    projectile: "galick_gun", cast: "ki.galick_cast", fire: "ki.galick_fire",
    chargeSound: "ki_beam_charge", fireSound: "ki_beam_fire",
    cost: 30, cooldown: 160, damage: [11, 0.6, 2], skillPointCost: 2
});

kiTechnique("final_flash", {
    name: "Final Flash", hidden: true, level: 40,
    description: "A colossal golden beam. Long charge, huge damage (Vegeta).",
    projectile: "final_flash", cast: "ki.finalflash_cast", fire: "ki.finalflash_fire",
    chargeSound: "ki_finalflash_charge", fireSound: "ki_finalflash_fire",
    cost: 70, cooldown: 400, damage: [24, 1.2, 4]
});

kiTechnique("big_bang_attack", {
    name: "Big Bang Attack", hidden: true, level: 50,
    description: "One hand, one blinding sphere that explodes on impact (Vegeta).",
    projectile: "big_bang", cast: "ki.bigbang_cast", fire: "ki.bigbang_fire",
    charge: 25, chargeSound: "ki_explosion_charge", fireSound: "ki_beam_fire",
    cost: 55, cooldown: 300, damage: [20, 1.0, 3]
});

kiTechnique("masenko", {
    name: "Masenko", hidden: true, level: 12,
    description: "Hands over the head, then a golden beam (Piccolo & Gohan).",
    projectile: "masenko", cast: "ki.masenko_cast", fire: "ki.masenko_fire",
    chargeSound: "ki_beam_charge", fireSound: "ki_beam_fire",
    cost: 25, cooldown: 140, damage: [9, 0.5, 2]
});

kiTechnique("special_beam_cannon", {
    name: "Special Beam Cannon", hidden: true, level: 25,
    description: "Makankosappo: two fingers, a long charge, and a drilling laser that hits everything in line (Piccolo).",
    projectile: "special_beam_cannon", cast: "ki.makkako_cast", fire: "ki.makkako_fire",
    chargeSound: "ki_beam_charge", fireSound: "laserbeam",
    cost: 45, cooldown: 300, damage: [22, 0.9, 3]
});

kiTechnique("hellzone_grenade", {
    name: "Hellzone Grenade", hidden: true, level: 45,
    description: "Ten orbs that surround the enemy and explode (Piccolo).",
    projectile: "hellzone_grenade", cast: "ki.hellzone_grenade_cast", fire: "ki.hellzone_grenade_fire",
    charge: 20, shots: 10, shotDelay: 2, chargeSound: "ki_sparks", fireSound: "kiblast_shoot",
    cost: 50, cooldown: 300, damage: [5, 0.3, 1]
});

kiTechnique("destructo_disk", {
    name: "Destructo Disk", hidden: true, level: 15,
    description: "Kienzan: a razor disk that slices through everything in its path (Krillin).",
    projectile: "destructo_disk", cast: "ki.kienzan_cast", fire: "ki.kienzan_fire",
    charge: 25, chargeSound: "ki_disk_charge", fireSound: "ki_disk_fire",
    cost: 30, cooldown: 160, damage: [14, 0.7, 2]
});

kiTechnique("double_destructo_disk", {
    name: "Double Destructo Disk", hidden: true, level: 35,
    requires: { destructo_disk: 3 },
    description: "Two disks, one in each hand (Krillin).",
    projectile: "destructo_disk", cast: "ki.kienzandoble_cast", fire: "ki.kienzandoble_fire",
    charge: 25, shots: 2, shotDelay: 6, chargeSound: "ki_disk_charge", fireSound: "ki_disk_fire",
    cost: 50, cooldown: 220, damage: [13, 0.7, 2]
});

kiTechnique("tri_beam", {
    name: "Tri-Beam", hidden: true, level: 20,
    description: "Kikoho: a crushing wave from a triangle of hands. Costs some health too (Tien).",
    projectile: "tri_beam", fire: "ki.kikohu_fire", fireSound: "ki_beam_fire",
    cost: 35, cooldown: 200, damage: [16, 0.8, 2],
    canCast: (p) => p.health > 6 ? true : "Too exhausted for the Tri-Beam."
});

kiTechnique("neo_tri_beam", {
    name: "Neo Tri-Beam", hidden: true, level: 45, requires: { tri_beam: 3 },
    description: "Tien's desperate, sustained Kikoho.",
    projectile: "neo_tri_beam", cast: "ki.neo_kikohu_cast", fire: "ki.neo_kikohu_fire",
    chargeSound: "ki_explosion_charge", fireSound: "ki_beam_fire",
    cost: 60, cooldown: 400, damage: [20, 1.0, 3]
});

kiTechnique("dodonpa", {
    name: "Dodon Ray", hidden: true, level: 8,
    description: "The Crane School's finger beam: fast, thin, no charge.",
    projectile: "dodonpa", fire: "ki.dodonpa_fire", fireSound: "laserbeam",
    cost: 15, cooldown: 60, damage: [7, 0.4, 1]
});

kiTechnique("spirit_bomb", {
    name: "Spirit Bomb", hidden: true, level: 60,
    description: "Gather energy from every living thing. A slow, enormous sphere (King Kai).",
    projectile: "spirit_bomb", cast: "ki.large_ball_cast", fire: "ki.large_ball_fire",
    charge: 80, chargeSound: "ki_spiritbomb_charge", fireSound: "ki_spiritbomb_fire",
    cost: 100, cooldown: 1200, damage: [40, 1.5, 5]
});

kiTechnique("burning_attack", {
    name: "Burning Attack", hidden: true, level: 30,
    description: "A rapid hand sequence and an exploding fireball (Trunks).",
    projectile: "burning_attack", cast: "ki.burning_attack_cast", fire: "ki.burning_attack_fire",
    charge: 20, chargeSound: "ki_burning_charge", fireSound: "ki_burning_fire",
    cost: 40, cooldown: 200, damage: [14, 0.8, 2]
});

kiTechnique("death_beam", {
    name: "Death Beam", race: "frost_demon",
    description: "A fingertip laser, fast and precise.",
    projectile: "death_beam", fire: "ki.emperor_laser_fire", fireSound: "laserbeam",
    cost: 10, cooldown: 30, damage: [6, 0.4, 1]
});

kiTechnique("supernova", {
    name: "Supernova", race: "frost_demon", level: 50, skillPointCost: 3,
    description: "Raise a burning sun over your head and throw it.",
    projectile: "supernova", cast: "ki.supernova_cooler_cast", fire: "ki.supernova_cooler_fire",
    charge: 60, chargeSound: "ki_supernova_charge", fireSound: "ki_supernova_fire",
    cost: 90, cooldown: 900, damage: [35, 1.3, 4]
});

kiTechnique("kill_driver", {
    name: "Kill Driver", race: "bio_android", level: 25, skillPointCost: 2,
    description: "A crimson ring of ki that cuts through enemies.",
    projectile: "kill_driver", cast: "ki.kill_driver_cast", fire: "ki.kill_driver_fire",
    charge: 20, chargeSound: "ki_disk_charge", fireSound: "ki_disk_fire",
    cost: 35, cooldown: 180, damage: [13, 0.7, 2]
});

kiTechnique("blaster_meteor", {
    name: "Blaster Meteor", race: "saiyan", level: 65, skillPointCost: 3,
    description: "A storm of green ki orbs, the legendary Saiyan's rampage.",
    projectile: "blaster_meteor", cast: "ki.blaster_meteor_cast", fire: "ki.blaster_meteor_fire",
    charge: 20, shots: 12, shotDelay: 2, chargeSound: "ki_sparks", fireSound: "kiblast_shoot",
    cost: 70, cooldown: 400, damage: [6, 0.3, 1]
});

kiTechnique("assault_rain", {
    name: "Assault Rain", level: 35, skillPointCost: 2,
    description: "Fire upward and let the blasts rain down. Aim high!",
    projectile: "assault_rain", cast: "ki.assault_rain_cast", fire: "ki.assault_rain_fire",
    charge: 15, shots: 10, shotDelay: 2, fireSound: "kiblast_shoot",
    cost: 40, cooldown: 240, damage: [5, 0.3, 1]
});

kiTechnique("soul_punisher", {
    name: "Soul Punisher", hidden: true, level: 75,
    description: "A sphere of pure, cleansing ki (Grand Kai's reward).",
    projectile: "soul_punisher", cast: "ki.soul_punisher_cast", fire: "ki.soul_punisher_fire",
    charge: 40, chargeSound: "ki_spiritbomb_charge", fireSound: "ki_spiritbomb_fire",
    cost: 90, cooldown: 600, damage: [30, 1.2, 4]
});

kiTechnique("planet_burst", {
    name: "Planet Burst", race: "majin", level: 30, skillPointCost: 2,
    description: "Three pink spheres of destruction in a row.",
    projectile: "planet_burst", fire: "ki.destruction_balls_fire", fireSound: "ki_beam_fire",
    shots: 3, shotDelay: 5, cost: 40, cooldown: 200, damage: [10, 0.6, 2]
});

kiTechnique("candy_beam", {
    name: "Candy Beam", race: "majin", level: 15,
    description: "Weak enemies hit by this beam become cookies. Tasty.",
    projectile: "candy_beam", fire: "evs.candy_beam", fireSound: "majin_absorb",
    cost: 25, cooldown: 160, damage: [2, 0.1, 0.5]
});

kiTechnique("eye_laser", {
    name: "Eye Laser", hidden: true, level: 18,
    description: "Instant lasers from the eyes. No hands needed (Dr. Gero).",
    projectile: "eye_laser", fire: "ki.laser_fire", fireSound: "laserbeam",
    cost: 10, cooldown: 25, damage: [5, 0.35, 1]
});

kiTechnique("mouth_blast", {
    name: "Mouth Blast", race: "saiyan", level: 8,
    description: "Oozaru only: a torrent of ki from the jaws.",
    projectile: "mouth_blast", cast: "ki.mouth_blast_cast", fire: "ki.mouth_blast_fire",
    chargeSound: "vegeta_oozaru_growl", fireSound: "ki_beam_fire",
    cost: 30, cooldown: 120, damage: [16, 0.8, 2],
    canCast: (p) => (p.hasEffect("oozaru") || p.hasEffect("golden_oozaru")) ? true : "Only an Oozaru can do that."
});

// =====================================================================================
//  Strikes (DMZ "skp" animations)
// =====================================================================================
strikeTechnique("wolf_fang_fist", {
    name: "Wolf Fang Fist", hidden: true, level: 8,
    description: "Rogafufuken: a wolf's frenzy of strikes (Yamcha).",
    animation: "skp.wolf_fang", ticks: 40, hits: 6, damage: [8, 0.6, 1], cooldown: 100
});

strikeTechnique("meteor_combo", {
    name: "Meteor Combo", hidden: true, level: 20,
    description: "An unblockable chain that ends with a hammer blow (Goku).",
    animation: "skp.combo_meteor", ticks: 40, hits: 5, damage: [12, 0.8, 2], cooldown: 140
});

strikeTechnique("meteor_burst", {
    name: "Meteor Burst", hidden: true, level: 45, requires: { meteor_combo: 3 },
    description: "Kick them skyward, chase them up and smash them down.",
    animation: "skp.meteor_burst", ticks: 50, hits: 6, damage: [20, 1.0, 3], cost: 20, cooldown: 240
});

strikeTechnique("meteor_smash", {
    name: "Meteor Smash", level: 25, skillPointCost: 2,
    description: "A single overhead hammer that sends the target flying.",
    animation: "skp.meteor", ticks: 25, hits: 1, damage: [16, 0.9, 2], knockback: 2.2, cooldown: 140
});

strikeTechnique("dragon_fist", {
    name: "Dragon Fist", hidden: true, level: 60,
    description: "Your fist becomes a golden dragon that pierces anything (Goku).",
    animation: "skp.dragon_fist", ticks: 50, hits: 4, damage: [40, 1.5, 5], cost: 50, cooldown: 600,
    sound: "dragon_fist", finalSound: "critic_punch2", knockback: 3, range: 14
});

strikeTechnique("kaioken_attack", {
    name: "Kaioken Attack", hidden: true, level: 12,
    description: "A crimson flurry. Only while Kaioken is active (King Kai).",
    animation: "skp.kaioken_attack", ticks: 35, hits: 5, damage: [14, 1.0, 2], cooldown: 120,
    needsEffect: ["kaioken"], needsMessage: "Activate Kaioken first!"
});

strikeTechnique("spirit_breaker", {
    name: "Spirit Breaker", hidden: true, level: 30,
    description: "A rising elbow and a crushing double-axe handle (Gohan).",
    animation: "skp.spirit_breaker", ticks: 35, hits: 3, damage: [16, 0.9, 2], cooldown: 160
});

strikeTechnique("spirit_breaking_cannon", {
    name: "Spirit Breaking Cannon", hidden: true, level: 50, requires: { spirit_breaker: 2 },
    description: "Strike, launch, and finish with a point-blank blast (Gohan).",
    animation: "skp.spirit_breaking_cannon", ticks: 45, hits: 4, damage: [26, 1.2, 3], cost: 30, cooldown: 300,
    finalSound: "ki_explosion_impact"
});

strikeTechnique("death_chaser", {
    name: "Death Chaser", race: "frost_demon", level: 30, skillPointCost: 2,
    description: "Teleport around the target, striking from every side.",
    animation: "skp.death_chaser", ticks: 40, hits: 5, damage: [14, 0.9, 2], cooldown: 160, sound: "zanzoken"
});

strikeTechnique("blue_hurricane", {
    name: "Blue Hurricane", race: "frost_demon", level: 18,
    description: "Spin into the target like a cyclone (Zarbon's style).",
    animation: "skp.blue_hurricane", ticks: 30, hits: 4, damage: [10, 0.7, 1], cooldown: 120, knockback: 1.6
});

strikeTechnique("perfect_rush", {
    name: "Perfect Rush", race: "bio_android", level: 30, skillPointCost: 2,
    description: "A flawless sequence from every fighter whose cells you carry.",
    animation: "skp.perfect_rush", ticks: 45, hits: 6, damage: [16, 1.0, 2], cooldown: 180
});

strikeTechnique("android_combo", {
    name: "Android Barrage", hidden: true, level: 20,
    description: "Tireless mechanical strikes (Dr. Gero's programming).",
    animation: "skp.android_combo", ticks: 35, hits: 5, damage: [11, 0.8, 2], cooldown: 120
});

strikeTechnique("gum_punch", {
    name: "Gum Punch", race: "majin", level: 10,
    description: "Stretch your arm across the field and pummel them.",
    animation: "skp.gum_punch", ticks: 25, hits: 3, damage: [9, 0.7, 1], range: 16, cooldown: 80
});

strikeTechnique("deadly_dance", {
    name: "Deadly Dance", race: "majin", level: 40, skillPointCost: 2,
    description: "A wild, spinning assault that's hard to follow.",
    animation: "skp.deadly_dance", ticks: 45, hits: 6, damage: [18, 1.0, 2], cooldown: 200
});

strikeTechnique("super_god_fist", {
    name: "Super God Fist", hidden: true, level: 70,
    description: "A punch charged with god ki that blows straight through the enemy.",
    animation: "skp.super_god_fist", ticks: 45, hits: 2, damage: [45, 1.6, 5], cost: 60, cooldown: 600,
    finalSound: "critic_punch2", knockback: 3
});

strikeTechnique("oozaru_fist", {
    name: "Oozaru Fist", race: "saiyan", level: 8,
    description: "Oozaru only: a punch the size of a house.",
    animation: "skp.oozaru_fist", ticks: 30, hits: 1, damage: [20, 1.0, 2], cooldown: 100, knockback: 2.5,
    sound: "oozaru_fist", needsEffect: ["oozaru", "golden_oozaru"], needsMessage: "Only an Oozaru can do that."
});

strikeTechnique("oozaru_slam", {
    name: "Oozaru Slam", race: "saiyan", level: 12,
    description: "Oozaru only: grab and slam.",
    animation: "skp.oozaru_slam", ticks: 35, hits: 2, damage: [24, 1.1, 2], cooldown: 160, knockback: 1.5,
    sound: "oozaru_fist", needsEffect: ["oozaru", "golden_oozaru"], needsMessage: "Only an Oozaru can do that."
});

strikeTechnique("shining_sword_attack", {
    name: "Shining Sword Attack", hidden: true, level: 35,
    description: "Slice them to pieces, then blast what's left. Hold the Brave Sword (Trunks).",
    animation: "skp.shining_sword_attack", ticks: 45, hits: 6, damage: [22, 1.1, 3], cost: 20, cooldown: 240,
    sound: "sword_out", finalSound: "ki_explosion_impact", needsItem: "brave_sword", needsItemName: "Brave Sword"
});

strikeTechnique("dimensional_slash", {
    name: "Dimensional Slash", hidden: true, level: 55,
    description: "A cut that tears space. Hold the Dimensional Sword.",
    animation: "skp.dimensional_sword_attack", ticks: 40, hits: 3, damage: [30, 1.2, 3], cost: 30, cooldown: 300,
    sound: "katana_slash", needsItem: "dimensional_sword", needsItemName: "Dimensional Sword"
});

strikeTechnique("beam_sword", {
    name: "Ki Blade", level: 28, skillPointCost: 2,
    description: "Form a blade of ki on your arm and slash.",
    animation: "skp.beam_sword_slash", ticks: 25, hits: 2, damage: [14, 0.8, 2], cost: 15, cooldown: 100,
    sound: "sword_slash"
});

strikeTechnique("counter_strike", {
    name: "Strike Clash", level: 15,
    description: "Meet the enemy head-on with a clashing blow.",
    animation: "skp.strike_clash", ticks: 20, hits: 1, damage: [10, 0.8, 1], cooldown: 80, sound: "parry"
});

// =====================================================================================
//  Evasions & utility (written out in full)
// =====================================================================================

// Zanzoken: vanish and reappear a few blocks ahead, leaving an afterimage.
RPG.skills.define("zanzoken", {
    noLearn: dmzReplaced("zanzoken"), hidden: dmzReplaced("zanzoken"),
    icon: "dbr:textures/skill/zanzoken.png",
    name: "Zanzoken", icon: "dbr:textures/skill/zanzoken.png",
    description: "Afterimage step: blink 6 blocks forward.",
    maxLevel: 5,
    cost: { stamina: 15 },
    cooldown: (player, level) => 50 - level * 5,
    onCast(ctx) {
        let p = ctx.player;
        let yaw = p.yaw * Math.PI / 180;
        let dist = 6 + ctx.level;
        // walk back until both blocks at the destination are free (no blinking into walls)
        while (dist > 1) {
            let x = Math.floor(p.x - Math.sin(yaw) * dist), z = Math.floor(p.z + Math.cos(yaw) * dist), y = Math.floor(p.y);
            if (RPG.world.getBlock(p.dimension, x, y, z) === "minecraft:air" && RPG.world.getBlock(p.dimension, x, y + 1, z) === "minecraft:air") break;
            dist--;
        }
        burst(p, "minecraft:cloud", 12, 0.3, 0.02);                 // the afterimage
        p.teleport(p.x - Math.sin(yaw) * dist, p.y, p.z + Math.cos(yaw) * dist);
        act(p, "evs.default", 10);
        sfx(p, "zanzoken", 1, 1);
    }
});

// Instant Transmission: two fingers to the forehead, and you're next to your lock-on target.
RPG.skills.define("instant_transmission", {
    icon: "dbr:textures/skill/instant_transmission.png",
    name: "Instant Transmission", hidden: true,
    description: "Lock on (Z) to someone, then appear right behind them. Without a lock: 24 blocks ahead (Goku, after Yardrat).",
    requires: { level: 35 },
    cost: { ki: 30 },
    cooldown: 200,
    onCast(ctx) {
        let p = ctx.player;
        let t = lockedTarget(p) || ctx.target;
        act(p, "evs.dimensional_teleport", 15);
        sfx(p, "tp", 1, 1);
        RPG.schedule(8, () => {
            if (t && t.isAlive()) {
                let yaw = t.yaw * Math.PI / 180;              // behind the target
                p.teleport(t.x + Math.sin(yaw) * 1.5, t.y, t.z - Math.cos(yaw) * 1.5);
            } else {
                let to = lookPoint(p, 24);
                p.teleport(to.x, Math.max(to.y - 1.6, p.y), to.z);
            }
            sfx(p, "tp_short", 1, 1);
            burst(p, "minecraft:reverse_portal", 20, 0.4, 0.05);
        });
    }
});

RPG.skills.define("solar_flare", {
    noLearn: dmzReplaced("solar_flare"), hidden: dmzReplaced("solar_flare"),
    icon: "dbr:textures/skill/solar_flare.png",
    name: "Solar Flare", icon: "dbr:textures/skill/solar_flare.png",
    description: "Taiyoken! Blinds and slows everything within 10 blocks.",
    requires: { level: 5 },
    cost: { ki: 15 },
    cooldown: 400,
    onCast(ctx) {
        let p = ctx.player;
        act(p, "evs.taiyoken", 20);
        RPG.schedule(10, () => {
            let hit = 0;
            p.nearby(10 + ctx.level).forEach((e) => {
                e.addPotion("minecraft:blindness", 100, 0);
                e.addPotion("minecraft:slowness", 100, 2);
                hit++;
            });
            RPG.world.particle(p.dimension, "minecraft:flash", p.x, p.y + 1.8, p.z, 1, 0, 0);
            sfx(p, "ki_sparks", 1, 1.6);
            p.actionbar("&e&lSOLAR FLARE! &7(" + hit + " blinded)");
        });
    }
});

RPG.skills.define("healing_ki", {
    icon: "dbr:textures/skill/healing_ki.png",
    name: "Healing Ki", icon: "dbr:textures/skill/healing_ki.png",
    description: "Heal the ally you look at, or yourself if nobody is there.",
    requires: { level: 1, race: "namekian" },
    maxLevel: 5,
    cost: { ki: 20 },
    cooldown: 200,
    range: 8,
    onCast(ctx) {
        let who = ctx.target || ctx.player;
        let amount = 6 + ctx.player.stat("kipower") * 0.2 + ctx.level * 2;
        act(ctx.player, "ki.barrier_fire", 20);
        who.heal(amount);
        burst(who, "minecraft:happy_villager", 15, 0.5, 0);
        sfx(who, "senzu", 0.7, 1.3);
    }
});

RPG.skills.define("explosive_wave", {
    icon: "dbr:textures/skill/explosive_wave.png",
    name: "Explosive Wave", icon: "dbr:textures/skill/explosive_wave.png",
    description: "Release ki in every direction: damages and blows back everything within 7 blocks.",
    requires: { level: 25 },
    skillPointCost: 2, maxLevel: 10,
    cost: { ki: (player, level) => kiCost(player, 45) },
    cooldown: 300,
    onCast(ctx) {
        let p = ctx.player;
        act(p, "ki.explosion_cast", 20);
        sfx(p, "ki_explosion_charge", 1, 1.2);
        RPG.schedule(20, () => {
            act(p, "ki.explosion_fire", 15);
            sfx(p, "ki_explosion_impact", 1.5, 0.9);
            RPG.world.particle(p.dimension, "minecraft:explosion_emitter", p.x, p.y + 1, p.z, 1, 0, 0);
            p.nearby(7).forEach((e) => {
                e.damageFrom(kiDamage(p, 12, 0.7, ctx.level, 2), p);
                knockAway(p, e, 2, 0.6);
            });
        });
    }
});

RPG.skills.define("ki_dome", {
    icon: "dbr:textures/skill/ki_dome.png",
    name: "Barrier Dome", icon: "dbr:textures/skill/ki_dome.png",
    description: "A dome of ki erupts around you, hurting everything inside.",
    requires: { level: 40, race: "bio_android" },
    skillPointCost: 2, maxLevel: 10,
    cost: { ki: 50 },
    cooldown: 400,
    onCast(ctx) {
        let p = ctx.player;
        act(p, "ki.cupula_cast", 20);
        RPG.schedule(20, () => {
            act(p, "ki.cupula_fire", 20);
            sfx(p, "ki_explosion_impact", 1.3, 1.2);
            for (let a = 0; a < 24; a++) {                      // a ring of light
                let ang = a / 24 * Math.PI * 2;
                RPG.world.particle(p.dimension, "minecraft:end_rod", p.x + Math.cos(ang) * 5, p.y + 1, p.z + Math.sin(ang) * 5, 2, 0.1, 0.02);
            }
            p.nearby(6).forEach((e) => { e.damageFrom(kiDamage(p, 14, 0.8, ctx.level, 2), p); knockAway(p, e, 1.5, 0.5); });
        });
    }
});

// Ki Barrier: 5 seconds of 70% damage reduction (the "hurt" hook in 90_hooks.js reads it).
RPG.effects.define("ki_barrier", {
    name: "&bKi Barrier",
    color: "#7FD4FF",
    aura: { texture: AURA_GOD, frames: 4, speed: 12, color: "#7FD4FF", scale: 1.2, alpha: 0.6 }
});

RPG.skills.define("ki_barrier", {
    icon: "dbr:textures/skill/ki_barrier.png",
    name: "Ki Barrier", hidden: true,
    description: "A shell of ki that blocks 70% of damage for 5 seconds (Dr. Gero).",
    requires: { level: 30 },
    cost: { ki: 35 },
    cooldown: 400,
    onCast(ctx) {
        let p = ctx.player;
        act(p, "ki.barrier_cast", 10);
        RPG.schedule(10, () => {
            act(p, "ki.barrier_fire", 20);
            p.addEffect("ki_barrier", 100);
            sfx(p, "block3", 1, 1);
        });
    }
});

RPG.skills.define("rage_scream", {
    noLearn: dmzReplaced("rage_scream"), hidden: dmzReplaced("rage_scream"),
    icon: "dbr:textures/skill/rage_scream.png",
    name: "Kiai", icon: "dbr:textures/skill/rage_scream.png",
    description: "A shout so strong it blows everyone back.",
    requires: { level: 10 },
    cost: { stamina: 20 },
    cooldown: 200,
    onCast(ctx) {
        let p = ctx.player;
        act(p, "evs.rage_scream", 30);
        sfx(p, "knockback_character", 1.5, 0.7);
        burst(p, "minecraft:sonic_boom", 1, 0, 0);
        p.nearby(6).forEach((e) => knockAway(p, e, 2.2, 0.5));
    }
});

RPG.skills.define("gum_bind", {
    noLearn: dmzReplaced("gum_bind"), hidden: dmzReplaced("gum_bind"),
    icon: "dbr:textures/skill/gum_bind.png",
    name: "Gum Bind", icon: "dbr:textures/skill/gum_bind.png",
    description: "Wrap the target in your own rubbery body. They can't move for 3 seconds.",
    requires: { level: 20, race: "majin" },
    cost: { ki: 25 },
    cooldown: 300,
    range: 12,
    onCast(ctx) {
        let p = ctx.player, t = aimTarget(p, 12);
        if (!t) { p.actionbar("&7No target."); return false; }
        act(p, "evs.gum_bind", 20);
        t.addPotion("minecraft:slowness", 60 + ctx.level * 10, 10);
        t.addPotion("minecraft:weakness", 60 + ctx.level * 10, 2);
        burst(t, "minecraft:item_slime", 20, 0.5, 0.1);
        sfx(t, "majin_absorb", 1, 0.8);
        if (t.isPlayer()) act(t.asPlayer(), "evs.gum_bound", 60);
    }
});

RPG.skills.define("sleep_recovery", {
    noLearn: dmzReplaced("sleep_recovery"), hidden: dmzReplaced("sleep_recovery"),
    icon: "dbr:textures/skill/sleep_recovery.png",
    name: "Power Nap", icon: "dbr:textures/skill/sleep_recovery.png",
    description: "Lie down for 5 seconds and recover health, ki and stamina (Dende's advice).",
    requires: { level: 5 },
    cost: { stamina: 5 },
    cooldown: 1200,
    onCast(ctx) {
        let p = ctx.player;
        act(p, "evs.sleep_recovery", 100);
        p.addPotion("minecraft:slowness", 100, 6);
        for (let i = 1; i <= 5; i++) {
            RPG.schedule(i * 20, () => {      // the closure doesn't read i, so a plain loop is fine
                p.heal(2 + ctx.level);
                p.addResource("ki", p.maxResource("ki") * 0.06);
                p.addResource("stamina", p.maxResource("stamina") * 0.1);
                burst(p, "minecraft:note", 1, 0.2, 0);
            });
        }
    }
});

// Bio-Androids absorb weakened enemies (and the occasional unlucky android).
RPG.skills.define("absorb", {
    icon: "dbr:textures/skill/absorb.png",
    name: "Absorb", icon: "dbr:textures/skill/absorb.png",
    description: "Absorb an enemy below 30% health within 4 blocks: full heal and TP. Otherwise drains a little.",
    requires: { level: 10, race: "bio_android" },
    cost: { ki: 20 },
    cooldown: 300,
    range: 4,
    onCast(ctx) {
        let p = ctx.player, t = ctx.target;
        if (!t || p.distanceTo(t) > 4.5) { p.actionbar("&7Get closer to your prey."); return false; }
        act(p, "base.absorb", 40);
        sfx(p, "absorb1", 1, 1);
        if (!t.isPlayer() && t.health < t.maxHealth * 0.3) {
            RPG.schedule(30, () => {
                if (!t.isAlive()) return;
                let gain = Math.floor(t.maxHealth);
                t.kill();
                p.heal(1000);
                p.addTp(gain);
                act(p, "transf.absorb", 30);
                sfx(p, "absorb2", 1, 1);
                p.actionbar("&2Absorbed! &a+" + gain + " TP");
            });
        } else {
            t.damageFrom(6 + ctx.level * 2, p);
            p.heal(4 + ctx.level);
        }
    }
});

// Cell's last resort: swell up and explode. You survive (barely) thanks to your regeneration.
RPG.skills.define("self_destruct", {
    noLearn: dmzReplaced("self_destruct"), hidden: dmzReplaced("self_destruct"),
    icon: "dbr:textures/skill/self_destruct.png",
    name: "Self-Destruct", icon: "dbr:textures/skill/self_destruct.png",
    description: "Swell for 3 seconds, then explode. Huge damage around you; you're left at 1 health.",
    requires: { level: 45, race: "bio_android" },
    skillPointCost: 2,
    cost: { ki: 80 },
    cooldown: 2400,
    onCast(ctx) {
        let p = ctx.player;
        act(p, "base.explodecell", 60);
        sfx(p, "ki_explosion_charge", 1.5, 0.6);
        RPG.schedule(60, () => {
            p.addPotion("minecraft:resistance", 10, 4);     // resistance V = immune to the blast
            p.nearby(10).forEach((e) => e.damageFrom(kiDamage(p, 40, 1.5, ctx.level, 4), p));
            RPG.world.explode(p.dimension, p.x, p.y + 1, p.z, 4, false);
            sfx(p, "ki_explosion_impact", 3, 0.6);
            RPG.schedule(2, () => p.setHealth(1));
        });
    }
});

// The Fusion Dance: two players, three minutes, one warrior.
RPG.skills.define("fusion_dance", {
    icon: "dbr:textures/skill/fusion_dance.png",
    name: "Fusion Dance", hidden: true,
    description: "Look at another player within 5 blocks who also knows the dance. FU-SION-HA!",
    requires: { level: 30 },
    cost: { ki: 40 },
    cooldown: 6000,
    range: 5,
    onCast(ctx) {
        let p = ctx.player, t = ctx.target;
        let partner = t ? t.asPlayer() : null;
        if (!partner || !partner.hasSkill("fusion_dance")) { p.actionbar("&7You need a partner who knows the dance."); return false; }
        act(p, "base.fusion_dance_left", 60);
        act(partner, "base.fusion_dance_right", 60);
        sfx(p, "fusion", 1.2, 1);
        RPG.schedule(60, () => {
            [p, partner].forEach((who) => { who.addEffect("dance_fusion", 3600); burst(who, "minecraft:end_rod", 40, 0.8, 0.2); });
            sfx(p, "transform_on", 1, 1);
        });
    }
});

// Korin taught you to throw beans to your friends.
RPG.skills.define("senzu_toss", {
    icon: "dbr:textures/skill/senzu_toss.png",
    name: "Senzu Toss", icon: "dbr:textures/skill/senzu_toss.png", hidden: true,
    description: "Throw a Senzu Bean from your inventory: it fully heals whoever it hits (Korin).",
    cost: { stamina: 5 },
    cooldown: 100,
    canCast(player, level) { return player.hasItem("senzu_bean", 1) ? true : "You have no Senzu Beans."; },
    onCast(ctx) {
        let p = ctx.player;
        p.takeItem("senzu_bean", 1);
        act(p, "base.attack2", 10);
        p.shoot("senzu_toss", null);
    }
});

// =====================================================================================
//  Passives (their effect is in 90_hooks.js)
// =====================================================================================
RPG.skills.define("zenkai", {
    icon: "dbr:textures/skill/zenkai.png",
    name: "Zenkai",
    description: "Passive: every time you respawn you gain +1 Strength and +1 Vitality, and fight harder for a minute.",
    icon: "dbr:textures/skill/zenkai.png",
    passive: true,
    requires: { race: "saiyan" }
});

RPG.skills.define("regeneration", {
    icon: "dbr:textures/skill/regeneration.png",
    name: "Regeneration",
    description: "Passive: wounds close on their own (Namekians, Bio-Androids and Majins - Majins fastest).",
    icon: "dbr:textures/skill/regeneration.png",
    passive: true
});
