// =====================================================================================
//  85_world.js - custom dimensions (Time Chamber, Namek, Other World) and structures
// =====================================================================================
//  RPG.dimensions.define("id", {...}) creates "ragnarok_rpg:id". Minecraft only loads
//  dimensions when a world starts, so restart the world/server ONCE after adding or
//  changing one (the load report tells you).
//    generator: "normal" | "nether" | "end" | "caves" | "floating_islands" | "flat" | "void"
//    layers (flat only), biome, effects (sky), fixedTime, ambientLight, hasSkylight, minY, height
//  The floors are this project's own blocks (55_blocks.js): blockRef("name") gives their id.
// =====================================================================================

// ---- The Hyperbolic Time Chamber: an endless white floor, always bright ----------------
RPG.dimensions.define("time_chamber", {
    generator: "flat",
    biome: "minecraft:the_void",           // no vanilla mobs, no trees
    layers: [
        { block: "minecraft:bedrock", height: 1 },
        { block: blockRef("time_chamber_block"), height: 2 }
    ],
    minY: 0,
    height: 256,                           // so the floor surface is at y = 3
    effects: "minecraft:overworld",
    fixedTime: 6000,                       // always noon
    ambientLight: 1.0,                     // fully bright, like the real chamber
    bedWorks: false
});

// ---- Planet Namek: green grass, blue water... well, green grass at least -----------------
RPG.dimensions.define("namek", {
    generator: "flat",
    biome: "dbr:namek",                    // DMZ's Namek colours and ores (datapack/data/dbr/worldgen/biome/namek.json)
    features: true,
    layers: [
        { block: "minecraft:bedrock", height: 1 },
        { block: blockRef("namek_deepslate"), height: 24 },
        { block: blockRef("namek_stone"), height: 26 },
        { block: blockRef("namek_dirt"), height: 3 },
        { block: blockRef("namek_grass_block"), height: 1 }
    ],
    minY: 0,
    height: 256,                           // surface at y = 55
    effects: "minecraft:overworld",
    fixedTime: 6000                        // Namek has three suns: it's always day
});

// ---- The Other World (DMZ OtherworldDimension / OtherworldGeneration) -----------------------
// DMZ's heights: Hell floor at y -14, cloud decks at ~y 101-108 (PALACE_LEVEL) and 262-269 (TOURNAMENT_LEVEL).
// The palace, Snake Way, King Kai's planet and the tournament grounds are DMZ's own builds,
// placed by 65_dmz_structures.js. (An Other World made before this change keeps its old chunks:
// delete world/dimensions/ragnarok_rpg/otherworld to regenerate it.)
RPG.dimensions.define("otherworld", {
    generator: "flat",
    biome: "minecraft:the_void",
    layers: [
        { block: "minecraft:bedrock", height: 1 },
        { block: blockRef("hell_deepstone"), height: 16 },
        { block: blockRef("hell_stone"), height: 33 },
        { block: blockRef("hell_ground"), height: 1 },       // Hell floor, y = -14
        { block: "minecraft:air", height: 114 },
        { block: blockRef("otherworld_cloud"), height: 8 },  // cloud deck, y = 101..108 (soft: you sink through to Hell)
        { block: "minecraft:air", height: 153 },
        { block: blockRef("otherworld_cloud"), height: 8 }   // upper deck at the tournament level, y = 262..269
    ],
    minY: -64,
    height: 448,                           // DMZ WORLD_BOTTOM -64 .. WORLD_TOP 384
    effects: "minecraft:overworld",
    fixedTime: 6000,
    ambientLight: 0.35,
    coordinateScale: 10,
    bedWorks: false,
    respawnAnchorWorks: false,
    natural: false
});

var TIME_CHAMBER = "ragnarok_rpg:time_chamber";
var NAMEK = "ragnarok_rpg:namek";
var OTHERWORLD = "ragnarok_rpg:otherworld";

// Remember where the player came from, then go.
function travel(player, dimension, x, y, z, title, subtitle) {
    if (player.dimension.indexOf("ragnarok_rpg:") !== 0) {
        player.setVar("travel_return", player.dimension + " " + player.x + " " + player.y + " " + player.z);
    }
    player.teleportTo(dimension, x, y, z);
    sfx(player, "tp", 1, 0.8);
    player.title(title, subtitle);
}

// The first visitor to a world finds its residents waiting (spawned once per server).
function populateOnce(key, dimension, npcs) {
    if (RPG.server.getData(key, 0)) return;
    RPG.server.setData(key, 1);
    npcs.forEach((n) => RPG.world.spawnNpc(dimension, n[0], n[1], n[2], n[3]));
}

// Called by Mr. Popo's dialogue (60_npcs_dialogue.js).
function enterTimeChamber(player) {
    // DMZ's Time Chamber building (65_dmz_structures.js): arrive at its door
    let a = typeof dmzHtcArrival === "function" ? dmzHtcArrival() : null;
    if (a) { travel(player, TIME_CHAMBER, a[0], a[1], a[2], "&fHyperbolic Time Chamber", "&7TP x1.75 while inside. Leave by the door or /rpgc leave"); return; }
    travel(player, TIME_CHAMBER, 0.5, 4, 0.5, "&fHyperbolic Time Chamber", "&7TP x2 while inside. Leave with /rpgc leave");
}

function enterNamek(player) {
    travel(player, NAMEK, 0.5, 56, 0.5, "&aPlanet Namek", "&7Frieza's soldiers are everywhere. Leave with /rpgc leave");
    populateOnce("namek_populated", NAMEK, [
        ["guru", 12, 56, 12], ["namek_villager_0", -10, 56, 6], ["namek_villager_1", -14, 56, 2], ["namek_villager_2", -8, 56, -6],
        ["namek_villager_3", -12, 56, -10], ["dende", 16, 56, 8]
    ]);
}

// Living visitors arrive where the dead do: in front of King Yemma (DMZ SPIRIT_ARRIVAL).
function enterOtherworld(player) {
    if (typeof dmzEnsureOtherworld === "function") dmzEnsureOtherworld();
    travel(player, OTHERWORLD, 0.5, 150, -44.5, "&eThe Other World", "&7Snake Way starts behind King Yemma's palace. Leave with /rpgc leave");
    // DMZ keeps Old Kai on the Sacred Kai planet; without that world he waits here with the Supreme Kai.
    if (!RPG.dimensions.exists("sacredkaiplanet")) populateOnce("otherworld_kais_populated", OTHERWORLD, [
        ["old_kai", -34.5, 150, 12.5], ["supreme_kai", -26.5, 150, 12.5], ["kibito", -24.5, 150, 12.5]
    ]);
}

// /rpgc leave - back to where you entered.
RPG.commands.register("leave", {
    description: "Leave the Time Chamber, Namek or the Other World",
    run(player, args) {
        if (!player || player.dimension.indexOf("ragnarok_rpg:") !== 0) return;
        let saved = String(player.getVar("travel_return", "minecraft:overworld 0 100 0")).split(" ");
        player.teleportTo(saved[0], Number(saved[1]), Number(saved[2]), Number(saved[3]));
        sfx(player, "tp", 1, 1.2);
    }
});

// =====================================================================================
//  Structures
// =====================================================================================
//  1. Build something, save it with a structure block (e.g. name "ragnarok_rpg:kame_house").
//  2. Copy the .nbt from the world's generated/ folder into
//     datapack/data/ragnarok_rpg/structures/kame_house.nbt in this project.
//  3. Either place it from code, or let it generate in new chunks:
//
// RPG.structures.place("minecraft:overworld", "ragnarok_rpg:kame_house", 100, 64, 200, 0);
//
// RPG.structures.define("kame_house", {
//     template: "ragnarok_rpg:kame_house",
//     biomes: ["minecraft:beach", "minecraft:warm_ocean"],   // or a tag: "#minecraft:is_beach"
//     spacing: 48,                // about one every 48 chunks...
//     separation: 16,             // ...and never closer than 16
//     terrainAdaptation: "beard_thin"
// });
//  Worldgen is read when a world loads too: restart once, and only NEW chunks get it.
