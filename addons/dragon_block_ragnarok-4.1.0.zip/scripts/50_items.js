// =====================================================================================
//  50_items.js - this addon's own items: vehicles, potara (legacy names), music (legacy names).
//  Every DMZ item (DMZ registry ids, DMZ behaviour) is in 16_dmz_items.js.
// =====================================================================================
//  RPG.items.define("my_name", {...}) gives the item a free placeholder slot the first
//  time and keeps it forever (saved in item_ids.json), so you can rename and reorder
//  scripts freely. Give it with:  /rpg give @s senzu_bean 5
//
//  The look:  model: "dmzpack:rpg/item/senzu_bean"  uses any model JSON found under
//  assets/<namespace>/models/rpg/ in a resource pack (the project's resources/ folder
//  counts). Every name in resources/dmzpack_catalog.json works. Without a model the item
//  uses a placeholder icon:  icon: "sword", iconColor: "#FFAA00"  (see README for the list).
//
//  Common fields: name, model, type ("consumable" | "material" | "tool" | "weapon" |
//  "accessory" | "armor"), rarity, lore, maxStack, useTime, useAnim, cooldown, value,
//  stats, slot, damage, attackSpeed, durability, levelReq, classReq, glint,
//  onUse(player, itemId) (return false = not used), onHit(player, target).
//  Armour lives in 52_armor.js.
// =====================================================================================

// A shortcut: every DMZ item model has the same prefix.
function dmzItem(model) { return DMZ + "rpg/item/" + model; }

// Plays the "eating" animation on the avatar after a consumable is used.
function eat(player, sound) {
    act(player, "base.eat", 20);
    sfx(player, sound || "senzu", 0.8, 1);
}

// Vehicles: 56_vehicles.js (DMZ's rideable cars, CC-576, Frieza's capsule, space pod, Nimbus).

// Dragon Balls and radars: 57_dragon_balls.js (DMZ's placeable balls).

// =====================================================================================
//  Weapons
// =====================================================================================
RPG.items.define("trunks_sword", {
    name: "Trunks' Sword (Super)", model: dmzItem("trunks_sword"), type: "weapon", rarity: "rare",
    damage: 10, attackSpeed: 1.6, durability: 2200, levelReq: 35, stats: { strength: 8, strike: 3 },
    onHit(player, target) { sfx(target, "sword_slash", 0.6, 0.9); }
});

// =====================================================================================
//  Materials
// =====================================================================================
[
    ["namek_grass_tuft", "Namekian Grass", 2], ["namek_sacred_grass_tuft", "Sacred Grass", 5], ["namek_moss_clump", "Namek Moss Clump", 3]
].forEach((m) => {
    let model = { namek_grass_tuft: "namek_grass", namek_sacred_grass_tuft: "namek_sacred_grass", namek_moss_clump: "namek_moss" }[m[0]] || m[0];
    RPG.items.define(m[0], { name: m[1], model: dmzItem(model), type: "material", maxStack: 64, value: m[2] });
});

// Potara earrings: use a pair while looking at another player to fuse for 5 minutes.
function potaraUse(player) {
    let t = player.target(6);
    let partner = t ? t.asPlayer() : null;
    if (!partner) { player.actionbar("&7Look at the player wearing the other earring."); return false; }
    act(player, "base.fusion_pothala_left", 30);
    act(partner, "base.fusion_pothala_right", 30);
    sfx(player, "fusion", 1.2, 1.1);
    [player, partner].forEach((who) => who.addEffect("potara_fusion", 6000));
}

RPG.items.define("potara_pair", {
    name: "&e&lPotara Earrings", model: dmzItem("pothala_pair"), type: "consumable", rarity: "legendary", glint: true, value: 25000,
    lore: ["A gift from the Supreme Kai.", "Right-click while looking at a friend: fuse for 5 minutes."],
    onUse(player) { return potaraUse(player); }
});
RPG.items.define("green_potara_pair", {
    name: "&a&lGreen Potara Earrings", model: dmzItem("green_pothala_pair"), type: "consumable", rarity: "legendary", glint: true, value: 25000,
    lore: ["Zamasu's earrings. The fusion is the same; the attitude is not."],
    onUse(player) { return potaraUse(player); }
});
["pothala_left", "pothala_right", "green_pothala_left", "green_pothala_right"].forEach((e) => {
    RPG.items.define(e.replace("pothala", "potara"), { name: "Potara Earring (" + e.replace(/_/g, " ").replace("pothala", "") + ")", model: dmzItem(e), type: "material", rarity: "epic", value: 10000 });
});

RPG.items.define("invisible_ladder", {
    name: "Invisible Ladder", model: dmzItem("invisible_ladder_block"), type: "material", maxStack: 64, value: 20,
    lore: ["Korin's tower is climbed the honest way."]
});

// =====================================================================================
//  Music discs: right-click to play a track from the asset pack
// =====================================================================================
// There are 39 tracks (menu_music_1 .. 39) plus the DMZ theme. The names come from DMZ.
var DISC_NAMES = [
    "Bulma is Happy", "Away on the Bike!", "Goku's Dinner Bird", "Goku Leaves With Umigame", "The Joys Of Travel",
    "Kame Sennin Prepares The Kamehameha", "Kuririn Arrives by Boat", "Milk Delivery", "Climbing The Tower", "Yajirobe in Action",
    "Prologue & Subtitle I", "Cha-La Head Cha-La (Variations)", "Bridge Collection", "Gohan's Theme", "Alas, the Days of Training",
    "Planet Namek and Hope Vanish", "Dragon Ball Z", "The Strongest In This World", "One More Conclusion", "Son Goku the Super Saiyajin",
    "Goodbye Warriors", "Angel", "Enter A New Hero", "Son Goku is the Strongest After All", "The Super Warrior Can't Rest",
    "Beerus' Tea Time", "Under the Blue Sky", "Pleasant Days", "Limit-Break x Survivor", "Like That Cloud",
    "Call for a Miracle", "Goku's Father-Son Victory", "Vegeta's Sacrifice", "Dearly Beloved", "in the pool",
    "Sad Brothers", "we will finish this game", "Styx Helix", "Stay Alive ~Regain~"
];

function discDef(name, sound, model) {
    return {
        name: "&bMusic Disc &7- " + name, model: dmzItem(model), type: "tool", rarity: "rare", value: 300,
        lore: ["Right-click to play for everyone nearby."], cooldown: 200,
        onUse(player) { sfx(player, sound, 2, 1); player.actionbar("&bNow playing: &f" + name); }
    };
}

RPG.items.define("music_disc_dmz", discDef("Main Theme", "menu_music", "music_disc_dmz"));
DISC_NAMES.forEach((title, i) => {
    RPG.items.define("music_disc_" + (i + 1), discDef(title, "menu_music_" + (i + 1), "music_disc_menu_music_" + (i + 1)));
});
