// =====================================================================================
//  11_dmz_combat.js - DMZ melee combo, guard, parry, poise and stun (CombatEvent, TickHandler)
// =====================================================================================
//  The client (client/scripts/42_combat.js) sends each combo step ("dmz_melee") and the
//  guard ("dmz_guard"). Here: everyone sees the attack animation, the swing sound plays,
//  the step's damage multiplier and stamina cost apply, and guarding/parrying works like DMZ.
// =====================================================================================
var DMZ_MELEE = {};          // uuid -> { mult, at }

RPG.effects.define("guarding", { name: "&bGuarding", color: "#7FD3FF", hidden: true });
RPG.effects.define("stunned", { name: "&cStunned", color: "#FF5555", hidden: true, flags: ["noMove", "noJump", "noAttack", "noSkills"] });
RPG.effects.define("staggered", { name: "&6Staggered", color: "#FFAA00", hidden: true,
    attributes: { "minecraft:generic.movement_speed": { amount: -0.5, operation: "multiply_total" } } });

(function () {
    var C = DMZ_COMBAT.CFG;
    var GUARD = {};          // uuid -> { since (ms), poiseHit (tick) }

    function now() { return Date.now(); }
    function tick() { return RPG.server.getTick(); }

    // ---- melee steps from the client ----
    RPG.net.on("dmz_melee", (p, d) => {
        if (!p.getVar("dmz_created", 0) || p.hasEffect("stunned") || p.hasEffect("guarding")) return;
        let anim = String(d && d.a || ""), step = DMZ_COMBAT.FIST.filter((a) => a.anim === anim)[0];
        if (!step) return;
        let infusion = p.hasEffect("ki_infusion") && p.getLevel() >= 5;
        let atk = DMZ_COMBAT.attackFor(Math.max(0, Math.floor(Number(d.c) || 0)), infusion);
        DMZ_MELEE[p.uuid] = { mult: atk.anim === anim ? atk.damage : 1, at: tick() };
        animPulse(p, "melee", { a: anim, s: Math.max(0.15, Math.min(2, Number(d.s) || 1)) });
        sfx(p, "fist_punch", 0.7, 0.9 + Math.random() * 0.2);
    });

    // ---- guard ----
    RPG.net.on("dmz_guard", (p, d) => {
        if (!p.getVar("dmz_created", 0)) return;
        if (d && d.on) {
            if (p.hasEffect("stunned") || p.hasEffect("ki_charge")) return;
            let g = GUARD[p.uuid] || (GUARD[p.uuid] = { since: 0, released: 0, poiseHit: -1000 });
            if (now() - g.released < C.reblockMs) return;                  // server re-block delay
            g.since = now();
            p.addEffect("guarding", -1);
        } else if (p.hasEffect("guarding")) {
            p.removeEffect("guarding");
            (GUARD[p.uuid] || (GUARD[p.uuid] = { since: 0, poiseHit: -1000 })).released = now();
        }
    });

    function poise(p) {
        let max = DMZ_F.maxPoise(dmzView(p)), v = p.getVar("dmz_poise", null);
        return { max: max, value: v === null ? max : Math.min(max, Number(v)) };
    }

    function guardBreak(p) {
        p.setVar("dmz_poise", 0);
        p.addResource("stamina", -p.resource("stamina"));
        p.removeEffect("guarding");
        p.setVar("dmz_surge", 0);
        p.addEffect("stunned", C.guardBreakStun);
        act(p, "base.parried_stun", C.guardBreakStun);
        let g = GUARD[p.uuid]; if (g) g.poiseHit = tick();
        sfx(p, "unblock", 1, 1);
        burst(p, "minecraft:crit", 15, 0.4, 0.2);
    }

    function inFront(target, src) {
        let yaw = target.yaw * Math.PI / 180, lx = -Math.sin(yaw), lz = Math.cos(yaw);
        let dx = src.x - target.x, dz = src.z - target.z;
        return lx * dx + lz * dz > 0;
    }

    // ---- damage: guard, parry, stun (after DMZ mitigation in 09_dmz_stats.js) ----
    RPG.on("damageFinal", (e) => {
        let a = e.attacker, t = e.target;
        // a stunned or guarding player can't hit
        if (a && a.isPlayer() && (a.asPlayer().hasEffect("stunned") || a.asPlayer().hasEffect("guarding")) && e.kind === "melee") { e.cancel(); return; }
        if (!t || !t.isPlayer() || e.amount <= 0) return;
        let p = t.asPlayer();
        if (!p.hasEffect("guarding") || p.hasEffect("stunned") || !a || !inFront(p, a)) return;
        let g = GUARD[p.uuid] || { since: 0 }, est = e.amount, nonPlayer = !a.isPlayer();
        let parry = now() - g.since <= C.parryWindowMs;
        let ps = poise(p);
        let poiseDmg = est * C.poiseDamageMult * (nonPlayer ? 1.5 : 1) * (parry ? 0.66 : 1);
        let staminaCost = est * C.blockStaminaCost;
        if (ps.value - poiseDmg <= 0 || p.resource("stamina") - staminaCost <= 0) {
            guardBreak(p);
            burst(p, "minecraft:enchanted_hit", 10, 0.4, 0.1);
            return;
        }
        p.setVar("dmz_poise", ps.value - poiseDmg);
        p.addResource("stamina", -staminaCost);
        if (GUARD[p.uuid]) GUARD[p.uuid].poiseHit = tick();
        if (parry) {
            e.amount = 0;
            let dx = a.x - p.x, dz = a.z - p.z, len = Math.max(0.001, Math.sqrt(dx * dx + dz * dz));
            a.push(dx / len * 1.5, 0.25, dz / len * 1.5);
            if (a.isPlayer()) {
                let ap = a.asPlayer();
                ap.addEffect("staggered", 60);
                ap.setVar("dmz_parried_until", now() + C.parryPenaltyMs);   // stamina costs x2 for 4 s
                act(ap, "base.parried", 29);
            } else {
                a.addPotion("minecraft:slowness", 20, 9);               // mobs: stunned 1 s
            }
            sfx(p, "parry", 1, 1);
            burst(p, "minecraft:electric_spark", 15, 0.4, 0.15);
        } else {
            let def = DMZ_F.defense(dmzView(p)) / 0.12;
            let mitig = Math.max(C.blockMin, Math.min(C.blockCap, def * 3 / (est + def * 3)));
            e.amount = est * (1 - mitig);
            sfx(p, "block" + RPG.randomInt(1, 3), 1, 0.9 + Math.random() * 0.1);
            burst(p, "minecraft:crit", 6, 0.3, 0.05);
        }
    });

    // ---- poise regen every second: not guarding, not stunned, 100 ticks after a poise hit ----
    RPG.every(20, () => {
        RPG.server.players().forEach((p) => {
            if (!p.getVar("dmz_created", 0) || p.hasEffect("guarding") || p.hasEffect("stunned")) return;
            let g = GUARD[p.uuid];
            if (g && tick() - g.poiseHit < C.poiseRegenCooldown) return;
            let ps = poise(p);
            if (ps.value < ps.max) p.setVar("dmz_poise", Math.min(ps.max, ps.value + Math.max(1, ps.max * 0.1)));
        });
    });
})();
