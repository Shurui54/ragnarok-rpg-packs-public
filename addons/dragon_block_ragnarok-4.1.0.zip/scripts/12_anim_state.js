// =====================================================================================
//  12_anim_state.js - what every client needs to animate a player like DMZ does
// =====================================================================================
//  The client animator (client/scripts/40_animator.js) reads these with pl.shared(key).
//  Only changes are sent, so checking every 2 ticks is cheap. Addons can share more with
//  player.setShared(key, value) and read them in their own animator extension
//  (DBR_ANIMATOR.extend on the client).
//
//    charge   1 while holding Charge Ki          surge     1 while the ki surge is armed
//    block    1 while guarding                   meditate  1 while meditating
//    fly      1 while flying                     flyFast   1 at full flight speed
//    stun     1 while stunned                    down      1 while knocked down
//    drain    1 while absorbing                  tf        the transformation animation while
//                                                          charging a form ("" otherwise)
//    act      {a, t, n}  a technique animation (act() in 01_toolbox.js)
//    dash     {d, n}     a dash (1 front, 2 back, 3 right, 4 left, 6-8 double-tap)
//    evade    {v, n}     a dodge (1 front, 2 back, 3 left, 4 right)
//    melee    {a, off, s, n}  a combo attack animation (combat.* id, offhand, speed)
//    pose     a weapon stance animation ("" for none)
// =====================================================================================
(function () {
    function flag(p, key, on) { p.setShared(key, on ? 1 : null); }

    RPG.every(2, () => {
        RPG.server.players().forEach((p) => {
            p.setShared("race", p.race || null);         // the look key can be a form, so share the race itself
            // ki charge pose; also DMZ's forced charge while the False Super Saiyan rage builds (31_dmz_transform.js)
            flag(p, "charge", p.hasEffect("ki_charge") || (Number(p.getVar("dmz_forced_aura", 0)) > 0 && !p.getVar("dmz_form", "")));
            flag(p, "surge", Number(p.getVar("dmz_surge", 0)) > 0);
            flag(p, "block", p.hasEffect("guarding"));
            flag(p, "meditate", p.hasEffect("meditating"));
            flag(p, "fly", p.hasEffect("flight"));
            flag(p, "flyFast", p.hasEffect("flight") && (p.getVar("fly_fast", 0) || p.sprinting));
            flag(p, "stun", p.hasEffect("stunned"));
            flag(p, "down", p.hasEffect("knocked_down"));
            flag(p, "drain", p.hasEffect("absorbing"));
            let tf = p.getVar("dmz_tf_anim", "");
            p.setShared("tf", tf ? tf : null);
        });
    });
})();
