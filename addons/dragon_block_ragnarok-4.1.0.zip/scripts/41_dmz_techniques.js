// =====================================================================================
//  41_dmz_techniques.js - DragonMine Z techniques: learn, equip, charge and fire
// =====================================================================================
//  Port of DMZ's Techniques / TechniqueDispatcher / KiTechniqueHandler / StrikeAttackHandler /
//  EvasionAttackHandler (DragonMine Z, GPL-3.0). Data: shared/09_dmz_techniques_data.js.
//
//  Per player (var "dmz_tech"):  { u: { id: { x: xp, d: dmgLvl, c: cdLvl, r: durLvl } },
//                                  s: [8 equipped ids], fl: Oozaru loadout backup or null }
//  Cooldowns (var "dmz_tech_cd"): { id: end time in ms }   ("strike_global" too)
//
//  How it is used, like DMZ:
//   - Learn: masters sell techniques for TP (46_dmz_skills.js -> DMZ_TECH.unlock), quests,
//     /rpgc dmztech learn. Learning shows DMZ's notification pop-up on the client.
//   - Equip: V > Skills > Ki Attacks / Strike Attacks / Evasion Attacks > "Bind to Slot" > 1..8.
//   - Use: Alt+1..4 (slots 1-4) and Ctrl+1..4 (slots 5-8), keys 1-8 in 45_keys.js. Ki attacks
//     charge while held (0 -> 100 -> 175 %) and fire per DMZ's rules; strikes and evasions cast at once.
//
//  Other scripts (e.g. the X radial menu) can call the global DMZ_TECH:
//     DMZ_TECH.unlock(p, id, {source, silent})   DMZ_TECH.forget(p, id)   DMZ_TECH.equip(p, slot, id)
//     DMZ_TECH.slots(p) -> [8 ids]   DMZ_TECH.unlocked(p) -> [ids]   DMZ_TECH.press(p, slot) / release(p, slot)
//     DMZ_TECH.cast(p, id)  (fire a technique by id, as if its slot key were tapped)
//     DMZ_TECH.isCharging(p)   DMZ_TECH.cancel(p)   DMZ_TECH.sendState(p)
// =====================================================================================
RPG.effects.define("dmz_tech_rooted", { name: "&7Charging", color: "#AAAAAA", hidden: true, flags: ["noMove", "noJump"] });

// ---- projectiles used by the techniques (35_projectiles.js holds the older ones) -------------
var DMZ_TECH_PROJ = (function () {
    function num(v, d) { var n = Number(v); return isNaN(n) ? d : n; }
    function hurtAround(owner, x, y, z, r, dmg) {
        if (!owner || dmg <= 0) return;
        RPG.world.entitiesNear(owner.dimension, x, y, z, r).forEach(function (e) {
            try {
                if (e.uuid === owner.uuid || !e.isAlive() || owner.isAlly(e)) return;
                e.damageFrom(dmg, owner, { kind: "ki", ignoreIFrames: true });
            } catch (err) { }
        });
    }
    function burst(owner, x, y, z, proj, big) {
        if (!owner || !proj || proj.getVar("done", 0)) return;
        proj.setVar("done", 1);
        var r = num(proj.getVar("r", 2.5), 2.5);
        hurtAround(owner, x, y, z, r, num(proj.getVar("dmg", 0), 0));
        RPG.world.particle(owner.dimension, big || r > 5 ? "minecraft:explosion_emitter" : "minecraft:explosion", x, y, z, 1, 0, 0);
        RPG.world.sound(owner.dimension, "minecraft:entity.generic.explode", x, y, z, 5, 0.6);
    }
    // beams: per hit = damage / maxHits, but a target's first hit is at least 75 % (KiWaveEntity)
    function beamDamage(owner, target, proj) {
        if (!proj || !target) return 0;
        var tot = num(proj.getVar("dmg", 0), 0), hits = Math.max(1, num(proj.getVar("hits", 1), 1)), key = "h_" + target.uuid;
        if (!proj.getVar(key, 0)) { proj.setVar(key, 1); return Math.max(tot / hits, tot * 0.75); }
        return tot / hits;
    }
    projectile("dmz_tech_ball", {
        shape: "ball", kind: "ki", size: 1, speed: 1, lifetime: 90, knockback: 0.4,
        damage: function () { return 0; },                       // the explosion below hits everything once
        onHit: function (o, t, x, y, z, proj) {
            if (proj && proj.getVar("noBlock", 0) && !t) { proj.discard(); return; }
            burst(o, x, y, z, proj, false);
            if (proj && proj.getVar("tech", "") === "soul_punisher" && t) RPG.world.particle(t.dimension, "minecraft:end_rod", x, y + 1, z, 30, 0.6, 0.1);
        },
        onEnd: function (o, x, y, z, proj) { if (proj && proj.getVar("endBoom", 0)) burst(o, x, y, z, proj, true); }
    });
    projectile("dmz_tech_wave", {
        shape: "beam", kind: "ki", size: 1, length: 100, speed: 1.2, duration: 80, hitInterval: 20, knockback: 0.6,
        followAim: false, slowPerHit: 0.75, damage: beamDamage,
        // the wave explodes at its tip when it ends: radius size x 4, full damage (KiWaveEntity)
        onEnd: function (o, x, y, z, proj) { burst(o, x, y, z, proj, true); }
    });
    projectile("dmz_tech_beam", {
        shape: "laser", kind: "ki", size: 0.8, length: 100, speed: 2, duration: 80, hitInterval: 20, knockback: 0.5,
        followAim: false, damage: beamDamage
    });
    projectile("dmz_tech_laser", {
        shape: "laser", kind: "ki", size: 0.4, length: 64, speed: 16, duration: 10, hitInterval: 10, knockback: 0.2, damage: 4
    });
    projectile("dmz_tech_disk", {
        shape: "disk", kind: "ki", size: 1, speed: 1.5, lifetime: 70, pierce: 999, knockback: 0, damage: 4,
        particles: "minecraft:wax_on",
        onHit: function (o, t, x, y, z, proj) { if (!t && proj && proj.getVar("boom", 0)) burst(o, x, y, z, proj, true); },
        onEnd: function (o, x, y, z, proj) { if (proj && proj.getVar("boom", 0)) burst(o, x, y, z, proj, true); }
    });
    projectile("dmz_tech_bullet", {
        shape: "ball", kind: "ki", size: 0.4, speed: 1.5, lifetime: 40, knockback: 0.1, damage: 2,
        onHit: function (o, t, x, y, z) { if (o) RPG.world.particle(o.dimension, "minecraft:crit", x, y, z, 3, 0.1, 0.05); }
    });
    projectile("dmz_tech_orb", {
        shape: "sprite", kind: "ki", texture: DMZ_TEX + "ki/kiblast.png", spin: 15, size: 0.8, speed: 0.01, lifetime: 120, knockback: 0.3, damage: 2,
        onHit: function (o, t, x, y, z) { if (o) RPG.world.particle(o.dimension, "minecraft:explosion", x, y, z, 1, 0, 0); }
    });
    return { burst: burst, hurtAround: hurtAround };
})();

var DMZ_TECH = (function () {
    var TD = DMZ_TECH_DATA, N = TD.SLOT_COUNT;
    var SESS = {};          // uuid -> ki charge session
    var FIRING = {};        // uuid -> { until, drain, emitter } while a restricted ki attack fires

    // ---------------------------------------------------------------------------------
    //  storage
    // ---------------------------------------------------------------------------------
    function load(p) {
        var v = p.getVar("dmz_tech", null);
        if (!v || typeof v !== "object") v = {};
        if (!v.u || typeof v.u !== "object") v.u = {};
        var s = [], old = v.s && v.s.length !== undefined ? v.s : [];
        for (var i = 0; i < N; i++) s.push(typeof old[i] === "string" ? old[i] : "");
        v.s = s;
        if (!v.fl || typeof v.fl !== "object") v.fl = null;
        return v;
    }
    function save(p, v) { p.setVar("dmz_tech", v); }
    function unlocked(p) { return Object.keys(load(p).u); }
    function has(p, id) { return !!load(p).u[id]; }
    function slots(p) { return load(p).s.slice(); }
    function rec(p, id) { return load(p).u[id] || null; }

    function nowMs() { return Date.now(); }
    function cds(p) { var c = p.getVar("dmz_tech_cd", null); return c && typeof c === "object" ? c : {}; }
    function cdLeft(p, id) { var e = Number(cds(p)[id]) || 0; return Math.max(0, Math.ceil((e - nowMs()) / 50)); }
    function setCd(p, id, ticks) {
        var c = cds(p), now = nowMs();
        Object.keys(c).forEach(function (k) { if (Number(c[k]) <= now) delete c[k]; });
        if (ticks > 0) c[id] = now + ticks * 50; else delete c[id];
        p.setVar("dmz_tech_cd", c);
    }
    function creative(p) { try { return p.getGameMode() === "creative"; } catch (e) { return false; } }
    function msg(p, key, args, color) { RPG.net.send(p, "dmz_msg", { key: key, args: args || [], color: color || "#FF5555" }); }

    // ---- DMZ stat getters (StatsData) ----
    function view(p) { return dmzView(p); }
    function noForms(v) {
        return { stat: v.stat, cls: v.cls, release: v.release, mult: function () { return 1; }, armor: v.armor, toughness: v.toughness, race: v.race };
    }
    function kiDamage(p) { return DMZ_F.ki(view(p)); }
    function kiNoForms(p) { return DMZ_F.ki(noForms(view(p))); }
    function strikeDamage(p) { return DMZ_F.strike(view(p)); }
    function strikeNoForms(p) { return DMZ_F.strike(noForms(view(p))); }
    function android(p) { return !!p.getVar("dmz_android", 0); }
    function costMod(p) { return android(p) ? 0.5 : 1; }                        // kiAttackCostModifier
    function dmgMod(p) { return android(p) ? 0.85 : 1; }                        // kiAttackDamageModifier
    function transformed(p) { var v = view(p); return v.mult("PWR") > 1.0001; }
    function release(p) { return Number(p.getVar("dmz_release", 0)) || 0; }
    function dmzRace(p) { return DMZ_DATA.DMZ[p.race] || p.race || "human"; }
    function raceAllowed(p, id) { return DMZ_SKILLS_DATA.allowed(id, dmzRace(p), android(p)); }
    function skillLevel(p, s) { return typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS.level(p, s) : 1; }

    // what the skills screen shows for each technique (getCalculatedCost, actual cooldown, damage...)
    function info(p, id, r) {
        r = r || {};
        var k = TD.kind(id), v = view(p), out = { kind: k };
        if (k === "ki") {
            var T = TD.KI[id];
            out.cost = Math.round(TD.kiCost(id, kiNoForms(p)) * 10) / 10;
            out.cd = TD.kiCooldown(id, 1, r.c);
            out.dmg = Math.floor(kiDamage(p) * T.dmg);
        } else if (k === "strike") {
            out.cost = Math.round(TD.strikeCost(id, strikeNoForms(p), r.d) * 10) / 10;
            out.cd = TD.strikeCooldown(id, r.c);
            out.dmg = Math.floor(strikeDamage(p) * TD.strikeDamageMult(id, r.d));
        } else if (k === "evasion") {
            out.cost = Math.round(TD.evasionCost(id, v.stat("SKP"), v.stat("PWR"), r.r) * 10) / 10;
            out.cd = TD.evasionCooldown(id, r.c);
            out.dur = TD.evasionDuration(id, r.r);
            out.dmg = Math.floor(TD.evasionHit(id, v.stat("SKP"), v.stat("PWR")));
        }
        out.req = TD.MIN_XP_COST;
        return out;
    }

    function sendState(p) {
        var v = load(p), u = {}, inf = {}, cd = {};
        Object.keys(v.u).forEach(function (id) {
            var r = v.u[id] || {};
            u[id] = { x: Math.floor(r.x || 0), d: r.d || 0, c: r.c || 0, r: r.r || 0 };
            if (TD.exists(id)) inf[id] = info(p, id, r);
            var left = cdLeft(p, id);
            if (left > 0) cd[id] = left;
        });
        // legacy (non-DMZ) skills sitting in a slot show their own cooldowns
        v.s.forEach(function (id) { if (id && !TD.exists(id)) { var l = Math.ceil(Number(p.cooldownLeft(id)) || 0); if (l > 0) cd[id] = l; } });
        var g = cdLeft(p, "strike_global");
        if (g > 0) cd.strike_global = g;
        RPG.net.send(p, "dmz_tech_state", { u: u, s: v.s, cd: cd, info: inf, kc: skillLevel(p, "kicontrol") > 0, fl: !!v.fl,
            race: dmzRace(p), android: android(p) });
    }

    // ---------------------------------------------------------------------------------
    //  learning (Techniques.unlockTechnique / removeTechnique) and the pop-up
    // ---------------------------------------------------------------------------------
    function markOwnedSkill(p, id) {
        if (typeof DMZ_SKILLS === "undefined") return;
        var map = DMZ_SKILLS.levels(p);
        if (typeof map[id] === "number" && map[id] >= 1) return;
        map[id] = 1;
        p.setVar("dmz_skills", map);
        DMZ_SKILLS.sendState(p);
    }
    /** opts: { source: "master" | "quest" | "command" | "form", silent } */
    function unlock(p, id, opts) {
        opts = opts || {};
        id = String(id || "").toLowerCase();
        if (!TD.exists(id) || id === TD.REVIVE_ID) return false;
        var v = load(p);
        if (v.u[id]) { if (!opts.silent) markOwnedSkill(p, id); return false; }
        if (Object.keys(v.u).length >= TD.MAX_UNLOCKED) { msg(p, "quest.dmz.reward.technique_slots_full", [], "#FFFF55"); return false; }
        v.u[id] = { x: 0, d: 0, c: 0, r: 0 };
        save(p, v);
        if (opts.source !== "form") markOwnedSkill(p, id);
        if (!opts.silent) RPG.net.send(p, "dmz_tech_learned", { id: id, kind: TD.kind(id), source: opts.source || "" });
        sendState(p);
        return true;
    }
    function forget(p, id) {
        var v = load(p);
        if (!v.u[id] || id === TD.REVIVE_ID) return false;
        delete v.u[id];
        for (var i = 0; i < N; i++) if (v.s[i] === id) v.s[i] = "";
        save(p, v);
        var s = SESS[p.uuid];
        if (s && s.id === id) cancel(p);
        if (typeof DMZ_SKILLS !== "undefined" && DMZ_SKILLS.owned(p, id)) {         // DeleteTechniqueC2S also removes the skill
            var map = DMZ_SKILLS.levels(p);
            delete map[id];
            p.setVar("dmz_skills", map);
            DMZ_SKILLS.sendState(p);
        }
        sendState(p);
        return true;
    }
    function clearAll(p) {
        cancel(p);
        save(p, { u: {}, s: ["", "", "", "", "", "", "", ""], fl: null });
        p.setVar("dmz_tech_cd", null);
        sendState(p);
    }

    // ---------------------------------------------------------------------------------
    //  equipping (Techniques.equipOrSwapTechnique + EquipTechniqueC2S rules)
    // ---------------------------------------------------------------------------------
    function equip(p, slot, id) {
        slot = Math.floor(Number(slot));
        id = String(id || "");
        if (!(slot >= 0 && slot < N)) return false;
        var v = load(p);
        if (v.fl && slot < TD.OOZARU_LOADOUT.length) return false;                     // the form loadout owns these
        if (id === TD.REVIVE_ID || v.s[slot] === TD.REVIVE_ID) return false;
        if (id) {
            if (TD.exists(id)) {
                if (!v.u[id]) return false;
                if (!raceAllowed(p, id)) return false;
            } else if (!(RPG.skills.exists(id) && p.hasSkill(id))) return false;       // older non-DMZ skills still fit
        }
        var existing = -1;
        for (var i = 0; i < N; i++) if (id && v.s[i] === id) { existing = i; break; }
        if (existing >= 0) { var tmp = v.s[slot]; v.s[slot] = id; v.s[existing] = tmp; }
        else v.s[slot] = id;
        save(p, v);
        sendState(p);
        return true;
    }

    // ---- Oozaru loadout (Techniques.applyFormLoadout / restoreFormLoadout) ----
    function applyLoadout(p) {
        var v = load(p), L = TD.OOZARU_LOADOUT, changed = false;
        if (!v.fl) { v.fl = { b: v.s.slice(0, L.length), g: [] }; changed = true; }
        L.forEach(function (id, i) {
            if (!v.u[id]) { v.u[id] = { x: 0, d: 0, c: 0, r: 0 }; v.fl.g.push(id); changed = true; }
            if (v.s[i] !== id) {
                for (var j = 0; j < N; j++) if (j !== i && v.s[j] === id) v.s[j] = "";
                v.s[i] = id; changed = true;
            }
        });
        if (changed) { save(p, v); sendState(p); }
    }
    function restoreLoadout(p) {
        var v = load(p);
        if (!v.fl) return;
        var g = v.fl.g || [], b = v.fl.b || [];
        g.forEach(function (id) { delete v.u[id]; var s = SESS[p.uuid]; if (s && s.id === id) cancel(p); });
        for (var j = TD.OOZARU_LOADOUT.length; j < N; j++) if (g.indexOf(v.s[j]) >= 0) v.s[j] = "";
        for (var i = 0; i < TD.OOZARU_LOADOUT.length; i++) v.s[i] = b[i] && (v.u[b[i]] || !TD.exists(b[i])) ? b[i] : "";
        v.fl = null;
        save(p, v);
        sendState(p);
    }
    function inOozaru(p) {
        if (typeof DMZ_TF === "undefined" || !DMZ_TF.activeForm) return false;
        var f = DMZ_TF.activeForm(p);
        return !!f && f.group === "oozaru";
    }

    // ---------------------------------------------------------------------------------
    //  using a slot (ClientStatsEvents.handleTechniqueSlotInput + server checks)
    // ---------------------------------------------------------------------------------
    function handEmpty(p) { var h = p.getHeldItem(); return !h || h === "minecraft:air"; }
    function canActivate(p, id) {
        if (p.getGameMode && p.getGameMode() === "spectator") return false;
        if (p.hasEffect("stunned")) return false;
        if (skillLevel(p, "kicontrol") <= 0) { msg(p, "message.dragonminez.technique.no_ki_control"); return false; }
        if (release(p) < 5) return false;
        var S = TD.STRIKE[id];
        if (S && S.needsItem) return holding(p, S.needsItem);
        if (S && S.heldItemOk) return true;
        return handEmpty(p);
    }
    function press(p, slot) {
        if (!p.getVar("dmz_created", 0)) return;
        if (SESS[p.uuid]) return;                                  // a charge session owns the keys
        var id = load(p).s[slot];
        if (!id) return;
        if (!TD.exists(id)) {                                      // an older script skill in the slot
            if (RPG.skills.exists(id) && p.hasSkill(id)) { p.castSkill(id); RPG.schedule(1, function () { sendState(p); }); }
            return;
        }
        if (!has(p, id) || !canActivate(p, id)) return;
        cast(p, id, slot);
    }
    function releaseKey(p, slot) {
        var s = SESS[p.uuid];
        if (s && s.slot === slot) s.holding = false;
    }
    function cast(p, id, slot) {
        var k = TD.kind(id);
        if (k === "strike") castStrike(p, id);
        else if (k === "evasion") castEvasion(p, id);
        else if (k === "ki") startCharge(p, id, slot === undefined ? -1 : slot);
    }

    // ---------------------------------------------------------------------------------
    //  ki attacks: the charge state machine (TickHandler.handleTechniqueCharge)
    // ---------------------------------------------------------------------------------
    function castOrigin(id) {
        if (id === "spiritbomb") return { forward: 0.5, up: 5.5, side: 0 };
        if (id === "supernova" || id === "supernova_cooler") return { forward: 0.5, up: 2.5, side: 0 };
        if (id === "masenko") return { forward: 0.2, up: 0.9, side: 0 };
        if (id === "final_flash") return { forward: 2.5, up: -0.15, side: 0 };
        if (id === "makkanko") return { forward: 0.5, up: 0.25, side: -0.2 };
        if (id === "mouth_blast") return { forward: 0.3, up: -0.25, side: 0 };
        return null;
    }
    function castProjectile(T) {
        switch (T.type) {
            case "MEDIUM_BALL": case "GIANT_BALL": return "dmz_tech_ball";
            case "WAVE": return "dmz_tech_wave";
            case "BEAM": return "dmz_tech_beam";
            case "DISK": return "dmz_tech_disk";
            default: return "dmz_tech_ball";                       // barrage / explosion: a glowing orb in the hands
        }
    }
    function startCharge(p, id, slot) {
        var T = TD.KI[id], K = TD.TYPES[T.type];
        if (cdLeft(p, id) > 0) return;
        if (K.restrict && p.vehicle) return;
        var lock = lockedTarget(p);
        if (id === "hellzone_grenade" && !(lock || p.target(48))) { msg(p, "message.dragonminez.hellzone_grenade.no_target"); return; }
        var size = TD.castSize(id, view(p).stat("PWR"), transformed(p));
        var s = { p: p, id: id, slot: slot, pct: 0, holding: slot >= 0, accum: 0, lock: lock, size: size, base: TD.kiCost(id, kiNoForms(p)),
            proj: null, ticks: 0, out: false };
        if (K.cast > 0) {
            var over = { hold: true, size: Math.max(0.15, size * 0.1), damage: 0, colors: T.colors,
                chargeGrow: { from: Math.max(0.15, size * 0.1), to: visualSize(T, size), ticks: K.cast } };
            if (T.type === "BARRAGE" || T.type === "EXPLOSION") { over.chargeGrow.to = 0.6; }
            var o = castOrigin(id);
            if (o) over.origin = o;
            s.proj = p.shoot(castProjectile(T), over);
            var ca = TD.castAnim(id);
            if (ca) act(p, ca, 600);
        }
        sfx(p, T.chargeSound, id === "burning_attack" ? 4.0 : 0.7, T.type === "DISK" ? 1.2 : 1.0);
        if (K.restrict) p.addEffect("dmz_tech_rooted", -1);
        SESS[p.uuid] = s;
    }
    // engine size for the shot (balls: DMZ size is a diameter-ish scale; beams: damage radius = size x 1.5)
    function visualSize(T, size) {
        switch (T.type) {
            case "WAVE": return size * 1.5;
            case "BEAM": return Math.max(0.5, size);
            case "MEDIUM_BALL": return Math.max(0.4, size * 0.6);
            case "GIANT_BALL": return Math.max(2, size * 0.6);
            case "DISK": return Math.max(0.8, size * 1.2);
            default: return size;
        }
    }
    function cancel(p) {
        var s = SESS[p.uuid];
        delete SESS[p.uuid];
        if (s) {
            if (s.proj && s.proj.alive) s.proj.discard();
            stopAct(p);
            RPG.net.send(p, "dmz_tech_charge", { pct: 0, id: "", c: false });
        }
        p.removeEffect("dmz_tech_rooted");
        var f = FIRING[p.uuid];
        if (f) { delete FIRING[p.uuid]; }
    }
    function isCharging(p) { return !!SESS[p.uuid]; }

    function tickCharge(s) {
        var p = s.p;
        if (!p.isAlive() || p.hasEffect("stunned")) { cancel(p); return; }
        var T = TD.KI[s.id], K = TD.TYPES[T.type], instant = K.cast === 0;
        var ceil = (s.holding && !instant) ? TD.OVERCHARGE_MAX : 100, bt = Math.max(1, K.cast);
        s.ticks++;
        if (s.pct < ceil - 0.001) {
            var rate = (s.pct < 100 ? 100 : 25) / bt;
            var np = Math.min(ceil, s.pct + rate);
            var cost = creative(p) ? 0 : 0.5 * s.base * (TD.costMultiplier(np) - TD.costMultiplier(s.pct)) * costMod(p);
            // paid as whole points, the fraction carried over (DMZ accumulates the fractional cost too)
            var ki = p.resource("ki"), owed = s.accum + cost, whole = Math.floor(owed);
            if (ki >= whole) { if (whole > 0) p.addResource("ki", -whole); s.accum = owed - whole; s.pct = np; }
            else { s.pct += (np - s.pct) * (whole > 0 ? ki / whole : 1); p.setResource("ki", 0); s.out = true; }
        }
        if (s.ticks % 2 === 0 && !instant) RPG.net.send(p, "dmz_tech_charge", { pct: Math.round(s.pct * 10) / 10, id: s.id, c: s.holding });
        var fire = K.full ? (s.pct >= ceil - 0.01 || s.out) : (!s.holding || s.out);
        if (fire) releaseCharge(s);
    }

    function releaseCharge(s) {
        var p = s.p, T = TD.KI[s.id], K = TD.TYPES[T.type], instant = K.cast === 0;
        delete SESS[p.uuid];
        RPG.net.send(p, "dmz_tech_charge", { pct: 0, id: "", c: false });
        var eff = Math.min(s.pct, TD.OVERCHARGE_MAX), ch = eff / 100;
        if (!instant && eff < 10) {                                 // fizzles: the charge ki is lost, no cooldown
            if (s.proj && s.proj.alive) s.proj.discard();
            p.removeEffect("dmz_tech_rooted");
            stopAct(p);
            return;
        }
        var r = rec(p, s.id) || {};
        var c = TD.clamp(ch, 0.1, 2);
        var dmg = kiDamage(p) * T.dmg * c * dmgMod(p);
        var life = Math.max(20, Math.floor(K.life * c));
        var ok = execute(p, s, dmg, life, ch);
        if (ok === false) { p.removeEffect("dmz_tech_rooted"); stopAct(p); return; }
        setCd(p, s.id, creative(p) ? 60 : TD.kiCooldown(s.id, ch, r.c));
        if (!creative(p)) {
            var fireFrac = K.restrict ? 0.25 : 0.5;
            var pay = Math.round(fireFrac * s.base * TD.costMultiplier(eff) * costMod(p));
            p.addResource("ki", -Math.min(pay, p.resource("ki")));
        }
        if (K.restrict) {
            var drain = creative(p) ? 0 : 0.25 * s.base * TD.costMultiplier(eff) * costMod(p) / life;
            var f = FIRING[p.uuid] || {};
            f.until = RPG.server.getTick() + life;
            f.drain = drain;
            f.p = p;
            FIRING[p.uuid] = f;
        } else p.removeEffect("dmz_tech_rooted");
        sfx(p, T.fireSound, s.id === "kill_driver" ? 2.5 : 0.7, s.id === "kill_driver" ? 0.8 : T.type === "DISK" ? 1.5 : 1.0);
        var fireAnim = T.anim + "_fire";
        act(p, fireAnim, K.restrict ? life : (s.id === "emperor_death_beam" ? 14 : s.id === "dodonpa" ? 12 : 12));
        sendState(p);
    }

    function aimAt(proj, from, to) {
        var dx = to.x - from.x, dy = (to.y + 1) - from.y, dz = to.z - from.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
        proj.setDirection(dx / l, dy / l, dz / l);
        return { x: dx / l, y: dy / l, z: dz / l };
    }
    function homing(T, s, proj) {
        if (s.lock && TD.TYPES[T.type].home && proj && s.lock.isAlive()) proj.homeAt(s.lock, 0.2, 120);
    }
    function spread(dir, deg) {
        var a = deg * Math.PI / 180;
        var x = dir.x + (Math.random() * 2 - 1) * a, y = dir.y + (Math.random() * 2 - 1) * a, z = dir.z + (Math.random() * 2 - 1) * a;
        var l = Math.sqrt(x * x + y * y + z * z) || 1;
        return { x: x / l, y: y / l, z: z / l };
    }
    function lookDir(p) {
        var yaw = p.yaw * Math.PI / 180, pitch = p.pitch * Math.PI / 180;
        return { x: -Math.sin(yaw) * Math.cos(pitch), y: -Math.sin(pitch), z: Math.cos(yaw) * Math.cos(pitch) };
    }

    // TechniqueDispatcher.executeKiAttack + the per-technique handlers (KiTechniqueHandler)
    function execute(p, s, dmg, life, ch) {
        var T = TD.KI[s.id], vsize = visualSize(T, s.size), speed = T.speed;
        var proj = s.proj && s.proj.alive ? s.proj : null;
        switch (T.type) {
            case "MEDIUM_BALL":
            case "GIANT_BALL": {
                if (!proj) proj = p.shoot("dmz_tech_ball", { size: vsize, colors: T.colors, damage: 0 });
                if (!proj) return false;
                var giant = T.type === "GIANT_BALL";
                proj.setVar("dmg", dmg);
                proj.setVar("tech", s.id);
                proj.setVar("r", giant ? Math.max(s.size * 1.5, 5) : Math.max(s.size * 0.5, 2.5));
                if (giant) proj.setVar("endBoom", 1);
                if (s.id === "soul_punisher") proj.setVar("noBlock", 1);
                if (s.id === "fake_moon") {
                    // no damage: climbs 30 blocks at 1 block/tick and glows there (Oozaru trigger is not ported)
                    proj.setVar("dmg", 0);
                    proj.fire({ speed: 1, lifetime: 30, size: vsize });
                    proj.setVelocity(0, 1, 0);
                    RPG.schedule(30, function () { RPG.world.particle(p.dimension, "minecraft:end_rod", p.x, p.y + 31, p.z, 40, 2, 0.02); });
                    return true;
                }
                proj.fire({ speed: speed, lifetime: life, size: vsize });
                homing(T, s, proj);
                return true;
            }
            case "WAVE": {
                if (!proj) proj = p.shoot("dmz_tech_wave", { size: vsize, colors: T.colors, damage: 0 });
                if (!proj) return false;
                proj.setVar("dmg", dmg);
                proj.setVar("hits", Math.max(1, Math.floor(life / 20)));
                proj.setVar("r", s.size * 4);
                var over = { speed: speed, duration: life, size: vsize };
                if (s.id === "mouth_blast") over.steerRate = 2.5;
                proj.fire(over);
                if (s.id === "heat_dome") {
                    // the closest target in front (8 blocks) is launched, then the dome fires upward
                    var best = null, bd = 99, look = lookDir(p);
                    p.nearby(8).forEach(function (e) {
                        if (p.isAlly(e)) return;
                        var dx = e.x - p.x, dz = e.z - p.z, l = Math.sqrt(dx * dx + dz * dz) || 1;
                        var fl = Math.sqrt(look.x * look.x + look.z * look.z) || 1;
                        if ((dx / l) * (look.x / fl) + (dz / l) * (look.z / fl) < 0.3) return;
                        var d = p.distanceTo(e);
                        if (d < bd) { bd = d; best = e; }
                    });
                    if (best) best.setVelocity((p.x - best.x) * 0.09, 1.6, (p.z - best.z) * 0.09);
                    proj.setDirection(0, 1, 0);
                }
                return true;
            }
            case "BEAM": {
                if (!proj) proj = p.shoot("dmz_tech_beam", { size: vsize, colors: T.colors, damage: 0 });
                if (!proj) return false;
                proj.setVar("dmg", dmg);
                proj.setVar("hits", Math.max(1, Math.floor(life / 20)));
                proj.fire({ speed: speed, duration: life, size: vsize });
                return true;
            }
            case "LASER": {
                var lsize = s.id === "kikoho" ? 2.4 : Math.max(0.3, T.size * (s.id === "emperor_death_beam" ? 1.75 : 1) * 0.6);
                var shootLaser = function (amount, sz) {
                    return p.shoot("dmz_tech_laser", { size: sz, colors: T.colors, damage: amount, speed: Math.max(8, speed * 8) });
                };
                if (s.id === "dodonpa") { RPG.schedule(2, function () { if (p.isAlive()) shootLaser(dmg, lsize); }); return true; }
                shootLaser(dmg, lsize);
                if (s.id === "emperor_death_beam") {
                    // chain: 10 shots in all, one every 7 ticks; follow-ups deal 20 %
                    times(9, function (i) {
                        RPG.schedule(7 * (i + 1), function () {
                            if (!p.isAlive()) return;
                            shootLaser(dmg * 0.2, lsize);
                            sfx(p, "laserbeam", 0.6, 1.1);
                            act(p, "ki.emperor_laser_fire", 8);
                        });
                    });
                }
                return true;
            }
            case "DISK": {
                if (!proj) proj = p.shoot("dmz_tech_disk", { size: vsize, colors: T.colors, damage: dmg });
                if (!proj) return false;
                var dsz = s.id === "kill_driver" ? 4 * TD.clamp(s.size, 0.75, 1.5) * 0.6 : vsize;
                proj.set("damage", dmg);
                if (s.id === "kill_driver") { proj.setVar("boom", 1); proj.setVar("r", 5.5); proj.setVar("dmg", dmg); }
                proj.fire({ speed: Math.max(0.6, speed), lifetime: life, size: dsz, damage: dmg });
                homing(T, s, proj);
                if (s.id === "kienzan_doble") {
                    var left = p.shoot("dmz_tech_disk", { size: vsize, colors: T.colors, damage: dmg, speed: speed, lifetime: life, origin: { forward: 0.2, up: 0.25, side: -0.8 } });
                    if (left) homing(T, s, left);
                    proj.set("speed", speed * 1.5);
                }
                return true;
            }
            case "BARRAGE": {
                if (proj) proj.discard();
                return barrage(p, s, T, dmg, life, ch);
            }
            case "EXPLOSION": {
                if (proj) proj.discard();
                // life sacrifice: HP drops to 5 %, damage x (1 + f x 1.8), radius x (1 + f x 0.8) (KiExplosionEntity)
                var maxHp = p.maxHealth, f = TD.clamp((p.health - maxHp * 0.05) / maxHp, 0, 1);
                p.setHealth(Math.max(1, maxHp * 0.05));
                var radius = Math.min(32, s.size * (1 + f * 0.8));
                var total = dmg * (1 + f * 1.8);
                times(4, function (i) {
                    RPG.schedule(1 + i * 3, function () {
                        var rr = radius * (i + 1) / 4;
                        DMZ_TECH_PROJ.hurtAround(p, p.x, p.y + 1, p.z, rr, i === 3 ? total : 0);
                        RPG.world.particle(p.dimension, "minecraft:explosion_emitter", p.x + (Math.random() - 0.5) * rr, p.y + 1, p.z + (Math.random() - 0.5) * rr, 2, rr * 0.4, 0);
                    });
                });
                sfx(p, "ki_explosion_impact", 3, 0.6);
                return true;
            }
        }
        return false;
    }

    // BARRAGE techniques: ki barrage emitter, assault rain, blaster meteor, hellzone grenade
    function barrage(p, s, T, dmg, life, ch) {
        var target = s.lock || p.target(s.id === "hellzone_grenade" ? 48 : 40);
        if (s.id === "ki_barrage") {
            // every 2 ticks, 5 small balls (size 0.8, full damage each, spread 6 degrees) while it lasts
            FIRING[p.uuid] = { until: RPG.server.getTick() + life, drain: 0, p: p,
                emitter: function (age) {
                    if (age % 2 !== 0) return;
                    var dir = lookDir(p);
                    times(5, function () {
                        var b = p.shoot("dmz_tech_bullet", { damage: dmg, colors: T.colors, size: 0.4, lifetime: 100, speed: T.speed });
                        if (b) { var d = spread(dir, 6); b.setDirection(d.x, d.y, d.z); b.setVelocity(d.x * T.speed, d.y * T.speed, d.z * T.speed); }
                    });
                    sfx(p, "kiblast_shoot", 0.1, 1.6 + Math.random() * 0.5);
                } };
            return true;
        }
        if (s.id === "assault_rain") {
            var c = target ? { x: target.x, y: target.y, z: target.z } : lookPoint(p, 40);
            times(3, function () { var up = p.shoot("dmz_tech_bullet", { damage: 0, colors: T.colors, speed: 1.8, lifetime: 12 }); if (up) { up.setDirection(0, 1, 0); up.setVelocity(0, 1.8, 0); } });
            var waves = Math.max(2, Math.floor(life / 10));
            times(waves, function (w) {
                RPG.schedule(10 + w * 10, function () {
                    times(4, function () {
                        var a = Math.random() * Math.PI * 2, r = Math.random() * 6;
                        var x = c.x + Math.cos(a) * r, z = c.z + Math.sin(a) * r;
                        var b = RPG.world.shootFrom(p.dimension, x, c.y + 22, z, 0.15 * (Math.random() - 0.5), -1, 0.15 * (Math.random() - 0.5), "dmz_tech_bullet",
                            { damage: dmg, size: 0.8, colors: T.colors, speed: 1.5, lifetime: 60 }, p);
                        if (b) { b.setVar("dmg", dmg); }
                    });
                });
            });
            return true;
        }
        if (s.id === "blaster_meteor") {
            // 8 orbs rise around the caster, then fire (2 at the target, the rest along the aim)
            times(8, function (i) {
                var a = i / 8 * Math.PI * 2;
                var x = p.x + Math.cos(a) * 1.5, z = p.z + Math.sin(a) * 1.5;
                var orb = RPG.world.shootFrom(p.dimension, x, p.y + 1, z, 0, 1, 0, "dmz_tech_ball",
                    { size: 0.8, colors: T.colors, speed: 0.11, lifetime: 200, damage: 0 }, p);
                if (!orb) return;
                orb.setVar("dmg", dmg); orb.setVar("r", 2.5);
                RPG.schedule(36 + i * 2, function () {
                    if (!orb.alive) return;
                    var d = (i < 2 && target && target.isAlive()) ? aimAt(orb, orb, target) : lookDir(p);
                    orb.setDirection(d.x, d.y, d.z);
                    orb.setVelocity(d.x * 1.5, d.y * 1.5, d.z * 1.5);
                    sfx(p, "ki_explosion_impact", 0.8, 1.2);
                });
            });
            return true;
        }
        if (s.id === "hellzone_grenade") {
            if (!target) { msg(p, "message.dragonminez.hellzone_grenade.no_target"); return false; }
            var n = Math.round(18 + 30 * TD.clamp((Math.min(ch, 1.75) - 0.1) / 1.65, 0, 1));
            var shell = 3.5 + 5.5 * TD.clamp((Math.min(ch, 1.75) - 0.1) / 1.65, 0, 1);
            var orbs = [];
            // opening: 4 shots every 2 ticks (15 % of the damage)
            times(4, function (i) { RPG.schedule(i * 2, function () { var b = p.shoot("dmz_tech_bullet", { damage: dmg * 0.15 / 4, colors: T.colors, speed: 1.5 }); }); });
            // scatter: the orbs take their places on a shell around the target
            times(n, function (i) {
                RPG.schedule(7 + Math.floor(i * 21 / n), function () {
                    if (!target.isAlive()) return;
                    var a = Math.random() * Math.PI * 2, b = Math.acos(2 * Math.random() - 1);
                    var x = target.x + shell * Math.sin(b) * Math.cos(a), y = target.y + 1 + Math.abs(shell * Math.cos(b)) * 0.6, z = target.z + shell * Math.sin(b) * Math.sin(a);
                    var o = RPG.world.shootFrom(p.dimension, x, y, z, 0, 0.01, 0, "dmz_tech_orb", { colors: T.colors, size: 0.8, speed: 0.01, lifetime: 140, damage: dmg * 0.4 / n }, p);
                    if (o) orbs.push(o);
                });
            });
            // converge at tick 69
            RPG.schedule(69, function () {
                orbs.forEach(function (o) {
                    if (!o.alive || !target.isAlive()) return;
                    var d = aimAt(o, o, target);
                    o.setVelocity(d.x * 1.2, d.y * 1.2, d.z * 1.2);
                });
            });
            // finale at tick 77: a chain of bursts on the target (45 %)
            RPG.schedule(77, function () {
                if (!target.isAlive()) return;
                DMZ_TECH_PROJ.hurtAround(p, target.x, target.y + 1, target.z, 2.5, dmg * 0.45);
                RPG.world.particle(p.dimension, "minecraft:explosion_emitter", target.x, target.y + 1, target.z, 3, 1.5, 0);
                sfx(target, "ki_explosion_impact", 2, 0.9);
            });
            return true;
        }
        return false;
    }

    // ---------------------------------------------------------------------------------
    //  strikes (StrikeAttackHandler)
    // ---------------------------------------------------------------------------------
    var PUNCH = ["punch1", "punch2", "punch3", "punch4", "punch5", "punch6"];
    function coneTarget(p, range) {
        var look = lookDir(p), best = null, bd = 1e9;
        p.nearby(range).forEach(function (e) {
            if (p.isAlly(e)) return;
            var dx = e.x - p.x, dy = (e.y + 1) - (p.y + 1.6), dz = e.z - p.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
            if ((dx * look.x + dy * look.y + dz * look.z) / l < 0.5) return;           // cone half-angle 60 degrees
            if (l < bd) { bd = l; best = e; }
        });
        return best;
    }
    function addXp(p, id, amount) {
        if (!TD.gainsXp(id)) return;
        var v = load(p);
        if (!v.u[id]) return;
        v.u[id].x = (v.u[id].x || 0) + amount;
        save(p, v);
    }
    function castStrike(p, id) {
        var S = TD.STRIKE[id], r = rec(p, id) || {};
        if (cdLeft(p, id) > 0 || cdLeft(p, "strike_global") > 0) return;
        var cost = TD.strikeCost(id, strikeNoForms(p), r.d) * (S.kiRatio || 1);
        if (!creative(p)) {
            if (p.resource("ki") < cost) { msg(p, "message.dragonminez.technique.no_ki", [Math.ceil(cost)]); return; }
            p.addResource("ki", -cost);
        }
        var range = S.range || (p.isFlying() ? 12 : 6);
        var lock = lockedTarget(p);
        var t = coneTarget(p, range) || (lock && p.distanceTo(lock) <= Math.max(range, 16) ? lock : null);
        var total = strikeDamage(p) * TD.strikeActualMult(id, r.d);
        var dur = S.dur, hits = Math.max(1, Math.ceil(Math.max(20, dur) / 10));
        var per = total * 0.65 / hits, fin = total * 0.35;
        var cd = creative(p) ? 20 : TD.strikeCooldown(id, r.c);
        if (!t && !S.targetless) {
            // a miss: half the cooldown and 40 % of the ki back
            if (!creative(p)) p.addResource("ki", cost * 0.4);
            setCd(p, id, Math.ceil(cd / 2));
            setCd(p, "strike_global", TD.STRIKE_GLOBAL_COOLDOWN);
            p.actionbar("&7No target in range.");
            sendState(p);
            return;
        }
        if (t && !S.stationary && p.distanceTo(t) > 1.6) {
            // appear 1.3 blocks in front of the target, facing it
            var dx = p.x - t.x, dz = p.z - t.z, l = Math.sqrt(dx * dx + dz * dz) || 1;
            var fx = t.x + dx / l * 1.3, fz = t.z + dz / l * 1.3;
            var yaw = Math.atan2(-(t.x - fx), t.z - fz) * 180 / Math.PI;
            p.teleportTo(p.dimension, fx, t.y, fz, yaw, 0);
            sfx(p, "tp_short", 1, 1);
        }
        if (t) {
            var tp = t.asPlayer();                                  // the strike lock
            if (tp) tp.addEffect("stunned", dur); else t.addPotion("minecraft:slowness", dur, 9);
        }
        act(p, S.anim, dur);
        if (S.sound) sfx(p, S.sound, 1, 1);
        function victims() {
            if (t) return t.isAlive() ? [t] : [];
            var at = lookPoint(p, 2);
            return RPG.world.entitiesNear(p.dimension, at.x, at.y - 1, at.z, 3).filter(function (e) {
                try { return e.uuid !== p.uuid && e.isAlive() && !p.isAlly(e); } catch (err) { return false; }
            });
        }
        times(hits, function (i) {
            RPG.schedule(Math.min(dur - 1, 10 * (i + 1)), function () {
                victims().forEach(function (e) {
                    e.damageFrom(per, p, { kind: "strike", ignoreIFrames: true });
                    addXp(p, id, 1);
                    burst(e, "minecraft:crit", 6, 0.3, 0.2);
                });
                sfx(t || p, PUNCH[i % PUNCH.length], 0.9, 1);
            });
        });
        RPG.schedule(Math.max(1, dur), function () {
            victims().forEach(function (e) {
                e.damageFrom(fin, p, { kind: "strike", ignoreIFrames: true });
                addXp(p, id, e.isAlive() ? 1 : 3);
                knockAway(p, e, 1.8, 0.4);
                burst(e, "minecraft:explosion", 1, 0.3, 0.2);
            });
            sfx(t || p, "knockback_character", 1, 1);
            sendState(p);
        });
        setCd(p, id, cd);
        setCd(p, "strike_global", TD.STRIKE_GLOBAL_COOLDOWN);
        sendState(p);
    }

    // ---------------------------------------------------------------------------------
    //  evasions (EvasionAttackHandler)
    // ---------------------------------------------------------------------------------
    function behind(t, dist) {
        var yaw = t.yaw * Math.PI / 180;
        return { x: t.x + Math.sin(yaw) * dist, z: t.z - Math.cos(yaw) * dist };
    }
    function freeAt(dim, x, y, z) {
        return RPG.world.getBlock(dim, Math.floor(x), Math.floor(y), Math.floor(z)) === "minecraft:air"
            && RPG.world.getBlock(dim, Math.floor(x), Math.floor(y) + 1, Math.floor(z)) === "minecraft:air";
    }
    function stepForward(p, dist) {
        var d = lookDir(p), fl = Math.sqrt(d.x * d.x + d.z * d.z) || 1;
        while (dist > 1 && !freeAt(p.dimension, p.x + d.x / fl * dist, p.y, p.z + d.z / fl * dist)) dist--;
        if (dist <= 1) { msg(p, "message.dragonminez.technique.afterimage.no_space"); return false; }
        burst(p, "minecraft:cloud", 12, 0.3, 0.02);
        p.teleport(p.x + d.x / fl * dist, p.y, p.z + d.z / fl * dist);
        return true;
    }
    function loseTrack(p, radius) {
        p.nearby(radius).forEach(function (e) { try { if (!e.isPlayer() && e.target && e.target.uuid === p.uuid) e.target = null; } catch (err) { } });
    }
    function castEvasion(p, id) {
        var E = TD.EVASION[id], r = rec(p, id) || {};
        if (cdLeft(p, id) > 0) return;
        var v = view(p), dur = TD.evasionDuration(id, r.r);
        var cost = TD.evasionCost(id, v.stat("SKP"), v.stat("PWR"), r.r);
        var hit = TD.evasionHit(id, v.stat("SKP"), v.stat("PWR"));
        var lock = lockedTarget(p);
        // targeted evasions check first so a failed cast costs nothing
        if (id === "candy_beam") {
            var ct = lock && p.distanceTo(lock) <= 5 ? lock : coneTarget(p, 5);
            if (!ct) { msg(p, "message.dragonminez.technique.candy_beam.no_target"); return; }
            lock = ct;
        }
        if (!creative(p)) {
            if (p.resource("ki") < cost) { msg(p, "message.dragonminez.technique.no_ki", [Math.ceil(cost)]); return; }
            p.addResource("ki", -cost);
        }
        act(p, id === "afterimage" ? "evs.default" : E.anim, dur);
        switch (id) {
            case "taiyoken": {
                sfx(p, "ki_explosion_charge", 1.2, 1.6);
                RPG.world.particle(p.dimension, "minecraft:flash", p.x, p.y + 1.8, p.z, 1, 0, 0);
                var look = lookDir(p);
                p.nearby(20).forEach(function (e) {
                    if (!p.canSee(e)) return;
                    var ey = e.yaw * Math.PI / 180, ex = -Math.sin(ey), ez = Math.cos(ey);
                    var dx = p.x - e.x, dz = p.z - e.z, l = Math.sqrt(dx * dx + dz * dz) || 1;
                    var dot = (ex * dx + ez * dz) / l;
                    if (dot < 0.5) return;                                   // must be facing the caster
                    var dist = Math.min(20, p.distanceTo(e));
                    var secs = (dot >= 0.93 ? 12 : 9) - 3 * (dist / 20);
                    if (p.isAlly(e)) secs *= 0.5;
                    e.addPotion("minecraft:blindness", Math.round(secs * 20), 0);
                    if (!e.isPlayer()) { try { e.target = null; } catch (err) { } e.addPotion("minecraft:slowness", Math.round(secs * 20), 2); }
                    else RPG.net.send(e.asPlayer(), "dmz_taiyoken", { ticks: Math.round(secs * 20) });
                });
                break;
            }
            case "rage_scream": {
                sfx(p, "oozaru_growl_player", 1.5, 1);
                times(Math.floor(dur / 5), function (i) {
                    RPG.schedule(i * 5, function () {
                        if (!p.isAlive()) return;
                        var rad = 5;
                        p.nearby(rad).forEach(function (e) {
                            if (p.isAlly(e)) return;
                            var fall = 1 - Math.min(1, p.distanceTo(e) / rad);
                            e.damageFrom(Math.max(1, hit), p, { kind: "strike", ignoreIFrames: true });
                            knockAway(p, e, 0.35 * fall, 0.12);
                        });
                        burst(p, "minecraft:sonic_boom", 1, 0, 0);
                    });
                });
                break;
            }
            case "afterimage": {
                var at = lock && p.distanceTo(lock) <= 24 ? lock : null;
                sfx(p, "evasion1", 1, 1);
                if (at) {
                    times(4, function (i) {
                        RPG.schedule(i * 5, function () {
                            if (!at.isAlive() || !p.isAlive()) return;
                            for (var tries = 0; tries < 10; tries++) {
                                var a = Math.random() * Math.PI * 2, hop = 4 + Math.random() * 2;
                                var x = at.x + Math.cos(a) * hop, z = at.z + Math.sin(a) * hop;
                                if (i === 3) { var b = behind(at, 1.5); x = b.x; z = b.z; }
                                if (!freeAt(p.dimension, x, at.y, z)) continue;
                                burst(p, "minecraft:cloud", 8, 0.3, 0.02);
                                var yaw = Math.atan2(-(at.x - x), at.z - z) * 180 / Math.PI;
                                p.teleportTo(p.dimension, x, at.y, z, yaw, 0);
                                sfx(p, "tp_short", 0.8, 1.2);
                                break;
                            }
                        });
                    });
                    loseTrack(p, 16);
                } else if (stepForward(p, 4)) loseTrack(p, 16);
                break;
            }
            case "sleep_recovery": {
                p.addPotion("minecraft:slowness", dur, 6);
                times(Math.floor(dur / 20), function (i) {
                    RPG.schedule((i + 1) * 20, function () {
                        if (!p.isAlive()) return;
                        p.heal(p.maxHealth * 0.10);
                        burst(p, "minecraft:note", 2, 0.3, 0);
                    });
                });
                break;
            }
            case "dimensional_teleport": {
                sfx(p, "tp", 1, 1);
                if (lock && p.distanceTo(lock) <= 64) {
                    RPG.schedule(8, function () {
                        if (!lock.isAlive()) return;
                        var b = behind(lock, 1.5);
                        p.teleportTo(p.dimension, b.x, lock.y, b.z, lock.yaw, 0);
                        sfx(p, "tp_short", 1, 1);
                        burst(p, "minecraft:reverse_portal", 20, 0.4, 0.05);
                    });
                } else stepForward(p, 4);
                break;
            }
            case "candy_beam": {
                RPG.schedule(10, function () {
                    if (!lock.isAlive()) return;
                    p.shoot("candy_beam", { damage: 0 });
                    var lp = lock.asPlayer();
                    if (lp) lp.addEffect("stunned", 60);
                    else { lock.addPotion("minecraft:slowness", 60, 255); try { lock.target = null; } catch (err) { } }
                    RPG.world.particle(lock.dimension, "minecraft:heart", lock.x, lock.y + 1, lock.z, 10, 0.5, 0);
                    sfx(lock, "majin_absorb", 1, 1.4);
                });
                break;
            }
            case "gum_bind": {
                RPG.schedule(10, function () {
                    var gt = lock && p.distanceTo(lock) <= 24 ? lock : p.target(24);
                    if (!gt || !gt.isAlive()) return;
                    var gp = gt.asPlayer();
                    if (gp) { gp.addEffect("stunned", 60); act(gp, "evs.gum_bound", 60); }
                    else gt.addPotion("minecraft:slowness", 60, 255);
                    burst(gt, "minecraft:item_slime", 20, 0.5, 0.1);
                    sfx(gt, "majin_absorb", 1, 0.8);
                });
                break;
            }
        }
        addXp(p, id, 2);
        // the cast evasion gets its own cooldown; every other evasion at least duration + 60
        setCd(p, id, creative(p) ? 20 : TD.evasionCooldown(id, r.c));
        Object.keys(load(p).u).forEach(function (o) {
            if (o === id || TD.kind(o) !== "evasion") return;
            if (cdLeft(p, o) < dur + TD.SHARED_EVASION_COOLDOWN) setCd(p, o, dur + TD.SHARED_EVASION_COOLDOWN);
        });
        sendState(p);
    }

    // ---------------------------------------------------------------------------------
    //  upgrades (UpgradeTechniqueC2S: strikes and evasions; predefined ki attacks can't be)
    // ---------------------------------------------------------------------------------
    function upgrade(p, id, stat) {
        var v = load(p), r = v.u[id];
        if (!r || !TD.canUpgrade(id, stat) || !raceAllowed(p, id)) return false;
        if ((r.x || 0) < TD.MIN_XP_COST) return false;
        r.x -= TD.MIN_XP_COST;
        if (stat === "damage") r.d = (r.d || 0) + 1;
        else if (stat === "cooldown") r.c = (r.c || 0) + 1;
        else if (stat === "duration") r.r = (r.r || 0) + 1;
        save(p, v);
        sendState(p);
        return true;
    }

    // ---------------------------------------------------------------------------------
    //  ticking: charge sessions and firing locks every tick; loadout + legacy migration per second
    // ---------------------------------------------------------------------------------
    RPG.every(1, function () {
        var ids = Object.keys(SESS);
        for (var i = 0; i < ids.length; i++) {
            var s = SESS[ids[i]];
            try { tickCharge(s); } catch (err) { delete SESS[ids[i]]; RPG.log("[DBR] technique charge error: " + err); }
        }
        var f = Object.keys(FIRING);
        if (!f.length) return;
        var now = RPG.server.getTick();
        for (var j = 0; j < f.length; j++) {
            var st = FIRING[f[j]], p = st.p;
            try {
                if (!p.isAlive() || now >= st.until) { delete FIRING[f[j]]; p.removeEffect("dmz_tech_rooted"); if (st.emitter) stopAct(p); continue; }
                if (st.drain > 0) {
                    if (p.resource("ki") <= 0) { delete FIRING[f[j]]; p.removeEffect("dmz_tech_rooted"); continue; }
                    p.addResource("ki", -Math.min(st.drain, p.resource("ki")));
                }
                if (st.emitter) {
                    st.age = (st.age || 0) + 1;
                    if (st.age === 1) act(p, "ki.barrage_fire", st.until - now);
                    st.emitter(st.age);
                }
            } catch (err2) { delete FIRING[f[j]]; }
        }
    });

    var REVERSE = {};
    Object.keys(DMZ_SKILLS_DATA.TECHNIQUES).forEach(function (k) { if (TD.exists(k)) REVERSE[DMZ_SKILLS_DATA.TECHNIQUES[k]] = k; });

    // older saves: techniques bought before this port (DMZ skill levels / our old skills / the skill bar)
    function migrate(p) {
        var v = load(p), changed = false;
        if (typeof DMZ_SKILLS !== "undefined") {
            var lv = DMZ_SKILLS.levels(p);
            Object.keys(lv).forEach(function (s) { if (TD.exists(s) && lv[s] >= 1 && !v.u[s]) { v.u[s] = { x: 0, d: 0, c: 0, r: 0 }; changed = true; } });
        }
        if (!p.getVar("dmz_tech_mig", 0)) {
            Object.keys(REVERSE).forEach(function (ours) {
                if (p.hasSkill(ours) && !v.u[REVERSE[ours]]) { v.u[REVERSE[ours]] = { x: 0, d: 0, c: 0, r: 0 }; changed = true; }
            });
            if (v.s.join("") === "") {
                var bar = p.skillBar, len = !bar ? 0 : bar.length !== undefined ? bar.length : bar.size();
                for (var i = 0; i < N && i < len; i++) {
                    var id = String(bar[i] !== undefined ? bar[i] : bar.get(i) || "");
                    if (!id) continue;
                    if (REVERSE[id] && v.u[REVERSE[id]]) v.s[i] = REVERSE[id];
                    else if (!REVERSE[id] && RPG.skills.exists(id) && p.hasSkill(id)) v.s[i] = id;
                }
                changed = true;
            }
            p.setVar("dmz_tech_mig", 1);
        }
        if (changed) save(p, v);
    }

    RPG.on("playerJoin", function (p) {
        RPG.schedule(45, function () {
            try { if (!p.isAlive()) return; } catch (e) { return; }
            migrate(p);
            sendState(p);
        });
    });
    RPG.on("playerLeave", function (p) { delete SESS[p.uuid]; delete FIRING[p.uuid]; });
    RPG.on("death", function (p) { if (SESS[p.uuid] || FIRING[p.uuid]) cancel(p); });
    RPG.on("playerTick", function (p) {
        if (!p.getVar("dmz_created", 0)) return;
        var oz = inOozaru(p), v = load(p);
        if (oz && !v.fl) applyLoadout(p);
        else if (!oz && v.fl) restoreLoadout(p);
    });

    // ---- client requests (SkillsMenuScreen: bind, delete, upgrade) ----
    RPG.net.on("dmz_tech", function (p, d) {
        if (!d || !p.getVar("dmz_created", 0)) return;
        var a = String(d.action || "");
        if (a === "state") return sendState(p);
        if (a === "equip") { if (!equip(p, d.slot, d.id)) sendState(p); return; }
        if (a === "forget") { if (!forget(p, String(d.id || ""))) sendState(p); return; }
        if (a === "upgrade") { if (upgrade(p, String(d.id || ""), String(d.stat || ""))) p.playSound("dmzpack:pip_menu", 1, 1); else sendState(p); }
    });

    // ---- /rpgc dmztech (DMZ's TechCommand) ----
    function targets(p, name) {
        if (!name) return p ? [p] : [];
        if (name === "@a") return RPG.server.players();
        var t = RPG.server.player(name);
        return t ? [t] : [];
    }
    function tell(p, text) { if (p) p.tell(text); else RPG.log(text.replace(/&./g, "")); }
    RPG.commands.register("dmztech", {
        permission: 2,
        description: "/rpgc dmztech <learn|forget|equip|list|xp|cooldowns> ... - DMZ techniques",
        run: function (p, args) {
            var sub = String(args[0] || "").toLowerCase();
            if (sub === "learn" || sub === "add" || sub === "forget" || sub === "remove") {
                var id = String(args[1] || "").toLowerCase(), who = targets(p, args[2]);
                if (!id || !who.length) return tell(p, "&cUsage: /rpgc dmztech " + sub + " <technique|all> [player]");
                if (id !== "all" && !TD.exists(id)) return tell(p, "&cUnknown technique: " + id);
                var learn = sub === "learn" || sub === "add";
                who.forEach(function (t) {
                    var list = id === "all" ? TD.all() : [id];
                    if (learn) list.forEach(function (x, i) { unlock(t, x, { source: "command", silent: id === "all" && i > 0 }); });
                    else if (id === "all") clearAll(t);
                    else forget(t, id);
                });
                return tell(p, "&a" + (learn ? "Added " : "Removed ") + (id === "all" ? "all techniques" : TD.english(id)) + (learn ? " to " : " from ") + who.length + " player(s).");
            }
            if (sub === "equip") {
                var slot = Math.floor(Number(args[1])) - 1, tid = String(args[2] || "").toLowerCase(), tw = targets(p, args[3]);
                if (!(slot >= 0 && slot < N) || !tid || !tw.length) return tell(p, "&cUsage: /rpgc dmztech equip <slot 1-8> <technique|none> [player]");
                tw.forEach(function (t) {
                    if (tid !== "none" && TD.exists(tid) && !has(t, tid)) unlock(t, tid, { source: "command" });
                    var ok = equip(t, slot, tid === "none" ? "" : tid);
                    tell(p, ok ? "&aSlot " + (slot + 1) + " -> " + (tid === "none" ? "empty" : TD.english(tid)) + " (" + t.name + ")" : "&cCan't equip that for " + t.name + ".");
                });
                return;
            }
            if (sub === "list" || sub === "") {
                var lw = targets(p, args[1]);
                if (!lw.length) return tell(p, "&cNo such player.");
                var t0 = lw[0], v = load(t0);
                tell(p, "&6" + t0.name + "'s techniques (" + Object.keys(v.u).length + "):");
                Object.keys(v.u).forEach(function (x) { tell(p, " &e" + TD.english(x) + " &7(" + x + ", " + (TD.kind(x) || "?") + (TD.gainsXp(x) ? ", " + (v.u[x].x || 0) + " XP" : "") + ")"); });
                tell(p, "&6Slots: &f" + v.s.map(function (x, i) { return (i + 1) + ":" + (x ? TD.english(x) : "-"); }).join("  "));
                return;
            }
            if (sub === "xp" || sub === "experience") {
                var mode = String(args[1] || "").toLowerCase(), xid = String(args[2] || "").toLowerCase(), amt = Math.max(0, Math.floor(Number(args[3]) || 0));
                var xw = targets(p, args[4]);
                if (["add", "set", "remove"].indexOf(mode) < 0 || !xid || !xw.length) return tell(p, "&cUsage: /rpgc dmztech xp <add|set|remove> <technique> <amount> [player]");
                xw.forEach(function (t) {
                    var vv = load(t);
                    if (!vv.u[xid]) return;
                    var x = vv.u[xid].x || 0;
                    vv.u[xid].x = mode === "add" ? x + amt : mode === "set" ? amt : Math.max(0, x - amt);
                    save(t, vv); sendState(t);
                });
                return tell(p, "&aUpdated experience of " + TD.english(xid) + ".");
            }
            if (sub === "cooldowns" || sub === "cd") {
                targets(p, args[1]).forEach(function (t) { t.setVar("dmz_tech_cd", null); sendState(t); });
                return tell(p, "&aTechnique cooldowns cleared.");
            }
            tell(p, "&cUsage: /rpgc dmztech <learn|forget|equip|list|xp|cooldowns> ...");
        },
        suggest: function (p, args) {
            if (args.length <= 1) return ["learn", "forget", "equip", "list", "xp", "cooldowns"];
            var sub = String(args[0]).toLowerCase();
            if ((sub === "learn" || sub === "forget") && args.length === 2) return ["all"].concat(TD.all());
            if (sub === "equip" && args.length === 2) return ["1", "2", "3", "4", "5", "6", "7", "8"];
            if (sub === "equip" && args.length === 3) return ["none"].concat(p ? unlocked(p) : TD.all());
            if (sub === "xp" && args.length === 2) return ["add", "set", "remove"];
            if (sub === "xp" && args.length === 3) return p ? unlocked(p).filter(TD.gainsXp) : TD.STRIKE_IDS.concat(TD.EVASION_IDS);
            return RPG.server.players().map(function (x) { return x.name; });
        }
    });

    return { unlock: unlock, forget: forget, clearAll: clearAll, equip: equip, slots: slots, unlocked: unlocked, has: has,
        press: press, release: releaseKey, cast: function (p, id) { if (has(p, id) && canActivate(p, id)) cast(p, id); },
        isCharging: isCharging, cancel: cancel, sendState: sendState, cooldownLeft: cdLeft, setCooldown: setCd, info: info, migrate: migrate };
})();
