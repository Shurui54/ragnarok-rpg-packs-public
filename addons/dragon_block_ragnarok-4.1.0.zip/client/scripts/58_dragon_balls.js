// =====================================================================================
//  Dragon Balls on the client: the radar (RadarRenderEvent), the wish screen (WishesScreen)
//  and the darkened "dragon sky" while a dragon is summoned.
// =====================================================================================
(function () {
    var RADAR = "dmzpack:textures/gui/radar.png", MENU_BIG = "dmzpack:textures/gui/menu/menubig.png";
    var BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png", FONT = "dmzpack:smooth";
    var radar = { ids: {}, sets: {} }, sky = { on: false, level: 0 };

    RPG.net.on("dmz_radar", function (d) { radar = d || radar; });
    RPG.net.on("dmz_dragon_sky", function (d) { sky.on = !!(d && d.on); });

    function full(id) { return id ? "ragnarok_rpg:" + id : "?"; }
    function setFor(dim, radarName) {
        if (radarName === "fused_dball_radar") return dim === "ragnarok_rpg:namek" ? "namek" : dim === "minecraft:overworld" ? "earth" : null;
        if (radarName === "dball_radar") return dim === "minecraft:overworld" ? "earth" : null;
        if (radarName === "namekdball_radar") return dim === "ragnarok_rpg:namek" ? "namek" : null;
        return null;
    }
    function heldRadar(item) {
        for (var k in radar.ids) if (radar.ids[k] && full(radar.ids[k]) === item) return k;
        return null;
    }

    RPG.hud.onRender(function (ctx) {
        // dragon sky: the world dims while the dragon is here (fades in and out)
        sky.level += ((sky.on ? 1 : 0) - sky.level) * 0.05;
        if (sky.level > 0.01) ctx.fill(0, 0, ctx.width, ctx.height, "#0A0F1E", 0.45 * sky.level);

        var p = RPG.player;
        if (!p.present || RPG.screen.getOpen()) return;
        var main = heldRadar(p.heldItem), off = main ? null : heldRadar(p.offhandItem);
        var which = main || off;
        if (!which) return;
        var setId = setFor(p.dimension, which);
        if (!setId) return;
        var targets = radar.sets[setId] || [], range = Number(RPG.getVar("dmz_radar_range", 150)) || 150;
        var size = 140, cx = main ? ctx.width - size - 10 : 10, cy = ctx.height - size - 10;
        if (!ctx.group(main ? "dmz_radar" : "dmz_radar_offhand", main ? "Dragon Radar" : "Dragon Radar (off hand)", cx, cy, 121, 146)) return;
        ctx.quad(RADAR, cx, cy, 121, 146, 0, 0, 121 / 256, 146 / 256, "#FFFFFF", 1);
        var rx = cx + 61, ry = cy + 87, nearest = 1e9;
        targets.forEach(function (t) {
            var dx = t.x - p.x, dz = t.z - p.z, dist = Math.sqrt(dx * dx + dz * dz);
            nearest = Math.min(nearest, dist);
            var ang = Math.atan2(dz, dx) - (p.yaw * Math.PI / 180 + Math.PI / 2) - Math.PI / 2;
            if (dist <= range) {
                var sd = dist / range * 50;
                ctx.quad(RADAR, rx + sd * Math.cos(ang) - 3, ry + sd * Math.sin(ang) - 3, 6, 6, 130 / 256, 0, 136 / 256, 6 / 256, "#FFFFFF", 1);
            } else {
                ctx.push();
                ctx.translate(rx + 50 * Math.cos(ang), ry + 50 * Math.sin(ang));
                ctx.rotate((ang + Math.PI / 2) * 180 / Math.PI);
                ctx.quad(RADAR, -3.5, -3, 7, 6, 130 / 256, 8 / 256, 137 / 256, 14 / 256, "#FFFFFF", 1);
                ctx.pop();
            }
        });
        if (targets.length && nearest < 1e9)
            ctx.textStyled(RPG.translate("gui.dmzradar.nearest", Math.round(nearest)), rx, cy + 146 - 18, 1, "#D9A441", 1, 0.5, null, null);
        ctx.endGroup();
    });

    // ---- the wish screen ----
    var W = null;          // { dragon, type, count, wishes, dead, picks: [], targets: [], scroll, picker }
    var ROW = 20, VISIBLE = 8;

    RPG.net.on("dmz_wishes", function (d) {
        W = { dragon: d.dragon, type: d.type, count: d.count, wishes: d.wishes || [], dead: d.dead || [], picks: [], targets: [], scroll: 0, picker: -1, pickerPicks: [] };
        RPG.sound("dmzpack:ui_menu_switch", 1, 1);
        openScreen();
    });

    function wishName(w) { return RPG.translate("wish." + (W.type === "shenron" ? "shenron" : "porunga") + "." + w.key + ".name"); }
    function wishDesc(w) { return RPG.translate("wish." + (W.type === "shenron" ? "shenron" : "porunga") + "." + w.key + ".desc"); }
    function badge(i) {
        var out = [];
        W.picks.forEach(function (p, k) { if (p === i) out.push(k + 1); });
        return out.join(",");
    }

    function openScreen() {
        var els = [
            { id: "panel", type: "image", anchor: "center", x: -70, y: -106, w: 141, h: 213, texture: MENU_BIG, texW: 256, texH: 256, u: 0, v: 0, uw: 141, vh: 213 },
            { id: "grant", type: "button", anchor: "bottom", x: -40, y: -30, w: 74, h: 20, texture: BUTTONS, texW: 256, texH: 256, u: 0, v: 28, uw: 74, vh: 20, hoverU: 0, hoverV: 48,
              label: RPG.translate("gui.dragonminez.customization.select"), font: FONT, visible: false, onClick: confirm }
        ];
        for (var i = 0; i < VISIBLE; i++) {
            (function (row) {
                els.push({ id: "row" + row, type: "rect", anchor: "center", x: -60, y: -71 + row * ROW, w: 116, h: ROW, color: "#00000000", hoverColor: "#80555555",
                    onClick: function () { clickRow(row + W.scroll); } });
            })(i);
        }
        RPG.screen.open({ id: "dmz_wishes", referenceHeight: 360, background: "dim", elements: els, onRender: render,
            onScroll: function (x, y, delta) { scroll(delta < 0 ? 1 : -1); } });
    }

    function scroll(n) {
        var max = Math.max(0, (W.picker >= 0 ? W.dead.length : W.wishes.length) - VISIBLE);
        W.scroll = Math.max(0, Math.min(max, W.scroll + n));
    }

    function clickRow(i) {
        if (W.picker >= 0) {
            if (i >= W.dead.length) return;
            var id = W.dead[i].id, at = W.pickerPicks.indexOf(id);
            var max = W.wishes[W.picks[W.picker]].targets;
            if (at >= 0) W.pickerPicks.splice(at, 1);
            else if (W.pickerPicks.length < max) W.pickerPicks.push(id);
            RPG.sound("dmzpack:pip_menu", 1, 1);
            return;
        }
        if (i >= W.wishes.length) return;
        var w = W.wishes[i];
        if (w.targets > 0 && W.dead.length === 0) return;               // nobody to revive
        var last = W.picks.lastIndexOf(i);
        if (last >= 0 && !w.repeatable) { W.picks.splice(last, 1); W.targets.splice(last, 1); }
        else if (W.picks.length < W.count) { W.picks.push(i); W.targets.push([]); }
        else if (last >= 0) { W.picks.splice(last, 1); W.targets.splice(last, 1); }
        RPG.sound("dmzpack:pip_menu", 1, 1);
    }

    function confirm() {
        if (W.picker >= 0) {
            if (!W.pickerPicks.length) return;
            W.targets[W.picker] = W.pickerPicks.slice();
            W.picker = -1; W.pickerPicks = []; W.scroll = 0;
        } else if (W.picks.length !== W.count) return;
        for (var k = 0; k < W.picks.length; k++) {
            if (W.wishes[W.picks[k]].targets > 0 && !W.targets[k].length) { W.picker = k; W.pickerPicks = []; W.scroll = 0; return; }
        }
        RPG.net.send("dmz_grant", { dragon: W.dragon, picks: W.picks, targets: W.targets });
        RPG.sound("dmzpack:confirm_menu", 1, 1);
        RPG.screen.close();
        W = null;
    }

    function render(ctx) {
        if (!W) return;
        var cx = ctx.width / 2, top = ctx.height / 2 - 106;
        var picking = W.picker >= 0;
        var title = picking ? RPG.translate("gui.dragonminez.wishes.revive_title", W.pickerPicks.length, W.wishes[W.picks[W.picker]].targets)
                            : RPG.translate("gui.dragonminez.wishes_title", W.picks.length, W.count);
        ctx.textStyled(title, cx, top + 18, 1, "#FFD700", 1, 0.5, FONT, "#000000");
        var list = picking ? W.dead : W.wishes, hover = -1;
        for (var r = 0; r < VISIBLE; r++) {
            var i = r + W.scroll;
            if (i >= list.length) break;
            var y = top + 35 + r * ROW, x = cx - 60;
            var selected = picking ? W.pickerPicks.indexOf(list[i].id) >= 0 : badge(i) !== "";
            if (selected) { ctx.fill(x, y, 116, ROW, "#D4AF37", 0.5); ctx.fill(x, y, 116, 1, "#FFD700", 1); ctx.fill(x, y + ROW - 1, 116, 1, "#FFD700", 1); }
            var disabled = !picking && list[i].targets > 0 && W.dead.length === 0;
            var name = picking ? list[i].name : wishName(list[i]);
            ctx.textStyled(name, x + 4, y + 6, 1, disabled ? "#8A8A8A" : "#FFFFFF", 1, 0, FONT, null);
            if (!picking && badge(i)) ctx.textStyled(badge(i), x + 112, y + 6, 1, "#FFE680", 1, 1, FONT, null);
            if (ctx.mouseX >= x && ctx.mouseX < x + 116 && ctx.mouseY >= y && ctx.mouseY < y + ROW) hover = i;
        }
        // scrollbar
        if (list.length > VISIBLE) {
            var barH = VISIBLE * ROW, th = Math.max(20, barH * VISIBLE / list.length), ty = top + 35 + (barH - th) * W.scroll / (list.length - VISIBLE);
            ctx.fill(cx + 58, top + 35, 3, barH, "#000000", 0.5);
            ctx.fill(cx + 58, ty, 3, th, "#E8D0A1", 1);
        }
        RPG.screen.update("grant", { visible: picking ? W.pickerPicks.length > 0 : W.picks.length === W.count,
            label: RPG.translate(picking ? "gui.dragonminez.wishes.revive_confirm" : "gui.dragonminez.customization.select") });
        // description of the hovered wish
        if (!picking && hover >= 0) {
            var desc = wishDesc(W.wishes[hover]), words = desc.split(" "), lines = [], line = "";
            words.forEach(function (wd) { if ((line + " " + wd).length > 34) { lines.push(line); line = wd; } else line = line ? line + " " + wd : wd; });
            if (line) lines.push(line);
            var bx = ctx.mouseX + 10, by = ctx.mouseY, bw = 190, bh = lines.length * 10 + 6;
            if (bx + bw > ctx.width) bx = ctx.mouseX - bw - 10;
            ctx.fill(bx, by, bw, bh, "#100010", 0.9);
            lines.forEach(function (l, k) { ctx.textStyled(l, bx + 4, by + 4 + k * 10, 1, "#FFFFFF", 1, 0, null, null); });
        }
    }
})();
