// =====================================================================================
//  DMZ's NPC dialogue (client/gui/dialogue/NpcDialogueScreen + NpcDialogueContent +
//  MasterServices + OptionColumn + Typewriter) and the master's TP skill shop
//  (client/gui/MastersSkillsScreen), drawn with DMZ's own sprite sheet and language lines.
//  The server side is scripts/61_dmz_masters.js ("dmz_npc_open", "dmz_npc", "dmz_npc_result").
// =====================================================================================
var MASTERS_SCREEN = (function () {
    var U = DMZ_UI, MD = DMZ_MASTERS_DATA, SD = DMZ_SKILLS_DATA, FONT = U.FONT;
    var SHEET = "dmzpack:textures/gui/menu/npcdialogue.png";
    var LINES = "gui.dragonminez.lines.", STAGE = "dialogue.dragonminez.story.sidequest.", GENERIC = "gui.dragonminez.dialogue.reply.";
    // DialogueSkin colours
    var ACCENT = "#7CFDD6", METAL = "#D2D7F1", TEXT = "#FFFFFF", MUTED = "#8A8A94", OFFER = "#9BE564", TURN_IN = ACCENT, PROGRESS = "#FFD54A",
        DANGER_TEXT = "#FF7A66", BAND = "#050B06";
    var ROW = { NORMAL: 0, HOVER: 1, DISABLED: 2, PRIMARY: 3, DANGER: 4, SELECTED: 5 };
    var ICON = { NONE: -1, OFFER: 0, TURN_IN: 1, PROGRESS: 2, LOCK: 3, CLOCK: 4, CHEVRON: 5, DOWN: 6, CHECK: 7 };
    // NpcDialogueScreen layout
    var MARGIN = 16, GAP = 14, TEXT_MAX_W = 420, TEXT_TOP = 14, LINE_H = 11, TAB_RISE = 15, FOOTER_W = 88, FOOTER_H = 20, FOOTER_BOTTOM = 8,
        FOOTER_GAP = 6, OPTIONS_TOP = 12, INPUT_H = 18, INPUT_W = 150, MIN_BAND_H = 118, SHADOW_H = 28, BAND_SHARE = 0.35, NAME_SCALE = 1.15,
        OPEN_MS = 380, CLOSE_MS = 200, DIM_ALPHA = 0.32, COL_W = 150, ROW_H = 20, ROW_STEP = 24;
    // Typewriter (68 chars/s, sentence/clause pauses, start delay)
    var CHAR_MS = 1000 / 68, SENTENCE_MS = 240, CLAUSE_MS = 85, START_MS = 110;

    var D = null;            // the open dialogue

    // ---- text --------------------------------------------------------------------------------
    function tr(key) { return U.tr.apply(null, arguments); }
    function has(key) { return RPG.hasTranslation(key); }
    function name() { return RPG.player.name; }
    /** DialogueReplies.pickKey: base + base.1..9 that exist, one at random */
    function pickKey() {
        var pool = [];
        for (var a = 0; a < arguments.length; a++) {
            var b = arguments[a];
            if (has(b)) pool.push(b);
            for (var i = 1; i <= 9; i++) if (has(b + "." + i)) pool.push(b + "." + i);
        }
        return pool.length ? pool[Math.floor(Math.random() * pool.length)] : null;
    }
    function pick(slot) {
        if (D.picks[slot] !== undefined) return D.picks[slot];
        return (D.picks[slot] = pickKey.apply(null, Array.prototype.slice.call(arguments, 1)));
    }
    function reason(r) { return r ? tr.apply(null, r) : ""; }
    function reply(event, args) {
        var key = pickKey(LINES + D.npc + ".reply." + event) || pickKey(GENERIC + event) || pickKey(GENERIC + "done") || GENERIC + "done.1";
        return tr.apply(null, [key].concat(args || []));
    }
    function stageLine(stage) { var own = STAGE + D.npc + "." + stage; return tr(has(own) ? own : STAGE + "generic_npc." + stage); }
    function npcName(id) {
        var m = MD.MASTERS[id];
        var keys = m && m.model ? ["entity.dragonminez." + m.model] : [];
        if (id === "baba_earth") keys.unshift("entity.dragonminez.master_uranai_earth");
        if (id === "world_tournament_announcer") keys.unshift("entity.dragonminez.saga_world_tournament_announcer");
        if (id === "beerus" || id === "whis") keys.push("entity.dragonminez.master_" + id);
        keys.push("entity.dragonminez.questnpc." + id, LINES + id + ".name");
        for (var i = 0; i < keys.length; i++) if (has(keys[i])) return tr(keys[i]);
        var q = MD.QUEST_NPCS[id];
        if (m) return m.name;
        if (q) return q.name;
        return id.split(/[_ ]+/).map(function (w) { return w.charAt(0).toUpperCase() + w.substring(1); }).join(" ");
    }

    // ---- state helpers ---------------------------------------------------------------------------
    function st() { return D.st || {}; }
    function align() { var a = st().align; return typeof a === "number" ? a : 100; }
    function cdLeftMs(key) { var end = D.cdEnd[key]; return end ? Math.max(0, end - RPG.nowMs()) : 0; }
    function healthy() {
        var p = RPG.player;
        return p.health >= p.maxHealth - 0.5 && p.resource("ki") >= p.resourceMax("ki") - 0.5 && p.resource("stamina") >= p.resourceMax("stamina") - 0.5;
    }
    function alignmentLock() { return D.master ? MD.masterBlocker(align(), D.npc) : null; }
    function disliked() { return !!alignmentLock() || (D.master && MD.dislikes(D.npc, align())); }
    function hasQuest(s) { return D.quests.some(function (q) { return status(q) === s; }); }
    function status(q) { return q.s === "COOLDOWN" && q.endMs && RPG.nowMs() >= q.endMs ? "OFFER" : q.s; }

    // ---- options (DialogueOption) -----------------------------------------------------------------
    function opt(id, label, run) { return { id: id, label: label, run: run, icon: ICON.NONE, iconColor: METAL, tone: "NORMAL", enabled: true }; }
    function lock(o, lines, onLocked) { o.locked = { title: tr("gui.dragonminez.dialogue.locked"), lines: lines }; if (onLocked) o.lockedAction = onLocked; return o; }
    function available(o) { return o.enabled && !o.locked && !(o.cooldown && o.cooldown() > 0) && !(o.cooldownEnd && RPG.nowMs() < o.cooldownEnd); }
    function perform(actionId, value, onSuccess, npcOverride) {
        var key = "npc_action_" + actionId;
        if (D.pending[key]) return;
        RPG.net.send("dmz_npc", { a: "action", npc: npcOverride || D.npc, id: actionId, v: value || 0 });
        D.pending[key] = onSuccess;
    }
    function pendingAction(actionId) { return !!D.pending["npc_action_" + actionId]; }
    function succeed(event, popToRoot, markUsed, args) {
        return function () {
            if (markUsed) D.used[event] = true;
            if (popToRoot) popRoot();
            say(reply(event, args));
            RPG.sound("dmzpack:confirm_menu", 0.6, 1);
        };
    }
    function simple(id, labelKey, actionId, event, markUsed) {
        var o = opt(id, tr(labelKey), function () { perform(actionId, 0, succeed(event, false, markUsed)); });
        o.enabled = !pendingAction(actionId);
        return o;
    }
    function closing(id, labelKey, actionId) {
        return opt(id, tr(labelKey), function () { RPG.net.send("dmz_npc", { a: "action", npc: D.npc, id: actionId }); close(); });
    }
    function submenu(o) { o.submenu = true; return o; }

    // ---- pages (DialoguePage) ---------------------------------------------------------------------
    function speech(id, line, options, extra) {
        var p = { id: id, line: line, options: options, root: false };
        for (var k in (extra || {})) p[k] = extra[k];
        return p;
    }
    function rootPage() { return speech("root", rootLine, rootOptions, { root: true }); }

    // NpcDialogueContent.rootLine
    function rootLine() {
        var s = st(), id = D.npc;
        if (disliked()) {
            var own = pick("disliked", LINES + id + ".disliked");
            return tr(own || pick("disliked_generic", "gui.dragonminez.dialogue.disliked"), name());
        }
        if (id === "enma") {
            if (s.alive) return tr(pick("enma_alive", LINES + "enma.main"), name());
            if (s.canEnmaReturn) return tr(LINES + "enma.main_temporary", name());
            if (s.tempEnabled) return tr(LINES + "enma.need_baba_temporary", name());
            return tr(pick("enma_dead", LINES + "enma.need_baba"), name());
        }
        if (id === "baba") {
            if (s.alive) return tr(pick("baba_alive", LINES + "baba.already_alive", LINES + "baba.idle"), name());
            if (s.tempEnabled && s.tempActive) return tr(LINES + "baba.temporary_active", name());
            if (cdLeftMs("revive_baba") > 0) return tr(LINES + "baba.wait", Math.ceil(cdLeftMs("revive_baba") / 1000));
            if (s.tempEnabled) return tr(LINES + "baba.main_temporary", name(), s.babaTempMin);
            return tr(pick("baba_dead", LINES + "baba.main"), name());
        }
        if (id === "gero" && !s.geroEligible) return tr(pick("gero_rejects", LINES + "gero.not_eligible"), name());
        if (D.turnedIn || hasQuest("TURN_IN")) return stageLine("complete");
        var greeting = D.master ? pick("greeting", LINES + id + ".main", LINES + id + ".idle", STAGE + id + ".idle") : null;
        if (greeting) return tr(greeting, name());
        if (hasQuest("OFFER")) return stageLine("offer");
        if (hasQuest("IN_PROGRESS")) return stageLine("in_progress");
        return stageLine("idle");
    }

    // NpcDialogueContent.rootOptions
    function rootOptions() {
        var out = [], lockR = alignmentLock();
        if (D.quests.length) out.push(questsOption());
        if (D.master) {
            var skillMaster = !MD.isTextMaster(D.npc);
            if (skillMaster) {
                out.push(lockedBy(opt("skills", tr("gui.dragonminez.npc.skills"), function () { openSkills(); }), lockR));
                out.push(lockedBy(submenu(opt("train", tr("gui.dragonminez.npc.train"), function () { push(trainingPage()); })), lockR));
            } else if (D.npc === "popo" && st().inHtc) {
                out.push(lockedBy(submenu(opt("train", tr("gui.dragonminez.npc.train"), function () { push(trainingPage()); })), lockR));
            }
            services(out);
            if (MD.TOURNAMENT_HOSTS[D.npc]) out.push(opt("tournament", tr("gui.dragonminez.npc.tournament"), function () {
                RPG.net.send("dmz_npc", { a: "tournament", npc: D.npc });
            }));
        }
        return out;
    }
    function lockedBy(o, r) { return r ? lock(o, [reason(r)]) : o; }

    // MasterServices.add
    function services(out) {
        var s = st(), id = D.npc;
        switch (id) {
            case "karin": {
                var nimbus = simple("nimbus", "gui.dragonminez.button.karin.nimbus", 1, "nimbus", true);
                if (s.nimbusOwned || D.used.nimbus) lock(nimbus, [tr("gui.dragonminez.dialogue.locked.nimbus_owned")]);
                out.push(nimbus);
                var senzu = simple("senzu", "gui.dragonminez.button.karin.senzu", 2, "senzu", false);
                senzu.cooldown = function () { return cdLeftMs(MD.CD.SENZU_KARIN); };
                out.push(senzu);
                break;
            }
            case "guru": {
                var unlock = simple("unlock_potential", "gui.dragonminez.button.guru.unlock_potential", 1, "unlock_potential", false);
                if (s.potential > MD.POTENTIAL_LEVEL) lock(unlock, [tr("gui.dragonminez.dialogue.locked.potential_unlocked")]);
                else if (align() < MD.GURU_MIN) lock(unlock, [tr("message.dragonminez.npc.master_alignment_too_low", MD.GURU_MIN)], function () { say(tr(LINES + "guru.evil", name())); });
                else if (s.potential < MD.POTENTIAL_LEVEL) lock(unlock, [tr("gui.dragonminez.dialogue.locked.potential_level", MD.POTENTIAL_LEVEL)], function () { say(tr(LINES + "guru.level", name())); });
                out.push(unlock);
                break;
            }
            case "dende": {
                out.push(heal("gui.dragonminez.button.dende.heal"));
                if (s.tailRace) out.push(simple("tail", s.tail ? "gui.dragonminez.button.dende.remove_tail" : "gui.dragonminez.button.dende.grow_tail", 3,
                    s.tail ? "tail_remove" : "tail_grow", false));
                var bless = simple("bless", "gui.dragonminez.button.dende.bless", 4, "bless", false);
                bless.cooldown = function () { return cdLeftMs(MD.CD.KAMI_BLESS); };
                if (MD.band(align()) !== "GOOD") lock(bless, [tr("message.dragonminez.npc.master_alignment_too_low", MD.BLESS_MIN)]);
                out.push(bless);
                out.push(submenu(opt("reset", tr("gui.dragonminez.button.dende.reset"), function () { push(dendeReset()); })));
                break;
            }
            case "enma": {
                var earth = closing("earth", "gui.dragonminez.button.enma.earth", 1);
                if (!s.canEnmaReturn) lock(earth, [tr("gui.dragonminez.dialogue.locked.need_baba")]);
                out.push(earth);
                break;
            }
            case "baba": {
                var revive = simple("revive", s.tempEnabled ? "gui.dragonminez.button.baba.revive_temporary" : "gui.dragonminez.button.baba.revive", 1, "revive", false);
                revive.cooldown = function () { return cdLeftMs("revive_baba"); };
                if (s.alive) lock(revive, [tr("gui.dragonminez.dialogue.locked.alive")]);
                else if (s.tempEnabled && s.tempActive) lock(revive, [tr("gui.dragonminez.dialogue.locked.time_borrowed")]);
                out.push(revive);
                break;
            }
            case "popo":
                if (!s.inHtc && s.hair) out.push(submenu(opt("haircut", tr("gui.dragonminez.button.popo.haircut"), function () { push(haircutPage()); })));
                break;
            case "gero": {
                if (!s.geroEligible) { out.push(opt("gero_leave", tr("gui.dragonminez.button.gero.not_interested"), close)); break; }
                var offer = submenu(opt("gero_offer", tr("gui.dragonminez.button.gero.accept"), function () { push(geroOffer()); }));
                if (s.android) lock(offer, [tr("gui.dragonminez.dialogue.locked.android")]);
                out.push(offer);
                break;
            }
            case "piccolo":
                out.push(heal("gui.dragonminez.button.piccolo.heal"));
                out.push(weightOption("gui.dragonminez.button.piccolo.weight", "gui.dragonminez.button.piccolo.confirm"));
                break;
            case "roshi": case "kingkai":
                out.push(weightOption("gui.dragonminez.button.weight", "gui.dragonminez.button.weight.confirm"));
                break;
            case "oldkai": {
                var ult = opt("ultimate", tr("gui.dragonminez.button.oldkai.unlock_ultimate"), function () { RPG.net.send("dmz_npc", { a: "ultimate", npc: D.npc }); });
                if (align() < MD.OLDKAI_MIN) lock(ult, [tr("message.dragonminez.npc.master_alignment_too_low", MD.OLDKAI_MIN)], function () { say(tr(LINES + "oldkai.evil", name())); });
                else if (s.potential < MD.POTENTIAL_LEVEL) lock(ult, [tr("gui.dragonminez.dialogue.locked.potential_level", MD.POTENTIAL_LEVEL)], function () { say(tr(LINES + "oldkai.level", name())); });
                out.push(ult);
                break;
            }
            case "babidi": {
                var mark = simple("mark", "gui.dragonminez.button.babidi.mark", 1, "mark", false);
                if (s.majin) lock(mark, [tr("gui.dragonminez.dialogue.locked.majin")], function () { say(tr(LINES + "babidi.already", name())); });
                else if (align() > MD.BABIDI_MAX) lock(mark, [tr("message.dragonminez.npc.master_alignment_too_high", MD.BABIDI_MAX)], function () { say(tr(LINES + "babidi.too_good", name())); });
                out.push(mark);
                break;
            }
            case "grandkai": out.push(closing("grounds", "gui.dragonminez.button.grandkai.tournament", 1)); break;
            case "otherworld_announcer": out.push(closing("return", "gui.dragonminez.button.otherworld_announcer.return", 1)); break;
        }
    }

    function heal(labelKey) {
        var o = simple("heal", labelKey, 1, "heal", false);
        if (healthy()) lock(o, [tr("gui.dragonminez.dialogue.locked.full_health")]);
        return o;
    }
    function weightOption(labelKey, confirmKey) {
        var o = submenu(opt("weight", tr(labelKey), function () { push(weightPage(confirmKey)); }));
        if (D.used.weight) lock(o, [tr("gui.dragonminez.dialogue.locked.weight_given")]);
        return o;
    }
    function weightPage(confirmKey) {
        var max = Math.max(1, st().maxWeight || 1);
        return speech("weight", function () { return tr(LINES + D.npc + ".weight_prompt", name()); }, function () {
            var o = opt("weight_confirm", tr(confirmKey), function () {
                var w = Math.min(inputValue(), max);
                if (w <= 0) return;
                perform(2, w, succeed("weight", true, true, [w]));
            });
            o.tone = "PRIMARY";
            o.enabled = inputValue() > 0 && !pendingAction(2);
            return [o];
        }, { input: { digits: String(max).length, hint: tr("gui.dragonminez.dialogue.weight.hint", max), numeric: true } });
    }
    function dendeReset() {
        return speech("dende_reset", function () { return tr(LINES + "dende.reset_warning", name()); }, function () {
            var yes = closing("reset_confirm", "gui.dragonminez.button.dende.reset_confirm", 2);
            yes.tone = "DANGER";
            return [yes, opt("reset_cancel", tr("gui.dragonminez.button.dende.reset_cancel"), pop)];
        });
    }
    function geroOffer() {
        return speech("gero_offer", function () { return tr(LINES + "gero.offer", name()); }, function () {
            return [submenu(opt("gero_interest", tr("gui.dragonminez.button.gero.interest"), function () { push(geroConfirm()); })),
                opt("gero_decline", tr("gui.dragonminez.button.gero.not_interested"), popRoot)];
        });
    }
    function geroConfirm() {
        return speech("gero_confirm", function () { return tr(LINES + "gero.confirm", name()); }, function () {
            var c = opt("gero_convert", tr("gui.dragonminez.button.gero.confirm"), function () { perform(1, 0, succeed("convert", true, false)); });
            c.tone = "DANGER";
            c.enabled = !pendingAction(1);
            return [c, opt("gero_cancel", tr("gui.dragonminez.button.gero.cancel"), popRoot)];
        });
    }
    // NpcDialogueContent.training
    function trainingPage() {
        return speech("train", function () {
            var own = LINES + D.npc + ".training";
            return has(own) ? tr(own, name()) : tr("gui.dragonminez.dialogue.train.prompt");
        }, function () {
            var out = [opt("shadow", tr("gui.dragonminez.button.popo.shadow"), function () {
                RPG.net.send("dmz_npc", { a: "action", npc: "popo", id: 1 });
                close();
            })];
            var game = MD.minigameFor(D.npc);
            if (game) out.push(opt("minigame", tr("gui.dragonminez.minigame." + game), function () {
                RPG.net.send("dmz_npc", { a: "train_minigame", npc: D.npc, game: game });
                if (st().minigames) close();
            }));
            return out;
        });
    }
    // Popo's haircut (DMZ opens its HairEditorScreen): our hair styles + hair colour
    function haircutPage() {
        var race = st().race, looks = (DMZ_DATA.LOOKS[race] || {}), styles = looks.hair || [];
        return speech("haircut", function () { return tr(STAGE + "popo.idle"); }, function () {
            var out = styles.map(function (s) {
                var label = has("gui.dragonminez.customization.hair." + s) ? tr("gui.dragonminez.customization.hair." + s) : U.humanize(s);
                var o = opt("hair_" + s, label, function () {
                    RPG.net.send("dmz_npc", { a: "haircut", npc: D.npc, style: s });
                });
                if (st().hairStyle === s) o.tone = "DONE";
                return o;
            });
            if (looks.hairColor) {
                var c = opt("hair_color", tr("gui.dragonminez.customization.hair") + " " + (inputText() || ""), function () {
                    RPG.net.send("dmz_npc", { a: "haircut", npc: D.npc, color: inputText() });
                });
                c.tone = "PRIMARY";
                c.enabled = /^#?[0-9A-Fa-f]{6}$/.test(inputText());
                out.push(c);
            }
            return out;
        }, looks.hairColor ? { input: { digits: 7, hint: st().hairColor || "#RRGGBB", numeric: false } } : null);
    }

    // ---- quests in the dialogue (questsOption / questList / QuestSheet) ---------------------------
    function questTitle(key) {
        var e = typeof DMZ_QL !== "undefined" ? DMZ_QL.entry(key) : null;
        if (!e) return key;
        return typeof DMZ_QUEST_NAMES !== "undefined" ? DMZ_QUEST_NAMES.label(key) : tr(e.quest.title);
    }
    function questsOption() {
        var icon = ICON.LOCK, color = MUTED;
        if (D.turnedIn || hasQuest("TURN_IN")) { icon = ICON.TURN_IN; color = TURN_IN; }
        else if (hasQuest("OFFER")) { icon = ICON.OFFER; color = OFFER; }
        else if (hasQuest("IN_PROGRESS")) { icon = ICON.PROGRESS; color = PROGRESS; }
        else if (!hasQuest("LOCKED")) icon = ICON.CHECK;
        var o = submenu(opt("quests", tr("gui.dragonminez.dialogue.quests"), function () { push(questList()); }));
        o.icon = icon; o.iconColor = color;
        return o;
    }
    function questList() {
        return speech("quests", function () {
            if (!D.quests.length) return tr("gui.dragonminez.sidequest.no_quests");
            if (D.master) {
                if ((D.turnedIn || hasQuest("TURN_IN")) && has(STAGE + D.npc + ".complete")) return tr(STAGE + D.npc + ".complete");
                if (hasQuest("OFFER") && has(STAGE + D.npc + ".offer")) return tr(STAGE + D.npc + ".offer");
                if (hasQuest("IN_PROGRESS") && has(STAGE + D.npc + ".in_progress")) return tr(STAGE + D.npc + ".in_progress");
            }
            return tr("gui.dragonminez.dialogue.quests.prompt");
        }, questOptions);
    }
    function lockLines(q) {
        var c = q.cond;
        if (c && c.type === "SAGA_QUEST") {
            var k = c.sagaId + ":" + c.questId, saga = typeof DMZ_QL !== "undefined" ? DMZ_QL.SAGAS[c.sagaId] : null;
            return [tr("gui.dragonminez.quests.requirement.complete_saga", "§f" + questTitle(k) + "§r"),
                tr("gui.dragonminez.dialogue.quest.saga_step", saga ? tr(saga.name) : c.sagaId, c.questId)];
        }
        if (c && c.type === "QUEST") {
            var e = typeof DMZ_QL !== "undefined" ? DMZ_QL.entry(c.questId) : null, lines = [tr("gui.dragonminez.quests.requirement.complete_quest", "§f" + questTitle(c.questId) + "§r")];
            var giver = e && e.quest.quest_giver;
            if (giver) lines.push(tr("gui.dragonminez.dialogue.quest.sidequest_from", npcName(MD.norm(giver))));
            return lines;
        }
        if (q.reason) return [reason(q.reason)];
        return [tr("message.dragonminez.quest.start.unavailable")];
    }
    function questOptions() {
        var ordered = D.quests.slice().sort(function (a, b) { return (status(a) === "COMPLETED" ? 1 : 0) - (status(b) === "COMPLETED" ? 1 : 0); });
        return ordered.map(function (q) {
            var s = status(q), o = opt("quest:" + q.k, questTitle(q.k), function () { push(questPage(q)); });
            if (s === "TURN_IN") { o.icon = ICON.TURN_IN; o.iconColor = TURN_IN; }
            else if (s === "OFFER") { o.icon = ICON.OFFER; o.iconColor = OFFER; }
            else if (s === "IN_PROGRESS") { o.icon = ICON.PROGRESS; o.iconColor = PROGRESS; }
            else if (s === "COOLDOWN") { o.icon = ICON.CLOCK; o.iconColor = MUTED; o.cooldownEnd = q.endMs; o.lockTitle = tr("gui.dragonminez.dialogue.quest.locked"); o.lockLines = lockLines(q); }
            else if (s === "LOCKED") { o.icon = ICON.LOCK; o.iconColor = MUTED; lock(o, lockLines(q)); o.locked.title = tr("gui.dragonminez.dialogue.quest.locked"); }
            else if (s === "COMPLETED") { o.icon = ICON.CHECK; o.iconColor = METAL; o.tone = "DONE"; }
            return o;
        });
    }
    function questPage(q) {
        var e = typeof DMZ_QL !== "undefined" ? DMZ_QL.entry(q.k) : null;
        return speech("quest:" + q.k, function () {
            var head = questTitle(q.k) + "\n", s = status(q);
            var label = { OFFER: "offer", IN_PROGRESS: "in_progress", TURN_IN: "turn_in", COMPLETED: "completed" }[s];
            if (label) head += "[" + tr("gui.dragonminez.dialogue.quest.status." + label) + "]\n";
            return head + (e && e.quest.description ? tr(e.quest.description) : "");
        }, function () { return []; }, { quest: q });
    }
    function accept(q) {
        var key = "quest_start_" + q.k;
        if (D.pending[key]) return;
        RPG.net.send("dmz_npc", { a: "quest_accept", npc: D.npc, key: q.k });
        D.pending[key] = function () {
            q.s = "IN_PROGRESS";
            popRoot();
            say(reply("quest_accept"));
            RPG.sound("dmzpack:confirm_menu", 0.6, 1);
        };
    }

    // ---- navigation ---------------------------------------------------------------------------
    function setPage(p) {
        D.page = p; D.override = null; D.optScroll = 0; D.lineText = null; D.rowsAt = RPG.nowMs(); D.inputPos = null;
        RPG.screen.update("input", { visible: !!p.input, value: "", maxLength: p.input ? p.input.digits : 9 });
    }
    function push(p) { D.history.push(D.page); setPage(p); RPG.sound("dmzpack:pip_menu", 0.6, 1.1); }
    function pop() { if (!D.history.length) return close(); setPage(D.history.pop()); RPG.sound("dmzpack:pip_menu", 0.6, 0.9); }
    function popRoot() { if (D.history.length) { setPage(D.history[0]); D.history = []; } }
    function say(text) { D.override = text; D.lineText = null; }
    function close() {
        if (!D || D.closingAt) return;
        D.closingAt = RPG.nowMs();
        RPG.net.send("dmz_npc", { a: "close", npc: D.npc });
    }
    function inputText() { var v = RPG.screen.value("input"); return v === null || v === undefined ? "" : String(v).trim(); }
    function inputValue() { var n = parseInt(inputText().replace(/[^0-9]/g, ""), 10); return isNaN(n) ? 0 : n; }

    // ---- open ------------------------------------------------------------------------------------
    function open(d) {
        var prev = D && D.npc === d.npc && !D.closingAt ? D : null;
        D = { npc: d.npc, master: !!d.master, quests: (d.quests || []).map(fixQuest), turnedIn: !!d.turnedIn, st: d.st || {}, cdEnd: {},
            history: [], page: null, pending: {}, used: prev ? prev.used : {}, picks: {}, override: null, openedAt: RPG.nowMs(), closingAt: 0,
            optScroll: 0, lineText: null, typeStart: 0, rowsAt: RPG.nowMs(), layout: null, rows: [], footer: [] };
        applyCooldowns();
        screen();
        setPage(rootPage());
    }
    function screen() {
        var mine = D;
        RPG.screen.open({ id: "dmz_npc_dialogue", referenceHeight: 360, background: "none", closeOnEsc: false,
            elements: [{ id: "input", type: "input", anchor: "topleft", x: 0, y: 0, w: INPUT_W, h: INPUT_H - 2, visible: false, maxLength: 9, value: "" }],
            onRender: render, onMouse: mouse, onScroll: scroll, onKey: key, onClose: function () { if (D === mine && !mine.toSkills) D = null; } });
    }
    function fixQuest(q) { if (q.ms) q.endMs = RPG.nowMs() + q.ms; return q; }
    function applyCooldowns() {
        var c = (D.st && D.st.cd) || {}, now = RPG.nowMs();
        D.cdEnd = {};
        Object.keys(c).forEach(function (k) { if (c[k] > 0) D.cdEnd[k] = now + c[k] * 50; });
    }

    // ---- drawing (DialogueSkin) --------------------------------------------------------------------
    function q(ctx, x, y, w, h, u, v, uw, vh, color, alpha) {
        if (w <= 0 || h <= 0 || alpha <= 0.004) return;
        ctx.quad(SHEET, x, y, w, h, u / 256, v / 256, (u + uw) / 256, (v + vh) / 256, color || "#FFFFFF", alpha);
    }
    function threeSlice(ctx, x, y, w, h, u, v, rw, rh, lc, rc, alpha) {
        var s = h / rh, left = Math.min(lc * s, w / 2), right = Math.min(rc * s, w - left), mid = Math.max(0, w - left - right);
        q(ctx, x, y, left, h, u, v, left / s, rh, null, alpha);
        if (mid > 0) q(ctx, x + left, y, mid, h, u + lc, v, rw - lc - rc, rh, null, alpha);
        q(ctx, x + left + mid, y, right, h, u + rw - right / s, v, right / s, rh, null, alpha);
    }
    function nineSlice(ctx, x, y, w, h, u, v, rw, rh, b, alpha) {
        var xs = [[0, b, 0, b], [b, w - 2 * b, b, rw - 2 * b], [w - b, b, rw - b, b]], ys = [[0, b, 0, b], [b, h - 2 * b, b, rh - 2 * b], [h - b, b, rh - b, b]];
        xs.forEach(function (cx) { ys.forEach(function (cy) { q(ctx, x + cx[0], y + cy[0], cx[1], cy[1], u + cx[2], v + cy[2], cx[3], cy[3], null, alpha); }); });
    }
    function rowSkin(ctx, row, x, y, w, h, alpha) { threeSlice(ctx, x, y, w, h, row * 40, 32, 40, 20, 4, 4, alpha); }
    function icon(ctx, i, x, y, color, alpha) { if (i >= 0) q(ctx, x, y, 10, 10, i * 10, 56, 10, 10, color, alpha); }
    function text(ctx, s, x, y, color, alpha, align, scale) { ctx.textStyled(s, x, y, scale || 1, color, alpha, align || 0, FONT, null); }
    function ease(t) { t = Math.max(0, Math.min(1, t)); return 1 - Math.pow(1 - t, 3); }
    function clock(ms) {
        var s = Math.floor((ms + 999) / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
        function two(n) { return n < 10 ? "0" + n : String(n); }
        return h > 0 ? h + ":" + two(m) + ":" + two(sec) : m + ":" + two(sec);
    }

    function layout(W, H) {
        var bandH = Math.max(MIN_BAND_H, Math.round(H * BAND_SHARE)), bandTop = H - bandH;
        // no NPC portrait in this engine (screens can only draw the player's model), so the text starts at the margin
        var optionsX = W - MARGIN - COL_W, textX = MARGIN + GAP, textW = Math.min(TEXT_MAX_W, optionsX - GAP - textX);
        var footerY = H - FOOTER_BOTTOM - FOOTER_H;
        return { W: W, H: H, bandH: bandH, bandTop: bandTop, optionsX: optionsX, textX: textX, textW: textW, textY: bandTop + TEXT_TOP,
            footerY: footerY, textH: footerY - FOOTER_GAP - (bandTop + TEXT_TOP), optionsY: bandTop + OPTIONS_TOP, optionsH: H - FOOTER_BOTTOM - bandTop - OPTIONS_TOP };
    }

    // Typewriter: reveal times for every character of the wrapped lines
    function typeTimes(lines) {
        var times = [], t = START_MS, all = lines.join(" ");
        for (var i = 0; i < all.length; i++) {
            t += CHAR_MS;
            times.push(t);
            var c = all.charAt(i), next = all.charAt(i + 1), brk = next === "" || next === " ";
            if (brk && (c === "." || c === "!" || c === "?" || c === "…")) t += SENTENCE_MS;
            else if (brk && (c === "," || c === ";" || c === ":")) t += CLAUSE_MS;
        }
        return times;
    }
    function visibleChars() {
        if (!D.typing) return 1e9;
        var el = RPG.nowMs() - D.typeStart, t = D.typing, n = 0;
        while (n < t.length && t[n] <= el) n++;
        return n;
    }
    function typingDone() { return !D.typing || visibleChars() >= D.typing.length; }

    function render(ctx) {
        if (!D) return;
        var now = RPG.nowMs(), L = D.layout = layout(ctx.width, ctx.height);
        var open = D.closingAt ? 1 - Math.min(1, (now - D.closingAt) / CLOSE_MS) : ease((now - D.openedAt) / OPEN_MS);
        if (D.closingAt && now - D.closingAt >= CLOSE_MS) { D = null; RPG.screen.close(); return; }
        var slide = (1 - open) * L.bandH;
        ctx.fill(0, 0, L.W, L.H, "#000000", DIM_ALPHA * open);
        ctx.push(); ctx.translate(0, slide);
        // band
        q(ctx, 0, L.bandTop - SHADOW_H, L.W, SHADOW_H, 136, 72, 8, 32, null, open);
        q(ctx, 0, L.bandTop, L.W, L.bandH + SHADOW_H, 128, 72, 8, 64, null, 1);
        q(ctx, 0, L.bandTop - 2, L.W, 5, 144, 72, 8, 5, null, 1);
        // name tab
        var nm = npcName(D.npc), tabW = Math.min(ctx.textWidthIn(nm, FONT) * NAME_SCALE + 34, L.textW), tabX = L.textX - 4, tabY = L.bandTop - TAB_RISE;
        threeSlice(ctx, tabX, tabY, tabW, 18, 64, 0, 48, 18, 6, 20, 1);
        text(ctx, nm, tabX + 10, tabY + 4, TEXT, 1, 0, NAME_SCALE);
        // speech
        var areaH = L.textH - (D.page.input ? INPUT_H + FOOTER_GAP : 0);
        renderLine(ctx, L, areaH, open);
        if (D.page.input) {
            var ix = L.textX + 2, iy = L.textY + areaH + FOOTER_GAP, iw = Math.min(INPUT_W, L.textW);
            nineSlice(ctx, ix - 2, iy + slide * 0, iw, INPUT_H, 0, 128, 24, 18, 5, open);
            var pos = Math.round(ix) + "," + Math.round(iy + slide + 1) + "," + (iw - 4);
            if (D.inputPos !== pos) { D.inputPos = pos; RPG.screen.update("input", { x: Math.round(ix), y: Math.round(iy + slide + 1), w: iw - 4 }); }
            if (!inputText()) text(ctx, D.page.input.hint, ix + 4, iy + 5, MUTED, open * 0.8);
        }
        renderOptions(ctx, L, open, now);
        renderFooter(ctx, L, open, now);
        ctx.pop();
        renderTooltip(ctx, now);
    }

    function currentLine() {
        if (D.override) return D.override;
        try { return D.page.line(); } catch (e) { return ""; }
    }
    function renderLine(ctx, L, areaH, open) {
        var line = U.strip(currentLine());
        if (D.lineText !== line) {
            D.lineText = line;
            D.lines = U.wrap(ctx, line, L.textW - 6);
            D.typing = typeTimes(D.lines.map(function (l) { return U.strip(l); }));
            D.typeStart = RPG.nowMs();
            D.textScroll = 0;
        }
        var lines = D.lines || [], shown = visibleChars(), used = 0, total = lines.length * LINE_H;
        var maxScroll = Math.max(0, total - areaH);
        if (!typingDone()) {                         // follow the typing
            var cursorLine = 0, c = 0;
            for (var j = 0; j < lines.length; j++) { c += U.strip(lines[j]).length + 1; if (c > shown) { cursorLine = j; break; } cursorLine = j; }
            D.textScroll = Math.max(0, Math.min(maxScroll, (cursorLine + 1) * LINE_H - areaH));
        }
        D.textScroll = Math.max(0, Math.min(maxScroll, D.textScroll || 0));
        for (var i = 0; i < lines.length; i++) {
            var raw = lines[i], plainLen = U.strip(raw).length, ly = L.textY + i * LINE_H - D.textScroll;
            var take = Math.max(0, Math.min(plainLen, shown - used));
            used += plainLen + 1;
            if (ly < L.textY - 2 || ly + 9 > L.textY + areaH) continue;
            if (take <= 0) continue;
            text(ctx, take >= plainLen ? raw : cutVisible(raw, take), L.textX, ly, TEXT, open);
        }
        if (typingDone() && maxScroll > 0 && D.textScroll < maxScroll - 1) {
            var bounce = Math.abs(Math.sin(RPG.nowMs() / 260)) * 2.5;
            icon(ctx, ICON.DOWN, L.textX + L.textW - 16, L.textY + areaH - 8 + bounce, ACCENT, open);
        }
    }
    // first n visible characters of a line that may hold § codes
    function cutVisible(s, n) {
        var out = "", count = 0;
        for (var i = 0; i < s.length && count < n; i++) {
            if (s.charAt(i) === "§" && i + 1 < s.length) { out += s.substring(i, i + 2); i++; continue; }
            out += s.charAt(i); count++;
        }
        return out;
    }

    function options() {
        try { return D.page.options() || []; } catch (e) { RPG.log("dialogue options failed: " + e); return []; }
    }
    function renderOptions(ctx, L, open, now) {
        var list = options(), x = L.optionsX, y = L.optionsY, h = L.optionsH, mx = ctx.mouseX, my = ctx.mouseY;
        var total = Math.max(0, list.length * ROW_STEP - (ROW_STEP - ROW_H));
        D.optScroll = Math.max(0, Math.min(D.optScroll, Math.max(0, total - h)));
        D.rows = [];
        D.hover = null;
        list.forEach(function (o, i) {
            var ry = y + i * ROW_STEP - D.optScroll;
            if (ry < y - 2 || ry + ROW_H > y + h + 2) return;
            var appear = ease((now - D.rowsAt - 110 - i * 32) / 210) * open;
            var avail = available(o) && !D.closingAt, over = mx >= x && mx < x + COL_W && my >= ry && my < ry + ROW_H;
            if (over) D.hover = o;
            var lit = over && avail, rx = x + (1 - appear) * 22 + (lit ? 3 : 0);
            D.rows.push({ o: o, x: x, y: ry });
            var base = !avail ? ROW.DISABLED : o.tone === "PRIMARY" ? ROW.PRIMARY : ROW.NORMAL;
            rowSkin(ctx, base, rx, ry, COL_W, ROW_H, appear);
            if (lit) rowSkin(ctx, o.tone === "DANGER" ? ROW.DANGER : ROW.HOVER, rx, ry, COL_W, ROW_H, appear);
            icon(ctx, o.icon, rx + 8, ry + 5, !avail ? MUTED : lit ? TEXT : o.iconColor, appear);
            var left = o.cooldown ? o.cooldown() : o.cooldownEnd ? Math.max(0, o.cooldownEnd - now) : 0;
            var time = left > 0 ? clock(left) : "", chipW = time ? Math.round(ctx.textWidthIn(time, FONT)) + 20 : 0;
            var reserve = time ? chipW + 8 : o.submenu ? 18 : 8, labelX = o.icon >= 0 ? 22 : 11;
            var color = !avail || (o.tone === "DONE" && !lit) ? MUTED : o.tone === "DANGER" && !lit ? DANGER_TEXT : TEXT;
            text(ctx, U.ellipsis(ctx, o.label, COL_W - labelX - reserve), rx + labelX, ry + 6, color, appear);
            if (time) {
                var cx = rx + COL_W - chipW - 5, cy = ry + 4;
                nineSlice(ctx, cx, cy, chipW, 12, 0, 160, 16, 12, 4, appear);
                icon(ctx, ICON.CLOCK, cx + 3, cy + 1, ACCENT, appear);
                text(ctx, time, cx + 15, cy + 2, METAL, appear);
            } else if (o.submenu) icon(ctx, ICON.CHEVRON, rx + COL_W - 14, ry + 5, !avail ? MUTED : lit ? TEXT : METAL, appear);
        });
        if (total > h) {
            var thumb = Math.max(10, h * h / total), ty = y + (h - thumb) * (D.optScroll / (total - h));
            ctx.fill(x + COL_W + 3, y, 2, h, "#16241A", open);
            ctx.fill(x + COL_W + 3, ty, 2, thumb, "#909AC3", open);
        }
    }

    function footer(L) {
        var left = L.textX, right = L.textX + L.textW - FOOTER_W, out = [];
        if (D.page.quest) {
            var s = status(D.page.quest);
            if (s === "OFFER") {
                out.push({ label: tr("gui.dragonminez.story.sidequests.accept"), row: ROW.PRIMARY, x: left, run: function () { accept(D.page.quest); } });
                out.push({ label: tr("gui.dragonminez.dialogue.reject"), row: ROW.NORMAL, x: right, run: pop });
            } else out.push({ label: tr("gui.dragonminez.customization.back"), row: ROW.NORMAL, x: left, run: pop });
        } else if (D.page.root) out.push({ label: tr("gui.dragonminez.close"), row: ROW.NORMAL, x: left, run: close });
        else out.push({ label: tr("gui.dragonminez.customization.back"), row: ROW.NORMAL, x: left, run: pop });
        return out;
    }
    function renderFooter(ctx, L, open, now) {
        D.footer = footer(L);
        D.footer.forEach(function (b) {
            var over = U.inside(ctx.mouseX, ctx.mouseY, b.x, L.footerY, FOOTER_W, FOOTER_H);
            if (b.row === ROW.PRIMARY) {
                rowSkin(ctx, ROW.PRIMARY, b.x, L.footerY, FOOTER_W, FOOTER_H, open);
                if (over) ctx.fill(b.x + 3, L.footerY + 2, FOOTER_W - 6, FOOTER_H - 4, "#FFFFFF", (0.10 + 0.06 * Math.sin(now / 140)) * open);
            } else rowSkin(ctx, over ? ROW.HOVER : ROW.NORMAL, b.x, L.footerY, FOOTER_W, FOOTER_H, open);
            text(ctx, b.label, b.x + FOOTER_W / 2, L.footerY + 6, TEXT, open, 0.5);
        });
    }
    function renderTooltip(ctx, now) {
        var o = D && D.hover;
        if (!o || available(o)) return;
        var title = o.locked ? o.locked.title : o.lockTitle, lines = o.locked ? o.locked.lines : o.lockLines;
        if (!lines || !lines.length) return;
        U.tooltip(ctx, [[title || o.label, "#FFFFFF"]].concat(lines.map(function (l) { return [l, "#B8B8C0"]; })), ctx.mouseX, ctx.mouseY, ACCENT);
    }

    // ---- input ---------------------------------------------------------------------------------
    function activate(o) {
        if (!available(o)) {
            if (o.lockedAction && !(o.cooldown && o.cooldown() > 0)) { RPG.sound("dmzpack:pip_menu", 0.6, 0.8); o.lockedAction(); }
            return;
        }
        RPG.sound("dmzpack:pip_menu", 0.6, 1);
        o.run();
    }
    function mouse(x, y, button, action) {
        if (!D || action !== "down" || D.closingAt) return;
        var L = D.layout;
        if (!L) return;
        var slide = 0;
        for (var i = 0; i < D.rows.length; i++) {
            var r = D.rows[i];
            if (x >= r.x && x < r.x + COL_W && y >= r.y + slide && y < r.y + ROW_H + slide) { activate(r.o); return false; }
        }
        for (var j = 0; j < D.footer.length; j++) {
            var b = D.footer[j];
            if (U.inside(x, y, b.x, L.footerY, FOOTER_W, FOOTER_H)) { RPG.sound("dmzpack:pip_menu", 0.6, 1); b.run(); return false; }
        }
        // clicking the speech finishes the typing
        if (x >= L.textX && x < L.textX + L.textW && y >= L.textY && y < L.footerY) { if (!typingDone()) D.typeStart = -1e9; return false; }
    }
    function scroll(x, y, delta) {
        if (!D || !D.layout) return;
        var L = D.layout, d = delta > 0 ? -1 : 1;
        if (x >= L.optionsX) D.optScroll += d * ROW_STEP;
        else D.textScroll = (D.textScroll || 0) + d * LINE_H * 2;
    }
    function key(k) {
        if (!D) return;
        if (k === "key.keyboard.escape") { if (D.page.root) close(); else pop(); return false; }
        if ((k === "key.keyboard.space" || k === "key.keyboard.enter") && !typingDone() && !D.page.input) { D.typeStart = -1e9; return false; }
    }

    // ---- server messages --------------------------------------------------------------------------
    RPG.net.on("dmz_npc_open", function (d) { if (d && d.npc) open(d); });
    RPG.net.on("dmz_npc_state", function (d) {
        if (!d) return;
        if (SHOP && SHOP.npc === d.npc) { SHOP.st = d.st || SHOP.st; }
        if (!D || D.npc !== d.npc) return;
        D.st = d.st || D.st;
        if (d.quests) D.quests = d.quests.map(fixQuest);
        applyCooldowns();
    });
    RPG.net.on("dmz_npc_result", function (d) {
        if (!d || !D || D.npc !== d.npc && !(d.npc === "popo")) return;
        var cb = D.pending[d.action];
        delete D.pending[d.action];
        if (!cb) return;
        if (d.ok) cb();
        else if (d.reason) say(reason(d.reason));
        else say(reply(String(d.action).indexOf("quest_") === 0 ? "quest_failure" : "failure"));
    });
    RPG.net.on("dmz_npc_say", function (d) { if (d && D && D.npc === d.npc) say(tr(d.key, name())); });

    // =====================================================================================
    //  MastersSkillsScreen: the master's TP shop
    // =====================================================================================
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png", MENU_SMALL = "dmzpack:textures/gui/menu/menusmall.png";
    var CATS = [["SKILLS", 142, 44, "gui.dragonminez.skills.tab.skills"], ["KI", 170, 44, "gui.dragonminez.skills.tab.kiattacks"],
        ["FORMS", 198, 44, "gui.dragonminez.skills.tab.forms"], ["STRIKE", 226, 44, "gui.dragonminez.skills.tab.strikeattacks"],
        ["EVASION", 142, 77, "gui.dragonminez.skills.tab.evasionattacks"]];
    var ITEM_H = 20, VISIBLE = 8, DESC_W = 119;
    var SHOP = null;

    function shopLevel(s) { var v = (SHOP.st.skills || {})[s]; return typeof v === "number" ? v : 0; }
    function shopOwned(s) { return Object.prototype.hasOwnProperty.call(SHOP.st.skills || {}, s); }
    function isTech(c) { return c === "KI" || c === "STRIKE" || c === "EVASION"; }
    function offerings() { return SD.OFFERINGS[SHOP.npc] || SD.OFFERINGS["default"]; }
    // getSkillsForCategory
    function skillsFor(cat) {
        var race = SHOP.st.race || "human", out = [];
        offerings().forEach(function (s) {
            var ki = SD.KI.indexOf(s) >= 0, form = SD.FORM_SKILLS.indexOf(s) >= 0, stack = SD.STACK_SKILLS.indexOf(s) >= 0,
                strike = SD.STRIKE.indexOf(s) >= 0, ev = SD.EVASION.indexOf(s) >= 0;
            if (form) { if (!(SD.FORM_COSTS[race] || {})[s]) return; }
            else if (!ki && !strike && !ev && !SD.allowed(s, race, false)) return;
            if (cat === "SKILLS" && !ki && !form && !stack && !strike && !ev) out.push(s);
            else if (cat === "KI" && ki) out.push(s);
            else if (cat === "FORMS" && (form || stack)) out.push(s);
            else if (cat === "STRIKE" && strike) out.push(s);
            else if (cat === "EVASION" && ev) out.push(s);
        });
        return out;
    }
    function cost(s) { var c = SD.cost(s, 0, SHOP.st.race || "human"); return c < 0 ? -1 : c; }
    // FormRequisites.checkSkillLevel(stats, skill, 1, true): the saga quest a form's first level needs
    function formLock(s) {
        if (!SD.isForm(s)) return null;
        var lockKey = null, done = SHOP.st.done || [];
        (SD.FORM_TREES[SHOP.st.race || "human"] || []).forEach(function (g) {
            if (g[1] !== s) return;
            g[2].forEach(function (f) { if (f[1] === 1 && f[3] && done.indexOf(f[3]) < 0 && !lockKey) lockKey = f[3]; });
        });
        return lockKey;
    }
    function questLabel(key) { return typeof DMZ_QUEST_NAMES !== "undefined" ? DMZ_QUEST_NAMES.label(key) : key; }
    function techName(s) {
        var keys = ["technique.dragonminez." + s, "skill.dragonminez." + s];
        for (var i = 0; i < keys.length; i++) if (has(keys[i])) return tr(keys[i]);
        var ours = SD.TECHNIQUES[s];
        return ours ? RPG.defName("skill", ours) : U.humanize(s);
    }
    function skillLabel(s, cat) { return isTech(cat) ? techName(s) : (has("skill.dragonminez." + s) ? tr("skill.dragonminez." + s) : U.humanize(s)); }

    function openSkills() {
        SHOP = { npc: D.npc, st: D.st, cat: null, selected: null, scroll: 0, descScroll: 0, reveal: 0, buyRect: null, cy: 180 };
        var cats = CATS.filter(function (c) { return skillsFor(c[0]).length > 0; });
        SHOP.cats = cats;
        SHOP.cat = cats.length ? cats[0][0] : "SKILLS";
        D.toSkills = true;
        RPG.screen.open({ id: "dmz_masters_skills", referenceHeight: 360, background: "dim", closeOnEsc: false, elements: [],
            onRender: renderShop, onMouse: shopMouse, onScroll: shopScroll, onKey: function (k) { if (k === "key.keyboard.escape") { backToDialogue(); return false; } },
            onClose: function () { SHOP = null; } });
        RPG.net.send("dmz_npc", { a: "state", npc: D.npc });
    }
    function backToDialogue() {
        var keep = D;
        SHOP = null;
        if (!keep) { RPG.screen.close(); return; }
        keep.toSkills = false;
        D = keep;
        screen();
        var page = D.page;
        D.page = null;
        setPage(page || rootPage());
    }

    function renderShop(ctx) {
        if (!SHOP) return;
        var W = ctx.width, H = ctx.height, cy = Math.floor(H / 2), mx = ctx.mouseX, my = ctx.mouseY;
        SHOP.cy = cy; SHOP.W = W;
        var px = 12, py = cy - 105;
        // category tabs slide out from under the left panel
        var hidden = px + 122, visible = px + 141;
        var overPanel = mx >= px && mx < px + 141 && my >= py && my < py + 213;
        var overHot = mx >= hidden && mx < visible + 26 && my >= py + 6 && my < py + 6 + Math.max(1, SHOP.cats.length) * 32;
        SHOP.reveal = U.approach(SHOP.reveal, overPanel || overHot ? 1 : 0, 1 / 15);
        var tx = hidden + (visible - hidden) * U.ease(SHOP.reveal);
        SHOP.cats.forEach(function (c, i) {
            var y = py + 6 + 32 * i, x0 = Math.max(tx, visible), w = tx + 26 - x0;
            if (w <= 0) return;
            ctx.quad(MENU_BIG, x0, y, w, 32, (c[1] + x0 - tx) / 256, c[2] / 256, (c[1] + 26) / 256, (c[2] + 32) / 256, "#FFFFFF", 1);
        });
        ctx.image(MENU_BIG, px, py, 141, 213, 0, 0, 141, 213, 256, 256);
        ctx.image(MENU_BIG, 29, cy - 95, 107, 21, 142, 22, 107, 21, 256, 256);
        // list
        var list = skillsFor(SHOP.cat), startY = py + 30, viewH = VISIBLE * ITEM_H, total = list.length * ITEM_H, canScroll = total > viewH;
        var listRight = px + (canScroll ? 124 : 130);
        SHOP.scroll = Math.max(0, Math.min(SHOP.scroll, Math.max(0, total - viewH)));
        list.forEach(function (s, i) {
            var y = startY + i * ITEM_H - SHOP.scroll;
            if (y < startY - 2 || y + 12 > startY + viewH) return;
            var sel = s === SHOP.selected, hov = mx >= px + 10 && mx <= px + 100 && my >= y && my <= y + ITEM_H;
            var color = sel ? "#FFAA00" : hov ? "#AAAAAA" : "#FFFFFF";
            U.bordered(ctx, U.ellipsis(ctx, skillLabel(s, SHOP.cat), 100), px + 15, y + 5, color);
            var lv = String(shopLevel(s) > 0 ? shopLevel(s) : 0);
            U.bordered(ctx, lv, listRight - U.width(ctx, lv), y + 5, color);
        });
        if (canScroll) {
            var thumb = Math.max(20, viewH * viewH / total), ty = startY + (viewH - thumb) * (SHOP.scroll / (total - viewH));
            ctx.fill(px + 128, startY, 2, viewH, "#000000", 0.4);
            ctx.fill(px + 128, ty, 2, thumb, "#FFFFFF", 0.7);
        }
        var cat = CATS.filter(function (c) { return c[0] === SHOP.cat; })[0];
        U.bordered(ctx, "§l" + tr(cat[3]), 80, cy - 88, "#FBC51C", 0.5);
        // the master's name over the middle (DMZ draws the master's model there)
        U.bordered(ctx, "§l" + npcName(SHOP.npc), W / 2, cy - 100, "#FFFFFF", 0.5);
        U.bordered(ctx, "TPS: " + Math.floor(RPG.player.tp), W / 2, cy + 96, "#FFD700", 0.5);
        renderShopRight(ctx, W - 158, py, mx, my);
    }

    function renderShopRight(ctx, px, py, mx, my) {
        var W = SHOP.W, cy = SHOP.cy;
        if (isTech(SHOP.cat)) {
            ctx.image(MENU_BIG, px, py, 141, 213, 0, 0, 141, 213, 256, 256);
            ctx.image(MENU_BIG, W - 141, cy - 95, 107, 21, 142, 22, 107, 21, 256, 256);
        } else {
            ctx.image(MENU_SMALL, px, py, 141, 94, 0, 0, 141, 94, 256, 256);
            ctx.image(MENU_BIG, W - 141, cy - 95, 107, 21, 142, 22, 107, 21, 256, 256);
            ctx.image(MENU_SMALL, px, py + 96, 141, 94, 0, 0, 141, 94, 256, 256);
            ctx.image(MENU_SMALL, px, py + 190, 141, 32, 0, 154, 141, 32, 256, 256);
        }
        U.bordered(ctx, "§l" + tr("gui.dragonminez.character_stats.info"), px + 70, py + 16, "#FFD700", 0.5);
        SHOP.buyRect = null;
        var s = SHOP.selected;
        if (!s) return;
        var race = SHOP.st.race || "human", c = cost(s), lv = shopLevel(s), notOwned = !shopOwned(s) || lv === 0;
        var lockKey = notOwned ? formLock(s) : null;
        if (isTech(SHOP.cat)) {
            // MastersSkillsScreen.render{Ki,Strike,Evasion}TechniqueDetails (DMZ numbers: shared/09_dmz_techniques_data.js)
            var y = py + 40, TDd = DMZ_TECH_DATA, t = TDd.get(s), pv = typeof DMZ_TECH_CLIENT !== "undefined" ? DMZ_TECH_CLIENT.preview(s) : {};
            var f1 = function (n) { return (Math.round(n * 10) / 10).toFixed(1); };
            var row = function (key, val, color) { U.bordered(ctx, tr(key) + ": " + val, px + 15, y, color || "#FFFFFF"); y += 12; };
            U.bordered(ctx, "§l" + techName(s), px + 70, y, "#FFFFFF", 0.5); y += 24;
            var type = !t ? "technique.type.wave" : t.kind === "ki" ? "technique.type." + t.type.toLowerCase() : "technique.type." + t.kind;
            row("gui.dragonminez.technique.type", has(type) ? tr(type) : U.humanize(SHOP.cat), "#DDDDDD");
            var races = SD.RACES[s] || [], allowed = SD.allowed(s, race, !!SHOP.st.android);
            var racesText = races.length ? races.map(function (r) { return has("race.dragonminez." + r) ? tr("race.dragonminez." + r) : U.humanize(r); }).join(", ")
                : tr("gui.dragonminez.technique.races.all");
            row("gui.dragonminez.technique.races", racesText, allowed ? "#DDDDDD" : "#FF5555");
            if (t && t.kind === "ki") {
                row("gui.dragonminez.technique.damage", String(pv.dmg || 0));
                row("gui.dragonminez.technique.size", f1(t.size));
                row("gui.dragonminez.technique.speed", f1(t.speed));
                row("gui.dragonminez.technique.armor_pen", "0");
                row("gui.dragonminez.technique.cast_time", f1((pv.cast || 0) / 20) + "s");
            } else if (t && t.kind === "strike") {
                row("gui.dragonminez.technique.damage", String(pv.dmg || 0));
                row("gui.dragonminez.technique.cast_time", "0.0s");
            } else if (t && t.kind === "evasion") {
                if (t.dmg > 0) row("gui.dragonminez.technique.damage", String(pv.dmg || 0));
                row("gui.dragonminez.technique.duration", f1((pv.dur || t.dur) / 20) + "s");
            }
            if (t) {
                row("gui.dragonminez.technique.cooldown", f1((pv.cd || 0) / 20) + "s");
                row("gui.dragonminez.technique.energy_cost", f1(pv.cost || 0), "#FFAAAA");
            }
            var learned = lv > 0 || (typeof DMZ_TECH_CLIENT !== "undefined" && !!DMZ_TECH_CLIENT.state.u[s]);
            U.bordered(ctx, learned ? tr("gui.dragonminez.skills.already_learned") : tr("gui.dragonminez.skills.not_learned"), px + 70, y, learned ? "#55AA55" : "#AAAAAA", 0.5);
            if (!learned && c >= 0) U.bordered(ctx, c + " TPS", px + 70, y + 12, "#AAAAAA", 0.5);
        } else {
            var y0 = py + 40, max = SD.maxLevel(s, race);
            U.bordered(ctx, "§l" + skillLabel(s, SHOP.cat), px + 72, y0, "#FFFFFF", 0.5);
            U.bordered(ctx, lv > 0 ? tr("gui.dragonminez.skills.level", lv, max) : tr("gui.dragonminez.skills.not_learned"), px + 72, y0 + 12, "#AAAAAA", 0.5);
            if (lv === 0) {
                if (c >= 0) U.bordered(ctx, c + " TPS", px + 72, y0 + 24, "#AAAAAA", 0.5);
                if (lockKey) U.wrap(ctx, tr("gui.dragonminez.skills.locked_until", questLabel(lockKey)), 130).forEach(function (l, i) {
                    U.bordered(ctx, l, px + 72, y0 + 36 + i * 11, "#FF5555", 0.5);
                });
            } else U.bordered(ctx, tr("gui.dragonminez.skills.already_learned"), px + 72, y0 + 24, "#55AA55", 0.5);
            var desc = has("skill.dragonminez." + s + ".desc") ? tr("skill.dragonminez." + s + ".desc") : "";
            var lines = U.wrap(ctx, desc, DESC_W - 4), viewH = 6 * LINE_H, tot = lines.length * LINE_H;
            SHOP.descScroll = Math.max(0, Math.min(SHOP.descScroll, Math.max(0, tot - viewH)));
            SHOP.descRect = [px + 12, y0 + 70, DESC_W, viewH];
            lines.forEach(function (l, i) {
                var ly = y0 + 70 + i * LINE_H - SHOP.descScroll;
                if (ly < y0 + 69 || ly + 9 > y0 + 70 + viewH) return;
                U.plain(ctx, l, px + 12, ly, "#CCCCCC");
            });
        }
        // initPurchaseButton
        var buyable = SD.allowed(s, race, !!SHOP.st.android) || SD.isTechnique(s);
        if (buyable && notOwned && c >= 0) {
            var canAfford = RPG.player.tp >= c && !lockKey;
            U.button(ctx, tr("gui.dragonminez.skills.purchase"), px + 35, py + 196, canAfford);
            SHOP.buyRect = [px + 35, py + 196, canAfford];
        }
        U.drawStatus(ctx, px + 70, py + 186);
    }

    function shopMouse(x, y, button, action) {
        if (!SHOP || action !== "down") return;
        var cy = SHOP.cy, px = 12, py = cy - 105;
        var tx = px + 122 + 19 * U.ease(SHOP.reveal);
        for (var i = 0; i < SHOP.cats.length; i++) {
            var ty = py + 6 + 32 * i;
            if (x >= Math.max(tx, px + 141) && x < tx + 26 && y >= ty && y < ty + 32) {
                SHOP.cat = SHOP.cats[i][0]; SHOP.selected = null; SHOP.scroll = 0; SHOP.descScroll = 0;
                RPG.sound("dmzpack:pip_menu", 1, 1);
                return false;
            }
        }
        var list = skillsFor(SHOP.cat), startY = py + 30;
        if (x >= px + 10 && x <= px + 100 && y >= startY && y < startY + VISIBLE * ITEM_H) {
            var idx = Math.floor((y - startY + SHOP.scroll) / ITEM_H);
            if (idx >= 0 && idx < list.length) { SHOP.selected = list[idx]; SHOP.descScroll = 0; RPG.sound("dmzpack:pip_menu", 1, 1); return false; }
        }
        if (SHOP.buyRect && SHOP.buyRect[2] && U.inside(x, y, SHOP.buyRect[0], SHOP.buyRect[1], 74, 20)) {
            RPG.net.send("dmz_npc", { a: "buy", npc: SHOP.npc, skill: SHOP.selected });
            return false;
        }
    }
    function shopScroll(x, y, delta) {
        if (!SHOP) return;
        var py = SHOP.cy - 105, d = delta > 0 ? 1 : -1;
        if (x >= 12 && x <= 153 && y >= py && y <= py + 213) { SHOP.scroll = Math.max(0, SHOP.scroll - d * ITEM_H * 2); return; }
        if (SHOP.descRect && U.inside(x, y, SHOP.descRect[0], SHOP.descRect[1], SHOP.descRect[2] + 4, SHOP.descRect[3])) SHOP.descScroll = Math.max(0, SHOP.descScroll - d * 24);
    }
    RPG.net.on("dmz_skills_state", function (d) {
        if (SHOP && d && d.skills) { SHOP.st.skills = d.skills; SHOP.st.done = d.done || SHOP.st.done; SHOP.st.android = !!d.android; }
    });

    return { open: open, close: close, openSkills: openSkills };
})();
