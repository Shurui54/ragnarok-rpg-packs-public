// =====================================================================================
//  DMZ CharacterStatsScreen (V): name plate, INFORMATION, STATS with +/multiplier and TPC,
//  STATISTICS (derived values) and the bottom navigation row, laid out like DragonMine Z.
//  Values come from the same formulas the server uses (shared/02_dmz_formulas.js).
// =====================================================================================
var STATS_SCREEN = (function () {
    var D = DMZ_DATA, F = DMZ_F;
    var FONT = "dmzpack:smooth";
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png", MENU_SMALL = "dmzpack:textures/gui/menu/menusmall.png";
    var NAV = "dmzpack:textures/gui/buttons/menubuttons.png", BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var MULTS = [1, 10, 100, 1000];
    var st = { mult: 0 };
    var T = function (k) { return RPG.translate(k); };

    function view() {
        var p = RPG.player, mult = RPG.getVar("dmz_mult", null) || {};
        return { stat: function (k) { return p.stat(D.STAT_IDS[k]); }, cls: p.playerClass || "warrior",
            release: Number(RPG.getVar("dmz_release", 0)) || 0, mult: function (k) { return typeof mult[k] === "number" ? mult[k] : 1; },
            armor: 0, toughness: 0, race: D.DMZ[p.race] || p.race };
    }
    function bordered(ctx, t, x, y, color, align) { ctx.textStyled(t, x, y, 1, color, 1, align === undefined ? 0.5 : align, FONT, "#000000"); }
    function plain(ctx, t, x, y, color, align) { ctx.textStyled(t, x, y, 1, color, 1, align || 0, FONT, null); }

    function open() {
        var els = [
            { id: "lpanel", type: "image", anchor: "left", x: 12, y: -105, w: 141, h: 213, texture: MENU_BIG, texW: 256, texH: 256, u: 0, v: 0, uw: 141, vh: 213 },
            { id: "lribbon", type: "image", anchor: "left", x: 29, y: -95, w: 107, h: 21, texture: MENU_BIG, texW: 256, texH: 256, u: 142, v: 22, uw: 107, vh: 21 },
            { id: "lheader", type: "image", anchor: "left", x: 43, y: -28, w: 79, h: 21, texture: MENU_BIG, texW: 256, texH: 256, u: 142, v: 0, uw: 79, vh: 21 },
            { id: "rpanel", type: "image", anchor: "right", x: -158, y: -105, w: 141, h: 213, texture: MENU_BIG, texW: 256, texH: 256, u: 0, v: 0, uw: 141, vh: 213 },
            { id: "rribbon", type: "image", anchor: "right", x: -141, y: -95, w: 107, h: 21, texture: MENU_BIG, texW: 256, texH: 256, u: 142, v: 22, uw: 107, vh: 21 },
            { id: "top", type: "image", anchor: "top", x: -70, y: 8, w: 145, h: 58, texture: MENU_SMALL, texW: 256, texH: 256, u: 0, v: 95, uw: 145, vh: 58 },
            { id: "model", type: "entity", anchor: "center", x: -35, y: -30, w: 80, h: 100, rotation: 180, followMouse: false, size: 75 }
        ];
        // "+" buttons (only when the stat can be raised) and the multiplier
        D.STATS.forEach(function (s, i) {
            els.push({ id: "plus_" + s, type: "button", anchor: "left", x: 27, y: -4 + 12 * i, w: 10, h: 10, texture: BUTTONS, texW: 256, texH: 256,
                u: 0, v: 0, uw: 10, vh: 10, hoverU: 0, hoverV: 10, onClick: function () { RPG.net.send("dmz_buy", { stat: s, n: MULTS[st.mult] }); } });
        });
        els.push({ id: "mult", type: "button", anchor: "left", x: 27, y: 71, w: 10, h: 10, texture: BUTTONS, texW: 256, texH: 256, u: 0, v: 0, uw: 10, vh: 10, hoverU: 0, hoverV: 10,
            onClick: function () { st.mult = (st.mult + 1) % MULTS.length; RPG.sound("dmzpack:pip_menu", 1, 1); } });
        // navigation row (BaseMenuScreen): party, stats, skills, quests, minigames, config
        var nav = [[-110, 120, "party"], [-70, 0, "stats"], [-30, 20, "skills"], [10, 60, "quests"], [50, 140, "minigames"], [90, 100, "config"]];
        nav.forEach(function (n) {
            els.push({ id: "nav_" + n[2], type: "button", anchor: "bottom", x: n[0], y: -30, w: 20, h: 20, texture: NAV, texW: 256, texH: 256,
                u: n[1], v: 0, uw: 20, vh: 20, hoverU: n[1], hoverV: 20, tooltip: n[2].charAt(0).toUpperCase() + n[2].slice(1),
                onClick: function () { navigate(n[2]); } });
        });
        RPG.screen.open({ id: "dmz_stats", referenceHeight: 360, background: "dim", elements: els, onRender: render });
    }

    function navigate(where) {
        RPG.sound("dmzpack:ui_menu_switch", 1, 1);
        if (where === "stats") return;
        RPG.net.send("dmz_menu", { tab: where });
    }

    function render(ctx) {
        var W = ctx.width, H = ctx.height, cx = W / 2, cy = H / 2, p = RPG.player, v = view();
        // top: name and race
        bordered(ctx, "§l" + p.name, cx + 2, 19, "#63FFFF");
        var race = RPG.translate("race.dragonminez." + (D.DMZ[p.race] || p.race));
        bordered(ctx, race, cx + 2, 46, "#FFFFFF");
        // left: INFORMATION
        bordered(ctx, "§lINFORMATION", 85, cy - 88, "#FBC51C");
        var rows = [["Level", String(p.level), "#FFFFFF"], ["TPs", F.sci(p.tp), "#FFE593"],
            ["Form", RPG.getVar("dmz_form_name", "") || "Base", "#C7EAFC"], ["Class", D.strip(T("class.dragonminez." + v.cls)), "#FFFFFF"]];
        rows.forEach(function (r, i) {
            plain(ctx, "§l" + r[0], 30, cy - 72 + 11 * i, "#D7FEF5");
            plain(ctx, r[1], 75, cy - 72 + 11 * i, r[2]);
        });
        // STATS
        bordered(ctx, "§lSTATS", 82, cy - 21, "#68CCFF");
        D.STATS.forEach(function (s, i) {
            var y = cy - 3 + 12 * i, m = v.mult(s);
            plain(ctx, "§l" + s, 42, y, "#D71432");
            var val = Math.floor(v.stat(s));
            plain(ctx, m !== 1 ? val + " x" + m.toFixed(2) : String(val), 75, y, m !== 1 ? "#FFFF00" : "#FFD7AB");
        });
        // cost of the current multiplier (AP first)
        var n = MULTS[st.mult], total = F.total(v), cls = D.CLASSES[v.cls] || D.CLASSES.warrior;
        if (p.statPoints > 0) { plain(ctx, "AP", 42, cy + 73, "#B36BFF"); plain(ctx, String(p.statPoints), 75, cy + 73, "#FFCE41"); }
        else { plain(ctx, "TPC", 42, cy + 73, "#2BFFE2"); plain(ctx, F.sci(F.cost(total, n, cls.tpCost)), 75, cy + 73, "#FFCE41"); }
        plain(ctx, "x" + n, 42, cy + 83, "#FFFFFF");
        // right: STATISTICS
        bordered(ctx, "§lSTATISTICS", W - 85, cy - 88, "#F91E64");
        var stats = [["Melee DMG", F.melee(v)], ["Strike DMG", F.strike(v)], ["Stamina", F.maxStamina(v)], ["Defense", F.flatDefense(v)],
            ["Health", F.maxHealth(v)], ["Ki DMG", F.ki(v)], ["Max Ki", F.maxKi(v)], ["Speed", F.speed(v) * 100]];
        stats.forEach(function (r, i) {
            var y = cy - 64 + 12 * i;
            plain(ctx, r[0], W - 137, y, "#7CFDD6");
            var txt = r[0] === "Speed" ? Math.round(r[1]) + "%" : F.compact(Math.round(r[1] * 100) / 100);
            ctx.textStyled(txt, W - 50, y, 1, "#FFFFFF", 1, 0.5, FONT, null);
        });
        plain(ctx, "Power Level", W - 137, cy + 54, "#7CFDD6");
        ctx.textStyled(p.race === "glind" ? "???" : F.compact(F.battlePower(v)), W - 50, cy + 54, 1, "#FFE593", 1, 0.5, FONT, null);
        plain(ctx, "TP Multiplier", W - 137, cy + 78, "#7CFDD6");
        var tpm = 1 + (cls.tpGain - 1) + (F.progression(v) - 1) + (p.race === "frost_demon" ? 0.25 : 0) + (p.dimension === "ragnarok_rpg:time_chamber" ? 0.75 : 0);
        ctx.textStyled("x" + tpm.toFixed(2), W - 50, cy + 78, 1, "#FFFFFF", 1, 0.5, FONT, null);
    }

    return { open: open };
})();

RPG.net.on("dmz_open_stats", function () { STATS_SCREEN.open(); });
