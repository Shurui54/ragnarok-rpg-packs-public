// =====================================================================================
//  DMZ melee and guard input (MinecraftMixin / CombatAttackRequestC2S, BLOCK_KEY)
//  Left click with empty hands: the next step of the fist combo, animated at once on your
//  screen and sent to the server (which shows it to everyone and applies the damage).
//  Hold right click with empty hands: guard (a quick press is a parry).
// =====================================================================================
(function () {
    var C = DMZ_COMBAT, st = { count: 0, last: -1000, guarding: false, relock: 0 };

    function emptyHands() {
        var h = RPG.player.heldItem;
        return !h || h === "minecraft:air";
    }
    function created() { return !!RPG.getVar("dmz_created", 0); }
    function now() { return RPG.nowMs(); }

    RPG.on("mouse", function (button, down) {
        if (RPG.screen.getOpen() || !created()) return;
        if (button === 0 && down) {
            if (!emptyHands() || st.guarding || RPG.player.hasEffect("stunned")) return;
            var t = C.timing(4), ms = now();
            if (ms - st.last < t.cooldown * 50) return;                     // still recovering
            if (ms - st.last > (t.cooldown + C.CFG.comboResetExtra) * 50) st.count = 0;
            var infusion = RPG.player.hasEffect("ki_infusion") && RPG.player.level >= 5;
            var atk = C.attackFor(st.count, infusion);
            st.last = ms;
            DBR_ANIMATOR.playMelee(atk.anim, t.speed);
            RPG.net.send("dmz_melee", { c: st.count, a: atk.anim, s: t.speed });
            st.count++;
        } else if (button === 1) {
            if (down && emptyHands() && !st.guarding && ms2() >= st.relock && !RPG.player.hasEffect("stunned")) {
                st.guarding = true;
                DBR_ANIMATOR.setLocalGuard(true);
                RPG.net.send("dmz_guard", { on: true });
            } else if (!down && st.guarding) {
                st.guarding = false;
                st.relock = ms2() + 250;                                   // 5-tick relock after release
                DBR_ANIMATOR.setLocalGuard(false);
                RPG.net.send("dmz_guard", { on: false });
            }
        }
    });
    function ms2() { return now(); }

    // let go of the guard if a screen opens or you pick something up
    RPG.on("tick", function () {
        if (st.guarding && (RPG.screen.getOpen() || !emptyHands())) {
            st.guarding = false;
            DBR_ANIMATOR.setLocalGuard(false);
            RPG.net.send("dmz_guard", { on: false });
        }
    });
})();
