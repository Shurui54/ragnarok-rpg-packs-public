// =====================================================================================
//  95_dbr_rituals.js - the Ragnarok original's rituals: the Super Saiyan God charge ritual, the Super Saiyan 5 fusion with
//  Shenron and the Namekian god ritual at a dragon idol
// =====================================================================================
//  Port of the Ragnarok original (GPL-3.0, see NOTICE.md) shuruisutilities ritual/{SsgRitualManager, WishRitualManager, WishRitualStore,
//  RitualSettings, RitualAnnouncer, DragonBallRecreation, ShenronIdol*, PacketIdolPrompt/Confirm, SsgKnowledgeCommand},
//  compat/dmz/{RitualForms, RitualFormsCompat, RitualRaceMergeImpl, SuSsj5Wish, SuSsgKnowledgeWish} and api/key/RitualHooks.
//  The forms: shared/07_dmz_forms_data.js (SSJ5 on both SSJ4 ladders, rung 9; Primal Namekian, rung 4), their prices
//  (-1, granted only): shared/03_dmz_skills_data.js. The grave totems for dragon balls: 89_dbr_keep_inventory.js.
//  The idol screen: client/scripts/95_dbr_rituals.js.
//
//  - Knowledge of God Ki (it replaced the Knowledge of Super Saiyan God): a Shenron wish shown to Saiyans of level 5000+
//    (ssgRitual.wishMinLevel). With it, the god ritual awakens God Ki: since 4.18.0 the Ragnarok original's charge ritual
//    (charge ki with 5 other charging Saiyans within 6 blocks for 3 s) is performed the original's way instead, through
//    ki sharing (64_dmz_kishare.js), with this file's counts: ssgRitual.requiredChargers givers (5) on servers and LAN,
//    ssgRitual.singleplayerRequiredChargers (0 = the vessel alone, holding Charge Ki for 3 s) in singleplayer.
//  - Every granted wish counts per player and set (Earth, Namek). From the eleventh Earth wish on, a Saiyan in Super
//    Saiyan 4 at level 10000+ is offered "Fuse with Shenron": it costs 5000 levels (taken from random stats, none
//    below zero), grants Super Saiyan 5 (superforms rung 9), is announced to the whole server, and spends the Earth
//    set: its balls are gone and a Shenron Idol is left somewhere within 1000 blocks of spawn (on the Earth radar).
//  - The eleventh Namek wish spends the Namek set the same way and leaves a Porunga Idol (on the Namek radar).
//  - A namekian of level 10000+ who right-clicks an idol (in hand) is offered the bargain: all the balls of that set
//    back in their hands and the Namekian God form (Primal Namekian, superforms rung 4) for 5000 levels; accepting
//    restores the set and is announced to the server. Shift + right-click places the idol; break it to pick it up.
//  (The fusion and the recreation are in the Ragnarok original's private Ragnarok Key; their rules here come from the public
//  core's requirements, numbers, lang and prompt, and RitualForms' grants and level cost.)
//  Ops: /rpgc rituals info [player] | wishes <earth|namek> <n> | knowledge | ssj5 | primal | spend <earth|namek> | idol <shenron|porunga>
//       | unlock ssj5 [player] (waive the Earth wish count for the SSJ5 wish) | lock ssj5 [player]
// =====================================================================================
// hooks 57_dragon_balls.js calls (set below)
var dbrWishVisible = null, dbrWishBlocked = null, dbrRitualWish = null, dbrWishGranted = null, dbrWishHint = null;
var DBR_RITUALS = (function () {
    var C = DBR_RITUALS_CFG;
    var IDOL_SET = { shenron: "earth", porunga: "namek" }, SET_IDOL = { earth: "shenron", namek: "porunga" };
    function now() { return RPG.server.getTick(); }
    function uid(p) { return String(p.uuid); }
    function online(u) { var l = RPG.server.players(); for (var i = 0; i < l.length; i++) if (uid(l[i]) === u) return l[i]; return null; }
    function race(p) { return typeof DMZ_TF !== "undefined" ? DMZ_TF.race(p) : p.race; }
    function level(p) { return p.getLevel(); }
    function reqLevel() { return C.get("wishRituals.requiredLevel"); }
    function cost() { return C.get("wishRituals.levelCost"); }
    function isSsgRace(p) { var r = race(p); return r === "saiyan" || r === "half_saiyan"; }

    // ---- WishRitualStore (player vars, saved with the character) -------------------------------------
    function count(p, set) { return Number(p.getVar("dmzr_wishes_" + set, 0)) || 0; }
    function flag(p, k) { return !!p.getVar("dmzr_ritual_" + k, 0); }
    function setFlag(p, k) { p.setVar("dmzr_ritual_" + k, 1); }
    /** An op waived the Earth wish count for this player's SSJ5 wish (/rpgc rituals unlock ssj5 <player>). */
    function ssj5Waived(p) { return !!p.getVar("dmzr_ssj5_waive", 0); }
    function wishesOk(p) { return ssj5Waived(p) || count(p, "earth") >= C.get("wishRituals.wishThreshold"); }

    // ---- RitualAnnouncer: one chat line and a title for everyone online ---------------------------------
    function announce(chat, title, subtitle, colour) {
        RPG.server.broadcast(colour + chat);
        RPG.server.players().forEach(function (v) { v.title(colour + "§l" + title, "§7" + subtitle); });
    }

    // ---- RitualForms.applyLevelCost: remove levels from random stats, none below zero ---------------------
    function applyLevelCost(p, levels) {
        if (levels <= 0) return 0;
        var start = level(p), target = Math.max(1, start - levels), ids = DMZ_DATA.STATS.map(function (k) { return DMZ_DATA.STAT_IDS[k]; });
        var guard = 0;
        while (level(p) > target && guard++ < 400) {
            var have = ids.filter(function (id) { return p.allocated(id) > 0; });
            if (!have.length) break;
            var v = dmzView(p), cm = v.capMult > 1 ? v.capMult : 1, maxV = Math.round(1000000 * cm);
            var perLevel = Math.max(1, (maxV * 6) / Math.max(1, maxV - 1));
            var need = Math.max(1, Math.ceil((level(p) - target) * perLevel)), chunk = Math.max(1, Math.ceil(need / (have.length * 8)));
            var id = have[Math.floor(Math.random() * have.length)];
            p.addStat(id, -Math.min(chunk, p.allocated(id)));
            p.refreshStats();
            if (typeof DMZ_F !== "undefined") p.setLevel(DMZ_F.level(dmzView(p)), { silent: true });
        }
        return start - level(p);
    }
    function raiseSuperform(p, expectRace, rung) {
        if (race(p) !== expectRace || typeof DMZ_SKILLS === "undefined") return false;
        if (DMZ_SKILLS.level(p, "superforms") < rung) DMZ_SKILLS.setLevel(p, "superforms", rung, "ritual");
        if (typeof DMZ_TF !== "undefined") DMZ_TF.refresh(p);
        return true;
    }

    // ---- the wish rows (SuSsgKnowledgeWish / SuSsj5Wish), read by 57_dragon_balls.js ------------------------
    function inSsj4(p) { var f = String(p.getVar("dmz_form", "") || ""); return race(p) === "saiyan" && /:supersaiyan4$/.test(f); }
    function canWishForSsj5(p) {
        return inSsj4(p) && level(p) >= reqLevel() && wishesOk(p) && !flag(p, "ssj5");
    }
    function ssgWishVisible(p) { return isSsgRace(p) && level(p) >= C.get("ssgRitual.wishMinLevel"); }
    // DBR shows each ritual row to the race it is for until it is taken, greyed with what is still missing
    // (dbrWishHint), so players can find them: the Ragnarok original hid them because the original resolves picks by list index, DBR
    // resolves them against the rows it sent this player (57_dragon_balls.js visibleWishes), so nothing shifts.
    // 4.18.0: the SSJ5 and God Ki rows always show (for every race, already awakened or not), greyed with the reason
    // (dbrWishHint) when they can't be taken, so nobody wonders where they went; granting still refuses (dbrWishBlocked)
    dbrWishVisible = function (p, w) {
        if (w.ritual === "ssg_knowledge") return false;            // replaced by the Knowledge of God Ki (kept so old picks resolve)
        return true;
    };
    /** What a player still lacks for a ritual row, or null when it can be taken now. */
    dbrWishHint = function (p, w) {
        if (w.ritual === "ssg_knowledge" || w.ritual === "godki_knowledge") {
            if (!isSsgRace(p)) return "Only saiyans can receive the knowledge of God Ki (you are " + race(p) + ").";
            if (p.getVar("dmzr_godki", 0)) return "Already awakened: you have God Ki.";
            if (flag(p, "godki_knowledge")) return "Already received: perform the god ritual to awaken God Ki.";
            if (ssgWishVisible(p)) return null;
            return "Needs level " + C.get("ssgRitual.wishMinLevel") + " (you are " + level(p) + ").";
        }
        if (w.ritual === "ssj5") {
            if (race(p) !== "saiyan") return "Only saiyans can fuse with Shenron for Super Saiyan 5 (you are " + race(p) + ").";
            if (flag(p, "ssj5")) return "Already awakened: you have Super Saiyan 5.";
            if (canWishForSsj5(p)) return null;
            var need = [], made = count(p, "earth"), th = C.get("wishRituals.wishThreshold");
            if (level(p) < reqLevel()) need.push("level " + reqLevel() + " (you are " + level(p) + ")");
            if (!wishesOk(p)) need.push(th + " Earth wishes made first (you have " + made + ")");
            if (!inSsj4(p)) need.push("to be transformed into SSJ 4 when you wish");
            return "Needs " + need.join(", ") + ".";
        }
        return null;
    };
    dbrWishBlocked = function (p, w) {
        if (w.ritual === "ssg_knowledge" || w.ritual === "godki_knowledge") {
            if (isSsgRace(p) && level(p) >= C.get("ssgRitual.wishMinLevel") && !flag(p, "godki_knowledge")) return false;
            if (!isSsgRace(p)) p.tell("The knowledge of God Ki means nothing to one who is not a saiyan.");
            else if (flag(p, "godki_knowledge")) p.tell("You already carry the knowledge of God Ki.");
            else p.tell("The divine power is still beyond your reach. Grow stronger and return at level " + C.get("ssgRitual.wishMinLevel") + ".");
            return true;
        }
        if (w.ritual === "ssj5") {
            if (canWishForSsj5(p)) return false;
            if (level(p) < reqLevel()) p.tell("You feel Shenron's power stir, but you are not yet strong enough. Reach level " + reqLevel() + ".");
            else p.tell("&e" + dbrWishHint(p, w));
            return true;
        }
        return true;
    };
    dbrRitualWish = function (p, w) {
        if (w.ritual === "ssg_knowledge" || w.ritual === "godki_knowledge") {     // SsgKnowledgeCommand.grant, now God Ki
            setFlag(p, "godki_knowledge");
            var n = requiredChargers();
            p.tell("Shenron grants you the knowledge of God Ki. " + (n > 0 ? "In Super Saiyan Mastered, " + n + " pure-hearted Saiyans in Super Saiyan must share their ki with you (Ctrl + Alt + right click)"
                : "Charge your ki in Super Saiyan Mastered") + " to perform the ritual and awaken it.");
            RPG.log("[ritual] " + p.name + " wished for the knowledge of God Ki.");
        } else if (w.ritual === "ssj5") fuseWithShenron(p);
    };
    function fuseWithShenron(p) {
        var lost = applyLevelCost(p, cost());
        raiseSuperform(p, "saiyan", 9);
        setFlag(p, "ssj5");
        p.tell("§bYou fuse with Shenron and awaken Super Saiyan 5!");
        announce(p.name + " has fused with the eternal dragon and awakened Super Saiyan 5!", "Super Saiyan 5", p.name + " fused with Shenron", "§b");
        spendSet("earth");
        RPG.log("[ritual] " + p.name + " fused with Shenron (Super Saiyan 5), " + lost + " levels taken");
    }
    /** WishRitualManager.onWishGranted: count every wish of the Earth and Namek sets; the eleventh Namek wish spends it. */
    dbrWishGranted = function (p, set, wishes) {
        if (set !== "earth" && set !== "namek") return;
        var n = count(p, set) + wishes;
        p.setVar("dmzr_wishes_" + set, n);
        if (set === "namek" && n > C.get("wishRituals.wishThreshold") && !(dbrBallSet && dbrBallSet.isSpent("namek"))) spendSet("namek");
    };

    // ---- spent sets and the idols (ShenronIdol, the key's ShenronIdolSpawner) ----------------------------
    function idols() { var v = RPG.data.get("dbr_idols", null); return v && typeof v === "object" ? v : {}; }
    function saveIdols(v) { RPG.data.set("dbr_idols", v); }
    function spendSet(set) {
        if (!dbrBallSet) return;
        // a summoned dragon's set scatters as it leaves: spend it once that has happened
        RPG.schedule(80, function () {
            dbrBallSet.spend(set);
            var sp = RPG.world.spawnPoint(), r = 1000, v = idols(), key = set + "@" + now();
            v[key] = { dragon: SET_IDOL[set], dim: DB_SETS[set].dim, x: Math.floor((sp.x || 0) + (Math.random() * 2 - 1) * r), z: Math.floor((sp.z || 0) + (Math.random() * 2 - 1) * r), y: null };
            saveIdols(v);
            RPG.log("[ritual] the " + set + " set is spent; a " + SET_IDOL[set] + " idol waits at " + v[key].x + ", " + v[key].z);
            // DBR: tell everyone where it went and what it is for (the key's spawner did this silently)
            var idolName = SET_IDOL[set] === "shenron" ? "Shenron Idol" : "Porunga Idol", where = set === "namek" ? "Namek" : "Earth";
            RPG.server.broadcast("§5The " + where + " dragon balls are spent and turned to stone. §7A §5" + idolName + "§7 now lies within " + r +
                " blocks of spawn on " + where + " (it shows on the dragon radar).");
            RPG.server.broadcast("§7A namekian of level " + reqLevel() + "+ who uses it from their hand can restore the set and awaken §aPrimal Namekian§7, for " + cost() + " levels.");
        });
    }
    RPG.every(40, function () {                  // drop a waiting idol once its chunk is loaded (like a scattered ball)
        var v = idols(), changed = false;
        Object.keys(v).forEach(function (k) {
            var e = v[k];
            if (e.y !== null || !RPG.server.hasDimension(e.dim) || !RPG.world.isLoaded(e.dim, e.x, e.z)) return;
            var y = RPG.world.surfaceY(e.dim, e.x, e.z);
            if (y < -9000) return;
            var g = 0;
            while (g++ < 320 && /^minecraft:(water|air|cave_air|kelp|kelp_plant|seagrass|tall_seagrass)$/.test(String(RPG.world.getBlock(e.dim, e.x, y - 1, e.z)))) y--;
            RPG.world.setBlock(e.dim, e.x, y, e.z, RPG.blocks.id(e.dragon + "_idol_block"));
            e.y = y; changed = true;
        });
        if (changed) saveIdols(v);
    });
    if (typeof DBR_RADAR_EXTRA !== "undefined") DBR_RADAR_EXTRA.push(function (out) {     // registered on the dragon radar
        var v = idols();
        Object.keys(v).forEach(function (k) { var e = v[k], set = IDOL_SET[e.dragon]; if (out.sets[set]) out.sets[set].push({ x: e.x, z: e.z, d: e.dim }); });
    });
    function forgetIdolAt(dim, x, y, z) {
        var v = idols(), changed = false;
        Object.keys(v).forEach(function (k) { var e = v[k]; if (e.dim === dim && e.x === x && e.z === z && (e.y === null || Math.abs(e.y - y) <= 1)) { delete v[k]; changed = true; } });
        if (changed) saveIdols(v);
    }
    ["shenron", "porunga"].forEach(function (dragon) {
        var item = dragon + "_idol", name = dragon === "shenron" ? "&5Shenron Idol" : "&5Porunga Idol";
        RPG.blocks.define(item + "_block", {
            name: name, model: "dbr:rpg/block/" + item, itemModel: "dbr:rpg/item/" + item, hardness: 2.5, light: 7, decor: true, renderType: "translucent",
            shape: [4, 0, 4, 12, 11.2, 12], sound: "stone", drops: [{ item: item, count: 1 }], support: ["any"], fragile: false,
            onBreak: function (p, x, y, z) { forgetIdolAt(p.dimension, x, y, z); },
            onUse: function (p) { p.actionbar("&7Pick the idol up and use it from your hand."); }
        });
        RPG.items.define(item, {
            name: name, model: "dbr:rpg/item/" + item, maxStack: 1, rarity: "epic",
            lore: ["Right-click: the eternal dragon's bargain (namekians)", "Shift + right-click a block: place it"],
            onUse: function (p) {
                if (p.isSneaking()) { place(p, dragon); return; }
                openPrompt(p, dragon);
            }
        });
    });
    function place(p, dragon) {
        var hit = p.raycast(5, { blocks: true, entities: false });
        if (!hit || hit.hit !== "block") return;
        var f = { up: [0, 1, 0], down: [0, -1, 0], north: [0, 0, -1], south: [0, 0, 1], west: [-1, 0, 0], east: [1, 0, 0] }[hit.face] || [0, 1, 0];
        var x = hit.blockX + f[0], y = hit.blockY + f[1], z = hit.blockZ + f[2];
        if (!RPG.world.isReplaceable(p.dimension, x, y, z)) return;
        if (!p.takeItem(dragon + "_idol", 1)) return;
        RPG.world.setBlock(p.dimension, x, y, z, RPG.blocks.id(dragon + "_idol_block"));
    }

    // ---- DragonBallRecreation: the prompt (PacketIdolPrompt) and the confirmation (PacketIdolConfirm) ---------
    function prompt(p, dragon) {
        var set = IDOL_SET[dragon], refusal = "NONE";
        if (race(p) !== "namekian") refusal = "NOT_NAMEKIAN";
        else if (level(p) < reqLevel()) refusal = "TOO_LOW_LEVEL";
        else if (p.countItem(dragon + "_idol") <= 0) refusal = "NO_IDOL";
        else if (!dbrBallSet || !dbrBallSet.isSpent(set)) refusal = "NOTHING_TO_RESTORE";
        return { dragon: dragon, set: set, level: level(p), requiredLevel: reqLevel(), levelCost: cost(), ballCount: DB_SETS[set].stars, refusal: refusal };
    }
    function refusalText(pr) {
        return { NOT_NAMEKIAN: "Only a namekian can restore what the dragon balls lost.", TOO_LOW_LEVEL: "You are not strong enough to pay this price. Reach level " + pr.requiredLevel + ".",
            NO_IDOL: "You are not carrying a " + (pr.dragon === "porunga" ? "Porunga" : "Shenron") + " Idol.", NOTHING_TO_RESTORE: "No dragon ball set is missing. There is nothing to restore." }[pr.refusal] || "";
    }
    function openPrompt(p, dragon) { RPG.net.send(p, "dbr_idol_prompt", prompt(p, dragon)); }
    RPG.net.on("dbr_idol_confirm", function (p, d) {
        if (!p || !d || !IDOL_SET[d.dragon]) return;
        var pr = prompt(p, d.dragon);
        if (pr.refusal !== "NONE") { p.tell(refusalText(pr)); return; }
        if (!p.takeItem(d.dragon + "_idol", 1)) return;
        var lost = applyLevelCost(p, pr.levelCost);
        var n = dbrBallSet.restore(pr.set, p);
        raiseSuperform(p, "namekian", 4);
        setFlag(p, "namekian_god");
        p.tell("§aThe dragon balls are whole again. " + n + " of them are yours.");
        p.tell("§aYou recreate the shattered dragon balls and awaken Primal Namekian!");
        announce(p.name + " has gathered the scattered dragon balls. The set is whole again!", "The Balls Return", p.name + " restored what was defiled", "§a");
        RPG.log("[ritual] " + p.name + " restored the " + pr.set + " set at a " + d.dragon + " idol, " + lost + " levels taken");
    });

    // ---- SsgRitualManager: the charge ritual's counts. Since 4.18.0 the ritual itself is the original's ki-sharing god
    // ritual (64_dmz_kishare.js DMZ_GOD_RITUAL), which reads these counts: the charge ritual's own trigger is gone.
    function requiredChargers() { return Math.max(0, dbrRitualSolo() ? C.get("ssgRitual.singleplayerRequiredChargers") : Math.max(1, C.get("ssgRitual.requiredChargers"))); }

    // ---- ops ----------------------------------------------------------------------------------------
    RPG.commands.register("rituals", {
        permission: 2, description: "/rpgc rituals info [player] | wishes <earth|namek> <n> | knowledge | ssj5 | primal | spend <set> | idol <shenron|porunga> | unlock ssj5 [player] | lock ssj5 [player]",
        run: function (p, a) {
            var sub = String(a[0] || "info");
            // unlock / lock ssj5 [player]: waive (or restore) the Earth wish count for the SSJ5 wish; the rest of the
            // ritual (level, wishing while in SSJ 4, the level cost) stays as it is
            if (sub === "unlock" || sub === "lock") {
                if (String(a[1] || "") !== "ssj5") { if (p) p.tell("&cUsage: /rpgc rituals " + sub + " ssj5 [player]"); return; }
                var who = a[2] ? RPG.server.player(a[2]) : p;
                if (!who) { if (p) p.tell("&cNo online player " + (a[2] || "") + "."); else RPG.log("[ritual] no player"); return; }
                who.setVar("dmzr_ssj5_waive", sub === "unlock" ? 1 : 0);
                var msg = sub === "unlock"
                    ? who.name + " can now wish for Super Saiyan 5 without the " + C.get("wishRituals.wishThreshold") + " Earth wishes first (still needs level " + reqLevel() + " and SSJ 4 when wishing)."
                    : who.name + " needs the " + C.get("wishRituals.wishThreshold") + " Earth wishes again before the Super Saiyan 5 wish.";
                if (p) p.tell("&e" + msg); else RPG.log("[ritual] " + msg);
                if (who !== p) who.tell(sub === "unlock" ? "&bShenron will hear your wish for Super Saiyan 5 without the usual wishes first." : "&eThe Super Saiyan 5 wish needs " + C.get("wishRituals.wishThreshold") + " Earth wishes first again.");
                RPG.log("[ritual] " + (p ? p.name : "console") + " " + sub + "ed the SSJ5 wish count for " + who.name);
                return;
            }
            var t = a[1] && a[0] === "info" ? RPG.server.player(a[1]) || p : p;
            if (!t) return;
            if (sub === "wishes") { t.setVar("dmzr_wishes_" + (a[1] === "namek" ? "namek" : "earth"), Number(a[2]) || 0); }
            else if (sub === "knowledge") setFlag(t, "godki_knowledge");
            else if (sub === "godki") { t.setVar("dmzr_godki", 1); t.setVar("dmz_god_ki", 1); }
            else if (sub === "ssj5") { raiseSuperform(t, "saiyan", 9); setFlag(t, "ssj5"); }
            else if (sub === "primal") { raiseSuperform(t, "namekian", 4); setFlag(t, "namekian_god"); }
            else if (sub === "spend") spendSet(a[1] === "namek" ? "namek" : "earth");
            else if (sub === "idol") t.giveItem((a[1] === "porunga" ? "porunga" : "shenron") + "_idol", 1);
            t.tell("&eRituals: race " + race(t) + ", level " + level(t) + ", earth wishes " + count(t, "earth") + ", namek wishes " + count(t, "namek") + ", God Ki knowledge " + flag(t, "godki_knowledge") + ", God Ki " + !!t.getVar("dmzr_godki", 0) +
                ", SSJ5 " + flag(t, "ssj5") + ", Namekian God " + flag(t, "namekian_god") + ", god ritual givers needed here " + requiredChargers() +
                ", earth spent " + !!(dbrBallSet && dbrBallSet.isSpent("earth")) + ", namek spent " + !!(dbrBallSet && dbrBallSet.isSpent("namek")) +
                ", SSJ5 wish count waived " + ssj5Waived(t) + ", SSJ5 offered " + canWishForSsj5(t));
        },
        suggest: function (p, a) {
            if (a.length === 2 && (a[0] === "unlock" || a[0] === "lock")) return ["ssj5"];
            if (a.length === 3 && (a[0] === "unlock" || a[0] === "lock")) return RPG.server.players().map(function (x) { return x.name; });
            return ["info", "wishes", "knowledge", "godki", "ssj5", "primal", "spend", "idol", "unlock", "lock"];
        }
    });

    return { applyLevelCost: applyLevelCost, canWishForSsj5: canWishForSsj5, requiredChargers: requiredChargers, prompt: prompt };
})();
