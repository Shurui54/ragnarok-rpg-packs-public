// =====================================================================================
//  64_dmz_kishare.js - the original's Ki sharing and its god ritual (which awakens God Ki here)
// =====================================================================================
//  Port of the original (GPL-3.0, see NOTICE.md): server/events/players/{KiShareService, GodRitualService},
//  common/network/C2S/KiShareC2S, common/util/GodRitualHelper, GeneralServerConfig.{KiTransferConfig, GodRitualConfig},
//  the ki share and god ritual parts of StatsData / Status / Cooldowns / TickHandler / UpdateStatC2S /
//  PlayerAttackHelper / EffectsCommand, and DefaultFormsFactory's godritual group (shared/07_dmz_forms_data.js; its
//  multipliers: 31_dmz_transform.js godRitualMult). Client side (the chord, poses, ki streams, the Spirit Bomb's orbs,
//  the ring's tracers, the white shell): client/scripts/46_dmz_kishare.js.
//
//  Ki sharing: hold Ctrl + Alt + right click looking at a player within 8 blocks. You give 2.5 % of your max ki a
//  second (no ki regen while you give), move and fly at 40 % speed and can't attack, guard, charge, use items or
//  techniques; after 1 s every giver raises the receiver's STR/SKP/DEF/PWR by 5 % (up to 5 givers), and keeps doing so
//  5 s per 3 s given after letting go. Each 3 s given also tires you: -5 % to the same stats (up to -25 %) that wears
//  off as long as you gave. Taking 10 % of your max health in hits breaks it. Ki that no longer fits in a receiver who
//  is charging a ki attack pays that attack's charge instead (up to their max ki).
//  The Spirit Bomb: while someone charges one, everyone within 64 blocks is called every 2.5 s; the chord (aimed at
//  nobody) gives to the nearest caster: 10 % of your max ki a second grows the bomb (up to 2.5x the largest ki attack,
//  up to 3x its damage) and it waits at full charge while anyone still gives.
//
//  The god ritual (the original's Super Saiyan God ritual; here it awakens God Ki for good): Saiyans in Super Saiyan (or
//  SSJ Mastered), each pure of heart (alignment 90+ or 10-), share their ki with a vessel in SSJ Mastered within 5 blocks
//  who holds Shenron's Knowledge of God Ki (95_dbr_rituals.js). Once enough givers have given 1 s: they glide into a ring
//  2.5 blocks round the vessel and hold hands, the vessel channels 10 s (a gauge fills), rises up to 6 blocks over 2 s,
//  glows white for 1 s and awakens God Ki. The givers then rest 30 minutes (God Ritual CD). A hit worth 25 % of someone's
//  health, a death, a logout, leaving the dimension or dropping out of the form ends it (30 s rest).
//  How many givers (DBR's own settings, ragnarok_rpg/config/dbr_rituals.json or the original config menu's Server rows):
//    ssgRitual.requiredChargers              5   dedicated servers and worlds open to LAN
//    ssgRitual.singleplayerRequiredChargers  0   a singleplayer world (only its owner can join): with 0 the vessel performs
//                                               the ritual alone by holding Charge Ki for godRitual.soloChargeSeconds (3 s)
//                                               in SSJ Mastered; every other rule stays the original's.
//  (godRitual.requiredDonors / singleplayerRequiredDonors are kept in the file but no longer read: the ki-sharing ritual
//  and the charge ritual were merged into this one in 4.18.0, and the charge ritual's counts are the ones that stay.)
//  Op test: /rpgc godritual status | reset (clears your God Ritual CD) | end
// =====================================================================================
var DBR_RITUALS_CFG = RPG.config.define("dbr_rituals", {
    kiShare: {
        enabled: { default: true, client: true, comment: "Ki sharing (Ctrl + Alt + right click a player)" },
        kiPercentPerSecond: { default: 0.025, min: 0, max: 1, comment: "Share of the giver's max ki given each second" },
        boostDelaySeconds: { default: 1.0, min: 0, max: 60, comment: "Seconds of giving before a giver boosts the receiver (and counts for the god ritual)" },
        boostPerDonor: { default: 0.05, min: 0, max: 10, comment: "STR/SKP/DEF/PWR bonus per giver" },
        maxBoostDonors: { default: 5, min: 0, max: 100, integer: true, comment: "Most givers that add a bonus" },
        donorSpeedMultiplier: { default: 0.4, min: 0, max: 1, client: true, comment: "Giver movement and flight speed" },
        interruptDamageRatio: { default: 0.10, min: 0.01, max: 10, comment: "Damage (share of max health) that breaks a giver's link" },
        startRange: { default: 8.0, min: 1, max: 64, client: true, comment: "Blocks to the receiver to start" },
        maxLinkDistance: { default: 32.0, min: 1, max: 256, comment: "Blocks before the link breaks" },
        attackChargeCreditRatio: { default: 1.0, min: 0, max: 100, comment: "Ki beyond a full bar given to someone charging a ki attack pays its charge, up to this share of their max ki" },
        intervalSeconds: { default: 3.0, min: 0.05, max: 600, comment: "Each interval given: the receiver keeps the bonus retainSecondsPerInterval longer, the giver tires one step" },
        retainSecondsPerInterval: { default: 5.0, min: 0, max: 600, comment: "Seconds of bonus kept per interval given" },
        donorPenaltyPerInterval: { default: 0.05, min: 0, max: 1, comment: "Giver penalty per interval" },
        donorPenaltyMax: { default: 0.25, min: 0, max: 0.95, comment: "Largest giver penalty" },
        restartCooldownSeconds: { default: 2.0, min: 0, max: 600, comment: "Seconds before a giver can start again" }
    },
    godRitual: {
        enabled: { default: true, client: true, comment: "The god ritual (it awakens God Ki) may start" },
        requiredDonors: { default: 5, min: 1, max: 100, integer: true, client: true, comment: "Not read since 4.18.0: ssgRitual.requiredChargers is the number of givers" },
        singleplayerRequiredDonors: { default: 0, min: 0, max: 100, integer: true, client: true, comment: "Not read since 4.18.0: ssgRitual.singleplayerRequiredChargers is the singleplayer number of givers" },
        soloChargeSeconds: { default: 3.0, min: 0.5, max: 600, client: true, comment: "Seconds of Charge Ki that start a solo ritual" },
        donorForms: { default: ["ssgrades.supersaiyan", "supersaiyan.supersaiyanmastered"], comment: "group.form the givers must be in" },
        recipientForms: { default: ["supersaiyan.supersaiyanmastered"], comment: "group.form the vessel must be in" },
        pureGoodMinAlignment: { default: 90, min: 0, max: 100, integer: true, comment: "A pure heart: alignment at least this..." },
        pureEvilMaxAlignment: { default: 10, min: 0, max: 100, integer: true, comment: "...or at most this" },
        ritualRadius: { default: 5.0, min: 1, max: 64, comment: "Givers must be within this many blocks of the vessel (horizontally)" },
        ritualVerticalRange: { default: 3.0, min: 0, max: 64, comment: "...and this many blocks above or below" },
        ringRadius: { default: 2.5, min: 1, max: 64, comment: "Radius of the ring the givers glide into" },
        channelSeconds: { default: 10.0, min: 1, max: 600, comment: "Channel time" },
        liftHeight: { default: 6.0, min: 0, max: 64, comment: "Blocks the vessel rises (less under a ceiling)" },
        liftSeconds: { default: 2.0, min: 0.05, max: 60, comment: "Rise time" },
        glowInSeconds: { default: 1.0, min: 0.05, max: 60, comment: "White shell fade in (then God Ki)" },
        glowOutSeconds: { default: 1.5, min: 0.05, max: 60, comment: "White shell fade out" },
        shellColor: { default: "#6FD8FF", client: true, comment: "Shell colour" },
        interruptDamageRatio: { default: 0.25, min: 0.01, max: 10, comment: "Damage (share of max health) taken by one body that breaks the ritual" },
        interruptCooldownSeconds: { default: 30.0, min: 0, max: 86400, comment: "Rest after a broken ritual" },
        cooldownMinutes: { default: 30.0, min: 0, max: 100000, comment: "Rest after a ritual (and after the old Super Saiyan God form ends)" },
        durationMinutes: { default: 5.0, min: 0.05, max: 100000, comment: "How long the old Super Saiyan God form lasts (characters still in it)" },
        powerBonus: { default: 0.30, min: 0, max: 100, comment: "The old Super Saiyan God form multiplies the best form's gain by 1 + this" },
        mutantPowerBonus: { default: 0.45, min: 0, max: 100, comment: "...for a mutant" }
    },
    ssgRitual: {
        requiredChargers: { default: 5, min: 1, max: 100, integer: true, client: true, comment: "God ritual: Saiyans who must share their ki with the vessel (dedicated / LAN)" },
        singleplayerRequiredChargers: { default: 0, min: 0, max: 100, integer: true, client: true, comment: "The same in a singleplayer world nobody else can join (0: the vessel alone, charging ki for 3 s)" },
        wishMinLevel: { default: 5000, min: 0, max: 1000000, integer: true, comment: "Level a Saiyan needs for Shenron's Knowledge of God Ki wish (SsgWishMinLevel)" }
    },
    wishRituals: {
        requiredLevel: { default: 10000, min: 0, max: 1000000000, integer: true, comment: "Level for the Super Saiyan 5 wish and the Namekian god ritual (default 10000)" },
        levelCost: { default: 5000, min: 0, max: 1000000000, integer: true, comment: "Levels either ritual takes, removed from random stats (default 5000)" },
        wishThreshold: { default: 10, min: 0, max: 1000, integer: true, comment: "Wishes on a set before its ritual opens (the eleventh wish on)" }
    }
});
/** The singleplayer rule applies in a world nobody else can join (RPG.server.isSingleplayer: not dedicated, not open to LAN). */
function dbrRitualSolo() {
    try { return !!RPG.server.isSingleplayer(); } catch (e) { return false; }
}
/** Status.isKiShareLocked: giving ki or standing in a god ritual (no attacks, guard, charge, techniques, items, ki blasts). */
function dmzKiShareLocked(p) {
    try { return !!p && (p.hasEffect("dmz_ki_sharing") || p.hasEffect("dmz_god_ritual")); } catch (e) { return false; }
}

// the original config menu's Server rows (client/scripts/54_dmz_config_menu.js): ops change these live
(function () {
    var KEYS = { "godRitual.enabled": 1, "godRitual.requiredDonors": 1, "godRitual.singleplayerRequiredDonors": 1, "ssgRitual.requiredChargers": 1, "ssgRitual.singleplayerRequiredChargers": 1 };
    RPG.net.on("dbr_rituals_set", function (p, d) {
        var op = false;
        try { op = p.isOp(); } catch (e) { }
        if (op && d && KEYS[d.key]) DBR_RITUALS_CFG.set(String(d.key), d.value);
    });
})();
RPG.effects.define("god_ritual_cd", { name: "God Ritual CD", color: "#9A9A9A", keepOnDeath: true });
RPG.effects.define("ki_transfer_boost", { name: "Shared Ki", color: "#6FD8FF", beneficial: true, maxStacks: 100 });
RPG.effects.define("ki_transfer_drain", { name: "Ki Exhaustion", color: "#5A6E80", maxStacks: 100 });
// a giver (Status.isKiShareLocked): no attacks, items, keys or techniques (UpdateStatC2S refuses charging, guarding and the
// action charge; ClientStatsEvents counts it as stunned), donorSpeedMultiplier speed; hidden like the original's own status flag
RPG.effects.define("dmz_ki_sharing", { name: "Sharing Ki", hidden: true, flags: ["noAttack", "noUse", "noKeys", "noSkills"],
    attributes: { "minecraft:generic.movement_speed": { amount: Number(DBR_RITUALS_CFG.get("kiShare.donorSpeedMultiplier")) - 1, operation: "multiply_total" } } });
// a ritual body (Status.isStunned while isInGodRitual): pinned by the ritual, every action refused, aura up
// (TickHandler: auraFromRitual), no form drain and no out-of-ki revert while it lasts (31_dmz_transform.js)
RPG.effects.define("dmz_god_ritual", { name: "God Ritual", hidden: true, flags: ["noMove", "noJump", "noAttack", "noUse", "noKeys", "noSkills"],
    aura: DMZ_AURA.spec({ texture: AURA_KAKAROT, frames: 4, speed: 10, color: "aura", scale: 1.0, alpha: 0.75 }) });

var DMZ_KISHARE = (function () {
    var C = DBR_RITUALS_CFG;
    function K(k) { return C.get("kiShare." + k); }
    var START_RANGE_TOLERANCE = 2.0, START_SOUND_VOLUME = 0.6, INDICATOR_TOLERANCE_TICKS = 20;
    var GENKI_RANGE = 64.0, GENKI_CALL_INTERVAL = 50, GENKI_KI_PERCENT_PER_SECOND = 0.10, START_RATE_TICKS = 5;
    var LINKS = {}, BOOSTED = {}, ATTACK_CREDIT = {}, RETAINED = {}, DRAINED = {}, RESTART_AT = {}, GENKI_CALLS = {}, LAST_START = {};
    var BOOST_KEYS = ["STR", "SKP", "DEF", "PWR"];
    function now() { return RPG.server.getTick(); }
    function uid(p) { return String(p.uuid); }
    function online(u) { var l = RPG.server.players(); for (var i = 0; i < l.length; i++) if (uid(l[i]) === u) return l[i]; return null; }
    function created(p) { return !!p.getVar("dmz_created", 0); }
    function gm(p) { return String(p.getGameMode()); }
    function creative(p) { return gm(p) === "creative"; }
    function ritualOf(p) { return typeof DMZ_GOD_RITUAL !== "undefined" && DMZ_GOD_RITUAL.isParticipant(p); }
    function canAct(p) {
        if (!p.isAlive() || gm(p) === "spectator" || !created(p)) return false;
        if (p.hasEffect("stunned")) return false;
        return !p.hasEffect("knocked_down") && !p.hasEffect("dmz_strike_locked") && !p.hasEffect("dmz_match_frozen") && !ritualOf(p);
    }
    function validReceiver(p) { return p.isAlive() && gm(p) !== "spectator" && created(p); }
    function receiving(u) { for (var d in LINKS) if (LINKS[d].recv === u) return true; return false; }
    function tell(p, s) { p.actionbar(s); }
    function tech() { return typeof DMZ_TECH !== "undefined" ? DMZ_TECH : null; }
    /** isChargingAttack: a ki attack charging (or charged and held) in the hands. */
    function chargingAttack(p) { var t = tech(); return !!(t && t.isCharging(p)); }
    /** chargingGenki: the Spirit Bomb this player is charging, or null. */
    function chargingGenki(p) { var t = tech(); return t && t.genki ? t.genki(p) : null; }

    // ---- the giver's and receiver's stat factor (GodRitualHelper.kiShareMultiplier), folded into dmz_mult ------
    function stacks(p) { return Number(p.getVar("dmz_kidrain_stacks", 0)) || 0; }
    function penalty(n) { return n <= 0 ? 0 : Math.min(K("donorPenaltyMax"), n * K("donorPenaltyPerInterval")); }
    function maxStacks() { var per = K("donorPenaltyPerInterval"); return per <= 0 ? 0 : Math.ceil(K("donorPenaltyMax") / per - 1e-6); }
    function factor(p) {
        var donors = BOOSTED[uid(p)] || 0, n = stacks(p);
        if (donors <= 0 && n <= 0) return 1;
        return (1 + Math.min(donors, K("maxBoostDonors")) * K("boostPerDonor")) * (1 - penalty(n));
    }
    function applyFactor(p) {
        var want = factor(p), had = Number(p.getVar("dmz_kishare_mult", 1)) || 1;
        if (Math.abs(want - had) < 1e-6) return;
        var m = p.getVar("dmz_mult", null) || {};
        BOOST_KEYS.forEach(function (k) { m[k] = (typeof m[k] === "number" ? m[k] : 1) / had * want; });
        p.setVar("dmz_mult", m);
        p.setVar("dmz_kishare_mult", want);
        p.refreshStats();
    }

    // ---- start / stop (requestStart, refusal, stop) -------------------------------------------
    function nearestGenkiCaster(donor) {
        var best = null, bd = GENKI_RANGE * GENKI_RANGE;
        RPG.server.players().forEach(function (o) {
            if (uid(o) === uid(donor) || o.dimension !== donor.dimension || !o.isAlive() || gm(o) === "spectator") return;
            var dx = o.x - donor.x, dy = o.y - donor.y, dz = o.z - donor.z, d = dx * dx + dy * dy + dz * dz;
            if (d > bd || !chargingGenki(o)) return;
            best = o; bd = d;
        });
        return best;
    }
    function refusal(donor, recv, genki) {
        var rn = recv.name;
        if (!canAct(donor)) return "§cYou cannot share your Ki right now";
        if (!validReceiver(recv) || ritualOf(recv)) return "§c" + rn + " cannot receive Ki right now";
        if (LINKS[uid(recv)]) return "§c" + rn + " is already sharing their own Ki";
        if (receiving(uid(donor))) return "§cYou cannot share Ki while you are receiving it";
        if (donor.resource("ki") <= 0) return "§cYou have no Ki left to share";
        if (donor.dimension !== recv.dimension) return "§c" + rn + " is too far away";
        if (genki) return donor.distanceTo(recv) > GENKI_RANGE ? "§c" + rn + " is too far away" : null;
        if (donor.distanceTo(recv) > K("startRange") + START_RANGE_TOLERANCE || !donor.canSee(recv)) return "§c" + rn + " is too far away";
        return null;
    }
    function start(donor, targetId) {
        if (!K("enabled") || LINKS[uid(donor)]) return;
        if (RESTART_AT[uid(donor)] && now() < RESTART_AT[uid(donor)]) return;
        var genki = targetId < 0, recv = null;
        if (genki) recv = nearestGenkiCaster(donor);
        else donor.nearby(Math.max(4, K("startRange") + 4), { players: true }).forEach(function (e) { if (e.entityId === targetId) recv = e; });
        if (recv && !genki) recv = recv.asPlayer ? recv.asPlayer() || recv : recv;
        if (!recv || !recv.isPlayer() || uid(recv) === uid(donor)) return;
        var why = refusal(donor, recv, genki);
        if (why) { tell(donor, why); return; }
        LINKS[uid(donor)] = { recv: uid(recv), start: now(), genki: genki, pending: 0, dmg: 0, ticks: 0 };
        // status.setKiTransferTarget, setChargingKi(false), setActionCharging(false), setBlocking(false), clearTechniqueCharge
        donor.removeEffect("ki_charge");
        donor.removeEffect("guarding");
        if (typeof DMZ_TF !== "undefined" && DMZ_TF.stopCharge) DMZ_TF.stopCharge(donor, -2);
        if (tech() && tech().isCharging(donor)) tech().cancel(donor);
        donor.addEffect("dmz_ki_sharing", -1);
        donor.setShared("kiShare", recv.entityId);
        sfx(donor, "aura_start", START_SOUND_VOLUME, 1.2);
        tell(donor, genki ? "§bYou raise your hands and give your energy to " + recv.name + "'s Spirit Bomb" : "§bYou are sharing your Ki with " + recv.name);
        tell(recv, genki ? "§b" + donor.name + " is giving their energy to your Spirit Bomb" : "§b" + donor.name + " is sharing their Ki with you");
    }
    function stop(u, message) {
        var link = LINKS[u];
        if (!link) {
            // no link (scripts reloaded while giving): still clear what the client draws, or it never asks again
            var q = online(u);
            if (q && q.hasEffect("dmz_ki_sharing")) { q.removeEffect("dmz_ki_sharing"); q.setShared("kiShare", 0); }
            return;
        }
        delete LINKS[u];
        if (K("restartCooldownSeconds") > 0) RESTART_AT[u] = now() + Math.round(K("restartCooldownSeconds") * 20);
        var p = online(u);
        if (!p) return;
        p.removeEffect("dmz_ki_sharing");
        p.setShared("kiShare", 0);
        if (message) tell(p, message);
    }
    function releaseForRitual(recvUuid) {
        Object.keys(LINKS).forEach(function (d) { if (LINKS[d].recv === recvUuid) stop(d, null); });
        stop(recvUuid, null);
    }
    function settled(recvUuid) {
        var delay = Math.round(K("boostDelaySeconds") * 20), out = [];
        for (var d in LINKS) {
            var l = LINKS[d];
            if (l.recv !== recvUuid || now() - l.start < delay) continue;
            var p = online(d);
            if (p) out.push(p);
        }
        return out;
    }
    /** drawAttackCredit: ki given beyond a full bar pays the receiver's charging attack (TickHandler's charge cost). */
    function drawAttackCredit(p, amount) {
        var credit = ATTACK_CREDIT[uid(p)];
        if (credit === undefined || amount <= 0) return 0;
        var drawn = Math.floor(Math.min(amount, Math.floor(credit)));
        if (drawn <= 0) return 0;
        var left = credit - drawn;
        if (left <= 0) delete ATTACK_CREDIT[uid(p)]; else ATTACK_CREDIT[uid(p)] = left;
        return drawn;
    }

    // ---- every tick (onServerTick) ---------------------------------------------------------
    function linkBreak(donor, recv, l) {
        if (!donor) return "";
        if (ritualOf(donor)) return "";
        if (!canAct(donor)) return "§cThe blow broke your concentration";
        if (!recv || !validReceiver(recv)) return "§cYou lost the link with your target";
        if (ritualOf(recv)) return "";
        var max = l.genki ? Math.max(GENKI_RANGE, K("maxLinkDistance")) : K("maxLinkDistance");
        if (donor.dimension !== recv.dimension || donor.distanceTo(recv) > max) return "§cYou lost the link with your target";
        if (l.genki && !chargingGenki(recv)) return "§eThe Spirit Bomb has been launched!";
        return null;
    }
    function transfer(donor, recv, l) {
        var pct = chargingGenki(recv) ? GENKI_KI_PERCENT_PER_SECOND : K("kiPercentPerSecond");
        l.pending += donor.maxResource("ki") * pct / 20;
        var whole = Math.floor(l.pending * 4) / 4;
        if (whole <= 0) return true;
        l.pending -= whole;
        var have = donor.resource("ki"), given = creative(donor) ? whole : Math.min(whole, have);
        if (given <= 0) return false;
        if (!creative(donor)) donor.setResource("ki", have - given);
        deliver(recv, given);
        return creative(donor) || donor.resource("ki") > 0;
    }
    function deliver(recv, amount) {
        var max = recv.maxResource("ki"), t = tech();
        if (chargingAttack(recv) && t && t.absorbGenki && t.absorbGenki(recv, amount / Math.max(1, max))) return;
        var cur = recv.resource("ki"), stored = Math.min(Math.max(0, max - cur), amount);
        if (stored > 0) recv.setResource("ki", cur + stored);
        var overflow = amount - stored;
        if (overflow <= 0 || !chargingAttack(recv)) return;
        var cap = max * K("attackChargeCreditRatio"), u = uid(recv);
        ATTACK_CREDIT[u] = Math.min(cap, (ATTACK_CREDIT[u] || 0) + overflow);
    }
    function interval(donor, l) {
        var retain = Math.round(K("retainSecondsPerInterval") * 20);
        if (retain > 0) { var r = RETAINED[l.recv] || (RETAINED[l.recv] = {}); r[uid(donor)] = (r[uid(donor)] || 0) + retain; }
        if (creative(donor)) return;
        donor.setVar("dmz_kidrain_stacks", Math.min(maxStacks(), stacks(donor) + 1));
        donor.setVar("dmz_kidrain_ticks", (Number(donor.getVar("dmz_kidrain_ticks", 0)) || 0) + retain);
        DRAINED[uid(donor)] = 1;
        applyFactor(donor);
    }
    /** showIndicator: the effect at stacks - 1 levels, endless while live, refreshed only when it drifts 20 ticks. */
    function indicator(p, id, ticks, n) {
        if (n <= 0) { if (p.hasEffect(id)) p.removeEffect(id); return; }
        if (p.hasEffect(id) && p.effectStacks(id) === n) {
            var left = p.effectTicks(id), endless = left < 0 || left > 1000000;
            if (ticks < 0 && endless) return;
            if (ticks >= 0 && !endless && Math.abs(left - ticks) <= INDICATOR_TOLERANCE_TICKS) return;
        }
        p.removeEffect(id);
        p.addEffectStacks(id, ticks < 0 ? -1 : ticks, n);
    }
    function clearDrain(p) {
        p.setVar("dmz_kidrain_stacks", 0); p.setVar("dmz_kidrain_ticks", 0);
        if (p.hasEffect("ki_transfer_drain")) p.removeEffect("ki_transfer_drain");
        applyFactor(p);
    }
    function tickDrains() {
        Object.keys(DRAINED).forEach(function (u) {
            var p = online(u);
            if (!p) { delete DRAINED[u]; return; }
            var giving = !!LINKS[u], t = Number(p.getVar("dmz_kidrain_ticks", 0)) || 0;
            if (!giving && t > 0) p.setVar("dmz_kidrain_ticks", --t);
            if (t <= 0 || !K("enabled")) { clearDrain(p); delete DRAINED[u]; return; }
            indicator(p, "ki_transfer_drain", giving ? -1 : t, stacks(p));
        });
    }
    /** tickGenkiCalls: every 2.5 s each Spirit Bomb caster calls everyone free within 64 blocks. */
    function tickGenkiCalls() {
        if (!K("enabled")) { GENKI_CALLS = {}; return; }
        var t = tech();
        if (!t || !t.genkiCasters) return;
        var casters = t.genkiCasters(), seen = {}, called = {};
        casters.forEach(function (c) {
            var cu = uid(c);
            seen[cu] = 1;
            if (GENKI_CALLS[cu] !== undefined && now() - GENKI_CALLS[cu] < GENKI_CALL_INTERVAL) return;
            GENKI_CALLS[cu] = now();
            RPG.server.players().forEach(function (o) {
                var ou = uid(o);
                if (ou === cu || o.dimension !== c.dimension || !o.isAlive() || gm(o) === "spectator" || LINKS[ou] || called[ou]) return;
                if (o.distanceTo(c) > GENKI_RANGE || !created(o) || chargingAttack(o)) return;
                called[ou] = 1;
                o.actionbar("§b" + c.name + " is trying to charge a Spirit Bomb! §eGive them your strength with Ctrl + Alt + Right Click");
                o.playSound("minecraft:block.note_block.chime", 0.7, 1.6);
            });
        });
        Object.keys(GENKI_CALLS).forEach(function (u) { if (!seen[u]) delete GENKI_CALLS[u]; });
    }
    RPG.every(1, function () {                                  // every tick (RPG.on("serverTick") is once a second)
        tickGenkiCalls();
        var linked = Object.keys(LINKS);
        if (!linked.length && !Object.keys(BOOSTED).length && !Object.keys(ATTACK_CREDIT).length && !Object.keys(RETAINED).length && !Object.keys(DRAINED).length) return;
        if (!K("enabled")) {
            linked.forEach(function (d) { stop(d, null); });
            RETAINED = {}; ATTACK_CREDIT = {};
        }
        var boosting = {}, receivers = {}, delay = Math.round(K("boostDelaySeconds") * 20), every = Math.max(1, Math.round(K("intervalSeconds") * 20));
        Object.keys(LINKS).forEach(function (d) {
            var l = LINKS[d], donor = online(d), recv = online(l.recv);
            var why = linkBreak(donor, recv, l);
            if (why !== null) { stop(d, why || null); return; }
            if (!transfer(donor, recv, l)) { stop(d, "§cYou have no Ki left to share"); return; }
            receivers[l.recv] = 1;
            if (++l.ticks % every === 0) interval(donor, l);
            if (now() - l.start >= delay) (boosting[l.recv] = boosting[l.recv] || {})[d] = 1;
        });
        // tickRetained: givers who let go still boost while their retained time lasts
        Object.keys(RETAINED).forEach(function (r) {
            var map = RETAINED[r];
            Object.keys(map).forEach(function (d) {
                var still = LINKS[d] && LINKS[d].recv === r, left = still ? map[d] : map[d] - 1;
                if (left <= 0) { delete map[d]; return; }
                map[d] = left;
                (boosting[r] = boosting[r] || {})[d] = 1;
            });
            if (!Object.keys(map).length) delete RETAINED[r];
        });
        // refreshBoosts
        var touched = {};
        Object.keys(BOOSTED).forEach(function (r) { touched[r] = 1; });
        Object.keys(boosting).forEach(function (r) { touched[r] = 1; });
        Object.keys(touched).forEach(function (r) {
            var n = boosting[r] ? Object.keys(boosting[r]).length : 0;
            if (n > 0) BOOSTED[r] = n; else delete BOOSTED[r];
            var p = online(r);
            if (!p) return;
            var longest = 0, ret = RETAINED[r] || {};
            Object.keys(ret).forEach(function (d) { longest = Math.max(longest, ret[d]); });
            indicator(p, "ki_transfer_boost", receiving(r) ? -1 : longest, n);
            applyFactor(p);
        });
        tickDrains();
        Object.keys(ATTACK_CREDIT).forEach(function (u) { var p = online(u); if (!p || !chargingAttack(p)) delete ATTACK_CREDIT[u]; });
        Object.keys(receivers).forEach(function (r) { var p = online(r); if (p && typeof DMZ_GOD_RITUAL !== "undefined") DMZ_GOD_RITUAL.evaluate(p); });
    });
    /** clearTransferEffects (EffectsCommand clear): the bonus, the exhaustion and their effects. */
    function clearTransferEffects(p) {
        var u = uid(p);
        delete RETAINED[u]; delete BOOSTED[u]; delete DRAINED[u];
        clearDrain(p);
        if (p.hasEffect("ki_transfer_boost")) p.removeEffect("ki_transfer_boost");
        applyFactor(p);
    }
    // onDamage: a giver who takes 10 % of their max health in hits stops
    RPG.on("damageFinal", function (e) {
        var t = e.target;
        if (!t || !t.isPlayer() || e.amount <= 0) return;
        var l = LINKS[String(t.uuid)];
        if (!l) return;
        l.dmg += Math.min(e.amount, t.health);
        if (l.dmg >= t.maxHealth * K("interruptDamageRatio")) stop(String(t.uuid), "§cThe blow broke your concentration");
    });
    RPG.on("death", function (p) { stop(uid(p), null); });
    RPG.on("dimensionChange", function (p) { stop(uid(p), null); });
    RPG.on("playerLeave", function (p) {
        var u = uid(p);
        stop(u, null);
        delete BOOSTED[u]; delete ATTACK_CREDIT[u]; delete RETAINED[u]; delete DRAINED[u]; delete RESTART_AT[u]; delete LAST_START[u];
        p.setShared("kiShare", 0);
    });
    RPG.on("playerJoin", function (p) {
        p.removeEffect("dmz_ki_sharing"); p.removeEffect("ki_transfer_boost"); p.setShared("kiShare", 0);
        if ((Number(p.getVar("dmz_kidrain_ticks", 0)) || 0) > 0) DRAINED[uid(p)] = 1;
        RPG.schedule(20, function () { applyFactor(p); });
    });
    // KiShareC2S (client/scripts/46_dmz_kishare.js): {op: "start", target: entity id, or -1 for the nearest Spirit Bomb} / {op: "stop"}
    RPG.net.on("dmz_kishare", function (p, d) {
        if (!p || !d) return;
        if (d.op === "stop") { stop(uid(p), null); return; }
        if (d.op !== "start") return;
        var u = uid(p);                                               // PacketRateLimiter: one start per 5 ticks
        if (LAST_START[u] !== undefined && now() - LAST_START[u] < START_RATE_TICKS) return;
        LAST_START[u] = now();
        var t = Number(d.target);
        start(p, isNaN(t) ? -1 : t);
    });

    // scripts (re)loaded: links live in memory only, so nobody is giving any more (Status.kiTransferTarget is reset on login too)
    RPG.server.players().forEach(function (p) { if (p.hasEffect("dmz_ki_sharing")) p.removeEffect("dmz_ki_sharing"); p.setShared("kiShare", 0); });

    return { settled: settled, releaseForRitual: releaseForRitual, isDonating: function (p) { return !!LINKS[uid(p)]; }, receiving: receiving, stop: stop,
        drawAttackCredit: drawAttackCredit, clearTransferEffects: clearTransferEffects, chargingGenki: chargingGenki, GENKI_RANGE: GENKI_RANGE };
})();

// =====================================================================================
//  GodRitualService
// =====================================================================================
var DMZ_GOD_RITUAL = (function () {
    var C = DBR_RITUALS_CFG;
    function G(k) { return C.get("godRitual." + k); }
    var GATHER_TICKS = 20, CHARGE_STEP = 20, FEEDBACK_INTERVAL = 60, SLOW_FALL_TICKS = 160;
    var GROUP = "godritual", FORM = "supersaiyangodritual";
    var RITUALS = {}, PARTICIPANTS = {}, LAST_FEEDBACK = {}, SOLO = {};
    function now() { return RPG.server.getTick(); }
    function uid(p) { return String(p.uuid); }
    function online(u) { var l = RPG.server.players(); for (var i = 0; i < l.length; i++) if (uid(l[i]) === u) return l[i]; return null; }
    function race(p) { return typeof DMZ_TF !== "undefined" ? DMZ_TF.race(p) : p.race; }
    function isSaiyan(p) { return race(p) === "saiyan"; }
    function activeKey(p) { return String(p.getVar("dmz_form", "") || "").replace(":", "."); }
    function inAnyForm(p, list) {
        if (!list || p.getVar("dmz_stack", "")) return false;
        var k = activeKey(p).toLowerCase();
        return !!k && list.some(function (e) { return String(e).trim().toLowerCase() === k; });
    }
    function alignment(p) { var a = Number(p.getVar("dmz_alignment", 100)); return isNaN(a) ? 100 : a; }
    function pure(p) { var a = alignment(p); return a >= G("pureGoodMinAlignment") || a <= G("pureEvilMaxAlignment"); }
    function cooling(p) { return p.hasEffect("god_ritual_cd"); }
    function isActiveForm(p) { return String(p.getVar("dmz_form", "") || "").indexOf(GROUP + ":") === 0; }
    // how many givers: DBR's own counts (the charge ritual's, kept when the two rituals merged in 4.18.0), the original's
    // GodRitualConfig.requiredDonors otherwise
    function required() {
        return dbrRitualSolo() ? Math.max(0, C.get("ssgRitual.singleplayerRequiredChargers")) : Math.max(1, C.get("ssgRitual.requiredChargers"));
    }
    function blocked(reason, p) {
        var n = p.name;
        return { impure: "§cThe ritual cannot begin: " + n + "'s heart is not pure enough", cooldown: "§cThe ritual cannot begin: " + n + " must rest before another ritual",
            too_far: "§cThe ritual cannot begin: " + n + " is too far from the circle", unable: "§cThe ritual cannot begin: " + n + " cannot channel right now" }[reason];
    }
    function fused(p) { return p.hasEffect("dmz_fused") || !!p.getVar("dmz_fused", 0); }
    // God Ki replaced the ritual's Super Saiyan God: the vessel needs Shenron's Knowledge of God Ki (95_dbr_rituals.js), and the
    // ritual awakens God Ki for good (31_dmz_transform.js) instead of a timed god form
    function knowsGodKi(p) { return !!p.getVar("dmzr_ritual_godki_knowledge", 0); }
    function hasGodKi(p) { return !!p.getVar("dmzr_godki", 0); }
    function recipientProblem(p) {
        if (hasGodKi(p)) return "§7" + p.name + " has already awakened God Ki";
        if (!knowsGodKi(p)) return "§cThe ritual cannot begin: " + p.name + " has not received the Knowledge of God Ki from Shenron";
        if (fused(p)) return "§cThe ritual cannot begin: a fusion cannot become the vessel";
        if (!pure(p)) return blocked("impure", p);
        if (cooling(p)) return blocked("cooldown", p);
        if (p.hasEffect("knocked_down") || !p.isAlive()) return blocked("unable", p);
        return null;
    }
    function withinCircle(d, r) {
        if (d.dimension !== r.dimension) return false;
        var dx = d.x - r.x, dz = d.z - r.z, rad = G("ritualRadius");
        return dx * dx + dz * dz <= rad * rad && Math.abs(d.y - r.y) <= G("ritualVerticalRange");
    }
    function candidate(d, r) {
        if (!isSaiyan(d) || !inAnyForm(d, G("donorForms"))) return null;
        var problem = null;
        if (!pure(d)) problem = blocked("impure", d);
        else if (cooling(d)) problem = blocked("cooldown", d);
        else if (!withinCircle(d, r)) problem = blocked("too_far", d);
        return { p: d, n: 1, problem: problem };          // (a fused giver counts as two in the original; DBR's fusion keeps one body)
    }
    function feedback(r, cands, problem) {
        var last = LAST_FEEDBACK[uid(r)];
        if (last !== undefined && now() - last < FEEDBACK_INTERVAL) return;
        LAST_FEEDBACK[uid(r)] = now();
        r.actionbar(problem);
        cands.forEach(function (c) { c.p.actionbar(problem); });
    }
    /** GodRitualService.evaluate: called for every receiver while ki flows to them. */
    function evaluate(r) {
        if (!G("enabled") || PARTICIPANTS[uid(r)] || !isSaiyan(r) || !inAnyForm(r, G("recipientForms"))) return;
        var need = required();
        if (need <= 0) return;                                // the solo ritual starts from Charge Ki instead
        var cands = [], attempted = 0;
        DMZ_KISHARE.settled(uid(r)).forEach(function (d) { var c = candidate(d, r); if (c) { cands.push(c); attempted += c.n; } });
        if (attempted < need) return;
        var problem = recipientProblem(r), chosen = [], ready = 0;
        cands.forEach(function (c) {
            if (c.problem) { if (!problem) problem = c.problem; return; }
            if (ready >= need) return;
            chosen.push(c); ready += c.n;
        });
        if (ready >= need && !recipientProblem(r)) { begin(r, chosen); return; }
        if (problem) feedback(r, cands, problem);
    }

    // ---- ground / space checks (canStand, clearance) -----------------------------------------
    function solid(dim, x, y, z) { var b = RPG.world.getBlock(dim, Math.floor(x), Math.floor(y), Math.floor(z)); return !(b === "minecraft:air" || b === "minecraft:cave_air" || (typeof siteLoose === "function" && siteLoose(b) && b.indexOf("leaves") < 0)); }
    function canStand(p, x, y, z, needsGround) {
        if (solid(p.dimension, x, y + 0.1, z) || solid(p.dimension, x, y + 1.1, z)) return false;
        return !needsGround || solid(p.dimension, x, y - 0.2, z);
    }
    function clearance(p, height) {
        var free = 0;
        for (var h = 0.25; h <= height + 1e-6; h += 0.25) {
            if (solid(p.dimension, p.x, p.y + h + 1.8, p.z)) break;
            free = h;
        }
        return free;
    }

    // ---- begin / enter -------------------------------------------------------------------------
    function enter(p, role, anchor) {
        // setChargingKi / setActionCharging / setDescending / setBlocking(false), clearTechniqueCharge, setSprinting(false)
        p.removeEffect("ki_charge");
        p.removeEffect("guarding");
        if (typeof DMZ_TF !== "undefined" && DMZ_TF.stopCharge) DMZ_TF.stopCharge(p, -2);
        if (typeof DMZ_TECH !== "undefined" && DMZ_TECH.isCharging(p)) DMZ_TECH.cancel(p);
        p.addEffect("dmz_god_ritual", -1);
        p.setShared("godRitual", { role: role, anchor: anchor });
        p.setSprinting && p.setSprinting(false);
    }
    function begin(r, chosen) {
        var cx = r.x, cy = r.y, cz = r.z;
        chosen.sort(function (a, b) { return Math.atan2(a.p.z - cz, a.p.x - cx) - Math.atan2(b.p.z - cz, b.p.x - cx); });
        DMZ_KISHARE.releaseForRitual(uid(r));
        var rit = { recv: uid(r), dim: r.dimension, cx: cx, cy: cy, cz: cz, donors: chosen.map(function (c) { return uid(c.p); }), slots: {}, dmg: {},
            phase: chosen.length ? "GATHER" : "CHANNEL", ticks: 0, charge: 0, liftFrom: 0, liftTo: 0 };
        if (chosen.length) {
            var base = Math.atan2(chosen[0].p.z - cz, chosen[0].p.x - cx), rad = Math.min(G("ritualRadius"), G("ringRadius")), onGround = r.onGround;
            chosen.forEach(function (c, i) {
                var d = c.p, a = base + i * Math.PI * 2 / chosen.length, x = cx + Math.cos(a) * rad, z = cz + Math.sin(a) * rad, y = cy;
                if (!canStand(d, x, y, z, onGround)) { x = d.x; y = d.y; z = d.z; }
                var yaw = Math.atan2(-(cx - x), cz - z) * 180 / Math.PI;
                rit.slots[uid(d)] = { fx: d.x, fy: d.y, fz: d.z, tx: x, ty: y, tz: z, yaw: yaw };
            });
        }
        RITUALS[rit.recv] = rit;
        bodies(rit).forEach(function (u) { PARTICIPANTS[u] = rit.recv; });
        delete LAST_FEEDBACK[rit.recv];
        enter(r, 2, r.entityId);
        r.setVar("dmz_formcharge", 0);
        chosen.forEach(function (c) { enter(c.p, 1, r.entityId); });
        RPG.world.sound(rit.dim, DMZ + "aura_start", cx, cy, cz, 1.5, 0.8);
        broadcast(rit, "§6Six pure hearts resonate as one...");
        RPG.log("[DBR] God ritual started for " + r.name + " with " + chosen.length + " donors at " + Math.floor(cx) + " " + Math.floor(cy) + " " + Math.floor(cz));
    }
    function bodies(rit) { return rit.donors.concat([rit.recv]); }
    function broadcast(rit, text) { bodies(rit).forEach(function (u) { var p = online(u); if (p) p.actionbar(text); }); }

    // ---- the ritual, every tick ----------------------------------------------------------------
    function face(p, x, y, z, yaw) { p.teleportTo(p.dimension, x, y, z, yaw, 0); p.setVelocity(0, 0, 0); p.fallDistance = 0; }
    function glide(p, s, f) { if (p && s) face(p, s.fx + (s.tx - s.fx) * f, s.fy + (s.ty - s.fy) * f, s.fz + (s.tz - s.fz) * f, s.yaw); }
    function pin(p, s) {
        if (!p || !s) return;
        var dx = p.x - s.tx, dz = p.z - s.tz, dyaw = ((p.yaw - s.yaw) % 360 + 540) % 360 - 180;
        if (dx * dx + dz * dz <= 0.25 && Math.abs(dyaw) < 1) return;
        face(p, s.tx, p.y, s.tz, s.yaw);
    }
    function pinCenter(r, rit) {
        var dx = r.x - rit.cx, dz = r.z - rit.cz;
        if (dx * dx + dz * dz <= 0.25) return;
        r.teleportTo(r.dimension, rit.cx, r.y, rit.cz, r.yaw, r.pitch); r.setVelocity(0, 0, 0);
    }
    function tickRitual(rit) {
        var r = online(rit.recv);
        if (!r || !r.isAlive() || r.dimension !== rit.dim || !inAnyForm(r, G("recipientForms"))) { cancel(rit, "§cThe ritual was interrupted"); return; }
        for (var i = 0; i < rit.donors.length; i++) {
            var d = online(rit.donors[i]);
            if (!d || !d.isAlive() || d.dimension !== r.dimension || !inAnyForm(d, G("donorForms"))) { cancel(rit, "§cThe ritual was interrupted"); return; }
        }
        rit.ticks++;
        var each = function (fn) { rit.donors.forEach(function (u) { fn(online(u), rit.slots[u]); }); };
        if (rit.phase === "GATHER") {
            var t = Math.min(1, rit.ticks / GATHER_TICKS), e = t * t * (3 - 2 * t);
            each(function (p, s) { glide(p, s, e); });
            if (rit.ticks >= GATHER_TICKS) { rit.phase = "CHANNEL"; rit.ticks = 0; }
        } else if (rit.phase === "CHANNEL") {
            each(pin);
            pinCenter(r, rit);
            var ch = Math.max(20, Math.round(G("channelSeconds") * 20));
            if (rit.ticks % CHARGE_STEP === 0 || rit.ticks >= ch) {
                rit.charge = Math.min(100, Math.round(100 * rit.ticks / ch));
                r.setVar("dmz_formcharge", rit.charge);
                r.setShared("godRitual", { role: 2, anchor: r.entityId, charge: rit.charge });
            }
            if (rit.ticks >= ch) {
                rit.phase = "ASCEND"; rit.ticks = 0;
                rit.liftFrom = r.y; rit.liftTo = r.y + clearance(r, G("liftHeight"));
                RPG.world.sound(r.dimension, DMZ + "ki_explosion_charge", r.x, r.y, r.z, 1.0, 1.2);
            }
        } else if (rit.phase === "ASCEND") {
            each(pin);
            var lt = Math.max(1, Math.round(G("liftSeconds") * 20)), f = Math.min(1, rit.ticks / lt), eased = 1 - (1 - f) * (1 - f) * (1 - f);
            r.teleportTo(r.dimension, rit.cx, rit.liftFrom + (rit.liftTo - rit.liftFrom) * eased, rit.cz, r.yaw, r.pitch);
            r.setVelocity(0, 0, 0); r.fallDistance = 0;
            if (rit.ticks >= lt) { rit.phase = "SHELL"; rit.ticks = 0; shell(r); }
        } else if (rit.phase === "SHELL") {
            each(pin);
            r.teleportTo(r.dimension, rit.cx, rit.liftTo, rit.cz, r.yaw, r.pitch);
            r.setVelocity(0, 0, 0); r.fallDistance = 0;
            if (rit.ticks >= Math.max(1, Math.round(G("glowInSeconds") * 20))) complete(rit, r);
        }
    }
    /** Status.godRitualGlowStart: every client near the vessel draws the white shell (46_dmz_kishare.js). */
    function shell(r) {
        var spec = { id: r.entityId, inTicks: Math.max(1, Math.round(G("glowInSeconds") * 20)), outTicks: Math.max(1, Math.round(G("glowOutSeconds") * 20)), color: G("shellColor") };
        RPG.server.players().forEach(function (p) { if (p.dimension === r.dimension && p.distanceTo(r) < 128) RPG.net.send(p, "dmz_god_shell", spec); });
    }
    function clearShell(r) { RPG.server.players().forEach(function (p) { if (p.dimension === r.dimension) RPG.net.send(p, "dmz_god_shell", { id: r.entityId, off: 1 }); }); }
    function finish(rit) {
        delete RITUALS[rit.recv];
        bodies(rit).forEach(function (u) {
            delete PARTICIPANTS[u];
            var p = online(u);
            if (!p) return;
            p.removeEffect("dmz_god_ritual");
            p.setShared("godRitual", null);
            if (u === rit.recv) p.setVar("dmz_formcharge", 0);
        });
    }
    function cooldown(p, ticks) {
        if (!p || ticks <= 0) return;
        if (p.hasEffect("god_ritual_cd") && p.effectTicks && p.effectTicks("god_ritual_cd") >= ticks) return;
        p.removeEffect("god_ritual_cd");
        p.addEffect("god_ritual_cd", ticks);
    }
    function cdTicks() { return Math.round(G("cooldownMinutes") * 1200); }
    function complete(rit, r) {
        finish(rit);
        awakenGodKi(r);
        r.setVar("dmz_formcharge", 0);
        r.fallDistance = 0;
        if (!r.hasEffect("flight")) r.addPotion("minecraft:slow_falling", SLOW_FALL_TICKS, 0);
        rit.donors.forEach(function (u) { cooldown(online(u), cdTicks()); });
        RPG.world.sound(r.dimension, DMZ + "fusion", r.x, r.y, r.z, 1.0, 1.0);
        RPG.world.sound(r.dimension, DMZ + "transform_on", r.x, r.y, r.z, 1.0, 0.9);
        r.tell("§cThe power of the gods flows through you... you have awakened God Ki! §7(Toggle it in the radial menu's Ki Actions; with it on, a full Ki Surge awakens God Ki.)");
        rit.donors.forEach(function (u) { var p = online(u); if (p) p.actionbar("§6" + r.name + " has awakened God Ki"); });
        RPG.log("[DBR] God ritual completed for " + r.name);
    }
    /** The ritual's end: God Ki is the vessel's from now on, the toggle on, and God Ki awakens at once. */
    function awakenGodKi(r) {
        r.setVar("dmzr_godki", 1);
        r.setVar("dmz_god_ki", 1);
        if (typeof DMZ_TF !== "undefined" && DMZ_TF.enterGodKi) DMZ_TF.enterGodKi(r);
    }
    function cancel(rit, message) {
        var lifted = rit.phase === "ASCEND" || rit.phase === "SHELL", r = online(rit.recv);
        if (r) clearShell(r);
        finish(rit);
        bodies(rit).forEach(function (u) {
            var p = online(u);
            if (!p) return;
            cooldown(p, Math.round(G("interruptCooldownSeconds") * 20));
            p.actionbar(message);
        });
        if (lifted && r) r.addPotion("minecraft:slow_falling", SLOW_FALL_TICKS, 0);
        RPG.log("[DBR] God ritual for " + rit.recv + " cancelled in " + rit.phase);
    }
    function cancelFor(p) { var k = PARTICIPANTS[uid(p)]; if (k && RITUALS[k]) cancel(RITUALS[k], "§cThe ritual was interrupted"); }

    RPG.every(1, function () {                                  // every tick (RPG.on("serverTick") is once a second)
        for (var k in RITUALS) try { tickRitual(RITUALS[k]); } catch (e) { RPG.log("[DBR] god ritual: " + e); cancel(RITUALS[k], "§cThe ritual was interrupted"); }
    });

    // ---- the solo ritual (DBR, singleplayer): the vessel holds Charge Ki in SSJ Mastered -------------------
    RPG.every(5, function () {
        if (!G("enabled") || required() > 0) return;
        RPG.server.players().forEach(function (p) {
            var u = uid(p);
            if (PARTICIPANTS[u] || !p.hasEffect("ki_charge") || !isSaiyan(p) || !inAnyForm(p, G("recipientForms")) || hasGodKi(p) || !knowsGodKi(p)) { delete SOLO[u]; return; }
            var problem = recipientProblem(p);
            if (problem) { delete SOLO[u]; feedback(p, [], problem); return; }
            SOLO[u] = (SOLO[u] || 0) + 5;
            if (SOLO[u] >= Math.round(G("soloChargeSeconds") * 20)) { delete SOLO[u]; begin(p, []); }
        });
    });

    // ---- the form's timer (onPlayerTick) ----------------------------------------------------------
    function endForm(p, message) {
        if (isActiveForm(p)) {
            p.setVar("dmz_prev", null);
            DMZ_TF.setForm(p, null, null);
            sfx(p, "insta_form_off", 1, 1);
        }
        p.setVar("dmz_godritual_ticks", 0);
        cooldown(p, cdTicks());
        if (message) p.actionbar(message);
    }
    RPG.every(20, function () {
        RPG.server.players().forEach(function (p) {
            var t = Number(p.getVar("dmz_godritual_ticks", 0)) || 0;
            if (isActiveForm(p)) {
                if (t <= 0) { p.setVar("dmz_godritual_ticks", Math.max(20, Math.round(G("durationMinutes") * 1200))); return; }
                t -= 20;
                p.setVar("dmz_godritual_ticks", Math.max(0, t));
                if (t <= 0) endForm(p, "§cThe divine Ki fades away...");
            } else if (t > 0) {
                p.setVar("dmz_godritual_ticks", 0);
                cooldown(p, cdTicks());
            }
        });
    });

    // ---- interruptions ---------------------------------------------------------------------------
    RPG.on("damageFinal", function (e) {
        var t = e.target;
        if (!t || !t.isPlayer() || e.amount <= 0) return;
        var k = PARTICIPANTS[String(t.uuid)], rit = k ? RITUALS[k] : null;
        if (!rit) return;
        var u = String(t.uuid);
        rit.dmg[u] = (rit.dmg[u] || 0) + Math.min(e.amount, t.health);
        if (rit.dmg[u] > t.maxHealth * G("interruptDamageRatio")) cancel(rit, "§cThe ritual was interrupted");
    });
    RPG.on("death", function (p) { cancelFor(p); if (isActiveForm(p) || (Number(p.getVar("dmz_godritual_ticks", 0)) || 0) > 0) endForm(p, null); });
    RPG.on("playerLeave", function (p) { cancelFor(p); delete LAST_FEEDBACK[uid(p)]; delete SOLO[uid(p)]; });
    RPG.on("playerJoin", function (p) {
        if (PARTICIPANTS[uid(p)]) return;
        if (p.hasEffect("dmz_god_ritual")) p.removeEffect("dmz_god_ritual");
        p.setShared("godRitual", null);
    });
    RPG.on("dimensionChange", function (p) { cancelFor(p); });

    RPG.commands.register("godritual", {
        permission: 2, description: "/rpgc godritual status | reset | end - the god ritual (test)",
        run: function (p, args) {
            if (!p) return;
            var a = String(args[0] || "status");
            if (a === "reset") { p.removeEffect("god_ritual_cd"); p.tell("&aGod ritual cooldown cleared."); return; }
            if (a === "end") { endForm(p, "&7God form ended."); return; }
            p.tell("&eGod ritual: " + (G("enabled") ? "on" : "off") + ", donors needed here: " + required() + (dbrRitualSolo() ? " (singleplayer rule)" : " (game rule)") +
                ", form " + activeKey(p) + ", pure " + pure(p) + ", cooldown " + cooling(p) + ", form time left " + Math.round((Number(p.getVar("dmz_godritual_ticks", 0)) || 0) / 20) + " s");
        }
    });

    // the Knowledge of Super Saiyan God from before God Ki counts as the Knowledge of God Ki
    RPG.on("playerJoin", function (p) {
        if (p.getVar("dmzr_ritual_ssg_knowledge", 0) && !p.getVar("dmzr_ritual_godki_knowledge", 0)) p.setVar("dmzr_ritual_godki_knowledge", 1);
    });

    // scripts (re)loaded: no ritual survives it, so nobody stays pinned
    RPG.server.players().forEach(function (p) { if (p.hasEffect("dmz_god_ritual")) { p.removeEffect("dmz_god_ritual"); p.setShared("godRitual", null); } });

    return { evaluate: evaluate, isParticipant: function (p) { return !!PARTICIPANTS[uid(p)]; }, required: required, isActiveForm: isActiveForm,
        endForm: endForm, awakenGodKi: awakenGodKi };
})();
