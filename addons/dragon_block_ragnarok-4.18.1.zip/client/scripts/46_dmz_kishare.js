// =====================================================================================
//  46_dmz_kishare.js - the original's Ki sharing and god ritual on this computer
// =====================================================================================
//  Port of the original (GPL-3.0, see NOTICE.md) client/systems/kishare/{KiShareInput, KiSharePose, KiShareVisuals},
//  the god ritual parts of PlayerGeoAnimatableMixin / DMZPlayerModel / ClientStatsEvents and
//  client/render/effects/GodRitualShellEffect. Server side: scripts/64_dmz_kishare.js.
//   - Ctrl + Alt + right click (held) looking at a player within 8 blocks shares your ki with them; let go to stop.
//     Aimed at nobody while someone within 64 blocks charges a Spirit Bomb, it gives to their bomb.
//     The chord never uses the item in your hand; while you give you can't attack, guard or sprint.
//   - Givers hold both hands out to the receiver (raised to the sky for a Spirit Bomb); ki streams from their hands into
//     the receiver's chest (orbs rise from their hands and are drawn into the bomb).
//   - Ritual givers face the vessel and join hands with their neighbours (two or fewer reach for the vessel); ki runs
//     round the ring, its colour turning from their aura to God Ki's as the vessel's channel fills. The vessel charges,
//     and floats once the channel is full.
//   - The vessel glows in a white shell (the ritual's shell colour) as it awakens God Ki.
// =====================================================================================
(function () {
    var RETRY_TICKS = 10, STOP_RESEND_TICKS = 10, GENKI_RANGE = 64, GENKI_SEARCH_RADIUS = 48;
    var requested = false, retry = 0, stopCd = 0;
    // God Ki's aura (shared/07_dmz_forms_data.js godki): the ritual's target form here
    var GOD_AURA = "#FF7A45";
    var KTEX = ["dmzpack:ki_trail0", "dmzpack:ki_trail1", "dmzpack:ki_trail2", "dmzpack:ki_trail3", "dmzpack:ki_trail4", "dmzpack:ki_trail5"];
    // KiSharePose
    var SHOULDER_H = 22 / 16, SHOULDER_SIDE = 5 / 16, HAND_REACH = 9 / 16, RING_DROOP = 0.35, CHEST = 0.6, MAX_SIDE_ANGLE = 100;
    var RAISED_HAND_HEIGHT = 4.0, RAISED_HAND_SPREAD = 1.2;
    // KiShareVisuals
    var STREAM_TRAVEL_FACTOR = 9.6, STREAM_JITTER = 0.06, STREAM_SCALE = 0.6, TRACERS_PER_WAY = 3, TRACER_SUBSTEPS = 3,
        TRACER_SPEED = 0.03, TRACER_RETURN_SPEED = 0.022, TRACER_LIFETIME = 9, TRACER_SCALE = 0.65,
        GENKI_ORBS_PER_TICK = 2, GENKI_ORB_DISTANCE = 3.0, GENKI_ORB_SPREAD = 0.9, GENKI_ORB_SCALE = 4.0, GENKI_ORB_LIFETIME = 22,
        GENKI_RISE_SPEED = 0.35, GENKI_HAND_ORB_SCALE = 1.6, GENKI_HAND_ORB_LIFETIME = 30;

    function cfg(k, d) { try { var v = RPG.config.get("dbr_rituals", k, d); return v === undefined || v === null ? d : v; } catch (e) { return d; } }
    function down(k) { return RPG.isKeyDown(k); }
    /** KiShareInput.isChordDown: Ctrl and Alt held with no screen open. */
    function chord() {
        return !RPG.screen.getOpen() && (down("key.keyboard.left.control") || down("key.keyboard.right.control"))
            && (down("key.keyboard.left.alt") || down("key.keyboard.right.alt"));
    }
    function locked() { return RPG.player.hasEffect("dmz_ki_sharing") || RPG.player.hasEffect("dmz_god_ritual"); }
    function me() { var l = RPG.avatar.players(); for (var i = 0; i < l.length; i++) if (l[i].local) return l[i]; return null; }

    // ---- the Spirit Bomb a player is charging (KiSharePose.genkiOf), from the projectiles this computer sees ---------------
    var GENKI = {}, genkiAt = -1;
    function genkiOf(pl) {
        var t = RPG.time();
        if (genkiAt !== t) {
            genkiAt = t; GENKI = {};
            RPG.world.projectiles(GENKI_RANGE + GENKI_SEARCH_RADIUS).forEach(function (pr) {
                if (!pr.held || pr.owner < 0 || !pr.tag) return;
                var tag = null;
                try { tag = JSON.parse(pr.tag); } catch (e) { return; }
                if (tag && tag.rt === 5 && tag.tech === "spiritbomb") GENKI[pr.owner] = pr;
            });
        }
        return pl ? GENKI[pl.id] || null : null;
    }
    function genkiCenter(pr) { return { x: pr.x, y: pr.y + pr.size / 2, z: pr.z }; }

    // ---- KiShareInput ----------------------------------------------------------------------------
    /** KiShareInput.pickTarget: the first player the crosshair line meets within range, not behind a block. */
    function solidAt(x, y, z) {
        var b = String(RPG.world.getBlock(Math.floor(x), Math.floor(y), Math.floor(z)) || "minecraft:air");
        return !/(^|:)(air|cave_air|void_air|water|lava|short_grass|grass|tall_grass|fern|large_fern|dead_bush|snow|light)$/.test(b) && !/flower|sapling|torch|vine|carpet|button|lever|rail|pressure_plate|sign/.test(b);
    }
    function pickTarget(range) {
        var p = RPG.player, eye = { x: p.x, y: p.eyeY, z: p.z }, look = p.look, maxD = range;
        for (var s = 0.25; s <= range; s += 0.25) if (solidAt(eye.x + look.x * s, eye.y + look.y * s, eye.z + look.z * s)) { maxD = s; break; }
        var best = null, bd = 1e9;
        RPG.avatar.players().forEach(function (pl) {
            if (pl.local || pl.spectator || pl.dead) return;
            var hw = 0.3 * pl.modelSize, h = 1.8 * pl.modelSize, lo = [pl.x - hw, pl.y, pl.z - hw], hi = [pl.x + hw, pl.y + h, pl.z + hw];
            var o = [eye.x, eye.y, eye.z], d = [look.x, look.y, look.z], t0 = 0, t1 = maxD;
            for (var a = 0; a < 3; a++) {
                if (Math.abs(d[a]) < 1e-9) { if (o[a] < lo[a] || o[a] > hi[a]) return; continue; }
                var u = (lo[a] - o[a]) / d[a], v = (hi[a] - o[a]) / d[a];
                if (u > v) { var w = u; u = v; v = w; }
                t0 = Math.max(t0, u); t1 = Math.min(t1, v);
                if (t0 > t1) return;
            }
            if (t0 < bd) { bd = t0; best = pl; }
        });
        return best;
    }
    function genkiNearby() {
        var p = RPG.player, found = false;
        RPG.avatar.players().forEach(function (pl) {
            if (found || pl.local) return;
            var dx = pl.x - p.x, dy = pl.y - p.y, dz = pl.z - p.z;
            if (dx * dx + dy * dy + dz * dz <= GENKI_RANGE * GENKI_RANGE && genkiOf(pl)) found = true;
        });
        return found;
    }
    // the chord never uses the held item (onInteraction: isUseItem && isChordDown); a giver doesn't sprint
    // (setSprinting(false) while isKiShareLocked). Only what this script switched off is switched back on.
    var OWN = {};
    function hold(what, on) {
        if (on === !!OWN[what]) return;
        if (!on && typeof DBR_CLIENT_LOCK !== "undefined" && DBR_CLIENT_LOCK.active()) return;   // a clash lock holds it
        OWN[what] = on;
        try { RPG.input.block(what, on); } catch (e) { }
    }
    function reset() { requested = false; retry = 0; stopCd = 0; hold("use", false); hold("sprint", false); }
    RPG.every(1, function () {
        if (!RPG.player.present || !RPG.getVar("dmz_created", 0)) { reset(); return; }
        var lock = locked(), c = chord();
        hold("sprint", lock);
        hold("use", c);
        var self = me(), sharing = !!(self && self.shared("kiShare", 0));
        var holding = c && down("key.mouse.right");
        if (stopCd > 0) stopCd--;
        if (!holding) {
            if ((requested || sharing) && stopCd === 0) { RPG.net.send("dmz_kishare", { op: "stop" }); stopCd = STOP_RESEND_TICKS; }
            requested = false; retry = 0;
            return;
        }
        stopCd = 0;
        if (sharing || RPG.player.hasEffect("stunned") || RPG.player.hasEffect("dmz_god_ritual")) return;
        if (retry > 0) { retry--; return; }
        if (!cfg("kiShare.enabled", true)) return;
        var t = pickTarget(Number(cfg("kiShare.startRange", 8)) || 8);
        if (!t && !genkiNearby()) return;
        RPG.net.send("dmz_kishare", { op: "start", target: t ? t.id : -1 });
        requested = true; retry = RETRY_TICKS;
    });

    // ---- KiSharePose ----------------------------------------------------------------------------
    function rad(d) { return d * Math.PI / 180; }
    function rightOf(pl) { var y = rad(pl.bodyYaw); return { x: -Math.cos(y), z: -Math.sin(y) }; }
    function fwdOf(pl) { var y = rad(pl.bodyYaw); return { x: -Math.sin(y), z: Math.cos(y) }; }
    function shoulder(pl, right) {
        var r = rightOf(pl), s = (right ? 1 : -1) * SHOULDER_SIDE * pl.modelSize;
        return { x: pl.x + r.x * s, y: pl.y + SHOULDER_H * pl.modelSize, z: pl.z + r.z * s };
    }
    function hand(pl, right, target) {
        var sh = shoulder(pl, right), dx = target.x - sh.x, dy = target.y - sh.y, dz = target.z - sh.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1e-3) return sh;
        var k = HAND_REACH * pl.modelSize / l;
        return { x: sh.x + dx * k, y: sh.y + dy * k, z: sh.z + dz * k };
    }
    function chest(pl) { return { x: pl.x, y: pl.y + 1.8 * pl.modelSize * CHEST, z: pl.z }; }
    function meeting(a, b) { return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 + SHOULDER_H * a.modelSize - RING_DROOP, z: (a.z + b.z) / 2 }; }
    function byId(id) { return id ? RPG.avatar.player(Number(id)) : null; }
    function ritualOf(pl) { var g = pl.shared("godRitual", null); return g && typeof g === "object" ? g : null; }
    /** KiSharePose.ring: the vessel and every giver round it, sorted by angle. */
    function ring(pl) {
        var g = ritualOf(pl), center = g ? byId(g.anchor) : null;
        if (!g) return null;
        var donors = RPG.avatar.players().filter(function (o) { var og = ritualOf(o); return og && og.role === 1 && og.anchor === g.anchor; });
        var c = center;
        if (!c) {
            if (!donors.length) return null;
            c = { x: 0, z: 0 };
            donors.forEach(function (d) { c.x += d.x / donors.length; c.z += d.z / donors.length; });
        }
        donors.sort(function (a, b) { return Math.atan2(a.z - c.z, a.x - c.x) - Math.atan2(b.z - c.z, b.x - c.x); });
        return { center: center, donors: donors };
    }
    /** raisedHands: both hands 4 blocks up and 1.2 out, to a Spirit Bomb. */
    function raisedHands(pl) {
        var r = rightOf(pl), sr = shoulder(pl, true), sl = shoulder(pl, false);
        return { right: { x: sr.x + r.x * RAISED_HAND_SPREAD, y: sr.y + RAISED_HAND_HEIGHT, z: sr.z + r.z * RAISED_HAND_SPREAD },
            left: { x: sl.x - r.x * RAISED_HAND_SPREAD, y: sl.y + RAISED_HAND_HEIGHT, z: sl.z - r.z * RAISED_HAND_SPREAD } };
    }
    /** KiSharePose.resolve: where each hand reaches, or null. */
    function aim(pl) {
        var g = ritualOf(pl);
        if (g && g.role === 1) {
            var r = ring(pl);
            if (!r) return null;
            var i = r.donors.indexOf(pl);
            if (i < 0) return null;
            if (r.donors.length < 3) { if (!r.center) return null; var c = chest(r.center); return { right: c, left: c }; }
            var prev = r.donors[(i - 1 + r.donors.length) % r.donors.length], next = r.donors[(i + 1) % r.donors.length];
            var tp = meeting(pl, prev), tn = meeting(pl, next), here = pl, rr = rightOf(pl);
            var ps = (tp.x - here.x) * rr.x + (tp.z - here.z) * rr.z, ns = (tn.x - here.x) * rr.x + (tn.z - here.z) * rr.z;
            return ps >= ns ? { right: tp, left: tn } : { right: tn, left: tp };
        }
        var recv = byId(pl.shared("kiShare", 0));
        if (!recv) return null;
        if (genkiOf(recv)) return raisedHands(pl);
        var t = chest(recv);
        return { right: clampFront(pl, true, t), left: clampFront(pl, false, t) };
    }
    function clampFront(pl, right, t) {
        var sh = shoulder(pl, right), dx = t.x - sh.x, dz = t.z - sh.z, h = Math.sqrt(dx * dx + dz * dz);
        if (h < 1e-4) return t;
        var f = fwdOf(pl), r = rightOf(pl), fw = (dx * f.x + dz * f.z) / h, sd = (dx * r.x + dz * r.z) / h, ang = Math.atan2(sd, fw), max = rad(MAX_SIDE_ANGLE);
        if (Math.abs(ang) <= max) return t;
        var cl = ang < 0 ? -max : max, nx = f.x * Math.cos(cl) + r.x * Math.sin(cl), nz = f.z * Math.cos(cl) + r.z * Math.sin(cl);
        return { x: sh.x + nx * h, y: t.y, z: sh.z + nz * h };
    }
    /** aimBone: the arm points from its shoulder at the target. */
    function armEdit(pl, right, t) {
        var sh = shoulder(pl, right), dx = t.x - sh.x, dy = t.y - sh.y, dz = t.z - sh.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1e-3) return null;
        dx /= l; dy /= l; dz /= l;
        var f = fwdOf(pl), r = rightOf(pl), fw = dx * f.x + dz * f.z, sd = dx * r.x + dz * r.z;
        var rx = Math.asin(Math.max(-1, Math.min(1, fw))), rz = Math.atan2(sd, -dy);
        return { rx: rx * 180 / Math.PI, ry: 0, rz: rz * 180 / Math.PI, absolute: true };
    }
    if (typeof DBR_ANIMATOR !== "undefined") DBR_ANIMATOR.extend(function (pl, out) {
        var g = ritualOf(pl), give = pl.shared("kiShare", 0);
        if (!give && !g) return;
        // isKiShareLocked: the weapon stance stops (posePredicate)
        out.layers.pose = null;
        if (g) {
            // PlayerGeoAnimatableMixin: in a god ritual a giver stands idle; the vessel charges, then floats once the channel is full
            if (g.role === 2) {
                out.layers.base = (Number(g.charge) || 0) >= 100 ? "base.fly_idle"
                    : DBR_ANIMATOR.chargeAnimations[pl.shared("race", pl.race)] || "base.ki_charge_saiyan";
                return;
            }
            out.layers.base = "base.idle";
        }
        var a = aim(pl);
        if (!a) return;
        var re = armEdit(pl, true, a.right), le = armEdit(pl, false, a.left);
        if (re) out.bones.right_arm = re;
        if (le) out.bones.left_arm = le;
        out.layers.attack = null; out.layers.mining = null;
    });

    // ---- KiShareVisuals: the original's KI_TRAIL particles (KiTrailParticle: velocity x 0.9 and size x 0.97 a tick, fading
    // over its life, 25-35 ticks unless set, additive, full bright) -------------------------------------------------------
    function hex(c) { return typeof c === "number" ? "#" + ("000000" + c.toString(16)).slice(-6) : String(c || "#FFFFFF"); }
    function lerpHex(a, b, t) {
        var pa = parseInt(hex(a).substring(1), 16), pb = parseInt(hex(b).substring(1), 16), r = 0;
        for (var sh = 16; sh >= 0; sh -= 8) { var ca = (pa >> sh) & 255, cb = (pb >> sh) & 255; r |= Math.round(ca + (cb - ca) * t) << sh; }
        return "#" + ("000000" + r.toString(16)).slice(-6);
    }
    function spawn(p, v, color, scale, life) {
        try {
            RPG.particles.sprite({ texture: KTEX, animate: true, x: p.x, y: p.y, z: p.z, vx: v.x, vy: v.y, vz: v.z, friction: 0.9, growMul: 0.97,
                size: scale * (0.1 + Math.random() * 0.3), life: life > 0 ? life : [25, 35], fade: "life", color: color, blend: "additive",
                fullbright: true, collide: false });
        } catch (e) { }
    }
    function jitter() { return (Math.random() - 0.5) * 2 * STREAM_JITTER; }
    /** auraColor: the form's aura colour (FormVisualTransition), else the character's own. */
    function auraColor(pl) {
        var fx = pl.shared("dmzAuraFx", null);
        if (fx && fx.f && typeof DMZ_FORMS !== "undefined") {
            try { var f = DMZ_FORMS.form(fx.r, fx.fg, fx.f); if (f && f.aura) return hex(f.aura); } catch (e) { }
        }
        if (fx && fx.base) return hex(fx.base);
        return hex(pl.color("aura", 0x7FC8FF));
    }
    function emitStream(from, to, color) {
        var start = { x: from.x + jitter(), y: from.y + jitter(), z: from.z + jitter() }, spread = 0.9 + Math.random() * 0.2, k = spread / STREAM_TRAVEL_FACTOR;
        spawn(start, { x: (to.x - start.x) * k, y: (to.y - start.y) * k, z: (to.z - start.z) * k }, color, STREAM_SCALE, -1);
    }
    function randomUnit() {
        var y = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2, r = Math.sqrt(1 - y * y);
        return { x: r * Math.cos(th), y: y, z: r * Math.sin(th) };
    }
    function genkiFlow(donor, genki, a) {
        var color = hex(genki.colors && genki.colors.core);
        if (a && Math.random() < 1 / 3) {
            var right = Math.random() < 0.5, h = hand(donor, right, Math.random() < 0.5 ? a.right : a.left);
            spawn({ x: h.x + jitter(), y: h.y + jitter(), z: h.z + jitter() }, { x: jitter(), y: GENKI_RISE_SPEED, z: jitter() }, color, GENKI_HAND_ORB_SCALE, GENKI_HAND_ORB_LIFETIME);
        }
        var c = genkiCenter(genki), radius = genki.size * 0.5;
        var tx = donor.x - c.x, ty = donor.y + 1.62 * donor.modelSize - c.y, tz = donor.z - c.z, tl = Math.sqrt(tx * tx + ty * ty + tz * tz);
        var bias = tl > 1e-2 ? { x: tx / tl, y: ty / tl, z: tz / tl } : { x: 0, y: -1, z: 0 };
        for (var i = 0; i < GENKI_ORBS_PER_TICK; i++) {
            var u = randomUnit(), dx = bias.x + u.x * GENKI_ORB_SPREAD, dy = bias.y + u.y * GENKI_ORB_SPREAD, dz = bias.z + u.z * GENKI_ORB_SPREAD;
            var dl = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
            dx /= dl; dy /= dl; dz /= dl;
            var s = { x: c.x + dx * (radius + GENKI_ORB_DISTANCE), y: c.y + dy * (radius + GENKI_ORB_DISTANCE), z: c.z + dz * (radius + GENKI_ORB_DISTANCE) };
            var e = { x: c.x + dx * radius * 0.6, y: c.y + dy * radius * 0.6, z: c.z + dz * radius * 0.6 };
            spawn(s, { x: (e.x - s.x) / STREAM_TRAVEL_FACTOR, y: (e.y - s.y) / STREAM_TRAVEL_FACTOR, z: (e.z - s.z) / STREAM_TRAVEL_FACTOR }, color, GENKI_ORB_SCALE, GENKI_ORB_LIFETIME);
        }
    }
    function frac(x) { return x - Math.floor(x); }
    function pointAt(path, lens, total, d) {
        for (var i = 1; i < path.length; i++) {
            if (d > lens[i] && i < path.length - 1) continue;
            var seg = lens[i] - lens[i - 1], f = seg > 1e-6 ? Math.max(0, Math.min(1, (d - lens[i - 1]) / seg)) : 0, a = path[i - 1], b = path[i];
            return { x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f, z: a.z + (b.z - a.z) * f };
        }
        return path[path.length - 1];
    }
    function emitTracers(path, color, time, seed) {
        var lens = [0], total = 0, Z = { x: 0, y: 0, z: 0 };
        for (var i = 1; i < path.length; i++) {
            var a = path[i - 1], b = path[i];
            total += Math.sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y) + (a.z - b.z) * (a.z - b.z));
            lens.push(total);
        }
        if (total < 1e-3) return;
        for (var sub = 0; sub < TRACER_SUBSTEPS; sub++) {
            var t = time + sub / TRACER_SUBSTEPS;
            for (var k = 0; k < TRACERS_PER_WAY; k++) {
                var off = k / TRACERS_PER_WAY + seed * 0.137;
                var fwd = frac(t * TRACER_SPEED + off), back = 1 - frac(t * TRACER_RETURN_SPEED + off + 0.5 / TRACERS_PER_WAY);
                spawn(pointAt(path, lens, total, total * fwd), Z, color, TRACER_SCALE, TRACER_LIFETIME);
                spawn(pointAt(path, lens, total, total * back), Z, color, TRACER_SCALE, TRACER_LIFETIME);
            }
        }
    }
    function onRight(pl, pt) { var r = rightOf(pl); return (pt.x - pl.x) * r.x + (pt.z - pl.z) * r.z >= 0; }
    function ritualFlow(pl, g) {
        var r = ring(pl);
        if (!r) return;
        var i = r.donors.indexOf(pl);
        if (i < 0) return;
        var cg = r.center ? ritualOf(r.center) : null;
        var color = lerpHex(auraColor(pl), GOD_AURA, Math.max(0, Math.min(1, ((cg && Number(cg.charge)) || 0) / 100)));
        var time = RPG.world.gameTime();
        if (r.donors.length < 3) {
            if (!r.center) return;
            var c = chest(r.center);
            emitTracers([shoulder(pl, true), hand(pl, true, c), c], color, time, i);
            return;
        }
        var next = r.donors[(i + 1) % r.donors.length], m = meeting(pl, next), pr = onRight(pl, m), nr = onRight(next, m);
        emitTracers([shoulder(pl, pr), hand(pl, pr, m), hand(next, nr, m), shoulder(next, nr)], color, time, i);
    }
    /** faceRitualCenter: a ritual giver keeps facing the vessel (your own view too). */
    function faceCenter(pl, g) {
        var c = byId(g.anchor);
        if (!c || !pl.local) return;
        var dx = c.x - pl.x, dz = c.z - pl.z;
        if (dx * dx + dz * dz < 1e-4) return;
        try { RPG.player.setRotation(Math.atan2(-dx, dz) * 180 / Math.PI, RPG.player.pitch); } catch (e) { }
    }
    RPG.every(1, function () {
        if (!RPG.player.present || RPG.isPaused && RPG.isPaused()) return;
        RPG.avatar.players().forEach(function (pl) {
            var g = ritualOf(pl);
            if (g && g.role === 1) { faceCenter(pl, g); ritualFlow(pl, g); return; }
            var give = pl.shared("kiShare", 0);
            if (!give) return;
            var recv = byId(give);
            if (!recv) return;
            var a = aim(pl), genki = genkiOf(recv);
            if (genki) { genkiFlow(pl, genki, a); return; }
            if (!a) return;
            var to = chest(recv), color = auraColor(pl);
            emitStream(hand(pl, true, a.right), to, color);
            emitStream(hand(pl, false, a.left), to, color);
        });
    });

    // ---- GodRitualShellEffect: the vessel drawn white in the shell colour, fading in then out --------------
    var SHELLS = {};
    RPG.net.on("dmz_god_shell", function (d) {
        if (!d) return;
        if (d.off) { delete SHELLS[d.id]; RPG.avatar.clearOutline(Number(d.id)); return; }
        SHELLS[d.id] = { start: RPG.time(), inT: d.inTicks || 20, outT: d.outTicks || 30, color: d.color || cfg("godRitual.shellColor", "#6FD8FF") };
    });
    RPG.every(1, function () {
        Object.keys(SHELLS).forEach(function (id) {
            var s = SHELLS[id], e = RPG.time() - s.start, a;
            if (e < s.inT) a = e / s.inT;
            else { var o = (e - s.inT) / s.outT; if (o >= 1) { delete SHELLS[id]; RPG.avatar.clearOutline(Number(id)); return; } var f = 1 - o; a = f * f * (3 - 2 * f); }
            RPG.avatar.setOutline(Number(id), { color: "#FFFFFF", color2: s.color, mode: "solid", thickness: 0.6, glow: a, bodyGlow: a, alpha: a });
        });
    });
})();
