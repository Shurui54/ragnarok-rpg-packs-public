// =====================================================================================
//  51w_dmz_kiweapon_render.js - the original's ki weapons drawn with its ki blade shader
// =====================================================================================
//  Port of the original (GPL-3.0, see NOTICE.md): KiWeaponRenderer + DMZWeaponsLayer. While a player has a ki weapon
//  out (look kiWeapon = blade | scythe | clawlance, scripts/79_dmz_kiweapon.js) the weapon is a camera-facing quad (the
//  claw lance nine rods) on the main arm, shaded by dbr:ki_blade (resources/assets/dbr/shaders/core) in the ki colour
//  (look kiWeaponColor), with the bloom pass. The draw follows the arm bone as the world drew it this frame (RPG.shaders
//  draw `bone`), so it is where the arm is in third person and on the animated first-person body.
//  The strike combos' beam sword (KiBladeExtendS2C: summon / extend, 49t_dmz_strike_fx2.js) grows the same blade,
//  also on bodies without Ki Manipulation and on saga enemies.
//  The weapon models (20_races.js KI_WEAPON_PARTS) are the original's fallback when its shader is missing: they stay
//  for computers where this shader does not load, and are hidden through the animator where it does.
// =====================================================================================
var DMZ_KIWEAPON_FX = (function () {
    var SH = "dbr:ki_blade", FMT = "position_tex", P = "dbr_kw_";
    var MESH_ONE = "dbr_kw_quad", MESH_CLAW = "dbr_kw_claw";
    var WEAPON = { blade: 0, scythe: 1, clawlance: 2 };
    // KiWeaponRenderer: BLADE_REACH, BLADE_SUMMON_TICKS, BLADE_GROW_TICKS, BLADE_SHRINK_TICKS
    var BLADE_REACH = 24 / 16, SUMMON_TICKS = 6, GROW_TICKS = 2, SHRINK_TICKS = 3;
    var ready = false, failed = false, stage = 0;
    var LIVE = {};            // entity id -> { key, color }
    var SUMMONS = {}, EXTENSIONS = {}, CLOCK = 0;

    function setup() {
        if (ready || failed) return ready;
        // bone draws arrived with API level 1 (engine 0.29.5): an older engine would draw the blade away from the arm
        if (typeof RPG.apiLevel !== "number") { failed = true; RPG.log("[DBR] ki blade shader needs engine 0.29.5; ki weapons keep their models"); return false; }
        var st = RPG.shaders.status(SH, FMT);
        if (st === "failed") { failed = true; RPG.log("[DBR] ki blade shader did not load; ki weapons keep their models"); return false; }
        if (st !== "ready") return false;
        if (stage === 0) {
            // one quad, its corners in UV0 (KiWeaponRenderer's vertex order); the vertex shader places it
            RPG.shaders.mesh(MESH_ONE, { format: FMT, mode: "quads", vertices: [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0] });
        } else {
            // the claw lance's nine rods: the rod number in position x
            var v = [];
            for (var i = 0; i < 9; i++) v.push(i, 0, 0, 0, 0, i, 0, 0, 0, 1, i, 0, 0, 1, 1, i, 0, 0, 1, 0);
            RPG.shaders.mesh(MESH_CLAW, { format: FMT, mode: "quads", vertices: v });
            ready = true;
        }
        stage++;
        return ready;
    }

    function rgb(c) { return [((c >> 16) & 255) / 255, ((c >> 8) & 255) / 255, (c & 255) / 255]; }
    function parse(s, d) { s = String(s || "").replace("#", ""); var v = parseInt(s.slice(-6), 16); return isNaN(v) ? d : v; }
    function seed(id) { return (id * 0.618034) % 1; }                 // KiWeaponRenderer.bladeSeed

    /** KiWeaponRenderer.bladeReach: the blade's length from the wrist with the beam sword's stretch and summon grow. */
    function bladeReach(id) {
        var reach = BLADE_REACH, ex = EXTENSIONS[id], su = SUMMONS[id];
        if (ex) {
            var age = CLOCK - ex.at;
            if (age > ex.ticks || age < 0) delete EXTENSIONS[id];
            else {
                var grow = Math.max(0, Math.min(1, age / GROW_TICKS)), shrink = Math.max(0, Math.min(1, (ex.ticks - age) / SHRINK_TICKS));
                reach = BLADE_REACH + (Math.max(BLADE_REACH, ex.length) - BLADE_REACH) * Math.min(grow, shrink);
            }
        }
        if (su) reach *= Math.max(0.05, Math.min(1, (CLOCK - su.at) / SUMMON_TICKS));
        return reach;
    }
    function forced(id) {
        var su = SUMMONS[id];
        if (!su) return false;
        var age = CLOCK - su.at;
        if (age < 0 || age > su.ticks) { delete SUMMONS[id]; return false; }
        return true;
    }

    function want(id, type, color, arm) {
        var key = type + "|" + arm, w = WEAPON[type], u = {
            Weapon: w, Reach: w === 0 ? bladeReach(id) : BLADE_REACH, Aura: rgb(color), Seed: seed(id), bloomMode: 0,
            BoneMinX: { k: { boneMinX: 1 } }, BoneMinY: { k: { boneMinY: 1 } }, BoneMinZ: { k: { boneMinZ: 1 } },
            BoneMaxX: { k: { boneMaxX: 1 } }, BoneMaxZ: { k: { boneMaxZ: 1 } } };
        var cur = LIVE[id];
        if (cur && cur.key === key) { RPG.shaders.update(P + id, { uniforms: { Reach: u.Reach, Aura: u.Aura } }); return; }
        // the claw lance: Matrix4f.rotateY(35).rotateX(35).translate(0, -0.1, -1) on the arm's matrix first
        var ops = w === 2 ? [["rotateY", 35], ["rotateX", 35], ["translate", 0, -0.1, -1]] : [];
        RPG.shaders.draw(P + id, { mesh: w === 2 ? MESH_CLAW : MESH_ONE, shader: SH, entity: id, bone: arm, ops: ops, uniforms: u,
            bloom: { bloomMode: 1 }, cull: false, depthWrite: false, order: 18 });
        LIVE[id] = { key: key };
    }
    function drop(id) { if (LIVE[id]) { RPG.shaders.remove(P + id); delete LIVE[id]; } }

    RPG.on("tick", function () {
        CLOCK++;
        if (!setup()) return;
        var seen = {};
        RPG.avatar.players().forEach(function (pl) {
            if (pl.invisible || pl.spectator || pl.dead) return;
            var type = String(pl.lookValue("kiWeapon") || "").toLowerCase(), f = forced(pl.id);
            if (f) type = "blade";                                  // DMZWeaponsLayer: a summoned blade wins
            if (WEAPON[type] === undefined) return;
            var color = f && SUMMONS[pl.id].color >= 0 ? SUMMONS[pl.id].color : pl.color("kiWeaponColor", 0x7FFFFF);
            want(pl.id, type, color, pl.leftHanded ? "left_arm" : "right_arm");
            seen[pl.id] = 1;
        });
        // summoned blades on other bodies (saga enemies: KiWeaponRenderer.SagaBladeLayer, always the right arm)
        for (var k in SUMMONS) {
            var id = Number(k);
            if (seen[id] || !forced(id) || !RPG.world.entity(id)) continue;
            want(id, "blade", SUMMONS[k].color >= 0 ? SUMMONS[k].color : 0x7FFFFF, "right_arm");
            seen[id] = 1;
        }
        for (var l in LIVE) if (!seen[l]) drop(Number(l));
    });

    // the weapon models step aside while the shader draws the weapons (the animator's bone edits reach part bones)
    if (typeof DBR_ANIMATOR !== "undefined") DBR_ANIMATOR.extend(function (pl, out) {
        if (!ready || !LIVE[pl.id]) return;
        out.bones.kiweapon_blade = { hide: true };
        out.bones.kiweapon_scythe = { hide: true };
        out.bones.kiweapon_clawlance = { hide: true };
    });

    RPG.on("load", function () { LIVE = {}; SUMMONS = {}; EXTENSIONS = {}; ready = false; failed = false; stage = 0; });

    return {
        /** True once the shader draws the weapons (else the models and the stand-in beam sword are used). */
        ready: function () { return ready; },
        /** KiBladeExtendS2C.summon: a blade on that body for ticks (0 takes summons and stretches away). */
        summon: function (id, ticks, color) {
            if (ticks <= 0) { delete SUMMONS[id]; delete EXTENSIONS[id]; return; }
            var c = typeof color === "number" && !isNaN(color) ? color : -1;
            // a blade already out stays out (no second grow): it is only kept longer
            if (forced(id)) { var su = SUMMONS[id]; su.ticks = Math.max(su.ticks, CLOCK - su.at + ticks); if (c >= 0) su.color = c; return; }
            SUMMONS[id] = { at: CLOCK, ticks: ticks, color: c };
        },
        /** KiBladeExtendS2C.extend: the blade stretched to length blocks over ticks. */
        extend: function (id, length, ticks) { EXTENSIONS[id] = { length: length, at: CLOCK, ticks: ticks }; }
    };
})();
