#version 150
// The original's ki weapons (GPL-3.0, see NOTICE.md): KiWeaponRenderer's camera-facing blade, scythe and claw lance
// quads, built here from the arm bone the draw follows (RPG.shaders draw `bone`: ModelViewMat is that bone's matrix,
// BoneMin / BoneMax its cubes' box in model blocks). Weapon: 0 blade, 1 scythe, 2 claw lance (its draw turns 35 / 35
// degrees and moves (0, -0.1, -1) first). Position.x: the claw lance rod (0-8); UV0: the corner of the quad.

in vec3 Position;
in vec2 UV0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform float Weapon;
uniform float Reach;
uniform float BoneMinX;
uniform float BoneMinY;
uniform float BoneMinZ;
uniform float BoneMaxX;
uniform float BoneMaxZ;

out vec2 vUv;

const float BLADE_WRIST_OFFSET = 3.0 / 16.0;
const float BLADE_ARM_SHIFT = 2.0 / 16.0;
const float BLADE_HALF_WIDTH = 7.5 / 16.0;
const float BLADE_FRONT_OFFSET = 2.6 / 16.0;
const float BURST_CENTER_OFFSET = 3.0 / 16.0;
const float BURST_HALF_SIZE = 10.0 / 16.0;
const float SCYTHE_SHAFT_LENGTH = 55.0 / 16.0;
const float SCYTHE_HEAD_FORWARD = 28.0 / 16.0;
const float SCYTHE_GRIP_HEIGHT = 2.25 / 16.0;
const float SCYTHE_PAD = 4.0 / 16.0;
const float SCYTHE_BACK_REACH = 5.0 / 16.0;
const float SCYTHE_BLADE_REACH = 25.0 / 16.0;
const float SCYTHE_UV_OFFSET = 20.0;
const float CLAW_AXIS_X = 6.15 / 16.0;
const float CLAW_AXIS_Y = 14.0 / 16.0;
const float CLAW_HEAD_Z = -17.0 / 16.0;
const float CLAW_BUTT_Z = 13.0 / 16.0;
const float CLAW_ELBOW_Z = -9.5 / 16.0;
const float CLAW_TINE_TIP_Z = -28.75 / 16.0;
const float CLAW_PRONG_RADIUS = 5.0 / 16.0;
const float CLAW_ROD_PAD = 0.3;
const float CLAW_ROD_HALF_REACH = 0.36;
const float CLAW_ROD_FRONT = 1.5 / 16.0;
const float CLAW_ROD_UV = 60.0;
const float CLAW_ROD_STRIDE = 4.0;

bool ok = true;

vec3 safeNormalize(vec3 v, float len) {
    float l2 = dot(v, v);
    if (l2 < 1.0e-10) return v;
    return v * (len / sqrt(l2));
}

// KiWeaponRenderer.renderBlade: one quad from start to end, facing the camera, pushed toward it, with the hand burst
vec3 blade(vec3 start, vec3 end, vec3 cam) {
    vec3 axis = end - start;
    if (dot(axis, axis) < 1.0e-10) { ok = false; return start; }
    vec3 dir = normalize(axis);
    vec3 toCamera = cam - (start + end) * 0.5;
    vec3 side = cross(axis, toCamera);
    if (dot(side, side) < 1.0e-10) { ok = false; return start; }
    side = normalize(side) * BLADE_HALF_WIDTH;
    vec3 front = safeNormalize(toCamera - dir * dot(toCamera, dir), BLADE_FRONT_OFFSET);
    float len = sqrt(dot(axis, axis));
    float uStart = min(0.0, (BURST_CENTER_OFFSET - BURST_HALF_SIZE) / len);
    float vMax = max(1.0, BURST_HALF_SIZE / BLADE_HALF_WIDTH);
    vec3 s = start + front + dir * (uStart * len);
    vec3 e = end + front;
    side *= vMax;
    float sv = UV0.y * 2.0 - 1.0;
    vUv = vec2(mix(uStart, 1.0, UV0.x), vMax * sv);
    return mix(s, e, UV0.x) + side * sv;
}

// KiWeaponRenderer.renderAxisWeapon: a quad along head -> butt, (s0..s1) along it and (t0..t1) across it
vec3 axisWeapon(vec3 head, vec3 butt, vec3 sideRef, bool useRef, vec4 span, float uOffset, float frontOffset, bool fixedFront, vec3 fixedValue, vec3 cam) {
    vec3 axis = butt - head;
    if (dot(axis, axis) < 1.0e-10) { ok = false; return head; }
    vec3 dir = normalize(axis);
    vec3 toCamera = cam - (head + butt) * 0.5;
    vec3 side = cross(dir, toCamera);
    if (dot(side, side) < 1.0e-10) { ok = false; return head; }
    side = normalize(side);
    if (useRef && dot(side, sideRef) < 0.0) side = -side;
    vec3 front = safeNormalize(toCamera - dir * dot(toCamera, dir), frontOffset);
    if (fixedFront) front = fixedValue;
    vec3 origin = head + front;
    float s = mix(span.x, span.y, UV0.x);
    float t = mix(span.z, span.w, UV0.y);
    vUv = vec2(uOffset + s, t);
    return origin + dir * s + side * t;
}

vec3 prongBase(int i) {
    vec2 d = i == 0 ? vec2(1.0, 0.0) : i == 1 ? vec2(0.0, 1.0) : i == 2 ? vec2(-1.0, 0.0) : vec2(0.0, -1.0);
    return vec3(CLAW_AXIS_X + d.x * CLAW_PRONG_RADIUS, CLAW_AXIS_Y + d.y * CLAW_PRONG_RADIUS, CLAW_HEAD_Z);
}

void main() {
    vec3 cam = (inverse(ModelViewMat) * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
    vec3 anchor = vec3((BoneMinX + BoneMaxX) * 0.5, BoneMinY, (BoneMinZ + BoneMaxZ) * 0.5);
    vec3 p;
    if (Weapon < 0.5) {
        p = blade(anchor + vec3(0.0, BLADE_WRIST_OFFSET + BLADE_ARM_SHIFT, 0.0), anchor + vec3(0.0, -Reach + BLADE_ARM_SHIFT, 0.0), cam);
    } else if (Weapon < 1.5) {
        vec3 head = vec3(anchor.x, anchor.y + SCYTHE_GRIP_HEIGHT, anchor.z - SCYTHE_HEAD_FORWARD);
        vec3 butt = head + vec3(0.0, 0.0, SCYTHE_SHAFT_LENGTH);
        p = axisWeapon(head, butt, vec3(0.0, -1.0, 0.0), true, vec4(-SCYTHE_PAD, SCYTHE_SHAFT_LENGTH + SCYTHE_PAD, -SCYTHE_BACK_REACH, SCYTHE_BLADE_REACH),
                SCYTHE_UV_OFFSET, BLADE_FRONT_OFFSET, false, vec3(0.0), cam);
    } else {
        // renderClawLance: the shaft, four elbows out to the prongs, four tines forward; every rod pushed the same way
        int piece = int(Position.x + 0.5);
        vec3 center = vec3(CLAW_AXIS_X, CLAW_AXIS_Y, (CLAW_TINE_TIP_Z + CLAW_BUTT_Z) * 0.5);
        vec3 front = cam - center;
        if (dot(front, front) < 1.0e-10) ok = false;
        front = safeNormalize(front, CLAW_ROD_FRONT);
        vec3 from, to;
        if (piece == 0) { from = vec3(CLAW_AXIS_X, CLAW_AXIS_Y, CLAW_HEAD_Z); to = vec3(CLAW_AXIS_X, CLAW_AXIS_Y, CLAW_BUTT_Z); }
        else if (piece <= 4) { from = vec3(CLAW_AXIS_X, CLAW_AXIS_Y, CLAW_ELBOW_Z); to = prongBase(piece - 1); }
        else { from = prongBase(piece - 5); to = vec3(from.x, from.y, CLAW_TINE_TIP_Z); }
        float len = length(to - from);
        p = axisWeapon(from, to, vec3(0.0), false, vec4(-CLAW_ROD_PAD, len + CLAW_ROD_PAD, -CLAW_ROD_HALF_REACH, CLAW_ROD_HALF_REACH),
                CLAW_ROD_UV + float(piece) * CLAW_ROD_STRIDE, CLAW_ROD_FRONT, true, front, cam);
    }
    gl_Position = ok ? ProjMat * ModelViewMat * vec4(p, 1.0) : vec4(2.0, 2.0, 2.0, 1.0);
}
