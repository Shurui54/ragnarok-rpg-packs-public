// =====================================================================================
//  67b_dmz_shadow_dummy.js - the original's Shadow Dummy (SummonPlayerShadowDummyC2S, ShadowDummyEntity,
//  StatsEvents / TickHandler / TPGainEvents / CombatEvent / EntitiesEvents)
// =====================================================================================
//  Two kinds of shadow, both the mob "shadow_dummy" (75_mobs_bosses.js):
//   - Mr. Popo's "Shadow Clone" (61_dmz_masters.js): copyStatsFromPlayer, your full health, a quarter of your damage.
//     Killing it pays half the usual kill TP for its health.
//   - The Minigames tab's Shadow Dummy (53_dmz_minigames.js): needs a shadow defeated before, Ki Control and Ki
//     Manipulation 5. You give it 25-75 % of yourself (copyStatsFromPlayerWithPercent: health x p, melee and ki
//     damage x p x 0.75) and lose the same share while it lives: Strength, Strike, Ki Power and Resistance (defence
//     and stamina) x (1 - p), max health x (1 - p), and ki and stamina regenerate only up to (1 - p) of their max.
//     Hits and the kill on it pay (1 + p) x the TP. It is dismissed (you get everything back) when it dies, when it
//     knocks you down (a hit that would kill you leaves you on 1 HP, knocked down), when it is more than 100 blocks
//     away or in another dimension, and when you log in again. One at a time.
//  Player vars: dmz_shadow {u: uuid, p: percent} while one lives, dmz_shadow_kills (shadows you have defeated).
//  dmzView (10_stats.js) reads dmz_shadow for the stat and health penalty.
// =====================================================================================
var DMZ_SHADOW = (function () {
    var TAG_PLAYER = "dmz_player_shadow", TETHER = 100, RATE_TICKS = 40;
    var LAST = {};

    function info(p) { var s = p.getVar("dmz_shadow", null); return s && typeof s === "object" && s.u ? s : null; }
    function pct(p) { var s = info(p); return s ? Math.max(25, Math.min(75, Number(s.p) || 0)) : 0; }
    function kills(p) { return Number(p.getVar("dmz_shadow_kills", 0)) || 0; }
    function level(p, s) { return typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS.level(p, s) : 0; }
    function meetsRequirements(p) { return kills(p) > 0 && level(p, "kicontrol") > 0 && level(p, "kimanipulation") >= 5; }
    function ownerOf(mob) { var o = mob.getVar("dmz_quest_owner", ""); return o ? String(o) : null; }
    function isPlayerShadow(e) { return !!e && e.hasTag && e.hasTag(TAG_PLAYER); }
    function shadowPct(e) { return Math.max(25, Math.min(75, Number(e.getVar("dmz_shadow_percent", 50)) || 50)); }

    function refreshOwner(p) {
        // the penalty is in dmzView; bring max health in step now (setHealth(min(health, newMax)))
        try {
            p.refreshStats();
            var hp = DMZ_F.maxHealth(dmzView(p));
            if (Math.abs(p.maxHealth - hp) > 0.01) p.maxHealth = hp;
            if (p.health > p.maxHealth) p.health = p.maxHealth;
            var ki = p.maxResource("ki") * (1 - pct(p) / 100), st = p.maxResource("stamina") * (1 - pct(p) / 100);
            if (p.resource("ki") > ki) p.setResource("ki", ki);
            if (p.resource("stamina") > st) p.setResource("stamina", st);
        } catch (e) { }
    }

    function restore(p) {
        if (!info(p)) return;
        p.setVar("dmz_shadow", null);
        refreshOwner(p);
    }

    // clearPlayerShadowDummy: discard the dummy and give everything back
    function clear(p) {
        var s = info(p);
        if (!s) return;
        var e = RPG.world.entityByUuid(String(s.u));
        if (e && e.isAlive()) e.remove();
        restore(p);
    }

    // dismissByDummy
    function dismiss(mob) {
        var owner = ownerOf(mob), p = owner ? RPG.server.player(owner) : null;
        if (p) { var s = info(p); if (s && String(s.u) === String(mob.uuid)) restore(p); }
        if (mob.isAlive()) mob.remove();
    }

    // copyStatsFromPlayerWithPercent / copyStatsFromPlayer
    function copyStats(mob, p, scale, meleeScale, kiScale) {
        var v = dmzView(p), hp = Math.max(1, p.maxHealth * scale);
        mob.maxHealth = hp;
        mob.health = hp;
        try { mob.setAttributeBase("generic.attack_damage", Math.max(0, DMZ_F.melee(v) * meleeScale)); } catch (e) { }
        mob.setVar("dmz_ki_damage", DMZ_F.ki(v) * kiScale);
        mob.setVar("dbr_bp", Math.floor(DMZ_F.battlePower(v) * scale));
    }

    function summon(p, percent) {
        if (!p.getVar("dmz_created", 0) || !p.alive) return;
        var now = RPG.server.getTick();
        if (LAST[p.uuid] && now - LAST[p.uuid] < RATE_TICKS) return;          // PacketRateLimiter 40
        LAST[p.uuid] = now;
        if (!meetsRequirements(p)) { RPG.net.send(p, "dmz_msg", { key: "gui.dragonminez.shadow_dummy.requirements_not_met", args: [], color: "#FF5555" }); return; }
        var share = Math.max(25, Math.min(75, Math.round(Number(percent) || 50)));
        clear(p);
        var mob = RPG.world.spawnMob(p.dimension, "shadow_dummy", p.x, p.y, p.z);
        if (!mob) return;
        copyStats(mob, p, share / 100, share / 100 * 0.75, share / 100 * 0.75);
        mob.addTag(TAG_PLAYER);
        mob.addTag("owner:" + p.uuid);
        mob.setVar("dmz_quest_owner", p.uuid);
        mob.setVar("dmz_shadow_percent", share);
        p.setVar("dmz_shadow", { u: mob.uuid, p: share });
        refreshOwner(p);
    }

    /** Mr. Popo's Shadow Clone (NPCActionC2S.spawnPopoDummy): copyStatsFromPlayer. */
    function popoCopy(mob, p) { copyStats(mob, p, 1, 0.25, 0.25); }

    // ---- the dummy's death (StatsEvents.onLivingDeath): a kill counts, a player's shadow gives its share back ----
    function onDeath(mob, killer) {
        var kp = killer && killer.isPlayer && killer.isPlayer() ? killer.asPlayer() : null;
        if (kp) kp.setVar("dmz_shadow_kills", kills(kp) + 1);
        if (isPlayerShadow(mob)) {
            var owner = ownerOf(mob), p = owner ? RPG.server.player(owner) : null;
            if (p) { var s = info(p); if (s && String(s.u) === String(mob.uuid)) restore(p); }
        }
    }

    // ---- TP (TPGainEvents): a player's shadow pays (1 + p) x; Popo's pays half for its health on the kill ----
    function killTp(victim, base) {
        if (!victim || String(victim.rpgId || "") !== "shadow_dummy") return base;
        if (isPlayerShadow(victim)) return Math.max(1, Math.round(base * (1 + shadowPct(victim) / 100)));
        return 2 + Math.round(victim.maxHealth * 0.25 * 0.5);
    }
    function hitTp(victim, base) {
        if (!isPlayerShadow(victim)) return base;
        return Math.max(1, Math.round(base * (1 + shadowPct(victim) / 100)));
    }

    // ---- the shadow's finishing blow knocks its owner down and goes (CombatEvent shadowKnockdown) ----
    RPG.on("lethal", function (e) {
        var a = e.attacker, t = e.target;
        if (!a || !t || !t.isPlayer() || e.isCancelled() || !isPlayerShadow(a)) return;
        var p = t.asPlayer();
        e.amount = Math.max(0, p.health - 1);
        if (typeof DMZ_KIWEAPON !== "undefined") DMZ_KIWEAPON.knockDown(p);
        dismiss(a);
    });

    // ---- the tether (TickHandler.enforceShadowDummyTether / EntitiesEvents): 100 blocks, same dimension ----
    RPG.every(20, function () {
        RPG.server.players().forEach(function (p) {
            var s = info(p);
            if (!s) return;
            var e = RPG.world.entityByUuid(String(s.u));
            if (!e || !e.isAlive() || e.dimension !== p.dimension || p.distanceTo(e) > TETHER) { if (e && e.isAlive()) e.remove(); restore(p); }
        });
    });
    // logging in again clears it (TickHandler.onPlayerLogin); leaving takes the dummy away (cleanupQuestEntities)
    RPG.on("playerJoin", function (p) { if (info(p)) clear(p); });
    RPG.on("playerLeave", function (p) { var s = info(p); if (s) { var e = RPG.world.entityByUuid(String(s.u)); if (e && e.isAlive()) e.remove(); } delete LAST[p.uuid]; });

    RPG.net.on("dmz_shadow_summon", function (p, d) { summon(p, d && d.pct); });

    return { info: info, pct: pct, kills: kills, meetsRequirements: meetsRequirements, summon: summon, clear: clear, dismiss: dismiss,
        popoCopy: popoCopy, onDeath: onDeath, killTp: killTp, hitTp: hitTp, isPlayerShadow: isPlayerShadow };
})();
