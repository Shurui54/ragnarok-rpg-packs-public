// =====================================================================================
//  Original transformations data (DefaultFormsFactory defaults) + the pure rules around them
//  (TransformationsHelper, StatsData multipliers, FormModeHandler requirements, TickHandler
//  drains). Shared: the server (scripts/31_dmz_transform.js) runs the state machine, the
//  client (client/scripts/45_transform.js) shows the form menu from the same tables.
//
//  Ported from the original (GPL-3.0) - values copied on purpose, see NOTICE.md.
//  docs/dmz-spec/02_forms_visuals.md section 2 lists every number below.
//
//  A group is an ordered list (the order IS the transformation ladder). Form fields
//  (omitted = the original FormData default):
//    n      display name                 lvl    unlockOnSkillLevel     saga  sagaRequisite (gates buying the level)
//    m      [STR, SKP, DEF, PWR]         spd    speedMultiplier        atk   attackSpeed
//    stmM   staminaDrainMultiplier       ki/sd/hd  energy/stamina/health drain (per second factors)
//    model  the original customModel key          scale  modelScaling (number or [x, y, z]) - absolute
//    anim   transformationAnimation      hair   hairType ("", base, ssj, ssj2, ssj3, ssj4, empty)
//    c      colour overrides {hair, eye1, eye2, body1, body2, body3}
//    aura   auraColor                    bolt   lightningColor (hasLightnings)
//    tint   [hex, intensity]             ult    incompatible with ultimate.ultimate
//    free   allowFreeTransformOnMastery (first form of a group: 0)
//    ol     outlineShader: {m: "gradient" | "pulse", c, c2, t thickness, fire fireIntensity, bg bodyGlow}
//           (TransformationPostShaderManager; drawn by the engine's avatar outline, 30_forms.js)
//    keepHead, tailOnly, req (formRequisite override), share [["group.form", mult]],
//    stackOn, stackDrain, stackable, maxMastery, layers (extra overlays, 30_forms.js)
//  Form editor fields (the Ragnarok original's sidecars; omitted = original default, see the editor section below):
//    mx {STM, VIT, ENE} multipliers   perHit / passive / instantOn  per-form mastery rates
//    mStats / mCost  maxStats / maxCost multipliers   unlockOn  requisite mastery   auraScale  aura size
//    plvl  min character level to use   alignMin / alignMax  alignment window to use (0..100)
//    cost  TP price of the form's skill level   desc  notes
//    combat {dodgePhysical, dodgeMeleeSkill, dodgeEnergySkill, damageMitigation, statGainPercent {STR..ENE}, maxBonusPercent}
//          The Ragnarok original's FormCombatData (Dodge / Buffs tabs), run by scripts/34_dbr_form_combat.js
//  Ops' edits from world storage are merged in below (applyCustom) before any script reads the tables.
// =====================================================================================
var DMZ_FORMS = (function () {
    var D = {
        maxMastery: 100, perHit: 0.025, passive: 0.004, maxStats: 1.5, maxCost: 0.75, stackOn: 25,
        instantOn: 40, freeOn: 50, unlockOn: 25, stackDrain: 2.0, anim: "transf.generic", scale: 0.9375,
        baselineDrain: 80
    };
    var RACE_SCALE = { frostdemon: 0.7375 };

    // ---- helpers to keep the tables short -------------------------------------------
    function F(id, n, lvl, saga, m, ki, x) {
        var f = { id: id, n: n, lvl: lvl, saga: saga || "", m: m, ki: ki || 0 };
        for (var k in (x || {})) f[k] = x[k];
        return f;
    }
    var SSJ_G = { hair: "#FFEDB3", body2: "#FFEDB3", eye1: "#00FFFF", eye2: "#00FFFF" };
    var SSJ_M = { hair: "#FFE89E", body2: "#FFE89E", eye1: "#00FFFF", eye2: "#00FFFF" };
    function eyes(c) { return { eye1: c, eye2: c }; }
    // ssj5.json / ssj5daima.json: silver grey, SSJ4's model, hairType "base" with its own forcedHairCode (packed into
    // client/data/dmz_hair_presets/extra.json as DMZR_SSJ5_CODE); mastery fields at the original's FormData defaults.
    // free 0: granted by a once-per-character ritual, it can be picked in the form menu at once (the original's 50 % rule would
    // hide it until it is mastered, and it can only be mastered by laddering up from SSJ 4 first).
    function SSJ5_X(model, anim, v, req) {
        return { model: model, anim: anim, hair: "base", hairCode: "DMZR_SSJ5_CODE", ssj4: v, req: req, c: { hair: "#D5D9E0", body2: "#C8CCD4", eye1: "#E8ECF2", eye2: "#E8ECF2" },
            aura: "#DCE2EA", bolt: "#F0F4FA", stackOn: 0, unlockOn: 0, free: 0, perHit: 0.01, passive: 0.001, mStats: 1.25, mCost: 0.5, incompat: ["ultimate.ultimate"] };
    }
    // FormData.outline(primary, secondary, thickness) + colorMode / fireIntensity / bodyGlow (spec 02 section 2 "Outline")
    function OL(m, c, c2, t, fire, bg) { var o = { m: m, c: c, c2: c2, t: t, fire: fire || 0 }; if (bg) o.bg = bg; return o; }
    function mix(a, b) { var o = {}, k; for (k in a) o[k] = a[k]; for (k in b) o[k] = b[k]; return o; }

    // ---- race groups (DefaultFormsFactory) -------------------------------------------
    var GROUPS = {
        human: [
            { id: "superforms", type: "superforms", n: "Super", forms: [
                F("buffed", "Buffed", 1, "classic_saga:46", [1.7, 1.85, 1.425, 1.5], 0.109, { model: "buffedg3", scale: [1.2, 1.1, 1.2], hair: "base" }),
                F("fullpower", "Full Power", 2, "saiyan_saga:12", [2.25, 2.45, 1.9375, 2.05], 0.25, { scale: 1.0, hair: "ssj" }),
                F("overdrive", "Overdrive", 3, "frieza_saga:10", [3.15, 3.3, 2.65, 2.85], 0.618, { scale: 1.1, hair: "ssj2", aura: "#FFFD99", bolt: "#E6F2F5" }),
                F("solaris", "Solaris", 4, "buu_saga:35", [4.6, 4.75, 3.6, 4.25], 0.479, { scale: 1.0, hair: "ssj2", aura: "#FFE11A", ult: 1, smoke: 1 })
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Legendary", forms: [
                F("shiyoken", "Shiyoken", 1, "", [3.75, 3.75, 2.8625, 3.75], 0.426, { scale: 1.1, hair: "base", tint: ["#FF0000", 0.25], aura: "#A10000", bolt: "#FF4F4F", shiyoken: 1 }),
                F("shin_shiyoken", "Shin Shiyoken", 2, "", [4.8, 4.8, 3.5875, 4.8], 0.613, { model: "buffed", scale: 1.3, hair: "base", tint: ["#FF0000", 0.25], aura: "#A10000", bolt: "#FF4F4F", shiyoken: 1 }),
                F("chou_shiyoken", "Chou Shiyoken", 3, "", [5.6, 5.6, 4.0125, 5.6], 0.805, { model: "4arms", scale: 1.5, hair: "base", tint: ["#FF0000", 0.25], aura: "#A10000", bolt: "#FF4F4F", shiyoken: 1,
                    ol: OL("pulse", "#F72D2D", "#7D0202", 3.7, 0.7) })
            ]},
            { id: "androidforms", type: "androidforms", n: "Android", forms: [
                F("androidbase", "Android Base", 0, "", [2.15, 2.15, 1.8625, 2.5], 0, { scale: 1.0, hair: "base", android: 1 }),
                F("superandroid", "Super Android", 1, "frieza_saga:10", [3.2, 3.2, 2.575, 3.65], 0, { model: "buffed", scale: 1.05, hair: "ssj", android: 1 }),
                F("fusedandroid", "Fused Android", 2, "buu_saga:1", [4.1, 4.1, 3.3, 4.7], 0, { model: "buffedg3", scale: [1.4, 1.3, 1.4], hair: "ssj2", stmM: 2.5, atk: 0.85,
                    c: { hair: "#E65332", eye1: "#FFFFFF", eye2: "#FFFFFF", body1: "#4D9AE8" }, bolt: "#E63232", android: 1 })
            ]}
        ],
        saiyan: [
            { id: "oozaru", type: "superforms", n: "Oozaru", forms: [
                F("oozaru", "Oozaru", 0, "", [1.25, 1.25, 1.15, 1.25], 0.056, { spd: 0.8, stmM: 1.2, atk: 0.25, model: "oozaru", scale: 3.8, anim: "transf.ozaru", hair: "base", tailOnly: 1 }),
                F("goldenoozaru", "Golden Oozaru", 7, "buu_saga:1", [2.15, 2.15, 2.3, 2.15], 0.352, { spd: 0.85, stmM: 1.3, atk: 0.25, model: "oozaru", scale: 3.8, anim: "transf.ozaru",
                    c: { hair: "#FFD700", body2: "#FFD700" }, aura: "#FFD700", hair: "base", tailOnly: 1 }),
                F("supersaiyan4", "SSJ 4 [GT]", 8, "buu_saga:35", [4.75, 4.75, 3.5625, 4.75], 0.523, { model: "ssj4gt", anim: "transf.ozaru",
                    c: { body2: "#9d1e31", eye1: "#FFD700", eye2: "#FFD700" }, aura: "#FFD700", hair: "ssj4", ult: 1, free: 50, ssj4: "gt" }),
                // the Ragnarok original (GPL-3.0, see NOTICE.md) ritual_forms/saiyan/ssj5.json: granted by the Super Saiyan 5 wish (95_dbr_rituals.js), never
                // bought (price -1). Its file sets no multipliers or drain (FormData's x1.0 / 0, weaker than base SSJ); these
                // carry the ladder one rung on: about x1.3 over SSJ 4 (4.75 -> 6.2, defence at SSJ 4's 0.75 ratio), ki drain
                // a step above SSJ 4's 0.523, still under the legendary top's 0.615 per point of power gained
                F("supersaiyan5", "SSJ 5", 9, "", [6.2, 6.2, 4.65, 6.2], 0.6, SSJ5_X("ssj4gt", "transf.ozaru", "gt", "oozaru.supersaiyan4"))
            ]},
            { id: "ssgrades", type: "superforms", n: "Super Saiyan", forms: [
                F("supersaiyan", "SSJ", 1, "classic_saga:46", [1.6, 1.6, 1.375, 1.6], 0.101, { c: SSJ_G, aura: "#FFD700", hair: "ssj" }),
                F("supersaiyangrade2", "SSJ Grade 2", 2, "saiyan_saga:12", [1.85, 1.85, 1.575, 1.85], 0.163, { spd: 0.9, stmM: 1.3, model: "buffed", scale: 1.0, anim: "transf.ssg2", c: SSJ_G, aura: "#FFD700", hair: "ssj" }),
                F("supersaiyangrade3", "SSJ Grade 3", 3, "frieza_saga:5", [3.0, 3.0, 2.15, 3.0], 0.831, { spd: 0.7, stmM: 3.5, atk: 0.75, model: "buffedg3", scale: 1.1, c: SSJ_G, aura: "#FFD700", hair: "ssj" })
            ]},
            { id: "supersaiyan", type: "superforms", n: "Super Saiyan+", forms: [
                F("supersaiyanmastered", "SSJ Mastered", 4, "android_saga:4", [1.85, 1.85, 1.5, 1.85], 0.041, { c: SSJ_M, aura: "#FFD700", hair: "ssj" }),
                F("supersaiyan2", "SSJ 2", 5, "android_saga:15", [2.45, 2.45, 1.9375, 2.45], 0.25, { c: SSJ_M, aura: "#FFD700", hair: "ssj2", bolt: "#A1FFF9", big: 1 }),
                F("supersaiyan3", "SSJ 3", 6, "buu_saga:1", [3.3, 3.3, 2.65, 3.3], 0.618, { anim: "transf.ssj3", c: SSJ_M, aura: "#FFD700", hair: "ssj3", bolt: "#A1FFF9", big: 1 }),
                F("supersaiyan4", "SSJ 4 [D]", 8, "buu_saga:35", [4.75, 4.75, 3.5625, 4.75], 0.523, { model: "ssj4d", scale: 1.2, anim: "transf.daima",
                    c: { hair: "#83073F", body2: "#83073F", eye1: "#83073F", eye2: "#83073F" }, aura: "#FFD633", hair: "ssj4", bolt: "#82C9FF", ult: 1, ssj4: "d",
                    ol: OL("gradient", "#FFFFFF", "#FFC81F", 1.5, 0.2) }),
                // The Ragnarok original ritual_forms/saiyan/ssj5daima.json (same wish, the Daima ladder's rung 9)
                F("supersaiyan5daima", "SSJ 5 [D]", 9, "", [6.2, 6.2, 4.65, 6.2], 0.6, SSJ5_X("ssj4d", "transf.daima", "d", "supersaiyan.supersaiyan4"))
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Mutant", forms: [
                F("ikari", "Ikari", 1, "", [3.75, 3.75, 2.8625, 3.75], 0.194, { model: "buffed", scale: 1.1, anim: "transf.berserker", hair: "ssj", c: eyes("#FFD700"), aura: "#40FF00",
                    ol: OL("gradient", "#FFEB26", "#33FF40", 1.5, 0.4, 0.6) }),
                F("ssjhybrid", "SSJ Hybrid", 2, "", [4.8, 4.8, 3.5875, 4.8], 0.351, { model: "buffed", scale: 1.15, anim: "transf.berserker", hair: "ssj",
                    c: { hair: "#FFE89E", body2: "#FFE89E", eye1: "#FFFFFF", eye2: "#FFFFFF" }, aura: "#40FF00", bolt: "#40FF00" }),
                F("ssjfullpower", "SSJ Full Power", 3, "", [5.6, 5.6, 4.0125, 5.6], 0.615, { model: "buffedg3", scale: [1.4, 1.3, 1.4], anim: "transf.berserker", hair: "ssj2",
                    c: { hair: "#9EFE53", body2: "#9EFE53", eye1: "#FFFFFF", eye2: "#FFFFFF" }, aura: "#40FF00", bolt: "#40FF00" })
            ]},
            // scripted (rage bar / ritual): never chargeable, listed so the state can hold them
            { id: "falseform", type: "falseform", n: "False Form", scripted: 1, forms: [
                F("falsesupersaiyan", "False Super Saiyan", 99, "", [1.45, 1.45, 1.2875, 1.45], 0, { anim: "transf.berserker", hair: "ssj",
                    c: { hair: "#6B1208", body2: "#6B1208", eye1: "#FFFFFF", eye2: "#FFFFFF" }, aura: "#FFD84D", tint: ["#FFD21F", 0.55], stackable: 0 })
            ]},
            // God Ki (DBR's own, not the original's): unlocked once by the god ki ritual (Shenron's "Knowledge of God Ki" wish, then
            // the god ritual, 95_dbr_rituals.js / 64_dmz_kishare.js). With the God Ki toggle on (the radial menu's Ki Actions,
            // beside Friendly Fist) a full Ki Surge (charging past full ki) awakens God Ki instead of the surge. Transforming
            // into SSJ / SSJ 2 / SSJ 3 while in God Ki (or up the ladder below) stacks them on God Ki: Super Saiyan Blue,
            // Blue Evolution and Blue Rampage, each needing that Super Saiyan level fully mastered (req, unlockOn 100); at 25 %
            // mastery a Blue form can be picked in the form menu and transformed into straight away (free 25). God Ki itself
            // can't be picked (noSelect): it comes from the surge. Descending steps down Rampage -> Evolution -> Blue -> God Ki
            // -> base like any ladder (31_dmz_transform.js). Never bought (no skill level): FORM_TREES leave the group out.
            // Multipliers sit above SSJ 3 (3.3) and the god ritual's floor, up to just above SSJ 5 (6.2) at the top, which
            // needs SSJ 3 fully mastered on top of the ritual.
            { id: "godki", type: "godki", n: "God Ki", forms: [
                F("godki", "God Ki", 1, "", [3.6, 3.6, 2.85, 3.6], 0.22, { hair: "base", noSelect: 1, noReq: 1,
                    c: eyes("#FF4A5A"), aura: "#FF7A45", ol: OL("gradient", "#FFD336", "#FF3636", 2.0, 0.6, 0.5) }),
                F("supersaiyanblue", "SSJ Blue", 2, "", [4.9, 4.9, 3.7, 4.9], 0.42, { hair: "ssj", req: "ssgrades.supersaiyan", unlockOn: 100, free: 25,
                    c: { hair: "#3FC4FF", body2: "#3FC4FF", eye1: "#2B9BFF", eye2: "#2B9BFF" }, aura: "#2EB8FF",
                    ol: OL("gradient", "#BFF0FF", "#1F8FFF", 1.6, 0.35) }),
                F("supersaiyanblueevolution", "SSJ Blue Evolution", 3, "", [5.6, 5.6, 4.2, 5.6], 0.55, { hair: "ssj", req: "supersaiyan.supersaiyan2", unlockOn: 100, free: 25,
                    model: "buffed", scale: 1.05, c: { hair: "#1F6FE8", body2: "#1F6FE8", eye1: "#0D4FC4", eye2: "#0D4FC4" }, aura: "#1A5CFF", bolt: "#A8DCFF",
                    ol: OL("gradient", "#8FD0FF", "#0B3FCF", 2.2, 0.5) }),
                F("supersaiyanbluerampage", "SSJ Blue Rampage", 4, "", [6.4, 6.4, 4.8, 6.4], 0.66, { hair: "ssj2", req: "supersaiyan.supersaiyan3", unlockOn: 100, free: 25,
                    model: "buffed", scale: 1.1, c: { hair: "#5AD8FF", body2: "#5AD8FF", eye1: "#E8FBFF", eye2: "#E8FBFF" }, aura: "#00D2FF", bolt: "#E8FBFF", big: 1,
                    ol: OL("pulse", "#E8FBFF", "#00A8FF", 2.8, 0.7) })
            ]},
            // DefaultFormsFactory godRitualForms: the original's Super Saiyan God ritual form (64_dmz_kishare.js). Its multipliers are
            // the best form's raised by the ritual's power bonus (31_dmz_transform.js godRitualMult); x1.0 is only its floor.
            { id: "godritual", type: "godritual", n: "God Ritual", scripted: 1, forms: [
                F("supersaiyangodritual", "Super Saiyan God", 99, "", [1.0, 1.0, 1.0, 1.0], 0.16, { hair: "base", scale: 0.9375,
                    c: { hair: "#D61F45", body2: "#D61F45", eye1: "#E8174F", eye2: "#E8174F" }, aura: "#FF5A36",
                    maxMastery: 0, perHit: 0, passive: 0, free: 0, stackable: 0, incompat: [],
                    ol: OL("gradient", "#FFD336", "#FF3636", 2.5, 1.0, 0.6) })
            ]}
        ],
        namekian: [
            { id: "superforms", type: "superforms", n: "Super", forms: [
                F("giant", "Giant", 1, "classic_saga:46", [2.15, 2.15, 1.8625, 2.15], 0.132, { atk: 0.25, scale: 3.6, keepHead: 1 }),
                F("fullpower", "Full Power", 2, "frieza_saga:10", [3.15, 3.15, 2.5125, 3.15], 0.319, { scale: 1.0, keepHead: 1 }),
                F("supernamekian", "Super Namekian", 3, "buu_saga:35", [4.75, 4.75, 3.5625, 4.75], 0.588, { model: "namekian_buffed", scale: 1.05, aura: "#7FFF00", bolt: "#FFFFFF", keepHead: 1, ult: 1 })
            ]},
            // the Ragnarok original (GPL-3.0, see NOTICE.md) ritual_forms/namekian/primalnamekian.json: superforms rung 4, granted by the Namekian god
            // ritual at a dragon idol (95_dbr_rituals.js), never bought (price -1)
            { id: "primalnamekian", type: "superforms", n: "Primal Namekian", forms: [
                F("primalnamekian", "Primal Namekian", 4, "", [4.75, 4.75, 3.5, 4.75], 0.28, { model: "namekian_buffed", scale: 1.3, anim: "transf.berserker", hair: "base",
                    c: { body2: "#3A6B00", eye1: "#FF0000", eye2: "#FF0000" }, aura: "#4CFF00", bolt: "#4CFF00", free: 50, stackOn: 25, incompat: [],
                    perHit: 0.04, passive: 0.006, ol: OL("gradient", "#7FFF00", "#CFFF7D", 3.5, 0) })
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Legendary", forms: [
                F("evilnamek", "Evil Namek", 1, "", [3.75, 3.75, 2.8625, 3.75], 0.349, { scale: 1.0, c: { eye1: "#FFFFFF", eye2: "#FFFFFF", body1: "#386327" }, aura: "#570B0B", bolt: "#D9180F", hair: "base", keepHead: 1 }),
                F("evilgiantnamek", "Evil Giant Namek", 2, "", [4.8, 4.8, 3.5875, 4.8], 0.548, { spd: 0.75, atk: 0.25, stmM: 1.5, model: "namekian_buffed", scale: 3.8,
                    c: { eye1: "#9E092F", eye2: "#9E092F", body1: "#274D18" }, aura: "#570B0B", hair: "base", keepHead: 1 }),
                F("buffednamek", "Buffed Namek", 3, "", [5.6, 5.6, 4.0125, 5.6], 0.568, { model: "namekian_buffed", scale: 1.3,
                    c: { eye1: "#9E092F", eye2: "#9E092F", body1: "#2C6914" }, aura: "#570B0B", bolt: "#D9180F", hair: "base", keepHead: 1,
                    ol: OL("gradient", "#942323", "#4F0404", 1.5, 0.5) })
            ]}
        ],
        frostdemon: [
            { id: "evolutionforms", type: "superforms", n: "Evolution", forms: [
                F("second", "Second Form", 1, "classic_saga:46", [1.75, 1.75, 1.425, 1.75], 0, { model: "frostdemon_second", scale: 1.3, anim: "transf.freezer", keepHead: 1 }),
                F("third", "Third Form", 2, "saiyan_saga:12", [2.25, 2.25, 1.9375, 2.25], 0, { model: "frostdemon_third", scale: 1.4, anim: "transf.freezer" }),
                F("final", "Final Form", 3, "frieza_saga:10", [2.85, 2.85, 2.3625, 2.85], 0, { model: "frostdemon_final", scale: 1.0 }),
                F("fullpower", "Full Power", 4, "buu_saga:1", [3.45, 3.45, 2.725, 3.45], 0.409, { stmM: 2.5, atk: 0.75, model: "frostdemon_fp", scale: [1.3, 1.2, 1.3] }),
                F("fifth", "Fifth Form", 5, "buu_saga:35", [4.9, 4.9, 3.6875, 4.9], 0.62, { model: "frostdemon_fifth", scale: [1.4, 1.3, 1.4], c: eyes("#D91E1E"), bolt: "#F02B16", ult: 1 })
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Artificial", forms: [
                F("mecha", "Mecha", 1, "", [3.9, 3.9, 2.9375, 3.9], 0, { model: "frostdemon_mecha", bolt: "#FF6052", layers: [["frostdemon/mechaform_layer1", "fBody1"]] }),
                F("metal", "Metal", 2, "", [4.9, 4.9, 3.6625, 4.9], -0.05, { model: "frostdemon_final", scale: 1.1, c: { body1: "#B8FFF0", body2: "#CCFDFF", body3: "#B8FFF0", hair: "#B8FFF0" }, bolt: "#B5FDFF" }),
                F("metalcore", "Metal-Core", 3, "", [5.7, 5.7, 4.0875, 5.7], -0.1, { atk: 0.25, model: "frostdemon_metalcore", scale: 3.8,
                    layers: [["frostdemon/metalcore_layer1", "#9BA377"], ["frostdemon/metalcore_layer2", "#20211A"]] })
            ]}
        ],
        majin: [
            { id: "pureforms", type: "superforms", n: "Pure", forms: [
                F("kid", "Kid Majin", 1, "classic_saga:46", [1.85, 1.85, 1.575, 1.85], 0, { model: "majin_kid", scale: 0.7, keepHead: 1 }),
                F("evil", "Evil Majin", 2, "frieza_saga:5", [2.45, 2.45, 2.15, 2.45], 0, { model: "majin_evil", scale: [0.9, 1.0, 0.9],
                    c: { hair: "#917979", body1: "#917979", body2: "#917979", body3: "#917979", eye1: "#F52746", eye2: "#F52746" }, keepHead: 1 }),
                F("super", "Super Majin", 3, "buu_saga:1", [3.3, 3.3, 2.8, 3.3], 0, { model: "majin_super", scale: 1.0, keepHead: 1 }),
                F("ultra", "Ultra Majin", 4, "buu_saga:35", [4.75, 4.75, 3.725, 4.75], 0.479, { stmM: 3.5, model: "majin_ultra", scale: [1.3, 1.2, 1.3], bolt: "#F02B16", keepHead: 1, ult: 1, big: 1 })
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Demon", forms: [
                F("innocencedemon", "Innocence Demon", 1, "", [3.75, 3.75, 2.8625, 3.75], 0, { model: "janemba_imperfect", scale: 1.4, anim: "transf.janemba", hair: "empty" }),
                F("giantinnocencedemon", "Giant Innocence Demon", 2, "", [4.8, 4.8, 3.5875, 4.8], 0.548, { atk: 0.25, model: "janemba_fat", scale: 3.8, anim: "transf.janemba", hair: "empty",
                    c: { body1: "#FFFC82", body2: "#FFB8FD", eye1: "#303030", eye2: "#303030" } }),
                F("superdemon", "Super Demon", 3, "", [5.6, 5.6, 4.0125, 5.6], 0, { model: "janemba_super", scale: 1.1, anim: "transf.janemba", hair: "empty",
                    c: { body1: "#FF6161", body2: "#E1A8FF", eye1: "#FFE98A", eye2: "#303030" } })
            ]}
        ],
        bioandroid: [
            { id: "bioevolution", type: "superforms", n: "Bio Evolution", forms: [
                F("semiperfect", "Semi-Perfect", 1, "classic_saga:46", [1.85, 1.85, 1.575, 1.85], 0, { model: "bioandroid_semi", scale: 1.3, c: { eye1: "#BA1414", eye2: "#FFFFFF" } }),
                F("perfect", "Perfect", 2, "frieza_saga:5", [2.6, 2.6, 2.225, 2.6], 0, { model: "bioandroid_perfect", scale: 1.1,
                    c: { eye1: "#BA1414", eye2: "#FFFFFF", body2: "#FFFFFF", body3: "#FFED61", hair: "#7C28B0" }, aura: "#FFFF69" }),
                F("superperfect", "Super Perfect", 3, "buu_saga:1", [3.35, 3.35, 2.65, 3.35], 0.293, { model: "bioandroid_perfect", scale: 1.1,
                    c: { eye1: "#BA1414", eye2: "#FFFFFF", body2: "#FFFFFF", body3: "#FFED61", hair: "#7C28B0" }, aura: "#FFFF69", bolt: "#1AA1C7", big: 1 }),
                F("ultraperfect", "Ultra Perfect", 4, "buu_saga:35", [4.9, 4.9, 3.6875, 4.9], 0.62, { spd: 0.6, stmM: 3.5, atk: 0.55, model: "bioandroid_ultra", scale: 1.3,
                    c: { eye1: "#BA1414", eye2: "#FFFFFF", body2: "#FFFFFF", body3: "#FFED61", hair: "#7C28B0" }, aura: "#FFFF69", bolt: "#1AA1C7", ult: 1 })
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Bio-Corruption", forms: [
                F("xeno", "Xeno", 1, "", [3.9, 3.9, 2.9375, 3.9], 0.118, { model: "bioandroid_ultra", scale: 1.1,
                    c: { eye1: "#FFFFFF", eye2: "#FFFFFF", body2: "#DBC8C8", body3: "#4C3554", hair: "#4C3554" }, aura: "#2C0A4A", bolt: "#340063", xeno: 1 }),
                F("xenofp", "Xeno Full Power", 2, "", [4.9, 4.9, 3.6625, 4.9], 0.354, { model: "bioandroid_xeno", scale: 1.3,
                    c: { eye1: "#BA1414", eye2: "#BA1414", body2: "#DBC8C8", body3: "#4C3554", hair: "#4C3554" }, aura: "#2C0A4A", bolt: "#340063", xeno: 1, noStinger: 1 }),
                F("xenomax", "Xeno Max", 3, "", [5.7, 5.7, 4.0875, 5.7], 0.525, { model: "bioandroid_xenofp", scale: 3.8,
                    c: { eye1: "#BA1414", eye2: "#BA1414", body2: "#DBC8C8", body3: "#4C3554", hair: "#4C3554" }, aura: "#2C0A4A", bolt: "#340063", xeno: 1, noStinger: 1 })
            ]}
        ],
        glind: [
            { id: "superforms", type: "superforms", n: "Super", forms: [
                F("buffed", "Buffed", 1, "classic_saga:46", [1.75, 1.75, 1.425, 1.75], 0.106, { model: "buffed", scale: 1.05, keepHead: 1 }),
                F("outofcontrol", "Out of Control", 2, "saiyan_saga:12", [2.25, 2.25, 1.9375, 2.25], 0.24, { model: "buffed", scale: 1.1, anim: "transf.berserker", c: eyes("#E01414"), aura: "#E01B1B", keepHead: 1,
                    ol: OL("pulse", "#FF6161", "#A11042", 1.5, 0.3) }),
                F("super", "Super", 3, "frieza_saga:10", [2.85, 2.85, 2.3625, 2.85], 0.371, { model: "buffed", scale: [1.2, 1.1, 1.2], anim: "transf.berserker", c: eyes("#E01414"), aura: "#2F6BFF", keepHead: 1,
                    ol: OL("pulse", "#B5F6FF", "#61A9FF", 1.5, 0.3) }),
                F("absorption", "Absorption", 4, "buu_saga:1", [3.45, 3.45, 2.725, 3.45], 0.446, { model: "ssj4gt", scale: 1.1, aura: "#2F6BFF", hair: "ssj4", keepHead: 1, ssj4: "final", furHair: 1,
                    ol: OL("gradient", "#E0FDFF", "#FFFFFF", 2.5, 0.7) }),
                F("trueform", "True Form", 5, "buu_saga:35", [4.9, 4.9, 3.6875, 4.9], 0.62, { model: "glindtrueform", scale: [1.95, 2.1, 1.95], hair: "ssj3",
                    c: { hair: "#BE3C48", body1: "#247FA2", body2: "#D2D2C6", eye1: "#A61717", eye2: "#A61717" }, aura: "#7B2FBE", ult: 1 })
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Legendary", forms: [
                F("transcended", "Transcended", 1, "", [3.75, 3.75, 2.8625, 3.75], 0.426, { model: "trascended", scale: 1.4, hair: "ssj2", keepHead: 1,
                    c: { hair: "#BE3C48", body1: "#D2D2C6", body2: "#247FA2", eye1: "#FFD700", eye2: "#FFD700" }, aura: "#7B2FBE" }),
                F("darkking", "Dark King", 2, "", [4.8, 4.8, 3.5875, 4.8], 0.613, { model: "buffedg3", scale: 1.1, hair: "ssj2", keepHead: 1,
                    c: { hair: "#F2234B", body1: "#D2D2C6", body2: "#3C3A3F", eye1: "#E01414", eye2: "#E01414" }, aura: "#B00000", sclera: "#050505",
                    ol: OL("gradient", "#FF4D4D", "#BF1F1F", 1.5, 0.5) }),
                F("timepower_darkking", "Time Power: Dark King", 3, "", [5.6, 5.6, 4.0125, 5.6], 0.805, { model: "glinddark", scale: 1.1, keepHead: 1,
                    c: { hair: "#F2234B", body1: "#D2D2C6", body2: "#463E4A", body3: "#E82C3E", eye1: "#E01414", eye2: "#E01414" }, aura: "#AD0C0C", sclera: "#050505",
                    share: [["legendaryforms.timepower_realmoflight", 0.5]], ol: OL("gradient", "#262426", "#121212", 2.5, 1.5) }),
                F("timepower_realmoflight", "Time Power: Realm of Light", 3, "", [5.6, 5.6, 4.0125, 5.6], 0.805, { scale: [1.35, 1.45, 1.35], hair: "base", aura: "#FFF3C4", keepHead: 1,
                    req: "legendaryforms.darkking", share: [["legendaryforms.timepower_darkking", 0.5]], ol: OL("pulse", "#FFFFFF", "#FFF3C4", 3.5, 1.5) })
            ]}
        ]
    };

    // ---- stack forms (createDefaultStackForms: Kaioken + Ultimate) ------------------------
    function KK(id, lvl, m, sa, hd, ti, next) {
        return F(id, id, lvl, "", m, 0, { spd: sa, atk: sa, hd: hd, tint: ["#FF0000", ti], aura: "#DB182C", auraLayer: 1, stackOn: 0, stackDrain: 1.0,
            keepHead: 1, noReq: 1, share: next ? [["kaioken." + next, 0.25]] : null, ult: 1 });
    }
    var STACKS = [
        { id: "kaioken", type: "kaioken", n: "Kaioken", forms: [
            KK("x2", 1, [1.1, 1.1, 1.125, 1.1], 1.1, 0.033, 0.1, "x3"),
            KK("x3", 2, [1.2, 1.2, 1.25, 1.2], 1.2, 0.072, 0.2, "x4"),
            KK("x4", 3, [1.35, 1.35, 1.4375, 1.35], 1.35, 0.128, 0.3, "x10"),
            KK("x10", 4, [1.5, 1.5, 1.625, 1.5], 1.5, 0.165, 0.4, "x20"),
            KK("x20", 5, [1.65, 1.65, 1.8125, 1.65], 1.65, 0.248, 0.5, null)
        ]},
        { id: "ultimate", type: "ultimate", n: "Ultimate", forms: [
            F("ultimate", "Ultimate", 1, "", [2.0, 2.0, 1.1875, 2.0], 0, { maxMastery: 0, stackable: 0, aura: "#FFFFFF", hair: "ssj2", keepHead: 1, stackDrain: 1.0 })
        ]}
    ];

    // ---- post-processing: original defaults, sequential requisites, lookups -------------------
    var BY = {};          // "race|group|form" (race "stack" for stacks) -> form
    // noIndex: the form editor finishes a copy to show effective values without touching the live tables
    function finish(race, g, noIndex) {
        var superType = g.type === "superforms";
        g.forms.forEach(function (f, i) {
            f.race = race; f.group = g.id; f.type = g.type;
            f.key = g.id + ":" + f.id;
            if (f.free === undefined) f.free = i === 0 ? 0 : D.freeOn;
            if (f.incompat === undefined) f.incompat = f.ult ? ["ultimate.ultimate"] : (superType || race === "stack" ? [] : ["ultimate.ultimate"]);
            if (race === "stack" && g.id === "kaioken") f.incompat = ["ultimate.ultimate"];
            if (f.stackOn === undefined) f.stackOn = D.stackOn;
            if (f.stackDrain === undefined) f.stackDrain = D.stackDrain;
            if (f.stackable === undefined) f.stackable = 1;
            if (f.maxMastery === undefined) f.maxMastery = D.maxMastery;
            f.maxStats = f.maxMastery > 0 ? (f.mStats !== undefined ? f.mStats : D.maxStats) : 1.0;
            f.maxCost = f.mCost !== undefined ? f.mCost : D.maxCost;
            if (!f.anim) f.anim = D.anim;
            if (f.spd === undefined) f.spd = 1; if (f.atk === undefined) f.atk = 1; if (f.stmM === undefined) f.stmM = 1;
            f.sd = f.sd || 0; f.hd = f.hd || 0;
            if (f.scale === undefined) f.scale = D.scale;
            if (typeof f.scale === "number") f.scale = [f.scale, f.scale, f.scale];
            f.c = f.c || {};
            if (f.hair === undefined) f.hair = "";
            if (!f.noReq && f.req === undefined && i > 0) f.req = g.id + "." + g.forms[i - 1].id;
            f.unlockOn = f.req ? (f.unlockOn !== undefined ? f.unlockOn : D.unlockOn) : 0;
            if (!noIndex) BY[race + "|" + g.id + "|" + f.id] = f;
        });
    }
    var RACES = Object.keys(GROUPS);
    var RAW = JSON.stringify(GROUPS);       // the defaults above, before finish(): what "reset" goes back to
    STACKS.forEach(function (g) { finish("stack", g); });

    // ---- custom / edited forms (scripts/32_dbr_form_editor.js, client/scripts/70_form_editor.js) ---------
    // Ops edit forms in game. Each edited race is saved whole (its ordered group list, raw fields as in the
    // tables above) in world storage: RPG.data "dbr_forms_race_<race>", with "dbr_forms_rev" counting saves.
    // The server reads them here on every (re)load, so 30_forms.js defines their effects like any other
    // form. Clients get the same data from the server (chunked, RPG.net "dbr_fe_data") and keep the last
    // copy in RPG.storage so the menu is right from the first frame. A save applies at once (32_dbr_form_editor.js applyLive).
    var DATA_PREFIX = "dbr_forms_race_", REV_KEY = "dbr_forms_rev", CACHE_KEY = "dbr_forms_cache";
    var ID_RE = /^[a-z0-9_]{1,32}$/, HEX_RE = /^#[0-9A-Fa-f]{6}$/, TOKEN_RE = /^[a-z0-9_]{1,32}\.[a-z0-9_]{1,32}$/;
    var GROUP_TYPES = ["superforms", "legendaryforms", "godforms", "androidforms", "falseform", "godritual", "godki"];
    var HAIR_TYPES = ["", "base", "ssj", "ssj2", "ssj3", "ssj4", "empty"];
    var COLOR_KEYS = ["body1", "body2", "body3", "hair", "eye1", "eye2"];
    var LIMITS = { groups: 16, forms: 24, bytes: 200000 };
    // number fields: [min, max, integer]
    var NUM_FIELDS = { lvl: [0, 99, 1], ki: [-5, 5], sd: [-5, 5], hd: [-5, 5], spd: [0.05, 10], atk: [0.05, 10], stmM: [0, 20],
        free: [0, 1000], stackOn: [0, 1000], stackDrain: [0, 20], maxMastery: [0, 1000], unlockOn: [0, 1000], perHit: [0, 10],
        passive: [0, 10], instantOn: [0, 1000], mStats: [1, 10], mCost: [0.01, 5], plvl: [0, 100000, 1], alignMin: [0, 100, 1],
        alignMax: [0, 100, 1], cost: [-1, 1000000000, 1], auraScale: [0.1, 5] };
    var FLAG_FIELDS = ["ult", "keepHead", "tailOnly", "stackable", "android", "shiyoken", "xeno", "noStinger", "furHair", "smoke", "big", "auraLayer", "noReq", "noSelect"];
    var STR_FIELDS = { n: [40, null], desc: [200, null], model: [40, /^[a-z0-9_]*$/], anim: [40, /^[a-z0-9_.]*$/], saga: [64, /^([a-z0-9_]+:\d+)?$/],
        ssj4: [8, /^(gt|d|final)?$/], hairCode: [40, /^[A-Za-z0-9_]*$/] };

    var PNG_RE = /^[a-z0-9_.-]{1,40}:[a-z0-9_\/.-]{1,120}\.png$/, GEO_RE = /^[a-z0-9_.-]{1,40}:[a-z0-9_\/.-]{1,120}\.geo\.json$/,
        ANIM_RE = /^[a-z0-9_.-]{1,40}:[a-z0-9_\/.-]{1,120}\.json$/, BONE_RE = /^[A-Za-z0-9_.\-]{1,40}$/;
    var AURA3D_TYPES = ["userPreference", "smooth", "sparking", "god"];
    // FormConfig.Aura3DStyle fields: [min, max, integer]
    var AURA3D_NUM = { flamePeaks: [1, 64, 1], waveFrequency: [0, 20], waveSpeed: [-50, 50], waveAmplitude: [0, 5], noiseDetail: [0, 5], upwardBias: [0, 1],
        coreAlpha: [0, 1], rimAlpha: [0, 1], rimPower: [0.1, 20], rimThreshold: [0.001, 5], bloomIntensity: [0, 10], spikeDensity: [4, 32, 1],
        spikeBurstRate: [0, 50], spikeRarity: [0.1, 50], bandStart: [0.05, 0.95] };
    var AURA3D_COLORS = ["coreColor", "rimColor", "noiseColor", "secondBorderColor"];
    function cleanStyle(src) {
        var s = {}, k;
        if (!src || typeof src !== "object") return s;
        for (k in AURA3D_NUM) { if (src[k] !== undefined && src[k] !== null) { var v = clampNum(src[k], AURA3D_NUM[k]); if (v !== undefined) s[k] = v; } }
        AURA3D_COLORS.forEach(function (ck) { var h = hex(src[ck]); if (h) s[ck] = h; });
        if (isList(src.size)) s.size = [0, 1, 2].map(function (i) { var v = clampNum(src.size[i], [0.05, 5]); return v === undefined ? [1.1, 1.17, 1.02][i] : v; });
        return s;
    }
    function cleanAura3d(src, withExtra) {
        var a = {};
        if (AURA3D_TYPES.indexOf(String(src.t3)) >= 0 && src.t3 !== "userPreference") a.t3 = String(src.t3);
        var l = clampNum(src.l, [withExtra ? 0 : -1, 6, 1]); if (l !== undefined) a.l = l;
        var st = cleanStyle(src.s); if (Object.keys(st).length) a.s = st;
        if (!withExtra) { var c = hex(src.c); if (c) a.c = c; }
        if (withExtra && src.x && typeof src.x === "object") { var x = cleanAura3d(src.x, false); if (x && typeof x.l === "number" && x.l >= 0) a.x = x; }
        return Object.keys(a).length ? a : null;
    }
    function clampNum(v, spec) {
        v = Number(v);
        if (typeof v !== "number" || isNaN(v) || !isFinite(v)) return undefined;
        v = Math.max(spec[0], Math.min(spec[1], v));
        return spec[2] ? Math.round(v) : Math.round(v * 100000) / 100000;
    }
    function hex(v) { v = String(v === undefined || v === null ? "" : v); return HEX_RE.test(v) ? v.toUpperCase() : null; }
    function tokens(v) {
        var out = [];
        String(v || "").split(",").forEach(function (t) { t = t.trim(); if (TOKEN_RE.test(t) && out.indexOf(t) < 0) out.push(t); });
        return out;
    }
    function isList(v) { return v && typeof v === "object" && typeof v.length === "number"; }
    // FormCombatData: dodge chances per damage category and mitigation are 0..100 (the editor's clampPct),
    // per-stat gains are % of the BASE stat added per hit taken, maxBonusPercent caps each stat's total (default 100).
    // Stored only when something is set (FormCombatData.isEmpty), like the Ragnarok original's form_combat.json.
    var COMBAT_STATS = ["STR", "SKP", "RES", "VIT", "PWR", "ENE"];
    var COMBAT_PCT = ["dodgePhysical", "dodgeMeleeSkill", "dodgeEnergySkill", "damageMitigation"];
    function cleanCombat(src) {
        if (!src || typeof src !== "object") return null;
        var o = {}, any = false;
        COMBAT_PCT.forEach(function (k) { var v = clampNum(src[k], [0, 100]); if (v) { o[k] = v; any = true; } });
        var g = src.statGainPercent && typeof src.statGainPercent === "object" ? src.statGainPercent : {}, gains = {};
        COMBAT_STATS.forEach(function (k) { var v = clampNum(g[k], [0, 1000]); if (v) { gains[k] = v; any = true; } });
        if (!any) return null;
        if (Object.keys(gains).length) o.statGainPercent = gains;
        var cap = clampNum(src.maxBonusPercent, [0, 100000]);
        o.maxBonusPercent = cap === undefined ? 100 : cap;
        return o;
    }
    /** One raw form from storage or the editor: known fields only, every value checked and clamped. */
    function cleanForm(src, errors, where) {
        var f = {}, k;
        if (!src || typeof src !== "object") { errors.push(where + ": not a form"); return null; }
        f.id = String(src.id || "");
        if (!ID_RE.test(f.id)) { errors.push(where + ": bad form id '" + f.id + "' (a-z, 0-9, _)"); return null; }
        for (k in STR_FIELDS) {
            if (src[k] === undefined || src[k] === null) continue;
            var sv = String(src[k]).replace(/[\u0000-\u001f]/g, "").substring(0, STR_FIELDS[k][0]);
            if (STR_FIELDS[k][1] && !STR_FIELDS[k][1].test(sv)) { errors.push(where + "." + f.id + ": bad " + k + " '" + sv + "'"); continue; }
            f[k] = sv;
        }
        if (!f.n) f.n = f.id;
        if (f.saga === undefined) f.saga = "";
        for (k in NUM_FIELDS) { if (src[k] !== undefined && src[k] !== null) { var nv = clampNum(src[k], NUM_FIELDS[k]); if (nv !== undefined) f[k] = nv; } }
        if (f.lvl === undefined) f.lvl = 1;
        if (f.ki === undefined) f.ki = 0;
        FLAG_FIELDS.forEach(function (fl) { if (src[fl] !== undefined && src[fl] !== null) f[fl] = src[fl] && src[fl] !== "0" ? 1 : 0; });
        if (src.hair !== undefined && HAIR_TYPES.indexOf(String(src.hair)) >= 0) f.hair = String(src.hair);
        ["aura", "bolt", "sclera"].forEach(function (hk) { var h = hex(src[hk]); if (h) f[hk] = h; });
        var m = isList(src.m) ? src.m : [];
        f.m = [0, 1, 2, 3].map(function (i) { var v = clampNum(m[i], [0.01, 100]); return v === undefined ? 1 : v; });
        if (src.mx && typeof src.mx === "object") {
            var mx = {};
            ["STM", "VIT", "ENE"].forEach(function (s) { var v = clampNum(src.mx[s], [0.01, 100]); if (v !== undefined && v !== 1) mx[s] = v; });
            if (Object.keys(mx).length) f.mx = mx;
        }
        if (typeof src.scale === "number" || typeof src.scale === "string") { var sc = clampNum(src.scale, [0.05, 10]); if (sc !== undefined) f.scale = sc; }
        else if (isList(src.scale)) f.scale = [0, 1, 2].map(function (i) { var v = clampNum(src.scale[i], [0.05, 10]); return v === undefined ? D.scale : v; });
        if (isList(src.tint) && hex(src.tint[0])) { var ti = clampNum(src.tint[1], [0, 1]); if (ti) f.tint = [hex(src.tint[0]), ti]; }
        if (src.c && typeof src.c === "object") {
            var c = {};
            COLOR_KEYS.forEach(function (ck) { var h = hex(src.c[ck]); if (h) c[ck] = h; });
            if (Object.keys(c).length) f.c = c;
        }
        if (src.req !== undefined && src.req !== null) { var rq = tokens(src.req); if (rq.length) f.req = rq.join(","); }
        if (isList(src.incompat)) f.incompat = tokens(Array.prototype.join.call(src.incompat, ","));
        if (isList(src.share)) {
            var sh = [];
            Array.prototype.forEach.call(src.share, function (e) {
                if (!isList(e) || !TOKEN_RE.test(String(e[0])) || sh.length >= 8) return;
                var mult = clampNum(e[1], [0, 5]);
                if (mult !== undefined) sh.push([String(e[0]), mult]);
            });
            if (sh.length) f.share = sh;
        }
        if (isList(src.layers)) {
            var ly = [];
            Array.prototype.forEach.call(src.layers, function (e) {
                if (!isList(e) || ly.length >= 6) return;
                var path = String(e[0]), col = String(e[1]);
                // an original race sheet ("humansaiyan/...", under dmzpack textures/entity/races/) or any pack picture "ns:path.png"
                if ((/^[a-z0-9_\/]{1,80}$/.test(path) || PNG_RE.test(path)) && (HEX_RE.test(col) || /^f(Body[123]|Hair|Eye[12])$/.test(col))) {
                    var lyr = [path, col], bn = isList(e[2]) ? Array.prototype.filter.call(e[2], function (b) { return BONE_RE.test(String(b)); }).slice(0, 8).map(String) : [];
                    if (bn.length) lyr.push(bn);
                    ly.push(lyr);
                }
            });
            if (ly.length) f.layers = ly;
        }
        // the aura (the original FormData auraType / auraType3D / auraLayer / aura3DStyle / extra aura): 2D sheet type or a pack
        // picture, 3D type, layer, the 3D style numbers and colours, and an extra layer
        if (src.aura2d !== undefined && src.aura2d !== null && src.aura2d !== "") {
            var a2 = String(src.aura2d);
            if (/^[a-z0-9_]{1,32}$/.test(a2) || PNG_RE.test(a2)) f.aura2d = a2;
        }
        if (src.aura3d && typeof src.aura3d === "object") {
            var a3 = cleanAura3d(src.aura3d, true);
            if (a3) f.aura3d = a3;
        }
        // The Ragnarok original's per-form combat tuning (FormCombatData, form editor Dodge and Buffs tabs; 34_dbr_form_combat.js)
        var cb = cleanCombat(src.combat);
        if (cb) f.combat = cb;
        // a dropped-in GeckoLib model (geo + texture + optional animation) as the form's body or an overlay on it
        if (src.geo && typeof src.geo === "object" && GEO_RE.test(String(src.geo.model || "")) && PNG_RE.test(String(src.geo.texture || ""))) {
            var g = { model: String(src.geo.model), texture: String(src.geo.texture), mode: src.geo.mode === "overlay" ? "overlay" : "body" };
            if (ANIM_RE.test(String(src.geo.anim || ""))) g.anim = String(src.geo.anim);
            if (BONE_RE.test(String(src.geo.attach || ""))) g.attach = String(src.geo.attach);
            if (isList(src.geo.bones)) { var gb = Array.prototype.filter.call(src.geo.bones, function (b) { return BONE_RE.test(String(b)); }).slice(0, 16).map(String); if (gb.length) g.bones = gb; }
            var gs = clampNum(src.geo.scale, [0.05, 20]); if (gs !== undefined && gs !== 1) g.scale = gs;
            var gc = hex(src.geo.color); if (gc) g.color = gc;
            if (src.geo.glow) g.glow = 1;
            f.geo = g;
        }
        return f;
    }
    /** A race's ordered group list from storage or the editor -> {groups, errors}. Never throws. */
    function sanitizeRace(list) {
        var errors = [], out = [], gids = {};
        if (!isList(list)) return { groups: [], errors: ["not a group list"] };
        Array.prototype.forEach.call(list, function (src, gi) {
            if (!src || typeof src !== "object") { errors.push("group " + gi + ": not a group"); return; }
            if (out.length >= LIMITS.groups) { errors.push("more than " + LIMITS.groups + " groups"); return; }
            var id = String(src.id || "");
            if (!ID_RE.test(id) || id === "o") { errors.push("group " + gi + ": bad id '" + id + "'"); return; }
            if (gids[id]) { errors.push("duplicate group id '" + id + "'"); return; }
            var type = String(src.type || "superforms");
            if (GROUP_TYPES.indexOf(type) < 0) { errors.push(id + ": unknown type '" + type + "'"); type = "superforms"; }
            var g = { id: id, type: type, n: String(src.n || id).replace(/[\u0000-\u001f]/g, "").substring(0, 40), forms: [] };
            if (src.scripted || type === "falseform" || type === "godritual") g.scripted = 1;
            var fids = {};
            Array.prototype.forEach.call(isList(src.forms) ? src.forms : [], function (fs, fi) {
                if (g.forms.length >= LIMITS.forms) { errors.push(id + ": more than " + LIMITS.forms + " forms"); return; }
                var f = cleanForm(fs, errors, id + "[" + fi + "]");
                if (!f) return;
                if (fids[f.id]) { errors.push(id + ": duplicate form id '" + f.id + "'"); return; }
                fids[f.id] = 1;
                g.forms.push(f);
            });
            if (!g.forms.length) { errors.push(id + ": no forms (group skipped)"); return; }
            gids[id] = 1;
            out.push(g);
        });
        if (JSON.stringify(out).length > LIMITS.bytes) return { groups: [], errors: ["too big (over " + LIMITS.bytes + " bytes)"] };
        return { groups: out, errors: errors };
    }

    // DMZ_SKILLS_DATA (shared/03) holds the skill trees / TP prices built from the default forms: an edited
    // race rebuilds its entries so buying levels, saga locks and the skills screen follow the edited ladder.
    var SD0 = typeof DMZ_SKILLS_DATA !== "undefined" && DMZ_SKILLS_DATA.FORM_TREES
        ? { trees: JSON.stringify(DMZ_SKILLS_DATA.FORM_TREES), costs: JSON.stringify(DMZ_SKILLS_DATA.FORM_COSTS) } : null;
    function patchSkills(custom) {
        if (!SD0) return;
        var SDX = DMZ_SKILLS_DATA, trees = JSON.parse(SD0.trees), costs = JSON.parse(SD0.costs);
        Object.keys(trees).forEach(function (k) { SDX.FORM_TREES[k] = trees[k]; });
        Object.keys(costs).forEach(function (k) { SDX.FORM_COSTS[k] = costs[k]; });
        Object.keys(custom).forEach(function (race) {
            if (!GROUPS[race]) return;
            var live = GROUPS[race].filter(function (g) { return !g.scripted && !isScripted(g.type) && g.type !== "godki"; });
            SDX.FORM_TREES[race] = live.map(function (g) {
                return [g.id, skillFor(g.type), g.forms.map(function (f) { return [f.id, f.lvl, f.aura || "", f.saga || ""]; })];
            });
            var rc = SDX.FORM_COSTS[race] = SDX.FORM_COSTS[race] || {}, maxL = {}, set = {};
            live.forEach(function (g) {
                var s = skillFor(g.type);
                g.forms.forEach(function (f) {
                    maxL[s] = Math.max(maxL[s] || 0, f.lvl);
                    if (typeof f.cost === "number" && f.lvl > 0) (set[s] = set[s] || {})[f.lvl] = f.cost;
                });
            });
            Object.keys(maxL).forEach(function (s) {
                var list = (rc[s] || []).slice();          // never shorter: the original lists can have spare levels (Namekian 4 vs 3 forms)
                while (list.length < maxL[s]) { var last = list.length ? list[list.length - 1] : 20000; list.push(last < 0 ? -1 : Math.round(last * 1.25)); }
                Object.keys(set[s] || {}).forEach(function (l) { list[Number(l) - 1] = set[s][l]; });
                rc[s] = list;
            });
        });
    }

    var APPLIED = { rev: 0, races: {} };
    /** Rebuild every race's groups: the stored version for edited races, the defaults for the rest. */
    function applyCustom(custom, rev) {
        custom = custom && typeof custom === "object" ? custom : {};
        var defs = JSON.parse(RAW), used = {};
        Object.keys(BY).forEach(function (k) { if (k.indexOf("stack|") !== 0) delete BY[k]; });
        RACES.forEach(function (r) {
            var list = defs[r];
            if (custom[r]) {
                var san = sanitizeRace(custom[r]);
                if (san.groups.length) { list = san.groups; used[r] = custom[r]; }
            }
            // God Ki is granted by a ritual, not edited: an edited race that left it out keeps the default group
            if (custom[r] && defs[r]) defs[r].forEach(function (g) { if (g.type === "godki" && !list.some(function (x) { return x.id === g.id; })) list.push(g); });
            GROUPS[r] = list;
            list.forEach(function (g) { finish(r, g); });
        });
        patchSkills(used);
        APPLIED = { rev: Number(rev) || 0, races: used };
        return APPLIED;
    }
    function readStored() {
        var out = { rev: 0, races: {} };
        try {
            if (RPG.isClient()) {
                var c = RPG.storage.get(CACHE_KEY, null);
                if (c && typeof c === "object" && c.races) { out.rev = Number(c.rev) || 0; out.races = c.races; }
            } else {
                out.rev = Number(RPG.data.get(REV_KEY, 0)) || 0;
                RACES.forEach(function (r) { var v = RPG.data.get(DATA_PREFIX + r, null); if (v && isList(v.groups)) out.races[r] = v.groups; });
            }
        } catch (e) { /* no world (or no storage) yet: defaults */ }
        return out;
    }
    (function () { var st0 = readStored(); applyCustom(st0.races, st0.rev); })();
    /** A finished copy of one raw group (effective values for the editor); the live tables are untouched. */
    function finishedCopy(race, rawGroup) {
        var g = JSON.parse(JSON.stringify(rawGroup));
        finish(race, g, true);
        return g;
    }

    function groups(race) { return GROUPS[race] || []; }
    function group(race, id) { var out = null; groups(race).forEach(function (g) { if (g.id === id) out = g; }); return out; }
    function stackGroup(id) { var out = null; STACKS.forEach(function (g) { if (g.id === id) out = g; }); return out; }
    function form(race, g, f) { return BY[race + "|" + g + "|" + f] || null; }
    function stackForm(g, f) { return BY["stack|" + g + "|" + f] || null; }
    function index(grp, id) { for (var i = 0; i < grp.forms.length; i++) if (grp.forms[i].id === id) return i; return -1; }
    function skillFor(type) {
        var t = String(type || "").toLowerCase();
        if (t.indexOf("superform") >= 0) return "superforms";
        if (t.indexOf("legendaryform") >= 0) return "legendaryforms";
        if (t.indexOf("godform") >= 0) return "godforms";
        if (t.indexOf("androidform") >= 0) return "androidforms";
        return t;
    }
    function isScripted(type) { return type === "falseform" || type === "godritual"; }

    // ---- StatsData multipliers -------------------------------------------------------
    var STAT_INDEX = { STR: 0, SKP: 1, DEF: 2, PWR: 3 };
    function baseMult(f, stat) {
        if (!f) return 1;
        if (stat === "SPD") return f.spd;
        var i = STAT_INDEX[stat];
        if (i === undefined) return f.mx && typeof f.mx[stat] === "number" ? Math.max(0.01, f.mx[stat]) : 1;   // STM, VIT, ENE: 1.0 unless edited
        return Math.max(0.01, f.m[i]);
    }
    function clamp01(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
    /** applyMastery: b <= 1 stays; else x1.0 .. x maxStats (1.5) at full mastery. */
    function masteryMult(f, b, m) {
        if (b <= 1 || f.maxMastery <= 0) return b;
        return b * (1 + clamp01(m / f.maxMastery) * (f.maxStats - 1));
    }
    /** costFactor: x1.0 .. x0.75 at full mastery. */
    function costFactor(f, m) {
        if (!f || f.maxMastery <= 0) return 1;
        return 1 + clamp01(m / f.maxMastery) * (f.maxCost - 1);
    }
    function chargeStep(m) { return 10 + Math.min(15, Math.floor((m || 0) * 0.2)); }
    function compatible(base, stack) {
        if (!base || !stack) return true;
        if (base.incompat.indexOf(stack.group + "." + stack.id) >= 0) return false;
        if (stack.incompat.indexOf(base.group + "." + base.id) >= 0) return false;
        return true;
    }
    function scaleOf(race, f) { return f ? f.scale : [RACE_SCALE[race] || D.scale, RACE_SCALE[race] || D.scale, RACE_SCALE[race] || D.scale]; }

    // ---- colours (ColorUtils / DMZSkinLayer tint) ----------------------------------------
    function hexToRgb(h) { h = String(h || "#000000").replace("#", ""); var n = parseInt(h, 16) || 0; return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
    function rgbToHex(c) {
        function p(v) { v = Math.max(0, Math.min(255, Math.round(v))); return (v < 16 ? "0" : "") + v.toString(16); }
        return ("#" + p(c[0]) + p(c[1]) + p(c[2])).toUpperCase();
    }
    function lerpHex(a, b, t) {
        if (!a) return b; if (!b) return a;
        var x = hexToRgb(a), y = hexToRgb(b); t = clamp01(t);
        return rgbToHex([x[0] + (y[0] - x[0]) * t, x[1] + (y[1] - x[1]) * t, x[2] + (y[2] - x[2]) * t]);
    }
    /** darkTintScale: 0.15 + 0.85 * min(1, luminance / 0.35) */
    function darkTintScale(hex) {
        var c = hexToRgb(hex), lum = (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
        return 0.15 + 0.85 * Math.min(1, lum / 0.35);
    }
    function tint(hex, tintHex, intensity) {
        if (!intensity) return hex;
        return lerpHex(hex, tintHex, clamp01(intensity) * darkTintScale(hex));
    }

    return { D: D, GROUPS: GROUPS, STACKS: STACKS, RACE_SCALE: RACE_SCALE, groups: groups, group: group, stackGroup: stackGroup, form: form, stackForm: stackForm,
        index: index, skillFor: skillFor, isScripted: isScripted, baseMult: baseMult, masteryMult: masteryMult, costFactor: costFactor, chargeStep: chargeStep,
        compatible: compatible, scaleOf: scaleOf, lerpHex: lerpHex, tint: tint, darkTintScale: darkTintScale, hexToRgb: hexToRgb, rgbToHex: rgbToHex, mix: mix,
        // form editor
        RACES: RACES, rawDefaults: function () { return JSON.parse(RAW); }, sanitizeRace: sanitizeRace, applyCustom: applyCustom,
        applied: function () { return APPLIED; }, finishedCopy: finishedCopy, readStored: readStored,
        EDIT: { DATA_PREFIX: DATA_PREFIX, REV_KEY: REV_KEY, CACHE_KEY: CACHE_KEY, GROUP_TYPES: GROUP_TYPES, HAIR_TYPES: HAIR_TYPES,
            COLOR_KEYS: COLOR_KEYS, NUM_FIELDS: NUM_FIELDS, FLAG_FIELDS: FLAG_FIELDS, LIMITS: LIMITS, ID_RE: ID_RE, HEX_RE: HEX_RE,
            PNG_RE: PNG_RE, GEO_RE: GEO_RE, ANIM_RE: ANIM_RE, BONE_RE: BONE_RE, AURA3D_TYPES: AURA3D_TYPES, AURA3D_NUM: AURA3D_NUM, AURA3D_COLORS: AURA3D_COLORS } };
})();
