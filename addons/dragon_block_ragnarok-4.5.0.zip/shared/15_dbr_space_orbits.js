// =====================================================================================
//  15_dbr_space_orbits.js - where the planets are (server and client)
// =====================================================================================
//  Port of DMZ Ragnarok's Orbits + PlanetPositions (GPL-3.0): a sun at the centre of the
//  space dimension, planets on concentric rings (inner floor 6000 blocks, 15000 between
//  rings), each starting at a bearing hashed from its DMZ Ragnarok key and drifting with
//  REAL time (wall clock), Kepler-like: the inner ring turns once in two hours,
//  period ~ radius^1.5. Orbits are flat (DMZR FLAT_ORBITS). Partners share a ring on the
//  opposite side (Demon Realm rides Beerus' ring, ring 5). Both sides compute the same
//  positions from the same instant, so nothing is synced per tick.
//
//  DBR additions: distanceScale shrinks the rings (orbital periods keep DMZR's full-size
//  radii), planeY lifts the body plane into the build column (void kill is at y -128).
// =====================================================================================
var DBR_SPACE_ORBITS = (function () {
    var TWO_PI = Math.PI * 2;
    var REFERENCE_RADIUS = 6000, BASE_PERIOD = 2 * 60 * 60 * 1000;
    var MIN_PERIOD = 10 * 60 * 1000, MAX_PERIOD = 1000 * 60 * 60 * 1000;
    var RING_FLOOR = 6000, RING_SPACING = 15000;
    var SPACE = "ragnarok_rpg:space";

    // ---- 64-bit unsigned maths on {hi, lo} pairs (Java long arithmetic, low 64 bits) ----
    function u64(hi, lo) { return { hi: hi >>> 0, lo: lo >>> 0 }; }
    function limbs(a) { return [a.lo & 0xFFFF, a.lo >>> 16, a.hi & 0xFFFF, a.hi >>> 16]; }
    function mul(a, b) {
        var x = limbs(a), y = limbs(b), r = [0, 0, 0, 0];
        for (var i = 0; i < 4; i++) for (var j = 0; i + j < 4; j++) r[i + j] += x[i] * y[j];
        var carry = 0;
        for (var k = 0; k < 4; k++) { var v = r[k] + carry; r[k] = v % 65536; carry = Math.floor(v / 65536); }
        return u64(r[2] + r[3] * 65536, r[0] + r[1] * 65536);
    }
    function shr(a, n) {
        if (n >= 32) return u64(0, a.hi >>> (n - 32));
        return u64(a.hi >>> n, (a.lo >>> n) | (a.hi << (32 - n)));
    }
    function xor(a, b) { return u64(a.hi ^ b.hi, a.lo ^ b.lo); }
    var C1 = u64(0x9E3779B9, 0x7F4A7C15), C2 = u64(0xBF58476D, 0x1CE4E5B9), C3 = u64(0x94D049BB, 0x133111EB);

    function javaHash(s) {
        var h = 0;
        for (var i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
        return h;
    }
    /** PlanetPositions.hash: String.hashCode * golden ratio, then splitmix64's finaliser. */
    function hash(key) {
        var h = javaHash(key);
        var z = mul(u64(h < 0 ? 0xFFFFFFFF : 0, h), C1);
        z = mul(xor(z, shr(z, 30)), C2);
        z = mul(xor(z, shr(z, 27)), C3);
        return xor(z, shr(z, 31));
    }

    // ---- the fixed bodies: our dimension -> DMZ Ragnarok key, ring, radius (PlanetPositions tables) ----
    var BODIES = [
        { id: "overworld", dim: "minecraft:overworld", key: "minecraft:overworld", ring: 0, radius: 60 },
        { id: "namek", dim: "ragnarok_rpg:namek", key: "dragonminez:namek", ring: 1, radius: 88 },
        { id: "sacredkaiplanet", dim: "ragnarok_rpg:sacredkaiplanet", key: "dragonminez:sacredkaiplanet", ring: 2, radius: 34 },
        // ORBIT_PARTNER: dragonminez:demon_realm rides dmz_ragnarok:beerus_planet's ring (5), PI ahead of it
        { id: "demon_realm", dim: "ragnarok_rpg:demon_realm", key: "dragonminez:demon_realm", ring: 5, radius: 50, partnerOf: "dmz_ragnarok:beerus_planet" }
    ];
    var BY_ID = {}, BY_DIM = {};
    BODIES.forEach(function (b) {
        var h = hash(b.partnerOf || b.key);
        b.phase0 = (h.lo / 4294967296) * TWO_PI + (b.partnerOf ? Math.PI : 0);
        var t = hash(b.key);                                   // PlanetPositions.tint
        b.tint = ((96 + Math.floor((t.lo & 0xFF) * 160 / 255)) << 16) | ((96 + Math.floor(((t.lo >>> 8) & 0xFF) * 160 / 255)) << 8) | (96 + Math.floor(((t.lo >>> 16) & 0xFF) * 160 / 255));
        b.orbitRadius = RING_FLOOR + b.ring * RING_SPACING;
        BY_ID[b.id] = b; BY_DIM[b.dim] = b;
    });
    var SUN = { id: "sun", radius: 140, danger: 480, tint: 0xFFE7A8 };

    function periodMillis(r) {
        var t = BASE_PERIOD * Math.pow(Math.max(1, r) / REFERENCE_RADIUS, 1.5);
        return Math.max(MIN_PERIOD, Math.min(MAX_PERIOD, t));
    }
    function angle(phase0, period, epoch) {
        var revs = epoch / period;
        return phase0 + TWO_PI * (revs - Math.floor(revs));
    }

    /** Where a body is at a wall-clock instant: {x, y, z}. scale = distanceScale, planeY = the body plane. */
    function position(id, epoch, scale, planeY) {
        var b = BY_ID[id];
        if (!b) return null;
        var a = angle(b.phase0, periodMillis(b.orbitRadius), epoch), r = b.orbitRadius * (scale || 1);
        return { x: Math.cos(a) * r, y: planeY || 0, z: Math.sin(a) * r };
    }

    function hex(c) { var s = (c & 0xFFFFFF).toString(16); while (s.length < 6) s = "0" + s; return "#" + s.toUpperCase(); }

    return { SPACE: SPACE, BODIES: BODIES, SUN: SUN, byId: function (id) { return BY_ID[id] || null; },
        byDim: function (d) { return BY_DIM[d] || null; }, position: position, periodMillis: periodMillis, hash: hash, hex: hex };
})();
