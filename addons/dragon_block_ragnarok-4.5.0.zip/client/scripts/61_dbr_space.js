// =====================================================================================
//  61_dbr_space.js - space on the player's computer (port of DMZ Ragnarok's Space client)
// =====================================================================================
//  The space sky (SpaceDimensionEffects + SpaceBodyRenderer): a starfield, faint dust, the
//  sun and the planets at their live orbit positions, drawn with RPG.sky. The autopilot
//  (the pod climbs out and flies to the chosen planet), the planet info overlay
//  (PlanetInfoOverlay), the radar dial (SuRadarHud, on DMZ's radar art) and the star map
//  (SpaceStarMapScreen: drag to pan, scroll to zoom, pick a planet, Autopilot). M opens it.
// =====================================================================================
(function () {
    var O = DBR_SPACE_ORBITS, SPACE = O.SPACE, TEX = "dbr:textures/space/";
    var FONT = "dmzpack:smooth", RADAR = "dmzpack:textures/gui/radar.png";
    var S = { autopilot: "", offset: 0, origin: "", info: {} };
    var NAMES = { overworld: "Earth", namek: "Namek", sacredkaiplanet: "Sacred Kai", demon_realm: "Demon Realm", sun: "Sun" };

    function cfg(k, fb) { var v = RPG.config.get("dbr_space", k, fb); return v === null || v === undefined ? fb : Number(v); }
    function now() { return Date.now() + S.offset; }
    function pos(id) { return O.position(id, now(), cfg("distanceScale", 0.25), cfg("planeY", 100)); }
    function sun() { return { x: 0, y: cfg("planeY", 100), z: 0 }; }
    function me() { return { x: RPG.player.x, y: RPG.player.y, z: RPG.player.z }; }
    function dist(a, b) { var dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z; return Math.sqrt(dx * dx + dy * dy + dz * dz); }
    function fmt(d) { return d >= 10000 ? (d / 1000).toFixed(1) + "k" : String(Math.round(d)); }

    // ---- the sky (DMZR SpaceDimensionEffects: 4500 stars, seed 0x5C4EE7; bodies from SpaceBodyRenderer) ----
    var BOX = { size: 64, north: [8, 8, 16, 16], south: [24, 8, 32, 16], west: [0, 8, 8, 16], east: [16, 8, 24, 16], down: [16, 0, 24, 8], up: [8, 0, 16, 8] };
    var SUN_UV = { north: [8, 8, 16, 16], south: [8, 8, 16, 16], east: [0, 8, 8, 16], west: [0, 8, 8, 16], up: [0, 0, 8, 8], down: [8, 0, 16, 8] };
    var VENUS_UV = { north: [2, 5, 5, 8], east: [5, 5, 8, 8], south: [2, 5, 5, 8], west: [5, 5, 8, 8], up: [5, 2, 8, 5], down: [2, 2, 5, 5] };
    var MARS_UV = { north: [5.25, 5.25, 8, 8], east: [2.5, 5.25, 5.25, 8], south: [5.25, 5.25, 8, 8], west: [2.5, 5.25, 5.25, 8], up: [5.25, 2.5, 8, 5.25], down: [8, 2.5, 10.75, 5.25] };
    var LOOK = {
        overworld: { texture: TEX + "earf.png", uv: BOX, color: "#FFFFFF" },
        namek: { texture: TEX + "namek.png", uv: BOX, color: "#FFFFFF" },
        sacredkaiplanet: { texture: TEX + "venus_grayscale.png", uv: VENUS_UV, color: "#42B43C" },        // DMZR FIXED_BODY_TINT
        demon_realm: { texture: TEX + "mars_grayscale.png", uv: MARS_UV, color: null }                     // DMZR hash tint
    };
    function defineSky() {
        var s = sun(), bodies = [{ id: "sun", texture: TEX + "sun.png", shape: "cube", uv: SUN_UV, frames: 2, frameTime: 20, x: s.x, y: s.y, z: s.z,
            radius: O.SUN.radius, shading: "flat", spin: 2, minSize: 1.2, glow: { color: "#FFE7A8", size: O.SUN.radius * 5, alpha: 0.45 } }];
        O.BODIES.forEach(function (b) {
            var l = LOOK[b.id], p = pos(b.id);
            bodies.push({ id: b.id, texture: l.texture, shape: "cube", uv: l.uv, color: l.color || O.hex(b.tint), x: p.x, y: p.y, z: p.z,
                radius: b.radius, shading: "lit", lightAt: [s.x, s.y, s.z], ambient: 0.16, spin: 1.5, tilt: 12, minSize: 0.5 });
        });
        RPG.sky.define(SPACE, {
            color: "#010208", sun: false, moon: false, clouds: false,
            stars: { count: 4500, seed: 6049511, brightness: 1, size: 1 },
            nebula: [
                { texture: TEX + "cloud_texture.png", dir: [0.8, 0.25, 0.3], size: 80, alpha: 0.18, color: "#6A3FA8" },
                { texture: TEX + "cloud_texture.png", dir: [-0.6, -0.1, 0.7], size: 95, alpha: 0.14, color: "#2F5FA8", roll: 40 },
                { texture: TEX + "cloud_texture.png", dir: [-0.2, 0.6, -0.8], size: 70, alpha: 0.12, color: "#A84A6A", roll: 110 },
                { texture: TEX + "star_halo.png", dir: [0.3, -0.5, -0.8], size: 30, alpha: 0.25, color: "#9FB8FF" }
            ],
            bodies: bodies
        });
    }
    defineSky();
    function moveBodies() {
        var u = {};
        O.BODIES.forEach(function (b) { var p = pos(b.id); u[b.id] = { x: p.x, y: p.y, z: p.z }; });
        var s = sun();
        u.sun = { x: s.x, y: s.y, z: s.z };
        RPG.sky.updateAll(SPACE, u);
    }

    RPG.net.on("dbr_space_state", function (d) {
        if (!d) return;
        S.autopilot = String(d.autopilot || "");
        S.origin = String(d.origin || "");
        if (d.epoch) S.offset = Number(d.epoch) - Date.now();
        if (!S.autopilot && RPG.player.vehicleSteered) RPG.player.stopVehicleSteer();
        defineSky();
    });
    RPG.on("load", function () { RPG.net.send("dbr_space_hello", {}); });
    RPG.net.on("dbr_space_info", function (d) { if (d && d.id) S.info[d.id] = d; });

    // ---- autopilot: climb straight up out of the planet, then cruise to the body (DMZR driveAutopilot) ----
    function waypoint(from, to) {
        // go round the sun instead of through it
        var s = sun(), danger = O.SUN.danger + 150;
        var dx = to.x - from.x, dz = to.z - from.z, len2 = dx * dx + dz * dz;
        if (len2 < 1) return to;
        var t = Math.max(0, Math.min(1, ((s.x - from.x) * dx + (s.z - from.z) * dz) / len2));
        var cx = from.x + dx * t - s.x, cz = from.z + dz * t - s.z, c = Math.sqrt(cx * cx + cz * cz);
        if (c >= danger) return to;
        if (c < 1) { cx = -dz; cz = dx; c = Math.sqrt(cx * cx + cz * cz); }
        return { x: s.x + cx / c * (danger + 200), y: to.y, z: s.z + cz / c * (danger + 200) };
    }
    function steer() {
        if (!S.autopilot || RPG.player.vehicleId !== "spacepod") {
            if (RPG.player.vehicleSteered) RPG.player.stopVehicleSteer();
            return;
        }
        var p = me();
        if (RPG.player.dimension !== SPACE) {
            if (!O.byDim(RPG.player.dimension)) return;
            RPG.player.steerVehicle(p.x, cfg("entryAltitude", 1000) + 16, p.z, cfg("ascentSpeed", 4));
            return;
        }
        var t = pos(S.autopilot);
        if (!t) return;
        var w = waypoint(p, t);
        RPG.player.steerVehicle(w.x, w.y, w.z, cfg("cruiseSpeed", 9));
    }

    // zero-g on foot: push off along your look (W/S, A/D, Space up, Shift down); ki flight and pods move as usual
    function drift() {
        if (RPG.player.riding || RPG.player.flying || RPG.player.hasEffect("flight") || RPG.screen.getOpen()) return;
        var k = function (n) { return RPG.isKeyDown("key.keyboard." + n) ? 1 : 0; };
        var f = k("w") - k("s"), st = k("d") - k("a"), up = k("space") - k("left.shift");
        if (!f && !st && !up) return;
        var l = RPG.player.look, yaw = RPG.player.yaw * Math.PI / 180, a = 0.035;
        var vx = RPG.player.vx + (l.x * f - Math.cos(yaw) * st * 0.7) * a, vy = RPG.player.vy + (l.y * f + up) * a, vz = RPG.player.vz + (l.z * f - Math.sin(yaw) * st * 0.7) * a;
        var len = Math.sqrt(vx * vx + vy * vy + vz * vz), max = 1.2;
        if (len > max) { vx *= max / len; vy *= max / len; vz *= max / len; }
        RPG.player.setVelocity(vx, vy, vz);
    }

    var tick = 0;
    RPG.on("tick", function () {
        tick++;
        var inSpace = RPG.player.dimension === SPACE;
        if (inSpace) { moveBodies(); drift(); }
        steer();
        if (inSpace && tick % 40 === 0 && target) RPG.net.send("dbr_space_info", { id: target });
    });

    // ---- HUD: planet labels + info overlay (PlanetInfoOverlay) and the radar dial (SuRadarHud) ----
    var target = null;
    RPG.hud.onRender(function (ctx) {
        if (RPG.player.dimension !== SPACE || RPG.screen.getOpen()) return;
        var p = me(), cx = ctx.width / 2, cy = ctx.height / 2, best = null, bestD = 1e9;
        var all = O.BODIES.map(function (b) { return { id: b.id, radius: b.radius, pos: pos(b.id) }; });
        all.push({ id: "sun", radius: O.SUN.radius, pos: sun() });
        all.forEach(function (b) {
            var sp = RPG.project(b.pos.x, b.pos.y, b.pos.z);
            if (!sp.visible) return;
            var d = dist(p, b.pos), sd = Math.abs(sp.x - cx) + Math.abs(sp.y - cy);
            var col = b.id === S.autopilot ? "#40FF80" : b.id === "sun" ? "#FFD27F" : "#20E0FF";
            ctx.textStyled(NAMES[b.id] + " §7" + fmt(Math.max(0, d - b.radius)), sp.x, sp.y + 8, 0.8, col, 0.85, 0.5, FONT, "#000000");
            if (b.id !== "sun" && sd < bestD && sd < 80) { best = b; bestD = sd; }
        });
        target = best ? best.id : null;
        if (best) {
            // DMZR PlanetInfoOverlay: a small panel for the body under the crosshair
            var i = S.info[best.id] || {}, x = cx + 14, y = cy - 30, w = 120, d = dist(p, best.pos) - best.radius;
            ctx.fill(x, y, w, 52, "#100010", 0.8);
            ctx.fill(x, y, w, 1, "#5000FF", 0.8);
            ctx.textStyled("§l" + NAMES[best.id], x + 5, y + 5, 1, "#FFD700", 1, 0, FONT, "#000000");
            ctx.textStyled("Distance: " + fmt(d), x + 5, y + 17, 0.8, "#FFFFFF", 1, 0, FONT, null);
            ctx.textStyled("Fighters: " + (i.count === undefined ? "?" : i.count), x + 5, y + 27, 0.8, "#FFFFFF", 1, 0, FONT, null);
            ctx.textStyled(i.visited ? "Visited" : "Unexplored", x + 5, y + 37, 0.8, i.visited ? "#80FF80" : "#A0A0A0", 1, 0, FONT, null);
        }
        drawRadar(ctx, p, all);
        if (S.autopilot) {
            var t = pos(S.autopilot), dd = t ? dist(p, t) : 0, eta = Math.round(dd / Math.max(1, cfg("cruiseSpeed", 9)) / 20);
            ctx.textStyled("Autopilot: " + NAMES[S.autopilot] + " §7" + fmt(dd) + " (" + eta + "s)", cx, ctx.height - 62, 1, "#40FF80", 1, 0.5, FONT, "#000000");
        }
    });
    function drawRadar(ctx, p, all) {
        if (!ctx.group("dbr_space_radar", "Space radar", ctx.width - 70, Math.floor(ctx.height / 2) - 40, 66, 80)) return;
        var x = ctx.width - 70, y = 4, sc = 66 / 121;
        ctx.image(RADAR, x, y, 66, 80, 0, 0, 121, 146, 256, 256);
        var ccx = x + 61 * sc, ccy = y + 87 * sc, reach = 50 * sc;
        var range = 1000 + 21000 * cfg("distanceScale", 0.25), yaw = RPG.player.yaw * Math.PI / 180, nearest = 1e12;
        all.forEach(function (b) {
            var dx = b.pos.x - p.x, dz = b.pos.z - p.z, d = Math.sqrt(dx * dx + dz * dz);
            nearest = Math.min(nearest, Math.max(0, dist(p, b.pos) - b.radius));
            // turn so straight ahead is up (DMZ radar dials are heading-up)
            var rx = dx * Math.cos(yaw) + dz * Math.sin(yaw), rz = -dx * Math.sin(yaw) + dz * Math.cos(yaw);
            var k = Math.min(1, Math.sqrt(d / range)) * reach / Math.max(1, d);
            var bx = ccx - rx * k, by = ccy - rz * k;
            var col = b.id === "sun" ? "#FFCD53" : b.id === S.autopilot ? "#40FF80" : "#FBFF4B";
            ctx.fill(bx - 2, by - 2, 4, 4, "#000000", 1);
            ctx.fill(bx - 1.5, by - 1.5, 3, 3, col, 1);
        });
        ctx.textStyled(fmt(nearest), x + 33, y + 72, 0.7, "#FFD54A", 1, 0.5, FONT, "#000000");
        ctx.endGroup();
    }

    // ---- the star map (SpaceStarMapScreen) ----
    try { RPG.keys.register("dbr_star_map", { name: "Star Map", key: "m" }); } catch (e) { }
    RPG.on("keybind", function (id, down) {
        if (id === "dbr_star_map" && down && !RPG.screen.getOpen()) openMap();
    });

    var M = null;
    function openMap() {
        var far = 0;
        O.BODIES.forEach(function (b) { far = Math.max(far, b.orbitRadius * cfg("distanceScale", 0.25)); });
        M = { cx: 0, cz: 0, zoom: 150 / Math.max(1, far), sel: S.autopilot || null, drag: null, moved: 0 };
        O.BODIES.forEach(function (b) { RPG.net.send("dbr_space_info", { id: b.id }); });
        RPG.sound("dmzpack:ui_menu_switch", 1, 1);
        RPG.screen.open({ id: "dbr_star_map", referenceHeight: 300, background: "#000008", elements: [], onRender: drawMap,
            onMouse: mapMouse, onScroll: function (x, y, delta) {
                if (!M) return;
                var f = delta > 0 ? 1.25 : 0.8, w = toWorld(x, y);
                M.zoom = Math.max(0.0005, Math.min(4, M.zoom * f));
                var w2 = toWorld(x, y);
                M.cx += w.x - w2.x; M.cz += w.z - w2.z;
            }, onClose: function () { M = null; } });
    }
    var VIEW = { x: 0, y: 0, w: 0, h: 0 };
    function toScreen(x, z) { return { x: VIEW.x + VIEW.w / 2 + (x - M.cx) * M.zoom, y: VIEW.y + VIEW.h / 2 + (z - M.cz) * M.zoom }; }
    function toWorld(sx, sy) { return { x: M.cx + (sx - VIEW.x - VIEW.w / 2) / M.zoom, z: M.cz + (sy - VIEW.y - VIEW.h / 2) / M.zoom }; }
    var BUTTONS = [];
    function mapMouse(x, y, button, action) {
        if (!M) return;
        if (action === "down") {
            for (var i = 0; i < BUTTONS.length; i++) {
                var b = BUTTONS[i];
                if (x >= b.x && y >= b.y && x < b.x + 74 && y < b.y + 20) { b.fn(); return false; }
            }
            M.drag = { x: x, y: y, cx: M.cx, cz: M.cz }; M.moved = 0;
        } else if (action === "drag" && M.drag) {
            M.cx = M.drag.cx - (x - M.drag.x) / M.zoom; M.cz = M.drag.cz - (y - M.drag.y) / M.zoom;
            M.moved += 1;
        } else if (action === "up" && M.drag) {
            if (M.moved < 3) {
                var pick = null, pd = 12;
                O.BODIES.forEach(function (b) { var p = pos(b.id), s = toScreen(p.x, p.z), d = Math.abs(s.x - x) + Math.abs(s.y - y); if (d < pd) { pd = d; pick = b.id; } });
                if (pick) { M.sel = pick; RPG.sound("dmzpack:pip_menu", 1, 1); RPG.net.send("dbr_space_info", { id: pick }); }
            }
            M.drag = null;
        }
    }
    function drawMap(ctx) {
        if (!M) return;
        var pad = 12;
        VIEW = { x: pad, y: pad, w: ctx.width - pad * 2 - 130, h: ctx.height - pad * 2 };
        if (typeof DMZ_UI !== "undefined") DMZ_UI.QUEST_PANEL.draw(ctx, 4, 4, ctx.width - 8, ctx.height - 8, 1);
        ctx.fill(VIEW.x, VIEW.y, VIEW.w, VIEW.h, "#000006", 0.92);
        ctx.clip(VIEW.x, VIEW.y, VIEW.w, VIEW.h);
        // background stars (fixed to the screen, like DMZR's parallax-free map backdrop)
        for (var i = 0; i < 140; i++) {
            var hx = (Math.sin(i * 12.9898) * 43758.5453) % 1, hy = (Math.sin(i * 78.233) * 12543.123) % 1;
            ctx.fill(VIEW.x + Math.abs(hx) * VIEW.w, VIEW.y + Math.abs(hy) * VIEW.h, 1, 1, "#FFFFFF", 0.25 + (i % 5) * 0.12);
        }
        var c0 = toScreen(0, 0);
        O.BODIES.forEach(function (b) {
            var r = b.orbitRadius * cfg("distanceScale", 0.25) * M.zoom;
            if (r > 2) ctx.arc(c0.x, c0.y, r - 0.5, r + 0.5, 0, 360, "#3A4A80", 0.6);
        });
        ctx.arc(c0.x, c0.y, 0, Math.max(3, O.SUN.danger * M.zoom), 0, 360, "#FF6020", 0.15);
        ctx.arc(c0.x, c0.y, 0, Math.max(3, O.SUN.radius * M.zoom), 0, 360, "#FFE7A8", 1);
        O.BODIES.forEach(function (b) {
            var p = pos(b.id), s = toScreen(p.x, p.z), r = Math.max(4, b.radius * M.zoom), l = LOOK[b.id];
            var face = l.uv.north, sz = l.uv.size || 16;
            if (M.sel === b.id) ctx.arc(s.x, s.y, r + 2, r + 3.5, 0, 360, "#FFD700", 1);
            if (S.autopilot === b.id) ctx.arc(s.x, s.y, r + 4, r + 5, 0, 360, "#40FF80", 1);
            ctx.quad(l.texture, s.x - r, s.y - r, r * 2, r * 2, face[0] / sz, face[1] / sz, face[2] / sz, face[3] / sz, l.color || O.hex(b.tint), 1);
            ctx.textStyled(NAMES[b.id], s.x, s.y + r + 4, 0.8, RPG.player.dimension === b.dim ? "#80FF80" : "#20E0FF", 1, 0.5, FONT, "#000000");
        });
        if (RPG.player.dimension === SPACE) {
            var ps = toScreen(RPG.player.x, RPG.player.z), yaw = RPG.player.yaw * Math.PI / 180;
            var fx = -Math.sin(yaw), fz = Math.cos(yaw);
            ctx.poly([ps.x + fx * 6, ps.y + fz * 6, ps.x - fz * 3.5 - fx * 3, ps.y + fx * 3.5 - fz * 3, ps.x + fz * 3.5 - fx * 3, ps.y - fx * 3.5 - fz * 3], "#FFFFFF", 1);
            if (S.autopilot) { var t = pos(S.autopilot), ts = toScreen(t.x, t.z); line(ctx, ps.x, ps.y, ts.x, ts.y, "#40FF80"); }
        }
        ctx.unclip();
        // side panel
        var px = ctx.width - pad - 124, py = pad + 4;
        BUTTONS = [];
        ctx.textStyled("§lStar Map", px + 60, py, 1.2, "#FFD700", 1, 0.5, FONT, "#000000");
        py += 18;
        if (M.sel) {
            var b = O.byId(M.sel), info = S.info[M.sel] || {}, bp = pos(M.sel);
            var period = O.periodMillis(b.orbitRadius) / 60000;
            ctx.textStyled("§l" + NAMES[M.sel], px + 4, py, 1, "#20E0FF", 1, 0, FONT, "#000000"); py += 14;
            [["Orbit", fmt(b.orbitRadius * cfg("distanceScale", 0.25)) + " blocks"], ["Year", Math.round(period) + " min"], ["Size", Math.round(b.radius * 2) + " blocks"],
             ["Distance", RPG.player.dimension === SPACE ? fmt(Math.max(0, dist(me(), bp) - b.radius)) : "-"],
             ["Fighters", info.count === undefined ? "?" : String(info.count)], ["", info.loaded === false ? "§cNot loaded" : info.visited ? "§aVisited" : "§7Unexplored"]
            ].forEach(function (r) { ctx.textStyled((r[0] ? "§7" + r[0] + ": §f" : "") + r[1], px + 4, py, 0.85, "#FFFFFF", 1, 0, FONT, null); py += 11; });
            if (info.players && info.players.length) { ctx.textStyled("§7" + info.players.join(", "), px + 4, py, 0.7, "#FFFFFF", 1, 0, FONT, null); py += 10; }
            py += 6;
            var riding = RPG.player.vehicleId === "spacepod";
            var can = riding && RPG.player.dimension !== b.dim && S.autopilot !== M.sel;
            if (typeof DMZ_UI !== "undefined") DMZ_UI.button(ctx, "Autopilot", px + 24, py, can);
            if (can) BUTTONS.push({ x: px + 24, y: py, fn: function () { RPG.net.send("dbr_space_autopilot", { id: M.sel }); RPG.sound("dmzpack:ui_nave_takeoff", 1, 1); RPG.screen.close(); } });
            py += 24;
            if (!riding) { ctx.textStyled("§7Ride a space pod to use the autopilot.", px + 4, py, 0.7, "#FFFFFF", 1, 0, FONT, null); py += 12; }
        } else {
            ctx.textStyled("§7Click a planet.", px + 4, py, 0.85, "#FFFFFF", 1, 0, FONT, null); py += 14;
        }
        if (S.autopilot) {
            ctx.textStyled("§aAutopilot: " + NAMES[S.autopilot], px + 4, py, 0.85, "#FFFFFF", 1, 0, FONT, null); py += 12;
            if (typeof DMZ_UI !== "undefined") DMZ_UI.button(ctx, "Stop", px + 24, py, true);
            BUTTONS.push({ x: px + 24, y: py, fn: function () { RPG.net.send("dbr_space_autopilot", { id: "" }); } });
        }
        ctx.textStyled("§7Drag: move   Scroll: zoom", px + 4, ctx.height - pad - 12, 0.7, "#FFFFFF", 1, 0, FONT, null);
    }
    function line(ctx, x0, y0, x1, y1, col) {
        var dx = x1 - x0, dy = y1 - y0, len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1) return;
        var nx = -dy / len * 0.6, ny = dx / len * 0.6;
        ctx.poly([x0 + nx, y0 + ny, x1 + nx, y1 + ny, x1 - nx, y1 - ny, x0 - nx, y0 - ny], col, 0.7);
    }
})();
