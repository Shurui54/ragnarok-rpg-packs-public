// =====================================================================================
//  DMZ character creation: RaceSelectionScreen and CharacterCustomizationScreen,
//  rebuilt from DragonMine Z's layouts (UI units: DMZ scales the screen so it is 360
//  units high, the same as referenceHeight 360 here). DMZ's own text comes from its
//  language file in the art pack (RPG.translate).
// =====================================================================================
var CREATOR = (function () {
    var D = DMZ_DATA;
    var FONT = "dmzpack:smooth";
    var BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png";
    var RACIAL = RPG.files.read("racial_parts.json") || { races: D.RACES, parts: {}, race_info: {} };
    var T = function (k) { return RPG.translate(k); };

    // what the player has picked so far (DMZ race ids)
    var st = { race: 0, cls: "warrior", colors: {}, looks: {}, tab: 0, carousel: 0, yaw: 180, pitch: 12, racialScroll: 0,
        picker: null, hsv: [0, 100, 100], lastFrame: 0, mode: "race", hairPage: -1 };

    function races() { return RACIAL.races && RACIAL.races.length ? RACIAL.races : D.RACES; }
    function raceId(i) { var r = races(); return r[((i % r.length) + r.length) % r.length]; }
    function ourRace(dmz) { return D.OUR[dmz] || dmz; }
    function lookKey(dmz) { return "race:" + ourRace(dmz); }

    // ---- helpers ---------------------------------------------------------------------
    function wrap(ctx, text, width) {
        var out = [], words = String(text).split(" "), line = "";
        words.forEach(function (w) {
            var t = line ? line + " " + w : w;
            if (ctx.textWidthIn(t, FONT) > width && line) { out.push(line); line = w; } else line = t;
        });
        if (line) out.push(line);
        return out;
    }
    function bordered(ctx, text, x, y, color, align, scale) {
        ctx.textStyled(text, x, y, scale || 1, color, 1, align === undefined ? 0.5 : align, FONT, "#000000");
    }
    function textButton(id, x, y, label, onClick, anchor) {
        return { id: id, type: "button", anchor: anchor || "topleft", x: x, y: y, w: 74, h: 20, texture: BUTTONS, texW: 256, texH: 256,
            u: 0, v: 28, uw: 74, vh: 20, hoverU: 0, hoverV: 48, label: label, font: FONT, textColor: "#FFFFFF", hoverTextColor: "#7CFDD6", onClick: onClick };
    }
    function arrow(id, x, y, right, onClick, anchor) {
        return { id: id, type: "button", anchor: anchor || "center", x: x, y: y, w: 8, h: 14, texture: BUTTONS, texW: 256, texH: 256,
            u: right ? 20 : 32, v: 0, uw: 8, vh: 14, hoverU: right ? 20 : 32, hoverV: 14, onClick: onClick };
    }
    function sound(id) { RPG.sound("dmzpack:" + id, 1, 1); }

    // ---- race selection ----------------------------------------------------------------
    function openRace() {
        st.mode = "race";
        var r = raceId(st.race);
        var els = [];
        // five carousel models, positioned every frame
        for (var i = -2; i <= 2; i++) els.push({ id: "m" + (i + 2), type: "entity", anchor: "center", x: -40, y: -30, w: 80, h: 100, rotation: 180, followMouse: false, size: 75 });
        els.push(arrow("left", -85, 88, false, function () { change(-1); }));
        els.push(arrow("right", 78, 88, true, function () { change(1); }));
        els.push(textButton("select", -85, -25, T("gui.dragonminez.customization.select"), function () { sound("pip_menu"); openCustomize(); }, "bottomright"));
        RPG.screen.open({ id: "dmz_race", referenceHeight: 360, closeOnEsc: false, background: { panorama: panorama(r) }, elements: els,
            onRender: renderRace, onKey: function (k) {
                if (k === "key.keyboard.left") change(-1);
                else if (k === "key.keyboard.right") change(1);
            }, onScroll: function (x, y, d) { st.racialScroll = Math.max(0, st.racialScroll - (d > 0 ? 24 : -24)); } });
    }

    function panorama(dmz) {
        var has = { human: 1, saiyan: 1, namekian: 1, frostdemon: 1, bioandroid: 1, majin: 1 };
        return "dmzpack:textures/gui/background/" + (has[dmz] ? dmz + "_panorama" : "roshi");
    }

    function change(dir) {
        st.race += dir;
        st.carousel = dir;               // slide from the side, then settle (exp decay 0.13 s)
        st.racialScroll = 0;
        st.looks = {}; st.colors = {}; st.hairPage = -1;
        sound("ui_nave_cooldown");
        RPG.screen.background({ panorama: panorama(raceId(st.race)) });
    }

    function renderRace(ctx) {
        var now = RPG.nowMs() / 1000, dt = st.lastFrame ? Math.min(0.1, now - st.lastFrame) : 0;
        st.lastFrame = now;
        if (Math.abs(st.carousel) > 0.001) st.carousel *= Math.exp(-dt / 0.13); else st.carousel = 0;
        var W = ctx.width, H = ctx.height, cx = W / 2, cy = H / 2;
        cinematicBars(ctx);
        // carousel: models and name plates, far ones first
        var order = [-2, -1, 0, 1, 2].sort(function (a, b) { return Math.abs(b + st.carousel) - Math.abs(a + st.carousel); });
        order.forEach(function (i) {
            var pos = i + st.carousel, abs = Math.abs(pos), id = "m" + (i + 2);
            var scale = Math.max(0.5, 1 - abs * 0.35), alpha = Math.max(0, 1 - abs * 0.6);
            if (abs > 1.5 || alpha <= 0.05) { RPG.screen.update(id, { visible: false }); return; }
            var race = raceId(st.race + i), xo = pos * 130;
            RPG.screen.update(id, { visible: true, x: 5 + xo - 40, y: 70 - 100, size: Math.round(75 * scale), brightness: alpha,
                rotation: i === 0 ? st.yaw : 180, look: { key: lookKey(race), colors: i === 0 ? st.colors : {} } });
            ctx.push();
            ctx.translate(cx + xo, cy + 92);
            ctx.scale(scale, scale);
            ctx.quad(MENU_BIG, -74, -7, 149, 21, 0 / 256, 215 / 256, 149 / 256, 236 / 256, "#FFFFFF", alpha);
            ctx.textStyled(info(race).name, 0, 0, 1, "#7CFDD6", alpha, 0.5, FONT, "#000000");
            ctx.pop();
        });
        // left: race name and description
        var r = raceId(st.race), inf = info(r), startY = cy - 50;
        bordered(ctx, "§l" + inf.name.replace(/(§[0-9a-fr])/gi, "$1§l"), 75, startY - 12, "#7CFDD6");
        var y = startY;
        wrap(ctx, D.strip(inf.desc), 130).forEach(function (line) { bordered(ctx, line, 75, y, "#CCCCCC"); y += 12; });
        // right: racial skills (scrollable)
        var right = W - 8, left = right - 130, title = T("gui.dragonminez.race_selection.racial_skills");
        bordered(ctx, "§l" + title, left + 65, startY - 12, "#55FF55");
        var lines = [];
        (RACIAL.parts[r] || []).forEach(function (p) {
            var para = wrap(ctx, "§6" + D.strip(p.name) + "§r: " + p.desc, 130);
            lines = lines.concat(para);
        });
        var view = Math.max(24, Math.min(13 * 12, H - 30 - startY)), maxScroll = Math.max(0, lines.length * 12 - view);
        st.racialScroll = Math.min(st.racialScroll, maxScroll);
        var first = Math.floor(st.racialScroll / 12);
        for (var li = first; li < lines.length && (li - first) * 12 < view; li++)
            ctx.textStyled(lines[li], left, startY + (li - first) * 12, 1, "#CCCCCC", 1, 0, FONT, null);
        if (maxScroll > 0) {
            var barH = Math.max(10, view * view / (lines.length * 12));
            ctx.fill(right + 2, startY, 2, view, "#000000", 0.4);
            ctx.fill(right + 2, startY + (view - barH) * (st.racialScroll / maxScroll), 2, barH, "#FFFFFF", 0.8);
        }
    }

    function info(dmz) {
        var i = (RACIAL.race_info || {})[dmz];
        return i || { name: T("race.dragonminez." + dmz), desc: T("race.dragonminez." + dmz + ".desc") };
    }

    function cinematicBars(ctx) {
        var W = ctx.width, H = ctx.height, total = H * 0.12, fade = 60 * (H / 360) / (H / 360);   // 60 units
        fade = Math.min(fade, total - 1);
        var solid = total - fade;
        ctx.fill(0, 0, W, solid, "#000000", 1);
        ctx.quadCorners("minecraft:textures/misc/white.png", 0, solid, W, fade, 0, 0, 1, 1, "#000000", 1, 1, 0, 0);
        ctx.quadCorners("minecraft:textures/misc/white.png", 0, H - total, W, fade, 0, 0, 1, 1, "#000000", 0, 0, 1, 1);
        ctx.fill(0, H - total + fade, W, solid, "#000000", 1);
    }

    // ---- customization -----------------------------------------------------------------
    var TABS = ["preset", "hair", "eyes", "face", "body", "aura"];
    function tabs() {
        var L = D.LOOKS[raceId(st.race)] || {};
        return TABS.filter(function (t) {
            if (t === "hair") return !!L.hair || !!L.headBones;
            if (t === "eyes") return L.eyes && L.eyes.length > 0;
            if (t === "face") return (L.nose && L.nose.length) || (L.mouth && L.mouth.length);
            return true;
        });
    }

    function look(k, def) { return st.looks[k] !== undefined ? st.looks[k] : def; }

    function openCustomize() {
        st.mode = "custom";
        st.tab = Math.min(st.tab, tabs().length - 1);
        rebuildCustomize();
    }

    // cards and swatches on screen, so a colour change can update them without a rebuild
    var LIVE = { cards: [], swatches: [] };
    function colorChanged() {
        var r = raceId(st.race);
        LIVE.swatches.forEach(function (k) { RPG.screen.update("sw_" + k, { color: st.colors[k] || defaults()[k] || "#FFFFFF" }); });
        LIVE.cards.forEach(function (c) { RPG.screen.update(c.id, { look: { key: lookKey(r), colors: merged(c.lk) } }); });
    }

    function rebuildCustomize() {
        var r = raceId(st.race), L = D.LOOKS[r] || {}, tab = tabs()[st.tab], els = [];
        LIVE.cards = []; LIVE.swatches = [];
        var aura = tab === "aura";
        els.push({ id: "panel", type: "image", anchor: "left", x: 12, y: -106, w: 141, h: 213, texture: MENU_BIG, texW: 256, texH: 256, u: 0, v: 0, uw: 141, vh: 213 });
        els.push({ id: "model", type: "entity", anchor: "topleft", x: 0, y: 0, w: 1, h: 1, rotation: st.yaw, tilt: st.pitch, followMouse: false, size: 95,
            look: { key: lookKey(r), colors: merged() } });
        els.push(textButton("back", -164, -28, T("gui.dragonminez.customization.back"), function () { sound("pip_menu"); back(); }, "bottomright"));
        var last = st.tab === tabs().length - 1;
        els.push(textButton("next", -86, -28, T(last ? "gui.dragonminez.customization.confirm" : "gui.dragonminez.customization.next"),
            function () { sound("pip_menu"); next(); }, "bottomright"));
        // cards and swatches for this tab
        var top = -106 + 12;            // relative to the vertical centre
        function grid(key, options, y0, rows, label, firstRow) {
            // DMZ preview cards: 34x44, 5 px gaps, 3 columns centred in the panel; head close-ups except body types
            var headZoom = key !== "bodyType" && key !== "tattoo", startX = 12 + Math.floor((141 - (3 * 34 + 2 * 5)) / 2);
            options.forEach(function (opt, i) {
                var col = i % 3, row = Math.floor(i / 3) - (firstRow || 0);
                if (row < 0 || row >= rows) return;
                var x = startX + col * 39, y = y0 + row * 49, sel = String(look(key, defaults()[key] !== undefined ? defaults()[key] : options[0])) === String(opt);
                els.push({ id: "cardb_" + key + "_" + i, type: "rect", anchor: "left", x: x - 1, y: y - 1, w: 36, h: 46, color: sel ? "#FFE8D0A1" : "#FF2A2A2A" });
                els.push({ id: "card_" + key + "_" + i, type: "rect", anchor: "left", x: x, y: y, w: 34, h: 44, color: "#AA111111", hoverColor: "#AA2A2A2A",
                    onClick: function () { st.looks[key] = opt; sound("pip_menu"); rebuildCustomize(); } });
                var lk = {}; lk[key] = opt;
                LIVE.cards.push({ id: "cardm_" + key + "_" + i, lk: lk });
                els.push({ id: "cardm_" + key + "_" + i, type: "entity", anchor: "left", x: x, y: y, w: 34, h: 44, clip: true, rotation: 180, followMouse: false,
                    modelX: 17, modelY: headZoom ? 92 : 44 - 2, size: headZoom ? 42 : 23, look: { key: lookKey(r), colors: merged(lk) } });
            });
        }
        function swatch(key, x, y) {
            var c = st.colors[key] || defaults()[key] || "#FFFFFF";
            // DMZ's swatch: the button's colour filled 2 px inside its 20x20 box
            LIVE.swatches.push(key);
            els.push({ id: "sw_" + key, type: "rect", anchor: "left", x: x + 2, y: y + 2, w: 16, h: 16, color: c, onClick: function () { openPicker(key); } });
        }
        if (tab === "preset") {
            var cols = L.colors || ["body1"];
            cols.forEach(function (k, i) { swatch(k, 12 + 70 - (cols.length * 30 - 10) / 2 + i * 30, top + 12); });
            grid("bodyType", L.bodies || ["0"], top + 40, 3, T("gui.dragonminez.customization.body_type"));
        } else if (tab === "hair" && !L.hair) {
            // races without hair pick DMZ's head bone instead: Namekian ears, Frost Demon horns, Majin tentacles
            grid("headBone", L.headBones, top + 30, 3, T("gui.dragonminez.customization.hair"));
        } else if (tab === "hair") {
            // DMZ's hair presets (shared/11_dmz_hair.js), nine cards a page like DMZ's scrolling preview grid
            if (L.hairColor) swatch("hair", 72, top + 10);
            var pages = Math.ceil(L.hair.length / 9);
            if (st.hairPage < 0) st.hairPage = Math.max(0, Math.floor(L.hair.indexOf(String(look("hairStyle", defaults().hairStyle || L.hair[0]))) / 9));
            st.hairPage = Math.max(0, Math.min(pages - 1, st.hairPage));
            grid("hairStyle", L.hair, top + 30, 3, T("gui.dragonminez.customization.hair"), st.hairPage * 3);
            if (pages > 1) {
                els.push(arrow("hair_prev", 22, top + 184, false, function () { hairPage(-1); }, "left"));
                els.push(arrow("hair_next", 135, top + 184, true, function () { hairPage(1); }, "left"));
            }
        } else if (tab === "eyes") {
            swatch("eyes", 72, top + 10);
            grid("eyeStyle", L.eyes, top + 30, 3, T("gui.dragonminez.customization.eyes"));
        } else if (tab === "face") {
            grid("nose", L.nose, top + 20, 1, T("gui.dragonminez.customization.nose"));
            grid("mouth", L.mouth, top + 94, 2, T("gui.dragonminez.customization.mouth"));
        } else if (tab === "body") {
            grid("tattoo", D.TATTOOS, top + 30, 3, T("gui.dragonminez.customization.tattoo"));
        } else if (aura) {
            els.push(arrow("cls_l", 30, top + 4, false, function () { cycleClass(-1); }, "left"));
            els.push(arrow("cls_r", 125, top + 4, true, function () { cycleClass(1); }, "left"));
            swatch("aura", 72, top + 160);
        }
        if (st.picker) pickerElements(els);
        RPG.screen.open({ id: "dmz_custom", referenceHeight: 360, closeOnEsc: false, background: { panorama: panorama(r) }, elements: els,
            onRender: renderCustomize, onKey: function (k) { if (k === "key.keyboard.escape") { back(); return false; } },
            onMouse: dragModel, onScroll: function (x, y, d) { if (tabs()[st.tab] === "hair" && L.hair && x < 169) hairPage(d > 0 ? -1 : 1); } });
    }

    function hairPage(dir) {
        var L = D.LOOKS[raceId(st.race)] || {}, pages = Math.ceil((L.hair || []).length / 9);
        var p = Math.max(0, Math.min(pages - 1, st.hairPage + dir));
        if (p === st.hairPage) return;
        st.hairPage = p;
        sound("pip_menu");
        rebuildCustomize();
    }

    var drag = null;
    function dragModel(x, y, button, action) {
        if (action === "down" && x > 169) drag = { x: x, y: y, yaw: st.yaw, pitch: st.pitch };
        else if (action === "up") drag = null;
    }

    function merged(extra) {
        var out = {}, d = defaults(), k;
        for (k in d) out[k] = d[k];
        for (k in st.colors) out[k] = st.colors[k];
        for (k in st.looks) out[k] = st.looks[k];
        if (extra) for (k in extra) out[k] = extra[k];
        if (out.bodyType !== undefined) {
            var bt = String(out.bodyType);
            out.bodyModel = bt.indexOf("female") === 0 || bt.indexOf("slim") >= 0 ? (raceId(st.race) === "majin" ? "majin_slim" : "human_slim") : (raceId(st.race) === "majin" ? "majin" : "human");
        }
        return out;
    }
    function defaults() { return (typeof DBR_RACE_DEFAULTS !== "undefined" && DBR_RACE_DEFAULTS[ourRace(raceId(st.race))]) || {}; }

    function renderCustomize(ctx) {
        var W = ctx.width, H = ctx.height, cx = W / 2, cy = H / 2, top = cy - 106 + 12;
        if (drag) {
            var m = RPG.screen.get("model");
            st.yaw = drag.yaw + (ctx.mouseX - drag.x) * 0.8;
            st.pitch = Math.max(-30, Math.min(40, drag.pitch + (ctx.mouseY - drag.y) * 0.5));
        }
        // model preview, centred in the free area
        var zx = 169, zw = W - 16 - zx, aura = tabs()[st.tab] === "aura";
        RPG.screen.update("model", { x: zx + zw / 2 - 50 - (aura ? 55 : 0), y: cy + 112 - 200, w: 100, h: 200, rotation: st.yaw, tilt: st.pitch, look: { key: lookKey(raceId(st.race)), colors: merged() } });
        // tab title
        var tab = tabs()[st.tab];
        var titles = { preset: "gui.dragonminez.customization.body_type", hair: "gui.dragonminez.customization.hair", eyes: "gui.dragonminez.customization.eyes",
            face: "gui.dragonminez.customization.nose", body: "gui.dragonminez.customization.tattoo", aura: "gui.dragonminez.customization.class" };
        bordered(ctx, T(titles[tab]), 82, tab === "aura" ? top - 2 : top + 2, "#FF9B9B");
        if (tab === "face") bordered(ctx, T("gui.dragonminez.customization.mouth"), 82, top + 74, "#FF9B9B");
        if (tab === "hair" && typeof DMZ_HAIR !== "undefined" && (D.LOOKS[raceId(st.race)] || {}).hair) {
            var L = D.LOOKS[raceId(st.race)] || {}, sel = String(look("hairStyle", defaults().hairStyle || (L.hair || [""])[0]));
            bordered(ctx, DMZ_HAIR.presetName(Number(sel)), 82, top + 180, "#FFFFFF");
            var pages = Math.ceil((L.hair || []).length / 9);
            if (pages > 1) bordered(ctx, (st.hairPage + 1) + "/" + pages, 82, top + 191, "#AAAAAA");
        }
        if (tab === "aura") renderClass(ctx, top, W, cy);
        // progress
        var n = st.tab + 1, N = tabs().length;
        bordered(ctx, n + "/" + N, W - 164 + 76, H - 50, "#FFFFFF");
        ctx.fill(W - 164, H - 40, 152, 6, "#FFFFFF", 1);
        ctx.fill(W - 163, H - 39, 150, 4, "#111111", 1);
        ctx.fill(W - 163, H - 39, 150 * n / N, 4, "#006400", 1);
    }

    function renderClass(ctx, top, W, cy) {
        var c = D.CLASSES[st.cls];
        bordered(ctx, T("class.dragonminez." + st.cls), 82, top + 10, "#FFFFFF");
        bordered(ctx, T("gui.dragonminez.customization.base_stats"), 82, top + 34, "#FFFFFF");
        var labels = [["STR", "SKP", "RES"], ["VIT", "PWR", "ENE"]];
        labels.forEach(function (row, ri) {
            row.forEach(function (s, ci) {
                var x = 82 + (ci - 1) * 40, y = top + 50 + ri * 32;
                bordered(ctx, s, x, y, "#D71432");
                bordered(ctx, String(c.base[s]), x, y + 12, "#FFFFFF");
            });
        });
        bordered(ctx, "TP Multiplier: x" + c.tpGain.toFixed(2), 82, top + 106, "#FFFFFF");
        bordered(ctx, "TPC Multiplier: x" + c.tpCost.toFixed(2), 82, top + 118, "#FFFFFF");
        bordered(ctx, T("gui.dragonminez.customization.aura"), 82, top + 134, "#FFFFFF");
        bordered(ctx, T("gui.dragonminez.customization.aura.2d"), 82, top + 152, "#FFFFFF");
        // right: the class passive
        bordered(ctx, "§6Passive", W - 75, cy - 62, "#FFFFFF");
        var y = cy - 50;
        wrap(ctx, D.strip(T("class.dragonminez." + st.cls + ".passive.desc")), 130).forEach(function (l) { bordered(ctx, l, W - 75, y, "#CCCCCC"); y += 12; });
    }

    function cycleClass(dir) {
        var o = D.CLASS_ORDER, i = o.indexOf(st.cls);
        st.cls = o[((i + dir) % o.length + o.length) % o.length];
        sound("ui_nave_cooldown");
        rebuildCustomize();
    }

    function back() {
        if (st.picker) { st.picker = null; rebuildCustomize(); return; }
        if (st.tab > 0) { st.tab--; rebuildCustomize(); } else openRace();
    }

    function next() {
        if (st.tab < tabs().length - 1) { st.tab++; rebuildCustomize(); return; }
        // Confirm: send everything to the server, which creates the character
        var data = { race: ourRace(raceId(st.race)), cls: st.cls, colors: {}, looks: {} }, k, m = merged();
        for (k in m) data.looks[k] = String(m[k]);
        RPG.net.send("dmz_create", data);
        RPG.screen.close();
    }

    // ---- colour picker (HSV sliders + hex) ----------------------------------------------
    function openPicker(key) {
        st.picker = key;
        st.hsv = toHsv(st.colors[key] || defaults()[key] || "#FFFFFF");
        sound("pip_menu");
        rebuildCustomize();
    }
    function pickerElements(els) {
        var y = -40;
        [["hue", 0, 360], ["saturation", 0, 100], ["value", 0, 100]].forEach(function (s, i) {
            els.push({ id: "hsv_" + i, type: "slider", anchor: "left", x: 161, y: y + i * 12, w: 80, h: 10, min: s[1], max: s[2], step: 1, value: st.hsv[i],
                onChange: function (id, v) { st.hsv[i] = v; st.colors[st.picker] = toHex(st.hsv); RPG.screen.update("hex", { value: st.colors[st.picker] }); colorChanged(); } });
        });
        els.push({ id: "hex", type: "input", anchor: "left", x: 161, y: y + 36, w: 80, h: 12, maxLength: 7, value: st.colors[st.picker] || toHex(st.hsv),
            onChange: function (id, v) {
                if (!/^#?[0-9a-fA-F]{6}$/.test(v)) return;
                st.colors[st.picker] = v.charAt(0) === "#" ? v : "#" + v;
                st.hsv = toHsv(st.colors[st.picker]);
                for (var j = 0; j < 3; j++) RPG.screen.update("hsv_" + j, { value: st.hsv[j] });
                colorChanged();
            } });
    }
    function toHsv(hex) {
        var n = parseInt(String(hex).replace("#", ""), 16) || 0, r = (n >> 16 & 255) / 255, g = (n >> 8 & 255) / 255, b = (n & 255) / 255;
        var max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min, h = 0;
        if (d) h = max === r ? ((g - b) / d) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
        h = Math.round(((h * 60) + 360) % 360);
        return [h, Math.round(max ? d / max * 100 : 0), Math.round(max * 100)];
    }
    function toHex(hsv) {
        var h = hsv[0], s = hsv[1] / 100, v = hsv[2] / 100, c = v * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c, r, g, b;
        if (h < 60) { r = c; g = x; b = 0; } else if (h < 120) { r = x; g = c; b = 0; } else if (h < 180) { r = 0; g = c; b = x; }
        else if (h < 240) { r = 0; g = x; b = c; } else if (h < 300) { r = x; g = 0; b = c; } else { r = c; g = 0; b = x; }
        function hx(v) { return ("0" + Math.round((v + m) * 255).toString(16)).slice(-2); }
        return "#" + hx(r) + hx(g) + hx(b);
    }

    return { open: openRace };
})();

// the server opens the creator for players without a character (and on V before creation)
RPG.net.on("dmz_open_creator", function () { CREATOR.open(); });
