// =====================================================================================
//  72_dball_rims.js - the thin glowing rim round each placed Dragon Ball
// =====================================================================================
//  DMZ Ragnarok (SuDragonBallBlockRenderer) draws a lighter, glowing ring at the edge of
//  its glass ball. The glass and the stars are block models (resources/.../dball_glass);
//  the rim is a camera-facing ring just outside the sphere, drawn with RPG.world3d. The
//  server sends the placed balls near you (57_dragon_balls.js, "dbr_ball_rims").
// =====================================================================================
(function () {
    // sphere centre height and radius in blocks (DMZ Ragnarok's ball sizes), rim colour (the set's glass, lighter)
    var SETS = {
        earth: { cy: 3.375 / 16, r: 3.75 / 16, color: "#FFD27A" },
        namek: { cy: 5.625 / 16, r: 5.75 / 16, color: "#FFD27A" },
        demon: { cy: 5.625 / 16, r: 5.75 / 16, color: "#FFAA66" }
    };
    var TEX = "dbr:textures/block/dball_glass/rim.png";
    RPG.net.on("dbr_ball_rims", function (d) {
        if (!RPG.world3d) return;
        RPG.world3d.removePrefix("dbr_rim_");
        (d && d.list || []).forEach(function (b) {
            var set = SETS[b[3]] || SETS.earth;
            RPG.world3d.billboard("dbr_rim_" + b[0] + "_" + b[1] + "_" + b[2], {
                x: b[0] + 0.5, y: b[1] + set.cy, z: b[2] + 0.5, size: set.r * 2 * 1.12,
                texture: TEX, color: set.color, alpha: 1, blend: "additive", emissive: true
            });
        });
    });
})();
