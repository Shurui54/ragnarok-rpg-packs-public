// =====================================================================================
//  43_dmz_auras.js - this computer's aura options and the overcharge shake
// =====================================================================================
//  Ported from DragonMine Z 2.2 (GPL-3.0): ConfigMenuScreen's "My Aura - 3D Style" (on/off),
//  "My Aura - 3D Type" (Smooth / Sparking / God) and "Enemy Auras - 3D Style", and
//  EffectsEvents' charge shake (stronger while overcharging into a ki surge).
//
//  Your own 3D choice goes to the server (scripts/29_dmz_auras.js) so everyone sees it; the
//  enemy option only changes how this computer draws other players. Stored in RPG.storage:
//      dmz_cfg_aura3d (bool)  dmz_cfg_aura3d_style (0 smooth, 1 sparking, 2 god)
//      dmz_cfg_aura3d_others (bool)
// =====================================================================================
var DMZ_AURAS = (function () {
    var STYLES = ["smooth", "sparking", "god"];
    var NAMES = ["gui.dragonminez.customization.aura.smooth", "gui.dragonminez.customization.aura.sparking", "gui.dragonminez.customization.aura.god"];

    function get(key, def) { try { var v = RPG.storage.get(key, def); return v === undefined || v === null ? def : v; } catch (e) { return def; } }
    function put(key, v) { try { RPG.storage.set(key, v); } catch (e) { } }

    function mine() { return !!get("dmz_cfg_aura3d", false); }
    function style() { var i = Math.round(Number(get("dmz_cfg_aura3d_style", 0)) || 0); return Math.max(0, Math.min(STYLES.length - 1, i)); }
    function others() { return !!get("dmz_cfg_aura3d_others", false); }

    function push() { RPG.net.send("dmz_aura3d", { on: mine(), style: STYLES[style()] }); }
    function applyLocal() {
        if (RPG.auras && typeof RPG.auras.options === "function") RPG.auras.options({ othersFlat: !others() });
    }

    // send once we are in a world (the server keeps it, but a fresh install may have changed it offline)
    var sent = false;
    RPG.on("tick", function () {
        if (sent || !RPG.player.present) return;
        sent = true;
        applyLocal();
        push();
    });
    RPG.on("unload", function () { sent = false; });

    // ---- charge shake (EffectsEvents): gentle while charging, strong while the surge bar fills ----
    var lastSurge = 0, shakeTick = 0, bigLeft = 0;
    RPG.on("tick", function () {
        if (!RPG.player.present) return;
        var charging = RPG.player.hasEffect("ki_charge");
        var surge = Math.max(0, Math.min(100, Number(RPG.getVar("dmz_surge", 0)) || 0));
        var active = !!Number(RPG.getVar("dmz_surge_active", 0));
        if (active && surge >= 99 && lastSurge < 99) { RPG.camera.shake(1.6, 12); bigLeft = 12; }   // the surge fires
        lastSurge = surge;
        if (bigLeft > 0) { bigLeft--; return; }
        if (++shakeTick % 8 !== 0) return;
        if (charging && surge > 0 && !active) RPG.camera.shake(0.25 + 0.4 * surge / 100, 14);   // overcharging
        else if (charging) RPG.camera.shake(0.12, 14);
    });

    return {
        mine: mine, style: style, others: others,
        setMine: function (on) { put("dmz_cfg_aura3d", !!on); push(); },
        setStyle: function (i) { put("dmz_cfg_aura3d_style", Math.max(0, Math.min(STYLES.length - 1, Math.round(i)))); push(); },
        setOthers: function (on) { put("dmz_cfg_aura3d_others", !!on); applyLocal(); },
        styleName: function () { return NAMES[style()]; },
        STYLE_COUNT: STYLES.length
    };
})();
