// =====================================================================================
//  DMZ parties on the client (server: scripts/78_dmz_party.js). Ports of DragonMine Z (GPL-3.0):
//   - PartyHUD: up to 3 other members on the left (head frame tinted with their aura, name, HP + ki bars,
//     red when down, distance when out of sight). Sheet textures/gui/hud/hud_party.png. Movable ("Party").
//   - PartyMarkerOverlay: a marker above every other member's head (hidden within 2.5 blocks), name +
//     distance, bigger when you look at it. Movable/hideable as "Party Markers".
//   - PartyInviteToastS2C: the invite pops up in the DMZ notification panel (47_dmz_notifications.js).
//   - PartyMenuScreen (simplified): V menu > Party tab: create, invite, leave/disband, kick, PvP,
//     invitations with accept/reject and the difficulty confirmation.
// =====================================================================================
var DMZ_PARTY_UI = (function () {
    var SHEET = "dmzpack:textures/gui/hud/hud_party.png", SW = 256, SH = 128, FONT = "dmzpack:smooth";
    var HUD = { members: [] }, STATE = null, PENDING_CONFIRM = null;
    function tr(key, fallback) {
        var args = Array.prototype.slice.call(arguments, 2), i = 0;
        if (!RPG.hasTranslation(key)) return fallback;
        var s = String(RPG.translate(key));
        s = s.replace(/%(\d+)\$s/g, function (m, n) { var v = args[Number(n) - 1]; return v === undefined ? "" : String(v); });
        return s.replace(/%s|%d/g, function () { var v = args[i++]; return v === undefined ? "" : String(v); }).replace(/%%/g, "%");
    }
    function sprite(ctx, u, v, w, h, x, y, dw, dh, color, a) {
        ctx.quad(SHEET, x, y, dw, dh, u / SW, v / SH, (u + w) / SW, (v + h) / SH, color || "#FFFFFF", a);
    }
    function hpColor(f) { return f > 0.5 ? "#5BD64A" : f > 0.25 ? "#F2C94C" : "#E5484D"; }
    function fmt(n) { n = Math.round(n || 0); return n >= 1e6 ? (n / 1e6).toFixed(1) + "M" : n >= 1e4 ? (n / 1e3).toFixed(1) + "K" : String(n); }

    RPG.net.on("dmz_party_hud", function (d) { HUD = d || { members: [] }; });
    RPG.net.on("dmz_party_state", function (d) { STATE = d; if (RPG.screen.getOpen() === "dmz_party") openScreen(); });
    RPG.net.on("dmz_open_party", function () { openScreen(); });
    RPG.net.on("dmz_party_invite", function (d) {
        RPG.sound("dmzpack:pip_menu", 1, 1.2);
        if (typeof DMZ_NOTIFY !== "undefined")
            DMZ_NOTIFY.push({ title: tr("toast.dragonminez.party.invite.title", "Party Invite"), description: tr("toast.dragonminez.party.invite.desc", (d.from || "?") + " invited you to a quest party", d.from || "?"),
                extra: "/rpgc party accept" }, DMZ_NOTIFY.PRIORITY.HIGH);
    });
    RPG.net.on("dmz_party_confirm", function (d) { PENDING_CONFIRM = d; openConfirm(d); });

    // ---- PartyHUD ----
    var BORDER = 1.5, HEAD = 20, ROW = 27, BAR_X = HEAD + BORDER, HP_W = 70, HP_H = 6, KI_H = 4.5;
    function others() {
        var me = RPG.player.name;
        return (HUD.members || []).filter(function (m) { return m.name !== me; }).slice(0, 3);
    }
    function drawHud(ctx) {
        if (!RPG.player.present) return;
        var list = others(), editing = ctx.isEditing();
        if (!list.length && !editing) return;
        if (!list.length) list = [{ name: "Goku", hp: 1800, max: 2000, ki: 900, kmax: 1500, aura: "#FF8A65" }, { name: "Vegeta", hp: 450, max: 2000, ki: 1300, kmax: 1500, aura: "#4FC3FF" },
            { name: "Piccolo", hp: 1200, max: 2000, ki: 400, kmax: 1500, aura: "#7CFDD6", far: true }];
        var unit = Math.max(0.25, ctx.height / 360), sc = 0.67 * unit, w = 116.5 * sc, h = 78 * sc, x = 46 * unit, y = ctx.height / 2 - h / 2;
        if (!ctx.group("dmz_party_hud", tr("gui.dragonminez.hud_editor.element.party", "Party"), x, y, w, h)) return;
        ctx.push();
        ctx.translate(x, y);
        ctx.scale(sc, sc);
        var startY = BORDER + 1 + (3 - list.length) * ROW / 2;
        list.forEach(function (m, i) {
            ctx.push();
            ctx.translate(BORDER, startY + i * ROW);
            var down = m.down || m.hp <= 0, aura = m.aura || "#4FC3FF";
            sprite(ctx, 150, 0, 46, 46, -BORDER, -BORDER, HEAD + BORDER * 2, HEAD + BORDER * 2, "#FFFFFF", 1);
            sprite(ctx, 150, 47, 46, 46, -BORDER, -BORDER, HEAD + BORDER * 2, HEAD + BORDER * 2, aura, 1);
            ctx.textStyled(String(m.name).charAt(0).toUpperCase(), HEAD / 2, HEAD / 2 - 6, 1.6, "#FFFFFF", 1, 0.5, FONT, "#000000");
            if (down) ctx.fill(0, 0, HEAD, HEAD, "#7A0000", 0.55);
            var hpY = HEAD - KI_H - BORDER - HP_H, kiY = HEAD - KI_H, f = m.max > 0 ? Math.max(0, Math.min(1, m.hp / m.max)) : 0, kf = m.kmax > 0 ? Math.max(0, Math.min(1, m.ki / m.kmax)) : 0;
            sprite(ctx, 0, 0, 146, 18, BAR_X - BORDER, hpY - BORDER, 73, 9, "#FFFFFF", 1);
            sprite(ctx, 0, 38, 140 * f, 12, BAR_X, hpY, HP_W * f, HP_H, hpColor(f), 1);
            sprite(ctx, 0, 64, 146, 15, BAR_X - BORDER, kiY - BORDER, 73, 7.5, "#FFFFFF", 1);
            sprite(ctx, 0, 80, 140 * kf, 9, BAR_X, kiY, HP_W * kf, KI_H, aura, 1);
            ctx.textStyled(m.name, BAR_X + 2, -1, 0.75, down ? "#FF7A7A" : "#FFFFFF", 1, 0, FONT, "#000000");
            var p = RPG.player, far = m.far || m.dim !== p.dimension;
            if (far || dist(m) > 64) ctx.textStyled(far ? "?" : Math.round(dist(m)) + "m", BAR_X + 2 + ctx.textWidthIn(m.name, FONT) * 0.75 + 4, -1, 0.75, "#A8B0C0", 1, 0, FONT, "#000000");
            ctx.textStyled(fmt(m.hp), BAR_X + HP_W + BORDER + 2, hpY, 0.75, "#FFFFFF", 1, 0, FONT, "#000000");
            ctx.pop();
        });
        ctx.pop();
        ctx.endGroup();
    }
    function dist(m) { var p = RPG.player, dx = m.x - p.x, dy = m.y - p.y, dz = m.z - p.z; return Math.sqrt(dx * dx + dy * dy + dz * dz); }

    // ---- PartyMarkerOverlay ----
    function drawMarkers(ctx) {
        if (!RPG.player.present || !RPG.storage.get("dmz_cfg_party_markers", true)) return;   // DMZ option "Party Markers"
        var list = others(), p = RPG.player;
        if (!list.length) return;
        if (!ctx.group("dmz_party_markers", tr("gui.dragonminez.config.partyMarkers", "Party Markers"), ctx.width / 2 - 20, 6, 40, 12)) return;
        if (ctx.isEditing()) { ctx.textStyled("Party Markers", ctx.width / 2, 8, 0.75, "#FFFFFF", 1, 0.5, FONT, "#000000"); ctx.endGroup(); return; }
        var unit = Math.max(0.25, ctx.height / 360), cx = ctx.width / 2, cy = ctx.height / 2;
        list.forEach(function (m) {
            if (m.dim !== p.dimension) return;
            var d = dist(m);
            if (d < 2.5 || d > 2000) return;
            var s = RPG.project(m.x, m.y + 0.4, m.z);
            if (!s.visible) return;
            var off = Math.sqrt((s.x - cx) * (s.x - cx) + (s.y - cy) * (s.y - cy)), focus = off < 12 * unit, k = (focus ? 1.6 : 1) * unit, a = focus ? 1 : 0.8;
            var tint = m.down ? "#FF7A7A" : (m.aura || "#4FC3FF");
            ctx.push();
            ctx.translate(s.x, s.y);
            ctx.scale(k, k);
            sprite(ctx, 200, 0, 32, 32, -4, -8, 8, 8, tint, a);
            sprite(ctx, 150, 0, 46, 46, -5, -19, 10, 10, "#FFFFFF", a);
            sprite(ctx, 150, 47, 46, 46, -5, -19, 10, 10, tint, a);
            ctx.textStyled(m.name, 0, -28, 0.75, m.down ? "#FF7A7A" : "#FFFFFF", a, 0.5, FONT, "#000000");
            if (focus) ctx.textStyled(Math.round(d) + "m", 0, -37, 0.75, "#B8C0CC", a, 0.5, FONT, "#000000");
            ctx.pop();
        });
        ctx.endGroup();
    }

    // ---- PartyMenuScreen (simplified) ----
    function send(action, extra) { var d = extra || {}; d.action = action; RPG.net.send("dmz_party", d); RPG.sound("dmzpack:ui_menu_switch", 1, 1); }
    var inviteOpen = false;
    function openScreen() {
        var st = STATE || { members: [], invites: [], players: [] }, els = [], y = -95;
        var me = st.me, mine = null;
        (st.members || []).forEach(function (m) { if (m.id === me) mine = m; });
        var leader = !!(mine && mine.leader), owner = !!(mine && mine.owner);
        els.push({ id: "bg", type: "rect", anchor: "center", x: -150, y: -115, w: 300, h: 230, color: "#D0141B25" });
        els.push({ id: "title", type: "text", anchor: "center", x: 0, y: -108, text: "§l" + tr("gui.dragonminez.party.title", "Party"), align: "center", color: "#FFD54F", font: FONT });
        if (!st.id) {
            els.push({ id: "hint", type: "text", anchor: "center", x: 0, y: y, text: tr("gui.dragonminez.party.create_hint", "Create a party to share quest progress."), align: "center", color: "#FFFFFF", wrap: 260 });
            els.push({ id: "w1", type: "text", anchor: "center", x: -135, y: y + 18, text: "§7- " + tr("gui.dragonminez.party.welcome.quests", "Share quest progress."), color: "#FFFFFF", wrap: 270 });
            els.push({ id: "w2", type: "text", anchor: "center", x: -135, y: y + 30, text: "§7- " + tr("gui.dragonminez.party.welcome.explore", "Friendly fire off by default."), color: "#FFFFFF", wrap: 270 });
            els.push({ id: "create", type: "button", anchor: "center", x: -50, y: y + 48, w: 100, h: 18, label: tr("gui.dragonminez.party.create", "Create Party"), onClick: function () { send("create"); } });
            y += 76;
        } else {
            els.push({ id: "role", type: "text", anchor: "center", x: -135, y: y, text: (leader ? tr("gui.dragonminez.party.role.leader", "Role: Leader") : tr("gui.dragonminez.party.role.member", "Role: Member")) +
                "   " + tr("gui.dragonminez.party.members", "Members: " + st.members.length, String(st.members.length)) + "   PvP: " + (st.pvp ? "§con" : "§aoff"), color: "#C7EAFC" });
            y += 14;
            st.members.forEach(function (m, i) {
                var line = (m.online ? "§f" : "§7") + m.name + (m.leader ? " §e(leader)" : "") + (m.owner ? " §6★" : "") + (m.online ? "  §7Lv " + (m.level || "?") + "  " + (m.race || "") + "  " + (m.cls || "") + "  §c" + fmt(m.hp) + "/" + fmt(m.max) : "  §8offline");
                els.push({ id: "m" + i, type: "text", anchor: "center", x: -135, y: y, text: line, color: "#FFFFFF" });
                if (leader && m.id !== me && !m.owner) els.push({ id: "k" + i, type: "button", anchor: "center", x: 100, y: y - 3, w: 36, h: 13, label: "Kick", onClick: function () { send("kick", { id: m.id }); } });
                y += 14;
            });
            y += 4;
            if (leader) {
                els.push({ id: "inv", type: "button", anchor: "center", x: -140, y: y, w: 90, h: 18, label: tr("gui.dragonminez.party.invite_players", "Invite Players"), onClick: function () { inviteOpen = !inviteOpen; openScreen(); } });
                els.push({ id: "pvp", type: "button", anchor: "center", x: -45, y: y, w: 90, h: 18, label: "PvP: " + (st.pvp ? "On" : "Off"), onClick: function () { send("pvp"); } });
            }
            els.push({ id: "leave", type: "button", anchor: "center", x: 50, y: y, w: 90, h: 18, label: owner && st.members.length > 1 ? tr("gui.dragonminez.party.disband", "Disband Party") : tr("gui.dragonminez.party.leave", "Leave Party"),
                onClick: function () { send(owner && st.members.length > 1 ? "disband" : "leave"); } });
            y += 24;
            if (inviteOpen && leader) {
                if (!st.players.length) els.push({ id: "none", type: "text", anchor: "center", x: -135, y: y, text: "§7" + tr("gui.dragonminez.party.invite_none", "No players available"), color: "#FFFFFF" });
                st.players.slice(0, 8).forEach(function (o, i) {
                    els.push({ id: "pl" + i, type: "button", anchor: "center", x: -140 + (i % 4) * 70, y: y + Math.floor(i / 4) * 16, w: 66, h: 14, label: o.name, tooltip: "Lv " + o.level, onClick: function () { send("invite", { name: o.name }); } });
                });
                y += 36;
            }
        }
        if (st.invites && st.invites.length) {
            els.push({ id: "ih", type: "text", anchor: "center", x: -135, y: y, text: "§l" + tr("gui.dragonminez.party.invites", "Invitations"), color: "#FFD54F" });
            y += 12;
            st.invites.slice(0, 3).forEach(function (iv, i) {
                els.push({ id: "iv" + i, type: "text", anchor: "center", x: -135, y: y + 3, text: iv.from + " §7(" + iv.diff + ", " + iv.left + "s)", color: "#FFFFFF" });
                els.push({ id: "ia" + i, type: "button", anchor: "center", x: 40, y: y, w: 46, h: 14, label: tr("quest.dmz.party.invite.accept", "Accept"), onClick: function () { send("accept", { party: iv.party }); } });
                els.push({ id: "ir" + i, type: "button", anchor: "center", x: 90, y: y, w: 46, h: 14, label: tr("quest.dmz.party.invite.reject", "Reject"), onClick: function () { send("reject", { party: iv.party }); } });
                y += 16;
            });
        }
        RPG.screen.open({ id: "dmz_party", referenceHeight: 360, background: "dim", elements: els });
    }
    function openConfirm(d) {
        RPG.screen.open({ id: "dmz_party_confirm", referenceHeight: 360, background: "dim", elements: [
            { id: "bg", type: "rect", anchor: "center", x: -130, y: -45, w: 260, h: 90, color: "#E0141B25" },
            { id: "t", type: "text", anchor: "center", x: 0, y: -38, text: "§l" + tr("gui.dragonminez.party.confirm.difficulty.title", "Difficulty Change"), align: "center", color: "#FFD54F" },
            { id: "b", type: "text", anchor: "center", x: -120, y: -22, wrap: 240, color: "#FFFFFF",
                text: tr("gui.dragonminez.party.confirm.difficulty.body", "This party plays on " + d.diff + ". Joining changes your difficulty permanently. Continue?", d.diff) },
            { id: "y", type: "button", anchor: "center", x: -100, y: 20, w: 90, h: 18, label: tr("gui.dragonminez.party.confirm_yes", "Confirm"), onClick: function () { RPG.screen.close(); send("accept", { party: d.party, confirm: true }); } },
            { id: "n", type: "button", anchor: "center", x: 10, y: 20, w: 90, h: 18, label: tr("gui.dragonminez.party.confirm_no", "Cancel"), onClick: function () { RPG.screen.close(); } }
        ] });
    }

    RPG.on("load", function () { RPG.hud.onRender(drawHud); RPG.hud.onRender(drawMarkers); });
    return { open: function () { RPG.net.send("dmz_party", { action: "state" }); openScreen(); } };
})();
