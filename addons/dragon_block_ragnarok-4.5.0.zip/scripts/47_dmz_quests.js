// =====================================================================================
//  47_dmz_quests.js - DragonMine Z's story: sagas, side quests, difficulty, rewards
// =====================================================================================
//  The quests are DMZ's own (shared/05_dmz_quest_data.js); the rules are in
//  shared/06_dmz_quest_logic.js. This file starts quests, spawns their enemies, tracks
//  objectives (QuestEvents), completes, turns in at NPCs and pays rewards (QuestService).
//  State: player var "dmz_quests" (see DMZ_QL). The quest screen talks to it over
//  "dmz_quest" (start / claim / claim_all / track / difficulty / state).
// =====================================================================================
var DMZ_QUESTS = (function () {
    var QL = DMZ_QL, ENTITIES = QL.DATA.entities || {};

    // DMZ npc ids -> ours (60_npcs_dialogue.js); DMZ NPCs we don't have are skipped over
    var NPCS = { roshi: "master_roshi", goku: "master_goku", krillin: "master_krillin", gohan: "master_gohan", piccolo: "master_piccolo",
        bulma: "bulma", dende: "dende", guru: "guru", popo: "mr_popo", oldkai: "old_kai", mr_satan: "mr_satan", trunks: "master_trunks",
        karin: "korin", baba_earth: "fortune_teller_baba", kingkai: "king_kai", tien: "master_tien", yamcha: "master_yamcha", vegeta: "master_vegeta" };
    var FROM_OURS = {};
    Object.keys(NPCS).forEach((k) => { FROM_OURS[NPCS[k]] = k; });
    function npcExists(dmzNpc) {
        let raw = String(dmzNpc || "").toLowerCase(), id = NPCS[raw];
        return !!(id && RPG.npcs.exists(id)) || (!!raw && RPG.npcs.exists(raw));           // saga editor quests may name our NPC ids
    }

    // DMZ dimensions -> ours (85_world.js)
    var DIMS = { "dragonminez:namek": "ragnarok_rpg:namek", "dragonminez:otherworld": "ragnarok_rpg:otherworld", "dragonminez:time_chamber": "ragnarok_rpg:time_chamber" };
    // DMZ items keep their registry ids here (16_dmz_items.js, 57_dragon_balls.js); older names as fallback
    var ITEM_ALIAS = { dball_radar: "dragon_radar", namekdball_radar: "namek_dragon_radar", fused_dball_radar: "fused_dragon_radar" };
    // non-saga DMZ mobs that this addon already has
    var MOB_ALIAS = { giant_fish: "giant_fish", dino1: "dinosaur", bandit: "bandit", red_ribbon_soldier: "red_ribbon_soldier", shadow_dummy: "shadow_dummy" };
    var TAG_PREFIX = { "#dragonminez:saibamen": "saibaman", "#dragonminez:red_ribbon_robots": "rr_robot_", "#dragonminez:frieza_soldiers": "frieza_soldier" };

    // readable names on the server (the client uses DMZ's lang)
    function entityName(e) { return String(e).replace(/^#?[a-z_]+:/, "").replace(/^(dmzq_)?saga_/, "").replace(/_v\d+$/, "").replace(/_/g, " "); }
    function titleCase(s) { return s.replace(/\b[a-z]/g, (c) => c.toUpperCase()); }

    // ---- one mob per DMZ saga enemy, with DMZ's model (DBSagaModel: geo/entity/sagas/<id>) ----
    function mobId(entity, variant) {
        let path = String(entity).split(":")[1] || entity;
        return "dmzq_" + path + (variant ? "_v" + variant : "");
    }
    Object.keys(ENTITIES).forEach((e) => {
        let info = ENTITIES[e], path = e.split(":")[1];
        if (MOB_ALIAS[path]) return;
        // DBSagasEntity attributes (43_dmz_saga_kits.js) + the DMZ brain (76_dmz_saga_ai.js)
        let base = dmzSagaBase(path), kit = DMZ_SAGA_KITS[path] || {};
        Object.keys(info.tex || { "0": "enemies/robotxv" }).forEach((v) => {
            RPG.mobs.define(mobId(e, Number(v)), {
                name: "&c" + titleCase(entityName(e)),
                geo: { model: DMZ_GEO + info.model + ".geo.json", texture: DMZ_TEX + info.tex[v] + ".png",
                    animation: DMZ_ANIM + "sagas/saga_base.animation.json", idle: "idle", walk: "walk", attack: "attack1_1",
                    scale: kit.sc || 1 },
                health: base[0], damage: base[2], speed: base[1], followRange: base[3], hostile: true, persistent: true, xp: 0,
                onTick(m) { if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onTick(m); },
                onDeath(m) { if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onDeath(m); }
            });
        });
    });

    // ---- state ----
    function view(p) {
        let v = p.getVar("dmz_quests", null);
        if (!v || typeof v !== "object") v = { q: {}, d: null, resets: 0, tr: null };
        if (!v.q) v.q = {};
        v.skill = (s) => DMZ_SKILLS.level(p, s);
        v.level = p.getLevel();
        v.alignment = Number(p.getVar("dmz_alignment", 100));
        v.race = DMZ_SKILLS.race(p);
        v.cls = p.playerClass;
        return v;
    }
    function save(p, v) {
        p.setVar("dmz_quests", { q: v.q, d: v.d, resets: v.resets || 0, tr: v.tr || null });
    }
    function sync(p, v) {
        v = v || view(p);
        RPG.net.send(p, "dmz_quests_state", { q: v.q, d: v.d, resets: v.resets || 0, tr: v.tr || null, skills: DMZ_SKILLS.levels(p),
            alignment: v.alignment, dim: p.dimension, op: !!p.isOp() });
    }
    function msg(p, key, args, color) { RPG.net.send(p, "dmz_msg", { key: key, args: args || [], color: color || "#FFFF55" }); }

    // ---- positional checks (QuestLocationHelper) ----
    function inDimension(p, dim) {
        if (DIMS[dim]) return p.dimension === DIMS[dim];
        if (dim.indexOf("minecraft:") === 0) return p.dimension === dim;
        return true;                                      // DMZ dimensions we don't have
    }
    function inBiome(p, biome) {
        if (/^#?dragonminez:/.test(biome)) {
            if (biome === "#dragonminez:is_plains") biome = "#forge:is_plains";
            else return true;                             // DMZ biomes we don't have
        }
        p.removeTag("dmzq_biome");
        p.runCommand("execute if biome ~ ~ ~ " + biome + " run tag @s add dmzq_biome");
        let ok = p.hasTag("dmzq_biome");
        p.removeTag("dmzq_biome");
        return ok;
    }
    function positional(p, key, v) {
        return function (c) {
            if (c.type === "DIMENSION") return inDimension(p, c.dimension);
            if (c.type === "BIOME") return inBiome(p, c.biome);
            if (c.type === "STRUCTURE") return true;      // no structure lookup in the API
            if (c.type === "TIME") {
                let r = QL.rec(v, key), t = r && r.t;
                if (!t) return false;
                return c.mode === "GAME_TIME" ? RPG.world.getTime("") - t.g >= (c.ticks || 0) : Date.now() - t.r >= (c.milliseconds || 0);
            }
            return null;
        };
    }
    function hasTime(g) { return !!(g && g.conditions && g.conditions.some((c) => c.conditions ? hasTime(c) : c.type === "TIME")); }

    // ---- items ----
    function itemRef(id) {
        if (!id) return null;
        if (id.indexOf("minecraft:") === 0) return id;
        let path = id.split(":")[1] || id;
        if (RPG.items.exists(path) || RPG.blocks.exists(path)) return path;         // DMZ blocks (stations, cables...) too
        if (ITEM_ALIAS[path] && RPG.items.exists(ITEM_ALIAS[path])) return ITEM_ALIAS[path];
        return null;
    }
    function heldCount(p, id) { let r = itemRef(id); return r ? p.countItem(r) : -1; }

    // ---- parties (78_dmz_party.js; QuestParty) ----
    function partyAll(p) { return typeof DMZ_PARTY !== "undefined" ? DMZ_PARTY.members(p) : [p]; }
    function partyNearby(p) { return typeof DMZ_PARTY !== "undefined" ? DMZ_PARTY.nearby(p) : [p]; }
    function partyIds(p) { return typeof DMZ_PARTY !== "undefined" ? DMZ_PARTY.memberIds(p) : [String(p.uuid)]; }
    function participants(p, key) { return partyNearby(p).filter((m) => QL.status(view(m), key) === QL.ACCEPTED); }
    function allParticipants(p, key) { return partyAll(p).filter((m) => QL.status(view(m), key) === QL.ACCEPTED); }
    // Quest.enemyPartyMultiplier: 1 + (size - 1) x (perPlayer - 1); enemyHealthPerPartyPlayer 1.25, enemyDamagePerPartyPlayer 1.1
    function partyMult(q, n, per) { return q.party_scaling === false ? 1 : 1 + (Math.max(1, n) - 1) * (per - 1); }
    // Quest.getScaledObjectiveRequired: kills ceil(c x 1.45^((n-1) x 0.75)), items c x 1.45^(n-1)
    function scaledRequired(q, o, n) {
        let base = QL.required(o);
        if (q.party_scaling === false || n <= 1 || base <= 0) return base;
        if (o.type === "ITEM") { let step = base >= 64 ? 16 : base >= 16 ? 4 : 1; return Math.ceil(Math.max(base, base * Math.pow(1.45, n - 1)) / step) * step; }
        if (o.type === "KILL") return base <= 1 ? base : Math.max(base, Math.ceil(base * Math.pow(1.45, (n - 1) * 0.75)));
        return base;
    }
    /** this player's required count (party-scaled when the quest started) */
    function req(v, e, i) { let r = v.q[e.key]; return r && r.rq && typeof r.rq[i] === "number" ? r.rq[i] : QL.required(e.quest.objectives[i]); }

    // ---- quest enemies (QuestService.spawnKillObjectives) ----
    function safeKey(key) { return String(key).replace(/[^A-Za-z0-9_.+-]/g, "."); }
    function questTag(p, key, i) { return "dmzq-" + p.uuid + "-" + safeKey(key) + "-" + i; }
    function aliveTagged(p, tag) { return p.nearby(128).filter((e) => e.isAlive() && e.hasTag(tag)).length; }

    function spawnEnemy(p, o) {
        let e = o.entity, path = String(e).split(":")[1] || e, mob = null;
        let x = p.x, y = p.y, z = p.z;
        for (let tries = 0; tries < 16; tries++) {
            let a = Math.random() * Math.PI * 2, dist = 9 + Math.random() * 2;
            let tx = Math.floor(p.x + Math.cos(a) * dist), tz = Math.floor(p.z + Math.sin(a) * dist), found = false;
            for (let ty = Math.floor(p.y) + 4; ty >= Math.floor(p.y) - 8; ty--) {
                let below = RPG.world.getBlock(p.dimension, tx, ty - 1, tz), at = RPG.world.getBlock(p.dimension, tx, ty, tz), up = RPG.world.getBlock(p.dimension, tx, ty + 1, tz);
                if (below !== "minecraft:air" && below.indexOf("water") < 0 && at === "minecraft:air" && up === "minecraft:air") { x = tx + 0.5; y = ty; z = tz + 0.5; found = true; break; }
            }
            if (found) break;
        }
        if (String(e).indexOf("minecraft:") === 0) mob = RPG.world.spawn(p.dimension, e, x, y, z);
        else if (MOB_ALIAS[path] && RPG.mobs.exists(MOB_ALIAS[path])) mob = RPG.world.spawnMob(p.dimension, MOB_ALIAS[path], x, y, z);
        else {
            let id = mobId(e, Number(o.TextureVariant || 0));
            if (!RPG.mobs.exists(id)) id = mobId(e, 0);
            if (RPG.mobs.exists(id)) mob = RPG.world.spawnMob(p.dimension, id, x, y, z);
            else if (RPG.mobs.exists(path)) mob = RPG.world.spawnMob(p.dimension, path, x, y, z);      // "rpg:<mob>" from the saga editor
            else if (String(e).indexOf("dragonminez:") !== 0 && String(e).indexOf(":") > 0) { try { mob = RPG.world.spawn(p.dimension, e, x, y, z); } catch (err) { mob = null; } }
        }
        return mob;
    }

    function aliveForParty(p, key, i) {
        let ids = partyIds(p), n = 0;
        p.nearby(128).forEach((m) => { if (m.isAlive() && ids.some((u) => m.hasTag("dmzq-" + u + "-" + safeKey(key) + "-" + i))) n++; });
        return n;
    }
    /** stats a quest enemy gets (dmz_quest_hp/melee/ki, ai tier, transform tuning), party-scaled and x difficulty */
    function enemyStats(o, q, diffName, n, path) {
        let diff = QL.DIFFICULTY[diffName] || QL.DIFFICULTY.NORMAL;
        let hpM = partyMult(q, n, 1.25), dmgM = partyMult(q, n, 1.1);
        let st = { diff: { hp: diff.hp, dmg: diff.dmg }, noTransform: o.canTransform === false,
            tier: (o.aiTier || o.AITier) > 0 ? (o.aiTier || o.AITier) : (typeof DMZ_SAGA !== "undefined" ? DMZ_SAGA.storyTier(diffName, path) : diff.tier) };
        if (o.health) st.hp = o.health * hpM * diff.hp;
        if (o.meleeDamage) st.melee = o.meleeDamage * dmgM * diff.dmg;
        st.ki = (o.kiDamage || 20) * dmgM * diff.dmg;
        if (o.TransformHealth || o.TransformMeleeDamage || o.TransformKiDamage)
            st.tf = { hp: o.TransformHealth ? o.TransformHealth * hpM : 0, melee: o.TransformMeleeDamage ? o.TransformMeleeDamage * dmgM : 0,
                ki: o.TransformKiDamage ? o.TransformKiDamage * dmgM : 0 };
        return st;
    }
    function applyStats(mob, st) {
        if (typeof DMZ_SAGA !== "undefined" && DMZ_SAGA.dmzId(mob)) { DMZ_SAGA.setup(mob, st); return; }
        if (st.hp) { mob.maxHealth = st.hp; mob.health = st.hp; }
        if (st.melee) mob.setAttributeBase("generic.attack_damage", st.melee);
    }
    function coordsOf(q) { for (let i = 0; i < q.objectives.length; i++) if (q.objectives[i].type === "COORDS") return q.objectives[i]; return null; }
    function atCoords(p, o) {
        let dx = p.x - (Number(o.x) || 0), dy = p.y - (Number(o.y) || 0), dz = p.z - (Number(o.z) || 0), r = Math.max(1, Number(o.radius) || 4);
        return dx * dx + dy * dy + dz * dz <= r * r;
    }
    function deferred(q, o) { return !!o.sdu_defer_spawn && !!coordsOf(q); }
    function spawnKills(p, e, v) {
        let q = e.quest, diffName = QL.questDifficulty(v, e.key), n = Math.max(1, participants(p, e.key).length), here = coordsOf(q) && atCoords(p, coordsOf(q));
        q.objectives.forEach((o, i) => {
            if ((o.type !== "KILL" && o.type !== "SPAR") || o.spawn !== "QUEST") return;
            if (deferred(q, o) && !here) return;
            let tag = questTag(p, e.key, i);
            let toSpawn = req(v, e, i) - QL.progress(v, e.key, i) - aliveForParty(p, e.key, i);
            let path = String(o.entity || "").split(":")[1] || "";
            for (let k = 0; k < toSpawn; k++) {
                let mob = spawnEnemy(p, o);
                if (!mob) continue;
                mob.addTag("dmzq");
                mob.addTag(tag);
                if (o.type === "SPAR") mob.addTag("dmzq_spar");
                applyStats(mob, enemyStats(o, q, diffName, n, path));
                mob.target = p;
            }
        });
    }
    function despawnQuest(p, key) {
        let prefixes = partyIds(p).map((u) => "dmzq-" + u + "-" + safeKey(key) + "-");
        p.nearby(160).forEach((m) => {
            if (!m.hasTag("dmzq") || m.isPlayer()) return;
            for (let i = 0; i < 16; i++) if (prefixes.some((pre) => m.hasTag(pre + i))) {
                if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onDeath(m);
                m.remove(); return;
            }
        });
    }

    // ---- start (QuestService.startQuest / beginQuest) ----
    function start(p, key) {
        let e = QL.entry(key), v = view(p);
        if (!e) return msg(p, "message.dragonminez.quest.start.unavailable", [], "#FF5555");
        if (QL.status(v, key) === QL.ACCEPTED) return msg(p, "message.dragonminez.quest.start.already_active", [], "#FF5555");
        if (!QL.startable(e, v)) return msg(p, "message.dragonminez.quest.start.locked", [], "#FF5555");
        let req = e.quest.requirements;
        if (req && hasTime(req)) {
            let r = v.q[key] || (v.q[key] = {});
            if (!r.t) { r.t = { g: RPG.world.getTime(""), r: Date.now() }; save(p, v); }
        }
        if (req && !QL.evalGroup(req, v, positional(p, key, v))) {
            let fail = QL.firstFailing(req, v, positional(p, key, v));
            RPG.net.send(p, "dmz_quest_blocker", { cond: fail });
            return;
        }
        // party members in range who can start it join (QuestService.startQuest); difficulty = the leader's
        let diff = (typeof DMZ_PARTY !== "undefined" ? DMZ_PARTY.difficulty(p) : null) || v.d || "NORMAL";
        let joiners = [{ p: p, v: v }];
        partyNearby(p).forEach((m) => {
            if (m === p || String(m.uuid) === String(p.uuid) || !m.getVar("dmz_created", 0)) return;
            let mv = view(m);
            if (QL.status(mv, key) === QL.ACCEPTED) return;
            if (QL.startable(e, mv) && (!req || QL.evalGroup(req, mv, positional(m, key, mv)))) joiners.push({ p: m, v: mv });
            else if (QL.status(mv, key) !== QL.COMPLETED) p.tell("&e" + m.name + " can't join this quest yet.");
        });
        let n = joiners.length;
        joiners.forEach((j) => {
            let keepT = j.v.q[key] && j.v.q[key].t, first = e.saga && e.saga.quests.every((sq) => !QL.status(j.v, e.saga.id + ":" + sq.id));
            j.v.q[key] = { s: QL.ACCEPTED, p: e.quest.objectives.map(() => 0), c: [], d: diff, dim: j.p.dimension,
                rq: e.quest.objectives.map((o) => scaledRequired(e.quest, o, n)) };
            if (Number(e.quest.sdu_time_limit) > 0) j.v.q[key].ts = Date.now();     // saga editor time limit
            if (keepT) j.v.q[key].t = keepT;
            j.v.tr = key;
            save(j.p, j.v);
            // SagaTitleCardS2C: the first quest of a saga shows the saga's title card
            if (first) RPG.net.send(j.p, "dmz_saga_title", { name: e.saga.name || e.saga.id, label: e.saga.label || "" });
        });
        try { spawnKills(p, e, v); } catch (err) { RPG.log("DMZ quest spawn failed for " + key + ": " + err); }
        joiners.forEach((j) => {
            j.p.playSound("dmzpack:pip_menu", 1, 1);
            RPG.net.send(j.p, "dmz_quest_toast", { kind: "started", key: key });
            sync(j.p, j.v);
        });
    }

    // ---- progress (QuestEvents) ----
    function setProgress(p, v, e, i, value) {
        let r = v.q[e.key];
        if (!r || r.p[i] === value) return false;
        let req = r.rq && typeof r.rq[i] === "number" ? r.rq[i] : QL.required(e.quest.objectives[i]), before = r.p[i] || 0;
        r.p[i] = Math.max(0, value);
        if (before < req && r.p[i] >= req) RPG.net.send(p, "dmz_quest_toast", { kind: "objective", key: e.key, index: i });
        return true;
    }
    function firstUncompleted(v, e, target) {
        for (let i = 0; i < target; i++) {
            let o = e.quest.objectives[i];
            if (QL.isTurnInTalk(e.quest, o)) continue;
            if (QL.progress(v, e.key, i) < req(v, e, i)) return false;
        }
        return true;
    }
    function blockStart(e, i, type) { let s = i; while (s > 0 && e.quest.objectives[s - 1].type === type) s--; return s; }
    function killUnlocked(v, e, i) { return e.quest.parallel_objectives || firstUncompleted(v, e, blockStart(e, i, e.quest.objectives[i].type === "SPAR" ? "SPAR" : "KILL")); }

    function complete(p, v, e) {
        let r = v.q[e.key];
        // saga editor "consume items": completing takes what the ITEM objectives asked for (QuestItemConsumeHandler)
        if (e.quest.sdu_consume_items && r.s === QL.ACCEPTED) e.quest.objectives.forEach((o, i) => {
            if (o.type !== "ITEM") return;
            let ref = itemRef(o.item), n = req(v, e, i);
            if (ref && n > 0) p.takeItem(ref, Math.min(n, p.countItem(ref)));
        });
        r.s = QL.COMPLETED; r.at = Date.now(); delete r.ts;
        if (v.tr === e.key) v.tr = null;
        despawnQuest(p, e.key);
        RPG.net.send(p, "dmz_quest_toast", { kind: "completed", key: e.key });
        p.playSound("dmzpack:ui_menu_switch", 1, 1);
    }
    /** QuestEvents.checkAndComplete (quests with a turn-in NPC finish there instead). */
    function checkAndComplete(p, v, e) {
        if (QL.status(v, e.key) !== QL.ACCEPTED || e.quest.turn_in && npcExists(e.quest.turn_in)) return false;
        for (let i = 0; i < e.quest.objectives.length; i++) if (QL.progress(v, e.key, i) < req(v, e, i)) return false;
        complete(p, v, e);
        return true;
    }

    function accepted(v) { return Object.keys(v.q).filter((k) => v.q[k].s === QL.ACCEPTED && QL.entry(k)); }

    function matchesKill(p, victim, e, i, o, ids) {
        if (o.count_mode === "QUEST_SPAWNED_ONLY" || o.spawn === "QUEST") return ids.some((u) => victim.hasTag("dmzq-" + u + "-" + safeKey(e.key) + "-" + i));
        let ent = String(o.entity || ""), rid = victim.rpgId || "";
        if (TAG_PREFIX[ent]) return rid.indexOf(TAG_PREFIX[ent]) === 0;
        if (ent.indexOf("minecraft:") === 0) return victim.type === ent;
        let path = ent.split(":")[1] || ent;
        if (MOB_ALIAS[path] && rid === MOB_ALIAS[path]) return true;
        return rid.indexOf("dmzq_" + path) === 0;
    }
    // QuestEvents.creditQuestKill / forEachSharedQuest: the killer and party members in range with the same quest
    function creditKill(killer, victim) {
        let ids = partyIds(killer), killerQuests = accepted(view(killer));
        partyNearby(killer).forEach((p) => {
            let v = view(p), changed = false, self = String(p.uuid) === String(killer.uuid);
            accepted(v).forEach((k) => {
                if (!self && killerQuests.indexOf(k) < 0) return;
                let e = QL.entry(k);
                e.quest.objectives.forEach((o, i) => {
                    if (o.type !== "KILL" && o.type !== "SPAR") return;
                    if (QL.progress(v, k, i) >= req(v, e, i) || !killUnlocked(v, e, i)) return;
                    if (matchesKill(p, victim, e, i, o, ids)) changed = setProgress(p, v, e, i, QL.progress(v, k, i) + 1) || changed;
                });
                changed = checkAndComplete(p, v, e) || changed;
            });
            if (changed) { save(p, v); sync(p, v); }
        });
    }
    RPG.on("kill", (p, victim) => creditKill(p, victim));

    // SPAR: the partner concedes instead of dying (SparObjective)
    RPG.on("lethal", (ev) => {
        let t = ev.target;
        if (!t || t.isPlayer() || !t.hasTag("dmzq_spar")) return;
        ev.cancel();
        t.health = 1;
        let owner = ev.attacker && ev.attacker.isPlayer() ? ev.attacker.asPlayer() : null;
        RPG.schedule(1, () => {
            if (owner) { creditKill(owner, t); msg(owner, "message.dragonminez.quest.spar_won", [entityName(t.rpgId)], "#55FF55"); }
            t.remove();
        });
    });

    // every second: items, places, skills, waves, dragons (QuestEvents.processTickObjectives)
    var WAVES = {};      // uuid|key|i -> { wave, waitUntil }
    function fail(p, v, k, why) {
        let e = QL.entry(k);
        if (!v.q[k] || v.q[k].s !== QL.ACCEPTED) return;
        v.q[k].s = QL.FAILED; delete v.q[k].ts; delete v.q[k].dsp;
        if (v.tr === k) v.tr = null;
        if (e) despawnQuest(p, k);
        RPG.net.send(p, "dmz_quest_toast", { kind: "failed", key: k });
        if (why) RPG.net.send(p, "dmz_msg", { text: why, color: "#FF5555" });
    }
    function tickPlayer(p) {
        let v = view(p), changed = false;
        accepted(v).forEach((k) => {
            let e = QL.entry(k), q = e.quest;
            // saga editor time limit (QuestTimerHandler)
            if (QL.timeLeft(v, e) === 0) { fail(p, v, k, "Time's up: " + String(q.title || k)); changed = true; return; }
            // deferred KILL spawns appear once the player reaches the COORDS objective
            let co = coordsOf(q);
            if (co && !v.q[k].dsp && q.objectives.some((o) => (o.type === "KILL" || o.type === "SPAR") && deferred(q, o)) && atCoords(p, co)) {
                v.q[k].dsp = true; changed = true;
                try { spawnKills(p, e, v); } catch (err) { RPG.log("DMZ quest spawn failed for " + k + ": " + err); }
            }
            for (let i = 0; i < q.objectives.length; i++) {
                let o = q.objectives[i], req = (v.q[k].rq && typeof v.q[k].rq[i] === "number") ? v.q[k].rq[i] : QL.required(o), cur = QL.progress(v, k, i);
                if (o.type === "ITEM") {
                    let held = heldCount(p, o.item);
                    held = held < 0 ? req : Math.min(held, req);    // items this addon doesn't have count as held
                    if (held !== cur) changed = setProgress(p, v, e, i, held) || changed;
                    if (held >= req) continue;
                    if (!q.parallel_objectives) break;
                    continue;
                }
                if (cur >= req || QL.isTurnInTalk(q, o)) continue;
                if (o.type === "BIOME" && inBiome(p, o.biome)) changed = setProgress(p, v, e, i, req) || changed;
                else if (o.type === "DIMENSION" && inDimension(p, o.dimension)) changed = setProgress(p, v, e, i, req) || changed;
                else if (o.type === "STRUCTURE") changed = setProgress(p, v, e, i, req) || changed;   // no structure lookup in the API
                else if (o.type === "COORDS" && atCoords(p, o)) changed = setProgress(p, v, e, i, req) || changed;
                else if (o.type === "SKILL") {
                    let lv = Math.min(DMZ_SKILLS.level(p, o.skill), req);
                    if (lv !== cur) changed = setProgress(p, v, e, i, lv) || changed;
                } else if (o.type === "TALK_TO" && !npcExists(o.npcId)) changed = setProgress(p, v, e, i, req) || changed;
                else if (o.type === "DELIVER" && !npcExists(o.npcId)) changed = setProgress(p, v, e, i, req) || changed;
                else if (o.type === "DRAGON_SUMMON") {
                    let dragon = String(o.dragon || "shenron");
                    if (p.nearby(48).some((m) => String(m.rpgId || "").indexOf(dragon) === 0)) changed = setProgress(p, v, e, i, req) || changed;
                } else if (o.type === "SURVIVE_WAVES") changed = tickWaves(p, v, e, i, o) || changed;
                if (!q.parallel_objectives) break;
            }
            changed = checkAndComplete(p, v, e) || changed;
        });
        if (changed) { save(p, v); sync(p, v); }
    }

    // SURVIVE_WAVES (QuestFieldSessions.tickWaves): a wave spawns, is cleared, then the next one after the delay
    function tickWaves(p, v, e, i, o) {
        let id = p.uuid + "|" + e.key + "|" + i, w = WAVES[id] || (WAVES[id] = { waitUntil: 0, active: false });
        let tag = questTag(p, e.key, i), alive = aliveTagged(p, tag), now = Date.now();
        if (w.active && alive === 0) {
            w.active = false; w.waitUntil = now + (o.wave_delay_seconds || 8) * 1000;
            msg(p, "message.dragonminez.quest.wave_cleared", [QL.progress(v, e.key, i) + 1, QL.required(o)], "#55FF55");
            return setProgress(p, v, e, i, QL.progress(v, e.key, i) + 1);
        }
        if (!w.active && now >= w.waitUntil && QL.progress(v, e.key, i) < QL.required(o)) {
            for (let n = 0; n < (o.mobs_per_wave || 1); n++) {
                let mob = spawnEnemy(p, o);
                if (!mob) continue;
                mob.addTag("dmzq"); mob.addTag(tag);
                applyStats(mob, enemyStats(o, e.quest, QL.questDifficulty(v, e.key), Math.max(1, participants(p, e.key).length), String(o.entity || "").split(":")[1] || ""));
                mob.target = p;
            }
            w.active = true;
            msg(p, "message.dragonminez.quest.wave_started", [QL.progress(v, e.key, i) + 1, QL.required(o)], "#FFAA00");
        }
        return false;
    }

    RPG.every(20, () => RPG.server.players().forEach((p) => { if (p.getVar("dmz_created", 0) && p.isAlive()) tickPlayer(p); }));

    // ---- NPCs: deliveries, talk objectives, turn-in (QuestEvents.onEntityInteract, QuestService.turnInQuest) ----
    function deliver(p, v, e, i, o) {
        let ref = itemRef(o.item), need = QL.required(o) - QL.progress(v, e.key, i);
        if (need <= 0) return false;
        if (!ref) return setProgress(p, v, e, i, QL.required(o));        // an item this addon doesn't have
        let have = p.countItem(ref), give = Math.min(have, need);
        if (give <= 0) { msg(p, "message.dragonminez.quest.deliver.missing", [ref, need], "#FFFF55"); return false; }
        p.takeItem(ref, give);
        return setProgress(p, v, e, i, QL.progress(v, e.key, i) + give);
    }
    function plainName(s) { return String(s || "").replace(/[§&][0-9a-fk-or]/gi, "").trim().toLowerCase(); }
    RPG.on("npcInteract", (p, npc, npcId) => {
        // DMZ npc id for ours; saga editor quests may also name our own NPC id or the NPC's display name
        let dmzNpc = FROM_OURS[npcId] || String(npcId || "").toLowerCase(), npcName = "";
        try { npcName = plainName(npc && npc.name); } catch (err) { npcName = ""; }
        let v = view(p), changed = false;
        // a custom side quest's quest giver offers it (DMZ's quest_giver)
        QL.SIDE.forEach((q) => {
            if (!q.custom || !q.quest_giver || String(q.quest_giver).toLowerCase() !== dmzNpc) return;
            let e = QL.entry(q.id);
            if (e && QL.status(v, q.id) !== QL.ACCEPTED && QL.startable(e, v)) { start(p, q.id); v = view(p); }
        });
        accepted(v).forEach((k) => {
            let e = QL.entry(k), q = e.quest;
            q.objectives.forEach((o, i) => {
                let target = String(o.npcId || "").toLowerCase();
                if (target !== dmzNpc && !(o.sdu_talk_npc_name && npcName && plainName(o.sdu_talk_npc_name) === npcName)) return;
                if (o.type === "DELIVER" && (q.parallel_objectives || firstUncompleted(v, e, blockStart(e, i, "DELIVER")))) changed = deliver(p, v, e, i, o) || changed;
                else if (o.type === "TALK_TO" && !QL.isTurnInTalk(q, o) && QL.progress(v, k, i) < 1 && (q.parallel_objectives || firstUncompleted(v, e, i)))
                    changed = setProgress(p, v, e, i, 1) || changed;
            });
            // turn-in: everything else done -> complete here and hand out the rewards
            if (q.turn_in && String(q.turn_in).toLowerCase() === dmzNpc) {
                let ready = true;
                q.objectives.forEach((o, i) => { if (!QL.isTurnInTalk(q, o) && QL.progress(v, k, i) < req(v, e, i)) ready = false; });
                if (ready) {
                    q.objectives.forEach((o, i) => { if (QL.isTurnInTalk(q, o)) setProgress(p, v, e, i, 1); });
                    complete(p, v, e);
                    claim(p, v, e);
                    changed = true;
                }
            } else changed = checkAndComplete(p, v, e) || changed;
        });
        if (changed) { save(p, v); sync(p, v); }
    });

    // ---- failure: dying with a fight in progress (QuestEvents.handlePlayerQuestFailure) ----
    // (a party only fails when every participant of that quest is dead)
    RPG.on("death", (p) => {
        let v = view(p);
        accepted(v).forEach((k) => {
            let e = QL.entry(k);
            if (!QL.hasKill(e.quest)) return;
            let group = allParticipants(p, k);
            if (group.some((m) => String(m.uuid) !== String(p.uuid) && m.isAlive() && m.health > 0)) return;
            group.concat(group.some((m) => String(m.uuid) === String(p.uuid)) ? [] : [p]).forEach((m) => {
                let mv = String(m.uuid) === String(p.uuid) ? v : view(m);
                if (!mv.q[k] || mv.q[k].s !== QL.ACCEPTED) return;
                mv.q[k].s = QL.FAILED;
                save(m, mv); sync(m, mv);
                RPG.net.send(m, "dmz_quest_toast", { kind: "failed", key: k });
            });
            despawnQuest(p, k);
        });
    });

    // ---- rewards (QuestService.claimAvailableRewards, StatsData.grantAttributeReward) ----
    function give(p, v, e, r) {
        let mult = QL.rewardMultiplier(v, e.key, r);
        switch (r.type) {
            case "ATTRIBUTES": {
                let attrs = Math.round((r.amount || 0) * mult);
                if (attrs <= 0) return;
                let points = Math.max(0, Math.min(attrs, Math.floor(attrs * 0.5)));
                if (points > 0) p.setStatPoints(p.getStatPoints() + points);
                let c = DMZ_DATA.CLASSES[p.playerClass] || DMZ_DATA.CLASSES.warrior;
                let tp = DMZ_F.cost(DMZ_F.total(dmzView(p)) + p.getStatPoints(), attrs - points, c.tpCost);
                if (tp > 0) p.addTp(tp, { raw: true, events: false, source: "quest" });
                return;
            }
            case "ATTRIBUTE_POINTS": p.setStatPoints(p.getStatPoints() + Math.round((r.amount || 0) * mult)); return;
            case "TPS": p.addTp(Math.round((r.amount || 0) * mult), { raw: true, events: false, source: "quest" }); return;
            case "ITEM": {
                let ref = itemRef(r.item), n = Math.max(1, Math.round((r.count || 1) * mult));
                if (r.nbt && /^\{.*\}$/.test(String(r.nbt).trim()) && String(r.item).indexOf(":") > 0) {     // saga editor ITEM + SNBT
                    RPG.server.runCommand("give " + p.name + " " + r.item + String(r.nbt).trim() + " " + Math.max(1, r.count || 1));
                    return;
                }
                if (ref) p.giveItem(ref, n);
                else p.tell("&7(" + r.item + " x" + n + " is not in this game)");
                return;
            }
            case "SKILL": DMZ_SKILLS.setLevel(p, String(r.skill).toLowerCase(), Math.max(DMZ_SKILLS.level(p, String(r.skill).toLowerCase()), r.level || 1), "quest"); return;
            // KiTechniqueReward: DMZ ships custom technique codes; a predefined technique id works here (41_dmz_techniques.js)
            case "TECHNIQUE":
            case "KI_TECHNIQUE": if (typeof DMZ_TECH !== "undefined") DMZ_TECH.unlock(p, String(r.technique || r.id || r.code || "").toLowerCase(), { source: "quest" }); return;
            case "COMMAND": RPG.server.runCommand(String(r.command || "").replace(/%player%/g, p.name)); return;
            // FORM_PURCHASE: unlocks buying a form (DBR_SAGA_EDITOR.formUnlocked); nothing is handed out
            case "FORM_PURCHASE": if (r.form) RPG.net.send(p, "dmz_msg", { text: "Form unlocked for purchase: " + r.form, color: "#55FF55" }); return;
            case "ALIGNMENT": p.setVar("dmz_alignment", Math.max(0, Math.min(100, Number(p.getVar("dmz_alignment", 100)) + (r.amount || 0)))); return;
        }
    }
    function claim(p, v, e) {
        let r = v.q[e.key];
        if (!r || r.s !== QL.COMPLETED) return false;
        let diff = QL.questDifficulty(v, e.key), any = false;
        r.c = r.c || [];
        (e.quest.rewards || []).forEach((rw, i) => {
            if (!QL.rewardUnlocked(rw, diff) || r.c.indexOf(i) >= 0) return;
            give(p, v, e, rw);
            r.c.push(i);
            any = true;
        });
        return any;
    }

    RPG.net.on("dmz_quest", (p, d) => {
        if (!d || !p.getVar("dmz_created", 0)) return;
        let action = String(d.action || ""), key = String(d.key || ""), v = view(p);
        if (action === "state") return sync(p, v);
        if (action === "difficulty") {
            if (v.d) return;                                      // locked in (DMZ: change it with a wish)
            let dd = String(d.difficulty || "").toUpperCase();
            if (!QL.DIFFICULTY[dd]) return;
            v.d = dd; save(p, v); sync(p, v);
            p.playSound("dmzpack:pip_menu", 1, 1);
            return;
        }
        if (action === "start") return start(p, key);
        let e = QL.entry(key);
        if (action === "resummon" && e && QL.status(v, key) === QL.ACCEPTED) { spawnKills(p, e, v); return; }
        if (action === "track" && e && QL.status(v, key) === QL.ACCEPTED) { v.tr = key; save(p, v); sync(p, v); return; }
        if (action === "claim" && e) {
            if (e.quest.claim_mode === "NPC_ONLY") return msg(p, "quest.dmz.reward.npc_only", [], "#FF5555");
            if (claim(p, v, e)) { save(p, v); sync(p, v); p.playSound("dmzpack:ui_menu_switch", 1, 1); }
            return;
        }
        if (action === "claim_all") {
            let any = false;
            Object.keys(v.q).forEach((k) => {
                let en = QL.entry(k);
                if (en && en.quest.claim_mode !== "NPC_ONLY") any = claim(p, v, en) || any;
            });
            if (any) { save(p, v); sync(p, v); p.playSound("dmzpack:ui_menu_switch", 1, 1); }
        }
    });

    function open(p) {
        sync(p);
        RPG.net.send(p, "dmz_open_quests", {});
    }

    // ops: /rpgc dmzquest <complete|reset|start> <key> [player], /rpgc dmzquest difficulty reset [player]
    RPG.commands.register("dmzquest", {
        permission: 2, description: "/rpgc dmzquest <start|complete|reset> <questKey> [player]",
        run(p, args) {
            let target = args[2] ? RPG.server.player(args[2]) : p;
            if (!target || !args[1]) return;
            let v = view(target), key = String(args[1]), e = QL.entry(key);
            if (args[0] === "difficulty") { v.d = null; save(target, v); sync(target, v); return; }
            if (!e) { if (p) p.tell("&cUnknown quest " + key); return; }
            if (args[0] === "start") { start(target, key); return; }
            if (args[0] === "complete") { v.q[key] = v.q[key] || { p: e.quest.objectives.map((o) => QL.required(o)), c: [] }; complete(target, v, e); }
            else if (args[0] === "reset") { despawnQuest(target, key); delete v.q[key]; }
            save(target, v); sync(target, v);
        }
    });

    return { open: open, sync: sync, start: start,
        isCompleted: (p, key) => QL.completed(view(p), key),
        completedKeys: (p) => { let v = view(p); return Object.keys(v.q).filter((k) => v.q[k].s === QL.COMPLETED); },
        /** other scripts: a dragon was summoned near this player (DRAGON_SUMMON objectives) */
        dragonSummoned: (p, dragon) => {
            let v = view(p), changed = false;
            accepted(v).forEach((k) => {
                let e = QL.entry(k);
                e.quest.objectives.forEach((o, i) => {
                    if (o.type === "DRAGON_SUMMON" && (!o.dragon || String(dragon).indexOf(o.dragon) === 0)) changed = setProgress(p, v, e, i, 1) || changed;
                });
                changed = checkAndComplete(p, v, e) || changed;
            });
            if (changed) { save(p, v); sync(p, v); }
        } };
})();
