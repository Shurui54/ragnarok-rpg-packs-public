// =====================================================================================
//  86_dbr_space.js - space travel (port of DMZ Ragnarok's Space module, GPL-3.0)
// =====================================================================================
//  Fly (or ride a space pod) above entryAltitude on a planet and you are in space, next to
//  the planet you left. Space is a zero-g void (ragnarok_rpg:space, datapack/) with a sun at
//  the centre and the planets on their rings (shared/15_dbr_space_orbits.js), drawn by the
//  client (client/scripts/61_dbr_space.js). Fly into a planet to land on it; drop below
//  returnAltitude and you go back where you took off (or to the nearest planet in range).
//  Picking a planet in the pod's list (or the star map, M in space) arms the autopilot:
//  the pod climbs out, crosses space and lands by itself (DMZ Ragnarok SpaceAutopilot).
//  Near the sun you burn. Settings: ragnarok_rpg/config/dbr_space.json or /rpg config dbr_space.
// =====================================================================================
var DBR_SPACE_CFG = RPG.config.define("dbr_space", {
    enabled:            { default: true, comment: "Space travel on (needs the ragnarok_rpg:space dimension: restart the world once after installing)" },
    entryAltitude:      { default: 1000, min: 64, max: 4096, client: true, comment: "Fly above this height on a planet to reach space (DMZ Ragnarok entryAltitude)" },
    returnAltitude:     { default: -96, min: -120, max: 60, client: true, comment: "Sink below this height in space to go back (DMZ Ragnarok returnAltitude; void damage starts at -128)" },
    distanceScale:      { default: 0.25, min: 0.02, max: 1, client: true, comment: "Planet ring radii x this. 1 = DMZ Ragnarok's distances (Earth 6000, Namek 21000 blocks from the sun)" },
    planeY:             { default: 100, min: -40, max: 300, client: true, comment: "Height of the planets' plane in space" },
    nearestPlanetRange: { default: 6144, min: 0, max: 100000, comment: "Below returnAltitude, land on a planet this close (x distanceScale) before going back home" },
    podAutopilot:       { default: true, comment: "Picking a planet in the space pod flies there through space (otherwise the pod jumps straight there)" },
    ascentSpeed:        { default: 4, min: 0.5, max: 9.5, client: true, comment: "Autopilot climb speed to entryAltitude (blocks per tick)" },
    cruiseSpeed:        { default: 9, min: 1, max: 9.5, client: true, comment: "Autopilot speed in space (blocks per tick; servers refuse vehicle moves over 10)" },
    sunDamage:          { default: true, comment: "Burn near the sun (DMZ Ragnarok SUN_DANGER_RADIUS 480)" }
});

// space is weightless (DMZ Ragnarok: no gravity in space); the engine applies it to players and mobs on both sides
RPG.dimensions.setGravity(DBR_SPACE_ORBITS.SPACE, 0);

var DBR_SPACE = (function () {
    var C = DBR_SPACE_CFG, O = DBR_SPACE_ORBITS, SPACE = O.SPACE;
    var LANDING_MARGIN = 8, STANDOFF = 40;
    var epochOffset = 0;

    function on() { return C.get("enabled") && RPG.server.hasDimension(SPACE); }
    function now() { return Date.now() + epochOffset; }
    function bodyPos(id) { return O.position(id, now(), C.get("distanceScale"), C.get("planeY")); }
    function sunPos() { return { x: 0, y: C.get("planeY"), z: 0 }; }
    function loadedBodies() { return O.BODIES.filter((b) => RPG.server.hasDimension(b.dim)); }
    function dist(a, b) { var dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z; return Math.sqrt(dx * dx + dy * dy + dz * dz); }
    function inPod(p) { var v = p.getVehicle(); return v && v.getVehicleId() === "spacepod" ? v : null; }

    function msg(p, text) { p.actionbar(text); }

    // ---- autopilot state (player var, like DMZR's persistent su_space_autopilot tag) ----
    function autopilot(p) { return String(p.getVar("dbr_space_autopilot", "") || ""); }
    function setAutopilot(p, id) {
        p.setVar("dbr_space_autopilot", id || "");
        sendState(p);
    }
    function sendState(p) {
        RPG.net.send(p, "dbr_space_state", { autopilot: autopilot(p), epoch: Date.now(), inSpace: p.dimension === SPACE,
            origin: String(p.getVar("dbr_space_origin", "") || "") });
    }

    // ---- moving players (and their pod) between worlds ----
    var cooldown = {};
    function dropY() { return Math.min(220, C.get("entryAltitude") - 24); }
    function carry(p, dim, x, y, z, after) {
        cooldown[p.uuid] = RPG.server.getTick() + 40;
        var pod = inPod(p);
        if (pod) p.dismount();
        var ok = p.teleportTo(dim, x, y, z);
        if (ok === false || p.dimension !== dim) {
            if (pod) p.mount(pod);
            msg(p, "&cThat world isn't loaded. Restart the world once so it loads.");
            return false;
        }
        if (pod) {
            pod.remove();
            RPG.schedule(1, () => {
                if (!p.alive || p.dimension !== dim) return;
                var np = RPG.world.spawnVehicle(dim, "spacepod", p.x, p.y, p.z, p.yaw);
                if (np) { DBR_POD_ARRIVING[p.uuid] = true; p.mount(np); }
                if (after) after(!!np);
            });
        } else if (after) RPG.schedule(1, () => after(false));
        return true;
    }

    /** Leaving a planet upward: remember where, then appear in space beside it (DMZR enterSpace). */
    function enterSpace(p, body) {
        p.setVar("dbr_space_origin", p.dimension + " " + p.x.toFixed(1) + " " + p.y.toFixed(1) + " " + p.z.toFixed(1));
        p.setVar("dbr_space_last_" + body.id, p.x.toFixed(1) + " " + p.z.toFixed(1));
        var bp = bodyPos(body.id), s = sunPos();
        var ox = bp.x - s.x, oz = bp.z - s.z, ol = Math.sqrt(ox * ox + oz * oz) || 1;
        var d = body.radius + STANDOFF;
        var x = bp.x + ox / ol * d, z = bp.z + oz / ol * d, y = bp.y;
        if (!carry(p, SPACE, x, y, z, () => { sendState(p); })) return;
        p.lookAt(bp.x, bp.y, bp.z);
        p.playSound(DMZ + "ui_nave_takeoff", 1, 0.8);
        p.title("&bSpace", "&7Fly into a planet to land. M: star map");
    }

    /** Touching a planet: down to its surface (DMZR landOnPlanet), at your last spot there if you have one. */
    function land(p, body) {
        var x = 0.5, z = 0.5;
        var origin = String(p.getVar("dbr_space_origin", "") || "").split(" ");
        var last = String(p.getVar("dbr_space_last_" + body.id, "") || "").split(" ");
        if (origin[0] === body.dim) { x = Number(origin[1]); z = Number(origin[3]); }
        else if (last.length === 2 && !isNaN(Number(last[0]))) { x = Number(last[0]); z = Number(last[1]); }
        else if (body.id === "demon_realm") { x = 160.5; z = 0.5; }
        var fixedY = body.id === "demon_realm" ? 745 : 0;
        setAutopilot(p, "");
        var hadPod = !!inPod(p);
        if (!carry(p, body.dim, x, fixedY || dropY(), z, (pod) => {
            if (!fixedY) settle(p, body.dim, x, z, 40);
            if (pod) p.playSound(DMZ + "ship_landing_open", 1, 1);
            sendState(p);
        })) return;
        p.title("&a" + RPG_NAME(body), "");
        if (!hadPod) p.setVelocity(0, 0, 0);
    }
    function RPG_NAME(body) {
        return { overworld: "Earth", namek: "Planet Namek", sacredkaiplanet: "Sacred World of the Kais", demon_realm: "Demon Realm" }[body.id] || body.id;
    }

    // land on the ground once the chunk is there (planets have different heights)
    function settle(p, dim, x, z, tries) {
        if (!p.alive || p.dimension !== dim) return;
        var sy = RPG.world.isLoaded(dim, Math.floor(x), Math.floor(z)) ? RPG.world.surfaceY(dim, Math.floor(x), Math.floor(z)) : -9999;
        if (sy <= -9999 && tries > 0) { RPG.world.requestChunks(dim, x, z, 1); RPG.schedule(3, () => settle(p, dim, x, z, tries - 1)); return; }
        var pod = p.getVehicle();
        var y = (sy > -9999 ? sy : 100) + 0.3;
        if (pod) { p.dismount(); pod.teleportTo(dim, x, y, z); RPG.schedule(1, () => { DBR_POD_ARRIVING[p.uuid] = true; p.mount(pod); }); }
        p.teleportTo(dim, x, y, z);
    }

    /** Below returnAltitude: the nearest planet in range, else where you took off (DMZR descend-out). */
    function leaveSpace(p) {
        var range = C.get("nearestPlanetRange") * C.get("distanceScale"), best = null, bestD = 1e18;
        loadedBodies().forEach((b) => {
            var d = dist(p, bodyPos(b.id)) - b.radius;
            if (d < range && d < bestD) { best = b; bestD = d; }
        });
        if (best) { land(p, best); return; }
        var o = String(p.getVar("dbr_space_origin", "") || "").split(" ");
        setAutopilot(p, "");
        var dim = o.length === 4 && RPG.server.hasDimension(o[0]) ? o[0] : "minecraft:overworld";
        var x = o.length === 4 ? Number(o[1]) : 0.5, z = o.length === 4 ? Number(o[3]) : 0.5;
        carry(p, dim, x, dropY(), z, () => { settle(p, dim, x, z, 40); sendState(p); });
        msg(p, "&7You drift back home.");
    }

    // ---- the per-player check (DMZR SpaceTravelModule player tick) ----
    var lastBurn = {};
    function check(p) {
        if (!p.alive || p.getGameMode() === "spectator") return;
        if (RPG.server.getTick() < (cooldown[p.uuid] || 0)) return;
        var dim = p.dimension;
        if (dim === SPACE) {
            var ap = autopilot(p);
            if (ap && !inPod(p)) { setAutopilot(p, ""); msg(p, "&7Autopilot off."); ap = ""; }
            if (p.y < C.get("returnAltitude")) { leaveSpace(p); return; }
            var bodies = loadedBodies();
            for (var i = 0; i < bodies.length; i++) {
                var b = bodies[i];
                if (ap && ap !== b.id) continue;                      // on autopilot only the target body lands you
                if (dist(p, bodyPos(b.id)) < b.radius + LANDING_MARGIN) { land(p, b); return; }
            }
            var sd = dist(p, sunPos());
            if (sd < O.SUN.danger && C.get("sunDamage") && p.getGameMode() !== "creative") {
                var heat = 1 - sd / O.SUN.danger;
                if (RPG.server.getTick() - (lastBurn[p.uuid] || 0) >= 10) {
                    lastBurn[p.uuid] = RPG.server.getTick();
                    p.damage(Math.max(1, Math.round(heat * 12)));
                    p.setFire(3);
                    msg(p, "&6The sun is burning you!");
                }
                if (sd < O.SUN.radius + 12) {
                    var s = sunPos(), k = 1.2 / (sd || 1);
                    p.setVelocity((p.x - s.x) * k, (p.y - s.y) * k, (p.z - s.z) * k);
                }
            }
            return;
        }
        var body = O.byDim(dim);
        if (!body || p.y < C.get("entryAltitude")) return;
        if (!on()) return;
        enterSpace(p, body);
        if (autopilot(p)) sendState(p);
    }

    RPG.every(5, () => {
        if (!C.get("enabled")) return;
        RPG.server.players().forEach((p) => { try { check(p); } catch (err) { RPG.log("[DBR] space: " + err); } });
    });
    RPG.on("playerJoin", (p) => { RPG.schedule(20, () => sendState(p)); });
    RPG.on("death", (p) => { if (autopilot(p)) p.setVar("dbr_space_autopilot", ""); });   // dying cancels the trip

    // ---- autopilot (called by the pod's destination list, 56_vehicles.js, and the star map) ----
    function startAutopilot(p, targetDim) {
        if (!C.get("podAutopilot") || !on() || !inPod(p)) return false;
        var b = O.byDim(targetDim);
        if (!b || !RPG.server.hasDimension(b.dim)) return false;
        if (p.dimension === b.dim) return false;
        if (p.dimension !== SPACE && !O.byDim(p.dimension)) return false;   // rooms (time chamber, otherworld) jump as before
        setAutopilot(p, b.id);
        p.playSound(DMZ + "ui_nave_takeoff", 1, 1);
        msg(p, "&bAutopilot: " + RPG_NAME(b) + (p.dimension === SPACE ? "" : " (climbing out)"));
        return true;
    }
    RPG.net.on("dbr_space_autopilot", (p, d) => {
        var id = String(d && d.id || "");
        if (!id) { if (autopilot(p)) { setAutopilot(p, ""); msg(p, "&7Autopilot off."); } return; }
        var b = O.byId(id);
        if (!b) return;
        if (!inPod(p)) { msg(p, "&cThe autopilot needs a space pod."); return; }
        if (!startAutopilot(p, b.dim)) msg(p, "&cThe autopilot can't reach " + RPG_NAME(b) + ".");
    });
    RPG.net.on("dbr_space_hello", (p) => sendState(p));

    // ---- planet info (DMZR PlanetInfoServer: who is on each world) ----
    RPG.net.on("dbr_space_info", (p, d) => {
        var b = O.byId(String(d && d.id || ""));
        if (!b) return;
        var here = RPG.server.players().filter((q) => q.dimension === b.dim).map((q) => q.name);
        RPG.net.send(p, "dbr_space_info", { id: b.id, name: RPG_NAME(b), loaded: RPG.server.hasDimension(b.dim), players: here.slice(0, 8), count: here.length,
            visited: !!p.getVar("dbr_space_last_" + b.id, "") || String(p.getVar("dbr_space_origin", "")).indexOf(b.dim + " ") === 0 });
    });

    return { on: on, bodyPos: bodyPos, startAutopilot: startAutopilot, name: RPG_NAME, enterSpace: enterSpace, land: land };
})();

function dbrSpaceAvailable() { return DBR_SPACE.on(); }
function dbrSpaceAutopilot(p, dim) { return DBR_SPACE.startAutopilot(p, dim); }

// /rpgc space: enter space from where you stand (ops: testing; DMZR /space)
RPG.commands.register("space", {
    permission: 2, description: "/rpgc space - go to space beside this planet",
    run(p) {
        if (!p) return;
        var b = DBR_SPACE_ORBITS.byDim(p.dimension);
        if (!b) { p.sendMessage("&cYou're not on a planet."); return; }
        if (!DBR_SPACE.on()) { p.sendMessage("&cThe space dimension isn't loaded: restart the world once."); return; }
        DBR_SPACE.enterSpace(p, b);
    }
});
