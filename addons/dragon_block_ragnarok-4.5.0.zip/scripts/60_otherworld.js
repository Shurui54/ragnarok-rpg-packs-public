// =====================================================================================
//  60_otherworld.js - dying sends you to King Yemma in the Other World (DragonMine Z)
// =====================================================================================
//  Ported from DragonMine Z (GPL-3.0): ForgeCommonEvents.onPlayerDeath, TickHandler
//  .handleOtherworldTransfer, BabaReviveService, BabaReviveEvents, NPCActionC2S (enma/baba/
//  grandkai/announcer), OtherworldDimension, OtherworldTournamentGrounds, HaloCommand,
//  ReviveCommand, ReviveWish.
//
//  How it works (same as DMZ):
//   - You die: you respawn as usual (vanilla keeps/drops items as usual), then you are a dead
//     soul: a halo, sent to the spirit arrival in front of King Yemma's desk (0.5, 150, -44.5).
//     Dead souls who leave the Other World are pulled back.
//   - Fortuneteller Baba (next to Yemma) lends you 1 hour among the living (after a 180 s
//     cooldown since your death). The hour only runs outside the Other World, faster in some
//     worlds and in strong forms. Killed while borrowing time = knocked out, not dead.
//     When it runs out you return to the Other World and wait one in-game day.
//   - King Yemma sends you back to your respawn point once you are alive or borrowing time.
//   - A Dragon Ball revive wish (dmzRevive) or /rpgc revive brings you back for good.
//   - While dead in the Other World you never get hungry and train twice as fast.
//  Settings: ragnarok_rpg/config/dbr_otherworld.json (DMZ GeneralServerConfig defaults).
// =====================================================================================

var OTHERWORLD_DIM = "ragnarok_rpg:otherworld";
var OW_SPIRIT_ARRIVAL = [0.5, 150, -44.5, 0];          // OtherworldDimension.SPIRIT_ARRIVAL, yaw 0
var OW_TOURNAMENT_ARRIVAL = [-25.5, 352, -1161.5, 180]; // OtherworldTournamentGrounds.ARRIVAL
var OW_GRAND_KAI_RETURN = [-30.5, 150, 10.5, 0];       // OtherworldTournamentGrounds.GRAND_KAI_RETURN

var OW_CFG = dbrConfig("dbr_otherworld", {
    otherworldActive: true,
    reviveCooldownSeconds: 180,
    babaTemporaryRevive: true,
    babaTempReturnSeconds: 3600,
    babaTimeMultiplierPerWorld: {
        "minecraft:overworld": 1.0, "minecraft:the_nether": 2.0, "minecraft:the_end": 3.0,
        "ragnarok_rpg:namek": 1.0, "ragnarok_rpg:time_chamber": 5.0, "ragnarok_rpg:sacredkaiplanet": 1.0
    },
    defaultBabaTimeMultiplier: 1.0,
    babaHardcoreEnabled: false,
    babaHardcoreCooldownGrowth: 0.5,
    otherworldDeadTpMultiplier: 2.0
});

var OW_WARNINGS = [1800, 600, 300, 60, 30, 10, 5];      // BabaReviveService.WARNING_SECONDS
var OW_KO_TICKS = 600, OW_AGGRO_GRACE_TICKS = 300;
var OW_RETRY_DAY_TICKS = 24000;

// A knocked-out borrowed body: can't move, fight or heal, can't be hurt (KNOCKDOWN_* cooldowns).
RPG.effects.define("dmz_knocked_out", {
    name: "&cKnocked Out", hidden: false, beneficial: false,
    flags: ["noMove", "noJump", "noAttack", "noSkills", "noKeys", "noRegen", "invulnerable"]
});

// ---- state ------------------------------------------------------------------------------
function owFmt(totalSeconds) {
    let s = Math.max(0, Math.floor(totalSeconds));
    let h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
    let two = (n) => (n < 10 ? "0" : "") + n;
    return h > 0 ? h + ":" + two(m) + ":" + two(r) : m + ":" + two(r);
}
function owFmtMult(x) {
    if (Math.abs(x - Math.round(x)) < 0.005) return "x" + Math.round(x);
    return "x" + String(x.toFixed(2)).replace(/0+$/, "").replace(/\.$/, "");
}
function owInOtherworld(p) { return p.dimension === OTHERWORLD_DIM; }
function owIsAlive(p) { return !p.getVar("dmz_dead", false); }
function owTemp(p) { return Number(p.getVar("dmz_temp", 0)) || 0; }
function owTempActive(p) { return !owIsAlive(p) && owTemp(p) > 0; }
function owKnockedOut(p) { return (Number(p.getVar("dmz_ko", 0)) || 0) > 0; }
function owHidden(p) { return (Number(p.getVar("dmz_aggro_grace", 0)) || 0) > 0; }
function owCanEnmaReturn(p) { return owIsAlive(p) || owTempActive(p); }
function owTempEnabled() { return !!OW_CFG.otherworldActive && !!OW_CFG.babaTemporaryRevive; }
function owDayTime() { return Number(RPG.world.getTime("")) || 0; }
function owGameMode(p) { return String(p.getGameMode()); }
function owSkipMode(p) { let g = owGameMode(p); return g === "creative" || g === "spectator"; }

// Strong forms drain the borrowed time faster (FormData.otherworldTimeDrain). Other scripts can set
// DMZ_FORM_TIME_DRAIN = function(player) { return extra; } (0 = none); DMZ adds (drain - 1) per active form.
function owFormMult(p) {
    let extra = 0;
    try { if (typeof DMZ_FORM_TIME_DRAIN === "function") extra = Number(DMZ_FORM_TIME_DRAIN(p)) || 0; } catch (e) { extra = 0; }
    return 1 + Math.max(0, extra);
}
function owWorldMult(p) {
    let m = OW_CFG.babaTimeMultiplierPerWorld || {};
    let v = m[p.dimension];
    return v === undefined || v === null ? Math.max(0, Number(OW_CFG.defaultBabaTimeMultiplier) || 1) : Number(v);
}
function owEscalation(p) {
    if (!OW_CFG.babaHardcoreEnabled) return 1;
    let repeats = Math.max(0, (Number(p.getVar("dmz_temp_uses", 0)) || 0) - 1);
    return Math.min(5.0, Math.pow(1.5, repeats));
}
function owTotalMult(p) {
    if (owInOtherworld(p)) return 0;
    return owFormMult(p) * owWorldMult(p) * owEscalation(p);
}

// TP multiplier while dead in the Other World (StatsData.getTpOtherworldMultiplier).
// 09_dmz_stats.js gives DMZ TP; it can add (dmzOtherworldTpMult(p) - 1) to its multiplier.
function dmzOtherworldTpMult(p) {
    return !owIsAlive(p) && owInOtherworld(p) ? Number(OW_CFG.otherworldDeadTpMultiplier) || 2 : 1;
}

// ---- teleports ------------------------------------------------------------------------
function owToSpiritArrival(p) {
    if (typeof dmzEnsureOtherworld === "function") dmzEnsureOtherworld();      // 65_dmz_structures.js
    p.teleportTo(OTHERWORLD_DIM, OW_SPIRIT_ARRIVAL[0], OW_SPIRIT_ARRIVAL[1], OW_SPIRIT_ARRIVAL[2], OW_SPIRIT_ARRIVAL[3], 0);
    if (!owPalaceReady()) owHoldUntilPalace(p);
}

// While Yemma's palace is still being built (a new world, or rebuilt after its chunks were regenerated) there is no
// floor at the arrival point and the soft clouds drop you into Hell: keep the spirit where it arrived until it's done.
function owPalaceReady() {
    if (typeof dmzBuilt !== "function") return true;
    let b = dmzBuilt()["ow_palace"];
    // done, and (once per server run) seen to still be there - see dmzStillThere in 65_dmz_structures.js
    return !!(b && b.done) && (typeof DMZ_VERIFIED === "undefined" || !!DMZ_VERIFIED["ow_palace"]);
}
var OW_HOLDING = {};
function owHoldUntilPalace(p) {
    if (OW_HOLDING[p.uuid]) return;
    OW_HOLDING[p.uuid] = true;
    p.actionbar("&eKing Yemma's palace is being prepared...");
    let tries = 0;
    (function hold() {
        if (!p.alive || !owInOtherworld(p)) { delete OW_HOLDING[p.uuid]; return; }
        if (typeof dmzEnsureOtherworld === "function" && tries % 10 === 0) dmzEnsureOtherworld();
        if (owPalaceReady() || ++tries > 20 * 120) {
            delete OW_HOLDING[p.uuid];
            p.teleportTo(OTHERWORLD_DIM, OW_SPIRIT_ARRIVAL[0], OW_SPIRIT_ARRIVAL[1], OW_SPIRIT_ARRIVAL[2], OW_SPIRIT_ARRIVAL[3], 0);
            p.setVelocity(0, 0, 0);
            return;
        }
        if (Math.abs(p.y - OW_SPIRIT_ARRIVAL[1]) > 1 || Math.abs(p.x - OW_SPIRIT_ARRIVAL[0]) > 3 || Math.abs(p.z - OW_SPIRIT_ARRIVAL[2]) > 3)
            p.teleport(OW_SPIRIT_ARRIVAL[0], OW_SPIRIT_ARRIVAL[1], OW_SPIRIT_ARRIVAL[2]);
        p.setVelocity(0, 0, 0);
        if (tries % 40 === 0) p.actionbar("&eKing Yemma's palace is being prepared...");
        RPG.schedule(1, hold);
    })();
}

// BabaReviveService.teleportToLivingWorld: your respawn point (not in the Other World), else world spawn.
function owToLivingWorld(p) {
    let home = p.getVar("dmz_home", null);
    if (home && home.length >= 4 && home[0] !== OTHERWORLD_DIM) {
        p.teleportTo(home[0], home[1], home[2], home[3], home.length > 4 ? home[4] : 0, 0);
        return;
    }
    let sp = RPG.world.spawnPoint();
    let x = Number(sp.x) + 0.5, z = Number(sp.z) + 0.5;
    p.teleportTo("minecraft:overworld", x, Number(sp.y) + 1, z, 0, 0);
    RPG.schedule(2, () => {
        let y = RPG.world.surfaceY("minecraft:overworld", Math.floor(x), Math.floor(z));
        if (y > -9999) p.teleport(x, y, z);
    });
}

// ---- death (ForgeCommonEvents.onPlayerDeath) --------------------------------------------
RPG.on("death", (p, killer) => {
    p.setVar("dmz_deaths", (Number(p.getVar("dmz_deaths", 0)) || 0) + 1);
    if (!OW_CFG.otherworldActive) return;
    if (owTemp(p) > 0) {
        p.setVar("dmz_temp_ready_at", owDayTime() + OW_RETRY_DAY_TICKS);
    } else if (owIsAlive(p)) {
        let cd = Number(OW_CFG.reviveCooldownSeconds) || 0;
        if (OW_CFG.babaHardcoreEnabled) {
            cd = Math.round(cd * (1 + (Number(OW_CFG.babaHardcoreCooldownGrowth) || 0) * Math.max(0, p.getVar("dmz_deaths", 1) - 1)));
        }
        p.setVar("dmz_baba_cd", (Number(p.getVar("dmz_baba_cd", 0)) || 0) + cd * 20);
    }
    p.setVar("dmz_spirit_pending", true);
    p.setVar("dmz_temp", 0);
    p.setVar("dmz_ko", 0);
    p.setVar("dmz_aggro_grace", 0);
    if (p.getVar("dmz_created", 0)) p.setVar("dmz_dead", true);
    p.setVar("dmz_in_kaio_planet", true);
});

// Respawn: remember the respawn point for King Yemma, then the next tick goes to the Other World.
RPG.on("respawn", (p) => {
    RPG.schedule(1, () => {
        if (!owInOtherworld(p)) p.setVar("dmz_home", [p.dimension, p.x, p.y, p.z, p.getYaw()]);
        owTransferCheck(p, true);
    });
});

// TickHandler.handleOtherworldTransfer: dead souls (not borrowing time) belong in the Other World.
function owShouldTransfer(p) {
    return !!OW_CFG.otherworldActive && p.alive && !owIsAlive(p) && owTemp(p) <= 0 && !owSkipMode(p)
        && (!owInOtherworld(p) || p.getVar("dmz_spirit_pending", false));
}
function owTransferCheck(p, now) {
    if (!owShouldTransfer(p)) {
        if (owIsAlive(p) || owTemp(p) > 0) p.setVar("dmz_spirit_pending", null);
        return;
    }
    p.setVar("dmz_spirit_pending", null);
    owToSpiritArrival(p);
    if (now) p.title("&eThe Other World", "&7King Yemma is waiting for you");
}

// ---- once a second ----------------------------------------------------------------------
RPG.on("playerTick", (p) => {
    let cd = Number(p.getVar("dmz_baba_cd", 0)) || 0;
    if (cd > 0) p.setVar("dmz_baba_cd", Math.max(0, cd - 20));
    let grace = Number(p.getVar("dmz_aggro_grace", 0)) || 0;
    if (grace > 0) {
        p.setVar("dmz_aggro_grace", Math.max(0, grace - 20));
        owDropAggro(p, false);                              // LivingChangeTargetEvent cancel
    }
    owTransferCheck(p, false);
    let dead = !owIsAlive(p);
    if (dead && owInOtherworld(p) && p.getFood() < 20) p.setFood(20);
    owHalo(p, (dead || p.getVar("dmz_force_halo", false)) && !owSkipModeHidden(p));
    if (OW_CFG.otherworldActive) owTickTempReturn(p);
});
function owSkipModeHidden(p) { return owGameMode(p) === "spectator"; }

// The halo (DMZRacePartsLayer "halo" bone of raceparts.geo.json, colour #FFF461 at 75%): every avatar has it as a
// part shown while the look value "halo" is set (20_races.js), so all players see it.
var OW_HALO_ON = {};
function owHalo(p, on) {
    if (!!OW_HALO_ON[p.uuid] === on) return;
    OW_HALO_ON[p.uuid] = on;
    p.setColor("halo", on ? "1" : null);
}

// BabaReviveService.tickTempReturn
function owTickTempReturn(p) {
    let timer = owTemp(p);
    if (timer <= 0 || owIsAlive(p)) return;
    if (owKnockedOut(p)) { owKnockoutRecovery(p); return; }
    if (owInOtherworld(p)) return;
    let drained = Math.round(20 * owTotalMult(p));
    let remaining = Math.max(0, timer - drained);
    p.setVar("dmz_temp", remaining);
    if (remaining <= 0) { owEndTempReturn(p); return; }
    let before = Math.floor(timer / 20), after = Math.floor(remaining / 20);
    for (let i = 0; i < OW_WARNINGS.length; i++) {
        if (after <= OW_WARNINGS[i] && before > OW_WARNINGS[i]) {
            p.actionbar("&eTime left among the living: &6" + owFmt(after));
            break;
        }
    }
    if (after % 60 === 0 || after <= 10) p.actionbar("&dBorrowed time: &f" + owFmt(after));
}

function owEndTempReturn(p) {
    p.setVar("dmz_temp", 0);
    p.setVar("dmz_temp_ready_at", owDayTime() + OW_RETRY_DAY_TICKS);
    owClearKnockout(p);
    p.tell("&cYour time among the living has run out...");
    if (!owSkipMode(p)) owToSpiritArrival(p);
}

// ---- knock-out instead of death while borrowing time (BabaReviveEvents.onPlayerDeath) --------
RPG.on("lethal", (e) => {
    let p = e.target && e.target.isPlayer() ? e.target.asPlayer() : null;
    if (!p || !owTempActive(p) || owKnockedOut(p) || owInOtherworld(p)) return;
    if (e.type === "minecraft:out_of_world" || e.type === "minecraft:generic_kill") return;   // bypasses invulnerability
    e.cancel();
    p.health = 1;
    owKnockOut(p);
});

function owKnockOut(p) {
    let total = (Number(OW_CFG.babaTempReturnSeconds) || 3600) * 20;
    let timer = owTemp(p);
    let cut = Math.round(Math.max(timer * 0.20, total * 0.05));
    p.setVar("dmz_temp", Math.max(1, timer - cut));
    p.setVar("dmz_ko", OW_KO_TICKS);
    p.setVar("dmz_aggro_grace", OW_KO_TICKS + OW_AGGRO_GRACE_TICKS);
    p.addEffect("dmz_knocked_out", OW_KO_TICKS);
    p.addPotion("minecraft:glowing", OW_KO_TICKS, 0);
    if (typeof dmzClearForms === "function") dmzClearForms(p);          // forms script, if it offers one
    owDropAggro(p, true);
    p.tell("&cYour borrowed body gives out... you lose &e" + owFmt(Math.max(1, cut / 20)) + "&c of your time among the living.");
}

// Heal toward 33% health / 50% ki and stamina over the 30 s knock-out.
function owKnockoutRecovery(p) {
    let ko = Math.max(0, (Number(p.getVar("dmz_ko", 0)) || 0) - 20);
    p.setVar("dmz_ko", ko);
    let secs = OW_KO_TICKS / 20;
    let hp = p.maxHealth * 0.33;
    if (p.health < hp) p.health = Math.min(hp, p.health + hp / secs);
    ["ki", "stamina"].forEach((r) => {
        try {
            let max = p.maxResource(r), target = max * 0.5, cur = p.resource(r);
            if (max > 0 && cur < target) p.setResource(r, Math.min(target, cur + target / secs));
        } catch (err) { /* resource not defined */ }
    });
    if (ko <= 0) owClearKnockout(p);
}

function owClearKnockout(p) {
    if (!owKnockedOut(p) && !p.hasEffect("dmz_knocked_out")) return;
    p.setVar("dmz_ko", 0);
    p.removeEffect("dmz_knocked_out");
    p.removePotion("minecraft:glowing");
}

// Mobs within 64 blocks that target this player forget them.
function owDropAggro(p, all) {
    RPG.world.entitiesNear(p.dimension, p.x, p.y, p.z, 64).forEach((m) => {
        if (m.isPlayer()) return;
        let t = m.target;
        if (t && t.isPlayer() && t.getUuid() === p.getUuid()) { m.target = null; if (all) m.stopMoving(); }
    });
}

// No healing while knocked out (BabaReviveEvents.onHeal); the recovery above sets health directly.
RPG.on("heal", (entity, amount) => {
    if (entity.isPlayer() && owKnockedOut(entity.asPlayer())) return false;
});

// ---- Baba, Yemma, revive ----------------------------------------------------------------
// BabaReviveService.handleBabaRevive. Returns the message shown.
function owBabaRevive(p) {
    if (owIsAlive(p)) return "&cYou are already alive. Talk to King Yemma to return to Earth.";
    let cd = Number(p.getVar("dmz_baba_cd", 0)) || 0;
    if (cd > 0) return "&cBaba cannot help you yet. Wait &e" + owFmt(Math.max(1, cd / 20)) + "&c.";
    if (!owTempEnabled()) {
        p.setVar("dmz_dead", null); p.setVar("dmz_temp", 0); p.setVar("dmz_temp_uses", 0); p.setVar("dmz_temp_ready_at", 0);
        return "&dFortuneteller Baba&f: You have been revived! Go back to &eKing Yemma&f to return to Earth.";
    }
    if (owTempActive(p)) return "&eBaba already lent you her time. Talk to King Yemma to return to Earth.";
    let day = owDayTime(), readyAt = Number(p.getVar("dmz_temp_ready_at", 0)) || 0;
    if (readyAt > day) return "&cThe spirits need a full day to gather your time again. Wait &e" + owFmt(Math.max(1, (readyAt - day) / 20)) + "&c of Overworld time (sleeping speeds it up).";
    let seconds = Number(OW_CFG.babaTempReturnSeconds) || 3600;
    p.setVar("dmz_temp", seconds * 20);
    p.setVar("dmz_temp_uses", (Number(p.getVar("dmz_temp_uses", 0)) || 0) + 1);
    let esc = owEscalation(p);
    if (esc > 1) return "&dBaba lends you &b" + owFmt(seconds) + "&d among the living, but the spirits grow impatient: your time now runs at &6" + owFmtMult(esc) + "&d. Talk to &eKing Yemma&d to return to Earth.";
    return "&dBaba lends you &b" + owFmt(seconds) + "&d among the living. Talk to &eKing Yemma&d to return to Earth. Powerful transformations will shorten your stay!";
}

// BabaReviveService.handleEnmaReturn
function owEnmaReturn(p) {
    if (!owCanEnmaReturn(p)) { p.tell("&cYou need to talk to Fortuneteller Baba first!"); return; }
    owToLivingWorld(p);
}

// BabaReviveService.reviveFully (Dragon Ball revive wish, /rpgc revive). Like DMZ, it does not
// teleport: the revived player asks King Yemma for the way down. teleportHome = true sends them now.
function dmzRevive(p, teleportHome) {
    p.setVar("dmz_baba_cd", 0);
    p.setVar("dmz_temp", 0);
    p.setVar("dmz_temp_uses", 0);
    p.setVar("dmz_temp_ready_at", 0);
    owClearKnockout(p);
    if (!owIsAlive(p)) {
        p.setVar("dmz_dead", null);
        p.health = p.maxHealth;
        p.tell("&aYou have been revived! Talk to King Yemma to go back to the Overworld.");
    }
    p.setVar("dmz_spirit_pending", null);
    if (teleportHome && owInOtherworld(p)) owToLivingWorld(p);
}
function dmzIsDead(p) { return !owIsAlive(p); }
function dmzDeadPlayers() { return RPG.server.players().filter((p) => !owIsAlive(p)); }
function dmzBorrowedSeconds(p) { return Math.floor(owTemp(p) / 20); }

// ---- NPCs and dialogue --------------------------------------------------------------------
function owPick(list, p) { return list[RPG.randomInt(0, list.length - 1)].replace("%s", p.getDisplayName()); }

// King Yemma (master_enma). Replaces the dialogue from 60_npcs_dialogue.js.
RPG.dialogues.define("enma", {
    start: "start",
    nodes: {
        start: {
            text: (p) => {
                if (owTempActive(p)) return owPick(["So Baba vouched for you, %s. Very well, I will send you back among the living, but remember: your time down there is borrowed. When it runs out, you return here."], p);
                if (!owIsAlive(p)) return owTempEnabled()
                    ? owPick(["You are still dead, %s. Fortuneteller Baba can lend you some time among the living. Convince her first, then come back and I will send you down."], p)
                    : owPick(["You are still dead, %s. Talk to Fortuneteller Baba first; only once she revives you can I send you back to Earth.",
                        "Name: %s. Status: deceased. I cannot simply undo that, you know. Fortuneteller Baba handles revivals. See her first, then come back to my desk.",
                        "No, no, no, %s, you cannot skip the queue. The dead stay up here unless Fortuneteller Baba revives them. Go talk to her first."], p);
                return owPick(["Welcome to the Otherworld, %s. I am King Yemma, the overseer of souls. Do you want to come back to Earth?",
                    "Hmm? A living soul wandering around my office, %s? Highly irregular. If you are done sightseeing, I can send you back to Earth.",
                    "Next! Oh, it's you, %s, and still breathing. Don't clutter up my line. Say the word and I will send you down to the world of the living."], p);
            },
            options: [
                { text: "Return to Earth", condition: (p) => owCanEnmaReturn(p), action: (p) => { owEnmaReturn(p); } },
                { text: "&8Return to Earth &7(Fortuneteller Baba has to help you first.)", condition: (p) => !owCanEnmaReturn(p), next: "need_baba" },
                { text: "Where is Snake Way?", next: "snake" },
                { text: "Goodbye." }
            ]
        },
        need_baba: { text: "You need to talk to Fortuneteller Baba first!", options: [{ text: "...", next: "start" }] },
        snake: {
            text: "Behind my palace. Follow the road ten thousand miles and you reach King Kai's planet. Don't fall off: Hell is below the clouds.",
            options: [{ text: "Take me to the start of Snake Way.", action: (p) => { owSnakeWayStart(p); } }, { text: "Thanks." }]
        }
    }
});
function owSnakeWayStart(p) {
    let y = RPG.world.surfaceY(OTHERWORLD_DIM, 0, 74);
    p.teleportTo(OTHERWORLD_DIM, 0.5, y > -9999 ? y : 152, 74.5, 0, 0);
}

// Fortuneteller Baba in the Other World (master_uranai, DMZ placement master_baba).
RPG.npcs.define("dmz_baba", { name: "&5Fortuneteller Baba", geo: masterLook("uranai", "uranai_idle"), dialogue: "dmz_baba" });
RPG.dialogues.define("dmz_baba", {
    start: "start",
    nodes: {
        start: {
            text: (p) => {
                if (owIsAlive(p)) return owPick(["Ohohoho! You are very much alive, %s. There is nothing for me to revive. Talk to King Yemma if you want to go back to Earth.",
                    "Your heart is still beating, %s. I can hear it from here! Save my rituals for the dead, dearie, and see King Yemma if you need a ride down.",
                    "Ohohoho, a living customer! How rare. I'm afraid there is nothing to revive, %s. If you want to go home, King Yemma can send you."], p);
                if (owTempActive(p)) return owPick(["I already lent you my time, %s. Go see King Yemma and he will send you down to Earth. Your borrowed time does not run while you are up here."], p);
                if (owTempEnabled()) return "Greetings " + p.getDisplayName() + ", I am Fortuneteller Baba. I cannot truly revive you, dearie, but I can lend you about "
                    + Math.round((Number(OW_CFG.babaTempReturnSeconds) || 3600) / 60) + " minutes among the living. Powerful transformations burn that time faster, and only the Dragon Balls can make it permanent. Shall I?";
                return owPick(["Greetings %s, I am Fortuneteller Baba. I can bring you back to the world of the living for good. Shall I perform the ritual?",
                    "Ohohoho! Another wandering soul, %s. Don't look so glum, dearie. My crystal ball says your story isn't finished yet. Shall I bring you back?",
                    "My, my, %s, you look rather transparent today. Lucky for you, I know a ritual or two. Say the word and I will return you to the living for good."], p);
            },
            options: [
                { text: (p) => owTempEnabled() ? "Borrow time" : "Revive", condition: (p) => !owIsAlive(p) && !owTempActive(p),
                  action: (p) => { let msg = owBabaRevive(p); p.tell(msg); return owIsAlive(p) || owTempActive(p) ? "done" : "wait"; } },
                { text: "Goodbye." }
            ]
        },
        done: { text: (p) => ["Ohohoho! The ritual is done. Now hurry to King Yemma before the spirits change their minds.",
            "There, the spirits agreed. Off you go, dearie, King Yemma is expecting you."][RPG.randomInt(0, 1)], options: [{ text: "Thank you, Baba!" }] },
        wait: { text: "The spirits are not ready yet, dearie. Even the dead cannot be rushed into these things!", options: [{ text: "..." }] }
    }
});

// The Other World Tournament announcer (master_otherworld_announcer): "Return" goes back to Grand Kai.
RPG.dialogues.define("otherworld_announcer", {
    start: "start",
    nodes: {
        start: {
            text: (p) => owPick(["Welcome to the Otherworld Tournament grounds, %s! The greatest warriors of every age fight right here, and the ring is open. Whenever you want to leave, I'll send you back to the Grand Kai.",
                "Ladies and gentlemen... oh, it's you, %s! Ready to step into the ring with legends from every age? I can send you back to the Grand Kai.",
                "Welcome back to the Otherworld Tournament, %s! The crowd is restless and the fighters are eager. Talk to me to head back."], p),
            options: [{ text: "Return", action: (p) => { owTeleportBackToGrandKai(p); } }, { text: "Cool." }]
        }
    }
});

// Grand Kai's "Tournament" option (60_npcs_dialogue.js calls this).
function owTeleportFromGrandKai(p) {
    let pct = typeof dmzBuildPercent === "function" ? dmzBuildPercent("ow_tournament") : 100;
    if (pct < 100) {
        if (typeof dmzEnsureTournament === "function") dmzEnsureTournament();
        p.actionbar("&eThe tournament grounds are still being prepared (" + pct + "%). Come back in a moment!");
        return;
    }
    p.teleportTo(OTHERWORLD_DIM, OW_TOURNAMENT_ARRIVAL[0], OW_TOURNAMENT_ARRIVAL[1], OW_TOURNAMENT_ARRIVAL[2], OW_TOURNAMENT_ARRIVAL[3], 0);
}
function owTeleportBackToGrandKai(p) {
    p.teleportTo(OTHERWORLD_DIM, OW_GRAND_KAI_RETURN[0], OW_GRAND_KAI_RETURN[1], OW_GRAND_KAI_RETURN[2], OW_GRAND_KAI_RETURN[3], 0);
}

// The hell ogre by Yemma's desk (quest_npc hell_ogre).
RPG.npcs.define("hell_ogre", { name: "&cHell Ogre", geo: sagaLook("saga_ogre", "saga_ogre_red"), dialogue: "hell_ogre" });
RPG.dialogues.define("hell_ogre", {
    start: "start",
    nodes: { start: { text: "Line up for King Yemma! Good souls go to Heaven, bad ones go down below the clouds to Hell. Don't fall off Snake Way!", options: [{ text: "Okay." }] } }
});

// ---- commands (DMZ /dmzrevive and /dmzhalo) -------------------------------------------------
function owTargets(player, args, index) {
    if (args.length > index) {
        let t = RPG.server.player(args[index]);
        return t ? [t] : [];
    }
    return player ? [player] : [];
}
RPG.commands.register("revive", {
    description: "Revive yourself or a player (DMZ /dmzrevive)",
    permission: 2,
    run(player, args) {
        let list = owTargets(player, args, 0);
        list.forEach((t) => dmzRevive(t, false));
        if (player) player.tell(list.length ? "&aRevived " + list.map((t) => t.getName()).join(", ") : "&cNo such player.");
    }
});
RPG.commands.register("halo", {
    description: "Show or hide a halo: /rpgc halo on|off [player] (DMZ /dmzhalo)",
    permission: 2,
    run(player, args) {
        let on = String(args[0] || "on") !== "off";
        let list = owTargets(player, args, 1);
        list.forEach((t) => t.setVar("dmz_force_halo", on ? true : null));
        if (player) player.tell("&e[DMZ-Halo]&r Halo " + (on ? "enabled" : "disabled") + " for " + list.map((t) => t.getName()).join(", "));
    }
});
RPG.commands.register("otherworld", {
    description: "Your Other World status (dead/alive, Baba's time)",
    run(player, args) {
        if (!player) return;
        if (owIsAlive(player)) { player.tell("&aYou are alive."); return; }
        let cd = Number(player.getVar("dmz_baba_cd", 0)) || 0;
        player.tell("&eYou are dead." + (owTempActive(player) ? " &dBorrowed time left: " + owFmt(owTemp(player) / 20) : "")
            + (cd > 0 ? " &7Baba can help you in " + owFmt(cd / 20) + "." : ""));
    }
});
