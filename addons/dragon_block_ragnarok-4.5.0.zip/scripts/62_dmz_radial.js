// =====================================================================================
//  62_dmz_radial.js - server side of DMZ's radial utility menu (client/scripts/45_transform.js)
// =====================================================================================
//  The radial menu sends { node, value } on the "dmz_radial" channel for every node that is
//  not a form/stack/racial-mode/descend/aura/eject action (those go to 31_dmz_transform.js on
//  "dmz_tf"). Live here: the release limit (DMZ SetReleaseLimitC2S + TickHandler cap) and
//  the Fly toggle (same as the F key). Everything else is routed to the system that owns it
//  once it exists, otherwise the player gets "not available yet":
//
//    node             value              routed to (first that exists)
//    fly              wanted on/off      DMZ_FLIGHT.toggle(p)            else F-key flight (45_keys.js)
//    flight_mode      0 search/1 combat  DMZ_FLIGHT.setMode(p, v)
//    flight_speed     5..100             DMZ_FLIGHT.setSpeedLimit(p, v)
//    flight_lock      wanted on/off      DMZ_FLIGHT.toggleLock(p)
//    skill_toggle     skill id           DMZ_SKILLS.toggle(p, id)  /  DMZ_TECH.toggleSkill(p, id)
//    friendly_fist    wanted on/off      DMZ_KIWEAPON.toggleFriendlyFist(p) (79_dmz_kiweapon.js)  /  DMZ_TECH / DMZ_COMBAT
//    kiweapon         blade|clawlance|scythe  DMZ_KIWEAPON.selectKiWeapon(p, type)  /  DMZ_TECH.selectKiWeapon(p, type)
//    fusion           wanted on/off      DMZ_FUSION.toggleMode(p)
//    namek_regen      true               DMZ_RACIAL_EXT.namekRegen(p)
//    bio_skill        drain|explode      DMZ_RACIAL_EXT.selectBioSkill(p, v)
//    tail             wanted visible     DMZ_RACIAL_EXT.toggleTail(p)
//    racial_mode      "human"            DMZ_RACIAL_EXT.selectRacial(p, race)   (Absorption Barrier)
//  Any owner may instead export radial(p, node, value) and return true when it handled it.
//
//  Vars the menu reads (the owners should keep them up to date; all optional):
//    dmz_release_limit 0|5..max     dmz_skill_active {id: true}     dmz_kiweapon "blade"
//    dmz_flight_mode 0|1            dmz_flight_lock 0|1             dmz_flight_speed_limit 0|5..100
//    dmz_friendly_fist 0|1          dmz_regen_state 0 ready|1 active|2 cooldown
//    dmz_bio_skill "drain"|"explode"  dmz_tail_visible 0|1          dmz_action "FUSION" (fusion mode)
//
//  The sector art (resources/assets/dbr/textures/gui/radial/sector_l*.png) is generated: one
//  annular-sector mask per inner/outer radius ratio, see the table in 45_transform.js (docs/dmz-spec/tools/gen_radial_sectors.py makes them).
// =====================================================================================
var DMZ_RADIAL_SERVER = (function () {
    function num(v, d) { v = Number(v); return isNaN(v) ? d : v; }
    function g(name) {
        switch (name) {
            case "DMZ_TECH": return typeof DMZ_TECH !== "undefined" ? DMZ_TECH : null;
            case "DMZ_FLIGHT": return typeof DMZ_FLIGHT !== "undefined" ? DMZ_FLIGHT : null;
            case "DMZ_FUSION": return typeof DMZ_FUSION !== "undefined" ? DMZ_FUSION : null;
            case "DMZ_RACIAL_EXT": return typeof DMZ_RACIAL_EXT !== "undefined" ? DMZ_RACIAL_EXT : null;
            case "DMZ_COMBAT": return typeof DMZ_COMBAT !== "undefined" ? DMZ_COMBAT : null;
            case "DMZ_SKILLS": return typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS : null;
            case "DMZ_KIWEAPON": return typeof DMZ_KIWEAPON !== "undefined" ? DMZ_KIWEAPON : null;
            default: return null;
        }
    }
    // try each [global, method, args...] in turn; true once one handled it
    function route(p, node, value, targets) {
        for (var i = 0; i < targets.length; i++) {
            var t = targets[i], o = g(t[0]);
            if (!o) continue;
            try {
                if (typeof o.radial === "function" && o.radial(p, node, value) === true) return true;
                if (typeof o[t[1]] === "function") { o[t[1]].apply(o, [p].concat(t.slice(2))); return true; }
            } catch (e) {
                RPG.log("dmz_radial " + node + " -> " + t[0] + "." + t[1] + " failed: " + e);
                return true;
            }
        }
        return false;
    }
    function notYet(p) { p.actionbar("&7Not available yet."); }

    // ---- release limit (SetReleaseLimitC2S) --------------------------------------------
    function maxRelease(p) {
        var mult = p.race === "saiyan" ? 1 + Math.min(0.15, num(p.getVar("dmz_zenkai_release", 0), 0)) : 1;
        return DMZ_F.maxRelease(num(p.getVar("dmz_potential", 0), 0), mult);
    }
    function setReleaseLimit(p, limit) {
        var max = maxRelease(p), next;
        limit = Math.floor(num(limit, 0));
        if (limit <= 0) next = 0;
        else next = Math.max(5, Math.min(max, Math.floor(limit / 5) * 5));
        p.setVar("dmz_release_limit", next);
        if (next > 0 && num(p.getVar("dmz_release", 0), 0) > next) p.setVar("dmz_release", next);
    }
    // TickHandler.chargePowerRelease: the release never climbs past the limit
    RPG.every(1, function () {
        RPG.server.players().forEach(function (p) {
            var lim = num(p.getVar("dmz_release_limit", 0), 0);
            if (lim > 0 && num(p.getVar("dmz_release", 0), 0) > lim) p.setVar("dmz_release", lim);
        });
    });

    // ---- fly (the F key's toggle, 45_keys.js) ------------------------------------------
    function toggleFly(p) {
        if (route(p, "fly", null, [["DMZ_FLIGHT", "toggle"]])) return;
        if (p.hasEffect("flight")) { p.removeEffect("flight"); p.actionbar("&7You land."); return; }
        if (p.getLevel() < 3) { p.actionbar("&7Reach level 3 to learn to fly (Bukujutsu)."); return; }
        p.push(0, 0.6, 0);
        p.addEffect("flight", -1);
        p.progressQuest("fly", 1);
        p.actionbar("&fFlying &7- Space up, Shift down, sprint or R for speed, V to land");
    }

    RPG.net.on("dmz_radial", function (p, d) {
        if (!d || !p.getVar("dmz_created", 0) || p.hasEffect("stunned")) return;
        var node = String(d.node || ""), v = d.value, done = true;
        switch (node) {
            case "release_limit": setReleaseLimit(p, v); break;
            case "fly": toggleFly(p); break;
            case "flight_mode": done = route(p, node, v, [["DMZ_FLIGHT", "setMode", num(v, 0)]]); break;
            case "flight_speed": done = route(p, node, v, [["DMZ_FLIGHT", "setSpeedLimit", num(v, 100)]]); break;
            case "flight_lock": done = route(p, node, v, [["DMZ_FLIGHT", "toggleLock"]]); break;
            case "skill_toggle": done = route(p, node, v, [["DMZ_SKILLS", "toggle", String(v)], ["DMZ_TECH", "toggleSkill", String(v)]]); break;
            case "friendly_fist": done = route(p, node, v, [["DMZ_KIWEAPON", "toggleFriendlyFist"], ["DMZ_TECH", "toggleFriendlyFist"], ["DMZ_COMBAT", "toggleFriendlyFist"]]); break;
            case "kiweapon": done = route(p, node, v, [["DMZ_KIWEAPON", "selectKiWeapon", String(v)], ["DMZ_TECH", "selectKiWeapon", String(v)]]); break;
            case "fusion": done = route(p, node, v, [["DMZ_FUSION", "toggleMode"]]); break;
            case "namek_regen": done = route(p, node, v, [["DMZ_RACIAL_EXT", "namekRegen"]]); break;
            case "bio_skill": done = route(p, node, v, [["DMZ_RACIAL_EXT", "selectBioSkill", String(v)]]); break;
            case "tail": done = route(p, node, v, [["DMZ_RACIAL_EXT", "toggleTail"]]); break;
            case "racial_mode": done = route(p, node, v, [["DMZ_RACIAL_EXT", "selectRacial", String(v)]]); break;
            case "eject_confirm_msg": p.actionbar("&eClick again within 5 seconds to eject this slot."); return;
            default: return;
        }
        if (!done) notYet(p);
        if (typeof DMZ_TF !== "undefined") { DMZ_TF.refresh(p); DMZ_TF.sendState(p, false); }
    });

    return { setReleaseLimit: setReleaseLimit, maxRelease: maxRelease };
})();
