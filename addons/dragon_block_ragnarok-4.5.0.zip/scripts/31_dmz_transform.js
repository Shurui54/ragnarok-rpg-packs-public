// =====================================================================================
//  31_dmz_transform.js - DMZ transformations: charge, transform, stack, descend, mastery,
//  drains, auras and the racial action. Port of DragonMine Z's TransformationsHelper,
//  FormModeHandler, StackFormModeHandler, RacialModeHandler, ExecuteActionC2S and the
//  form parts of TickHandler / StatsData (GPL-3.0, see NOTICE.md).
// =====================================================================================
//  Controls (45_keys.js binds them; DMZ defaults):
//    G       hold: charge the selected action (FORM: next form of your group, STACK: next
//            stack form, RACIAL: your race's ability). Double-tap: instant transform.
//    Alt+G   descend one form (FORM/STACK) / racial secondary (RACIAL)
//    Ctrl+G  hold: charge the next stack form (Kaioken/Ultimate) whatever the mode
//    X       the form menu (DMZ's radial menu): pick group/form, stack, racial, aura
//
//  Player vars (saved; the client reads some):
//    dmz_form / dmz_stack            "group:form" ("" = none)
//    dmz_sel / dmz_sel_stack         the selected target ("group:form")
//    dmz_prev / dmz_prev_stack       one-step undo for descend ({v: "group:form"} or null)
//    dmz_mastery / dmz_stack_mastery { "group:form": 0..100 }
//    dmz_action                      "FORM" | "STACK" | "RACIAL"
//    dmz_formcharge                  0..100 (HUD gauge)    dmz_form_name   shown on the stats screen
//    dmz_tf_anim                     transf.* animation while charging (12_anim_state.js shares it)
//    dmz_form_mult                   the form multipliers currently folded into dmz_mult
//    dmz_aura_perm                   permanent aura toggle (needs kicontrol)
//    dmz_aura_color                  current aura colour (HUD)
// =====================================================================================
RPG.effects.define("absorbing", { name: "Absorbing", color: "#2E8B57", hidden: true, flags: ["noMove", "noJump"] });

var DMZ_TF = (function () {
    var FD = DMZ_FORMS, LOOK = DMZ_LOOK, D = FD.D;
    var ST = {};                  // uuid -> transient state (not saved)
    var STATS6 = ["STR", "SKP", "DEF", "VIT", "PWR", "ENE"];
    var MULT_KEYS = ["STR", "SKP", "DEF", "PWR", "SPD", "STM", "VIT", "ENE"];   // STM/VIT/ENE: 1 unless a form edits them (mx)

    // ---- small helpers ---------------------------------------------------------------
    function race(p) { return DMZ_DATA.DMZ[p.race] || p.race || "human"; }
    function our(r) { return DMZ_DATA.OUR[r] || r; }
    function st(p) {
        return ST[p.uuid] || (ST[p.uuid] = { charging: null, key: -1, ticks: 0, charge: 0, step: 0, chord: {}, sec: 0, passive: 0,
            fx: null, auraFx: null, sweep: false, lastMsg: 0, colorTick: 0, drain: null });
    }
    function creative(p) { return String(p.getGameMode()) === "creative"; }
    function spectator(p) { return String(p.getGameMode()) === "spectator"; }
    function skill(p, s) { return typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS.level(p, s) : 0; }
    function hasSkill(p, s) { return typeof DMZ_SKILLS !== "undefined" && DMZ_SKILLS.owned(p, s) && DMZ_SKILLS.level(p, s) > 0; }
    function android(p) { return !!p.getVar("dmz_android", 0); }
    function hasTail(p) { return race(p) === "saiyan" && Number(p.getVar("dmz_tail", 1)) !== 0; }
    function pair(v) {
        if (!v) return null;
        v = String(v);
        let i = v.indexOf(":");
        return i > 0 ? { g: v.substring(0, i), f: v.substring(i + 1) } : null;
    }
    function num(v, d) { v = Number(v); return isNaN(v) ? d : v; }
    function release(p) { return num(p.getVar("dmz_release", 0), 0); }
    function maxRelease(p) {
        let mult = p.race === "saiyan" ? 1 + Math.min(0.15, num(p.getVar("dmz_zenkai_release", 0), 0)) : 1;
        return DMZ_F.maxRelease(num(p.getVar("dmz_potential", 0), 0), mult);
    }
    function msg(p, text) { p.actionbar(text); }
    function obj(v) { return v && typeof v === "object" ? v : {}; }
    function stackOrForm(f) { return f && f.race === "stack"; }
    function fullName(f, s) {
        let name = f ? f.n : "";
        if (s) name = (name ? name + " x " : "") + FD.stackGroup(s.group).n + " " + s.n;
        return name;
    }

    // ---- state -----------------------------------------------------------------------
    function activeForm(p) { let x = pair(p.getVar("dmz_form", "")); return x ? FD.form(race(p), x.g, x.f) : null; }
    function activeStack(p) { let x = pair(p.getVar("dmz_stack", "")); return x ? FD.stackForm(x.g, x.f) : null; }
    function action(p) { let a = String(p.getVar("dmz_action", "FORM") || "FORM"); return a === "STACK" || a === "RACIAL" ? a : "FORM"; }

    // ---- mastery (FormMasteries) -----------------------------------------------------
    function masteryMap(p, stack) { return obj(p.getVar(stack ? "dmz_stack_mastery" : "dmz_mastery", null)); }
    function mastery(p, f) { if (!f) return 0; return num(masteryMap(p, stackOrForm(f))[f.key], 0); }
    function masteryAny(p, key) { return Math.max(num(masteryMap(p, false)[key], 0), num(masteryMap(p, true)[key], 0)); }

    function addMastery(p, f, x, noShare) {
        if (!f || f.maxMastery <= 0 || !(x > 0)) return;
        let stack = stackOrForm(f), map = masteryMap(p, stack);
        let cur = num(map[f.key], 0);
        if (cur < f.maxMastery) {
            map[f.key] = Math.min(f.maxMastery, cur + x);
            p.setVar(stack ? "dmz_stack_mastery" : "dmz_mastery", map);
        }
        if (noShare || !f.share) return;
        f.share.forEach((sh) => {
            let dot = sh[0].indexOf("."), g = sh[0].substring(0, dot), id = sh[0].substring(dot + 1);
            let t = stack ? FD.stackForm(g, id) : FD.form(race(p), g, id);
            if (t) addMastery(p, t, x * sh[1], true);
        });
    }
    function potionMult(p) { return p.hasEffect("mastery_gain") ? 1.5 : 1; }
    /** A per-form mastery rate (perHit, passive, instantOn) set in the form editor, else DMZ's default. */
    function per(f, k) { return f && typeof f[k] === "number" ? f[k] : D[k]; }

    // ---- unlock rules (TransformationsHelper) ----------------------------------------
    // Form editor gates (DMZ Ragnarok's FormLevelGate / FormAlignmentGate "use" bounds): character level and
    // alignment needed to transform into (and stay in) a form. Buying its level is gated by saga + TP cost
    // (DMZ_SKILLS_DATA, rebuilt by shared/07_dmz_forms_data.js for edited races).
    function alignment(p) { let a = Number(p.getVar("dmz_alignment", 100)); return isNaN(a) ? 100 : a; }
    function gateBlock(p, f) {
        if (!f || creative(p)) return null;
        if (f.plvl > 0 && p.getLevel() < f.plvl) return "&cYou need character level " + f.plvl + " for " + f.n + ".";
        let a = alignment(p);
        if (typeof f.alignMin === "number" && a < f.alignMin) return "&cYour alignment is too low for " + f.n + " (needs " + f.alignMin + "+).";
        if (typeof f.alignMax === "number" && a > f.alignMax) return "&cYour alignment is too high for " + f.n + " (max " + f.alignMax + ").";
        return null;
    }
    function formUnlocked(p, f) {
        if (gateBlock(p, f)) return false;
        if (stackOrForm(f)) return skill(p, f.type) >= f.lvl && (f.lvl > 0 || hasSkill(p, f.type));
        return skill(p, FD.skillFor(f.type)) >= f.lvl;
    }
    function meetsMastery(p, f) {
        if (creative(p) || !f.req || f.unlockOn <= 0) return true;
        let ok = true;
        String(f.req).split(",").forEach((tok) => {
            let t = tok.trim(), dot = t.indexOf(".");
            if (dot <= 0) return;
            if (masteryAny(p, t.substring(0, dot) + ":" + t.substring(dot + 1)) < f.unlockOn) ok = false;
        });
        return ok;
    }
    function groupAllowed(p, g) {
        if (!g || g.scripted || FD.isScripted(g.type)) return false;
        let isAndroid = g.id === "androidforms", isGod = String(g.type).indexOf("god") >= 0;
        if (isAndroid && !android(p)) return false;
        if (android(p) && !isAndroid && !isGod) return false;
        if (typeof DMZ_SKILLS_DATA !== "undefined" && !DMZ_SKILLS_DATA.allowed(FD.skillFor(g.type), race(p), android(p))) return false;
        return true;
    }
    function tailSkip(p, g, f) { return g.id === "oozaru" && f.tailOnly && !hasTail(p); }
    function unlockedForms(p, g) {
        if (!groupAllowed(p, g)) return [];
        return g.forms.filter((f) => !tailSkip(p, g, f) && formUnlocked(p, f) && meetsMastery(p, f));
    }
    function unlockedStack(p, g) {
        if (!g) return [];
        if (typeof DMZ_SKILLS_DATA !== "undefined" && !DMZ_SKILLS_DATA.allowed(g.type, race(p), android(p))) return [];
        return g.forms.filter((f) => formUnlocked(p, f) && meetsMastery(p, f));
    }
    function meetsFree(p, g, f, stack) {
        if (creative(p)) return true;
        let list = stack ? unlockedStack(p, g) : unlockedForms(p, g);
        if (list.length && list[0].id === f.id) return true;
        return mastery(p, f) >= f.free;
    }
    function selectable(p, g, f, stack) {
        let list = stack ? unlockedStack(p, g) : unlockedForms(p, g);
        return list.indexOf(f) >= 0 && meetsFree(p, g, f, stack);
    }

    function targetGroupId(p) {
        let sel = pair(p.getVar("dmz_sel", "")), act = pair(p.getVar("dmz_form", ""));
        if (act) return sel && sel.g !== act.g ? sel.g : act.g;
        return sel ? sel.g : null;
    }
    function crossGroup(p) {
        let sel = pair(p.getVar("dmz_sel", "")), act = pair(p.getVar("dmz_form", ""));
        return !!(act && sel && sel.g !== act.g);
    }
    function inScripted(p) { let f = activeForm(p); return !!(f && FD.isScripted(f.type)); }

    function nextCandidate(p) {
        let r = race(p), gid = targetGroupId(p);
        if (!gid || inScripted(p)) return null;
        let g = FD.group(r, gid);
        if (!g || !groupAllowed(p, g)) return null;
        let act = activeForm(p);
        if (crossGroup(p) || !act) {
            let sel = pair(p.getVar("dmz_sel", ""));
            let selected = sel ? FD.form(r, gid, sel.f) : null;
            if (selected && tailSkip(p, g, selected)) return g.forms.filter((f) => !f.tailOnly)[0] || null;
            return selected;
        }
        let i = FD.index(g, act.id);
        for (let j = i + 1; j < g.forms.length; j++) {
            if (tailSkip(p, g, g.forms[j])) continue;
            return g.forms[j];
        }
        return null;
    }
    function nextForm(p) { let c = nextCandidate(p); return c && formUnlocked(p, c) && meetsMastery(p, c) ? c : null; }
    function needsFree(p) {
        let gid = targetGroupId(p), act = pair(p.getVar("dmz_form", ""));
        if (!gid || (act && act.g === gid)) return false;
        return nextCandidate(p) !== null;
    }
    function nextStack(p) {
        let act = pair(p.getVar("dmz_stack", "")), sel = pair(p.getVar("dmz_sel_stack", ""));
        let gid = act ? act.g : sel ? sel.g : null;
        let g = gid ? FD.stackGroup(gid) : null;
        if (!g) return null;
        let f = null;
        if (!act) f = sel ? FD.stackForm(gid, sel.f) : null;
        else { let i = FD.index(g, act.f); f = i >= 0 && i + 1 < g.forms.length ? g.forms[i + 1] : null; }
        return f && formUnlocked(p, f) && meetsMastery(p, f) && unlockedStack(p, g).indexOf(f) >= 0 ? f : null;
    }

    // first available group/form when nothing valid is selected (getGroupWithFirstAvailableForm)
    function ensureSelection(p) {
        let r = race(p), sel = pair(p.getVar("dmz_sel", ""));
        let g = sel ? FD.group(r, sel.g) : null, f = g ? FD.form(r, sel.g, sel.f) : null;
        if (!(g && f && selectable(p, g, f, false))) {
            let best = null, bestLvl = 1e9, preferred = [];
            FD.groups(r).forEach((gg) => { if (groupAllowed(p, gg) && skill(p, FD.skillFor(gg.type)) > 0 && preferred.indexOf(gg.type) < 0) preferred.push(gg.type); });
            FD.groups(r).forEach((gg) => {
                if (!groupAllowed(p, gg)) return;
                if (preferred.length && preferred.indexOf(gg.type) < 0) return;
                let u = unlockedForms(p, gg);
                if (u.length && u[0].lvl < bestLvl) { bestLvl = u[0].lvl; best = gg.id + ":" + u[0].id; }
            });
            if (best && best !== String(p.getVar("dmz_sel", "") || "")) p.setVar("dmz_sel", best);
        }
        let ss = pair(p.getVar("dmz_sel_stack", ""));
        let sg = ss ? FD.stackGroup(ss.g) : null, sf = sg ? FD.stackForm(ss.g, ss.f) : null;
        if (!(sg && sf && selectable(p, sg, sf, true))) {
            let pick = null;
            FD.STACKS.forEach((gg) => { if (!pick && skill(p, gg.type) > 0) { let u = unlockedStack(p, gg); if (u.length) pick = gg.id + ":" + u[0].id; } });
            if (pick && pick !== String(p.getVar("dmz_sel_stack", "") || "")) p.setVar("dmz_sel_stack", pick);
        }
    }

    // ---- multipliers (StatsData.getTotalMultiplier, additive mode) --------------------
    function bestBase(p, forUltimate) {
        let best = null, bestAvg = -1;
        FD.groups(race(p)).forEach((g) => {
            if (!forUltimate && g.id === "legendaryforms") return;
            unlockedForms(p, g).forEach((f) => {
                if (forUltimate && f.incompat.indexOf("ultimate.ultimate") >= 0) return;
                let m = mastery(p, f), avg = 0;
                STATS6.forEach((k) => { avg += FD.masteryMult(f, FD.baseMult(f, k), m); });
                avg /= 6;
                if (avg > bestAvg) { bestAvg = avg; best = f; }
            });
        });
        return best;
    }
    function formMult(p, f, stat) { return f ? FD.masteryMult(f, FD.baseMult(f, stat), mastery(p, f)) : 1; }
    function stackMult(p, s, stat) {
        if (!s) return 1;
        if (s.group === "ultimate") {
            let b = bestBase(p, true);
            return formMult(p, b, stat) + FD.baseMult(s, stat) - 1;
        }
        return formMult(p, s, stat);
    }
    function totals(p) {
        let f = activeForm(p), s = activeStack(p), out = {};
        MULT_KEYS.forEach((k) => {
            if (k === "SPD") out[k] = formMult(p, f, k) * stackMult(p, s, k);
            else out[k] = 1 + (formMult(p, f, k) - 1) + (stackMult(p, s, k) - 1);
        });
        return out;
    }
    // fold the form totals into dmz_mult (other scripts scale it multiplicatively: fruits, Demon Eye)
    function applyMult(p) {
        let want = totals(p), old = obj(p.getVar("dmz_form_mult", null)), m = obj(p.getVar("dmz_mult", null)), changed = false;
        MULT_KEYS.forEach((k) => {
            let o = num(old[k], 1) || 1;
            if (Math.abs(o - want[k]) < 1e-4) return;
            let cur = typeof m[k] === "number" ? m[k] : 1;
            m[k] = cur / o * want[k];
            changed = true;
        });
        if (!changed) return;
        p.setVar("dmz_mult", m);
        p.setVar("dmz_form_mult", want);
        p.refreshStats();
    }

    // ---- drains (TickHandler.handleActiveFormDrains, once a second) --------------------
    var KIND = { energy: "ki", stamina: "sd", health: "hd" };
    function stackMastery(p, s) { return s && s.group === "ultimate" ? 0 : mastery(p, s); }
    function adjusted(p, kind) {
        let f = activeForm(p), s = activeStack(p), k = KIND[kind], pr = release(p) / 100;
        let baseD = f ? f[k] : 0, stackD = s ? s[k] : 0;
        if (f && s) { baseD *= f.stackDrain * s.stackDrain; stackD *= f.stackDrain * s.stackDrain; }
        let cf = FD.costFactor(f, mastery(p, f)), cs = FD.costFactor(s, stackMastery(p, s));
        let a = (baseD >= 0 ? baseD * cf : baseD / cf) * pr;
        let b = (stackD >= 0 ? stackD * cs : stackD / cs) * pr;
        let d = a + b;
        if (d === 0) return 0;
        let sc = d * D.baselineDrain;
        return d < 0 ? Math.min(-1, sc) : Math.max(1, sc);
    }
    function rawSum(p, k) { let f = activeForm(p), s = activeStack(p); return (f ? f[k] : 0) + (s ? s[k] : 0); }
    function weightedCost(p, k) {
        let f = activeForm(p), s = activeStack(p), num1 = 0, den = 0;
        if (f && f[k]) { num1 += f[k] * FD.costFactor(f, mastery(p, f)); den += f[k]; }
        if (s && s[k]) { num1 += s[k] * FD.costFactor(s, stackMastery(p, s)); den += s[k]; }
        return den ? num1 / den : 1;
    }
    function effective(p) {
        let v = dmzView(p), ro = DMZ_F.melee(v) + DMZ_F.strike(v) + DMZ_F.ki(v);
        let maxE = p.maxResource("ki"), maxS = p.maxResource("stamina"), maxH = p.maxHealth;
        let aE = adjusted(p, "energy"), aS = adjusted(p, "stamina"), aH = adjusted(p, "health");
        return {
            e: Math.round(aE <= 0 ? aE : aE * Math.max(1, ro / Math.max(1, maxE * 5)) + maxE * (rawSum(p, "ki") * 0.01) * 0.75 * weightedCost(p, "ki")),
            s: Math.round(aS <= 0 ? aS : aS * Math.max(1, ro / Math.max(1, maxS * 1.5)) + maxS * 0.005 * weightedCost(p, "sd")),
            h: Math.round(aH <= 0 ? aH : aH * Math.max(1, ro / Math.max(1, maxH * 1.5)) + maxH * 0.005 * weightedCost(p, "hd"))
        };
    }
    function drainTick(p) {
        if (!activeForm(p) && !activeStack(p)) return;
        if (creative(p) || spectator(p) || inScripted(p)) return;
        if (typeof dmzIsDead === "function" && dmzIsDead(p) && p.dimension === "ragnarok_rpg:otherworld") return;
        let d = effective(p), ki = p.resource("ki"), stam = p.resource("stamina"), hp = p.health;
        if ((d.e <= 0 || ki >= d.e) && (d.s <= 0 || stam >= d.s) && (d.h <= 0 || hp > d.h)) {
            if (d.e > 0) p.addResource("ki", -d.e); else if (d.e < 0) p.addResource("ki", Math.min(-d.e, p.maxResource("ki") - ki));
            if (d.s > 0) p.addResource("stamina", -d.s); else if (d.s < 0) p.addResource("stamina", -d.s);
            if (d.h > 0) p.setHealth(Math.max(1, hp - d.h)); else if (d.h < 0) p.heal(-d.h);
        } else {
            let why = d.e > 0 && ki < d.e ? "ki" : d.s > 0 && stam < d.s ? "stamina" : "health";
            clearStack(p, true);
            revertBase(p, true);
            msg(p, "&cDrained " + why + "! You lose your transformation.");
        }
    }

    // ---- setting the form (Character.setActiveForm & co) ------------------------------
    function setForm(p, g, id) { p.setVar("dmz_form", g && id ? g + ":" + id : ""); refresh(p); }
    function setStack(p, g, id) { p.setVar("dmz_stack", g && id ? g + ":" + id : ""); refresh(p); }
    function recordPrev(p) { p.setVar("dmz_prev", { v: String(p.getVar("dmz_form", "") || "") }); }
    function recordPrevStack(p) { p.setVar("dmz_prev_stack", { v: String(p.getVar("dmz_stack", "") || "") }); }
    function clearStack(p, silent) {
        if (!p.getVar("dmz_stack", "")) return;
        p.setVar("dmz_prev_stack", null);
        setStack(p, null, null);
        if (!silent) msg(p, "&7Stack form removed.");
    }

    // frost demon evolution floor (TransformationsHelper.getEvolutionFloorForm)
    function floorForm(p) {
        if (race(p) !== "frostdemon") return null;
        let act = pair(p.getVar("dmz_form", ""));
        if (!act || act.g !== "evolutionforms") return null;
        let g = FD.group("frostdemon", "evolutionforms");
        let fi = FD.index(g, "final"), ai = FD.index(g, act.f);
        return fi >= 0 && ai >= fi ? "final" : null;
    }
    function belowFloor(p, g, f) {
        let floor = floorForm(p);
        if (!floor) return false;
        if (!f) return true;
        if (g !== "evolutionforms") return false;
        let grp = FD.group("frostdemon", g);
        return FD.index(grp, f) < FD.index(grp, floor);
    }
    function clampFloor(p) {
        let floor = floorForm(p);
        if (!floor) return false;
        if (pair(p.getVar("dmz_form", "")).f !== floor) setForm(p, "evolutionforms", floor);
        return true;
    }
    function revertBase(p, respectFloor) {
        if (respectFloor && clampFloor(p)) return false;
        p.setVar("dmz_prev", null);
        if (android(p) && race(p) === "human") setForm(p, "androidforms", "androidbase");
        else setForm(p, null, null);
        return true;
    }

    function canAfford(p, f, factor) {
        let need = { ki: Math.floor(p.maxResource("ki") * factor * f.ki), st: Math.floor(p.maxResource("stamina") * factor * f.sd), hp: Math.floor(p.maxHealth * factor * f.hd) };
        if (creative(p)) return true;
        if (need.ki > 0 && p.resource("ki") < need.ki) { msg(p, "&cNot enough ki! You need " + need.ki + "."); return false; }
        if (need.st > 0 && p.resource("stamina") < need.st) { msg(p, "&cNot enough stamina! You need " + need.st + "."); return false; }
        if (need.hp > 0 && p.health < need.hp) { msg(p, "&cNot enough health! You need " + need.hp + "."); return false; }
        return true;
    }
    function freeMsg(p) {
        let c = nextCandidate(p);
        if (c) msg(p, "&cYou need " + c.free + " mastery in " + c.n + " to transform into it directly.");
    }
    // a stack form that can't stay on top of the new base form is dropped (FormModeHandler)
    function checkStackWith(p, next) {
        let s = activeStack(p);
        if (!s) return;
        let ok = next.stackable && s.stackable && mastery(p, next) >= next.stackOn && mastery(p, s) >= s.stackOn && FD.compatible(next, s);
        if (!ok) { clearStack(p, true); p.tell("&7Your stack form can't hold in " + next.n + " and fades."); }
    }

    // FormModeHandler.performAction
    function performForm(p) {
        let next = nextForm(p);
        if (!next) return false;
        if (needsFree(p) && !meetsFree(p, FD.group(race(p), targetGroupId(p)), next, false)) { freeMsg(p); return false; }
        if (!canAfford(p, next, 0.1)) return false;
        checkStackWith(p, next);
        let gid = targetGroupId(p);
        recordPrev(p);
        setForm(p, gid, next.id);
        sfx(p, "transform_on", 1, 1);
        msg(p, "&e" + fullName(next, activeStack(p)));
        return true;
    }
    function stackableWithBase(p, next) {
        let base = activeForm(p);
        if (!base) return true;
        return base.stackable && next.stackable && FD.compatible(base, next) && mastery(p, base) >= base.stackOn && mastery(p, next) >= next.stackOn;
    }
    // StackFormModeHandler.performAction
    function performStack(p) {
        let next = nextStack(p);
        if (!next) return false;
        if (!stackableWithBase(p, next)) { msg(p, "&cThat stack form can't be used with your current form."); return false; }
        if (!canAfford(p, next, 1)) return false;
        recordPrevStack(p);
        setStack(p, next.group, next.id);
        sfx(p, "transform_on", 1, 1);
        if (next.group === "kaioken") sfx(p, "stack_form", 1, 1);
        msg(p, "&e" + fullName(activeForm(p), next));
        return true;
    }

    // ExecuteActionC2S.INSTANT_TRANSFORM (double-tap G)
    function instant(p) {
        if (p.hasEffect("stunned") || inScripted(p)) return;
        if (action(p) === "STACK") return instantStack(p);
        if (action(p) !== "FORM") return;
        let next = nextForm(p);
        if (!next || next.id === "oozaru") return;
        if (needsFree(p) && !meetsFree(p, FD.group(race(p), targetGroupId(p)), next, false)) { freeMsg(p); return; }
        if (!creative(p) && mastery(p, next) < per(next, "instantOn")) { msg(p, "&cYou need " + per(next, "instantOn") + " mastery in " + next.n + " to transform instantly."); return; }
        let cost = Math.floor(adjusted(p, "energy") * 4);
        if (!creative(p) && cost > 0 && p.resource("ki") < cost) { msg(p, "&cNot enough ki for an instant transformation (" + cost + ")."); return; }
        if (!creative(p) && cost > 0) p.addResource("ki", -cost);
        checkStackWith(p, next);
        let gid = targetGroupId(p);
        recordPrev(p);
        setForm(p, gid, next.id);
        stopCharge(p, -2);
        sfx(p, "insta_form_on", 1, 1);
        msg(p, "&e" + fullName(next, activeStack(p)));
    }
    function chargeMasteryStack(p, f) {
        if (f.group === "ultimate") { let b = bestBase(p, true); return b ? mastery(p, b) : 0; }
        return mastery(p, f);
    }
    function instantStack(p) {
        let next = nextStack(p);
        if (!next) return;
        if (!stackableWithBase(p, next)) { msg(p, "&cThat stack form can't be used with your current form."); return; }
        if (!creative(p) && chargeMasteryStack(p, next) < per(next, "instantOn")) { msg(p, "&cYou need " + per(next, "instantOn") + " mastery to transform instantly."); return; }
        let cost = Math.floor(adjusted(p, "energy") * 4);
        if (!creative(p) && cost > 0 && p.resource("ki") < cost) { msg(p, "&cNot enough ki for an instant transformation (" + cost + ")."); return; }
        if (!creative(p) && cost > 0) p.addResource("ki", -cost);
        recordPrevStack(p);
        setStack(p, next.group, next.id);
        stopCharge(p, -2);
        sfx(p, "insta_form_on", 1, 1);
        if (next.group === "kaioken") sfx(p, "stack_form", 1, 1);
        msg(p, "&e" + fullName(activeForm(p), next));
    }

    // ExecuteActionC2S.FORCE_DESCEND / MENU_DESCEND
    function descend(p, menu, all) {
        if (inScripted(p) || p.hasEffect("stunned")) return;
        if (all) { clearStack(p, true); revertBase(p, false); return; }
        let f = activeForm(p), s = activeStack(p);
        if ((!f && !s) || (android(p) && f && f.id === "androidbase")) p.setVar("dmz_release", 0);
        if (s) descendStack(p);
        else if (f) descendForm(p, menu);
    }
    function descendForm(p, ignoreFloor) {
        let r = race(p), rec = p.getVar("dmz_prev", null);
        if (rec && typeof rec === "object") {
            p.setVar("dmz_prev", null);
            let prev = pair(rec.v);
            if (prev && FD.form(r, prev.g, prev.f)) {
                if (!ignoreFloor && belowFloor(p, prev.g, prev.f)) return;
                setForm(p, prev.g, prev.f);
                sfx(p, "insta_form_off", 1, 1);
                return;
            }
            if (!ignoreFloor && clampFloor(p)) return;
            revertBase(p, false);
            return;
        }
        let act = pair(p.getVar("dmz_form", "")), g = FD.group(r, act.g), i = FD.index(g, act.f);
        let prevF = null;
        for (let j = i - 1; j >= 0; j--) { if (!tailSkip(p, g, g.forms[j])) { prevF = g.forms[j]; break; } }
        if (!ignoreFloor && belowFloor(p, act.g, prevF ? prevF.id : null)) return;
        if (prevF) { setForm(p, act.g, prevF.id); sfx(p, "insta_form_off", 1, 1); }
        else revertBase(p, false);
    }
    function descendStack(p) {
        let rec = p.getVar("dmz_prev_stack", null);
        if (rec && typeof rec === "object") {
            p.setVar("dmz_prev_stack", null);
            let prev = pair(rec.v);
            if (prev && FD.stackForm(prev.g, prev.f)) { setStack(p, prev.g, prev.f); sfx(p, "insta_form_off", 1, 1); }
            else setStack(p, null, null);
            return;
        }
        let act = pair(p.getVar("dmz_stack", "")), g = FD.stackGroup(act.g), i = FD.index(g, act.f);
        if (i > 0) { setStack(p, act.g, g.forms[i - 1].id); sfx(p, "insta_form_off", 1, 1); }
        else setStack(p, null, null);
    }

    // =================================================================================
    //  Charging (hold the key: TickHandler.handleActionCharge every 20 ticks)
    // =================================================================================
    // kind: "form" | "stack" | "racial"; key: the action key that owns the charge (0 = moon)
    function startCharge(p, kind, key) {
        let s = st(p);
        if (s.charging && s.key !== key) return;
        if (!p.getVar("dmz_created", 0) || p.hasEffect("stunned") || p.hasEffect("absorbing")) return;
        if (s.charging === kind) return;
        if (kind === "racial" && !RACIAL.canCharge(p, true)) return;
        s.charging = kind; s.key = key; s.ticks = 0; s.charge = 0; s.step = 0; s.can = canChargeKind(p, kind);
        if (!s.can && key !== 0) blockedMsg(p, kind);
        p.setVar("dmz_formcharge", 0);
        updateTfAnim(p, s);
        refresh(p);
    }
    function stopCharge(p, key) {
        let s = st(p);
        if (!s.charging || (key !== -2 && s.key !== key)) return;
        s.charging = null; s.key = -1; s.charge = 0; s.ticks = 0;
        p.setVar("dmz_formcharge", 0);
        p.setVar("dmz_tf_anim", "");
        refresh(p);
    }
    function chargeTarget(p, s) {
        if (s.charging === "form") return nextForm(p);
        if (s.charging === "stack") return nextStack(p);
        return null;
    }
    function updateTfAnim(p, s) {
        let anim = "";
        if (!s.can) anim = "";
        else if (s.charging === "racial") anim = RACIAL.anim(p);
        else {
            let t = chargeTarget(p, s);
            anim = t ? (t.id.indexOf("ozaru") >= 0 ? "transf.ozaru" : t.anim) : D.anim;
        }
        if (String(p.getVar("dmz_tf_anim", "") || "") !== anim) p.setVar("dmz_tf_anim", anim);
    }
    // FormModeHandler / StackFormModeHandler.canCharge: while it's false the held key charges nothing
    function canChargeKind(p, kind) {
        if (kind === "form") {
            let n = nextForm(p);
            if (!n) return false;
            return n.id === "oozaru" ? shouldAutoOozaru(p) : true;
        }
        if (kind === "stack") {
            let n = nextStack(p), base = activeForm(p);
            if (!n) return false;
            return !base || (base.stackable && n.stackable && FD.compatible(base, n));
        }
        return true;
    }
    function chargeStepFor(p, s) {
        if (s.charging === "form") { let n = nextForm(p); return n ? FD.chargeStep(mastery(p, n)) : 0; }
        if (s.charging === "stack") { let n = nextStack(p); return n ? FD.chargeStep(chargeMasteryStack(p, n)) : 0; }
        return RACIAL.step(p);
    }
    function advance(p, s) {
        s.ticks += 2;
        let was = s.can;
        s.can = canChargeKind(p, s.charging);
        if (!s.can) {
            if (s.charge || p.getVar("dmz_tf_anim", "")) { s.charge = 0; s.step = 0; p.setVar("dmz_formcharge", 0); p.setVar("dmz_tf_anim", ""); refresh(p); }
            if (s.ticks % 60 === 20 && s.key !== 0) blockedMsg(p, s.charging);
            return;
        }
        if (!was) { updateTfAnim(p, s); refresh(p); }
        // power release climbs while charging (TickHandler: releaseCharging = chargingKi || actionCharging)
        if (s.charging !== "racial" && !p.hasEffect("ki_charge")) {
            let rel = release(p), max = maxRelease(p);
            let step = DMZ_F.releaseStep(s.ticks, num(p.getVar("dmz_potential", 0), 0));
            if (rel < max) p.setVar("dmz_release", Math.min(max, rel + step));
        }
        if (s.ticks % 20 === 0) {
            if (s.charging === "racial" && !RACIAL.canCharge(p, true)) { stopCharge(p, -2); return; }
            let inc = chargeStepFor(p, s);
            if (!s.charging) return;                     // the racial action fired right away
            if (inc <= 0) s.charge = 0;
            else {
                s.step = inc;
                s.charge = Math.min(100, s.charge + inc);
                if (s.charge >= 100) {
                    let ok = s.charging === "form" ? performForm(p) : s.charging === "stack" ? performStack(p) : RACIAL.activate(p);
                    if (ok) { s.charge = 0; if (s.charging === "racial" && !RACIAL.canCharge(p, false)) { stopCharge(p, -2); return; } }
                }
            }
            p.setVar("dmz_formcharge", Math.round(s.charge));
            updateTfAnim(p, s);
            if (s.charging !== "racial") { sfx(p, "ki_charge_loop", 0.5, 1); p.shake(0.15, 25); }
        }
        if (s.ticks % 10 === 0) refresh(p);
    }
    function blockedMsg(p, kind) {
        if (kind === "stack") {
            let n = nextStack(p);
            msg(p, n ? "&cThat stack form can't be used with your current form." : "&7No stack form available. Press X to pick one.");
            return;
        }
        if (kind !== "form") return;
        let c = nextCandidate(p), gate = gateBlock(p, c);
        if (gate) { msg(p, gate); return; }
        if (c && c.id === "oozaru" && formUnlocked(p, c)) { msg(p, "&7Look at the full moon to become an Oozaru."); return; }
        if (c && formUnlocked(p, c) && !meetsMastery(p, c)) {
            let t = String(c.req).split(",")[0], dot = t.indexOf(".");
            let req = FD.form(race(p), t.substring(0, dot), t.substring(dot + 1));
            msg(p, "&cYou need " + c.unlockOn + " mastery in " + (req ? req.n : t) + " first.");
        } else if (!c && activeForm(p)) msg(p, "&7No stronger form in this group.");
        else if (!c) msg(p, "&7No form selected. Press X to pick one.");
    }

    // =================================================================================
    //  Look: avatar effect, colours, aura (FormVisualTransition simplified)
    // =================================================================================
    function ownColor(p, k) {
        let c = p.getColor(k);
        if (c) return String(c);
        let rc = RACE_COLORS[p.race] || {};
        return rc[k] || "#FFFFFF";
    }
    function baseColors(p) {
        let r = race(p), eyes = ownColor(p, "eyes");
        return { fBody1: ownColor(p, "body1"), fBody2: ownColor(p, "body2"), fBody3: ownColor(p, "body3"), fHair: ownColor(p, "hair"),
            fEye1: eyes, fEye2: r === "bioandroid" ? "#FFFFFF" : String(p.getVar("dmz_fusion_eye2", "") || eyes) };   // fused: the partner's eye (64_dmz_fusion.js)
    }
    var C_MAP = { fBody1: "body1", fBody2: "body2", fBody3: "body3", fHair: "hair", fEye1: "eye1", fEye2: "eye2" };
    function lookColors(p, f, s) {
        let base = baseColors(p), out = {};
        Object.keys(C_MAP).forEach((k) => {
            let key = C_MAP[k];
            out[k] = (s && s.c[key]) || (f && f.c[key]) || base[k];
        });
        let t = s && s.tint && s.tint[1] > 0 ? s.tint : f && f.tint && f.tint[1] > 0 ? f.tint : null;
        if (t) ["fBody1", "fBody2", "fBody3", "fHair"].forEach((k) => { out[k] = FD.tint(out[k], t[0], t[1]); });
        return out;
    }
    function auraColorOf(p, f, s) {
        if (s) return s.aura || "#FFFFFF";
        return (f && f.aura) || ownColor(p, "aura");
    }
    function bigForm(f) { return !!f && (!!f.big || /supersaiyan2|supersaiyan3|ultra|superperfect/.test(f.id)); }

    function allLookEffects() {
        let ids = [];
        Object.keys(FD.GROUPS).forEach((r) => { ids.push(LOOK.baseId(r)); FD.GROUPS[r].forEach((g) => g.forms.forEach((f) => ids.push(LOOK.effectId(r, f)))); });
        FD.STACKS.forEach((g) => g.forms.forEach((f) => ids.push(LOOK.stackId(f))));
        return ids;
    }
    var LOOK_IDS = null;
    function sweep(p, keep) {
        LOOK_IDS = LOOK_IDS || allLookEffects();
        LOOK_IDS.forEach((id) => { if (keep.indexOf(id) < 0 && p.hasEffect(id)) p.removeEffect(id); });
        for (let i = 0; i < LOOK.AURA_STEPS; i++) {
            let id = "dmz_aura_" + i;
            if (keep.indexOf(id) < 0 && p.hasEffect(id)) p.removeEffect(id);
        }
    }
    function setLook(p, k, v) { if (String(p.getColor(k) || "") !== v) p.setColor(k, v); }
    function ensure(p, id) { if (!p.hasEffect(id)) p.addEffect(id, -1); }

    function refresh(p) {
        if (!p.getVar("dmz_created", 0)) return;
        let s = st(p), r = race(p), f = activeForm(p), sf = activeStack(p);
        if (f && !FD.form(r, f.group, f.id)) f = null;
        // charge blend toward the target's colours
        let target = s.charging === "form" && s.can ? nextForm(p) : null, targetStack = s.charging === "stack" && s.can ? nextStack(p) : null;
        let factor = 0;
        if (target || targetStack) {
            let planned = s.step > 0 ? s.charge + s.step * ((s.ticks % 20) / 20) : s.charge;
            factor = Math.max(0, Math.min(1, planned / 100));
        }
        // which body: the form's, else the base body with form colours when needed
        let want = [];
        let needBase = !f && (sf || factor > 0);
        if (f) want.push(LOOK.effectId(r, f));
        else if (needBase && FD.groups(r).length) want.push(LOOK.baseId(r));
        if (sf) want.push(LOOK.stackId(sf));
        // look values the avatar templates use
        let bodyType = String(p.getColor("bodyType") || (RACE_LOOKS[p.race] || {}).bodyType || "");
        let bodyModel = String(p.getColor("bodyModel") || (RACE_LOOKS[p.race] || {}).bodyModel || "");
        let v = LOOK.variant(bodyType);
        setLook(p, "dmzModel", LOOK.modelFile(r, f, bodyType, bodyModel));
        setLook(p, "dmzSlim", v === "male" ? "" : "slim");
        setLook(p, "dmzGender", v === "female" ? "female" : "male");
        // colours
        let cur = lookColors(p, f, sf);
        if (factor > 0) {
            let tgt = target ? lookColors(p, target, sf) : lookColors(p, f, targetStack);
            Object.keys(cur).forEach((k) => { cur[k] = FD.lerpHex(cur[k], tgt[k], factor); });
        }
        Object.keys(cur).forEach((k) => setLook(p, k, cur[k]));
        // aura
        let auraHex = auraColorOf(p, f, sf);
        if (target) auraHex = FD.lerpHex(auraHex, auraColorOf(p, target, sf), factor);
        if (targetStack) auraHex = FD.lerpHex(auraHex, auraColorOf(p, f, targetStack), factor);
        setLook(p, "dmzAura", auraHex);
        if (String(p.getVar("dmz_aura_color", "") || "") !== auraHex) p.setVar("dmz_aura_color", auraHex);
        let fly = p.hasEffect("flight") && (p.getVar("fly_fast", 0) || p.sprinting);
        let visible = p.hasEffect("ki_charge") || ((s.charging === "form" || s.charging === "stack") && s.can && !!(target || targetStack))
            || !!p.getVar("dmz_aura_perm", 0) || !!p.getVar("dmz_forced_aura", 0) || fly;
        if (visible) {
            let kic = hasSkill(p, "kicontrol") ? 0.35 * Math.min(1, release(p) / 100) : 0;
            let as = (1.05 + (f ? 0.1 : 0) + (sf ? 0.1 : 0) + (bigForm(f) ? 0.2 : 0) + kic) * ((f && f.auraScale) || 1);
            let sy = FD.scaleOf(r, f)[1];
            let height = 2 * 2.2 * as * sy * (sf || targetStack ? 1.15 : 1);
            want.push("dmz_aura_" + LOOK.auraStep(height));
        }
        // markers other scripts check
        let markers = { kaioken: !!sf && sf.group === "kaioken", oozaru: !!f && f.id === "oozaru", golden_oozaru: !!f && f.id === "goldenoozaru" };
        Object.keys(markers).forEach((m) => { if (markers[m]) ensure(p, m); else if (p.hasEffect(m)) p.removeEffect(m); });
        // apply: add before removing so the body never flashes back to the race model
        want.forEach((id) => ensure(p, id));
        let key = want.join(",");
        if (s.fx !== key || !s.sweep) { sweep(p, want); s.fx = key; s.sweep = true; }
        // names and stats
        let name = fullName(f, sf);
        if (String(p.getVar("dmz_form_name", "") || "") !== name) p.setVar("dmz_form_name", name);
        applyMult(p);
    }

    // =================================================================================
    //  The racial action (RacialRegistry: majin, namekian, bioandroid)
    // =================================================================================
    var RACIAL = (function () {
        var NOW = () => Date.now();
        function cd(p, k) { return Math.max(0, num(p.getVar("dmz_cd_" + k, 0), 0) - NOW()); }
        function setCd(p, k, sec) { p.setVar("dmz_cd_" + k, NOW() + sec * 1000); }
        function slots(p, k) { let v = p.getVar(k, null); return v && typeof v === "object" && typeof v.length === "number" ? v : []; }
        function tier(p) { let f = activeForm(p); return !f ? "imperfect" : f.id === "semiperfect" ? "semi" : "perfect"; }
        function eligible(p, t) {
            if (!t || !t.isAlive() || t.uuid === p.uuid) return false;
            if (String(t.getType()).indexOf(":npc") >= 0) return false;            // masters and other NPCs
            return !p.isAlly(t);
        }
        function isStronger(p, t) {
            let v = dmzView(p); v.release = 100;
            let maxDmg = Math.max(DMZ_F.maxMelee(v), DMZ_F.strike(v), DMZ_F.ki(v));
            if (t.health > maxDmg) return false;
            let tp = t.asPlayer();
            return tp ? tp.getLevel() < p.getLevel() : true;
        }
        function cdMsg(p, k) { msg(p, "&cOn cooldown: " + Math.ceil(cd(p, k) / 1000) + "s"); }

        // MajinAbsorption: 4 s, target in 8 blocks, 3 slots, 600 s cooldown, 4 % copy, 30 % heal
        var MAJIN = { amount: 3, cooldown: 600, heal: 0.30, copy: 0.04, boosts: ["STR", "SKP", "PWR"] };
        // NamekAssimilation: 4 s, target in 3 blocks, 4 slots, 600 s cooldown, +7.5 % own stats, 35 % heal
        var NAMEK = { amount: 4, cooldown: 600, heal: 0.35, boost: 0.075, boosts: ["STR", "SKP", "PWR"] };
        // BioAndroidEvolution drain: instant, 3 blocks, 6 s channel, 25 % of max HP, TP x0.5, 180 s cooldown
        var BIO = { cooldown: 180, ratio: 0.25, tpRatio: 0.5, stunTicks: 120, channel: 5 };

        function which(p) { let r = race(p); return r === "majin" || r === "namekian" || r === "bioandroid" ? r : null; }
        function label(p) {
            let w = which(p);
            if (w === "majin") return "Absorption";
            if (w === "namekian") return "Assimilation";
            if (w === "bioandroid") return tier(p) === "perfect" ? "Cell Jr. (not available)" : "Vital Drain";
            return "";
        }
        function icon(p) {
            let w = which(p);
            return w === "majin" ? "absorption" : w === "namekian" ? "assimilation" : w === "bioandroid" ? (tier(p) === "perfect" ? "celljr" : "vitaldrain") : "racial";
        }
        function anim(p) { return which(p) === "bioandroid" ? "" : "transf.absorb"; }
        function canCharge(p, quiet) {
            let w = which(p), s = st(p);
            let say = (t) => { if (!quiet || RPG.server.getTick() - s.lastMsg > 40) { s.lastMsg = RPG.server.getTick(); msg(p, t); } };
            if (!w) return false;
            if (w === "majin") {
                if (cd(p, "absorb") > 0) { say("&cAbsorption on cooldown: " + Math.ceil(cd(p, "absorb") / 1000) + "s"); return false; }
                if (slots(p, "dmz_absorptions").length >= MAJIN.amount) { say("&cYou can't absorb anyone else."); return false; }
                let t = p.target(8);
                return !!t && eligible(p, t);
            }
            if (w === "namekian") {
                if (cd(p, "assim") > 0) { say("&cAssimilation on cooldown: " + Math.ceil(cd(p, "assim") / 1000) + "s"); return false; }
                if (slots(p, "dmz_assimilations").length >= NAMEK.amount) { say("&cYou can't assimilate anyone else."); return false; }
                let t = p.target(3);
                return !!t && namekTarget(p, t);
            }
            if (tier(p) === "perfect") { say("&7Cell Jr. summoning isn't available yet."); return false; }
            if (cd(p, "drain") > 0) { say("&cVital drain on cooldown: " + Math.ceil(cd(p, "drain") / 1000) + "s"); return false; }
            return true;
        }
        function step(p) {
            let w = which(p);
            if (w === "majin" || w === "namekian") return 25;                        // 100 / 4 s
            if (w === "bioandroid") { activate(p); stopCharge(p, -2); return 0; }    // chargeSeconds 0: right away
            return 0;
        }
        function namekTarget(p, t) {
            if (!eligible(p, t)) return false;
            let tp = t.asPlayer();
            if (tp) return tp.race === "namekian";
            let n = String(t.name || "");
            return n.indexOf("Namek") >= 0 || n.indexOf("Piccolo") >= 0;
        }

        function activate(p) {
            let w = which(p);
            if (w === "majin") return absorb(p);
            if (w === "namekian") return assimilate(p);
            if (w === "bioandroid") return drain(p);
            return false;
        }

        function absorb(p) {
            let t = p.target(8);
            if (!t || !eligible(p, t)) return true;
            let tp = t.asPlayer(), down = tp && tp.hasEffect("knocked_down");
            if (!down && !isStronger(p, t) && !creative(p)) { msg(p, "&cYour target is too strong to absorb."); return true; }
            setCd(p, "absorb", MAJIN.cooldown);
            let granted = {}, cap = DMZ_F.MAX_TOTAL;
            MAJIN.boosts.forEach((k) => {
                let src = tp ? tp.stat(DMZ_DATA.STAT_IDS[k]) : t.maxHealth;
                granted[k] = capped(src, MAJIN.copy, cap);
            });
            let list = slots(p, "dmz_absorptions");
            list.push({ n: String(t.name || "?"), s: granted, t: NOW() });
            p.setVar("dmz_absorptions", list);
            syncBonus(p);
            p.heal(p.maxHealth * MAJIN.heal);
            t.kill();
            sfx(p, "majin_absorb", 1, 1);
            msg(p, "&dAbsorbed " + t.name + "!");
            return true;
        }
        function capped(src, ratio, cap) {
            if (!(src > 0)) return 1;
            let b = Math.min(src, cap) * ratio;
            return b < 1 ? 1 : Math.floor(Math.min(b, cap));
        }
        function assimilate(p) {
            let t = p.target(3);
            if (!t || !namekTarget(p, t)) { msg(p, "&cYou can only assimilate a Namekian."); return true; }
            let tp = t.asPlayer();
            if (tp && !tp.hasEffect("knocked_down") && !creative(p)) { msg(p, "&cKnock " + tp.name + " down first."); return true; }
            setCd(p, "assim", NAMEK.cooldown);
            let granted = {};
            NAMEK.boosts.forEach((k) => { granted[k] = Math.max(1, Math.floor(Math.min(DMZ_F.MAX_VALUE, p.stat(DMZ_DATA.STAT_IDS[k]) * NAMEK.boost))); });
            let list = slots(p, "dmz_assimilations");
            list.push({ n: String(t.name || "?"), s: granted, t: NOW() });
            p.setVar("dmz_assimilations", list);
            syncBonus(p);
            p.heal(p.maxHealth * NAMEK.heal);
            t.kill();
            sfx(p, "stack_form", 1, 1);
            msg(p, "&aAssimilated " + t.name + "!");
            return true;
        }
        function drain(p) {
            let t = p.target(3);
            if (!t || !eligible(p, t)) return true;
            setCd(p, "drain", BIO.cooldown);
            let s = st(p), semi = tier(p) === "semi";
            s.drain = { uuid: t.uuid, until: RPG.server.getTick() + BIO.stunTicks, total: Math.round(t.maxHealth * BIO.ratio), drained: 0, semi: semi };
            behind(p, t);
            p.addEffect("absorbing", BIO.stunTicks);
            if (t.isPlayer()) t.asPlayer().addEffect("stunned", BIO.stunTicks); else t.addPotion("minecraft:slowness", BIO.stunTicks, 9);
            if (semi) p.setShared("drainSemiPerfect", 1);
            sfx(p, "tp_short", 1, 1);
            return true;
        }
        function behind(p, t) {
            let yaw = t.yaw * Math.PI / 180;
            p.teleport(t.x + Math.sin(yaw) * 0.75, t.y, t.z - Math.cos(yaw) * 0.75);
            p.lookAt(t.x, t.y + 1.2, t.z);
        }
        function drainTick(p, s, second) {
            let d = s.drain;
            if (!d) return;
            let t = RPG.world.entityByUuid(d.uuid);
            let over = RPG.server.getTick() >= d.until;
            if (!t || !t.isAlive() || p.distanceTo(t) >= 6 || over) {
                if (t && t.isAlive() && over) {
                    let yaw = p.yaw * Math.PI / 180, lx = -Math.sin(yaw), lz = Math.cos(yaw);
                    t.push(lx * 1.5, 0.5, lz * 1.5);
                    p.push(-lx, 0.3, -lz);
                    sfx(p, "knockback_character", 1, 1);
                }
                endDrain(p, s);
                return;
            }
            behind(p, t);
            if (!second) return;
            let per = Math.round(d.total / BIO.channel);
            t.setHealth(Math.max(1, t.health - per));
            if (p.health < p.maxHealth) p.heal(per);
            p.addResource("ki", per * 5);
            d.drained += per;
            sfx(p, "absorb1", 1, 1);
            if (t.health <= 1) {
                if (!d.semi) p.addTp(Math.round(d.drained * BIO.tpRatio));
                t.kill();
                endDrain(p, s);
            }
        }
        function endDrain(p, s) {
            s.drain = null;
            p.removeEffect("absorbing");
            p.setShared("drainSemiPerfect", null);
        }
        function secondary(p) {
            // DMZ: dismiss Cell Jrs (perfect Bio-Android); nothing else uses it by default
            if (which(p) === "bioandroid" && tier(p) === "perfect") msg(p, "&7No Cell Jr. to dismiss.");
        }

        // absorbed / assimilated stats are kept as allocated points; reconciled against the slots
        function syncBonus(p) {
            let want = {};
            ["dmz_absorptions", "dmz_assimilations"].forEach((k) => slots(p, k).forEach((sl) => {
                Object.keys(sl.s || {}).forEach((stat) => { want[stat] = (want[stat] || 0) + num(sl.s[stat], 0); });
            }));
            let have = obj(p.getVar("dmz_racial_applied", null)), changed = false;
            ["STR", "SKP", "RES", "VIT", "PWR", "ENE"].forEach((k) => {
                let diff = (want[k] || 0) - num(have[k], 0);
                if (!diff) return;
                p.addStat(DMZ_DATA.STAT_IDS[k], diff);
                have[k] = want[k] || 0;
                changed = true;
            });
            if (changed) { p.setVar("dmz_racial_applied", have); p.refreshStats(); }
        }
        function onDeath(p) {
            let w = which(p);
            if (w === "majin" && slots(p, "dmz_absorptions").length) { p.setVar("dmz_absorptions", []); syncBonus(p); }
            if (w === "namekian") {
                let l = slots(p, "dmz_assimilations");
                if (l.length) { l.pop(); p.setVar("dmz_assimilations", l); syncBonus(p); }
            }
            let s = st(p);
            if (s.drain) endDrain(p, s);
        }
        function info(p) {
            let w = which(p);
            if (!w) return null;
            let list = w === "majin" ? slots(p, "dmz_absorptions") : w === "namekian" ? slots(p, "dmz_assimilations") : [];
            let cdKey = w === "majin" ? "absorb" : w === "namekian" ? "assim" : "drain";
            return { label: label(p), icon: icon(p), slots: list.map((x) => x.n), max: w === "majin" ? MAJIN.amount : w === "namekian" ? NAMEK.amount : 0,
                cooldown: Math.ceil(cd(p, cdKey) / 1000) };
        }
        function eject(p, i) {
            // MajinAbsorption.ejectSlot (300 s cooldown for that slot is simplified to the shared one)
            if (which(p) !== "majin") return;
            let l = slots(p, "dmz_absorptions");
            if (i < 0 || i >= l.length) return;
            l.splice(i, 1);
            p.setVar("dmz_absorptions", l);
            syncBonus(p);
        }
        return { canCharge: canCharge, step: step, activate: activate, anim: anim, drainTick: drainTick, secondary: secondary, syncBonus: syncBonus,
            onDeath: onDeath, info: info, eject: eject, which: which };
    })();

    // =================================================================================
    //  False Super Saiyan (FalseSuperSaiyanEvents): a rage bar for low-level Saiyans
    // =================================================================================
    var FSSJ = (function () {
        var CFG = { minLevel: 100, maxLevel: 200, hp: 0.25, dealt: 60, taken: 150, cap: 25, worthy: 0.10, takenMin: 0.01, activeMult: 0.5,
            idle: 10, grace: 2000, drain: 8, activeDrain: 12 };
        var LAST = {};
        function active(p) { let f = activeForm(p); return !!f && f.group === "falseform"; }
        function base(p) {
            if (race(p) !== "saiyan" || p.getVar("dmz_mutant", 0) || skill(p, "superforms") > 0) return false;
            let lvl = p.getLevel();
            return lvl >= CFG.minLevel && lvl < CFG.maxLevel;
        }
        function canCharge(p) { return base(p) && !activeForm(p) && !p.hasEffect("knocked_down") && p.health <= p.maxHealth * CFG.hp; }
        function rage(p) { return num(p.getVar("dmz_rage", 0), 0); }
        function setRage(p, v) { v = Math.round(Math.max(0, Math.min(100, v)) * 1000) / 1000; if (v !== rage(p)) p.setVar("dmz_rage", v); }
        function add(p, gain) {
            if (active(p)) gain *= CFG.activeMult;
            gain = Math.min(gain, CFG.cap);
            LAST[p.uuid] = Date.now();
            if (gain > 0) setRage(p, rage(p) + gain);
        }
        function canGain(p) { return !p.hasEffect("knocked_down") && (active(p) || canCharge(p)); }
        function transform(p) {
            p.setVar("dmz_prev", null);
            p.setVar("dmz_form", "falseform:falsesupersaiyan");
            setRage(p, 100);
            sfx(p, "transform_on", 1, 1);
            p.tell("&e&lYour rage explodes... False Super Saiyan!");
            refresh(p);
        }
        function end(p) {
            let was = active(p);
            setRage(p, 0);
            delete LAST[p.uuid];
            if (!was) return;
            p.setVar("dmz_prev", null);
            revertBase(p, false);
            sfx(p, "insta_form_off", 1, 1);
            p.tell("&7Your rage fades.");
        }
        // every 2 ticks (DMZ: every tick, so the per-tick amounts are doubled)
        function tick(p) {
            let on = active(p);
            let forced = on || canCharge(p) ? 1 : 0;
            if (num(p.getVar("dmz_forced_aura", 0), 0) !== forced) p.setVar("dmz_forced_aura", forced);
            if (!on && !base(p)) return;
            if (on && !base(p)) { end(p); return; }
            if (p.hasEffect("knocked_down")) return;
            if (!on) {
                if (canCharge(p)) {
                    if (rage(p) >= 100) { transform(p); return; }
                    setRage(p, rage(p) + CFG.idle / 10);
                    if (rage(p) >= 100) transform(p);
                    return;
                }
                if (rage(p) <= 0) return;
            }
            if (LAST[p.uuid] && Date.now() - LAST[p.uuid] <= CFG.grace) return;
            setRage(p, rage(p) - 2 * 100 / ((on ? CFG.activeDrain : CFG.drain) * 20));
            if (on && rage(p) <= 0) end(p);
        }
        function onDamage(e) {
            let amount = Math.min(e.amount, e.target.health);
            let hurt = e.target.isPlayer() ? e.target.asPlayer() : null;
            if (hurt && hurt.getVar("dmz_created", 0) && canGain(hurt)) {
                let frac = amount / Math.max(1, hurt.maxHealth);
                if (frac >= CFG.takenMin) add(hurt, frac * CFG.taken);
            }
            let a = e.attacker && e.attacker.isPlayer() ? e.attacker.asPlayer() : null;
            if (a && a !== hurt && a.getVar("dmz_created", 0) && canGain(a)) {
                let t = e.target, worthy = t.isPlayer() || (t.maxHealth >= a.maxHealth * CFG.worthy && !(t.health >= t.maxHealth * 0.99 && e.amount >= t.health));
                if (worthy) add(a, amount / Math.max(1, t.maxHealth) * CFG.dealt);
            }
        }
        return { tick: tick, onDamage: onDamage, end: end };
    })();

    // =================================================================================
    //  Oozaru: charge by looking at the full moon (TransformationsHelper.shouldAutoChargeOozaru)
    // =================================================================================
    function seesFullMoon(p) {
        if (p.dimension !== "minecraft:overworld") return false;
        let t = RPG.world.getTime(p.dimension), day = Math.floor(t / 24000), tod = t % 24000;
        if (!(tod > 12542 && tod < 23460) || day % 8 !== 0) return false;      // night, full moon
        if (p.pitch > -71.8) return false;                                       // lookAngle.y > 0.95
        let up = RPG.world.raycast(p.dimension, p.x, p.y + 1.6, p.z, 0, 1, 0, 320, { blocks: true, entities: false });
        return !up || up.hit === "none";
    }
    function shouldAutoOozaru(p) {
        if (action(p) !== "FORM" || activeForm(p) || activeStack(p)) return false;
        let n = nextForm(p);
        return !!n && n.id === "oozaru" && seesFullMoon(p);
    }

    // =================================================================================
    //  Ticking
    // =================================================================================
    function second(p, s) {
        ensureSelection(p);
        // android-upgraded humans live in androidbase
        if (android(p) && race(p) === "human" && !activeForm(p)) setForm(p, "androidforms", "androidbase");
        let f = activeForm(p), sf = activeStack(p);
        // a stale form from another race / removed config
        if (p.getVar("dmz_form", "") && !f) setForm(p, null, null);
        if (p.getVar("dmz_stack", "") && !sf) setStack(p, null, null);
        // Oozaru needs the tail
        if (f && f.group === "oozaru" && f.tailOnly && !hasTail(p)) revertBase(p, false);
        // edited level / alignment gates also apply while transformed (alignment can drop mid-form)
        if (f && f.id !== "androidbase" && gateBlock(p, f)) { msg(p, gateBlock(p, f)); revertBase(p, false); }
        if (sf && gateBlock(p, sf)) clearStack(p, false);
        f = activeForm(p); sf = activeStack(p);
        // passive mastery: once every 6 s while transformed
        if (f || sf) {
            if (++s.passive >= 6) {
                s.passive = 0;
                if (f) addMastery(p, f, per(f, "passive") * potionMult(p));
                if (sf) addMastery(p, sf, per(sf, "passive") * potionMult(p));
            }
        }
        // drains, then the 5 % ki rule
        drainTick(p);
        f = activeForm(p); sf = activeStack(p);
        if ((f || sf) && !(f && f.android) && !creative(p) && !inScripted(p) && p.resource("ki") <= p.maxResource("ki") * 0.05) {
            if (!clampFloor(p)) revertBase(p, false);
            clearStack(p, true);
            p.setVar("dmz_release", 0);
            stopCharge(p, -2);
            sfx(p, "no_ki_form", 1, 1);
            msg(p, "&cYou ran out of ki and lost your transformation.");
        }
        // moon
        if (shouldAutoOozaru(p)) startCharge(p, "form", 0);
        else if (s.charging && s.key === 0) stopCharge(p, 0);
        // keys that are held but haven't started (e.g. Alt let go while G is still down)
        if (s.held && !s.charging && !s.chord[17] && !s.chord[19] && !s.chord[20]) startCharge(p, kindFor(p), 12);
        RACIAL.syncBonus(p);
        refresh(p);
    }

    var TICK = 0;
    RPG.every(2, () => {
        TICK += 2;
        RPG.server.players().forEach((p) => {
            if (!p.getVar("dmz_created", 0) || !p.alive) return;
            let s = st(p);
            if (s.charging) {
                if (p.hasEffect("stunned") || p.hasEffect("absorbing")) stopCharge(p, -2);
                else advance(p, s);
            }
            if (s.drain) RACIAL.drainTick(p, s, TICK % 20 === 0);
            FSSJ.tick(p);
            let kiNow = p.hasEffect("ki_charge");
            if (TICK % 20 === 0) second(p, s);
            else if (TICK % 10 === 0 || kiNow !== s.kiWas) refresh(p);    // aura on/off with ki charging and flight
            s.kiWas = kiNow;
            if (TICK % 10 === 0) effects(p, s);
        });
    });
    // lightning (hasLightnings: shown in any aura state) and the aura's ground dust
    function effects(p, s) {
        let f = activeForm(p), sf = activeStack(p);
        let bolt = (sf && sf.bolt) || (f && f.bolt);
        if (bolt) {
            burst(p, "minecraft:electric_spark", 6, 0.6, 0.1);
            if (TICK % 60 === 0) sfx(p, "ki_sparks", 0.3, 0.9 + Math.random() * 0.2);
        }
        if (s.fx && s.fx.indexOf("dmz_aura_") >= 0 && p.onGround && Math.random() < 0.5) {
            let sc = FD.scaleOf(race(p), f)[0];
            RPG.world.particle(p.dimension, "minecraft:cloud", p.x, p.y + 0.15, p.z, 8, 0.75 * sc, 0.06);
        }
    }

    // ---- mastery from hits (StatsEvents.onLivingHurt) ----
    RPG.on("damageFinal", (e) => {
        if (e.isCancelled() || !e.target) return;
        if (e.amount > 0) FSSJ.onDamage(e);
        if (e.amount < 1) return;
        let a = e.attacker && e.attacker.isPlayer() ? e.attacker.asPlayer() : null;
        let v = e.target.isPlayer() ? e.target.asPlayer() : null;
        let scale = 1 + 3 * Math.max(0, Math.min(1, (e.amount / Math.max(1, e.target.maxHealth) - 0.2) / 0.6));
        [a, v].forEach((p, i) => {
            if (!p || !p.getVar("dmz_created", 0) || release(p) < 50) return;
            if (i === 1 && !e.attacker) return;                        // hit by a living entity
            let x = scale * potionMult(p);
            let f = activeForm(p), sf = activeStack(p);
            if (f) addMastery(p, f, per(f, "perHit") * x);
            if (sf) addMastery(p, sf, per(sf, "perHit") * x);
        });
    });

    RPG.on("death", (p) => {
        stopCharge(p, -2);
        RACIAL.onDeath(p);
        p.setVar("dmz_rage", 0); p.setVar("dmz_forced_aura", 0);
        p.setVar("dmz_stack", "");
        p.setVar("dmz_prev", null); p.setVar("dmz_prev_stack", null);
        p.setVar("dmz_form", android(p) && race(p) === "human" ? "androidforms:androidbase" : "");
        st(p).sweep = false;
    });
    RPG.on("respawn", (p) => { st(p).sweep = false; RPG.schedule(2, () => refresh(p)); });
    RPG.on("playerJoin", (p) => { delete ST[p.uuid]; RPG.schedule(20, () => { st(p).sweep = false; refresh(p); }); });
    RPG.on("playerLeave", (p) => { delete ST[p.uuid]; });
    RPG.on("raceChange", (p) => {
        RPG.schedule(1, () => {
            ["dmz_form", "dmz_stack", "dmz_sel", "dmz_sel_stack"].forEach((k) => p.setVar(k, ""));
            p.setVar("dmz_prev", null); p.setVar("dmz_prev_stack", null);
            st(p).sweep = false;
            refresh(p);
        });
    });

    // =================================================================================
    //  Keys (45_keys.js calls these) and the form menu
    // =================================================================================
    function kindFor(p) { let a = action(p); return a === "STACK" ? "stack" : a === "RACIAL" ? "racial" : "form"; }
    // action mode FUSION: G charges the Fusion Dance instead (64_dmz_fusion.js)
    function fusionKey(p, phase) {
        if (String(p.getVar("dmz_action", "") || "") !== "FUSION" || typeof DMZ_FUSION === "undefined") return false;
        DMZ_FUSION.key(p, phase);
        return true;
    }
    var KEYS = {
        // G (key 12): hold to charge the selected action, double-tap = instant
        actionPress(p) { if (fusionKey(p, "press")) return; let s = st(p); s.held = true; if (s.chord[17] || s.chord[19] || s.chord[20]) return; startCharge(p, kindFor(p), 12); },
        actionHold(p) { if (fusionKey(p, "hold")) return; let s = st(p); if (!s.charging && !s.chord[17] && !s.chord[19] && !s.chord[20]) startCharge(p, kindFor(p), 12); },
        actionRelease(p) { fusionKey(p, "release"); let s = st(p); s.held = false; stopCharge(p, 12); },
        actionDoubleTap(p) { if (String(p.getVar("dmz_action", "") || "") === "FUSION") return; if (kindFor(p) !== "racial") instant(p); },
        // Alt+G (key 17): descend (FORM/STACK) / racial secondary (RACIAL)
        descendPress(p) {
            let s = st(p); s.chord[17] = true; stopCharge(p, 12);
            if (action(p) === "RACIAL") RACIAL.secondary(p); else descend(p, false, false);
        },
        descendRelease(p) { st(p).chord[17] = false; },
        // Ctrl+G (key 19): hold to charge the next stack form
        stackPress(p) { let s = st(p); s.chord[19] = true; stopCharge(p, 12); startCharge(p, "stack", 19); },
        stackRelease(p) { st(p).chord[19] = false; stopCharge(p, 19); },
        stackDoubleTap(p) { instantStack(p); },
        // key 20: hold to charge the racial action
        racialPress(p) { let s = st(p); s.chord[20] = true; stopCharge(p, 12); startCharge(p, "racial", 20); },
        racialRelease(p) { st(p).chord[20] = false; stopCharge(p, 20); },
        // X (key 18): the menu
        menu(p) { sendState(p, true); }
    };

    function formInfo(p, g, f, stack) {
        let unlocked = formUnlocked(p, f), mOk = meetsMastery(p, f);
        let req = null;
        if (f.req) { let t = String(f.req).split(",")[0], dot = t.indexOf("."); req = { f: t.substring(dot + 1), need: f.unlockOn }; }
        return { id: f.id, n: f.n, lvl: f.lvl, aura: f.aura || "", unlocked: unlocked, mastery: Math.floor(mastery(p, f) * 100) / 100, maxMastery: f.maxMastery,
            masteryOk: mOk, selectable: selectable(p, g, f, stack), free: f.free, req: req, m: f.m, ki: f.ki, saga: f.saga,
            tail: g.id === "oozaru" && f.tailOnly && !hasTail(p) };
    }
    function sendState(p, open) {
        if (!p.getVar("dmz_created", 0)) return;
        ensureSelection(p);
        let r = race(p);
        let groups = FD.groups(r).filter((g) => groupAllowed(p, g)).map((g) => ({
            id: g.id, n: g.n, type: g.type, skill: FD.skillFor(g.type), level: skill(p, FD.skillFor(g.type)),
            forms: g.forms.map((f) => formInfo(p, g, f, false))
        }));
        let stacks = FD.STACKS.filter((g) => skill(p, g.type) > 0 && (typeof DMZ_SKILLS_DATA === "undefined" || DMZ_SKILLS_DATA.allowed(g.type, r, android(p)))).map((g) => ({
            id: g.id, n: g.n, type: g.type, level: skill(p, g.type), forms: g.forms.map((f) => formInfo(p, g, f, true))
        }));
        RPG.net.send(p, "dmz_tf_state", {
            open: !!open, race: r, action: action(p), groups: groups, stacks: stacks,
            sel: String(p.getVar("dmz_sel", "") || ""), selStack: String(p.getVar("dmz_sel_stack", "") || ""),
            form: String(p.getVar("dmz_form", "") || ""), stack: String(p.getVar("dmz_stack", "") || ""),
            aura: !!p.getVar("dmz_aura_perm", 0), kicontrol: hasSkill(p, "kicontrol"), racial: RACIAL.info(p)
        });
    }

    RPG.net.on("dmz_tf", (p, d) => {
        if (!d || !p.getVar("dmz_created", 0) || p.hasEffect("stunned")) return;
        let op = String(d.op || ""), r = race(p);
        if (op === "select") {
            let stack = !!d.stack, gid = String(d.g || ""), fid = String(d.f || "");
            let g = stack ? FD.stackGroup(gid) : FD.group(r, gid), f = g ? (stack ? FD.stackForm(gid, fid) : FD.form(r, gid, fid)) : null;
            if (!g || !f || (!stack && !groupAllowed(p, g)) || !selectable(p, g, f, stack)) { sendState(p, false); return; }
            p.setVar(stack ? "dmz_sel_stack" : "dmz_sel", gid + ":" + fid);
            p.setVar("dmz_action", stack ? "STACK" : "FORM");
            if (d.instant) instant(p);
        } else if (op === "mode") {
            let m = String(d.mode || "FORM");
            if (m === "RACIAL" && !RACIAL.which(p)) return;
            if (m === "FORM" || m === "STACK" || m === "RACIAL") p.setVar("dmz_action", m);
        } else if (op === "aura") {
            if (hasSkill(p, "kicontrol")) p.setVar("dmz_aura_perm", p.getVar("dmz_aura_perm", 0) ? 0 : 1);
            else msg(p, "&cYou need Ki Control for a permanent aura.");
        } else if (op === "descend") {
            descend(p, true, !!d.all);
        } else if (op === "eject") {
            RACIAL.eject(p, Math.floor(num(d.i, -1)));
        }
        refresh(p);
        sendState(p, false);
    });

    // ---- ops ----
    RPG.commands.register("dmzform", {
        permission: 2, description: "/rpgc dmzform <group> <form>|base|mastery <group> <form> <n> [player] - set a DMZ form or its mastery",
        run(p, args) {
            if (args[0] === "mastery") {
                let target = args[4] ? RPG.server.player(args[4]) : p;
                if (!target) return;
                let f = FD.form(race(target), String(args[1]), String(args[2])) || FD.stackForm(String(args[1]), String(args[2]));
                if (!f) { if (p) p.tell("&cUnknown form"); return; }
                let map = masteryMap(target, stackOrForm(f));
                map[f.key] = Math.max(0, Math.min(f.maxMastery, num(args[3], 0)));
                target.setVar(stackOrForm(f) ? "dmz_stack_mastery" : "dmz_mastery", map);
                refresh(target);
                if (p) p.tell("&a" + f.n + " mastery -> " + map[f.key]);
                return;
            }
            let target = args[2] ? RPG.server.player(args[2]) : p;
            if (!target) return;
            if (args[0] === "base" || !args[0]) { clearStack(target, true); setForm(target, null, null); return; }
            let f = FD.form(race(target), String(args[0]), String(args[1]));
            let sf = f ? null : FD.stackForm(String(args[0]), String(args[1]));
            if (f) setForm(target, f.group, f.id);
            else if (sf) setStack(target, sf.group, sf.id);
            else if (p) p.tell("&cUnknown form for " + race(target));
        }
    });

    return { KEYS: KEYS, activeForm: activeForm, activeStack: activeStack, nextForm: nextForm, nextStack: nextStack, mastery: mastery, addMastery: addMastery,
        descend: descend, instant: instant, refresh: refresh, sendState: sendState, totals: totals, adjusted: adjusted, effective: effective,
        setForm: setForm, setStack: setStack, RACIAL: RACIAL, startCharge: startCharge, stopCharge: stopCharge, selectable: selectable,
        unlockedForms: unlockedForms, ensureSelection: ensureSelection, race: race };
})();
