# Dragon Block Ragnarok

Dragon Block Ragnarok is an addon for the Ragnarok RPG Toolkit. Its gameplay systems are a port of
**DragonMine Z** (https://github.com/DragonMineZ/dragonminez), rewritten as toolkit scripts.

- DragonMine Z is Copyright (c) DragonMine Z 2025 and is licensed under the GNU General Public License v3.0.
- This addon is a modified version of that work and is likewise licensed under the **GNU General Public
  License v3.0** (see `LICENSE`). Its scripts are its complete source code.
- Models, textures, animations and sounds come from DragonMine Z through the separate `dmzpack` asset pack,
  which carries its own credits, including CC-BY attributions for third-party sounds.
- Changes: DragonMine Z's Java systems were reimplemented as JavaScript for the Ragnarok RPG Toolkit's script
  engine; content and balance are adapted to that engine.
- The structure templates in `datapack/data/dbr/structures/dmz/` and their descriptions in `data/dmz_structures/`
  are converted from DragonMine Z's structure files, Other World region files and tournament schematic
  (split into 32x32 pieces, DMZ blocks mapped to this addon's blocks or vanilla stand-ins). The chest loot
  tables in `datapack/data/dbr/loot_tables/chests/` are DragonMine Z's.

- The hair system (`shared/11_dmz_hair.js`) ports DragonMine Z's strand hair (hair codes, presets, per-form styles,
  physics profiles); `client/data/dmz_hair_presets.json` and `shared/10_dmz_hair_presets.js` are DragonMine Z's
  hair preset codes, decoded with that file's decoder.

- The in-game form editor (`scripts/32_dbr_form_editor.js`, `client/scripts/70_form_editor.js`) ports the form
  editor screens and form data workflow of DMZ Ragnarok, a GPL-3.0 Forge addon for DragonMine Z.

- The rgnpc NPC cast (`scripts/62_rg_npcs.js`, `shared/14_rg_npc_data.js`, `client/scripts/71_rg_npc_picker.js`,
  `resources/assets/dbr/geo|textures/entity/rgnpc/`) is DMZ Ragnarok's
  rgnpc display NPC table, models and sizes (GPL-3.0). The `saga_*` and `master_*` models and their textures are
  derived from NinjinEntities (kaixi, Vidal1sHere, Phoenix_II) under the MIT License; its notice is
  `NINJIN-LICENSE.txt` in those folders. The shadow dragon models (`2stars` .. `7starstrue`, `omega`, `omega2`) are
  DMZ Ragnarok's own art. The `dmzpack` asset pack also carries DMZ Ragnarok's RagnaPack textures (see its credits).

- The space system (`scripts/86_dbr_space.js`, `client/scripts/61_dbr_space.js`, the `ragnarok_rpg:space` dimension in
  `datapack/`) ports the behaviour of DMZ Ragnarok's Space module (GPL-3.0): the sun-centred planet rings and their
  wall-clock orbits (Orbits / PlanetPositions), entering space above the entry altitude and leaving below the return
  altitude, landing on planets, the star map with autopilot, the planet info overlay and the radar. The planet, sun,
  ring and cloud textures in `resources/assets/dbr/textures/space/` are DMZ Ragnarok's (its solar system pack and
  planet sheets).

Dragon Ball is a trademark of its respective owners. This is a non-commercial fan project.
