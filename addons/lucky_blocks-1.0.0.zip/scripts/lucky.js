// =====================================================================================
//  Lucky Blocks - break one and something happens. Add your own outcomes to LUCKY.outcomes:
//  { weight, luck: "good" | "bad" | "meh", run(player, dim, x, y, z) }
// =====================================================================================
(function () {
    var LUCKY = {
        oreDropChance: 0.04,      // chance a mined gold ore also drops a lucky block
        outcomes: []
    };
    function add(weight, luck, run) { LUCKY.outcomes.push({ weight: weight, luck: luck, run: run }); }
    function drop(d, x, y, z, item, n) { RPG.world.dropItem(d, x + 0.5, y + 0.5, z + 0.5, item, n); }
    function ench(id, list, name) {
        return { id: id, name: name, nbt: "{Enchantments:[" + list.map((e) => "{id:\"minecraft:" + e[0] + "\",lvl:" + e[1] + "s}").join(",") + "]}" };
    }
    function mobs(d, x, y, z, type, n) { for (let i = 0; i < n; i++) RPG.world.spawn(d, type, x + 0.5 + (Math.random() - 0.5) * 3, y + 0.2, z + 0.5 + (Math.random() - 0.5) * 3); }

    // ---- good ----
    add(10, "good", (p, d, x, y, z) => drop(d, x, y, z, "minecraft:diamond", 2 + Math.floor(Math.random() * 4)));
    add(8,  "good", (p, d, x, y, z) => drop(d, x, y, z, "minecraft:iron_ingot", 8 + Math.floor(Math.random() * 16)));
    add(8,  "good", (p, d, x, y, z) => drop(d, x, y, z, "minecraft:gold_ingot", 8 + Math.floor(Math.random() * 12)));
    add(6,  "good", (p, d, x, y, z) => drop(d, x, y, z, "minecraft:emerald", 4 + Math.floor(Math.random() * 8)));
    add(5,  "good", (p, d, x, y, z) => drop(d, x, y, z, "minecraft:golden_apple", 2));
    add(1,  "good", (p, d, x, y, z) => drop(d, x, y, z, "minecraft:enchanted_golden_apple", 1));
    add(2,  "good", (p, d, x, y, z) => drop(d, x, y, z, "minecraft:totem_of_undying", 1));
    add(6,  "good", (p, d, x, y, z) => drop(d, x, y, z, "minecraft:experience_bottle", 16));
    add(4,  "good", (p) => p.giveStack(ench("minecraft:diamond_sword", [["sharpness", 4], ["looting", 2]], "&bLucky Blade")));
    add(4,  "good", (p) => p.giveStack(ench("minecraft:diamond_pickaxe", [["efficiency", 4], ["fortune", 2]], "&bLucky Pick")));
    add(3,  "good", (p) => ["helmet", "chestplate", "leggings", "boots"].forEach((s) => p.giveStack(ench("minecraft:iron_" + s, [["protection", 3]], null))));
    add(3,  "good", (p, d, x, y, z) => { drop(d, x, y, z, "minecraft:bow", 1); drop(d, x, y, z, "minecraft:arrow", 32); });
    add(4,  "good", (p, d, x, y, z) => drop(d, x, y, z, "minecraft:cake", 1));
    add(3,  "good", (p) => { p.addPotion("minecraft:speed", 1200, 1); p.addPotion("minecraft:strength", 1200, 1); p.addPotion("minecraft:regeneration", 400, 1); p.tell("&a&lYou feel powerful!"); });
    add(2,  "good", (p, d, x, y, z) => {
        // a lucky pig that drops loot when killed
        let pig = RPG.world.spawn(d, "minecraft:pig", x + 0.5, y, z + 0.5);
        if (pig) { pig.setGlowing(true); p.tell("&dA lucky pig appeared! Catch it!"); }
        drop(d, x, y, z, "minecraft:saddle", 1);
    });
    add(2,  "good", (p, d, x, y, z) => {
        // a pillar of gold blocks
        for (let i = 0; i < 5; i++) RPG.world.setBlock(d, x, y + i, z, "minecraft:gold_block");
        p.tell("&6A golden pillar!");
    });
    add(2,  "good", (p, d, x, y, z) => {
        // a small hidden room with a diamond block
        RPG.world.fill(d, x - 2, y - 5, z - 2, x + 2, y - 1, z + 2, "minecraft:stone_bricks", "hollow");
        RPG.world.setBlock(d, x, y - 4, z, "minecraft:diamond_block");
        RPG.world.setBlock(d, x, y - 1, z, "minecraft:air");
        p.tell("&bThere's something under your feet...");
    });
    add(3,  "good", (p, d, x, y, z) => {
        // fireworks
        for (let i = 0; i < 5; i++) RPG.schedule(i * 6, () => RPG.server.runCommand("summon minecraft:firework_rocket " + (x + Math.random() * 2) + " " + (y + 1) + " " + (z + Math.random() * 2) + " {LifeTime:20,FireworksItem:{id:\"minecraft:firework_rocket\",Count:1,tag:{Fireworks:{Explosions:[{Type:1,Colors:[I;16766720,16711680]}]}}}}"));
        drop(d, x, y, z, "minecraft:diamond", 1);
    });

    // ---- meh ----
    add(5, "meh", (p, d, x, y, z) => drop(d, x, y, z, "minecraft:dirt", 64));
    add(4, "meh", (p, d, x, y, z) => drop(d, x, y, z, "minecraft:rotten_flesh", 16));
    add(3, "meh", (p, d, x, y, z) => { p.setVelocity(0, 2.2, 0); p.addPotion("minecraft:slow_falling", 200, 0); p.tell("&eWheee!"); });
    add(3, "meh", (p, d, x, y, z) => { mobs(d, x, y, z, "minecraft:chicken", 8); p.tell("&eChickens!"); });

    // ---- bad ----
    add(5, "bad", (p, d, x, y, z) => { mobs(d, x, y, z, "minecraft:zombie", 4); p.tell("&cAmbush!"); });
    add(4, "bad", (p, d, x, y, z) => { mobs(d, x, y, z, "minecraft:skeleton", 3); });
    add(3, "bad", (p, d, x, y, z) => { mobs(d, x, y, z, "minecraft:creeper", 2); p.tell("&cSsssss..."); });
    add(3, "bad", (p, d, x, y, z) => { RPG.world.spawn(d, "minecraft:tnt", x + 0.5, y, z + 0.5); p.tell("&cRun!"); });
    add(3, "bad", (p, d, x, y, z) => { RPG.world.lightning(d, p.x, p.y, p.z, false); });
    add(3, "bad", (p, d, x, y, z) => { RPG.world.setBlock(d, Math.floor(p.x), Math.floor(p.y) + 6, Math.floor(p.z), "minecraft:anvil"); p.tell("&cLook up!"); });
    add(3, "bad", (p, d, x, y, z) => {
        // cobweb trap
        let px = Math.floor(p.x), py = Math.floor(p.y), pz = Math.floor(p.z);
        RPG.world.fill(d, px - 1, py, pz - 1, px + 1, py + 1, pz + 1, "minecraft:cobweb", "keep");
        mobs(d, x, y, z, "minecraft:spider", 2);
    });
    add(3, "bad", (p) => { p.addPotion("minecraft:blindness", 200, 0); p.addPotion("minecraft:slowness", 300, 2); p.addPotion("minecraft:hunger", 300, 1); p.tell("&cYou feel awful."); });
    add(2, "bad", (p, d, x, y, z) => {
        // a glass cage around the player
        let px = Math.floor(p.x), py = Math.floor(p.y), pz = Math.floor(p.z);
        RPG.world.fill(d, px - 1, py - 1, pz - 1, px + 1, py + 2, pz + 1, "minecraft:glass", "hollow");
        p.tell("&cTrapped! Dig your way out.");
    });
    add(1, "bad", (p, d, x, y, z) => { RPG.world.spawn(d, "minecraft:ravager", x + 0.5, y, z + 0.5); p.tell("&4Uh oh."); });

    function roll() {
        let total = 0;
        LUCKY.outcomes.forEach((o) => total += o.weight);
        let r = Math.random() * total;
        for (let i = 0; i < LUCKY.outcomes.length; i++) { r -= LUCKY.outcomes[i].weight; if (r <= 0) return LUCKY.outcomes[i]; }
        return LUCKY.outcomes[0];
    }

    var BLOCK = "ragnarok_rpg:" + RPG.blocks.define("lucky_block", {
        name: "&eLucky Block", model: "lucky:rpg/block/lucky_block", hardness: 0.4, drops: "none", light: 6,
        onBreak(player, x, y, z) {
            if (!player) return;
            let o = roll(), d = player.dimension;
            RPG.world.particle(d, "minecraft:happy_villager", x + 0.5, y + 0.5, z + 0.5, 20, 0.5, 0.1);
            RPG.world.sound(d, o.luck === "bad" ? "minecraft:entity.witch.celebrate" : "minecraft:entity.player.levelup", x, y, z, 0.8, 1.2);
            // run next tick, once the block is gone
            RPG.schedule(1, () => o.run(player, d, x, y, z));
        }
    });

    RPG.recipes.addShaped("lucky_block", ["GGG", "GDG", "GGG"], { G: "minecraft:gold_ingot", D: "minecraft:dropper" }, { id: BLOCK, count: 1 });

    // mining gold ore can turn up a lucky block
    RPG.on("blockBreak", (p, block, x, y, z, dim) => {
        if ((block === "minecraft:gold_ore" || block === "minecraft:deepslate_gold_ore") && Math.random() < LUCKY.oreDropChance) {
            RPG.schedule(1, () => RPG.world.dropItem(dim, x + 0.5, y + 0.5, z + 0.5, BLOCK, 1));
        }
    });

    RPG.commands.register("lucky", {
        root: true, permission: "lucky.give", description: "Get lucky blocks: /lucky [amount] [player]",
        run(p, args) {
            let n = args.length ? Math.max(1, Math.min(64, parseInt(args[0]) || 1)) : 1;
            let t = args.length > 1 ? RPG.server.player(args[1]) : p;
            if (!t) { if (p) p.tell("&cWho?"); return; }
            t.giveStack({ id: BLOCK, count: n });
            if (p) p.tell("&eGave " + n + " lucky block" + (n === 1 ? "" : "s") + ".");
        }
    });
    RPG.perms.group("admin", ["lucky.*"]);
})();
