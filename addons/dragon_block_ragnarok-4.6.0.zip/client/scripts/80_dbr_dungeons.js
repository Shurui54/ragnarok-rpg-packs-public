// =====================================================================================
//  80_dbr_dungeons.js - DMZ Ragnarok's Dungeons: the screens
// =====================================================================================
//  Port of DMZ Ragnarok's dungeon GUIs (GPL-3.0): DungeonConfigScreen (Floors / Settings tabs),
//  DungeonFloorEditScreen (General / Loot / Spawners tabs), AdvancedSpawnerScreen (General, Stats,
//  Ki, Spawn, Rewards, Drops, Boss, Disguise), DropListEditor and the crate reward reveal
//  (ClientCrateRolls). Labels and tooltips are DMZR's own strings (client/data/dbr_dungeons/).
//  Drawn with DragonMine Z's menubig panel like the rest of DBR's DMZ screens.
//  Plus the Dungeon Gate floor picker (DBR has no Shurui's Utilities portals to walk through).
//  Server: scripts/90_dbr_dungeons*.js.
// =====================================================================================
(function () {
    var U = DMZ_UI, FONT = U.FONT;
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png", BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var LANG = RPG.files.read("dbr_dungeons/lang_en_us.json") || {};
    function T(key, fb) {
        var s = LANG[key];
        if (s === undefined) return fb !== undefined ? fb : key;
        var args = Array.prototype.slice.call(arguments, 2), i = 0;
        s = s.replace(/%(\d+)\$s/g, function (m, n) { var v = args[Number(n) - 1]; return v === undefined ? "" : String(v); });
        return s.replace(/%s/g, function () { var v = args[i++]; return v === undefined ? "" : String(v); }).replace(/%%/g, "%");
    }
    function clone(o) { return JSON.parse(JSON.stringify(o)); }
    function cap(s) { s = String(s).toLowerCase().replace(/_/g, " "); return s.charAt(0).toUpperCase() + s.substring(1); }
    function themeName(t) { return T("gui.opt.theme." + String(t).toLowerCase(), cap(t)); }
    function styleName(s) { return s ? T("gui.opt.layout." + String(s).toLowerCase(), cap(s)) : T("gui.opt.layout.default", "(default)"); }

    // ---- menubig nine-slice panel (DmzTextures.panel) ----
    function panel(ctx, x, y, w, h) {
        var b = 7, PW = 141, PH = 213, A = 256;
        ctx.image(MENU_BIG, x, y, b, b, 0, 0, b, b, A, A);
        ctx.image(MENU_BIG, x + w - b, y, b, b, PW - b, 0, b, b, A, A);
        ctx.image(MENU_BIG, x, y + h - b, b, b, 0, PH - b, b, b, A, A);
        ctx.image(MENU_BIG, x + w - b, y + h - b, b, b, PW - b, PH - b, b, b, A, A);
        ctx.image(MENU_BIG, x + b, y, w - 2 * b, b, b, 0, PW - 2 * b, b, A, A);
        ctx.image(MENU_BIG, x + b, y + h - b, w - 2 * b, b, b, PH - b, PW - 2 * b, b, A, A);
        ctx.image(MENU_BIG, x, y + b, b, h - 2 * b, 0, b, b, PH - 2 * b, A, A);
        ctx.image(MENU_BIG, x + w - b, y + b, b, h - 2 * b, PW - b, b, b, PH - 2 * b, A, A);
        ctx.image(MENU_BIG, x + b, y + b, w - 2 * b, h - 2 * b, b, b, PW - 2 * b, PH - 2 * b, A, A);
    }
    function btn(id, x, y, w, label, onClick, tip, h) {
        return { id: id, type: "button", anchor: "center", x: x, y: y, w: w, h: h || 16, texture: BUTTONS, texW: 256, texH: 256, u: 0, v: 28, uw: 74, vh: 20,
            hoverU: 0, hoverV: 48, label: label, font: FONT, tooltip: tip || undefined, onClick: onClick };
    }

    // =================================================================================
    //  A paged form: tabs of rows (bool, int, num, text, cycle, button, row-with-buttons)
    // =================================================================================
    var PW = 330, PH = 236, ROWS = 9, ROW_H = 19, TOP = -74;
    var F = null;                                            // the open form
    function openForm(spec) {
        F = spec; F.tab = F.tab || 0; F.page = F.page || 0;
        render();
    }
    function curFields() { var t = F.tabs[F.tab]; return typeof t.fields === "function" ? t.fields() : t.fields; }
    function readInputs() {
        if (!F || !F.inputs) return;
        F.inputs.forEach(function (inp) {
            var v = RPG.screen.value(inp.id);
            if (v === undefined || v === null) return;
            if (inp.kind === "text") inp.set(String(v));
            else { var n = Number(v); if (!isNaN(n)) inp.set(inp.kind === "int" ? Math.round(clampN(n, inp.min, inp.max)) : clampN(n, inp.min, inp.max)); }
        });
    }
    function clampN(v, a, b) { if (a !== undefined && v < a) v = a; if (b !== undefined && v > b) v = b; return v; }
    function go(fn) { return function () { readInputs(); fn(); }; }
    function reopen() { RPG.schedule(1, render); }
    function render() {
        if (!F) return;
        var form = F, els = [], fields = curFields(), pages = Math.max(1, Math.ceil(fields.length / ROWS));
        form.page = Math.min(form.page, pages - 1);
        form.inputs = [];
        form.tips = [];
        var left = -PW / 2 + 12, ctlX = 14, ctlW = PW / 2 - 26;
        // tabs
        if (form.tabs.length > 1) {
            var tw = Math.min(78, Math.floor((PW - 24) / form.tabs.length));
            form.tabs.forEach(function (t, i) {
                els.push(btn("tab" + i, -PW / 2 + 12 + i * (tw + 2), -PH / 2 + 30, tw, (i === form.tab ? "§e" : "§7") + t.name, go(function () { form.tab = i; form.page = 0; reopen(); })));
            });
        }
        fields.slice(form.page * ROWS, form.page * ROWS + ROWS).forEach(function (fd, k) {
            var y = TOP + k * ROW_H + (form.tabs.length > 1 ? 8 : 0), id = "f" + k;
            form.tips.push({ y: y, label: fd.label, tip: fd.tip, header: fd.type === "header", color: fd.color });
            if (fd.type === "bool") {
                els.push(btn(id, ctlX, y, ctlW, fd.get() ? T("gui.common.toggle_on", "§a[x] ON") : T("gui.common.toggle_off", "§7[ ] OFF"),
                    go(function () { fd.set(!fd.get()); reopen(); }), fd.tip));
            } else if (fd.type === "cycle") {
                var opts = fd.options(), cur = fd.get(), idx = 0;
                opts.forEach(function (o, i) { if (o.v === cur) idx = i; });
                els.push(btn(id, ctlX, y, ctlW, (opts[idx] || { label: "?" }).label, go(function () { fd.set(opts[(idx + 1) % opts.length].v); reopen(); }), fd.tip));
            } else if (fd.type === "int" || fd.type === "num" || fd.type === "text") {
                var v = fd.get();
                els.push({ id: id, type: "input", anchor: "center", x: ctlX, y: y + 2, w: ctlW, h: 12, maxLength: fd.max_len || 256, value: v === null || v === undefined ? "" : String(v), tooltip: fd.tip || undefined });
                form.inputs.push({ id: id, kind: fd.type, set: fd.set, min: fd.min, max: fd.max });
            } else if (fd.type === "button") {
                els.push(btn(id, ctlX, y, ctlW, fd.text || fd.label, go(fd.run), fd.tip));
            } else if (fd.type === "row") {
                var x = PW / 2 - 12;
                (fd.buttons || []).slice().reverse().forEach(function (b, bi) {
                    var w = b.w || 22; x -= w + 2;
                    els.push(btn(id + "b" + bi, x, y, w, b.label, go(b.run), b.tip));
                });
                (fd.inputs || []).slice().reverse().forEach(function (inp, ii) {
                    var w = inp.w || 34; x -= w + 2;
                    els.push({ id: id + "i" + ii, type: "input", anchor: "center", x: x, y: y + 2, w: w, h: 12, maxLength: 64, value: String(inp.get()), tooltip: inp.tip || undefined });
                    form.inputs.push({ id: id + "i" + ii, kind: inp.kind || "num", set: inp.set, min: inp.min, max: inp.max });
                });
                if (fd.item) els.push({ id: id + "it", type: "item", anchor: "center", x: left, y: y, item: fd.item, tooltip: "item" });
            }
        });
        // bottom bar
        var by = PH / 2 - 26;
        if (pages > 1) {
            els.push(btn("prev", -20 - 20, by, 20, "<", go(function () { form.page = (form.page + pages - 1) % pages; reopen(); })));
            els.push(btn("next", 20, by, 20, ">", go(function () { form.page = (form.page + 1) % pages; reopen(); })));
        }
        if (form.onSave) els.push(btn("save", PW / 2 - 12 - 60, by, 60, T("gui.common.save", "§aSave"), go(function () { form.onSave(); })));
        els.push(btn("back", -PW / 2 + 12, by, 60, form.onBack ? T("gui.common.back", "Back") : T("gui.config.close", "Close"), go(function () {
            if (form.onBack) form.onBack(); else { F = null; RPG.screen.close(); }
        })));
        (form.extra || []).forEach(function (e, i) { els.push(btn("x" + i, -PW / 2 + 76 + i * 64, by, 62, e.label, go(e.run), e.tip)); });
        RPG.screen.open({ id: "dbrd_form", referenceHeight: 270, background: "dim", elements: els, closeOnEsc: true,
            onRender: function (ctx) { draw(ctx, form, pages); }, onClose: function () { } });
    }
    function draw(ctx, form, pages) {
        var cx = Math.floor(ctx.width / 2), cy = Math.floor(ctx.height / 2), x0 = cx - PW / 2, y0 = cy - PH / 2;
        panel(ctx, x0, y0, PW, PH);
        U.bordered(ctx, "§l" + form.title, cx, y0 + 9, "#FFD700", 0.5);
        if (form.subtitle) U.plain(ctx, form.subtitle, cx, y0 + 19, "#C8C8C8", 0.5);
        var hover = null;
        form.tips.forEach(function (t) {
            var ly = cy + t.y + 4;
            if (t.header) { U.bordered(ctx, t.label, x0 + 12, ly, t.color || "#FFD27A", 0); return; }
            var lbl = U.ellipsis ? U.ellipsis(ctx, t.label, PW / 2 - 20) : t.label;
            U.plain(ctx, lbl, x0 + 14, ly, t.color || "#FFFFFF", 0);
            if (t.tip && U.inside(ctx.mouseX, ctx.mouseY, x0 + 10, cy + t.y, PW / 2, ROW_H - 2)) hover = t.tip;
        });
        if (pages > 1) U.plain(ctx, (form.page + 1) + "/" + pages, cx, cy + PH / 2 - 21, "#C8C8C8", 0.5);
        if (form.footer) U.plain(ctx, form.footer, cx, cy + PH / 2 - 38, "#C8C8C8", 0.5);
        U.drawStatus(ctx, cx, y0 - 12);
        if (hover) U.tooltip(ctx, U.wrap(ctx, hover, 220).map(function (l) { return [l]; }), ctx.mouseX, ctx.mouseY);
    }
    // field helpers bound to an object's key
    function fBool(o, k, label, tip) { return { type: "bool", label: label, tip: tip, get: function () { return !!o[k]; }, set: function (v) { o[k] = v; } }; }
    function fNum(o, k, label, tip, min, max, isInt) { return { type: isInt ? "int" : "num", label: label, tip: tip, min: min, max: max, get: function () { return o[k] === null || o[k] === undefined ? "" : o[k]; }, set: function (v) { o[k] = v; } }; }
    function fInt(o, k, label, tip, min, max) { return fNum(o, k, label, tip, min, max, true); }
    function fText(o, k, label, tip) { return { type: "text", label: label, tip: tip, get: function () { return o[k] || ""; }, set: function (v) { o[k] = v; } }; }
    function fCycle(o, k, label, tip, opts) { return { type: "cycle", label: label, tip: tip, options: function () { return opts; }, get: function () { return o[k]; }, set: function (v) { o[k] = v; } }; }
    // an "at max level" value: blank = automatic (x100 the level 1 value)
    function fAnchor(o, k, label, base) {
        return { type: "text", label: label, tip: T("gui.spawner.anchor_tip", "", DBRD.LEVEL_MULTIPLE),
            get: function () { return o[k] === null || o[k] === undefined ? "" : String(o[k]); },
            set: function (v) { v = String(v).trim(); o[k] = v === "" || /^auto$/i.test(v) || isNaN(Number(v)) ? null : Number(v); } };
    }
    function header(label, color) { return { type: "header", label: label, color: color }; }

    // =================================================================================
    //  Drop list editor (DropListEditor / DropListScreen)
    // =================================================================================
    function dropEditor(title, list, back) {
        openForm({ title: title, subtitle: "§7" + T("gui.spawner.col_item", "Item") + " / " + T("gui.spawner.col_min", "Min") + " / " + T("gui.spawner.col_max", "Max") + " / " + T("gui.spawner.col_pct", "%"),
            tabs: [{ name: "Drops", fields: function () {
                var rows = list.map(function (d, i) {
                    return { type: "row", label: "    " + d.itemId, tip: T("gui.spawner.drop_row_tip", ""), item: d.itemId,
                        inputs: [
                            { w: 26, kind: "int", get: function () { return d.minCount; }, set: function (v) { d.minCount = Math.max(0, v); }, min: 0, max: 64 },
                            { w: 26, kind: "int", get: function () { return d.maxCount; }, set: function (v) { d.maxCount = Math.max(0, v); }, min: 0, max: 64 },
                            { w: 30, kind: "num", get: function () { return d.chance; }, set: function (v) { d.chance = v; }, min: 0, max: 100 }],
                        buttons: [{ label: T("gui.spawner.drop_remove", "§cX"), run: function () { list.splice(i, 1); reopen(); } }] };
                });
                rows.push({ type: "row", label: "§7Item id:", inputs: [{ w: 110, kind: "text", get: function () { return F.newId || ""; }, set: function (v) { F.newId = v; } }],
                    buttons: [{ label: "§a+", w: 22, tip: T("gui.spawner.add_drop", "Add"), run: function () { if (F.newId) { list.push({ itemId: F.newId.indexOf(":") > 0 ? F.newId : "minecraft:" + F.newId, minCount: 1, maxCount: 1, chance: 100 }); F.newId = ""; } reopen(); } },
                        { label: "§bHeld", w: 34, tip: T("gui.spawner.add_held_tip", ""), run: function () { var h = RPG.player.heldItem; if (h && h !== "minecraft:air") list.push({ itemId: String(h), minCount: 1, maxCount: 1, chance: 100 }); reopen(); } }] });
                return rows;
            } }],
            onBack: back });
    }

    // =================================================================================
    //  Spawner editor (AdvancedSpawnerScreen): floor enemies, floor guardians, placed spawner blocks
    // =================================================================================
    function spawnerEditor(title, sub, c, back, onSave, isBoss) {
        var S = "gui.spawner.";
        var tabs = [
            { name: T("gui.opt.tab.general", "General"), fields: [
                fText(c, "entityTypeId", T(S + "entity", "Entity"), "DBR mob or boss id (raditz, saibaman, red_ribbon_soldier...) or any entity id (minecraft:zombie)."),
                fText(c, "displayName", T(S + "display_name", "Display Name"), T(S + "display_name_tip", "")),
                fBool(c, "enabled", T(S + "enabled", "Spawner Enabled"), T(S + "enabled_tip", "")),
                fCycle(c, "aiTier", T(S + "ai_tier", "AI Tier"), T(S + "ai_tier_tip", ""), DBRD.OPTS.aiTier.map(function (k, i) { return { v: i, label: T("gui.opt.ai_tier." + k, cap(k)) }; })),
                fCycle(c, "behavior", T(S + "behavior", "Behavior"), T(S + "behavior_tip", ""), DBRD.OPTS.behavior.map(function (k, i) { return { v: i, label: T("gui.opt.behavior." + k, cap(k)) }; }))] },
            { name: T("gui.opt.tab.stats", "Stats"), fields: [
                fNum(c, "maxHealth", T(S + "health", "Health"), T(S + "health_tip", ""), 1, 1e9), fNum(c, "attackDamage", T(S + "melee", "Melee Damage"), T(S + "melee_tip", ""), 0, 1e9),
                fNum(c, "moveSpeed", T(S + "speed", "Speed"), T(S + "speed_tip", ""), 0, 2), fNum(c, "defense", T(S + "defense", "Defense"), T(S + "defense_tip", ""), 0, 1e6),
                fNum(c, "scale", T(S + "scale", "Scale"), T(S + "scale_tip", ""), 0.1, 10),
                fAnchor(c, "maxHealthAtMax", T(S + "health_at_max", "Health at max level")), fAnchor(c, "attackDamageAtMax", T(S + "melee_at_max", "Melee at max level")),
                fAnchor(c, "defenseAtMax", T(S + "defense_at_max", "Defense at max level"))] },
            { name: T("gui.opt.tab.ki", "Ki"), fields: [
                fBool(c, "kiEnabled", T(S + "ki_attacks", "Ki Attacks"), T(S + "ki_attacks_tip", "")),
                fInt(c, "kiDmgMin", T(S + "ki_min", "Ki Damage Min"), T(S + "ki_min_tip", ""), 0, 1e9), fInt(c, "kiDmgMax", T(S + "ki_max", "Ki Damage Max"), T(S + "ki_max_tip", ""), 0, 1e9)] },
            { name: T("gui.opt.tab.spawn", "Spawn"), fields: [
                fInt(c, "maxSpawns", T(S + "spawn_amount", "Spawn Amount"), T(S + "spawn_amount_tip", ""), 0, 64), fInt(c, "cooldownTicks", T(S + "cooldown_ticks", "Cooldown (ticks)"), T(S + "cooldown_ticks_tip", ""), 1, 72000),
                fInt(c, "wanderDistance", T(S + "wander_dist", "Wander Dist"), T(S + "wander_dist_tip", ""), 0, 256),
                fCycle(c, "timeCondition", T(S + "time_of_day", "Time of Day"), T(S + "time_of_day_tip", ""), DBRD.OPTS.time.map(function (k, i) { return { v: i, label: T("gui.opt.time." + k, cap(k)) }; })),
                fCycle(c, "weatherCondition", T(S + "weather", "Weather"), T(S + "weather_tip", ""), DBRD.OPTS.weather.map(function (k, i) { return { v: i, label: T("gui.opt.weather." + k, cap(k)) }; })),
                fCycle(c, "redstoneMode", T(S + "redstone", "Redstone"), T(S + "redstone_tip", ""), DBRD.OPTS.redstone.map(function (k, i) { return { v: i, label: T("gui.opt.redstone." + k, cap(k)) }; }))] },
            { name: T("gui.opt.tab.rewards", "Rewards"), fields: [
                fInt(c, "tpMin", T(S + "tp_min", "TP Min"), T(S + "tp_min_tip", ""), 0, 2e9), fInt(c, "tpMax", T(S + "tp_max", "TP Max"), T(S + "tp_max_tip", ""), 0, 2e9),
                fInt(c, "balMin", "Zeni Min", T(S + "balance_min_tip", "").replace("Shurui's Utilities balance", "zeni"), 0, 2e9),
                fInt(c, "balMax", "Zeni Max", T(S + "balance_max_tip", "").replace("balance", "zeni"), 0, 2e9),
                fText(c, "killCommands", T(S + "kill_commands", "Kill Commands"), T(S + "kill_commands_tip", "")),
                fBool(c, "levelScaling", T(S + "level_scaling", "Scale with level"), T(S + "level_scaling_tip", "")),
                fInt(c, "scaleMaxLevel", T(S + "scale_max_level", "Max level"), T(S + "scale_max_level_tip", ""), 2, 1e9),
                fAnchor(c, "tpMinAtMax", T(S + "tp_min_at_max", "TP Min at max level")), fAnchor(c, "tpMaxAtMax", T(S + "tp_max_at_max", "TP Max at max level")),
                fAnchor(c, "balMinAtMax", "Zeni Min at max level"), fAnchor(c, "balMaxAtMax", "Zeni Max at max level")] },
            { name: T("gui.opt.tab.drops", "Drops"), fields: [
                { type: "button", label: T("gui.opt.tab.drops", "Drops"), text: "Edit drops (" + (c.drops || []).length + ")...", run: function () { var me = F; dropEditor(T("gui.opt.tab.drops", "Drops"), c.drops || (c.drops = []), function () { openForm(me); }); } }] }
        ];
        if (!isBoss) {
            tabs.push({ name: T("gui.opt.tab.boss", "Boss"), fields: [
                fBool(c, "bossEnabled", T(S + "boss_enabled", "Boss Enabled"), T(S + "boss_enabled_tip", "").replace(" Requires the server key: without it the boss never spawns.", "")),
                fNum(c, "bossChance", T(S + "boss_chance", "Spawn Chance %"), T(S + "boss_chance_tip", ""), 0, 100),
                fText(c, "bossEntityTypeId", T(S + "boss_entity", "Boss Entity"), "DBR mob or boss id, or an entity id."),
                fText(c, "bossName", T(S + "boss_name", "Boss Name"), T(S + "boss_name_tip", "")),
                fNum(c, "bossHealth", T(S + "health", "Health"), T(S + "boss_health_tip", ""), 1, 1e9), fNum(c, "bossDamage", T(S + "melee", "Melee Damage"), T(S + "boss_melee_tip", ""), 0, 1e9),
                fNum(c, "bossScale", T(S + "scale", "Scale"), T(S + "boss_scale_tip", ""), 0.1, 10)] });
            tabs.push({ name: T("gui.opt.tab.disguise", "Disguise"), fields: [fText(c, "disguise", T(S + "disguise", "Disguise Block"), T(S + "disguise_tip", ""))] });
        }
        openForm({ title: title, subtitle: sub, tabs: tabs, onBack: back, onSave: onSave });
    }
    RPG.net.on("dbrd_spawner", function (d) {
        var c = clone(d.config);
        spawnerEditor(T("gui.spawner.title", "Advanced NPC Spawner"), "§7" + c.entityTypeId, c, null, function () { RPG.net.send("dbrd_spawner_save", { key: d.key, config: c }); RPG.screen.close(); F = null; }, false);
    });

    // =================================================================================
    //  Dungeon config (DungeonConfigScreen) and floor editor (DungeonFloorEditScreen)
    // =================================================================================
    var CFG = null;                                          // {rules, floors, generated, bossDefeated, styles}
    function save(reopenIt) { RPG.net.send("dbrd_save_config", { rules: CFG.rules, floors: CFG.floors, reopen: !!reopenIt }); }
    function configScreen(tab) {
        var R = CFG.rules, G = "gui.config.";
        openForm({ title: T(G + "title", "Dungeon Config"), tab: tab || 0, tabs: [
            { name: T(G + "tab_floors", "Floors"), fields: function () {
                var rows = CFG.floors.map(function (f, i) {
                    var n = i + 1, regen = CFG.confirm === n;
                    return { type: "row", color: CFG.generated[n] ? "#B4FFB4" : "#FFFFFF",
                        label: (f.type === "BOSS" ? T(G + "floor_row_boss", "", n, themeName(f.theme), f.size, f.depth) : T(G + "floor_row", "", n, themeName(f.theme), f.size, f.depth)),
                        tip: styleName(CFG.styles[i]) + (CFG.generated[n] ? " · built" : " · not built yet") + (f.type === "BOSS" && CFG.bossDefeated[n] ? " · guardian defeated" : "") + (f.inRotation ? "" : " · out of rotation"),
                        buttons: [
                            { label: T("gui.common.edit", "Edit"), w: 28, run: function () { floorEditor(i); } },
                            { label: T(G + "floor_go", "Go"), w: 22, tip: T(G + "floor_go_tip", ""), run: function () { RPG.net.send("dbrd_floor_go", { floor: n }); RPG.screen.close(); F = null; } },
                            { label: regen ? T(G + "floor_regen_confirm", "Confirm?") : T(G + "floor_regen", "Regen"), w: 36, tip: T(G + "floor_regen_tip", ""),
                                run: function () { if (regen) { CFG.confirm = 0; RPG.net.send("dbrd_floor_regen", { floor: n }); } else { CFG.confirm = n; reopen(); } } },
                            { label: T(G + "floor_remove", "§cX"), w: 16, tip: T(G + "floor_remove_tip", ""), run: function () { CFG.floors.splice(i, 1); CFG.styles.splice(i, 1); reopen(); } }] };
                });
                rows.push({ type: "button", label: "", text: T(G + "add_floor", "§a+ Add Floor"), run: function () {
                    var n = CFG.floors.length + 1, f = DBRD.newFloor(n, CFG.floors.length ? CFG.floors[CFG.floors.length - 1].size : 250, CFG.floors.length ? CFG.floors[CFG.floors.length - 1].depth : 96);
                    CFG.floors.push(f); CFG.styles.push(""); reopen();
                } });
                return rows;
            } },
            { name: T(G + "tab_settings", "Settings"), fields: [
                fInt(R, "timeLimitSeconds", T(G + "time_limit", "Time Limit (s)"), T(G + "time_limit_tip", ""), 0, 86400),
                fInt(R, "cooldownSeconds", T(G + "cooldown", "Cooldown (s)"), T(G + "cooldown_tip", ""), 0, 86400),
                fBool(R, "pvp", T(G + "pvp", "PvP"), T(G + "pvp_tip", "")),
                fBool(R, "kiBlockDestruction", T(G + "ki_block", "Ki Block Destruction"), T(G + "ki_block_tip", "")),
                fBool(R, "blockEditing", T(G + "block_editing", "Hand Block Editing"), T(G + "block_editing_tip", ""))] }
        ], onSave: function () { save(true); } });
    }
    RPG.net.on("dbrd_config", function (d) { var tab = F && F.title === T("gui.config.title", "Dungeon Config") ? F.tab : 0; CFG = d; CFG.confirm = 0; configScreen(tab); });

    function floorEditor(i) {
        var f = CFG.floors[i], n = i + 1, E = "gui.floor_edit.", L = "gui.loot.", N = "gui.npcs.";
        var back = function () { configScreen(0); };
        var themes = DBRD.THEMES.concat(f.theme === "STONY" ? ["STONY"] : []).map(function (t) { return { v: t, label: themeName(t) }; });
        var styles = [{ v: "", label: styleName("") }].concat(DBRD.STYLE_NAMES.map(function (s) { return { v: s, label: styleName(s) }; }));
        var tiers = [];
        DBRD.TIERS.forEach(function (t, ti) {
            var p = f.crateLoot.tiers[ti];
            tiers.push(header(T("tier." + t.key, cap(t.key)), t.color));
            tiers.push(fInt(p, "weight", "  " + T(L + "weight", "Weight"), T(L + "weight_tip", ""), 0, 100000));
            tiers.push(fInt(p, "zeniMin", "  " + T(L + "zeni_min", "Zeni Min"), T(L + "zeni_min_tip", ""), 0, 2e9));
            tiers.push(fInt(p, "zeniMax", "  " + T(L + "zeni_max", "Zeni Max"), T(L + "zeni_max_tip", ""), 0, 2e9));
            tiers.push({ type: "button", label: "", text: T(L + "edit_drops", "Drops", p.drops.length), tip: T(L + "edit_drops_tip", "").replace(" (currently a testing nether star", "").replace(/\)\.?$/, "."),
                run: function () { var me = F; dropEditor(T(L + "drops_title", "Crate Drops") + " - " + T("tier." + t.key, t.key), p.drops, function () { openForm(me); }); } });
        });
        DBRD.METALS.forEach(function (m, mi) { tiers.push(fInt(f.crateLoot.metals[mi], "weight", T("metal." + m.key, cap(m.key)) + " " + T(L + "weight", "weight").toLowerCase(), "How likely a crate is banded in " + m.key + ", relative to the other metals.", 0, 100000)); });
        openForm({ title: T(E + "title", "Edit Floor"), subtitle: T(E + "subtitle", "Floor " + n, n), onBack: back, onSave: function () { save(true); },
            tabs: [
                { name: T(E + "tab_general", "General"), fields: function () {
                    var g = [fCycle(f, "theme", T(E + "theme", "Theme"), T(E + "theme_tip", ""), themes),
                        fCycle(f, "layoutStyle", T(E + "layout", "Layout Style"), T(E + "layout_tip", ""), styles),
                        fInt(f, "size", T(E + "size", "Size (blocks)"), T(E + "size_tip", ""), DBRD.MIN_SIZE, DBRD.MAX_SIZE),
                        fInt(f, "depth", T(E + "depth", "Depth (blocks)"), T(E + "depth_tip", ""), DBRD.MIN_DEPTH, DBRD.MAX_DEPTH),
                        fCycle(f, "type", T(E + "type", "Floor Type"), T(E + "type_tip", ""), DBRD.TYPES.map(function (t) { return { v: t, label: T("gui.opt.floortype." + t.toLowerCase(), cap(t)) }; })),
                        fBool(f, "requireTicket", "Require Ticket", "A floor ticket for this floor must be redeemed before its portals let a player through (ops bypass)."),
                        fBool(f, "inRotation", "In Rotation", "Out of rotation keeps the floor's config and terrain but stops it gating progression (its guardian no longer seals the floors above)."),
                        fBool(f, "bossEnabled", T(E + "boss_enabled", "Boss Enabled"), T(E + "boss_enabled_tip", "")),
                        { type: "button", label: T(E + "boss", "Boss"), text: T(E + "boss_btn", "Configure Boss..."), tip: T(E + "boss_tip", ""),
                            run: function () { var me = F; spawnerEditor(T(E + "boss", "Boss"), "§7Floor " + n, f.boss, function () { openForm(me); }, null, true); } }];
                    return g;
                } },
                { name: T(E + "tab_loot", "Loot"), fields: [
                    fInt(f.crateLoot, "refreshHours", T(L + "refresh_hours", "Refresh (hours)"), T(L + "refresh_hours_tip", ""), 0, 100000),
                    fInt(f.crateLoot, "chestChancePercent", T(L + "chest_chance", "Chest Chance (%)"), T(L + "chest_chance_tip", ""), 0, 100),
                    fInt(f.crateLoot, "barrelChancePercent", T(L + "barrel_chance", "Barrel Chance (%)"), T(L + "barrel_chance_tip", ""), 0, 100)].concat(tiers) },
                { name: T(E + "tab_npcs", "Spawners"), fields: function () {
                    var rows = [fBool(f, "enemiesEnabled", T(N + "enabled", "Spawners Enabled"), T(N + "enabled_tip", ""))];
                    f.enemyPresets.forEach(function (p, pi) {
                        rows.push({ type: "row", label: (pi + 1) + ". " + (p.config.displayName || p.config.entityTypeId), tip: T(N + "edit_tip", ""),
                            inputs: [{ w: 26, kind: "int", tip: T(N + "weight_tip", ""), get: function () { return p.weight; }, set: function (v) { p.weight = Math.max(1, v); }, min: 1, max: 100000 }],
                            buttons: [
                                { label: T("gui.common.edit", "Edit"), w: 28, run: function () { var me = F; spawnerEditor(T(N + "enemies", "Enemies"), "§7Floor " + n + " #" + (pi + 1), p.config, function () { openForm(me); }, null, false); } },
                                { label: T(N + "duplicate", "§b⧉"), w: 16, tip: T(N + "duplicate_tip", ""), run: function () { f.enemyPresets.splice(pi + 1, 0, clone(p)); reopen(); } },
                                { label: "§cX", w: 16, tip: T(N + "remove_tip", ""), run: function () { f.enemyPresets.splice(pi, 1); reopen(); } }] });
                    });
                    rows.push({ type: "row", label: "", buttons: [
                        { label: T(N + "add", "§a+ Add Spawner"), w: 70, run: function () { f.enemyPresets.push({ weight: 1, config: DBRD.defaultEnemyConfig() }); reopen(); } },
                        { label: T(N + "copy", "§bCopy Spawners"), w: 70, run: function () { RPG.storage.set("dbrd_preset_clip", JSON.stringify(f.enemyPresets)); U.showStatus("Copied " + f.enemyPresets.length + " spawners", "#55FFFF"); } },
                        { label: T(N + "paste", "§dPaste Spawners"), w: 70, run: function () { try { var v = JSON.parse(RPG.storage.get("dbrd_preset_clip", "[]")); if (v.length) f.enemyPresets = clone(v); } catch (e) { } reopen(); } }] });
                    return rows;
                } }
            ] });
    }

    // =================================================================================
    //  Dungeon Gate: the floor picker
    // =================================================================================
    function gateScreen(d) {
        var rows = (d.floors || []).map(function (e) {
            var lock = e.locked, status = e.type === "BOSS" ? (e.cleared ? "§a[Guardian defeated]" : "§c[Guardian]") : "";
            var tip = themeName(e.theme) + " · " + styleName(e.style) + (e.built ? "" : " · built on first visit");
            if (lock === "ticket") tip = T("message.portal_ticket_locked", "", e.n);
            else if (lock.indexOf("boss:") === 0) tip = T("message.portal_floor_locked", "", lock.substring(5));
            else if (lock === "out") tip = "Out of rotation (staff only).";
            return { type: "row", color: lock && lock !== "out" ? "#9A9A9A" : "#FFFFFF", label: "Floor " + e.n + ": " + themeName(e.theme) + " " + status, tip: tip,
                buttons: [{ label: lock && lock !== "out" ? "§8Locked" : "§aEnter", w: 44, tip: tip, run: function () { if (!lock || lock === "out") { RPG.net.send("dbrd_enter", { floor: e.n }); RPG.screen.close(); F = null; } else U.showStatus(tip, "#FF5555"); } }] };
        });
        if (!rows.length) rows.push(header("§7No floors are open."));
        var foot = [];
        if (d.cooldown > 0) foot.push("§cCooldown: " + d.cooldown + "s");
        if (d.timeLimit > 0) foot.push("§7Time limit " + Math.floor(d.timeLimit / 60) + " min");
        if (d.best) foot.push("§7Deepest " + d.best.deepest + " · guardians " + d.best.guardians + " · crates " + d.best.crates);
        openForm({ title: "Dungeon Gate", subtitle: "§7Choose a floor", tabs: [{ name: "Floors", fields: rows }], footer: foot.join("  "),
            extra: d.admin ? [{ label: "Config...", run: function () { RPG.net.send("dbrd_open_config", {}); } }] : [] });
    }
    RPG.net.on("dbrd_gate", function (d) { gateScreen(d || {}); });

    // =================================================================================
    //  Crate reveal (ClientCrateRolls): the candidates blur past, then the reward lands
    // =================================================================================
    var ROLL = null;
    RPG.net.on("dbrd_crate_roll", function (d) {
        var t = DBRD.TIERS[d.tier] || DBRD.TIERS[0], m = DBRD.METALS[d.metal] || DBRD.METALS[0];
        ROLL = { d: d, start: RPG.nowMs(), tier: t, metal: m, strip: [] };
        var c = (d.candidates && d.candidates.length) ? d.candidates : [d.item || { id: "minecraft:barrier", count: 1 }];
        for (var i = 0; i < 30; i++) ROLL.strip.push(c[i % c.length]);
        ROLL.strip.push(d.item || { id: "minecraft:barrier", count: 1 });
        var mine = ROLL;
        RPG.screen.open({ id: "dbrd_crate", referenceHeight: 270, background: "dim", elements: [], closeOnEsc: true,
            onRender: function (ctx) { drawRoll(ctx, mine); },
            onMouse: function (x, y, b, a) { if (a === "down" && RPG.nowMs() - mine.start > 2600) RPG.screen.close(); },
            onClose: function () { if (ROLL === mine) ROLL = null; } });
    });
    function drawRoll(ctx, R) {
        var cx = Math.floor(ctx.width / 2), cy = Math.floor(ctx.height / 2), w = 220, h = 110, x0 = cx - w / 2, y0 = cy - h / 2;
        var el = (RPG.nowMs() - R.start) / 1000, dur = 2.4, done = el >= dur;
        panel(ctx, x0, y0, w, h);
        ctx.fill(x0 + 4, y0 + 4, w - 8, 2, R.tier.color, 1);
        U.bordered(ctx, "§l" + T("tier." + R.tier.key, cap(R.tier.key)) + " " + T("metal." + R.metal.key, cap(R.metal.key)) + " " + T("container.crate", "Dungeon Crate"), cx, y0 + 10, R.tier.color, 0.5);
        var slot = 24, total = (R.strip.length - 1) * slot, f = Math.min(1, el / dur), ease = 1 - Math.pow(1 - f, 3), off = total * ease;
        ctx.clip(x0 + 10, cy - 18, w - 20, 34);
        R.strip.forEach(function (it, i) {
            var x = cx + i * slot - off - 8;
            if (x < x0 - 20 || x > x0 + w) return;
            ctx.item(it.id, x, cy - 10);
        });
        ctx.unclip();
        ctx.fill(cx - 1, cy - 18, 2, 34, R.tier.color, 0.9);
        if (done) {
            var it = R.d.item;
            U.bordered(ctx, it ? (it.count + "x " + U.humanize(it.id)) : T("message.crate_empty", "Empty"), cx, cy + 22, "#FFFFFF", 0.5);
            if (R.d.zeni > 0) U.plain(ctx, T("message.crate_zeni", "", R.d.zeni), cx, cy + 34, "#FFD700", 0.5);
            U.plain(ctx, "§7Click to close", cx, y0 + h - 12, "#AAAAAA", 0.5);
            if (!R.chimed) { R.chimed = true; RPG.sound("minecraft:entity.player.levelup", 0.7, R.tier.pitch); }
        } else if (Math.floor(el * 12) !== R.tickN) { R.tickN = Math.floor(el * 12); RPG.sound("minecraft:block.note_block.hat", 0.4, 1.2 + f); }
    }
})();
