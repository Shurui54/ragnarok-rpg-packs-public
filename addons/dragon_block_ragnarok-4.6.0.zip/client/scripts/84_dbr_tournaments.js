// =====================================================================================
//  84_dbr_tournaments.js - Tournaments (client): the editor, the sign-up NPC screens, the
//  bracket and leaderboard views, the stat gem picker, and the HUD
// =====================================================================================
//  Ported from DMZ Ragnarok's Tournaments module (GPL-3.0, shuruis_dmz_tournaments):
//  client/gui/HubScreen, TournamentListScreen, TournamentEditScreen (General / Bounds /
//  Schedule / Rules / Messages / Rewards tabs), RewardListScreen, RewardEditScreen,
//  BrowserScreen, SignupScreen, StatGemScreen, NpcNameRenderer and TitleDisplay's tag above
//  the holder's head, plus the open sign-up notice (TournamentSignupWaypoints). Drawn in
//  DMZ's style like 69_saga_editor.js: questmenu panel, characterbuttons buttons / switches /
//  arrows, smooth font. The server (scripts/94_dbr_tournaments.js) checks everything sent.
// =====================================================================================
(function () {
    var S = DBR_TOURNEY_SHARED, U = DMZ_UI, FONT = U.FONT, BUTTONS = U.BUTTONS, T = S.t;
    var TS = 0.8, ROW = 16, SID = "dbr_tourney";
    var E = { stack: [], token: 0, open: false, widgets: [], titles: [], confirm: null };

    function send(a, extra) { var d = { a: a }; for (var k in extra || {}) d[k] = extra[k]; RPG.net.send("dbr_tourney", d); }
    function clone(o) { return JSON.parse(JSON.stringify(o)); }
    function page() { return E.stack[E.stack.length - 1]; }
    function dims() { var p = page() || {}; return [p.w || 400, p.h || 300]; }
    function push(p) { p.scroll = {}; E.stack.push(p); }
    function back() {
        if (E.stack.length > 1) { E.stack.pop(); return; }
        close();
    }
    function close() { E.open = false; E.token++; E.stack = []; boxes(null); RPG.screen.close(); }
    function confirmed(key) {
        if (E.confirm && E.confirm.key === key && RPG.nowMs() < E.confirm.until) { E.confirm = null; return true; }
        E.confirm = { key: key, until: RPG.nowMs() + 3000 };
        return false;
    }
    function armed(key) { return E.confirm && E.confirm.key === key && RPG.nowMs() < E.confirm.until; }
    function sec(s) { return String(s === undefined || s === null ? "" : s).replace(/&([0-9a-fk-or])/gi, "§$1"); }

    // ---- widget builders (panel coordinates) ----
    var B;
    function text(x, y, t, color, scale, align, mw) { B.push({ k: "text", x: x, y: y, t: t, color: color, scale: scale, align: align, mw: mw }); }
    function input(x, y, w, get, set, opts) { B.push({ k: "input", x: x, y: y, w: w, get: get, set: set, max: (opts && opts.max) || 128, tip: opts && opts.tip }); }
    function button(x, y, w, t, fn, tip, color, disabled) { B.push({ k: "btn", x: x, y: y, w: w, h: 16, t: t, fn: fn, tip: tip, color: color, disabled: !!disabled }); }
    function toggle(x, y, t, get, set, tip, w) { B.push({ k: "toggle", x: x, y: y, w: w || 24 + Math.ceil(S.strip(t).length * 4.6), h: 12, t: t, get: get, set: set, tip: tip }); }
    function cycle(x, y, w, opts, get, set, tip) { B.push({ k: "cycle", x: x, y: y, w: w, h: 14, opts: opts, get: get, set: set, tip: tip }); }
    function tab(x, y, w, t, active, fn) { B.push({ k: "tab", x: x, y: y, w: w, h: 15, t: t, active: active, fn: fn }); }
    function listBox(key, x, y, w, h, rows) { B.push({ k: "list", key: key, x: x, y: y, w: w, h: h, rows: rows }); }
    function label(x, y, t, tip, w) { text(x, y + 3, t, "#E0E0E0", 0.75, 0, w ? w - 4 : null); if (tip) B.push({ k: "tip", x: x, y: y, w: w || Math.ceil(S.strip(t).length * 4.2) + 2, h: 12, tip: tip }); }
    function footer(buttons) {
        var d = dims(), w = 76, gap = 6, total = buttons.length * w + (buttons.length - 1) * gap, x = Math.floor((d[0] - total) / 2);
        buttons.forEach(function (b) { button(x, d[1] - 30, w, b[0], b[1], b[2], b[3], b[4]); x += w + gap; });
    }
    function title(t, sub) {
        var d = dims();
        text(d[0] / 2, 10, "§l" + t, "#FFD700", 1, 0.5);
        if (sub) text(d[0] / 2, 22, sub, "#AAAAAA", 0.7, 0.5);
    }
    function tipOf(key) { var k = "edit." + key + "_tip"; return S.TEXT[k] ? T(k) : null; }

    // ===================================================================================
    //  Editor: tournament list (TournamentListScreen)
    // ===================================================================================
    function buildList(p) {
        title(T("list.title"), T("list.subtitle"));
        listBox("defs", 14, 34, p.w - 28, p.h - 72, function () {
            if (!p.defs.length) return [{ t: "§7No tournaments yet. Press " + S.strip(T("list.new")) + ".", actions: [] }];
            return p.defs.map(function (d) {
                var st = p.states[d.id] || "IDLE", ready = S.hasAllRegions(d) ? T("list.status_ready") : T("list.status_no_bounds");
                return { t: T("list.row", sec(d.name), d.id, " " + ready) + (st !== "IDLE" ? " §b" + st : ""),
                    actions: [[T("common.edit"), function () { push({ type: "edit", def: clone(d), tab: 0, w: 400, h: 300 }); }],
                        [T("list.copy"), function () { send("copy", { id: d.id }); }],
                        [T("list.signups"), function () { send("open_signups", { id: d.id }); }, false, "Open sign-ups now (/tourney open)"],
                        [armed("del" + d.id) ? "Sure?" : "X", function () { if (confirmed("del" + d.id)) send("delete", { id: d.id }); }, true, S.strip(T("common.delete"))]] };
            });
        });
        footer([[S.strip(T("list.new")), function () { send("new"); }, "A new tournament seeded from the global settings", "#80FF80"], [T("common.close"), close]]);
    }

    // ===================================================================================
    //  Editor: one tournament (TournamentEditScreen), tabbed
    // ===================================================================================
    function fieldsOf(tabIndex) { return S.FIELDS.filter(function (f) { return f.tab === tabIndex; }); }
    function strGet(o, k) { return function () { return o[k] === undefined || o[k] === null ? "" : String(o[k]); }; }
    function strSet(o, k) { return function (v) { o[k] = v; }; }
    function intGet(o, k) { return function () { return String(o[k]); }; }
    function intSet(o, k) { return function (v) { var n = parseInt(v, 10); if (!isNaN(n)) o[k] = n; else if (v === "" || v === "-") o[k] = 0; }; }
    function buildEdit(p) {
        var d = p.def;
        title(T("edit.title") + ": " + S.strip(d.name));
        var tw = Math.floor((p.w - 28) / S.TABS.length);
        S.TABS.forEach(function (k, i) { tab(14 + i * tw, 26, tw - 2, T(k), p.tab === i, function () { p.tab = i; }); });
        var y = 48;
        if (p.tab === 0) {
            fieldsOf(0).forEach(function (f) {
                label(14, y, T("edit." + f.label), tipOf(f.label), 130);
                if (f.type === "enum") cycle(150, y, 120, function () { return S.FORMATS.map(function (x) { return [x.id, x.label]; }); }, function () { return d.format; }, function (v) { d.format = v; }, tipOf(f.label));
                else input(150, y, 230, strGet(d, f.k), strSet(d, f.k), { max: f.max });
                y += 20;
            });
            text(14, y + 6, "§7Place the host: §f/tourney npc spawn " + d.id + " §7(or §fnpc bind§7 / §fnpc setgroup§7)", "#AAAAAA", 0.7);
        } else if (p.tab === 1) {
            ["arena", "waiting", "stands"].forEach(function (key) { boundsRows(p, key, y); y += 64; });
            text(14, y - 4, "§6Arena §7gold, §bwaiting §7aqua, §astands §7green outlines are drawn while you edit.", "#AAAAAA", 0.7);
        } else if (p.tab === 2) {
            fieldsOf(2).forEach(function (f) {
                if (f.type === "bool") { toggle(14, y, T("edit." + f.label), function () { return d[f.k]; }, function (v) { d[f.k] = v; }, tipOf(f.label)); y += 20; return; }
                label(14, y, T("edit." + f.label), tipOf(f.label), 170);
                input(190, y, 60, intGet(d, f.k), intSet(d, f.k), { max: 6 });
                y += 20;
            });
            text(14, y + 6, "§7Cadence: day of month > 0 = monthly, else day of week > 0 = weekly, else daily (server local time).", "#AAAAAA", 0.7);
        } else if (p.tab === 3) {
            var ly = y, ry = y;
            fieldsOf(3).forEach(function (f) {
                if (f.type === "bool") {
                    toggle(204, ry, T("edit." + f.label), function () { return d[f.k]; }, function (v) { d[f.k] = v; }, tipOf(f.label), 182);
                    ry += 14;
                } else if (f.type === "int") {
                    label(14, ly, T("edit." + f.label), tipOf(f.label), 118);
                    input(138, ly, 50, intGet(d, f.k), intSet(d, f.k), { max: 6 });
                    ly += 17;
                }
            });
            var ex = S.FIELD.excludeTitleIds;
            label(14, ly + 4, T("edit." + ex.label), tipOf(ex.label) + " " + T("edit.exclude_title_ids_live", E.titles.join(", ")), 170);
            input(14, ly + 18, 174, function () { return d.excludeTitleIds.join(", "); }, function (v) { d.excludeTitleIds = String(v).split(",").map(function (s) { return s.trim(); }).filter(function (s) { return s; }); }, { max: 256 });
        } else if (p.tab === 4) {
            fieldsOf(4).forEach(function (f) {
                label(14, y, T("edit." + f.label), tipOf(f.label), 200);
                input(14, y + 12, p.w - 28, strGet(d, f.k), strSet(d, f.k), { max: f.max });
                y += 34;
            });
        } else if (p.tab === 5) {
            text(14, y, sec(T("edit.rewards_header")), "#FFFFFF", 0.8);
            y += 18;
            [["winnerRewards", "reward_list.winner"], ["runnerUpRewards", "reward_list.runner_up"], ["participationRewards", "reward_list.participation"]].forEach(function (r) {
                button(20, y, 260, T("edit.rewards_button", T(r[1]), d[r[0]].length), function () { push({ type: "rewards", def: d, key: r[0], titleKey: r[1], w: 400, h: 300 }); });
                y += 20;
            });
            text(14, y + 10, "§7Tokens: item:<id>:<count>, command:<cmd {player}>, tp:<n>, skill:<id>:<levels>, title:<id>, message:<text>", "#AAAAAA", 0.7);
        }
        footer([[S.strip(T("common.save")), function () { send("save", { def: d, reopen: true }); }, "Save and return to the list", "#80FF80"], [T("common.back"), back]]);
    }
    function boundsRows(p, key, y) {
        var d = p.def, r = d[key];
        p.coords = p.coords || {};
        if (!p.coords[key]) p.coords[key] = { min: r ? r.min.map(String) : ["", "", ""], max: r ? r.max.map(String) : ["", "", ""] };
        var c = p.coords[key], name = T("edit.bounds_" + key);
        var status = r ? "§a" + S.regionText(r) + (r.dim !== RPG.player.dimension ? " §7(" + r.dim + ")" : "") : T("edit.bounds_not_set");
        label(14, y, T("edit.bounds_row", name, status), T("edit.bounds_tip", name), 280);
        button(306, y - 1, 80, T("edit.set_via_we"), function () { send("bounds_we", { id: d.id, key: key, def: d }); }, "Use your WorldEdit selection (//pos1, //pos2)");
        [["min", "edit.bounds_min"], ["max", "edit.bounds_max"]].forEach(function (row, ri) {
            var ry = y + 18 + ri * 18;
            text(14, ry + 3, T(row[1]), "#AAAAAA", 0.75);
            [0, 1, 2].forEach(function (i) {
                input(42 + i * 50, ry, 46, function () { return c[row[0]][i]; }, function (v) { c[row[0]][i] = v; }, { max: 9 });
            });
            button(194, ry - 1, 40, "Here", function () {
                c[row[0]] = [Math.floor(RPG.player.x), Math.floor(RPG.player.y), Math.floor(RPG.player.z)].map(String);
            }, "Fill with where you stand");
        });
        button(306, y + 35, 80, T("edit.set_manually"), function () {
            var nums = c.min.concat(c.max).map(function (s) { return parseInt(s, 10); });
            if (nums.some(function (n) { return isNaN(n); })) { U.showStatus("Type all six coordinates first", "#FF5555"); return; }
            d[key] = S.region({ dim: r ? r.dim : RPG.player.dimension, min: nums.slice(0, 3), max: nums.slice(3, 6) });
            p.coords[key] = null;
            send("save", { def: d });
        });
    }

    // ===================================================================================
    //  Editor: reward lists (RewardListScreen) and one reward (RewardEditScreen)
    // ===================================================================================
    function buildRewards(p) {
        var list = p.def[p.key];
        title(T(p.titleKey), S.strip(p.def.name));
        listBox("rw", 14, 34, p.w - 28, p.h - 72, function () {
            if (!list.length) return [{ t: "§7No rewards.", actions: [] }];
            return list.map(function (tok, i) {
                return { t: S.rewardSummary(S.rewardFrom(tok)),
                    actions: [[T("common.edit"), function () { push({ type: "reward", list: list, index: i, r: S.rewardFrom(tok), w: 360, h: 240 }); }],
                        [armed("rw" + i) ? "Sure?" : "X", function () { if (confirmed("rw" + i)) list.splice(i, 1); }, true, S.strip(T("common.delete"))]] };
            });
        });
        footer([[S.strip(T("reward_list.add")), function () { push({ type: "reward", list: list, index: -1, r: S.rewardFrom("item:minecraft:diamond:1"), w: 360, h: 240 }); }, null, "#80FF80"],
            [T("common.back"), back, "Changes are kept when you press Save on the tournament"]]);
    }
    function buildReward(p) {
        var r = p.r, y = 40;
        title(T("reward_edit.title"));
        label(14, y, T("reward_edit.type"), T("reward_edit.type_tip"), 100);
        cycle(120, y, 140, function () { return S.REWARD_TYPES.map(function (t) { return [t, t]; }); }, function () { return r.type; }, function (v) { r.type = v; });
        y += 24;
        function row(lab, get, set, w, max) { label(14, y, lab, null, 100); input(120, y, w || 220, get, set, { max: max || 256 }); y += 22; }
        switch (r.type) {
            case "ITEM": row(T("reward_edit.item"), strGet(r, "item"), strSet(r, "item"), 220, 128); row(T("reward_edit.count"), intGet(r, "count"), intSet(r, "count"), 60, 6);
                text(14, y, "§7Any item id (minecraft:diamond) or a script item name (stat_gem_100).", "#AAAAAA", 0.7); break;
            case "COMMAND": row(T("reward_edit.command"), strGet(r, "command"), strSet(r, "command"));
                text(14, y, "§7Run by the console. {player} and {uuid} are filled in.", "#AAAAAA", 0.7); break;
            case "TP": row(T("reward_edit.amount"), strGet(r, "tp"), function (v) { var n = Number(v); if (!isNaN(n)) r.tp = n; }, 100, 12); break;
            case "SKILL": row(T("reward_edit.skill"), strGet(r, "skill"), strSet(r, "skill"), 160, 64); row(T("reward_edit.levels"), intGet(r, "level"), intSet(r, "level"), 60, 4);
                text(14, y, "§7A DMZ skill id: fly, kicontrol, kisense, meditation, potentialunlock...", "#AAAAAA", 0.7); break;
            case "TITLE":
                label(14, y, T("reward_edit.title_field"), null, 100);
                if (E.titles.length) cycle(120, y, 200, function () { return E.titles.map(function (t) { return [t, t]; }); }, function () { return r.title; }, function (v) { r.title = v; });
                else text(120, y + 3, T("reward_edit.no_titles"), "#AAAAAA", 0.75);
                y += 22; break;
            default: row(T("reward_edit.message"), strGet(r, "message"), strSet(r, "message"));
        }
        text(14, p.h - 48, function () { return "§7→ §f" + S.rewardSummary(r); }, "#FFFFFF", 0.75);
        footer([[S.strip(T("common.save")), function () {
            var tok = S.rewardTo(r);
            if (p.index >= 0) p.list[p.index] = tok; else p.list.push(tok);
            E.stack.pop();
        }, null, "#80FF80"], [T("common.back"), back]]);
    }

    // ===================================================================================
    //  The sign-up NPC: browser (BrowserScreen) and sign-up (SignupScreen)
    // ===================================================================================
    var EXPANDED = {};
    function buildBrowser(p) {
        title(T("browser.title"), T("browser.subtitle"));
        var groups = {}, order = [];
        p.entries.forEach(function (e) {
            var g = e.group && String(e.group).trim() ? e.group : "Ungrouped";
            if (!groups[g]) { groups[g] = []; order.push(g); }
            groups[g].push(e);
        });
        order.sort(function (a, b) { return S.strip(a).toLowerCase() < S.strip(b).toLowerCase() ? -1 : 1; });
        listBox("br", 14, 34, p.w - 28, p.h - 72, function () {
            if (!order.length) return [{ t: T("browser.empty"), actions: [] }];
            var rows = [];
            order.forEach(function (g) {
                var open = EXPANDED[g] !== false;
                rows.push({ t: T("browser.group", open ? "▾ " : "▸ ", sec(g), groups[g].length), actions: [[open ? "Hide" : "Show", function () { EXPANDED[g] = !open; }]] });
                if (!open) return;
                groups[g].forEach(function (e) {
                    var st = e.open ? T("browser.state_open") : T("browser.state_closed") + (e.state !== "IDLE" ? " §b" + e.state : "");
                    rows.push({ t: "   " + T("browser.entry", sec(e.name), e.fmt, st, e.open ? e.count + " in" : ""),
                        actions: [["Open", function () { send("signup", { id: e.id }); }]] });
                });
            });
            return rows;
        });
        var b = [[T("browser.leaderboard"), function () { send("top"); }]];
        if (p.admin) b.push(["Editor", function () { send("list"); }, "/tourney edit"]);
        b.push([T("common.close"), close]);
        footer(b);
    }
    function buildSignup(p) {
        var f = S.format(p.format), team = S.isTeam(f), y = 34, x = 30, w = p.w - 60;
        text(p.w / 2, 10, sec(p.name), "#F6E27A", 1, 0.5);
        var states = { COUNTDOWN: "state_starting", MATCH: "state_in_progress", INTERMISSION: "state_between", FINISHED: "state_finished" };
        text(p.w / 2, 22, p.open ? sec(T("signup.state_open")) : "§7" + T("signup." + (states[p.state] || "state_none")), "#FFFFFF", 0.75, 0.5);
        var kind = team ? T("signup.kind_team", f.label, p.size) : S.isFfa(f) ? T("signup.kind_ffa") : T("signup.kind_solo");
        text(p.w / 2, 32, sec(T("signup.summary", kind, p.count)), "#FFFFFF", 0.75, 0.5);
        y = 46;
        if (!team) {
            button(x, y, w, T("signup.sign_up"), function () { send("join", { id: p.id }); close(); }, null, null, !p.open || p.signed); y += 20;
            button(x, y, w, T("signup.withdraw"), function () { send("leave", { id: p.id }); close(); }, null, null, !p.signed); y += 20;
        } else {
            p.teamName = p.teamName || "";
            input(x, y, w - 48, function () { return p.teamName; }, function (v) { p.teamName = v; }, { max: 24 });
            button(x + w - 44, y - 1, 44, T("signup.create"), function () { send("create_team", { id: p.id, name: p.teamName }); }, T("signup.team_name"), null, !p.open);
            y += 20;
            var maxRows = 6, sc = p.teamScroll || 0, maxSc = Math.max(0, p.teams.length - maxRows);
            sc = p.teamScroll = Math.max(0, Math.min(sc, maxSc));
            p.teams.slice(sc, sc + maxRows).forEach(function (t) {
                var full = t.members.length >= p.size;
                button(x, y, p.teams.length > maxRows ? w - 16 : w, T("signup.join_team", sec(t.name), t.members.length, p.size), function () { send("join_team", { id: p.id, team: t.id }); },
                    t.members.join(", "), null, !p.open || full);
                y += 18;
            });
            if (p.teams.length > maxRows) {
                button(x + w - 14, 66, 14, "▲", function () { p.teamScroll = Math.max(0, sc - 1); }, null, null, sc <= 0);
                button(x + w - 14, y - 18, 14, "▼", function () { p.teamScroll = Math.min(maxSc, sc + 1); }, null, null, sc >= maxSc);
            }
            if (!p.teams.length) { text(p.w / 2, y + 3, "§7No teams yet - create one or sign up solo.", "#AAAAAA", 0.7, 0.5); y += 14; }
            y += 4;
            button(x, y, w, T("signup.sign_up_solo"), function () { send("join", { id: p.id }); close(); }, null, null, !p.open || p.signed); y += 20;
            button(x, y, w, T("signup.leave_team"), function () { send("leave_team", { id: p.id }); }); y += 20;
            button(x, y, w, T("signup.withdraw"), function () { send("leave", { id: p.id }); close(); }, null, null, !p.signed); y += 20;
        }
        button(x, y, w, T("signup.to_waiting"), function () { send("tpwait", { id: p.id }); close(); }); y += 20;
        button(x, y, (w - 4) / 2, T("signup.status"), function () { send("status", { id: p.id }); });
        button(x + (w + 4) / 2, y, (w - 4) / 2, T("signup.bracket"), function () { send("bracket", { id: p.id }); }); y += 24;
        button(x, y, w, T("common.close"), close);
    }
    function signupHeight(d) {
        if (!S.isTeam(S.format(d.format))) return 160;
        return 206 + 18 * Math.min(6, Math.max(1, d.teams.length));
    }

    // ===================================================================================
    //  Bracket, leaderboard, stat gem picker
    // ===================================================================================
    function buildBracket(p) {
        title(T("bracket.title") + ": " + S.strip(p.name));
        text(p.w / 2, 22, sec(p.status), "#FFFFFF", 0.65, 0.5);
        listBox("bk", 14, 34, p.w - 28, p.h - 72, function () {
            var rows = [];
            if (p.ffa) {
                rows.push({ t: "§6" + T("bracket.ffa", p.ffa.alive.length, p.ffa.total), actions: [] });
                p.ffa.alive.forEach(function (n) { rows.push({ t: "   §a" + n, actions: [] }); });
                p.ffa.out.forEach(function (n, i) { rows.push({ t: "   §7" + (p.ffa.alive.length + i + 1) + ". §8" + n, actions: [] }); });
                return rows;
            }
            if (!p.rounds.length) return [{ t: T("bracket.empty"), actions: [] }];
            p.rounds.forEach(function (round, ri) {
                rows.push({ t: "§6§l" + T("bracket.round", ri + 1), actions: [] });
                round.forEach(function (m) {
                    if (m.b === null) { rows.push({ t: "   §a" + sec(m.a) + " §7" + T("bracket.bye"), actions: [] }); return; }
                    var a = m.w === 1 ? "§e§l" + S.strip(m.a) : m.w === 2 ? "§8" + S.strip(m.a) : "§f" + S.strip(m.a);
                    var b = m.w === 2 ? "§e§l" + S.strip(m.b) : m.w === 1 ? "§8" + S.strip(m.b) : "§f" + S.strip(m.b);
                    rows.push({ t: "   " + a + " §r§7vs " + b + (m.live ? "  §c§lLIVE" : ""), actions: [] });
                });
            });
            return rows;
        });
        footer([["Refresh", function () { send("bracket", { id: p.id }); }], [T("common.back"), back]]);
    }
    function buildTop(p) {
        title(T("top.title"));
        var cols = [["top.wins", p.wins], ["top.bouts", p.bouts], ["top.played", p.played]], cw = Math.floor((p.w - 28) / 3);
        cols.forEach(function (c, i) {
            var x = 14 + i * cw;
            text(x + cw / 2, 34, "§6§l" + T(c[0]), "#FFD700", 0.8, 0.5);
            if (!c[1].length) text(x + cw / 2, 50, T("top.empty"), "#AAAAAA", 0.75, 0.5);
            c[1].forEach(function (e, j) {
                text(x + 6, 50 + j * 14, (j === 0 ? "§e" : j < 3 ? "§f" : "§7") + e.r + ". " + e.n, "#FFFFFF", 0.75);
                text(x + cw - 6, 50 + j * 14, "§b" + e.s, "#FFFFFF", 0.75, 1);
            });
        });
        footer([[T("common.back"), back]]);
    }
    function buildGem(p) {
        title(T("gem.title"), "+" + p.amount);
        S.GEM_STATS.forEach(function (g, i) {
            var col = i % 2, row = Math.floor(i / 2);
            button(16 + col * 104, 40 + row * 22, 100, T("gem.stat." + g[0]), function () { send("gem", { amount: p.amount, stat: g[0] }); close(); });
        });
        footer([[T("common.close"), close]]);
    }

    // ===================================================================================
    //  The screen
    // ===================================================================================
    function show() {
        var p = page();
        if (!p) return;
        p.scroll = p.scroll || {};
        B = [];
        switch (p.type) {
            case "list": buildList(p); break;
            case "edit": buildEdit(p); break;
            case "rewards": buildRewards(p); break;
            case "reward": buildReward(p); break;
            case "browser": buildBrowser(p); break;
            case "signup": buildSignup(p); break;
            case "bracket": buildBracket(p); break;
            case "top": buildTop(p); break;
            case "gem": buildGem(p); break;
        }
        E.widgets = B;
        var d = dims(), els = [], n = 0;
        B.forEach(function (w) {
            if (w.k !== "input") return;
            w.id = "in" + (n++);
            els.push({ id: w.id, type: "input", anchor: "center", x: w.x - d[0] / 2 + 1, y: w.y - d[1] / 2, w: w.w - 2, h: 12, maxLength: w.max, value: w.get(),
                onChange: (function (wd) { return function (id, v) { wd.set(String(v)); }; })(w) });
        });
        boxes(p.type === "edit" ? p.def : null);
        var tok = ++E.token;
        E.open = true;
        RPG.screen.open({ id: SID, referenceHeight: 360, background: "dim", closeOnEsc: false, elements: els,
            onRender: render, onMouse: mouse, onScroll: scroll,
            onKey: function (k, action) { if (action === "down" && k === "key.keyboard.escape") { act(back, true); return false; } },
            onClose: function () { if (tok === E.token) { E.open = false; E.stack = []; boxes(null); } } });
    }
    // the edited tournament's regions drawn in the world (RPG.world.box) while its editor is open
    function boxes(def) {
        ["arena", "waiting", "stands"].forEach(function (k) { RPG.world.removeBox("dbrt_" + k); });
        if (!def) return;
        [["arena", "#FFAA00"], ["waiting", "#55FFFF"], ["stands", "#55FF55"]].forEach(function (b) {
            var r = def[b[0]];
            if (r && r.dim === RPG.player.dimension) RPG.world.box("dbrt_" + b[0], r.min[0], r.min[1], r.min[2], r.max[0], r.max[1], r.max[2], b[1], { alpha: 0.9, maxDistance: 256 });
        });
    }

    function val(x) { return typeof x === "function" ? x() : x; }
    function txt(ctx, t, x, y, color, align, scale) { ctx.textStyled(String(t), x, y, scale || TS, color || "#FFFFFF", 1, align || 0, FONT, "#000000"); }
    function tw(ctx, t, scale) { return ctx.textWidthIn(String(t), FONT) * (scale || TS); }
    function fit(ctx, t, w, scale) {
        if (tw(ctx, t, scale) <= w) return t;
        while (t.length > 1 && tw(ctx, t + "...", scale) > w) t = t.substring(0, t.length - 1);
        return t + "...";
    }
    function drawButton(ctx, x, y, w, h, lab, hover, color, active, disabled) {
        var v = (hover || active) && !disabled ? 48 : 28;
        ctx.quad(BUTTONS, x, y, 3, h, 0, v / 256, 3 / 256, (v + 20) / 256, "#FFFFFF", 1);
        ctx.quad(BUTTONS, x + 3, y, w - 6, h, 3 / 256, v / 256, 71 / 256, (v + 20) / 256, "#FFFFFF", 1);
        ctx.quad(BUTTONS, x + w - 3, y, 3, h, 71 / 256, v / 256, 74 / 256, (v + 20) / 256, "#FFFFFF", 1);
        if (active) ctx.fill(x + 2, y + 2, w - 4, h - 4, "#FFD700", 0.18);
        if (disabled) ctx.fill(x + 2, y + 2, w - 4, h - 4, "#000000", 0.4);
        txt(ctx, fit(ctx, lab, w - 6, 0.75), x + w / 2, y + Math.floor((h - 6) / 2), disabled ? "#808080" : active ? "#FFD700" : hover ? "#FFFFA0" : (color || "#FFFFFF"), 0.5, 0.75);
    }
    function render(ctx) {
        var p = page();
        if (!p) return;
        var d = dims(), PW = d[0], PH = d[1];
        var px = Math.floor((ctx.width - PW) / 2), py = Math.floor((ctx.height - PH) / 2), mx = ctx.mouseX - px, my = ctx.mouseY - py, tip = null;
        E.px = px; E.py = py;
        ctx.fill(px + 6, py + 6, PW - 12, PH - 12, "#0F1020", 0.8);
        U.QUEST_PANEL.draw(ctx, px, py, PW, PH);
        E.widgets.forEach(function (w) {
            var hov = mx >= w.x && my >= w.y && mx < w.x + (w.w || 0) && my < w.y + (w.h || 0);
            var x = px + w.x, y = py + w.y;
            switch (w.k) {
                case "text": var tv = String(val(w.t)); txt(ctx, w.mw ? fit(ctx, tv, w.mw, w.scale || TS) : tv, x, y, w.color || "#FFFFFF", w.align || 0, w.scale || TS); break;
                case "btn": drawButton(ctx, x, y, w.w, w.h, val(w.t), hov, w.color, false, w.disabled); break;
                case "tab": drawButton(ctx, x, y, w.w, w.h, w.t, hov, null, w.active, false); break;
                case "toggle":
                    var on = !!w.get();
                    ctx.quad(BUTTONS, x, y + 1, 20, 10, 122 / 256, (on ? 0 : 10) / 256, 142 / 256, (on ? 10 : 20) / 256, "#FFFFFF", 1);
                    txt(ctx, fit(ctx, w.t, w.w - 26, 0.75), x + 24, y + 2, hov ? "#FFFFA0" : on ? "#FFFFFF" : "#A0A0A0", 0, 0.75);
                    break;
                case "cycle":
                    var opts = w.opts() || [], cur = w.get(), lab = String(cur);
                    opts.forEach(function (o) { if (String(o[0]) === String(cur)) lab = o[1]; });
                    ctx.fill(x, y, w.w, w.h, "#000000", 0.55);
                    ctx.fill(x, y, w.w, 1, "#5A5A7A", 1); ctx.fill(x, y + w.h - 1, w.w, 1, "#5A5A7A", 1);
                    var hl = hov && mx < w.x + w.w / 2, hr = hov && !hl;
                    ctx.quad(BUTTONS, x + 2, y + 2, 10, 10, 142 / 256, (hl ? 10 : 0) / 256, 152 / 256, (hl ? 20 : 10) / 256, "#FFFFFF", 1);
                    ctx.quad(BUTTONS, x + w.w - 12, y + 2, 10, 10, 0, (hr ? 10 : 0) / 256, 10 / 256, (hr ? 20 : 10) / 256, "#FFFFFF", 1);
                    txt(ctx, fit(ctx, lab, w.w - 30, 0.75), x + w.w / 2, y + 4, hov ? "#FFFFA0" : "#FFFFFF", 0.5, 0.75);
                    break;
                case "list": tip = drawList(ctx, w, x, y, mx, my) || tip; break;
            }
            if (hov && w.tip && w.k !== "list") tip = w.tip;
        });
        U.drawStatus(ctx, px + PW / 2, py + PH - 44);
        if (tip) U.tooltip(ctx, U.wrap(ctx, sec(tip), 220).map(function (l) { return [l, "#E0E0E0"]; }), ctx.mouseX, ctx.mouseY);
    }
    function rowsOf(w) { if (!w._rows || w._at !== E.token + ":" + RPG.time()) { w._rows = w.rows(); w._at = E.token + ":" + RPG.time(); } return w._rows; }
    function actionRects(w, rx, ry, row) {
        var out = [], x = rx + w.w - 4;
        for (var i = row.actions.length - 1; i >= 0; i--) {
            var a = row.actions[i], bw = a[0] === "X" ? 16 : Math.max(30, Math.ceil(S.strip(a[0]).length * 4.4) + 8);
            x -= bw;
            out.unshift([x, ry + 1, bw, ROW - 2, a]);
            x -= 3;
        }
        return out;
    }
    function drawList(ctx, w, x, y, mx, my) {
        var rows = rowsOf(w), p = page(), total = rows.length * ROW, max = Math.max(0, total - w.h), tip = null;
        var sc = p.scroll[w.key] = Math.max(0, Math.min(p.scroll[w.key] || 0, max));
        ctx.fill(x, y, w.w, w.h, "#000000", 0.3);
        ctx.fill(x, y, w.w, 1, "#444466", 0.6); ctx.fill(x, y + w.h - 1, w.w, 1, "#444466", 0.6);
        ctx.clip(x, y, w.w, w.h);
        rows.forEach(function (r, i) {
            var ry = y + i * ROW - sc;
            if (ry + ROW < y || ry > y + w.h) return;
            var lx = mx + E.px, ly = my + E.py, hov = lx >= x && lx < x + w.w && ly >= ry && ly < ry + ROW && ly >= y && ly < y + w.h;
            if (hov) ctx.fill(x + 1, ry, w.w - 2, ROW, "#FFFFFF", 0.07);
            var rects = actionRects(w, x, ry, r), textW = (rects.length ? rects[0][0] - x : w.w) - 10;
            txt(ctx, fit(ctx, r.t, textW, TS), x + 5, ry + 4, "#FFFFFF", 0, TS);
            rects.forEach(function (rc) {
                var bh = lx >= rc[0] && lx < rc[0] + rc[2] && ly >= rc[1] && ly < rc[1] + rc[3] && ly >= y && ly < y + w.h;
                drawButton(ctx, rc[0], rc[1], rc[2], rc[3], rc[4][0], bh, rc[4][2] ? "#FF9090" : null, false, false);
                if (bh && rc[4][3]) tip = rc[4][3];
            });
            if (hov && !tip && tw(ctx, r.t, TS) > textW) tip = U.strip(r.t);
        });
        ctx.unclip();
        if (total > w.h) {
            var th = Math.max(12, w.h * w.h / total), ty = y + (w.h - th) * sc / max;
            ctx.fill(x + w.w - 3, y, 2, w.h, "#000000", 0.4); ctx.fill(x + w.w - 3, ty, 2, th, "#D2D7F1", 1);
        }
        return tip;
    }
    function cycleNext(opts, cur, dd) {
        var i = -1;
        for (var j = 0; j < opts.length; j++) if (String(opts[j][0]) === String(cur)) i = j;
        return opts[(i + dd + opts.length * 2) % opts.length][0];
    }
    function mouse(x, y, btn, action) {
        if (action !== "down" || btn !== 0 || E.px === undefined) return;
        var mx = x - E.px, my = y - E.py, ws = E.widgets, handled = false;
        for (var i = ws.length - 1; i >= 0 && !handled; i--) {
            var w = ws[i];
            if (w.k === "list") {
                if (mx < w.x || my < w.y || mx >= w.x + w.w || my >= w.y + w.h) continue;
                var rows = rowsOf(w), sc = page().scroll[w.key] || 0, ri = Math.floor((my - w.y + sc) / ROW), r = rows[ri];
                if (!r) return false;
                actionRects(w, w.x, w.y + ri * ROW - sc, r).forEach(function (rc) {
                    if (!handled && mx >= rc[0] && mx < rc[0] + rc[2] && my >= rc[1] && my < rc[1] + rc[3]) { handled = true; act(rc[4][1]); }
                });
                return false;
            }
            if (!(mx >= w.x && my >= w.y && mx < w.x + (w.w || 0) && my < w.y + (w.h || 0))) continue;
            if (w.k === "btn" || w.k === "tab") { if (w.disabled) { RPG.sound("minecraft:block.note_block.bass", 0.4, 0.6); return false; } handled = true; act(w.fn); }
            else if (w.k === "toggle") { handled = true; var nv = !w.get(); RPG.sound(nv ? "dmzpack:switch_on" : "dmzpack:switch_off", 1, 1); act(function () { w.set(nv); }, true); }
            else if (w.k === "cycle") { handled = true; var dd = mx < w.x + w.w / 2 ? -1 : 1; act(function () { w.set(cycleNext(w.opts(), w.get(), dd)); }); }
        }
        if (handled) return false;
    }
    function act(fn, silent) {
        if (!silent) RPG.sound("dmzpack:pip_menu", 1, 1);
        try { fn(); } catch (e) { RPG.log("Tournaments: " + e); U.showStatus("Error: " + e, "#FF5555"); }
        if (E.open && page()) show();
    }
    function scroll(x, y, delta) {
        if (E.px === undefined) return;
        var mx = x - E.px, my = y - E.py, p = page();
        if (p && p.type === "signup" && p.teams && p.teams.length > 6) { p.teamScroll = Math.max(0, (p.teamScroll || 0) + (delta > 0 ? -1 : 1)); show(); return; }
        E.widgets.forEach(function (w) {
            if (w.k === "list" && mx >= w.x && my >= w.y && mx < w.x + w.w && my < w.y + w.h) p.scroll[w.key] = Math.max(0, (p.scroll[w.key] || 0) - (delta > 0 ? ROW * 2 : -ROW * 2));
        });
    }

    // ---- what the server opens ----
    RPG.net.on("dbr_tourney_open", function (d) {
        if (!d || !d.page) return;
        var top = page();
        if (d.titles) E.titles = S.list(d.titles).map(String);
        switch (d.page) {
            case "list":
                E.stack = [{ type: "list", defs: S.list(d.defs).map(S.normalize), states: d.states || {}, w: 400, h: 300, scroll: {} }];
                break;
            case "edit":
                push({ type: "edit", def: S.normalize(d.def), tab: 0, w: 400, h: 300 });
                break;
            case "browser":
                E.stack = [{ type: "browser", entries: S.list(d.entries), admin: !!d.admin, w: 340, h: 260, scroll: {} }];
                break;
            case "signup":
                var sp = { type: "signup", id: d.id, name: d.name, open: !!d.open, signed: !!d.signed, count: d.count, state: d.state, format: d.format,
                    size: d.size, teams: S.list(d.teams).map(function (t) { return { id: t.id, name: t.name, members: S.list(t.members) }; }), w: 220, scroll: {} };
                sp.h = signupHeight(sp);
                if (top && top.type === "signup" && top.id === sp.id) { sp.teamName = top.teamName; sp.teamScroll = top.teamScroll; E.stack[E.stack.length - 1] = sp; }
                else if (top && top.type === "browser" && E.open) push(sp);
                else E.stack = [sp];
                break;
            case "bracket":
                var bp = { type: "bracket", id: d.id, name: d.name, status: d.status, rounds: S.list(d.rounds).map(function (r) { return S.list(r); }),
                    ffa: d.ffa ? { alive: S.list(d.ffa.alive), out: S.list(d.ffa.out), total: d.ffa.total } : null, w: 400, h: 300, scroll: {} };
                if (top && top.type === "bracket" && top.id === bp.id) E.stack[E.stack.length - 1] = bp;
                else if (top && E.open) push(bp); else E.stack = [bp];
                break;
            case "top":
                var tp = { type: "top", wins: S.list(d.wins), bouts: S.list(d.bouts), played: S.list(d.played), w: 400, h: 230, scroll: {} };
                if (top && E.open) push(tp); else E.stack = [tp];
                break;
            case "gem":
                E.stack = [{ type: "gem", amount: d.amount, w: 236, h: 150, scroll: {} }];
                break;
            default: return;
        }
        show();
    });
    // a WorldEdit selection was captured for the open editor
    RPG.net.on("dbr_tourney_def", function (d) {
        if (!d || !d.def) return;
        var nd = S.normalize(d.def);
        E.stack.forEach(function (p) {
            if (p.type === "edit" && p.def.id === nd.id) { p.def.arena = nd.arena; p.def.waiting = nd.waiting; p.def.stands = nd.stands; p.coords = {}; }
        });
        if (E.open && page()) show();
    });

    // ===================================================================================
    //  HUD: open sign-ups (the quest tracker notice in DMZ Ragnarok), the bout being watched,
    //  title tags over holders' heads and a marker over sign-up hosts
    // ===================================================================================
    var HUD = { s: [], m: null, at: 0 };
    RPG.net.on("dbr_tourney_hud", function (d) {
        HUD.s = d && d.s ? S.list(d.s) : [];
        HUD.m = d && d.m ? d.m : null;
        HUD.at = RPG.nowMs();
    });
    function hudText(ctx, t, x, y, color, align, scale) { ctx.textStyled(sec(t), x, y, scale || 0.75, color || "#FFFFFF", 1, align || 0, FONT, "#000000"); }
    RPG.hud.onRender(function (ctx) {
        if (!HUD.s.length && !HUD.m) return;
        var gone = Math.floor((RPG.nowMs() - HUD.at) / 1000);
        if (HUD.s.length) {
            var h = 6 + HUD.s.length * 10, w = 200, x = ctx.width - w - 4, y = Math.floor(ctx.height * 0.32);
            if (ctx.group("dbr_tourney_signups", "Tournament sign-ups", x, y, w, h)) {
                HUD.s.forEach(function (s, i) {
                    var left = S.mmss(Math.max(0, s.l - gone));
                    hudText(ctx, s.i ? T("hud.signed", S.strip(s.n), s.c, left) : T("hud.signups", S.strip(s.n), s.c, left), x + w, y + 3 + i * 10, "#FFFFFF", 1);
                });
                ctx.endGroup();
            }
        }
        var m = HUD.m;
        if (!m) return;
        var mw = 230, mh = m.a ? 18 + 10 * Math.max(m.a.m.length, m.b ? m.b.m.length : 0) : 26, mx = Math.floor((ctx.width - mw) / 2), my = 4;
        if (!ctx.group("dbr_tourney_match", "Tournament match", mx, my, mw, mh)) return;
        ctx.fill(mx, my, mw, mh, "#000000", 0.45);
        ctx.fill(mx, my, mw, 1, "#FFD700", 0.6);
        var head = "&6" + S.strip(m.n) + (m.r ? " &7- Round " + m.r : "");
        if (m.c) head += " &e- " + m.c + "...";
        else if (m.t !== undefined) head += " &f- " + S.mmss(Math.max(0, m.t - (m.st === "MATCH" ? gone : 0)));
        else if (m.st === "INTERMISSION") head += " &7- next bout soon";
        else if (m.st === "FINISHED") head += " &a- finished";
        hudText(ctx, head, mx + mw / 2, my + 4, "#FFFFFF", 0.5);
        if (m.f) { hudText(ctx, "&fTournament of Power: &e" + m.f.a + "&7/" + m.f.t + " &fstanding", mx + mw / 2, my + 15, "#FFFFFF", 0.5); }
        else if (m.a && m.b) {
            [[m.a, mx + 6, 0], [m.b, mx + mw - 6, 1]].forEach(function (side) {
                var t = side[0];
                t.m.forEach(function (f, i) {
                    var yy = my + 15 + i * 10, bw = 60, pct = Math.max(0, Math.min(1, f.h / Math.max(1, f.x)));
                    var bx = side[2] ? side[1] - bw : side[1];
                    ctx.fill(bx, yy + 7, bw, 2, "#000000", 0.7);
                    ctx.fill(side[2] ? bx + bw * (1 - pct) : bx, yy + 7, bw * pct, 2, f.o ? "#555555" : pct > 0.5 ? "#55FF55" : pct > 0.25 ? "#FFAA00" : "#FF5555", 1);
                    hudText(ctx, (f.o ? "&8&m" : "&f") + f.n, side[2] ? side[1] : side[1], yy, "#FFFFFF", side[2], 0.65);
                });
            });
            hudText(ctx, "&cvs", mx + mw / 2, my + 16, "#FFFFFF", 0.5, 0.7);
        }
        ctx.endGroup();
    });

    var TAGS = { titles: {}, hosts: {} }, SHOWN = {};
    RPG.net.on("dbr_tourney_tags", function (d) { TAGS = { titles: (d && d.titles) || {}, hosts: (d && d.hosts) || {} }; refreshTags(); });
    function refreshTags() {
        var seen = {};
        RPG.world.entities(48).forEach(function (e) {
            var tag = TAGS.titles[e.uuid], host = TAGS.hosts[e.uuid];
            if (tag && e.player) {
                var id = "dbrt_tag_" + e.id;
                seen[id] = 1;
                if (SHOWN[id] !== tag) { RPG.hud.set(id, { type: "text", text: tag.replace(/^\s+/, ""), entity: e.id, offsetY: 0.8, shadow: true, align: "center" }); SHOWN[id] = tag; }
            } else if (host) {
                var hid = "dbrt_host_" + e.id;
                seen[hid] = 1;
                if (SHOWN[hid] !== host) { RPG.hud.set(hid, { type: "text", text: host, entity: e.id, offsetY: 0.85, shadow: true, align: "center", scale: 0.8 }); SHOWN[hid] = host; }
            }
        });
        Object.keys(SHOWN).forEach(function (id) { if (!seen[id]) { RPG.hud.remove(id); delete SHOWN[id]; } });
    }
    RPG.every(10, refreshTags);
})();
