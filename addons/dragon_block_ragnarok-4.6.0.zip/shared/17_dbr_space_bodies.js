// =====================================================================================
//  17_dbr_space_bodies.js - every body in space, planet surfaces and their weather
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0): MoonBody (every main planet has a moon, a quarter of its
//  size, 2.6 radii out, one degree a second), SurfaceDimension (each generated planet and
//  moon is a square cell of the one planet_surface dimension, 65536 blocks apart on a
//  900 x 900 grid), SurfaceStamp's themes (stony, overworld, Namek, nether, end, Kai) with
//  their relief profiles, sea levels and ground layers, and PlanetWeather (each planet's
//  weather walks through hour-long blocks of 3..10 minute episodes picked from its theme).
// =====================================================================================
var DBR_SPACE_BODIES = (function () {
    var O = DBR_SPACE_ORBITS, G = DBR_SPACE_GEN, U = O.u64;
    var SURFACE = "ragnarok_rpg:planet_surface";
    var S = { scale: 0.25, planeY: 0 };
    function configure(scale, planeY) { S.scale = scale; S.planeY = planeY; G.configure(scale, planeY); }

    // ---- the main system ----
    function fixedPos(b, epoch) { return O.position(b.id, epoch, S.scale, S.planeY); }
    function sunPos() { return { x: 0, y: S.planeY, z: 0 }; }
    /** MoonBody.position, driven by the wall clock (1 degree a second, DMZR's 0.05 degrees a tick). */
    function moonPos(parent, epoch) {
        var p = fixedPos(parent, epoch), a = ((epoch / 1000) % 360) * Math.PI / 180, r = parent.radius * 2.6;
        return { x: p.x + Math.cos(a) * r, y: p.y, z: p.z - Math.sin(a) * r };
    }
    var MOONS = O.BODIES.map(function (b) { return { id: "moon_" + b.id, key: "sumoon:" + b.key, parent: b, radius: b.radius * 0.25, surface: 400 }; });
    var MOON_BY_ID = {};
    MOONS.forEach(function (m) { MOON_BY_ID[m.id] = m; MOON_BY_ID[m.key] = m; });

    // ---- the seven Super Dragon Ball bodies (SuperPlanetPositions): each on its own orbit round the sun, in a band
    // between two main rings (two bands in each of the four inner gaps); orbit elements chosen once by the server ----
    var SUPER = [];                                    // [{star, ring (DMZR radius), phase0, y (DMZR height)}]
    var SUPER_RADIUS = 4 * 88;                         // 4x Namek
    function setSuper(list) { SUPER = (list || []).map(function (e) { return { star: Number(e.star), ring: Number(e.ring), phase0: Number(e.phase0), y: Number(e.y) }; }); }
    function superBand(band) {
        var keep = 92 * (1 + 2.6 + 0.25) + SUPER_RADIUS + 256, gapW = 2 * SUPER_RADIUS + 256, gap = Math.floor(band / 2), half = band % 2;
        var inner = 6000 + gap * 15000 + keep, outer = 6000 + (gap + 1) * 15000 - keep, w = Math.max(0, (outer - inner - gapW) / 2);
        var lo = inner + half * (w + gapW);
        return [lo, lo + w];
    }
    function superPos(e, epoch) {
        var a = O.angle(e.phase0, O.periodMillis(e.ring), epoch), r = e.ring * S.scale;
        return { x: Math.cos(a) * r, y: S.planeY + e.y * S.scale, z: Math.sin(a) * r };
    }
    // ---- destroyed bodies (PlanetDestruction): gone from space for everyone ----
    var DESTROYED = {};
    function setDestroyed(list) { DESTROYED = {}; (list || []).forEach(function (id) { DESTROYED[id] = true; }); }
    function isDestroyed(id) { return !!DESTROYED[id]; }

    /**
     * Everything landable or dangerous near a point: {kind: "fixed"|"moon"|"planet"|"star"|"sun"|"hole", id, pos, radius, ...}.
     * range = how far to look for generated things (the main system is always included).
     */
    function near(p, range, epoch) {
        var out = [];
        O.BODIES.forEach(function (b) { out.push({ kind: "fixed", id: b.id, body: b, pos: fixedPos(b, epoch), radius: b.radius }); });
        MOONS.forEach(function (m) { out.push({ kind: "moon", id: m.key, moon: m, pos: moonPos(m.parent, epoch), radius: m.radius, surface: m.surface }); });
        out.push({ kind: "sun", id: "sun", pos: sunPos(), radius: O.SUN.radius, tint: O.SUN.tint });
        G.systemsNear(p.x, p.z, range).forEach(function (s) {
            out.push({ kind: "star", id: s.key, pos: { x: s.x, y: s.y, z: s.z }, radius: s.radius, tint: s.tint, system: s });
            s.planets.forEach(function (pl) { out.push({ kind: "planet", id: pl.id, planet: pl, pos: G.planetPos(pl, epoch), radius: pl.radius, tint: pl.tint, surface: pl.surface }); });
        });
        G.loneStarsNear(p.x, p.y, p.z, Math.min(range, 4096)).forEach(function (s) { out.push({ kind: "star", id: s.key, pos: { x: s.x, y: s.y, z: s.z }, radius: s.radius, tint: s.tint, lone: true }); });
        G.blackHolesNear(p.x, p.y, p.z, Math.min(range, 6000)).forEach(function (h) { out.push({ kind: "hole", id: h.key, pos: { x: h.x, y: h.y, z: h.z }, radius: h.radius, hole: h }); });
        SUPER.forEach(function (e) { out.push({ kind: "super", id: "susuper:" + e.star, star: e.star, sup: e, pos: superPos(e, epoch), radius: SUPER_RADIUS }); });
        return out.filter(function (b) { return !DESTROYED[b.id] && !(b.kind === "planet" && DESTROYED[b.planet.system.key]); });
    }
    /** A landable body by id at an instant (fixed id, moon key, or sugen: planet). */
    function find(id, epoch) {
        var b = O.byId(id);
        if (b) return { kind: "fixed", id: id, body: b, pos: fixedPos(b, epoch), radius: b.radius };
        var m = MOON_BY_ID[id];
        if (m) return { kind: "moon", id: m.key, moon: m, pos: moonPos(m.parent, epoch), radius: m.radius, surface: m.surface };
        if (String(id).indexOf("susuper:") === 0) {
            var st = Number(String(id).substring(8));
            for (var i = 0; i < SUPER.length; i++) if (SUPER[i].star === st) return { kind: "super", id: id, star: st, sup: SUPER[i], pos: superPos(SUPER[i], epoch), radius: SUPER_RADIUS };
            return null;
        }
        var pl = G.findPlanet(id);
        if (pl) return { kind: "planet", id: pl.id, planet: pl, pos: G.planetPos(pl, epoch), radius: pl.radius, tint: pl.tint, surface: pl.surface };
        return null;
    }

    // ---- surfaces (SurfaceDimension) ----
    var CELL_SPACING = 65536, GRID_HALF = 450;
    // Math.floorMod(signed 64-bit h, n) for small n
    function floorMod64(h, n) {
        var two32 = 4294967296 % n;
        var r = ((h.hi % n) * two32 + (h.lo % n)) % n;
        if (h.hi >= 0x80000000) {
            var two64 = (two32 * two32) % n;                       // 2^64 mod n
            r = ((r - two64) % n + n) % n;
        }
        return r;
    }
    function cellCentre(id) {
        var cx = floorMod64(O.hash(id), GRID_HALF * 2) - GRID_HALF, cz = floorMod64(O.hash(id + "#z"), GRID_HALF * 2) - GRID_HALF;
        return { x: cx * CELL_SPACING + 0.5, y: 96, z: cz * CELL_SPACING + 0.5 };
    }
    function surfaceSize(id) { var m = MOON_BY_ID[id]; return m ? m.surface : G.surfaceSizeForId(id); }

    // ---- themes (SurfaceStamp.Theme, profileFor, liquidFor, seaFractionFor, paletteFor) ----
    var THEMES = [
        { id: "stony", weight: 12, amp: 52, oct: 5, pers: 0.55, ridge: 0.70, warp: 12, sea: 0, layers: ["stone", "andesite"], deep: "deepslate" },
        { id: "overworld", weight: 34, amp: 40, oct: 4, pers: 0.50, ridge: 0.35, warp: 16, sea: 0.34, fluid: "water", layers: ["grass_block", "dirt"], deep: "stone", shore: "sand" },
        { id: "namek", weight: 21, amp: 44, oct: 4, pers: 0.50, ridge: 0.40, warp: 16, sea: 0.33, fluid: "water", layers: ["@namek_grass_block", "@namek_dirt"], deep: "@namek_stone", shore: "sand" },
        { id: "nether", weight: 12, amp: 46, oct: 5, pers: 0.55, ridge: 0.60, warp: 12, sea: 0.16, fluid: "lava", layers: ["netherrack", "soul_soil"], deep: "basalt" },
        { id: "end", weight: 8, amp: 34, oct: 4, pers: 0.50, ridge: 0.50, warp: 10, sea: 0.20, fluid: "packed_ice", layers: ["end_stone", "end_stone"], deep: "purpur_block" },
        { id: "kaio", weight: 13, amp: 22, oct: 3, pers: 0.45, ridge: 0.20, warp: 12, sea: 0, layers: ["@sacred_planet_grass_block", "@rocky_dirt"], deep: "@rocky_stone" }
    ];
    var THEME_BY_ID = {};
    THEMES.forEach(function (t) { THEME_BY_ID[t.id] = t; });
    var THEME_MEMO = {};
    function themeFor(id) {
        if (THEME_MEMO[id]) return THEME_MEMO[id];
        return (THEME_MEMO[id] = themeRaw(id));
    }
    function themeRaw(id) {
        if (MOON_BY_ID[id] || String(id).indexOf("susuper:") === 0) return THEME_BY_ID.stony;
        var total = 0;
        THEMES.forEach(function (t) { total += t.weight; });
        var h = O.hash(id + "#surfaceTheme"), roll = Math.floor((U.shr(h, 24).lo & 0xFFFFFF) / 16777216 * total), acc = 0;
        for (var i = 0; i < THEMES.length; i++) { acc += THEMES[i].weight; if (roll < acc) return THEMES[i]; }
        return THEME_BY_ID.overworld;
    }
    /** The RPG.edit.terrain spec for a planet's surface (DMZR v4 tileable terrain: periodic relief, sea, dry landing plateau). */
    function terrainSpec(id, resolveBlock) {
        var t = themeFor(id), c = cellCentre(id), size = surfaceSize(id), half = size / 2;
        var seed = O.hash(id + "#stamp");
        var blk = function (n) { return n.charAt(0) === "@" ? (resolveBlock(n.substring(1)) || "stone") : n; };
        var seaY = t.fluid ? Math.round(96 + t.amp * (0.18 + t.sea * 0.75)) : -1;
        var spec = {
            x: Math.floor(c.x - half), z: Math.floor(c.z - half), width: size, length: size, seed: seed.lo + (seed.hi & 0x1FFFFF) * 4294967296,
            base: 96 + t.amp / 2, relief: t.amp / 2, octaves: t.oct, cells: 4, persistence: t.pers, ridge: t.ridge, warp: t.warp, periodic: true,
            floor: 64, layers: [{ block: blk(t.layers[0]), depth: 1 }, { block: blk(t.layers[1]), depth: 3 }], deep: blk(t.deep),
            plateau: { x: Math.floor(c.x), z: Math.floor(c.z), radius: 10, blend: 22, y: (seaY > 0 ? seaY + 3 : 96 + Math.round(t.amp * 0.55)) },
            clearAbove: false
        };
        if (t.fluid) spec.fluid = { block: t.fluid, level: seaY };
        if (t.shore) spec.shore = { block: t.shore, range: 1 };
        return spec;
    }

    // ---- weather (PlanetWeather) ----
    var BLOCK_MS = 3600000, EP_MIN = 180000, EP_MAX = 600000, FADE = 20000;
    var GOLD = U.make(0x9E3779B9, 0x7F4A7C15), C2 = U.make(0xBF58476D, 0x1CE4E5B9);
    function add(a, b) {
        var lo = (a.lo >>> 0) + (b.lo >>> 0), carry = lo >= 4294967296 ? 1 : 0;
        return U.make((a.hi + b.hi + carry) >>> 0, lo >>> 0);
    }
    function step(s) { return U.finish(add(s, GOLD)); }
    function mixw(a, b) { return U.finish(U.xor(a, U.mul(b, C2))); }
    function unitw(s) { return (s.hi * 2097152 + Math.floor(s.lo / 2048)) / 9007199254740992; }   // (s >>> 11) * 2^-53
    function salted(key, salt) {
        var h = U.make(0x0003FFFF, 0xFFFFFFE5 | 0), s = key + "#" + salt, k31 = U.fromInt(31);    // 1125899906842597
        for (var i = 0; i < s.length; i++) h = add(U.mul(h, k31), U.fromInt(s.charCodeAt(i)));
        return h;
    }
    function weighted(u, bag) {
        var total = 0, i;
        for (i = 1; i < bag.length; i += 2) total += bag[i];
        var target = Math.floor(u * total), acc = 0;
        for (i = 0; i < bag.length; i += 2) { acc += bag[i + 1]; if (target < acc) return bag[i]; }
        return bag[0];
    }
    function pickWeather(theme, cold, u) {
        switch (theme) {
            case "overworld": return cold ? weighted(u, ["clear", 55, "snow", 30, "blizzard", 15]) : weighted(u, ["clear", 55, "rain", 30, "storm", 15]);
            case "namek": return weighted(u, ["clear", 50, "rain", 33, "storm", 17]);
            case "kaio": return weighted(u, ["clear", 85, "rain", 15]);
            case "stony": return cold ? weighted(u, ["clear", 55, "snow", 30, "blizzard", 15]) : weighted(u, ["clear", 55, "dust", 30, "meteor", 15]);
            case "nether": return weighted(u, ["clear", 55, "ash", 45]);
            case "end": return weighted(u, ["clear", 65, "meteor", 35]);
        }
        return "clear";
    }
    var CLIMATE = {};
    /** {state, intensity 0..1} for a planet at a wall-clock instant. */
    function weather(id, epoch) {
        var theme = themeFor(id).id;
        if (CLIMATE[id] === undefined) {
            var ch = salted(id, "climate");
            CLIMATE[id] = { cold: floorMod64(ch, 3) === 0, seed: U.mul(salted(id, "weather"), GOLD) };
        }
        var c = CLIMATE[id], block = Math.floor(epoch / BLOCK_MS), offset = epoch - block * BLOCK_MS;
        var st = mixw(c.seed, U.fromInt(block)), cursor = 0;
        for (var i = 0; i < 64; i++) {
            st = step(st);
            var dur = EP_MIN + Math.floor(unitw(st) * (EP_MAX - EP_MIN));
            st = step(st);
            var s = pickWeather(theme, c.cold, unitw(st)), end = cursor + dur;
            if (offset < end || i === 63) {
                var into = offset - cursor, remain = end - offset;
                return { state: s, intensity: s === "clear" ? 0 : Math.max(0, Math.min(1, into / FADE, remain / FADE)) };
            }
            cursor = end;
        }
        return { state: "clear", intensity: 0 };
    }

    return { SURFACE: SURFACE, configure: configure, setSuper: setSuper, superBand: superBand, superPos: superPos, SUPER_RADIUS: SUPER_RADIUS,
        superList: function () { return SUPER; }, setDestroyed: setDestroyed, isDestroyed: isDestroyed, near: near, find: find, fixedPos: fixedPos, moonPos: moonPos, sunPos: sunPos, MOONS: MOONS,
        moonById: function (id) { return MOON_BY_ID[id] || null; }, cellCentre: cellCentre, surfaceSize: surfaceSize, themeFor: themeFor,
        terrainSpec: terrainSpec, weather: weather, floorMod64: floorMod64, settings: S };
})();
