// =====================================================================================
//  24_dbr_tournaments.js - Tournaments: data shared by the server and the client
// =====================================================================================
//  Ported from DMZ Ragnarok's Tournaments module (GPL-3.0, shuruis_dmz_tournaments):
//  TournamentDef (every field, its default and its editor tab), TournamentFormat, Reward
//  (the type-based reward editor form <-> the flat reward tokens) and the module's English
//  strings (assets/dmz_ragnarok/lang/en_us.json, "gui.dmz_ragnarok.tournaments.*").
//  Server: scripts/94_dbr_tournaments.js. Client: client/scripts/84_dbr_tournaments.js.
// =====================================================================================
var DBR_TOURNEY_SHARED = (function () {
    // ---- strings (en_us), "/rg tourney" is "/tourney" here ----
    var TEXT = {
        "browser.empty": "§7No tournaments available.",
        "browser.entry": "§e%s§r §7[%s] %s §7%s",
        "browser.group": "§6%s%s§r §7(%s)",
        "browser.state_closed": "§7[closed]",
        "browser.state_open": "§a[open]",
        "browser.subtitle": "Choose a tournament",
        "browser.title": "Tournaments",
        "common.back": "Back",
        "common.close": "Close",
        "common.current": "%s §7(current)",
        "common.delete": "§cDelete",
        "common.edit": "Edit",
        "common.menu": "Menu",
        "common.none": "§7(none)",
        "common.save": "§aSave",
        "common.save_plain": "Save",
        "common.toggle_off": "§7[ ] OFF",
        "common.toggle_on": "§a[x] ON",
        "dropdown.empty": "-",
        "dropdown.no_matches": "(no matches)",
        "dropdown.search": "Search...",
        "edit.announce_sound": "Announce Sound",
        "edit.announce_sound_tip": "Sound played to everyone on major announcements. Searchable list of every sound; choose (none) to disable.",
        "edit.auto_schedule": "Auto-schedule",
        "edit.auto_schedule_tip": "If ON, sign-ups open automatically at the time below. If OFF, run manually with /tourney open <name>.",
        "edit.bounds_arena": "Arena",
        "edit.bounds_max": "§7Max",
        "edit.bounds_min": "§7Min",
        "edit.bounds_not_set": "§c(not set)",
        "edit.bounds_range": "§a%s → %s",
        "edit.bounds_row": "%s: %s",
        "edit.bounds_stands": "Spectator stands",
        "edit.bounds_tip": "Two ways to set the %s bounds: make a WorldEdit selection and press \"Set via WE\", OR type the two corner coordinates (in your current dimension) and press \"Set manually\". No WorldEdit needed for the manual option. The region is treated as a full-height column, so only the X/Z footprint matters - a thin floor-level selection is enough and height is ignored.",
        "edit.bounds_waiting": "Waiting area",
        "edit.countdown": "Countdown Seconds",
        "edit.countdown_tip": "Countdown length after both fighters are teleported in, before the match begins.",
        "edit.day_of_month": "Day of Month (0=ignore, 1-28)",
        "edit.day_of_month_tip": "Monthly cadence: day of the month to run. 0 ignores it and falls back to the weekly or daily schedule.",
        "edit.day_of_week": "Day of Week (0=ignore, 1-7)",
        "edit.day_of_week_tip": "Weekly cadence: 1=Monday .. 7=Sunday. 0 ignores this and (unless Day of Month is set) runs DAILY.",
        "edit.display_name": "Display Name",
        "edit.display_name_tip": "The tournament's display name, used in announcements, the sign-up GUI, the NPC name, and in commands (/tourney join <name>). Supports & colour codes.",
        "edit.exclude_title_ids": "Barred title ids",
        "edit.exclude_title_ids_live": "Titles in use right now: %s.",
        "edit.exclude_title_ids_tip": "Comma-separated title ids barred from entering this tournament. Anyone holding one of these titles is refused; everyone else, including the champion, enters freely. Blank bars nobody. Titles carry across the shard network, so a holder on another shard is barred here too. Checked only when a fighter signs up, never mid-match.",
        "edit.flight_allowed": "Flight allowed",
        "edit.flight_allowed_tip": "If OFF, every fighter's flight is switched off for the whole bout and switched off again if they turn it back on. A grounded format, whatever anyone has unlocked.",
        "edit.floor_out": "Floor-out (drop below Y eliminates)",
        "edit.floor_out_tip": "If ON, a fighter whose Y falls below the value below is eliminated at once, in the air or not, so anyone knocked into a pit is out the moment they pass the line. Fully independent of ring-out: run either, both, or neither. A Tournament of Power style rule.",
        "edit.floor_out_y": "Floor-out Y level",
        "edit.floor_out_y_tip": "The Y below which floor-out eliminates a fighter. Negatives are fine (worlds reach -64). Only used while floor-out is ON.",
        "edit.force_friendly_fist": "Force Friendly Fist",
        "edit.force_friendly_fist_tip": "Force DragonMineZ's non-lethal 'friendly fist' ON for contestants inside the arena.",
        "edit.format": "Format",
        "edit.format_tip": "Competitive format. 1v1 / 2v2 / 3v3 run a single-elimination bracket; FFA (Tournament of Power) is one simultaneous free-for-all where the last fighter standing wins. Team rewards go to every member of the winning team.",
        "edit.ground_out": "Ground-out (landing eliminates)",
        "edit.ground_out_tip": "If ON, the sky is the arena: once a fighter has taken off, touching the ground knocks them out. Nobody is eliminated before their first take-off, so the bell never wipes the field. Ignored while flight is off.",
        "edit.group": "Group",
        "edit.group_tip": "Category used to organise this tournament under a collapsible dropdown in the sign-up NPC browser. NPCs can be filtered to one group with /tourney npc setgroup. Leave blank for 'Ungrouped'. Supports & colour codes.",
        "edit.heal_after_fight": "Heal After Fight",
        "edit.heal_after_fight_tip": "Fully restore both fighters' health, energy and stamina before and after every match.",
        "edit.host_entity": "Host Entity",
        "edit.host_entity_tip": "Which entity is used as the sign-up NPC. Searchable list of every entity from every mod (DMZ, sdu, vanilla). Right-clicking it opens sign-up. Every ragnarok NPC character is in this list too, as its own row (rgnpc#name): type a character's name to find it.",
        "edit.host_model": "Host Model",
        "edit.host_model_tip": "Which ragnarok NPC character it looks like, when the entity above is dmz_ragnarok:rgnpc. All of them (the ninjin cast included) share that one entity type, so this is where the actual character is chosen. Leave it on (default) for any other entity.",
        "edit.hour": "Hour (0-23)",
        "edit.hour_tip": "Time of day (server local, 24h) that sign-ups auto-open. 0 = midnight.",
        "edit.items_allowed": "Items Allowed in Arena",
        "edit.items_allowed_tip": "If OFF, contestants can't use items during a match, and their inventory + Curios (except armor) are stored away on entering and returned when they leave.",
        "edit.max_participants": "Max Participants (0=unlimited)",
        "edit.max_participants_tip": "Cap on the number of contestants. 0 means no limit.",
        "edit.min_participants": "Min Participants",
        "edit.min_participants_tip": "If fewer than this many fighters sign up, the tournament is cancelled instead of starting.",
        "edit.minute": "Minute (0-59)",
        "edit.minute_tip": "Minute of the hour for the auto-open time.",
        "edit.msg_champion": "Msg: Champion",
        "edit.msg_champion_tip": "Announced when the tournament is won. Placeholders: {name} {champion}.",
        "edit.msg_match": "Msg: Match",
        "edit.msg_match_tip": "Announced before each match. Placeholders: {name} {p1} {p2}.",
        "edit.msg_match_win": "Msg: Match Win",
        "edit.msg_match_win_tip": "Announced when a match ends. Placeholders: {name} {winner} {loser}.",
        "edit.msg_signup_open": "Msg: Sign-ups Open",
        "edit.msg_signup_open_tip": "Chat message when sign-ups open. Placeholders: {name} {id} {npc}. Use & colour codes.",
        "edit.msg_starting": "Msg: Starting",
        "edit.msg_starting_tip": "Message when the tournament starts. Placeholders: {name} {count}.",
        "edit.npc_name": "NPC Name",
        "edit.npc_name_tip": "The name shown above the sign-up NPC's head.",
        "edit.pvp_stands": "PvP in Stands",
        "edit.pvp_stands_tip": "Allow players to damage each other in the spectator stands. Normally OFF.",
        "edit.pvp_waiting": "PvP in Waiting Area",
        "edit.pvp_waiting_tip": "Allow players to damage each other in the fighter waiting area. Normally OFF.",
        "edit.random_fill": "Allow Random Team Fill",
        "edit.random_fill_tip": "Team formats (2v2/3v3) only: after pre-made teams are honored, randomly pair leftover solo sign-ups to fill remaining team slots. If OFF, only complete pre-made teams compete.",
        "edit.reminder": "Sign-up Reminder (s, 0=off)",
        "edit.reminder_tip": "While sign-ups are open, re-show the 'Sign-ups Open' title and a clickable join prompt every this-many seconds (e.g. 30 or 60). 0 = announce only once. Filling the roster (Max Participants) starts the tournament early.",
        "edit.require_character": "Require DMZ Character",
        "edit.require_character_tip": "If ON, a player must have created a DragonMineZ character before they can sign up.",
        "edit.rewards_button": "%s (%s)",
        "edit.rewards_header": "&fEdit reward lists (type-based, selectable):",
        "edit.ring_out": "Ring-out (leaving arena eliminates)",
        "edit.ring_out_tip": "If ON, stepping outside the arena's X/Z footprint knocks a fighter out. The arena is treated as full-height, so flying or being launched upward never counts as a ring-out. If OFF, only knockdowns/health decide bouts.",
        "edit.set_manually": "Set manually",
        "edit.set_via_we": "Set via WE",
        "edit.signup_minutes": "Sign-up Minutes",
        "edit.signup_minutes_tip": "How long sign-ups stay open before an auto-scheduled tournament begins.",
        "edit.tab_bounds": "Bounds",
        "edit.tab_general": "General",
        "edit.tab_messages": "Messages",
        "edit.tab_rewards": "Rewards",
        "edit.tab_rules": "Rules",
        "edit.tab_schedule": "Schedule",
        "edit.time_limit": "Match Time Limit (s, 0=none)",
        "edit.time_limit_tip": "If a match runs longer than this, the fighter with more remaining health wins. 0 = no limit.",
        "edit.title": "Tournament",
        "edit.tournament_chars": "Tournament Characters",
        "edit.tournament_chars_tip": "If ON, contestants fight with a dedicated tournament character (fixed training points, no growth). If OFF, they fight with their real character and it is never touched.",
        "edit.use_titles": "On-screen Title Announcements",
        "edit.use_titles_tip": "Also show big on-screen titles (not just chat) for major announcements.",
        "gem.stat.ene": "Energy",
        "gem.stat.pwr": "Ki Power",
        "gem.stat.res": "Resistance",
        "gem.stat.skp": "Strike Power",
        "gem.stat.str": "Strength",
        "gem.stat.vit": "Vitality",
        "gem.title": "Choose a Stat",
        "hub.subtitle": "Editor Menu",
        "hub.title": "Shurui's DMZ Tournaments",
        "hub.tournaments": "Tournaments",
        "item.stat_gem.maxed": "Your stats are maxed - equip a matching Z-Soul to benefit.",
        "item.stat_gem.no_character": "Create a DragonMineZ character first!",
        "item.stat_gem.no_key": "Stat Gems require Shurui's Key on this server.",
        "item.stat_gem.tooltip": "Right-click to choose one DMZ stat to gain +%s",
        "item.stat_gem.used": "+%s to all stats!",
        "item.stat_gem.used_one": "+%s to %s!",
        "item.stat_gem.used_one_zsoul": "+%s to %s, +%s into your Z-Soul!",
        "item.stat_gem.used_zsoul": "+%s to stats, +%s into your Z-Soul!",
        "item.stat_gem_10": "Stat Gem (+10)",
        "item.stat_gem_100": "Stat Gem (+100)",
        "item.stat_gem_25": "Stat Gem (+25)",
        "item.stat_gem_250": "Stat Gem (+250)",
        "item.stat_gem_50": "Stat Gem (+50)",
        "item.stat_gem_500": "Stat Gem (+500)",
        "list.copy": "Copy",
        "list.new": "§a+ New Tournament",
        "list.row": "§e%s§r §7(%s)%s",
        "list.signups": "Signups",
        "list.status_no_bounds": "§c[no bounds]",
        "list.status_ready": "§a[ready]",
        "list.subtitle": "Editor",
        "list.title": "Tournaments",
        "reward_edit.amount": "Amount",
        "reward_edit.command": "Command",
        "reward_edit.count": "Count",
        "reward_edit.item": "Item",
        "reward_edit.levels": "Levels",
        "reward_edit.message": "Message",
        "reward_edit.no_skills": "(no skills found)",
        "reward_edit.no_titles": "(no titles configured)",
        "reward_edit.skill": "Skill",
        "reward_edit.title": "Edit Reward",
        "reward_edit.title_field": "Title",
        "reward_edit.type": "Type",
        "reward_edit.type_tip": "What this reward does. The fields below change to match the selected type.",
        "reward_list.add": "§a+ Add Reward",
        "reward_list.edit_reward": "Edit Reward",
        "reward_list.participation": "Participation Rewards",
        "reward_list.runner_up": "Runner-up Rewards",
        "reward_list.winner": "Winner Rewards",
        "signup.create": "Create",
        "signup.join_team": "Join %s (%s/%s)",
        "signup.kind_ffa": "FFA · last one standing",
        "signup.kind_solo": "1v1",
        "signup.kind_team": "%s · teams of %s",
        "signup.leave_team": "Leave Team",
        "signup.sign_up": "Sign Up",
        "signup.sign_up_solo": "Sign Up Solo",
        "signup.state_between": "Between matches",
        "signup.state_finished": "Tournament finished",
        "signup.state_in_progress": "Match in progress",
        "signup.state_none": "No tournament running",
        "signup.state_open": "&aSign-ups are OPEN",
        "signup.state_starting": "Match starting",
        "signup.status": "Tournament Status",
        "signup.summary": "&7%s &f| Signed up: &e%s",
        "signup.team_name": "Team name",
        "signup.team_name_hint": "§8Team name",
        "signup.to_waiting": "To Waiting Area",
        "signup.withdraw": "Withdraw",
        "signup.withdraw_status": "§7Withdraw / Status"
    };
    // DBR differences from DMZ Ragnarok's wording
    TEXT["edit.host_entity_tip"] = "Which NPC /tourney npc spawn places as this tournament's sign-up host: any NPC id (/rpg npc <id>), e.g. rgnpc_saga_cl_hercule. Blank uses the npc.character setting (/rpg config dbr_tournaments). Right-clicking the host opens sign-up.";
    TEXT["edit.host_model_tip"] = "Which DMZ Ragnarok character the host looks like: an rgnpc model id such as saga_cl_hercule, saga_cl_tournament_announcer or saga_jiren (/rpgc rgnpc list). When set it wins over Host Entity. Leave blank for any other NPC.";
    TEXT["edit.tournament_chars_tip"] = "If ON, contestants fight with a dedicated tournament character (fixed training points, no growth). If OFF, they fight with their real character and it is never touched. Not in Dragon Block Ragnarok yet: contestants always fight as themselves (their inventory is still stored away when items are not allowed).";
    TEXT["edit.exclude_title_ids_tip"] = "Comma-separated title ids barred from entering this tournament. Anyone holding one of these titles is refused; everyone else, including the champion, enters freely. Blank bars nobody. Checked only when a fighter signs up, never mid-match.";
    TEXT["edit.bounds_tip"] = "Three ways to set the %s bounds: make a WorldEdit selection (//wand, //pos1, //pos2) and press \"Set via WE\"; OR type the two corner coordinates (in your current dimension) and press \"Set manually\"; \"Here\" fills a corner with where you stand. Only the X/Z footprint counts for ring-outs.";
    TEXT["edit.announce_sound_tip"] = "Sound played to everyone on major announcements (a sound id such as minecraft:ui.toast.challenge_complete). Leave blank to disable.";
    TEXT["browser.leaderboard"] = "Leaderboard";
    TEXT["signup.bracket"] = "Bracket";
    TEXT["bracket.title"] = "Bracket";
    TEXT["bracket.round"] = "Round %s";
    TEXT["bracket.bye"] = "(bye)";
    TEXT["bracket.empty"] = "§7The bracket is drawn when the tournament starts.";
    TEXT["bracket.ffa"] = "Tournament of Power: %s of %s fighters left";
    TEXT["top.title"] = "Tournament Leaderboard";
    TEXT["top.wins"] = "Championships";
    TEXT["top.bouts"] = "Bouts won";
    TEXT["top.played"] = "Tournaments entered";
    TEXT["top.empty"] = "§7Nobody yet.";
    TEXT["hud.signups"] = "&e%s &7sign-ups open &f(%s in, %s)";
    TEXT["hud.signed"] = "&a%s &7- you are signed up &f(%s in, %s)";

    function t(key) {
        var s = TEXT[key];
        if (s === undefined) s = key;
        var args = Array.prototype.slice.call(arguments, 1), i = 0;
        s = s.replace(/%(\d+)\$s/g, function (m, n) { var v = args[Number(n) - 1]; return v === undefined ? "" : String(v); });
        return s.replace(/%s/g, function () { var v = args[i++]; return v === undefined ? "" : String(v); });
    }
    function strip(s) { return String(s === undefined || s === null ? "" : s).replace(/[&§][0-9a-fk-or]/gi, ""); }

    // ---- TournamentFormat: SOLO/DUOS/TRIOS run a bracket, FFA is one free-for-all ----
    var FORMATS = [
        { id: "SOLO", label: "1v1", size: 1 }, { id: "DUOS", label: "2v2", size: 2 },
        { id: "TRIOS", label: "3v3", size: 3 }, { id: "FFA", label: "FFA", size: 1 }];
    function format(s) {
        var v = String(s || "").trim().toUpperCase();
        for (var i = 0; i < FORMATS.length; i++) if (FORMATS[i].id === v || FORMATS[i].label.toUpperCase() === v) return FORMATS[i];
        return FORMATS[0];
    }
    function isTeam(f) { return f.id === "DUOS" || f.id === "TRIOS"; }
    function isFfa(f) { return f.id === "FFA"; }

    // ---- TournamentDef: field, type, editor tab, label key, default (the Java field initialisers) ----
    //  Types: str, int (min/max), bool, enum (format), csv (title ids), region, rewards.
    var TABS = ["edit.tab_general", "edit.tab_bounds", "edit.tab_schedule", "edit.tab_rules", "edit.tab_messages", "edit.tab_rewards"];
    function F(k, type, tab, label, def, extra) {
        var f = { k: k, type: type, tab: tab, label: label, def: def };
        for (var e in extra || {}) f[e] = extra[e];
        return f;
    }
    var FIELDS = [
        F("name", "str", 0, "display_name", "Tournament", { max: 64 }),
        F("format", "enum", 0, "format", "SOLO"),
        F("group", "str", 0, "group", "", { max: 48 }),
        F("npcEntityType", "str", 0, "host_entity", "", { max: 96 }),
        F("npcModelId", "str", 0, "host_model", "", { max: 96 }),
        F("npcName", "str", 0, "npc_name", "Hercule", { max: 64 }),
        F("arena", "region", 1, "bounds_arena", null),
        F("waiting", "region", 1, "bounds_waiting", null),
        F("stands", "region", 1, "bounds_stands", null),
        F("scheduleEnabled", "bool", 2, "auto_schedule", false),
        F("scheduleHour", "int", 2, "hour", 18, { min: 0, max: 23 }),
        F("scheduleMinute", "int", 2, "minute", 0, { min: 0, max: 59 }),
        F("scheduleDayOfWeek", "int", 2, "day_of_week", 0, { min: 0, max: 7 }),
        F("scheduleDayOfMonth", "int", 2, "day_of_month", 0, { min: 0, max: 28 }),
        F("signupMinutes", "int", 3, "signup_minutes", 10, { min: 1, max: 1440 }),
        F("minParticipants", "int", 3, "min_participants", 2, { min: 2, max: 256 }),
        F("maxParticipants", "int", 3, "max_participants", 16, { min: 0, max: 256 }),
        F("requireCharacter", "bool", 3, "require_character", true),
        F("tournamentChars", "bool", 3, "tournament_chars", true),
        F("itemsAllowed", "bool", 3, "items_allowed", false),
        F("healAfterFight", "bool", 3, "heal_after_fight", true),
        F("forceFriendlyFist", "bool", 3, "force_friendly_fist", true),
        F("ringOut", "bool", 3, "ring_out", true),
        F("floorOut", "bool", 3, "floor_out", false),
        F("floorOutY", "int", 3, "floor_out_y", 0, { min: -2048, max: 4096 }),
        F("excludeTitleIds", "csv", 3, "exclude_title_ids", []),
        F("flightAllowed", "bool", 3, "flight_allowed", true),
        F("groundOut", "bool", 3, "ground_out", false),
        F("allowRandomFill", "bool", 3, "random_fill", true),
        F("pvpInWaiting", "bool", 3, "pvp_waiting", false),
        F("pvpInStands", "bool", 3, "pvp_stands", false),
        F("useTitles", "bool", 3, "use_titles", true),
        F("countdownSeconds", "int", 3, "countdown", 5, { min: 0, max: 60 }),
        F("matchTimeLimit", "int", 3, "time_limit", 300, { min: 0, max: 3600 }),
        F("signupReminderSeconds", "int", 3, "reminder", 30, { min: 0, max: 3600 }),
        F("announceSound", "str", 4, "announce_sound", "minecraft:ui.toast.challenge_complete", { max: 128 }),
        F("msgSignupOpen", "str", 4, "msg_signup_open", "&e[Tournament] &fSign-ups OPEN for {name}! Talk to {npc} or /tourney join {id}.", { max: 256 }),
        F("msgStarting", "str", 4, "msg_starting", "&6[Tournament] &f{name} is starting with {count} fighters!", { max: 256 }),
        F("msgMatch", "str", 4, "msg_match", "&6[{name}] &fNext match: &e{p1} &fvs &e{p2}&f!", { max: 256 }),
        F("msgMatchWin", "str", 4, "msg_match_win", "&6[{name}] &e{winner} &fdefeats &e{loser}&f!", { max: 256 }),
        F("msgChampion", "str", 4, "msg_champion", "&6[{name}] &e{champion} &fis the new CHAMPION!", { max: 256 }),
        F("winnerRewards", "rewards", 5, "winner", []),
        F("runnerUpRewards", "rewards", 5, "runner_up", []),
        F("participationRewards", "rewards", 5, "participation", [])
    ];
    var FIELD = {};
    FIELDS.forEach(function (f) { FIELD[f.k] = f; });

    /** A JS array from a JS array or a Java list (config and saved data can hand back either). */
    function list(v) {
        if (v === undefined || v === null || typeof v === "string") return [];
        if (typeof v.length === "number") return Array.prototype.slice.call(v);
        if (typeof v.size === "function") { var o = []; for (var i = 0; i < v.size(); i++) o.push(v.get(i)); return o; }
        return [];
    }
    function int(v, f) {
        var n = Math.round(Number(v));
        if (isNaN(n) || !isFinite(n)) n = f.def;
        if (f.min !== undefined && n < f.min) n = f.min;
        if (f.max !== undefined && n > f.max) n = f.max;
        return n;
    }
    function region(r) {
        if (!r || typeof r !== "object" || !r.min || !r.max) return null;
        var mn = list(r.min), mx = list(r.max);
        if (mn.length < 3 || mx.length < 3) return null;
        var a = [0, 1, 2].map(function (i) { return Math.round(Number(mn[i]) || 0); });
        var b = [0, 1, 2].map(function (i) { return Math.round(Number(mx[i]) || 0); });
        return { dim: String(r.dim || "minecraft:overworld"),
            min: [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.min(a[2], b[2])],
            max: [Math.max(a[0], b[0]), Math.max(a[1], b[1]), Math.max(a[2], b[2])] };
    }
    /** A clean copy of a definition: every field present, typed and in range (TournamentDef.load). */
    function normalize(src) {
        src = src && typeof src === "object" ? src : {};
        var d = { id: String(src.id || "").toLowerCase().replace(/[^a-z0-9_\-]/g, "_").substring(0, 48) };
        FIELDS.forEach(function (f) {
            var v = src[f.k];
            if (f.type === "str") d[f.k] = v === undefined || v === null ? f.def : String(v).substring(0, f.max || 256);
            else if (f.type === "int") d[f.k] = v === undefined ? f.def : int(v, f);
            else if (f.type === "bool") d[f.k] = v === undefined ? f.def : !!v;
            else if (f.type === "enum") d[f.k] = format(v === undefined ? f.def : v).id;
            else if (f.type === "region") d[f.k] = region(v);
            else if (f.type === "csv") {
                var ids = typeof v === "string" ? v.split(",") : list(v);
                var seen = {};
                // sorted, like TournamentDef.save: stable bytes
                d[f.k] = ids.map(function (s) { return String(s).trim(); }).filter(function (s) { if (!s || seen[s]) return false; seen[s] = 1; return true; }).sort();
            } else if (f.type === "rewards") {
                d[f.k] = list(v).map(function (s) { return String(s); })
                    .filter(function (s) { return s.trim().length > 0; }).slice(0, 64);
            }
        });
        return d;
    }
    function hasAllRegions(d) { return !!(d && d.arena && d.waiting && d.stands); }
    function regionText(r) { return r ? r.min.join(", ") + " -> " + r.max.join(", ") : ""; }

    // ---- Reward: the editor form of one reward token ----
    //   command:<cmd> ({player} {uuid})   item:<id>:<count>   tp:<amount>   skill:<dmzSkillId>:<levels>
    //   title:<titleId>                   message:<text>
    var REWARD_TYPES = ["ITEM", "COMMAND", "TP", "SKILL", "TITLE", "MESSAGE"];
    function num(s, fb) { var n = Number(String(s).trim()); return isNaN(n) || !isFinite(n) ? fb : n; }
    function fmtTp(f) { return f === Math.round(f) ? String(Math.round(f)) : String(f); }
    function rewardFrom(token) {
        var r = { type: "ITEM", item: "minecraft:diamond", count: 1, command: "say hi {player}", tp: 1000, skill: "", level: 1, title: "champion", message: "&aWell fought!" };
        if (token === undefined || token === null) return r;
        token = String(token);
        var c = token.indexOf(":");
        if (c < 0) { r.type = "MESSAGE"; r.message = token; return r; }
        var type = token.substring(0, c).toLowerCase(), arg = token.substring(c + 1), parts;
        if (type === "item") {
            r.type = "ITEM";
            parts = arg.split(":");
            if (parts.length >= 3) { r.item = parts[0] + ":" + parts[1]; r.count = Math.max(1, Math.round(num(parts[2], 1))); }
            else if (parts.length === 2 && /^\d+$/.test(parts[1].trim())) { r.item = parts[0]; r.count = Math.max(1, Math.round(num(parts[1], 1))); }
            else r.item = arg;
        } else if (type === "command") { r.type = "COMMAND"; r.command = arg; }
        else if (type === "tp") { r.type = "TP"; r.tp = num(arg, 1000); }
        else if (type === "skill") { r.type = "SKILL"; parts = arg.split(":"); r.skill = parts[0]; r.level = parts.length >= 2 ? Math.round(num(parts[1], 1)) : 1; }
        else if (type === "title") { r.type = "TITLE"; r.title = arg.trim(); }
        else if (type === "message") { r.type = "MESSAGE"; r.message = arg; }
        else { r.type = "MESSAGE"; r.message = token; }
        return r;
    }
    function rewardTo(r) {
        switch (r.type) {
            case "ITEM": return "item:" + r.item + ":" + Math.max(1, Math.round(num(r.count, 1)));
            case "COMMAND": return "command:" + r.command;
            case "TP": return "tp:" + fmtTp(num(r.tp, 0));
            case "SKILL": return "skill:" + r.skill + ":" + Math.round(num(r.level, 1));
            case "TITLE": return "title:" + r.title;
            default: return "message:" + r.message;
        }
    }
    function rewardSummary(r) {
        switch (r.type) {
            case "ITEM": return "Item: " + r.count + "x " + r.item;
            case "COMMAND": return "Command: /" + r.command;
            case "TP": return "Training Points: +" + fmtTp(num(r.tp, 0));
            case "SKILL": return "Skill: " + r.skill + " +" + r.level;
            case "TITLE": return "Grant title: " + r.title;
            default: return "Message: " + r.message;
        }
    }

    // ---- stat gems (StatGemItem): +amount to one of DMZ's six stats ----
    var STAT_GEMS = [10, 25, 50, 100, 250, 500];
    var GEM_STATS = [["str", "strength"], ["skp", "strike"], ["res", "resistance"], ["vit", "vitality"], ["pwr", "kipower"], ["ene", "energy"]];

    function mmss(seconds) {
        seconds = Math.max(0, Math.floor(seconds));
        var h = Math.floor(seconds / 3600), m = Math.floor((seconds % 3600) / 60), s = seconds % 60;
        var two = function (n) { return (n < 10 ? "0" : "") + n; };
        return h > 0 ? h + ":" + two(m) + ":" + two(s) : m + ":" + two(s);
    }

    return { TEXT: TEXT, t: t, list: list, strip: strip, FORMATS: FORMATS, format: format, isTeam: isTeam, isFfa: isFfa,
        TABS: TABS, FIELDS: FIELDS, FIELD: FIELD, normalize: normalize, region: region, hasAllRegions: hasAllRegions, regionText: regionText,
        REWARD_TYPES: REWARD_TYPES, rewardFrom: rewardFrom, rewardTo: rewardTo, rewardSummary: rewardSummary, fmtTp: fmtTp,
        STAT_GEMS: STAT_GEMS, GEM_STATS: GEM_STATS, mmss: mmss };
})();
