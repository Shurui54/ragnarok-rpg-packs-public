// =====================================================================================
//  DMZ stat formulas (StatsData, TickHandler, TPGainEvents), shared by the server and the
//  stats screen. Every function takes a "view" of a character:
//      { stat(k) -> STR/SKP/RES/VIT/PWR/ENE value, cls -> class id, release -> 0..100,
//        mult(k) -> form/effect multiplier (1 = none), armor, toughness, race }
// =====================================================================================
var DMZ_F = (function () {
    var MAX_VALUE = 1000000, MAX_TOTAL = MAX_VALUE * 6;
    var VIT_KNEE = 16000, DEF_KNEE = 20000;

    function S(v, k) { var c = DMZ_DATA.CLASSES[v.cls] || DMZ_DATA.CLASSES.warrior; return c.scaling[k]; }
    function cls(v) { return DMZ_DATA.CLASSES[v.cls] || DMZ_DATA.CLASSES.warrior; }
    function M(v, k) { return v.mult ? v.mult(k) : 1; }
    function rel(v) { return (v.release || 0) / 100; }
    function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }

    function curveScalingAt(val, min, max, knee) { var r = clamp(val / knee, 0, 1); return min + (max - min) * r * r; }
    function curveValue(val, min, max, knee) {
        if (val <= 0) return val * min;
        var r = Math.min(val, knee);
        return min * r + (max - min) * r * r * r / (3 * knee * knee) + (val > knee ? max * (val - knee) : 0);
    }

    function total(v) { var t = 0; DMZ_DATA.STATS.forEach(function (k) { t += v.stat(k); }); return t; }
    function initialTotal(v) { var c = cls(v), t = 0; for (var k in c.base) t += c.base[k]; return t; }

    // ---- derived values (StatsData) ----
    function healthBonus(v) { return curveValue(v.stat("VIT"), S(v, "VIT"), S(v, "VIT_max"), VIT_KNEE) * M(v, "VIT"); }
    function maxHealth(v) { return 20 + healthBonus(v); }
    function maxKi(v) { return 20 + v.stat("ENE") * S(v, "ENE") * M(v, "ENE"); }
    function maxStamina(v) { return 20 + v.stat("RES") * S(v, "STM") * M(v, "STM"); }
    function meleeRaw(v) { return v.stat("STR") * S(v, "STR") * M(v, "STR"); }
    function melee(v) { return 1 + meleeRaw(v) * rel(v); }
    function maxMelee(v) { return 1 + meleeRaw(v); }
    function strike(v) { return 1 + (v.stat("SKP") * S(v, "SKP") * M(v, "SKP") + 0.25 * meleeRaw(v)) * rel(v); }
    function ki(v) { return (v.stat("PWR") * S(v, "PWR") * M(v, "PWR")) * rel(v); }
    function defense(v) { return (v.stat("RES") * S(v, "DEF") + (v.armor || 0) * 0.5 + (v.toughness || 0) * 0.7) * rel(v); }
    function flatDefense(v) {
        return (curveValue(v.stat("RES"), S(v, "DEF"), S(v, "DEF_max"), DEF_KNEE) + (v.armor || 0) * 0.5 + (v.toughness || 0) * 0.7) * rel(v);
    }
    function maxPoise(v) { return 25 + defense(v) / 0.12; }
    function speed(v) {
        var fm = M(v, "SPD");
        return Math.max(1, 1 + (v.stat("RES") / 10000) * fm * rel(v));
    }
    function battlePower(v) {
        var raw = ["STR", "SKP", "PWR"].reduce(function (a, k) { return a + v.stat(k) * S(v, k) * M(v, k); }, 0)
            + v.stat("RES") * S(v, "DEF") * ((M(v, "DEF") + M(v, "STM")) / 2)
            + 0.5 * (v.stat("VIT") * S(v, "VIT") * M(v, "VIT") + v.stat("ENE") * S(v, "ENE") * M(v, "ENE"));
        return 1200 * Math.pow(Math.max(0, raw) / 100, 1.2) * rel(v);
    }

    // ---- damage taken after DMZ's own mitigation (calculatePostMitigationDamage) ----
    function postMitigation(v, incoming, armorPen) {
        armorPen = armorPen || 0;
        var d = Math.max(1, M(v, "DEF")), base = defense(v) * d, flat = flatDefense(v) * d;
        base *= (1 - armorPen); flat *= (1 - armorPen);
        if (flat >= incoming * 2.5) return 0;
        var post = incoming - Math.min(flat, incoming * 0.82);
        var expectedMax = MAX_VALUE * S(v, "DEF"), soft = Math.max(12, expectedMax * 0.015), hard = Math.max(soft * 1.01, expectedMax * 0.05);
        var k = soft * (1 - 0.5) / 0.5, red;
        if (base <= soft) red = Math.min(base / (k + base), 0.88);
        else if (base >= hard) red = 0.88;
        else { var p = (base - soft) / (hard - soft); red = 0.5 + (0.88 - 0.5) * (1 - (1 - p) * (1 - p)); }
        post *= (1 - red);
        if (flat > 0) {
            var ratio = incoming / flat, m = clamp(0.15 + (0.15 / 13) * (1 - ratio), 0.0001, 0.65);
            post *= (1 - m);
        }
        return Math.max(0, post);
    }

    // ---- regeneration per second (TickHandler) ----
    function foodMult(food) { var d = Math.floor(food / 2); return d >= 9 ? 1 : d <= 3 ? 0 : 1 - (9 - d) * 0.1; }
    function hpRegen(v) { var c = cls(v); return (c.baseHp5 + v.stat("VIT") * M(v, "VIT") * c.hp5VitScaling) / 5 * (v.race === "glind" ? 1.25 : 1); }
    function kiRegen(v, charging) {
        var c = cls(v), base = (c.baseEp5 + v.stat("ENE") * M(v, "ENE") * c.ep5EneScaling) / 5;
        return (charging ? Math.max(1, base * 1.5) : base) * (v.race === "glind" ? 1.25 : 1);
    }
    function stmRegen(v, actionMod) {
        var c = cls(v);
        return (c.baseSp5 + v.stat("VIT") * M(v, "VIT") * c.sp5VitScaling + v.stat("RES") * M(v, "STM") * c.sp5ResScaling) / 5 * (actionMod === undefined ? 1 : actionMod)
            * (v.race === "glind" ? 1.25 : 1);
    }

    // ---- level and TP (StatsData.getLevel / getSingleStatCost) ----
    function level(v) {
        var init = initialTotal(v), sum = total(v);
        var progress = clamp((Math.max(init, sum) - init) / Math.max(1, MAX_TOTAL - init), 0, 1);
        return clamp(1 + Math.floor(progress * (MAX_VALUE - 1)), 1, MAX_VALUE);
    }
    function singleCost(T, classCostMult) {
        var knee = MAX_TOTAL * 0.05;
        var vary = T <= knee ? T * 1.25 : knee * 1.25 + (knee * 1.25 / 0.7) * (Math.pow(T / knee, 0.7) - 1);
        var discount = T < 140 ? 140 - T : 0;
        return Math.max(16, Math.floor((16 + vary) * (classCostMult || 1)) - discount);
    }
    /** TP for n more points starting at total T. */
    function cost(T, n, classCostMult) {
        var sum = 0;
        for (var i = 0; i < n; i++) sum += singleCost(T + i, classCostMult);
        return sum;
    }
    /** progression multiplier for TP gains (cheap early, up to x1.75 as stats get expensive). */
    function progression(v) {
        var init = initialTotal(v), T = total(v);
        var tref = init + Math.round((Math.min(MAX_VALUE, 10000) - 1) / (MAX_VALUE - 1) * (MAX_TOTAL - init));
        return 1 + 0.75 * Math.sqrt(clamp(singleCost(T, 1) / singleCost(tref, 1), 0, 1));
    }

    // ---- power release (TickHandler.chargePowerRelease) ----
    // bonus: DMZ Ragnarok's Super Shenron "Break Your Limit" wish (player var dmzr_release_boost), added on top
    function maxRelease(potential, racialMult, bonus) { return Math.floor((50 + 5 * (potential || 0)) * (racialMult || 1)) + (Number(bonus) || 0); }
    function releaseStep(chargeTicks, potential) {
        return clamp(Math.floor(Math.pow(chargeTicks / 50, 2) * (1 + 0.1 * Math.min(10, potential || 0))), 1, 10);
    }

    /** Compact number like DMZ ("1.2K", "3.4M"). */
    function compact(n) {
        var a = Math.abs(n), units = [[1e12, "T"], [1e9, "B"], [1e6, "M"], [1e3, "K"]];
        for (var i = 0; i < units.length; i++) if (a >= units[i][0]) return (n / units[i][0]).toFixed(a >= units[i][0] * 100 ? 0 : 1) + units[i][1];
        return String(Math.floor(n));
    }
    function sci(n) { return n < 1e6 ? String(Math.floor(n)) : n.toExponential(2).replace("+", ""); }

    return { MAX_VALUE: MAX_VALUE, MAX_TOTAL: MAX_TOTAL, S: S, curveValue: curveValue, curveScalingAt: curveScalingAt, total: total, initialTotal: initialTotal,
        healthBonus: healthBonus, maxHealth: maxHealth, maxKi: maxKi, maxStamina: maxStamina, melee: melee, maxMelee: maxMelee, strike: strike, ki: ki,
        defense: defense, flatDefense: flatDefense, maxPoise: maxPoise, speed: speed, battlePower: battlePower, postMitigation: postMitigation,
        foodMult: foodMult, hpRegen: hpRegen, kiRegen: kiRegen, stmRegen: stmRegen, level: level, singleCost: singleCost, cost: cost,
        progression: progression, maxRelease: maxRelease, releaseStep: releaseStep, compact: compact, sci: sci };
})();
