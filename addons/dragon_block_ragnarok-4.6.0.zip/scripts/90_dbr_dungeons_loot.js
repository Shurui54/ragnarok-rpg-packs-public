// =====================================================================================
//  90_dbr_dungeons_loot.js - DMZ Ragnarok's Dungeons: crates, spawners, guardians, items
// =====================================================================================
//  Port of DMZ Ragnarok's dungeon rewards (GPL-3.0):
//   - Dungeon crates (CrateBlock / CrateTier / CrateMetal / DungeonCrateLoot / DungeonCrateData):
//     four rarities x three metals, the twelve GeckoLib crate models; the crate's look rolls from the
//     floor's tier and metal weights per refresh window; each player loots each crate once per window
//     (refreshHours 0 = once for good): ONE item from the (rarity, metal) pool, else the rarity pool,
//     else the theme defaults, plus a zeni payout, shown with the rolling reveal screen.
//   - The advanced NPC spawner (AdvancedSpawnerBlockEntity / SpawnerConfig): floors put one under
//     every spawner rune (a weighted pick of the floor's enemy presets), staff can place the block
//     anywhere. Spawn amount, cooldown, wander leash, time-of-day, the boss mix-in, level scaling
//     (stats for the lowest nearby level, rewards for the killer's), TP / zeni ranges, custom drops
//     and kill commands (SpawnerRewardEvents).
//   - Floor guardians: a BOSS floor's guardian (the floor's boss config), scaled to the party, paid
//     out by damage share on death; beating it opens the floor's boss-lock portals for everyone and
//     records a personal clear for each damager (DungeonBossUnlocks).
//   - Items: the fourteen TP gems (TpGemItem) and the floor ticket (FloorTicketItem: right-click to
//     unlock a ticket-gated floor; a possession record, kept if already unlocked).
//   - Leaderboards (DBR addition): deepest floor, guardians beaten, crates opened, fastest clears.
// =====================================================================================
var DBRD_LOOT = (function () {
    var CORE = DBRD_CORE, C = DBRD_CFG;
    function uid(p) { return String(p.uuid); }
    function rint(a, b) { a = Math.floor(a); b = Math.floor(b); if (b < a) { var t = a; a = b; b = t; } return a + Math.floor(Math.random() * (b - a + 1)); }
    function dist2(e, x, y, z) { var dx = e.x - x, dy = e.y - y, dz = e.z - z; return dx * dx + dy * dy + dz * dz; }
    function giveTp(p, n) { if (n > 0) p.addTp(n, { raw: true, events: false, source: "dungeon" }); }
    function colorText(s) { return String(s || "").replace(/&([0-9a-fk-or])/gi, "§$1"); }
    function setName(e, name) {
        if (!e || !name) return;
        var json = JSON.stringify({ text: colorText(name) }).replace(/'/g, "\\'");
        RPG.server.runCommand("data merge entity " + e.uuid + " {CustomName:'" + json + "',CustomNameVisible:1b}");
    }

    // ---- blocks ----
    var PORTAL_ID = RPG.blocks.define("dbrd_dungeon_portal", {
        name: "&5Dungeon Portal", model: "dbr:rpg/block/dungeons/dungeon_portal", hardness: -1, light: 11, drops: "none",
        onStep: function (entity, x, y, z) { CORE.usePortal(entity, x, y, z); },
        onUse: function (player, x, y, z) { CORE.usePortal(player, x, y, z); }
    });
    function portalBlock() { return "ragnarok_rpg:" + PORTAL_ID; }
    var SPAWNER_ID = RPG.blocks.define("dbrd_advanced_spawner", {
        name: "&dAdvanced NPC Spawner", model: "dbr:rpg/block/dungeons/advanced_spawner", hardness: 5, drops: [{ item: "dbrd_advanced_spawner", count: 1 }],
        onUse: function (player, x, y, z) { openSpawner(player, player.dimension, x, y, z); },
        onPlace: function (player, x, y, z) { var all = standalone(); all[skey(player.dimension, x, y, z)] = { dim: player.dimension, x: x, y: y, z: z, config: DBRD.newSpawner() }; RPG.data.set("dbrd_spawners", all); },
        onBreak: function (player, x, y, z) { var all = standalone(); delete all[skey(player.dimension, x, y, z)]; RPG.data.set("dbrd_spawners", all); }
    });

    // the Gatekeeper: talks players into the Dungeon Gate's floor picker (place with /rpg npc dbrd_gatekeeper)
    RPG.npcs.define("dbrd_gatekeeper", {
        name: "&5Dungeon Gatekeeper", showName: true, invulnerable: true, immovable: true, wander: false,
        geo: typeof sagaLook === "function" ? sagaLook("saga_kibito") : undefined,
        onInteract: function (p) { p.setVar("dbrd_at_gate", RPG.server.getTick()); RPG.net.send(p, "dbrd_gate", CORE.gateState(p)); return false; }
    });

    // ---- items ----
    var GEM_IDS = {};
    DBRD.TP_GEMS.forEach(function (v) {
        GEM_IDS[v] = RPG.items.define("dbrd_tp_gem_" + v, {
            name: "&bTP Gem &7(" + v.toLocaleString() + ")", model: "dbr:rpg/item/dungeons/tp_gem_" + v, type: "consumable", useTime: 1, consume: true,
            rarity: v >= 10000000 ? "legendary" : v >= 1000000 ? "epic" : v >= 100000 ? "rare" : v >= 10000 ? "uncommon" : "common",
            lore: [CORE.msg("tooltip.tp_gem", v.toLocaleString())],
            onUse: function (p) { giveTp(p, v); CORE.bar(p, "tp_gem_used", v.toLocaleString()); p.playSound("minecraft:entity.player.levelup", 0.6, 1.6); }
        });
    });
    function gemStack(v) { var best = DBRD.TP_GEMS[0]; DBRD.TP_GEMS.forEach(function (g) { if (Math.abs(g - v) < Math.abs(best - v)) best = g; }); return { id: "ragnarok_rpg:" + GEM_IDS[best], count: 1 }; }
    var TICKET_ID = RPG.items.define("dbrd_floor_ticket", {
        name: "&eFloor Ticket", model: "dbr:rpg/item/dungeons/floor_ticket", type: "key", consume: false,
        lore: [CORE.msg("tooltip.floor_ticket_unset")],
        onUse: function (p) {
            var st = p.getHeldStack(), floor = st && st.data ? (st.data.floor | 0) : 0;
            if (!floor) { CORE.bar(p, "ticket_unset"); return false; }
            if (!CORE.isValid(floor)) { CORE.bar(p, "ticket_no_floor", floor); return false; }
            if (!CORE.unlockTicket(p, floor)) { CORE.bar(p, "ticket_already_unlocked", floor); return false; }
            st.count = (st.count || 1) - 1;
            p.setHeldStack(st.count > 0 ? st : null);
            CORE.bar(p, "ticket_unlocked", floor);
            p.playSound("minecraft:block.note_block.chime", 0.8, 1.4);
            return false;
        }
    });
    function ticketStack(floor) {
        return { id: "ragnarok_rpg:" + TICKET_ID, count: 1, name: "§eFloor Ticket §7(Floor " + floor + ")", data: { floor: floor },
            lore: [CORE.msg("tooltip.floor_ticket", floor)] };
    }

    // ---- crates ----
    var CRATE_NPC = {};
    DBRD.TIERS.forEach(function (t, ti) {
        DBRD.METALS.forEach(function (m, mi) {
            var name = "crate_" + t.key + "_" + m.key, id = "dbrd_" + name;
            CRATE_NPC[ti + "_" + mi] = id;
            RPG.npcs.define(id, {
                name: "", geo: { model: "dbr:geo/block/dungeons/crate/" + name + ".geo.json", texture: "dbr:textures/block/dungeons/crate/" + name + ".png",
                    animation: "dbr:animations/block/dungeons/crate/" + name + ".animation.json", idle: "idle", scale: 0.75 },
                wander: false, lookAtPlayers: false, immovable: true, invulnerable: true, width: 0.9, height: 0.9,
                onInteract: function (player, npc) { openCrate(player, npc); return false; }
            });
        });
    });
    function crateLook(n, f, q) {
        var loot = f.crateLoot, ep = DBRD.epoch(RPG.server.getTick(), loot.refreshHours), key = DBRD.posKey(q.x, q.y, q.z);
        var tw = loot.tiers.map(function (p) { return p.weight; }), mw = loot.metals.map(function (p) { return p.weight; });
        return { tier: DBRD.rollTier(key, ep, "", tw), metal: DBRD.rollMetal(key, ep, "", mw), epoch: ep, key: key };
    }
    function openCrate(p, npc) {
        var n = CORE.floorAt(npc.dimension, npc.x), f = CORE.floor(n), lay = CORE.layoutOf(n);
        if (!f || !lay) return;
        var q = null, bx = Math.floor(npc.x), by = Math.round(npc.y), bz = Math.floor(npc.z);
        (lay.crates || []).forEach(function (c) { if (!q && c.x === bx && Math.abs(c.y - by) <= 1 && c.z === bz) q = c; });
        if (!q) return;
        var look = crateLook(n, f, q), store = "dbrd_copen_" + n, opens = RPG.data.get(store, {}) || {}, k = look.key, mine = opens[k] || {};
        if (mine[uid(p)] !== undefined && mine[uid(p)] >= look.epoch) { CORE.bar(p, "crate_empty"); return; }
        mine[uid(p)] = look.epoch; opens[k] = mine; RPG.data.set(store, opens);
        var src = DBRD.crateSource(f.crateLoot, look.tier, look.metal, f.theme), stack = rollDrop(src);
        var z = DBRD.crateZeniRange(f.crateLoot, look.tier, look.metal, f.theme), zeni = rint(z[0], z[1]);
        if (stack) p.giveStack(stack);
        if (zeni > 0) p.addMoney(zeni);
        npc.playAnimation("open");
        RPG.world.sound(npc.dimension, "minecraft:block.chest.open", npc.x, npc.y, npc.z, 0.8, DBRD.TIERS[look.tier].pitch);
        var cands = src.slice().sort(function () { return Math.random() - 0.5; }).slice(0, 8).map(function (d) { return { id: d.itemId, count: rint(d.minCount, d.maxCount) }; });
        RPG.net.send(p, "dbrd_crate_roll", { tier: look.tier, metal: look.metal, item: stack ? { id: stack.id, count: stack.count } : null, zeni: zeni, candidates: cands });
        RPG.data.addScore("dbrd_crates", p, 1);
    }
    function rollDrop(list) {
        var pool = (list || []).filter(function (d) { return d && d.itemId; });
        while (pool.length) {
            var total = 0; pool.forEach(function (d) { total += Math.max(0, Number(d.chance) || 0); });
            var x = Math.random() * total, chosen = pool[pool.length - 1], acc = 0;
            if (total <= 0) chosen = pool[Math.floor(Math.random() * pool.length)];
            else for (var i = 0; i < pool.length; i++) { acc += Math.max(0, Number(pool[i].chance) || 0); if (x < acc) { chosen = pool[i]; break; } }
            var count = rint(chosen.minCount || 1, chosen.maxCount || 1);
            if (count > 0 && chosen.itemId) return { id: chosen.itemId, count: count, nbt: chosen.nbt || undefined };
            pool.splice(pool.indexOf(chosen), 1);
        }
        return null;
    }
    // the crates near players: spawn missing ones, swap a refreshed look, drop strays
    function sweepCrates(p, n, f, lay) {
        var dim = lay.dim, near = RPG.world.entitiesNear(dim, p.x, p.y, p.z, 56).filter(function (e) { return String(e.rpgId || "").indexOf("dbrd_crate_") === 0; });
        var want = {};
        (lay.crates || []).forEach(function (q) {
            if (dist2(p, q.x, q.y, q.z) > 48 * 48) return;
            var look = crateLook(n, f, q), id = CRATE_NPC[look.tier + "_" + look.metal];
            want[q.x + "," + q.y + "," + q.z] = id;
        });
        var seen = {};
        near.forEach(function (e) {
            var k = Math.floor(e.x) + "," + Math.round(e.y) + "," + Math.floor(e.z);
            if (want[k] === e.rpgId && !seen[k]) seen[k] = true;
            else if (dist2(p, e.x, e.y, e.z) <= 48 * 48) e.remove();
        });
        Object.keys(want).forEach(function (k) {
            if (seen[k]) return;
            var a = k.split(",").map(Number);
            RPG.world.spawnNpc(dim, want[k], a[0] + 0.5, a[1], a[2] + 0.5);
        });
    }

    // ---- spawners ----
    function skey(dim, x, y, z) { return dim + "|" + x + "|" + y + "|" + z; }
    function standalone() { return RPG.data.get("dbrd_spawners", {}) || {}; }
    var STATE = {};                                              // spawner key -> { alive: [uuid], boss: uuid, next: tick, idle: ticks }
    function presetFor(f, q) {
        var list = f.enemyPresets || [];
        if (!list.length) return { i: -1, cfg: f.enemies };
        var total = 0; list.forEach(function (p) { total += Math.max(1, p.weight | 0); });
        var x = DBRD.rng(DBRD.mix(q.x, q.y, q.z, 77))() * total, acc = 0;
        for (var i = 0; i < list.length; i++) { acc += Math.max(1, list[i].weight | 0); if (x < acc) return { i: i, cfg: list[i].config }; }
        return { i: list.length - 1, cfg: list[list.length - 1].config };
    }
    function spawnEntity(dim, id, x, y, z) {
        id = String(id || "minecraft:zombie");
        var bare = id.replace(/^ragnarok_rpg:/, "");
        if (RPG.mobs.exists(bare)) return RPG.world.spawnMob(dim, bare, x, y, z);
        if (id.indexOf(":") > 0) return RPG.world.spawn(dim, id, x, y, z);
        return RPG.world.spawn(dim, "minecraft:" + id, x, y, z);
    }
    function lowestLevel(dim, x, y, z, r) {
        var lv = null;
        RPG.server.players().forEach(function (p) { if (p.dimension === dim && dist2(p, x, y, z) <= r * r) lv = lv === null ? p.getLevel() : Math.min(lv, p.getLevel()); });
        return lv === null ? 1 : lv;
    }
    function playersNear(dim, x, y, z, r) { return RPG.server.players().filter(function (p) { return p.dimension === dim && p.isAlive() && dist2(p, x, y, z) <= r * r; }); }
    // spawns one configured mob; tag ties it back to its config for the kill rewards
    function spawnConfigured(dim, cfg, x, y, z, tag, asBoss, extraHealth) {
        var level = lowestLevel(dim, x, y, z, 32), ml = Math.max(2, cfg.scaleMaxLevel | 0), scale = cfg.levelScaling;
        var hp = asBoss ? cfg.bossHealth : (scale ? DBRD.lerp(cfg.maxHealth, DBRD.atMax(cfg, "maxHealth"), level, ml) : cfg.maxHealth);
        var dmg = asBoss ? cfg.bossDamage : (scale ? DBRD.lerp(cfg.attackDamage, DBRD.atMax(cfg, "attackDamage"), level, ml) : cfg.attackDamage);
        var def = scale ? DBRD.lerp(cfg.defense, DBRD.atMax(cfg, "defense"), level, ml) : cfg.defense;
        var e = spawnEntity(dim, asBoss ? cfg.bossEntityTypeId : cfg.entityTypeId, x + 0.5, y, z + 0.5);
        if (!e) return null;
        hp = Math.max(1, hp * (1 + (extraHealth || 0)));
        e.setMaxHealth(hp); e.health = hp;
        e.setAttributeBase("generic.attack_damage", Math.max(0, dmg));
        if (!asBoss && cfg.moveSpeed > 0) e.setAttributeBase("generic.movement_speed", cfg.moveSpeed);
        if (def > 0) e.setAttributeBase("generic.armor", Math.min(30, def));
        e.addTag("dbrd_mob"); e.addTag(tag + (asBoss ? "_b" : ""));
        var nm = asBoss ? cfg.bossName : cfg.displayName;
        if (nm) setName(e, nm);
        return e;
    }
    // ki moves (SpawnerConfig kiEnabled / ki damage range): a ki blast at the target now and then
    function kiAttack(e, cfg, boss) {
        var lo = boss ? cfg.bossKiDmgMin : cfg.kiDmgMin, hi = boss ? cfg.bossKiDmgMax : cfg.kiDmgMax;
        if (!cfg.kiEnabled || hi <= 0 || Math.random() > 0.2) return;
        var t = e.target;
        if (!t || !t.isAlive() || e.distanceTo(t) > 24) return;
        e.lookAt(t.x, t.y + 1.2, t.z);
        e.shoot("ki_blast", { damage: rint(lo, hi) });
    }
    function timeOk(dim, cond) {
        if (!cond) return true;
        var t = ((RPG.world.getTime(dim) % 24000) + 24000) % 24000;
        if (cond === 1) return t < 12000; if (cond === 2) return t >= 13000 && t < 23000;
        if (cond === 3) return t >= 22500 || t < 1500; if (cond === 4) return t >= 11500 && t < 13500;
        return true;
    }
    function alive(u) { var e = u ? RPG.world.entityByUuid(u) : null; return e && e.isAlive() ? e : null; }
    function tickSpawner(key, dim, q, cfg, tag, extraPer, now) {
        if (!cfg || !cfg.enabled) return;
        var s = STATE[key] || (STATE[key] = { alive: [], boss: null, next: 0, idle: 0 });
        var near = playersNear(dim, q.x, q.y, q.z, 16);
        s.alive = s.alive.filter(function (u) {
            var e = alive(u);
            if (e && cfg.wanderDistance > 0 && dist2(e, q.x, q.y, q.z) > cfg.wanderDistance * cfg.wanderDistance) e.moveTo(q.x + 0.5, q.y, q.z + 0.5, 0.35);
            if (e) kiAttack(e, cfg, false);
            return !!e;
        });
        if (s.boss && !alive(s.boss)) s.boss = null;
        if (!near.length) {
            s.idle += 20;
            if (s.idle > 1200) {                                  // nobody around for a minute: tidy up
                s.alive.forEach(function (u) { var e = alive(u); if (e) e.remove(); });
                if (s.boss) { var b = alive(s.boss); if (b) b.remove(); }
                delete STATE[key];
            }
            return;
        }
        s.idle = 0;
        if (now < s.next || !timeOk(dim, cfg.timeCondition)) return;
        s.next = now + Math.max(20, cfg.cooldownTicks | 0);
        var extra = extraPer * Math.max(0, near.length - 1);
        if (cfg.bossEnabled && !s.boss && Math.random() * 100 < cfg.bossChance) {
            var b2 = spawnConfigured(dim, cfg, q.x, q.y, q.z, tag, true, extra);
            if (b2) s.boss = String(b2.uuid);
        }
        var want = Math.max(0, (cfg.maxSpawns | 0) - s.alive.length);
        for (var i = 0; i < want; i++) {
            var ox = Math.floor(Math.random() * 3) - 1, oz = Math.floor(Math.random() * 3) - 1;
            var e2 = spawnConfigured(dim, cfg, q.x + ox, q.y, q.z + oz, tag, false, extra);
            if (e2) s.alive.push(String(e2.uuid));
        }
    }
    function configForTag(tags) {
        // dbrd_f<floor>_p<preset>[_b]  |  dbrd_s<hash>[_b]
        for (var i = 0; i < tags.length; i++) {
            var m = /^dbrd_f(\d+)_p(-?\d+)(_b)?$/.exec(tags[i]);
            if (m) {
                var f = CORE.floor(m[1] | 0);
                if (!f) return null;
                var cfg = (m[2] | 0) >= 0 && f.enemyPresets[m[2] | 0] ? f.enemyPresets[m[2] | 0].config : f.enemies;
                return { cfg: cfg, boss: !!m[3] };
            }
            var s = /^dbrd_s([0-9a-f]+)(_b)?$/.exec(tags[i]);
            if (s) {
                var all = standalone(), found = null;
                Object.keys(all).forEach(function (k) { if (DBRD.mix(k).toString(16) === s[1]) found = all[k]; });
                return found ? { cfg: DBRD.newSpawner(found.config), boss: !!s[2] } : null;
            }
        }
        return null;
    }
    function rollReward(cfg, killer, kind) {
        var ml = Math.max(2, cfg.scaleMaxLevel | 0), lv = killer.getLevel();
        var lo = cfg[kind + "Min"], hi = cfg[kind + "Max"];
        if (cfg.levelScaling) { lo = DBRD.lerp(lo, DBRD.atMax(cfg, kind + "Min"), lv, ml); hi = DBRD.lerp(hi, DBRD.atMax(cfg, kind + "Max"), lv, ml); }
        return Math.max(0, rint(lo, hi));
    }
    function payKill(p, victim, cfg) {
        giveTp(p, rollReward(cfg, p, "tp"));
        var z = rollReward(cfg, p, "bal");
        if (z > 0) p.addMoney(z);
        String(cfg.killCommands || "").split(";").forEach(function (c) {
            c = c.trim().replace(/%player%/g, p.name).replace(/^\//, "");
            if (c) { try { RPG.server.runCommand(c); } catch (e) { RPG.log("[dungeons] kill command failed: " + c); } }
        });
        (cfg.drops || []).forEach(function (d) {
            if (!d || !d.itemId || Math.random() * 100 >= (Number(d.chance) || 0)) return;
            var c = rint(d.minCount || 1, d.maxCount || 1);
            if (c > 0) RPG.world.dropItem(victim.dimension, victim.x, victim.y + 0.5, victim.z, d.itemId, c);
        });
    }
    RPG.on("kill", function (p, victim) {
        if (!victim || !victim.hasTag("dbrd_mob") || victim.hasTag("dbrd_guardian")) return;
        var tags = [];
        // the tag set of a script entity is not listable, so try the known shapes
        var n = CORE.floorAt(victim.dimension, victim.x), f = n ? CORE.floor(n) : null;
        if (f) {
            for (var i = -1; i < f.enemyPresets.length; i++) {
                if (victim.hasTag("dbrd_f" + n + "_p" + i)) tags.push("dbrd_f" + n + "_p" + i);
                if (victim.hasTag("dbrd_f" + n + "_p" + i + "_b")) tags.push("dbrd_f" + n + "_p" + i + "_b");
            }
        }
        Object.keys(standalone()).forEach(function (k) { var h = "dbrd_s" + DBRD.mix(k).toString(16); if (victim.hasTag(h)) tags.push(h); if (victim.hasTag(h + "_b")) tags.push(h + "_b"); });
        var found = configForTag(tags);
        if (found) payKill(p, victim, found.cfg);
    });

    // ---- guardians (BOSS floors) ----
    var GUARD = {};                                              // floor -> { uuid, damage: {uuid: n}, names: {}, started }
    function guardianBar(n) { return "dbrd_guard_" + n; }
    function tickGuardian(n, f, lay) {
        if (f.type !== "BOSS" || !f.bossEnabled || !lay.boss) return;
        var players = RPG.server.players().filter(function (p) { return p.dimension === lay.dim && CORE.floorAt(p.dimension, p.x) === n && p.isAlive(); });
        var g = GUARD[n];
        if (CORE.isBossDefeated(n)) { if (g) { var old = alive(g.uuid); if (old) old.remove(); delete GUARD[n]; RPG.ui.removeBossBar(guardianBar(n)); } return; }
        if (!players.length) {
            if (g) { g.idle = (g.idle || 0) + 1; if (g.idle > 120) { var e0 = alive(g.uuid); if (e0) e0.remove(); delete GUARD[n]; RPG.ui.removeBossBar(guardianBar(n)); } }
            return;
        }
        if (g) g.idle = 0;
        var e = g ? alive(g.uuid) : null;
        if (g && !e) {                                            // gone without a hit (despawned, /kill): it comes back
            var hits = 0; Object.keys(g.damage).forEach(function (u) { hits += g.damage[u]; });
            if (hits > 0) defeated(n, f, g); else { delete GUARD[n]; RPG.ui.removeBossBar(guardianBar(n)); }
            return;
        }
        if (!g) {
            var cfg = f.boss, extra = C.get("dbr.guardianHealthPerExtraPlayer") * Math.max(0, players.length - 1);
            var copy = DBRD.newSpawner(cfg);
            e = spawnConfigured(lay.dim, copy, lay.boss.x, lay.boss.y, lay.boss.z, "dbrd_f" + n + "_guard", false, extra);
            if (!e) return;
            e.addTag("dbrd_guardian");
            GUARD[n] = g = { uuid: String(e.uuid), damage: {}, names: {}, started: Date.now(), max: e.maxHealth };
            if (!cfg.displayName) setName(e, "&c" + (RPG.mobs.exists(cfg.entityTypeId) ? RPG.mobs.name(cfg.entityTypeId) : "Guardian"));
            players.forEach(function (p) { p.title("&cThe Guardian", "&7Floor " + n); });
        }
        RPG.ui.bossBar(guardianBar(n), { name: (e.name || "Guardian") + " §7- Floor " + n, color: "red", style: "10", progress: Math.max(0, Math.min(1, e.health / e.maxHealth)), players: players });
        if (e.target === null || !e.target) { var t = players[0]; e.target = t; }
        kiAttack(e, f.boss, false);
    }
    RPG.on("attack", function (e) {
        var t = e.target, a = e.attacker;
        if (!t || !a || !a.isPlayer() || !t.hasTag("dbrd_guardian")) return;
        Object.keys(GUARD).forEach(function (n) {
            var g = GUARD[n];
            if (g.uuid !== String(t.uuid)) return;
            var u = String(a.uuid);
            g.damage[u] = (g.damage[u] || 0) + Math.max(0, e.amount);
            g.names[u] = a.name;
        });
    });
    function defeated(n, f, g) {
        delete GUARD[n];
        RPG.ui.removeBossBar(guardianBar(n));
        CORE.markBossDefeated(n);
        var cfg = f.boss, total = 0, ids = Object.keys(g.damage);
        ids.forEach(function (u) { total += g.damage[u]; });
        var secs = Math.round((Date.now() - g.started) / 1000);
        ids.forEach(function (u) {
            var p = CORE.online(u);
            if (!p) return;
            var share = total > 0 ? g.damage[u] / total : 1 / ids.length;
            CORE.recordCleared(p, n);
            giveTp(p, Math.floor(rollReward(cfg, p, "tp") * share));
            var z = Math.floor(rollReward(cfg, p, "bal") * share);
            if (z > 0) p.addMoney(z);
            if (share >= 0.1 || ids.length === 1) (cfg.drops || []).forEach(function (d) {
                if (d && d.itemId && Math.random() * 100 < (Number(d.chance) || 0)) p.giveStack({ id: d.itemId, count: rint(d.minCount || 1, d.maxCount || 1) });
            });
            p.tell("&6[Dungeon] &eYou dealt &f" + Math.round(share * 100) + "% &eof the damage to floor " + n + "'s guardian.");
            RPG.data.addScore("dbrd_guardians", p, 1);
            var best = RPG.data.getScore("dbrd_fastest_" + n, p);
            if (!best || secs < best) RPG.data.setScore("dbrd_fastest_" + n, p, secs);
        });
        RPG.server.players().forEach(function (p) { if (CORE.floorAt(p.dimension, p.x) === n) { CORE.bar(p, "portal_boss_cleared"); p.playSound("minecraft:ui.toast.challenge_complete", 0.7, 1); } });
    }
    function resetGuardian(n) { var g = GUARD[n]; if (g) { var e = alive(g.uuid); if (e) e.remove(); } delete GUARD[n]; RPG.ui.removeBossBar(guardianBar(n)); }

    // ---- the per-second loop ----
    RPG.every(20, function () {
        var now = RPG.server.getTick(), seenFloor = {};
        RPG.server.players().forEach(function (p) {
            if (DBRD.isDungeonDim(p.dimension)) {
                var n = CORE.floorAt(p.dimension, p.x), f = n ? CORE.floor(n) : null, lay = n ? CORE.layoutOf(n) : null;
                if (!f || !lay || !lay.placed) return;
                if (!seenFloor[n]) { seenFloor[n] = true; tickGuardian(n, f, lay); }
                if (now % 100 < 20) sweepCrates(p, n, f, lay);
                if (f.enemiesEnabled) (lay.spawners || []).forEach(function (q, i) {
                    if (dist2(p, q.x, q.y, q.z) > 24 * 24) return;
                    var pr = presetFor(f, q);
                    tickSpawner("f" + n + "_" + i, lay.dim, q, pr.cfg, "dbrd_f" + n + "_p" + pr.i, C.get("dbr.enemyHealthPerExtraPlayer"), now);
                });
            }
        });
        // spawners away from players still tidy up; standalone spawners near players run
        var all = standalone();
        Object.keys(all).forEach(function (k) {
            var s = all[k];
            if (!playersNear(s.dim, s.x, s.y, s.z, 24).length && !STATE[k]) return;
            tickSpawner(k, s.dim, { x: s.x, y: s.y + 1, z: s.z }, DBRD.newSpawner(s.config), "dbrd_s" + DBRD.mix(k).toString(16), 0, now);
        });
        Object.keys(STATE).forEach(function (k) {
            if (k.charAt(0) !== "f") return;
            var m = /^f(\d+)_(\d+)$/.exec(k), lay = m ? CORE.layoutOf(m[1] | 0) : null, q = lay && lay.spawners ? lay.spawners[m[2] | 0] : null;
            if (!q || !playersNear(lay.dim, q.x, q.y, q.z, 24).length) {
                var s = STATE[k]; s.idle = (s.idle || 0) + 20;
                if (s.idle > 1200 || !q) { s.alive.forEach(function (u) { var e = alive(u); if (e) e.remove(); }); if (s.boss) { var b = alive(s.boss); if (b) b.remove(); } delete STATE[k]; }
            }
        });
        // portal shimmer near players
        if (now % 40 < 20) {
            var portals = RPG.data.get("dbrd_portals", {}) || {};
            Object.keys(portals).forEach(function (k) {
                var a = k.split("|"), dim = a[0], x = Number(a[1]), y = Number(a[2]), z = Number(a[3]);
                if (!playersNear(dim, x, y, z, 24).length) return;
                RPG.world.particle(dim, "minecraft:portal", x + 0.5, y + 1.2, z + 0.5, 12, 0.3, 0.4);
            });
        }
    });

    // ---- the spawner editor (AdvancedSpawnerScreen) for placed spawner blocks ----
    function openSpawner(p, dim, x, y, z) {
        if (!CORE.canEdit(p)) { CORE.bar(p, "no_permission"); return; }
        var all = standalone(), k = skey(dim, x, y, z);
        if (!all[k]) { all[k] = { dim: dim, x: x, y: y, z: z, config: DBRD.newSpawner() }; RPG.data.set("dbrd_spawners", all); }
        RPG.net.send(p, "dbrd_spawner", { key: k, config: DBRD.newSpawner(all[k].config), title: "Advanced NPC Spawner" });
    }
    RPG.net.on("dbrd_spawner_save", function (p, d) {
        if (!CORE.canEdit(p) || !d || !d.key) return;
        var all = standalone();
        if (!all[d.key]) return;
        all[d.key].config = DBRD.newSpawner(d.config);
        RPG.data.set("dbrd_spawners", all);
        var s = all[d.key], cfg = all[d.key].config;
        RPG.world.setBlock(s.dim, s.x, s.y, s.z, cfg.disguise ? cfg.disguise : "ragnarok_rpg:" + SPAWNER_ID);
        CORE.tell(p, "&aSpawner saved.");
    });
    function highlight(p, r) {
        var all = standalone(), found = [];
        Object.keys(all).forEach(function (k) {
            var s = all[k];
            if (s.dim === p.dimension && s.config && s.config.disguise && dist2(p, s.x, s.y, s.z) <= r * r) found.push(s);
        });
        var n = 0, id = RPG.every(10, function () {
            if (++n > 20) { RPG.cancel(id); return; }
            found.forEach(function (s) { RPG.world.particleLine(s.dim, "minecraft:end_rod", s.x + 0.5, s.y, s.z + 0.5, s.x + 0.5, s.y + 3, s.z + 0.5, 0.3); });
        });
        return found.length;
    }
    // a disguised spawner block can still be opened: right-click it with a stick
    RPG.on("blockInteract", function (p, block, x, y, z, dim) {
        var s = standalone()[skey(dim, x, y, z)];
        if (!s || !s.config || !s.config.disguise || !CORE.canEdit(p)) return;
        var held = p.getHeldItem ? String(p.getHeldItem()) : "";
        if (held.indexOf("stick") >= 0) { openSpawner(p, dim, x, y, z); return false; }
    });

    // ---- hooks for the core ----
    function floorEntered(n, group) {
        var f = CORE.floor(n);
        group.forEach(function (p) {
            var deepest = RPG.data.getScore("dbrd_deepest", p);
            if (n > deepest) RPG.data.setScore("dbrd_deepest", p, n);
            if (f && f.type === "BOSS" && f.bossEnabled && !CORE.isBossDefeated(n)) p.tell("&c[Dungeon] &7This floor's guardian blocks the way down. Defeat it to open the portal.");
        });
    }
    function forgetFloor(n) {
        Object.keys(STATE).forEach(function (k) { if (k.indexOf("f" + n + "_") === 0) { STATE[k].alive.forEach(function (u) { var e = alive(u); if (e) e.remove(); }); delete STATE[k]; } });
        resetGuardian(n);
        RPG.data.remove("dbrd_copen_" + n);
    }
    function respawnFloor(n) {
        var lay = CORE.layoutOf(n);
        if (!lay) return CORE.msg("floor_respawn_not_built", n);
        if (!lay.spawners || !lay.spawners.length) return CORE.msg("floor_respawn_no_markers", n);
        var removed = 0;
        Object.keys(STATE).forEach(function (k) { if (k.indexOf("f" + n + "_") === 0) { STATE[k].alive.forEach(function (u) { var e = alive(u); if (e) { e.remove(); removed++; } }); delete STATE[k]; } });
        return CORE.msg("floor_respawn_done", n, lay.spawners.length, removed, 0, lay.spawners.length);
    }
    function boards(p) {
        return { deepest: RPG.data.getScore("dbrd_deepest", p), guardians: RPG.data.getScore("dbrd_guardians", p), crates: RPG.data.getScore("dbrd_crates", p),
            top: RPG.data.top("dbrd_deepest", 5).map(function (e) { return [e.name, e.score]; }) };
    }
    function showTop(p) {
        if (!p) return;
        p.tell("&6=== Dungeon leaderboards ===");
        [["dbrd_deepest", "Deepest floor", false], ["dbrd_guardians", "Guardians beaten", false], ["dbrd_crates", "Crates opened", false]].forEach(function (b) {
            p.tell("&e" + b[1] + ": &7" + RPG.data.top(b[0], 5, b[2]).map(function (e) { return e.rank + ". " + e.name + " (" + e.score + ")"; }).join("  "));
        });
        for (var n = 1; n <= CORE.count(); n++) {
            var f = CORE.floor(n);
            if (f.type !== "BOSS") continue;
            var t = RPG.data.top("dbrd_fastest_" + n, 3, true);
            if (t.length) p.tell("&eFastest floor " + n + " guardian: &7" + t.map(function (e) { return e.rank + ". " + e.name + " " + CORE.human(e.score); }).join("  "));
        }
    }

    return { portalBlock: portalBlock, gemStack: gemStack, ticketStack: ticketStack, floorEntered: floorEntered, forgetFloor: forgetFloor,
        respawnFloor: respawnFloor, resetGuardian: resetGuardian, highlight: highlight, boards: boards, showTop: showTop };
})();
