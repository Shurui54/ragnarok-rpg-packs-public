// =====================================================================================
//  90_dbr_dungeons.js - DMZ Ragnarok's Dungeons: floors, rules, entering, timers, commands
// =====================================================================================
//  Port of DMZ Ragnarok's shuruis_dmz_dungeons module (GPL-3.0, by Shurui):
//   - Config (shuruis_dmz_dungeons-common.toml): the same twelve options, names and defaults, in
//     ragnarok_rpg/config/dbr_dungeons.json (/rpg config dbr_dungeons). Like DMZR they SEED the
//     world's rules and floor list the first time; after that the in-game editor (/dungeon edit)
//     is authoritative (DungeonRules / DungeonFloors SavedData -> RPG.data here).
//   - DungeonRules: PvP, ki block destruction, hand block editing, time limit, re-entry cooldown.
//   - DungeonTimeEvents: the run timer (boss bar "Dungeon time left"), the resume window (a quick
//     step out and back in continues the run), the eject to spawn on time-out and the cooldown,
//     with its one-shot "cooldown is over" notice. Ops / the dbr.dungeons.bypass_timelimit node skip it.
//   - DungeonFloors: numbered floors, each a theme (its own dimension), a size, a depth, a layout
//     style, NORMAL or BOSS, crate loot, enemy presets, a guardian, ticket gate and rotation flag.
//     Floor N sits at x = N * 100000 in its theme's dimension (z = relocation epoch * 100000).
//   - Progression (UtilitiesPortalCompat): to enter floor N every in-rotation BOSS floor below it must
//     be cleared, by this world's flag or the player's own clear record; a ticket-gated floor needs
//     its floor ticket redeemed first; boss-lock portals stay shut while the guardian lives.
//   - DungeonWarps, /rg dungeon tp|setwarp|warp|delwarp|warps|highlight|paste|edit, floor admin.
//  DMZR entered floors through Shurui's Utilities portals; DBR has none, so this adds dungeon portal
//  blocks (a floor's descent/exit portals are placed by the generator, staff place more with
//  /dungeon portal), the Dungeon Gate (DMZR's overworld_portal structure) and the Gatekeeper NPC.
//  Parties (78_dmz_party.js): party members near the leader enter together; guardians scale.
//  Generation: 90_dbr_dungeons_gen.js. Crates, spawners, guardians, items: 90_dbr_dungeons_loot.js.
// =====================================================================================
var DBRD_CFG = RPG.config.define("dbr_dungeons", {
    requireOpToEdit: { default: true, comment: "Require permission level 2 (op) or creative mode to open the spawner admin GUI and run privileged /dungeon subcommands." },
    maxHighlightRadius: { default: 128, min: 1, max: 512, integer: true, comment: "Maximum radius (blocks) allowed for /dungeon highlight." },
    dungeonPvp: { default: false, comment: "Allow players to damage each other inside the dungeon dimension." },
    dungeonKiBlockDestruction: { default: false, comment: "Allow DMZ ki attacks to break blocks inside the dungeon dimension." },
    dungeonBlockEditing: { default: false, comment: "Allow ORDINARY players to break and place blocks by hand inside the dungeon dimensions. Creative mode is never restricted." },
    dungeonTimeLimitSeconds: { default: 1800, min: 0, max: 86400, integer: true, comment: "How long a non-bypass player may stay in the dungeon dimension, in seconds. 0 disables the time limit." },
    dungeonCooldownSeconds: { default: 600, min: 0, max: 86400, integer: true, comment: "Cooldown (seconds) after a player is timed out of the dungeon before they may re-enter. 0 disables the cooldown." },
    dungeonFloorCount: { default: 5, min: 0, max: 256, integer: true, comment: "Number of procedural dungeon floors seeded into a fresh world. 0 seeds none." },
    dungeonFloorSize: { default: 250, min: 64, max: 1120, integer: true, comment: "Default side length (blocks) of a seeded floor's terrain disc." },
    dungeonFloorDepth: { default: 96, min: 16, max: 124, integer: true, comment: "Default depth (blocks) a seeded floor's solid body extends below its surface." },
    dungeonRoomBlocksPerTick: { default: 40000, min: 1024, max: 500000, integer: true, comment: "Per-tick block-write budget for the room-placement layer. Higher builds a floor faster but costs more per server tick." },
    dungeonDefaultLayoutStyle: { default: "VARIED", options: ["VARIED", "SPINE_AND_RIBS", "ROADS_AND_BUILDINGS", "INSUFFERABLE_CRYPT"],
        comment: "Default room-layout algorithm for floors that do not set their own. VARIED rolls a different archetype per floor." },
    dbr: {
        partyEntry: { default: true, comment: "DBR: party members within partyRange of a player entering a floor come along (each passes the gates on their own)." },
        partyRange: { default: 32, min: 0, max: 256, integer: true, comment: "DBR: how close (blocks) a party member must be to come along." },
        guardianHealthPerExtraPlayer: { default: 0.5, min: 0, max: 10, comment: "DBR: a floor guardian gets this much extra max health per extra player on the floor when it spawns (0.5 = +50%)." },
        enemyHealthPerExtraPlayer: { default: 0.25, min: 0, max: 10, comment: "DBR: floor enemies get this much extra max health per extra player near them when they spawn." },
        autoPortals: { default: true, comment: "DBR: generated floors get a return portal in the spawn room and a descent portal in the exit room." }
    }
});

var DBRD_CORE = (function () {
    var C = DBRD_CFG;
    var LANG = RPG.files.read("dbr_dungeons/lang_en_us.json") || {};

    // ---- text ----
    function msg(key) {
        var s = LANG[key] || LANG["message." + key] || key, args = Array.prototype.slice.call(arguments, 1), i = 0;
        s = s.replace(/%(\d+)\$s/g, function (m, n) { var v = args[Number(n) - 1]; return v === undefined ? "" : String(v); });
        return s.replace(/%s/g, function () { var v = args[i++]; return v === undefined ? "" : String(v); }).replace(/%%/g, "%");
    }
    function tell(p, key) { if (p) p.tell(msg.apply(null, Array.prototype.slice.call(arguments, 1))); }
    function bar(p, key) { if (p) p.actionbar(msg.apply(null, Array.prototype.slice.call(arguments, 1))); }
    function uid(p) { return String(p.uuid); }
    function online(u) { var l = RPG.server.players(); for (var i = 0; i < l.length; i++) if (String(l[i].uuid) === u) return l[i]; return null; }
    function human(secs) {
        secs = Math.max(0, Math.round(secs));
        var h = Math.floor(secs / 3600), m = Math.floor(secs % 3600 / 60), s = secs % 60, out = [];
        if (h) out.push(h + "h"); if (m) out.push(m + "m"); if (s || !out.length) out.push(s + "s");
        return out.join(" ");
    }
    function clock(secs) { var m = Math.floor(secs / 60), s = secs % 60; return m + ":" + (s < 10 ? "0" : "") + s; }

    // ---- permissions (Config.canEdit, DungeonTimeEvents.canBypass) ----
    function canEdit(p) { return !!p && (!C.get("requireOpToEdit") || p.isOp() || p.getGameMode() === "creative"); }
    function canBypass(p) { return !!p && (p.isOp() || (RPG.perms && RPG.perms.has(p, "dbr.dungeons.bypass_timelimit"))); }

    // ---- saved state ----
    var RULES = null, FLOORS = null;
    function rules() {
        if (!RULES) {
            RULES = RPG.data.get("dbrd_rules", null);
            if (!RULES) {                                         // seeded from the config once, then authoritative
                RULES = { pvp: C.get("dungeonPvp"), kiBlockDestruction: C.get("dungeonKiBlockDestruction"), blockEditing: C.get("dungeonBlockEditing"),
                    timeLimitSeconds: C.get("dungeonTimeLimitSeconds"), cooldownSeconds: C.get("dungeonCooldownSeconds") };
                RPG.data.set("dbrd_rules", RULES);
            }
        }
        return RULES;
    }
    function applyRules(r) {
        var cur = rules();
        cur.pvp = !!r.pvp; cur.kiBlockDestruction = !!r.kiBlockDestruction; cur.blockEditing = !!r.blockEditing;
        cur.timeLimitSeconds = Math.max(0, Math.min(86400, Math.floor(Number(r.timeLimitSeconds) || 0)));
        cur.cooldownSeconds = Math.max(0, Math.min(86400, Math.floor(Number(r.cooldownSeconds) || 0)));
        RPG.data.set("dbrd_rules", cur);
    }
    // stored in pieces (RPG.data values are capped at 256 KB): dbrd_floors = the flags, dbrd_floor_<n> = a
    // floor's config, dbrd_layout_<n> = its built layout (spawn, exit, spawner runes, crates)
    function floors() {
        if (!FLOORS) {
            var meta = RPG.data.get("dbrd_floors", null);
            if (!meta) {
                FLOORS = { list: [], generated: {}, bossDefeated: {}, epochs: {}, layouts: {} };
                for (var i = 1; i <= C.get("dungeonFloorCount"); i++) FLOORS.list.push(DBRD.newFloor(i, C.get("dungeonFloorSize"), C.get("dungeonFloorDepth")));
                saveFloors();
            } else {
                FLOORS = { list: [], generated: meta.generated || {}, bossDefeated: meta.bossDefeated || {}, epochs: meta.epochs || {}, layouts: {} };
                for (var k = 1; k <= (meta.count | 0); k++) FLOORS.list.push(DBRD.normalizeFloor(RPG.data.get("dbrd_floor_" + k, null), k, C.get("dungeonFloorSize"), C.get("dungeonFloorDepth")));
            }
        }
        return FLOORS;
    }
    var SAVED_COUNT = -1;
    function saveFloors() {
        if (!FLOORS) return;
        var n = FLOORS.list.length;
        if (SAVED_COUNT < 0) SAVED_COUNT = (RPG.data.get("dbrd_floors", { count: 0 }) || { count: 0 }).count | 0;
        RPG.data.set("dbrd_floors", { count: n, generated: FLOORS.generated, bossDefeated: FLOORS.bossDefeated, epochs: FLOORS.epochs });
        FLOORS.list.forEach(function (f, i) { RPG.data.set("dbrd_floor_" + (i + 1), f); });
        for (var k = n + 1; k <= SAVED_COUNT; k++) RPG.data.remove("dbrd_floor_" + k);
        SAVED_COUNT = n;
    }
    function setLayout(n, lay) { floors().layouts[n] = lay; RPG.data.set("dbrd_layout_" + n, lay); }
    function dropLayout(n) { delete floors().layouts[n]; RPG.data.remove("dbrd_layout_" + n); }
    function count() { return floors().list.length; }
    function isValid(n) { return n >= 1 && n <= count(); }
    function floor(n) { return isValid(n) ? floors().list[n - 1] : null; }
    function epochOf(n) { return floors().epochs[n] | 0; }
    function layoutOf(n) {
        var F = floors();
        if (F.layouts[n] === undefined) F.layouts[n] = F.generated[n] ? RPG.data.get("dbrd_layout_" + n, null) : null;
        return F.layouts[n];
    }
    function isBossDefeated(n) { return !!floors().bossDefeated[n]; }
    function setCount(n) {
        var F = floors();
        n = Math.max(0, Math.min(256, n | 0));
        while (F.list.length < n) F.list.push(DBRD.newFloor(F.list.length + 1, C.get("dungeonFloorSize"), C.get("dungeonFloorDepth")));
        if (F.list.length > n) F.list.length = n;
        saveFloors();
    }
    // a retyped floor (theme, type or style changed) moves to fresh ground: DungeonFloors.relocateFloor
    function relocate(n) {
        var F = floors();
        F.epochs[n] = Math.min(299, (F.epochs[n] | 0) + 1);
        dropLayout(n); delete F.generated[n];
        if (typeof DBRD_LOOT !== "undefined") DBRD_LOOT.forgetFloor(n);
        saveFloors();
    }
    function clearGenerated(n) {                                  // Regen: re-stamp on the next visit, same place
        var F = floors();
        dropLayout(n); delete F.generated[n];
        if (typeof DBRD_LOOT !== "undefined") DBRD_LOOT.forgetFloor(n);
        saveFloors();
    }
    function styleFor(n, f) {
        if (f.layoutStyle) return f.layoutStyle;
        var d = C.get("dungeonDefaultLayoutStyle");
        if (d !== "VARIED") return d;
        return DBRD.STYLE_NAMES[DBRD.floorSeed(n) % DBRD.STYLE_NAMES.length];
    }
    // the floor a position in a dungeon dimension belongs to (DungeonFloorLayout.floorNumberForX)
    function floorAt(dim, x) {
        if (!DBRD.isDungeonDim(dim)) return 0;
        var n = DBRD.floorForX(x);
        return isValid(n) ? n : 0;
    }
    function markBossDefeated(n) { floors().bossDefeated[n] = true; saveFloors(); }
    function clearBossDefeated(n) { var had = !!floors().bossDefeated[n]; delete floors().bossDefeated[n]; saveFloors(); return had; }

    // editor save (DungeonFloors.applyConfigsFromEditor): a theme / type / style change relocates the floor
    function applyFloorsFromEditor(list) {
        var F = floors(), old = F.list;
        var next = (list || []).slice(0, 256).map(function (f, i) { return DBRD.normalizeFloor(f, i + 1, C.get("dungeonFloorSize"), C.get("dungeonFloorDepth")); });
        next.forEach(function (f, i) {
            var o = old[i];
            if (o && (o.theme !== f.theme || o.type !== f.type || o.layoutStyle !== f.layoutStyle)) {
                F.epochs[i + 1] = Math.min(299, (F.epochs[i + 1] | 0) + (F.generated[i + 1] ? 1 : 0));
                dropLayout(i + 1); delete F.generated[i + 1];
                if (typeof DBRD_LOOT !== "undefined") DBRD_LOOT.forgetFloor(i + 1);
            }
        });
        for (var k = next.length + 1; k <= old.length; k++) { dropLayout(k); delete F.generated[k]; }
        F.list = next;
        saveFloors();
    }

    // ---- personal records (DungeonBossUnlocks, DungeonTicketUnlocks) ----
    function bossClears(p) { var v = p.getVar("dbrd_boss_clears", []); return Array.isArray(v) ? v : []; }
    function hasCleared(p, n) { return bossClears(p).indexOf(n) >= 0; }
    function recordCleared(p, n) { var v = bossClears(p); if (v.indexOf(n) < 0) { v.push(n); p.setVar("dbrd_boss_clears", v); } }
    function tickets(p) { var v = p.getVar("dbrd_tickets", []); return Array.isArray(v) ? v : []; }
    function hasTicket(p, n) { return tickets(p).indexOf(n) >= 0; }
    function unlockTicket(p, n) { var v = tickets(p); if (v.indexOf(n) >= 0) return false; v.push(n); p.setVar("dbrd_tickets", v); return true; }

    // the lowest in-rotation BOSS floor below n not yet cleared (for this player), or -1
    function firstUnclearedBossBefore(p, n) {
        for (var i = 1; i < n; i++) {
            var f = floor(i);
            if (f && f.type === "BOSS" && f.inRotation && !isBossDefeated(i) && !hasCleared(p, i)) return i;
        }
        return -1;
    }
    function recordBossClearsBelow(p, n) {
        for (var i = 1; i < n; i++) { var f = floor(i); if (f && f.type === "BOSS" && f.inRotation) recordCleared(p, i); }
    }

    // ---- cooldowns (DungeonCooldowns) ----
    function cooldowns() { return RPG.data.get("dbrd_cooldowns", {}) || {}; }
    function onCooldown(p) { var e = cooldowns()[uid(p)] || 0; return e > Date.now(); }
    function remaining(p) { return Math.max(0, Math.ceil(((cooldowns()[uid(p)] || 0) - Date.now()) / 1000)); }
    function stampCooldown(p) {
        var secs = rules().cooldownSeconds;
        if (secs <= 0) return;
        var all = cooldowns(); all[uid(p)] = Date.now() + secs * 1000;
        for (var k in all) if (all[k] < Date.now()) delete all[k];
        RPG.data.set("dbrd_cooldowns", all);
        p.setVar("dbrd_cd_notify", true);
    }

    // ---- entering a floor (DungeonFloorManager.teleportToFloor + the portal gates) ----
    function gateCheck(p, n, opts) {
        opts = opts || {};
        if (!isValid(n)) { tell(p, "&cThere is no floor " + n + "."); return false; }
        if (canBypass(p)) return true;
        if (onCooldown(p) && !DBRD.isDungeonDim(p.dimension)) { bar(p, "cooldown_portal", human(remaining(p))); return false; }
        var f = floor(n);
        if ((f.requireTicket || opts.requireTicket) && !hasTicket(p, n)) { bar(p, "portal_ticket_locked", n); return false; }
        var locked = firstUnclearedBossBefore(p, n);
        if (locked > 0) { bar(p, "portal_floor_locked", locked); return false; }
        return true;
    }
    var BUILDING = {};                                            // floor -> [callbacks waiting for its build
    var LAST_ROUTE = {};
    function enterFloor(p, n, opts) {
        opts = opts || {};
        var now = RPG.server.getTick();
        if (LAST_ROUTE[uid(p)] && now - LAST_ROUTE[uid(p)] < 40 && now >= LAST_ROUTE[uid(p)]) return false;
        if (!gateCheck(p, n, opts)) return false;
        LAST_ROUTE[uid(p)] = now;
        if (!canBypass(p)) recordBossClearsBelow(p, n);
        var group = [p];
        if (opts.party !== false && C.get("dbr.partyEntry") && typeof DMZ_PARTY !== "undefined") {
            var r = C.get("dbr.partyRange");
            DMZ_PARTY.members(p).forEach(function (m) {
                if (uid(m) === uid(p) || m.dimension !== p.dimension || m.distanceTo(p) > r) return;
                if (floorAt(m.dimension, m.x) === n) return;
                if (gateCheck(m, n, opts)) { group.push(m); if (!canBypass(m)) recordBossClearsBelow(m, n); }
            });
        }
        ensureBuilt(n, function (ok, lay) {
            if (!ok || !lay) { group.forEach(function (m) { tell(m, "&c" + msg("portal_floor_failed", n)); }); return; }
            group.forEach(function (m, i) {
                if (!m.isAlive()) return;
                if (!DBRD.isDungeonDim(m.dimension)) m.setVar("dbrd_return", { dim: m.dimension, x: m.x, y: m.y, z: m.z });
                var s = lay.spawn, ox = (i % 3) - 1, oz = Math.floor(i / 3) % 3 - 1;
                m.teleportTo(lay.dim, s.x + 0.5 + ox * 0.6, s.y, s.z + 0.5 + oz * 0.6, s.yaw || 0, 0);
                m.title("&6" + floorTitle(n), "&7" + themeLabel(floor(n).theme));
                RPG.world.sound(lay.dim, "minecraft:block.portal.travel", s.x, s.y, s.z, 0.3, 1.4);
            });
            if (typeof DBRD_LOOT !== "undefined") DBRD_LOOT.floorEntered(n, group);
        }, p);
        return true;
    }
    function floorTitle(n) { var f = floor(n); return "Floor " + n + (f && f.type === "BOSS" ? " - Guardian" : ""); }
    function themeLabel(t) {
        var k = "gui.opt.theme." + String(t).toLowerCase();
        return LANG[k] || DBRD_TITLE(t);
    }
    function DBRD_TITLE(s) { s = String(s).toLowerCase(); return s.charAt(0).toUpperCase() + s.substring(1); }

    // builds the floor on first visit (rolls + places once, then never re-rolls), then calls back
    function ensureBuilt(n, cb, who) {
        var F = floors(), lay = layoutOf(n);
        if (lay && lay.placed) { cb(true, lay); return; }
        if (BUILDING[n]) { BUILDING[n].push(cb); if (who) { who.actionbar("&bBuilding dungeon floor " + n + "..."); who.setVar("dbrd_waiting", n); } return; }
        BUILDING[n] = [cb];
        var f = floor(n), style = styleFor(n, f);
        if (who) who.actionbar("&bBuilding dungeon floor " + n + "...");
        try {
            DBRD_GEN.build(n, f, style, epochOf(n), function (progress) {
                RPG.server.players().forEach(function (pl) {
                    if ((BUILDING[n] || []).length && pl.getVar("dbrd_waiting", 0) === n) pl.actionbar("&bBuilding dungeon floor " + n + "... &f" + Math.floor(progress * 100) + "%");
                });
            }, function (result) {
                var waiting = BUILDING[n] || [];
                delete BUILDING[n];
                if (result) {
                    result.placed = true;
                    F.generated[n] = true; setLayout(n, result);
                    saveFloors();
                }
                waiting.forEach(function (w) { try { w(!!result, result); } catch (e) { RPG.log("[dungeons] " + e); } });
            });
            if (who) who.setVar("dbrd_waiting", n);
        } catch (e) {
            RPG.log("[dungeons] floor " + n + " failed to start: " + e);
            var w = BUILDING[n] || []; delete BUILDING[n];
            w.forEach(function (x) { x(false, null); });
        }
    }
    function isBuilding(n) { return !!BUILDING[n]; }

    // ---- leaving ----
    function sendToSpawn(p) {
        var s = RPG.world.spawnPoint();
        p.teleportTo("minecraft:overworld", s.x + 0.5, s.y, s.z + 0.5);
    }
    function leave(p) {
        var r = p.getVar("dbrd_return", null);
        if (r && r.dim && !DBRD.isDungeonDim(r.dim)) p.teleportTo(r.dim, r.x, r.y, r.z); else sendToSpawn(p);
    }

    // ---- the run timer (DungeonTimeEvents) ----
    var LAST_DIM = {};
    function resumeWindowMs() { var r = rules(); var s = Math.max(r.timeLimitSeconds, r.cooldownSeconds); return s <= 0 ? 0 : s * 1000; }
    function barId(p) { return "dbrd_time_" + uid(p).substring(0, 8); }
    function removeBar(p) { try { RPG.ui.removeBossBar(barId(p)); } catch (e) { } }
    function onDimChange(p, from, to) {
        var fromD = DBRD.isDungeonDim(from), toD = DBRD.isDungeonDim(to);
        if (fromD && !toD) { removeBar(p); p.setVar("dbrd_left_at", Date.now()); }
        if (!toD || fromD) return;
        if (canBypass(p)) return;
        if (onCooldown(p)) {                                      // backstop for entries that skipped the gate
            bar(p, "cooldown_entry", human(remaining(p)));
            RPG.schedule(1, function () { sendToSpawn(p); });
            return;
        }
        var ticks = p.getVar("dbrd_ticks", 0) | 0, leftAt = Number(p.getVar("dbrd_left_at", 0)) || 0, since = Date.now() - leftAt;
        if (ticks > 0 && leftAt > 0 && since >= 0 && resumeWindowMs() > 0 && since <= resumeWindowMs()) { bar(p, "run_resumed"); return; }
        p.setVar("dbrd_ticks", 0); p.setVar("dbrd_left_at", 0);
    }
    RPG.on("playerTick", function (p) {
        var dim = p.dimension, u = uid(p), last = LAST_DIM[u];
        if (last !== undefined && last !== dim) onDimChange(p, last, dim);
        if (last === undefined && DBRD.isDungeonDim(dim) && !canBypass(p) && onCooldown(p)) { bar(p, "cooldown_entry", human(remaining(p))); sendToSpawn(p); }
        LAST_DIM[u] = dim;
        // the "cooldown is over" notice, once
        if (p.getVar("dbrd_cd_notify", false) && !onCooldown(p)) { p.setVar("dbrd_cd_notify", false); bar(p, "cooldown_ready"); }
        if (!DBRD.isDungeonDim(dim)) return;
        var limit = rules().timeLimitSeconds;
        if (canBypass(p) || limit <= 0 || !p.isAlive()) { removeBar(p); return; }
        var total = limit * 20, ticks = (p.getVar("dbrd_ticks", 0) | 0) + 20;
        if (ticks < total) {
            p.setVar("dbrd_ticks", ticks);
            var left = Math.ceil((total - ticks) / 20);
            RPG.ui.bossBar(barId(p), { name: msg("bossbar.time", clock(left)), color: "blue", progress: Math.max(0, Math.min(1, (total - ticks) / total)), players: [p] });
            return;
        }
        p.setVar("dbrd_ticks", 0); p.setVar("dbrd_left_at", 0);
        removeBar(p);
        stampCooldown(p);
        sendToSpawn(p);
        bar(p, "time_up");
    });
    RPG.on("playerLeave", function (p) {
        removeBar(p);
        if (DBRD.isDungeonDim(p.dimension) && (p.getVar("dbrd_ticks", 0) | 0) > 0) p.setVar("dbrd_left_at", Date.now());
        delete LAST_DIM[uid(p)];
    });
    RPG.on("death", function (p) { removeBar(p); });

    // ---- rules (DungeonRuleEvents, MixinDmzKiGriefDungeon) ----
    RPG.on("attack", function (e) {
        var a = e.attacker, t = e.target;
        if (!a || !t || !a.isPlayer() || !t.isPlayer() || rules().pvp) return;
        if (DBRD.isDungeonDim(t.dimension)) e.cancel();
    });
    function editDenied(p, dim) { return DBRD.isDungeonDim(dim) && !rules().blockEditing && p && p.getGameMode() !== "creative"; }
    RPG.on("blockBreak", function (p, block, x, y, z, dim) { if (editDenied(p, dim)) return false; });
    RPG.on("blockPlace", function (p, block, x, y, z, dim) { if (editDenied(p, dim)) return false; });
    RPG.on("explode", function (e) { if (DBRD.isDungeonDim(e.dimension) && !rules().kiBlockDestruction) e.cancelBlocks(); });

    // ---- warps (DungeonWarps) ----
    function warps() { return RPG.data.get("dbrd_warps", {}) || {}; }

    // ---- dungeon portals: a portal block, what it leads to stored by position ----
    function portalKey(dim, x, y, z) { return dim + "|" + x + "|" + y + "|" + z; }
    function portals() { return RPG.data.get("dbrd_portals", {}) || {}; }
    function setPortal(dim, x, y, z, spec) { var all = portals(); if (spec) all[portalKey(dim, x, y, z)] = spec; else delete all[portalKey(dim, x, y, z)]; RPG.data.set("dbrd_portals", all); }
    function portalAt(dim, x, y, z) { return portals()[portalKey(dim, x, y, z)] || null; }
    var PORTAL_COOL = {};
    function usePortal(entity, x, y, z) {
        var p = entity && entity.isPlayer() ? entity.asPlayer() : null;
        if (!p) return;
        var u = uid(p), now = RPG.server.getTick();
        if (PORTAL_COOL[u] && now - PORTAL_COOL[u] < 30 && now >= PORTAL_COOL[u]) return;
        PORTAL_COOL[u] = now;
        var spec = portalAt(p.dimension, x, y, z);
        if (!spec) { spec = { kind: DBRD.isDungeonDim(p.dimension) ? "next" : "gate" }; }
        var here = floorAt(p.dimension, x);
        // BOSS PORTAL: shut while the guardian of the floor it sits in lives (or the player's own clear)
        if (spec.bosslock || (spec.kind === "next" && here && floor(here).type === "BOSS")) {
            var f = here ? floor(here) : null;
            if (f && f.type === "BOSS" && f.inRotation && f.bossEnabled && !isBossDefeated(here) && !hasCleared(p, here) && !canBypass(p)) {
                bar(p, "portal_boss_locked"); p.push((p.x - x - 0.5) * 0.6, 0.3, (p.z - z - 0.5) * 0.6); return;
            }
        }
        if (spec.kind === "exit") { leave(p); return; }
        if (spec.kind === "spawn") { sendToSpawn(p); return; }
        if (spec.kind === "gate") { p.setVar("dbrd_at_gate", RPG.server.getTick()); RPG.net.send(p, "dbrd_gate", gateState(p)); return; }
        var target = spec.kind === "floor" ? (spec.floor | 0) : here + 1;
        if (spec.kind === "next" && !here) { tell(p, "&cThis portal is not inside a dungeon floor, so it has no next floor."); return; }
        if (!isValid(target)) { bar(p, "portal_final_floor"); return; }
        enterFloor(p, target, { requireTicket: !!spec.requireTicket, party: spec.kind !== "next" });
    }

    // what the Dungeon Gate screen lists: floors with the player's access to each
    function gateState(p) {
        var list = floors().list.map(function (f, i) {
            var n = i + 1, why = "";
            if (!f.inRotation) why = "out";
            else if (f.requireTicket && !hasTicket(p, n) && !canBypass(p)) why = "ticket";
            else if (!canBypass(p) && firstUnclearedBossBefore(p, n) > 0) why = "boss:" + firstUnclearedBossBefore(p, n);
            return { n: n, theme: f.theme, type: f.type, style: styleFor(n, f), built: !!(layoutOf(n) && layoutOf(n).placed),
                cleared: f.type === "BOSS" && (isBossDefeated(n) || hasCleared(p, n)), locked: why };
        }).filter(function (e) { return e.locked !== "out" || canBypass(p); });
        return { floors: list, cooldown: canBypass(p) ? 0 : remaining(p), timeLimit: rules().timeLimitSeconds, admin: canEdit(p),
            best: typeof DBRD_LOOT !== "undefined" ? DBRD_LOOT.boards(p) : null };
    }

    // ---- the editor (DungeonConfigScreen / OpenDungeonConfigPacket / SaveDungeonConfigPacket) ----
    function openEditor(p) {
        if (!canEdit(p)) { tell(p, "&c" + msg("no_permission")); return; }
        var F = floors();
        RPG.net.send(p, "dbrd_config", { rules: rules(), floors: F.list, generated: F.generated, bossDefeated: F.bossDefeated,
            styles: F.list.map(function (f, i) { return styleFor(i + 1, f); }), defaultStyle: C.get("dungeonDefaultLayoutStyle") });
    }
    RPG.net.on("dbrd_open_config", function (p) { openEditor(p); });
    RPG.net.on("dbrd_save_config", function (p, d) {
        if (!canEdit(p) || !d) { tell(p, "&c" + msg("no_permission")); return; }
        try {
            if (d.rules) applyRules(d.rules);
            if (Array.isArray(d.floors)) applyFloorsFromEditor(d.floors);
            tell(p, "&a" + msg("config_saved"));
        } catch (e) { RPG.log("[dungeons] save failed: " + e); tell(p, "&c" + msg("config_save_failed")); }
        if (d.reopen) openEditor(p);
    });
    RPG.net.on("dbrd_floor_go", function (p, d) {
        if (!canEdit(p) || !d) return;
        enterFloor(p, d.floor | 0, { party: false });
    });
    RPG.net.on("dbrd_floor_regen", function (p, d) {
        if (!canEdit(p) || !d || !isValid(d.floor | 0)) return;
        clearGenerated(d.floor | 0);
        tell(p, "&eFloor " + (d.floor | 0) + " will be re-stamped on its next visit.");
        openEditor(p);
    });
    RPG.net.on("dbrd_enter", function (p, d) {
        if (!d) return;
        var n = d.floor | 0;
        var f = floor(n);
        if (!f || (!f.inRotation && !canBypass(p))) return;
        var at = Number(p.getVar("dbrd_at_gate", 0)) || 0, now = RPG.server.getTick();
        if (!canBypass(p) && (!at || now < at || now - at > 6000)) { tell(p, "&cUse a Dungeon Gate (or the Gatekeeper) to choose a floor."); return; }
        p.setVar("dbrd_at_gate", 0);
        enterFloor(p, n, {});
    });
    RPG.net.on("dbrd_gate_open", function (p) { RPG.net.send(p, "dbrd_gate", gateState(p)); });

    // ---- commands (/dungeon, legacy alias /sdd; DMZR's /rg dungeon tree) ----
    function num(s, d) { var v = Number(s); return isNaN(v) ? d : v; }
    function onOff(s) { return /^(on|true|yes|1)$/i.test(String(s)); }
    var HELP = ["&6/dungeon &7- choose a floor (at a Dungeon Gate) / &6leave &7/ &6top",
        "&6/dungeon edit &7| floor <n> | floor list | floor count <n> | floor theme|size|depth|style|type <n> <v>",
        "&6/dungeon floor regen|relocate|respawn <n> &7| floor rotation|requireticket <n> on|off",
        "&6/dungeon bossreset <n> &7| ticket give <player> <floor> | gem give <player> <tp>",
        "&6/dungeon tp [x y z] &7| setwarp|warp|delwarp <name> | warps | highlight <r> | paste <schem> <x y z>",
        "&6/dungeon gate &7(place a Dungeon Gate) | portal next|exit|spawn|floor <n> [bosslock] [ticket] | portal remove"];
    function run(p, args) {
        var sub = String(args[0] || "").toLowerCase();
        if (!sub || sub === "gate" && !canEdit(p)) {
            if (p) RPG.net.send(p, "dbrd_gate", gateState(p));
            return;
        }
        if (sub === "leave") { if (p && DBRD.isDungeonDim(p.dimension)) leave(p); return; }
        if (sub === "top") { if (typeof DBRD_LOOT !== "undefined") DBRD_LOOT.showTop(p); return; }
        if (sub === "help") { HELP.forEach(function (h) { if (p) p.tell(h); }); return; }
        if (p && !canEdit(p)) { tell(p, "&c" + msg("no_permission")); return; }
        var out = function (t) { if (p) p.tell(t); else RPG.log(t); };
        switch (sub) {
            case "edit": if (p) openEditor(p); return;
            case "tp": {
                if (!p) return;
                var x = num(args[1], 0.5), y = num(args[2], DBRD.SURFACE_Y + 2), z = num(args[3], 0.5);
                p.teleportTo("dbr:dungeon_overworld", x, y, z);
                out("&a" + msg("tp_done", Math.floor(x) + ", " + Math.floor(y) + ", " + Math.floor(z)));
                return;
            }
            case "setwarp": {
                if (!p || !args[1]) return;
                var w = warps(); w[args[1]] = { dim: p.dimension, x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch };
                RPG.data.set("dbrd_warps", w); out("&a" + msg("warp_set", args[1])); return;
            }
            case "warp": {
                var t = warps()[args[1]];
                if (!p || !t) { out("&c" + msg("warp_not_found_or_dim", args[1])); return; }
                p.teleportTo(t.dim, t.x, t.y, t.z, t.yaw, t.pitch); out("&a" + msg("warp_done", args[1])); return;
            }
            case "delwarp": {
                var ws = warps();
                if (!ws[args[1]]) { out("&c" + msg("warp_not_found", args[1])); return; }
                delete ws[args[1]]; RPG.data.set("dbrd_warps", ws); out("&a" + msg("warp_deleted", args[1])); return;
            }
            case "warps": { var names = Object.keys(warps()); out("&e" + msg("warp_list", names.length, "[" + names.join(", ") + "]")); return; }
            case "highlight": {
                if (!p) return;
                var r = Math.min(Math.max(1, num(args[1], 32)), C.get("maxHighlightRadius"));
                var found = typeof DBRD_LOOT !== "undefined" ? DBRD_LOOT.highlight(p, r) : 0;
                out("&e" + msg("highlight_result", found, r)); return;
            }
            case "paste": {
                if (!p || !args[1]) return;
                var px = Math.floor(num(args[2], p.x)), py = Math.floor(num(args[3], p.y)), pz = Math.floor(num(args[4], p.z)), name = args[1];
                RPG.edit.schemLoad(p, name, function (res) {
                    if (!res || !res.ok) { out("&c" + msg("paste_failed", name)); return; }
                    RPG.edit.paste(p, p.dimension, px, py, pz).then(function () { out("&a" + msg("paste_done", name, px + ", " + py + ", " + pz)); });
                });
                return;
            }
            case "bossreset": {
                var bn = num(args[1], 0) | 0;
                out(clearBossDefeated(bn) ? "&aFloor " + bn + "'s guardian is back." : "&eFloor " + bn + "'s guardian was not defeated.");
                if (typeof DBRD_LOOT !== "undefined") DBRD_LOOT.resetGuardian(bn);
                return;
            }
            case "ticket": case "gem": {
                if (typeof DBRD_LOOT === "undefined") return;
                var target = RPG.player(args[2] || "") || p, v = num(args[3], 0);
                if (!target) return;
                if (sub === "ticket") { target.giveStack(DBRD_LOOT.ticketStack(v | 0)); out("&aGave a floor " + (v | 0) + " ticket to " + target.name); }
                else { target.giveStack(DBRD_LOOT.gemStack(v)); out("&aGave a " + v + " TP gem to " + target.name); }
                return;
            }
            case "gate": { if (p) DBRD_GEN.placeGate(p); return; }
            case "portal": {
                if (!p) return;
                var bx = Math.floor(p.x), by = Math.floor(p.y), bz = Math.floor(p.z), kind = String(args[1] || "next").toLowerCase();
                if (kind === "remove") { setPortal(p.dimension, bx, by, bz, null); RPG.world.setBlock(p.dimension, bx, by, bz, "minecraft:air"); out("&ePortal removed."); return; }
                var spec = { kind: kind === "floor" ? "floor" : kind, floor: kind === "floor" ? num(args[2], 1) | 0 : 0 };
                args.slice(2).forEach(function (a) { if (a === "bosslock") spec.bosslock = true; if (a === "ticket") spec.requireTicket = true; });
                RPG.world.setBlock(p.dimension, bx, by, bz, DBRD_LOOT.portalBlock());
                setPortal(p.dimension, bx, by, bz, spec);
                out("&aPlaced a " + kind + " portal" + (spec.floor ? " to floor " + spec.floor : "") + ".");
                return;
            }
            case "floor": return floorCmd(p, args.slice(1), out);
        }
        HELP.forEach(out);
    }
    function floorCmd(p, a, out) {
        var op = String(a[0] || "list").toLowerCase(), n = num(a[1], 0) | 0, f = floor(n);
        if (/^\d+$/.test(op)) { if (p) enterFloor(p, op | 0, { party: false }); return; }
        if (op === "list") {
            out("&6Dungeon floors (" + count() + "):");
            floors().list.forEach(function (fl, i) {
                out("&e" + (i + 1) + "&7: " + fl.theme + " " + fl.type + " " + styleFor(i + 1, fl) + " size " + fl.size + " depth " + fl.depth +
                    (floors().generated[i + 1] ? " &a[built]" : "") + (fl.type === "BOSS" && isBossDefeated(i + 1) ? " &a[cleared]" : "") + (fl.inRotation ? "" : " &c[out of rotation]"));
            });
            return;
        }
        if (op === "count") { setCount(n); out("&aThere are now " + count() + " floors."); return; }
        if (!f) { out("&cNo floor " + n + "."); return; }
        var v = a[2];
        switch (op) {
            case "theme": f.theme = DBRD.canonicalTheme(v); relocate(n); break;
            case "type": f.type = DBRD.canonicalType(v); relocate(n); break;
            case "style": f.layoutStyle = DBRD.canonicalStyle(v); relocate(n); break;
            case "size": f.size = Math.max(DBRD.MIN_SIZE, Math.min(DBRD.MAX_SIZE, num(v, f.size) | 0)); break;
            case "depth": f.depth = Math.max(DBRD.MIN_DEPTH, Math.min(DBRD.MAX_DEPTH, num(v, f.depth) | 0)); break;
            case "rotation": f.inRotation = onOff(v); break;
            case "requireticket": f.requireTicket = onOff(v); break;
            case "regen": clearGenerated(n); out("&eFloor " + n + " will be re-stamped on its next visit."); return;
            case "relocate": relocate(n); out("&eFloor " + n + " moved to fresh ground (epoch " + epochOf(n) + ")."); return;
            case "respawn": { if (typeof DBRD_LOOT !== "undefined") out("&e" + DBRD_LOOT.respawnFloor(n)); return; }
            case "go": if (p) enterFloor(p, n, { party: false }); return;
            default: out("&cUnknown floor option " + op); return;
        }
        saveFloors();
        out("&aFloor " + n + " updated.");
    }
    function suggest(p, args) {
        if (args.length <= 1) return ["leave", "top", "help", "edit", "floor", "tp", "setwarp", "warp", "delwarp", "warps", "highlight", "paste", "bossreset", "ticket", "gem", "gate", "portal"];
        if (args[0] === "floor" && args.length === 2) return ["list", "count", "theme", "size", "depth", "style", "type", "regen", "relocate", "respawn", "rotation", "requireticket", "go"];
        if (args[0] === "floor" && args.length === 4 && args[1] === "theme") return DBRD.THEMES;
        if (args[0] === "floor" && args.length === 4 && args[1] === "style") return DBRD.STYLE_NAMES;
        if (args[0] === "floor" && args.length === 4 && args[1] === "type") return DBRD.TYPES;
        if (args[0] === "portal" && args.length === 2) return ["next", "exit", "spawn", "floor", "remove"];
        if ((args[0] === "warp" || args[0] === "delwarp") && args.length === 2) return Object.keys(warps());
        return [];
    }
    RPG.commands.register("dungeon", { root: true, aliases: ["sdd"], permission: 0, description: "Dungeons (DMZ Ragnarok)", run: run, suggest: suggest });

    return {
        msg: msg, tell: tell, bar: bar, human: human, canEdit: canEdit, canBypass: canBypass, rules: rules, floors: floors, saveFloors: saveFloors,
        floor: floor, count: count, isValid: isValid, layoutOf: layoutOf, epochOf: epochOf, styleFor: styleFor, floorAt: floorAt,
        isBossDefeated: isBossDefeated, markBossDefeated: markBossDefeated, hasCleared: hasCleared, recordCleared: recordCleared,
        hasTicket: hasTicket, unlockTicket: unlockTicket, enterFloor: enterFloor, ensureBuilt: ensureBuilt, isBuilding: isBuilding,
        leave: leave, sendToSpawn: sendToSpawn, usePortal: usePortal, setPortal: setPortal, portalAt: portalAt, gateState: gateState,
        openEditor: openEditor, online: online, uid: uid, themeLabel: themeLabel
    };
})();
