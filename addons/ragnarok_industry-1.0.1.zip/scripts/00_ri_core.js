// =====================================================================================
//  Ragnarok Industry - core: shared helpers, materials, ores, the Pyrogas fluid and world generation.
//  Energy is Ragnarok Energy (RE). Ids (the "ri_" names below) are permanent: never rename or remove one.
// =====================================================================================
var RI = {
    NS: "ragnarok_industry",
    TIERS: [null, { name: "Basic", color: "&7" }, { name: "Advanced", color: "&e" }, { name: "Elite", color: "&b" }, { name: "Celestial", color: "&d" }],
    items: {},      // key -> full item id
    blocks: {},     // key -> full block id
    open: {}        // "dim|x|y|z" -> [{player, bench, refresh}] screens to refresh from onTick
};

// Screen titles are drawn in vanilla's dark grey on the grey panel (tier colours are for names in tooltips).
RI.gui = function (name) { return "&8" + String(name).replace(/&[0-9a-fk-or]/g, ""); };
RI.tex = function (name) { return RI.NS + ":block/" + name; };
RI.fmt = function (n) {
    n = Math.round(n);
    var s = String(Math.abs(n)), out = "";
    while (s.length > 3) { out = "," + s.slice(-3) + out; s = s.slice(0, -3); }
    return (n < 0 ? "-" : "") + s + out;
};
RI.posKey = function (be) { return be.dimension + "|" + be.x + "|" + be.y + "|" + be.z; };

RI.item = function (key, def) {
    if (!def.model) def.model = RI.NS + ":rpg/item/" + key.replace(/^ri_/, "");
    if (!def.type) def.type = "material";
    var id = "ragnarok_rpg:" + RI.items_define(key, def);
    RI.items[key] = id;
    return id;
};
RI.items_define = function (key, def) { return RPG.items.define(key, def); };

RI.block = function (key, def) {
    var id = "ragnarok_rpg:" + RPG.blocks.define(key, def);
    RI.blocks[key] = id;
    return id;
};

// Screens opened on a block entity: kept so onTick can refresh their status buttons while they are open.
RI.track = function (be, player, bench, refresh) {
    if (!bench) return;
    var k = RI.posKey(be), list = RI.open[k] || (RI.open[k] = []);
    list.push({ player: player, bench: bench, refresh: refresh });
    if (refresh) refresh(be, bench);
};
RI.refresh = function (be) {
    var k = RI.posKey(be), list = RI.open[k];
    if (!list) return;
    for (var i = list.length - 1; i >= 0; i--) {
        var o = list[i];
        if (!o.bench.isOpen()) { list.splice(i, 1); continue; }
        if (o.refresh) o.refresh(be, o.bench);
    }
    if (list.length === 0) delete RI.open[k];
};

// The block entity a player clicked, and remembering who placed it (machines work for their owner: claims).
RI.be = function (player, x, y, z) { return RPG.blocks.entityAt(player.dimension, x, y, z); };
RI.claimOwner = function (player, x, y, z) {
    var be = RI.be(player, x, y, z);
    if (!be) return;
    var d = be.data;
    d.owner = player.uuid;
    d.ownerName = player.name;
    be.save();
};

// ---- materials ------------------------------------------------------------------------------------------
RI.item("ri_raw_galvanite", { name: "Raw Galvanite", lore: ["&7Smelt it into Galvanite Ingots."] });
RI.item("ri_galvanite_ingot", { name: "Galvanite Ingot", lore: ["&7A soft, very conductive blue-green metal."] });
RI.item("ri_galvanite_plate", { name: "Galvanite Plate" });
RI.item("ri_sunsteel_blend", { name: "Sunsteel Blend", lore: ["&7Smelt it into Sunsteel Ingots."] });
RI.item("ri_sunsteel_ingot", { name: "Sunsteel Ingot", lore: ["&7An alloy that drinks in heat and light."] });
RI.item("ri_sunsteel_plate", { name: "Sunsteel Plate" });
RI.item("ri_raw_ragnite", { name: "Raw Ragnite", lore: ["&7Found deep below. Needs a Blast Furnace."] });
RI.item("ri_ragnite_ingot", { name: "Ragnite Ingot", rarity: "rare", lore: ["&7Dense crimson metal from the deep."] });
RI.item("ri_ragnite_plate", { name: "Ragnite Plate", rarity: "rare" });
RI.item("ri_pyrolite_shard", { name: "Pyrolite Shard", burnTime: 2400, lore: ["&7Burns hot. A Refinery turns it into Pyrogas."] });
RI.item("ri_basic_circuit", { name: "Basic Circuit" });
RI.item("ri_advanced_circuit", { name: "Advanced Circuit", rarity: "uncommon" });
RI.item("ri_elite_circuit", { name: "Elite Circuit", rarity: "rare" });
RI.item("ri_solar_cell", { name: "Solar Cell" });
RI.item("ri_radiant_cell", { name: "Radiant Cell", rarity: "uncommon", lore: ["&7Catches moonlight too."] });
RI.item("ri_heat_coil", { name: "Heat Coil" });
RI.item("ri_machine_casing", { name: "Machine Casing" });
RI.item("ri_advanced_casing", { name: "Advanced Casing", rarity: "uncommon" });
RI.item("ri_elite_casing", { name: "Elite Casing", rarity: "rare" });
RI.item("ri_forge_hammer", { name: "Forge Hammer", type: "tool", durability: 160, maxStack: 1, craftingRemainder: "self",
    lore: ["&7Craft it with an ingot to beat out a plate."] });
RI.item("ri_wrench", { name: "Conduit Wrench", type: "tool", maxStack: 1,
    lore: ["&7Use on a cable or pipe connection to switch it:", "&7pipes: normal → extract → off; cables: on → off.", "&7Power bank faces: in → out → off.", "&7Sneak-use with an empty hand does the same."],
    onUseOnBlock: function (player, x, y, z, face) { return RI.wrench(player, x, y, z); } });
RI.item("ri_speed_upgrade", { name: "Quarry Speed Upgrade", maxStack: 4, lore: ["&7Quarry: +50% blocks per tick each (up to 4),", "&7+25% energy per block each."] });
RI.item("ri_fortune_upgrade", { name: "Quarry Fortune Upgrade", maxStack: 3, lore: ["&7Quarry: Fortune I-III (stack 1-3)."] });
RI.item("ri_silk_upgrade", { name: "Quarry Silk Touch Upgrade", maxStack: 1, lore: ["&7Quarry: mines blocks whole.", "&7Replaces Fortune."] });

// ---- ores and storage blocks ------------------------------------------------------------------------------
function riOre(key, name, texture, drop, count, tier, deep) {
    return RI.block(key, {
        family: "simple", name: name, textures: { all: RI.tex(texture) }, hardness: deep ? 4.5 : 3, explosionResistance: 3,
        tool: "pickaxe", tier: tier, requiresTool: true, sound: deep ? "deepslate" : "stone",
        drops: [{ item: drop, count: count }], silkTouch: true, fortune: true
    });
}
riOre("ri_galvanite_ore", "Galvanite Ore", "galvanite_ore", RI.items.ri_raw_galvanite, 1, "stone", false);
riOre("ri_deepslate_galvanite_ore", "Deepslate Galvanite Ore", "deepslate_galvanite_ore", RI.items.ri_raw_galvanite, 1, "stone", true);
riOre("ri_pyrolite_ore", "Pyrolite Ore", "pyrolite_ore", RI.items.ri_pyrolite_shard, 2, "stone", false);
riOre("ri_deepslate_pyrolite_ore", "Deepslate Pyrolite Ore", "deepslate_pyrolite_ore", RI.items.ri_pyrolite_shard, 2, "stone", true);
riOre("ri_ragnite_ore", "Ragnite Ore", "ragnite_ore", RI.items.ri_raw_ragnite, 1, "diamond", true);
["galvanite", "sunsteel", "ragnite"].forEach(function (m) {
    var name = m.charAt(0).toUpperCase() + m.slice(1);
    RI.block("ri_" + m + "_block", { family: "simple", name: "Block of " + name, textures: { all: RI.tex(m + "_block") }, hardness: 5,
        tool: "pickaxe", tier: "stone", requiresTool: true, sound: "metal", drops: "self" });
});

// ---- Pyrogas: the gas fuel ------------------------------------------------------------------------------
RI.PYROGAS = "ragnarok_rpg:" + RPG.fluids.define("ri_pyrogas", {
    name: "Pyrogas", stillTexture: RI.tex("pyrogas_still"), flowTexture: RI.tex("pyrogas_flow"),
    alpha: 190, flow: "up", density: -200, viscosity: 300, temperature: 420, canSwim: false, canDrown: true, canExtinguish: false,
    boats: false, canHydrate: false, fogColor: "D9832B", lightLevel: 3,
    bucket: { id: "ri_pyrogas_bucket", name: "Pyrogas Bucket", lore: ["&7Fuel for Gas Generators."] }
});
RI.PYROGAS_BUCKET = RPG.fluids.bucket("ri_pyrogas");

// ---- world generation: ores in new chunks, from the moment the addon is on (engine RPG.world.ore: no restart) ----
(function () {
    function ore(name, stone, deep, size, count, minY, maxY, air, triangle) {
        var targets = [];
        if (stone) targets.push({ replace: "#minecraft:stone_ore_replaceables", block: stone });
        if (deep) targets.push({ replace: "#minecraft:deepslate_ore_replaceables", block: deep });
        try {
            RPG.world.ore(RI.NS + "/" + name, { targets: targets, size: size, count: count, minY: minY, maxY: maxY, airExposure: air,
                shape: triangle ? "trapezoid" : "uniform", biomes: "#minecraft:is_overworld" });
        } catch (e) { console.warn("[Ragnarok Industry] ore generation " + name + ": " + e); }
        // 1.0.0 wrote these as data-pack worldgen files (a restart was needed): they go, so ores don't generate twice
        ["forge/biome_modifier", "worldgen/placed_feature", "worldgen/configured_feature"].forEach(function (c) {
            try { if (RPG.datapack.read(RI.NS, c, name) !== null) RPG.datapack.remove(RI.NS, c, name); } catch (e) { console.warn("[Ragnarok Industry] old ore file " + c + "/" + name + ": " + e); }
        });
    }
    ore("ore_galvanite", RI.blocks.ri_galvanite_ore, RI.blocks.ri_deepslate_galvanite_ore, 9, 14, -32, 80, 0, true);
    ore("ore_pyrolite", RI.blocks.ri_pyrolite_ore, RI.blocks.ri_deepslate_pyrolite_ore, 12, 8, -24, 56, 0.1, false);
    ore("ore_ragnite", null, RI.blocks.ri_ragnite_ore, 5, 4, -64, -12, 0.5, true);
})();

// ---- tags (other mods' recipes, the right tools) ----------------------------------------------------------
(function () {
    function t(kind, tag, ids) { try { RPG.tags.add(kind, tag, ids); } catch (e) { console.warn("[Ragnarok Industry] tag " + tag + ": " + e); } }
    t("item", "forge:ingots/galvanite", [RI.items.ri_galvanite_ingot]);
    t("item", "forge:ingots/sunsteel", [RI.items.ri_sunsteel_ingot]);
    t("item", "forge:ingots/ragnite", [RI.items.ri_ragnite_ingot]);
    t("item", "forge:plates/galvanite", [RI.items.ri_galvanite_plate]);
    t("item", "forge:plates/sunsteel", [RI.items.ri_sunsteel_plate]);
    t("item", "forge:plates/ragnite", [RI.items.ri_ragnite_plate]);
    t("item", "forge:raw_materials/galvanite", [RI.items.ri_raw_galvanite]);
    t("item", "forge:raw_materials/ragnite", [RI.items.ri_raw_ragnite]);
    t("item", "forge:gems/pyrolite", [RI.items.ri_pyrolite_shard]);
    t("block", "forge:ores/galvanite", [RI.blocks.ri_galvanite_ore, RI.blocks.ri_deepslate_galvanite_ore]);
    t("block", "forge:ores/pyrolite", [RI.blocks.ri_pyrolite_ore, RI.blocks.ri_deepslate_pyrolite_ore]);
    t("block", "forge:ores/ragnite", [RI.blocks.ri_ragnite_ore]);
    t("block", "forge:ores", [RI.blocks.ri_galvanite_ore, RI.blocks.ri_deepslate_galvanite_ore, RI.blocks.ri_pyrolite_ore, RI.blocks.ri_deepslate_pyrolite_ore, RI.blocks.ri_ragnite_ore]);
})();

// ---- shared screen pieces ---------------------------------------------------------------------------------
RI.ENERGY_GAUGE = function (x, y) { return { type: "energy", x: x, y: y, w: 14, h: 52, label: "&cEnergy" }; };
RI.RATE = function (x, y) { return { type: "rate", x: x, y: y }; };
RI.btn = function (id, text, x, y, w, tip) { return { id: id, text: text, x: x, y: y, w: w || 52, h: 14, tooltip: tip || [] }; };
