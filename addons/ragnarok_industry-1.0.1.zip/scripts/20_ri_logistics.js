// =====================================================================================
//  Ragnarok Industry - logistics: energy cables, fluid pipes, connected tanks and ender tanks.
//  Cable and pipe networks are cached by the engine (BlockDef.blockEntity.conduit) and rebuilt only when something
//  changes; touching tanks share one fluid (tanks[0].connect). Nothing here runs per tick.
// =====================================================================================
var RI_SIDES = ["north", "south", "east", "west", "up", "down"];
// Cables and pipes use a 12-pixel box as their shape (the models are thinner): blocks smaller than that count as
// non-solid, and flowing water or lava would wash them away like torches.
// They are engine "conduit" family blocks: six sides none | pipe | extract, built in, so they work the moment the
// addon is turned on (no restart). 1.0.0 gave them layout slots (states made at start-up); the engine moves those
// names to conduit slots and turns blocks and items saved as the old ones into the new ones.

// Wrench (or sneak-use with an empty hand): switch the connection the player points at.
RI.wrench = function (player, x, y, z) {
    if (RI.bankWrench && RI.bankWrench(player, x, y, z)) return true;     // power bank faces (25_ri_banks.js)
    var be = RI.be(player, x, y, z);
    if (!be || be.conduitSide("north") === null) return false;
    var face = be.sideAt(player);
    if (!face) return true;
    var fluid = be.key.indexOf("ri_fluid_pipe") === 0;
    var cur = be.conduitSide(face), next;
    if (fluid) next = cur === "auto" ? "extract" : cur === "extract" ? "off" : "auto";
    else next = cur === "auto" ? "off" : "auto";
    be.setConduitSide(face, next);
    var label = next === "auto" ? (fluid ? "&aNormal" : "&aConnected") : next === "extract" ? "&6Extract" : "&cOff";
    player.actionbar("&7" + face.charAt(0).toUpperCase() + face.slice(1) + ": " + label);
    player.playSound("minecraft:block.lever.click", 0.5, next === "off" ? 0.7 : 1.2);
    return true;
};

RI.conduitUse = function (unit) {
    return function (p, x, y, z) {
        if (p.isSneaking()) { RI.wrench(p, x, y, z); return; }
        var be = RI.be(p, x, y, z), info = be ? be.conduitInfo() : null;
        if (info) p.actionbar("&7Network: &f" + info.members + " &7blocks, &f" + info.endpoints + " &7connections, &f" + RI.fmt(info.rate) + " " + unit + "/t");
    };
};

// ---- energy cables ----------------------------------------------------------------------------------------
RI.CABLE = [null, { rate: 1000, mat: "Galvanite" }, { rate: 8000, mat: "Sunsteel" }, { rate: 64000, mat: "Ragnite" }];
for (var cbt = 1; cbt <= 3; cbt++) (function (t) {
    RI.block("ri_cable_" + t, {
        family: "conduit", blockstate: RI.NS + ":cable_" + t, itemModel: RI.NS + ":rpg/item/cable_" + t,
        name: RI.TIERS[t].color + RI.CABLE[t].mat + " Cable", shape: [2, 2, 2, 14, 14, 14], solid: false, renderType: "cutout",
        hardness: 0.8, sound: "metal", drops: "self",
        lore: ["&7Carries &f" + RI.fmt(RI.CABLE[t].rate) + " RE/t&7.", "&7Cables of any tier join; a network runs at its slowest cable.",
               "&7Generators and cells push into it; it feeds every machine it touches.", "&7Wrench a connection to switch it off."],
        blockEntity: { conduit: { type: "energy", rate: RI.CABLE[t].rate, group: "ri_energy" } },
        useWith: ["empty"], onUse: RI.conduitUse("RE")
    });
})(cbt);

// ---- fluid pipes ------------------------------------------------------------------------------------------
RI.PIPE = [null, { rate: 100, mat: "Galvanite" }, { rate: 500, mat: "Sunsteel" }, { rate: 2500, mat: "Ragnite" }];
for (var ppt = 1; ppt <= 3; ppt++) (function (t) {
    RI.block("ri_fluid_pipe_" + t, {
        family: "conduit", blockstate: RI.NS + ":fluid_pipe_" + t, itemModel: RI.NS + ":rpg/item/fluid_pipe_" + t,
        name: RI.TIERS[t].color + RI.PIPE[t].mat + " Fluid Pipe", shape: [2, 2, 2, 14, 14, 14], solid: false, renderType: "cutout",
        hardness: 0.8, sound: "metal", drops: "self",
        lore: ["&7Moves &f" + RI.fmt(RI.PIPE[t].rate) + " mB/t&7.", "&7Wrench a connection: normal → &6extract&7 → off.",
               "&7Extracting connections pull from what they touch", "&7and feed every other connection."],
        blockEntity: { conduit: { type: "fluid", rate: RI.PIPE[t].rate, group: "ri_fluid" } },
        useWith: ["empty"], onUse: RI.conduitUse("mB")
    });
})(ppt);

// ---- tanks: touching tanks form one tank (one fluid, capacities add up, filled from the bottom) -------------
RI.TANK = [null, { cap: 16000, mat: "Galvanite" }, { cap: 64000, mat: "Sunsteel" }, { cap: 256000, mat: "Ragnite" }];
RI.tankInfo = function (p, be) {
    var t = be.tank(0), n = be.tankGroupSize;
    p.actionbar((t.fluid ? "&b" + t.name : "&7Empty") + "&7: &f" + RI.fmt(t.amount) + " / " + RI.fmt(t.capacity) + " mB" + (n > 1 ? " &8(" + n + " tanks)" : ""));
};
for (var tkt = 1; tkt <= 3; tkt++) (function (t) {
    RI.block("ri_tank_" + t, {
        name: RI.TIERS[t].color + RI.TANK[t].mat + " Tank", model: RI.NS + ":rpg/block/tank_" + t, decor: true, renderType: "cutout",
        hardness: 2, sound: "glass", drops: "self",
        // only buckets and an empty hand use the tank: any other block in hand is placed against it (more tanks)
        useWith: ["empty", "minecraft:bucket", "minecraft:water_bucket", "minecraft:lava_bucket", "minecraft:milk_bucket", RI.PYROGAS_BUCKET],
        lore: ["&7Holds &f" + RI.fmt(RI.TANK[t].cap) + " mB&7.", "&7Touching tanks become one tank (up to 512), any shape,", "&7holding one fluid. Keeps its share of the fluid when broken.",
               "&7Right-click with a bucket to fill or empty it."],
        blockEntity: {
            inventory: { size: 0, keepContents: true },
            tanks: [{ capacity: RI.TANK[t].cap, connect: "ri_tank", render: [1.01, 0.02, 1.01, 14.99, 15.98, 14.99] }]
        },
        onPlace: function (p, x, y, z) {
            RI.claimOwner(p, x, y, z);
            var be = RI.be(p, x, y, z);
            if (!be) return;
            var mine = be.tank(0).fluid, d = p.dimension, refused = false;
            for (var i = 0; i < 6; i++) {
                var o = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]][i];
                var n = RPG.blocks.entityAt(d, x + o[0], y + o[1], z + o[2]);
                if (!n || n.key.indexOf("ri_tank_") !== 0) continue;
                var f = n.tank(0).fluid;
                if (f && mine && f !== mine) refused = true;
            }
            if (refused) p.tell("&cThat tank touches a tank holding a different fluid: they stay separate.");
            else if (be.tankGroupSize >= 512) p.tell("&eThis tank group is at its limit of 512 tanks: the new one stays separate.");
        },
        onUse: function (p, x, y, z) {
            var be = RI.be(p, x, y, z);
            if (!be) return;
            if (!be.useHeldContainer(p)) RI.tankInfo(p, be);
            else RI.tankInfo(p, be);
        }
    });
})(tkt);

// ---- ender tank: every ender tank with the same combo (and owner, when private) shares one tank ------------
RI.ENDER = { cap: 32000, rate: 1000 };
RI.enderKey = function (be) {
    var d = be.data, combo = Math.max(0, Math.min(9999, Math.floor(Number(d.combo) || 0)));
    var c = ("000" + combo).slice(-4);
    return d.private && d.owner ? "ri_private:" + String(d.owner).toLowerCase() + ":" + c : "ri_combo:" + c;
};
RI.enderLink = function (be) { be.linkTank(0, RI.enderKey(be)); };
RI.DIGITS = ["&f0", "&61", "&d2", "&b3", "&e4", "&a5", "&c6", "&82", "&73", "&94"];
RI.block("ri_ender_tank", {
    name: "&5Ender Tank", model: RI.NS + ":rpg/block/ender_tank", hardness: 4, explosionResistance: 600, sound: "stone", drops: "self", renderType: "cutout",
    lore: ["&7Every ender tank set to the same four digits shares", "&7one &f32,000 mB &7tank, in any dimension.",
           "&7Private: only ender tanks you placed share it.", "&7Moves up to 1,000 mB/t through each tank."],
    blockEntity: {
        inventory: { size: 4, accepts: function (slot, id) { return slot === 0 || slot === 2; }, inputs: [0, 2], outputs: [1, 3] },
        tanks: [{ capacity: RI.ENDER.cap, shared: true, rate: RI.ENDER.rate, fillFrom: 0, emptyTo: 1, drainFrom: 2, drainTo: 3 }]
    },
    onPlace: function (p, x, y, z) {
        RI.claimOwner(p, x, y, z);
        var be = RI.be(p, x, y, z);
        if (be) { be.data.combo = 0; be.data.private = false; be.save(); RI.enderLink(be); }
    },
    onUse: function (p, x, y, z) {
        var be = RI.be(p, x, y, z);
        if (!be) return;
        if (!be.tankKey(0)) RI.enderLink(be);       // placed by a command or before it had an owner
        var owner = be.data.owner;
        if (be.data.private && owner && owner !== p.uuid && !RPG.perms.has(p, "industry.admin")) { p.actionbar("&cThis ender tank is private."); return; }
        var buttons = [];
        for (var i = 0; i < 4; i++) {
            buttons.push(RI.btn("up" + i, "+", 44 + i * 22, 18, 20, ["Next digit"]));
            buttons.push(RI.btn("dn" + i, "-", 44 + i * 22, 50, 20, ["Previous digit"]));
            buttons.push(RI.btn("d" + i, "0", 44 + i * 22, 34, 20, []));
        }
        buttons.push(RI.btn("priv", "", 44, 66 - 2, 43, ["Private: only ender tanks you placed", "with the same digits share this tank."]));
        buttons.push(RI.btn("load", "", 89, 66 - 2, 41, ["Keep this tank's chunks loaded (owner only):", "Off, its own chunk (1x1) or 3x3 chunks around it,", "so pumps and pipes there keep working", "while nobody is near."]));
        var spec = { title: RI.gui("Ender Tank"), height: 176, inventory: { y: 94, labelY: 83 },
            slots: [{ x: 8, y: 18, slot: 0, accepts: "fluid_container" }, { x: 8, y: 54, slot: 1 }, { x: 134, y: 18, slot: 2, accepts: "fluid_container" }, { x: 134, y: 54, slot: 3 }],
            gauges: [{ type: "fluid", x: 152, y: 17, tank: 0, h: 70 }, { type: "fluid", x: 26, y: 17, tank: 0, h: 52 }],
            buttons: buttons,
            onButton: function (pl, id, bench) {
                // everything is decided here on the server: the client only says which button
                if (be.data.private && be.data.owner && be.data.owner !== pl.uuid && !RPG.perms.has(pl, "industry.admin")) return;
                var c = Math.max(0, Math.min(9999, Math.floor(Number(be.data.combo) || 0)));
                var digits = [Math.floor(c / 1000) % 10, Math.floor(c / 100) % 10, Math.floor(c / 10) % 10, c % 10];
                if (id.indexOf("up") === 0) { var k = Number(id.slice(2)); digits[k] = (digits[k] + 1) % 10; }
                else if (id.indexOf("dn") === 0) { var k2 = Number(id.slice(2)); digits[k2] = (digits[k2] + 9) % 10; }
                else if (id === "load") {
                    if (be.data.owner !== pl.uuid && !RPG.perms.has(pl, "industry.admin")) { pl.actionbar("&cOnly the owner can keep its chunks loaded."); return; }
                    var cur = Number(be.data.load) || 0, nx = cur === 0 ? 1 : cur === 1 ? 3 : 0;
                    RI.enderSetLoad(be, nx, pl);
                    refresh(be, bench);
                    return;
                }
                else if (id === "priv") {
                    if (be.data.owner !== pl.uuid && !RPG.perms.has(pl, "industry.admin")) { pl.actionbar("&cOnly the owner can make it private."); return; }
                    be.data.private = !be.data.private;
                }
                be.data.combo = digits[0] * 1000 + digits[1] * 100 + digits[2] * 10 + digits[3];
                be.save();
                RI.enderLink(be);
                refresh(be, bench);
            } };
        function refresh(b, bn) {
            var c = Math.max(0, Math.min(9999, Math.floor(Number(b.data.combo) || 0)));
            var digits = [Math.floor(c / 1000) % 10, Math.floor(c / 100) % 10, Math.floor(c / 10) % 10, c % 10];
            for (var i = 0; i < 4; i++) bn.button("d" + i, { text: RI.DIGITS[digits[i]].slice(0, 2) + digits[i], enabled: false });
            bn.button("priv", { text: b.data.private ? "&dPrivate" : "&7Public" });
            var ld = Number(b.data.load) || 0;
            bn.button("load", { text: ld === 0 ? "&7Off" : "&a" + ld + "x" + ld });
        }
        RI.track(be, p, be.open(p, spec), refresh);
    }
});

// ---- chunk-loading ender tanks -----------------------------------------------------------------------------
// The owner can keep an ender tank's chunk (1x1) or the 3x3 chunks around it loaded and ticking (engine force-loading:
// Forge tickets, kept across restarts), so a pump next to it in the Nether keeps filling the shared tank while nobody is
// there. Server config (ragnarok_industry): on or off, chunks per player, whether it works while the owner is offline.
RI.CFG = RPG.config.define("ragnarok_industry", {
    chunkLoading: {
        enderTanks: { default: true, comment: "Ender tanks may keep their chunks loaded (the owner switches it on in the tank's screen)" },
        maxChunksPerPlayer: { default: 9, min: 0, max: 256, integer: true, comment: "Chunks one player's ender tanks may keep loaded in all" },
        whileOwnerOffline: { default: true, comment: "Keep them loaded while the owner is offline" }
    }
});
RI.ENDER_LOAD = "ri_ender_load";      // RPG.data: { key: {owner, name, dim, x, y, z, r} }
RI.enderLoadKey = function (dim, x, y, z) { return "ri_ender:" + dim + ":" + x + ":" + y + ":" + z; };
RI.enderLoaders = function () { return RPG.data.get(RI.ENDER_LOAD, {}) || {}; };
RI.enderOnline = function (uuid) { return RPG.server.players().some(function (p) { return p.uuid === uuid; }); };

// Asks for (or lets go of) one loader's chunks; false and why when it can't.
RI.enderApply = function (k, e) {
    RPG.world.releaseForced(k);
    if (!e || !e.r) return { ok: true };
    if (!RI.CFG.get("chunkLoading.enderTanks", true)) return { ok: false, why: "Chunk-loading ender tanks are turned off on this server." };
    if (!RI.CFG.get("chunkLoading.whileOwnerOffline", true) && !RI.enderOnline(e.owner)) return { ok: true, waiting: true };
    var h = e.r === 3 ? 1 : 0, cx = e.x >> 4, cz = e.z >> 4;
    for (var dx = -h; dx <= h; dx++) for (var dz = -h; dz <= h; dz++) {
        if (!RPG.world.forceLoad(k, e.dim, cx + dx, cz + dz, true, { persist: true, ticking: true })) {
            RPG.world.releaseForced(k);
            return { ok: false, why: "The server won't keep more chunks loaded right now." };
        }
    }
    return { ok: true };
};

// The owner switched the tank's loading to r (0, 1 or 3).
RI.enderSetLoad = function (be, r, pl) {
    var k = RI.enderLoadKey(be.dimension, be.x, be.y, be.z), all = RI.enderLoaders(), owner = be.data.owner || pl.uuid;
    if (r > 0) {
        if (!RI.CFG.get("chunkLoading.enderTanks", true)) { pl.tell("&cChunk-loading ender tanks are turned off on this server."); r = 0; }
        else {
            var used = 0, max = RI.CFG.get("chunkLoading.maxChunksPerPlayer", 9);
            for (var o in all) if (o !== k && all[o].owner === owner) used += all[o].r * all[o].r;
            if (used + r * r > max) {
                pl.tell("&c" + r + "x" + r + " is " + (r * r) + " chunks, and your ender tanks may keep " + max + " loaded (" + used + " in use)" + (r === 3 && used + 1 <= max ? ": 1x1 fits." : ": none left."));
                r = 0;
            }
        }
    }
    if (r > 0) all[k] = { owner: owner, name: be.data.ownerName || pl.name, dim: be.dimension, x: be.x, y: be.y, z: be.z, r: r };
    else delete all[k];
    var res = RI.enderApply(k, all[k]);
    if (!res.ok) { delete all[k]; pl.tell("&c" + res.why); r = 0; }
    RPG.data.set(RI.ENDER_LOAD, all);
    be.data.load = r; be.save();
    pl.actionbar(r ? "&aKeeping " + r + "x" + r + " chunks loaded" + (res.waiting ? " &7(while you are online)" : "") : "&7Chunks not kept loaded");
};

// After every load (start-up, reload): ask again for every loader the rules allow, let the rest go.
(function () {
    var all = RI.enderLoaders();
    for (var k in all) RI.enderApply(k, all[k]);
})();
RI.enderOwnerChunks = function (uuid, on) {
    var all = RI.enderLoaders();
    for (var k in all) if (all[k].owner === uuid) { if (on) RI.enderApply(k, all[k]); else RPG.world.releaseForced(k); }
};
RPG.on("playerJoin", function (p) { if (!RI.CFG.get("chunkLoading.whileOwnerOffline", true)) RI.enderOwnerChunks(p.uuid, true); });
RPG.on("playerLeave", function (p) { if (!RI.CFG.get("chunkLoading.whileOwnerOffline", true)) RI.enderOwnerChunks(p.uuid, false); });
RI.CFG.onChange(function () { var all = RI.enderLoaders(); for (var k in all) RI.enderApply(k, all[k]); });
// a tank that is gone (broken, exploded, replaced) lets its chunks go: checked once a minute where its chunk is loaded
RPG.every(1200, function () {
    var all = RI.enderLoaders(), changed = false;
    for (var k in all) {
        var e = all[k];
        if (!RPG.world.isLoaded || !RPG.world.isLoaded(e.dim, e.x, e.z)) continue;
        var b = RPG.blocks.entityAt(e.dim, e.x, e.y, e.z);
        if (!b || b.key !== "ri_ender_tank") { RPG.world.releaseForced(k); delete all[k]; changed = true; }
    }
    if (changed) RPG.data.set(RI.ENDER_LOAD, all);
});
RPG.on("blockBreak", function (p, block, x, y, z, dim) {
    if (block !== RI.blocks.ri_ender_tank) return;
    var k = RI.enderLoadKey(dim, x, y, z), all = RI.enderLoaders();
    if (all[k]) { RPG.world.releaseForced(k); delete all[k]; RPG.data.set(RI.ENDER_LOAD, all); }
});
