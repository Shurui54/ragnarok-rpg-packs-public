// =====================================================================================
//  Ragnarok Industry - power banks. Touching banks become one bank (engine: blockEntity.energy.connect), like tanks:
//  capacities add up, energy goes in on any face and out of faces switched to "out" (wrench or sneak-use), and each
//  block adds its own input and output rate. They are engine "io" family blocks (six faces in | out | off and a fill
//  level 0-3, built in): no restart. The engine keeps the faces, the fill level and the comparator; scripts only
//  draw the screen.
// =====================================================================================
RI.BANK = [null,
    { cap: 1000000, io: 2000 },
    { cap: 8000000, io: 8000 },
    { cap: 64000000, io: 32000 },
    { cap: 256000000, io: 128000 }];
RI.BANK_IDS = {};
// banks have no onTick (a 512-block bank would run 512 scripts): open bank screens are refreshed here twice a second
RI.bankScreens = {};
RPG.every(10, function () {
    for (var k in RI.bankScreens) {
        if (!RI.open[k]) { delete RI.bankScreens[k]; continue; }
        RI.refresh(RI.bankScreens[k]);
    }
});
RI.BANK_FACES = ["in", "out", "off"];

// Wrench / sneak-use on a bank: the face pointed at goes in -> out -> off.
RI.bankWrench = function (player, x, y, z) {
    var d = player.dimension, id = RPG.world.getBlock(d, x, y, z);
    if (!RI.BANK_IDS[String(id).replace(/\[.*$/, "")]) return false;
    var be = RI.be(player, x, y, z), face = be ? be.sideAt(player) : null;
    if (!face) return true;
    var cur = RPG.world.blockProperty(d, x, y, z, face) || "in";
    var next = RI.BANK_FACES[(RI.BANK_FACES.indexOf(cur) + 1) % 3];
    RPG.world.setBlockProperty(d, x, y, z, face, next);
    player.actionbar("&7" + face.charAt(0).toUpperCase() + face.slice(1) + ": " + (next === "in" ? "&aIn" : next === "out" ? "&6Out" : "&cOff"));
    player.playSound("minecraft:block.lever.click", 0.5, next === "off" ? 0.7 : 1.2);
    return true;
};

for (var bkt = 1; bkt <= 4; bkt++) (function (t) {
    var b = RI.BANK[t];
    var id = RI.block("ri_power_bank_" + t, {
        family: "io", name: riTitle(t, "Power Bank"), blockstate: RI.NS + ":power_bank_" + t, itemModel: RI.NS + ":rpg/item/power_bank_" + t,
        hardness: 3.5, explosionResistance: 8, tool: "pickaxe", tier: "stone", requiresTool: false, sound: "metal", drops: "self",
        lore: ["&7Stores &f" + RI.fmt(b.cap) + " RE&7, &f" + RI.fmt(b.io) + " RE/t &7in and out.",
               "&7Touching banks become one bank (up to 512):", "&7capacities and rates add up.",
               "&7Takes energy on every face; wrench a face to &6out&7 or &coff&7.", "&7Keeps its share of the charge when broken."],
        useWith: ["empty"],
        blockEntity: {
            inventory: { size: 0, keepContents: true },
            comparator: "energy",
            energy: { capacity: b.cap, maxInput: b.io, maxOutput: b.io, push: true, connect: "ri_bank", stateFaces: true, levelProperty: "level" }
        },
        onPlace: function (p, x, y, z) {
            RI.claimOwner(p, x, y, z);
            var be = RI.be(p, x, y, z);
            if (be && be.energyGroupSize >= 512) p.tell("&eThis bank is at its limit of 512 blocks: the new one stays separate.");
        },
        onUse: function (p, x, y, z) {
            if (p.isSneaking()) { RI.bankWrench(p, x, y, z); return; }
            var be = RI.be(p, x, y, z);
            if (!be) return;
            var spec = { title: RI.gui(riTitle(t, "Power Bank")), slots: [], height: 186, inventory: { y: 104, labelY: 93 },
                gauges: [RI.ENERGY_GAUGE(152, 17)],
                buttons: [RI.btn("stored", "", 8, 18, 138, ["Energy in the whole bank"]),
                          RI.btn("in", "", 8, 34, 138, ["Energy that came in last tick", "(the bank takes up to its input rate)"]),
                          RI.btn("out", "", 8, 50, 138, ["Energy that went out of the out faces last tick"]),
                          RI.btn("size", "", 8, 66, 138, ["Blocks in this bank: rates add up per block"])] };
            RI.bankScreens[RI.posKey(be)] = be;
            RI.track(be, p, be.open(p, spec), function (e, bn) {
                var n = Math.max(1, e.energyGroupSize);
                bn.button("stored", { text: "&f" + RI.fmt(e.energy) + " &7/ " + RI.fmt(e.energyCapacity) + " RE", enabled: false });
                bn.button("in", { text: "&aIn: &f" + RI.fmt(e.energyIn) + " &7/ " + RI.fmt(b.io * n) + " RE/t", enabled: false });
                bn.button("out", { text: "&6Out: &f" + RI.fmt(e.energyOut) + " &7/ " + RI.fmt(b.io * n) + " RE/t", enabled: false });
                bn.button("size", { text: "&7Blocks: &f" + n, enabled: false });
            });
        }
    });
    RI.BANK_IDS[id] = true;
})(bkt);
