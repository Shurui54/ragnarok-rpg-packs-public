# Ragnarok Ambience

Ragnarok Ambience is an addon for the Ragnarok Modding Toolkit. It is its own work, **inspired by and porting** two
open-source Minecraft mods to the toolkit's script API (`RPG.audio`). It is not either mod and is not made or endorsed
by their authors.

## Ambient Sounds (LGPL-3.0)

- Ambient Sounds by **CreativeMD**, https://github.com/CreativeMD/AmbientSounds, licensed under the GNU Lesser General
  Public License v3.0 (LGPL-3.0-only).
- Ported here (as scripts and data, combined into this GPL-3.0 work as the LGPL allows):
  - `client/scripts/00_as_data.js`: the "basic" engine's data (engine settings, dimensions, regions, sound categories,
    sound collections, features and block groups), converted from its JSON by `tools/ambience_port.py` in the
    toolkit. Sound ids now point at this addon's own sounds; the two wolf events use the game's wolf howl.
  - `client/scripts/20_ambient_engine.js`: its engine (AmbientEngine, AmbientCondition, AmbientSelection,
    AmbientSound, AmbientRegion, AmbientDimension, AmbientSoundCategory, AmbientTime, AmbientFeatureSelection,
    AirPocket, AmbientSoundEngine) rewritten in JavaScript with the same behaviour and numbers. The air pocket
    scanner, biome sampling and height scan it relies on are generic toolkit services (`RPG.audio.ambience.scan`,
    `biomes`, `heights`), written for the toolkit.
- **Not used: its sound files.** Its recordings are not redistributed: most carry Pixabay credits (the Pixabay
  Content License forbids redistributing the files on their own, which an asset pack would do), and the others have no
  recorded source or licence (wind, water, caves, owls, crows, gulls, frogs, crickets, birds, the Nether bed credited to
  a freesound.org user without the original page or licence). Every sound this addon plays was synthesized for it
  instead (see the ambiencepack's NOTICE.md) or is one of the game's own.

## Sound Physics Remastered (GPL-3.0)

- Sound Physics Remastered by **henkelmax** (Max Henkel), https://github.com/henkelmax/sound-physics-remastered,
  licensed under the GNU General Public License v3.0; itself a fork of Sound Physics Fabric by vlad2305m and Sound
  Physics by Sonic Ether.
- Ported here: `client/scripts/10_sound_physics.js` sets the toolkit's sound physics to its model and default
  settings: ray and bounce counts, the four reverb settings (ReverbParams), how a bounce's delay picks a reverb slot,
  bounce energy, shared airspace weights, occlusion (paths, variation, caps, partial-block factor, exp cutoff),
  underwater filtering, air absorption, and its reflectivity and occlusion tables by block sound type.
- The tracing, EFX reverb slots and filters themselves are the toolkit's own engine code (closed source, written
  independently); this addon only supplies the numbers.

## This addon

- Copyright (c) Ragnarok Studios. Licensed under the GNU General Public License v3.0 or later (see `LICENSE`).
  Its scripts are its complete source code.
- Sounds: the "ambiencepack" art pack (downloaded in game when a world uses this addon), made by
  `tools/ambiencepack_sounds.py` in the toolkit from numpy-synthesized noise and oscillators; no recordings.
