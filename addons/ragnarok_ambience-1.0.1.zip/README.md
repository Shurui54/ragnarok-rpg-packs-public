# Ragnarok Ambience

Soundscapes and sound physics for Ragnarok worlds.

- **Soundscapes** that follow where you are: birds by day and owls and crickets by night in forests, wind on plains,
  deserts, mesas, snow and mountains, waves on beaches and oceans, frogs and insects in swamps and jungles, rain and
  storms near and far, cave air, drips and deep rumble underground, the deep dark, the Nether and the End. Each sound
  fades in and out with biome, time of day, weather, height, light and the space around you (an air scan finds open
  sky, caves, lush caves, dripstone, water and trees nearby).
- **Sound physics**: reverb from the blocks around each sound (stone rings, wool swallows), sounds muffled through
  walls, muffled hearing under water, rain dulled from under a roof.

Enable it per world in the addon picker. The first time, the game offers to download its sound pack (ambiencepack,
about 3 MB).

Settings (operators): `/rpg config ragnarok_ambience` — overall volume, birds, insects, animals, wind, water,
weather, caves, suspense, rain muffling, sound physics on or off, reverb and occlusion strength. Each player can turn
sound physics and ambience off or down in K > Sound physics & ambience.

Credits and licences: see NOTICE.md. GPL-3.0-or-later.
