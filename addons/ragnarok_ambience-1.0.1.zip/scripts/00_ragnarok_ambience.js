// =====================================================================================
//  Ragnarok Ambience (server side): asks players for the ambiencepack sounds and keeps the world's settings.
//  The soundscapes and the sound physics run on each player's computer (client/scripts/).
// =====================================================================================
RPG.project.configure({ assetPacks: ["ambiencepack@1.0.0"] });

var RAGNAROK_AMBIENCE_CFG = RPG.config.define("ragnarok_ambience", {
    enabled: { default: true, client: true, comment: "Play the soundscapes (players can still turn Ambience off in their own settings)" },
    volume: { default: 1, min: 0, max: 1, client: true, comment: "Overall soundscape volume" },
    birds: { default: 1, min: 0, max: 1, client: true, comment: "Birds (day and night)" },
    insects: { default: 1, min: 0, max: 1, client: true, comment: "Crickets and cicadas" },
    animals: { default: 1, min: 0, max: 1, client: true, comment: "All animals (birds, insects, frogs, owls, wolves, gulls...)" },
    wind: { default: 1, min: 0, max: 1, client: true, comment: "Wind" },
    water: { default: 1, min: 0, max: 1, client: true, comment: "Ocean, beach and underwater" },
    weather: { default: 1, min: 0, max: 1, client: true, comment: "Rain and storms" },
    caves: { default: 1, min: 0, max: 1, client: true, comment: "Caves: drips, rumble, echoes" },
    suspense: { default: 1, min: 0, max: 1, client: true, comment: "Nether and End drones" },
    rainMuffle: { default: true, client: true, comment: "Rain and storms sound muffled from under a roof (needs sound physics)" },
    soundPhysics: { default: true, client: true, comment: "Sound physics: reverb in caves and halls, sounds muffled through walls" },
    reverb: { default: 1, min: 0, max: 2, client: true, comment: "Reverb strength (players can lower it in their own settings)" },
    occlusion: { default: 1, min: 0, max: 2, client: true, comment: "How much walls muffle sounds" }
});
