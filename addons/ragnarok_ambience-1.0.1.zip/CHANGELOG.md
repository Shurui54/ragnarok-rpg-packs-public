# Ragnarok Ambience changelog

## 1.0.1 (2026-11-18)
- Soundscapes no longer lag behind the camera when you turn or walk (they play listener-relative; needs engine 0.29.1).
- Rain and storm sounds follow the Weather volume slider; everything else follows Ambient/Environment (both with Master).

## 1.0.0 (2026-11-18)
- First release: Ambient Sounds' soundscape engine and data and Sound Physics Remastered's tuning, ported to the
  toolkit's RPG.audio API, with synthesized sounds (ambiencepack 1.0.0).
