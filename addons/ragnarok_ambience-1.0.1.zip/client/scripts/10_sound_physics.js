// =====================================================================================
//  Ragnarok Ambience: sound physics tuning
//  The numbers of Sound Physics Remastered (https://github.com/henkelmax/sound-physics-remastered, GPL-3.0, by
//  henkelmax, a fork of Sound Physics by Sonic Ether and Sound Physics Fabric by vlad2305m) with its default
//  settings, applied to the toolkit's sound physics (RPG.audio.physics):
//    - 32 rays per sound with 4 bounces each, up to 256 blocks; every sound traced from its own position;
//    - four EAX reverb slots (0.15 s, 0.55 s, 1.68 s, 4.14 s decay; SoundPhysicsMod's ReverbParams), a bounce's delay
//      (path length x 0.12 x reflectivity) choosing between them, energy 0.25 x (reflectivity x 0.75 + 0.25);
//    - shared airspace (bounce points that see the listener) letting reverb and some dry sound round corners;
//    - occlusion summed per block along nine paths (+-0.35, block sounds +-0.49) and the clearest kept, capped at 64,
//      blocks that aren't full cubes count x0.25; direct cutoff exp(-occlusion x 3), gain cutoff^0.1;
//    - underwater: dry cutoff x0.1 (filter 0.9), reverb cutoff x0.4; air absorption 1;
//    - its reflectivity and occlusion tables by block sound type (stone 1.5, wool 0.1 / 1.5 ...);
//    - ambient sounds ("ambient.*" ids, like the game's cave sounds) and music discs left dry, like its defaults.
//  The world's settings scale reverb and occlusion; each player's own Sound physics settings scale them again.
// =====================================================================================
(function () {
    if (!RPG.audio || !RPG.audio.physics) return;

    function cfg(key, d) {
        try { var v = RPG.config.get("ragnarok_ambience", key, d); return v === undefined || v === null ? d : v; } catch (e) { return d; }
    }

    // ReverbParams.getReverb0..3: gain x globalReverbMultiplier (0.7 x reverb_gain 1) x 0.85, brightness 1, attenuation factor 1
    var G = 0.7 * 1.0 * 0.85;
    RPG.audio.preset("spr_reverb0", { decay: 0.15, density: 0, diffusion: 1, gain: 0.2 * G, gainHF: 0.99, decayHFRatio: 0.6, reflectionsGain: 2.5,
        reflectionsDelay: 0.001, lateGain: 1.26, lateDelay: 0.011, airAbsorptionHF: 0.994, roomRolloff: 0.16 });
    RPG.audio.preset("spr_reverb1", { decay: 0.55, density: 0, diffusion: 1, gain: 0.3 * G, gainHF: 0.99, decayHFRatio: 0.7, reflectionsGain: 0.2,
        reflectionsDelay: 0.015, lateGain: 1.26, lateDelay: 0.011, airAbsorptionHF: 0.994, roomRolloff: 0.15 });
    RPG.audio.preset("spr_reverb2", { decay: 1.68, density: 0.1, diffusion: 1, gain: 0.5 * G, gainHF: 0.99, decayHFRatio: 0.7, reflectionsGain: 0,
        reflectionsDelay: 0.021, lateGain: 1.26, lateDelay: 0.021, airAbsorptionHF: 0.994, roomRolloff: 0.13 });
    RPG.audio.preset("spr_reverb3", { decay: 4.142, density: 0.5, diffusion: 1, gain: 0.4 * G, gainHF: 0.89, decayHFRatio: 0.7, reflectionsGain: 0,
        reflectionsDelay: 0.025, lateGain: 1.26, lateDelay: 0.021, airAbsorptionHF: 0.994, roomRolloff: 0.11 });

    // ReflectivityConfig / OcclusionConfig defaults (by block sound type; a few blocks by id)
    var REFLECT = { stone: 1.5, netherite_block: 1.5, tuff: 1.5, amethyst: 1.5, basalt: 1.5, calcite: 1.5, bone_block: 1.5, copper: 1.25,
        deepslate: 1.5, deepslate_bricks: 1.5, deepslate_tiles: 1.5, polished_deepslate: 1.5, nether_bricks: 1.5, netherrack: 1.1,
        nether_gold_ore: 1.1, nether_ore: 1.1, stem: 0.4, wool: 0.1, honey_block: 0.1, moss: 0.1, soul_sand: 0.2, soul_soil: 0.2,
        coral_block: 0.2, metal: 1.25, wood: 0.4, gravel: 0.3, grass: 0.3, glass: 0.75, sand: 0.2, snow: 0.15 };
    var OCCLUDE = { wool: 1.5, moss: 0.75, honey_block: 0.5, glass: 0.1, snow: 0.1, powder_snow: 0.1, bamboo: 0.1, bamboo_sapling: 0.1,
        wet_grass: 0.1, moss_carpet: 0.1, weeping_vines: 0, twisting_vines: 0, vine: 0, sweet_berry_bush: 0, spore_blossom: 0,
        small_dripleaf: 0, roots: 0, pointed_dripstone: 0, scaffolding: 0, glow_lichen: 0, crop: 0, fungus: 0, lily_pad: 0,
        large_amethyst_bud: 0, medium_amethyst_bud: 0, small_amethyst_bud: 0, ladder: 0, chain: 0,
        "minecraft:water": 0.25, "minecraft:lava": 0.75, "minecraft:jukebox": 0 };
    // the engine's own material defaults are replaced: every type the original lists at the default gets the default
    var ALL_TYPES = ["wood", "gravel", "grass", "lily_pad", "stone", "metal", "glass", "wool", "sand", "snow", "powder_snow", "ladder", "anvil",
        "slime_block", "honey_block", "wet_grass", "coral_block", "bamboo", "bamboo_sapling", "scaffolding", "sweet_berry_bush", "crop",
        "hard_crop", "vine", "nether_wart", "lantern", "stem", "nylium", "fungus", "roots", "shroomlight", "weeping_vines", "twisting_vines",
        "soul_sand", "soul_soil", "basalt", "wart_block", "netherrack", "nether_bricks", "nether_sprouts", "nether_ore", "bone_block",
        "netherite_block", "ancient_debris", "lodestone", "chain", "nether_gold_ore", "gilded_blackstone", "candle", "amethyst",
        "amethyst_cluster", "small_amethyst_bud", "medium_amethyst_bud", "large_amethyst_bud", "tuff", "calcite", "dripstone_block",
        "pointed_dripstone", "copper", "cave_vines", "spore_blossom", "azalea", "flowering_azalea", "moss_carpet", "moss", "big_dripleaf",
        "small_dripleaf", "rooted_dirt", "hanging_roots", "azalea_leaves", "sculk_sensor", "sculk_catalyst", "sculk", "sculk_vein",
        "sculk_shrieker", "glow_lichen", "deepslate", "deepslate_bricks", "deepslate_tiles", "polished_deepslate", "froglight", "frogspawn",
        "mangrove_roots", "muddy_mangrove_roots", "mud", "mud_bricks", "packed_mud"];
    var reflectivity = {}, occlusionFactors = {}, i, k;
    for (i = 0; i < ALL_TYPES.length; i++) { reflectivity[ALL_TYPES[i]] = 0.5; occlusionFactors[ALL_TYPES[i]] = 1; }
    for (k in REFLECT) reflectivity[k] = REFLECT[k];
    for (k in OCCLUDE) occlusionFactors[k] = OCCLUDE[k];

    function apply() {
        if (!cfg("soundPhysics", true)) { RPG.audio.off(); return; }
        RPG.audio.physics({
            reverb: Number(cfg("reverb", 1)), occlusion: Number(cfg("occlusion", 1)),
            rays: 32, bounces: 4, maxDistance: 256, perSource: true, environmentTicks: 5, sourceTicks: 0, raysPerTick: 1400,
            slots: ["spr_reverb0", "spr_reverb1", "spr_reverb2", "spr_reverb3"], sendOrder: [3, 2, 1, 0],
            slotCentres: [0, 1, 2, 3], delayScale: 0.12, slotGains: [6.4, 12.8, 12.8, 12.8], slotBounceExponents: [0, 1, 3, 4],
            slotOffsets: [0, 0, 0.05, 0.05], energy: [0.25, 0.75, 0.25], minReverbPath: 0,
            airspaceScale: 64, airspaceDivisors: [20, 15, 10, 10], reverbDistance: 1.5,
            absorption: 3, gainExponent: 0.1, variation: 0.35, blockVariation: 0.49, maxOcclusionBlocks: 16, maxOcclusion: 64,
            partialBlockFactor: 0.25, airspaceDirectFloor: 0.2, underwater: 0.9, underwaterSend: 0.4, airAbsorption: 1,
            excludeCategories: ["music", "record"], excludeIds: ["*:ambient.*"], excludeRelative: true,
            defaultReflectivity: 0.5, defaultOcclusion: 1, reflectivity: reflectivity, occlusionFactors: occlusionFactors
        });
    }
    apply();
    RPG.on("config", function (name) { if (String(name) === "ragnarok_ambience") apply(); });
})();
