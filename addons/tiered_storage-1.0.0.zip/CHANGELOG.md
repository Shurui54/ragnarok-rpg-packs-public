# Changelog

## 1.0.0 (2026-11-25)

- First release: chests by tier (Copper 45 slots, Iron 54, Gold 81, Diamond 108, Crystal 108 showing its most plentiful items through the glass, Obsidian 108 and blast resistant, Netherite 126 and blast resistant, and a 1-slot Dirt Chest).
- Furnaces, blast furnaces and smokers in eight tiers (Copper 1.11x, Iron 1.25x, Gold 1.67x, Diamond 2.5x, Emerald 5x, Obsidian 6.67x, Crystal 10x, Netherite 40x vanilla speed), the same fuel per item as vanilla, smelting only what the vanilla block of their kind takes.
- Upgrade kits for chests (wooden to copper or iron, copper to iron, iron to gold, gold to diamond, diamond to crystal, obsidian or netherite) and furnaces (one per tier, keeping the kind): right-click a placed block to upgrade it in place, keeping its contents, fuel and progress.
- Vanilla screens (chest, furnace, blast furnace, smoker), hoppers from every side like vanilla, comparator output, original art for every tier.
