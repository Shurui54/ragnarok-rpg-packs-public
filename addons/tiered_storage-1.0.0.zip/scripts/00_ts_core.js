// =====================================================================================
//  Upgraded Chests & Furnaces - shared tables and helpers.
//  Chests: bigger inventories by tier (copper 45 ... netherite 126), upgraded in place with kits.
//  Furnaces, blast furnaces and smokers: faster by tier, same fuel use per item as vanilla, upgraded in place.
//  All content (names, art, numbers) is this addon's own.
// =====================================================================================
var TS = {
    NS: "tiered_storage",
    blocks: {},          // script key -> full block id
    items: {},           // script key -> full item id
    chestByBlock: {},    // full block id -> chest tier key
    furnaceByBlock: {},  // full block id -> { tier, kind }
    probe: null          // any live furnace block entity: asks the platform for burn times (be.fuelTicks)
};

TS.tex = function (name) { return TS.NS + ":block/" + name; };
TS.model = function (name) { return TS.NS + ":rpg/block/" + name; };

TS.block = function (key, def) {
    var id = "ragnarok_rpg:" + RPG.blocks.define(key, def);
    TS.blocks[key] = id;
    return id;
};

TS.item = function (key, def) {
    if (!def.type) def.type = "material";
    var id = "ragnarok_rpg:" + RPG.items.define(key, def);
    TS.items[key] = id;
    return id;
};

TS.fmt = function (n) {
    var s = String(Math.round(n));
    return s.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
};

// Turns a block in place, keeping the way it faces. Returns the new block's block entity (or null).
TS.replaceBlock = function (dim, x, y, z, newId) {
    var facing = RPG.world.blockProperty(dim, x, y, z, "facing");
    if (facing === "up" || facing === "down") facing = null;
    RPG.world.setBlock(dim, x, y, z, facing ? newId + "[facing=" + facing + "]" : newId);
    return RPG.blocks.entityAt(dim, x, y, z);
};

TS.sound = function (dim, x, y, z, id, vol, pitch) {
    RPG.world.sound(dim, id, x + 0.5, y + 0.5, z + 0.5, vol || 0.5, pitch || 1);
};

// Uses up one of the held item (not in creative).
TS.useHeld = function (player) {
    if (player.getGameMode() === "creative") return;
    var held = player.getHeldStack();
    if (!held) return;
    held.count -= 1;
    player.setHeldStack(held.count > 0 ? held : null);
};
