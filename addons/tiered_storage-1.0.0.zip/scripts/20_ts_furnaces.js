// =====================================================================================
//  Upgraded Chests & Furnaces - furnaces, blast furnaces and smokers by tier.
//  Each tier runs the vanilla furnace faster: a furnace smelts in 200 / speed ticks, a blast furnace or smoker in
//  100 / speed, and fuel burns faster by the same factor, so one coal still smelts 8 items (4 in a blast furnace or
//  smoker's half-length burn, like vanilla). They smelt what the vanilla block of their kind accepts (the game's own
//  smelting, blasting and smoking recipes, other mods' and data packs' included) and burn what vanilla burns.
//  Slots: 0 input, 1 fuel, 2 output. Hoppers: input from above, fuel from the sides, output from below (like vanilla).
// =====================================================================================
TS.FURNACES = {
    copper:    { name: "Copper",    ticks: 180, blast: 6,    hardness: 3.5, sound: "copper" },
    iron:      { name: "Iron",      ticks: 160, blast: 6,    hardness: 3.5, sound: "metal" },
    gold:      { name: "Gold",      ticks: 120, blast: 6,    hardness: 3.5, sound: "metal" },
    diamond:   { name: "Diamond",   ticks: 80,  blast: 6,    hardness: 4,   sound: "metal" },
    emerald:   { name: "Emerald",   ticks: 40,  blast: 6,    hardness: 4,   sound: "metal" },
    obsidian:  { name: "Obsidian",  ticks: 30,  blast: 1200, hardness: 12,  sound: "stone" },
    crystal:   { name: "Crystal",   ticks: 20,  blast: 6,    hardness: 4,   sound: "glass" },
    netherite: { name: "Netherite", ticks: 5,   blast: 1200, hardness: 12,  sound: "netherite_block" }
};
TS.FURNACE_ORDER = ["copper", "iron", "gold", "diamond", "emerald", "obsidian", "crystal", "netherite"];
// recipe: the vanilla recipe type it smelts; base: vanilla's ticks per item; fuelDiv: vanilla's burn time divider
TS.KINDS = {
    furnace:       { name: "Furnace",       recipe: "smelting", base: 200, fuelDiv: 1, screen: "furnace",       vanilla: "minecraft:furnace" },
    blast_furnace: { name: "Blast Furnace", recipe: "blasting", base: 100, fuelDiv: 2, screen: "blast_furnace", vanilla: "minecraft:blast_furnace" },
    smoker:        { name: "Smoker",        recipe: "smoking",  base: 100, fuelDiv: 2, screen: "smoker",        vanilla: "minecraft:smoker" }
};
TS.KIND_ORDER = ["furnace", "blast_furnace", "smoker"];
TS.FURNACE_STEP = 5;   // onTick runs every 5 ticks and catches up the whole step at once

TS.furnaceKey = function (tier, kind) { return "ts_" + tier + "_" + kind; };
TS.speed = function (tier) { return 200 / TS.FURNACES[tier].ticks; };

// ---- recipes and fuels -------------------------------------------------------------------------------------------
// The result of an item in a recipe type, from the game's recipe list (cached per load: the lookup costs more than
// the whole tick). null: no such recipe.
TS.resultCache = { smelting: {}, blasting: {}, smoking: {} };
TS.result = function (type, id) {
    var cache = TS.resultCache[type];
    if (cache[id] !== undefined) return cache[id];
    var found = null, uses = RPG.recipes.uses(id);
    for (var i = 0; i < uses.length && !found; i++) if (uses[i].type === type) found = uses[i].result;
    cache[id] = found;
    return found;
};

// Vanilla burn time (any mod's fuels too, through the platform), asked of a furnace block entity and cached.
TS.fuelCache = {};
TS.burnTicks = function (be, id) {
    var t = TS.fuelCache[id];
    if (t === undefined) {
        var probe = be || (TS.probe && TS.probe.valid ? TS.probe : null);
        if (!probe) return -1;   // unknown yet
        t = TS.fuelCache[id] = probe.fuelTicks(id);
    }
    return t;
};

// Experience per item, as the vanilla recipes give it (the recipe list doesn't carry it; anything else gets 0.1).
TS.XP = { "minecraft:iron_ingot": 0.7, "minecraft:gold_ingot": 1, "minecraft:copper_ingot": 0.7, "minecraft:netherite_scrap": 2,
          "minecraft:diamond": 1, "minecraft:emerald": 1, "minecraft:lapis_lazuli": 0.2, "minecraft:redstone": 0.7,
          "minecraft:coal": 0.1, "minecraft:quartz": 0.2, "minecraft:charcoal": 0.15, "minecraft:sponge": 0.15,
          "minecraft:green_dye": 1, "minecraft:lime_dye": 0.1, "minecraft:brick": 0.3, "minecraft:nether_brick": 0.1,
          "minecraft:terracotta": 0.35, "minecraft:cooked_beef": 0.35, "minecraft:cooked_porkchop": 0.35,
          "minecraft:cooked_chicken": 0.35, "minecraft:cooked_mutton": 0.35, "minecraft:cooked_rabbit": 0.35,
          "minecraft:cooked_cod": 0.35, "minecraft:cooked_salmon": 0.35, "minecraft:baked_potato": 0.35,
          "minecraft:dried_kelp": 0.1, "minecraft:popped_chorus_fruit": 0.1 };
TS.xpFor = function (id) { return TS.XP[id] !== undefined ? TS.XP[id] : 0.1; };

// ---- the machine -------------------------------------------------------------------------------------------------
// The lit front (and its light) follows the fire. A freshly placed block starts lit by default, so the first tick
// sets it either way.
TS.setLit = function (be, lit) {
    be.data.lit = lit;
    RPG.world.setBlockProperty(be.dimension, be.x, be.y, be.z, "lit", lit);
};

TS.canSmelt = function (res, out) {
    return !!res && (!out || (out.id === res.id && out.count + res.count <= 64));
};

TS.furnaceTick = function (be, tier, kind) {
    TS.probe = be;
    var K = TS.KINDS[kind], d = be.data;
    var input = be.get(0);
    var burning = d.burn > 0;
    if (!burning && !input && !(d.cook > 0)) {
        if (d.lit !== false) { TS.setLit(be, false); be.setBurn(0, 0); be.setProgress(0); be.save(); }
        return;
    }
    var out = be.get(2);
    var res = input ? TS.result(K.recipe, input.id) : null;
    var budget = TS.FURNACE_STEP * TS.speed(tier);      // vanilla ticks to run this step
    var changed = false, guard = 0;
    while (budget > 1e-6 && guard++ < 128) {
        var can = TS.canSmelt(res, out);
        if (!(d.burn > 0)) {
            if (!can) break;
            var fuel = be.get(1);
            var t = fuel ? TS.burnTicks(be, fuel.id) / K.fuelDiv : 0;
            if (!(t > 0)) break;
            if (fuel.id === "minecraft:lava_bucket") be.set(1, "minecraft:bucket");
            else be.take(1, 1);
            d.burn = t; d.burnTotal = t;
            changed = true;
        }
        var step = Math.min(budget, d.burn);
        if (can) step = Math.min(step, K.base - (d.cook || 0));
        d.burn -= step; budget -= step; changed = true;
        if (can) {
            d.cook = (d.cook || 0) + step;
            if (d.cook >= K.base - 1e-6) {
                d.cook = 0;
                be.take(0, 1);
                be.set(2, { id: res.id, count: (out ? out.count : 0) + res.count });
                d.xp = (d.xp || 0) + TS.xpFor(res.id) * res.count;
                d.made = (d.made || 0) + res.count;
                input = be.get(0); out = be.get(2);
                res = input ? TS.result(K.recipe, input.id) : null;
            }
        } else d.cook = 0;
        if (d.burn < 1e-6) d.burn = 0;
    }
    // not burning: the progress cools down like vanilla's (2 per tick)
    if (!(d.burn > 0) && d.cook > 0 && budget > 0) { d.cook = Math.max(0, d.cook - 2 * budget); changed = true; }
    var lit = d.burn > 0;
    if (lit !== d.lit) { TS.setLit(be, lit); changed = true; }
    be.setProgress((d.cook || 0) / K.base);
    be.setBurn(Math.ceil(d.burn || 0), Math.ceil(d.burnTotal || 0));
    if (changed) be.save();
};

// The screen: the vanilla furnace / blast furnace / smoker screen with its flame and arrow.
TS.openFurnace = function (player, x, y, z, tier, kind) {
    var be = RPG.blocks.entityAt(player.dimension, x, y, z);
    if (!be) return;
    TS.probe = be;
    var K = TS.KINDS[kind], last = be.get(2);
    var lastCount = last ? last.count : 0;
    var payXp = function (p) {
        var cur = be.get(2), count = cur ? cur.count : 0;
        if (count < lastCount && be.data.xp > 0) {
            // like vanilla: the stored experience goes to the player who takes from the output
            var whole = Math.floor(be.data.xp), frac = be.data.xp - whole;
            if (Math.random() < frac) whole++;
            be.data.xp = 0;
            be.save();
            if (whole > 0) RPG.world.dropXp(p.dimension, p.x, p.y + 0.5, p.z, whole);
        }
        lastCount = count;
    };
    be.open(player, {
        title: TS.FURNACES[tier].name + " " + K.name,
        background: K.screen,
        slots: [{ x: 56, y: 17 }, { x: 56, y: 53 }, { x: 116, y: 35 }],
        gauges: [{ type: "burn", x: 56, y: 36 }, { type: "progress", x: 79, y: 34 }],
        onChange: function (p) { payXp(p); },
        onClose: function (p) { payXp(p); }
    });
};

// What automation and screens may put in: anything in the input, fuels (and empty buckets) in the fuel slot, nothing
// in the output.
TS.furnaceAccepts = function (slot, id) {
    if (slot === 0) return true;
    if (slot === 2) return false;
    if (id === "minecraft:bucket") return true;
    var t = TS.burnTicks(null, id);
    return t !== 0;
};

TS.FURNACE_ORDER.forEach(function (tier) {
    var F = TS.FURNACES[tier];
    TS.KIND_ORDER.forEach(function (kind) {
        var K = TS.KINDS[kind];
        var key = TS.furnaceKey(tier, kind);
        var secs = K.base / TS.speed(tier) / 20;
        var lore = ["&7" + (Math.round(TS.speed(tier) * 100) / 100) + "x vanilla speed: " + (Math.round(secs * 100) / 100) + " s per item",
                    "&7Smelts what a " + K.name.toLowerCase() + " smelts, burns the same fuels"];
        if (F.blast >= 1200) lore.push("&7Blast resistant");
        var p = tier + "_" + kind + "_";
        var id = TS.block(key, {
            family: "machine", name: F.name + " " + K.name,
            textures: { front: TS.tex(p + "front"), front_on: TS.tex(p + "front_on"), side: TS.tex(p + "side"), top: TS.tex(p + "top") },
            hardness: F.hardness, explosionResistance: F.blast, tool: "pickaxe", sound: F.sound, drops: "self", lore: lore,
            blockEntity: {
                inventory: { size: 3, accepts: TS.furnaceAccepts, inputs: [0, 1], outputs: [2],
                             sides: { up: [0], side: [1], down: [2] } },
                tickInterval: TS.FURNACE_STEP,
                // no tanks: an empty list gives the block the engine's machine part, which knows every fuel's burn time
                tanks: [],
                onTick: function (be) { TS.furnaceTick(be, tier, kind); }
            },
            onPlace: function (player, x, y, z) {
                var be = RPG.blocks.entityAt(player.dimension, x, y, z);
                if (be) { TS.probe = be; TS.setLit(be, false); be.save(); }
            },
            onUse: function (player, x, y, z) {
                if (TS.tryFurnaceUpgrade && TS.tryFurnaceUpgrade(player, x, y, z)) return;
                TS.openFurnace(player, x, y, z, tier, kind);
            }
        });
        TS.furnaceByBlock[id] = { tier: tier, kind: kind };
    });
});
