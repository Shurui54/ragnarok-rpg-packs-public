// =====================================================================================
//  Upgraded Chests & Furnaces - upgrade kits: right-click a placed chest or furnace to turn it into the next tier in
//  place. Everything inside stays (and a furnace keeps its burning fuel and cooking progress); the block keeps facing
//  the same way. Vanilla chests (single ones) and vanilla furnaces, blast furnaces and smokers take the first kits.
// =====================================================================================
TS.CHEST_UPGRADES = [
    { from: ["wood"], to: "copper" },
    { from: ["wood"], to: "iron" },
    { from: ["copper"], to: "iron" },
    { from: ["iron"], to: "gold" },
    { from: ["gold"], to: "diamond" },
    { from: ["diamond"], to: "crystal" },
    { from: ["diamond"], to: "obsidian" },
    { from: ["diamond", "crystal", "obsidian"], to: "netherite" }
];
TS.TIER_NAME = { wood: "Wooden", copper: "Copper", iron: "Iron", gold: "Gold", diamond: "Diamond", crystal: "Crystal",
                 obsidian: "Obsidian", netherite: "Netherite", emerald: "Emerald", vanilla: "plain" };
TS.upgradeByItem = {};

TS.chestUpgradeKey = function (u) { return "ts_chest_upgrade_" + u.from[0] + "_" + u.to; };

// Empties a vanilla container after its items were copied, so replacing the block can't drop them a second time:
// takes them through the inventory, then clears its saved item list too (works the same on every loader).
TS.emptyVanilla = function (dim, x, y, z) {
    RPG.world.containerItems(dim, x, y, z, true);
    RPG.world.mergeBlockNbt(dim, x, y, z, "{Items:[]}");
};

// "a plain or Copper", "an Emerald": the tiers a furnace kit takes, for its text.
TS.tierPhrase = function (list) {
    var words = list.map(function (t) { return t === "vanilla" ? "plain" : TS.TIER_NAME[t]; });
    var first = /^[AEIOU]/.test(words[0]) ? "an " : "a ";
    return first + (words.length === 1 ? words[0] : words.slice(0, -1).join(", ") + " or " + words[words.length - 1]);
};

// "a wooden chest", "a Diamond, Crystal or Obsidian Chest": the chests a chest kit takes, for its text.
TS.chestPhrase = function (list) {
    if (list.length === 1 && list[0] === "wood") return "a wooden chest";
    return TS.tierPhrase(list) + " Chest";
};

// ---- chests ------------------------------------------------------------------------------------------------------
TS.chestTierAt = function (dim, x, y, z) {
    var id = RPG.world.getBlock(dim, x, y, z);
    if (id === "minecraft:chest") return "wood";
    return TS.chestByBlock[id] || null;
};

TS.upgradeChest = function (player, x, y, z, u, from) {
    var dim = player.dimension, items = [], i;
    if (from === "wood") {
        if (RPG.world.blockProperty(dim, x, y, z, "type") !== "single") {
            player.actionbar("&cOnly a single chest can be upgraded (break the other half first)");
            return false;
        }
        var n = RPG.world.containerSize(dim, x, y, z);
        for (i = 0; i < n; i++) items.push(RPG.world.containerSlot(dim, x, y, z, i));
        TS.emptyVanilla(dim, x, y, z);
    } else {
        var old = RPG.blocks.entityAt(dim, x, y, z);
        if (!old) return false;
        items = old.items();
        old.clear();
        if (from === "crystal") TS.crystalClear(dim, x, y, z);
    }
    var be = TS.replaceBlock(dim, x, y, z, TS.blocks["ts_" + u.to + "_chest"]);
    var lost = [];
    for (i = 0; i < items.length; i++) {
        if (!items[i]) continue;
        if (be && i < be.size) be.set(i, items[i]);
        else lost.push(items[i]);
    }
    // never happens with the kits above (every tier holds at least as much as the one before), but nothing is lost
    for (i = 0; i < lost.length; i++) RPG.world.dropItem(dim, x + 0.5, y + 1, z + 0.5, lost[i]);
    TS.sound(dim, x, y, z, "minecraft:block.smithing_table.use", 0.8, 1);
    return true;
};

TS.tryChestUpgrade = function (player, x, y, z) {
    var u = TS.upgradeByItem[player.heldItem];
    if (!u || u.kind !== "chest") return false;
    var dim = player.dimension;
    if (!RPG.world.canInteract(player, dim, x, y, z)) return true;
    var from = TS.chestTierAt(dim, x, y, z);
    if (!from || u.from.indexOf(from) < 0) {
        player.actionbar("&cThis kit upgrades " + TS.chestPhrase(u.from) + " only");
        return true;
    }
    if (TS.upgradeChest(player, x, y, z, u, from)) TS.useHeld(player);
    return true;
};

// ---- furnaces ----------------------------------------------------------------------------------------------------
// The kit of a tier upgrades a furnace of the tier before it (any kind, which it keeps); copper and iron kits also
// take vanilla ones.
TS.FURNACE_UPGRADES = TS.FURNACE_ORDER.map(function (tier, n) {
    var from = n === 0 ? ["vanilla"] : n === 1 ? ["vanilla", "copper"] : [TS.FURNACE_ORDER[n - 1]];
    return { from: from, to: tier };
});

TS.furnaceAt = function (dim, x, y, z) {
    var id = RPG.world.getBlock(dim, x, y, z);
    for (var k in TS.KINDS) if (TS.KINDS[k].vanilla === id) return { tier: "vanilla", kind: k };
    return TS.furnaceByBlock[id] || null;
};

TS.snbtNum = function (snbt, key) {
    var m = new RegExp("(?:^|[{,])" + key + ":(-?[0-9.]+)[sbifdL]?").exec(snbt || "");
    return m ? Number(m[1]) : 0;
};

TS.upgradeFurnace = function (player, x, y, z, u, at) {
    var dim = player.dimension, items = [], state = {}, i;
    var K = TS.KINDS[at.kind];
    if (at.tier === "vanilla") {
        for (i = 0; i < 3; i++) items.push(RPG.world.containerSlot(dim, x, y, z, i));
        var nbt = RPG.world.getBlockNbt(dim, x, y, z);
        state.burn = TS.snbtNum(nbt, "BurnTime");
        state.cook = Math.min(K.base - 1, TS.snbtNum(nbt, "CookTime"));
        var fuelTotal = items[1] ? TS.burnTicks(null, items[1].id) / K.fuelDiv : 0;
        state.burnTotal = Math.max(state.burn, fuelTotal > 0 ? fuelTotal : state.burn);
        TS.emptyVanilla(dim, x, y, z);
    } else {
        var old = RPG.blocks.entityAt(dim, x, y, z);
        if (!old) return false;
        items = old.items();
        var d = old.data;
        state = { burn: d.burn || 0, burnTotal: d.burnTotal || 0, cook: d.cook || 0, xp: d.xp || 0, made: d.made || 0 };
        old.clear();
    }
    var be = TS.replaceBlock(dim, x, y, z, TS.blocks[TS.furnaceKey(u.to, at.kind)]);
    if (!be) return false;
    for (i = 0; i < 3; i++) if (items[i]) be.set(i, items[i]);
    var nd = be.data;
    nd.burn = state.burn; nd.burnTotal = state.burnTotal; nd.cook = state.cook; nd.xp = state.xp || 0; nd.made = state.made || 0;
    TS.setLit(be, state.burn > 0);
    be.setProgress(nd.cook / K.base);
    be.setBurn(Math.ceil(nd.burn), Math.ceil(nd.burnTotal));
    be.save();
    TS.sound(dim, x, y, z, "minecraft:block.smithing_table.use", 0.8, 1);
    return true;
};

TS.tryFurnaceUpgrade = function (player, x, y, z) {
    var u = TS.upgradeByItem[player.heldItem];
    if (!u || u.kind !== "furnace") return false;
    var dim = player.dimension;
    if (!RPG.world.canInteract(player, dim, x, y, z)) return true;
    var at = TS.furnaceAt(dim, x, y, z);
    if (!at || u.from.indexOf(at.tier) < 0) {
        player.actionbar("&cThis kit upgrades " + TS.tierPhrase(u.from) + " furnace, blast furnace or smoker only");
        return true;
    }
    if (TS.upgradeFurnace(player, x, y, z, u, at)) TS.useHeld(player);
    return true;
};

// ---- the kit items -----------------------------------------------------------------------------------------------
// The kits work from the item too, so vanilla chests and furnaces (whose own right-click opens them) take them, and so
// does a sneaking right-click on this addon's blocks.
TS.kitUse = function (player, x, y, z) {
    if (TS.tryChestUpgrade(player, x, y, z)) return true;
    if (TS.tryFurnaceUpgrade(player, x, y, z)) return true;
    return false;
};

TS.CHEST_UPGRADES.forEach(function (u) {
    var key = TS.chestUpgradeKey(u);
    var id = TS.item(key, {
        name: TS.TIER_NAME[u.from[0]] + " to " + TS.TIER_NAME[u.to] + " Chest Upgrade",
        model: TS.NS + ":rpg/item/chest_upgrade_" + u.from[0] + "_" + u.to, maxStack: 64,
        lore: ["&7Right-click " + TS.chestPhrase(u.from) + " to make it",
               "&7" + (/^[AEIOU]/.test(TS.TIER_NAME[u.to]) ? "an " : "a ") + TS.TIER_NAME[u.to] + " Chest (" + TS.CHESTS[u.to].slots + " slots), keeping everything in it"],
        onUseOnBlock: function (player, x, y, z) { return TS.kitUse(player, x, y, z); }
    });
    u.kind = "chest"; u.key = key;
    TS.upgradeByItem[id] = u;
});

TS.FURNACE_UPGRADES.forEach(function (u) {
    var key = "ts_furnace_upgrade_" + u.to;
    var id = TS.item(key, {
        name: TS.TIER_NAME[u.to] + " Furnace Upgrade",
        model: TS.NS + ":rpg/item/furnace_upgrade_" + u.to, maxStack: 64,
        lore: ["&7Right-click " + TS.tierPhrase(u.from) + " furnace, blast furnace", "&7or smoker to make it the " + TS.TIER_NAME[u.to] +
               " one (" + (Math.round(TS.speed(u.to) * 100) / 100) + "x speed),", "&7keeping its items, fuel and progress"],
        onUseOnBlock: function (player, x, y, z) { return TS.kitUse(player, x, y, z); }
    });
    u.kind = "furnace"; u.key = key;
    TS.upgradeByItem[id] = u;
});
