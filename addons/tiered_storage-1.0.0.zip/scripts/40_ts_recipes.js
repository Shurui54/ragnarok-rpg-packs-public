// =====================================================================================
//  Upgraded Chests & Furnaces - recipes. Each tier is the one before it surrounded by its material; netherite comes
//  from the smithing table like netherite gear. Every one is a real recipe (the recipe book, JEI and the Recipe
//  Viewer list them).
// =====================================================================================
(function () {
    var R = RPG.recipes, B = TS.blocks, I = TS.items;
    var PLANKS = "#minecraft:planks", LOGS = "#minecraft:logs";
    var TEMPLATE = "minecraft:netherite_upgrade_smithing_template", NETHERITE = "minecraft:netherite_ingot";
    function shaped(id, pattern, keys, result) { R.addShaped("ts_" + id, pattern, keys, { id: result, count: 1 }); }
    function ring(id, material, center, result) { shaped(id, ["MMM", "MCM", "MMM"], { M: material, C: center }, result); }

    // ---- chests
    var chest = function (t) { return B["ts_" + t + "_chest"]; };
    ring("copper_chest", "minecraft:copper_ingot", "minecraft:chest", chest("copper"));
    ring("iron_chest", "minecraft:iron_ingot", "minecraft:chest", chest("iron"));
    ring("iron_chest_from_copper", "minecraft:iron_ingot", chest("copper"), chest("iron"));
    ring("gold_chest", "minecraft:gold_ingot", chest("iron"), chest("gold"));
    shaped("diamond_chest", ["GGG", "DCD", "GGG"], { G: "minecraft:glass", D: "minecraft:diamond", C: chest("gold") }, chest("diamond"));
    ring("crystal_chest", "minecraft:glass", chest("diamond"), chest("crystal"));
    ring("obsidian_chest", "minecraft:obsidian", chest("diamond"), chest("obsidian"));
    ["diamond", "crystal", "obsidian"].forEach(function (t) {
        R.addSmithing("ts_netherite_chest_from_" + t, TEMPLATE, chest(t), NETHERITE, chest("netherite"));
    });
    ring("dirt_chest", "minecraft:dirt", "minecraft:chest", chest("dirt"));

    // ---- chest upgrade kits: the new material around the old one
    var kit = function (from, to) { return I["ts_chest_upgrade_" + from + "_" + to]; };
    ring("chest_upgrade_wood_copper", "minecraft:copper_ingot", PLANKS, kit("wood", "copper"));
    ring("chest_upgrade_wood_iron", "minecraft:iron_ingot", PLANKS, kit("wood", "iron"));
    ring("chest_upgrade_copper_iron", "minecraft:iron_ingot", "minecraft:copper_ingot", kit("copper", "iron"));
    ring("chest_upgrade_iron_gold", "minecraft:gold_ingot", "minecraft:iron_ingot", kit("iron", "gold"));
    shaped("chest_upgrade_gold_diamond", ["GGG", "DXD", "GGG"], { G: "minecraft:glass", D: "minecraft:diamond", X: "minecraft:gold_ingot" }, kit("gold", "diamond"));
    ring("chest_upgrade_diamond_crystal", "minecraft:glass", "minecraft:amethyst_shard", kit("diamond", "crystal"));
    ring("chest_upgrade_diamond_obsidian", "minecraft:obsidian", "minecraft:glass", kit("diamond", "obsidian"));
    R.addShapeless("ts_chest_upgrade_diamond_netherite", [TEMPLATE, NETHERITE, "minecraft:obsidian"], { id: kit("diamond", "netherite"), count: 1 });

    // ---- furnaces, blast furnaces and smokers: each kind from the tier before of the same kind
    var furnace = function (t, k) { return t === "vanilla" ? TS.KINDS[k].vanilla : B[TS.furnaceKey(t, k)]; };
    TS.KIND_ORDER.forEach(function (k) {
        var s = k === "furnace" ? "" : "_" + k;
        ring("copper" + s, "minecraft:copper_ingot", furnace("vanilla", k), furnace("copper", k));
        ring("iron" + s, "minecraft:iron_ingot", furnace("vanilla", k), furnace("iron", k));
        ring("iron" + s + "_from_copper", "minecraft:iron_ingot", furnace("copper", k), furnace("iron", k));
        ring("gold" + s, "minecraft:gold_ingot", furnace("iron", k), furnace("gold", k));
        shaped("diamond" + s, ["GDG", "DFD", "GDG"], { G: "minecraft:glass", D: "minecraft:diamond", F: furnace("gold", k) }, furnace("diamond", k));
        ring("emerald" + s, "minecraft:emerald", furnace("diamond", k), furnace("emerald", k));
        ring("obsidian" + s, "minecraft:obsidian", furnace("emerald", k), furnace("obsidian", k));
        shaped("crystal" + s, ["GAG", "AFA", "GAG"], { G: "minecraft:glass", A: "minecraft:amethyst_shard", F: furnace("obsidian", k) }, furnace("crystal", k));
        R.addSmithing("ts_netherite" + s, TEMPLATE, furnace("crystal", k), NETHERITE, furnace("netherite", k));
    });
    // a blast furnace or smoker of any tier from that tier's furnace, the way vanilla makes them
    TS.FURNACE_ORDER.forEach(function (t) {
        shaped(t + "_blast_furnace_from_furnace", ["III", "IFI", "SSS"], { I: "minecraft:iron_ingot", F: furnace(t, "furnace"), S: "minecraft:smooth_stone" }, furnace(t, "blast_furnace"));
        shaped(t + "_smoker_from_furnace", [" L ", "LFL", " L "], { L: LOGS, F: furnace(t, "furnace") }, furnace(t, "smoker"));
    });

    // ---- furnace upgrade kits: the tier's material around cobblestone
    var fkit = function (t) { return I["ts_furnace_upgrade_" + t]; };
    var C = "minecraft:cobblestone";
    ring("furnace_upgrade_copper", "minecraft:copper_ingot", C, fkit("copper"));
    ring("furnace_upgrade_iron", "minecraft:iron_ingot", C, fkit("iron"));
    ring("furnace_upgrade_gold", "minecraft:gold_ingot", C, fkit("gold"));
    shaped("furnace_upgrade_diamond", ["GDG", "DCD", "GDG"], { G: "minecraft:glass", D: "minecraft:diamond", C: C }, fkit("diamond"));
    ring("furnace_upgrade_emerald", "minecraft:emerald", C, fkit("emerald"));
    ring("furnace_upgrade_obsidian", "minecraft:obsidian", C, fkit("obsidian"));
    shaped("furnace_upgrade_crystal", ["GAG", "ACA", "GAG"], { G: "minecraft:glass", A: "minecraft:amethyst_shard", C: C }, fkit("crystal"));
    R.addShapeless("ts_furnace_upgrade_netherite", [TEMPLATE, NETHERITE, C], { id: fkit("netherite"), count: 1 });
})();
