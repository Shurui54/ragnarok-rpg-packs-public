// =====================================================================================
//  Ragnarok Industry - recipes. Progression: Galvanite (early) -> Sunsteel (mid, Nether) -> Ragnite (deep, late).
//  Every crafting and smelting recipe is a real recipe (JEI and the recipe book list it); Refinery recipes are
//  listed for viewers with RPG.recipes.addDisplay.
// =====================================================================================
(function () {
    var I = RI.items, B = RI.blocks, R = RPG.recipes;
    function shaped(id, pattern, keys, result, count) { R.addShaped("ri_" + id, pattern, keys, { id: result, count: count || 1 }); }
    function shapeless(id, list, result, count) { R.addShapeless("ri_" + id, list, { id: result, count: count || 1 }); }

    // ---- metals
    R.addSmelting("ri_galvanite_ingot", I.ri_raw_galvanite, I.ri_galvanite_ingot, 0.7, 200);
    R.addBlasting("ri_galvanite_ingot_blasting", I.ri_raw_galvanite, I.ri_galvanite_ingot, 0.7, 100);
    R.addSmelting("ri_galvanite_ingot_from_ore", B.ri_galvanite_ore, I.ri_galvanite_ingot, 0.7, 200);
    R.addSmelting("ri_galvanite_ingot_from_deep_ore", B.ri_deepslate_galvanite_ore, I.ri_galvanite_ingot, 0.7, 200);
    shapeless("sunsteel_blend", [I.ri_galvanite_ingot, I.ri_galvanite_ingot, "minecraft:gold_ingot", "minecraft:blaze_powder"], I.ri_sunsteel_blend, 2);
    R.addSmelting("ri_sunsteel_ingot", I.ri_sunsteel_blend, I.ri_sunsteel_ingot, 1.0, 200);
    R.addBlasting("ri_sunsteel_ingot_blasting", I.ri_sunsteel_blend, I.ri_sunsteel_ingot, 1.0, 100);
    R.addBlasting("ri_ragnite_ingot", I.ri_raw_ragnite, I.ri_ragnite_ingot, 1.5, 200);
    ["galvanite", "sunsteel", "ragnite"].forEach(function (m) {
        shaped(m + "_block", ["XXX", "XXX", "XXX"], { X: I["ri_" + m + "_ingot"] }, B["ri_" + m + "_block"]);
        shapeless(m + "_ingot_from_block", [B["ri_" + m + "_block"]], I["ri_" + m + "_ingot"], 9);
        shapeless(m + "_plate", [I.ri_forge_hammer, I["ri_" + m + "_ingot"]], I["ri_" + m + "_plate"]);
    });

    // ---- parts
    shaped("forge_hammer", ["III", "III", " S "], { I: "minecraft:iron_ingot", S: "minecraft:stick" }, I.ri_forge_hammer);
    shaped("wrench", ["G G", " G ", " G "], { G: I.ri_galvanite_ingot }, I.ri_wrench);
    shaped("basic_circuit", ["RCR", "GPG", "RCR"], { R: "minecraft:redstone", C: "minecraft:copper_ingot", G: I.ri_galvanite_ingot, P: I.ri_galvanite_plate }, I.ri_basic_circuit, 2);
    shaped("advanced_circuit", ["GQG", "CSC", "GQG"], { G: "minecraft:gold_ingot", Q: "minecraft:quartz", C: I.ri_basic_circuit, S: I.ri_sunsteel_plate }, I.ri_advanced_circuit, 2);
    shaped("elite_circuit", ["DRD", "AEA", "DRD"], { D: "minecraft:diamond", R: I.ri_ragnite_plate, A: I.ri_advanced_circuit, E: "minecraft:ender_pearl" }, I.ri_elite_circuit, 2);
    shaped("machine_casing", ["PIP", "I I", "PIP"], { P: I.ri_galvanite_plate, I: "minecraft:iron_ingot" }, I.ri_machine_casing);
    shaped("advanced_casing", ["SBS", "CMC", "SBS"], { S: I.ri_sunsteel_plate, B: "minecraft:blaze_rod", C: I.ri_advanced_circuit, M: I.ri_machine_casing }, I.ri_advanced_casing);
    shaped("elite_casing", ["RNR", "EAE", "RNR"], { R: I.ri_ragnite_plate, N: "minecraft:netherite_scrap", E: I.ri_elite_circuit, A: I.ri_advanced_casing }, I.ri_elite_casing);
    shaped("heat_coil", ["CCC", "CPC", "CCC"], { C: "minecraft:copper_ingot", P: I.ri_galvanite_plate }, I.ri_heat_coil, 2);
    shaped("solar_cell", ["GGG", "LPL", "CRC"], { G: "minecraft:glass_pane", L: "minecraft:lapis_lazuli", P: I.ri_galvanite_plate, C: "minecraft:copper_ingot", R: "minecraft:redstone" }, I.ri_solar_cell, 2);
    shaped("radiant_cell", ["GQG", "SCS", "GDG"], { G: "minecraft:glowstone_dust", Q: "minecraft:quartz", S: I.ri_sunsteel_plate, C: I.ri_solar_cell, D: "minecraft:diamond" }, I.ri_radiant_cell);
    shaped("speed_upgrade", ["RSR", "SCS", "RSR"], { R: "minecraft:redstone", S: "minecraft:sugar", C: I.ri_advanced_circuit }, I.ri_speed_upgrade);
    shaped("fortune_upgrade", ["LGL", "GCG", "LGL"], { L: "minecraft:lapis_block", G: "minecraft:gold_ingot", C: I.ri_advanced_circuit }, I.ri_fortune_upgrade);
    shaped("silk_upgrade", ["SES", "ECE", "SES"], { S: "minecraft:slime_ball", E: "minecraft:emerald", C: I.ri_elite_circuit }, I.ri_silk_upgrade);

    // ---- tiered blocks: tier 1 from parts, tiers 2+ from two of the tier below plus that tier's plate, circuit and casing
    var PLATE = [null, I.ri_galvanite_plate, I.ri_sunsteel_plate, I.ri_ragnite_plate, I.ri_ragnite_plate];
    var CIRCUIT = [null, I.ri_basic_circuit, I.ri_advanced_circuit, I.ri_elite_circuit, I.ri_elite_circuit];
    var CASING = [null, I.ri_machine_casing, I.ri_advanced_casing, I.ri_elite_casing, I.ri_elite_casing];
    function upgrades(base, top) {
        for (var t = 2; t <= top; t++)
            shaped(base + "_" + t, ["PCP", "XMX", "PCP"], { P: PLATE[t], C: CIRCUIT[t], X: B["ri_" + base + "_" + (t - 1)], M: CASING[t] }, B["ri_" + base + "_" + t]);
    }
    shaped("solar_panel_1", ["SSS", "PCP", "III"], { S: I.ri_solar_cell, P: I.ri_galvanite_plate, C: I.ri_basic_circuit, I: "minecraft:iron_ingot" }, B.ri_solar_panel_1);
    shaped("solar_panel_2", ["SSS", "XCX", "PMP"], { S: I.ri_solar_cell, X: B.ri_solar_panel_1, C: I.ri_advanced_circuit, P: I.ri_sunsteel_plate, M: I.ri_advanced_casing }, B.ri_solar_panel_2);
    shaped("solar_panel_3", ["SSS", "XCX", "PMP"], { S: I.ri_radiant_cell, X: B.ri_solar_panel_2, C: I.ri_advanced_circuit, P: I.ri_sunsteel_plate, M: I.ri_advanced_casing }, B.ri_solar_panel_3);
    shaped("solar_panel_4", ["SNS", "XCX", "PMP"], { S: I.ri_radiant_cell, N: "minecraft:nether_star", X: B.ri_solar_panel_3, C: I.ri_elite_circuit, P: I.ri_ragnite_plate, M: I.ri_elite_casing }, B.ri_solar_panel_4);
    shaped("combustion_generator_1", ["PCP", "HMH", "PFP"], { P: I.ri_galvanite_plate, C: I.ri_basic_circuit, H: I.ri_heat_coil, M: I.ri_machine_casing, F: "minecraft:furnace" }, B.ri_combustion_generator_1);
    upgrades("combustion_generator", 3);
    shaped("gas_generator_1", ["PCP", "BMB", "PHP"], { P: I.ri_galvanite_plate, C: I.ri_basic_circuit, B: "minecraft:bucket", M: I.ri_machine_casing, H: I.ri_heat_coil }, B.ri_gas_generator_1);
    upgrades("gas_generator", 3);
    shaped("heat_generator_1", ["HCH", "PMP", "HNH"], { H: I.ri_heat_coil, C: I.ri_basic_circuit, P: I.ri_galvanite_plate, M: I.ri_machine_casing, N: "minecraft:magma_block" }, B.ri_heat_generator_1);
    upgrades("heat_generator", 3);
    shaped("energy_cell_1", ["PRP", "RMR", "PCP"], { P: I.ri_galvanite_plate, R: "minecraft:redstone_block", M: I.ri_machine_casing, C: I.ri_basic_circuit }, B.ri_energy_cell_1);
    upgrades("energy_cell", 3);
    shaped("pump_1", ["PCP", "BMB", "PKP"], { P: I.ri_galvanite_plate, C: I.ri_basic_circuit, B: "minecraft:bucket", M: I.ri_machine_casing, K: B.ri_fluid_pipe_1 }, B.ri_pump_1);
    upgrades("pump", 3);
    shaped("quarry_1", ["PCP", "DMD", "PHP"], { P: I.ri_galvanite_plate, C: I.ri_basic_circuit, D: "minecraft:diamond_pickaxe", M: I.ri_machine_casing, H: "minecraft:hopper" }, B.ri_quarry_1);
    upgrades("quarry", 3);
    shaped("refinery", ["PCP", "BMB", "PFP"], { P: I.ri_galvanite_plate, C: I.ri_basic_circuit, B: "minecraft:bucket", M: I.ri_machine_casing, F: "minecraft:blast_furnace" }, B.ri_refinery);

    // conduits and tanks per metal
    var METAL = [null, I.ri_galvanite_ingot, I.ri_sunsteel_ingot, I.ri_ragnite_ingot];
    for (var t = 1; t <= 3; t++) {
        shaped("cable_" + t, ["KKK", "MMM", "KKK"], { K: "minecraft:dried_kelp", M: METAL[t] }, B["ri_cable_" + t], 8);
        shaped("fluid_pipe_" + t, ["PGP"], { P: PLATE[t], G: "minecraft:glass" }, B["ri_fluid_pipe_" + t], 4);
        shaped("tank_" + t, ["PGP", "G G", "PGP"], { P: PLATE[t], G: "minecraft:glass" }, B["ri_tank_" + t]);
    }
    shaped("ender_tank", ["OEO", "ATA", "OEO"], { O: "minecraft:obsidian", E: "minecraft:ender_pearl", A: I.ri_advanced_circuit, T: B.ri_tank_2 }, B.ri_ender_tank);

    // ---- refinery recipes, for recipe viewers
    Object.keys(RI.REFINE).forEach(function (item) {
        var r = RI.REFINE[item];
        R.addDisplay("ri_refining_" + item.replace(/[^a-z0-9_]/g, "_"), { station: "Refinery", stationItem: B.ri_refinery, grid: [item],
            extras: [{ label: r.water + " mB Water", item: "minecraft:water_bucket", count: 1 }],
            result: { id: RI.PYROGAS_BUCKET, count: 1 },
            note: r.water + " mB water -> " + r.gas + " mB Pyrogas, " + RI.fmt(r.ticks * RI.REFINE_RATE) + " RE, " + (r.ticks / 20) + " s" });
    });
})();
