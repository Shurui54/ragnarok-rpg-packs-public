// =====================================================================================
//  Ragnarok Industry - logistics: energy cables, fluid pipes, connected tanks and ender tanks.
//  Cable and pipe networks are cached by the engine (BlockDef.blockEntity.conduit) and rebuilt only when something
//  changes; touching tanks share one fluid (tanks[0].connect). Nothing here runs per tick.
// =====================================================================================
var RI_SIDES = ["north", "south", "east", "west", "up", "down"];
// Cables and pipes use a 12-pixel box as their shape (the models are thinner): blocks smaller than that count as
// non-solid, and flowing water or lava would wash them away like torches.

function riConduitProps(values) {
    return RI_SIDES.map(function (n) { return { name: n, type: "enum", values: values, default: "none" }; });
}

// Wrench (or sneak-use with an empty hand): switch the connection the player points at.
RI.wrench = function (player, x, y, z) {
    var be = RI.be(player, x, y, z);
    if (!be || be.conduitSide("north") === null) return false;
    var face = be.sideAt(player);
    if (!face) return true;
    var fluid = be.key.indexOf("ri_fluid_pipe") === 0;
    var cur = be.conduitSide(face), next;
    if (fluid) next = cur === "auto" ? "extract" : cur === "extract" ? "off" : "auto";
    else next = cur === "auto" ? "off" : "auto";
    be.setConduitSide(face, next);
    var label = next === "auto" ? (fluid ? "&aNormal" : "&aConnected") : next === "extract" ? "&6Extract" : "&cOff";
    player.actionbar("&7" + face.charAt(0).toUpperCase() + face.slice(1) + ": " + label);
    player.playSound("minecraft:block.lever.click", 0.5, next === "off" ? 0.7 : 1.2);
    return true;
};

RI.conduitUse = function (unit) {
    return function (p, x, y, z) {
        if (p.isSneaking()) { RI.wrench(p, x, y, z); return; }
        var be = RI.be(p, x, y, z), info = be ? be.conduitInfo() : null;
        if (info) p.actionbar("&7Network: &f" + info.members + " &7blocks, &f" + info.endpoints + " &7connections, &f" + RI.fmt(info.rate) + " " + unit + "/t");
    };
};

// ---- energy cables ----------------------------------------------------------------------------------------
RI.CABLE = [null, { rate: 1000, mat: "Galvanite" }, { rate: 8000, mat: "Sunsteel" }, { rate: 64000, mat: "Ragnite" }];
for (var cbt = 1; cbt <= 3; cbt++) (function (t) {
    RI.block("ri_cable_" + t, {
        family: "layout", properties: riConduitProps(["none", "pipe"]), blockstate: RI.NS + ":cable_" + t, itemModel: RI.NS + ":rpg/item/cable_" + t,
        name: RI.TIERS[t].color + RI.CABLE[t].mat + " Cable", shape: [2, 2, 2, 14, 14, 14], solid: false, renderType: "cutout",
        hardness: 0.8, sound: "metal", drops: "self",
        lore: ["&7Carries &f" + RI.fmt(RI.CABLE[t].rate) + " RE/t&7.", "&7Cables of any tier join; a network runs at its slowest cable.",
               "&7Generators and cells push into it; it feeds every machine it touches.", "&7Wrench a connection to switch it off."],
        blockEntity: { conduit: { type: "energy", rate: RI.CABLE[t].rate, group: "ri_energy" } },
        useWith: ["empty"], onUse: RI.conduitUse("RE")
    });
})(cbt);

// ---- fluid pipes ------------------------------------------------------------------------------------------
RI.PIPE = [null, { rate: 100, mat: "Galvanite" }, { rate: 500, mat: "Sunsteel" }, { rate: 2500, mat: "Ragnite" }];
for (var ppt = 1; ppt <= 3; ppt++) (function (t) {
    RI.block("ri_fluid_pipe_" + t, {
        family: "layout", properties: riConduitProps(["none", "pipe", "extract"]), blockstate: RI.NS + ":fluid_pipe_" + t, itemModel: RI.NS + ":rpg/item/fluid_pipe_" + t,
        name: RI.TIERS[t].color + RI.PIPE[t].mat + " Fluid Pipe", shape: [2, 2, 2, 14, 14, 14], solid: false, renderType: "cutout",
        hardness: 0.8, sound: "metal", drops: "self",
        lore: ["&7Moves &f" + RI.fmt(RI.PIPE[t].rate) + " mB/t&7.", "&7Wrench a connection: normal → &6extract&7 → off.",
               "&7Extracting connections pull from what they touch", "&7and feed every other connection."],
        blockEntity: { conduit: { type: "fluid", rate: RI.PIPE[t].rate, group: "ri_fluid" } },
        useWith: ["empty"], onUse: RI.conduitUse("mB")
    });
})(ppt);

// ---- tanks: touching tanks form one tank (one fluid, capacities add up, filled from the bottom) -------------
RI.TANK = [null, { cap: 16000, mat: "Galvanite" }, { cap: 64000, mat: "Sunsteel" }, { cap: 256000, mat: "Ragnite" }];
RI.tankInfo = function (p, be) {
    var t = be.tank(0), n = be.tankGroupSize;
    p.actionbar((t.fluid ? "&b" + t.name : "&7Empty") + "&7: &f" + RI.fmt(t.amount) + " / " + RI.fmt(t.capacity) + " mB" + (n > 1 ? " &8(" + n + " tanks)" : ""));
};
for (var tkt = 1; tkt <= 3; tkt++) (function (t) {
    RI.block("ri_tank_" + t, {
        name: RI.TIERS[t].color + RI.TANK[t].mat + " Tank", model: RI.NS + ":rpg/block/tank_" + t, decor: true, renderType: "cutout",
        hardness: 2, sound: "glass", drops: "self",
        // only buckets and an empty hand use the tank: any other block in hand is placed against it (more tanks)
        useWith: ["empty", "minecraft:bucket", "minecraft:water_bucket", "minecraft:lava_bucket", "minecraft:milk_bucket", RI.PYROGAS_BUCKET],
        lore: ["&7Holds &f" + RI.fmt(RI.TANK[t].cap) + " mB&7.", "&7Touching tanks become one tank (up to 512), any shape,", "&7holding one fluid. Keeps its share of the fluid when broken.",
               "&7Right-click with a bucket to fill or empty it."],
        blockEntity: {
            inventory: { size: 0, keepContents: true },
            tanks: [{ capacity: RI.TANK[t].cap, connect: "ri_tank", render: [1.01, 0.02, 1.01, 14.99, 15.98, 14.99] }]
        },
        onPlace: function (p, x, y, z) {
            RI.claimOwner(p, x, y, z);
            var be = RI.be(p, x, y, z);
            if (!be) return;
            var mine = be.tank(0).fluid, d = p.dimension, refused = false;
            for (var i = 0; i < 6; i++) {
                var o = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]][i];
                var n = RPG.blocks.entityAt(d, x + o[0], y + o[1], z + o[2]);
                if (!n || n.key.indexOf("ri_tank_") !== 0) continue;
                var f = n.tank(0).fluid;
                if (f && mine && f !== mine) refused = true;
            }
            if (refused) p.tell("&cThat tank touches a tank holding a different fluid: they stay separate.");
            else if (be.tankGroupSize >= 512) p.tell("&eThis tank group is at its limit of 512 tanks: the new one stays separate.");
        },
        onUse: function (p, x, y, z) {
            var be = RI.be(p, x, y, z);
            if (!be) return;
            if (!be.useHeldContainer(p)) RI.tankInfo(p, be);
            else RI.tankInfo(p, be);
        }
    });
})(tkt);

// ---- ender tank: every ender tank with the same combo (and owner, when private) shares one tank ------------
RI.ENDER = { cap: 32000, rate: 1000 };
RI.enderKey = function (be) {
    var d = be.data, combo = Math.max(0, Math.min(9999, Math.floor(Number(d.combo) || 0)));
    var c = ("000" + combo).slice(-4);
    return d.private && d.owner ? "ri_private:" + String(d.owner).toLowerCase() + ":" + c : "ri_combo:" + c;
};
RI.enderLink = function (be) { be.linkTank(0, RI.enderKey(be)); };
RI.DIGITS = ["&f0", "&61", "&d2", "&b3", "&e4", "&a5", "&c6", "&82", "&73", "&94"];
RI.block("ri_ender_tank", {
    name: "&5Ender Tank", model: RI.NS + ":rpg/block/ender_tank", hardness: 4, explosionResistance: 600, sound: "stone", drops: "self", renderType: "cutout",
    lore: ["&7Every ender tank set to the same four digits shares", "&7one &f32,000 mB &7tank, in any dimension.",
           "&7Private: only ender tanks you placed share it.", "&7Moves up to 1,000 mB/t through each tank."],
    blockEntity: {
        inventory: { size: 4, accepts: function (slot, id) { return slot === 0 || slot === 2; }, inputs: [0, 2], outputs: [1, 3] },
        tanks: [{ capacity: RI.ENDER.cap, shared: true, rate: RI.ENDER.rate, fillFrom: 0, emptyTo: 1, drainFrom: 2, drainTo: 3 }]
    },
    onPlace: function (p, x, y, z) {
        RI.claimOwner(p, x, y, z);
        var be = RI.be(p, x, y, z);
        if (be) { be.data.combo = 0; be.data.private = false; be.save(); RI.enderLink(be); }
    },
    onUse: function (p, x, y, z) {
        var be = RI.be(p, x, y, z);
        if (!be) return;
        if (!be.tankKey(0)) RI.enderLink(be);       // placed by a command or before it had an owner
        var owner = be.data.owner;
        if (be.data.private && owner && owner !== p.uuid && !RPG.perms.has(p, "industry.admin")) { p.actionbar("&cThis ender tank is private."); return; }
        var buttons = [];
        for (var i = 0; i < 4; i++) {
            buttons.push(RI.btn("up" + i, "+", 44 + i * 22, 18, 20, ["Next digit"]));
            buttons.push(RI.btn("dn" + i, "-", 44 + i * 22, 50, 20, ["Previous digit"]));
            buttons.push(RI.btn("d" + i, "0", 44 + i * 22, 34, 20, []));
        }
        buttons.push(RI.btn("priv", "", 44, 66 - 2, 86, ["Private: only ender tanks you placed", "with the same digits share this tank."]));
        var spec = { title: RI.gui("Ender Tank"), height: 176, inventory: { y: 94, labelY: 83 },
            slots: [{ x: 8, y: 18, slot: 0, accepts: "fluid_container" }, { x: 8, y: 54, slot: 1 }, { x: 134, y: 18, slot: 2, accepts: "fluid_container" }, { x: 134, y: 54, slot: 3 }],
            gauges: [{ type: "fluid", x: 152, y: 17, tank: 0, h: 70 }, { type: "fluid", x: 26, y: 17, tank: 0, h: 52 }],
            buttons: buttons,
            onButton: function (pl, id, bench) {
                // everything is decided here on the server: the client only says which button
                if (be.data.private && be.data.owner && be.data.owner !== pl.uuid && !RPG.perms.has(pl, "industry.admin")) return;
                var c = Math.max(0, Math.min(9999, Math.floor(Number(be.data.combo) || 0)));
                var digits = [Math.floor(c / 1000) % 10, Math.floor(c / 100) % 10, Math.floor(c / 10) % 10, c % 10];
                if (id.indexOf("up") === 0) { var k = Number(id.slice(2)); digits[k] = (digits[k] + 1) % 10; }
                else if (id.indexOf("dn") === 0) { var k2 = Number(id.slice(2)); digits[k2] = (digits[k2] + 9) % 10; }
                else if (id === "priv") {
                    if (be.data.owner !== pl.uuid && !RPG.perms.has(pl, "industry.admin")) { pl.actionbar("&cOnly the owner can make it private."); return; }
                    be.data.private = !be.data.private;
                }
                be.data.combo = digits[0] * 1000 + digits[1] * 100 + digits[2] * 10 + digits[3];
                be.save();
                RI.enderLink(be);
                refresh(be, bench);
            } };
        function refresh(b, bn) {
            var c = Math.max(0, Math.min(9999, Math.floor(Number(b.data.combo) || 0)));
            var digits = [Math.floor(c / 1000) % 10, Math.floor(c / 100) % 10, Math.floor(c / 10) % 10, c % 10];
            for (var i = 0; i < 4; i++) bn.button("d" + i, { text: RI.DIGITS[digits[i]].slice(0, 2) + digits[i], enabled: false });
            bn.button("priv", { text: b.data.private ? "&dPrivate" : "&7Public" });
        }
        RI.track(be, p, be.open(p, spec), refresh);
    }
});

// ---- first enable: cables and pipes wait for one restart ---------------------------------------------------
// Their connected shapes are block states, which the game only creates while it starts, so the first time a world
// turns the addon on they stay inert until the server (or, in singleplayer, the game) restarts once. Everything else
// works at once. Ops (or the singleplayer owner) are told clearly, at once and when they join, until then.
RI.CONDUITS_READY = RPG.blocks.isReady(RI.blocks.ri_cable_1) && RPG.blocks.isReady(RI.blocks.ri_fluid_pipe_1);
if (!RI.CONDUITS_READY) {
    RI.RESTART_MSG = function () {
        var where = RPG.server.isDedicated() ? "Restart the server once." : "Save and quit, close Minecraft and start it again once.";
        return ["&6[Ragnarok Industry] &eCables and fluid pipes need one restart before they work. &f" + where,
                "&7They are new blocks with connected shapes, which the game only creates when it starts. Until then they can't be placed or carry anything; every other machine works now, and nothing has to be redone after the restart."];
    };
    RI.tellRestart = function (p) { if (p.isOp() || !RPG.server.isDedicated()) RI.RESTART_MSG().forEach(function (l) { p.tell(l); }); };
    console.warn("Ragnarok Industry: cables and fluid pipes need one restart (their block states are created at start-up); they stay inert until then");
    RPG.schedule(1, function () { RPG.server.players().forEach(RI.tellRestart); });
    RPG.on("playerJoin", function (p) { RPG.schedule(40, function () { RI.tellRestart(p); }); });
}
