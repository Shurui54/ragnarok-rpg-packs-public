// =====================================================================================
//  Ragnarok Industry - generators and energy cells. Energy making, fuel burning and pushing into neighbours all
//  run in the engine every tick (BlockDef.blockEntity energy / generator); scripts only react to conditions
//  (daylight, lava around) every couple of seconds and draw the screens.
// =====================================================================================

// A machine-family block (faces you, lit while working) with a block entity and a screen.
RI.machine = function (key, o) {
    var tier = o.tier || 1;
    var def = {
        family: "machine", name: o.name,
        textures: { front: RI.tex(o.front), front_on: RI.tex(o.frontOn || o.front), side: RI.tex(o.side || ("casing_side_" + tier)), top: RI.tex(o.top || ("casing_top_" + tier)) },
        hardness: 3.5, explosionResistance: 8, tool: "pickaxe", tier: "stone", requiresTool: false, sound: "metal", drops: "self",
        lore: o.lore || [],
        blockEntity: o.be,
        onPlace: function (p, x, y, z) { RI.claimOwner(p, x, y, z); if (o.placed) o.placed(p, x, y, z); },
        onUse: function (p, x, y, z) { var be = RI.be(p, x, y, z); if (be && o.screen) o.screen(be, p); }
    };
    if (o.useWith) def.useWith = o.useWith;
    return RI.block(key, def);
};

function riTitle(tier, name) { return RI.TIERS[tier].color + RI.TIERS[tier].name + " " + name; }

// ---- solar panels ---------------------------------------------------------------------------------------
RI.SOLAR = [null,
    { peak: 8, night: 0, buffer: 4000, out: 64 },
    { peak: 32, night: 0, buffer: 32000, out: 256 },
    { peak: 128, night: 0.1, buffer: 128000, out: 1024 },
    { peak: 512, night: 0.25, buffer: 512000, out: 4096 }];
RI.SOLAR_NAMES = [null, "Basic Solar Panel", "Reinforced Solar Panel", "Radiant Solar Panel", "Celestial Solar Panel"];

// How strong the light on a panel is (0-1) and why, from the sky, the time of day and the weather.
RI.sunlight = function (be, s) {
    var d = be.dimension;
    if (!RPG.world.canSeeSky(d, be.x, be.y + 1, be.z)) return { f: 0, why: "&cNo sky above" };
    var f, why;
    if (RPG.world.isDay(d)) {
        var t = RPG.world.timeOfDay(d);                       // 0 sunrise, 6000 noon, 12000 sunset
        f = t < 12000 ? Math.min(1, 0.2 + 1.2 * Math.sin(Math.PI * t / 12000)) : 0.2;
        why = "&6Daylight " + Math.round(f * 100) + "%";
    } else {
        f = s.night;
        why = s.night > 0 ? "&9Moonlight" : "&8Night";
    }
    var w = RPG.world.weather(d);
    if (w && w.thundering) { f *= 0.25; why += " &7(storm)"; }
    else if (w && w.raining) { f *= 0.4; why += " &7(rain)"; }
    return { f: f, why: why };
};

for (var st = 1; st <= 4; st++) (function (t) {
    var s = RI.SOLAR[t];
    RI.block("ri_solar_panel_" + t, {
        name: RI.TIERS[t].color + RI.SOLAR_NAMES[t], model: RI.NS + ":rpg/block/solar_panel_" + t, shape: [0, 0, 0, 16, 6, 16],
        hardness: 2.5, tool: "pickaxe", sound: "metal", drops: "self", renderType: "cutout",
        lore: ["&7Up to &f" + s.peak + " RE/t &7in full sun" + (s.night > 0 ? ", &f" + Math.round(s.peak * s.night) + " RE/t &7at night" : "") + ".",
               "&7Needs open sky. Rain: 40%, storms: 25%.", "&7Buffer " + RI.fmt(s.buffer) + " RE, pushes out below and to the sides."],
        blockEntity: {
            tickInterval: 40,
            energy: { capacity: s.buffer, maxInput: 0, maxOutput: s.out, push: true, sides: { all: "out", up: "none" } },
            onTick: function (be) {
                var l = RI.sunlight(be, s);
                be.setGeneration(s.peak * l.f);
                be.data.why = l.why;
                RI.refresh(be);
            }
        },
        onPlace: function (p, x, y, z) { RI.claimOwner(p, x, y, z); },
        onUse: function (p, x, y, z) {
            var be = RI.be(p, x, y, z);
            if (!be) return;
            var bench = be.open(p, { title: RI.gui(RI.SOLAR_NAMES[t]), slots: [],
                gauges: [RI.ENERGY_GAUGE(152, 17), RI.RATE(10, 22)],
                buttons: [RI.btn("why", "", 10, 40, 130, ["What the panel sees right now"])] });
            RI.track(be, p, bench, function (b, bn) { bn.button("why", { text: (b.data.why || "&7...") , enabled: false }); });
        }
    });
})(st);

// ---- combustion generators (furnace fuels) ---------------------------------------------------------------
RI.COMBUSTION = [null,
    { rate: 40, buffer: 40000, out: 200, scale: 1.0 },
    { rate: 120, buffer: 160000, out: 600, scale: 1.25 / 3 },
    { rate: 360, buffer: 640000, out: 1800, scale: 1.5 / 9 }];

function fuelScreen(title, extra) {
    return function (be, p) {
        var spec = { title: RI.gui(title), slots: [{ x: 80, y: 53, slot: 0, accepts: "fuel" }],
            gauges: [RI.ENERGY_GAUGE(152, 17), { type: "burn", x: 81, y: 36 }, RI.RATE(10, 22)],
            buttons: [RI.btn("fuel", "", 10, 40, 60, ["Turn burning new fuel on or off"])],
            onButton: function (pl, id, bench) { if (id === "fuel") { be.setFuelEnabled(!be.fuelEnabled); refresh(be, bench); } } };
        function refresh(b, bn) { bn.button("fuel", { text: b.fuelEnabled ? "&aFuel: On" : "&cFuel: Off" }); }
        RI.track(be, p, be.open(p, spec), refresh);
    };
}

for (var ct = 1; ct <= 3; ct++) (function (t) {
    var c = RI.COMBUSTION[t];
    RI.machine("ri_combustion_generator_" + t, {
        tier: t, name: riTitle(t, "Combustion Generator"), front: "combustion_front_" + t, frontOn: "combustion_front_on_" + t,
        lore: ["&7Burns furnace fuel: &f" + c.rate + " RE/t&7.", "&7Coal gives &f" + RI.fmt(1600 * c.scale * c.rate) + " RE&7.",
               "&7Pauses (saving fuel) while its buffer is full.", "&7Buffer " + RI.fmt(c.buffer) + " RE."],
        be: {
            inventory: { size: 1, accepts: ["fuel"], inputs: [0] },
            energy: { capacity: c.buffer, maxInput: 0, maxOutput: c.out, push: true, sides: { all: "out" } },
            generator: { energyPerTick: c.rate, item: { slot: 0, timeScale: c.scale } },
            activeProperty: "lit"
        },
        screen: fuelScreen(riTitle(t, "Combustion Generator"))
    });
})(ct);

// ---- fluid-fuel generators: gas (Pyrogas) and lava heat ----------------------------------------------------
function fluidScreen(title, extraButtons, onButton, refreshMore) {
    return function (be, p) {
        var buttons = [RI.btn("fuel", "", 76, 56, 70, ["Turn burning fuel from the tank on or off"])].concat(extraButtons || []);
        var spec = { title: RI.gui(title),
            slots: [{ x: 48, y: 17, slot: 0, accepts: "fluid_container" }, { x: 48, y: 53, slot: 1 }],
            gauges: [{ type: "fluid", x: 26, y: 17, tank: 0 }, RI.ENERGY_GAUGE(152, 17), { type: "burn", x: 78, y: 19 }, RI.RATE(96, 22)],
            buttons: buttons,
            onButton: function (pl, id, bench) {
                if (id === "fuel") be.setFuelEnabled(!be.fuelEnabled);
                else if (onButton) onButton(be, pl, id);
                refresh(be, bench);
            } };
        function refresh(b, bn) {
            bn.button("fuel", { text: b.fuelEnabled ? "&aBurn tank: On" : "&cBurn tank: Off" });
            if (refreshMore) refreshMore(b, bn);
        }
        RI.track(be, p, be.open(p, spec), refresh);
    };
}

RI.GAS = [null,
    { rate: 100, amount: 1, ticks: 4, buffer: 100000, out: 500, tank: 8000 },
    { rate: 300, amount: 3, ticks: 5, buffer: 400000, out: 1500, tank: 16000 },
    { rate: 900, amount: 3, ticks: 2, buffer: 1600000, out: 4500, tank: 32000 }];
for (var gt = 1; gt <= 3; gt++) (function (t) {
    var g = RI.GAS[t];
    RI.machine("ri_gas_generator_" + t, {
        tier: t, name: riTitle(t, "Gas Generator"), front: "gas_front_" + t, frontOn: "gas_front_on_" + t,
        lore: ["&7Burns Pyrogas: &f" + g.rate + " RE/t&7, &f" + Math.round(g.rate * g.ticks / g.amount) + " RE &7per mB.",
               "&7Fill it with pipes or Pyrogas Buckets.", "&7Tank " + RI.fmt(g.tank) + " mB, buffer " + RI.fmt(g.buffer) + " RE."],
        be: {
            inventory: { size: 2, accepts: function (slot, id) { return slot === 0; }, inputs: [0], outputs: [1] },
            energy: { capacity: g.buffer, maxInput: 0, maxOutput: g.out, push: true, sides: { all: "out" } },
            tanks: [{ capacity: g.tank, accepts: [RI.PYROGAS], sides: { all: "in" }, fillFrom: 0, emptyTo: 1 }],
            generator: { energyPerTick: g.rate, fluid: { tank: 0, amount: g.amount, ticks: g.ticks } },
            activeProperty: "lit"
        },
        screen: fluidScreen(riTitle(t, "Gas Generator"))
    });
})(gt);

// Lava heat generator: burns lava from its tank (buckets, pipes, any mod's fluid handler) and/or draws heat from
// lava source blocks touching it. Drawing heat is free; with "consume" on it makes four times as much, but each
// touching source cools to basalt after about two minutes on average.
RI.HEAT = [null,
    { rate: 60, amount: 1, ticks: 2, face: 2, buffer: 60000, out: 300, tank: 4000 },
    { rate: 180, amount: 6, ticks: 5, face: 6, buffer: 240000, out: 900, tank: 8000 },
    { rate: 540, amount: 3, ticks: 1, face: 18, buffer: 960000, out: 2700, tank: 16000 }];
RI.heatAround = function (be, h) {
    var d = be.dimension, n = 0, consume = !!be.data.consume, dirs = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
    for (var i = 0; i < 6; i++) {
        var x = be.x + dirs[i][0], y = be.y + dirs[i][1], z = be.z + dirs[i][2];
        if (RPG.world.getBlock(d, x, y, z) !== "minecraft:lava" || RPG.world.blockProperty(d, x, y, z, "level") !== "0") continue;
        n++;
        if (consume && Math.random() < 40 / 2400) RPG.world.setBlock(d, x, y, z, "minecraft:basalt");
    }
    be.setGeneration(n * h.face * (consume ? 4 : 1));
    be.data.faces = n;
};
for (var ht = 1; ht <= 3; ht++) (function (t) {
    var h = RI.HEAT[t];
    RI.machine("ri_heat_generator_" + t, {
        tier: t, name: riTitle(t, "Lava Heat Generator"), front: "heat_front_" + t, frontOn: "heat_front_on_" + t,
        lore: ["&7Burns lava: &f" + h.rate + " RE/t&7, &f" + Math.round(h.rate * h.ticks / h.amount) + " RE &7per mB.",
               "&7Touching lava sources: &f" + h.face + " RE/t &7each (free),", "&7or &f" + (h.face * 4) + " RE/t &7each with Consume on (they cool to basalt).",
               "&7Tank " + RI.fmt(h.tank) + " mB, buffer " + RI.fmt(h.buffer) + " RE."],
        be: {
            tickInterval: 40,
            inventory: { size: 2, accepts: function (slot, id) { return slot === 0; }, inputs: [0], outputs: [1] },
            energy: { capacity: h.buffer, maxInput: 0, maxOutput: h.out, push: true, sides: { all: "out" } },
            tanks: [{ capacity: h.tank, accepts: ["minecraft:lava"], sides: { all: "in" }, fillFrom: 0, emptyTo: 1 }],
            generator: { energyPerTick: h.rate, fluid: { tank: 0, amount: h.amount, ticks: h.ticks } },
            activeProperty: "lit",
            onTick: function (be) { RI.heatAround(be, h); RI.refresh(be); }
        },
        screen: fluidScreen(riTitle(t, "Lava Heat Generator"),
            [RI.btn("consume", "", 76, 42, 70, ["Consume touching lava sources for 4x heat"])],
            function (be, pl, id) { if (id === "consume") { be.data.consume = !be.data.consume; be.save(); RI.heatAround(be, h); } },
            function (b, bn) { bn.button("consume", { text: (b.data.consume ? "&6Consume: On" : "&7Consume: Off") + " &8(" + (b.data.faces || 0) + ")" }); })
    });
})(ht);

// ---- energy cells ---------------------------------------------------------------------------------------
RI.CELL = [null, { cap: 500000, io: 1000 }, { cap: 4000000, io: 4000 }, { cap: 32000000, io: 16000 }];
for (var et = 1; et <= 3; et++) (function (t) {
    var c = RI.CELL[t];
    RI.machine("ri_energy_cell_" + t, {
        tier: t, name: riTitle(t, "Energy Cell"), front: "cell_front_" + t,
        lore: ["&7Stores &f" + RI.fmt(c.cap) + " RE&7, &f" + RI.fmt(c.io) + " RE/t &7in and out.",
               "&7Takes energy on every side, gives it out of its front.", "&7Keeps its charge when broken."],
        be: {
            inventory: { size: 0, keepContents: true },
            energy: { capacity: c.cap, maxInput: c.io, maxOutput: c.io, push: true, sides: { all: "in", front: "out" } }
        },
        screen: function (be, p) {
            be.open(p, { title: RI.gui(riTitle(t, "Energy Cell")), slots: [], gauges: [RI.ENERGY_GAUGE(81, 17)] });
        }
    });
})(et);
