# Changelog

## 1.0.0 (2026-11-18)

- First release: solar panels (4 tiers), combustion, gas and lava heat generators (3 tiers each), energy cells,
  cables, fluid pipes, connected tanks (3 tiers each), ender tanks, a refinery, pumps and quarries (3 tiers each).
- Galvanite, Pyrolite and Ragnite ores with world generation; Sunsteel alloy; plates, circuits, casings, cells, coils,
  quarry upgrades, a Forge Hammer and a Conduit Wrench.
- Pyrogas, a gas fuel made in the Refinery.
- With JEI, the Refinery's recipes show in their own JEI category (needs the engine's JEI support for machine recipes).
- The Combustion Generator's Fuel button no longer sits on the inventory label.
- The quarry leaves no floating sand or gravel at the edge of its area, and water and lava there flow in.
- The first time a world turns the addon on, ops (or the singleplayer player) are told clearly that cables and pipes need one restart.
- Ragnarok Energy (RE) works with other mods' energy cables and machines, 1:1; fluids use the standard fluid capability.
