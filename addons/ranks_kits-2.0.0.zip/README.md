# Ranks & Kits (now part of Essentials)

Ranks & Kits is now part of **Essentials** (2.0.0 and later): the rank editor (`/rank`), the kit editor (`/kitadmin`)
and the kit menu (`/kits`, `/kit`) live there.

This addon is kept only so the id `ranks_kits` keeps resolving: it requires Essentials, so a world that lists
`ranks_kits` gets Essentials installed and switched on with it. It has no scripts of its own. New worlds only need
Essentials.
