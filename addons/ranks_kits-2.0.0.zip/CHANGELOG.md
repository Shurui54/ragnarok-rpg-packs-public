# Changelog

Ranks & Kits, newest first. Keep the heading as `## <version> (YYYY-MM-DD)` and the bullets short.

## 2.0.0 (2026-11-25)

- Ranks & Kits is now part of Essentials 2.0.0. This addon only requires Essentials (installing it with it) and has no scripts of its own.

## 1.0.0

- First release: ranks (/rank) with chat and tab prefixes, colour pickers, weight, inheritance, permission toggles and timed ranks; kits (/kitadmin) with capture, cooldowns, costs, one-time and first-join kits; /kits browse and preview.
