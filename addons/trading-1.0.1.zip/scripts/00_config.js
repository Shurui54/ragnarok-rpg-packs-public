// =====================================================================================
//  Trading - settings (ragnarok_rpg/config/trading.json, or /rpg config trading ...)
// =====================================================================================
//  /trade <player> asks someone to trade (or sneak + right-click them). They answer with
//  /trade accept or /trade deny. Both sides then put items and money on the table, both press
//  Confirm, and the swap happens at once (after an optional countdown).
//
//  Permissions (operators have them all; change with /rpg perm):
//    trading.use            trade with other players
//    trading.bypassdistance trade from any distance / dimension
//    trading.admin          /trade log, /trade cancel <player>
// =====================================================================================

// Other addons may refuse a swap: RPG_TRADE_HOOKS.veto.push((receiver, incoming, outgoing) => reason or null), where
// incoming are the stacks the receiver would get and outgoing the stacks they give (already out of their inventory).
// Asked when a stack is offered, when a side confirms and right before the swap.
var RPG_TRADE_HOOKS = typeof RPG_TRADE_HOOKS !== "undefined" && RPG_TRADE_HOOKS ? RPG_TRADE_HOOKS : { veto: [] };

var TR_CFG = RPG.config.define("trading", {
    prefix: { default: "&6[&eTrade&6] &r", comment: "Put before this addon's chat messages" },
    currency: {
        type: { default: "money", options: ["money", "item", "tp", "none"],
            comment: "What can be offered next to items: money (the project's currency, e.g. Zeni), item (see currency.item), tp, or none" },
        item: { default: "minecraft:emerald", comment: "The item used as money when currency.type is item" },
        name: { default: "", comment: "Name shown after amounts (empty: the project's currency name, or the item's name)" },
        max: { default: 1000000000, min: 0, max: 1e15, integer: true, comment: "Most money one side can offer in one trade" },
        taxPercent: { default: 0, min: 0, max: 100, comment: "Percent of traded money kept by the server (a money sink)" }
    },
    maxItems: { default: 16, min: 1, max: 16, integer: true, comment: "Stacks each side can offer (the offer grid holds 16)" },
    requestSeconds: { default: 30, min: 5, max: 600, integer: true, comment: "How long a trade request stays open" },
    requestCooldown: { default: 5, min: 0, max: 600, integer: true, comment: "Seconds between requests to the same player" },
    sneakClick: { default: true, comment: "Sneak + right-click a player to ask them to trade" },
    maxDistance: { default: 16, min: 0, max: 100000, comment: "Blocks apart players may be to start a trade (0: any distance)" },
    keepDistance: { default: 32, min: 0, max: 100000, comment: "The trade is cancelled if the players get further apart than this (0: never)" },
    sameDimension: { default: true, comment: "Both players must be in the same dimension" },
    countdown: { default: 3, min: 0, max: 30, integer: true, comment: "Seconds between both confirming and the swap (any change cancels it; 0: swap at once)" },
    blockCreative: { default: false, comment: "Players in creative mode can't trade" },
    blacklist: { default: [], comment: "Item ids that can't be traded, e.g. [\"minecraft:bedrock\"]" },
    allowConfined: { default: true, comment: "Items only players may carry (RPG.items.confine, e.g. dragon balls or a pouch holding them) can be traded. They go straight into the other player's inventory: the swap waits until they have room, and they are never dropped (off: such items can't be offered)" },
    logSize: { default: 300, min: 0, max: 5000, integer: true, comment: "Finished trades kept for /trade log" }
});

RPG.perms.group("default", ["trading.use"]);
RPG.perms.group("admin", ["trading.*"]);

var TR_CUR = {
    type() { return TR_CFG.get("currency.type") || "money"; },
    enabled() { return this.type() !== "none"; },
    name() {
        let n = TR_CFG.get("currency.name");
        if (n) return n;
        if (this.type() === "tp") return "TP";
        if (this.type() === "item") return RPG.items.name(TR_CFG.get("currency.item")) || "Items";
        return ((RPG.currency.get() || {}).name) || "Money";
    },
    balance(p) {
        let t = this.type();
        if (t === "tp") return Math.floor(p.getTp());
        if (t === "item") return p.countItem(TR_CFG.get("currency.item"));
        if (t === "none") return 0;
        return Math.floor(p.getMoney());
    },
    take(p, n) {
        n = Math.floor(n);
        if (n <= 0) return true;
        let t = this.type();
        if (t === "tp") { if (p.getTp() < n) return false; p.setTp(p.getTp() - n); return true; }
        if (t === "item") { let it = TR_CFG.get("currency.item"); return p.countItem(it) >= n && p.takeItem(it, n); }
        if (t === "none") return false;
        return p.takeMoney(n);
    },
    /** type: the currency the money was taken in (escrow remembers it), so a config change never loses money. */
    give(p, n, type, item) {
        n = Math.floor(n);
        if (n <= 0) return;
        let t = type || this.type();
        if (t === "tp") p.setTp(p.getTp() + n);
        else if (t === "item") p.giveItem(item || TR_CFG.get("currency.item"), n);
        else p.addMoney(n);
    },
    fmt(n) { return trNum(n) + " " + this.name(); }
};

function trNum(n) { return String(Math.floor(n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
function trMsg(p, text) { if (p) p.tell(TR_CFG.get("prefix") + text); else RPG.log(String(text).replace(/&./g, "")); }
function trHas(p, node) { return !p || RPG.perms.has(p, node); }
