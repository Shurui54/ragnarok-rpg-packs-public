# Changelog

Trading, newest first. Keep the heading as `## <version> (YYYY-MM-DD)` and the bullets short.

## 1.0.1 (2026-11-25)

- Inventories are no longer polled: the trade screen's inventory and the return of items that waited for a free slot now follow the engine's `inventoryChange` event. Trades behave as before (the screen just refreshes sooner, in the tick the inventory changes, instead of up to a quarter second later), and the addon no longer scans every online inventory every two seconds.

## 1.0.0

- First release: `/trade <player>` (or sneak + right-click), offers of items and money held in escrow, both sides confirm, optional countdown, `/trade log`.
