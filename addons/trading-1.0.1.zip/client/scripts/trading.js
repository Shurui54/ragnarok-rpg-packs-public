// =====================================================================================
//  Trading - the trade screen
// =====================================================================================
//  Two offer grids (yours on the left, theirs on the right), a money row under them, your own
//  inventory below as a click-to-offer grid, and Confirm / Cancel in the footer. Click one of
//  your offered stacks to take it back. Escape cancels the trade. The server checks everything;
//  this only draws what it sends. Drawn as a vanilla container window (the engine's ctx.panel/slot/button pieces).
// =====================================================================================
(function () {
    var NS = "trading";
    // vanilla text colours on the grey window (dark grey, chat's dark green / red / gold), the slot highlight
    var COL = { title: "#FF404040", row: "#FF404040", muted: "#FF6F6F6F", bad: "#FFAA0000", good: "#FF00AA00", wait: "#FFAA6600",
        wash: "#80FFFFFF" };
    var UW = 300, UH = 260, FOOT = 238, CELL = 19, COLS = 4;
    var SELF_X = 14, OTHER_X = 160, OFFER_Y = 50, MONEY_Y = OFFER_Y + COLS * CELL + 3, INV_X = 10, INV_Y = MONEY_Y + 28;

    var S = { d: null, at: 0, hits: [], ox: 0, oy: 0, serverClose: false, typed: false, note: "", bad: false, noteAt: 0 };

    function num(n) { return String(Math.floor(n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
    function send(d) { RPG.net.send("tr", d); }
    function isOpen() { return RPG.screen.getOpen() === "trading"; }
    function over(mx, my, x, y, w, h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    function note(t, bad) { S.note = t || ""; S.bad = !!bad; S.noteAt = RPG.nowMs(); }

    // inventory grid: three rows of the main inventory (slots 9-35), then the hotbar (0-8), like a chest screen
    function invPos(slot) {
        if (slot < 9) return { x: INV_X + slot * CELL, y: INV_Y + 3 * CELL + 3 };
        let i = slot - 9;
        return { x: INV_X + i % 9 * CELL, y: INV_Y + Math.floor(i / 9) * CELL };
    }
    function offerPos(base, i) { return { x: base + i % COLS * CELL, y: OFFER_Y + Math.floor(i / COLS) * CELL }; }

    // ---- drawing kit: the engine's vanilla pieces ------------------------------------------------------------

    function box(ctx, x, y, w, h) { ctx.field(x, y, w, h, false); }
    function fit(ctx, text, w) {
        text = String(text);
        if (ctx.textWidth(text) <= w) return text;
        while (text.length > 1 && ctx.textWidth(text + "...") > w) text = text.substring(0, text.length - 1);
        return text + "...";
    }
    function label(ctx, text, x, y, color, w) { ctx.text(w ? fit(ctx, text, w) : String(text), x, y, color, false); }
    function centered(ctx, text, cx, y, color) { ctx.text(text, Math.round(cx - ctx.textWidth(text) / 2), y, color, false); }
    function outline(ctx, x, y, w, h, color) {
        ctx.rect(x - 1, y - 1, w + 2, 1, color); ctx.rect(x - 1, y + h, w + 2, 1, color);
        ctx.rect(x - 1, y, 1, h, color); ctx.rect(x + w, y, 1, h, color);
    }
    function button(ctx, mx, my, x, y, w, h, text, fn, disabled) {
        ctx.button(fit(ctx, text, w - 8), x, y, w, h, !disabled);
        S.hits.push({ x: x, y: y, w: w, h: h, fn: disabled ? null : fn });
    }

    // ---- the screen ---------------------------------------------------------------------------------------

    function el(list, e) { e.anchor = "center"; e.x = -UW / 2 + e.x; e.y = -UH / 2 + e.y; list.push(e); return e; }
    function cell(list, prefix, i, x, y) {
        el(list, { id: "s" + prefix + i, type: "panel", style: "slot", x: x, y: y, w: 18, h: 18 });
        el(list, { id: "i" + prefix + i, type: "item", item: "minecraft:stone", x: x + 1, y: y + 1, w: 16, h: 16, tooltip: "item", visible: false });
    }

    function build() {
        let els = [];
        el(els, { id: "win", type: "panel", x: 0, y: 0, w: UW, h: UH });
        for (let i = 0; i < 16; i++) {
            let a = offerPos(SELF_X, i), b = offerPos(OTHER_X, i);
            cell(els, "o", i, a.x, a.y);
            cell(els, "t", i, b.x, b.y);
        }
        for (let slot = 0; slot < 36; slot++) { let p = invPos(slot); cell(els, "v", slot, p.x, p.y); }
        el(els, { id: "money", type: "input", x: 64, y: MONEY_Y + 3, w: 44, h: 9, bordered: false, maxLength: 12, value: String(S.d.selfMoney || 0),
            onChange: () => { S.typed = true; } });
        S.serverClose = false; S.typed = false;
        // GUI pixels like a chest screen; only a window too small for the panel scales it down to fit
        RPG.screen.open({ id: "trading", referenceHeight: RPG.screenHeight < UH + 4 ? UH + 4 : 0, title: "Trade", background: "dim", elements: els, onRender: render, onMouse: mouse, onKey: key,
            onClose: () => { if (!S.serverClose) send({ a: "cancel" }); } });
        sync();
    }

    function setCell(prefix, i, st) {
        if (st) RPG.screen.update("i" + prefix + i, { visible: true, item: st.id, count: st.count, nbt: st.nbt || "" });
        else RPG.screen.update("i" + prefix + i, { visible: false });
    }
    function sync() {
        if (!isOpen() || !S.d) return;
        let d = S.d;
        for (let i = 0; i < 16; i++) {
            let on = i < d.maxItems;
            RPG.screen.update("so" + i, { visible: on }); RPG.screen.update("st" + i, { visible: on });
            setCell("o", i, d.selfOffer[i]);
            setCell("t", i, d.otherOffer[i]);
        }
        for (let slot = 0; slot < 36; slot++) setCell("v", slot, d.inv[slot]);
        RPG.screen.update("money", { visible: !!d.money });
        if (!S.typed) RPG.screen.update("money", { value: String(d.selfMoney || 0) });
    }

    function render(ctx) {
        let d = S.d;
        if (!d) return;
        S.ox = Math.round(ctx.width / 2 - UW / 2); S.oy = Math.round(ctx.height / 2 - UH / 2);
        let mx = ctx.mouseX - S.ox, my = ctx.mouseY - S.oy;
        S.hits = [];
        ctx.push(); ctx.translate(S.ox, S.oy);

        label(ctx, "Trade", 8, 9, COL.title);
        if (d.money) { let bal = num(d.balance) + " " + d.currency; ctx.text(bal, UW - 8 - ctx.textWidth(bal), 9, COL.title, false); }

        // column headers + confirmation state
        label(ctx, "Your offer", SELF_X, 28, COL.title, 140);
        label(ctx, d.other + "'s offer", OTHER_X, 28, COL.title, 130);
        label(ctx, d.selfConfirmed ? "You: confirmed" : "You: not confirmed", SELF_X, 38, d.selfConfirmed ? COL.good : COL.wait, 140);
        label(ctx, d.otherConfirmed ? d.other + ": confirmed" : d.other + ": waiting", OTHER_X, 38, d.otherConfirmed ? COL.good : COL.muted, 130);
        let gw = COLS * CELL - 1;
        if (d.selfConfirmed) outline(ctx, SELF_X, OFFER_Y, gw, gw, COL.good);
        if (d.otherConfirmed) outline(ctx, OTHER_X, OFFER_Y, gw, gw, COL.good);

        // your stacks: click to take back; inventory: click to offer (not while you are confirmed)
        let locked = d.selfConfirmed;
        d.selfOffer.forEach((st, i) => {
            let p = offerPos(SELF_X, i);
            if (!locked && over(mx, my, p.x, p.y, 18, 18)) ctx.rect(p.x, p.y, 18, 18, COL.wash);
            S.hits.push({ x: p.x, y: p.y, w: 18, h: 18, fn: locked ? null : () => send({ a: "remove", index: i }) });
        });
        d.inv.forEach((st, slot) => {
            if (!st) return;
            let p = invPos(slot);
            if (!locked && over(mx, my, p.x, p.y, 18, 18)) ctx.rect(p.x, p.y, 18, 18, COL.wash);
            S.hits.push({ x: p.x, y: p.y, w: 18, h: 18, fn: locked ? null : () => {
                if (d.selfOffer.length >= d.maxItems) { note("Your trade offer is full.", true); return; }
                send({ a: "add", slot: slot, id: st.id, count: st.count });
            } });
        });

        // money row: your stake (field + Set), theirs read-only
        if (d.money) {
            label(ctx, "Your " + d.currency.toLowerCase(), SELF_X, MONEY_Y + 3, COL.row, 44);
            box(ctx, 60, MONEY_Y + 1, 52, 11);
            button(ctx, mx, my, 116, MONEY_Y, 30, 14, "Set", setMoney, locked);
            label(ctx, d.other + "'s " + d.currency.toLowerCase() + ": " + num(d.otherMoney), OTHER_X, MONEY_Y + 3, COL.title, 130);
        }
        label(ctx, locked ? "Your inventory (unconfirm to change your offer)" : "Your inventory (click to offer)", INV_X, INV_Y - 11, COL.row, 270);

        // footer: countdown / message, Confirm, Cancel
        let left = d.cd > 0 ? Math.max(0, d.cd - (RPG.nowMs() - S.at)) : 0;
        if (d.cd > 0) label(ctx, "Trading in " + Math.ceil(left / 1000) + "...", 10, FOOT + 4, COL.title, 116);
        else if (S.note && RPG.nowMs() - S.noteAt < 6000) label(ctx, S.note, 10, FOOT + 4, S.bad ? COL.bad : COL.good, 116);
        else label(ctx, "Trading with " + d.other, 10, FOOT + 4, COL.muted, 116);
        button(ctx, mx, my, 130, FOOT, 90, 14, d.selfConfirmed ? "Unconfirm" : "Confirm", () => send({ a: "confirm" }));
        button(ctx, mx, my, 224, FOOT, 70, 14, "Cancel", () => send({ a: "cancel" }));
        ctx.pop();
    }

    function setMoney() {
        let raw = String(RPG.screen.value("money") || "").replace(/[, _]/g, "").trim();
        if (raw === "") raw = "0";
        if (!/^\d{1,15}$/.test(raw)) { note("Enter a whole number.", true); return; }
        let amt = parseInt(raw, 10);
        if (amt > S.d.maxMoney) { note("At most " + num(S.d.maxMoney) + ".", true); return; }
        S.typed = false;
        send({ a: "money", amount: amt });
    }

    function mouse(x, y, button, action) {
        if (action !== "down" || button !== 0) return;
        let mx = x - S.ox, my = y - S.oy;
        for (let i = S.hits.length - 1; i >= 0; i--) {
            let h = S.hits[i];
            if (!over(mx, my, h.x, h.y, h.w, h.h)) continue;
            if (h.fn) { RPG.sound("minecraft:ui.button.click", 0.25, 1); h.fn(); }
            return false;
        }
    }
    function key(k, action) {
        if (action === "down" && (k === "key.keyboard.enter" || k === "key.keyboard.keypad.enter")) { if (S.d && S.d.money && !S.d.selfConfirmed) setMoney(); return false; }
    }

    RPG.net.on("tr_view", (v) => {
        if (!v) return;
        if (!v.active) {
            // server-driven end: close without sending a cancel back
            S.d = null;
            if (isOpen()) { S.serverClose = true; RPG.screen.close(); }
            return;
        }
        S.d = v; S.at = RPG.nowMs();
        if (v.note) { note(v.note, v.bad); if (v.bad) RPG.sound("minecraft:block.note_block.bass", 0.4, 0.8); }
        if (!isOpen()) { if (v.open) build(); return; }
        sync();
    });
})();
