// =====================================================================================
//  Player Vaults - /pv [n]: a private 6-row chest you can open anywhere
// =====================================================================================
//  Everyone gets VAULTS.free vaults; vaults.amount.<n> raises it (e.g. vaults.amount.5).
//  Admins (vaults.admin) can open anyone's: /pv <n> <player>. Saved with the world.
//  Items only players may carry (RPG.items.confine, e.g. dragon balls) can't be stored (refuseConfined); one
//  found in a vault from before goes back to its owner when they open it (into a free slot, never dropped).
(function () {
    var VAULTS = { free: 1, rows: 6, max: 50, refuseConfined: true,
                   confinedMessage: "&cThat item can only be carried by players, so it can't be stored in a vault." };
    RPG.perms.group("default", ["vaults.use"]);
    RPG.perms.group("vip", ["vaults.amount.3"]);
    RPG.perms.group("admin", ["vaults.*"]);

    function allowed(p) {
        if (RPG.perms.has(p, "vaults.amount.unlimited")) return VAULTS.max;
        let n = VAULTS.free;
        for (let i = 2; i <= VAULTS.max; i++) if (RPG.perms.has(p, "vaults.amount." + i)) n = i;
        return n;
    }
    function key(uuid, n) { return "pv:" + uuid + ":" + n; }
    function confined(st) { try { return !!st && RPG.items.isConfined(st); } catch (e) { return false; } }
    /** Stored before they were confined: out of the vault and back to its owner (free slots only). */
    function handBack(owner, items) {
        let free = 0, moved = 0;
        for (let i = 0; i < 36; i++) if (!owner.getStack(i)) free++;
        for (let i = 0; i < items.length; i++) {
            if (!confined(items[i])) continue;
            if (free <= 0) { owner.tell("&eMake room in your inventory to get the items only players may carry back out of this vault."); break; }
            owner.giveStack(items[i]);
            items[i] = null;
            free--; moved++;
        }
        return moved;
    }
    function open(viewer, ownerUuid, ownerName, n) {
        let items = RPG.data.get(key(ownerUuid, n), []);
        if (!Array.isArray(items)) items = [];
        if (VAULTS.refuseConfined && ownerUuid === viewer.uuid && handBack(viewer, items) > 0) {
            RPG.data.set(key(ownerUuid, n), items);      // saved at once: they are in the inventory now
            viewer.tell("&eItems that only players may carry can't stay in a vault: they were put in your inventory.");
        }
        RPG.ui.container(viewer, {
            title: "&8Vault #" + n + (ownerUuid === viewer.uuid ? "" : " (" + ownerName + ")"),
            rows: VAULTS.rows,
            items: items,
            allowConfined: !VAULTS.refuseConfined, confinedMessage: VAULTS.confinedMessage,
            onClose(p, items) { RPG.data.set(key(ownerUuid, n), items); }
        });
        viewer.playSound("minecraft:block.chest.open", 0.6, 1);
    }

    RPG.commands.register("pv", {
        root: true, aliases: ["vault", "playervault"], permission: "vaults.use",
        description: "Open a vault: /pv [number]",
        suggest(p, args) { let out = []; if (args.length <= 1) for (let i = 1; i <= Math.min(allowed(p), 20); i++) out.push(String(i)); else out = RPG.server.players().map((q) => q.name); return out; },
        run(p, args) {
            if (!p) return;
            let n = args.length ? parseInt(args[0]) : 1;
            if (!(n >= 1)) { p.tell("&c/pv <number>"); return; }
            if (args.length > 1) {
                if (!RPG.perms.has(p, "vaults.admin")) { p.tell("&cYou can only open your own vaults."); return; }
                let t = RPG.server.player(args[1]);
                if (!t) { p.tell("&cThat player isn't online."); return; }
                open(p, t.uuid, t.name, n);
                return;
            }
            if (n > allowed(p)) { p.tell("&cYou have " + allowed(p) + " vault" + (allowed(p) === 1 ? "" : "s") + "."); return; }
            open(p, p.uuid, p.name, n);
        }
    });
})();
