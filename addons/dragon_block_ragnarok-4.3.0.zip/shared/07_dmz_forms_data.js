// =====================================================================================
//  DMZ transformations data (DefaultFormsFactory defaults) + the pure rules around them
//  (TransformationsHelper, StatsData multipliers, FormModeHandler requirements, TickHandler
//  drains). Shared: the server (scripts/31_dmz_transform.js) runs the state machine, the
//  client (client/scripts/45_transform.js) shows the form menu from the same tables.
//
//  Ported from DragonMine Z (GPL-3.0) - values copied on purpose, see NOTICE.md.
//  docs/dmz-spec/02_forms_visuals.md section 2 lists every number below.
//
//  A group is an ordered list (the order IS the transformation ladder). Form fields
//  (omitted = DMZ FormData default):
//    n      display name                 lvl    unlockOnSkillLevel     saga  sagaRequisite (gates buying the level)
//    m      [STR, SKP, DEF, PWR]         spd    speedMultiplier        atk   attackSpeed
//    stmM   staminaDrainMultiplier       ki/sd/hd  energy/stamina/health drain (per second factors)
//    model  DMZ customModel key          scale  modelScaling (number or [x, y, z]) - absolute
//    anim   transformationAnimation      hair   hairType ("", base, ssj, ssj2, ssj3, ssj4, empty)
//    c      colour overrides {hair, eye1, eye2, body1, body2, body3}
//    aura   auraColor                    bolt   lightningColor (hasLightnings)
//    tint   [hex, intensity]             ult    incompatible with ultimate.ultimate
//    free   allowFreeTransformOnMastery (first form of a group: 0)
//    keepHead, tailOnly, req (formRequisite override), share [["group.form", mult]],
//    stackOn, stackDrain, stackable, maxMastery, layers (extra overlays, 30_forms.js)
// =====================================================================================
var DMZ_FORMS = (function () {
    var D = {
        maxMastery: 100, perHit: 0.025, passive: 0.004, maxStats: 1.5, maxCost: 0.75, stackOn: 25,
        instantOn: 40, freeOn: 50, unlockOn: 25, stackDrain: 2.0, anim: "transf.generic", scale: 0.9375,
        baselineDrain: 80
    };
    var RACE_SCALE = { frostdemon: 0.7375 };

    // ---- helpers to keep the tables short -------------------------------------------
    function F(id, n, lvl, saga, m, ki, x) {
        var f = { id: id, n: n, lvl: lvl, saga: saga || "", m: m, ki: ki || 0 };
        for (var k in (x || {})) f[k] = x[k];
        return f;
    }
    var SSJ_G = { hair: "#FFEDB3", body2: "#FFEDB3", eye1: "#00FFFF", eye2: "#00FFFF" };
    var SSJ_M = { hair: "#FFE89E", body2: "#FFE89E", eye1: "#00FFFF", eye2: "#00FFFF" };
    function eyes(c) { return { eye1: c, eye2: c }; }
    function mix(a, b) { var o = {}, k; for (k in a) o[k] = a[k]; for (k in b) o[k] = b[k]; return o; }

    // ---- race groups (DefaultFormsFactory) -------------------------------------------
    var GROUPS = {
        human: [
            { id: "superforms", type: "superforms", n: "Super", forms: [
                F("buffed", "Buffed", 1, "classic_saga:46", [1.7, 1.85, 1.425, 1.5], 0.109, { model: "buffedg3", scale: [1.2, 1.1, 1.2], hair: "base" }),
                F("fullpower", "Full Power", 2, "saiyan_saga:12", [2.25, 2.45, 1.9375, 2.05], 0.25, { scale: 1.0, hair: "ssj" }),
                F("overdrive", "Overdrive", 3, "frieza_saga:10", [3.15, 3.3, 2.65, 2.85], 0.618, { scale: 1.1, hair: "ssj2", aura: "#FFFD99", bolt: "#E6F2F5" }),
                F("solaris", "Solaris", 4, "buu_saga:35", [4.6, 4.75, 3.6, 4.25], 0.479, { scale: 1.0, hair: "ssj2", aura: "#FFE11A", ult: 1, smoke: 1 })
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Legendary", forms: [
                F("shiyoken", "Shiyoken", 1, "", [3.75, 3.75, 2.8625, 3.75], 0.426, { scale: 1.1, hair: "base", tint: ["#FF0000", 0.25], aura: "#A10000", bolt: "#FF4F4F", shiyoken: 1 }),
                F("shin_shiyoken", "Shin Shiyoken", 2, "", [4.8, 4.8, 3.5875, 4.8], 0.613, { model: "buffed", scale: 1.3, hair: "base", tint: ["#FF0000", 0.25], aura: "#A10000", bolt: "#FF4F4F", shiyoken: 1 }),
                F("chou_shiyoken", "Chou Shiyoken", 3, "", [5.6, 5.6, 4.0125, 5.6], 0.805, { model: "4arms", scale: 1.5, hair: "base", tint: ["#FF0000", 0.25], aura: "#A10000", bolt: "#FF4F4F", shiyoken: 1 })
            ]},
            { id: "androidforms", type: "androidforms", n: "Android", forms: [
                F("androidbase", "Android Base", 0, "", [2.15, 2.15, 1.8625, 2.5], 0, { scale: 1.0, hair: "base", android: 1 }),
                F("superandroid", "Super Android", 1, "frieza_saga:10", [3.2, 3.2, 2.575, 3.65], 0, { model: "buffed", scale: 1.05, hair: "ssj", android: 1 }),
                F("fusedandroid", "Fused Android", 2, "buu_saga:1", [4.1, 4.1, 3.3, 4.7], 0, { model: "buffedg3", scale: [1.4, 1.3, 1.4], hair: "ssj2", stmM: 2.5, atk: 0.85,
                    c: { hair: "#E65332", eye1: "#FFFFFF", eye2: "#FFFFFF", body1: "#4D9AE8" }, bolt: "#E63232", android: 1 })
            ]}
        ],
        saiyan: [
            { id: "oozaru", type: "superforms", n: "Oozaru", forms: [
                F("oozaru", "Oozaru", 0, "", [1.25, 1.25, 1.15, 1.25], 0.056, { spd: 0.8, stmM: 1.2, atk: 0.25, model: "oozaru", scale: 3.8, anim: "transf.ozaru", hair: "base", tailOnly: 1 }),
                F("goldenoozaru", "Golden Oozaru", 7, "buu_saga:1", [2.15, 2.15, 2.3, 2.15], 0.352, { spd: 0.85, stmM: 1.3, atk: 0.25, model: "oozaru", scale: 3.8, anim: "transf.ozaru",
                    c: { hair: "#FFD700", body2: "#FFD700" }, aura: "#FFD700", hair: "base", tailOnly: 1 }),
                F("supersaiyan4", "SSJ 4 [GT]", 8, "buu_saga:35", [4.75, 4.75, 3.5625, 4.75], 0.523, { model: "ssj4gt", anim: "transf.ozaru",
                    c: { body2: "#9d1e31", eye1: "#FFD700", eye2: "#FFD700" }, aura: "#FFD700", hair: "ssj4", ult: 1, free: 50, ssj4: "gt" })
            ]},
            { id: "ssgrades", type: "superforms", n: "Super Saiyan", forms: [
                F("supersaiyan", "SSJ", 1, "classic_saga:46", [1.6, 1.6, 1.375, 1.6], 0.101, { c: SSJ_G, aura: "#FFD700", hair: "ssj" }),
                F("supersaiyangrade2", "SSJ Grade 2", 2, "saiyan_saga:12", [1.85, 1.85, 1.575, 1.85], 0.163, { spd: 0.9, stmM: 1.3, model: "buffed", scale: 1.0, anim: "transf.ssg2", c: SSJ_G, aura: "#FFD700", hair: "ssj" }),
                F("supersaiyangrade3", "SSJ Grade 3", 3, "frieza_saga:5", [3.0, 3.0, 2.15, 3.0], 0.831, { spd: 0.7, stmM: 3.5, atk: 0.75, model: "buffedg3", scale: 1.1, c: SSJ_G, aura: "#FFD700", hair: "ssj" })
            ]},
            { id: "supersaiyan", type: "superforms", n: "Super Saiyan+", forms: [
                F("supersaiyanmastered", "SSJ Mastered", 4, "android_saga:4", [1.85, 1.85, 1.5, 1.85], 0.041, { c: SSJ_M, aura: "#FFD700", hair: "ssj" }),
                F("supersaiyan2", "SSJ 2", 5, "android_saga:15", [2.45, 2.45, 1.9375, 2.45], 0.25, { c: SSJ_M, aura: "#FFD700", hair: "ssj2", bolt: "#A1FFF9", big: 1 }),
                F("supersaiyan3", "SSJ 3", 6, "buu_saga:1", [3.3, 3.3, 2.65, 3.3], 0.618, { anim: "transf.ssj3", c: SSJ_M, aura: "#FFD700", hair: "ssj3", bolt: "#A1FFF9", big: 1 }),
                F("supersaiyan4", "SSJ 4 [D]", 8, "buu_saga:35", [4.75, 4.75, 3.5625, 4.75], 0.523, { model: "ssj4d", scale: 1.2, anim: "transf.daima",
                    c: { hair: "#83073F", body2: "#83073F", eye1: "#83073F", eye2: "#83073F" }, aura: "#FFD633", hair: "ssj4", bolt: "#82C9FF", ult: 1, ssj4: "d" })
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Mutant", forms: [
                F("ikari", "Ikari", 1, "", [3.75, 3.75, 2.8625, 3.75], 0.194, { model: "buffed", scale: 1.1, anim: "transf.berserker", hair: "ssj", c: eyes("#FFD700"), aura: "#40FF00" }),
                F("ssjhybrid", "SSJ Hybrid", 2, "", [4.8, 4.8, 3.5875, 4.8], 0.351, { model: "buffed", scale: 1.15, anim: "transf.berserker", hair: "ssj",
                    c: { hair: "#FFE89E", body2: "#FFE89E", eye1: "#FFFFFF", eye2: "#FFFFFF" }, aura: "#40FF00", bolt: "#40FF00" }),
                F("ssjfullpower", "SSJ Full Power", 3, "", [5.6, 5.6, 4.0125, 5.6], 0.615, { model: "buffedg3", scale: [1.4, 1.3, 1.4], anim: "transf.berserker", hair: "ssj2",
                    c: { hair: "#9EFE53", body2: "#9EFE53", eye1: "#FFFFFF", eye2: "#FFFFFF" }, aura: "#40FF00", bolt: "#40FF00" })
            ]},
            // scripted (rage bar / ritual): never chargeable, listed so the state can hold them
            { id: "falseform", type: "falseform", n: "False Form", scripted: 1, forms: [
                F("falsesupersaiyan", "False Super Saiyan", 99, "", [1.45, 1.45, 1.2875, 1.45], 0, { anim: "transf.berserker", hair: "ssj",
                    c: { hair: "#6B1208", body2: "#6B1208", eye1: "#FFFFFF", eye2: "#FFFFFF" }, aura: "#FFD84D", tint: ["#FFD21F", 0.55], stackable: 0 })
            ]}
        ],
        namekian: [
            { id: "superforms", type: "superforms", n: "Super", forms: [
                F("giant", "Giant", 1, "classic_saga:46", [2.15, 2.15, 1.8625, 2.15], 0.132, { atk: 0.25, scale: 3.6, keepHead: 1 }),
                F("fullpower", "Full Power", 2, "frieza_saga:10", [3.15, 3.15, 2.5125, 3.15], 0.319, { scale: 1.0, keepHead: 1 }),
                F("supernamekian", "Super Namekian", 3, "buu_saga:35", [4.75, 4.75, 3.5625, 4.75], 0.588, { model: "namekian_buffed", scale: 1.05, aura: "#7FFF00", bolt: "#FFFFFF", keepHead: 1, ult: 1 })
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Legendary", forms: [
                F("evilnamek", "Evil Namek", 1, "", [3.75, 3.75, 2.8625, 3.75], 0.349, { scale: 1.0, c: { eye1: "#FFFFFF", eye2: "#FFFFFF", body1: "#386327" }, aura: "#570B0B", bolt: "#D9180F", hair: "base", keepHead: 1 }),
                F("evilgiantnamek", "Evil Giant Namek", 2, "", [4.8, 4.8, 3.5875, 4.8], 0.548, { spd: 0.75, atk: 0.25, stmM: 1.5, model: "namekian_buffed", scale: 3.8,
                    c: { eye1: "#9E092F", eye2: "#9E092F", body1: "#274D18" }, aura: "#570B0B", hair: "base", keepHead: 1 }),
                F("buffednamek", "Buffed Namek", 3, "", [5.6, 5.6, 4.0125, 5.6], 0.568, { model: "namekian_buffed", scale: 1.3,
                    c: { eye1: "#9E092F", eye2: "#9E092F", body1: "#2C6914" }, aura: "#570B0B", bolt: "#D9180F", hair: "base", keepHead: 1 })
            ]}
        ],
        frostdemon: [
            { id: "evolutionforms", type: "superforms", n: "Evolution", forms: [
                F("second", "Second Form", 1, "classic_saga:46", [1.75, 1.75, 1.425, 1.75], 0, { model: "frostdemon_second", scale: 1.3, anim: "transf.freezer", keepHead: 1 }),
                F("third", "Third Form", 2, "saiyan_saga:12", [2.25, 2.25, 1.9375, 2.25], 0, { model: "frostdemon_third", scale: 1.4, anim: "transf.freezer" }),
                F("final", "Final Form", 3, "frieza_saga:10", [2.85, 2.85, 2.3625, 2.85], 0, { model: "frostdemon_final", scale: 1.0 }),
                F("fullpower", "Full Power", 4, "buu_saga:1", [3.45, 3.45, 2.725, 3.45], 0.409, { stmM: 2.5, atk: 0.75, model: "frostdemon_fp", scale: [1.3, 1.2, 1.3] }),
                F("fifth", "Fifth Form", 5, "buu_saga:35", [4.9, 4.9, 3.6875, 4.9], 0.62, { model: "frostdemon_fifth", scale: [1.4, 1.3, 1.4], c: eyes("#D91E1E"), bolt: "#F02B16", ult: 1 })
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Artificial", forms: [
                F("mecha", "Mecha", 1, "", [3.9, 3.9, 2.9375, 3.9], 0, { model: "frostdemon_mecha", bolt: "#FF6052", layers: [["frostdemon/mechaform_layer1", "fBody1"]] }),
                F("metal", "Metal", 2, "", [4.9, 4.9, 3.6625, 4.9], -0.05, { model: "frostdemon_final", scale: 1.1, c: { body1: "#B8FFF0", body2: "#CCFDFF", body3: "#B8FFF0", hair: "#B8FFF0" }, bolt: "#B5FDFF" }),
                F("metalcore", "Metal-Core", 3, "", [5.7, 5.7, 4.0875, 5.7], -0.1, { atk: 0.25, model: "frostdemon_metalcore", scale: 3.8,
                    layers: [["frostdemon/metalcore_layer1", "#9BA377"], ["frostdemon/metalcore_layer2", "#20211A"]] })
            ]}
        ],
        majin: [
            { id: "pureforms", type: "superforms", n: "Pure", forms: [
                F("kid", "Kid Majin", 1, "classic_saga:46", [1.85, 1.85, 1.575, 1.85], 0, { model: "majin_kid", scale: 0.7, keepHead: 1 }),
                F("evil", "Evil Majin", 2, "frieza_saga:5", [2.45, 2.45, 2.15, 2.45], 0, { model: "majin_evil", scale: [0.9, 1.0, 0.9],
                    c: { hair: "#917979", body1: "#917979", body2: "#917979", body3: "#917979", eye1: "#F52746", eye2: "#F52746" }, keepHead: 1 }),
                F("super", "Super Majin", 3, "buu_saga:1", [3.3, 3.3, 2.8, 3.3], 0, { model: "majin_super", scale: 1.0, keepHead: 1 }),
                F("ultra", "Ultra Majin", 4, "buu_saga:35", [4.75, 4.75, 3.725, 4.75], 0.479, { stmM: 3.5, model: "majin_ultra", scale: [1.3, 1.2, 1.3], bolt: "#F02B16", keepHead: 1, ult: 1, big: 1 })
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Demon", forms: [
                F("innocencedemon", "Innocence Demon", 1, "", [3.75, 3.75, 2.8625, 3.75], 0, { model: "janemba_imperfect", scale: 1.4, anim: "transf.janemba", hair: "empty" }),
                F("giantinnocencedemon", "Giant Innocence Demon", 2, "", [4.8, 4.8, 3.5875, 4.8], 0.548, { atk: 0.25, model: "janemba_fat", scale: 3.8, anim: "transf.janemba", hair: "empty",
                    c: { body1: "#FFFC82", body2: "#FFB8FD", eye1: "#303030", eye2: "#303030" } }),
                F("superdemon", "Super Demon", 3, "", [5.6, 5.6, 4.0125, 5.6], 0, { model: "janemba_super", scale: 1.1, anim: "transf.janemba", hair: "empty",
                    c: { body1: "#FF6161", body2: "#E1A8FF", eye1: "#FFE98A", eye2: "#303030" } })
            ]}
        ],
        bioandroid: [
            { id: "bioevolution", type: "superforms", n: "Bio Evolution", forms: [
                F("semiperfect", "Semi-Perfect", 1, "classic_saga:46", [1.85, 1.85, 1.575, 1.85], 0, { model: "bioandroid_semi", scale: 1.3, c: { eye1: "#BA1414", eye2: "#FFFFFF" } }),
                F("perfect", "Perfect", 2, "frieza_saga:5", [2.6, 2.6, 2.225, 2.6], 0, { model: "bioandroid_perfect", scale: 1.1,
                    c: { eye1: "#BA1414", eye2: "#FFFFFF", body2: "#FFFFFF", body3: "#FFED61", hair: "#7C28B0" }, aura: "#FFFF69" }),
                F("superperfect", "Super Perfect", 3, "buu_saga:1", [3.35, 3.35, 2.65, 3.35], 0.293, { model: "bioandroid_perfect", scale: 1.1,
                    c: { eye1: "#BA1414", eye2: "#FFFFFF", body2: "#FFFFFF", body3: "#FFED61", hair: "#7C28B0" }, aura: "#FFFF69", bolt: "#1AA1C7", big: 1 }),
                F("ultraperfect", "Ultra Perfect", 4, "buu_saga:35", [4.9, 4.9, 3.6875, 4.9], 0.62, { spd: 0.6, stmM: 3.5, atk: 0.55, model: "bioandroid_ultra", scale: 1.3,
                    c: { eye1: "#BA1414", eye2: "#FFFFFF", body2: "#FFFFFF", body3: "#FFED61", hair: "#7C28B0" }, aura: "#FFFF69", bolt: "#1AA1C7", ult: 1 })
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Bio-Corruption", forms: [
                F("xeno", "Xeno", 1, "", [3.9, 3.9, 2.9375, 3.9], 0.118, { model: "bioandroid_ultra", scale: 1.1,
                    c: { eye1: "#FFFFFF", eye2: "#FFFFFF", body2: "#DBC8C8", body3: "#4C3554", hair: "#4C3554" }, aura: "#2C0A4A", bolt: "#340063", xeno: 1 }),
                F("xenofp", "Xeno Full Power", 2, "", [4.9, 4.9, 3.6625, 4.9], 0.354, { model: "bioandroid_xeno", scale: 1.3,
                    c: { eye1: "#BA1414", eye2: "#BA1414", body2: "#DBC8C8", body3: "#4C3554", hair: "#4C3554" }, aura: "#2C0A4A", bolt: "#340063", xeno: 1, noStinger: 1 }),
                F("xenomax", "Xeno Max", 3, "", [5.7, 5.7, 4.0875, 5.7], 0.525, { model: "bioandroid_xenofp", scale: 3.8,
                    c: { eye1: "#BA1414", eye2: "#BA1414", body2: "#DBC8C8", body3: "#4C3554", hair: "#4C3554" }, aura: "#2C0A4A", bolt: "#340063", xeno: 1, noStinger: 1 })
            ]}
        ],
        glind: [
            { id: "superforms", type: "superforms", n: "Super", forms: [
                F("buffed", "Buffed", 1, "classic_saga:46", [1.75, 1.75, 1.425, 1.75], 0.106, { model: "buffed", scale: 1.05, keepHead: 1 }),
                F("outofcontrol", "Out of Control", 2, "saiyan_saga:12", [2.25, 2.25, 1.9375, 2.25], 0.24, { model: "buffed", scale: 1.1, anim: "transf.berserker", c: eyes("#E01414"), aura: "#E01B1B", keepHead: 1 }),
                F("super", "Super", 3, "frieza_saga:10", [2.85, 2.85, 2.3625, 2.85], 0.371, { model: "buffed", scale: [1.2, 1.1, 1.2], anim: "transf.berserker", c: eyes("#E01414"), aura: "#2F6BFF", keepHead: 1 }),
                F("absorption", "Absorption", 4, "buu_saga:1", [3.45, 3.45, 2.725, 3.45], 0.446, { model: "ssj4gt", scale: 1.1, aura: "#2F6BFF", hair: "ssj4", keepHead: 1, ssj4: "final", furHair: 1 }),
                F("trueform", "True Form", 5, "buu_saga:35", [4.9, 4.9, 3.6875, 4.9], 0.62, { model: "glindtrueform", scale: [1.95, 2.1, 1.95], hair: "ssj3",
                    c: { hair: "#BE3C48", body1: "#247FA2", body2: "#D2D2C6", eye1: "#A61717", eye2: "#A61717" }, aura: "#7B2FBE", ult: 1 })
            ]},
            { id: "legendaryforms", type: "legendaryforms", n: "Legendary", forms: [
                F("transcended", "Transcended", 1, "", [3.75, 3.75, 2.8625, 3.75], 0.426, { model: "trascended", scale: 1.4, hair: "ssj2", keepHead: 1,
                    c: { hair: "#BE3C48", body1: "#D2D2C6", body2: "#247FA2", eye1: "#FFD700", eye2: "#FFD700" }, aura: "#7B2FBE" }),
                F("darkking", "Dark King", 2, "", [4.8, 4.8, 3.5875, 4.8], 0.613, { model: "buffedg3", scale: 1.1, hair: "ssj2", keepHead: 1,
                    c: { hair: "#F2234B", body1: "#D2D2C6", body2: "#3C3A3F", eye1: "#E01414", eye2: "#E01414" }, aura: "#B00000", sclera: "#050505" }),
                F("timepower_darkking", "Time Power: Dark King", 3, "", [5.6, 5.6, 4.0125, 5.6], 0.805, { model: "glinddark", scale: 1.1, keepHead: 1,
                    c: { hair: "#F2234B", body1: "#D2D2C6", body2: "#463E4A", body3: "#E82C3E", eye1: "#E01414", eye2: "#E01414" }, aura: "#AD0C0C", sclera: "#050505",
                    share: [["legendaryforms.timepower_realmoflight", 0.5]] }),
                F("timepower_realmoflight", "Time Power: Realm of Light", 3, "", [5.6, 5.6, 4.0125, 5.6], 0.805, { scale: [1.35, 1.45, 1.35], hair: "base", aura: "#FFF3C4", keepHead: 1,
                    req: "legendaryforms.darkking", share: [["legendaryforms.timepower_darkking", 0.5]] })
            ]}
        ]
    };

    // ---- stack forms (createDefaultStackForms: Kaioken + Ultimate) ------------------------
    function KK(id, lvl, m, sa, hd, ti, next) {
        return F(id, id, lvl, "", m, 0, { spd: sa, atk: sa, hd: hd, tint: ["#FF0000", ti], aura: "#DB182C", auraLayer: 1, stackOn: 0, stackDrain: 1.0,
            keepHead: 1, noReq: 1, share: next ? [["kaioken." + next, 0.25]] : null, ult: 1 });
    }
    var STACKS = [
        { id: "kaioken", type: "kaioken", n: "Kaioken", forms: [
            KK("x2", 1, [1.1, 1.1, 1.125, 1.1], 1.1, 0.033, 0.1, "x3"),
            KK("x3", 2, [1.2, 1.2, 1.25, 1.2], 1.2, 0.072, 0.2, "x4"),
            KK("x4", 3, [1.35, 1.35, 1.4375, 1.35], 1.35, 0.128, 0.3, "x10"),
            KK("x10", 4, [1.5, 1.5, 1.625, 1.5], 1.5, 0.165, 0.4, "x20"),
            KK("x20", 5, [1.65, 1.65, 1.8125, 1.65], 1.65, 0.248, 0.5, null)
        ]},
        { id: "ultimate", type: "ultimate", n: "Ultimate", forms: [
            F("ultimate", "Ultimate", 1, "", [2.0, 2.0, 1.1875, 2.0], 0, { maxMastery: 0, stackable: 0, aura: "#FFFFFF", hair: "ssj2", keepHead: 1, stackDrain: 1.0 })
        ]}
    ];

    // ---- post-processing: DMZ defaults, sequential requisites, lookups -------------------
    var BY = {};          // "race|group|form" (race "stack" for stacks) -> form
    function finish(race, g) {
        var superType = g.type === "superforms";
        g.forms.forEach(function (f, i) {
            f.race = race; f.group = g.id; f.type = g.type;
            f.key = g.id + ":" + f.id;
            if (f.free === undefined) f.free = i === 0 ? 0 : D.freeOn;
            if (f.incompat === undefined) f.incompat = f.ult ? ["ultimate.ultimate"] : (superType || race === "stack" ? [] : ["ultimate.ultimate"]);
            if (race === "stack" && g.id === "kaioken") f.incompat = ["ultimate.ultimate"];
            if (f.stackOn === undefined) f.stackOn = D.stackOn;
            if (f.stackDrain === undefined) f.stackDrain = D.stackDrain;
            if (f.stackable === undefined) f.stackable = 1;
            if (f.maxMastery === undefined) f.maxMastery = D.maxMastery;
            f.maxStats = f.maxMastery > 0 ? D.maxStats : 1.0;
            f.maxCost = D.maxCost;
            if (!f.anim) f.anim = D.anim;
            if (f.spd === undefined) f.spd = 1; if (f.atk === undefined) f.atk = 1; if (f.stmM === undefined) f.stmM = 1;
            f.sd = f.sd || 0; f.hd = f.hd || 0;
            if (f.scale === undefined) f.scale = D.scale;
            if (typeof f.scale === "number") f.scale = [f.scale, f.scale, f.scale];
            f.c = f.c || {};
            if (f.hair === undefined) f.hair = "";
            if (!f.noReq && f.req === undefined && i > 0) f.req = g.id + "." + g.forms[i - 1].id;
            f.unlockOn = f.req ? D.unlockOn : 0;
            BY[race + "|" + g.id + "|" + f.id] = f;
        });
    }
    Object.keys(GROUPS).forEach(function (r) { GROUPS[r].forEach(function (g) { finish(r, g); }); });
    STACKS.forEach(function (g) { finish("stack", g); });

    function groups(race) { return GROUPS[race] || []; }
    function group(race, id) { var out = null; groups(race).forEach(function (g) { if (g.id === id) out = g; }); return out; }
    function stackGroup(id) { var out = null; STACKS.forEach(function (g) { if (g.id === id) out = g; }); return out; }
    function form(race, g, f) { return BY[race + "|" + g + "|" + f] || null; }
    function stackForm(g, f) { return BY["stack|" + g + "|" + f] || null; }
    function index(grp, id) { for (var i = 0; i < grp.forms.length; i++) if (grp.forms[i].id === id) return i; return -1; }
    function skillFor(type) {
        var t = String(type || "").toLowerCase();
        if (t.indexOf("superform") >= 0) return "superforms";
        if (t.indexOf("legendaryform") >= 0) return "legendaryforms";
        if (t.indexOf("godform") >= 0) return "godforms";
        if (t.indexOf("androidform") >= 0) return "androidforms";
        return t;
    }
    function isScripted(type) { return type === "falseform" || type === "godritual"; }

    // ---- StatsData multipliers -------------------------------------------------------
    var STAT_INDEX = { STR: 0, SKP: 1, DEF: 2, PWR: 3 };
    function baseMult(f, stat) {
        if (!f) return 1;
        if (stat === "SPD") return f.spd;
        var i = STAT_INDEX[stat];
        if (i === undefined) return 1;                       // STM, VIT, ENE: 1.0 in every default form
        return Math.max(0.01, f.m[i]);
    }
    function clamp01(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
    /** applyMastery: b <= 1 stays; else x1.0 .. x maxStats (1.5) at full mastery. */
    function masteryMult(f, b, m) {
        if (b <= 1 || f.maxMastery <= 0) return b;
        return b * (1 + clamp01(m / f.maxMastery) * (f.maxStats - 1));
    }
    /** costFactor: x1.0 .. x0.75 at full mastery. */
    function costFactor(f, m) {
        if (!f || f.maxMastery <= 0) return 1;
        return 1 + clamp01(m / f.maxMastery) * (f.maxCost - 1);
    }
    function chargeStep(m) { return 10 + Math.min(15, Math.floor((m || 0) * 0.2)); }
    function compatible(base, stack) {
        if (!base || !stack) return true;
        if (base.incompat.indexOf(stack.group + "." + stack.id) >= 0) return false;
        if (stack.incompat.indexOf(base.group + "." + base.id) >= 0) return false;
        return true;
    }
    function scaleOf(race, f) { return f ? f.scale : [RACE_SCALE[race] || D.scale, RACE_SCALE[race] || D.scale, RACE_SCALE[race] || D.scale]; }

    // ---- colours (ColorUtils / DMZSkinLayer tint) ----------------------------------------
    function hexToRgb(h) { h = String(h || "#000000").replace("#", ""); var n = parseInt(h, 16) || 0; return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
    function rgbToHex(c) {
        function p(v) { v = Math.max(0, Math.min(255, Math.round(v))); return (v < 16 ? "0" : "") + v.toString(16); }
        return ("#" + p(c[0]) + p(c[1]) + p(c[2])).toUpperCase();
    }
    function lerpHex(a, b, t) {
        if (!a) return b; if (!b) return a;
        var x = hexToRgb(a), y = hexToRgb(b); t = clamp01(t);
        return rgbToHex([x[0] + (y[0] - x[0]) * t, x[1] + (y[1] - x[1]) * t, x[2] + (y[2] - x[2]) * t]);
    }
    /** darkTintScale: 0.15 + 0.85 * min(1, luminance / 0.35) */
    function darkTintScale(hex) {
        var c = hexToRgb(hex), lum = (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
        return 0.15 + 0.85 * Math.min(1, lum / 0.35);
    }
    function tint(hex, tintHex, intensity) {
        if (!intensity) return hex;
        return lerpHex(hex, tintHex, clamp01(intensity) * darkTintScale(hex));
    }

    return { D: D, GROUPS: GROUPS, STACKS: STACKS, RACE_SCALE: RACE_SCALE, groups: groups, group: group, stackGroup: stackGroup, form: form, stackForm: stackForm,
        index: index, skillFor: skillFor, isScripted: isScripted, baseMult: baseMult, masteryMult: masteryMult, costFactor: costFactor, chargeStep: chargeStep,
        compatible: compatible, scaleOf: scaleOf, lerpHex: lerpHex, tint: tint, darkTintScale: darkTintScale, hexToRgb: hexToRgb, rgbToHex: rgbToHex, mix: mix };
})();
