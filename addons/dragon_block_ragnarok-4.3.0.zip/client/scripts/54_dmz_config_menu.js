// =====================================================================================
//  54_dmz_config_menu.js - DragonMine Z's options screen (the V menu's Config button)
// =====================================================================================
//  Ported from DragonMine Z (GPL-3.0): client/gui/character/ConfigMenuScreen (two menubig
//  panels: "Options" with a search field and collapsible Interface / Gameplay / Visuals /
//  Audio categories, "Values" with DMZ's switches, -/+ steppers and "Open »" buttons).
//  Textures: dmzpack:textures/gui/menu/menubig.png, gui/buttons/characterbuttons.png.
//
//  Each option is stored on this computer (RPG.storage) under the key the matching DBR
//  feature reads. Options DBR has no feature for yet are shown like DMZ's, greyed out, with
//  a tooltip. "More settings" opens the engine's own settings menu.
//  Opened by the server ("dmz_open_config", scripts/08_character.js's dmz_menu handler).
// =====================================================================================
var DMZ_CONFIG_MENU = (function () {
    var U = DMZ_UI, FONT = U.FONT;
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png", BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var NAV = "dmzpack:textures/gui/buttons/menubuttons.png";
    var ROW_H = 20, SEARCH_TOP = 34, LIST_TOP = 52, LIST_H = 148, CLIP_W = 131, TEXT_SCALE = 0.75, FLASH_MS = 1500;
    var CATS = ["interface", "gameplay", "visuals", "audio"];
    var EXPANDED = {};                       // stays between openings, like DMZ's static EnumSet
    var NOT_YET = "Not in Dragon Block Ragnarok yet";

    function tr() { return U.tr.apply(null, arguments); }
    function trOr(key, fallback) { return U.hasTr(key) ? U.tr(key) : fallback; }
    function get(key, def) { try { var v = RPG.storage.get(key, def); return v === undefined || v === null ? def : v; } catch (e) { return def; } }
    function set(key, v) { try { RPG.storage.set(key, v); } catch (e) { } }
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

    // ---- the options (ConfigMenuScreen.initializeConfigOptions), wired to DBR's settings ----
    function toggle(cat, key, store, def, extra) {
        var o = { cat: cat, key: key, type: "bool", get: function () { return !!get(store, def); }, set: function (v) { set(store, !!v); } };
        for (var k in extra || {}) o[k] = extra[k];
        return o;
    }
    function off(cat, key, type, value, extra) {
        var o = { cat: cat, key: key, type: type, disabled: true, tip: NOT_YET, get: function () { return value; }, set: function () { } };
        for (var k in extra || {}) o[k] = extra[k];
        return o;
    }
    function number(cat, key, store, def, min, max, step, bigStep, extra) {
        var o = { cat: cat, key: key, type: "num", min: min, max: max, step: step, bigStep: bigStep,
            get: function () { var v = Number(get(store, def)); return isNaN(v) ? def : v; }, set: function (v) { set(store, v); } };
        for (var k in extra || {}) o[k] = extra[k];
        return o;
    }
    function action(cat, key, label, run, extra) {
        var o = { cat: cat, key: key, type: "action", label: label, run: run };
        for (var k in extra || {}) o[k] = extra[k];
        return o;
    }
    function options() {
        return [
            action("interface", "config.hudEditor", "gui.dragonminez.config.open", function () { RPG.net.send("dmz_menu", { tab: "engine_settings" }); },
                { tip: "Opens the game settings: use \"Move / resize HUD\" there" }),
            toggle("interface", "config.alwaysVisibleHudValues", "dmz_hud_always_numbers", false),
            toggle("interface", "config.hideHudNumbers", "dmz_hud_hide_numbers", false),
            toggle("interface", "config.hudPercent", "dmz_hud_percent", true, { label: "HUD Values as %" }),
            toggle("interface", "config.hideHud", "dmz_hud_hidden", false, { label: "Hide the DMZ HUD" }),
            toggle("interface", "config.partyMarkers", "dmz_cfg_party_markers", true),
            toggle("interface", "config.showAccumulativeDamage", "dmz_cfg_accum_damage", true),
            off("interface", "config.advancedDescription", "bool", true),
            off("interface", "config.advancedDescriptionPercentage", "bool", true),
            off("interface", "config.hexagonStatsDisplay", "bool", false),
            off("interface", "config.menuScaleMultiplier", "float", 1.0),
            off("interface", "config.utilityMenuScaleMultiplier", "float", 1.0),
            off("interface", "config.tutorialsEnabled", "bool", true),
            action("interface", "config.resetTutorials", "gui.dragonminez.config.reset", function () { set("dmz_rhythm_calibrated", false); },
                { tip: "Shows the rhythm audio calibration again (DBR has no other tutorials yet)" }),

            off("gameplay", "config.cameraMovementDuringFlight", "bool", true),
            off("gameplay", "config.flightTurnSensitivity", "float", 0.75),
            off("gameplay", "config.overShoulderCamera", "action", 0, { label: "gui.dragonminez.config.open" }),
            off("gameplay", "config.reserveFirstHotbarSlot", "bool", false),

            action("visuals", "config.spriteCreator", "gui.dragonminez.config.open", openSpriteCreator,
                { name: "Sprite Creator", tip: "Opens the built-in sprite creator" }),
            off("visuals", "config.aura3DPersonal", "bool", false),
            off("visuals", "config.aura3DStyle", "int", 0, { fmt: function () { return tr("gui.dragonminez.customization.aura.smooth"); } }),
            off("visuals", "config.aura3DEntities", "bool", false),
            off("visuals", "config.transformationOutlines", "bool", true),
            off("visuals", "config.impactFramesEnabled", "bool", false),
            off("visuals", "config.firstPersonAnimated", "bool", true),
            toggle("visuals", "config.taiyokenInvertPalette", "dmz_cfg_taiyoken_invert", false),

            off("audio", "config.kiSoundVolume", "int", 100),
            number("audio", "config.rhythmAudioOffset", "dmz_rhythm_offset", 60, -200, 400, 5, 25, { label: "Rhythm Latency (ms)", int: true })
        ];
    }
    function openSpriteCreator() {
        if (RPG.screen && typeof RPG.screen.openSpriteCreator === "function") RPG.screen.openSpriteCreator();
        else U.showStatus("The sprite creator needs a newer Ragnarok RPG build", "#FF5555");
    }
    function name(o) { if (o.name) return o.name; return o.label && o.type !== "action" ? (U.hasTr(o.label) ? tr(o.label) : o.label) : trOr("gui.dragonminez." + o.key, o.key); }
    function catName(c) { return tr("gui.dragonminez.config.category." + c); }

    // ---- state ----
    var M = null;
    function open() {
        var mine = { opts: options(), query: "", scroll: 0, prog: {}, last: RPG.nowMs(), flash: {}, held: null, holdTicks: 0, rows: [] };
        CATS.forEach(function (c) { mine.prog[c] = EXPANDED[c] ? 1 : 0; });
        M = mine;
        var els = [
            { id: "search", type: "input", anchor: "center", x: -126, y: -68, w: 106, h: 10, maxLength: 32, value: "",
                onChange: function (id, v) { if (!M) return; var q = String(v || "").trim().toLowerCase(); if (q !== M.query) { M.query = q; M.scroll = 0; } } },
            { id: "sprites", type: "button", anchor: "center", x: -95, y: 110, w: 90, h: 20, texture: BUTTONS, texW: 256, texH: 256, u: 0, v: 28, uw: 74, vh: 20, hoverU: 0, hoverV: 48,
                label: "Sprite Creator", font: FONT, tooltip: "Opens the built-in sprite creator", onClick: function () { openSpriteCreator(); } },
            { id: "more", type: "button", anchor: "center", x: 5, y: 110, w: 90, h: 20, texture: BUTTONS, texW: 256, texH: 256, u: 0, v: 28, uw: 74, vh: 20, hoverU: 0, hoverV: 48,
                label: trOr("gui.dbr.config.more_settings", "More settings"), font: FONT, tooltip: "The game's own settings (keys, HUD layout, sounds...)",
                onClick: function () { RPG.net.send("dmz_menu", { tab: "engine_settings" }); } }
        ];
        var nav = [[-110, 120, "party"], [-70, 0, "stats"], [-30, 20, "skills"], [10, 60, "quests"], [50, 140, "minigames"], [90, 100, "config"]];
        nav.forEach(function (n) {
            els.push({ id: "nav_" + n[2], type: "button", anchor: "bottom", x: n[0], y: -30, w: 20, h: 20, texture: NAV, texW: 256, texH: 256,
                u: n[1], v: 0, uw: 20, vh: 20, hoverU: n[1], hoverV: 20, tooltip: n[2].charAt(0).toUpperCase() + n[2].slice(1),
                onClick: function () { RPG.sound("dmzpack:ui_menu_switch", 1, 1); if (n[2] !== "config") RPG.net.send("dmz_menu", { tab: n[2] }); } });
        });
        RPG.screen.open({ id: "dmz_config", referenceHeight: 360, background: "dim", elements: els, onRender: render, onMouse: mouse, onScroll: scroll,
            onClose: function () { if (M === mine) M = null; } });
    }
    RPG.net.on("dmz_open_config", function () { open(); });

    function matches(o) {
        if (!M.query) return true;
        return name(o).toLowerCase().indexOf(M.query) >= 0 || catName(o.cat).toLowerCase().indexOf(M.query) >= 0;
    }
    function ease(t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }

    function layout(dt) {
        var rows = [], cursor = 0, searching = !!M.query;
        CATS.forEach(function (c) {
            var visible = M.opts.filter(function (o) { return o.cat === c && matches(o); });
            var target = visible.length && (searching || EXPANDED[c]) ? 1 : 0;
            M.prog[c] = U.approach(M.prog[c], target, dt / 0.24);
            if (!visible.length) return;
            rows.push({ cat: c, header: true, y: cursor, top: cursor, bottom: cursor + ROW_H, count: visible.length });
            cursor += ROW_H;
            var top = cursor, bottom = cursor + visible.length * ROW_H * ease(clamp(M.prog[c], 0, 1));
            if (bottom - top > 0.5) {
                var slide = (bottom - top) - visible.length * ROW_H;
                visible.forEach(function (o, i) { rows.push({ cat: c, opt: o, y: top + slide + i * ROW_H, top: top, bottom: bottom }); });
            }
            cursor = bottom;
        });
        M.rows = rows;
        M.total = cursor;
        M.scroll = clamp(M.scroll, 0, Math.max(0, cursor - LIST_H));
    }

    function render(ctx) {
        if (!M) return;
        var now = RPG.nowMs(), dt = Math.min(0.1, (now - M.last) / 1000);
        M.last = now;
        var Wd = ctx.width, cx = Math.floor(Wd / 2), cy = Math.floor(ctx.height / 2), mx = ctx.mouseX, my = ctx.mouseY;
        var lx = cx - 143, rx = cx + 2, py = cy - 105, listTop = py + LIST_TOP;
        M.lx = lx; M.rx = rx; M.py = py;
        layout(dt);
        // held -/+ repeats (ConfigMenuScreen.tick: after 10 ticks, every 2)
        if (M.held) {
            M.holdTicks += dt * 20;
            if (M.holdTicks > 10) { M.holdAcc = (M.holdAcc || 0) + dt * 20; while (M.holdAcc >= 2) { M.holdAcc -= 2; modify(M.held.o, M.held.d); } }
        }

        [[lx, "gui.dragonminez.config.options"], [rx, "gui.dragonminez.config.values"]].forEach(function (p) {
            ctx.image(MENU_BIG, p[0], py, 141, 213, 0, 0, 141, 213, 256, 256);
            ctx.image(MENU_BIG, p[0] + 17, py + 10, 107, 21, 142, 22, 107, 21, 256, 256);
            U.bordered(ctx, "§l" + tr(p[1]), p[0] + 70, py + 17, "#FFD700", 0.5);
        });
        // search field (PanelSkin.FIELD: characterbuttons 0,108)
        field(ctx, lx + 12, py + SEARCH_TOP, 117, 14);
        if (!M.query && !RPG.screen.value("search")) ctx.textStyled(tr("gui.dragonminez.config.search"), lx + 17, py + SEARCH_TOP + 3, 1, "#808080", 1, 0, FONT, null);

        var hoverTip = null;
        ctx.clip(lx + 5, listTop, CLIP_W, LIST_H);
        M.rows.forEach(function (r) {
            var y = listTop + r.y - M.scroll;
            if (y + ROW_H < listTop || y > listTop + LIST_H) return;
            var hovered = rowHovered(r, mx, my, lx + 8, lx + 126) || rowHovered(r, mx - (rx - lx), my, lx + 8, lx + 126);
            if (r.header) { header(ctx, r, lx, y, hovered); return; }
            ctx.clip(lx + 5, listTop + r.top - M.scroll, 131, r.bottom - r.top);
            if (hovered) ctx.fill(lx + 9, y, 117, ROW_H - 1, "#FFFFFF", 0.086);
            text(ctx, name(r.opt), lx + 15, y + 6, r.opt.disabled ? "#9A9A9A" : "#FFFFFF", 0);
            ctx.unclip();
            if (hovered && r.opt.tip && mx < rx) hoverTip = r.opt;
        });
        ctx.unclip();
        if (!M.rows.length) text(ctx, "§7" + tr("gui.dragonminez.config.no_results"), lx + 70, listTop + 8, "#AAAAAA", 0.5);
        scrollbar(ctx, lx + 128, listTop);

        ctx.clip(rx + 5, listTop, CLIP_W, LIST_H);
        M.rows.forEach(function (r) {
            var y = listTop + r.y - M.scroll;
            if (y + ROW_H < listTop || y > listTop + LIST_H) return;
            var hovered = rowHovered(r, mx, my, rx + 8, rx + 132) || rowHovered(r, mx + (rx - lx), my, rx + 8, rx + 132);
            if (r.header) {
                ctx.fill(rx + 15, y + 1, 111, ROW_H - 3, "#FFFFFF", hovered ? 0.19 : 0.11);
                ctx.fill(rx + 24, y + 9, 93, 1, "#8D9BC6", 0.33);
                return;
            }
            ctx.clip(rx + 5, listTop + r.top - M.scroll, 131, r.bottom - r.top);
            if (hovered) ctx.fill(rx + 15, y, 111, ROW_H - 1, "#FFFFFF", 0.086);
            value(ctx, r.opt, rx, y, mx, my, interactable(r, my));
            ctx.unclip();
            if (hovered && r.opt.tip && mx >= rx) hoverTip = r.opt;
        });
        ctx.unclip();
        if (hoverTip) U.tooltip(ctx, [[name(hoverTip), "#FFD700"], [hoverTip.tip, hoverTip.disabled ? "#FF9090" : "#B0B0B0"]], mx, my, hoverTip.disabled ? "#AA3030" : "#5000FF");
    }

    function text(ctx, t, x, y, color, align) { ctx.textStyled(t, x, y, TEXT_SCALE, color, 1, align || 0, FONT, "#000000"); }
    function field(ctx, x, y, w, h) {
        var f = function (sx, sy, sw, sh, dx, dy, dw, dh) { ctx.quad(BUTTONS, dx, dy, dw, dh, sx / 256, sy / 256, (sx + sw) / 256, (sy + sh) / 256, "#FFFFFF", 1); };
        var v = 108;
        f(0, v, 3, 3, x, y, 3, 3); f(3, v, 101, 3, x + 3, y, w - 6, 3); f(104, v, 3, 3, x + w - 3, y, 3, 3);
        f(0, v + 3, 3, 11, x, y + 3, 3, h - 7); f(3, v + 3, 101, 11, x + 3, y + 3, w - 6, h - 7); f(104, v + 3, 3, 11, x + w - 3, y + 3, 3, h - 7);
        f(0, v + 14, 3, 4, x, y + h - 4, 3, 4); f(3, v + 14, 101, 4, x + 3, y + h - 4, w - 6, 4); f(104, v + 14, 3, 4, x + w - 3, y + h - 4, 3, 4);
    }
    function header(ctx, r, lx, y, hovered) {
        var p = ease(clamp(M.prog[r.cat], 0, 1));
        ctx.fill(lx + 9, y + 1, 117, ROW_H - 3, "#FFFFFF", hovered ? 0.19 : 0.11);
        ctx.push(); ctx.translate(lx + 16.5, y + 9.5); ctx.rotate(90 * p); ctx.scale(0.6, 0.6);
        ctx.image(BUTTONS, -4, -7, 8, 14, 20, hovered ? 14 : 0, 8, 14, 256, 256);
        ctx.pop();
        text(ctx, "§l" + catName(r.cat), lx + 24, y + 6, hovered ? "#7CFDD6" : "#FFD700", 0);
        text(ctx, String(r.count), lx + 122, y + 6, "#9FB8AE", 1);
    }
    function valueText(o) {
        if (o.fmt) return o.fmt();
        var v = o.get();
        if (o.type === "float" || (o.type === "num" && !o.int)) return (Math.round(v * 100) / 100).toFixed(2);
        return String(Math.round(v));
    }
    function value(ctx, o, px, y, mx, my, interactable) {
        var a = o.disabled ? 0.4 : 1;
        if (o.type === "bool") {
            ctx.quad(BUTTONS, px + 60, y + 3, 20, 10, 122 / 256, (o.get() ? 0 : 10) / 256, 142 / 256, (o.get() ? 10 : 20) / 256, "#FFFFFF", a);
        } else if (o.type === "action") {
            var hov = !o.disabled && interactable && U.inside(mx, my, px + 33, y, 74, ROW_H);
            ctx.quad(BUTTONS, px + 33, y, 74, 20, 0, (hov ? 48 : 28) / 256, 74 / 256, (hov ? 68 : 48) / 256, "#FFFFFF", a);
            var flashing = (M.flash[o.key] || 0) > RPG.nowMs(), label = tr(flashing ? "gui.dragonminez.config.done" : o.label);
            ctx.textStyled(label, px + 70, y + 6, 1, flashing ? "#55FF55" : hov ? "#7CFDD6" : o.disabled ? "#909090" : "#FFFFFF", 1, 0.5, FONT, null);
        } else {
            var od = !o.disabled && interactable && U.inside(mx, my, px + 20, y + 3, 14, 11), oi = !o.disabled && interactable && U.inside(mx, my, px + 103, y + 3, 14, 11);
            ctx.quad(BUTTONS, px + 20, y + 3, 10, 10, 142 / 256, (od ? 10 : 0) / 256, 152 / 256, (od ? 20 : 10) / 256, "#FFFFFF", a);
            ctx.quad(BUTTONS, px + 103, y + 3, 10, 10, 0, (oi ? 10 : 0) / 256, 10 / 256, (oi ? 20 : 10) / 256, "#FFFFFF", a);
            text(ctx, valueText(o), px + 69, y + 5, o.disabled ? "#909090" : "#FFFFFF", 0.5);
        }
    }
    function scrollbar(ctx, x, top) {
        if (M.total <= LIST_H) return;
        var th = Math.max(20, LIST_H * LIST_H / M.total), ty = top + (LIST_H - th) * M.scroll / (M.total - LIST_H);
        ctx.fill(x, top, 2, LIST_H, "#000000", 0.35);
        ctx.fill(x, ty, 2, th, "#D2D7F1", 1);
    }
    function interactable(r, my) {
        var top = M.py + LIST_TOP;
        if (my < top || my >= top + LIST_H) return false;
        return my >= top + r.top - M.scroll && my < top + r.bottom - M.scroll;
    }
    function rowHovered(r, mx, my, left, right) {
        if (mx < left || mx >= right || !interactable(r, my)) return false;
        var y = M.py + LIST_TOP + r.y - M.scroll;
        return my >= y && my < y + ROW_H;
    }
    function rowAt(mx, my) {
        for (var i = 0; i < M.rows.length; i++) {
            var r = M.rows[i];
            if (rowHovered(r, mx, my, M.lx + 8, M.lx + 126) || rowHovered(r, mx, my, M.rx + 8, M.rx + 132)) return r;
        }
        return null;
    }

    function modify(o, delta) {
        if (o.disabled) return;
        if (o.type === "bool") o.set(!o.get());
        else if (o.type === "num") {
            var shift = RPG.isKeyDown("key.keyboard.left.shift") || RPG.isKeyDown("key.keyboard.right.shift");
            var v = clamp(o.get() + delta * (shift ? o.bigStep : o.step), o.min, o.max);
            o.set(o.int ? Math.round(v) : Math.round(v * 100) / 100);
        }
    }
    function mouse(x, y, button, action) {
        if (!M) return;
        if (action === "up") { M.held = null; M.holdAcc = 0; return; }
        if (action !== "down" || button !== 0) return;
        var r = rowAt(x, y);
        if (!r) return;
        if (r.header) {
            if (M.query) return false;
            EXPANDED[r.cat] = !EXPANDED[r.cat];
            RPG.sound("dmzpack:pip_menu", 1, 1);
            return false;
        }
        var o = r.opt, px = M.rx, ry = M.py + LIST_TOP + r.y - M.scroll;
        if (o.disabled) { RPG.sound("minecraft:block.note_block.bass", 0.4, 0.6); return false; }
        if (o.type === "bool") {
            if (!U.inside(x, y, px + 56, ry, 28, ROW_H)) return;
            modify(o, 1);
            RPG.sound(o.get() ? "dmzpack:switch_on" : "dmzpack:switch_off", 1, 1);
            return false;
        }
        if (o.type === "action") {
            if (!U.inside(x, y, px + 33, ry, 74, ROW_H)) return;
            RPG.sound("dmzpack:pip_menu", 1, 1);
            M.flash[o.key] = /\.reset$/.test(o.label) ? RPG.nowMs() + FLASH_MS : 0;
            o.run();
            return false;
        }
        var d = U.inside(x, y, px + 18, ry + 1, 18, 15) ? -1 : U.inside(x, y, px + 101, ry + 1, 18, 15) ? 1 : 0;
        if (!d) return;
        RPG.sound("dmzpack:ui_nave_cooldown", 1, 1);
        M.held = { o: o, d: d }; M.holdTicks = 0; M.holdAcc = 0;
        modify(o, d);
        return false;
    }
    function scroll(x, y, d) {
        if (!M) return;
        if (x >= M.lx && x <= M.rx + 141 && y >= M.py && y <= M.py + 213) M.scroll = clamp(M.scroll - (d > 0 ? ROW_H : -ROW_H), 0, Math.max(0, M.total - LIST_H));
    }

    return { open: open };
})();
