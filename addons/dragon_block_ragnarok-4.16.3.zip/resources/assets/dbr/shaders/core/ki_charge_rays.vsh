#version 150
// The original's charge-rays quad (GPL-3.0, see NOTICE.md): the flat billboard in its own -1..1 square.

in vec3 Position;
in vec2 UV0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec2 vLocal;

void main() {
    vLocal = Position.xy;
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
}
