// =====================================================================================
//  The original's "Generate from Base" (common/hair/HairTransformGenerator, GPL-3.0 - see NOTICE.md): builds the
//  SSJ, SSJ2, SSJ3 and SSJ4 styles from a base style - spikes lifted up and out with their bangs kept, long hanging
//  hair (lacio) curled instead, fillers where lifted strands bared the scalp, the SSJ3 / SSJ4 templates with the
//  player's bangs and locks. Same constants, same order of steps, 32-bit float maths like the original (shared/11_dmz_hair.js JF).
//  Used by the hair editor (client/scripts/21_dmz_hair_editor.js). Styles are DMZ_HAIR's canonical objects.
// =====================================================================================
var DMZ_HAIR_GEN = (function () {
    var H = DMZ_HAIR, J = H.JF, F = Math.fround, FACES = H.FACES;
    var HEAD_HALF = 4, HEAD_TOP = 8, HEAD_TOLERANCE = F(0.25), ROOT_CLEARANCE = 1, SAMPLE_STEP = 0.5, MIN_CHORD = F(0.05);
    var OUTWARD_BIAS = F(0.6), HANGING_ELEVATION = -20, CENTER_BANG_WEIGHT = 1.25, BANG_PAIR_TOLERANCE = F(0.9);
    var RADIAL_LIMIT = F(150 * J.D2R), RADIAL_RAMP = 20, FLIP_STRAIGHTEN = F(0.6), LONG_STRAND = 6, HANG_LIMIT = -30, RISE_MIN = 45;
    var SNAP_PIVOT = 5, BANG_RISE_MIN = 45, FACE_RADIAL_SHARE = F(0.4), RISEN_LENGTH_CAP = 8, RISEN_LENGTH_KEEP = 0.5;
    var EXPOSURE_DONOR_DISTANCE = 3.5, VOLUME_FIRST_ROW = 2, COLLISION_STEPS = 6, COLLISION_PUSH = F(0.35);
    var COVER_SKIP = 1.5, COVER_RADIUS = 1, FILLER_LENGTH = 0.75, FILLER_MIN_LENGTH = 2, FILLER_SPREAD = F(0.35);
    var LACIO_STRAND_LENGTH = 6, LACIO_SHARE = F(0.3), LACIO_MIN_STRANDS = 4, LACIO_HANG_ELEVATION = -35, LACIO_LIFT_SCALE = 0.5;
    var CURL_MIN_LENGTH = 3.5, CURL_FOCUS = F(2.5), CURL_SKIP = 5, CURL_RADIAL = F(0.7), CURL_SIDE_FORWARD = F(0.4), CURL_ATTEMPTS = 3, CURL_RETRY_STEP = 15;
    var LACIO_FILLER_LENGTH = F(0.45), LACIO_FILLER_MAX_LENGTH = 5, LACIO_FILLER_SEGMENT = F(1.6), LACIO_FILLER_RISE = 0.25, LACIO_VOLUME_FIRST_ROW = 1;
    var TEMPLATE_BANG_LENGTH = 4.5, TEMPLATE_BANG_ELEVATION = -25, FORELOCK_WIDTH = 0.25, FORELOCK_LENGTH = F(0.6), LOCK_MIN_LENGTH = 5;
    var LONG_BACK_LENGTH = 9, LONG_BACK_MIN_STRANDS = 4, LOCK_HANG_ELEVATION = -30, MIN_GENERATED_TAPER = 0.25;
    var NaN_ = NaN;
    function lift(t, u, h) { return { target: t, upright: F(u), hanging: F(h) }; }
    function curl(p, s) { return { primary: p, secondary: s }; }
    var SSJ_PROFILE = { lifts: [lift(55, 0.4, 0.45), lift(60, 0.55, 0.15), lift(65, 0.6, 0.75), lift(65, 0.6, 0.75), lift(70, 0.5, 0.75)],
        curls: [curl(35, NaN_), curl(NaN_, NaN_), curl(35, NaN_), curl(35, NaN_), curl(35, NaN_)], radial: F(0.5), straighten: F(0.7), taper: F(0.92), lengthScale: 1, singleBang: false };
    var SSJ2_PROFILE = { lifts: [lift(65, 0.8, 0.9), lift(60, 0.5, 0.8), lift(65, 0.4, 0.55), lift(65, 0.4, 0.55), lift(70, 0.35, 0.5)],
        curls: [curl(50, NaN_), curl(25, NaN_), curl(50, 20), curl(50, 20), curl(50, 20)], radial: F(0.4), straighten: F(0.85), taper: F(0.88), lengthScale: F(1.15), singleBang: true };
    var UP = [0, 1, 0];
    var PX = 0.0625;

    function clone(o) { return JSON.parse(JSON.stringify(o)); }
    function visible(s) { return !!s && s.sg > 0 && s.ln > 0; }
    function strand(h, fi, i) { var l = h.faces[FACES[fi].key]; return l ? l[i] : null; }
    function setStrand(h, fi, i, s) { var c = clone(s); c.i = fi * 100 + i; (h.faces[FACES[fi].key] = h.faces[FACES[fi].key] || [])[i] = c; }
    function clampF(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }
    function cfin(v, lo, hi, fb) { return H.clampFF(F(v), lo, hi, fb); }
    // ---- float vector helpers with the original library's rounding
    function fma(a, b, c) { return J.fma(a, b, c); }
    function vlenSq(v) { return fma(v[0], v[0], fma(v[1], v[1], F(v[2] * v[2]))); }
    function vlen(v) { return J.sqrt(vlenSq(v)); }
    function invsqrt(x) { return F(1 / J.sqrt(x)); }
    function vnorm(v) { var s = invsqrt(vlenSq(v)); return [F(v[0] * s), F(v[1] * s), F(v[2] * s)]; }
    function vdot(a, b) { return fma(a[0], b[0], fma(a[1], b[1], F(a[2] * b[2]))); }
    function vcross(a, b) { return [fma(a[1], b[2], F(-a[2] * b[1])), fma(a[2], b[0], F(-a[0] * b[2])), fma(a[0], b[1], F(-a[1] * b[0]))]; }
    function vlerp(a, b, t) { return [fma(F(b[0] - a[0]), t, a[0]), fma(F(b[1] - a[1]), t, a[1]), fma(F(b[2] - a[2]), t, a[2])]; }
    function vfma(a, s, b) { return [fma(s, b[0], a[0]), fma(s, b[1], a[1]), fma(s, b[2], a[2])]; }
    function vdist(a, b) { return vlen(J.vsub(a, b)); }
    function divPx(v) { return J.vdiv(v, PX); }
    function qRotationTo(f, t) {
        var fn = invsqrt(fma(f[0], f[0], fma(f[1], f[1], F(f[2] * f[2])))), tn = invsqrt(fma(t[0], t[0], fma(t[1], t[1], F(t[2] * t[2]))));
        var fx = F(f[0] * fn), fy = F(f[1] * fn), fz = F(f[2] * fn), tx = F(t[0] * tn), ty = F(t[1] * tn), tz = F(t[2] * tn);
        var dot = F(F(F(fx * tx) + F(fy * ty)) + F(fz * tz));
        if (dot < F(-0.999999)) {
            var x = fy, y = -fx, z = 0;
            if (F(F(fy * fy) + F(y * y)) === 0) { x = 0; y = fz; z = -fy; }
            return [x, y, z, 0];
        }
        var sd2 = J.sqrt(F(F(1 + dot) * 2)), isd2 = F(1 / sd2);
        var cx = F(F(fy * tz) - F(fz * ty)), cy = F(F(fz * tx) - F(fx * tz)), cz = F(F(fx * ty) - F(fy * tx));
        var qx = F(cx * isd2), qy = F(cy * isd2), qz = F(cz * isd2), qw = F(sd2 * 0.5);
        var n2 = invsqrt(fma(qx, qx, fma(qy, qy, fma(qz, qz, F(qw * qw)))));
        return [F(qx * n2), F(qy * n2), F(qz * n2), F(qw * n2)];
    }
    function qEuler(q) {
        var x = q[0], y = q[1], z = q[2], w = q[3];
        var ex = F(Math.atan2(F(F(x * w) - F(y * z)), F(F(0.5 - F(x * x)) - F(y * y))));
        var r = F(2 * F(F(x * z) + F(y * w))), ey = r <= -1 ? F(-F(Math.PI) / 2) : r >= 1 ? F(F(Math.PI) / 2) : F(Math.asin(r));
        var ez = F(Math.atan2(F(F(z * w) - F(x * y)), F(F(0.5 - F(y * y)) - F(z * z))));
        return [ex, ey, ez];
    }
    function qRotateAxis(q, angle, a) {
        var h = F(angle / 2), sn = J.sin(h), inv = invsqrt(fma(a[0], a[0], fma(a[1], a[1], F(a[2] * a[2]))));
        var rx = F(F(a[0] * inv) * sn), ry = F(F(a[1] * inv) * sn), rz = F(F(a[2] * inv) * sn), rw = J.cosFromSin(sn, h);
        return J.qmul(q, [rx, ry, rz, rw]);
    }
    function qFromEulerDeg(rx, ry, rz) { return J.qrz(J.qry(J.qrx([0, 0, 0, 1], F(rx * J.D2R)), F(ry * J.D2R)), F(rz * J.D2R)); }

    // ---- measurements (pixels) ----
    function pose(s, fi, i) { return H.poseExact(s, fi, i); }
    function restEnd(p, k) { return J.vadd(J.qtr(p.restRotations[k], [0, p.lengths[k], 0]), p.restStarts[k]); }
    function measure(s, fi, i, out) {
        var p = pose(s, fi, i), len = 0;
        var c = divPx(J.vsub(p.restTip, p.root));
        out.chord = c; out.pose = p;
        for (var k = 0; k < p.segments; k++) len = F(len + p.lengths[k]);
        return F(len / PX);
    }
    function measureDirection(s, fi, i, out) {
        var len = measure(s, fi, i, out);
        if (vlen(out.chord) < MIN_CHORD) return -1;
        out.chord = vnorm(out.chord);
        return len;
    }
    function elevation(d) {
        var l = vlen(d);
        if (l < F(1e-6)) return 0;
        return F(F(Math.asin(clampF(F(d[1] / l), -1, 1))) * J.R2D);
    }
    function headPenetration(s, fi, i) {
        var p = pose(s, fi, i), arc = 0, depth = 0;
        for (var k = 0; k < p.segments; k++) {
            var a = divPx(p.restStarts[k]), b = divPx(restEnd(p, k)), len = vdist(a, b);
            var steps = Math.max(1, Math.ceil(len / SAMPLE_STEP));
            for (var n = 0; n <= steps; n++) {
                var t = F(n / steps);
                if (F(arc + F(len * t)) < ROOT_CLEARANCE) continue;
                var q = vlerp(a, b, t);
                var inside = Math.min(Math.min(F(HEAD_HALF - Math.abs(q[0])), F(HEAD_HALF - Math.abs(q[2]))), Math.min(q[1], F(HEAD_TOP - q[1])));
                depth = Math.max(depth, inside);
            }
            arc = F(arc + len);
        }
        return depth;
    }
    function outward(fi, rootBlocks) {
        var o = divPx([rootBlocks[0], 0, rootBlocks[2]]);
        if (vlenSq(o) < F(1e-4)) o = [0, 0, 1];
        o = vnorm(o);
        if (FACES[fi].key === "T") return o;
        var n = FACES[fi].key === "F" ? [0, 0, -1] : FACES[fi].key === "B" ? [0, 0, 1] : FACES[fi].key === "L" ? [-1, 0, 0] : [1, 0, 0];
        return vnorm(J.vadd(J.vmul(o, FACE_RADIAL_SHARE), n));
    }
    function wrapRad(r) {
        var w = F(r % (Math.PI * 2));
        if (w > Math.PI) w = F(w - F(Math.PI * 2));
        if (w < -Math.PI) w = F(w + F(Math.PI * 2));
        return w;
    }
    function liftedDirection(dir, out, elev, radial) {
        var hz = [dir[0], 0, dir[2]], spread = vlen(hz);
        hz = vfma(hz, F(OUTWARD_BIAS * Math.max(0, F(1 - spread))), out);
        if (vlenSq(hz) < F(1e-6)) hz = out.slice();
        var heading = F(Math.atan2(hz[0], hz[2]));
        var delta = wrapRad(F(F(Math.atan2(out[0], out[2])) - heading));
        if (Math.abs(delta) < RADIAL_LIMIT) heading = F(heading + F(delta * radial));
        var rad = F(elev * J.D2R), c = F(Math.cos(rad));
        return vnorm([F(F(Math.sin(heading)) * c), F(Math.sin(rad)), F(F(Math.cos(heading)) * c)]);
    }
    function slerp(a, b, f) {
        var dot = clampF(vdot(a, b), -1, 1), ang = F(Math.acos(dot));
        if (ang < F(1e-4)) return a.slice();
        var sn = F(Math.sin(ang)), x = F(F(Math.sin(F(F(1 - f) * ang))) / sn), y = F(F(Math.sin(F(f * ang))) / sn);
        return vnorm(vfma(J.vmul(a, x), y, b));
    }
    function rotateStrand(s, baseRot, from, to) {
        var e = qEuler(J.qmul(qRotationTo(from, to), baseRot));
        s.rx = H.wrapF(F(e[0] * J.R2D)); s.ry = H.wrapF(F(e[1] * J.R2D)); s.rz = H.wrapF(F(e[2] * J.R2D));
    }
    function straighten(s, f) {
        s.bx = cfin(F(s.bx * f), -3600, 3600, s.bx); s.by = cfin(F(s.by * f), -3600, 3600, s.by); s.bz = cfin(F(s.bz * f), -3600, 3600, s.bz);
        (s.so || []).forEach(function (o) { o.rx = cfin(F(o.rx * f), -180, 180, o.rx); o.ry = cfin(F(o.ry * f), -180, 180, o.ry); o.rz = cfin(F(o.rz * f), -180, 180, o.rz); });
    }
    function sharpen(s, prof) { if (prof.taper !== 1 && s.tp > MIN_GENERATED_TAPER) s.tp = cfin(Math.max(MIN_GENERATED_TAPER, F(s.tp * prof.taper)), 0.05, 2, s.tp); }
    function reshape(s, prof) { if (prof.lengthScale !== 1) s.ln = cfin(F(s.ln * prof.lengthScale), 0.1, 128, s.ln); sharpen(s, prof); }
    function amountOf(l, elev) { return elev >= 0 ? l.upright : F(l.upright + F(F(l.hanging - l.upright) * Math.min(1, F(-elev / 90)))); }
    function curlTarget(c, fi, i) {
        var cols = FACES[fi].cols, col = i % cols, outer = col === 0 || col === cols - 1;
        return (Math.floor(i / cols) + (outer ? 0 : 1)) % 2 === 0 ? c.primary : c.secondary;
    }

    function liftStrand(s, fi, i, prof, lacio) {
        var l = prof.lifts[fi], m = {}, len = measureDirection(s, fi, i, m);
        if (len < 0) return;
        var cur = elevation(m.chord), amount = F(amountOf(l, cur) * (lacio ? LACIO_LIFT_SCALE : 1));
        var lifted = cur >= l.target ? cur : F(cur + F(amount * F(l.target - cur)));
        if (!lacio && FACES[fi].key === "F") lifted = Math.max(lifted, BANG_RISE_MIN);
        else if (!lacio && len >= LONG_STRAND && lifted > HANG_LIMIT && lifted < RISE_MIN) lifted = lifted >= SNAP_PIVOT ? RISE_MIN : Math.min(cur, HANG_LIMIT);
        var radial = F(prof.radial * clampF(F(F(lifted - cur) / RADIAL_RAMP), 0, 1));
        var target = liftedDirection(m.chord, outward(fi, m.pose.root), lifted, radial);
        straighten(s, F(prof.straighten * F(1 - F(FLIP_STRAIGHTEN * clampF(F(F(lifted - cur) / 90), 0, 1)))));
        if (lifted > 0 && cur < 0 && len > RISEN_LENGTH_CAP) s.ln = cfin(F(F(s.ln * F(RISEN_LENGTH_CAP + F(F(len - RISEN_LENGTH_CAP) * RISEN_LENGTH_KEEP))) / len), 0.1, 128, s.ln);
        if (measureDirection(s, fi, i, m) < 0) return;
        rotateStrand(s, m.pose.baseRotation, m.chord, target);
    }
    function resolveHeadCollision(s, fi, i, allowed) {
        for (var step = 0; step < COLLISION_STEPS; step++) {
            if (headPenetration(s, fi, i) <= F(allowed + HEAD_TOLERANCE)) return;
            var m = {};
            if (measureDirection(s, fi, i, m) < 0) return;
            var escape = vnorm(J.vadd(outward(fi, m.pose.root), UP));
            rotateStrand(s, m.pose.baseRotation, m.chord, slerp(m.chord, escape, COLLISION_PUSH));
        }
    }
    function curlWeight(j, n) { return F(Math.pow(F(j / (n - 1)), CURL_FOCUS)); }
    function curlOutward(fi, root) {
        if (FACES[fi].key !== "F") return outward(fi, root);
        return vnorm([Math.sign(root[0]), 0, -CURL_SIDE_FORWARD]);
    }
    function curlStrand(s, fi, i, tipElev) {
        var n = s.sg;
        if (n < 2) return false;
        var p = pose(s, fi, i), tip = J.qtr(p.restRotations[n - 1], UP);
        if (elevation(tip) >= tipElev - CURL_SKIP) return false;
        var target = liftedDirection(tip, curlOutward(fi, p.root), tipElev, CURL_RADIAL);
        var remaining = 0, k;
        for (k = 1; k < n; k++) remaining = F(remaining + curlWeight(k, n));
        for (k = 1; k < n; k++) {
            var w = curlWeight(k, n), frac = F(w / remaining);
            remaining = F(remaining - w);
            p = pose(s, fi, i);
            var tangent = J.qtr(p.restRotations[k], UP);
            var ang = F(Math.acos(clampF(vdot(tangent, target), -1, 1))), axis = vcross(tangent, target);
            if (ang < F(1e-4) || vlenSq(axis) < F(1e-8)) continue;
            axis = J.qtr(J.qinv(p.restRotations[k]), vnorm(axis));
            var o = H.getOrCreateOverride(s, k);
            var e = qEuler(qRotateAxis(qFromEulerDeg(o.rx, o.ry, o.rz), F(ang * frac), axis));
            o.rx = cfin(F(e[0] * J.R2D), -180, 180, o.rx); o.ry = cfin(F(e[1] * J.R2D), -180, 180, o.ry); o.rz = cfin(F(e[2] * J.R2D), -180, 180, o.rz);
        }
        return true;
    }
    function curlWithCollision(s, fi, i, tipElev, allowed) {
        var orig = clone(s);
        for (var a = 0; a < CURL_ATTEMPTS; a++) {
            if (!curlStrand(s, fi, i, tipElev - a * CURL_RETRY_STEP)) return;
            if (headPenetration(s, fi, i) <= F(allowed + HEAD_TOLERANCE)) return;
            Object.keys(s).forEach(function (k) { delete s[k]; });
            Object.keys(orig).forEach(function (k) { s[k] = clone(orig[k]); });
        }
    }
    function isLongHanging(s, fi, i) {
        var m = {};
        if (measure(s, fi, i, m) < LACIO_STRAND_LENGTH) return false;
        if (elevation(m.chord) <= LACIO_HANG_ELEVATION) return true;
        return m.pose.segments > 0 && elevation(J.qtr(m.pose.restRotations[m.pose.segments - 1], UP)) <= LACIO_HANG_ELEVATION;
    }
    function isLacio(h) {
        var vis = 0, hang = 0;
        FACES.forEach(function (f, fi) { for (var i = 0; i < f.max; i++) { var s = strand(h, fi, i); if (!visible(s)) continue; vis++; if (isLongHanging(s, fi, i)) hang++; } });
        return hang >= LACIO_MIN_STRANDS && hang >= F(vis * LACIO_SHARE);
    }
    function pickBangs(src, prof) {
        var cand = [];
        for (var i = 0; i < 4; i++) {
            var s = strand(src, 0, i);
            if (!visible(s)) continue;
            var m = {}, len = measure(s, 0, i, m), elev = elevation(m.chord);
            if (elev >= HANGING_ELEVATION) continue;
            var center = i > 0 && i < 3;
            cand.push([i, F(F(len * F(-Math.sin(F(elev * J.D2R)))) * (center ? CENTER_BANG_WEIGHT : 1))]);
        }
        cand.sort(function (a, b) { return a[1] !== b[1] ? b[1] - a[1] : a[0] - b[0]; });
        var keep = prof.singleBang ? Math.min(1, cand.length) : Math.floor((cand.length + 1) / 2), kept = {};
        for (var k = 0; k < keep; k++) kept[cand[k][0]] = true;
        if (!prof.singleBang && keep > 0) {
            var last = cand[keep - 1], partner = 3 - last[0];
            cand.forEach(function (c) { if (c[0] === partner && c[1] >= F(last[1] * BANG_PAIR_TOLERANCE)) kept[partner] = true; });
        }
        return kept;
    }
    function coverSamples(h) {
        var out = [];
        FACES.forEach(function (f, fi) {
            for (var i = 0; i < f.max; i++) {
                var s = strand(h, fi, i);
                if (!visible(s)) continue;
                var p = pose(s, fi, i), arc = 0;
                for (var k = 0; k < p.segments; k++) {
                    var a = divPx(p.restStarts[k]), b = divPx(restEnd(p, k)), len = vdist(a, b);
                    var radius = F(F(Math.max(p.widths[k], p.depths[k]) / PX) * 0.5), steps = Math.max(1, Math.ceil(len / SAMPLE_STEP));
                    for (var n = 0; n <= steps; n++) {
                        var t = F(n / steps);
                        if (F(arc + F(len * t)) < COVER_SKIP) continue;
                        out.push({ fi: fi, i: i, pos: vlerp(a, b, t), r: radius });
                    }
                    arc = F(arc + len);
                }
            }
        });
        return out;
    }
    function nearestCover(samples, pt) {
        var best = null, gapBest = Infinity;
        for (var n = 0; n < samples.length; n++) {
            var gap = F(vdist(samples[n].pos, pt) - samples[n].r);
            if (gap <= COVER_RADIUS && gap < gapBest) { gapBest = gap; best = samples[n]; }
        }
        return best;
    }
    function placeFiller(out, fi, i, dfi, di, lacio) {
        var donor = strand(out, dfi, di);
        if (!visible(donor)) return;
        var dm = {};
        if (measureDirection(donor, dfi, di, dm) < 0) return;
        var f = clone(donor);
        f.so = []; f.ox = 0; f.oy = 0; f.oz = 0;
        if (lacio) {
            var len = clampF(F(donor.ln * LACIO_FILLER_LENGTH), FILLER_MIN_LENGTH, LACIO_FILLER_MAX_LENGTH);
            f.bx = 0; f.by = 0; f.bz = 0; f.tw = 0;
            f.sg = clampF(Math.max(1, Math.min(donor.sg, Math.round(F(len / LACIO_FILLER_SEGMENT)))), 0, 32);
            f.ln = cfin(len, 0.1, 128, f.ln);
        } else f.ln = cfin(Math.max(FILLER_MIN_LENGTH, F(donor.ln * FILLER_LENGTH)), 0.1, 128, f.ln);
        var m = {};
        if (measureDirection(f, fi, i, m) < 0) return;
        var escape = vnorm(J.vadd(outward(fi, m.pose.root), UP));
        var target = lacio ? slerp(escape, UP, LACIO_FILLER_RISE) : slerp(dm.chord, escape, FILLER_SPREAD);
        rotateStrand(f, m.pose.baseRotation, m.chord, target);
        resolveHeadCollision(f, fi, i, 0);
        setStrand(out, fi, i, f);
    }
    function addFillers(src, out, lacio) {
        var before = coverSamples(src), after = coverSamples(out), exposed = [];
        FACES.forEach(function (f, fi) {
            for (var i = 0; i < f.max; i++) {
                if (visible(strand(src, fi, i))) continue;
                var pt = H.basePosition(fi, i), donor = nearestCover(before, pt);
                if (!donor || nearestCover(after, pt)) continue;
                if (vdist(H.basePosition(donor.fi, donor.i), pt) > EXPOSURE_DONOR_DISTANCE) continue;
                exposed.push([fi, i, donor.fi, donor.i]);
            }
        });
        exposed.forEach(function (e) { placeFiller(out, e[0], e[1], e[2], e[3], lacio); });
        [1, 2, 3].forEach(function (fi) {
            var f = FACES[fi];
            for (var row = lacio ? LACIO_VOLUME_FIRST_ROW : VOLUME_FIRST_ROW; row < f.rows; row++) {
                for (var col = 0; col < f.cols; col++) {
                    var i = row * f.cols + col;
                    if (visible(strand(out, fi, i))) continue;
                    if (!lacio && H.basePosition(fi, i)[2] <= 0) continue;
                    var up = i - f.cols;
                    if (!visible(strand(src, fi, up))) continue;
                    placeFiller(out, fi, i, fi, up, lacio);
                }
            }
        });
    }
    function finish(out, base, limits) {
        out.name = base.name; out.gc = base.gc;
        H.sanitize(out, limits);
        return out;
    }
    function spike(src, ref, prof, limits) {
        var out = clone(src), bangs = pickBangs(src, prof), lacio = isLacio(ref);
        FACES.forEach(function (f, fi) {
            for (var i = 0; i < f.max; i++) {
                var s = strand(out, fi, i);
                if (!visible(s)) continue;
                if (fi === 0 && bangs[i]) continue;
                var depth = headPenetration(s, fi, i), shape = strand(ref, fi, i);
                if (lacio && visible(shape) && measure(shape, fi, i, {}) >= CURL_MIN_LENGTH) {
                    sharpen(s, prof);
                    var tip = curlTarget(prof.curls[fi], fi, i);
                    if (!isNaN(tip)) curlWithCollision(s, fi, i, tip, depth);
                    continue;
                }
                reshape(s, prof);
                liftStrand(s, fi, i, prof, lacio);
                resolveHeadCollision(s, fi, i, depth);
            }
        });
        addFillers(src, out, lacio);
        return finish(out, src, limits);
    }
    function hasLongBack(base) {
        var total = 0, n = 0;
        for (var i = 0; i < 16; i++) { var s = strand(base, 1, i); if (!visible(s)) continue; total = F(total + measure(s, 1, i, {})); n++; }
        return n >= LONG_BACK_MIN_STRANDS && F(total / n) >= LONG_BACK_LENGTH;
    }
    function superSaiyan3(base, limits) {
        var out = clone(H.extraStyle(hasLongBack(base) ? "LONG_SSJ3_CODE" : "DEFAULT_SSJ3_CODE"));
        for (var i = 1; i < 3; i++) {
            var bang = strand(base, 0, i);
            if (!visible(bang)) continue;
            var m = {}, len = measure(bang, 0, i, m);
            if (len < TEMPLATE_BANG_LENGTH || elevation(m.chord) > TEMPLATE_BANG_ELEVATION) continue;
            var fl = clone(bang);
            fl.w = FORELOCK_WIDTH; fl.d = FORELOCK_WIDTH; fl.ln = cfin(F(bang.ln * FORELOCK_LENGTH), 0.1, 128, fl.ln);
            setStrand(out, 0, i, fl);
        }
        return finish(out, base, limits);
    }
    function isLock(s, fi, i) {
        if (!visible(s)) return false;
        var m = {};
        if (measure(s, fi, i, m) < LOCK_MIN_LENGTH) return false;
        if (elevation(m.chord) <= LOCK_HANG_ELEVATION) return true;
        return elevation(J.qtr(m.pose.restRotations[m.pose.segments - 1], UP)) <= LOCK_HANG_ELEVATION;
    }
    function superSaiyan4(base, ssj, limits) {
        var out = clone(base);
        FACES.forEach(function (f, fi) {
            for (var i = 0; i < f.max; i++) { var own = strand(base, fi, i), fill = strand(ssj, fi, i); if (!visible(own) && visible(fill)) setStrand(out, fi, i, fill); }
        });
        var tpl = H.extraStyle("DEFAULT_SSJ4_CODE");
        [1, 2, 3].forEach(function (fi) {
            for (var i = 0; i < 16; i++) {
                var lock = strand(tpl, fi, i);
                if (!isLock(lock, fi, i)) continue;
                var mf = H.mirrorFace(fi), mi = H.mirrorIndex(fi, i);
                if (!isLock(strand(tpl, mf, mi), mf, mi)) continue;
                var lockLen = measure(lock, fi, i, {}), cur = strand(out, fi, i), curLen = visible(cur) ? measure(cur, fi, i, {}) : 0;
                if (curLen < lockLen) setStrand(out, fi, i, lock);
            }
        });
        return finish(out, base, limits);
    }
    function generateAll(base, limits) {
        var ssj = spike(base, base, SSJ_PROFILE, limits), ssj2 = spike(ssj, base, SSJ2_PROFILE, limits);
        return { ssj: ssj, ssj2: ssj2, ssj3: superSaiyan3(base, limits), ssj4: superSaiyan4(base, ssj, limits) };
    }
    function generate(base, slot, limits) {
        if (slot === "base") return clone(base);
        if (slot === "ssj") return spike(base, base, SSJ_PROFILE, limits);
        if (slot === "ssj2") return spike(spike(base, base, SSJ_PROFILE, limits), base, SSJ2_PROFILE, limits);
        if (slot === "ssj3") return superSaiyan3(base, limits);
        return superSaiyan4(base, spike(base, base, SSJ_PROFILE, limits), limits);
    }
    return { generateAll: generateAll, generate: generate };
})();
