// =====================================================================================
//  05_ui.js - menus, HUD and colours
// =====================================================================================
//  Menu key: K.  Controls (Options > Controls > "Ragnarok Modding Toolkit"), original layout:
//      Alt+1..4 / Ctrl+1..4   technique slots 1-8 (the skill bar)
//      C hold  charge ki      V  fly          R  dash          G  descend / meditate
//      Z       lock on        H  ascend / super jump           (45_keys.js)
//      `       the Dragon Block menu, every DBR screen in one place (/dbrgui; client/scripts/90_dbr_hub.js)
//  Want to repaint the menus themselves? Menu (K) > Settings > "Edit menu art".
// =====================================================================================

RPG.ui.configure({
    theme: "vanilla",              // the engine's menus always have the vanilla Minecraft look
    showLogo: true,

    // The original's own character creator handles race and class (08_character.js, client/scripts/20_creator.js)
    chooseRaceOnJoin: false,
    chooseClassOnJoin: false,

    damageNumbers: false,          // The original has no floating numbers (damage pops are part of Ki Sense)

    // The original's Xenoverse HUD is drawn by client/scripts/10_hud_xenoverse.js; the engine's own HUD is off.
    hud: {
        enabled: false,
        primary: "ki",             // big bar  = resource id from 15_resources.js
        secondary: "stamina",      // small bar
        // tertiary: "release",    // a fourth bar, if you add a third resource
        portrait: true,            // the player's live portrait in the scouter orb
        showXp: true,
        showMoney: true,           // Zeni
        showTp: true,              // Training Points
        showSkillBar: true,        // the 8 technique slots
        showEffects: true,         // active forms/buffs in the top right
        scale: 0.75,
        x: 4, y: 4
    },

    // Which menu tabs exist, their order, and their labels. Only Options: DBR's own screens show stats,
    // techniques and sagas (the stats screen, the techniques screen and the quests screen).
    tabs: ["settings"],
    tabLabels: { character: "Status", skills: "Techniques", quests: "Sagas", settings: "Options" },

    // Text colours in the engine menus' dark boxes ("#RRGGBB" or 0xRRGGBB); the menus themselves have the vanilla look.
    colors: {
        title: "#F6E27A",
        text: "#E0E0E0",
        muted: "#9A9A9A",
        accent: "#FFB347",
        good: "#6AE07A",
        bad: "#E87A6A",
        rim: "#B8862B",            // gold rim on small buttons and bars
        rimHover: "#FFD34D",
        barBack: "#0B1430"         // navy behind menu bars
    },

    // DMZ Ragnarok's GUI art (resources/assets/dbr/textures/gui/theme/): DBR's own screens (the Dragon Block menu)
    // draw with it. The engine's menus only take the logo from here (they always look like vanilla Minecraft).
    textures: {
        panel: "dbr:textures/gui/theme/panel.png",
        buttons: "dbr:textures/gui/theme/buttons.png",
        field: "dbr:textures/gui/theme/dropdown.png",
        slot: "dbr:textures/gui/theme/slot.png",
        scrollbar: "dbr:textures/gui/theme/scrollbar.png",
        scrollbarThumb: "dbr:textures/gui/theme/scrollbar_alt.png",
        tab: "dbr:textures/gui/theme/tab.png",
        logo: "dbr:textures/gui/theme/logo.png"
    }
});
