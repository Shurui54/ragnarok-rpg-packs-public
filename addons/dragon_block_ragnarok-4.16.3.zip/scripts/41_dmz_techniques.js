// =====================================================================================
//  41_dmz_techniques.js - original techniques: learn, equip, charge and fire
// =====================================================================================
//  Port of the original's Techniques / TechniqueDispatcher / KiTechniqueHandler / StrikeAttackHandler /
//  EvasionAttackHandler (the original, GPL-3.0). Data: shared/09_dmz_techniques_data.js.
//
//  Per player (var "dmz_tech"):  { u: { id: { x: xp, d: dmgLvl, c: cdLvl, r: durLvl } },
//                                  s: [8 equipped ids], fl: Oozaru loadout backup or null }
//  Cooldowns (var "dmz_tech_cd"): { id: end time in ms }   ("strike_global" too)
//
//  How it is used, like the original:
//   - Learn: masters sell techniques for TP (46_dmz_skills.js -> DMZ_TECH.unlock), quests,
//     /rpgc tech add. Learning shows the original's notification pop-up on the client.
//   - Equip: V > Skills > Ki Attacks / Strike Attacks / Evasion Attacks > "Bind to Slot" > 1..8.
//   - Use: Alt+1..4 (slots 1-4) and Ctrl+1..4 (slots 5-8), keys 1-8 in 45_keys.js. Ki attacks
//     charge while held (0 -> 100 -> 175 %) and fire per the original's rules; strikes and evasions cast at once.
//
//  Other scripts (e.g. the X radial menu) can call the global DMZ_TECH:
//     DMZ_TECH.unlock(p, id, {source, silent})   DMZ_TECH.forget(p, id)   DMZ_TECH.equip(p, slot, id)
//     DMZ_TECH.slots(p) -> [8 ids]   DMZ_TECH.unlocked(p) -> [ids]   DMZ_TECH.press(p, slot) / release(p, slot)
//     DMZ_TECH.cast(p, id)  (fire a technique by id, as if its slot key were tapped)
//     DMZ_TECH.isCharging(p)   DMZ_TECH.cancel(p)   DMZ_TECH.sendState(p)
// =====================================================================================
RPG.effects.define("dmz_tech_rooted", { name: "&7Charging", color: "#AAAAAA", hidden: true, flags: ["noMove", "noJump"] });

// ---- projectiles used by the techniques (35_projectiles.js holds the older ones) -------------
var DMZ_TECH_PROJ = (function () {
    function num(v, d) { var n = Number(v); return isNaN(n) ? d : n; }
    // tag: "dmzki:<technique id>", read by the original's death lines (98_dbr_quirks.js)
    function hurtAround(owner, x, y, z, r, dmg, tag) {
        if (!owner || dmg <= 0) return 0;
        var hit = 0;
        RPG.world.entitiesNear(owner.dimension, x, y, z, r).forEach(function (e) {
            try {
                if (e.uuid === owner.uuid || !e.isAlive() || owner.isAlly(e)) return;
                e.damageFrom(dmg, owner, { kind: "ki", tag: tag || "", ignoreIFrames: true });
                hit++;
            } catch (err) { }
        });
        return hit;
    }
    function burst(owner, x, y, z, proj, big) {
        if (!owner || !proj || proj.getVar("done", 0)) return;
        proj.setVar("done", 1);
        var r = num(proj.getVar("r", 2.5), 2.5);
        var hit = hurtAround(owner, x, y, z, r, num(proj.getVar("dmg", 0), 0), "dmzki:" + String(proj.getVar("tech", "") || ""));
        // The original CombatEvent: a ki GIANT_BALL hit flashes an impact frame (08_dmz_impact_frames.js)
        if (hit > 0 && proj.getVar("endBoom", 0) && typeof DMZ_IMPACT !== "undefined") DMZ_IMPACT.kiHit({ x: x, y: y, z: z, dimension: owner.dimension });
        RPG.world.particle(owner.dimension, big || r > 5 ? "minecraft:explosion_emitter" : "minecraft:explosion", x, y, z, 1, 0, 0);
        RPG.world.sound(owner.dimension, "minecraft:entity.generic.explode", x, y, z, 5, 0.6);
        if (typeof DBR_DESTRUCTION !== "undefined") DBR_DESTRUCTION.blast(owner, x, y, z, r, big);   // ki grief (42_dbr_destruction.js)
    }
    // beams: per hit = damage / maxHits, but a target's first hit is at least 75 % (KiWaveEntity)
    // a beam clash (41b_dbr_beam_clash.js): a locked beam deals nothing; the winner's next hit on the loser is the whole beam
    function beamDamage(owner, target, proj) {
        if (!proj || !target) return 0;
        if (proj.getVar("clashLock", 0)) return 0;
        var tot = num(proj.getVar("dmg", 0), 0), hits = Math.max(1, num(proj.getVar("hits", 1), 1)), key = "h_" + target.uuid;
        if (proj.getVar("breakthrough", "") === target.uuid) { proj.setVar("breakthrough", ""); proj.setVar(key, 1); return tot; }
        if (!proj.getVar(key, 0)) { proj.setVar(key, 1); return Math.max(tot / hits, tot * 0.75); }
        return tot / hits;
    }
    projectile("dmz_tech_ball", {
        shape: "ball", kind: "ki", size: 1, speed: 1, lifetime: 90, knockback: 0.4,
        damage: function () { return 0; },                       // the explosion below hits everything once
        onHit: function (o, t, x, y, z, proj) {
            if (proj && proj.getVar("noBlock", 0) && !t) { proj.discard(); return; }
            burst(o, x, y, z, proj, false);
            if (proj && proj.getVar("tech", "") === "soul_punisher" && t) RPG.world.particle(t.dimension, "minecraft:end_rod", x, y + 1, z, 30, 0.6, 0.1);
        },
        onEnd: function (o, x, y, z, proj) { if (proj && proj.getVar("endBoom", 0)) burst(o, x, y, z, proj, true); }
    });
    projectile("dmz_tech_wave", {
        shape: "beam", kind: "ki", size: 1, length: 100, speed: 1.2, duration: 80, hitInterval: 20, knockback: 0.6,
        followAim: false, slowPerHit: 0.75, damage: beamDamage,
        // the wave explodes at its tip when it ends: radius size x 4, full damage (KiWaveEntity)
        onEnd: function (o, x, y, z, proj) { burst(o, x, y, z, proj, true); }
    });
    projectile("dmz_tech_beam", {
        shape: "laser", kind: "ki", size: 0.8, length: 100, speed: 2, duration: 80, hitInterval: 20, knockback: 0.5,
        followAim: false, damage: beamDamage
    });
    projectile("dmz_tech_laser", {
        shape: "laser", kind: "ki", size: 0.4, length: 64, speed: 16, duration: 10, hitInterval: 10, knockback: 0.2, damage: 4
    });
    projectile("dmz_tech_disk", {
        shape: "disk", kind: "ki", size: 1, speed: 1.5, lifetime: 70, pierce: 999, knockback: 0, damage: 4,
        particles: "minecraft:wax_on",
        onHit: function (o, t, x, y, z, proj) { if (!t && proj && proj.getVar("boom", 0)) burst(o, x, y, z, proj, true); },
        onEnd: function (o, x, y, z, proj) { if (proj && proj.getVar("boom", 0)) burst(o, x, y, z, proj, true); }
    });
    projectile("dmz_tech_bullet", {
        shape: "ball", kind: "ki", size: 0.4, speed: 1.5, lifetime: 40, knockback: 0.1, damage: 2,
        onHit: function (o, t, x, y, z) { if (o) RPG.world.particle(o.dimension, "minecraft:crit", x, y, z, 3, 0.1, 0.05); }
    });
    projectile("dmz_tech_orb", {
        shape: "sprite", kind: "ki", texture: DMZ_TEX + "ki/kiblast.png", spin: 15, size: 0.8, speed: 0.01, lifetime: 120, knockback: 0.3, damage: 2,
        onHit: function (o, t, x, y, z) { if (o) RPG.world.particle(o.dimension, "minecraft:explosion", x, y, z, 1, 0, 0); }
    });

    // =========================================================================================
    //  The original's ki entities (KiBlastEntity, KiWaveEntity, KiLaserEntity, KiDiskEntity):
    //  movement, hits, pulses, terrain and explosions. Every shot carries its original look in its tag
    //  (k: kind, rt: render type, sz: original size, cs: cast size, ct: charge growth ticks), drawn
    //  on every client by client/scripts/51_dmz_ki_render.js with the original's own ki shader.
    // =========================================================================================
    var BALL_BOX = 0.8;                                  // KI_BLAST is sized 0.8 x 0.8 (scaled by size)
    // AbstractKiProjectile.shouldDamage: allies never; neutral things only when looked straight at
    function canHurt(owner, e) {
        if (!e || e.uuid === owner.uuid || !e.isAlive()) return false;
        try { if (owner.isAlly(e)) return false; } catch (x) { }
        try {
            if (owner.isPlayer() && !e.isPlayer() && !e.isHostile()) {
                var yaw = owner.yaw * Math.PI / 180, pitch = owner.pitch * Math.PI / 180;
                var lx = -Math.sin(yaw) * Math.cos(pitch), ly = -Math.sin(pitch), lz = Math.cos(yaw) * Math.cos(pitch);
                var dx = e.x - owner.x, dy = e.y + e.height / 2 - owner.eyeY, dz = e.z - owner.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
                return (dx * lx + dy * ly + dz * lz) / l > 0.95;
            }
        } catch (x2) { }
        return true;
    }
    // applyDamageOrHeal: a normal hurt (the target's hurt window applies, unlike hurtAround)
    function hurt(owner, e, dmg, tag) {
        try { return e.damageFrom(dmg, owner, { kind: "ki", tag: tag || "", ignoreIFrames: false }) !== false; } catch (err) { return false; }
    }
    function hurtNear(owner, x, y, z, r, dmg, tag, box) {
        if (!owner || dmg <= 0) return 0;
        var n = 0;
        RPG.world.entitiesNear(owner.dimension, x, y, z, r + 3).forEach(function (e) {
            if (!canHurt(owner, e)) return;
            var cy = e.y + e.height / 2, hw = e.width / 2, hh = e.height / 2;
            var inside = box
                ? Math.abs(e.x - x) <= r + hw && Math.abs(cy - y) <= r + hh && Math.abs(e.z - z) <= r + hw
                : Math.sqrt(Math.pow(Math.max(0, Math.abs(e.x - x) - hw), 2) + Math.pow(Math.max(0, Math.abs(cy - y) - hh), 2) + Math.pow(Math.max(0, Math.abs(e.z - z) - hw), 2)) <= r;
            if (inside && hurt(owner, e, dmg, tag)) n++;
        });
        return n;
    }
    function techTag(proj) { return "dmzki:" + String(proj.getVar("tech", "") || ""); }
    // the original look of the shot, for the clients
    function look(proj, o) { try { proj.setTag(JSON.stringify(o)); } catch (e) { } }
    // KiExplosionVisualEntity + the KI_EXPLOSION particle + the boom, on every client nearby
    function fx(owner, x, y, z, visual, particle, colors) {
        var msg = { x: x, y: y, z: z, v: visual, p: particle, c: colors ? [colors.core, colors.border, colors.outline] : null };
        RPG.server.players().forEach(function (pl) {
            try { if (pl.dimension === owner.dimension && Math.abs(pl.x - x) < 160 && Math.abs(pl.z - z) < 160) RPG.net.send(pl, "dmz_ki_fx", msg); } catch (e) { }
        });
    }
    // KI_SPLASH_WAVE on whoever a beam, laser or disk hits (KiWaveEntity / KiLaserEntity / KiDiskEntity.damage*)
    function splashHit(owner, t, amount, proj, size, key) {
        if (!(amount > 0) || !owner || !t) return amount;
        var c = colorsOf(proj), msg = { x: t.x, y: t.y + (Number(t.height) || 1.8) / 2, z: t.z, v: 0, p: 0, s: size, c: [c.core, c[key || "border"], c.outline] };
        RPG.server.players().forEach(function (pl) {
            try { if (pl.dimension === owner.dimension && Math.abs(pl.x - msg.x) < 48 && Math.abs(pl.z - msg.z) < 48) RPG.net.send(pl, "dmz_ki_fx", msg); } catch (e) { }
        });
        return amount;
    }
    function colorsOf(proj) {
        var c = proj.getVar("colors", null);
        return c && typeof c === "object" ? c : { core: "#FFFFFF", border: "#29D8FF", outline: "#0077FF" };
    }
    function ballCenter(proj) { var sz = proj.getSize(); return { x: proj.x, y: proj.y + sz * BALL_BOX / 2, z: proj.z }; }
    // KiBlastEntity.explodeAndDie (balls) and its giant detonation (Spirit Bomb, Supernova)
    function ballBoom(owner, proj) {
        if (!owner || !proj || proj.getVar("done", 0)) return;
        proj.setVar("done", 1);
        var sz = proj.getSize(), giant = !!proj.getVar("giant", 0), c = ballCenter(proj), dmg = num(proj.getVar("dmg", 0), 0);
        var r = giant ? Math.max(sz * 1.5, 5) : Math.max(sz * 0.5, 2.5);
        var hit = hurtNear(owner, c.x, c.y, c.z, r, dmg, techTag(proj), true);
        if (hit > 0 && giant && typeof DMZ_IMPACT !== "undefined") DMZ_IMPACT.kiHit({ x: c.x, y: c.y, z: c.z, dimension: owner.dimension });
        fx(owner, c.x, c.y, c.z, (giant ? sz * 0.9 : sz * 0.25) * 2, r * 1.8, colorsOf(proj));
        RPG.world.sound(owner.dimension, "minecraft:entity.generic.explode", c.x, c.y, c.z, 5, 0.6);
        if (typeof DBR_DESTRUCTION !== "undefined") DBR_DESTRUCTION.blast(owner, c.x, c.y, c.z, r, giant);
        proj.discard();
    }
    // AbstractKiProjectile.getDamagePerHit: damage / max(1, firing window / 20)
    function perHit(proj) { return num(proj.getVar("dmg", 0), 0) / Math.max(1, Math.floor(num(proj.getVar("life", 20), 20) / 20)); }
    // KiBlastEntity.pulseAreaDamage: every 10 ticks in flight, everything within 5 blocks of the ball's surface
    function pulse(owner, proj) {
        var c = ballCenter(proj);
        hurtNear(owner, c.x, c.y, c.z, proj.getSize() / 2 + 5, perHit(proj), techTag(proj), false);
    }
    function speedSq(proj) { return proj.vx * proj.vx + proj.vy * proj.vy + proj.vz * proj.vz; }
    // beams: a target is hit at most every `gap` ticks (its hurt window), the first hit at least 75 % (applyBeamHit)
    // a beam clash (41b_dbr_beam_clash.js): a clash-locked beam hits nothing; the winner's next hit on the loser is the
    // whole beam, through the hurt window (applyBeamHit's breakthrough)
    function beamHit(proj, target, gap) {
        if (proj.getVar("clashLock", 0)) return -1;
        var key = "h_" + target.uuid, now = RPG.server.getTick(), last = num(proj.getVar(key, -999), -999);
        if (proj.getVar("breakthrough", "") === target.uuid) { proj.setVar("breakthrough", ""); proj.setVar(key, now); return num(proj.getVar("dmg", 0), 0); }
        if (now - last < gap) return -1;
        var first = last === -999;
        proj.setVar(key, now);
        var tot = num(proj.getVar("dmg", 0), 0), each = perHit(proj);
        return first ? Math.max(each, tot * 0.75) : each;
    }

    // balls: big bang, burning attack, sokidan, soul punisher, small blasts, barrage shots
    projectile("dmz_ki_ball", {
        shape: "ball", kind: "ki", hitboxScale: BALL_BOX, size: 1, speed: 1, lifetime: 90, knockback: 0, respectIFrames: true, tickEvery: 10,
        // KiBlastEntity.onHitEntity: the direct hit splashes KI_SPLASH_WAVE (border colour, the ball's size) on the target
        damage: function (o, t, proj) { if (!proj || proj.getVar("noHit", 0)) return -1; return splashHit(o, t, num(proj.getVar("dmg", 0), 0), proj, proj.getSize()); },
        onHit: function (o, t, x, y, z, proj) {
            if (!proj || proj.isHeld()) return;
            if (proj.getVar("soul", 0)) { proj.setVar("done", 1); proj.discard(); return; }   // Soul Punisher: no blast
            ballBoom(o, proj);
        },
        onTick: function (o, age, proj) { if (o && proj && !proj.isHeld() && !proj.getVar("soul", 0) && !proj.getVar("noHit", 0)) pulse(o, proj); },
        onEnd: function (o, x, y, z, proj) { if (proj && !proj.getVar("soul", 0) && !proj.getVar("noHit", 0)) ballBoom(o, proj); }
    });
    // giant balls (Spirit Bomb, Supernova): through people and terrain, slowed by both, a growing crater at the end
    projectile("dmz_ki_giant", {
        shape: "ball", kind: "ki", hitboxScale: BALL_BOX, size: 10, speed: 0.5, lifetime: 300, knockback: 0, respectIFrames: true,
        pierce: 100000, slowPerHit: 0.85, throughBlocks: true, tickEvery: 10,
        damage: function (o, t, proj) { return proj ? num(proj.getVar("dmg", 0), 0) : 0; },
        onHit: function (o, t, x, y, z, proj) { if (proj && !proj.isHeld() && speedSq(proj) < 0.01) ballBoom(o, proj); },
        onTick: function (o, age, proj) {
            if (!o || !proj || proj.isHeld()) return;
            pulse(o, proj);
            if (age % 20 !== 0) return;
            var c = ballCenter(proj);
            if (typeof DBR_DESTRUCTION !== "undefined" && DBR_DESTRUCTION.eat(o, c.x, c.y, c.z, proj.getSize() * 1.2) > 0)
                proj.setVelocity(proj.vx * 0.95, proj.vy * 0.95, proj.vz * 0.95);
            if (speedSq(proj) < 0.01) ballBoom(o, proj);
        },
        onEnd: function (o, x, y, z, proj) { ballBoom(o, proj); }
    });
    // waves (Kamehameha, Galick Gun, Final Flash, Masenko, Heat Dome, Mouth Blast): KiWaveEntity
    projectile("dmz_ki_wave", {
        shape: "beam", kind: "ki", size: 1, length: 300, speed: 1.2, duration: 80, hitInterval: 1, knockback: 0,
        followAim: false, stayAtFire: true, slowPerHit: 0.75, minSpeed: 0.05, stopResistance: 1000, tickEvery: 1,
        damage: function (o, t, proj) { return proj ? splashHit(o, t, beamHit(proj, t, 20), proj, num(proj.getVar("sz", 1), 1)) : -1; },
        onTick: function (o, age, proj) {
            if (!o || !proj || proj.isHeld() || proj.getLength() < 0.5) return;
            // KiTerrainDestruction.eat works on what the tip newly reached; here: again once the tip has moved a block
            var tip = proj.tip, lx = num(proj.getVar("ex", 1e9), 1e9), ly = num(proj.getVar("ey", 0), 0), lz = num(proj.getVar("ez", 0), 0);
            if ((tip.x - lx) * (tip.x - lx) + (tip.y - ly) * (tip.y - ly) + (tip.z - lz) * (tip.z - lz) < 1) return;
            proj.setVar("ex", tip.x); proj.setVar("ey", tip.y); proj.setVar("ez", tip.z);
            if (typeof DBR_DESTRUCTION !== "undefined") DBR_DESTRUCTION.eat(o, tip.x, tip.y, tip.z, Math.min(12, num(proj.getVar("sz", 1), 1) * 4));   // WAVE maxDestructionRadius 12
        },
        // explodeAndDie at the tip: radius size x 4, the full damage
        onEnd: function (o, x, y, z, proj) {
            if (!o || !proj || proj.getVar("done", 0)) return;
            proj.setVar("done", 1);
            var sz = num(proj.getVar("sz", 1), 1), r = sz * 4;
            hurtNear(o, x, y, z, r, num(proj.getVar("dmg", 0), 0), techTag(proj), true);
            fx(o, x, y - 0.5, z, sz * 1.8 * 2, r * 2.4, colorsOf(proj));
            RPG.world.sound(o.dimension, "minecraft:entity.generic.explode", x, y, z, 5, 0.6);
            if (typeof DBR_DESTRUCTION !== "undefined") DBR_DESTRUCTION.blast(o, x, y, z, r, true);
        }
    });
    // Special Beam Cannon and the lasers: KiLaserEntity (fixed where fired; blows up on the first block)
    function laserDef(id, gap) {
        projectile(id, {
            shape: "laser", kind: "ki", size: 0.5, length: 250, speed: 2, duration: 80, hitInterval: 1, knockback: 0,
            followAim: false, stayAtFire: true, blockHit: true,
            damage: function (o, t, proj) { return proj ? splashHit(o, t, beamHit(proj, t, gap), proj, num(proj.getVar("sz", 1), 1), "core") : -1; },
            onHit: function (o, t, x, y, z, proj) {
                if (t || !o || !proj || proj.getVar("done", 0)) return;
                proj.setVar("done", 1);
                var r = num(proj.getVar("sz", 1), 1);
                hurtNear(o, x, y, z, r, num(proj.getVar("dmg", 0), 0), techTag(proj), false);
                RPG.world.particle(o.dimension, "minecraft:explosion_emitter", x, y, z, 1, 0, 0);
                RPG.world.sound(o.dimension, "minecraft:entity.generic.explode", x, y, z, 4, 0.7);
                if (typeof DBR_DESTRUCTION !== "undefined") DBR_DESTRUCTION.blast(o, x, y, z, r, false);
            }
        });
    }
    laserDef("dmz_ki_beam", 10);
    laserDef("dmz_ki_laser", 10);
    // Kienzan & co: KiDiskEntity (cuts through people and terrain)
    projectile("dmz_ki_disk", {
        shape: "disk", kind: "ki", hitboxScale: 1, size: 1, speed: 1.5, lifetime: 70, knockback: 0, respectIFrames: true,
        pierce: 100000, throughBlocks: true, tickEvery: 1,
        damage: function (o, t, proj) { return proj ? splashHit(o, t, num(proj.getVar("dmg", 0), 0), proj, proj.getSize(), "core") : 0; },
        onTick: function (o, age, proj) {
            if (!o || !proj) return;
            if (proj.isHeld()) {
                // charging: whatever touches the disk in the hand is cut every 10 ticks (pulseAreaDamage)
                if (age % 10 === 0) hurtNear(o, proj.x, proj.y + 0.1, proj.z, proj.getSize() * 0.5 + 0.5, num(proj.getVar("dmg", 0), 0), techTag(proj), true);
                return;
            }
            var lx = num(proj.getVar("lx", NaN), NaN);
            if (!isNaN(lx) && typeof DBR_DESTRUCTION !== "undefined")
                DBR_DESTRUCTION.slice(o, lx, num(proj.getVar("ly", 0), 0), num(proj.getVar("lz", 0), 0), proj.x, proj.y, proj.z, proj.getSize());
            proj.setVar("lx", proj.x); proj.setVar("ly", proj.y); proj.setVar("lz", proj.z);
        }
    });

    return { burst: burst, hurtAround: hurtAround, hurtNear: hurtNear, look: look, fx: fx, ballBoom: ballBoom, BALL_BOX: BALL_BOX };
})();

var DMZ_TECH = (function () {
    var TD = DMZ_TECH_DATA, N = TD.SLOT_COUNT;
    var SESS = {};          // uuid -> ki charge session
    var FIRING = {};        // uuid -> { until, drain, emitter } while a restricted ki attack fires

    // ---------------------------------------------------------------------------------
    //  storage
    // ---------------------------------------------------------------------------------
    function load(p) {
        var v = p.getVar("dmz_tech", null);
        if (!v || typeof v !== "object") v = {};
        if (!v.u || typeof v.u !== "object") v.u = {};
        var s = [], old = v.s && v.s.length !== undefined ? v.s : [];
        for (var i = 0; i < N; i++) s.push(typeof old[i] === "string" ? old[i] : "");
        v.s = s;
        if (!v.fl || typeof v.fl !== "object") v.fl = null;
        return v;
    }
    function save(p, v) { p.setVar("dmz_tech", v); }
    function unlocked(p) { return Object.keys(load(p).u); }
    function has(p, id) { return !!load(p).u[id]; }
    function slots(p) { return load(p).s.slice(); }
    function rec(p, id) { return load(p).u[id] || null; }

    function nowMs() { return Date.now(); }
    function cds(p) { var c = p.getVar("dmz_tech_cd", null); return c && typeof c === "object" ? c : {}; }
    function cdLeft(p, id) { var e = Number(cds(p)[id]) || 0; return Math.max(0, Math.ceil((e - nowMs()) / 50)); }
    function setCd(p, id, ticks) {
        var c = cds(p), now = nowMs();
        Object.keys(c).forEach(function (k) { if (Number(c[k]) <= now) delete c[k]; });
        if (ticks > 0) c[id] = now + ticks * 50; else delete c[id];
        p.setVar("dmz_tech_cd", c);
    }
    function creative(p) { try { return p.getGameMode() === "creative"; } catch (e) { return false; } }
    function msg(p, key, args, color) { RPG.net.send(p, "dmz_msg", { key: key, args: args || [], color: color || "#FF5555" }); }

    // ---- original stat getters (StatsData) ----
    function view(p) { return dmzView(p); }
    function noForms(v) {
        return { stat: v.stat, cls: v.cls, release: v.release, mult: function () { return 1; }, armor: v.armor, toughness: v.toughness, race: v.race };
    }
    function kiDamage(p) { return DMZ_F.ki(view(p)); }
    function kiNoForms(p) { return DMZ_F.ki(noForms(view(p))); }
    function strikeDamage(p) { return DMZ_F.strike(view(p)); }
    function strikeNoForms(p) { return DMZ_F.strike(noForms(view(p))); }
    function android(p) { return !!p.getVar("dmz_android", 0); }
    function costMod(p) { return android(p) ? 0.5 : 1; }                        // kiAttackCostModifier
    function dmgMod(p) { return android(p) ? 0.85 : 1; }                        // kiAttackDamageModifier
    function transformed(p) { var v = view(p); return v.mult("PWR") > 1.0001; }
    function release(p) { return Number(p.getVar("dmz_release", 0)) || 0; }
    function dmzRace(p) { return DMZ_DATA.DMZ[p.race] || p.race || "human"; }
    function raceAllowed(p, id) { return DMZ_SKILLS_DATA.allowed(id, dmzRace(p), android(p)); }
    function skillLevel(p, s) { return typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS.level(p, s) : 1; }

    // what the skills screen shows for each technique (getCalculatedCost, actual cooldown, damage...)
    // the player's numbers every technique's info needs, worked out once per call (they can't change in between)
    function infoBase(p) {
        var v = view(p), nf = noForms(v);
        return { v: v, ki: DMZ_F.ki(v), kiNF: DMZ_F.ki(nf), strike: DMZ_F.strike(v), strikeNF: DMZ_F.strike(nf) };
    }
    function info(p, id, r, base) {
        r = r || {};
        base = base || infoBase(p);
        var k = TD.kind(id), v = base.v, out = { kind: k };
        if (k === "ki") {
            var T = TD.KI[id];
            out.cost = Math.round(TD.kiCost(id, base.kiNF) * 10) / 10;
            out.cd = TD.kiCooldown(id, 1, r.c);
            out.dmg = Math.floor(base.ki * T.dmg);
        } else if (k === "strike") {
            out.cost = Math.round(TD.strikeCost(id, base.strikeNF, r.d) * 10) / 10;
            out.cd = TD.strikeCooldown(id, r.c);
            out.dmg = Math.floor(base.strike * TD.strikeDamageMult(id, r.d));
        } else if (k === "evasion") {
            out.cost = Math.round(TD.evasionCost(id, v.stat("SKP"), v.stat("PWR"), r.r) * 10) / 10;
            out.cd = TD.evasionCooldown(id, r.c);
            out.dur = TD.evasionDuration(id, r.r);
            out.dmg = Math.floor(TD.evasionHit(id, v.stat("SKP"), v.stat("PWR")));
        }
        out.req = TD.MIN_XP_COST;
        return out;
    }

    function sendState(p) {
        var v = load(p), u = {}, inf = {}, cd = {}, base = null, c = cds(p), t = nowMs();
        Object.keys(v.u).forEach(function (id) {
            var r = v.u[id] || {};
            u[id] = { x: Math.floor(r.x || 0), d: r.d || 0, c: r.c || 0, r: r.r || 0 };
            if (TD.exists(id)) inf[id] = info(p, id, r, base || (base = infoBase(p)));
            var left = Math.max(0, Math.ceil(((Number(c[id]) || 0) - t) / 50));       // cdLeft without re-reading the var
            if (left > 0) cd[id] = left;
        });
        // legacy (non-original) skills sitting in a slot show their own cooldowns
        v.s.forEach(function (id) { if (id && !TD.exists(id)) { var l = Math.ceil(Number(p.cooldownLeft(id)) || 0); if (l > 0) cd[id] = l; } });
        var g = cdLeft(p, "strike_global");
        if (g > 0) cd.strike_global = g;
        RPG.net.send(p, "dmz_tech_state", { u: u, s: v.s, cd: cd, info: inf, kc: skillLevel(p, "kicontrol") > 0, fl: !!v.fl,
            race: dmzRace(p), android: android(p) });
    }

    // ---------------------------------------------------------------------------------
    //  learning (Techniques.unlockTechnique / removeTechnique) and the pop-up
    // ---------------------------------------------------------------------------------
    function markOwnedSkill(p, id) {
        if (typeof DMZ_SKILLS === "undefined") return;
        var map = DMZ_SKILLS.levels(p);
        if (typeof map[id] === "number" && map[id] >= 1) return;
        map[id] = 1;
        p.setVar("dmz_skills", map);
        DMZ_SKILLS.sendState(p);
    }
    /** opts: { source: "master" | "quest" | "command" | "form", silent } */
    function unlock(p, id, opts) {
        opts = opts || {};
        id = String(id || "").toLowerCase();
        if (!TD.exists(id) || id === TD.REVIVE_ID) return false;
        var v = load(p);
        if (v.u[id]) { if (!opts.silent) markOwnedSkill(p, id); return false; }
        if (Object.keys(v.u).length >= TD.MAX_UNLOCKED) { msg(p, "quest.dmz.reward.technique_slots_full", [], "#FFFF55"); return false; }
        v.u[id] = { x: 0, d: 0, c: 0, r: 0 };
        save(p, v);
        if (opts.source !== "form") markOwnedSkill(p, id);
        if (!opts.silent) RPG.net.send(p, "dmz_tech_learned", { id: id, kind: TD.kind(id), source: opts.source || "" });
        sendState(p);
        return true;
    }
    function forget(p, id) {
        var v = load(p);
        if (!v.u[id] || id === TD.REVIVE_ID) return false;
        delete v.u[id];
        for (var i = 0; i < N; i++) if (v.s[i] === id) v.s[i] = "";
        save(p, v);
        var s = SESS[p.uuid];
        if (s && s.id === id) cancel(p);
        if (typeof DMZ_SKILLS !== "undefined" && DMZ_SKILLS.owned(p, id)) {         // DeleteTechniqueC2S also removes the skill
            var map = DMZ_SKILLS.levels(p);
            delete map[id];
            p.setVar("dmz_skills", map);
            DMZ_SKILLS.sendState(p);
        }
        sendState(p);
        return true;
    }
    function clearAll(p) {
        cancel(p);
        save(p, { u: {}, s: ["", "", "", "", "", "", "", ""], fl: null });
        p.setVar("dmz_tech_cd", null);
        sendState(p);
    }

    // ---------------------------------------------------------------------------------
    //  equipping (Techniques.equipOrSwapTechnique + EquipTechniqueC2S rules)
    // ---------------------------------------------------------------------------------
    function equip(p, slot, id) {
        slot = Math.floor(Number(slot));
        id = String(id || "");
        if (!(slot >= 0 && slot < N)) return false;
        var v = load(p);
        if (v.fl && slot < TD.OOZARU_LOADOUT.length) return false;                     // the form loadout owns these
        if (id === TD.REVIVE_ID || v.s[slot] === TD.REVIVE_ID) return false;
        if (id) {
            if (TD.exists(id)) {
                if (!v.u[id]) return false;
                if (!raceAllowed(p, id)) return false;
            } else if (!(RPG.skills.exists(id) && p.hasSkill(id))) return false;       // older non-original skills still fit
        }
        var existing = -1;
        for (var i = 0; i < N; i++) if (id && v.s[i] === id) { existing = i; break; }
        if (existing >= 0) { var tmp = v.s[slot]; v.s[slot] = id; v.s[existing] = tmp; }
        else v.s[slot] = id;
        save(p, v);
        sendState(p);
        return true;
    }

    // ---- Oozaru loadout (Techniques.applyFormLoadout / restoreFormLoadout) ----
    function applyLoadout(p) {
        var v = load(p), L = TD.OOZARU_LOADOUT, changed = false;
        if (!v.fl) { v.fl = { b: v.s.slice(0, L.length), g: [] }; changed = true; }
        L.forEach(function (id, i) {
            if (!v.u[id]) { v.u[id] = { x: 0, d: 0, c: 0, r: 0 }; v.fl.g.push(id); changed = true; }
            if (v.s[i] !== id) {
                for (var j = 0; j < N; j++) if (j !== i && v.s[j] === id) v.s[j] = "";
                v.s[i] = id; changed = true;
            }
        });
        if (changed) { save(p, v); sendState(p); }
    }
    function restoreLoadout(p) {
        var v = load(p);
        if (!v.fl) return;
        var g = v.fl.g || [], b = v.fl.b || [];
        g.forEach(function (id) { delete v.u[id]; var s = SESS[p.uuid]; if (s && s.id === id) cancel(p); });
        for (var j = TD.OOZARU_LOADOUT.length; j < N; j++) if (g.indexOf(v.s[j]) >= 0) v.s[j] = "";
        for (var i = 0; i < TD.OOZARU_LOADOUT.length; i++) v.s[i] = b[i] && (v.u[b[i]] || !TD.exists(b[i])) ? b[i] : "";
        v.fl = null;
        save(p, v);
        sendState(p);
    }
    function inOozaru(p) {
        if (typeof DMZ_TF === "undefined" || !DMZ_TF.activeForm) return false;
        var f = DMZ_TF.activeForm(p);
        return !!f && f.group === "oozaru";
    }

    // ---------------------------------------------------------------------------------
    //  using a slot (ClientStatsEvents.handleTechniqueSlotInput + server checks)
    // ---------------------------------------------------------------------------------
    function handEmpty(p) { var h = p.getHeldItem(); return !h || h === "minecraft:air"; }
    // The original refuses these silently (canActivateTechnique); a short hint says why the key did nothing
    var HINT_AT = {};
    function hint(p, text) {
        var now = Date.now();
        if (now - (HINT_AT[p.uuid] || 0) < 1500) return;
        HINT_AT[p.uuid] = now;
        p.actionbar(text);
    }
    function canActivate(p, id) {
        if (p.getGameMode && p.getGameMode() === "spectator") return false;
        if (p.hasEffect("stunned")) return false;
        if (skillLevel(p, "kicontrol") <= 0) { msg(p, "message.dragonminez.technique.no_ki_control"); return false; }
        if (release(p) < 5) { hint(p, "&7Release at least 5% of your power first (hold Charge Ki)."); return false; }
        var S = TD.STRIKE[id];
        if (S && S.needsItem) { if (holding(p, S.needsItem)) return true; hint(p, "&7" + TD.english(id) + " needs the right weapon in your hand."); return false; }
        if (S && S.heldItemOk) return true;
        if (handEmpty(p)) return true;
        hint(p, "&7Empty your main hand to use techniques.");
        return false;
    }
    function press(p, slot) {
        if (!p.getVar("dmz_created", 0)) return;
        if (SESS[p.uuid]) return;                                  // a charge session owns the keys
        var id = load(p).s[slot];
        if (!id) return;
        if (!TD.exists(id)) {                                      // an older script skill in the slot
            if (RPG.skills.exists(id) && p.hasSkill(id)) { p.castSkill(id); RPG.schedule(1, function () { sendState(p); }); }
            return;
        }
        if (id === TD.REVIVE_ID) {                                  // ClientStatsEvents: ReviveTechniqueData -> WorldBossReviveC2S
            if (!has(p, id) || p.hasEffect("stunned") || cdLeft(p, id) > 0) return;
            var lt = lockedTarget(p);
            if (typeof DMZ_WB !== "undefined") DMZ_WB.requestRevive(p, lt && lt.isPlayer() ? lt : null);
            return;
        }
        if (!has(p, id) || !canActivate(p, id)) return;
        cast(p, id, slot);
    }
    // ---- the world boss Revive technique (Techniques.installRevive / uninstallRevive) ----
    function hasRevive(p) { return !!load(p).u[TD.REVIVE_ID]; }
    function installRevive(p, slotIndex) {
        var v = load(p), changed = false;
        if (!v.u[TD.REVIVE_ID]) { v.u[TD.REVIVE_ID] = { x: 0, d: 0, c: 0, r: 0 }; changed = true; }
        if (v.s[slotIndex] !== TD.REVIVE_ID) {
            for (var i = 0; i < N; i++) if (v.s[i] === TD.REVIVE_ID) v.s[i] = "";
            v.rd = v.s[slotIndex] || "";
            v.s[slotIndex] = TD.REVIVE_ID;
            changed = true;
        }
        if (changed) { save(p, v); sendState(p); }
        return changed;
    }
    function uninstallRevive(p) {
        var v = load(p), changed = !!v.u[TD.REVIVE_ID];
        delete v.u[TD.REVIVE_ID];
        for (var i = 0; i < N; i++) {
            if (v.s[i] !== TD.REVIVE_ID) continue;
            var back = v.rd || "";
            v.s[i] = back && (v.u[back] || (!TD.exists(back) && RPG.skills.exists(back))) && v.s.indexOf(back) < 0 ? back : "";
            changed = true;
        }
        v.rd = "";
        if (changed) { save(p, v); sendState(p); }
        return changed;
    }
    function releaseKey(p, slot) {
        var s = SESS[p.uuid];
        if (s && s.slot === slot) s.holding = false;
    }
    function cast(p, id, slot) {
        var k = TD.kind(id);
        if (k === "strike") castStrike(p, id);
        else if (k === "evasion") castEvasion(p, id);
        else if (k === "ki") startCharge(p, id, slot === undefined ? -1 : slot);
    }

    // ---------------------------------------------------------------------------------
    //  ki attacks: the charge state machine (TickHandler.handleTechniqueCharge)
    // ---------------------------------------------------------------------------------
    // ---------------------------------------------------------------------------------
    //  where each ki attack forms and how it grows (KiBlastEntity / KiWaveEntity / KiLaserEntity /
    //  KiDiskEntity setup*Player + castOffset). Engine origin = the original's: base "center" is the middle of
    //  the hitbox (ownerCastCenterY), side = the caster's right, up = world up (balls) or the view's up
    //  (waves, beams, disks), forward along the look, plus clear = the attack's own radius.
    // ---------------------------------------------------------------------------------
    var BB = DMZ_TECH_PROJ.BALL_BOX, MAX_OWNER_SCALE = 6;
    // AbstractKiProjectile.castOffset: side / forward grow with the caster's box width against 0.6, up with its height
    // against 1.8, never below 1 and at most 6 (the engine's origin boxScale); offsets that already come from the box
    // are divided by that scale first, as the original passes them in player-equivalent units
    function hScale(p) { return Math.max(1, Math.min(MAX_OWNER_SCALE, (Number(p.height) || 1.8) / 1.8)); }
    function ballUp(p, size) {                                                                     // calcCenterOffsetY
        var hs = hScale(p), h = Number(p.height) || 1.8;
        return (Math.max(0.5 * hs, size * 0.5 + 0.1 - h * 0.5) - BB * size * 0.5) / hs;
    }
    function ballForward(p, size) { return (Number(p.width) || 0.6) / 2 + size / 2 + 0.1; }      // calcForwardOffset
    function overheadUp(p, size) {                                                                 // calcOverheadOffsetY
        var hs = hScale(p), h = Number(p.height) || 1.8;
        return (h * 0.5 + 0.6 * hs + size * 0.5 - BB * size * 0.5) / hs;
    }
    // KiWaveEntity cast sizes (the charging orb is drawn at castSize x 1.5) and growth ticks (castWave or 12)
    function waveCast(id, size) {
        switch (id) {
            case "kamehameha": return { rt: 1, cs: 0.2, ct: 12 };
            case "galick_gun": return { rt: 2, cs: 0.3, ct: 12 };
            case "final_flash": return { rt: 3, cs: size / 2, ct: 50 };
            case "masenko": return { rt: 4, cs: 0.2, ct: 15 };
            case "heat_dome": return { rt: 0, cs: 1.0, ct: 12, dome: true };
            case "mouth_blast": return { rt: 0, cs: size / 2, ct: 12, mouth: true };
            default: return { rt: 0, cs: 0.2, ct: 12 };
        }
    }
    // the wave's charging orb moves while the pose plays out (KiWaveEntity.tick)
    function waveOffsets(id, wc, age) {
        if (wc.dome) return { base: "center", side: 0, up: 0, forward: 0, clear: 0, viewUp: 0 };
        if (wc.mouth) return { base: "eye", side: 0, up: -0.25, forward: 0.3, clear: wc.cs * 1.5, viewUp: 1 };
        var o;
        if (wc.rt === 1 || wc.rt === 0) o = age <= 5 ? [0, 0.1, 0.5] : age < 15 ? [0, 0.3, 0.5] : [0.4, 0.1, 0];
        else if (wc.rt === 2) o = age <= 5 ? [0, 0.3, 0.5] : [0.2, 0.4, -0.3];
        else if (wc.rt === 3) o = [0, 0.3, 2.5];
        else o = [0, 0.9, 0.2];
        return { base: "center", side: o[0], up: o[1], forward: o[2], clear: wc.cs * 1.5, viewUp: 1 };
    }
    function chargeSpec(p, id, T, size) {
        var spec = chargeSpecOf(p, id, T, size);
        if (spec && spec.origin && spec.origin.boxScale === undefined) spec.origin.boxScale = MAX_OWNER_SCALE;
        if (spec && spec.origin2 && spec.origin2.boxScale === undefined) spec.origin2.boxScale = MAX_OWNER_SCALE;
        return spec;
    }
    function chargeSpecOf(p, id, T, size) {
        var hs = hScale(p);
        switch (T.type) {
            case "MEDIUM_BALL":
                if (id === "sokidan") return { def: "dmz_ki_ball", k: "ball", rt: 8, ct: 40, origin: { base: "center", up: 0.5, forward: 0.5, clear: size / 2 } };
                // castClearanceRadius is 0 for the Soul Punisher and the Tri-Beam while they charge
                if (id === "soul_punisher") return { def: "dmz_ki_ball", k: "ball", rt: 4, ct: 100, origin: { base: "center", side: -0.5, up: 1.2 + (size * 0.15 - BB * size / 2) / hs, forward: 0.1, clear: 0 } };
                if (id === "fake_moon") return { def: "dmz_ki_ball", k: "ball", rt: 11, ct: 60, origin: { base: "center", up: 0.5, forward: 0.5, clear: size / 2 } };
                if (id === "neo_kikoho") return { def: "dmz_ki_ball", k: "ball", rt: 14, ct: 40, origin: { base: "center", up: -BB * size / 2, forward: 0.6, clear: 0 } };
                return { def: "dmz_ki_ball", k: "ball", rt: 1, ct: 100, origin: { base: "center", up: ballUp(p, size), forward: ballForward(p, size), clear: size / 2 } };
            case "GIANT_BALL":
                // setupKiGenkiPlayer 5.5 over the middle, setupKiNovaPlayer / setupKiNovaCoolerPlayer 2.5, any other giant ball
                // setupKiLargeBlastPlayer (render type 2: overhead, pulled back by its own radius)
                if (id === "spiritbomb") return { def: "dmz_ki_giant", k: "ball", rt: 5, ct: 100, origin: { base: "center", up: 5.5, forward: 0, clear: size / 2 } };
                if (id === "supernova" || id === "supernova_cooler") return { def: "dmz_ki_giant", k: "ball", rt: 6, ct: 100, origin: { base: "center", up: 2.5, forward: 0, clear: size / 2 } };
                return { def: "dmz_ki_giant", k: "ball", rt: 2, ct: 100, origin: { base: "center", up: overheadUp(p, size), forward: -(size / 2) / Math.max(1, Math.min(MAX_OWNER_SCALE, (Number(p.width) || 0.6) / 0.6)), clear: size / 2 } };
            case "WAVE": {
                // getCastSize: the stored cast size x the caster's height scale (the orb and its clearance grow with a giant)
                var wc = waveCast(id, size);
                wc.cs *= hs;
                return { def: "dmz_ki_wave", k: "wave", rt: wc.rt, ct: wc.ct, cs: wc.cs, wc: wc, origin: waveOffsets(id, wc, 0) };
            }
            case "BEAM":
                return { def: "dmz_ki_beam", k: "beam", rt: 1, ct: 0, origin: { base: "center", side: -0.2, up: 0.7, forward: 0.5, clear: size / 2, viewUp: 1 } };
            case "DISK":
                if (id === "kill_driver") return null;
                return { def: "dmz_ki_disk", k: "disk", rt: 0, ct: 40, origin: { base: "eye", side: id === "kienzan_doble" ? 0.8 : 0.4, up: 0.7, forward: 0.2, clear: size / 2, viewUp: 1 } };
            case "BARRAGE":
                // setupKiVolleyPlayer: (0, 0, 0.7); the twin orbs are drawn round the box's middle, 0.4 x size above it
                if (id === "ki_barrage") return { def: "dmz_ki_ball", k: "volley", rt: 9, ct: 8, origin: { base: "center", up: 0, forward: 0.7, clear: size / 2 } };
                // KiBlastEntity.setupAssaultRainPlayer: an orb of 0.7 + 0.4 x size over the left shoulder, grown over the cast
                if (id === "assault_rain") return { def: "dmz_ki_ball", k: "ball", rt: 12, ct: T.cast || 40, sz: 0.7 + size * 0.4, origin: { base: "center", side: -0.4, up: 1.3, forward: 0, clear: 0 } };
                // setupBlasterMeteor: a sphere round the caster's middle (1.7 x their height)
                if (id === "blaster_meteor") return { def: "dmz_ki_ball", k: "ball", rt: 13, ct: T.cast || 40, sz: -1, origin: { base: "center", up: 0, forward: 0, clear: 0 } };
                // HellzoneGrenadeEntity.formHandOrbs: an orb in each hand, from 0.2 x to full size over 8 ticks
                // Orb.chargeHand: 0.42 of the height up, half the width + 0.35 out, 0.05 back, on the BODY's heading
                if (id === "hellzone_grenade") {
                    var hzH = Number(p.height) || 1.8, hzSide = (Number(p.width) || 0.6) * 0.5 + 0.35 * hs, hzUp = hzH * 0.42 - hzH / 2 - BB * size / 2;
                    return { def: "dmz_ki_ball", k: "ball", rt: 0, ct: 8, hz: 1,
                        origin: { base: "center", frame: "body", side: hzSide, up: hzUp, forward: -0.05 * hs, clear: 0, boxScale: 0 },
                        origin2: { base: "center", frame: "body", side: -hzSide, up: hzUp, forward: -0.05 * hs, clear: 0, boxScale: 0 } };
                }
                return null;
        }
        return null;
    }
    function tagOf(s, extra) {
        var o = { k: s.spec.k, rt: s.spec.rt, ct: s.spec.ct, sz: s.spec.sz > 0 ? s.spec.sz : s.size, tech: s.id };
        if (s.spec.cs !== undefined) o.cs = s.spec.cs;
        if (extra) for (var k in extra) o[k] = extra[k];
        return o;
    }
    function startCharge(p, id, slot) {
        var T = TD.KI[id], K = TD.TYPES[T.type];
        if (cdLeft(p, id) > 0) return;
        if (K.restrict && p.vehicle) { p.actionbar("&cYou can't charge that while riding. Get out first."); return; }
        if (FIRING[p.uuid] && FIRING[p.uuid].lock) return;            // still firing a restricted attack (isActionRestrictedKiAttack)
        var lock = lockedTarget(p);
        if (id === "hellzone_grenade" && !(lock || p.target(48))) { msg(p, "message.dragonminez.hellzone_grenade.no_target"); return; }
        var size = TD.castSize(id, view(p).stat("PWR"), transformed(p));
        var s = { p: p, id: id, slot: slot, pct: 0, holding: slot >= 0, accum: 0, lock: lock, size: size, base: TD.kiCost(id, kiNoForms(p)),
            proj: null, proj2: null, ticks: 0, out: false, spec: null };
        var spec = chargeSpec(p, id, T, size);
        if (spec && spec.sz === -1) { spec.sz = DMZ_VOLLEY.meteorSize(p); spec.origin.up = -BB * spec.sz / 2 / hScale(p); }   // the sphere's centre on the caster's middle
        if (id === "hellzone_grenade") s.hzTarget = lock || p.target(48);
        if (id === "kill_driver") { DMZ_VOLLEY.killDriverCharge(p, s, T, size); spec = null; }
        if (spec && K.cast > 0) {
            // the attack exists from the first tick of the charge, in the caster's hands, for everyone to see
            s.spec = spec;
            var engineSize = spec.k === "wave" ? spec.cs * 1.5 : spec.sz > 0 ? spec.sz : size;
            s.proj = p.shoot(spec.def, { hold: true, size: engineSize, damage: 0, colors: T.colors, origin: spec.origin });
            if (s.proj) {
                s.proj.setVar("tech", id); s.proj.setVar("colors", T.colors);
                if (spec.k === "disk") s.proj.setVar("dmg", kiDamage(p) * T.dmg * 0.1 * dmgMod(p));
                DMZ_TECH_PROJ.look(s.proj, tagOf(s));
            }
            if (id === "kienzan_doble" || spec.origin2) {
                var o2 = spec.origin2 || { base: "eye", side: -0.8, up: 0.7, forward: 0.2, clear: size / 2, viewUp: 1, boxScale: MAX_OWNER_SCALE };
                s.proj2 = p.shoot(spec.def, { hold: true, size: size, damage: 0, colors: T.colors, origin: o2 });
                if (s.proj2) { s.proj2.setVar("tech", id); s.proj2.setVar("colors", T.colors); s.proj2.setVar("dmg", s.proj.getVar("dmg", 0)); DMZ_TECH_PROJ.look(s.proj2, tagOf(s)); }
            }
        } else if (T.type === "EXPLOSION") {
            exploStart(p, s, T);
        } else if (K.cast > 0 && id !== "kill_driver" && T.type !== "BARRAGE" && id !== "kikoho") {
            // assault rain, blaster meteor, hellzone grenade: a small orb in the hands while charging
            s.proj = p.shoot("dmz_tech_ball", { hold: true, size: 0.15, damage: 0, colors: T.colors,
                chargeGrow: { from: 0.15, to: 0.6, ticks: K.cast } });
        }
        var ca = TD.castAnim(id);
        if (ca && K.cast > 0) act(p, ca, 600);
        chargeSounds(p, id, T);
        if (K.restrict) p.addEffect("dmz_tech_rooted", -1);
        SESS[p.uuid] = s;
    }
    // the sounds the original's charging entities make when they appear: KiWaveEntity (its constructor's quiet fire sound,
    // then on its first tick the Final Flash charge or the explosion charge, plus the Kamehameha charge), KiBlastEntity
    // (only the Spirit Bomb and the Supernovas; the Burning Attack's charge comes from TechniqueDispatcher at 4.0; other
    // medium balls and the Tri-Beam are silent), KiLaserEntity (the beam charge), KiDiskEntity (the disk charge at 1.2)
    // and playInitialSound (the volleys: the explosion charge at 0.8-1.0)
    function chargeSounds(p, id, T) {
        if (id === "assault_rain" || id === "blaster_meteor" || id === "hellzone_grenade" || id === "ki_barrage") { sfx(p, "ki_explosion_charge", 0.7, 0.8 + Math.random() * 0.2); return; }
        switch (T.type) {
            case "WAVE":
                sfx(p, "ki_kame_fire", 0.1, 0.8 + Math.random() * 0.2);
                sfx(p, id === "final_flash" ? "ki_finalflash_charge" : "ki_explosion_charge", 0.7, 1.0);
                if (id === "kamehameha") sfx(p, "ki_kame_charge", 0.7, 1.0);
                return;
            case "MEDIUM_BALL": if (id === "burning_attack") sfx(p, T.chargeSound, 4.0, 1.0); return;
            case "GIANT_BALL": sfx(p, T.chargeSound, 0.7, 1.0); return;
            case "BEAM": sfx(p, T.chargeSound, 0.7, 1.0); return;
            case "DISK": if (id !== "kill_driver") sfx(p, T.chargeSound, 0.7, 1.2); return;
            case "LASER": return;
            default: if (id !== "kill_driver" && id !== "kikoho") sfx(p, T.chargeSound, 0.7, 1.0);
        }
    }
    function cancel(p) {
        var s = SESS[p.uuid];
        delete SESS[p.uuid];
        if (s) {
            if (s.proj && s.proj.alive) s.proj.discard();
            if (s.proj2 && s.proj2.alive) s.proj2.discard();
            stopAct(p);
            RPG.net.send(p, "dmz_tech_charge", { pct: 0, id: "", c: false });
        }
        p.removeEffect("dmz_tech_rooted");
        var f = FIRING[p.uuid];
        if (f) { delete FIRING[p.uuid]; if (f.cam) RPG.net.send(p, "dmz_tech_firelock", { on: false }); if (f.onEnd) f.onEnd(); }
        if (s && s.explo) exploEnd(p);
        if (s && (s.id === "assault_rain" || s.id === "blaster_meteor")) DMZ_VOLLEY.land(p);
    }
    function isCharging(p) { return !!SESS[p.uuid]; }

    // ---------------------------------------------------------------------------------
    //  Final Explosion (KiExplosionEntity): the sphere forms round the caster from the first tick of the charge
    //  (2 blocks), lifting them 1.5 blocks over the first 20 ticks and holding them there; fired, it swells 0.4 a
    //  tick to its radius (at least 10) and stays out for the attack's life, hitting everything within 1.4 x the
    //  radius every 20 ticks. Drawn on every client by client/scripts/51_dmz_ki_render.js ("dmz_kiexpl").
    // ---------------------------------------------------------------------------------
    function exploSend(p, msg) {
        msg.e = p.entityId;
        RPG.server.players().forEach(function (pl) {
            try { if (pl.dimension === p.dimension && Math.abs(pl.x - p.x) < 160 && Math.abs(pl.z - p.z) < 160) RPG.net.send(pl, "dmz_kiexpl", msg); } catch (e) { }
        });
    }
    function exploStart(p, s, T) {
        s.explo = { x: p.x, y: p.y, z: p.z };
        try { p.setNoGravity(true); p.setVelocity(0, 0, 0); } catch (e) { }
        p.setVar("dmz_explo_ng", 1);
        exploSend(p, { s: "c", r: s.size, c: [T.colors.core, T.colors.border, T.colors.outline] });
    }
    function exploEnd(p) {
        try { p.setNoGravity(false); } catch (e) { }
        p.setVar("dmz_explo_ng", 0);
        exploSend(p, { s: "x" });
    }

    function tickCharge(s) {
        var p = s.p;
        if (!p.isAlive() || p.hasEffect("stunned")) { cancel(p); return; }
        var T = TD.KI[s.id], K = TD.TYPES[T.type], instant = K.cast === 0;
        var ceil = (s.holding && !instant) ? TD.OVERCHARGE_MAX : 100, bt = Math.max(1, K.cast);
        s.ticks++;
        // Final Explosion: the caster rises with the sphere, 1.5 blocks over the first half of its 40-tick cast
        if (s.id === "blaster_meteor") s.risen = DMZ_VOLLEY.meteorRise(p, s.risen || 0);   // tickBlasterMeteor while casting
        else if (s.id === "assault_rain") DMZ_VOLLEY.hover(p);                          // tickAssaultRain zeroes the caster's motion
        else if (s.id === "kill_driver") DMZ_VOLLEY.killDriverTick(p, s);
        if (s.explo && s.ticks <= 20) { try { p.teleport(s.explo.x, s.explo.y + 0.075 * s.ticks, s.explo.z); p.setVelocity(0, 0, 0); } catch (e) { } }
        // the wave's orb follows the pose (KiWaveEntity.tick offsets)
        if (s.spec && s.spec.k === "wave" && s.proj && s.proj.alive && (s.ticks === 6 || s.ticks === 15)) {
            var wo = waveOffsets(s.id, s.spec.wc, s.ticks);
            s.proj.set("origin.side", wo.side); s.proj.set("origin.up", wo.up); s.proj.set("origin.forward", wo.forward);
        }
        if (s.pct < ceil - 0.001) {
            var rate = (s.pct < 100 ? 100 : 25) / bt;
            var np = Math.min(ceil, s.pct + rate);
            var cost = creative(p) ? 0 : 0.5 * s.base * (TD.costMultiplier(np) - TD.costMultiplier(s.pct)) * costMod(p);
            // paid as whole points, the fraction carried over (original accumulates the fractional cost too)
            var ki = p.resource("ki"), owed = s.accum + cost, whole = Math.floor(owed);
            if (ki >= whole) { if (whole > 0) p.addResource("ki", -whole); s.accum = owed - whole; s.pct = np; }
            else { s.pct += (np - s.pct) * (whole > 0 ? ki / whole : 1); p.setResource("ki", 0); s.out = true; }
        }
        if (s.ticks % 2 === 0 && !instant) RPG.net.send(p, "dmz_tech_charge", { pct: Math.round(s.pct * 10) / 10, id: s.id, c: s.holding });
        var fire = K.full ? (s.pct >= ceil - 0.01 || s.out) : (!s.holding || s.out);
        if (fire) releaseCharge(s);
    }

    function releaseCharge(s) {
        var p = s.p, T = TD.KI[s.id], K = TD.TYPES[T.type], instant = K.cast === 0;
        delete SESS[p.uuid];
        RPG.net.send(p, "dmz_tech_charge", { pct: 0, id: "", c: false });
        var eff = Math.min(s.pct, TD.OVERCHARGE_MAX), ch = eff / 100;
        if (!instant && eff < 10) {                                 // fizzles: the charge ki is lost, no cooldown
            if (s.id === "assault_rain" || s.id === "blaster_meteor") DMZ_VOLLEY.land(p);
            if (s.explo) exploEnd(p);
            if (s.proj && s.proj.alive) s.proj.discard();
            if (s.proj2 && s.proj2.alive) s.proj2.discard();
            p.removeEffect("dmz_tech_rooted");
            stopAct(p);
            return;
        }
        var r = rec(p, s.id) || {};
        var c = TD.clamp(ch, 0.1, 2);
        var dmg = kiDamage(p) * T.dmg * c * dmgMod(p);
        var life = Math.max(20, Math.floor(K.life * c));
        s.fired = [];
        var ok = execute(p, s, dmg, life, ch);
        if (ok === false) { p.removeEffect("dmz_tech_rooted"); stopAct(p); return; }
        setCd(p, s.id, creative(p) ? 60 : TD.kiCooldown(s.id, ch, r.c));
        if (!creative(p)) {
            var fireFrac = K.restrict ? 0.25 : 0.5;
            var pay = Math.round(fireFrac * s.base * TD.costMultiplier(eff) * costMod(p));
            p.addResource("ki", -Math.min(pay, p.resource("ki")));
        }
        // Original holds the caster (TechniqueDispatcher.isMovementRestrictedKiAttack) only while a restricted attack of
        // theirs is still out within 32 blocks: a wave or beam while it is being emitted, a giant ball until it has
        // flown off; the camera is held too unless the attack steers (Mouth Blast). Other shots hold you only for
        // the instant they leave the hands (3 blocks). The ki drain runs for the attack's life.
        var drain = K.restrict && !creative(p) ? 0.25 * s.base * TD.costMultiplier(eff) * costMod(p) / life : 0;
        var f = FIRING[p.uuid];
        if (!f || !f.emitter) f = FIRING[p.uuid] = { p: p };
        f.projs = s.fired.filter(function (x) { return !!x; });
        f.restrict = !!K.restrict;
        if (!f.keepUntil) f.until = RPG.server.getTick() + life;
        f.drain = drain;
        f.lock = true;
        f.anim = T.anim + "_fire";
        f.cam = K.restrict && s.id !== "mouth_blast";
        if (f.cam) RPG.net.send(p, "dmz_tech_firelock", { on: true });
        if (!K.restrict) p.removeEffect("dmz_tech_rooted");
        else if (!f.projs.length && !f.emitter) { f.lock = false; p.removeEffect("dmz_tech_rooted"); }
        if (T.type !== "GIANT_BALL" && T.type !== "MEDIUM_BALL" && T.type !== "WAVE" && T.type !== "LASER" && (T.type !== "BARRAGE" || s.id === "ki_barrage"))
            sfx(p, T.fireSound, s.id === "kill_driver" ? 2.5 : 0.7, s.id === "kill_driver" ? 0.8 : T.type === "DISK" ? 1.5 : 1.0);
        var fireAnim = T.anim + "_fire";
        act(p, fireAnim, K.restrict ? life : (s.id === "emperor_death_beam" ? 14 : s.id === "dodonpa" ? 12 : 12));
        sendState(p);
    }

    function aimAt(proj, from, to) {
        var dx = to.x - from.x, dy = (to.y + 1) - from.y, dz = to.z - from.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
        proj.setDirection(dx / l, dy / l, dz / l);
        return { x: dx / l, y: dy / l, z: dz / l };
    }
    // KiBlastEntity.fireHability: the ball flies from its centre to whatever the crosshair is on (100 blocks)
    function aimCrosshair(p, proj, centerY) {
        var hit = null;
        try { hit = p.raycast(100, { blocks: true, entities: true }); } catch (e) { }
        var end = hit && hit.hit !== "none" && hit.x !== undefined ? { x: hit.x, y: hit.y, z: hit.z } : lookPoint(p, 100);
        // the point where the eye ray meets what it hit (an entity's x/y/z are its feet: aiming there sent balls into the ground)
        if (hit && hit.hit === "entity" && hit.entity) {           // KiBlastEntity.fireHability: the box grown by 0.3, clipped by the eye ray
            var e = hit.entity, lk = lookDir(p), hw = (Number(e.width) || 0.6) / 2 + 0.3, o = [p.x, p.eyeY, p.z], dd = [lk.x, lk.y, lk.z];
            var lo = [e.x - hw, e.y - 0.3, e.z - hw], hi = [e.x + hw, e.y + (Number(e.height) || 1.8) + 0.3, e.z + hw], t0 = 0, t1 = 100;
            for (var ax = 0; ax < 3; ax++) {
                if (Math.abs(dd[ax]) < 1e-9) continue;
                var u = (lo[ax] - o[ax]) / dd[ax], v = (hi[ax] - o[ax]) / dd[ax];
                if (u > v) { var sw = u; u = v; v = sw; }
                t0 = Math.max(t0, u); t1 = Math.min(t1, v);
            }
            if (t0 <= t1) end = { x: o[0] + dd[0] * t0, y: o[1] + dd[1] * t0, z: o[2] + dd[2] * t0 };
            else end = { x: e.x, y: e.y + (Number(e.height) || 1.8) / 2, z: e.z };
        }
        if (!hit || hit.hit === "none") { var lp = lookPoint(p, 100); end = { x: lp.x, y: p.eyeY + (lp.y - p.y - 1.6), z: lp.z }; }
        var dx = end.x - proj.x, dy = end.y - centerY, dz = end.z - proj.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
        proj.setDirection(dx / l, dy / l, dz / l);
    }
    function homing(T, s, proj) {
        if (s.lock && TD.TYPES[T.type].home && proj && s.lock.isAlive()) proj.homeAt(s.lock, 0.2, 120);
    }
    function spread(dir, deg) {
        var a = deg * Math.PI / 180;
        var x = dir.x + (Math.random() * 2 - 1) * a, y = dir.y + (Math.random() * 2 - 1) * a, z = dir.z + (Math.random() * 2 - 1) * a;
        var l = Math.sqrt(x * x + y * y + z * z) || 1;
        return { x: x / l, y: y / l, z: z / l };
    }
    function lookDir(p) {
        var yaw = p.yaw * Math.PI / 180, pitch = p.pitch * Math.PI / 180;
        return { x: -Math.sin(yaw) * Math.cos(pitch), y: -Math.sin(pitch), z: Math.cos(yaw) * Math.cos(pitch) };
    }
    function arm(proj, s, T, dmg, life) {
        proj.setVar("dmg", dmg); proj.setVar("tech", s.id); proj.setVar("life", life); proj.setVar("colors", T.colors);
    }

    // TechniqueDispatcher.executeKiAttack + the per-technique handlers (KiTechniqueHandler)
    function execute(p, s, dmg, life, ch) {
        var T = TD.KI[s.id], speed = T.speed, size = s.size;
        var proj = s.proj && s.proj.alive ? s.proj : null;
        switch (T.type) {
            case "MEDIUM_BALL":
            case "GIANT_BALL": {
                if (!proj || !s.spec) return false;
                var giant = T.type === "GIANT_BALL";
                arm(proj, s, T, dmg, life);
                if (giant) proj.setVar("giant", 1);
                if (s.id === "soul_punisher") proj.setVar("soul", 1);
                if (s.id === "neo_kikoho") { proj.discard(); return triBeam(p, s, T, dmg, life, true); }
                DMZ_TECH_PROJ.look(proj, tagOf(s, { f: 1 }));
                if (s.id === "fake_moon") {
                    // no damage: climbs 30 blocks at 1 block a tick, then hangs there glowing for 20 s (Oozaru trigger not ported)
                    proj.setVar("noHit", 1);
                    proj.fire({ speed: 1, lifetime: 30 + 400, size: size, throughBlocks: 1 });
                    proj.setDirection(0, 1, 0);
                    RPG.schedule(30, function () { if (proj.alive) proj.setVelocity(0, 0, 0); });
                    s.fired.push(proj);
                    return true;
                }
                proj.fire({ speed: speed, lifetime: life, size: size });
                aimCrosshair(p, proj, proj.y + size / 2);
                sfx(proj, s.id === "burning_attack" ? "ki_burning_fire" : s.id === "spiritbomb" ? "ki_spiritbomb_fire"
                    : (s.id === "supernova" || s.id === "supernova_cooler") ? "ki_supernova_fire" : "kiblast_shoot", 0.7, 1.0);
                if (!giant) homing(T, s, proj);
                s.fired.push(proj);
                if (typeof dbrSpaceKiFired === "function") dbrSpaceKiFired(p, proj, dmg, T);   // planet buster (87_dbr_space_buster.js)
                return true;
            }
            case "WAVE": {
                if (!proj || !s.spec) return false;
                var wc = s.spec.wc;
                if (typeof dbrSpaceKiFired === "function") dbrSpaceKiFired(p, proj, dmg, T);   // only says why a beam can't break a planet
                arm(proj, s, T, dmg, life);
                proj.setVar("sz", size);
                DMZ_TECH_PROJ.look(proj, tagOf(s, { f: 1 }));
                // fired: the wave leaves (bbWidth / 2 + 2.2) + its radius ahead of the body centre and stays there
                var fo = wc.mouth ? { base: "eye", side: 0, up: -0.25, forward: 0.3, clear: size, viewUp: 1 }
                    : wc.dome ? { base: "center", side: 0, up: 0.9 + 0.3, forward: 0, clear: 0, viewUp: 0 }
                    : { base: "center", side: 0, up: 0, forward: 2.5, clear: size, viewUp: 0 };
                var over = { speed: speed, duration: life, size: size * 1.5, origin: fo };
                if (wc.mouth) { over.stayAtFire = 0; over.steerRate = 2.5; }
                if (s.id === "heat_dome") {
                    // the closest target in front (8 blocks) is launched, then the dome fires upward
                    var best = null, bd = 99, lk = lookDir(p);
                    p.nearby(8).forEach(function (e) {
                        if (p.isAlly(e)) return;
                        var dx = e.x - p.x, dz = e.z - p.z, l = Math.sqrt(dx * dx + dz * dz) || 1;
                        var fl = Math.sqrt(lk.x * lk.x + lk.z * lk.z) || 1;
                        if ((dx / l) * (lk.x / fl) + (dz / l) * (lk.z / fl) < 0.3) return;
                        var d = p.distanceTo(e);
                        if (d < bd) { bd = d; best = e; }
                    });
                    if (best) best.setVelocity((p.x - best.x) * 0.09, 1.6, (p.z - best.z) * 0.09);
                }
                proj.fire(over);
                if (s.id === "heat_dome") proj.setDirection(0, 1, 0);
                s.fired.push(proj);
                if (typeof DBR_BEAM_CLASH !== "undefined") DBR_BEAM_CLASH.track(proj, { size: size, power: dmg, color: T.colors.border });   // beam clashes
                return true;
            }
            case "BEAM": {
                if (!proj || !s.spec) return false;
                arm(proj, s, T, dmg, life);
                proj.setVar("sz", size);
                DMZ_TECH_PROJ.look(proj, tagOf(s, { f: 1 }));
                proj.fire({ speed: speed, duration: life, size: Math.max(0.5, size / 3),
                    origin: { base: "center", side: 0.1, up: 0.5, forward: 0.6, clear: 0, viewUp: 1 } });
                s.fired.push(proj);
                if (typeof DBR_BEAM_CLASH !== "undefined") DBR_BEAM_CLASH.track(proj, { size: size, power: dmg, color: T.colors.border });   // beam clashes
                return true;
            }
            case "LASER": {
                if (s.id === "kikoho") return triBeam(p, s, T, dmg, life, false);
                if (proj) proj.discard();
                var lsz = s.id === "emperor_death_beam" ? size * 1.75 : size;
                var fireLaser = function (amount, chain) {
                    var lp = p.shoot("dmz_ki_laser", { size: Math.max(0.5, lsz / 3), colors: T.colors, damage: 0,
                        speed: chain ? Math.max(speed * 3, 8) : speed, duration: chain ? 10 : life,
                        origin: { base: "center", side: 0.1, up: 0.5, forward: 0.6, clear: 0, viewUp: 1 } });
                    if (!lp) return null;
                    lp.setVar("dmg", amount); lp.setVar("tech", s.id); lp.setVar("life", chain ? 10 : life); lp.setVar("sz", lsz); lp.setVar("colors", T.colors);
                    DMZ_TECH_PROJ.look(lp, { k: "laser", rt: 0, sz: lsz, tech: s.id, f: 1 });
                    sfx(lp, "laserbeam", 0.7, 1.0 + Math.random() * 0.2);
                    return lp;
                };
                if (s.id === "dodonpa") { RPG.schedule(2, function () { if (p.isAlive()) fireLaser(dmg, false); }); return true; }
                fireLaser(dmg, false);
                if (s.id === "emperor_death_beam") {
                    // chain: 10 shots in all, one every 7 ticks; follow-ups deal 20 %
                    times(9, function (i) {
                        RPG.schedule(7 * (i + 1), function () {
                            if (!p.isAlive()) return;
                            fireLaser(dmg * 0.2, true);
                            act(p, "ki.emperor_laser_fire", 8);
                        });
                    });
                }
                return true;
            }
            case "DISK": {
                if (s.id === "kill_driver") return DMZ_VOLLEY.killDriverFire(p, s, T, dmg, life);
                if (!proj || !s.spec) return false;
                var disks = [proj];
                if (s.proj2 && s.proj2.alive) disks.push(s.proj2);
                var lk2 = lookDir(p);
                disks.forEach(function (d, i) {
                    arm(d, s, T, dmg, life);
                    DMZ_TECH_PROJ.look(d, tagOf(s, { f: 1 }));
                    // KiDiskEntity.fireHability: from in front of the eyes, straight along the look (the right one of a pair 1.5x faster)
                    var sp = s.id === "kienzan_doble" && i === 0 ? speed * 1.5 : speed;
                    d.fire({ speed: sp, lifetime: life, size: size });
                    d.moveTo(p.x + lk2.x * 0.5, p.eyeY + lk2.y * 0.5 - 0.2, p.z + lk2.z * 0.5);
                    d.setDirection(lk2.x, lk2.y, lk2.z);
                    homing(T, s, d);
                });
                return true;
            }
            case "BARRAGE": {
                if (proj && s.id !== "ki_barrage" && s.id !== "assault_rain" && s.id !== "blaster_meteor" && s.id !== "hellzone_grenade") proj.discard();
                return barrage(p, s, T, dmg, life, ch);
            }
            case "EXPLOSION": {
                if (proj) proj.discard();
                // life sacrifice: HP drops to 5 %, damage x (1 + f x 1.8), radius x (1 + f x 0.8) (applyFinalExplosionSacrifice)
                var maxHp = p.maxHealth, f = TD.clamp((p.health - maxHp * 0.05) / maxHp, 0, 1);
                if (f > 0) p.setHealth(Math.max(1, maxHp * 0.05));
                var radius = Math.min(32, s.size * (1 + f * 0.8));
                var total = dmg * (1 + f * 1.8), hits = Math.max(1, Math.floor(life / 20));
                var ex = s.explo || { x: p.x, y: p.y, z: p.z }, cy = (s.explo ? ex.y + 0.075 * Math.min(20, s.ticks) : p.y) + (Number(p.height) || 1.8) / 2;
                if (!s.explo) { s.explo = ex; try { p.setNoGravity(true); } catch (e0) { } p.setVar("dmz_explo_ng", 1); }
                exploSend(p, { s: "f", r: radius, life: life, c: [T.colors.core, T.colors.border, T.colors.outline] });
                sfx(p, "ki_explosion_impact", 0.7, 1.2);
                if (typeof DBR_DESTRUCTION !== "undefined") DBR_DESTRUCTION.blast(p, ex.x, cy, ex.z, radius * 1.2, true);   // createCrater
                var tag = "dmzki:" + s.id;
                FIRING[p.uuid] = { until: RPG.server.getTick() + life, drain: 0, p: p, emitAnim: T.anim + "_fire",
                    onEnd: function () { exploEnd(p); },
                    emitter: function (age) {
                        try { p.setVelocity(0, 0, 0); } catch (e1) { }
                        if (age % 70 === 0) sfx(p, "ki_explosion_impact", 0.2, 1.2);
                        if (age % 20 !== 0) return;
                        // pulseDamage: everything in a box 1.4 x the radius round the centre, 2 x the per-hit share, pushed away
                        var R = radius * 1.4, n = 0;
                        RPG.world.entitiesNear(p.dimension, ex.x, cy, ex.z, R * 1.75).forEach(function (e) {
                            try {
                                if (e.uuid === p.uuid || !e.isAlive() || p.isAlly(e)) return;
                                if (Math.abs(e.x - ex.x) > R || Math.abs(e.y + e.height / 2 - cy) > R || Math.abs(e.z - ex.z) > R) return;
                                if (e.damageFrom(total / hits * 2, p, { kind: "ki", tag: tag, ignoreIFrames: false }) === false) return;
                                n++;
                                var dx = e.x - ex.x, dz = e.z - ex.z, l = Math.sqrt(dx * dx + dz * dz) || 1;
                                e.push(dx / l * 0.2, 0.1, dz / l * 0.2);
                            } catch (e2) { }
                        });
                        if (n > 0 && typeof DMZ_IMPACT !== "undefined") DMZ_IMPACT.kiHit(p);   // EXPLOSION hit: impact frame
                    } };
                return true;
            }
        }
        return false;
    }

    // The Tri-Beam (KiBlastEntity render type 14): fired, the shot grows into a triangle 4.8 x its size, 0.6 deep, moved
    // ahead by half its depth + 0.5, and flies like a ki ball to the crosshair (pulses, blows up on what it meets, radius
    // 2.5). The Neo Tri-Beam's charged triangle passes through terrain eating it (0.6 x its size every 2 ticks).
    function triBeam(p, s, T, dmg, life, neo) {
        var tri = s.size * 4.8, depthAhead = tri * 0.6 * 0.5 + 0.5;
        var lp = p.shoot(neo ? "dmz_ki_neo" : "dmz_ki_tri", { hold: true, size: tri, damage: 0, colors: T.colors,
            origin: { base: "center", up: -BB * s.size / 2 + s.size / 2 - tri / 2, forward: 0.6 + depthAhead, clear: 0 } });
        if (!lp) return false;
        arm(lp, s, T, dmg, life);
        DMZ_TECH_PROJ.look(lp, { k: "ball", rt: 14, sz: tri, tech: s.id, f: 1 });
        lp.fire({ speed: T.speed, lifetime: life, size: tri });
        aimCrosshair(p, lp, lp.y + tri / 2);
        sfx(lp, "kiblast_shoot", 0.7, 1.0);
        if (s.lock && s.lock.isAlive()) lp.homeAt(s.lock, 0.2, 120);   // setHomingTarget
        s.fired.push(lp);
        if (neo) neoFired(p, s, T, dmg, life);
        return true;
    }
    // KiTechniqueHandler.TriBeam follow-ups: after a Neo Tri-Beam, 60 ticks to right click another (no charge, 8 ticks apart at
    // least), each paid with 10 % of your max health (silently, never below 1; only while you have 20 % or more; free in
    // creative), three at most in a row; each opens the window again ("message.dragonminez.tri_beam.follow_up")
    var NEO = {}, NEO_WINDOW = 60, NEO_GAP = 8, NEO_COST = 0.10, NEO_MIN_RATIO = 0.20, NEO_MAX = 3;
    function neoAfford(p) { return creative(p) || p.health >= p.maxHealth * NEO_MIN_RATIO; }
    function neoFired(p, s, T, dmg, life) {
        var now = RPG.server.getTick(), prev = NEO[p.uuid], shots = prev && now <= prev.until ? prev.shots + 1 : 0;
        if (shots < NEO_MAX && neoAfford(p)) {
            NEO[p.uuid] = { s: { id: s.id, size: s.size, lock: s.lock, fired: [] }, T: T, dmg: dmg, life: life, until: now + NEO_WINDOW, next: now + NEO_GAP, shots: shots };
            RPG.net.send(p, "dmz_tribeam_window", { t: NEO_WINDOW });
        } else neoClose(p);
    }
    function neoClose(p) { if (NEO[p.uuid]) delete NEO[p.uuid]; try { RPG.net.send(p, "dmz_tribeam_window", { t: 0 }); } catch (e) { } }
    RPG.net.on("dmz_tribeam_follow", function (p) {
        var f = NEO[p.uuid], now = RPG.server.getTick();
        if (!f) return;
        if (now > f.until || !p.isAlive()) { neoClose(p); return; }
        if (now < f.next) return;
        if (!neoAfford(p)) { neoClose(p); return; }
        if (!creative(p)) p.setHealth(Math.max(1, p.health - p.maxHealth * NEO_COST));   // SilentDamage.apply(cost, 1)
        f.s.lock = f.s.lock && f.s.lock.isAlive() ? f.s.lock : null;
        triBeam(p, f.s, f.T, f.dmg, f.life, true);
    });
    RPG.every(20, function () { var now = RPG.server.getTick(); for (var u in NEO) if (now > NEO[u].until) delete NEO[u]; });

    // BARRAGE techniques: ki barrage emitter, assault rain, blaster meteor, hellzone grenade
    function barrage(p, s, T, dmg, life, ch) {
        var target = s.lock || p.target(s.id === "hellzone_grenade" ? 48 : 40);
        if (s.id === "ki_barrage") {
            // KiBlastEntity render type 9: the twin orbs stay in the hands; every 2 ticks 5 small blasts (setupKiSmall:
            // size 0.8, full damage each, 6 degrees of spread) fly where the caster aims, while it lasts
            var emitterOrb = s.proj && s.proj.alive ? s.proj : null;
            if (emitterOrb) DMZ_TECH_PROJ.look(emitterOrb, tagOf(s, { f: 1 }));
            FIRING[p.uuid] = { until: RPG.server.getTick() + life, drain: 0, p: p, volley: emitterOrb,
                emitter: function (age) {
                    if (age % 2 !== 0) return;
                    var dir = lookDir(p);
                    times(5, function () {
                        var b = p.shoot("dmz_ki_ball", { size: 0.8, damage: 0, colors: T.colors, lifetime: 100, speed: T.speed,
                            origin: { base: "center", up: -0.5, forward: 0.5, clear: 0.4 } });
                        if (!b) return;
                        b.setVar("dmg", dmg); b.setVar("tech", s.id); b.setVar("life", 100); b.setVar("colors", T.colors);
                        DMZ_TECH_PROJ.look(b, { k: "small", rt: 0, sz: 0.8, tech: s.id, f: 1 });
                        var g = function () { var u = 0, v = 0; while (u === 0) u = Math.random(); v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
                        var d = { x: dir.x + g() * 0.0075 * 6, y: dir.y + g() * 0.0075 * 6, z: dir.z + g() * 0.0075 * 6 };
                        var l = Math.sqrt(d.x * d.x + d.y * d.y + d.z * d.z) || 1;
                        b.setDirection(d.x / l, d.y / l, d.z / l);
                        b.setVelocity(d.x / l * T.speed, d.y / l * T.speed, d.z / l * T.speed);
                    });
                    sfx(p, "kiblast_shoot", 0.1, 1.6 + Math.random() * 0.5);
                } };
            return true;
        }
        // the volleys: light simulations, not one entity a shot (41v_dmz_volleys.js)
        var vol = null, lock = s.lock && s.lock.isAlive() ? s.lock : lockedTarget(p);
        if (s.id === "assault_rain") vol = DMZ_VOLLEY.assaultRain(p, s.proj && s.proj.alive ? s.proj : null, T, dmg, life, lock);
        else if (s.id === "blaster_meteor") vol = DMZ_VOLLEY.blasterMeteor(p, s.proj && s.proj.alive ? s.proj : null, T, dmg, life, lock);
        else if (s.id === "hellzone_grenade") {
            // HellzoneGrenadeEntity.fireHability: the lock or what the crosshair is on (48), else the charge's own target
            var ht = lock || p.target(48);
            if (!ht || !ht.isAlive() || p.isAlly(ht)) ht = s.hzTarget && s.hzTarget.isAlive() && p.distanceTo(s.hzTarget) <= 48 ? s.hzTarget : null;
            if (!ht) { msg(p, "message.dragonminez.hellzone_grenade.no_target"); [s.proj, s.proj2].forEach(function (x) { if (x && x.alive) x.discard(); }); return false; }
            DMZ_VOLLEY.hellzone(p, s, T, dmg, ch, ht);
            vol = { until: RPG.server.getTick() + 95, emitter: function () { } };
        }
        if (vol) {
            FIRING[p.uuid] = { until: vol.until, drain: 0, p: p, volley: vol.volley || null, emitter: vol.emitter, keepUntil: true, emitAnim: T.anim + "_fire",
                onEnd: function () { DMZ_VOLLEY.land(p); } };
            return true;
        }
        return false;
    }

    // ---------------------------------------------------------------------------------
    //  strikes (StrikeAttackHandler)
    // ---------------------------------------------------------------------------------
    var PUNCH = ["punch1", "punch2", "punch3", "punch4", "punch5", "punch6"];
    function coneTarget(p, range) {
        var look = lookDir(p), best = null, bd = 1e9;
        p.nearby(range).forEach(function (e) {
            if (p.isAlly(e)) return;
            var dx = e.x - p.x, dy = (e.y + 1) - (p.y + 1.6), dz = e.z - p.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
            if ((dx * look.x + dy * look.y + dz * look.z) / l < 0.5) return;           // cone half-angle 60 degrees
            if (l < bd) { bd = l; best = e; }
        });
        return best;
    }
    function addXp(p, id, amount) {
        if (!TD.gainsXp(id)) return;
        var v = load(p);
        if (!v.u[id]) return;
        v.u[id].x = (v.u[id].x || 0) + amount;
        save(p, v);
    }
    function castStrike(p, id) {
        // StrikeAttackHandler, tick by tick (41s_dmz_strikes.js); what follows is only a fallback without it
        if (typeof DMZ_STRIKES !== "undefined") {
            return DMZ_STRIKES.cast(p, id, { rec: rec, cdLeft: cdLeft, setCd: setCd, creative: creative, msg: msg, sendState: sendState,
                addXp: addXp, strikeDamage: strikeDamage, strikeNoForms: strikeNoForms, kiDamage: kiDamage, dmgMod: dmgMod,
                meleeDamage: function (q) { return DMZ_F.melee(view(q)); } });
        }
        var S = TD.STRIKE[id], r = rec(p, id) || {};
        if (cdLeft(p, id) > 0 || cdLeft(p, "strike_global") > 0) return;
        var cost = TD.strikeCost(id, strikeNoForms(p), r.d) * (S.kiRatio || 1);
        if (!creative(p)) {
            if (p.resource("ki") < cost) { msg(p, "message.dragonminez.technique.no_ki", [Math.ceil(cost)]); return; }
            p.addResource("ki", -cost);
        }
        var range = S.range || (p.hasEffect("flight") || p.isFlying() ? 12 : 6);
        var lock = lockedTarget(p);
        var t = coneTarget(p, range) || (lock && p.distanceTo(lock) <= Math.max(range, 16) ? lock : null);
        var total = strikeDamage(p) * TD.strikeActualMult(id, r.d);
        var dur = S.dur, hits = Math.max(1, Math.ceil(Math.max(20, dur) / 10));
        var per = total * 0.65 / hits, fin = total * 0.35;
        var cd = creative(p) ? 20 : TD.strikeCooldown(id, r.c);
        if (!t && !S.targetless) {
            // a miss: half the cooldown and 40 % of the ki back
            if (!creative(p)) p.addResource("ki", cost * 0.4);
            setCd(p, id, Math.ceil(cd / 2));
            setCd(p, "strike_global", TD.STRIKE_GLOBAL_COOLDOWN);
            p.actionbar("&7No target in range.");
            sendState(p);
            return;
        }
        if (t && !S.stationary && p.distanceTo(t) > 1.6) {
            // appear 1.3 blocks in front of the target, facing it
            var dx = p.x - t.x, dz = p.z - t.z, l = Math.sqrt(dx * dx + dz * dz) || 1;
            var fx = t.x + dx / l * 1.3, fz = t.z + dz / l * 1.3;
            var yaw = Math.atan2(-(t.x - fx), t.z - fz) * 180 / Math.PI;
            p.teleportTo(p.dimension, fx, t.y, fz, yaw, 0);
            sfx(p, "tp_short", 1, 1);
        }
        if (t) {
            var tp = t.asPlayer();                                  // the strike lock
            if (tp) tp.addEffect("stunned", dur); else t.addPotion("minecraft:slowness", dur, 9);
        }
        act(p, S.anim, dur);
        if (S.sound) sfx(p, S.sound, 1, 1);
        function victims() {
            if (t) return t.isAlive() ? [t] : [];
            var at = lookPoint(p, 2);
            return RPG.world.entitiesNear(p.dimension, at.x, at.y - 1, at.z, 3).filter(function (e) {
                try { return e.uuid !== p.uuid && e.isAlive() && !p.isAlly(e); } catch (err) { return false; }
            });
        }
        times(hits, function (i) {
            RPG.schedule(Math.min(dur - 1, 10 * (i + 1)), function () {
                victims().forEach(function (e) {
                    e.damageFrom(per, p, { kind: "strike", tag: "dmzstrike:" + id, ignoreIFrames: true });
                    addXp(p, id, 1);
                    burst(e, "minecraft:crit", 6, 0.3, 0.2);
                });
                sfx(t || p, PUNCH[i % PUNCH.length], 0.9, 1);
            });
        });
        RPG.schedule(Math.max(1, dur), function () {
            victims().forEach(function (e) {
                e.damageFrom(fin, p, { kind: "strike", tag: "dmzstrike:" + id, ignoreIFrames: true });
                addXp(p, id, e.isAlive() ? 1 : 3);
                knockAway(p, e, 1.8, 0.4);
                burst(e, "minecraft:explosion", 1, 0.3, 0.2);
            });
            sfx(t || p, "knockback_character", 1, 1);
            sendState(p);
        });
        setCd(p, id, cd);
        setCd(p, "strike_global", TD.STRIKE_GLOBAL_COOLDOWN);
        sendState(p);
    }

    // ---------------------------------------------------------------------------------
    //  evasions (EvasionAttackHandler)
    // ---------------------------------------------------------------------------------
    function behind(t, dist) {
        var yaw = t.yaw * Math.PI / 180;
        return { x: t.x + Math.sin(yaw) * dist, z: t.z - Math.cos(yaw) * dist };
    }
    function freeAt(dim, x, y, z) {
        return RPG.world.getBlock(dim, Math.floor(x), Math.floor(y), Math.floor(z)) === "minecraft:air"
            && RPG.world.getBlock(dim, Math.floor(x), Math.floor(y) + 1, Math.floor(z)) === "minecraft:air";
    }
    function stepForward(p, dist) {
        var d = lookDir(p), fl = Math.sqrt(d.x * d.x + d.z * d.z) || 1;
        while (dist > 1 && !freeAt(p.dimension, p.x + d.x / fl * dist, p.y, p.z + d.z / fl * dist)) dist--;
        if (dist <= 1) { msg(p, "message.dragonminez.technique.afterimage.no_space"); return false; }
        burst(p, "minecraft:cloud", 12, 0.3, 0.02);
        p.teleport(p.x + d.x / fl * dist, p.y, p.z + d.z / fl * dist);
        return true;
    }
    function loseTrack(p, radius) {
        p.nearby(radius).forEach(function (e) { try { if (!e.isPlayer() && e.target && e.target.uuid === p.uuid) e.target = null; } catch (err) { } });
    }
    function castEvasion(p, id) {
        var E = TD.EVASION[id], r = rec(p, id) || {};
        if (cdLeft(p, id) > 0) return;
        var v = view(p), dur = TD.evasionDuration(id, r.r);
        var cost = TD.evasionCost(id, v.stat("SKP"), v.stat("PWR"), r.r);
        var hit = TD.evasionHit(id, v.stat("SKP"), v.stat("PWR"));
        var lock = lockedTarget(p);
        // targeted evasions check first so a failed cast costs nothing
        if (id === "candy_beam") {
            var ct = lock && p.distanceTo(lock) <= 5 ? lock : coneTarget(p, 5);
            if (!ct) { msg(p, "message.dragonminez.technique.candy_beam.no_target"); return; }
            lock = ct;
        }
        if (!creative(p)) {
            if (p.resource("ki") < cost) { msg(p, "message.dragonminez.technique.no_ki", [Math.ceil(cost)]); return; }
            p.addResource("ki", -cost);
        }
        act(p, id === "afterimage" ? "evs.default" : E.anim, dur);
        switch (id) {
            case "taiyoken": {
                sfx(p, "ki_explosion_charge", 1.2, 1.6);
                RPG.world.particle(p.dimension, "minecraft:flash", p.x, p.y + 1.8, p.z, 1, 0, 0);
                var look = lookDir(p);
                p.nearby(20).forEach(function (e) {
                    if (!p.canSee(e)) return;
                    var ey = e.yaw * Math.PI / 180, ex = -Math.sin(ey), ez = Math.cos(ey);
                    var dx = p.x - e.x, dz = p.z - e.z, l = Math.sqrt(dx * dx + dz * dz) || 1;
                    var dot = (ex * dx + ez * dz) / l;
                    if (dot < 0.5) return;                                   // must be facing the caster
                    var dist = Math.min(20, p.distanceTo(e));
                    var secs = (dot >= 0.93 ? 12 : 9) - 3 * (dist / 20);
                    if (p.isAlly(e)) secs *= 0.5;
                    e.addPotion("minecraft:blindness", Math.round(secs * 20), 0);
                    if (!e.isPlayer()) { try { e.target = null; } catch (err) { } e.addPotion("minecraft:slowness", Math.round(secs * 20), 2); }
                    else RPG.net.send(e.asPlayer(), "dmz_taiyoken", { ticks: Math.round(secs * 20) });
                });
                break;
            }
            case "rage_scream": {
                sfx(p, "oozaru_growl_player", 1.5, 1);
                times(Math.floor(dur / 5), function (i) {
                    RPG.schedule(i * 5, function () {
                        if (!p.isAlive()) return;
                        var rad = 5;
                        p.nearby(rad).forEach(function (e) {
                            if (p.isAlly(e)) return;
                            var fall = 1 - Math.min(1, p.distanceTo(e) / rad);
                            e.damageFrom(Math.max(1, hit), p, { kind: "strike", ignoreIFrames: true });
                            knockAway(p, e, 0.35 * fall, 0.12);
                        });
                        burst(p, "minecraft:sonic_boom", 1, 0, 0);
                    });
                });
                break;
            }
            case "afterimage": {
                var at = lock && p.distanceTo(lock) <= 24 ? lock : null;
                sfx(p, "evasion1", 1, 1);
                if (at) {
                    times(4, function (i) {
                        RPG.schedule(i * 5, function () {
                            if (!at.isAlive() || !p.isAlive()) return;
                            for (var tries = 0; tries < 10; tries++) {
                                var a = Math.random() * Math.PI * 2, hop = 4 + Math.random() * 2;
                                var x = at.x + Math.cos(a) * hop, z = at.z + Math.sin(a) * hop;
                                if (i === 3) { var b = behind(at, 1.5); x = b.x; z = b.z; }
                                if (!freeAt(p.dimension, x, at.y, z)) continue;
                                burst(p, "minecraft:cloud", 8, 0.3, 0.02);
                                var yaw = Math.atan2(-(at.x - x), at.z - z) * 180 / Math.PI;
                                p.teleportTo(p.dimension, x, at.y, z, yaw, 0);
                                sfx(p, "tp_short", 0.8, 1.2);
                                break;
                            }
                        });
                    });
                    loseTrack(p, 16);
                } else if (stepForward(p, 4)) loseTrack(p, 16);
                break;
            }
            case "sleep_recovery": {
                p.addPotion("minecraft:slowness", dur, 6);
                times(Math.floor(dur / 20), function (i) {
                    RPG.schedule((i + 1) * 20, function () {
                        if (!p.isAlive()) return;
                        p.heal(p.maxHealth * 0.10);
                        burst(p, "minecraft:note", 2, 0.3, 0);
                    });
                });
                break;
            }
            case "dimensional_teleport": {
                sfx(p, "tp", 1, 1);
                if (lock && p.distanceTo(lock) <= 64) {
                    RPG.schedule(8, function () {
                        if (!lock.isAlive()) return;
                        var b = behind(lock, 1.5);
                        p.teleportTo(p.dimension, b.x, lock.y, b.z, lock.yaw, 0);
                        sfx(p, "tp_short", 1, 1);
                        burst(p, "minecraft:reverse_portal", 20, 0.4, 0.05);
                    });
                } else stepForward(p, 4);
                break;
            }
            case "candy_beam": {
                RPG.schedule(10, function () {
                    if (!lock.isAlive()) return;
                    p.shoot("candy_beam", { damage: 0 });
                    var lp = lock.asPlayer();
                    if (lp) lp.addEffect("stunned", 60);
                    else { lock.addPotion("minecraft:slowness", 60, 255); try { lock.target = null; } catch (err) { } }
                    RPG.world.particle(lock.dimension, "minecraft:heart", lock.x, lock.y + 1, lock.z, 10, 0.5, 0);
                    sfx(lock, "majin_absorb", 1, 1.4);
                });
                break;
            }
            case "gum_bind": {
                RPG.schedule(10, function () {
                    var gt = lock && p.distanceTo(lock) <= 24 ? lock : p.target(24);
                    if (!gt || !gt.isAlive()) return;
                    var gp = gt.asPlayer();
                    if (gp) { gp.addEffect("stunned", 60); act(gp, "evs.gum_bound", 60); }
                    else gt.addPotion("minecraft:slowness", 60, 255);
                    burst(gt, "minecraft:item_slime", 20, 0.5, 0.1);
                    sfx(gt, "majin_absorb", 1, 0.8);
                });
                break;
            }
        }
        addXp(p, id, 2);
        // the cast evasion gets its own cooldown; every other evasion at least duration + 60
        setCd(p, id, creative(p) ? 20 : TD.evasionCooldown(id, r.c));
        Object.keys(load(p).u).forEach(function (o) {
            if (o === id || TD.kind(o) !== "evasion") return;
            if (cdLeft(p, o) < dur + TD.SHARED_EVASION_COOLDOWN) setCd(p, o, dur + TD.SHARED_EVASION_COOLDOWN);
        });
        sendState(p);
    }

    // ---------------------------------------------------------------------------------
    //  upgrades (UpgradeTechniqueC2S: strikes and evasions; predefined ki attacks can't be)
    // ---------------------------------------------------------------------------------
    function upgrade(p, id, stat) {
        var v = load(p), r = v.u[id];
        if (!r || !TD.canUpgrade(id, stat) || !raceAllowed(p, id)) return false;
        if ((r.x || 0) < TD.MIN_XP_COST) return false;
        r.x -= TD.MIN_XP_COST;
        if (stat === "damage") r.d = (r.d || 0) + 1;
        else if (stat === "cooldown") r.c = (r.c || 0) + 1;
        else if (stat === "duration") r.r = (r.r || 0) + 1;
        save(p, v);
        sendState(p);
        return true;
    }

    // ---------------------------------------------------------------------------------
    //  ticking: charge sessions and firing locks every tick; loadout + legacy migration per second
    // ---------------------------------------------------------------------------------
    RPG.every(1, function () {
        var ids = Object.keys(SESS);
        for (var i = 0; i < ids.length; i++) {
            var s = SESS[ids[i]];
            try { tickCharge(s); } catch (err) { delete SESS[ids[i]]; RPG.log("[DBR] technique charge error: " + err); }
        }
        var f = Object.keys(FIRING);
        if (!f.length) return;
        var now = RPG.server.getTick();
        for (var j = 0; j < f.length; j++) {
            var st = FIRING[f[j]], p = st.p;
            try {
                if (!p.isAlive()) { endFiring(p, st); continue; }
                // the hold lasts while a restricted attack is still out within 32 blocks (a wave or beam being
                // emitted, a giant ball flying off), or for any other shot the instant it is within 3 blocks
                var live = (st.projs || []).filter(function (x) { return x && x.alive; });
                st.projs = live;
                var reach = st.restrict ? 32 : 3, near = false;
                live.forEach(function (x) { var dx = x.x - p.x, dy = x.y - p.y, dz = x.z - p.z; if (dx * dx + dy * dy + dz * dz <= reach * reach) near = true; });
                var emitting = !!st.emitter && now < st.until;
                var holding = emitting || near || !!st.clash || now < (st.holdUntil || 0);
                if (st.lock && !holding) {
                    st.lock = false;
                    p.removeEffect("dmz_tech_rooted");
                    if (st.cam) { st.cam = false; RPG.net.send(p, "dmz_tech_firelock", { on: false }); }
                    if (st.restrict || st.emitter) stopAct(p);
                } else if (st.lock && st.restrict && !p.hasEffect("dmz_tech_rooted")) p.addEffect("dmz_tech_rooted", -1);
                // the ki drain lasts while the attack does (kiLifetimeDrainPerTick)
                if (st.drain > 0 && live.length && now < st.until && !st.clash) {     // a clash-locked beam drains nothing
                    if (p.resource("ki") <= 0) live.forEach(function (x) { x.discard(); });
                    else p.addResource("ki", -Math.min(st.drain, p.resource("ki")));
                }
                if (emitting) {
                    st.age = (st.age || 0) + 1;
                    if (st.age === 1) act(p, st.emitAnim || "ki.barrage_fire", st.until - now);
                    st.emitter(st.age);
                }
                if (!holding && !live.length && !emitting) endFiring(p, st);
            } catch (err2) { delete FIRING[f[j]]; }
        }
    });
    function endFiring(p, st) {
        delete FIRING[p.uuid];
        if (st.onEnd) { try { st.onEnd(); } catch (e0) { } }
        if (st.volley && st.volley.alive) st.volley.discard();
        try {
            if (st.lock) { p.removeEffect("dmz_tech_rooted"); if (st.restrict || st.emitter) stopAct(p); }
            if (st.cam) RPG.net.send(p, "dmz_tech_firelock", { on: false });
        } catch (e) { }
    }

    var REVERSE = {};
    Object.keys(DMZ_SKILLS_DATA.TECHNIQUES).forEach(function (k) { if (TD.exists(k)) REVERSE[DMZ_SKILLS_DATA.TECHNIQUES[k]] = k; });

    // older saves: techniques bought before this port (original skill levels / our old skills / the skill bar)
    function migrate(p) {
        var v = load(p), changed = false;
        if (typeof DMZ_SKILLS !== "undefined") {
            var lv = DMZ_SKILLS.levels(p);
            Object.keys(lv).forEach(function (s) { if (TD.exists(s) && lv[s] >= 1 && !v.u[s]) { v.u[s] = { x: 0, d: 0, c: 0, r: 0 }; changed = true; } });
        }
        if (!p.getVar("dmz_tech_mig", 0)) {
            Object.keys(REVERSE).forEach(function (ours) {
                if (p.hasSkill(ours) && !v.u[REVERSE[ours]]) { v.u[REVERSE[ours]] = { x: 0, d: 0, c: 0, r: 0 }; changed = true; }
            });
            if (v.s.join("") === "") {
                var bar = p.skillBar, len = !bar ? 0 : bar.length !== undefined ? bar.length : bar.size();
                for (var i = 0; i < N && i < len; i++) {
                    var id = String(bar[i] !== undefined ? bar[i] : bar.get(i) || "");
                    if (!id) continue;
                    if (REVERSE[id] && v.u[REVERSE[id]]) v.s[i] = REVERSE[id];
                    else if (!REVERSE[id] && RPG.skills.exists(id) && p.hasSkill(id)) v.s[i] = id;
                }
                changed = true;
            }
            p.setVar("dmz_tech_mig", 1);
        }
        if (changed) save(p, v);
    }

    RPG.on("playerJoin", function (p) {
        // a Final Explosion that was still holding the caster up when they left
        if (p.getVar("dmz_explo_ng", 0)) { try { p.setNoGravity(false); } catch (e0) { } p.setVar("dmz_explo_ng", 0); }
        RPG.schedule(45, function () {
            try { if (!p.isAlive()) return; } catch (e) { return; }
            migrate(p);
            sendState(p);
        });
    });
    RPG.on("playerLeave", function (p) { delete SESS[p.uuid]; delete FIRING[p.uuid]; delete HINT_AT[p.uuid]; });
    RPG.on("death", function (p) { if (SESS[p.uuid] || FIRING[p.uuid]) cancel(p); });
    RPG.on("playerTick", function (p) {
        if (!p.getVar("dmz_created", 0)) return;
        var oz = inOozaru(p), v = load(p);
        if (oz && !v.fl) applyLoadout(p);
        else if (!oz && v.fl) restoreLoadout(p);
    });

    // ---- client requests (SkillsMenuScreen: bind, delete, upgrade) ----
    RPG.net.on("dmz_tech", function (p, d) {
        if (!d || !p.getVar("dmz_created", 0)) return;
        var a = String(d.action || "");
        if (a === "state") return sendState(p);
        if (a === "equip") { if (!equip(p, d.slot, d.id)) sendState(p); return; }
        if (a === "forget") { if (!forget(p, String(d.id || ""))) sendState(p); return; }
        if (a === "upgrade") { if (upgrade(p, String(d.id || ""), String(d.stat || ""))) uiSfx(p, "dmzpack:pip_menu", 1, 1); else sendState(p); }
    });

    // ---- /rpgc dmztech (the old form; the original's TechCommand is /rpgc tech in 98_dbr_commands.js) ----
    function targets(p, name) {
        if (!name) return p ? [p] : [];
        if (name === "@a") return RPG.server.players();
        var t = RPG.server.player(name);
        return t ? [t] : [];
    }
    function tell(p, text) { if (p) p.tell(text); else RPG.log(text.replace(/&./g, "")); }
    RPG.commands.register("dmztech", {
        hidden: true,   // the old form, kept for existing setups; /rpgc tech is the original's command (98_dbr_commands.js)
        permission: 2,
        description: "/rpgc dmztech <learn|forget|equip|list|xp|cooldowns> ... - techniques",
        run: function (p, args) {
            var sub = String(args[0] || "").toLowerCase();
            if (sub === "learn" || sub === "add" || sub === "forget" || sub === "remove") {
                var id = String(args[1] || "").toLowerCase(), who = targets(p, args[2]);
                if (!id || !who.length) return tell(p, "&cUsage: /rpgc dmztech " + sub + " <technique|all> [player]");
                if (id !== "all" && !TD.exists(id)) return tell(p, "&cUnknown technique: " + id);
                var learn = sub === "learn" || sub === "add";
                who.forEach(function (t) {
                    var list = id === "all" ? TD.all() : [id];
                    if (learn) list.forEach(function (x, i) { unlock(t, x, { source: "command", silent: id === "all" && i > 0 }); });
                    else if (id === "all") clearAll(t);
                    else forget(t, id);
                });
                return tell(p, "&a" + (learn ? "Added " : "Removed ") + (id === "all" ? "all techniques" : TD.english(id)) + (learn ? " to " : " from ") + who.length + " player(s).");
            }
            if (sub === "equip") {
                var slot = Math.floor(Number(args[1])) - 1, tid = String(args[2] || "").toLowerCase(), tw = targets(p, args[3]);
                if (!(slot >= 0 && slot < N) || !tid || !tw.length) return tell(p, "&cUsage: /rpgc dmztech equip <slot 1-8> <technique|none> [player]");
                tw.forEach(function (t) {
                    if (tid !== "none" && TD.exists(tid) && !has(t, tid)) unlock(t, tid, { source: "command" });
                    var ok = equip(t, slot, tid === "none" ? "" : tid);
                    tell(p, ok ? "&aSlot " + (slot + 1) + " -> " + (tid === "none" ? "empty" : TD.english(tid)) + " (" + t.name + ")" : "&cCan't equip that for " + t.name + ".");
                });
                return;
            }
            if (sub === "list" || sub === "") {
                var lw = targets(p, args[1]);
                if (!lw.length) return tell(p, "&cNo such player.");
                var t0 = lw[0], v = load(t0);
                tell(p, "&6" + t0.name + "'s techniques (" + Object.keys(v.u).length + "):");
                Object.keys(v.u).forEach(function (x) { tell(p, " &e" + TD.english(x) + " &7(" + x + ", " + (TD.kind(x) || "?") + (TD.gainsXp(x) ? ", " + (v.u[x].x || 0) + " XP" : "") + ")"); });
                tell(p, "&6Slots: &f" + v.s.map(function (x, i) { return (i + 1) + ":" + (x ? TD.english(x) : "-"); }).join("  "));
                return;
            }
            if (sub === "xp" || sub === "experience") {
                var mode = String(args[1] || "").toLowerCase(), xid = String(args[2] || "").toLowerCase(), amt = Math.max(0, Math.floor(Number(args[3]) || 0));
                var xw = targets(p, args[4]);
                if (["add", "set", "remove"].indexOf(mode) < 0 || !xid || !xw.length) return tell(p, "&cUsage: /rpgc dmztech xp <add|set|remove> <technique> <amount> [player]");
                xw.forEach(function (t) {
                    var vv = load(t);
                    if (!vv.u[xid]) return;
                    var x = vv.u[xid].x || 0;
                    vv.u[xid].x = mode === "add" ? x + amt : mode === "set" ? amt : Math.max(0, x - amt);
                    save(t, vv); sendState(t);
                });
                return tell(p, "&aUpdated experience of " + TD.english(xid) + ".");
            }
            if (sub === "cooldowns" || sub === "cd") {
                targets(p, args[1]).forEach(function (t) { t.setVar("dmz_tech_cd", null); sendState(t); });
                return tell(p, "&aTechnique cooldowns cleared.");
            }
            tell(p, "&cUsage: /rpgc dmztech <learn|forget|equip|list|xp|cooldowns> ...");
        },
        suggest: function (p, args) {
            if (args.length <= 1) return ["learn", "forget", "equip", "list", "xp", "cooldowns"];
            var sub = String(args[0]).toLowerCase();
            if ((sub === "learn" || sub === "forget") && args.length === 2) return ["all"].concat(TD.all());
            if (sub === "equip" && args.length === 2) return ["1", "2", "3", "4", "5", "6", "7", "8"];
            if (sub === "equip" && args.length === 3) return ["none"].concat(p ? unlocked(p) : TD.all());
            if (sub === "xp" && args.length === 2) return ["add", "set", "remove"];
            if (sub === "xp" && args.length === 3) return p ? unlocked(p).filter(TD.gainsXp) : TD.STRIKE_IDS.concat(TD.EVASION_IDS);
            return RPG.server.players().map(function (x) { return x.name; });
        }
    });

    // ---------------------------------------------------------------------------------
    //  the plain ki blast (KiBlastC2S): Left Alt + right click. A tap throws one blast from alternating hands
    //  (32-tick cooldown); holding 6 ticks throws a volley of 6, one every 3 ticks after a 4-tick wind-up
    //  (x3 cost, x0.6 damage, 2.5 spread, 600-tick volley cooldown). Cost 2 % of max ki + 0.1 x the baseline
    //  form drain; damage = ki damage x (0.5 + 0.05 x Ki Manipulation level). Size 0.5, speed 1.5, life 100.
    // ---------------------------------------------------------------------------------
    var KB = { SHOTS: 6, INTERVAL: 3, WINDUP: 4, RECOVERY: 4, VOLLEY_CD: 600, SINGLE_CD: 32, COST_X: 3, DMG_X: 0.6, HAND: 0.35, SPREAD: 2.5 };
    var VOLLEYS = {}, LEFT_NEXT = {};
    function darken(hex, f) {
        var n = parseInt(String(hex || "#FFFFFF").replace("#", ""), 16) || 0;
        var r = Math.floor(((n >> 16) & 255) * f), g = Math.floor(((n >> 8) & 255) * f), b = Math.floor((n & 255) * f);
        return "#" + ("000000" + ((r << 16) | (g << 8) | b).toString(16).toUpperCase()).slice(-6);
    }
    function kiBlastShot(p, dmg, side, spread) {
        var main = String(p.getVar("dmz_aura_color", "") || "#FFFFFF"), colors = { core: main, border: darken(main, 0.85), outline: "#FFFFFF" };
        var yaw = (p.yaw + 90) * Math.PI / 180, rx = -Math.sin(yaw), rz = Math.cos(yaw), d = lookDir(p);
        var x = p.x + rx * side, y = p.eyeY - 0.4, z = p.z + rz * side;
        var b = RPG.world.shootFrom(p.dimension, x, y, z, d.x, d.y, d.z, "dmz_ki_ball", { size: 0.5, speed: 1.5, lifetime: 100, damage: 0, colors: colors }, p);
        if (!b) return;
        b.setVar("dmg", dmg); b.setVar("tech", ""); b.setVar("life", 100); b.setVar("colors", colors);
        DMZ_TECH_PROJ.look(b, { k: "ball", rt: 1, sz: 0.5, f: 1 });
        aimCrosshair(p, b, y + 0.25);                            // fireHability: from the ball to the crosshair
        if (spread > 0) {
            var v = { x: b.vx / 1.5, y: b.vy / 1.5, z: b.vz / 1.5 }, a = spread * 0.0075;
            var g = function () { var u = 0; while (u === 0) u = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * Math.random()); };
            v = { x: v.x + g() * a, y: v.y + g() * a, z: v.z + g() * a };
            var l = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z) || 1;
            b.setDirection(v.x / l, v.y / l, v.z / l);
        }
        sfx(b, "kiblast_shoot", 0.1, 1.0 + Math.random() * 0.2);
    }
    function kiBlast(p, volley) {
        if (!p.getVar("dmz_created", 0) || VOLLEYS[p.uuid] || SESS[p.uuid] || (FIRING[p.uuid] && FIRING[p.uuid].lock)) return;
        if (cdLeft(p, "ki_blast") > 0 || p.hasEffect("stunned") || skillLevel(p, "kicontrol") <= 0) return;
        var drain = typeof DMZ_FLIGHT !== "undefined" && DMZ_FLIGHT.CFG ? DMZ_FLIGHT.CFG.baselineFormDrain : 80;
        var cost = Math.floor(p.maxResource("ki") * 0.02 + 0.1 * drain);
        volley = !!volley && cdLeft(p, "ki_volley") <= 0;
        if (volley) cost *= KB.COST_X;
        if (creative(p)) cost = 0;
        if (p.resource("ki") < cost) return;
        p.addResource("ki", -cost);
        var dmg = kiDamage(p) * (0.5 + 0.05 * skillLevel(p, "kimanipulation"));
        if (volley) {
            var lock = KB.WINDUP + KB.SHOTS * KB.INTERVAL + KB.RECOVERY;
            setCd(p, "ki_blast", lock + KB.SINGLE_CD / 2);
            setCd(p, "ki_volley", KB.VOLLEY_CD);
            VOLLEYS[p.uuid] = { p: p, dmg: dmg * KB.DMG_X, ticks: 0, shots: 0 };
            act(p, "ki.barrage_fire", lock);
            return;
        }
        setCd(p, "ki_blast", KB.SINGLE_CD);
        var left = !!LEFT_NEXT[p.uuid];
        LEFT_NEXT[p.uuid] = !left;
        kiBlastShot(p, dmg, (left ? -1 : 1) * KB.HAND, 0.5);
        act(p, "ki.barrage_fire", 8);
    }
    RPG.every(1, function () {
        for (var u in VOLLEYS) {
            var v = VOLLEYS[u], p = v.p;
            try {
                if (!p.isAlive() || p.hasEffect("stunned")) { delete VOLLEYS[u]; stopAct(p); continue; }
                var el = v.ticks++ - KB.WINDUP;
                if (el >= 0 && v.shots < KB.SHOTS && el % KB.INTERVAL === 0) { kiBlastShot(p, v.dmg, (v.shots % 2 === 0 ? 1 : -1) * KB.HAND, KB.SPREAD); v.shots++; }
                if (v.shots >= KB.SHOTS && el >= KB.SHOTS * KB.INTERVAL + KB.RECOVERY) { delete VOLLEYS[u]; stopAct(p); }
            } catch (e) { delete VOLLEYS[u]; }
        }
    });
    RPG.net.on("dmz_kiblast", function (p, d) { kiBlast(p, !!(d && d.v)); });
    RPG.on("playerLeave", function (p) { delete VOLLEYS[p.uuid]; delete LEFT_NEXT[p.uuid]; });

    /**
     * Beam clash (41b_dbr_beam_clash.js): on = hold the shooter in the firing pose (rooted, the fire animation held,
     * no ki drain) for as long as the clash calls this every tick; off = the pose for holdTicks more (the winner's
     * breakthrough, the rest of a dissolved beam), 0 ends it now (the loser).
     */
    function clashFire(p, on, holdTicks) {
        if (!p) return;
        var now = RPG.server.getTick(), f = FIRING[p.uuid];
        if (on) {
            if (!f) f = FIRING[p.uuid] = { until: now, drain: 0, p: p };
            if (!f.clash) { f.clash = true; if (f.anim) act(p, f.anim, 600); p.addEffect("dmz_tech_rooted", -1); }
            f.until = Math.max(f.until, now + 2);
            f.holdUntil = now + 2; f.lock = true; f.restrict = true;
            return;
        }
        if (!f) return;
        f.clash = false;
        var t = Math.max(0, Math.floor(Number(holdTicks) || 0));
        if (t <= 0) { f.lock = true; f.restrict = true; endFiring(p, f); return; }
        f.until = now + t;
        f.holdUntil = now + t;
        if (f.anim) act(p, f.anim, t);
    }

    return { clashFire: clashFire, unlock: unlock, forget: forget, clearAll: clearAll, equip: equip, slots: slots, unlocked: unlocked, has: has,
        press: press, release: releaseKey, cast: function (p, id, slot) { if (has(p, id) && canActivate(p, id)) cast(p, id, slot); },
        isCharging: isCharging, cancel: cancel, sendState: sendState, cooldownLeft: cdLeft, setCooldown: setCd, info: info, migrate: migrate,
        hasRevive: hasRevive, installRevive: installRevive, uninstallRevive: uninstallRevive,
        /** TechCommand experience add|set|remove: false when the technique isn't unlocked */
        experience: function (p, id, mode, amt) {
            var v = load(p);
            if (!v.u[id]) return false;
            var x = v.u[id].x || 0;
            v.u[id].x = mode === "add" ? x + amt : mode === "set" ? amt : Math.max(0, x - amt);
            save(p, v); sendState(p);
            return true;
        } };
})();
