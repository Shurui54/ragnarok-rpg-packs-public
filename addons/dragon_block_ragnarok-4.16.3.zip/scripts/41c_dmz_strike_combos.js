// =====================================================================================
//  41c_dmz_strike_combos.js - the original's choreographed strike combos (StrikeCombos + HeldVictim)
// =====================================================================================
//  Port of the original (GPL-3.0, see NOTICE.md): StrikeCombos.MeteorBurstCombo, MysticBallCombo,
//  DarknessEyeBeamCombo, DeathChaserCombo, AndroidCombo, BeamSwordSlashCombo, PerfectRushCombo and
//  SpiritBreakerCombo, tick by tick with the original's tick tables, positions, damage shares, poses,
//  visuals and sounds, and HeldVictim (the victim is pinned and carried through the choreography: players
//  are strike locked and teleported each tick, NPCs lose their AI while held; world bosses are never carried,
//  they stay rooted and the combo plays round them).
//  41s_dmz_strikes.js starts and ends these (cost, cooldowns, targeting) and hands each tick here with a
//  performer C: { p, t, id, place(pos, yaw), feet(pos), strikeBudget, kiBudget, strikeHit(v, amount, lethal),
//  kiHit(v, amount, lethal), fx(at, msg), snd(at, sound, volume, pitch), frame(threshold, lerp, ticks, invert),
//  shake(full, radius) }.
//  Every visual is a "dmz_strike_fx" message (client/scripts/49s_dmz_strike_fx.js); the held ki balls, the eye
//  lasers and the beam sword are drawn by the clients from a few messages, never entities.
// =====================================================================================
var DMZ_STRIKE_COMBOS = (function () {
    // ---- vectors ----
    function V(x, y, z) { return { x: x, y: y, z: z }; }
    function pos(e) { return V(e.x, e.y, e.z); }
    function add(a, b) { return V(a.x + b.x, a.y + b.y, a.z + b.z); }
    function sub(a, b) { return V(a.x - b.x, a.y - b.y, a.z - b.z); }
    function mul(a, k) { return V(a.x * k, a.y * k, a.z * k); }
    function up(a, h) { return V(a.x, a.y + h, a.z); }
    function lerp(a, b, t) { return V(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t); }
    function len(a) { return Math.sqrt(a.x * a.x + a.y * a.y + a.z * a.z); }
    function dist(a, b) { return len(sub(a, b)); }
    function norm(a) { var l = len(a); return l < 1e-9 ? V(0, 0, 0) : mul(a, 1 / l); }
    function dot(a, b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
    function cross(a, b) { return V(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x); }
    function facing(yaw) { var r = yaw * Math.PI / 180; return V(-Math.sin(r), 0, Math.cos(r)); }   // Vec3.directionFromRotation(0, yaw)
    function yawTowards(from, to) {
        var dx = to.x - from.x, dz = to.z - from.z;
        if (dx * dx + dz * dz < 1e-6) return 0;
        return Math.atan2(dz, dx) * 180 / Math.PI - 90;
    }
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function clamp01(v) { return clamp(v, 0, 1); }
    function smooth(t) { return t * t * (3 - 2 * t); }
    function easeOut(t) { var i = 1 - t; return 1 - i * i; }
    function bezier(a, b, c, t) { return lerp(lerp(a, b, t), lerp(b, c, t), t); }
    function slerp(a, b, t) {
        var d = clamp(dot(a, b), -1, 1), ang = Math.acos(d);
        if (ang < 1e-3) return norm(lerp(a, b, t));
        var s = Math.sin(ang);
        if (Math.abs(s) < 1e-3) {
            var side = cross(a, V(0, 1, 0));
            if (dot(side, side) < 1e-4) side = V(1, 0, 0);
            var mid = norm(side);
            return t < 0.5 ? slerp(a, mid, t * 2) : slerp(mid, b, t * 2 - 1);
        }
        return norm(add(mul(a, Math.sin((1 - t) * ang) / s), mul(b, Math.sin(t * ang) / s)));
    }
    function hexs(n) { var s = (n & 0xFFFFFF).toString(16); while (s.length < 6) s = "0" + s; return "#" + s.toUpperCase(); }
    function r2(v) { return Math.round(v * 100) / 100; }
    function center(e) { return V(e.x, e.y + e.height / 2, e.z); }
    function width(e) { return Number(e.width) || 0.6; }
    function height(e) { return Number(e.height) || 1.8; }
    function alive(e) { try { return !!e && e.isAlive(); } catch (x) { return false; } }
    function isPlayer(e) { try { return e.isPlayer(); } catch (x) { return false; } }

    // ---- the world (level.clip, groundHeight, noCollision) ----
    /** level.clip with COLLIDER blocks: where the segment from -> to first meets terrain, or null. */
    function clip(dim, from, to) {
        var d = sub(to, from), l = len(d);
        if (l < 1e-4) return null;
        var r = null;
        try { r = RPG.world.raycast(dim, from.x, from.y, from.z, d.x / l, d.y / l, d.z / l, l, { blocks: true, entities: false }); } catch (x) { }
        return r && r.hit === "block" ? { at: V(r.x, r.y, r.z), d: r.distance } : null;
    }
    function clearPoint(dim, from, wanted, margin) {
        var h = clip(dim, from, wanted);
        if (!h) return wanted;
        var dir = sub(wanted, from), l = len(dir);
        if (l < 1e-4) return from;
        return add(from, mul(dir, Math.max(0, h.d - margin) / l));
    }
    /** groundHeight: the top of the first solid block at or below fromY + 1 (64 down at most). */
    function groundHeight(dim, x, z, fromY) {
        var h = null;
        try { h = RPG.world.raycast(dim, x, Math.floor(fromY) + 1.999, z, 0, -1, 0, 65, { blocks: true, entities: false }); } catch (e) { }
        if (h && h.hit === "block") return h.y;
        var hr = null;
        try { hr = RPG.world.heightRange(dim); } catch (e2) { }
        return hr ? hr.min : -64;
    }
    function groundedWithin(dim, at, maxDrop) {
        var floor = groundHeight(dim, at.x, at.z, at.y + 0.5);
        if (at.y - floor > maxDrop) return at;
        return V(at.x, floor, at.z);
    }
    /** level.noCollision for an entity-sized box with its feet at p (blocks a body can stand in). */
    function fits(dim, e, p) {
        var hw = width(e) / 2 - 0.01, h = height(e) - 0.01;
        for (var x = Math.floor(p.x - hw); x <= Math.floor(p.x + hw); x++)
            for (var y = Math.floor(p.y + 0.01); y <= Math.floor(p.y + h); y++)
                for (var z = Math.floor(p.z - hw); z <= Math.floor(p.z + hw); z++) {
                    try { if (!RPG.world.isReplaceable(dim, x, y, z)) return false; } catch (er) { return true; }
                }
        return true;
    }
    function clearAbove(dim, victim, from, h0) {
        for (var h = h0; h > 0; h -= 0.5) if (fits(dim, victim, up(from, h))) return up(from, h);
        return from;
    }
    function gap(self, target, extra) { return width(self) * 0.5 + width(target) * 0.5 + extra; }

    // ---- HeldVictim ----
    var LEASE = {};                                       // held player uuid -> server tick (isHeld)
    function now() { return RPG.server.getTick(); }
    function isBoss(e) { try { return typeof DMZ_WORLD_BOSSES !== "undefined" && DMZ_WORLD_BOSSES.isBoss(e); } catch (x) { return false; } }
    function canTarget(holder, t) {
        if (!t || t.uuid === holder.uuid || !alive(t)) return false;
        if (isPlayer(t)) { var g = t.asPlayer().getGameMode(); if (g === "creative" || g === "spectator") return false; }
        return true;
    }
    function canHold(holder, t) { return canTarget(holder, t) && !isBoss(t); }
    function Held(e, pinned, stunTicks) {
        this.e = e; this.pinned = pinned; this.fromLeft = false; this.hadAI = null;
        if (!pinned) return;
        if (isPlayer(e)) { e.asPlayer().addEffect("dmz_strike_locked", stunTicks); LEASE[e.uuid] = now(); }
        else { try { this.hadAI = e.hasAI(); if (this.hadAI) e.setAI(false); } catch (x) { } }
    }
    Held.prototype.valid = function (holder, maxDist) {
        var e = this.e;
        if (this.pinned && isPlayer(e)) LEASE[e.uuid] = now();
        if (!alive(e) || e.dimension !== holder.dimension) return false;
        if (dist(pos(e), pos(holder)) > maxDist) return false;
        if (isPlayer(e)) {
            var p = e.asPlayer(), g = p.getGameMode();
            if (g === "creative" || g === "spectator") return false;
            if (p.hasEffect("knocked_down")) return false;
        }
        return true;
    };
    Held.prototype.hold = function (at, faceYaw) {
        if (!this.pinned) return;
        var e = this.e;
        e.fallDistance = 0;
        try { e.setVelocity(0, 0, 0); } catch (x) { }
        if (isPlayer(e)) { LEASE[e.uuid] = now(); e.asPlayer().teleportTo(e.dimension, at.x, at.y, at.z, faceYaw, e.pitch || 0); }
        else { e.teleport(at.x, at.y, at.z); try { e.setRotation(faceYaw, 0); } catch (x2) { } }
    };
    Held.prototype.pose = function (a) {
        if (!this.pinned || !isPlayer(this.e)) return;
        act(this.e.asPlayer(), a, 60);
    };
    Held.prototype.flinch = function () { this.fromLeft = !this.fromLeft; this.pose(this.fromLeft ? "base.hurt_left" : "base.hurt_right"); };
    Held.prototype.launched = function () { this.pose("base.hurt_top"); };
    Held.prototype.knockOut = function () { this.pose("base.faint_horizontal"); };
    Held.prototype.knockDown = function () { this.pose("base.hurt_down"); };
    Held.prototype.grabbed = function () { this.pose("skp.grabbed"); };
    Held.prototype.release = function () {
        if (!this.pinned) return;
        var e = this.e;
        this.pinned = false;
        if (isPlayer(e)) {
            delete LEASE[e.uuid];
            try { var p = e.asPlayer(); if (p.hasEffect("dmz_strike_locked")) p.removeEffect("dmz_strike_locked"); stopAct(p); } catch (x) { }
        } else if (this.hadAI) { try { if (alive(e)) e.setAI(true); } catch (x2) { } }
    };
    function capture(holder, t, dur) { return canHold(holder, t) ? new Held(t, true, dur + 20) : new Held(t, false, 0); }

    // ---- visuals shared by the combos ----
    function burst(C, at, dir, scale, c1, c2, glow, life) {      // ImpactBurstVfxS2C
        var d = norm(dir);
        C.fx(at, { t: "burst", x: r2(at.x), y: r2(at.y), z: r2(at.z), d: [r2(d.x), r2(d.y), r2(d.z)], s: scale, c: hexs(c1), c2: hexs(c2), g: glow ? 1 : 0, life: life });
    }
    function shock(C, at, scale, color, life) { C.fx(at, { t: "shock", x: r2(at.x), y: r2(at.y), z: r2(at.z), s: scale, c: hexs(color), life: life }); }
    function after(C, at, yaw) { C.fx(at, { t: "after", e: C.p.entityId, x: r2(at.x), y: r2(at.y), z: r2(at.z), yaw: Math.round(yaw), life: 30 }); }
    function rocks(C, at, n, spread, sy, speed) { C.fx(at, { t: "rocks", x: r2(at.x), y: r2(at.y), z: r2(at.z), n: n, sx: spread, sy: sy, v: speed }); }
    function dust(C, at, n, spread, sy, speed) { C.fx(at, { t: "dust", x: r2(at.x), y: r2(at.y), z: r2(at.z), n: n, sx: spread, sy: sy, v: speed }); }
    function boom(C, at, size, c1, c2, c3) {                  // KiExplosionVisualEntity.setupExplosion(main, border, outline, size)
        C.fx(at, { t: "boom", x: r2(at.x), y: r2(at.y), z: r2(at.z), s: size, c: [hexs(c1), hexs(c2), hexs(c3)] });
    }
    function slash(C, from, dir, speed, roll, radius, color, core, life) {   // SwordSlashS2C
        var d = norm(dir);
        C.fx(from, { t: "slash", x: r2(from.x), y: r2(from.y), z: r2(from.z), d: [r2(d.x), r2(d.y), r2(d.z)], sp: speed, roll: roll, r: radius,
            c: hexs(color), c2: hexs(core), life: life });
    }
    function particle(C, at, type, n, spread, speed) { RPG.world.particle(C.p.dimension, type, at.x, at.y, at.z, n, spread, speed); }
    function punchSound() { return ["punch4", "punch5", "punch6"][Math.floor(Math.random() * 3)]; }
    function pitchJitter(base, span) { return base + Math.random() * span; }

    // the combo's ordinary hit: strike damage share, a white burst with the combo's tint, the sound
    function strike(C, S, share, scale, sound, dir, tint) {
        var v = S.victim.e;
        C.strikeHit(v, C.strikeBudget * share, false);
        burst(C, center(v), dir, scale, 0xFFFFFF, tint, true, 8 + Math.floor(scale * 2));
        C.snd(center(v), sound, 1.8, pitchJitter(0.85, 0.2));
    }
    function groundImpact(C, at, scale, color, rocksN, dustN) {
        rocks(C, up(at, 0.2), rocksN, scale * 0.3, 0.3, 0.25);
        if (dustN) dust(C, up(at, 0.2), dustN, scale * 0.35, 0.3, 0.1);
        shock(C, up(at, 0.2), scale, color, rocksN === 30 || color === 0xFFE0A0 ? 12 : 14);
        C.snd(at, "knockback_character", 2, 0.7);
    }
    // the common opening (tick < DASH_START: stand still facing the target; DASH_START: capture the victim)
    function opening(C, S, tick, DASH_START, DURATION, RANGE, extraGap, onDash) {
        var self = C.p, dim = self.dimension;
        if (tick < DASH_START) {
            if (!canTarget(self, C.t)) return false;
            if (!S.origin) S.origin = pos(self);
            S.yaw = yawTowards(pos(self), pos(C.t));
            C.place(S.origin, S.yaw);
            return true;
        }
        if (tick === DASH_START) {
            var t = C.t;
            if (!canTarget(self, t) || t.dimension !== dim || self.distanceTo(t) > RANGE + 6) return false;
            if (!S.origin) S.origin = pos(self);
            S.yaw = yawTowards(pos(self), pos(t));
            S.start = pos(t); S.held = S.start;
            S.base = sub(S.start, mul(facing(S.yaw), gap(self, t, extraGap)));
            if (!fits(dim, self, S.base)) S.base = pos(self);
            S.victim = capture(self, t, DURATION);
            if (onDash) onDash();
        }
        return S.base ? null : false;
    }

    // =====================================================================================
    //  Meteor Burst (MeteorBurstCombo): dash, punch, launch, stomp ride, vanish below, knee, hammer slam, leap
    //  back, step in, a ki ball charged in the hand and pressed into the victim, six spheres, the blast
    // =====================================================================================
    var MB = (function () {
        var L = 4, DURATION = L + 197, RANGE = 14, CM = 0xA64DFF, CB = 0x6A3BFF, CO = 0x4A2CE0;
        var DASH_START = L, DASH_END = L + 6, PUNCH = L + 10, LAUNCH = L + 22, LAUNCH_END = L + 32, RISE_START = L + 26, RISE_END = L + 42,
            DIVE_START = L + 44, STOMP = L + 48, RIDE_END = L + 53, FALL_END = L + 59, VANISH = L + 58, KNEE = L + 63, HAMMER = L + 74,
            SLAM = L + 77, LEAP_START = L + 83, LEAP_END = L + 93, STEP_START = L + 96, STEP_END = L + 100, CHARGE_START = L + 125,
            THRUST = L + 157, BLAST = L + 175, BLAST_VIS = [L + 175, L + 183, L + 191], BLAST_SIZES = [5.0, 6.5, 5.5], WHITEOUT = L + 187,
            SHOTS = [L + 159, L + 162, L + 165, L + 168, L + 171, L + 174];
        var VICTIM_GAP = 0.35, HIT_NUDGE = 0.35, LAUNCH_HEIGHT = 5, OVER_HEIGHT = 1.2, STOMP_FALL = 3, KNEE_BUMP = 0.4, MAX_DROP = 30,
            LEAP_BACK = 1.8, LEAP_ARC = 1.5, FOOT_REACH = 0.55, HAND_HEIGHT = 0.9, HAND_SIDE = 0.45, BALL_START = 0.2, BALL_HAND = 0.9,
            BALL_PRESS = 1.6, MAX_VICTIM = 48, PUNCH_SHARE = 0.15, LAUNCH_SHARE = 0.15, STOMP_SHARE = 0.2, KNEE_SHARE = 0.15,
            SLAM_SHARE = 0.35, SHOT_SHARE = 0.1, BLAST_SHARE = 0.4, SHOT_SIZE = 0.7, SHOT_SPEED = 1.2;
        function hit(C, S, share, scale, sound) { strike(C, S, share, scale, sound, facing(S.yaw), 0xFFD27F); }
        function grounded(C, at) { return groundedWithin(C.p.dimension, at, MAX_DROP); }
        function ball(C, S, at, size, life) {
            C.fx(at, { t: "orb", id: "mb" + C.p.entityId, x: r2(at.x), y: r2(at.y), z: r2(at.z), s: r2(size), c: [hexs(CM), hexs(CB), hexs(CO)], life: life || 4 });
            S.ballOn = true;
        }
        function dropBall(C, S) { if (S.ballOn) { C.fx(C.p, { t: "orbx", id: "mb" + C.p.entityId }); S.ballOn = false; } }
        function tick(C, S, tick) {
            var self = C.p, dim = self.dimension;
            var o = opening(C, S, tick, DASH_START, DURATION, RANGE, VICTIM_GAP, function () { C.snd(pos(self), "zanzoken", 1.5, 0.9); });
            if (o !== null) return o;
            if (S.blasted) {
                C.place(S.foot, S.yaw);
                if (S.victim) {
                    if (alive(S.victim.e)) S.victim.hold(S.ground, S.yaw + 180);
                    else { S.victim.release(); S.victim = null; }
                }
                if (tick === WHITEOUT) C.frame(0.9, 0.05, 4, false);
                for (var i = 1; i < BLAST_VIS.length; i++) if (BLAST_VIS[i] === tick) boom(C, up(S.ground, 0.5), BLAST_SIZES[i], CM, CB, CO);
                return true;
            }
            if (!S.victim || !S.victim.valid(self, MAX_VICTIM)) return false;
            var victim = S.victim.e, f = facing(S.yaw), back = S.yaw + 180, vh = height(victim);
            if (tick < LAUNCH) {
                var dash = smooth(clamp01((tick - DASH_START) / (DASH_END - DASH_START)));
                C.place(lerp(S.origin, S.base, dash), S.yaw);
                S.held = lerp(S.held, S.start, 0.35);
                if (tick === PUNCH) { S.held = add(S.start, mul(f, HIT_NUDGE)); hit(C, S, PUNCH_SHARE, 1.6, "punch3"); S.victim.flinch(); }
                S.victim.hold(S.held, back);
                return true;
            }
            if (tick < DIVE_START) {
                if (tick === LAUNCH) {
                    S.apex = clearAbove(dim, victim, S.start, LAUNCH_HEIGHT);
                    S.over = up(S.apex, vh + OVER_HEIGHT);
                    hit(C, S, LAUNCH_SHARE, 1.8, "critic_punch2");
                    S.victim.launched();
                    C.snd(S.start, "evasion1", 1.4, 0.8);
                }
                S.held = lerp(S.start, S.apex, easeOut(clamp01((tick - LAUNCH) / (LAUNCH_END - LAUNCH))));
                S.victim.hold(S.held, back);
                C.place(lerp(S.base, S.over, smooth(clamp01((tick - RISE_START) / (RISE_END - RISE_START)))), S.yaw);
                return true;
            }
            if (tick < VANISH) {
                if (tick === DIVE_START) { S.chest = up(S.apex, vh * 0.35); C.snd(S.over, "evasion2", 1.4, 0.9); }
                if (tick === STOMP) {
                    var floor = groundHeight(dim, S.apex.x, S.apex.z, S.apex.y);
                    S.fallEnd = up(S.apex, -Math.max(0, Math.min(STOMP_FALL, S.apex.y - (floor + 1.5))));
                    hit(C, S, STOMP_SHARE, 2.2, "critic_punch1");
                    S.victim.knockDown();
                }
                if (tick < STOMP) {
                    var dv = (tick - DIVE_START) / (STOMP - DIVE_START);
                    S.victim.hold(S.apex, back);
                    C.place(lerp(S.over, S.chest, dv * dv), S.yaw);
                    return true;
                }
                S.held = lerp(S.apex, S.fallEnd, easeOut(clamp01((tick - STOMP) / (FALL_END - STOMP))));
                S.victim.hold(S.held, back);
                if (tick <= RIDE_END) C.place(up(S.held, vh * 0.35), S.yaw);
                if (tick === RIDE_END + 1) C.frame(0.7, 0.05, 2, false);
                return true;
            }
            if (tick < HAMMER) {
                if (tick === VANISH) {
                    S.below = up(sub(S.fallEnd, mul(f, gap(self, victim, VICTIM_GAP))), -0.6);
                    after(C, pos(self), S.yaw);
                    C.snd(S.below, "zanzoken", 1.5, 1.3);
                }
                var at = lerp(S.apex, S.fallEnd, easeOut(clamp01((tick - STOMP) / (FALL_END - STOMP))));
                if (tick >= KNEE) at = up(S.fallEnd, KNEE_BUMP * easeOut(clamp01((tick - KNEE) / 2)));
                if (tick === KNEE) { hit(C, S, KNEE_SHARE, 1.8, "punch6"); S.victim.flinch(); }
                S.held = at;
                S.victim.hold(S.held, back);
                C.place(S.below, S.yaw);
                return true;
            }
            if (tick <= SLAM) {
                if (tick === HAMMER) {
                    S.land = grounded(C, S.below);
                    S.ground = grounded(C, S.held);
                    C.frame(0.75, 0.05, 2, true);
                    C.snd(S.held, "evasion2", 1.6, 0.7);
                }
                var dive = Math.pow((tick - HAMMER) / (SLAM - HAMMER), 2);
                S.victim.hold(lerp(up(S.fallEnd, KNEE_BUMP), S.ground, dive), back);
                C.place(lerp(S.below, S.land, dive), S.yaw);
                if (tick === SLAM) {
                    hit(C, S, SLAM_SHARE, 3.0, "critic_punch1");
                    S.victim.knockOut();
                    groundImpact(C, S.ground, 5.0, 0xFFE0A0, 40, 0);
                    C.shake(true, 12);
                }
                return true;
            }
            S.victim.hold(S.ground, back);
            if (tick < LEAP_START) { C.place(S.land, S.yaw); return true; }
            if (!S.side) {
                var wanted = sub(S.ground, mul(f, LEAP_BACK + width(victim) * 0.5));
                S.side = grounded(C, wanted);
                if (Math.abs(S.side.y - S.ground.y) > 3) S.side = V(wanted.x, S.ground.y, wanted.z);
                var fw = sub(S.ground, mul(f, width(victim) * 0.5 + FOOT_REACH));
                S.foot = V(fw.x, S.side.y, fw.z);
            }
            if (tick <= LEAP_END) {
                var u = (tick - LEAP_START) / (LEAP_END - LEAP_START);
                C.place(up(lerp(S.land, S.side, u), Math.sin(u * Math.PI) * LEAP_ARC), S.yaw);
                if (tick === LEAP_END) C.snd(S.side, "knockback_character", 0.8, 1.3);
                return true;
            }
            if (tick < STEP_START) { C.place(S.side, S.yaw); return true; }
            if (tick <= STEP_END) {
                C.place(lerp(S.side, S.foot, smooth((tick - STEP_START) / (STEP_END - STEP_START))), S.yaw);
                if (tick === STEP_END) C.snd(S.ground, "punch2", 1.0, 0.7);
                return true;
            }
            C.place(S.foot, S.yaw);
            if (tick < THRUST) {
                if (tick >= CHARGE_START) {
                    var right = facing(S.yaw + 90), hand = sub(add(up(S.foot, HAND_HEIGHT), mul(right, HAND_SIDE)), mul(f, 0.15));
                    var grow = (tick - CHARGE_START) / (THRUST - CHARGE_START);
                    ball(C, S, hand, BALL_START + (BALL_HAND - BALL_START) * grow);
                    if ((tick - CHARGE_START) % 20 === 0) C.snd(hand, "ki_charge_loop", 1.2, 1.2);
                }
                return true;
            }
            if (tick === THRUST) {
                C.frame(0.8, 0.05, 3, true);
                C.shake(false, 10);
                C.snd(S.ground, "ki_beam_fire", 2.0, 0.6);
            }
            if (tick < BLAST) {
                var press = (tick - THRUST) / (BLAST - THRUST);
                ball(C, S, up(S.ground, 0.4), BALL_HAND + (BALL_PRESS - BALL_HAND) * press);
                for (var k = 0; k < SHOTS.length; k++) if (SHOTS[k] === tick) fireSphere(C, S);
                return true;
            }
            // blast: the ki budget's 40 % on the victim, the purple explosion, a white-out
            dropBall(C, S);
            S.blasted = true;
            C.kiHit(victim, C.kiBudget * BLAST_SHARE, true);
            if (alive(victim)) S.victim.hold(S.ground, back);
            else { S.victim.release(); S.victim = null; }
            boom(C, up(S.ground, 0.5), BLAST_SIZES[0], CM, CB, CO);
            C.frame(0.85, 0.05, 3, true);
            C.shake(true, 16);
            shock(C, up(S.ground, 0.2), 10, CB, 18);
            C.snd(S.ground, "ki_explosion_impact", 3.5, 0.7);
            return true;
        }
        // fireSphere: a small ki blast from the right hand at the victim (20 ticks, no terrain damage)
        function fireSphere(C, S) {
            var f = facing(S.yaw), right = facing(S.yaw + 90);
            var from = add(add(up(S.foot, 1.1), mul(f, 0.8)), mul(right, HAND_SIDE * 0.7)), aim = up(S.ground, 0.5), d = norm(sub(aim, from));
            if (typeof DMZ_VOLLEY !== "undefined") DMZ_VOLLEY.shoot(C.p, { x: from.x, y: from.y, z: from.z, vx: d.x * SHOT_SPEED, vy: d.y * SHOT_SPEED, vz: d.z * SHOT_SPEED,
                dmg: C.kiBudget * SHOT_SHARE, tech: "meteor_burst", colors: { core: hexs(CM), border: hexs(CB), outline: hexs(CO) }, life: 20, noBlocks: true, size: SHOT_SIZE });
            C.snd(from, "kiblast_shoot", 1.3, pitchJitter(0.9, 0.3));
        }
        return { DURATION: DURATION, RANGE: RANGE, tick: tick, release: function (C, S) { dropBall(C, S); } };
    })();

    // =====================================================================================
    //  Mystic Ball Attack (MysticBallCombo): a kick up, the caster curls into a ball and bounces off the victim
    //  six times from random sides, rises, dives and stomps it into the ground, then flips back and lands
    // =====================================================================================
    var MY = (function () {
        var L = 4, DURATION = L + 92, CM = 0xFF82F3, CD = 0xFF1AEC;
        var KICK = L + 5, LAUNCH_END = L + 15, CURL = L + 14, BOUNCES = [L + 20, L + 26, L + 32, L + 38, L + 44, L + 50], RISE_END = L + 54,
            DIVE_START = L + 56, STOMP = L + 61, QUAKE = L + 63, PRESS_END = L + 66, LAND = L + 73;
        var LAUNCH_HEIGHT = 4.5, CASTER_LIFT = 0.75, BOUNCE_R = 5, MIN_BOUNCE_R = 2.5, CONTACT_GAP = 0.45, BALL_CENTER = 0.75, BALL_R = 0.8,
            RISE_HEIGHT = 4.5, HIT_PUSH = 0.5, FLIP_BACK = 2.8, FLIP_ARC = 1.8, MAX_VICTIM = 48, MAX_LAND_DROP = 10, MAX_SLAM_DROP = 24, STOMP_SPEED = 3.2,
            KICK_SHARE = 0.17, BOUNCE_SHARE = 0.08, STOMP_SHARE = 0.35;
        function centerOf(S) { var v = S.victim.e; return S.victim.pinned ? up(S.hover, height(v) * 0.5) : center(v); }
        function contact(v) { return width(v) * 0.5 + CONTACT_GAP + BALL_R * 0.5; }
        function clearReach(dim, from, dir, wanted) {
            var h = clip(dim, from, add(from, mul(dir, wanted)));
            return Math.max(MIN_BOUNCE_R, h ? h.d - BALL_R : wanted);
        }
        function flatten(d, fallbackYaw) { var fl = V(d.x, 0, d.z); return dot(fl, fl) < 1e-4 ? facing(fallbackYaw) : norm(fl); }
        function pickDirection(C, S, prev) {
            var dim = C.p.dimension, c = centerOf(S), ct = contact(S.victim.e), baseYaw = Math.atan2(prev.z, prev.x) * 180 / Math.PI, best = null, br = -1;
            for (var a = 0; a < 6; a++) {
                var turn = 110 + Math.random() * 60, yaw = baseYaw + (Math.random() < 0.5 ? turn : -turn), pitch = -20 + Math.random() * 60;
                var cp = Math.cos(pitch * Math.PI / 180), d = V(Math.cos(yaw * Math.PI / 180) * cp, Math.sin(pitch * Math.PI / 180), Math.sin(yaw * Math.PI / 180) * cp);
                var reach = clearReach(dim, c, d, BOUNCE_R + ct);
                if (reach > br) { best = d; br = reach; }
                if (reach >= BOUNCE_R + ct - 0.01) break;
            }
            return best;
        }
        function moveBall(C, S, b) { S.ball = b; C.feet(up(b, -BALL_CENTER)); }
        function tick(C, S, tick) {
            var self = C.p, dim = self.dimension;
            if (!S.base) {
                var t = C.t;
                if (!canTarget(self, t) || t.dimension !== dim) return false;
                S.base = pos(self); S.yaw = self.yaw;
                S.victim = capture(self, t, DURATION);
                S.start = pos(t); S.hover = S.start; S.hoverGoal = S.start;
            }
            if (tick > STOMP) return finish(C, S, tick);
            if (!S.victim || !S.victim.valid(self, MAX_VICTIM)) return false;
            var victim = S.victim.e;
            if (tick < CURL) { kick(C, S, tick); return true; }
            if (S.victim.pinned) {
                S.hover = lerp(S.hover, S.hoverGoal, 0.5);
                S.victim.hold(S.hover, yawTowards(S.hover, S.ball || pos(self)));
            }
            if (tick === CURL) {
                S.ball = up(pos(self), BALL_CENTER);
                S.from = S.ball;
                S.fromDir = flatten(sub(S.ball, centerOf(S)), S.yaw + 180);
                S.toDir = pickDirection(C, S, S.fromDir);
                S.reach = clearReach(dim, centerOf(S), S.toDir, BOUNCE_R + contact(victim));
                S.bounce = 0;
                C.snd(S.ball, "staff_spin", 1.4, 1.3);
                C.fx(self, { t: "mball", e: self.entityId, life: STOMP - CURL + 1, c: hexs(CM) });
            }
            if (S.bounce < BOUNCES.length) bounce(C, S, tick);
            else if (tick <= RISE_END) {
                var st = BOUNCES[BOUNCES.length - 1], u = (tick - st) / (RISE_END - st);
                var dir = slerp(S.fromDir, V(0, 1, 0), smooth(u)), rad = len(sub(S.from, centerOf(S))) + (S.reach - len(sub(S.from, centerOf(S)))) * easeOut(u);
                moveBall(C, S, add(centerOf(S), mul(dir, rad)));
                if (tick === RISE_END) { S.above = S.ball; C.snd(S.ball, "ki_explosion_charge", 1.2, 1.6); }
            } else if (tick < DIVE_START) moveBall(C, S, S.above);
            else {
                var u2 = (tick - DIVE_START) / (STOMP - DIVE_START), top = up(centerOf(S), height(victim) * 0.5 + BALL_CENTER);
                moveBall(C, S, lerp(S.above, top, u2 * u2 * u2));
                if (tick === DIVE_START) C.snd(S.above, "evasion2", 1.6, 0.7);
                if (tick === STOMP) stomp(C, S);
            }
            return true;
        }
        function kick(C, S, tick) {
            var back = S.yaw + 180;
            if (tick < KICK) { C.feet(S.base); S.victim.hold(S.start, back); return; }
            if (tick === KICK) {
                var v = S.victim.e;
                C.strikeHit(v, C.strikeBudget * KICK_SHARE, false);
                S.victim.launched();
                S.apex = clearAbove(C.p.dimension, v, S.start, LAUNCH_HEIGHT);
                var at = up(pos(v), height(v) * 0.35);
                burst(C, at, V(0, 1, 0), 4.2, CM, CD, false, 14);
                C.frame(0.65, 0.05, 2, false);
                C.shake(false, 8);
                C.snd(at, "critic_punch2", 2.2, 1.0);
                C.snd(at, "evasion1", 1.4, 0.7);
            }
            var lift = easeOut(clamp01((tick - KICK) / (LAUNCH_END - KICK)));
            S.hover = lerp(S.start, S.apex, lift);
            S.hoverGoal = S.apex;
            S.victim.hold(S.hover, back);
            C.feet(up(S.base, (S.apex.y - S.start.y) * CASTER_LIFT * lift));
        }
        function bounce(C, S, tick) {
            var v = S.victim.e, dim = C.p.dimension, st = S.bounce === 0 ? CURL : BOUNCES[S.bounce - 1], ht = BOUNCES[S.bounce];
            var u = clamp01((tick - st) / (ht - st)), c = centerOf(S), sr = len(sub(S.from, c)), ct = contact(v), inb = (u - 0.5) * 2;
            var rad = u < 0.5 ? sr + (S.reach - sr) * easeOut(u * 2) : S.reach + (ct - S.reach) * inb * inb * inb;
            moveBall(C, S, add(c, mul(slerp(S.fromDir, S.toDir, smooth(u)), rad)));
            if (tick !== ht) return;
            C.strikeHit(v, C.strikeBudget * BOUNCE_SHARE, false);
            S.victim.flinch();
            var at = add(c, mul(S.toDir, ct - CONTACT_GAP));
            burst(C, at, mul(S.toDir, -1), 3.0, CM, CD, false, 10);
            C.shake(false, 6);
            C.snd(at, punchSound(), 2.0, pitchJitter(0.8, 0.3));
            C.snd(at, "knockback_character", 0.8, pitchJitter(1.4, 0.2));
            if (S.victim.pinned) {
                var pushed = add(S.hoverGoal, mul(S.toDir, -HIT_PUSH));
                if (fits(dim, v, pushed)) S.hoverGoal = pushed;
            }
            S.bounce++;
            S.from = S.ball; S.fromDir = S.toDir;
            if (S.bounce < BOUNCES.length) {
                S.toDir = pickDirection(C, S, S.fromDir);
                S.reach = clearReach(dim, centerOf(S), S.toDir, BOUNCE_R + ct);
            } else S.reach = clearReach(dim, centerOf(S), V(0, 1, 0), RISE_HEIGHT + ct);
            C.snd(S.ball, "staff_spin", 1.3, pitchJitter(1.2, 0.3));
        }
        function stomp(C, S) {
            var v = S.victim.e, pinned = S.victim.pinned, feet = up(S.ball, -BALL_CENTER), dim = C.p.dimension;
            S.press = feet;
            C.strikeHit(v, C.strikeBudget * STOMP_SHARE, true);
            burst(C, feet, V(0, -1, 0), 6.5, CM, CD, false, 18);
            C.frame(0.8, 0.05, 3, true);
            C.shake(true, 14);
            shock(C, feet, 4.0, CD, 10);
            C.snd(feet, "critic_punch1", 3.0, 0.75);
            C.snd(feet, "anchor_slam", 2.0, 1.1);
            if (!alive(v)) { S.victim.release(); S.victim = null; return; }
            S.stomped = v;
            S.victim.knockDown();
            if (!pinned) return;
            S.slamFrom = pos(v);
            var floor = groundHeight(dim, S.slamFrom.x, S.slamFrom.z, S.slamFrom.y + 0.5);
            if (S.slamFrom.y - floor <= MAX_SLAM_DROP) { S.ground = V(S.slamFrom.x, floor, S.slamFrom.z); return; }
            S.victim.release(); S.victim = null;
            try { v.setVelocity(0, -STOMP_SPEED, 0); } catch (x) { }
        }
        function finish(C, S, tick) {
            var dim = C.p.dimension;
            if (!S.press) return false;
            var st = S.stomped, riding = !!st && alive(st) && st.dimension === dim && dist(pos(st), S.press) < 8;
            if (S.victim && !riding) { S.victim.release(); S.victim = null; }
            if (S.victim && S.ground) {
                var u = clamp01((tick - STOMP) / (QUAKE - STOMP));
                S.victim.hold(lerp(S.slamFrom, S.ground, u * u), S.yaw + 180);
            }
            if (tick <= PRESS_END) {
                if (riding) S.press = up(pos(st), height(st));
                C.feet(S.press);
                if (tick === QUAKE) {
                    var at = S.ground || (riding ? pos(st) : S.press), g = V(at.x, groundHeight(dim, at.x, at.z, at.y + 0.5), at.z);
                    rocks(C, up(g, 0.2), 45, 1.6, 0.3, 0.35);
                    dust(C, up(g, 0.2), 70, 2.2, 0.4, 0.12);
                    particle(C, up(g, 0.5), "minecraft:explosion", 2, 0.6, 0);
                    shock(C, up(g, 0.2), 7.0, CM, 16);
                    shock(C, up(g, 0.2), 11.0, CD, 20);
                    C.snd(g, "ki_explosion_impact", 2.2, 0.8);
                }
                return true;
            }
            if (!S.landing) {
                var back = mul(facing(S.yaw), -FLIP_BACK);
                var wanted = up(clearPoint(dim, up(S.press, BALL_CENTER), up(add(S.press, back), BALL_CENTER), BALL_R), -BALL_CENTER);
                var floor = groundHeight(dim, wanted.x, wanted.z, S.press.y + 1);
                S.landing = S.press.y - floor <= MAX_LAND_DROP ? V(wanted.x, floor, wanted.z) : wanted;
                C.snd(S.press, "evasion1", 1.2, 1.2);
            }
            if (tick < LAND) {
                var u2 = (tick - PRESS_END) / (LAND - PRESS_END);
                C.feet(up(lerp(S.press, S.landing, u2), Math.sin(u2 * Math.PI) * FLIP_ARC));
                return true;
            }
            C.feet(S.landing);
            if (tick === LAND) { dust(C, up(S.landing, 0.1), 16, 0.6, 0.1, 0.05); C.snd(S.landing, "knockback_character", 1.0, 1.3); }
            return true;
        }
        return { DURATION: DURATION, RANGE: 0, tick: tick, release: function () { } };
    })();

    // =====================================================================================
    //  Darkness Eye Beam (DarknessEyeBeamCombo): backhand, grab, three punches, choke lift, the arm stretches to
    //  throw and catch, a swing and an overhead fling, a roar, two eye lasers, the blast
    // =====================================================================================
    var EB = (function () {
        var L = 4, DURATION = L + 98, RANGE = 14, CM = 0xFFD23A, CB = 0xFF8A00, CO = 0xE84A00;
        var DASH_START = L, DASH_END = L + 3, BACKHAND = L + 4, GRAB = L + 8, PUNCHES = [L + 11, L + 15, L + 19], CHOKE_START = L + 22,
            CHOKE_END = L + 25, THROW = L + 28, THROW_END = L + 36, STRETCH_START = L + 33, STRETCH_GRAB = L + 37, RETRACT_START = L + 39,
            RETRACT_END = L + 44, SWING_END = L + 47, FLING = L + 50, FLING_END = L + 60, ROAR = L + 57, GLOW_START = L + 58, BEAM_START = L + 68,
            BEAM_EVERY = 2, BLAST = L + 88, BLAST_VIS = [L + 88, L + 92], BLAST_SIZES = [4.5, 6.0], BEAM_LIFE = BLAST - BEAM_START + 2;
        var VICTIM_GAP = 0.3, BACKHAND_PUSH = 0.45, PUNCH_NUDGE = 0.2, CHOKE_LIFT = 0.7, SHOULDER_H = 22 / 16, SHOULDER_SIDE = 5 / 16,
            ARM_FORWARD = 81 / 16, ARM_RISE = 12 / 16, GRIP_DROP = 0.75, SWING_SIDE = 1.4, SWING_BACK = 0.6, OVERHEAD_FWD = 1.0, OVERHEAD_H = 2.6,
            FLING_FWD = 9, FLING_H = 5, EYE_SIDE = 0.12, EYE_FWD = 0.3, MAX_VICTIM = 48, BACKHAND_SHARE = 0.15, PUNCH_SHARE = 0.1,
            THROW_SHARE = 0.15, STRETCH_SHARE = 0.1, FLING_SHARE = 0.3, BEAM_SHARE = 0.04, BLAST_SHARE = 0.6, BEAM_SIZE = 0.35;
        function hit(C, S, share, scale, sound, dir) { strike(C, S, share, scale, sound, dir, 0xFFD27F); }
        function aim(S) {
            if (S.victim && !S.victim.pinned) return center(S.victim.e);
            return up(S.held, S.victim ? height(S.victim.e) * 0.5 : 0.9);
        }
        function eye(S, side) { return add(add(up(S.base, 1.62), mul(facing(S.yaw), EYE_FWD)), mul(facing(S.yaw + 90), EYE_SIDE * side)); }
        function eyeGlow(C, S, size) {
            for (var i = 0; i < 2; i++) { var e = eye(S, i === 0 ? 1 : -1); RPG.world.particle(C.p.dimension, "minecraft:dust 1 0.85 0.3 " + size, e.x, e.y, e.z, 1, 0, 0); }
        }
        function lasers(C, S, life) {
            var a = aim(S);
            for (var i = 0; i < 2; i++) {
                var e = eye(S, i === 0 ? 1 : -1);
                C.fx(e, { t: "laser", id: "eb" + C.p.entityId + "_" + i, a: [r2(e.x), r2(e.y), r2(e.z)], b: [r2(a.x), r2(a.y), r2(a.z)], w: BEAM_SIZE,
                    c: [hexs(0xFFFFFF), hexs(CB), hexs(CO)], life: life });
            }
        }
        function tick(C, S, tick) {
            var self = C.p, dim = self.dimension;
            var o = opening(C, S, tick, DASH_START, DURATION, RANGE, VICTIM_GAP, function () { after(C, pos(self), S.yaw); C.snd(pos(self), "zanzoken", 1.5, 0.8); });
            if (o !== null) return o;
            if (S.blasted) {
                C.place(S.base, S.yaw);
                if (S.victim) { if (alive(S.victim.e)) S.victim.hold(S.held, S.yaw + 180); else { S.victim.release(); S.victim = null; } }
                for (var i = 1; i < BLAST_VIS.length; i++) if (BLAST_VIS[i] === tick) boom(C, aim(S), BLAST_SIZES[i], CM, CB, CO);
                return true;
            }
            if (!S.victim || !S.victim.valid(self, MAX_VICTIM)) return false;
            var v = S.victim.e, f = facing(S.yaw), right = facing(S.yaw + 90), back = S.yaw + 180;
            if (tick < CHOKE_START) {
                C.place(lerp(S.origin, S.base, smooth(clamp01((tick - DASH_START) / (DASH_END - DASH_START)))), S.yaw);
                if (!S.front) S.front = S.start;
                S.held = lerp(S.held, S.front, 0.35);
                if (tick === BACKHAND) { S.held = add(S.start, mul(right, BACKHAND_PUSH)); hit(C, S, BACKHAND_SHARE, 2.2, "critic_punch2", right); S.victim.flinch(); }
                if (tick === GRAB) { S.front = add(S.base, mul(f, gap(self, v, VICTIM_GAP) - 0.1)); S.victim.grabbed(); C.snd(S.front, "punch2", 1.0, 0.7); }
                if (PUNCHES.indexOf(tick) >= 0) { S.held = add(S.front, mul(f, PUNCH_NUDGE)); hit(C, S, PUNCH_SHARE, 1.6, punchSound(), f); S.victim.flinch(); }
                S.victim.hold(S.held, back);
                return true;
            }
            if (tick < THROW) {
                C.place(S.base, S.yaw);
                if (tick === CHOKE_START) S.victim.grabbed();
                S.held = up(S.front, CHOKE_LIFT * smooth(clamp01((tick - CHOKE_START) / (CHOKE_END - CHOKE_START))));
                S.victim.hold(S.held, back);
                if (tick === CHOKE_END) C.snd(S.held, "knockback_character", 1.0, 0.6);
                return true;
            }
            if (tick < STRETCH_GRAB) {
                C.place(S.base, S.yaw);
                if (tick === THROW) {
                    var sh = add(up(S.base, SHOULDER_H), mul(right, SHOULDER_SIDE));
                    var tip = clearPoint(dim, sh, up(add(sh, mul(f, ARM_FORWARD)), ARM_RISE), width(v) * 0.5 + 0.2);
                    S.hand = up(tip, -height(v) * GRIP_DROP);
                    S.front = S.held;
                    hit(C, S, THROW_SHARE, 2.4, "critic_punch1", f);
                    S.victim.launched();
                    C.snd(S.held, "evasion1", 1.4, 0.7);
                }
                S.held = lerp(S.front, S.hand, easeOut(clamp01((tick - THROW) / (THROW_END - THROW))));
                S.victim.hold(S.held, back);
                if (tick === STRETCH_START) C.snd(S.base, "evasion2", 1.6, 0.6);
                return true;
            }
            if (tick < FLING) {
                C.place(S.base, S.yaw);
                if (tick === STRETCH_GRAB) {
                    hit(C, S, STRETCH_SHARE, 2.0, "punch6", f);
                    S.victim.grabbed();
                    S.front = up(add(S.base, mul(f, gap(self, v, VICTIM_GAP))), CHOKE_LIFT);
                }
                if (tick < RETRACT_START) S.held = S.hand;
                else if (tick <= RETRACT_END) {
                    S.held = lerp(S.hand, S.front, smooth((tick - RETRACT_START) / (RETRACT_END - RETRACT_START)));
                    if (tick === RETRACT_START) C.snd(S.hand, "evasion1", 1.4, 1.2);
                } else if (tick <= SWING_END) {
                    var u = smooth((tick - RETRACT_END) / (SWING_END - RETRACT_END));
                    var side = up(clearPoint(dim, up(S.base, 1), up(sub(add(S.base, mul(right, SWING_SIDE)), mul(f, SWING_BACK)), 1.3), 0.3), -1);
                    S.held = lerp(S.front, side, u);
                    if (tick === SWING_END) { S.start = side; C.snd(side, "staff_spin", 1.4, 0.7); }
                } else {
                    var u3 = (tick - SWING_END) / (FLING - SWING_END);
                    var over = up(clearPoint(dim, up(S.base, 1), up(add(S.base, mul(f, OVERHEAD_FWD)), OVERHEAD_H + 1), 0.3), -1);
                    var top = up(add(S.base, mul(right, SWING_SIDE * 0.5)), OVERHEAD_H + 0.6);
                    S.held = bezier(S.start, top, over, u3 * u3);
                }
                S.victim.hold(S.held, back);
                return true;
            }
            if (tick < BEAM_START) {
                C.place(S.base, S.yaw);
                if (tick === FLING) {
                    S.front = S.held;
                    var want = up(add(S.base, mul(f, FLING_FWD)), FLING_H);
                    S.far = up(clearPoint(dim, up(S.held, 1), up(want, 1), width(v) * 0.5 + 0.3), -1);
                    hit(C, S, FLING_SHARE, 3.0, "critic_punch1", f);
                    S.victim.launched();
                    C.frame(0.75, 0.05, 2, false);
                    C.shake(false, 10);
                    C.snd(S.held, "evasion2", 1.8, 0.6);
                }
                S.held = lerp(S.front, S.far, easeOut(clamp01((tick - FLING) / (FLING_END - FLING))));
                S.victim.hold(S.held, back);
                if (tick === ROAR) {                              // roar(): rage scream, a full ki burst, the ring and dust, the growl
                    C.fx(self, { t: "scream", e: self.entityId, life: BEAM_START - ROAR });
                    C.shake(true, 12);
                    shock(C, up(S.base, 0.2), 6.0, CB, 16);
                    dust(C, up(S.base, 0.1), 40, 1.8, 0.1, 0.08);
                    C.snd(S.base, "oozaru_growl_player", 2.0, 1.25);
                    C.snd(S.base, "ki_explosion_charge", 1.6, 0.8);
                }
                if (tick >= GLOW_START && (tick - GLOW_START) % 2 === 0) eyeGlow(C, S, 0.6);
                return true;
            }
            C.place(S.base, S.yaw);
            S.victim.hold(S.held, back);
            if (tick === BEAM_START) {
                lasers(C, S, BEAM_LIFE);
                C.frame(0.8, 0.05, 3, true);
                C.snd(S.base, "laserbeam", 2.5, 0.8);
                C.snd(S.base, "ki_beam_fire", 2.0, 1.3);
            }
            if (tick < BLAST) {
                if ((tick - BEAM_START) % BEAM_EVERY === 1) {
                    C.kiHit(v, C.kiBudget * BEAM_SHARE, false);
                    var at = aim(S);
                    burst(C, at, f, 2.2, CM, CB, false, 8);
                    RPG.world.particle(dim, "minecraft:dust 1 0.75 0.2 2", at.x, at.y, at.z, 10, 0.4, 0);
                    C.snd(at, "kiblast_shoot", 1.2, pitchJitter(1.1, 0.3));
                }
                eyeGlow(C, S, 1.0);
                return true;
            }
            // blast
            C.fx(self, { t: "laserx", id: "eb" + self.entityId + "_0" }); C.fx(self, { t: "laserx", id: "eb" + self.entityId + "_1" });
            S.blasted = true;
            var ba = aim(S);
            C.kiHit(v, C.kiBudget * BLAST_SHARE, true);
            if (alive(v)) S.victim.knockOut(); else { S.victim.release(); S.victim = null; }
            boom(C, ba, BLAST_SIZES[0], CM, CB, CO);
            C.frame(0.9, 0.05, 4, false);
            shock(C, ba, 9.0, CB, 18);
            C.snd(ba, "ki_explosion_impact", 3.5, 0.7);
            return true;
        }
        return { DURATION: DURATION, RANGE: RANGE, tick: tick,
            release: function (C, S) { C.fx(C.p, { t: "laserx", id: "eb" + C.p.entityId + "_0" }); C.fx(C.p, { t: "laserx", id: "eb" + C.p.entityId + "_1" }); } };
    })();

    // =====================================================================================
    //  Death Chaser (DeathChaserCombo): power up, hook, straight that knocks the victim down the ground, vanish
    //  beside it, knee, launch, appear above, hammer down, a stomp, two grinds, the crush, a leap back
    // =====================================================================================
    var DC = (function () {
        var L = 4, DURATION = L + 68, RANGE = 14, CM = 0xB57CFF, CD = 0x6A2BD9;
        var POWER = L + 2, DASH_START = L + 4, DASH_END = L + 6, HOOK = L + 7, STRAIGHT = L + 10, SLIDE_END = L + 18, VANISH = L + 19,
            KNEE = L + 21, RISE = L + 26, RISE_END = L + 34, VANISH2 = L + 31, APPEAR_ABOVE = L + 33, HAMMER = L + 35, SLAM = L + 39,
            DIVE_START = L + 41, STOMP = L + 46, GRINDS = [L + 50, L + 53], CRUSH = L + 56, LEAP_START = L + 57, LEAP_END = L + 63;
        var VICTIM_GAP = 0.3, HOOK_NUDGE = 0.3, KNOCK_DIST = 3.5, KNEE_BUMP = 0.5, LAUNCH_HEIGHT = 7, OVER_HEIGHT = 0.8, STAND_HEIGHT = 0.35,
            LEAP_BACK = 2.2, LEAP_ARC = 1.8, MAX_DROP = 30, MAX_VICTIM = 48, HOOK_SHARE = 0.1, STRAIGHT_SHARE = 0.12, KNEE_SHARE = 0.12,
            RISE_SHARE = 0.13, HAMMER_SHARE = 0.18, STOMP_SHARE = 0.15, GRIND_SHARE = 0.05, CRUSH_SHARE = 0.1;
        function hit(C, S, share, scale, sound, dir) { strike(C, S, share, scale, sound, dir, CM); }
        function grounded(C, at) { return groundedWithin(C.p.dimension, at, MAX_DROP); }
        function gi(C, at, scale) { rocks(C, up(at, 0.2), 40, scale * 0.3, 0.3, 0.25); dust(C, up(at, 0.2), 50, scale * 0.35, 0.3, 0.1); shock(C, up(at, 0.2), scale, CM, 14); C.snd(at, "knockback_character", 2.0, 0.7); }
        function tick(C, S, tick) {
            var self = C.p, dim = self.dimension;
            if (tick < DASH_START && tick === POWER && canTarget(self, C.t)) {
                C.shake(true, 8);
                shock(C, up(pos(self), 0.1), 3.5, CM, 10);
                C.snd(pos(self), "aura_start", 1.4, 0.9);
            }
            var o = opening(C, S, tick, DASH_START, DURATION, RANGE, VICTIM_GAP, function () { after(C, pos(self), S.yaw); C.shake(false, 6); C.snd(pos(self), "zanzoken", 1.5, 0.9); });
            if (o !== null) return o;
            if (S.crushed) {
                if (S.victim) { if (alive(S.victim.e)) S.victim.hold(S.ground, S.yaw + 180); else { S.victim.release(); S.victim = null; } }
                if (!S.land) {
                    var w = sub(S.ground, mul(facing(S.yaw), LEAP_BACK));
                    S.land = grounded(C, w);
                    if (Math.abs(S.land.y - S.ground.y) > 3) S.land = V(w.x, S.ground.y, w.z);
                }
                if (tick < LEAP_START) { C.place(S.stand, S.yaw); return true; }
                var u = clamp01((tick - LEAP_START) / (LEAP_END - LEAP_START));
                C.place(up(lerp(S.stand, S.land, u), Math.sin(u * Math.PI) * LEAP_ARC), S.yaw);
                if (tick === LEAP_START) C.snd(S.stand, "evasion1", 1.2, 1.2);
                if (tick === LEAP_END) { dust(C, up(S.land, 0.1), 12, 0.5, 0.1, 0.04); C.snd(S.land, "knockback_character", 0.8, 1.3); }
                return true;
            }
            if (!S.victim || !S.victim.valid(self, MAX_VICTIM)) return false;
            var v = S.victim.e, f = facing(S.yaw), back = S.yaw + 180;
            if (tick < VANISH) {
                C.place(lerp(S.origin, S.base, smooth(clamp01((tick - DASH_START) / (DASH_END - DASH_START)))), S.yaw);
                if (tick < STRAIGHT) {
                    S.held = lerp(S.held, S.start, 0.4);
                    if (tick === HOOK) { S.held = add(S.start, mul(f, HOOK_NUDGE)); hit(C, S, HOOK_SHARE, 1.8, "punch4", f); S.victim.flinch(); }
                } else {
                    if (tick === STRAIGHT) {
                        S.knock = grounded(C, up(clearPoint(dim, up(S.start, 1), up(add(S.start, mul(f, KNOCK_DIST)), 1), width(v) * 0.5 + 0.2), -1));
                        hit(C, S, STRAIGHT_SHARE, 2.4, "critic_punch2", f);
                        S.victim.knockDown();
                        C.frame(0.65, 0.05, 2, false);
                        C.snd(S.start, "evasion1", 1.3, 0.8);
                    }
                    var sl = easeOut(clamp01((tick - STRAIGHT) / (SLIDE_END - STRAIGHT)));
                    S.held = up(lerp(S.start, S.knock, sl), Math.sin(sl * Math.PI) * 0.6);
                    if (tick === SLIDE_END) { dust(C, up(S.knock, 0.1), 14, 0.5, 0.1, 0.04); C.snd(S.knock, "knockback_character", 1.2, 0.8); }
                }
                S.victim.hold(S.held, back);
                return true;
            }
            if (tick < RISE) {
                if (tick === VANISH) {
                    var from = pos(self), want = sub(S.knock, mul(f, gap(self, v, VICTIM_GAP)));
                    S.base = fits(dim, self, want) ? want : from;
                    after(C, from, S.yaw);
                    C.snd(S.base, "zanzoken", 1.5, 1.2);
                }
                C.place(S.base, S.yaw);
                S.held = S.knock;
                if (tick === KNEE) { hit(C, S, KNEE_SHARE, 2.2, "punch6", V(0, 1, 0)); S.victim.flinch(); }
                if (tick >= KNEE) S.held = up(S.knock, KNEE_BUMP * easeOut(clamp01((tick - KNEE) / 2)));
                S.victim.hold(S.held, back);
                return true;
            }
            if (tick < HAMMER) {
                if (tick === RISE) {
                    S.apex = clearAbove(dim, v, S.knock, LAUNCH_HEIGHT);
                    S.over = sub(up(S.apex, height(v) + OVER_HEIGHT), mul(f, 0.4));
                    hit(C, S, RISE_SHARE, 2.6, "critic_punch1", V(0, 1, 0));
                    S.victim.launched();
                    shock(C, up(S.base, 0.1), 4.0, CM, 10);
                    C.snd(S.knock, "evasion2", 1.5, 0.7);
                }
                S.held = lerp(up(S.knock, KNEE_BUMP), S.apex, easeOut(clamp01((tick - RISE) / (RISE_END - RISE))));
                S.victim.hold(S.held, back);
                if (tick === VANISH2) { after(C, pos(self), S.yaw); C.snd(S.base, "zanzoken", 1.5, 1.0); }
                C.place(tick >= APPEAR_ABOVE ? S.over : S.base, S.yaw);
                return true;
            }
            if (tick < STOMP) {
                if (tick === HAMMER) {
                    S.ground = grounded(C, S.held);
                    S.stand = up(S.ground, STAND_HEIGHT);
                    hit(C, S, HAMMER_SHARE, 3.0, "critic_punch1", V(0, -1, 0));
                    S.victim.knockDown();
                    C.frame(0.75, 0.05, 2, true);
                    C.shake(false, 8);
                }
                S.held = lerp(S.apex, S.ground, Math.pow(clamp01((tick - HAMMER) / (SLAM - HAMMER)), 2));
                S.victim.hold(S.held, back);
                if (tick === SLAM) gi(C, S.ground, 5.0);
                if (tick < DIVE_START) C.place(S.over, S.yaw);
                else {
                    C.place(lerp(S.over, S.stand, Math.pow((tick - DIVE_START) / (STOMP - DIVE_START), 3)), S.yaw);
                    if (tick === DIVE_START) C.snd(S.over, "evasion2", 1.6, 0.6);
                }
                return true;
            }
            C.place(S.stand, S.yaw);
            S.victim.hold(S.ground, back);
            if (tick === STOMP) { hit(C, S, STOMP_SHARE, 3.0, "anchor_slam", V(0, -1, 0)); S.victim.knockOut(); gi(C, S.ground, 6.0); C.frame(0.8, 0.05, 3, true); }
            if (GRINDS.indexOf(tick) >= 0) { hit(C, S, GRIND_SHARE, 1.4, "punch5", V(0, -1, 0)); rocks(C, up(S.ground, 0.2), 12, 0.6, 0.2, 0.15); }
            if (tick === CRUSH) {
                S.crushed = true;
                C.strikeHit(v, C.strikeBudget * CRUSH_SHARE, true);
                burst(C, S.ground, V(0, -1, 0), 5.5, CM, CD, false, 18);
                C.frame(0.85, 0.05, 3, false);
                C.shake(true, 12);
                gi(C, S.ground, 8.0);
                C.snd(S.ground, "critic_punch1", 3.0, 0.7);
                if (!alive(v)) { S.victim.release(); S.victim = null; }
            }
            return true;
        }
        return { DURATION: DURATION, RANGE: RANGE, tick: tick, release: function () { } };
    })();

    // =====================================================================================
    //  Android Combo (AndroidCombo): palm, hook, haymaker that sends the victim tumbling, the chase, knee, three
    //  jabs, an uppercut that floats it away, a red ki ball charged at the chest, thrown, the blast
    // =====================================================================================
    var AC = (function () {
        var L = 4, DURATION = L + 78, RANGE = 14, CM = 0xFF3B3B, CB = 0xD10F1F, CO = 0xB0001A;
        var DASH_START = L, DASH_END = L + 3, PALM = L + 5, HOOK = L + 8, HAYMAKER = L + 12, SLIDE_END = L + 18, CHASE_START = L + 16,
            CHASE_END = L + 19, KNEE = L + 20, JABS = [L + 23, L + 26, L + 29], UPPERCUT = L + 34, FLIGHT_END = L + 44, CHARGE_START = L + 39,
            SHOUT = L + 54, THROW = L + 61, IMPACT = L + 66, BLAST_VIS = [L + 66, L + 70], BLAST_SIZES = [5.0, 6.5];
        var VICTIM_GAP = 0.3, PALM_NUDGE = 0.25, HIT_NUDGE = 0.2, KNOCK_DIST = 3.0, FLOAT_FWD = 3.5, FLOAT_H = 2.5, CHEST_H = 1.05, CHEST_FWD = 0.4,
            BALL_START = 0.2, BALL_CHEST = 1.8, MAX_DROP = 30, MAX_VICTIM = 48, PALM_SHARE = 0.1, HOOK_SHARE = 0.12, HAYMAKER_SHARE = 0.18,
            KNEE_SHARE = 0.1, JAB_SHARE = 0.06, UPPERCUT_SHARE = 0.32, BOMB_SHARE = 1.0;
        function hit(C, S, share, scale, sound, dir) { strike(C, S, share, scale, sound, dir, 0xFFD27F); }
        function grounded(C, at) { return groundedWithin(C.p.dimension, at, MAX_DROP); }
        function aim(S) {
            var v = S.victim ? S.victim.e : null;
            if (v && !S.victim.pinned) return center(v);
            return up(S.hover || S.held, v ? height(v) * 0.5 : 0.9);
        }
        function slide(S, tick) {
            var sl = easeOut(clamp01((tick - HAYMAKER) / (SLIDE_END - HAYMAKER)));
            S.held = up(lerp(S.start, S.knock, sl), Math.sin(sl * Math.PI) * 0.8);
        }
        function ball(C, S, at, size) { S.ballOn = true; C.fx(at, { t: "orb", id: "ac" + C.p.entityId, x: r2(at.x), y: r2(at.y), z: r2(at.z), s: r2(size), c: [hexs(CM), hexs(CB), hexs(CO)], life: 4 }); }
        function dropBall(C, S) { if (S.ballOn) { C.fx(C.p, { t: "orbx", id: "ac" + C.p.entityId }); S.ballOn = false; } }
        function tick(C, S, tick) {
            var self = C.p, dim = self.dimension;
            var o = opening(C, S, tick, DASH_START, DURATION, RANGE, VICTIM_GAP, function () { after(C, pos(self), S.yaw); C.snd(pos(self), "zanzoken", 1.5, 0.9); });
            if (o !== null) return o;
            if (S.blasted) {
                C.place(S.chase, S.yaw);
                if (S.victim) { if (alive(S.victim.e)) S.victim.hold(S.hover, S.yaw + 180); else { S.victim.release(); S.victim = null; } }
                for (var i = 1; i < BLAST_VIS.length; i++) if (BLAST_VIS[i] === tick) boom(C, aim(S), BLAST_SIZES[i], CM, CB, CO);
                return true;
            }
            if (!S.victim || !S.victim.valid(self, MAX_VICTIM)) return false;
            var v = S.victim.e, f = facing(S.yaw), back = S.yaw + 180;
            if (tick < CHASE_START) {
                C.place(lerp(S.origin, S.base, smooth(clamp01((tick - DASH_START) / (DASH_END - DASH_START)))), S.yaw);
                if (tick < HAYMAKER) {
                    S.held = lerp(S.held, S.start, 0.4);
                    if (tick === PALM) { S.held = add(S.start, mul(f, PALM_NUDGE)); hit(C, S, PALM_SHARE, 1.8, "punch3", f); S.victim.flinch(); }
                    if (tick === HOOK) { S.held = add(add(S.start, mul(f, PALM_NUDGE)), mul(facing(S.yaw + 90), HIT_NUDGE)); hit(C, S, HOOK_SHARE, 2.0, "punch5", facing(S.yaw + 90)); S.victim.flinch(); }
                } else {
                    if (tick === HAYMAKER) {
                        S.knock = grounded(C, up(clearPoint(dim, up(S.start, 1), up(add(S.start, mul(f, KNOCK_DIST)), 1), width(v) * 0.5 + 0.2), -1));
                        hit(C, S, HAYMAKER_SHARE, 2.6, "critic_punch2", f);
                        S.victim.launched();
                        C.frame(0.65, 0.05, 2, false);
                        C.snd(S.start, "evasion1", 1.3, 0.8);
                    }
                    slide(S, tick);
                }
                S.victim.hold(S.held, back);
                return true;
            }
            if (tick < UPPERCUT) {
                if (tick === CHASE_START) {
                    var want = sub(S.knock, mul(f, gap(self, v, VICTIM_GAP)));
                    S.chase = fits(dim, self, want) ? want : pos(self);
                    C.shake(false, 6);
                    C.snd(pos(self), "evasion2", 1.4, 1.1);
                }
                C.place(lerp(S.base, S.chase, smooth(clamp01((tick - CHASE_START) / (CHASE_END - CHASE_START)))), S.yaw);
                if (tick <= SLIDE_END) slide(S, tick); else S.held = lerp(S.held, S.knock, 0.4);
                if (tick === KNEE) { S.held = up(S.knock, 0.4); hit(C, S, KNEE_SHARE, 2.0, "punch6", V(0, 1, 0)); S.victim.flinch(); }
                if (JABS.indexOf(tick) >= 0) { S.held = add(S.knock, mul(f, HIT_NUDGE)); hit(C, S, JAB_SHARE, 1.5, punchSound(), f); S.victim.flinch(); }
                S.victim.hold(S.held, back);
                return true;
            }
            C.place(S.chase, S.yaw);
            if (tick === UPPERCUT) {
                var w2 = up(add(S.knock, mul(f, FLOAT_FWD)), FLOAT_H);
                S.hover = up(clearPoint(dim, up(S.knock, 1), up(w2, 1), width(v) * 0.5 + 0.3), -1);
                S.start = S.held;
                hit(C, S, UPPERCUT_SHARE, 3.0, "critic_punch1", V(0, 1, 0));
                S.victim.launched();
                C.frame(0.75, 0.05, 2, true);
                shock(C, up(S.chase, 0.1), 4.0, 0xFFE0A0, 10);
            }
            S.held = lerp(S.start, S.hover, easeOut(clamp01((tick - UPPERCUT) / (FLIGHT_END - UPPERCUT))));
            S.victim.hold(S.held, back);
            if (tick >= CHARGE_START && tick < THROW) {             // charge(): the ball grows at the chest
                var grow = clamp01((tick - CHARGE_START) / (THROW - CHARGE_START)), size = BALL_START + (BALL_CHEST - BALL_START) * easeOut(grow);
                var at = add(up(S.chase, CHEST_H), mul(f, CHEST_FWD + size * 0.5));
                if ((tick - CHARGE_START) % 20 === 0) C.snd(at, "ki_charge_loop", 1.4, 1.1);
                if ((tick - CHARGE_START) % 3 === 0) {
                    var spread = size * 0.9 + 0.6;
                    RPG.world.particle(dim, "minecraft:dust 1 0.25 0.25 1.4", at.x, at.y, at.z, 6, spread, 0);
                    RPG.world.particle(dim, "minecraft:electric_spark", at.x, at.y, at.z, 4, size * 0.6, 0.15);
                }
                ball(C, S, at, size);
                S.throwFrom = at; S.size = size;
            }
            if (tick === SHOUT) {
                C.shake(true, 10);
                shock(C, up(S.chase, 0.1), 5.0, CM, 14);
                C.snd(S.chase, "ki_explosion_charge", 1.8, 0.9);
            }
            if (tick >= THROW && tick < IMPACT && S.ballOn) {
                if (tick === THROW) { C.shake(false, 10); C.snd(S.throwFrom, "ki_beam_fire", 2.0, 0.8); }
                ball(C, S, lerp(S.throwFrom, aim(S), (tick - THROW + 1) / (IMPACT - THROW)), S.size);
            }
            if (tick === IMPACT) {
                var ba = aim(S);
                dropBall(C, S);
                S.blasted = true;
                C.kiHit(v, C.kiBudget * BOMB_SHARE, true);
                if (alive(v)) S.victim.knockOut(); else { S.victim.release(); S.victim = null; }
                boom(C, ba, BLAST_SIZES[0], CM, CB, CO);
                C.frame(0.9, 0.05, 4, false);
                shock(C, ba, 9.0, CB, 18);
                C.snd(ba, "ki_explosion_impact", 3.5, 0.7);
            }
            return true;
        }
        return { DURATION: DURATION, RANGE: RANGE, tick: tick, release: function (C, S) { dropBall(C, S); } };
    })();

    // =====================================================================================
    //  Beam Sword Slash (BeamSwordSlashCombo): kick, knee, punch, launch, an air hit, appear above, hammer down,
    //  hover and summon the ki blade, it stretches down to skewer the victim three times, a sweep, drop, dash, slash
    // =====================================================================================
    var BS = (function () {
        var L = 4, DURATION = L + 108, RANGE = 14;
        var DASH_START = L, DASH_END = L + 3, KICK = L + 4, KNEE = L + 8, PUNCH = L + 12, SLIDE_END = L + 16, LAUNCH = L + 17, LAUNCH_END = L + 25,
            LEAP_START = L + 19, AIR_HIT = L + 25, AIR_RISE_END = L + 31, VANISH = L + 29, APPEAR = L + 30, HAMMER = L + 32, SLAM = L + 37,
            HOVER_END = L + 41, CHARGE_START = L + 40, SUMMON = L + 44, THRUST = L + 58, SKEWERS = [L + 60, L + 65, L + 70], SWEEP = L + 81,
            DROP_START = L + 83, DROP_END = L + 88, STAND = L + 86, DASH2_START = L + 90, DASH2_END = L + 94, SLASH = L + 99;
        var VICTIM_GAP = 0.35, KICK_NUDGE = 0.3, KNEE_BUMP = 0.4, KNOCK_DIST = 2.0, LAUNCH_HEIGHT = 6, AIR_RISE = 2.5, OVER_HEIGHT = 0.8,
            SHOULDER_SIDE = 5 / 16, SHOULDER_UP = 17.5 / 16, SHOULDER_FWD = 13 / 16, THRUST_FWD = 0.778, THRUST_DOWN = 0.628, THRUST_LEN = 5.5,
            BLADE_FIST = 0.5, BLADE_PIERCE = 0.3, LYING_AIM = 0.4, SLASH_REACH = 0.8, DASH_DIST = 2.5, HAND_SIDE = 0.4, HAND_UP = 0.75,
            MAX_DROP = 30, MAX_VICTIM = 48, FINAL_PUSH = 1.8, FINAL_LIFT = 0.7, KICK_SHARE = 0.08, KNEE_SHARE = 0.08, PUNCH_SHARE = 0.08,
            LAUNCH_SHARE = 0.1, AIR_SHARE = 0.08, HAMMER_SHARE = 0.1, SKEWER_SHARE = 0.06, SWEEP_SHARE = 0.08, SLASH_SHARE = 0.22;
        function grounded(C, at) { return groundedWithin(C.p.dimension, at, MAX_DROP); }
        function bhit(C, S, share, at, dir, scale, sound) {
            C.strikeHit(S.victim.e, C.strikeBudget * share, false);
            burst(C, at, dir, scale, 0xFFFFFF, S.blade ? C.bladeColor : 0xFFD27F, true, 8 + Math.floor(scale * 2));
            C.snd(at, sound, 1.8, pitchJitter(0.85, 0.2));
        }
        function aimHeight(v) { return isPlayer(v) ? Math.min(LYING_AIM, height(v) * 0.5) : height(v) * 0.5; }
        function shoulder(feet, yaw, sc) { return add(up(add(feet, mul(facing(yaw + 90), SHOULDER_SIDE * sc)), SHOULDER_UP * sc), mul(facing(yaw), SHOULDER_FWD * sc)); }
        function hoverPoint(S, v) {
            var f = facing(S.yaw), right = facing(S.yaw + 90), c = up(S.ground, aimHeight(v));
            var sh = up(sub(c, mul(f, THRUST_FWD * THRUST_LEN)), THRUST_DOWN * THRUST_LEN);
            return sub(up(sub(sh, mul(right, SHOULDER_SIDE * S.scale)), -SHOULDER_UP * S.scale), mul(f, SHOULDER_FWD * S.scale));
        }
        function tick(C, S, tick) {
            var self = C.p, dim = self.dimension;
            var o = opening(C, S, tick, DASH_START, DURATION, RANGE, VICTIM_GAP, function () { S.scale = Math.max(0.2, C.modelScale); after(C, pos(self), S.yaw); C.snd(pos(self), "zanzoken", 1.5, 0.9); });
            if (o !== null) return o;
            if (S.finished) { C.place(S.strikePos, S.yaw); return true; }
            if (!S.victim || !S.victim.valid(self, MAX_VICTIM)) return false;
            var v = S.victim.e, f = facing(S.yaw), back = S.yaw + 180;
            if (tick < LAUNCH) {
                var dashed = lerp(S.origin, S.base, smooth(clamp01((tick - DASH_START) / (DASH_END - DASH_START))));
                if (tick < PUNCH) {
                    S.held = lerp(S.held, S.start, 0.4);
                    if (tick === KICK) { S.held = add(S.start, mul(f, KICK_NUDGE)); bhit(C, S, KICK_SHARE, center(v), f, 1.8, "punch4"); S.victim.flinch(); }
                    if (tick === KNEE) { S.held = up(S.start, KNEE_BUMP); bhit(C, S, KNEE_SHARE, center(v), V(0, 1, 0), 2.0, "punch6"); S.victim.flinch(); }
                    C.place(dashed, S.yaw);
                } else {
                    if (tick === PUNCH) {
                        S.knock = grounded(C, up(clearPoint(dim, up(S.start, 1), up(add(S.start, mul(f, KNOCK_DIST)), 1), width(v) * 0.5 + 0.2), -1));
                        bhit(C, S, PUNCH_SHARE, center(v), f, 2.2, "critic_punch2");
                        S.victim.flinch();
                    }
                    var sl = easeOut(clamp01((tick - PUNCH) / (SLIDE_END - PUNCH)));
                    S.held = lerp(S.start, S.knock, sl);
                    C.place(lerp(dashed, sub(S.held, mul(f, gap(self, v, VICTIM_GAP))), sl), S.yaw);
                }
                S.victim.hold(S.held, back);
                return true;
            }
            if (tick < HAMMER) {
                if (tick === LAUNCH) {
                    S.base = pos(self);
                    S.apex = clearAbove(dim, v, S.knock, LAUNCH_HEIGHT);
                    S.apex2 = clearAbove(dim, v, S.knock, LAUNCH_HEIGHT + AIR_RISE);
                    S.airPos = up(sub(S.apex, mul(f, gap(self, v, VICTIM_GAP))), -0.5);
                    S.over = sub(up(S.apex2, height(v) + OVER_HEIGHT), mul(f, 0.3));
                    S.ground = grounded(C, S.apex2);
                    S.hover = hoverPoint(S, v);
                    bhit(C, S, LAUNCH_SHARE, center(v), V(0, 1, 0), 2.6, "critic_punch1");
                    S.victim.launched();
                    shock(C, up(S.base, 0.1), 4.0, 0xFFE0A0, 10);
                    C.snd(S.knock, "evasion2", 1.5, 0.7);
                }
                if (tick <= LAUNCH_END) S.held = lerp(S.knock, S.apex, easeOut(clamp01((tick - LAUNCH) / (LAUNCH_END - LAUNCH))));
                else S.held = lerp(S.apex, S.apex2, easeOut(clamp01((tick - AIR_HIT) / (AIR_RISE_END - AIR_HIT))));
                if (tick === AIR_HIT) { bhit(C, S, AIR_SHARE, center(v), V(0, 1, 0), 2.4, "critic_punch2"); S.victim.launched(); }
                S.victim.hold(S.held, back);
                if (tick < LEAP_START) C.place(S.base, S.yaw);
                else if (tick <= AIR_HIT) {
                    C.place(lerp(S.base, S.airPos, smooth((tick - LEAP_START) / (AIR_HIT - LEAP_START))), S.yaw);
                    if (tick === LEAP_START) C.snd(S.base, "evasion1", 1.4, 1.0);
                } else if (tick < APPEAR) C.place(S.airPos, S.yaw);
                else C.place(S.over, S.yaw);
                if (tick === VANISH) { after(C, pos(self), S.yaw); C.snd(S.airPos, "zanzoken", 1.5, 1.1); }
                return true;
            }
            if (tick < THRUST) {
                if (tick === HAMMER) { bhit(C, S, HAMMER_SHARE, center(v), V(0, -1, 0), 3.0, "critic_punch1"); S.victim.knockDown(); C.frame(0.75, 0.05, 2, true); }
                S.held = lerp(S.apex2, S.ground, Math.pow(clamp01((tick - HAMMER) / (SLAM - HAMMER)), 2));
                S.victim.hold(S.held, back);
                if (tick === SLAM) { rocks(C, up(S.ground, 0.2), 30, 1.5, 0.3, 0.25); shock(C, up(S.ground, 0.2), 5.0, 0xFFE0A0, 12); C.snd(S.ground, "knockback_character", 2.0, 0.7); }
                C.place(lerp(S.over, S.hover, smooth(clamp01((tick - HAMMER) / (HOVER_END - HAMMER)))), S.yaw);
                if (tick >= CHARGE_START && (tick - CHARGE_START) % 2 === 0) {
                    var right = facing(S.yaw + 90), hand = sub(up(add(S.hover, mul(right, HAND_SIDE * S.scale)), HAND_UP * S.scale), mul(f, 0.2)), bc = C.bladeColor;
                    RPG.world.particle(dim, "minecraft:dust " + r2(((bc >> 16) & 255) / 255) + " " + r2(((bc >> 8) & 255) / 255) + " " + r2((bc & 255) / 255) + " 1.3",
                        hand.x, hand.y, hand.z, 6, 0.25, 0);
                    RPG.world.particle(dim, "minecraft:electric_spark", hand.x, hand.y, hand.z, 3, 0.2, 0.1);
                    if ((tick - CHARGE_START) % 20 === 0) C.snd(hand, "ki_charge_loop", 1.3, 1.3);
                }
                if (tick === SUMMON) {
                    S.blade = true;
                    C.fx(self, { t: "blade", e: self.entityId, reach: 0, c: hexs(C.bladeColor), life: DURATION - SUMMON + 2 });
                    C.shake(false, 6);
                    C.snd(S.hover, "sword_out", 1.6, 1.0);
                }
                return true;
            }
            if (tick < DROP_START) {
                C.place(S.hover, S.yaw);
                S.victim.hold(S.ground, back);
                var c = up(S.ground, aimHeight(v));
                if (tick === THRUST) {
                    var reach = dist(shoulder(S.hover, S.yaw, S.scale), c) / S.scale - BLADE_FIST + BLADE_PIERCE;
                    S.tip = (reach + BLADE_FIST) * S.scale;
                    C.fx(self, { t: "blade", e: self.entityId, reach: r2(reach), c: hexs(C.bladeColor), life: DURATION - THRUST + 2 });
                    C.frame(0.75, 0.05, 2, true);
                    C.snd(S.hover, "ki_beam_fire", 2.0, 1.4);
                }
                if (SKEWERS.indexOf(tick) >= 0) bhit(C, S, SKEWER_SHARE, c, V(0, -1, 0), 2.0, "punch6");
                if (tick === SWEEP) { bhit(C, S, SWEEP_SHARE, c, V(0, 1, 0), 3.0, "sword_slash"); C.shake(false, 8); }
                return true;
            }
            if (tick < SLASH) {
                if (tick === DROP_START) {
                    var sr = S.tip * SLASH_REACH, w = sub(S.ground, mul(f, sr + DASH_DIST));
                    S.land = grounded(C, w);
                    if (Math.abs(S.land.y - S.ground.y) > 3) S.land = V(w.x, S.ground.y, w.z);
                    var sw = sub(S.ground, mul(f, Math.max(gap(self, v, VICTIM_GAP), sr)));
                    S.strikePos = V(sw.x, S.land.y, sw.z);
                    C.fx(self, { t: "blade", e: self.entityId, reach: 0, c: hexs(C.bladeColor), life: DURATION - DROP_START + 2 });
                    C.snd(S.hover, "evasion1", 1.2, 1.2);
                }
                if (tick === STAND) S.victim.flinch();
                S.victim.hold(S.ground, back);
                if (tick <= DROP_END) {
                    C.place(lerp(S.hover, S.land, Math.pow((tick - DROP_START) / (DROP_END - DROP_START), 2)), S.yaw);
                    if (tick === DROP_END) dust(C, up(S.land, 0.1), 14, 0.5, 0.1, 0.04);
                } else if (tick < DASH2_START) C.place(S.land, S.yaw);
                else {
                    C.place(lerp(S.land, S.strikePos, smooth(clamp01((tick - DASH2_START) / (DASH2_END - DASH2_START)))), S.yaw);
                    if (tick === DASH2_START) { after(C, pos(self), S.yaw); C.snd(S.land, "zanzoken", 1.5, 1.1); }
                }
                return true;
            }
            C.place(S.strikePos, S.yaw);
            // finish(): the slash, the victim let go and pushed away
            var vc = center(v);
            S.finished = true;
            C.strikeHit(v, C.strikeBudget * SLASH_SHARE, true);
            slash(C, sub(vc, mul(f, 0.8)), f, 0.45, 0, 3.6, C.bladeColor, 0xFFFFFF, 10);
            burst(C, vc, f, 4.0, 0xFFFFFF, C.bladeColor, true, 18);
            C.frame(0.85, 0.05, 3, false);
            C.shake(true, 10);
            C.snd(vc, "critic_punch1", 3.0, 0.8);
            C.snd(vc, "sword_slash", 2.0, 0.7);
            var held = S.victim; S.victim = null; held.release();
            if (alive(v)) try { v.setVelocity(f.x * FINAL_PUSH, FINAL_LIFT, f.z * FINAL_PUSH); } catch (x) { }
            return true;
        }
        return { DURATION: DURATION, RANGE: RANGE, tick: tick,
            release: function (C, S) { if (S.blade) { C.fx(C.p, { t: "bladex", e: C.p.entityId }); S.blade = false; } } };
    })();

    // =====================================================================================
    //  Perfect Rush (PerfectRushCombo): power up, hook, backhand, elbow (each with a golden arc), knee launch,
    //  leap after it, jab, straight that sends it higher, appear above crackling, hammer, the crash, descend
    // =====================================================================================
    var PR = (function () {
        var L = 4, DURATION = L + 88, RANGE = 14, CM = 0xFFC93C, CD = 0xFF8A00, CS = 0x7FC8FF;
        var POWER = L + 1, DASH_START = L + 4, DASH_END = L + 8, HOOK = L + 9, BACKHAND = L + 12, ELBOW = L + 15, KNEE = L + 18, LAUNCH_END = L + 28,
            LEAP = L + 30, APPEAR = L + 33, JAB = L + 38, STRAIGHT = L + 41, SECOND_RISE_END = L + 49, DASH_UP = L + 49, APPEAR_ABOVE = L + 51,
            HAMMER = L + 62, CRASH = L + 68, DESCEND_START = L + 70, DESCEND_END = L + 78;
        var VICTIM_GAP = 0.3, HIT_NUDGE = 0.15, ELBOW_BUMP = 0.3, KNEE_BUMP = 0.5, LAUNCH_HEIGHT = 6, SECOND_RISE = 4, AIR_DROP = 0.3, OVER_HEIGHT = 0.8,
            LAND_BACK = 1.2, MAX_DROP = 30, MAX_VICTIM = 48, HOOK_SHARE = 0.1, BACKHAND_SHARE = 0.1, ELBOW_SHARE = 0.1, KNEE_SHARE = 0.12,
            JAB_SHARE = 0.12, STRAIGHT_SHARE = 0.14, HAMMER_SHARE = 0.14, CRASH_SHARE = 0.18;
        function hit(C, S, share, scale, sound, dir) { strike(C, S, share, scale, sound, dir, CM); }
        function grounded(C, at) { return groundedWithin(C.p.dimension, at, MAX_DROP); }
        function arc(C, v, dir, roll) { var d = norm(dir), c = center(v); slash(C, sub(c, mul(d, 0.6)), d, 0.5, roll, 1.6, CM, 0xFFFFFF, 8); }
        function sparkDust(C, at, n, sx, sy, speed) { RPG.world.particle(C.p.dimension, "minecraft:dust 0.5 0.78 1 1.4", at.x, at.y, at.z, n, sx, speed); }
        function tick(C, S, tick) {
            var self = C.p, dim = self.dimension;
            if (tick < DASH_START && tick === POWER && canTarget(self, C.t)) {
                C.shake(true, 8);
                shock(C, up(pos(self), 0.1), 3.5, CM, 10);
                C.snd(pos(self), "aura_start", 1.4, 1.1);
            }
            var o = opening(C, S, tick, DASH_START, DURATION, RANGE, VICTIM_GAP, function () { after(C, pos(self), S.yaw); C.shake(false, 6); C.snd(pos(self), "zanzoken", 1.5, 0.9); });
            if (o !== null) return o;
            if (S.crashed) {
                if (S.victim) { if (alive(S.victim.e)) S.victim.hold(S.ground, S.yaw + 180); else { S.victim.release(); S.victim = null; } }
                if (!S.land) {
                    var w = sub(S.ground, mul(facing(S.yaw), gap(self, self, VICTIM_GAP) + LAND_BACK));
                    S.land = grounded(C, w);
                    if (Math.abs(S.land.y - S.ground.y) > 3) S.land = V(w.x, S.ground.y, w.z);
                }
                if (tick < DESCEND_START) { C.place(S.over, S.yaw); return true; }
                var u = clamp01((tick - DESCEND_START) / (DESCEND_END - DESCEND_START));
                C.place(lerp(S.over, S.land, u * u), S.yaw);
                if (tick === DESCEND_START) C.snd(S.over, "evasion1", 1.2, 0.9);
                if (tick === DESCEND_END) { dust(C, up(S.land, 0.1), 14, 0.5, 0.1, 0.04); C.snd(S.land, "knockback_character", 0.9, 1.2); }
                return true;
            }
            if (!S.victim || !S.victim.valid(self, MAX_VICTIM)) return false;
            var v = S.victim.e, f = facing(S.yaw), right = facing(S.yaw + 90), back = S.yaw + 180;
            if (tick < KNEE) {
                C.place(lerp(S.origin, S.base, smooth(clamp01((tick - DASH_START) / (DASH_END - DASH_START)))), S.yaw);
                S.held = lerp(S.held, S.start, 0.4);
                if (tick === HOOK) { S.held = add(S.start, mul(right, -HIT_NUDGE)); hit(C, S, HOOK_SHARE, 2.0, "punch4", f); arc(C, v, f, 0); S.victim.flinch(); }
                if (tick === BACKHAND) { S.held = up(add(S.start, mul(right, HIT_NUDGE)), -0.1); hit(C, S, BACKHAND_SHARE, 2.0, "punch5", f); arc(C, v, f, 150); S.victim.flinch(); }
                if (tick === ELBOW) { S.held = up(S.start, ELBOW_BUMP); hit(C, S, ELBOW_SHARE, 2.2, "punch6", V(0, 1, 0)); arc(C, v, f, 80); S.victim.flinch(); }
                S.victim.hold(S.held, back);
                return true;
            }
            if (tick < JAB) {
                if (tick === KNEE) {
                    S.apex = clearAbove(dim, v, S.start, LAUNCH_HEIGHT);
                    S.apex2 = clearAbove(dim, v, S.start, LAUNCH_HEIGHT + SECOND_RISE);
                    if (S.apex2.y < S.apex.y) S.apex2 = S.apex;
                    S.air = up(sub(S.apex, mul(f, gap(self, v, VICTIM_GAP))), -AIR_DROP);
                    hit(C, S, KNEE_SHARE, 2.6, "critic_punch1", V(0, 1, 0));
                    S.victim.launched();
                    shock(C, up(S.base, 0.1), 4.0, CM, 10);
                    C.frame(0.6, 0.05, 2, false);
                    C.snd(S.start, "evasion2", 1.5, 0.7);
                }
                S.held = lerp(up(S.start, KNEE_BUMP), S.apex, easeOut(clamp01((tick - KNEE) / (LAUNCH_END - KNEE))));
                S.victim.hold(S.held, back);
                if (tick < LEAP) C.place(S.base, S.yaw);
                else {
                    if (tick === LEAP) {
                        after(C, pos(self), S.yaw);
                        sparkDust(C, up(S.base, 0.6), 40, 0.7, 0.4, 0.2);
                        RPG.world.particle(dim, "minecraft:electric_spark", S.base.x, S.base.y + 0.6, S.base.z, 20, 0.6, 0.3);
                        dust(C, up(S.base, 0.1), 14, 0.5, 0.1, 0.05);
                        C.snd(S.base, "zanzoken", 1.5, 1.2);
                    }
                    C.place(lerp(S.base, S.air, smooth(clamp01((tick - LEAP) / (APPEAR - LEAP)))), S.yaw);
                }
                return true;
            }
            if (tick < HAMMER) {
                if (tick === JAB) { hit(C, S, JAB_SHARE, 2.4, "critic_punch2", f); arc(C, v, f, 20); S.victim.flinch(); }
                if (tick === STRAIGHT) {
                    hit(C, S, STRAIGHT_SHARE, 2.8, "critic_punch1", V(f.x, 1, f.z));
                    arc(C, v, f, -30);
                    S.victim.launched();
                    C.frame(0.65, 0.05, 2, false);
                    C.snd(S.apex, "evasion2", 1.5, 0.8);
                }
                S.held = tick < STRAIGHT ? S.apex : lerp(S.apex, S.apex2, easeOut(clamp01((tick - STRAIGHT) / (SECOND_RISE_END - STRAIGHT))));
                S.victim.hold(S.held, back);
                if (tick === DASH_UP) {
                    S.over = sub(up(S.apex2, height(v) + OVER_HEIGHT), mul(f, 0.4));
                    after(C, pos(self), S.yaw);
                    sparkDust(C, up(pos(self), 1.0), 24, 0.5, 0.6, 0.2);
                    C.snd(pos(self), "zanzoken", 1.5, 1.0);
                }
                if (tick < DASH_UP) C.place(S.air, S.yaw);
                else if (tick < APPEAR_ABOVE) C.place(lerp(S.air, S.over, smooth((tick - DASH_UP) / (APPEAR_ABOVE - DASH_UP))), S.yaw);
                else {
                    C.place(S.over, S.yaw);
                    if ((tick - APPEAR_ABOVE) % 3 === 0) {
                        var ch = up(pos(self), height(self) * 0.6);
                        RPG.world.particle(dim, "minecraft:electric_spark", ch.x, ch.y, ch.z, 4, 0.45, 0.15);
                        RPG.world.particle(dim, "minecraft:dust 1 0.79 0.24 1.2", ch.x, ch.y, ch.z, 4, 0.45, 0);
                    }
                }
                return true;
            }
            if (tick < CRASH) {
                if (tick === HAMMER) {
                    S.ground = grounded(C, S.held);
                    hit(C, S, HAMMER_SHARE, 3.2, "critic_punch1", V(0, -1, 0));
                    arc(C, v, V(f.x, -1, f.z), 90);
                    S.victim.knockDown();
                    C.frame(0.8, 0.05, 3, true);
                    C.shake(false, 8);
                }
                S.held = lerp(S.apex2, S.ground, Math.pow(clamp01((tick - HAMMER) / (CRASH - HAMMER)), 2));
                S.victim.hold(S.held, back);
                C.place(S.over, S.yaw);
                return true;
            }
            C.place(S.over, S.yaw);
            S.crashed = true;
            S.victim.hold(S.ground, back);
            C.strikeHit(v, C.strikeBudget * CRASH_SHARE, true);
            S.victim.knockOut();
            burst(C, S.ground, V(0, -1, 0), 5.5, CM, CD, false, 18);
            C.frame(0.85, 0.05, 3, false);
            rocks(C, up(S.ground, 0.2), 50, 2.4, 0.3, 0.3); dust(C, up(S.ground, 0.2), 60, 2.8, 0.3, 0.1); shock(C, up(S.ground, 0.2), 8.0, CM, 14);
            C.snd(S.ground, "knockback_character", 2.0, 0.7);
            C.snd(S.ground, "critic_punch1", 3.0, 0.7);
            C.snd(S.ground, "anchor_slam", 2.5, 0.8);
            if (!alive(v)) { S.victim.release(); S.victim = null; }
            return true;
        }
        return { DURATION: DURATION, RANGE: RANGE, tick: tick, release: function () { } };
    })();

    // =====================================================================================
    //  Spirit Breaker (SpiritBreakerCombo): gut punch, uppercut, vanish after it, a four punch flurry, the big punch
    //  that blows it away, a ram that rides it into the ground, hop back, jump, flaming flip, the axe kick
    // =====================================================================================
    var SB = (function () {
        var L = 4, DURATION = L + 144, RANGE = 14, CM = 0xFFD23C, CD = 0xFF8C1A;
        var DASH_START = L + 2, DASH_END = L + 5, GUT = L + 6, UPPERCUT = L + 26, LAUNCH_END = L + 35, POWER = L + 32, VANISH = L + 38, APPEAR = L + 40,
            FLURRY = [L + 41, L + 45, L + 49, L + 53], FLASH = L + 48, BIG_PUNCH = L + 57, BLOWN_END = L + 67, RAGE = L + 64, RAM_START = L + 70,
            RAM = L + 73, SLAM = L + 82, HOP_END = L + 88, JUMP_START = L + 104, JUMP_END = L + 111, FLAME_START = L + 112, FLIP_START = L + 119,
            AXE = L + 127, STEP_START = L + 132, STEP_END = L + 136;
        var VICTIM_GAP = 0.3, GUT_PUSH = 0.25, LAUNCH_HEIGHT = 5, LAUNCH_DIST = 3, AIR_DROP = 0.3, FLURRY_PUSH = 0.6, BLOWN_DIST = 6, BLOWN_RISE = 1,
            RIDE_HEIGHT = 0.5, STAND_BACK = 0.8, HOP_ARC = 1.2, AXE_HEIGHT = 3.5, HEEL_HEIGHT = 0.2, MAX_DROP = 30, MAX_VICTIM = 48,
            GUT_SHARE = 0.08, UPPERCUT_SHARE = 0.08, FLURRY_SHARE = 0.06, BIG_PUNCH_SHARE = 0.08, RAM_SHARE = 0.1, SLAM_SHARE = 0.12, AXE_SHARE = 0.3;
        function hit(C, S, share, scale, sound, dir) { strike(C, S, share, scale, sound, dir, CM); }
        function grounded(C, at) { return groundedWithin(C.p.dimension, at, MAX_DROP); }
        function airBehind(at, f, self, v) { return up(sub(at, mul(f, gap(self, v, VICTIM_GAP))), -AIR_DROP); }
        function sparks(C, spread) { var p = C.p; RPG.world.particle(p.dimension, "minecraft:electric_spark", p.x, p.y + height(p) * 0.6, p.z, 3, spread, 0.15); }
        function gi(C, at, scale) { rocks(C, up(at, 0.2), 50, scale * 0.3, 0.3, 0.3); dust(C, up(at, 0.2), 60, scale * 0.35, 0.3, 0.1); shock(C, up(at, 0.2), scale, CM, 14); C.snd(at, "knockback_character", 2.0, 0.7); }
        function tick(C, S, tick) {
            var self = C.p, dim = self.dimension;
            var o = opening(C, S, tick, DASH_START, DURATION, RANGE, VICTIM_GAP, function () { after(C, pos(self), S.yaw); C.snd(pos(self), "zanzoken", 1.5, 0.9); });
            if (o !== null) return o;
            if (S.finished) {
                if (S.victim) { if (alive(S.victim.e)) S.victim.hold(S.ground, S.yaw + 180); else { S.victim.release(); S.victim = null; } }
                if (!S.rest) {
                    var w = sub(S.ground, mul(facing(S.yaw), width(self) + VICTIM_GAP + 0.4));
                    S.rest = grounded(C, w);
                    if (Math.abs(S.rest.y - S.ground.y) > 3) S.rest = V(w.x, S.ground.y, w.z);
                }
                if (tick < STEP_START) { C.place(S.heel, S.yaw); return true; }
                var u = clamp01((tick - STEP_START) / (STEP_END - STEP_START));
                C.place(up(lerp(S.heel, S.rest, u), Math.sin(u * Math.PI) * 0.6), S.yaw);
                return true;
            }
            if (!S.victim || !S.victim.valid(self, MAX_VICTIM)) return false;
            var v = S.victim.e, f = facing(S.yaw), back = S.yaw + 180;
            if (tick < UPPERCUT) {
                C.place(lerp(S.origin, S.base, smooth(clamp01((tick - DASH_START) / (DASH_END - DASH_START)))), S.yaw);
                if (tick < GUT) S.held = lerp(S.held, S.start, 0.4);
                if (tick === GUT) {
                    S.held = add(S.start, mul(f, GUT_PUSH));
                    hit(C, S, GUT_SHARE, 2.8, "critic_punch2", f);
                    S.victim.flinch();
                    C.frame(0.8, 0.05, 6, true);
                    shock(C, up(S.held, height(v) * 0.5), 2.5, CM, 8);
                }
                S.victim.hold(S.held, back);
                return true;
            }
            if (tick < APPEAR) {
                if (tick === UPPERCUT) {
                    S.apex = clearPoint(dim, up(S.held, 1), up(add(S.held, mul(f, LAUNCH_DIST)), LAUNCH_HEIGHT), width(v) * 0.5 + 0.2);
                    hit(C, S, UPPERCUT_SHARE, 2.6, "critic_punch1", V(0, 1, 0));
                    S.victim.launched();
                    shock(C, up(S.held, 1), 3.5, 0xFFFFFF, 10);
                    C.snd(S.held, "evasion2", 1.5, 0.7);
                }
                var lift = easeOut(clamp01((tick - UPPERCUT) / (LAUNCH_END - UPPERCUT)));
                S.victim.hold(lerp(add(S.start, mul(f, GUT_PUSH)), S.apex, lift), back);
                if (tick === POWER) { C.shake(true, 10); shock(C, up(S.base, 0.1), 4.5, CM, 12); C.snd(S.base, "aura_start", 1.6, 0.8); }
                if (tick >= POWER && tick < VANISH) sparks(C, 0.6);
                if (tick === VANISH) {
                    S.held = S.apex;
                    after(C, pos(self), S.yaw);
                    RPG.world.particle(dim, "minecraft:electric_spark", S.base.x, S.base.y + 1, S.base.z, 20, 0.6, 0.3);
                    C.snd(S.base, "zanzoken", 1.5, 1.2);
                }
                if (tick < VANISH) C.place(S.base, S.yaw);
                else C.place(lerp(S.base, airBehind(S.apex, f, self, v), smooth((tick - VANISH) / (APPEAR - VANISH))), S.yaw);
                return true;
            }
            if (tick < RAM_START) {
                if (tick === APPEAR) S.flurry = S.apex;
                var fi = FLURRY.indexOf(tick);
                if (fi >= 0) {
                    S.flurry = clearPoint(dim, S.flurry, add(S.flurry, mul(f, FLURRY_PUSH)), width(v) * 0.5 + 0.2);
                    hit(C, S, FLURRY_SHARE, 2.2, fi % 2 === 0 ? "punch4" : "punch5", fi % 2 === 0 ? up(f, 0.3) : f);
                    S.victim.flinch();
                }
                if (tick === FLASH) C.frame(0.6, 0.05, 2, false);
                if (tick < BIG_PUNCH) {
                    S.held = lerp(S.held, S.flurry, 0.5);
                    S.victim.hold(S.held, back);
                    C.place(airBehind(S.held, f, self, v), S.yaw);
                    return true;
                }
                if (tick === BIG_PUNCH) {
                    S.brace = pos(self);
                    S.far = clearPoint(dim, S.flurry, up(add(S.flurry, mul(f, BLOWN_DIST)), BLOWN_RISE), width(v) * 0.5 + 0.3);
                    hit(C, S, BIG_PUNCH_SHARE, 3.2, "critic_punch1", f);
                    S.victim.launched();
                    C.frame(0.75, 0.05, 3, false);
                    shock(C, up(S.flurry, 1), 4.0, CM, 10);
                }
                S.held = lerp(S.flurry, S.far, easeOut(clamp01((tick - BIG_PUNCH) / (BLOWN_END - BIG_PUNCH))));
                S.victim.hold(S.held, back);
                C.place(S.brace, S.yaw);
                if (tick === RAGE) { C.shake(true, 9); C.snd(S.brace, "ki_charge_loop", 1.5, 1.4); }
                if (tick >= RAGE) sparks(C, 0.8);
                return true;
            }
            if (tick < SLAM) {
                if (tick === RAM_START) {
                    S.ram = up(sub(S.far, mul(f, gap(self, v, VICTIM_GAP))), RIDE_HEIGHT);
                    S.ground = grounded(C, S.far);
                    after(C, pos(self), S.yaw);
                    C.shake(false, 7);
                    C.snd(S.brace, "zanzoken", 1.5, 0.8);
                }
                if (tick <= RAM) {
                    C.place(lerp(S.brace, S.ram, smooth((tick - RAM_START) / (RAM - RAM_START))), S.yaw);
                    S.victim.hold(S.far, back);
                    if (tick === RAM) {
                        hit(C, S, RAM_SHARE, 3.6, "critic_punch2", V(f.x, -0.6, f.z));
                        S.victim.knockDown();
                        C.frame(0.85, 0.05, 3, true);
                        burst(C, up(S.far, 1), f, 5.0, 0xFFFFFF, CM, false, 14);
                    }
                    return true;
                }
                S.held = lerp(S.far, S.ground, Math.pow((tick - RAM) / (SLAM - RAM), 2));
                S.victim.hold(S.held, back);
                S.ride = sub(up(S.held, RIDE_HEIGHT), mul(f, 0.3));
                C.place(S.ride, S.yaw);
                return true;
            }
            if (tick === SLAM) {
                S.victim.hold(S.ground, back);
                hit(C, S, SLAM_SHARE, 3.4, "anchor_slam", V(0, -1, 0));
                S.victim.knockDown();
                gi(C, S.ground, 6.0);
                C.frame(0.75, 0.05, 2, false);
                var w2 = sub(S.ground, mul(f, gap(self, v, VICTIM_GAP) + STAND_BACK));
                S.stand = grounded(C, w2);
                if (Math.abs(S.stand.y - S.ground.y) > 3) S.stand = V(w2.x, S.ground.y, w2.z);
                S.axeAir = up(sub(S.ground, mul(f, gap(self, v, VICTIM_GAP) * 0.8)), AXE_HEIGHT);
                S.heel = up(sub(S.ground, mul(f, gap(self, v, VICTIM_GAP) * 0.6)), HEEL_HEIGHT);
                C.place(S.ride, S.yaw);
                return true;
            }
            S.victim.hold(S.ground, back);
            if (tick <= HOP_END) {
                var u2 = (tick - SLAM) / (HOP_END - SLAM);
                C.place(up(lerp(S.ride, S.stand, u2), Math.sin(u2 * Math.PI) * HOP_ARC), S.yaw);
                if (tick === HOP_END) dust(C, up(S.stand, 0.1), 10, 0.4, 0.1, 0.03);
                return true;
            }
            if (tick < JUMP_START) { C.place(S.stand, S.yaw); return true; }
            if (tick <= JUMP_END) {
                C.place(lerp(S.stand, S.axeAir, smooth((tick - JUMP_START) / (JUMP_END - JUMP_START))), S.yaw);
                if (tick === JUMP_START) C.snd(S.stand, "evasion1", 1.3, 1.0);
                return true;
            }
            if (tick < FLIP_START) {
                C.place(S.axeAir, S.yaw);
                if (tick >= FLAME_START && (tick - FLAME_START) % 2 === 0) {
                    RPG.world.particle(dim, "minecraft:flame", self.x, self.y + height(self) * 0.5, self.z, 5, 0.5, 0.02);
                    RPG.world.particle(dim, "minecraft:electric_spark", self.x, self.y + height(self) * 0.6, self.z, 2, 0.4, 0.1);
                }
                if (tick === FLAME_START) { C.shake(true, 8); C.snd(S.axeAir, "aura_start", 1.5, 1.0); }
                return true;
            }
            if (tick < AXE) {
                C.place(lerp(S.axeAir, S.heel, Math.pow((tick - FLIP_START) / (AXE - FLIP_START), 2)), S.yaw);
                if (tick === FLIP_START || tick === FLIP_START + 4) slash(C, up(pos(self), height(self) * 0.5), V(f.x, 0, f.z), 0.6, 90, 1.8, CM, 0xFFFFFF, 8);
                if (tick === FLIP_START) C.snd(S.axeAir, "evasion2", 1.6, 0.6);
                if (tick === AXE - 2) C.snd(S.axeAir, "ki_explosion_charge", 1.4, 1.4);
                return true;
            }
            C.place(S.heel, S.yaw);
            // axe(): the finisher on the ground
            S.finished = true;
            C.strikeHit(v, C.strikeBudget * AXE_SHARE, true);
            S.victim.knockOut();
            var at = S.ground;
            burst(C, up(at, 0.5), V(0, -1, 0), 7.5, CM, CD, false, 20);
            C.frame(0.9, 0.05, 5, true);
            C.shake(true, 14);
            shock(C, up(at, 0.3), 13.0, 0xFFFFFF, 18);
            boom(C, up(at, 0.3), 5.5, CM, CD, CD);
            gi(C, at, 9.0);
            C.snd(at, "critic_punch1", 3.0, 0.7);
            C.snd(at, "ki_explosion_impact", 2.5, 0.9);
            C.snd(at, "anchor_slam", 3.0, 0.6);
            if (!alive(v)) { S.victim.release(); S.victim = null; }
            return true;
        }
        return { DURATION: DURATION, RANGE: RANGE, tick: tick, release: function () { } };
    })();

    var COMBOS = { meteor_burst: MB, mystic_ball: MY, darkness_eye_beam: EB, death_chaser: DC, android_combo: AC, beam_sword_slash: BS, perfect_rush: PR,
        spirit_breaker: SB };
    return {
        has: function (id) { return !!COMBOS[id]; },
        duration: function (id) { return COMBOS[id] ? COMBOS[id].DURATION : 0; },
        /** One tick: false = interrupted (half cooldown). */
        tick: function (id, C, S, n) { return COMBOS[id].tick(C, S, n); },
        /** Always called when the strike ends: lets the victim go, removes held visuals. */
        release: function (id, C, S) {
            try { COMBOS[id].release(C, S); } catch (e) { }
            if (S.victim) { try { S.victim.release(); } catch (e2) { } S.victim = null; }
        },
        isHeld: function (p) { var t = LEASE[p.uuid]; return t !== undefined && now() - t <= 40; },
        // shared with 41s_dmz_strikes.js (grab, the clash)
        Held: Held, capture: capture, canTarget: canTarget, facing: facing, yawTowards: yawTowards, groundHeight: groundHeight, clip: clip,
        fits: fits, clearPoint: clearPoint
    };
})();
