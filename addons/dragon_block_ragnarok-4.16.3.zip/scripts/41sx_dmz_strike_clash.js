// =====================================================================================
//  41sx_dmz_strike_clash.js - two strike rushes meeting head on (the original's StrikeClash)
// =====================================================================================
//  Port of the original (GPL-3.0, see NOTICE.md): StrikeClash, with the beam clash's meter (ClashParticipant /
//  ClashMeter / BeamClash.advanceBias: DBR_CLASH, 41b_dbr_beam_clash.js).
//  - Detection (tryStart, every tick of a rush): another player rushing (a strike rush, 41s_dmz_strikes.js) within
//    4.5 blocks body to body, both heading at each other (rushing at the other, or looking within dot 0.35 of it),
//    not allies. One twice the other's height or more simply shrugs the smaller rush off (it fails). A strike cast at
//    someone rushing at you starts a rush back instead of a teleport, so the two rushes meet.
//  - Both rushes end without their penalty; the fighters are placed fist to fist (each reach = 1.05 / 1.8 of their
//    height, at least 0.9, from the middle; the grounded one's height when only one stands), facing along the axis,
//    held there (40b_dbr_clash_lock.js) in skp.strike_clash with their aura on, and get the beam clash HUD and camera
//    ("dbr_clash", client/scripts/61_dbr_space.js): right click on the marker. Power = melee + strike damage.
//  - The tug of war slides both 0.6 blocks along the axis at most. 0.8 wins; 100 ticks without presses from either is a
//    tie; after 240 ticks the one ahead wins. Shockwaves in both colours every 5 ticks, sparks and dust every 3, a punch
//    sound every 9.
//  - Winner: no cooldown for its strike. Loser: half the winner's strike damage, thrown 2.6 away (0.45 up) into a
//    collision impact (a fifth of that damage), stunned 70 ticks (EXHAUSTED) 8 ticks later, full cooldown. Tie: both
//    thrown 1.4 apart, half cooldowns. Clashing fighters take no damage.
// =====================================================================================
var DMZ_STRIKE_CLASH = (function () {
    var TRIGGER_GAP = 4.5, HEADING_DOT = 0.35, SIZE_DOMINANCE = 2.0, REACH_PER_HEIGHT = 1.05 / 1.8, MIN_REACH = 0.9, FIST_RATIO = 0.62,
        SLIDE = 0.6, MAX_DURATION = 240, IDLE_TIE = 100, LOSER_DAMAGE = 0.5, IMPACT_RATIO = 0.2, LOSER_KB = 2.6, LOSER_LIFT = 0.45,
        EXHAUST_DELAY = 8, TIE_KB = 1.4, TIE_LIFT = 0.3, TIE_CD = 0.5, SHOCK_EVERY = 5, DUST_EVERY = 3, PUNCH_EVERY = 9, POSE = "skp.strike_clash";
    var K = DBR_CLASH, ACTIVE = [], EXHAUST = [];
    function S() { return DMZ_STRIKES; }
    function M() { return DBR_BEAM_CLASH.meter; }
    function alive(e) { try { return !!e && e.isAlive(); } catch (x) { return false; } }
    function tick() { return RPG.server.getTick(); }
    function center(e) { return { x: e.x, y: e.y + e.height / 2, z: e.z }; }
    function gap(a, b) {
        var ca = center(a), cb = center(b), dx = ca.x - cb.x, dy = ca.y - cb.y, dz = ca.z - cb.z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz) - (a.width + b.width) * 0.5;
    }
    function lookVec(p) { var y = p.yaw * Math.PI / 180, pt = p.pitch * Math.PI / 180; return { x: -Math.sin(y) * Math.cos(pt), y: -Math.sin(pt), z: Math.cos(y) * Math.cos(pt) }; }
    function headingTowards(self, other) {
        var t = S().rushTarget(self);
        if (t && t.uuid === other.uuid) return true;
        var h = lookVec(self), ca = center(self), cb = center(other), d = { x: cb.x - ca.x, y: cb.y - ca.y, z: cb.z - ca.z };
        var l = Math.sqrt(d.x * d.x + d.y * d.y + d.z * d.z);
        if (l < 1e-3) return true;
        return (h.x * d.x + h.y * d.y + h.z * d.z) / l >= HEADING_DOT;
    }
    function allies(a, b) { try { return a.isAlly(b) || b.isAlly(a); } catch (x) { return false; } }
    function rushing(e) { return e && e.isPlayer() && S().isRushing(e.asPlayer()); }
    function isClashing(u) { for (var i = 0; i < ACTIVE.length; i++) if (ACTIVE[i].a.uuid === u || ACTIVE[i].b.uuid === u) return true; return false; }
    function beamClashing(u) { return typeof DBR_BEAM_CLASH !== "undefined" && DBR_BEAM_CLASH.isClashing(u); }
    function hexColor(p) {
        var f = typeof DMZ_TF !== "undefined" ? DMZ_TF.activeForm(p) : null;
        return String((f && f.aura) || p.getColor("aura") || "#FFFFFF");
    }
    function power(p) { try { return Math.max(1, S().helpers().meleeDamage(p) + S().helpers().strikeDamage(p)); } catch (x) { return 1; } }

    /** isRushingAt: rusher is rushing toward target (a strike cast at it rushes back instead of teleporting). */
    function isRushingAt(rusher, target) {
        if (!rushing(rusher) || beamClashing(rusher.uuid) || allies(rusher, target)) return false;
        return headingTowards(rusher.asPlayer(), target);
    }
    function tryStart(self) {
        if (!alive(self) || !S().isRushing(self) || beamClashing(self.uuid) || isClashing(self.uuid)) return false;
        var best = null, bg = 1e9, done = false;
        RPG.world.entitiesNear(self.dimension, self.x, self.y + 1, self.z, TRIGGER_GAP + 3).forEach(function (o) {
            if (done || o.uuid === self.uuid || !alive(o) || !rushing(o)) return;
            var op = o.asPlayer();
            if (beamClashing(o.uuid) || isClashing(o.uuid) || allies(self, op)) return;
            var g = gap(self, op);
            if (g > TRIGGER_GAP || !headingTowards(self, op) || !headingTowards(op, self)) return;
            if (op.height >= self.height * SIZE_DOMINANCE) { S().cancelRush(self); done = true; return; }
            if (self.height >= op.height * SIZE_DOMINANCE) { S().cancelRush(op); return; }
            if (g < bg) { bg = g; best = op; }
        });
        if (done) return true;
        if (!best) return false;
        start(self, best);
        return true;
    }
    function reach(e) { return Math.max(MIN_REACH, e.height * REACH_PER_HEIGHT); }
    function fits(e, p) { return typeof DMZ_STRIKE_COMBOS === "undefined" || DMZ_STRIKE_COMBOS.fits(e.dimension, e, p); }
    function pickAnchor(e, x, y, z) {
        var shared = { x: x, y: y, z: z };
        if (fits(e, shared)) return shared;
        var own = { x: x, y: e.y, z: z };
        if (fits(e, own)) return own;
        return { x: e.x, y: e.y, z: e.z };
    }
    function side(p, rush, anchor, yaw) {
        var color = hexColor(p), s = M().participant(p, power(p), color);
        return { p: p, uuid: p.uuid, rush: rush, anchor: anchor, yaw: yaw, color: color, m: s };
    }
    function start(first, second) {
        var ra = S().takeRush(first), rb = S().takeRush(second);
        var ax = second.x - first.x, az = second.z - first.z, al = Math.sqrt(ax * ax + az * az);
        if (al < 1e-3) { var y0 = first.yaw * Math.PI / 180; ax = -Math.sin(y0); az = Math.cos(y0); al = 1; }
        ax /= al; az /= al;
        var mid = { x: (first.x + second.x) / 2, y: (first.y + second.y) / 2, z: (first.z + second.z) / 2 };
        var ga = first.isOnGround(), gb = second.isOnGround(), baseY = ga && !gb ? first.y : gb && !ga ? second.y : mid.y;
        var anA = pickAnchor(first, mid.x - ax * reach(first), ga ? first.y : baseY, mid.z - az * reach(first));
        var anB = pickAnchor(second, mid.x + ax * reach(second), gb ? second.y : baseY, mid.z + az * reach(second));
        var yawA = Math.atan2(az, ax) * 180 / Math.PI - 90, yawB = yawA + 180;
        var fistY = (anA.y + first.height * FIST_RATIO + anB.y + second.height * FIST_RATIO) * 0.5;
        var c = { a: side(first, ra, anA, yawA), b: side(second, rb, anB, yawB), axis: { x: ax, z: az }, base: { x: mid.x, y: fistY, z: mid.z },
            dim: first.dimension, age: 0, bias: 0.5, slide: 0, startMs: Date.now() };
        enter(c, c.a, c.b); enter(c, c.b, c.a);
        ACTIVE.push(c);
        var pt = point(c);
        fx(c, { t: "burst", x: pt.x, y: pt.y, z: pt.z, d: [ax, 0, az], s: 5.0, c: c.a.color, c2: c.b.color, g: 1, life: 16 });
        fx(c, { t: "shock", x: pt.x, y: pt.y, z: pt.z, s: 6.0, c: c.a.color, life: 14 });
        sfx(at(c, pt), "critic_punch2", 2.5, 0.8);
        sfx(at(c, pt), "ki_explosion_impact", 1.5, 1.2);
    }
    function at(c, p) { return { dimension: c.dim, x: p.x, y: p.y, z: p.z }; }
    function point(c) { return { x: c.base.x + c.axis.x * c.slide, y: c.base.y, z: c.base.z + c.axis.z * c.slide }; }
    function fx(c, msg) {
        var pt = point(c);
        RPG.server.players().forEach(function (v) {
            try { if (v.dimension === c.dim && Math.abs(v.x - pt.x) < 96 && Math.abs(v.z - pt.z) < 96) RPG.net.send(v, "dmz_strike_fx", msg); } catch (x) { }
        });
    }
    function enter(c, s, foe) {
        var p = s.p;
        p.setShared("rgDash", 1);                              // the aura shows (setAuraActive)
        p.teleportTo(p.dimension, s.anchor.x, s.anchor.y, s.anchor.z, s.yaw, 0);
        DBR_LOCK.lock(p, "strike", { at: s.anchor, yaw: s.yaw, pitch: 0, use: true });
        act(p, POSE, MAX_DURATION + 20);
        RPG.net.send(p, "dbr_clash", { start: true, beam: 1, hi: s.m.seed.hi, lo: s.m.seed.lo, self: s.color, foe: foe.color, adv: 0.5,
            title: "§c§lBEAM CLASH!", you: "YOU", them: "FOE", opp: foe.p.entityId, x: c.base.x, y: c.base.y, z: c.base.z });
    }
    function hold(c, s) {
        var a = { x: s.anchor.x + c.axis.x * c.slide, y: s.anchor.y, z: s.anchor.z + c.axis.z * c.slide };
        if (!fits(s.p, a)) a = s.anchor;
        DBR_LOCK.lock(s.p, "strike", { at: a });
    }
    function step(c) {
        if (!alive(c.a.p) || !alive(c.b.p) || !c.a.p.isConnected() || !c.b.p.isConnected() || c.a.p.dimension !== c.b.p.dimension) return "dissolve";
        c.age++;
        M().tickMeter(c, c.a.m); M().tickMeter(c, c.b.m);
        c.bias = K.advanceBias(c.bias, c.a.m, c.b.m);
        var vis = K.visualBias(c.bias);
        c.slide = (vis - 0.5) * 2 * SLIDE;
        hold(c, c.a); hold(c, c.b);
        struggle(c, vis);
        if (c.age % 2 === 0) [c.a, c.b].forEach(function (s) {
            var pt = point(c);
            RPG.net.send(s.p, "dbr_clash", { adv: s === c.a ? vis : 1 - vis, x: pt.x, y: pt.y, z: pt.z });
        });
        if (c.bias >= K.WIN) return "a";
        if (c.bias <= 1 - K.WIN) return "b";
        if (Math.min(c.a.m.idle, c.b.m.idle) >= IDLE_TIE) return "tie";
        if (c.age >= MAX_DURATION) return c.bias > 0.5 ? "a" : c.bias < 0.5 ? "b" : "tie";
        return "on";
    }
    function struggle(c, vis) {
        var pt = point(c), dec = Math.abs(vis - 0.5) * 2;
        if (c.age % SHOCK_EVERY === 0) fx(c, { t: "shock", x: pt.x, y: pt.y, z: pt.z, s: 2.4 + 1.6 * dec, c: (c.age / SHOCK_EVERY) % 2 === 0 ? c.a.color : c.b.color, life: 9 });
        if (c.age % DUST_EVERY === 0) {
            fx(c, { t: "sparks", x: pt.x, y: pt.y, z: pt.z, c: Math.random() < 0.5 ? c.a.color : c.b.color, n: 3 });
            var gy = Math.min(c.a.anchor.y, c.b.anchor.y);
            for (var d = 0; d < 3; d++) {
                var by = Math.floor(gy - 0.5) - d;
                if (RPG.world.getBlock(c.dim, Math.floor(pt.x), by, Math.floor(pt.z)) === "minecraft:air") continue;
                RPG.world.particle(c.dim, "minecraft:cloud", pt.x, by + 1.1, pt.z, 6, 1.2, 0.12);
                break;
            }
        }
        if (c.age % PUNCH_EVERY === 0) sfx(at(c, pt), "punch" + (1 + Math.floor(Math.random() * 6)), 1.2, 0.8 + Math.random() * 0.3);
    }
    function release(c, s) {
        var p = s.p;
        try {
            if (!p.isConnected()) return;
            RPG.net.send(p, "dbr_clash", { end: true, exhaust: 0 });
            p.setShared("rgDash", null);
            DBR_LOCK.unlock(p, "strike");
            stopAct(p);
        } catch (x) { }
    }
    function settle(s, ratio) { if (s.rush) S().settleRush(s.p, s.rush, ratio); }
    function finish(c, w, l) {
        release(c, w); release(c, l);
        settle(w, 0); settle(l, 1);
        var pt = point(c), v = l.p, dx = v.x - w.p.x, dz = v.z - w.p.z, dl = Math.sqrt(dx * dx + dz * dz);
        var dir = dl < 1e-3 ? { x: c.axis.x * (w === c.a ? 1 : -1), y: 0, z: c.axis.z * (w === c.a ? 1 : -1) } : { x: dx / dl, y: 0, z: dz / dl };
        try { if (l.p.isConnected()) RPG.net.send(l.p, "dbr_clash", { end: true, exhaust: K.LOSER_EXHAUST }); } catch (x) { }
        if (alive(v)) {
            var dmg = winnerDamage(w) * LOSER_DAMAGE;
            if (dmg > 0) v.damageFrom(dmg, w.p, { kind: "strike", tag: "dmzstrike:" + (w.rush ? w.rush.id : "clash"), ignoreIFrames: true, knockback: 0 });
            if (alive(v)) {
                v.setVelocity(dir.x * LOSER_KB, LOSER_LIFT, dir.z * LOSER_KB);
                S().impact(v, v.isOnGround() ? "ground" : "wall", { dir: dir, dmg: dmg * IMPACT_RATIO, by: w.p, tag: "dmzstrike:clash" });
                EXHAUST.push({ p: v, due: tick() + EXHAUST_DELAY });
            }
        }
        fx(c, { t: "burst", x: pt.x, y: pt.y, z: pt.z, d: [dir.x, 0, dir.z], s: 5.5, c: w.color, c2: l.color, g: 1, life: 18 });
        fx(c, { t: "shock", x: pt.x, y: pt.y, z: pt.z, s: 7.0, c: w.color, life: 14 });
        sfx(at(c, pt), "critic_punch1", 2.5, 0.8);
    }
    function winnerDamage(w) {
        if (!w.rush) return 0;
        var r = 1;
        try { r = DMZ_TECH_DATA.strikeActualMult(w.rush.id, ((S().helpers().rec(w.p, w.rush.id)) || {}).d); } catch (x) { }
        return S().helpers().strikeDamage(w.p) * r;
    }
    function tie(c) {
        release(c, c.a); release(c, c.b);
        settle(c.a, TIE_CD); settle(c.b, TIE_CD);
        try { c.a.p.setVelocity(-c.axis.x * TIE_KB, TIE_LIFT, -c.axis.z * TIE_KB); c.b.p.setVelocity(c.axis.x * TIE_KB, TIE_LIFT, c.axis.z * TIE_KB); } catch (x) { }
        var pt = point(c);
        fx(c, { t: "burst", x: pt.x, y: pt.y, z: pt.z, d: [0, 1, 0], s: 4.5, c: c.a.color, c2: c.b.color, g: 1, life: 16 });
        fx(c, { t: "shock", x: pt.x, y: pt.y, z: pt.z, s: 5.0, c: "#FFFFFF", life: 12 });
        sfx(at(c, pt), "ki_explosion_impact", 2.0, 0.9);
    }
    RPG.every(1, function () {
        if (!ACTIVE.length && !EXHAUST.length) return;
        for (var i = ACTIVE.length - 1; i >= 0; i--) {
            var c = ACTIVE[i], r;
            try { r = step(c); } catch (err) { RPG.log("[DBR] strike clash error: " + err); r = "dissolve"; }
            if (r === "on") continue;
            ACTIVE.splice(i, 1);
            try {
                if (r === "a") finish(c, c.a, c.b);
                else if (r === "b") finish(c, c.b, c.a);
                else if (r === "tie") tie(c);
                else { release(c, c.a); release(c, c.b); settle(c.a, TIE_CD); settle(c.b, TIE_CD); }
            } catch (err2) { RPG.log("[DBR] strike clash end error: " + err2); }
        }
        var now = tick();
        for (var j = EXHAUST.length - 1; j >= 0; j--) {
            var e = EXHAUST[j];
            if (now < e.due) continue;
            EXHAUST.splice(j, 1);
            try { if (alive(e.p)) { e.p.removeEffect("stunned"); e.p.addEffect("stunned", K.LOSER_EXHAUST); } } catch (x) { }
        }
    });
    // the press (StrikeClash.handlePress): the same meter and press check as a beam clash
    RPG.net.on("dbr_clash_press", function (p, d) {
        if (!p || !d) return;
        for (var i = 0; i < ACTIVE.length; i++) {
            var c = ACTIVE[i], s = c.a.uuid === p.uuid ? c.a : c.b.uuid === p.uuid ? c.b : null;
            if (!s) continue;
            var g = M().registerPress(c, s.m, d.t, d.m);
            if (g === "PERFECT" || g === "GOOD") sfx(p, M().PUNCHES[Math.floor(Math.random() * M().PUNCHES.length)], 1, (g === "PERFECT" ? 1.15 : 0.95) + Math.random() * 0.1);
            return;
        }
    });
    RPG.on("damageAttempt", function (e) { if (e.target && ACTIVE.length && isClashing(e.target.uuid)) e.cancel(); });
    RPG.on("playerJoin", function (p) { try { p.setShared("rgDash", null); } catch (x) { } });

    // /rpgc strikeclash auto <player>: that player's presses are perfect (a tester), like /rpgc beamtest auto
    var AUTO = {};
    RPG.every(1, function () {
        for (var i = 0; i < ACTIVE.length; i++) [ACTIVE[i].a, ACTIVE[i].b].forEach(function (s) {
            if (!AUTO[s.uuid]) return;
            var c = ACTIVE[i], nowS = K.sample(s.m.seed, c.age), next = K.sample(s.m.seed, c.age + 1);
            if (nowS.cycle.index <= s.m.consumed || nowS.grade === "MISS" || (next.cycle.index === nowS.cycle.index && next.distance < nowS.distance)) return;
            s.m.consumed = nowS.cycle.index; s.m.momentum += nowS.efficiency; s.m.idle = 0;
        });
    });
    RPG.commands.register("strikeclash", {
        description: "Strike clash test aid: /rpgc strikeclash auto <player>",
        permission: 2,
        run: function (p, args) {
            var who = args[1] ? RPG.server.player(String(args[1])) : p;
            if (!who) return;
            AUTO[who.uuid] = !AUTO[who.uuid];
            if (p) p.tell("&aPerfect strike clash presses for " + who.name + ": " + (AUTO[who.uuid] ? "on" : "off"));
        }
    });
    return { tryStart: tryStart, isRushingAt: isRushingAt, isClashing: isClashing };
})();
