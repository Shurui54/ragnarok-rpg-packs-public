// =====================================================================================
//  41v_dmz_volleys.js - the original's barrage techniques, simulated without entities
// =====================================================================================
//  Port of the original (GPL-3.0, see NOTICE.md): KiBlastEntity.tickAssaultRain / tickBlasterMeteor /
//  spawnVolleyShot and HellzoneGrenadeEntity (+ its Orb). The original spawns one entity per shot (Assault Rain:
//  7 every 2 ticks, Blaster Meteor: 8 every 2 ticks, Hellzone Grenade: up to 52 orbs). Here every shot is a few
//  numbers on the server: it flies straight, finds where it meets terrain with one ray when it is fired, tests
//  the few living things near the volley each tick, and hits, pulses and explodes with the original's numbers.
//  Each client draws them from one batched message a tick ("dmz_vol", client/scripts/51v_dmz_volleys.js).
//
//  Shots (the original's small ki blast, render type 0, size 0.8): damage = the attack's damage, 60 ticks of
//  flight; a direct hit deals it and splashes, then it explodes (radius 2.5, everything in the box, crater 2.5
//  under the ki-griefing rules, KI_EXPLOSION 4.5, boom 5 / 0.6); every 10 ticks in flight it hits everything
//  within 5.4 blocks for a third (pulseAreaDamage); at the end of its flight it explodes where it is.
// =====================================================================================
var DMZ_VOLLEY = (function () {
    var BALL = 0.8, SHOT_LIFE = 60, RISER_LIFE = 12, VIEW = 160;
    function num(v, d) { var n = Number(v); return isNaN(n) ? d : n; }
    function r2(v) { return Math.round(v * 100) / 100; }
    function norm(x, y, z) { var l = Math.sqrt(x * x + y * y + z * z); return l < 1e-9 ? { x: 0, y: 0, z: 0 } : { x: x / l, y: y / l, z: z / l }; }
    function gauss() { var u = 0; while (u === 0) u = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * Math.random()); }
    function now() { return RPG.server.getTick(); }
    function lookDir(p) {
        var yaw = p.yaw * Math.PI / 180, pitch = p.pitch * Math.PI / 180;
        return { x: -Math.sin(yaw) * Math.cos(pitch), y: -Math.sin(pitch), z: Math.cos(yaw) * Math.cos(pitch) };
    }
    function colorsArr(c) { return [c.core, c.border, c.outline]; }

    // ---- what goes to the clients: everything new this tick, one message per player ----
    var EV = [];                                         // {dim, x, z, e: [...]}
    function emit(dim, x, z, e) { EV.push({ dim: dim, x: x, z: z, e: e }); }
    function flush() {
        if (!EV.length) return;
        var evs = EV; EV = [];
        RPG.server.players().forEach(function (pl) {
            var out = null;
            try {
                for (var i = 0; i < evs.length; i++) {
                    var v = evs[i];
                    if (v.dim !== pl.dimension || Math.abs(v.x - pl.x) > VIEW || Math.abs(v.z - pl.z) > VIEW) continue;
                    (out || (out = [])).push(v.e);
                }
                if (out) RPG.net.send(pl, "dmz_vol", { e: out });
            } catch (err) { }
        });
    }

    // ---- who a volley can hit this tick: the living things near it, fetched once a tick per owner ----
    var IFR = {};                                        // target uuid -> {t, a}: the hurt window, so blocked hits cost nothing
    function canHurt(o, e) {
        if (!e || e.uuid === o.uuid) return false;
        try { if (!e.isAlive() || o.isAlly(e)) return false; } catch (x) { return false; }
        try {
            if (o.isPlayer() && !e.isPlayer() && !e.isHostile()) {   // AbstractKiProjectile.shouldDamage: neutral = only when looked at
                var lk = lookDir(o), dx = e.x - o.x, dy = e.y + e.height / 2 - o.eyeY, dz = e.z - o.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
                return (dx * lk.x + dy * lk.y + dz * lk.z) / l > 0.95;
            }
        } catch (x2) { }
        return true;
    }
    function gather(o, dim, box) {
        var cx = (box[0] + box[3]) / 2, cy = (box[1] + box[4]) / 2, cz = (box[2] + box[5]) / 2;
        var r = Math.sqrt(Math.pow(box[3] - box[0], 2) + Math.pow(box[4] - box[1], 2) + Math.pow(box[5] - box[2], 2)) / 2 + 8;
        var out = [];
        RPG.world.entitiesNear(dim, cx, cy, cz, Math.min(r, 200)).forEach(function (e) {
            if (!canHurt(o, e)) return;
            var hw = (Number(e.width) || 0.6) / 2, h = Number(e.height) || 1.8;
            out.push({ e: e, x0: e.x - hw, y0: e.y, z0: e.z - hw, x1: e.x + hw, y1: e.y + h, z1: e.z + hw, cx: e.x, cy: e.y + h / 2, cz: e.z });
        });
        return out;
    }
    /** applyDamageOrHeal: a normal ki hit (the hurt window applies). */
    function hurt(o, c, dmg, tag) {
        if (!(dmg > 0)) return false;
        var t = now(), w = IFR[c.e.uuid];
        if (w && t - w.t < 10 && dmg <= w.a) return false;   // still in its hurt window: Minecraft would refuse it too
        var ok = false;
        try { ok = c.e.damageFrom(dmg, o, { kind: "ki", tag: tag, ignoreIFrames: false }) !== false; } catch (x) { }
        if (ok) IFR[c.e.uuid] = { t: t, a: dmg };
        return ok;
    }
    // the segment a->b against a box grown by g: the fraction along it, or -1
    function segBox(ax, ay, az, bx, by, bz, c, g) {
        var t0 = 0, t1 = 1, d = [bx - ax, by - ay, bz - az], a = [ax, ay, az], lo = [c.x0 - g, c.y0 - g, c.z0 - g], hi = [c.x1 + g, c.y1 + g, c.z1 + g];
        for (var i = 0; i < 3; i++) {
            if (Math.abs(d[i]) < 1e-9) { if (a[i] < lo[i] || a[i] > hi[i]) return -1; continue; }
            var u = (lo[i] - a[i]) / d[i], v = (hi[i] - a[i]) / d[i];
            if (u > v) { var s = u; u = v; v = s; }
            if (u > t0) t0 = u;
            if (v < t1) t1 = v;
            if (t0 > t1) return -1;
        }
        return t0;
    }
    function boxDist(c, x, y, z) {
        var dx = Math.max(0, Math.abs(x - c.cx) - (c.x1 - c.x0) / 2), dy = Math.max(0, Math.abs(y - c.cy) - (c.y1 - c.y0) / 2), dz = Math.max(0, Math.abs(z - c.cz) - (c.z1 - c.z0) / 2);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
    function inBox(c, x, y, z, r) { return Math.abs(x - c.cx) <= r + (c.x1 - c.x0) / 2 && Math.abs(y - c.cy) <= r + (c.y1 - c.y0) / 2 && Math.abs(z - c.cz) <= r + (c.z1 - c.z0) / 2; }

    // =========================================================================================
    //  shots: the original's small ki blasts (spawnVolleyShot)
    // =========================================================================================
    var SHOTS = [], NEXT = 1;
    /** shoot(owner, {x, y, z (centre), vx, vy, vz, dmg, tech, colors, swap, life, noBlocks}) */
    function shoot(o, sp) {
        var s = { id: NEXT++, o: o, dim: o.dimension, x: sp.x, y: sp.y, z: sp.z, vx: sp.vx, vy: sp.vy, vz: sp.vz, age: 0, life: sp.life || SHOT_LIFE,
            dmg: num(sp.dmg, 0), tag: "dmzki:" + sp.tech, col: sp.colors, swap: !!sp.swap, hitAt: -1, noBlocks: !!sp.noBlocks };
        s.perHit = s.dmg / Math.max(1, Math.floor(s.life / 20));
        var speed = Math.sqrt(s.vx * s.vx + s.vy * s.vy + s.vz * s.vz);
        if (speed > 1e-6) {
            // it flies straight: where it meets terrain is known now (one ray instead of one a tick)
            var ray = null;
            try { ray = RPG.world.raycast(s.dim, s.x, s.y, s.z, s.vx / speed, s.vy / speed, s.vz / speed, speed * s.life, { blocks: true, entities: false }); } catch (e) { }
            if (ray && ray.hit === "block") { s.hitAt = ray.distance / speed; s.hx = ray.x; s.hy = ray.y; s.hz = ray.z; }
        }
        SHOTS.push(s);
        var c = s.col;
        emit(s.dim, s.x, s.z, ["s", s.id, r2(s.x), r2(s.y), r2(s.z), r2(s.vx), r2(s.vy), r2(s.vz), s.life, c.core, s.swap ? c.outline : c.border, s.swap ? c.border : c.outline]);
        return s;
    }
    /** The original's assault rain risers: no damage, 12 ticks, drawn by the clients only. */
    function riser(dim, x, y, z, vx, vy, vz, c, swap) {
        emit(dim, x, z, ["r", r2(x), r2(y), r2(z), r2(vx), r2(vy), r2(vz), RISER_LIFE, c.core, swap ? c.outline : c.border, swap ? c.border : c.outline]);
    }
    // KiBlastEntity.explodeAndDie for a small blast
    function blast(s, x, y, z, cands) {
        var r = Math.max(BALL * 0.5, 2.5);
        for (var i = 0; i < cands.length; i++) if (inBox(cands[i], x, y, z, r)) hurt(s.o, cands[i], s.dmg, s.tag);
        emit(s.dim, x, z, ["x", s.id, r2(x), r2(y), r2(z)]);
        RPG.world.sound(s.dim, "minecraft:entity.generic.explode", x, y, z, 5, 0.6);
        if (!s.noBlocks && typeof DBR_DESTRUCTION !== "undefined") DBR_DESTRUCTION.blast(s.o, x, y, z, r, false);   // carveKiSphere (unless setBlockDestructionEnabled(false))
    }
    function tickShots() {
        if (!SHOTS.length) return;
        var t = now(), groups = {};
        // one box per owner and dimension round its live shots, for one entity lookup each
        SHOTS.forEach(function (s) {
            var k = s.o.uuid + "|" + s.dim, g = groups[k] || (groups[k] = { o: s.o, dim: s.dim, box: [1e9, 1e9, 1e9, -1e9, -1e9, -1e9] }), b = g.box;
            var nx = s.x + s.vx, ny = s.y + s.vy, nz = s.z + s.vz;
            b[0] = Math.min(b[0], s.x, nx); b[1] = Math.min(b[1], s.y, ny); b[2] = Math.min(b[2], s.z, nz);
            b[3] = Math.max(b[3], s.x, nx); b[4] = Math.max(b[4], s.y, ny); b[5] = Math.max(b[5], s.z, nz);
        });
        for (var k in groups) groups[k].c = gather(groups[k].o, groups[k].dim, groups[k].box);
        var keep = [];
        for (var i = 0; i < SHOTS.length; i++) {
            var s = SHOTS[i], cands = groups[s.o.uuid + "|" + s.dim].c, done = false;
            try {
                var ax = s.x, ay = s.y, az = s.z;
                s.age++;
                s.x += s.vx; s.y += s.vy; s.z += s.vz;
                // a direct hit (the first living thing along this tick's move)
                var best = -1, bt = 2;
                for (var j = 0; j < cands.length; j++) {
                    var f = segBox(ax, ay, az, s.x, s.y, s.z, cands[j], BALL / 2 + 0.3);
                    if (f >= 0 && f < bt) { bt = f; best = j; }
                }
                var blockF = s.hitAt >= 0 && s.age >= s.hitAt ? Math.max(0, 1 - (s.age - s.hitAt)) : 2;
                if (best >= 0 && bt <= blockF) {
                    var c = cands[best], hx = ax + (s.x - ax) * bt, hy = ay + (s.y - ay) * bt, hz = az + (s.z - az) * bt;
                    if (hurt(s.o, c, s.dmg, s.tag)) emit(s.dim, c.cx, c.cz, ["k", r2(c.cx), r2(c.cy), r2(c.cz), 0, 0, BALL, s.col.core, s.col.border, s.col.outline]);
                    blast(s, hx, hy, hz, cands);
                    done = true;
                } else if (blockF <= 1) {
                    blast(s, s.hx, s.hy, s.hz, cands);
                    done = true;
                } else {
                    if (s.age % 10 === 0)                               // pulseAreaDamage: 5 blocks round the ball
                        for (var q = 0; q < cands.length; q++) if (boxDist(cands[q], s.x, s.y, s.z) <= BALL / 2 + 5) hurt(s.o, cands[q], s.perHit, s.tag);
                    if (s.age >= s.life) { blast(s, s.x, s.y, s.z, cands); done = true; }
                }
            } catch (err) { done = true; }
            if (!done && s.o.isAlive && s.o.isAlive()) keep.push(s);
            else if (!done) emit(s.dim, s.x, s.z, ["d", s.id]);
        }
        SHOTS = keep;
        if (t % 200 === 0) for (var u in IFR) if (t - IFR[u].t > 40) delete IFR[u];
    }

    // =========================================================================================
    //  Assault Rain (KiBlastEntity render type 12): an orb over the caster's left shoulder; fired, every 2 ticks
    //  3 shots rise from it (1.8 a tick, leaning toward the target) and, after 10 ticks, 4 shots fall on a disc of
    //  radius 6 round the target from 22 blocks up (or under the ceiling), at 1.6 x the attack's speed (2-3)
    // =========================================================================================
    function rainCenter(p, lock) {
        if (lock && lock.isAlive()) return { x: lock.x, y: lock.y, z: lock.z };
        var hit = null;
        try { hit = p.raycast(40, { blocks: true, entities: true }); } catch (e) { }
        if (hit && hit.hit === "entity" && hit.entity) return { x: hit.entity.x, y: hit.entity.y, z: hit.entity.z };
        if (hit && hit.hit === "block") return { x: hit.x, y: hit.y, z: hit.z };
        var lp = lookPoint(p, 40), end = { x: lp.x, y: p.eyeY + (lp.y - p.y - 1.6), z: lp.z }, g = null;
        try { g = RPG.world.raycast(p.dimension, end.x, end.y, end.z, 0, -1, 0, 64, { blocks: true, entities: false }); } catch (e2) { }
        return g && g.hit === "block" ? { x: g.x, y: g.y, z: g.z } : end;
    }
    function rainHeight(dim, c) {
        var r = null;
        try { r = RPG.world.raycast(dim, c.x, c.y + 1.5, c.z, 0, 1, 0, 22 - 1.5, { blocks: true, entities: false }); } catch (e) { }
        return r && r.hit === "block" ? Math.max(3, r.y - c.y - 1) : 22;
    }
    function assaultRain(p, orb, T, dmg, life, lock) {
        var size = orb ? orb.size : 1, fallSpeed = Math.max(2, Math.min(3, T.speed * 1.6));
        if (orb) DMZ_TECH_PROJ.look(orb, { k: "ball", rt: 12, ct: 40, sz: size, tech: "assault_rain", f: 1 });
        sfx(orb || p, "kiblast_shoot", 0.7, 0.8);
        return {
            until: now() + life + 10, volley: orb,
            emitter: function (age) {
                hover(p);
                if (age % 2 !== 0) return;
                var src = orb && orb.alive ? { x: orb.x, y: orb.y + size * BALL / 2, z: orb.z } : { x: p.x, y: p.y + 1.3 + 0.9, z: p.z };
                var c = rainCenter(p, lock), tw = norm(c.x - src.x, 0, c.z - src.z);
                if (age < life) {
                    for (var i = 0; i < 3; i++) {
                        var d = norm(tw.x * 0.25 + gauss() * 0.22, 1, tw.z * 0.25 + gauss() * 0.22);
                        riser(p.dimension, src.x, src.y, src.z, d.x * 1.8, d.y * 1.8, d.z * 1.8, T.colors, Math.random() < 0.5);
                    }
                    sfx(src.x !== undefined ? { dimension: p.dimension, x: src.x, y: src.y, z: src.z } : p, "kiblast_shoot", 0.15, 1.4 + Math.random() * 0.5);
                }
                if (age >= 10) {
                    var fd = norm(tw.x * 0.15, -1, tw.z * 0.15), h = rainHeight(p.dimension, c), back = h / -fd.y;
                    for (var k = 0; k < 4; k++) {
                        var a = Math.random() * Math.PI * 2, dist = 6 * Math.sqrt(Math.random());
                        var gx = c.x + Math.cos(a) * dist, gz = c.z + Math.sin(a) * dist;
                        shoot(p, { x: gx - fd.x * back, y: c.y - fd.y * back, z: gz - fd.z * back, vx: fd.x * fallSpeed, vy: fd.y * fallSpeed, vz: fd.z * fallSpeed,
                            dmg: dmg, tech: "assault_rain", colors: T.colors, swap: Math.random() < 0.5 });
                    }
                }
            }
        };
    }

    // =========================================================================================
    //  Blaster Meteor (render type 13): a sphere round the caster (1.7 x their height) that lifts them 0.11 a tick
    //  (4 blocks at most) while it charges; fired, every 2 ticks 8 shots leave its surface at max(1, 0.8 x speed):
    //  2 at the target (or along the aim), 6 every which way
    // =========================================================================================
    function meteorSize(p) {
        var h = Number(p.height) || 1.8, w = Number(p.width) || 0.6;
        return Math.max(h * 1.7, Math.sqrt(h * h + w * w) * 1.25);
    }
    function meteorAim(p, center, lock) {
        if (!lock || !lock.isAlive()) return lookDir(p);
        var d = norm(lock.x - center.x, lock.y + lock.height / 2 - center.y, lock.z - center.z);
        return d.x === 0 && d.y === 0 && d.z === 0 ? lookDir(p) : d;
    }
    function blasterMeteor(p, orb, T, dmg, life, lock) {
        var size = meteorSize(p), radius = size * 0.5, speed = Math.max(1, T.speed * 0.8);
        if (orb) DMZ_TECH_PROJ.look(orb, { k: "ball", rt: 13, ct: 40, sz: size, tech: "blaster_meteor", f: 1 });
        sfx(orb || p, "ki_explosion_impact", 0.8, 1.2);
        return {
            until: now() + life, volley: orb,
            emitter: function (age) {
                hover(p);
                if (age % 2 !== 0) return;
                var center = { x: p.x, y: p.y + (Number(p.height) || 1.8) / 2, z: p.z }, aim = meteorAim(p, center, lock);
                for (var i = 0; i < 8; i++) {
                    var d;
                    if (i < 2) d = norm(aim.x + gauss() * 0.12, aim.y + gauss() * 0.12, aim.z + gauss() * 0.12);
                    else { var y = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2, ring = Math.sqrt(1 - y * y); d = { x: ring * Math.cos(th), y: y, z: ring * Math.sin(th) }; }
                    shoot(p, { x: center.x + d.x * radius, y: center.y + d.y * radius, z: center.z + d.z * radius, vx: d.x * speed, vy: d.y * speed, vz: d.z * speed,
                        dmg: dmg, tech: "blaster_meteor", colors: T.colors, swap: Math.random() < 0.5 });
                }
                sfx(p, "kiblast_shoot", 0.15, 1.0 + Math.random() * 0.4);
            }
        };
    }
    // the caster floats while the volley lasts (the anchored volley zeroes their motion every tick)
    function hover(p) {
        try { if (!p.getVar("dmz_explo_ng", 0)) { p.setNoGravity(true); p.setVar("dmz_explo_ng", 1); } p.setVelocity(0, 0, 0); p.fallDistance = 0; } catch (e) { }
    }
    function land(p) {
        try { if (p.getVar("dmz_explo_ng", 0)) { p.setNoGravity(false); p.setVar("dmz_explo_ng", 0); } } catch (e) { }
    }
    /** While Blaster Meteor charges: the caster rises 0.11 a tick, 4 blocks at most. Returns the height risen. */
    function meteorRise(p, risen) {
        var rise = Math.min(0.11, 4 - risen);
        try {
            if (!p.getVar("dmz_explo_ng", 0)) { p.setNoGravity(true); p.setVar("dmz_explo_ng", 1); }
            p.setVelocity(0, Math.max(0, rise), 0); p.fallDistance = 0;
        } catch (e) { }
        return risen + Math.max(0, rise);
    }

    // =========================================================================================
    //  Hellzone Grenade (HellzoneGrenadeEntity + Orb): two orbs form in the hands while it charges; fired at a
    //  target, the two (and two more) are thrown at it (15 % of the damage, a 15-tick stagger), then 18-48 orbs
    //  (by the charge) fly out from alternating hands between ticks 7 and 28 to slots on a shell round the target
    //  (golden-angle directions, kept off walls), hover there bobbing and following it, the caster clenches at 61,
    //  every orb dives at 69 (40 % shared), and at 77 the shell detonates (45 % to everything in it, a push, a
    //  crater, a shockwave) with 7 ticks of chained bursts.
    // =========================================================================================
    var HZ = { OPEN: 4, OPEN_GAP: 2, SC0: 7, SC1: 28, CLENCH: 61, CONVERGE: 69, FINALE: 77, CHAIN: 7, END: 95, MIN: 18, MAX: 48, MAXCH: 1.75,
        SHELL: 3.5, SHELL_MAX: 9, MARGIN: 0.8, REFRESH: 0.75, LOW: -0.45, ARC: 0.9, CRUISE: 1.3, OPEN_SPEED: 2.2, CONV_SPEED: 1.6,
        GAIN: 0.3, SEEK: 0.3, DIVE: 0.55, ARRIVE: 0.6, TIMEOUT: 24, IMPACT: 1.3, STAGGER: 15, AGE: 140, FOLLOW: 0.35 };
    var HELL = {}, HNEXT = 1;
    function yawVec(yaw, add) { var a = (yaw + (add || 0)) * Math.PI / 180; return { x: -Math.sin(a), y: 0, z: Math.cos(a) }; }
    function hzValid(o, t) { return t && t.isAlive() && t.uuid !== o.uuid && !o.isAlly(t); }
    function hzCenter(t) { return { x: t.x, y: t.y + (Number(t.height) || 1.8) / 2, z: t.z }; }
    function hand(p, right) {                                   // HellzoneGrenadeEntity.handPosition (orb centre)
        var f = yawVec(p.yaw), r = yawVec(p.yaw, 90), side = (Number(p.width) || 0.6) * 0.5 + 0.3, h = Number(p.height) || 1.8;
        return { x: p.x + r.x * (right ? side : -side) + f.x * 0.6, y: p.y + h * 0.72, z: p.z + r.z * (right ? side : -side) + f.z * 0.6 };
    }
    function hellzone(p, s, T, dmg, ch, target) {
        var size = s.size, cruise = Math.max(HZ.CRUISE, T.speed), prog = Math.max(0, Math.min(1, ch / HZ.MAXCH));
        var n = Math.round(HZ.MIN + (HZ.MAX - HZ.MIN) * prog);
        var ext = Math.max(Number(target.width) || 0.6, Number(target.height) || 1.8) * 0.5;
        var h = { id: HNEXT++, p: p, dim: p.dimension, t: target, anchor: hzCenter(target), shellR: Math.min(HZ.SHELL_MAX, HZ.SHELL + size * 0.6 + ext),
            n: n, size: size, cruise: cruise, dmg: dmg, col: T.colors, tick: 0, orbs: [], shell: [], right: [], left: [], slotAnchor: null,
            hands: [s.proj, s.proj2], clenched: false, converged: false, finaleDone: false };
        // buildSlots: golden-angle directions from the top down to -0.45, shuffled, split by the caster's right / left
        var rv = yawVec(p.yaw, 90), golden = Math.PI * (3 - Math.sqrt(5)), spin = Math.random() * Math.PI * 2, dirs = [];
        for (var i = 0; i < n; i++) {
            var y = 1 + (HZ.LOW - 1) * ((i + 0.5) / n), ring = Math.sqrt(Math.max(0, 1 - y * y)), th = spin + golden * i;
            dirs.push({ x: Math.cos(th) * ring, y: y, z: Math.sin(th) * ring });
        }
        for (var j = dirs.length - 1; j > 0; j--) { var q = Math.floor(Math.random() * (j + 1)), sw = dirs[j]; dirs[j] = dirs[q]; dirs[q] = sw; }
        dirs.forEach(function (d) { (d.x * rv.x + d.z * rv.z >= 0 ? h.right : h.left).push(d); });
        HELL[h.id] = h;
        sfx(p, "kiblast_shoot", 1, 0.8);
        return h;
    }
    function hzSlot(h, right) {
        var a = right ? h.right : h.left, b = right ? h.left : h.right;
        if (a.length) return a.shift();
        if (b.length) return b.shift();
        var th = Math.random() * Math.PI * 2; return norm(Math.cos(th), 0.3, Math.sin(th));
    }
    function hzSlotOffset(h, d) {                               // kept 0.8 off a wall between the target and the slot
        var r = null;
        try { r = RPG.world.raycast(h.dim, h.anchor.x, h.anchor.y, h.anchor.z, d.x, d.y, d.z, h.shellR, { blocks: true, entities: false }); } catch (e) { }
        var reach = r && r.hit === "block" ? Math.max(0.6, r.distance - HZ.MARGIN) : h.shellR;
        return { x: d.x * reach, y: d.y * reach, z: d.z * reach };
    }
    function hzOrb(h, pos, vel) {
        var o = { i: h.orbs.length, x: pos.x, y: pos.y, z: pos.z, vx: vel ? vel.x : 0, vy: vel ? vel.y : 0, vz: vel ? vel.z : 0, goal: null, cruise: h.cruise,
            diving: false, done: false, free: 0, diveT: 0, dmg: 0, stagger: false, slot: null, off: null, phase: 0 };
        h.orbs.push(o);
        return o;
    }
    function hzDive(h, o, dmg, speed, launch, stagger) {
        o.diving = true; o.goal = h.anchor; o.dmg = dmg; o.cruise = speed; o.stagger = stagger; o.diveT = 0;
        if (launch) { var l = norm(launch.x, launch.y, launch.z); if (l.x || l.y || l.z) { o.vx = l.x * speed; o.vy = l.y * speed; o.vz = l.z * speed; } }
    }
    function hzExplode(h, o, cands) {                           // Orb.explode
        if (o.done) return;
        o.done = true;
        var r = HZ.IMPACT + h.size * 0.5, tag = "dmzki:hellzone_grenade";
        for (var i = 0; i < cands.length; i++) {
            var c = cands[i];
            if (Math.sqrt(Math.pow(c.cx - o.x, 2) + Math.pow(c.cy - o.y, 2) + Math.pow(c.cz - o.z, 2)) > r + Math.max(c.x1 - c.x0, c.y1 - c.y0) / 2) continue;
            try { c.e.invulnerableTime = 0; } catch (x) { }
            if (!hurtOnce(h.p, c, o.dmg, tag)) continue;
            if (o.stagger) { try { if (c.e.isPlayer()) c.e.asPlayer().addEffect("stunned", HZ.STAGGER); else c.e.addPotion("minecraft:slowness", HZ.STAGGER, 9); } catch (x2) { } }
        }
        emit(h.dim, o.x, o.z, ["o", h.id, o.i, r2(o.x), r2(o.y), r2(o.z), r2(h.size * 2.4)]);
        if (Math.random() < 1 / 3) RPG.world.sound(h.dim, DMZ + "ki_explosion_impact", o.x, o.y, o.z, 1.2, 0.9 + Math.random() * 0.4);
    }
    // the hurt window is cleared for every orb, like the original (victim.invulnerableTime = 0)
    function hurtOnce(o, c, dmg, tag) {
        if (!(dmg > 0)) return false;
        try { return c.e.damageFrom(dmg, o, { kind: "ki", tag: tag, ignoreIFrames: true }) !== false; } catch (x) { return false; }
    }
    function hzFinale(h, cands) {
        h.finaleDone = true;
        var c0 = h.anchor, radius = h.shellR + 1, dmg = h.dmg * 0.45, tag = "dmzki:hellzone_grenade";
        cands.forEach(function (c) {
            var d = Math.sqrt(Math.pow(c.cx - c0.x, 2) + Math.pow(c.cy - c0.y, 2) + Math.pow(c.cz - c0.z, 2));
            if (d > radius + Math.max(c.x1 - c.x0, c.y1 - c.y0) / 2) return;
            hurtOnce(h.p, c, dmg, tag);
            var pu = d < 1e-2 ? { x: 0, y: 0, z: 0 } : norm(c.cx - c0.x, c.cy - c0.y, c.cz - c0.z);
            try { c.e.setVelocity(c.e.vx + pu.x * 0.8, c.e.vy + 0.45, c.e.vz + pu.z * 0.8); } catch (x) { }
        });
        // KiExplosionVisualEntity (main, outline, 0xFF3B1F, shell x 0.85) + ShockwaveVfx (radius x 1.6, outline, 18 ticks)
        emit(h.dim, c0.x, c0.z, ["k", r2(c0.x), r2(c0.y), r2(c0.z), r2(h.shellR * 0.85 * 2), 0, 0, h.col.core, h.col.outline, "#FF3B1F"]);
        emit(h.dim, c0.x, c0.z, ["w", r2(c0.x), r2(c0.y), r2(c0.z), r2(radius * 1.6), h.col.outline, 18]);
        emit(h.dim, c0.x, c0.z, ["c", h.id]);                  // the shell is gone
        RPG.world.sound(h.dim, DMZ + "ki_explosion_impact", c0.x, c0.y, c0.z, 3, 0.75);
        RPG.world.sound(h.dim, "minecraft:entity.generic.explode", c0.x, c0.y, c0.z, 4, 0.7);
        if (typeof DBR_DESTRUCTION !== "undefined") DBR_DESTRUCTION.blast(h.p, c0.x, c0.y, c0.z, 2.5, false);   // carveKiSphere(2.5)
        h.shell.forEach(function (o) { o.done = true; });
    }
    function tickHell(h) {
        var p = h.p;
        if (!p.isAlive() || p.dimension !== h.dim) return false;
        var tick = h.tick++, t = h.t;
        // followTarget: the anchor eases 35 % a tick toward the target's middle until the finale
        if (!h.finaleDone && t && t.isAlive() && t.dimension === h.dim) {
            var tc = hzCenter(t);
            h.anchor = { x: h.anchor.x + (tc.x - h.anchor.x) * HZ.FOLLOW, y: h.anchor.y + (tc.y - h.anchor.y) * HZ.FOLLOW, z: h.anchor.z + (tc.z - h.anchor.z) * HZ.FOLLOW };
        }
        // throwOpening: the two hand orbs first, then two fresh ones, one every 2 ticks
        if (tick < HZ.OPEN * HZ.OPEN_GAP && tick % HZ.OPEN_GAP === 0) {
            var idx = tick / HZ.OPEN_GAP, right = idx % 2 === 0, pos = null, hp = idx < 2 ? h.hands[right ? 0 : 1] : null;
            if (hp && hp.alive) { pos = { x: hp.x, y: hp.y + h.size * BALL / 2, z: hp.z }; hp.discard(); }
            if (!pos) pos = hand(p, right);
            var o = hzOrb(h, pos, null), sp = Math.max(HZ.OPEN_SPEED, h.cruise);
            hzDive(h, o, h.dmg * 0.15 / HZ.OPEN, sp, { x: h.anchor.x - o.x, y: h.anchor.y - o.y, z: h.anchor.z - o.z }, true);
            sfx({ dimension: h.dim, x: o.x, y: o.y, z: o.z }, "kiblast_shoot", 0.6, 1.1 + Math.random() * 0.3);
        }
        // scatter: the orbs fly from alternating hands to their slots
        if (tick >= HZ.SC0 && tick <= HZ.SC1) {
            var due = Math.min(h.n, Math.ceil((tick - HZ.SC0 + 1) * h.n / (HZ.SC1 - HZ.SC0 + 1))), rv = yawVec(p.yaw, 90);
            while (h.shell.length < due) {
                var rh = h.shell.length % 2 === 0, d = hzSlot(h, rh), hp2 = hand(p, rh), ob = hzOrb(h, hp2, null);
                ob.slot = d; ob.off = hzSlotOffset(h, d); ob.phase = Math.random() * Math.PI * 2;
                var goal = { x: h.anchor.x + ob.off.x, y: h.anchor.y + ob.off.y, z: h.anchor.z + ob.off.z }, tw = norm(goal.x - ob.x, goal.y - ob.y, goal.z - ob.z);
                if (!tw.x && !tw.y && !tw.z) tw = yawVec(p.yaw);
                var arc = rh ? HZ.ARC : -HZ.ARC, ln = norm(tw.x + rv.x * arc, tw.y + 0.3 + Math.random() * 0.4, tw.z + rv.z * arc);
                ob.goal = goal; ob.vx = ln.x * h.cruise; ob.vy = ln.y * h.cruise; ob.vz = ln.z * h.cruise;
                h.shell.push(ob);
            }
            if (tick % 2 === 0) sfx(p, "kiblast_shoot", 0.35, 1.3 + Math.random() * 0.5);
        }
        // steerShell: slots refreshed when the anchor moved 0.75, goals bob 0.15
        if (!h.converged) {
            var sa = h.slotAnchor, a = h.anchor;
            if (!sa || Math.pow(sa.x - a.x, 2) + Math.pow(sa.y - a.y, 2) + Math.pow(sa.z - a.z, 2) > HZ.REFRESH * HZ.REFRESH) {
                h.slotAnchor = a;
                h.shell.forEach(function (o) { if (!o.done) o.off = hzSlotOffset(h, o.slot); });
            }
            h.shell.forEach(function (o) {
                if (o.done || o.diving) return;
                var bob = Math.sin(tick * 0.3 + o.phase) * 0.15;
                o.goal = { x: a.x + o.off.x, y: a.y + o.off.y + bob, z: a.z + o.off.z };
            });
        }
        if (!h.clenched && tick >= HZ.CLENCH) { h.clenched = true; act(p, "ki.hellzone_grenade_clench", 26); }
        if (!h.converged && tick >= HZ.CONVERGE) {
            h.converged = true;
            var share = h.dmg * 0.4 / Math.max(1, h.n);
            h.shell.forEach(function (o) { if (!o.done) hzDive(h, o, share, HZ.CONV_SPEED, null, false); });
            RPG.world.sound(h.dim, DMZ + "ki_beam_fire", h.anchor.x, h.anchor.y, h.anchor.z, 2, 1.3);
        }
        // the orbs: one entity lookup for the lot
        var live = h.orbs.filter(function (o) { return !o.done; }), cands = null;
        if (live.length || (!h.finaleDone && tick >= HZ.FINALE)) {
            var b = [h.anchor.x, h.anchor.y, h.anchor.z, h.anchor.x, h.anchor.y, h.anchor.z];
            live.forEach(function (o) { b[0] = Math.min(b[0], o.x); b[1] = Math.min(b[1], o.y); b[2] = Math.min(b[2], o.z); b[3] = Math.max(b[3], o.x); b[4] = Math.max(b[4], o.y); b[5] = Math.max(b[5], o.z); });
            b[0] -= h.shellR; b[1] -= h.shellR; b[2] -= h.shellR; b[3] += h.shellR; b[4] += h.shellR; b[5] += h.shellR;
            cands = gather(p, h.dim, b);
        }
        var pos2 = [];
        live.forEach(function (o) {
            if (++o.free > HZ.AGE) { o.done = true; emit(h.dim, o.x, o.z, ["q", h.id, o.i]); return; }
            if (o.diving) {                                      // tickDive
                var aim = o.goal;
                if (t && t.isAlive()) aim = hzCenter(t);
                var dx = aim.x - o.x, dy = aim.y - o.y, dz = aim.z - o.z, dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (++o.diveT > HZ.TIMEOUT || dist <= Math.max(HZ.ARRIVE, o.cruise * 0.5)) { hzExplode(h, o, cands); return; }
                var k = o.cruise / dist;
                o.vx += (dx * k - o.vx) * HZ.DIVE; o.vy += (dy * k - o.vy) * HZ.DIVE; o.vz += (dz * k - o.vz) * HZ.DIVE;
            } else if (o.goal) {                                 // tickSeek
                var gx = o.goal.x - o.x, gy = o.goal.y - o.y, gz = o.goal.z - o.z, gd = Math.sqrt(gx * gx + gy * gy + gz * gz);
                var spd = Math.min(o.cruise, gd * HZ.GAIN), kk = gd < 1e-3 ? 0 : spd / gd;
                o.vx += (gx * kk - o.vx) * HZ.SEEK; o.vy += (gy * kk - o.vy) * HZ.SEEK; o.vz += (gz * kk - o.vz) * HZ.SEEK;
            }
            var ox = o.x, oy = o.y, oz = o.z;
            o.x += o.vx; o.y += o.vy; o.z += o.vz;
            if (o.diving) {                                      // a diving orb blows up on what it touches
                for (var i = 0; i < cands.length; i++) if (segBox(ox, oy, oz, o.x, o.y, o.z, cands[i], h.size * BALL / 2) >= 0) { hzExplode(h, o, cands); return; }
                var bl = "";
                try { bl = RPG.world.getBlock(h.dim, Math.floor(o.x), Math.floor(o.y), Math.floor(o.z)); } catch (e) { }
                if (bl && bl !== "minecraft:air" && bl !== "minecraft:cave_air" && bl !== "minecraft:water") { hzExplode(h, o, cands); return; }
            }
            pos2.push(o.i, r2(o.x), r2(o.y), r2(o.z));
        });
        if (!h.finaleDone && tick >= HZ.FINALE) hzFinale(h, cands || []);
        if (h.finaleDone && tick < HZ.FINALE + HZ.CHAIN) {        // chainBursts: 3 KI_EXPLOSIONs a tick inside the shell
            var bursts = [];
            for (var m = 0; m < 3; m++) {
                var th = Math.random() * Math.PI * 2, yy = Math.random() * 2 - 1, rg = Math.sqrt(1 - yy * yy), reach = h.shellR * (0.25 + Math.random() * 0.6);
                bursts.push(r2(h.anchor.x + Math.cos(th) * rg * reach), r2(h.anchor.y + yy * reach), r2(h.anchor.z + Math.sin(th) * rg * reach), r2(h.shellR * (0.55 + Math.random() * 0.45)));
            }
            emit(h.dim, h.anchor.x, h.anchor.z, ["b", bursts]);
            if (Math.random() < 0.5) RPG.world.sound(h.dim, DMZ + "ki_explosion_impact", h.anchor.x, h.anchor.y, h.anchor.z, 1.6, 0.8 + Math.random() * 0.3);
        }
        if (pos2.length) emit(h.dim, h.anchor.x, h.anchor.z, ["h", h.id, r2(h.size), h.col.core, h.col.border, h.col.outline, pos2]);
        return tick < HZ.END;
    }
    function endHell(h) {
        delete HELL[h.id];
        emit(h.dim, h.anchor.x, h.anchor.z, ["c", h.id]);
        (h.hands || []).forEach(function (x) { try { if (x && x.alive) x.discard(); } catch (e) { } });
    }

    // =========================================================================================
    //  Kill Driver (KillDriverEntity + KillDriverRenderer): a ring (radius 4 x the size, 0.75-1.5; tube 0.11 of it)
    //  forms at the chest at 0.35 of its size, rises over the head to full size between ticks 30 and 38 of the
    //  charge, and flies flat toward the lock / crosshair at max(0.6, speed) for 40-100 ticks. Touching anything
    //  (the ring itself, not a box) or terrain, or at the end, it bursts: 5.5 blocks round, the whole damage
    //  through hurt windows, a 1.3 push and 0.55 up, a ki explosion 0.9 x its radius, a shockwave and a boom.
    //  No terrain damage.
    // =========================================================================================
    var KD = { RADIUS: 4, FORM: 0.35, TUBE: 0.11, RAISE0: 30, RAISE1: 38, MINF: 40, MAXF: 100, MINSP: 0.6, BURST: 5.5, MARGIN: 0.3 };
    function kdOrigin(p, raise, radius) {
        var h = Number(p.height) || 1.8, height = h * 0.65 + (h * 1.15 + radius - h * 0.65) * raise, ahead = 1.0 + (0.3 - 1.0) * raise;
        // holdPoint: from the feet along the heading only (the look's pitch doesn't tip the ring)
        return { base: "center", frame: "flat", up: height - h / 2, forward: ahead, side: 0, clear: 0 };
    }
    // where the eye ray enters an entity's box (grown by g): ProjectileUtil.getEntityHitResult's clip point
    function eyeClip(p, e, g) {
        var lk = lookDir(p), hw = (Number(e.width) || 0.6) / 2 + g, o = [p.x, p.eyeY, p.z], d = [lk.x, lk.y, lk.z], t0 = 0, t1 = 200;
        var lo = [e.x - hw, e.y - g, e.z - hw], hi = [e.x + hw, e.y + (Number(e.height) || 1.8) + g, e.z + hw];
        for (var a = 0; a < 3; a++) {
            if (Math.abs(d[a]) < 1e-9) continue;
            var u = (lo[a] - o[a]) / d[a], v = (hi[a] - o[a]) / d[a];
            if (u > v) { var w = u; u = v; v = w; }
            t0 = Math.max(t0, u); t1 = Math.min(t1, v);
        }
        return t0 <= t1 ? { x: o[0] + d[0] * t0, y: o[1] + d[1] * t0, z: o[2] + d[2] * t0 } : hzCenter(e);
    }
    function killDriverCharge(p, s, T, size) {
        var full = KD.RADIUS * Math.max(0.75, Math.min(1.5, size));
        s.kdFull = full;
        s.proj = p.shoot("dmz_ki_ring", { hold: true, size: 0.5, damage: 0, colors: T.colors, origin: kdOrigin(p, 0, full * KD.FORM) });
        if (s.proj) {
            s.proj.setVar("tech", s.id); s.proj.setVar("colors", T.colors); s.proj.setVar("r", full);
            DMZ_TECH_PROJ.look(s.proj, { k: "ring", r: full, tech: s.id });
        }
    }
    function killDriverTick(p, s) {
        if (!s.proj || !s.proj.alive || s.ticks < KD.RAISE0 || s.ticks > KD.RAISE1) return;
        var raise = Math.max(0, Math.min(1, (s.ticks - KD.RAISE0) / (KD.RAISE1 - KD.RAISE0)));
        var o = kdOrigin(p, raise, s.kdFull * (KD.FORM + (1 - KD.FORM) * raise));
        s.proj.set("origin.up", o.up); s.proj.set("origin.forward", o.forward);
    }
    function killDriverFire(p, s, T, dmg, life) {
        var pr = s.proj && s.proj.alive ? s.proj : null;
        if (!pr) return false;
        var lock = s.lock && s.lock.isAlive() ? s.lock : null, aim;
        if (lock) aim = hzCenter(lock);
        else {
            var hit = null;
            try { hit = p.raycast(100, { blocks: true, entities: true }); } catch (e) { }
            if (hit && hit.hit === "entity" && hit.entity) aim = eyeClip(p, hit.entity, 0);
            else if (hit && hit.hit !== "none" && hit.x !== undefined) aim = { x: hit.x, y: hit.y, z: hit.z };
            else { var lk = lookDir(p); aim = { x: p.x + lk.x * 100, y: p.eyeY + lk.y * 100, z: p.z + lk.z * 100 }; }
        }
        var d = norm(aim.x - pr.x, aim.y - pr.y, aim.z - pr.z), sp = Math.max(KD.MINSP, T.speed);
        if (!d.x && !d.y && !d.z) d = lookDir(p);
        pr.setVar("dmg", dmg); pr.setVar("r", s.kdFull);
        DMZ_TECH_PROJ.look(pr, { k: "ring", r: s.kdFull, tech: s.id, f: 1 });
        pr.fire({ speed: sp, lifetime: Math.max(KD.MINF, Math.min(KD.MAXF, life)) });
        pr.setDirection(d.x, d.y, d.z);
        pr.setVelocity(d.x * sp, d.y * sp, d.z * sp);
        s.fired.push(pr);
        return true;
    }
    function ringTouches(o, pr) {
        var r = num(pr.getVar("r", 4), 4), tube = r * KD.TUBE, n = pr.direction, hit = false;
        RPG.world.entitiesNear(pr.dimension, pr.x, pr.y, pr.z, r + tube + 2).forEach(function (e) {
            if (hit || !canHurt(o, e)) return;
            var h = Number(e.height) || 1.8, ox = e.x - pr.x, oy = e.y + h / 2 - pr.y, oz = e.z - pr.z;
            var ax = ox * n.x + oy * n.y + oz * n.z, rx = ox - n.x * ax, ry = oy - n.y * ax, rz = oz - n.z * ax;
            var reach = Math.max(Number(e.width) || 0.6, h) * 0.5;
            if (Math.abs(ax) <= tube + reach + KD.MARGIN && Math.sqrt(rx * rx + ry * ry + rz * rz) <= r + tube + reach) hit = true;
        });
        return hit;
    }
    function ringBoom(o, pr) {
        if (!o || !pr || pr.getVar("done", 0)) return;
        pr.setVar("done", 1);
        var r = num(pr.getVar("r", 4), 4), dmg = num(pr.getVar("dmg", 0), 0), c = pr.getVar("colors", null) || { core: "#FFF3A0", border: "#FFC400", outline: "#E08A00" };
        var x = pr.x, y = pr.y, z = pr.z;
        RPG.world.entitiesNear(pr.dimension, x, y, z, KD.BURST + 3).forEach(function (e) {
            if (!canHurt(o, e)) return;
            var h = Number(e.height) || 1.8, ox = e.x - x, oy = e.y + h / 2 - y, oz = e.z - z, l = Math.sqrt(ox * ox + oy * oy + oz * oz);
            if (l > KD.BURST) return;
            try { e.invulnerableTime = 0; e.damageFrom(dmg, o, { kind: "ki", tag: "dmzki:kill_driver", ignoreIFrames: true, knockback: 0 }); } catch (x1) { }
            var pu = l < 1e-2 ? norm(pr.vx, pr.vy, pr.vz) : { x: ox / l, y: oy / l, z: oz / l };
            try { e.setVelocity(e.vx + pu.x * 1.3, e.vy + 0.55, e.vz + pu.z * 1.3); } catch (x2) { }
        });
        emit(pr.dimension, x, z, ["k", r2(x), r2(y), r2(z), r2(r * 0.9 * 2), 0, 0, c.core, c.border, c.outline]);
        emit(pr.dimension, x, z, ["w", r2(x), r2(y), r2(z), r2(KD.BURST * 1.6), c.border, 18]);
        RPG.world.sound(pr.dimension, DMZ + "ki_explosion_impact", x, y, z, 3, 0.8);
        pr.discard();
    }
    projectile("dmz_ki_ring", {
        shape: "ball", kind: "ki", size: 0.5, speed: 1.2, lifetime: 100, knockback: 0, pierce: 100000, tickEvery: 1,
        damage: function () { return -1; },
        onHit: function (o, t, x, y, z, proj) { if (!t && proj && !proj.held) ringBoom(o, proj); },
        onTick: function (o, age, proj) { if (o && proj && !proj.held && ringTouches(o, proj)) ringBoom(o, proj); },
        onEnd: function (o, x, y, z, proj) { ringBoom(o, proj); }
    });
    // the Tri-Beam's triangle: a ki ball that blows up on terrain where its middle meets it (the box is 3.5 tall: a
    // box test would set it off on the ground under the caster), pulses every 10 ticks, bursts on people
    function triPerHit(proj) { return num(proj.getVar("dmg", 0), 0) / Math.max(1, Math.floor(num(proj.getVar("life", 20), 20) / 20)); }
    projectile("dmz_ki_tri", {
        shape: "ball", kind: "ki", hitboxScale: BALL, size: 4, speed: 1.8, lifetime: 80, knockback: 0, respectIFrames: true, throughBlocks: true, tickEvery: 1,
        damage: function (o, t, proj) { return proj ? num(proj.getVar("dmg", 0), 0) : 0; },
        onHit: function (o, t, x, y, z, proj) { if (t && proj && !proj.held) DMZ_TECH_PROJ.ballBoom(o, proj); },
        onTick: function (o, age, proj) {
            if (!o || !proj || proj.held || proj.getVar("done", 0)) return;
            var sz = proj.getSize(), cy = proj.y + sz * BALL / 2, sp = Math.sqrt(proj.vx * proj.vx + proj.vy * proj.vy + proj.vz * proj.vz);
            if (age % 10 === 0) DMZ_TECH_PROJ.hurtNear(o, proj.x, cy, proj.z, sz / 2 + 5, triPerHit(proj), "dmzki:kikoho", false);
            if (sp < 1e-3) return;
            // people are met by its middle too (the original's ray from under the triangle passes beneath a standing target)
            var nx = proj.x + proj.vx, ny = cy + proj.vy, nz = proj.z + proj.vz, met = false;
            RPG.world.entitiesNear(proj.dimension, proj.x, cy, proj.z, sp + 3).forEach(function (e) {
                if (met || !canHurt(o, e)) return;
                var hw = (Number(e.width) || 0.6) / 2, h = Number(e.height) || 1.8;
                if (segBox(proj.x, cy, proj.z, nx, ny, nz, { x0: e.x - hw, y0: e.y, z0: e.z - hw, x1: e.x + hw, y1: e.y + h, z1: e.z + hw }, 0.3) >= 0) met = true;
            });
            if (met) { DMZ_TECH_PROJ.ballBoom(o, proj); return; }
            var r = null;
            try { r = RPG.world.raycast(proj.dimension, proj.x, cy, proj.z, proj.vx / sp, proj.vy / sp, proj.vz / sp, sp, { blocks: true, entities: false }); } catch (e) { }
            if (r && r.hit === "block") DMZ_TECH_PROJ.ballBoom(o, proj);
        },
        onEnd: function (o, x, y, z, proj) { DMZ_TECH_PROJ.ballBoom(o, proj); }
    });
    // the Neo Tri-Beam's triangle: through terrain, eating 0.6 x its size every 2 ticks; pulses every 10; bursts on people
    projectile("dmz_ki_neo", {
        shape: "ball", kind: "ki", hitboxScale: BALL, size: 4, speed: 1.6, lifetime: 90, knockback: 0, respectIFrames: true, throughBlocks: true, tickEvery: 2,
        damage: function (o, t, proj) { return proj ? num(proj.getVar("dmg", 0), 0) : 0; },
        onHit: function (o, t, x, y, z, proj) { if (t && proj && !proj.held) DMZ_TECH_PROJ.ballBoom(o, proj); },
        onTick: function (o, age, proj) {
            if (!o || !proj || proj.held) return;
            var sz = proj.getSize(), c = { x: proj.x, y: proj.y + sz / 2, z: proj.z };
            if (typeof DBR_DESTRUCTION !== "undefined") DBR_DESTRUCTION.eat(o, c.x, c.y, c.z, sz * 0.6);
            if (age % 10 === 0) DMZ_TECH_PROJ.hurtNear(o, c.x, proj.y + sz * BALL / 2, c.z, sz / 2 + 5,
                num(proj.getVar("dmg", 0), 0) / Math.max(1, Math.floor(num(proj.getVar("life", 20), 20) / 20)), "dmzki:neo_kikoho", false);
        },
        onEnd: function (o, x, y, z, proj) { DMZ_TECH_PROJ.ballBoom(o, proj); }
    });

    RPG.every(1, function () {
        try { tickShots(); } catch (e) { RPG.log("[DBR] volley shots: " + e); SHOTS = []; }
        for (var id in HELL) {
            var h = HELL[id];
            try { if (!tickHell(h)) endHell(h); } catch (e2) { RPG.log("[DBR] hellzone: " + e2); endHell(h); }
        }
        flush();
    });
    RPG.on("playerLeave", function (p) {
        for (var id in HELL) if (HELL[id].p.uuid === p.uuid) endHell(HELL[id]);
        SHOTS = SHOTS.filter(function (s) { return s.o.uuid !== p.uuid; });
    });

    return {
        shoot: shoot, assaultRain: assaultRain, killDriverCharge: killDriverCharge, killDriverTick: killDriverTick, killDriverFire: killDriverFire, blasterMeteor: blasterMeteor, meteorSize: meteorSize, meteorRise: meteorRise,
        hellzone: hellzone, hover: hover, land: land,
        hellzoneActive: function (p) { for (var id in HELL) if (HELL[id].p.uuid === p.uuid) return true; return false; },
        stats: function () { var n = 0; for (var id in HELL) n += HELL[id].orbs.filter(function (o) { return !o.done; }).length; return { shots: SHOTS.length, orbs: n }; }
    };
})();
