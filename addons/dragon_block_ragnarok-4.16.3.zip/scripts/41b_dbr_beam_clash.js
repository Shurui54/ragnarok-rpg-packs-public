// =====================================================================================
//  41b_dbr_beam_clash.js - beam struggles (the original's BeamClashManager / BeamClash /
//  ClashParticipant, GPL-3.0; see NOTICE.md)
// =====================================================================================
//  Major beams (every ki wave, the Special Beam Cannon, the bosses' beams) that meet head on start a
//  beam clash, checked every tick like the original: the two beam axes point against each other (dot <= -0.3)
//  and the segments from origin to tip come within (size A + size B) x 1.0 + 1.5 blocks. Players and
//  NPCs alike; party members / teammates never clash.
//  - Both beams lock at the meeting point (no growing, no damage, kept alive 40 ticks at a time) and
//    both owners are frozen: players stay in their firing pose, held in place, keys and turning off
//    (40b_dbr_clash_lock.js), NPCs lose their AI. Clashing owners take no damage.
//  - Each player gets the original's clash meter (DBR_CLASH, the shared ClashMeter maths with the harder
//    DIFFICULTY): right click while the marker crosses the window; PERFECT / GOOD add momentum (x0.94
//    a tick), a MISS nothing. Presses are stamped with the meter time on the client and checked here
//    against the server time with the player's ping (12 ticks at most + 2 grace), out-of-range or
//    mismatching stamps count as strikes (4 = presses dampened x0.4), and a bot-steady offset over
//    six presses is dampened x0.4. NPCs press the closest tick of each sweep, efficiency x their
//    accuracy (DBR_CLASH.npcAccuracy) x 0.7-1.0, and push with OPPONENT x their power.
//  - The tug of war (DBR_CLASH.advanceBias) moves the meeting point: lock lengths are the origin gap
//    x the visual bias. 0.8 wins; the winner's beam pushes through (60 more ticks, its next hit on the
//    loser deals the full beam damage), the loser's beam is gone and the loser is stunned 70 ticks
//    (EXHAUSTED). Either beam ending or an owner dying dissolves it; 140 ticks without presses from
//    both dissolves it; after 600 ticks the side ahead wins.
//  - Major beams shatter minor attacks they touch (lasers, discs, small ki blasts): a poof and the original's
//    impact sound.
//  Server -> client: "dbr_clash" (the clash HUD in client/scripts/61_dbr_space.js, with beam: 1 for the
//  cinematic camera); client -> server: "dbr_clash_press" {t, m}.
// =====================================================================================
var DBR_BEAM_CLASH = (function () {
    var K = DBR_CLASH, U = DBR_SPACE_ORBITS.u64;
    var OPPOSITION_DOT = -0.3, CLASH_RADIUS_FACTOR = 1.0, CLASH_RADIUS_PAD = 1.5, MINOR_BREAK_FACTOR = 0.7, MINOR_BREAK_PAD = 0.6;
    var WINNER_BREAKTHROUGH_TICKS = 60, KEEP_ALIVE = 40, NO_HITS = 1000000000;
    var TIMING_SAMPLE_COUNT = 6, BOT_SPREAD_THRESHOLD = 0.12, BOT_DAMPEN = 0.4, STRIKE_LIMIT = 4, MARKER_MISMATCH = 0.06,
        MAX_LAG_TICKS = 12, LAG_GRACE_TICKS = 2;
    // ClashRole: MAJOR beams clash, MINOR attacks are broken by them (KiWave all MAJOR, KiLaser type 1 MAJOR / type 0
    // MINOR, KiBlast type 0 MINOR, KiDisk MINOR)
    var MAJOR = { dmz_tech_wave: 1, dmz_tech_beam: 1, dmz_ki_wave: 1, dmz_ki_beam: 1, kamehameha: 1, galick_gun: 1, final_flash: 1, masenko: 1, tri_beam: 1,
        neo_tri_beam: 1, mouth_blast: 1, special_beam_cannon: 1, boss_beam: 1 };
    var MINOR = { dmz_tech_laser: 1, dmz_tech_disk: 1, dmz_ki_laser: 1, dmz_ki_disk: 1, dmz_tech_bullet: 1, ki_blast: 1, ki_volley: 1, boss_ki_blast: 1, blaster_shot: 1,
        dodonpa: 1, death_beam: 1, eye_laser: 1, merus_laser: 1, destructo_disk: 1, candy_beam: 1 };
    var PUNCHES = ["punch1", "punch2", "punch3", "punch4", "punch5", "punch6"];

    var BEAMS = [];         // tracked major beams: { proj, owner, size, power, color }
    var CLASHES = [];
    var CLASHING = {};      // owner uuid -> true (rebuilt every tick)
    var EXHAUSTED = {};     // npc uuid -> tick (players get "stunned")

    function tick() { return RPG.server.getTick(); }
    function num(v, d) { v = Number(v); return isFinite(v) ? v : d; }
    function sub(a, b) { return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z }; }
    function add(a, b) { return { x: a.x + b.x, y: a.y + b.y, z: a.z + b.z }; }
    function mul(a, k) { return { x: a.x * k, y: a.y * k, z: a.z * k }; }
    function dot(a, b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
    function dist(a, b) { var d = sub(a, b); return Math.sqrt(dot(d, d)); }
    function clamp01(v) { return v < 0 ? 0 : Math.min(v, 1); }
    function hex(c, d) {
        if (typeof c === "string" && c) return c.charAt(0) === "#" ? c : "#" + c;
        if (typeof c === "number") { var s = (c & 0xFFFFFF).toString(16); while (s.length < 6) s = "0" + s; return "#" + s; }
        return d;
    }
    function origin(b) { var p = b.proj; return { x: p.x, y: p.y, z: p.z }; }
    function direction(b) { var d = b.proj.direction; return { x: d.x, y: d.y, z: d.z }; }
    function firing(b) { var p = b.proj; return p.alive && !p.held && p.age >= p.get("charge", 0); }
    function isPlayer(e) { try { return e.isPlayer(); } catch (err) { return false; } }

    /**
     * A major beam to watch (call after firing it). opts: size (original beam size: the clash radius), power (the beam's
     * whole damage, the original's getKiDamage), color (its border colour, for the HUD).
     */
    function track(proj, opts) {
        if (!proj || !proj.beam || !MAJOR[proj.id]) return;
        for (var i = 0; i < BEAMS.length; i++) if (BEAMS[i].proj.equals(proj)) return;
        var owner = proj.owner;
        if (!owner) return;
        opts = opts || {};
        // power: the whole beam's damage (a per-hit beam: damage x its hits)
        var whole = num(proj.getVar("dmg", 0), 0) || proj.damage * Math.max(1, proj.get("duration", 60) / Math.max(1, proj.get("hitInterval", 5)));
        BEAMS.push({ proj: proj, owner: owner, size: num(opts.size, proj.size), power: Math.max(1, num(opts.power, whole)),
            color: hex(opts.color, "#00F8FF"), locked: false });
    }
    function beamOf(proj) { for (var i = 0; i < BEAMS.length; i++) if (BEAMS[i].proj.equals(proj)) return BEAMS[i]; return null; }
    // the engine reports beams whose tips meet; anything not tracked yet is picked up here
    RPG.on("beamClash", function (a, b) { track(a); track(b); });

    // ---- the beam lock (AbstractKiProjectile.setClashLock / clearClashLock) ----
    function lockBeam(b, length) {
        var p = b.proj;
        if (!b.locked) {
            b.locked = true;
            b.speed0 = p.speed; b.hit0 = p.get("hitInterval", 5); b.min0 = p.get("minSpeed", 0);
            p.set("speed", 0);
            p.set("minSpeed", 0);                                   // held still, not slowed to a stop (minSpeed ends a beam)
            p.set("hitInterval", NO_HITS);                          // a locked beam doesn't extend or damage
            p.setVar("clashLock", 1);
        }
        p.length = Math.max(0, length);
        p.setLifetime(p.age - p.get("charge", 0) + KEEP_ALIVE);       // keepAlive: maxLife = tickCount + 40
    }
    function clearLock(b) {
        if (!b.locked) return;
        b.locked = false;
        var p = b.proj;
        if (!p.alive) return;
        p.set("speed", b.speed0);
        p.set("minSpeed", b.min0);
        p.set("hitInterval", b.hit0);
        p.setVar("clashLock", 0);
    }
    function lifeLeft(b) {
        var p = b.proj, d = p.get(p.beam ? "duration" : "lifetime", 60);
        return Math.max(0, d + p.get("charge", 0) - p.age);
    }

    // ---- participants (ClashParticipant) ----
    function participant(b) {
        var o = b.owner, npc = !isPlayer(o), power = Math.max(1, b.power);
        if (npc) power *= (K.OPPONENT || 1);                         // DBR_CLASH difficulty: whatever pushes back pushes harder
        var hadAI = true;
        if (npc) { try { hadAI = o.hasAI(); } catch (err) { } }
        return { beam: b, owner: o, uuid: o.uuid, npc: npc, player: npc ? null : o.asPlayer(), hadAI: hadAI, power: power,
            acc: npc ? K.npcAccuracy(power) : 0, seed: U.make(Math.floor(Math.random() * 4294967296), Math.floor(Math.random() * 4294967296)),
            offsets: [], strikes: 0, dampened: false, consumed: -1, last: -1e9, momentum: 0, idle: 0 };
    }
    function stillFiring(s) { try { return s.owner.isAlive() && s.beam.proj.alive && firing(s.beam); } catch (err) { return false; } }
    function faceOf(s) {
        var d = direction(s.beam);
        return { yaw: Math.atan2(-d.x, d.z) * 180 / Math.PI, pitch: -Math.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * 180 / Math.PI };
    }
    function freezeOwner(s, first) {
        if (s.npc) {
            try { if (s.owner.hasAI()) s.owner.setAI(false); s.owner.stopMoving(); s.owner.setVelocity(0, 0, 0); } catch (err) { }
            return;
        }
        var p = s.player;
        if (first) {
            var f = faceOf(s);
            if (typeof DBR_LOCK !== "undefined") DBR_LOCK.lock(p, "beam", { yaw: f.yaw, pitch: f.pitch, use: true });
        }
        if (typeof DMZ_TECH !== "undefined" && DMZ_TECH.clashFire) DMZ_TECH.clashFire(p, true);   // firing pose, rooted, no ki drain
    }
    function unfreezeOwner(s, holdTicks) {
        if (s.npc) { try { if (s.owner.isAlive()) s.owner.setAI(s.hadAI); } catch (err) { } return; }
        var p = s.player;
        if (typeof DBR_LOCK !== "undefined") DBR_LOCK.unlock(p, "beam");
        if (typeof DMZ_TECH !== "undefined" && DMZ_TECH.clashFire) DMZ_TECH.clashFire(p, false, holdTicks);
    }
    function addBurst(s, eff) { s.momentum += eff; }
    function tickMeter(c, s) {
        s.momentum *= K.DECAY;
        s.idle++;
        if (!s.npc) return;
        // tickNpcPress: the closest tick of each sweep that lands in the window
        var now = K.sample(s.seed, c.age);
        if (now.cycle.index <= s.consumed || now.grade === "MISS") return;
        var next = K.sample(s.seed, c.age + 1);
        if (next.cycle.index === now.cycle.index && next.distance < now.distance) return;
        s.consumed = now.cycle.index;
        addBurst(s, now.efficiency * s.acc * (0.7 + Math.random() * 0.3));
        s.idle = 0;
    }
    function strike(s, reason) {
        s.strikes++;
        if (s.strikes === STRIKE_LIMIT) {
            s.dampened = true;
            RPG.log("[DBR] Beam clash: repeated implausible input from " + s.owner.getName() + " (" + reason + "); dampening their presses for the rest of this clash");
        }
    }
    function botPenalty(s, off) {
        s.offsets.push(off);
        if (s.offsets.length > TIMING_SAMPLE_COUNT) s.offsets.shift();
        if (s.offsets.length < TIMING_SAMPLE_COUNT) return 1;
        var lo = 1e9, hi = -1e9;
        for (var i = 0; i < s.offsets.length; i++) { if (Math.abs(s.offsets[i]) > 1) return 1; lo = Math.min(lo, s.offsets[i]); hi = Math.max(hi, s.offsets[i]); }
        return hi - lo < BOT_SPREAD_THRESHOLD ? BOT_DAMPEN : 1;
    }
    /** registerPlayerPress: the press's meter time is trusted within the player's lag; returns the grade or null. */
    function registerPress(c, s, claimed, marker) {
        var serverTime = c.age, realElapsed = (Date.now() - c.startMs) / 50;
        var ping = 0;
        try { ping = Math.max(0, num(s.player.ping, 0)); } catch (err) { }
        var tolerance = Math.min(MAX_LAG_TICKS, ping / 50 + LAG_GRACE_TICKS);
        var earliest = serverTime - tolerance, latest = Math.max(serverTime, realElapsed) + 1 + LAG_GRACE_TICKS;
        var t = Number(claimed);
        if (!isFinite(t)) { strike(s, "unreadable press time"); t = serverTime; }
        else if (t < earliest || t > latest) { strike(s, "press stamped " + (t - serverTime) + " ticks from server time, tolerance " + tolerance); t = Math.max(earliest, Math.min(latest, t)); }
        if (t <= s.last) return null;
        s.last = t;
        s.idle = 0;
        var smp = K.sample(s.seed, t), m = Number(marker);
        if (!isFinite(m) || Math.abs(smp.marker - m) > MARKER_MISMATCH) strike(s, "marker " + marker + " does not match the simulated " + smp.marker);
        if (smp.cycle.index <= s.consumed) return null;
        s.consumed = smp.cycle.index;
        if (smp.grade !== "MISS") {
            var eff = smp.efficiency * botPenalty(s, (smp.marker - smp.cycle.center) / smp.cycle.halfWidth);
            if (s.dampened) eff *= BOT_DAMPEN;
            addBurst(s, eff);
        }
        return smp.grade;
    }

    // ---- one clash (BeamClash) ----
    function midpointOfTips(c, la, lb) {
        var ta = add(origin(c.a.beam), mul(direction(c.a.beam), Math.max(0, la))), tb = add(origin(c.b.beam), mul(direction(c.b.beam), Math.max(0, lb)));
        return mul(add(ta, tb), 0.5);
    }
    function start(ba, bb) {
        var c = { a: participant(ba), b: participant(bb), age: 0, bias: 0.5, startMs: Date.now(), dim: ba.proj.dimension, ended: false };
        lockBeam(ba, ba.proj.length); lockBeam(bb, bb.proj.length);
        c.point = midpointOfTips(c, ba.proj.length, bb.proj.length);
        freezeOwner(c.a, true); freezeOwner(c.b, true);
        CLASHES.push(c);
        [c.a, c.b].forEach(function (s) {
            if (s.npc) return;
            var o = s === c.a ? c.b : c.a;
            RPG.net.send(s.player, "dbr_clash", { start: true, beam: 1, hi: s.seed.hi, lo: s.seed.lo, self: s.beam.color, foe: o.beam.color, adv: 0.5,
                title: "§c§lBEAM CLASH!", you: "YOU", them: "FOE", opp: o.owner.entityId, x: c.point.x, y: c.point.y, z: c.point.z });
        });
        sfx({ dimension: c.dim, x: c.point.x, y: c.point.y, z: c.point.z }, "ki_explosion_impact", 1.5, 0.6);
        if (TRACE) RPG.log("[DBR] beam clash: " + c.a.owner.getName() + " vs " + c.b.owner.getName());
        return c;
    }
    function visual(c) { return K.visualBias(c.bias); }
    function applyLock(c) {
        var oa = origin(c.a.beam), ob = origin(c.b.beam), gap = dist(oa, ob), v = visual(c);
        var la = gap * v, lb = gap * (1 - v);
        lockBeam(c.a.beam, la); lockBeam(c.b.beam, lb);
        c.point = midpointOfTips(c, la, lb);
    }
    /** "on", "a", "b" or "dissolve" */
    function step(c) {
        if (!stillFiring(c.a) || !stillFiring(c.b)) return "dissolve";
        c.age++;
        freezeOwner(c.a, false); freezeOwner(c.b, false);
        tickMeter(c, c.a); tickMeter(c, c.b);
        c.bias = K.advanceBias(c.bias, c.a, c.b);
        applyLock(c);
        if (c.bias >= K.WIN) return "a";
        if (c.bias <= 1 - K.WIN) return "b";
        if (Math.min(c.a.idle, c.b.idle) >= K.IDLE_DISSOLVE) return "dissolve";
        if (c.age >= K.MAX_DURATION) return c.bias > 0.5 ? "a" : c.bias < 0.5 ? "b" : "dissolve";
        return "on";
    }
    function notifyEnded(c, loser) {
        [c.a, c.b].forEach(function (s) {
            if (s.npc) return;
            try { if (s.player.isConnected()) RPG.net.send(s.player, "dbr_clash", { end: true, exhaust: s === loser ? K.LOSER_EXHAUST : 0 }); } catch (err) { }
        });
    }
    function exhaust(s) {
        try {
            if (!s.owner.isAlive()) return;
            if (s.npc) { EXHAUSTED[s.uuid] = tick() + K.LOSER_EXHAUST; s.owner.addPotion("minecraft:slowness", K.LOSER_EXHAUST, 9); }
            else { s.player.removeEffect("stunned"); s.player.addEffect("stunned", K.LOSER_EXHAUST); }
        } catch (err) { }
    }
    function resolve(c, winner, loser) {
        c.ended = true;
        if (TRACE) RPG.log("[DBR] beam clash won by " + winner.owner.getName() + " after " + c.age + " ticks");
        notifyEnded(c, loser);
        var wp = winner.beam.proj;
        clearLock(winner.beam);
        if (wp.alive) {
            wp.setLifetime(wp.age - wp.get("charge", 0) + WINNER_BREAKTHROUGH_TICKS);
            wp.setVar("breakthrough", loser.uuid);                  // its next hit on the loser is the whole beam
        }
        clearLock(loser.beam);
        if (loser.beam.proj.alive) loser.beam.proj.discard();
        unfreezeOwner(winner, WINNER_BREAKTHROUGH_TICKS);
        unfreezeOwner(loser, 0);
        exhaust(loser);
        sfx({ dimension: c.dim, x: c.point.x, y: c.point.y, z: c.point.z }, "ki_explosion_impact", 2, 0.8);
        RPG.world.particle(c.dim, "minecraft:explosion", c.point.x, c.point.y, c.point.z, 3, 0.6, 0);
    }
    function dissolve(c) {
        c.ended = true;
        if (TRACE) RPG.log("[DBR] beam clash dissolved after " + c.age + " ticks");
        notifyEnded(c, null);
        clearLock(c.a.beam); clearLock(c.b.beam);
        unfreezeOwner(c.a, lifeLeft(c.a.beam)); unfreezeOwner(c.b, lifeLeft(c.b.beam));
    }
    function sendState(c) {
        [c.a, c.b].forEach(function (s) {
            if (s.npc) return;
            var v = visual(c);
            RPG.net.send(s.player, "dbr_clash", { adv: s === c.a ? v : 1 - v, x: c.point.x, y: c.point.y, z: c.point.z });
        });
    }

    // ---- the manager (BeamClashManager.onLevelTick) ----
    function segmentDistanceSq(p1, q1, p2, q2) {
        var d1 = sub(q1, p1), d2 = sub(q2, p2), r = sub(p1, p2), a = dot(d1, d1), e = dot(d2, d2), f = dot(d2, r), EPS = 1e-9, s, t;
        if (a <= EPS && e <= EPS) return dot(r, r);
        if (a <= EPS) { s = 0; t = clamp01(f / e); }
        else {
            var cc = dot(d1, r);
            if (e <= EPS) { t = 0; s = clamp01(-cc / a); }
            else {
                var b = dot(d1, d2), denom = a * e - b * b;
                s = denom > EPS ? clamp01((b * f - cc * e) / denom) : 0;
                t = (b * s + f) / e;
                if (t < 0) { t = 0; s = clamp01(-cc / a); }
                else if (t > 1) { t = 1; s = clamp01((b - cc) / a); }
            }
        }
        var diff = sub(add(p1, mul(d1, s)), add(p2, mul(d2, t)));
        return dot(diff, diff);
    }
    function pointSegmentDistanceSq(p, s0, s1) {
        var d = sub(s1, s0), len2 = dot(d, d);
        if (len2 <= 1e-9) { var q = sub(p, s0); return dot(q, q); }
        var t = clamp01(dot(sub(p, s0), d) / len2), proj = add(s0, mul(d, t)), w = sub(p, proj);
        return dot(w, w);
    }
    function allies(a, b) {
        if (!isPlayer(a) || !isPlayer(b)) return false;
        try { return a.isAlly(b); } catch (err) { return false; }
    }
    function beamsClash(a, b) {
        var da = direction(a), db = direction(b);
        if (dot(da, db) > OPPOSITION_DOT) return false;
        var a0 = origin(a), a1 = add(a0, mul(da, Math.max(0.1, a.proj.length))), b0 = origin(b), b1 = add(b0, mul(db, Math.max(0.1, b.proj.length)));
        var th = (a.size + b.size) * CLASH_RADIUS_FACTOR + CLASH_RADIUS_PAD;
        return segmentDistanceSq(a0, a1, b0, b1) <= th * th;
    }
    function inClash(b) { for (var i = 0; i < CLASHES.length; i++) if (CLASHES[i].a.beam === b || CLASHES[i].b.beam === b) return true; return false; }
    function ownerClashing(u) { for (var i = 0; i < CLASHES.length; i++) if (CLASHES[i].a.uuid === u || CLASHES[i].b.uuid === u) return true; return false; }
    function detect(majors) {
        for (var i = 0; i < majors.length; i++) {
            var a = majors[i];
            if (a.locked || inClash(a)) continue;
            for (var j = i + 1; j < majors.length; j++) {
                var b = majors[j];
                if (b.locked || inClash(b) || a.proj.dimension !== b.proj.dimension) continue;
                if (a.owner.uuid === b.owner.uuid || allies(a.owner, b.owner)) continue;
                if (ownerClashing(a.owner.uuid) || ownerClashing(b.owner.uuid)) continue;
                if (beamsClash(a, b)) { start(a, b); break; }
            }
        }
    }
    function breakMinors(majors) {
        for (var i = 0; i < majors.length; i++) {
            var m = majors[i], dir = direction(m), a0 = origin(m), len = Math.max(0.1, m.proj.length), a1 = add(a0, mul(dir, len)), mid = mul(add(a0, a1), 0.5);
            var near = RPG.world.projectilesNear(m.proj.dimension, mid.x, mid.y, mid.z, len / 2 + m.size + 3);
            for (var j = 0; j < near.length; j++) {
                var n = near[j];
                if (!MINOR[n.id] || !n.alive) continue;
                var no = n.owner;
                if (no && (no.uuid === m.owner.uuid || allies(m.owner, no))) continue;
                var th = (m.size + n.size) * MINOR_BREAK_FACTOR + MINOR_BREAK_PAD;
                if (pointSegmentDistanceSq({ x: n.x, y: n.y, z: n.z }, a0, a1) <= th * th) {
                    RPG.world.particle(n.dimension, "minecraft:poof", n.x, n.y, n.z, 6, 0.2, 0.02);
                    sfx({ dimension: n.dimension, x: n.x, y: n.y, z: n.z }, "ki_explosion_impact", 0.6, 1.3);
                    n.discard();
                }
            }
        }
    }
    RPG.every(1, function () {
        if (!BEAMS.length && !CLASHES.length) return;
        for (var i = CLASHES.length - 1; i >= 0; i--) {
            var c = CLASHES[i], r;
            try { r = step(c); } catch (err) { RPG.log("[DBR] beam clash error: " + err); r = "dissolve"; }
            if (r === "on") continue;
            CLASHES.splice(i, 1);
            try {
                if (r === "a") resolve(c, c.a, c.b);
                else if (r === "b") resolve(c, c.b, c.a);
                else dissolve(c);
            } catch (err2) { RPG.log("[DBR] beam clash end error: " + err2); }
        }
        var majors = [];
        BEAMS = BEAMS.filter(function (b) {
            try {
                if (!b.proj.alive) return false;
                if (!b.locked && firing(b)) majors.push(b);
                return true;
            } catch (err) { return false; }
        });
        if (majors.length > 1) detect(majors);
        if (majors.length) breakMinors(majors);
        CLASHING = {};
        CLASHES.forEach(function (c) { CLASHING[c.a.uuid] = true; CLASHING[c.b.uuid] = true; });
        CLASHES.forEach(function (c) { if (c.age % 2 === 0) sendState(c); });
    });

    // the press (BeamClashManager.handlePlayerPress); the planet and world boss clashes answer their own presses
    RPG.net.on("dbr_clash_press", function (p, d) {
        if (!p || !d) return;
        for (var i = 0; i < CLASHES.length; i++) {
            var c = CLASHES[i], s = c.a.uuid === p.uuid ? c.a : c.b.uuid === p.uuid ? c.b : null;
            if (!s || s.npc) continue;
            var g = registerPress(c, s, d.t, d.m);
            if (g === "PERFECT" || g === "GOOD") {
                var pitch = (g === "PERFECT" ? 1.15 : 0.95) + Math.random() * 0.1;
                sfx(p, PUNCHES[Math.floor(Math.random() * PUNCHES.length)], 1, pitch);
            }
            return;
        }
    });
    // onClashingHurt: nobody in a beam struggle takes damage
    RPG.on("damageAttempt", function (e) { if (e.target && CLASHING[e.target.uuid]) e.cancel(); });

    function isClashing(u) { return !!CLASHING[u] || ownerClashing(u); }

    // ---- /rpgc beamtest: testing aids for operators ----
    //  fire <player> <technique> [hold ticks]   the player charges that technique (slot key held) and lets go
    //  npc [player]                              the nearest NPC within 32 blocks fires a wave at the player (saga style)
    //  auto [player]                             that player's presses in their current clash are perfect (a tester)
    var AUTO = {}, TRACE = false;
    RPG.every(1, function () {
        for (var i = 0; i < CLASHES.length; i++) [CLASHES[i].a, CLASHES[i].b].forEach(function (s) {
            if (s.npc || !AUTO[s.uuid]) return;
            var c = CLASHES[i], now = K.sample(s.seed, c.age), next = K.sample(s.seed, c.age + 1);
            if (now.cycle.index <= s.consumed || now.grade === "MISS" || (next.cycle.index === now.cycle.index && next.distance < now.distance)) return;
            s.consumed = now.cycle.index; addBurst(s, now.efficiency); s.idle = 0;
        });
    });
    RPG.commands.register("beamtest", {
        description: "Beam clash test aids: /rpgc beamtest fire <player> <technique> [hold] | npc [player] [mob name] | auto [player]",
        permission: 2,
        run: function (p0, args) {
            var p = p0 || { tell: function (t) { RPG.log("[beamtest] " + String(t).replace(/&./g, "")); } };
            var sub = String(args[0] || "");
            if (sub === "fire") {
                var t = RPG.server.player(String(args[1] || "")), id = String(args[2] || "kamehameha"), hold = Math.max(1, Math.floor(num(args[3], 60)));
                if (!t || typeof DMZ_TECH === "undefined") { if (p) p.tell("&c/rpgc beamtest fire <player> <technique> [hold ticks]"); return; }
                if (!DMZ_TECH.has(t, id)) DMZ_TECH.unlock(t, id, { source: "command", silent: true });
                DMZ_TECH.setCooldown(t, id, 0);
                DMZ_TECH.cast(t, id, 0);
                RPG.schedule(hold, function () { try { DMZ_TECH.release(t, 0); } catch (err) { } });
                if (p) p.tell("&a" + t.name + " charges " + id + " for " + hold + " ticks.");
                return;
            }
            if (sub === "trace") { TRACE = !TRACE; p.tell("trace " + TRACE); return; }
            var who = args[1] ? RPG.server.player(String(args[1])) : p0;
            if (!who) return;
            if (sub === "auto") { AUTO[who.uuid] = !AUTO[who.uuid]; if (p) p.tell("&aPerfect presses for " + who.name + ": " + (AUTO[who.uuid] ? "on" : "off")); return; }
            if (sub === "npc") {
                var best = null, bd = 1e9;
                RPG.world.entitiesNear(who.dimension, who.x, who.y, who.z, 32).forEach(function (e) {
                    try { if (e.isPlayer() || !e.isAlive() || (args[2] && String(e.getName()).toLowerCase().indexOf(String(args[2]).toLowerCase()) < 0)) return; var d = e.distanceTo(who); if (d < bd) { bd = d; best = e; } } catch (err) { }
                });
                if (!best) { if (p) p.tell("&cNo NPC within 32 blocks."); return; }
                var fy = best.eyeY - 0.2, dx = who.x - best.x, dy = (who.y + 1) - fy, dz = who.z - best.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
                try { best.lookAt(who.x, who.eyeY, who.z); } catch (err) { }
                var colors = { core: "#FFFFFF", border: "#FF3B3B", outline: "#B00000" };
                var pr = RPG.world.shootFrom(best.dimension, best.x, fy, best.z, dx / l, dy / l, dz / l, "dmz_tech_wave",
                    { size: 1.5, colors: colors, damage: 0, speed: 0.8, duration: 80, length: 64, followAim: false }, best);
                if (pr) { pr.setVar("dmg", 40); pr.setVar("hits", 4); pr.setVar("r", 3); track(pr, { size: 1.5, power: 40, color: colors.border }); }
                if (p) p.tell(pr ? "&a" + best.getName() + " fires a wave at " + who.name + "." : "&cCould not fire.");
                return;
            }
            if (p) p.tell("&c/rpgc beamtest fire <player> <technique> [hold] | npc [player] | auto [player]");
        }
    });
    return {
        track: track, isClashing: isClashing,
        /** Clashing or exhausted after losing one (NPC brains hold still). */
        isHeld: function (u) { return isClashing(u) || (EXHAUSTED[u] || 0) > tick(); },
        /** A locked beam must not deal damage; the winner's breakthrough hit deals the whole beam (beamDamage, 41_dmz_techniques.js). */
        isLocked: function (proj) { return !!proj && !!proj.getVar("clashLock", 0); },
        MAJOR: MAJOR, MINOR: MINOR,
        /** ClashParticipant and its meter, for other struggles (the strike clash, 41sx_dmz_strike_clash.js): participant(owner,
         *  power, color) -> s; tickMeter(c, s) and registerPress(c, s, time, marker) with c = {age, startMs}. */
        meter: { participant: function (owner, power, color) { return participant({ owner: owner, power: power, color: color }); },
            tickMeter: tickMeter, registerPress: registerPress, PUNCHES: PUNCHES }
    };
})();
