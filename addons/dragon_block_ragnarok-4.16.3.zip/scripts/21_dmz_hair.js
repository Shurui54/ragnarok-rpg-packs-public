// =====================================================================================
//  21_dmz_hair.js - the player's own hairstyles (the original's custom hair: hairId 0 and HairBase..HairSSJ4)
// =====================================================================================
//  Port of the original's custom-hair storage and sync (GPL-3.0, see NOTICE.md): Character.hairStyles,
//  UpdateCustomHairC2S (+ HairSanitizer), StatsSyncC2S's hair colour and RenderHairBase, and HairCommand (/dmzhair).
//
//  What a character keeps (append-only keys; they travel with the character's slot like every other var / look):
//    var  dmz_hair_custom   the five styles as one full-set code ("DMZF22:...", the original's own format, joint styles
//                           kept). Saved by the hair editor (client/scripts/21_dmz_hair_editor.js).
//    var  dmz_hair_base     the original's RenderHairBase ("Hairbase" in the editor): 0 hides the scalp layer. Default 1.
//    look hairStyle         "1".."28" a preset (the original's hairId), "c<hash>" the own styles, "0" none.
//    look dmzHairCap        "0" when the scalp layer (hair_base) is hidden: RenderHairBase off, or own styles with an empty base.
//  Clients get every custom code once ("dmz_hair_codes" {hash: code}) and draw it as "dmzhc<hash>_<slot>"
//  (shared/11_dmz_hair.js); nothing is resent while the hair stays the same.
//
//  Commands (the original's /dmzhair): /dmzhair resync [players] - send the hair again
//                                     /dmzhair reset [players]  - back to the race's default hair and colour
//  plus /dmzhair edit (opens the hair editor) and /dmzhair export [slot] (your hair code as a clickable chat line).
// =====================================================================================
var DMZ_HAIR_SRV = (function () {
    var V = "dmz_hair_custom", V_BASE = "dmz_hair_base";
    var CODES = {};                 // hash -> code, for everyone online this session
    var UPLOAD = {};                // uuid -> {id, parts: [], total}
    var LAST_SAVE = {};             // uuid -> server tick of the last accepted save (UpdateCustomHairC2S: PacketRateLimiter)
    var SAVE_INTERVAL_TICKS = 10;   // UpdateCustomHairC2S.MIN_INTERVAL_TICKS: a save decodes and checks the whole set (tens of ms)
    var MAX_CODE = 262144;          // HairCodec.MAX_CODE_LENGTH

    function code(p) { var c = p.getVar(V, ""); return typeof c === "string" ? c : ""; }
    function hairBase(p) { return Number(p.getVar(V_BASE, 1)) !== 0; }
    function look(p) { return String(p.getColor("hairStyle") || ""); }
    function isCustom(v) { return /^c[0-9a-f]{8}$/.test(String(v)); }
    // HairManager.canUseHair: humans, Saiyans and Majins, plus races whose head art has hair (Glinds)
    function canUseHair(p) { var r = String(p.race || ""); return r === "human" || r === "saiyan" || r === "majin" || r === "glind"; }

    function setLook(p, k, v) { if (String(p.getColor(k) || "") !== String(v)) p.setColor(k, v); }

    // the look values that follow from the var: hairStyle "c<hash>" while the own styles are worn, dmzHairCap
    function apply(p, wearOwn) {
        var c = code(p), hash = c ? DMZ_HAIR.codeHash(c) : "";
        if (c && !CODES[hash]) { CODES[hash] = c; var m = {}; m[hash] = c; DMZ_HAIR.addCodes(m); broadcast(hash, c); }
        var hs = look(p);
        if (!wearOwn && isCustom(hs) && hs === "c" + hash && p.getColor("dmzHairCap")) return;   // already in step: no decoding
        if (wearOwn || isCustom(hs)) {
            var set = c ? DMZ_HAIR.customSet(hash) : null;
            var any = !!set && DMZ_HAIR.SLOTS.some(function (s) { return !DMZ_HAIR.isEmpty(set[s]); });
            hs = any ? "c" + hash : "0";
            setLook(p, "hairStyle", hs);
        }
        var cap = hairBase(p);
        if (cap && isCustom(hs)) { var st = DMZ_HAIR.customSet(hs.substring(1)); cap = !!st && !DMZ_HAIR.isEmpty(st.base); }
        setLook(p, "dmzHairCap", cap ? "1" : "0");
    }

    function broadcast(hash, c) {
        var m = {}; m[hash] = c;
        RPG.server.players().forEach(function (q) { RPG.net.send(q, "dmz_hair_codes", { codes: m }); });
    }
    function sendAll(p) {
        RPG.server.players().forEach(function (q) { var c = code(q); if (c) CODES[DMZ_HAIR.codeHash(c)] = c; });
        if (Object.keys(CODES).length) RPG.net.send(p, "dmz_hair_codes", { codes: CODES });
    }

    RPG.on("playerJoin", function (p) {
        apply(p, false);
        RPG.schedule(20, function () { if (p.isConnected()) sendAll(p); });
    });
    RPG.on("respawn", function (p) { apply(p, false); });
    RPG.on("playerLeave", function (p) { delete UPLOAD[String(p.uuid)]; delete LAST_SAVE[String(p.uuid)]; });
    RPG.net.on("dmz_hair_sync", function (p) { apply(p, false); sendAll(p); });
    // a character switch (93_dbr_characters.js) swaps vars and looks: keep the look values in step, cheaply
    var tick = 0;
    RPG.on("tick", function () {
        if (++tick % 40) return;
        RPG.server.players().forEach(function (p) {
            var c = code(p), hs = look(p);
            if (c && !CODES[DMZ_HAIR.codeHash(c)]) apply(p, false);
            else if (isCustom(hs) && (!c || "c" + DMZ_HAIR.codeHash(c) !== hs)) apply(p, false);
        });
    });

    // ---- the editor's Save (HairEditorScreen.save): own styles, hair colour, RenderHairBase ------------------------
    // The code can be longer than one message (30 KB): {id, part, total, data} pieces, then the rest of the fields.
    RPG.net.on("dmz_hair_save", function (p, d) {
        if (!d || typeof d !== "object") return;
        var u = String(p.uuid), id = String(d.id || "");
        if (!UPLOAD[u] || UPLOAD[u].id !== id) UPLOAD[u] = { id: id, parts: [], total: Math.max(1, Math.min(16, d.total | 0)) };
        var up = UPLOAD[u], part = d.part | 0;
        if (part < 0 || part >= up.total || typeof d.data !== "string") return;
        up.parts[part] = d.data;
        for (var i = 0; i < up.total; i++) if (typeof up.parts[i] !== "string") return;
        delete UPLOAD[u];
        var now = RPG.server.getTick();
        if (LAST_SAVE[u] !== undefined && now - LAST_SAVE[u] < SAVE_INTERVAL_TICKS) return;      // rate limited, like the original
        LAST_SAVE[u] = now;
        save(p, up.parts.join(""), d);
    });

    function save(p, c, d) {
        if (!p.getVar("dmz_created", 0) && !d.creator) return;
        if (!canUseHair(p) && !d.creator) { p.tell("&cYour race has no hair to edit."); return; }
        if (c.length > MAX_CODE || c.indexOf("DMZF22:") !== 0) { p.tell("&cThat hair could not be saved."); return; }
        var set = DMZ_HAIR.decodeFullSet(c, true);
        if (!set) { p.tell("&cThat hair could not be saved."); return; }
        // UpdateCustomHairC2S: HairSanitizer.sanitizeAndLog per style
        var fixed = 0;
        DMZ_HAIR.SLOTS.forEach(function (slot) { fixed += DMZ_HAIR.sanitize(set[slot]); });
        if (fixed) RPG.log("[Hair] Clamped " + fixed + " hair value(s) received from " + p.name);
        var clean = fixed ? DMZ_HAIR.toFullSetCode(set, true) : c;      // the client wrote it with the same encoder
        if (!clean || clean.length > MAX_CODE) { p.tell("&cThat hair could not be saved."); return; }
        DMZ_HAIR.cacheSet(DMZ_HAIR.codeHash(clean), clean, set);
        p.setVar(V, clean);
        if (typeof d.hairBase === "boolean") p.setVar(V_BASE, d.hairBase ? 1 : 0);
        var gc = DMZ_HAIR.normColor(d.color);
        if (gc) p.setColor("hair", gc);
        apply(p, true);                       // character.setHairId(0): the own styles are worn from now on
        if (typeof DMZ_TF !== "undefined" && DMZ_TF.refresh) DMZ_TF.refresh(p);
    }

    // ---- /dmzhair -----------------------------------------------------------------------------------------------
    function targets(p, args, i) {
        if (!args[i]) return p ? [p] : [];
        if (!p || !p.isOp()) { if (p) p.tell("&cOnly operators can change other players' hair."); return []; }
        var names = args.slice(i), out = [];
        names.forEach(function (n) {
            if (n === "@a") RPG.server.players().forEach(function (q) { out.push(q); });
            else { var q = RPG.server.player(n); if (q) out.push(q); }
        });
        return out;
    }
    function reset(q) {
        var def = DBR_RACE_DEFAULTS[q.race] || {};
        var hs = def.hairStyle !== undefined ? String(def.hairStyle) : "0";
        q.setColor("hairStyle", hs);
        if (def.hair) q.setColor("hair", def.hair);
        q.setVar(V, null);                    // character.clearHairStyles()
        q.setVar(V_BASE, null);
        apply(q, false);
        if (typeof DMZ_TF !== "undefined" && DMZ_TF.refresh) DMZ_TF.refresh(q);
    }
    function exportLine(p, slot) {
        var c = code(p), hs = look(p), out;
        if (isCustom(hs) && c) {
            var set = DMZ_HAIR.decodeFullSet(c, false);
            out = slot ? DMZ_HAIR.toCode(DMZ_HAIR.resolveOwn(set, slot)) : DMZ_HAIR.toFullSetCode(set, false);
        } else {
            var id = DMZ_HAIR.presetOf(hs, p.race);
            if (id <= 0) { p.tell("&7You have no hair to export."); return; }
            var styles = {};
            DMZ_HAIR.SLOTS.forEach(function (s) { styles[s] = DMZ_HAIR.preset(id, s); });
            out = slot ? DMZ_HAIR.toCode(styles[slot]) : DMZ_HAIR.toFullSetCode(styles, false);
        }
        p.tellRich([{ text: "&e[Hair]&r " }, { text: "&b&nClick to copy your " + (slot ? slot.toUpperCase() + " style" : "full hairstyle") + " code",
            copy: out, hover: out.length + " characters - paste it into the hair editor (here or in the original)" }]);
    }
    RPG.commands.register("dmzhair", { root: true, permission: 0,
        description: "/dmzhair edit | export [slot] | resync [players] | reset [players] - the hair editor, your hair code, sync and reset",
        run: function (p, args) {
            var sub = String(args[0] || "").toLowerCase(), n = 0;
            if (sub === "resync") {
                targets(p, args, 1).forEach(function (q) {
                    var hs = look(q), hc = q.getColor("hair");
                    q.setColor("hairStyle", null); q.setColor("hairStyle", hs || null);
                    q.setColor("hair", null); q.setColor("hair", hc || null);
                    apply(q, false);
                    RPG.server.players().forEach(function (v) { sendAll(v); });
                    n++;
                });
                if (p) p.tell("&e[DMZ-Hair]&r Re-synced hair for " + n + " player(s).");
            } else if (sub === "reset") {
                targets(p, args, 1).forEach(function (q) { reset(q); n++; });
                if (p) p.tell("&e[DMZ-Hair]&r Reset hair to race default for " + n + " player(s).");
            } else if (sub === "edit" && p) {
                if (!p.getVar("dmz_created", 0) || !canUseHair(p)) { p.tell("&cYour race has no hair to edit."); return; }
                RPG.net.send(p, "dmz_hair_open", {});
            } else if (sub === "export" && p) {
                var slot = String(args[1] || "").toLowerCase();
                exportLine(p, DMZ_HAIR.SLOTS.indexOf(slot) >= 0 ? slot : "");
            } else if (p) p.tell("&7/dmzhair edit | export [base|ssj|ssj2|ssj3|ssj4] | resync [players] | reset [players]");
        },
        suggest: function (p, args) {
            if (args.length <= 1) return ["edit", "export", "resync", "reset"];
            if (String(args[0]) === "export") return DMZ_HAIR.SLOTS.slice();
            return RPG.server.players().map(function (q) { return q.name; });
        } });

    // ops: /rpgc hairtest - the hair code tests with the engine's own Deflater (whole codes, byte for byte). Reads
    // data/dmz_hair_tests.json, a copy of tests/hair_codes.json (not shipped: copy it in to run the test).
    RPG.commands.register("hairtest", { permission: 2, description: "/rpgc hairtest - hair code tests (needs data/dmz_hair_tests.json)",
        run: function (p) {
            var say = function (m) { if (p) p.tell(m); RPG.log("[Hair] " + m); };
            var d = null;
            try { d = RPG.files.read("dmz_hair_tests.json"); } catch (e) { d = null; }
            if (!d || !d.cases) { say("&cNo data/dmz_hair_tests.json (copy tests/hair_codes.json there)."); return; }
            var ok = 0, rt = 0, n = d.cases.length, i = 0, worst = 0, worstName = "", total = 0;
            // one case a tick (each is a whole decode + encode + decode + encode, up to tens of KB of NBT)
            function step() {
                if (i >= n) {
                    say("&aHair codes: " + ok + "/" + n + " identical to the original's own output, " + rt + "/" + n + " stable round trips ("
                        + total + " ms in all, slowest " + worst + " ms: " + worstName + ")");
                    return;
                }
                var c = d.cases[i++], t0 = Date.now(), full = DMZ_HAIR.isFullSetCode(c.input), out;
                if (full) out = DMZ_HAIR.toFullSetCode(DMZ_HAIR.decodeFullSet(c.input), false);
                else out = DMZ_HAIR.toCode(DMZ_HAIR.decode(c.input));
                if (out === c.expected) ok++; else say("&cdiffers: " + c.name + " (" + out.length + " vs " + c.expected.length + " chars)");
                var back = full ? DMZ_HAIR.toFullSetCode(DMZ_HAIR.decodeFullSet(out), false) : DMZ_HAIR.toCode(DMZ_HAIR.decode(out));
                if (back === out) rt++;
                var ms = Date.now() - t0;
                total += ms;
                if (ms > worst) { worst = ms; worstName = c.name; }
                RPG.schedule(1, step);
            }
            step();
        } });

    // the creator's Confirm (08_character.js): the hair made with "Edit" in the creator's hair tab
    function saveCode(p, c, hairBase) { if (typeof c === "string" && c) save(p, c, { creator: true, hairBase: hairBase !== false }); }

    return { apply: apply, code: code, canUseHair: canUseHair, hairBase: hairBase, reset: reset, saveCode: saveCode };
})();
