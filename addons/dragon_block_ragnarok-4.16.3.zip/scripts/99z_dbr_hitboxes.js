// =====================================================================================
//  99z_dbr_hitboxes.js - every mob's and NPC's hitbox as the original registers it
// =====================================================================================
//  Runs after every other script has defined its mobs and NPCs, and patches width / height
//  (before the definition's scale) so the box the server hits with, and F3+B shows, is the
//  original's:
//   - DragonMine Z (GPL-3.0, see NOTICE.md): MainEntities' EntityType.Builder...sized(w, h), and
//     DragonBallDefinitions' dragon boxes, are the box at the original's own model scale (the
//     entity's setScaleVal: Ozaru 1.8, Gomah's third eye 5.5, Tamagami 1.5...; the dragons' render
//     scale 3.5 / 7; the vehicles' modelScale). The table holds
//     sized / that scale, so a body drawn at another scale here (a world boss's growth stages, a
//     bigger story Oozaru) keeps the original's proportions. The giants with hitbox parts (Ozaru,
//     Janemba, Hirudegarn, Metal Cooler's core, the giant forms...) get their registered box,
//     which is the envelope of their parts.
//   - The Ragnarok original: SuDragonBallDefinitions' Apophis / Super / Cerulean Shenron boxes;
//     the rgnpc cast (RgNpcModelSizes), the shrine dragons (sdu ShenronDisplayEntity 2 x 3) and the
//     space garrison keep the boxes their own files give them.
//  Which original entity a body is: its id ("saibaman" is not, "dmzq_saga_raditz_v0" is
//  saga_raditz), its texture ("saga_saibaman3"), then its model.
//  Generated from the original's sources (scratchpad hitbox/tools: dmztable.py, mapping.py).
// =====================================================================================

var DBR_HITBOXES = {
    "bandit": [1.4, 3.2], "bio_cell_jr": [0.8, 1.6], "car": [2.4, 1.3], "cc576": [4.5, 4], "cc_namekian": [1, 2],
    "dino1": [2.2, 5.1], "dino2": [3.3, 5.2], "dino3": [1.8, 1.5], "dinokid": [1, 1], "evil_clone_goku": [0.6, 1.8],
    "evil_clone_krillin": [0.6, 1.6], "evil_clone_nappa": [1.3, 2.8], "evil_clone_piccolo": [0.6, 1.8],
    "evil_clone_vegeta": [0.6, 1.8], "flying_nimbus": [2, 1.3], "frieza_capsule": [0.6, 0.64],
    "giant_fish": [1.9, 1.8], "giant_turtle": [0.9, 0.9], "master_babidi": [0.6, 1.2], "master_beerus": [0.8, 2],
    "master_cell": [0.7273, 1.8182], "master_dende": [0.8, 2], "master_enma": [5.5, 7.5],
    "master_frieza": [0.8889, 2.2222], "master_gero": [0.8, 2], "master_gohan": [0.8, 2], "master_goku": [0.8, 2],
    "master_grandkai": [0.8, 1.8], "master_guru": [1.3, 3], "master_kaiosama": [0.8, 1.5],
    "master_karin": [0.8, 0.8], "master_krillin": [0.75, 2], "master_oldkai": [0.75, 2],
    "master_otherworld_announcer": [0.8, 2], "master_piccolo": [0.8, 2], "master_popo": [0.8, 2],
    "master_roshi": [0.8, 1.8], "master_tien": [0.8, 2], "master_toribot": [0.6, 1.4], "master_trunks": [0.8, 2],
    "master_uranai": [0.8, 1.4], "master_vegeta": [0.8, 2], "master_whis": [0.8, 2], "master_yamcha": [0.8, 2],
    "mini_buu": [0.8889, 2], "mini_janemba_stampede": [0.9, 1.9], "namek_frog": [0.4, 0.4],
    "namek_frog_ginyu": [0.4, 0.4], "namek_trader": [1, 2], "namek_warrior": [1, 2], "porunga": [1.1429, 5.7143],
    "porunga_daima": [0.5714, 2.8571], "punch_machine": [1.5, 1.5], "red_ribbon_soldier": [1, 2],
    "robot1": [1.7, 4.5], "robot2": [1.7, 4.5], "robot3": [1.7, 4.5], "robotxv": [1.5, 1.5],
    "sabertooth": [1.8, 1.2], "saga_a13": [0.6, 2], "saga_a14": [0.5, 1.8333], "saga_a15": [0.75, 1.875],
    "saga_a16": [0.75, 1.8333], "saga_a17": [0.6, 1.8], "saga_a18": [0.6, 1.8], "saga_a18_gt": [0.6, 1.8],
    "saga_a19": [0.9, 2.1], "saga_a8": [0.7143, 1.9286], "saga_akkuman": [0.6, 1.9], "saga_babidi": [0.4, 1.5],
    "saga_baby": [0.6, 1.8], "saga_baby_golden_ozaru": [3.3333, 5.9722], "saga_baby_vegeta": [0.6, 1.8],
    "saga_bido": [0.6154, 1.7692], "saga_bio_broly": [0.5714, 1.7857], "saga_bio_broly_giant": [0.8333, 2.1667],
    "saga_bioman": [0.8, 1.6], "saga_bojack": [0.5833, 1.8333], "saga_bojack_fp": [0.6923, 1.7692],
    "saga_bon_para": [0.6, 1.8], "saga_broly_base": [0.6, 2], "saga_broly_lssj": [0.7143, 1.9286],
    "saga_broly_ssj": [0.6, 2.1], "saga_broly_ssj_restricted": [0.6, 2], "saga_bujin": [0.5556, 1.7778],
    "saga_bulma": [0.6, 1.8], "saga_burter": [1.2, 2.3], "saga_buufat": [0.8, 1.9],
    "saga_cell_imperfect": [0.6, 1.8], "saga_cell_jr": [0.8, 1.6], "saga_cell_perfect": [0.8, 2],
    "saga_cell_semiperfect": [0.5, 1.5], "saga_cell_superperfect": [0.6, 1.8], "saga_chaoz": [0.5, 1.3],
    "saga_chichi": [0.6452, 1.9355], "saga_colonel_silver": [0.6, 1.9], "saga_cooler": [0.6, 2],
    "saga_cooler_5ta": [0.5714, 1.6429], "saga_cui": [0.6, 1.8], "saga_dabura": [0.6, 1.8], "saga_dodoria": [1, 2.2],
    "saga_don_para": [0.6, 1.8], "saga_dore": [0.6, 2], "saga_dr_wheelo": [2, 2.6667], "saga_dracula": [0.6, 1.9],
    "saga_drgero": [0.6, 1.8], "saga_drum": [1.4, 4.1], "saga_eis_shenron": [0.6, 1.9],
    "saga_evilbuu": [0.4167, 1.75], "saga_fgohan_base": [0.6, 1.8], "saga_fgohan_ssj": [0.6, 1.8],
    "saga_frieza_base": [0.6, 1.8], "saga_frieza_first": [0.625, 2], "saga_frieza_fp": [0.8, 2.1],
    "saga_frieza_second": [0.6667, 2], "saga_frieza_third": [0.7692, 1.9231], "saga_friezasoldier01": [0.6, 1.8],
    "saga_friezasoldier02": [0.6, 1.8], "saga_friezasoldier03": [0.6, 1.8], "saga_ftrunks_base": [0.6, 1.8],
    "saga_ftrunks_ssg3": [0.4615, 1.3846], "saga_ftrunks_ssj": [0.6, 1.8], "saga_garlick_jr": [0.5, 1.3],
    "saga_garlick_jr_transformed": [0.75, 1.9167], "saga_general_black_robot": [1.2, 2.8],
    "saga_general_blue": [0.6, 1.9], "saga_general_red": [0.5, 1.1], "saga_gete_robot": [0.9, 2.4],
    "saga_ginyu": [0.6, 1.8], "saga_ginyu_goku": [0.6, 1.8], "saga_giran": [0.7692, 1.8462],
    "saga_glorio": [0.6, 1.8], "saga_gogeta_ssj": [0.6, 1.8], "saga_gogeta_ssj4": [0.6, 1.8],
    "saga_gohan_end_base": [0.6, 1.8], "saga_gohan_end_ssj": [0.6, 1.8], "saga_gohan_end_ssj2": [0.6, 1.8],
    "saga_gohan_end_ultimate": [0.6, 1.8], "saga_gohan_gt": [0.6, 1.8], "saga_gohan_gt_baby": [0.6, 1.8],
    "saga_gohan_gt_ssj": [0.6, 1.8], "saga_gohan_mid_base": [0.6, 1.6], "saga_gohan_mid_ssj": [0.6, 1.6],
    "saga_gohan_mid_ssj2": [0.6, 1.6], "saga_goku_daima": [0.6, 1.8], "saga_goku_daima_ssj": [0.6, 1.8],
    "saga_goku_daima_ssj2": [0.6, 1.8], "saga_goku_daima_ssj3": [0.6, 1.8], "saga_goku_end_base": [0.6, 1.8],
    "saga_goku_end_ssj": [0.6, 1.8], "saga_goku_end_ssj2": [0.6, 1.8], "saga_goku_end_ssj3": [0.6, 1.8],
    "saga_goku_gt": [0.5, 1.3], "saga_goku_gt_ssj": [0.5, 1.3], "saga_goku_gt_ssj3": [0.5, 1.3],
    "saga_goku_gt_ssj4": [0.6, 1.8], "saga_goku_mid_base": [0.6, 1.8], "saga_goku_mid_ssj": [0.6, 1.8],
    "saga_goku_mini": [0.5, 1.3], "saga_goku_mini_ssj": [0.5, 1.3], "saga_goku_mini_ssj2": [0.5, 1.3],
    "saga_goku_mini_ssj3": [0.5, 1.3], "saga_goku_t23": [0.6, 1.8], "saga_gokua": [0.5, 1.8333],
    "saga_gomah_mini": [0.5, 1.3], "saga_gomah_soldier_1": [0.7, 2.1], "saga_gomah_soldier_2": [0.7, 2.1],
    "saga_gomah_third_eye": [0.8545, 2.1727], "saga_goten": [0.5, 1.3], "saga_goten_gt": [0.6, 1.8],
    "saga_goten_gt_baby": [0.6, 1.8], "saga_goten_gt_ssj": [0.6, 1.8], "saga_goten_ssj": [0.5, 1.3],
    "saga_gotenks": [0.5, 1.4], "saga_gotenks_ssj": [0.5, 1.4], "saga_gotenks_ssj3": [0.5, 1.4],
    "saga_guldo": [0.8, 1.6], "saga_hirudegarn": [4, 5.2], "saga_hirudegarn_incomplete2": [4, 5.2],
    "saga_hyper_rilldo": [0.6, 1.9], "saga_invisible_man": [0.6, 1.9], "saga_jackie_chun": [0.7059, 2.1176],
    "saga_jackie_chun_fp": [0.7143, 1.9286], "saga_janemba_fat": [1.0625, 1.625], "saga_jeice": [0.6, 1.8],
    "saga_kibito": [0.9, 2.2], "saga_kid_gohan": [0.5, 1.3], "saga_kid_goku": [0.5, 1.1],
    "saga_kid_krillin": [0.5, 1.1], "saga_kid_trunks": [0.5, 1.3], "saga_kid_trunks_ssj": [0.5, 1.3],
    "saga_kidbuu": [0.4, 1.4], "saga_king_cold": [0.75, 2], "saga_krillin": [0.6, 1.6],
    "saga_ledgic": [0.6364, 1.8182], "saga_liang_xing_long": [0.8, 2.4], "saga_liu_xing_long": [0.6, 1.8],
    "saga_liu_xing_long_transformed": [0.6, 1.9], "saga_luud": [2, 4], "saga_mai_robot": [1.3333, 3.4167],
    "saga_majin_duu": [0.7, 1.5], "saga_majin_kuu": [0.8, 2], "saga_majunia": [0.8, 2.2],
    "saga_majunia_giant": [0.9, 2.35], "saga_majuub": [0.6, 1.8], "saga_masked_warrior": [0.6, 1.9],
    "saga_mecha_frieza": [0.6, 1.8], "saga_metal_cooler": [0.8, 2], "saga_metal_cooler_core": [0.8333, 2.1667],
    "saga_metal_rilldo": [0.6364, 1.8182], "saga_morosoldier": [0.6, 1.8], "saga_mr_satan": [0.6, 1.8],
    "saga_mummy": [0.7143, 1.9286], "saga_nail": [0.6, 1.8], "saga_nam": [0.6, 2], "saga_nappa": [1.3, 2.8],
    "saga_neiz": [0.6, 2], "saga_neo_shenron": [0.6, 1.9], "saga_neo_shenron_transformed": [0.6, 1.9],
    "saga_ninja_murasaki": [0.6, 2], "saga_ogre_blue": [0.6, 1.95], "saga_ogre_red": [0.6, 1.95],
    "saga_omega_shenron": [1.2, 2.5], "saga_oolong": [0.5, 1.1], "saga_oolong_transformed": [0.8, 1.6667],
    "saga_ozaru": [3.3333, 5.9722], "saga_ozaruvegeta": [3.3333, 5.9722], "saga_paikuhan": [0.6, 2],
    "saga_pan": [0.6667, 1.8889], "saga_paragus": [0.6, 2], "saga_piccolo": [0.6, 1.8],
    "saga_piccolo_daimao_old": [0.8182, 2.0909], "saga_piccolo_daimao_young": [0.8333, 2.1667],
    "saga_piccolo_kami": [0.6, 1.8], "saga_pilaf_robot": [1.25, 1.8125], "saga_pilaf_robot_fused": [1.5, 4.3333],
    "saga_puipui": [0.6, 1.8], "saga_qi_xing_long": [1.8333, 2], "saga_qi_xing_long_transformed": [1.75, 2],
    "saga_raditz": [0.6, 1.8], "saga_recoome": [0.8, 2.1], "saga_rilldo": [0.6, 1.8], "saga_saibaman1": [0.8, 1.6],
    "saga_saibaman2": [0.8, 1.6], "saga_saibaman3": [0.8, 1.6], "saga_saibaman4": [0.8, 1.6],
    "saga_saibaman5": [0.8, 1.6], "saga_saibaman6": [0.8, 1.6], "saga_saiyan_elite": [0.6, 1.8],
    "saga_saiyan_oozaru": [2.2222, 4.2778], "saga_saiyan_soldier": [0.6, 1.8], "saga_salza": [0.6, 2],
    "saga_sergeant_metallic": [0.7143, 1.9286], "saga_shin": [0.6, 1.8], "saga_shu_robot": [1, 2.4],
    "saga_slug": [0.5833, 1.8333], "saga_slug_giant": [0.8333, 2.1667], "saga_slug_soldier": [0.6, 2],
    "saga_son_para": [0.6, 1.8], "saga_spopovitch": [0.9, 2.2], "saga_super_17": [0.5714, 1.8095],
    "saga_super_a13": [0.7143, 1.8571], "saga_super_baby_vegeta": [0.6, 1.8], "saga_super_baby_vegeta2": [0.6, 1.8],
    "saga_super_hirudegarn": [4, 5.2], "saga_super_janemba": [0.6, 2], "saga_superbuu": [0.5, 1.75],
    "saga_superbuu_gohan": [0.5, 1.75], "saga_superbuu_gotenks": [0.5, 1.75], "saga_superbuu_piccolo": [0.5, 1.75],
    "saga_syn_shenron": [0.9, 2.4], "saga_tamagami_1": [0.6667, 2.3333], "saga_tamagami_1_powered": [0.6667, 2.3333],
    "saga_tamagami_2": [0.6667, 2.3333], "saga_tamagami_2_powered": [0.6667, 2.3333],
    "saga_tamagami_3": [0.7333, 2.0667], "saga_tamagami_3_powered": [0.7333, 2.0667], "saga_tambourine": [0.8, 2.2],
    "saga_tao_pai_pai": [0.6, 1.9], "saga_tao_pai_pai_cyborg": [0.6, 1.9], "saga_teen_yamcha": [0.6667, 2],
    "saga_tien_early": [0.6, 1.8], "saga_tien_t23": [0.6, 1.8], "saga_trunks_gt": [0.6, 1.8],
    "saga_trunks_gt_baby": [0.6, 1.8], "saga_trunks_gt_ssj": [0.6, 1.8], "saga_turles": [0.6, 2],
    "saga_uub": [0.6, 1.8], "saga_vegeta": [0.6, 1.8], "saga_vegeta_daima": [0.6, 1.8],
    "saga_vegeta_daima_ssj": [0.6, 1.8], "saga_vegeta_daima_ssj2": [0.6, 1.8], "saga_vegeta_daima_ssj3": [0.6, 1.8],
    "saga_vegeta_end_base": [0.6, 1.8], "saga_vegeta_end_ssj": [0.6, 1.8], "saga_vegeta_end_ssj2": [0.6, 1.8],
    "saga_vegeta_gt": [0.6, 1.8], "saga_vegeta_gt_ssj": [0.6, 1.8], "saga_vegeta_gt_ssj2": [0.6, 1.8],
    "saga_vegeta_gt_ssj4": [0.6, 1.8], "saga_vegeta_majin": [0.6, 1.8], "saga_vegeta_mid_base": [0.6, 1.8],
    "saga_vegeta_mid_ssj": [0.6, 1.8], "saga_vegeta_mini": [0.5, 1.3], "saga_vegeta_mini_ssj": [0.5, 1.3],
    "saga_vegeta_mini_ssj2": [0.5, 1.3], "saga_vegeta_mini_ssj3": [0.5, 1.3], "saga_vegeta_namek": [0.6, 1.8],
    "saga_vegetto_base": [0.6, 1.8], "saga_vegetto_ssj": [0.6, 1.8], "saga_videl": [0.6, 1.8],
    "saga_world_tournament_announcer": [0.6, 1.9], "saga_wu_xing_long": [0.8, 2.4],
    "saga_wu_xing_long_transformed": [1.8333, 2.5], "saga_yajirobe": [0.6, 1.8], "saga_yakon": [0.7333, 1.6667],
    "saga_yamcha": [0.6, 1.8], "saga_yamcha_t23": [0.6, 1.8], "saga_young_tien": [0.6, 1.8],
    "saga_young_yamcha": [0.6, 1.8], "saga_zangya": [0.6, 1.8], "saga_zarbon": [0.6, 1.8],
    "saga_zarbont1": [1.3, 2.1], "shadow_dummy": [0.6, 1.8], "shenron": [0.8571, 4.8571],
    "spacepod": [1.8182, 1.8182], "worldboss_janemba_fat": [1.0625, 1.625], "worldboss_metal_cooler": [0.8, 2],
    "worldboss_metal_cooler_copy": [0.7778, 2], "worldboss_metal_cooler_core": [0.8333, 2.1667],
    "worldboss_mini_janemba": [0.875, 1.875], "worldboss_super_janemba": [0.6, 2], "worldboss_turles": [0.6, 2]
};
// The Ragnarok original's dragons (SuDragonBallDefinitions entity boxes over their render scales 3 / 4 / 3)
var DBR_HITBOXES_RG = { apophis: [1, 5.6667], super_shenron: [1, 6], cerulean_shenron: [1, 5.6667] };

var DBR_HITBOX = (function () {
    var ALIAS = { giantturtle: "giant_turtle", namekfrog: "namek_frog", giantfish: "giant_fish", kinton: "flying_nimbus" };
    var FORCE = { wb_gomah: "saga_gomah_third_eye", wb_gomah_s1: "saga_gomah_third_eye", wb_gomah_s2: "saga_gomah_third_eye",
        wb_gomah_s3: "saga_gomah_third_eye", wb_gomah_s4: "saga_gomah_third_eye", wb_gomah_s5: "saga_gomah_third_eye" };
    function base(p) { return String(p || "").replace(/^.*[\/:]/, "").replace(/\.geo\.json$/, "").replace(/\.png$/, ""); }
    function known(n) { n = ALIAS[n] || n; return n && DBR_HITBOXES[n] ? n : null; }

    // the original entity a definition draws, or null
    function original(id, d) {
        if (FORCE[id]) return FORCE[id];
        if (/^(rgnpc_|dbr_shrine_dragon_)/.test(id)) return null;
        var g = d.geo || {}, tex = base(g.texture), mod = base(g.model);
        var bare = id.replace(/^(dmzq_|dbr_garrison_|dbr_conquest_|dbr_vegeta_)/, "").replace(/_v\d+$/, "");
        var cands = [id, bare, id.indexOf("wb_") === 0 ? "worldboss_" + id.substring(3) : null, tex, tex.replace(/_\d+$/, ""),
            "saga_" + id, "master_" + id, mod];
        for (var i = 0; i < cands.length; i++) { var n = cands[i] ? known(cands[i]) : null; if (n) return n; }
        return null;
    }

    // [width, height] before the definition's scale, or null to keep what it has
    function box(id, d) {
        if (DBR_HITBOXES_RG[id]) return DBR_HITBOXES_RG[id];
        var n = original(id, d);
        return n ? DBR_HITBOXES[n] : null;
    }

    function apply(api) {
        var n = 0;
        api.list().forEach(function (id) {
            var d = api.get(id);
            if (!d) return;
            var b = box(String(id), d);
            if (!b) return;
            if (Math.abs(Number(d.width) - b[0]) < 1e-3 && Math.abs(Number(d.height) - b[1]) < 1e-3) return;
            api.patch(id, { width: b[0], height: b[1] });
            n++;
        });
        return n;
    }
    var mobs = apply(RPG.mobs), npcs = apply(RPG.npcs);
    return { box: box, original: original, patched: { mobs: mobs, npcs: npcs } };
})();
