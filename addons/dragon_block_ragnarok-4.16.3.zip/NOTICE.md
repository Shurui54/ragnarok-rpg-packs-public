# Dragon Block Ragnarok

Dragon Block Ragnarok is an addon for the Ragnarok Modding Toolkit. Its gameplay systems are a port of
**DragonMine Z** (https://github.com/DragonMineZ/dragonminez), rewritten as toolkit scripts.

- DragonMine Z is Copyright (c) DragonMine Z 2025 and is licensed under the GNU General Public License v3.0.
- This addon is a modified version of that work and is likewise licensed under the **GNU General Public
  License v3.0** (see `LICENSE`). Its scripts are its complete source code.
- Models, textures, animations and sounds come from DragonMine Z through the separate `dmzpack` asset pack,
  which carries its own credits, including CC-BY attributions for third-party sounds.
- Changes: DragonMine Z's Java systems were reimplemented as JavaScript for the Ragnarok Modding Toolkit's script
  engine; content and balance are adapted to that engine.
- In the scripts' comments, "the original" means DragonMine Z and "the Ragnarok original" means DMZ Ragnarok
  (both credited in this file); class and file names given there are those projects' own.
- The structure templates in `datapack/data/dbr/structures/dmz/` and their descriptions in `data/dmz_structures/`
  are converted from DragonMine Z's structure files, Other World region files and tournament schematic
  (split into 32x32 pieces, DMZ blocks mapped to this addon's blocks or vanilla stand-ins). The chest loot
  tables in `datapack/data/dbr/loot_tables/chests/` are DragonMine Z's.
- The higher-tier radar parts (`resources/assets/dbr/textures/item/refined_radar_piece.png`, `t3|t4|t5_radar_chip|cpu.png`)
  and the outfit / cosmetic pattern icons (`resources/assets/dbr/textures/item/patterns/`) are DragonMine Z's radar part
  and pattern textures, recoloured by `docs/dmz-spec/tools/make_radar_tints.py` and `make_outfit_patterns.py` in the
  toolkit. The radar recipes follow DMZ's ShapedDragonRadarRecipeDefinition; the outfit patterns follow DMZ's
  Pattern Station / Kikono Station recipes (DMZPatternRecipeProvider, DMZKikonoRecipeProvider).

- The aura shaders and their includes (`resources/assets/dbr/shaders/core/aura_*`, `bloom_*`, `shaders/include/aura_color.glsl`)
  are DragonMine Z's GLSL; `resources/assets/dbr/textures/fx/aura_noise.png` is generated with DMZ's AuraNoiseTexture
  algorithm; `client/scripts/43_dmz_aura_shader.js` ports AuraRenderer / Aura3DRenderer / AuraStyle / AuraMeshFactory
  and `shared/07b_dmz_aura_data.js` holds DMZ's per-form aura settings (FormConfig).

- Flight (`scripts/64_dmz_movement.js`, `client/scripts/44_dmz_flight.js`) ports FlySkillEvent, CombatFlightHandler,
  FlightOrientationHandler, FlightAttitude (the fast-flight attitude quaternions and the barrel roll), FlightSoundInstance,
  FlyStatusHandler, FlyToggleC2S, FlightModeC2S, FlightModeLockC2S, SetFlightSpeedLimitC2S, CombatFlyImpulseC2S,
  KnockbackHelper's flight sync (KnockbackFlightS2C) and DMZPlayerRenderer's fast-flight model rotation.

- The ki attack shader (`resources/assets/dbr/shaders/core/kiattack*`) is DragonMine Z's kiattack GLSL (vertex
  inputs adapted to the toolkit's mesh formats), and `ki_charge_rays*` is its charge_rays shader (the Kamehameha's
  charge rays; its shockwave vertex stage rewritten for the toolkit's matrices); the ki ball lightning in
  `client/scripts/43_dmz_lightning.js` ports LightningBoltRenderer's sphere pass (drawSphereKiPass); `client/scripts/51_dmz_ki_render.js` ports KiProjectileRenderer,
  KiWaveRenderer, KiLaserRenderer, KiDiskRenderer, KiEmberRenderer, KiExplosionVisualRenderer, KiMeshFactory and
  KiSpiralMesh; the ki attack behaviour in `scripts/41_dmz_techniques.js` ports KiBlastEntity, KiWaveEntity,
  KiLaserEntity, KiDiskEntity, AbstractKiProjectile, TechniqueDispatcher's movement holds and KiBlastC2S (the plain
  ki blast); `scripts/42_dbr_destruction.js` eat / slice follow KiTerrainDestruction. Final Explosion (in 41 and 51)
  ports KiExplosionEntity and KiExplosionRenderer; the ki particles and the small blast's ribbon in 51 port the
  particle code of those entities, KiTrailParticle, KiSheddingParticle, KiSplashParticle, KiSplashWaveParticle,
  KiExplosionParticle, KiExplosionSplashParticle and KiTrailRenderer.
- `scripts/99z_dbr_hitboxes.js` holds DragonMine Z's entity boxes (MainEntities' `sized(w, h)`, DragonBallDefinitions'
  dragon boxes, the hitbox parts of its giants) over its model scales (setScaleVal, renderer and vehicle model scales),
  and DMZ Ragnarok's dragon boxes (SuDragonBallDefinitions).
- The melee hit, block, parry and guard-break particles (`scripts/11_dmz_combat.js`, `client/scripts/42_combat.js`)
  port ForgeCommonEvents.onLivingAttack, CombatEvent's guard code, PunchParticle, BlockParticle and GuardBlockParticle.
- The barrage techniques (`scripts/41v_dmz_volleys.js`, `client/scripts/51v_dmz_volleys.js`) port DragonMine Z's
  KiBlastEntity Assault Rain / Blaster Meteor / Tri-Beam code, HellzoneGrenadeEntity (and its Orb), KillDriverEntity and
  KillDriverRenderer, KiMeshFactory's triangle-prism and torus meshes, as light simulations instead of one entity a shot.
  `scripts/11b_dmz_impacts.js` ports CombatEvent's momentum strike and damage-scaled knockback and MomentumImpactHandler;
  the melee wind-up (`shared/04_dmz_combat.js`, `client/scripts/42_combat.js`) ports PlayerAttackHelper /
  MeleeWindupTracker's timing; the Dimensional Punch in `scripts/41s_dmz_strikes.js` ports processDimensionalPunch.
- The strike combos (`scripts/41c_dmz_strike_combos.js`) port DragonMine Z's StrikeCombos (MeteorBurstCombo, MysticBallCombo,
  DarknessEyeBeamCombo, DeathChaserCombo, AndroidCombo, BeamSwordSlashCombo, PerfectRushCombo, SpiritBreakerCombo) and
  HeldVictim; `scripts/41s_dmz_strikes.js` ports processGrab, processShiningSword, processDimensionalSlash,
  SwordSlashManager and StrikeCinematics; `scripts/41sx_dmz_strike_clash.js` ports StrikeClash;
  `client/scripts/49c_dmz_strike_camera.js` ports StrikeCinematicCamera and `client/scripts/49t_dmz_strike_fx2.js`
  ports SwordSlashEffect, DimensionalFistEffect's portal, KiBurstShakeState and the Neo Tri-Beam's charge lightning and
  follow-up window (KiProjectileRenderer, KiTechniqueHandler.TriBeam).
- The transformation outlines use DragonMine Z's post chain `shaders/post/transformation_outline.json` and its
  programs from the dmzpack art pack; `shared/07c_dmz_outline.js` ports TransformationPostShaderManager's uniforms,
  and the forms' (FormConfig outlineShader), the Demon Eye's and the world bosses' outline styles (DBSagasEntity) are DMZ's.

- The hair system (`shared/11_dmz_hair.js`) ports DragonMine Z's strand hair (hair codes, presets, per-form styles,
  physics profiles); `client/data/dmz_hair_presets/` (one file per preset) and `shared/10_dmz_hair_presets.js` are DragonMine Z's
  hair preset codes, decoded with that file's decoder. DragonMine Z 2.2's own hair code format (HairCodec: NBT, raw
  DEFLATE, base64url / base62), CustomHair / HairStrand / HairSegmentOverride saving, HairLegacyMigrator, HairSanitizer,
  HairStrandSizing and the server's HairConfig limits are ported there too (byte-exact encoding).
- `shared/12_dmz_hair_gen.js` ports DragonMine Z 2.2's HairTransformGenerator ("Generate from Base").
- The hair editor (`client/scripts/21_dmz_hair_editor.js`) ports DragonMine Z 2.2's HairEditorScreen, HairOutlinerPanel,
  HairInspectorPanel / HairInspectorRows, HairEditorState, HairEditHistory, HairViewportTool, HairEditorUi / Textures / Sounds
  (layout, controls, texts and its GUI art: menubig, menusmall, characterbuttons, the roshi panorama).
- `scripts/21_dmz_hair.js` ports DragonMine Z 2.2's per-character custom hair storage and sync (Character hair styles,
  UpdateCustomHairC2S) and HairCommand (`/dmzhair`).
- `client/scripts/44_dmz_hair_transition.js` ports DragonMine Z 2.2's FormTransition / FormVisualTransition as the hair
  uses them, HairStyleResolver and HairPoseBuilder.buildBlend (the hair growing while a transformation charges).
- `tests/hair_codes.json` holds DragonMine Z 2.2's preset hair codes and what its own HairCodec / HairTransformGenerator
  produce from them (run once outside the game).

- The world bosses (`scripts/77_dmz_world_bosses.js`, `scripts/77_dmz_world_bosses_ai.js`, `client/scripts/68_dmz_worldboss.js`)
  port DragonMine Z's WorldBossManager / WorldBossSession / WorldBossContribution / WorldBossRewards / WorldBossCombatEvents,
  AllWorldBossesEntity, GeteStarEntities, WorldBossResultsScreen, WorldBossContributionHUD, WorldBossReviveOverlay and
  TelegraphEffect (GPL-3.0), reimplemented in JavaScript.
- The NPC-hosted tournaments (`scripts/95_dmz_tournaments.js`, `client/scripts/85_dmz_tournaments.js`) port DragonMine Z's
  tournament system (Tournament.java, TournamentDefinition, ArenaProtectionHandler, TournamentBracketScreen,
  TournamentOverlay, SagaHaloLayer) with its default tournament settings and English lines.

- The in-game form editor (`scripts/32_dbr_form_editor.js`, `client/scripts/70_form_editor.js`) ports the form
  editor screens and form data workflow of DMZ Ragnarok, a GPL-3.0 Forge addon for DragonMine Z (saves apply at once
  and reach every client's transformation menu, like its SaveFormPacket).
- The per-form auto dodge, damage mitigation and damage-taken stat buffs (`scripts/34_dbr_form_combat.js`, the form
  editor's Dodge and Buffs tabs, the `combat` form field in `shared/07_dmz_forms_data.js`, the flat bonus terms in
  `shared/02_dmz_formulas.js` and the dodge twist in `client/scripts/40_animator.js`) port DMZ Ragnarok's (GPL-3.0)
  FormCombatData, FormCombatHandler, FormEditScreen Dodge/Buffs tabs and DodgeAnimator; the flat bonus follows
  DragonMine Z's BonusStats / StatsData (GPL-3.0).
- The menu transitions (`client/scripts/29_dmz_menu_fx.js`, used by the V-menu screens) port DragonMine Z's
  BaseMenuScreen panel slide / fade timings and easing (GPL-3.0).

- The rgnpc NPC cast (`scripts/62_rg_npcs.js`, `shared/14_rg_npc_data.js`, `client/scripts/71_rg_npc_picker.js`,
  `resources/assets/dbr/geo|textures/entity/rgnpc/`) is DMZ Ragnarok's
  rgnpc display NPC table, models and sizes (GPL-3.0). The `saga_*` and `master_*` models and their textures are
  derived from NinjinEntities (kaixi, Vidal1sHere, Phoenix_II) under the MIT License; its notice is
  `ninjin_license.txt` in those folders. The shadow dragon models (`2stars` .. `7starstrue`, `omega`, `omega2`) are
  DMZ Ragnarok's own art. The `dmzpack` asset pack also carries DMZ Ragnarok's RagnaPack textures (see its credits).

- The menu skin (`resources/assets/dbr/textures/gui/theme/`: panel, buttons, field box, slot, scrollbar, tab plaque and
  the RAGNAROK logo, set as the engine theme's textures in `scripts/05_ui.js`) is DMZ Ragnarok's GUI art (its
  `shuruisutilities` panel, buttons, dropdown, slot and scrollbar textures, GPL-3.0).

- The Dragon Block menu (`/dbrgui` and its key: `scripts/98_dbr_hub.js`, `client/scripts/90_dbr_hub.js`) ports DMZ
  Ragnarok's unified hub (GPL-3.0): shuruisutilities `hub/HubServer` (the server-side router and permission gate that
  sends only the rows a player may open and re-checks every open request), the player menu `SUHubScreen` and the
  editor hub `SduHubScreen` (one dropdown section per module) on its shared `SagaBaseScreen` / `GuiTheme` canvas.

- The space system (`scripts/86_dbr_space.js`, `client/scripts/61_dbr_space.js`, the `ragnarok_rpg:space` dimension in
  `datapack/`) ports the behaviour of DMZ Ragnarok's Space module (GPL-3.0): the sun-centred planet rings and their
  wall-clock orbits (Orbits / PlanetPositions), entering space above the entry altitude and leaving below the return
  altitude, landing on planets, the star map with autopilot, the planet info overlay and the radar. The planet, sun,
  ring and cloud textures in `resources/assets/dbr/textures/space/` are DMZ Ragnarok's (its solar system pack and
  planet sheets, and the solar-system pack's block models in `resources/assets/dbr/models/space/`, with their animated
  sun and flare sheets) plus its dragon-ball star sprites. The generated universe (`shared/16_dbr_space_gen.js`,
  `shared/17_dbr_space_bodies.js`) reproduces DMZ Ragnarok's GeneratedSystems, StarPositions, BlackHolePositions,
  MoonBody, SuperPlanetPositions, SurfaceDimension cells, SurfaceStamp themes and PlanetWeather bit for bit where they
  are hashes. Planet Vegeta's worldgen (`datapack/data/ragnarok_rpg/dimension*/planet_vegeta.json`,
  `datapack/data/dbr/worldgen/*/vegeta*`, `noise_settings/planet_vegeta.json`) is DMZ Ragnarok's, with its blocks mapped
  to this addon's. Its Saiyan settlement and Saibaman hut structures (`datapack/data/dbr/structures/saiyan_settlement/`,
  `worldgen/{structure,structure_set,template_pool}/saiyan_settlement*`, `saibaman_hut.json`) are DMZ Ragnarok's
  templates, pools and placement, with Rocky blocks mapped to this addon's. The asteroid fields, planet destruction
  (planet buster, the planet clash, the doom sequence, salvage) and Vegeta's garrisons, citizens and traders
  (`shared/18_dbr_space_clash.js`, `scripts/87_dbr_space_buster.js`, `scripts/88_dbr_space_vegeta.js`) port DMZ
  Ragnarok's AsteroidPositions/AsteroidStamp, PlanetBusterModule/PlanetClash/PlanetDestruction/PlanetSalvage and
  PlanetGarrison/SaiyanTraderEntity; the clash meter is DragonMine Z's ClashMeter/BeamClash, drawn on DMZ's ki bar art.
  The wild planet garrisons and the conquest defender (`scripts/86c_dbr_space_garrison.js`) port DMZ Ragnarok's
  PlanetGarrison, PlanetGarrisonRoster, PlanetGarrisonData, PlanetGarrisonDefenderConfineGoal, PlanetConquest and the
  conquest parts of CommandSpacePlanet/PlanetToughness/PlanetInfoServer (families, counts, battle-power stats, the
  hero defenders per theme, the player-scaled boss, its messages and the personal claim).
  Beam clashes (`scripts/41b_dbr_beam_clash.js`, the clash HUD and cinematic camera in `client/scripts/61_dbr_space.js`)
  port DragonMine Z's BeamClashManager, BeamClash, ClashParticipant, BeamClashOverlay, BeamClashCinematicCamera and
  BeamClashScreenRenderer (its `beam_clash` speed-line shader from the dmzpack art pack); the clash lock
  (`scripts/40b_dbr_clash_lock.js`, `client/scripts/41_dbr_clash_lock.js`) holds the fighters of a beam or melee clash.
  The planet's death in `client/scripts/61_dbr_space.js` (the red ramp, the detonation flash, the flying shards and
  the bang) ports DMZ Ragnarok's PlanetDoomEffects and SpaceBodyRenderer.drawShatter, and the shards wear DMZ
  Ragnarok's planet placeholder sheets (`resources/assets/dbr/textures/space/planet_placeholder_*.png`).

- The Planet Vegeta capital and Beerus' planet (`regions/ragnarok_rpg/planet_vegeta/`, `regions/ragnarok_rpg/beerus_planet/`,
  `datapack/data/ragnarok_rpg/dimension{,_type}/beerus_planet.json`, `datapack/data/dbr/worldgen/biome/beerus.json`) are
  DMZ Ragnarok's authored builds (its shipped region files, GPL-3.0), converted by the toolkit's `tools/dmzr_regions.py`
  (DMZ / DMZ Ragnarok block and biome ids mapped to this addon's, DMZ Ragnarok's structure references dropped).
- Planet Cereal is this addon's own work (GPL-3.0): DragonMine Z only names it (the `dragonminez:cereal_planet` pod
  destination, its Instant Transmission fee, Granolah's armour and pattern) and DMZ Ragnarok gives it a ring in the sky
  and the Cerulean Dragon Balls. Its dimension, terrain, biomes, features and structure templates
  (`datapack/data/ragnarok_rpg/dimension{,_type}/cereal_planet.json`, `datapack/data/dbr/worldgen/*/cereal*`,
  `datapack/data/dbr/structures/cereal/`) are generated from vanilla blocks by the toolkit's `tools/cereal_worldgen.py`;
  the Cerealian model and skins and Granolah's (`resources/assets/dbr/{geo,textures}/entity/cereal/`) are original
  pixel art painted by `tools/cereal_art.py`, and Monaito's sheet is DragonMine Z's Namekian villager texture aged and
  recoloured by it. The sky (`client/scripts/62_dbr_cereal_sky.js`) hangs DragonMine Z's own Demon Realm sky sheets.
- The dungeons (`scripts/90_dbr_dungeons*.js`, `shared/20_dbr_dungeons_data.js`, `client/scripts/80_dbr_dungeons.js`, the
  `dbr:dungeon_*` dimensions in `datapack/`, `data/dbr_dungeons/`, `client/data/dbr_dungeons/`) port DMZ Ragnarok's
  Dungeons module (GPL-3.0): its floor, rule, spawner and crate models, configuration options, screens and strings.
  The room templates, jigsaw pools and theme palettes in `data/dbr_dungeons/` are converted from DMZ Ragnarok's own
  rooms (built by Ragnarok Studios from DMZ's block palette); the crate models,
  animations and textures and the TP gem icons in `resources/assets/dbr/*/dungeons/` are DMZ Ragnarok's.

- The partial keep inventory and death graves (`scripts/89_dbr_keep_inventory.js`, with the Server rows of
  `client/scripts/54_dmz_config_menu.js`) port DMZ Ragnarok's (GPL-3.0) KeepPartialInventory gamerule and grave system
  (GraveEventHandler, GraveManager, GraveData, GraveStorage, GraveAccess, the Curios and Cosmetic Armor grave compat,
  the dragon ball totems of DragonBallTotem and the /rggrave command): what is kept below and above the level
  threshold, the graves with their stored items and experience, their despawn timer and settings, and their strings.
  The headstone model (`resources/assets/dbr/models/rpg/block/dbr_grave.json`, vanilla textures) and the ball totems
  drawn as the balls they hold are this addon's own look; DMZ Ragnarok's graves are an oak fence with the player's head.

- The ground item clear (`scripts/99_dbr_item_clear.js`, with Server rows in `client/scripts/54_dmz_config_menu.js`)
  ports DMZ Ragnarok's (GPL-3.0) shuruisutilities ItemClearHandler and its ItemClear* settings: the schedule, the
  countdown warnings, the warning and done messages (same text and colours), the operator countdown, the exclusion
  list and the rule that dragon balls are never cleared. The /rpgc clearitems command is this addon's own.
- DMZ Ragnarok's Dragon Ball-Sack and dragon ball rules (`scripts/57_dragon_balls_bag.js`, `scripts/57_dragon_balls_rules.js`,
  `client/scripts/57_dbr_dragonball_bag.js`, with hooks in `scripts/57_dragon_balls.js`, `89_dbr_keep_inventory.js`,
  `90_dbr_dungeons.js` and `65_dmz_structures.js`) port its dragonballbag package (DragonBallBagItem, DragonBallBagMenu,
  DragonBallBagScreen, DragonBallBagInventory, DragonBallCarry, DragonBallConfine, DragonBallContainerEject,
  DragonBallEntityGuard, DragonBallInventoryHandler, DragonBallTotem), BallUniqueness, BallDimensionSweep, ScatterGuard,
  DragonBallClaimGuard, RadarDimensionReport, BallSetCommands, BallLocatorCommand, DungeonPvpBridge, its Super ball
  placement spacing and real-day Super dormancy (GPL-3.0), with their rules, defaults and English lines. The sack's
  item and screen textures (`resources/assets/dbr/textures/item/dragonball_bag.png`, `textures/gui/dragonball_bag.png`)
  are DMZ Ragnarok's; the empty-slot outline (`textures/gui/slot/dragonball_bag.png`) is traced from its item art.
- The Saibaman seeds, plants and tamed Saibamen (`scripts/86b_dbr_saibamen.js`, with hooks in `86_dbr_space.js`,
  `88_dbr_space_vegeta.js` and `45_keys.js`, and `datapack/data/dbr/worldgen/processor_list/hut_saibaman_seeds_*.json`)
  port DMZ Ragnarok's (GPL-3.0) shuruisutilities saibaman package (SaibamanCropRegistry, SaibamanSeedItem,
  SaibamanCropBlock, SaibamanCropBlockEntity, SaibamanKiRegenSuppression, SaibamanGrowItem, SaibamanCropEvents,
  ConfigSaibamanPet, SaibamanPetEntity, SaibamanPetRegistry, HutSaibamanCropProcessor), its hut_saibaman_seeds processor
  lists and SurfaceStamp.plantHutSeeds, with their numbers and English lines. The plant, seed and buried seed textures
  and models (`resources/assets/dbr/textures/block/saibaman_*`, `textures/item/saibaman_seed.png`,
  `models/rpg/*/saibaman_*`) are DMZ Ragnarok's; the tamed Saibamen wear DragonMine Z's saibaman model and skins.

- The Ki sharing and the Super Saiyan God ritual (`scripts/64_dmz_kishare.js`, `client/scripts/46_dmz_kishare.js`, the
  `godritual` form group in `shared/07_dmz_forms_data.js`) port DragonMine Z's (GPL-3.0) KiShareService, GodRitualService,
  GodRitualHelper, KiShareInput, KiSharePose, KiShareVisuals, GodRitualShellEffect, the KiTransfer / GodRitual server
  settings and the god ritual form, with their numbers and English lines. The singleplayer settings are this addon's.
- DragonMine Z's raids (`scripts/92_dmz_raids.js`, with the scout hand-off in `scripts/66_dmz_sites.js` and the raid music
  in `client/scripts/68_dmz_worldboss.js`) port its Raid, RaidManager, RaidSiteManager, RaidTriggerEvents, RaidFeedback,
  RaidReward, RaidDefaults / RaidDefinition, RaidCommand, RaidMusicManager and the Saiyan invaders' fake moon (GPL-3.0),
  with their waves, numbers, rewards and English lines.
- DMZ Ragnarok's rituals (`scripts/95_dbr_rituals.js`, `client/scripts/95_dbr_rituals.js`, the Super Saiyan 5 and Primal
  Namekian forms in `shared/07_dmz_forms_data.js`, the idol models and textures in `resources/assets/dbr/models/rpg/*/`
  and `textures/block/idol_*`, `*_idol_art`) port its SsgRitualManager, WishRitualManager, WishRitualStore, RitualSettings,
  RitualAnnouncer, DragonBallRecreation, ShenronIdol (block, item, prompt and confirm packets, screen), SsgKnowledgeCommand,
  RitualForms, RitualRaceMergeImpl (the ssj5 / ssj5daima / primalnamekian form files), SuSsj5Wish and SuSsgKnowledgeWish
  (GPL-3.0), and its RadarTotems (dragon ball grave totems on the radar) and the logout half of DragonBallTotem in
  `scripts/89_dbr_keep_inventory.js`. The fusion with Shenron and the recreation live in DMZ Ragnarok's private Ragnarok
  Key; their behaviour here is rebuilt from the public core's rules, numbers, strings and screen.
- DragonMine Z's quirks and easter eggs (`scripts/98_dbr_quirks.js`, `shared/27_dbr_quirks.js`, with hooks in
  `scripts/31_dmz_transform.js`, `scripts/30_forms.js`, `shared/11_dmz_hair.js`, `client/scripts/43_dmz_aura_shader.js`,
  `scripts/41_dmz_techniques.js` and `scripts/75_mobs_bosses.js`) port its HelmetFormLook (Broly's tiara over the Mutant
  forms), helmetsThatKeepHair, HalloweenEvent and HalloweenPumpkinLayer, the animals' spawn skins (GiantFishEntity's 3%
  special fish, GiantTurtleEntity, SabertoothEntity, NamekFrogEntity), the frogs' croaks and death laugh and
  NamekFrogGinyuEntity, AkkumanEntity's evil-heart bonus, SagaOgreEntity's targeting, the Saibaman and Chaoz kamikaze,
  InvisibleManEntity, and DMZDamageSource / MainDamageTypes with the English death lines (GPL-3.0).
- DragonMine Z's racial skills (`scripts/33_dmz_racials.js`, `client/scripts/46_dmz_racials.js`, with hooks in
  `scripts/31_dmz_transform.js`, `scripts/75_mobs_bosses.js` and `scripts/98_dbr_commands.js`) port its HumanAdaptation
  (Adrenaline), FrostDemonReserve, SaiyanZenkai, BioAndroidEvolution (Self-Destruct, Cell Jr.), CellJrEntity,
  CaptureRequest / PendingCapture / RacialRequestS2C, RacialReset, the racial branch of TriggerCommand, RacialSkillsConfig,
  BioSwellRenderState and KiReserveHUD / HudSideMeters with DMZ's `hud_reserve` sheet (GPL-3.0), with their numbers and
  English lines.

- The Tailor's Catalogue outfits and cosmetics (`scripts/18_outfits_data.js`, `scripts/19_outfits.js`,
  `scripts/19b_cosmetics_data.js`, `scripts/19c_cosmetics.js`) use art from the separate `outfitpack` art pack, which
  carries its own credits (`assets/outfitpack/CREDITS.md`). That art is not covered by this addon's GPL licence.

Dragon Ball is a trademark of its respective owners. This is a non-commercial fan project.
- DMZ Ragnarok's tab list and rank badges (`scripts/98_dbr_tablist.js`, `client/scripts/98_dbr_tablist.js`) port its
  shuruisutilities tab list and ranks (GPL-3.0: MixinPlayerTabOverlay, TabListBannerClient / PacketTabListBanner,
  RankManager, RankBadgeMetrics, RankClientEvents): the 14-pixel rows with the 12-pixel badge centred, rows sorted
  most senior rank first, the server banner above the header, and the badge before names in the tab list and over
  heads. The rank badge pictures (`resources/assets/dbr/textures/badges/dmzr/`, from its rank-assets, each cropped to
  its own ink like its generator does) and the supporter crowns (`textures/badges/dmzr_crowns/`) are DMZ Ragnarok's
  art. Badges are picked per rank in the Ranks & Kits rank editor (/rank), which is the toolkit's own.
