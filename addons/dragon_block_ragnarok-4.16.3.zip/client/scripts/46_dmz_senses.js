// =====================================================================================
//  Original lock-on camera + reticle, Ki Sense panels, the scouter HUD and the Instant
//  Transmission destination screen (client side of scripts/64_dmz_senses.js)
// =====================================================================================
//  Port of the original (GPL-3.0, see NOTICE.md): LockOnEvent (camera rotlerp 0.15, spinning lock_on.png),
//  KiSenseState/KiSenseOverlay/CombatIndicators, ScouterHUD and InstantTransmissionScreen.
//  F4 (Options > Controls, "Ki Sense"): with a scouter on, toggles the scouter's read-out;
//  otherwise cycles Ki Sense NONE -> COMBAT (panels over sensed fighters in sight) -> SEARCH (a grey world, everything
//  sensed wrapped in a coloured aura: RPG.camera.worldEffect + RPG.shaders overWorldEffects). The scouter is movable in the HUD editor.
// =====================================================================================
(function () {
    var FONT = "dmzpack:smooth";
    function num(v, d) { v = Number(v); return isNaN(v) || !isFinite(v) ? d : v; }
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function skills() { var m = RPG.getVar("dmz_skills", null); return m && typeof m === "object" ? m : {}; }
    function lvl(s) { var v = skills()[s]; return typeof v === "number" ? v : 0; }
    function hex(c) { return "#" + ("000000" + (c & 0xFFFFFF).toString(16)).slice(-6); }
    function mix(a, b, t) {
        t = clamp(t, 0, 1);
        var r = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        var g = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        var bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }
    function parseColor(s) { s = String(s || "#7FC8FF").replace("#", ""); if (s.length > 6) s = s.slice(-6); var v = parseInt(s, 16); return isNaN(v) ? 0x7FC8FF : v; }
    function byUuid(uuid, radius) {
        var found = null;
        RPG.world.entities(radius).forEach(function (e) { if (e.uuid === uuid) found = e; });
        return found;
    }

    // ============================ lock-on ============================
    var LOCK = { uuid: "", id: -1, looking: false };
    function lockTick() {
        var u = String(RPG.getVar("lock_uuid", "") || "");
        if (!u) {
            LOCK.uuid = ""; LOCK.id = -1;
            if (LOCK.looking) { RPG.camera.stopLooking(); LOCK.looking = false; }
            return;
        }
        var e = LOCK.id >= 0 ? RPG.world.entity(LOCK.id) : null;
        if (u !== LOCK.uuid || !e || e.uuid !== u) {
            LOCK.uuid = u;
            e = byUuid(u, 128);
            LOCK.id = e ? e.id : -1;
        }
        if (!e) { if (LOCK.looking) { RPG.camera.stopLooking(); LOCK.looking = false; } return; }
        // LockOnEvent.suspend: the strike cinematic camera (49c_dmz_strike_camera.js) films without the lock-on turning you
        if (typeof DMZ_STRIKE_CAM !== "undefined" && DMZ_STRIKE_CAM.filming()) { if (LOCK.looking) { RPG.camera.stopLooking(); LOCK.looking = false; } return; }
        // LockOnEvent.onRenderTick: rotlerp 0.15 toward the target's middle, faded right next to it
        var p = RPG.player, ty = e.y + e.height * 0.5;
        var dx = e.x - p.x, dz = e.z - p.z, dy = ty - p.eyeY, dist = Math.sqrt(dx * dx + dz * dz);
        var nearH = 0.6, nearV = (1.8 + e.height) * 0.5;
        var yawFollow = clamp((dist - nearH * 0.5) / 1.0, 0, 1);
        var pitchFollow = Math.max(yawFollow, clamp((Math.abs(dy) - nearV) / 1.0, 0, 1));
        if (pitchFollow <= 0.001) { if (LOCK.looking) { RPG.camera.stopLooking(); LOCK.looking = false; } return; }
        RPG.camera.lookAt(e.x, ty, e.z, 0.15 * pitchFollow);
        LOCK.looking = true;
    }
    function lockRender(ctx) {
        if (LOCK.id < 0) return;
        var e = RPG.world.entity(LOCK.id);
        if (!e) return;
        var mid = e.y + e.height * 0.5, a = RPG.project(e.x, mid, e.z), b = RPG.project(e.x, mid + 1, e.z);
        if (!a.visible) return;
        var ppb = Math.abs(a.y - b.y);
        if (!b.visible || ppb <= 0) return;
        var p = RPG.player, d = Math.sqrt(Math.pow(e.x - p.x, 2) + Math.pow(e.y - p.y, 2) + Math.pow(e.z - p.z, 2));
        var t = d > 24 ? 0 : RPG.nowMs();
        var size = 32 * 0.04 * ppb;                     // a 32-unit quad at scale 0.04
        var tex = "dmzpack:textures/gui/lock_on.png";
        ctx.push(); ctx.translate(a.x, a.y);
        ctx.push(); ctx.rotate((t % 3600) / 10); ctx.quad(tex, -size / 2, -size / 2, size, size, 0, 0, 1, 1, "#FFFFFF", 0.9); ctx.pop();
        ctx.push(); ctx.rotate(-((t % 7200) / 20)); ctx.scale(1.5, 1.5); ctx.quad(tex, -size / 2, -size / 2, size, size, 0, 0, 1, 1, "#FFFFFF", 0.5); ctx.pop();
        ctx.pop();
    }

    // ============================ Ki Sense ============================
    var KS = { mode: 0, views: {}, my: 0, search: {} };      // views: id -> {u, data, appear, track}; search: id -> {bp, ps}
    function setMode(m) {
        KS.mode = m;
        if (m !== 1) KS.views = {};
        if (m !== 2) { KS.search = {}; searchOff(); }
        else searchOn();
    }
    // KiSenseState.cycle: NONE -> COMBAT -> SEARCH -> NONE
    function cycleSense() {
        if (lvl("kisense") <= 0) return;
        setMode((KS.mode + 1) % 3);
        RPG.net.send("dmz_sense", { a: "mode", m: KS.mode });
    }
    RPG.net.on("dmz_sense_reset", function () { setMode(0); });
    RPG.net.on("dmz_sense_scan", function (d) {
        if (!d) return;
        if (!d.mode) { setMode(0); return; }
        if (d.mode === 2) { if (KS.mode === 2) searchScan(d); return; }
        if (KS.mode !== 1) return;
        KS.my = num(d.my, 0);
        var seen = {}, near = RPG.world.entities(64);
        (d.combat || []).forEach(function (o) {
            var e = null;
            near.forEach(function (x) { if (x.uuid === o.u) e = x; });
            if (!e) return;
            var v = KS.views[e.id] || (KS.views[e.id] = { id: e.id, appear: 0, track: { init: false, last: 0, dmg: 0, heal: 0, dt: 0, ht: 0, dx: 0, dy: 0, hx: 0, hy: 0, pops: [] } });
            v.data = o; v.present = true; seen[e.id] = true;
        });
        Object.keys(KS.views).forEach(function (id) { if (!seen[id]) KS.views[id].present = false; });
    });
    // CombatIndicators.tick: health changes of sensed entities
    function randX() { return (Math.random() - 0.5) * 26; }
    function randY() { return -14 - Math.random() * 12; }
    function senseTick() {
        if (KS.mode !== 1) return;
        var now = RPG.time();
        Object.keys(KS.views).forEach(function (id) {
            var v = KS.views[id], e = RPG.world.entity(Number(id)), t = v.track;
            if (e && v.present && typeof e.health === "number") {
                if (t.init) {
                    var delta = e.health - t.last;
                    if (delta < -0.05) { if (t.dmg <= 0) { t.dx = randX(); t.dy = randY(); } t.dmg += -delta; t.dt = now; t.pops.push({ v: -delta, heal: false, t: now, x: randX(), y: randY() }); }
                    else if (delta > 0.05) { if (t.heal <= 0) { t.hx = randX(); t.hy = randY(); } t.heal += delta; t.ht = now; t.pops.push({ v: delta, heal: true, t: now, x: randX(), y: randY() }); }
                }
                t.last = e.health; t.init = true;
            }
            if (now - t.dt > 40) t.dmg = 0;
            if (now - t.ht > 40) t.heal = 0;
            t.pops = t.pops.filter(function (q) { return now - q.t <= 30; });       // POPUP_LIFETIME
            if (!e || (!v.present && v.appear <= 0.01)) delete KS.views[id];
        });
    }
    // hud_default.png (512x512 texels, 2 texels per pixel)
    function spr(u, v, w, h) { return { u: u, v: v, w: w, h: h, gw: w / 2, gh: h / 2 }; }
    var SKIN = {
        hp: { frame: spr(0, 0, 256, 32), fill: spr(0, 66, 250, 26) }, hpSolo: { frame: spr(0, 256, 256, 32), fill: spr(0, 322, 250, 26) },
        ki: { frame: spr(0, 120, 256, 26), fill: spr(0, 147, 250, 20) }, stm: { frame: spr(0, 189, 256, 22), fill: spr(0, 212, 250, 16) }
    };
    var SHEET = "dmzpack:textures/gui/hud/hud_default.png", W = 125, BORDER = 1.5;
    var HP_H = 13, KI_Y = HP_H + BORDER, KI_H = 10, STM_Y = KI_Y + KI_H + BORDER, STM_H = 8;
    var PLAYER_BOTTOM = STM_Y + STM_H + BORDER, NPC_BOTTOM = HP_H + BORDER, PANEL_W = W + BORDER * 2;
    function sq(ctx, s, x, y, w, h, fx, tx, rgb, alpha) {
        if (tx <= fx || alpha <= 0.004) return;
        ctx.quad(SHEET, x + w * fx, y, w * (tx - fx), h, (s.u + s.w * fx) / 512, s.v / 512, (s.u + s.w * tx) / 512, (s.v + s.h) / 512, hex(rgb), alpha);
    }
    function bar(ctx, skin, y, h, frac, rgb, alpha, value) {
        var b = (skin.frame.gh - skin.fill.gh) / 2;
        sq(ctx, skin.frame, -b, y - b, W + 2 * b, h + 2 * b, 0, 1, 0xFFFFFF, alpha);
        sq(ctx, skin.fill, 0, y, W, h, 0, clamp(frac, 0, 1), rgb, alpha);
        ctx.textStyled(String(Math.round(value)), W - 3, y + Math.max(1.5, h / 2 - 3), 0.75 * (h >= 10 ? 1 : 0.85), "#FFFFFF", alpha, 1, FONT, "#000000");
    }
    function healthColor(f) {
        function ss(e0, e1, v) { var t = clamp((v - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); }
        return mix(mix(0xE8392F, 0xF2C230, ss(0.22, 0.38, f)), 0x35D46A, ss(0.52, 0.70, f));
    }
    function bpText(bp) { return "BP: " + String(Math.floor(bp)).replace(/\B(?=(\d{3})+(?!\d))/g, "."); }
    function accumAlpha(t) { return t <= 25 ? 1 : t >= 40 ? 0 : 1 - (t - 25) / 15; }
    function senseRender(ctx) {
        if (KS.mode !== 1) return;
        var unit = Math.max(0.25, ctx.height / 360), pad = 40 * unit, now = RPG.time() + ctx.partial, list = [];
        Object.keys(KS.views).forEach(function (id) {
            var v = KS.views[id], e = RPG.world.entity(Number(id));
            v.appear += ((v.present ? 1 : 0) - v.appear) * 0.15;
            if (!e) return;
            var topY = e.y + e.height + 0.6, a = RPG.project(e.x, topY, e.z), b = RPG.project(e.x, topY + 1, e.z);
            if (!a.visible || !b.visible) return;
            if (a.x < -pad || a.x > ctx.width + pad || a.y < -pad || a.y > ctx.height + pad) return;
            var p = RPG.player;
            list.push({ v: v, e: e, x: a.x, y: a.y, s: clamp(2.2 * Math.abs(a.y - b.y) / PANEL_W, 0.42 * unit, 0.7 * unit),
                d: Math.pow(e.x - p.x, 2) + Math.pow(e.y - p.y, 2) + Math.pow(e.z - p.z, 2) });
        });
        list.sort(function (a, b) { return b.d - a.d; });
        list.forEach(function (it) {
            var v = it.v, o = v.data || {}, e = it.e, full = !!o.pl, alpha = clamp(v.appear, 0, 1);
            var hp = num(e.health, 0), maxHp = Math.max(1, num(e.maxHealth, 1));
            ctx.push(); ctx.translate(it.x, it.y); ctx.scale(it.s, it.s); ctx.translate(-W / 2, -(full ? PLAYER_BOTTOM : NPC_BOTTOM));
            bar(ctx, full ? SKIN.hp : SKIN.hpSolo, 0, HP_H, hp / maxHp, healthColor(hp / maxHp), alpha, hp);
            if (full) {
                bar(ctx, SKIN.ki, KI_Y, KI_H, num(o.ki, 0) / Math.max(1, num(o.kiM, 1)), parseColor(o.au), alpha, num(o.ki, 0));
                bar(ctx, SKIN.stm, STM_Y, STM_H, num(o.st, 0) / Math.max(1, num(o.stM, 1)), 0xF5A623, alpha, num(o.st, 0));
            }
            ctx.textStyled(o.bp >= 2147483647 ? "BP: ???" : bpText(num(o.bp, 0)), W / 2, -BORDER - 1.5 - 9 * 0.85, 0.85, "#FFFFFF", alpha, 0.5, FONT, "#000000");
            // formatDelta: % of max health with "Adv. Desc. (Percentage)", the raw amount without
            var pctOpt = RPG.storage.get("dmz_hud_percent", true), delta = function (n) { return pctOpt ? Math.round(n / maxHp * 100) + "%" : String(Math.round(n)); };
            var t = v.track;
            if (!RPG.storage.get("dmz_cfg_accum_damage", true)) {
                // showAccumulativeDamage off: one popup per change, rising 15 and fading over 30 ticks
                t.pops.forEach(function (q) {
                    var life = clamp((now - q.t) / 30, 0, 1);
                    if (1 - life > 0.01) ctx.textStyled((q.heal ? "+" : "-") + delta(q.v), W / 2 + q.x * 1.5, -BORDER + q.y * 1.5 - life * 15, 1.25, q.heal ? "#55FF55" : "#FF5555", (1 - life) * alpha, 0.5, FONT, "#000000");
                });
                ctx.pop();
                return;
            }
            if (t.dmg > 0) ctx.textStyled("-" + delta(t.dmg), W / 2 + t.dx * 1.5, -BORDER + t.dy * 1.5, 1.25, "#FF5555", accumAlpha(now - t.dt) * alpha, 0.5, FONT, "#000000");
            if (t.heal > 0) ctx.textStyled("+" + delta(t.heal), W / 2 + t.hx * 1.5, -BORDER + t.hy * 1.5, 1.25, "#55FF55", accumAlpha(now - t.ht) * alpha, 0.5, FONT, "#000000");
            ctx.pop();
        });
    }

    // ============================ Ki Sense: SEARCH ============================
    // SearchGrayscaleManager + KiSenseAuraRenderer: the world goes fully grey (kisense_grayscale: Rec. 601 luma, no
    // tint or vignette, on and off at once) after the weather, before the hand and the HUD, and everything sensed
    // within the search range gets three camera-facing aura cards (kakarot_cross.png, the aura shader) in colour
    // over it, hidden by walls in front. The list comes from the server's scan every 100 ticks.
    var KS_FX = "dmz_kisense", KS_CHAIN = "ragnarok_rpg:shaders/post/greyscale.json", KS_DRAW = "dmz_ks_";
    var KS_TEX = "dmzpack:textures/entity/races/aura/kakarot_cross.png", KS_MESH = "dbr:kisense_quad", KS_SHADER = "dbr:aura";
    var ksMesh = false;
    function searchOn() { RPG.camera.worldEffect(KS_FX, KS_CHAIN, { Amount: 1 }); }
    function searchOff() { RPG.camera.stopWorldEffect(KS_FX); RPG.shaders.removePrefix(KS_DRAW); }
    function searchScan(d) {
        KS.my = num(d.my, 0);
        var want = {}, list = {};
        (d.search || []).forEach(function (o) { want[o.u] = o; });
        RPG.world.entities(128).forEach(function (e) { var o = want[e.uuid]; if (o && e.id !== RPG.player.id) list[e.id] = { bp: num(o.bp, 0), ps: !!o.ps }; });
        Object.keys(KS.search).forEach(function (id) { if (!list[id]) for (var i = 0; i < 3; i++) RPG.shaders.remove(KS_DRAW + id + "_" + i); });
        KS.search = list;
    }
    // KiSenseAuraRenderer.auraColors: [border, inner]
    function ksColors(ps, ratio) {
        if (ps || ratio < 0.85) return [[0.3, 0.5, 1.0], [0.55, 0.85, 1.0]];
        if (ratio > 1.15) return [[1.0, 0.25, 0.2], [1.0, 0.6, 0.2]];
        return [[1.0, 0.9, 0.4], [1.0, 1.0, 0.7]];
    }
    function searchTick() {
        if (KS.mode !== 2) return;
        if (!RPG.camera.worldEffectActive(KS_FX)) searchOn();
        if (!ksMesh) { RPG.shaders.mesh(KS_MESH, { format: "position_tex", vertices: [-1, -1, 0, 0, 1, 1, -1, 0, 1, 1, 1, 1, 0, 1, 0, -1, 1, 0, 0, 0] }); ksMesh = true; }
        var p = RPG.player, myBP = KS.my > 0 ? KS.my : 1;
        Object.keys(KS.search).forEach(function (id) {
            var o = KS.search[id], e = RPG.world.entity(Number(id));
            if (!e || (typeof e.health === "number" && e.health <= 0)) { for (var r = 0; r < 3; r++) RPG.shaders.remove(KS_DRAW + id + "_" + r); return; }
            var dist = Math.sqrt(Math.pow(e.x - p.x, 2) + Math.pow(e.y - p.y, 2) + Math.pow(e.z - p.z, 2));
            var ratio = o.bp / Math.max(1, myBP), c = ksColors(o.ps, ratio);
            var scale = (Math.max(e.width, e.height) * 0.9 + 0.6) * clamp(1 + 0.5 * Math.log(Math.max(1, ratio)) / Math.LN10, 1, 3);
            var lod = dist > 24;          // LOD_DISTANCE: far auras stand still
            var key = c[0][0] + "|" + scale.toFixed(2) + "|" + lod;
            if (o.key === key) return;    // drawn already: the engine follows the entity every frame
            o.key = key;
            [[c[0], 1, 0.9, 1], [c[1], 0.66, 0.5, 1.2], [c[1], 0.78, 0.4, 1.45]].forEach(function (L, i) {
                var k = L[0], s = scale * L[1];
                RPG.shaders.draw(KS_DRAW + id + "_" + i, { mesh: KS_MESH, shader: KS_SHADER, entity: Number(id),
                    ops: [["translate", 0, e.height * 0.5, 0], ["billboard"], ["rotateY", 180], ["scale", s, s, s]],
                    modelUniform: "modelMatrix", samplers: { Sampler0: KS_TEX }, overWorldEffects: true, order: i,
                    uniforms: { speed: lod ? 0 : { c: 0, k: { gameTime: 0.5 * L[3] } }, alp1: L[2], bloomMode: 0,
                        color1: [k[0] * 1.6, k[1] * 1.6, k[2] * 1.6, 1], color2: [k[0] * 1.3, k[1] * 1.3, k[2] * 1.3, 1],
                        color3: [k[0], k[1], k[2], 0.85], color4: [k[0] * 0.75, k[1] * 0.75, k[2] * 0.75, 0.65] } });
            });
        });
    }

    // ============================ the scouter ============================
    var SC = { on: false, data: {}, bio: false, strongest: "", strongestBp: 0, locked: "", focus: null, ids: [], idsAt: -99 };
    function scouterColor() { return String(RPG.getVar("dmz_scouter", "") || ""); }
    function setScouter(on) {
        if (on === SC.on) return;
        SC.on = on; SC.locked = "";
        RPG.sound(on ? "dmzpack:switch_on" : "dmzpack:switch_off", 0.6, 1);
        RPG.net.send("dmz_sense", { a: "scouter", on: on });
    }
    RPG.net.on("dmz_scouter_data", function (d) {
        if (!d) return;
        if (d.off) { SC.on = false; SC.data = {}; return; }
        var map = {}, best = null, cur = SC.strongest ? null : null;
        (d.list || []).forEach(function (o) { map[o.u] = o; });
        SC.data = map; SC.bio = !!d.bio;
        // performSmartScan: keep the strongest until something stronger shows up
        var alive = SC.strongest && map[SC.strongest];
        var threshold = alive ? SC.strongestBp : -1;
        Object.keys(map).forEach(function (u) { if (map[u].bp > threshold) { threshold = map[u].bp; best = u; } });
        if (best) {
            if (best !== SC.strongest) RPG.sound("dmzpack:pip_menu", 0.6, 1.2);
            SC.strongest = best; SC.strongestBp = threshold;
        } else if (!alive) { SC.strongest = ""; SC.strongestBp = 0; }
    });
    function blockedAt(x, y, z) {
        var id = String(RPG.world.getBlock(Math.floor(x), Math.floor(y), Math.floor(z)) || "minecraft:air");
        return !/(^|:)(air|cave_air|void_air|water|lava|grass|short_grass|tall_grass|fern|.*glass.*|.*_leaves|torch|.*_sapling|.*flower.*|vine)$/.test(id.split("[")[0]);
    }
    // ScouterHUD.pickTarget: the nearest entity along the view (aim tolerance 0.5) before a wall
    function scouterTick() {
        SC.focus = null;
        if (!SC.on || !scouterColor()) { if (SC.on && !scouterColor()) SC.on = false; return; }
        var p = RPG.player, now = RPG.time();
        if (now - SC.idsAt >= 10) { SC.idsAt = now; SC.ids = RPG.world.entities(50).map(function (e) { return e.id; }); }
        var l = p.look, ex = p.x, ey = p.eyeY, ez = p.z, reach = 50;
        for (var s = 0.5; s <= 50; s += 0.5) if (blockedAt(ex + l.x * s, ey + l.y * s, ez + l.z * s)) { reach = s; break; }
        var best = null, bestT = 1e9;
        SC.ids.forEach(function (id) {
            var e = RPG.world.entity(id);
            if (!e || e.uuid === undefined) return;
            var r = 0.3 + 0.5, mn = [e.x - r, e.y - 0.5, e.z - r], mx = [e.x + r, e.y + e.height + 0.5, e.z + r];
            var o = [ex, ey, ez], d = [l.x, l.y, l.z], t0 = 0, t1 = reach;
            for (var i = 0; i < 3; i++) {
                if (Math.abs(d[i]) < 1e-9) { if (o[i] < mn[i] || o[i] > mx[i]) return; continue; }
                var a = (mn[i] - o[i]) / d[i], b = (mx[i] - o[i]) / d[i];
                if (a > b) { var tmp = a; a = b; b = tmp; }
                t0 = Math.max(t0, a); t1 = Math.min(t1, b);
                if (t0 > t1) return;
            }
            if (t0 < bestT) { bestT = t0; best = e; }
        });
        if (!best) return;
        var dist = Math.sqrt(Math.pow(best.x - p.x, 2) + Math.pow(best.y - p.y, 2) + Math.pow(best.z - p.z, 2));
        SC.focus = { e: best, dist: dist };
        if (dist <= 20) {
            if (best.uuid !== SC.locked) { SC.locked = best.uuid; RPG.sound("dmzpack:lockon", 0.6, 1); }
        } else SC.locked = "";
    }
    function formatBP(bp) {
        if (bp < 10000) return String(Math.floor(bp));
        if (bp < 99950) return (bp / 1000).toFixed(1) + "k";
        if (bp < 1000000) return Math.floor(bp / 1000) + "k";
        if (bp < 99950000) return (bp / 1000000).toFixed(1) + "m";
        return Math.floor(bp / 1000000) + "m";
    }
    var GLYPH = { "0": [2, 64], "1": [6, 64], "2": [10, 64], "3": [14, 64], "4": [18, 64], "5": [2, 68], "6": [6, 68], "7": [10, 68], "8": [14, 68], "9": [18, 68], k: [22, 64], m: [22, 68], ".": [27, 64] };
    function scouterRender(ctx) {
        var color = scouterColor();
        if (!color && !ctx.isEditing()) return;
        var tex = "dmzpack:textures/gui/scouter/scouter_" + (color || "green") + ".png";
        var unit = Math.max(0.25, ctx.height / 360), s = 2 * unit, w = 70 * s, h = 41 * s;
        var x = 0, y = clamp(ctx.height * 0.5 - h * 0.5, 0, Math.max(0, ctx.height - h));
        if (!ctx.group("dmz_scouter", "Scouter", x, y, w, h)) return;
        function part(px, py, u, v, pw, ph, sc, alpha) {
            ctx.quad(tex, px, py, pw * (sc || 1), ph * (sc || 1), u / 128, v / 128, (u + pw) / 128, (v + ph) / 128, "#FFFFFF", alpha === undefined ? 1 : alpha);
        }
        ctx.push(); ctx.translate(x, y); ctx.scale(s, s);
        part(0, 0, 0, 15, 7, 41);
        part(7, 0, 7, 15, 63, 41, 1, 0.65);
        function info(extra, isPlayer) {
            part(41 - 9, 19 - 9, 2, 73, 9, 9, 2);
            if (!extra) return;
            part(49, 6, 4, 88, 12, 5);
            part(52, 9, isPlayer ? 3 : 20, 98, isPlayer ? 14 : 11, 5);
        }
        function numbers(text) {
            text = text.slice(0, 5);
            var tw = -1;
            for (var i = 0; i < text.length; i++) tw += (text[i] === "." ? 1 : 3) + 1;
            var cx = 36 - tw;
            for (var j = 0; j < text.length; j++) {
                var g = GLYPH[text[j]] || GLYPH["0"], gw = text[j] === "." ? 1 : 3;
                part(cx, 30, g[0], g[1], gw, 3);
                cx += gw + 1;
            }
        }
        function arrow(e) {
            var p = RPG.player;
            var ang = Math.atan2(e.z - p.z, e.x - p.x) * 180 / Math.PI - 90;
            var diff = -(((ang - p.yaw) % 360 + 540) % 360 - 180);
            var dir = Math.floor(((-diff % 360 + 360 + 22.5) % 360) / 45) % 8;
            var reach = 9 + 2, half = 2.5;
            if (dir === 7 || dir === 0 || dir === 1) part(41 - half, 19 - reach - 5, 26, 75, 5, 5);
            if (dir >= 1 && dir <= 3) part(41 + reach, 19 - half, 14, 75, 5, 5);
            if (dir >= 3 && dir <= 5) part(41 - half, 19 + reach, 34, 75, 5, 5);
            if (dir >= 5 && dir <= 7) part(41 - reach - 5, 19 - half, 19, 75, 5, 5);
        }
        if (ctx.isEditing() && !SC.on) { numbers(formatBP(12300)); info(true, true); }
        else if (SC.on) {
            var f = SC.focus;
            if (f && f.dist <= 20) {
                var o = SC.data[f.e.uuid];
                numbers(formatBP(o ? o.bp : 0));
                info(SC.bio, !!f.e.player);
            } else if (f && f.dist <= 50) { arrow(f.e); info(false, !!f.e.player); }
            else if (SC.strongest) {
                var st = null;
                SC.ids.forEach(function (id) { var e = RPG.world.entity(id); if (e && e.uuid === SC.strongest) st = e; });
                if (st) arrow(st);
            }
        }
        ctx.pop();
        ctx.endGroup();
    }

    // ============================ F4 ============================
    RPG.keys.register("dmz_ki_sense", { name: "Ki Sense", key: "key.keyboard.f4", category: "Dragon Block Ragnarok" });
    RPG.on("keybind", function (id, down) {
        if (id !== "dmz_ki_sense" || !down || RPG.screen.getOpen()) return;
        if (scouterColor()) setScouter(!SC.on);
        else if (lvl("kisense") > 0) cycleSense();
    });

    // ============================ Instant Transmission screen ============================
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png", ICONS = "dmzpack:textures/gui/spaceshipicons.png";
    var BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var PW = 141, PH = 213, ROW = 24, VISIBLE = 5;
    var IT = null;            // {lvl, list, players, sel, scroll}
    var PRIORITY = { MASTER: 1, PARTY: 2, EXTERNAL: 3 }, TYPE_COLOR = { MASTER: "#20E0FF", PARTY: "#FFD700", EXTERNAL: "#FFFFFF" };
    function iconIndex(dim) {
        dim = String(dim || "").replace("ragnarok_rpg:", "dragonminez:");
        switch (dim) {
            case "dragonminez:namek": return 1;
            case "dragonminez:otherworld": case "dragonminez:time_chamber": case "minecraft:the_end": return 2;
            case "dragonminez:sacredkaiplanet": return 3;
            case "dragonminez:cereal_planet": return 4;
            case "dragonminez:beerus_planet": return 5;
            case "dragonminez:demon_realm": case "minecraft:the_nether": return 6;
            default: return 0;
        }
    }
    function visible() { return IT ? IT.list.filter(function (e) { return (e.type === "MASTER") !== IT.players; }) : []; }
    function selected() { var v = visible(); return IT && IT.sel >= 0 && IT.sel < v.length ? v[IT.sel] : null; }
    function enoughKi(e) { return !!num(RPG.getVar("dmz_creative", 0), 0) || RPG.player.resource("ki") >= e.cost; }
    function geom(ctx) { var W2 = ctx ? ctx.width : 0, H2 = ctx ? ctx.height : 0; return { left: (W2 - PW) / 2, top: (H2 - PH) / 2, w: W2, h: H2 }; }
    var lastGeom = { left: 0, top: 0, w: 0, h: 0 };
    function clearSel() { IT.sel = -1; IT.scroll = 0; }
    function travel() {
        var d = selected();
        if (!d || !d.reach || !enoughKi(d)) return;
        RPG.net.send("dmz_it", { a: d.type === "MASTER" ? "master" : "player", id: d.id });
        RPG.screen.close();
        IT = null;
    }
    function del() {
        var d = selected();
        if (!d || d.type !== "MASTER") return;
        RPG.net.send("dmz_it", { a: "delete", id: d.id });
        IT.list.splice(IT.list.indexOf(d), 1);
        clearSel();
    }
    RPG.net.on("dmz_it_open", function (d) {
        if (!d) return;
        var list = (d.entries || []).slice().sort(function (a, b) {
            return (PRIORITY[a.type] - PRIORITY[b.type]) || String(a.name).toLowerCase().localeCompare(String(b.name).toLowerCase());
        });
        IT = { lvl: num(d.lvl, 0), list: list, players: false, sel: -1, scroll: 0 };
        RPG.screen.open({ id: "dmz_it", referenceHeight: DMZ_OPTS.menuRef(), background: "dim", elements: [
            { id: "travel", type: "button", x: 0, y: 0, w: 74, h: 20, texture: BUTTONS, texW: 256, texH: 256, u: 0, v: 28, uw: 74, vh: 20,
              hoverU: 0, hoverV: 48, label: RPG.translate("gui.dragonminez.travel"), font: FONT, visible: false, onClick: travel },
            { id: "delete", type: "button", x: 0, y: 0, w: 14, h: 11, texture: BUTTONS, texW: 256, texH: 256, u: 10, v: 0, uw: 10, vh: 10,
              hoverU: 10, hoverV: 10, label: "", visible: false, onClick: del }
        ], onBackground: itRender, onMouse: itMouse, onScroll: itScroll, onClose: function () { IT = null; } });
    });
    function itRender(ctx) {
        if (!IT) return;
        var g = geom(ctx); lastGeom = g;
        ctx.image(MENU_BIG, g.left, g.top, PW, PH, 0, 0, PW, PH, 256, 256);
        ctx.textStyled(RPG.translate("gui.dragonminez.transmission.title"), g.w / 2, g.top + 18, 1, "#FFD700", 1, 0.5, FONT, "#000000");
        function tab(x, y, w, label, sel) {
            ctx.fill(x, y, w, 15, sel ? "#555555" : "#000000", sel ? 0.5 : 0.25);
            if (sel) { ctx.fill(x, y, w, 1, "#FFD700", 1); ctx.fill(x, y + 14, w, 1, "#FFD700", 1); ctx.fill(x, y, 1, 15, "#FFD700", 1); ctx.fill(x + w - 1, y, 1, 15, "#FFD700", 1); }
            ctx.textStyled(label, x + w / 2, y + 4, 1, sel ? "#FFD700" : "#B0B0B0", 1, 0.5, null, null);
        }
        tab(g.left + 10, g.top + 29, 59, RPG.translate("gui.dragonminez.transmission.npcs"), !IT.players);
        if (IT.lvl >= 5) tab(g.left + 71, g.top + 29, 59, RPG.translate("gui.dragonminez.transmission.players"), IT.players);
        var list = visible(), lx = g.left + 10, ly = g.top + 49, lw = PW - 25, maxScroll = Math.max(0, list.length * ROW - VISIBLE * ROW);
        IT.scroll = clamp(IT.scroll, 0, maxScroll);
        list.forEach(function (d, i) {
            var y = ly + i * ROW - IT.scroll;
            if (y < ly - 0.01 || y + ROW > ly + VISIBLE * ROW + 0.01) return;
            var hover = ctx.mouseX >= lx && ctx.mouseX < lx + lw && ctx.mouseY >= y && ctx.mouseY < y + ROW;
            if (!d.reach) ctx.fill(lx, y, lw, ROW, "#000000", 0.19);
            else if (i === IT.sel || hover) ctx.fill(lx, y, lw, ROW, i === IT.sel ? "#D4AF37" : "#555555", 0.5);
            if (i === IT.sel) { ctx.fill(lx, y, lw, 1, "#FFD700", 1); ctx.fill(lx, y + ROW - 1, lw, 1, "#FFD700", 1); ctx.fill(lx, y, 1, ROW, "#FFD700", 1); ctx.fill(lx + lw - 1, y, 1, ROW, "#FFD700", 1); }
            var v = 3 + iconIndex(d.dim) * 14;
            ctx.quad(ICONS, lx + 5, y + (ROW - 11) / 2, 11, 11, 3 / 256, v / 256, 14 / 256, (v + 11) / 256, "#FFFFFF", 1);
            var name = String(d.name), maxW = lw - 31;
            while (name.length > 1 && ctx.textWidthIn(name, FONT) > maxW) name = name.slice(0, -1);
            if (name !== String(d.name)) name = name.slice(0, -1) + "…";
            ctx.textStyled("§l" + name, lx + 21, y + 8, 1, d.reach ? TYPE_COLOR[d.type] : "#747678", 1, 0, FONT, "#000000");
        });
        if (maxScroll > 0) {                                  // scrollbar
            var bh = Math.max(20, VISIBLE * ROW * VISIBLE * ROW / (list.length * ROW)), by = ly + (VISIBLE * ROW - bh) * IT.scroll / maxScroll;
            ctx.fill(g.left + PW - 12, ly, 3, VISIBLE * ROW, "#000000", 0.4);
            ctx.fill(g.left + PW - 12, by, 3, bh, "#D4AF37", 0.9);
        }
        var s = selected();
        if (s) ctx.textStyled(RPG.translate("gui.dragonminez.transmission.ki_required", String(s.cost)), g.w / 2, g.top + 171, 1, enoughKi(s) ? "#FFFFFF" : "#FF5555", 1, 0.5, FONT, "#000000");
        RPG.screen.update("travel", { x: g.left + (PW - 80) / 2, y: g.h - 30, visible: !!s, disabled: !(s && s.reach && enoughKi(s)) });
        RPG.screen.update("delete", { x: g.left + PW - 28, y: g.h - 25, visible: !!s && s.type === "MASTER" });
    }
    function itMouse(x, y, button, action) {
        if (!IT || action !== "down" || button !== 0) return;
        var g = lastGeom, tt = g.top + 29, tl = g.left + 10;
        if (y >= tt && y < tt + 15 && x >= tl && x < tl + 120) {
            var players = x >= tl + 60;
            if (players && IT.lvl < 5) return false;
            if (players !== IT.players) { IT.players = players; clearSel(); }
            return false;
        }
        var lx = g.left + 10, ly = g.top + 49, lw = PW - 25;
        if (x >= lx && x < lx + lw && y >= ly && y < ly + VISIBLE * ROW) {
            var i = Math.floor((y - ly + IT.scroll) / ROW), list = visible();
            if (i >= 0 && i < list.length) {
                if (!list[i].reach) return false;
                if (IT.sel !== i) { IT.sel = i; RPG.sound("dmzpack:ui_menu_switch", 1, 1); }
                return false;
            }
        }
    }
    function itScroll(x, y, delta) { if (IT) IT.scroll -= delta * ROW * 2; }

    // ============================ wiring ============================
    RPG.on("tick", function () {
        if (!RPG.player.present) return;
        lockTick();
        senseTick();
        searchTick();
        scouterTick();
    });
    RPG.on("load", function () {
        RPG.hud.onRender(function (ctx) {
            senseRender(ctx);
            lockRender(ctx);
            scouterRender(ctx);
        });
    });
})();
