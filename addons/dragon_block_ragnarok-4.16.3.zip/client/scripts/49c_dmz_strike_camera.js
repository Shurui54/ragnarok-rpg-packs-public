// =====================================================================================
//  49c_dmz_strike_camera.js - the original's strike cinematic camera (StrikeCinematicCamera)
// =====================================================================================
//  Port of the original (GPL-3.0, see NOTICE.md). When a strike connects (scripts/41s_dmz_strikes.js sends
//  "dmz_strike_cine" to the attacker and to a player victim), the view goes to third person and films the two from a
//  three-quarter angle (32 degrees off the side of the line between them), swaying 10 degrees every 7 seconds,
//  3.6 + 0.85 x their separation (+ 0.8 per block of height over 2) blocks out (3.2 - 16), 0.6 + 0.14 x that up,
//  following their middle (eased 0.1 s), turning at most 75 degrees a second (0.5 s ease) to stay on the nearer
//  three-quarter side; farther than 9 blocks apart it drifts toward you (all the way at 18). The field of view narrows
//  to 0.9. It blends in over 0.35 s from your own view and back out over 0.45 s when the strike ends (or after 600
//  ticks, or 10 ticks without the attacker). The mouse doesn't turn you while it films and the lock-on camera waits.
//  Walls: the engine's shot pulls the camera in toward the middle; a camera inside blocks cranes up 1.5 at a time.
//  The original has no option for it, so neither does this.
// =====================================================================================
var DMZ_STRIKE_CAM = (function () {
    var BLEND_IN = 0.35, BLEND_OUT = 0.45, FOCUS_TAU = 0.1, DIST_TAU = 0.3, YAW_TAU = 0.5, YAW_MAX = 75, DIST_BASE = 3.6, DIST_PER_SEP = 0.85,
        DIST_PER_HEIGHT = 0.8, DIST_MIN = 3.2, DIST_MAX = 16, HEIGHT_BASE = 0.6, HEIGHT_PER_DIST = 0.14, THREE_QUARTER = 32, SWAY = 10, SWAY_PERIOD = 7,
        AXIS_MIN = 0.35, FAR_START = 9, FAR_END = 18, CRANE_STEP = 1.5, CRANE_STEPS = 4, CRANE_UP_TAU = 0.12, CRANE_DOWN_TAU = 0.6, LOOK_TAU = 0.06,
        PITCH_LIMIT = 80, FOV = 0.9, MAX_FILMING = 600, MISSING = 10, FIRST_PULLBACK = 0.6;
    var phase = "idle", att = -1, vic = -1, prev = null, t0 = 0, last = 0, filming = 0, missing = 0, framed = false, orbit = 0, film = 0,
        focus = null, dist = DIST_BASE, crane = 0, lookYaw = 0, lookPitch = 0, origin = null, shown = null, cine = null, locked = false;
    function nowS() { return RPG.nowMs() / 1000; }
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function wrap(d) { d = d % 360; if (d >= 180) d -= 360; if (d < -180) d += 360; return d; }
    function ease(dt, tau) { return 1 - Math.exp(-dt / tau); }
    function smoothstep(x) { var t = clamp(x, 0, 1); return t * t * (3 - 2 * t); }
    function body(e) { return { x: e.x, y: e.y + e.height * 0.5, z: e.z }; }
    function solid(x, y, z) { var b = RPG.world.getBlock(Math.floor(x), Math.floor(y), Math.floor(z)); return b && b !== "minecraft:air" && b !== "minecraft:cave_air" && b !== "minecraft:void_air"; }
    function natural() {                                       // where your own camera would be
        var p = RPG.player, lk = p.look, back = prev === "first" ? FIRST_PULLBACK : 4;
        return { x: p.x - lk.x * back, y: p.eyeY - lk.y * back, z: p.z - lk.z * back, yaw: p.yaw, pitch: p.pitch };
    }
    function start(a, v) {
        if (!RPG.player.present) return;
        if (phase === "idle") { prev = RPG.camera.currentMode(); origin = natural(); }
        else origin = shown;
        RPG.camera.mode("third");
        if (!locked) { try { RPG.camera.lockRotation(true); locked = true; } catch (e) { } }
        RPG.camera.fov(FOV, 4);
        att = a; vic = v; phase = "film"; t0 = nowS(); filming = 0; missing = 0; framed = false; film = 0; focus = null; cine = null;
    }
    function release() {
        if (phase !== "film") return;
        phase = "release"; t0 = nowS();
        if (locked) { try { RPG.camera.lockRotation(false); } catch (e) { } locked = false; }
        RPG.camera.fov(1, 4);
    }
    function finish() {
        phase = "idle"; att = -1; vic = -1; focus = null; origin = null; shown = null; cine = null;
        try { RPG.camera.clearShot(); } catch (e) { }
        if (prev) RPG.camera.mode(prev);
        prev = null;
    }
    RPG.net.on("dmz_strike_cine", function (d) {
        if (!d) return;
        if (d.on) start(Number(d.a), Number(d.v));
        else if (phase === "film" && Number(d.a) === att) release();
    });
    RPG.on("tick", function () {
        if (phase === "idle") return;
        if (!RPG.player.present) { finish(); return; }
        if (phase === "film") {
            filming++;
            missing = RPG.world.entity(att) ? 0 : missing + 1;
            if (filming > MAX_FILMING || missing > MISSING) release();
            else if (RPG.camera.currentMode() !== "third") RPG.camera.mode("third");
        } else if (nowS() - t0 >= BLEND_OUT) finish();
    });
    RPG.on("unload", function () { if (phase !== "idle") { if (locked) try { RPG.camera.lockRotation(false); } catch (e) { } locked = false; finish(); } });

    function threeQuarter(fx, fz, side) {
        var tilt = THREE_QUARTER * Math.PI / 180;
        var x = -fz * side * Math.cos(tilt) - fx * Math.sin(tilt), z = fx * side * Math.cos(tilt) - fz * Math.sin(tilt);
        return Math.atan2(z, x);
    }
    function nearest(fx, fz, cur) {
        var a = threeQuarter(fx, fz, 1), b = threeQuarter(fx, fz, -1);
        return Math.abs(wrap((a - cur) * 180 / Math.PI)) <= Math.abs(wrap((b - cur) * 180 / Math.PI)) ? a : b;
    }
    function openSide(fx, fz, cur, wanted) {               // pickOpeningSide: the clearer side, else the smaller turn
        var a = threeQuarter(fx, fz, 1), b = threeQuarter(fx, fz, -1);
        function free(ang) {
            var n = 0;
            for (var k = 1; k <= 4; k++) { var r = wanted * k / 4; if (!solid(focus.x + Math.cos(ang) * r, focus.y + (HEIGHT_BASE + HEIGHT_PER_DIST * wanted) * k / 4, focus.z + Math.sin(ang) * r)) n++; else break; }
            return n / 4;
        }
        var fa = free(a), fb = free(b);
        if (Math.abs(fa - fb) > 0.1) return fa > fb ? a : b;
        return nearest(fx, fz, cur);
    }
    function shoot(dt, nat) {
        var a = RPG.world.entity(att), v = vic >= 0 ? RPG.world.entity(vic) : null;
        if (!a && !v) return null;
        var ap = a ? body(a) : body(v), vp = v ? body(v) : ap, tallest = Math.max(a ? a.height : 0, v ? v.height : 0);
        var ax = vp.x - ap.x, ay = vp.y - ap.y, az = vp.z - ap.z, sep = Math.sqrt(ax * ax + ay * ay + az * az), flat = Math.sqrt(ax * ax + az * az);
        var far = clamp((sep - FAR_START) / (FAR_END - FAR_START), 0, 1), me = RPG.player;
        var mid = { x: (ap.x + vp.x) / 2, y: (ap.y + vp.y) / 2, z: (ap.z + vp.z) / 2 }, mine = { x: me.x, y: me.y + 0.9, z: me.z };
        var target = { x: mid.x + (mine.x - mid.x) * far, y: mid.y + (mine.y - mid.y) * far, z: mid.z + (mine.z - mid.z) * far };
        if (!focus) focus = target;
        else { var k = ease(dt, FOCUS_TAU); focus = { x: focus.x + (target.x - focus.x) * k, y: focus.y + (target.y - focus.y) * k, z: focus.z + (target.z - focus.z) * k }; }
        var wanted = clamp(DIST_BASE + DIST_PER_SEP * Math.min(sep, FAR_START) * (1 - far) + DIST_PER_HEIGHT * Math.max(0, tallest - 2), DIST_MIN, DIST_MAX);
        var opening = !framed;
        if (!framed) {
            var fx0 = nat.x - focus.x, fz0 = nat.z - focus.z, cur = fx0 * fx0 + fz0 * fz0 > 1e-4 ? Math.atan2(fz0, fx0) : 0, fx, fz;
            if (flat > AXIS_MIN) { fx = ax / flat; fz = az / flat; }
            else { var y = (a ? a.yaw : me.yaw) * Math.PI / 180; fx = -Math.sin(y); fz = Math.cos(y); }
            orbit = openSide(fx, fz, cur, wanted); dist = wanted; crane = 0; framed = true;
        } else {
            film += dt;
            if (flat > AXIS_MIN) {
                var desired = nearest(ax / flat, az / flat, orbit), delta = wrap((desired - orbit) * 180 / Math.PI), cap = YAW_MAX * dt;
                orbit += clamp(delta * ease(dt, YAW_TAU), -cap, cap) * Math.PI / 180;
            }
            dist += (wanted - dist) * ease(dt, DIST_TAU);
        }
        var ang = orbit + SWAY * Math.PI / 180 * Math.sin(film * Math.PI * 2 / SWAY_PERIOD);
        var gx = focus.x + Math.cos(ang) * dist, gy = focus.y + HEIGHT_BASE + HEIGHT_PER_DIST * dist, gz = focus.z + Math.sin(ang) * dist;
        var lift = 0;
        for (var s = 0; s <= CRANE_STEPS; s++) { lift = s * CRANE_STEP; if (!solid(gx, gy + lift, gz) && !solid(gx, gy + lift + 0.5, gz)) break; }
        crane += (lift - crane) * ease(dt, lift > crane ? CRANE_UP_TAU : CRANE_DOWN_TAU);
        var cx = gx, cy = gy + crane, cz = gz;
        var lx = focus.x - cx, ly = focus.y - cy, lz = focus.z - cz, hor = Math.sqrt(lx * lx + lz * lz);
        var yaw = Math.atan2(lz, lx) * 180 / Math.PI - 90, pitch = clamp(-Math.atan2(ly, hor) * 180 / Math.PI, -PITCH_LIMIT, PITCH_LIMIT);
        if (opening) { lookYaw = yaw; lookPitch = pitch; }
        else { var turn = ease(dt, LOOK_TAU); lookYaw += wrap(yaw - lookYaw) * turn; lookPitch += (pitch - lookPitch) * turn; }
        return { x: cx, y: cy, z: cz, yaw: lookYaw, pitch: lookPitch };
    }
    function blend(from, to, w) {
        if (w <= 0) return from;
        if (w >= 1) return to;
        var p = { x: from.x + (to.x - from.x) * w, y: from.y + (to.y - from.y) * w, z: from.z + (to.z - from.z) * w };
        if (focus) {                                          // swing round the focus instead of cutting across it
            var ax = from.x - focus.x, az = from.z - focus.z, bx = to.x - focus.x, bz = to.z - focus.z, ra = Math.sqrt(ax * ax + az * az), rb = Math.sqrt(bx * bx + bz * bz);
            if (ra > 0.5 && rb > 0.5) {
                var a0 = Math.atan2(az, ax), turn = wrap((Math.atan2(bz, bx) - a0) * 180 / Math.PI) * Math.PI / 180, an = a0 + turn * w, r = ra + (rb - ra) * w;
                p = { x: focus.x + Math.cos(an) * r, y: p.y, z: focus.z + Math.sin(an) * r };
            }
        }
        return { x: p.x, y: p.y, z: p.z, yaw: from.yaw + wrap(to.yaw - from.yaw) * w, pitch: from.pitch + (to.pitch - from.pitch) * w };
    }
    RPG.hud.onRender(function () {
        if (phase === "idle") return;
        var t = nowS(), dt = last ? clamp(t - last, 0, 0.1) : 0;
        last = t;
        var nat = natural(), c = shoot(dt, nat);
        if (c) cine = c; else c = cine || nat;
        var out = phase === "film" ? blend(origin || nat, c, smoothstep((t - t0) / BLEND_IN)) : blend(c, nat, smoothstep((t - t0) / BLEND_OUT));
        shown = out;
        var yr = out.yaw * Math.PI / 180, pr = out.pitch * Math.PI / 180;
        var lx = -Math.sin(yr) * Math.cos(pr), ly = -Math.sin(pr), lz = Math.cos(yr) * Math.cos(pr);
        var fd = focus ? Math.max(1, Math.sqrt(Math.pow(focus.x - out.x, 2) + Math.pow(focus.y - out.y, 2) + Math.pow(focus.z - out.z, 2))) : 4;
        RPG.camera.shot(out.x, out.y, out.z, out.x + lx * fd, out.y + ly * fd, out.z + lz * fd);
    });
    return { filming: function () { return phase === "film"; }, active: function () { return phase !== "idle"; } };
})();
