// =====================================================================================
//  51v_dmz_volleys.js - draws the volleys the server simulates (scripts/41v_dmz_volleys.js, "dmz_vol")
// =====================================================================================
//  Port of the original (GPL-3.0, see NOTICE.md): KiProjectileRenderer for the small ki blast (render type 0:
//  the charging-orb look, 0.4 across with its fire inside) and its KiTrailRenderer streak, used by Assault Rain,
//  Blaster Meteor and the Hellzone Grenade's orbs; their explosions (KI_EXPLOSION + KiExplosionVisualEntity),
//  the Hellzone finale's chained bursts and the ShockwaveVfx rings. Everything here runs on this computer only:
//  straight shots move on their own between messages, the Hellzone orbs follow the positions the server sends.
// =====================================================================================
(function () {
    var R = typeof DMZ_KI_RENDER !== "undefined" ? DMZ_KI_RENDER : null;
    var SHOTS = {}, ORBS = {}, RN = 0;
    var BALL_R = 0.4, TRAIL_LEN = 5.5 * 0.8, TRAIL_W = 0.19 * 0.8;

    function ok() { return R && RPG.player.present && R.setup(); }
    function cols(a, b, c) { return [R.rgb(a), R.rgb(b), R.rgb(c)]; }
    function angles(dx, dy, dz) {
        var l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
        return { yaw: Math.atan2(-dx / l, dz / l) * 180 / Math.PI, pitch: -Math.asin(Math.max(-1, Math.min(1, dy / l))) * 180 / Math.PI };
    }
    function drawBall(id, x, y, z, col, r, life) {
        RPG.shaders.draw(id, { mesh: R.MESH.sphere, shader: R.SH, x: x, y: y, z: z, ops: [["scale", r]],
            uniforms: R.uni(col, { blotchMode: 1, flameMode: 1, orbMode: 1 }), bloom: { bloomMode: 1 }, cull: false, depthWrite: false, ticks: life, order: 20 });
    }
    // the streak behind a shot (KiTrailRenderer: 5.5 x the size long, 0.38 x wide): a ki-shaded tube pointing back
    function trailOps(dx, dy, dz, len) {
        var a = angles(-dx, -dy, -dz);
        return [["rotateY", -a.yaw], ["rotateX", a.pitch], ["scale", TRAIL_W, TRAIL_W, Math.max(0.05, len)]];
    }
    function drawTrail(id, s, len) {
        RPG.shaders.draw(id, { mesh: R.MESH.tube, shader: R.SH, x: s.x, y: s.y, z: s.z, ops: trailOps(s.vx, s.vy, s.vz, len),
            uniforms: R.uni(s.col, { alphaMult: 0.85 }), bloom: { bloomMode: 1 }, cull: false, depthWrite: false, ticks: s.life + 2, order: 19 });
    }
    function addShot(key, e, off) {
        var s = { x: e[off], y: e[off + 1], z: e[off + 2], vx: e[off + 3], vy: e[off + 4], vz: e[off + 5], life: e[off + 6], age: 0,
            col: cols(e[off + 7], e[off + 8], e[off + 9]), hex: [e[off + 7], e[off + 8], e[off + 9]] };
        s.speed = Math.sqrt(s.vx * s.vx + s.vy * s.vy + s.vz * s.vz);
        SHOTS[key] = s;
        drawBall("dmzv_" + key, s.x, s.y, s.z, s.col, BALL_R, s.life + 2);
        drawTrail("dmzv_" + key + "t", s, 0.05);
    }
    function removeShot(key) {
        if (!SHOTS[key]) return null;
        var s = SHOTS[key];
        delete SHOTS[key];
        RPG.shaders.remove("dmzv_" + key); RPG.shaders.remove("dmzv_" + key + "t");
        return s;
    }
    function fx(x, y, z, v, p, sz, c) { try { R.kiFx({ x: x, y: y, z: z, v: v, p: p, s: sz, c: c }); } catch (e) { } }
    function shock(x, y, z, size, color, life) {
        if (typeof DMZ_STRIKE_FX !== "undefined") DMZ_STRIKE_FX.play({ t: "shock", x: x, y: y, z: z, s: size, c: color, life: life });
    }

    RPG.net.on("dmz_vol", function (d) {
        if (!d || !d.e || !ok()) return;
        for (var i = 0; i < d.e.length; i++) {
            var e = d.e[i], k = e[0];
            try {
                if (k === "s") addShot(e[1], e, 2);
                else if (k === "r") addShot("r" + (RN++), e, 1);
                else if (k === "x") {                            // a small blast's explosion: visual 0.2, KI_EXPLOSION 4.5
                    var s = removeShot(e[1]);
                    fx(e[2], e[3], e[4], 0.4, 4.5, 0, s ? s.hex : null);
                } else if (k === "d") removeShot(e[1]);
                else if (k === "k") fx(e[1], e[2], e[3], e[4], e[5], e[6], [e[7], e[8], e[9]]);
                else if (k === "w") shock(e[1], e[2], e[3], e[4], e[5], e[6]);
                else if (k === "b") { for (var j = 0; j + 3 < e[1].length; j += 4) fx(e[1][j], e[1][j + 1], e[1][j + 2], 0, e[1][j + 3], 0, null); }
                else if (k === "h") hellzone(e);
                else if (k === "o") { orbGone(e[1], e[2]); fx(e[3], e[4], e[5], 0, e[6], 0, null); }
                else if (k === "q") orbGone(e[1], e[2]);
                else if (k === "c") hellzoneGone(e[1]);
            } catch (err) { }
        }
    });

    // ---- the Hellzone Grenade's orbs: drawn where the server says, streak along their motion ----
    function hellzone(e) {
        var id = e[1], sz = e[2], col = cols(e[3], e[4], e[5]), list = e[6], H = ORBS[id] || (ORBS[id] = {});
        for (var i = 0; i + 3 < list.length; i += 4) {
            var n = list[i], x = list[i + 1], y = list[i + 2], z = list[i + 3], o = H[n], key = "dmzh_" + id + "_" + n;
            if (!o) {
                o = H[n] = { x: x, y: y, z: z, vx: 0, vy: 0, vz: 0, seen: 0 };
                drawBall(key, x, y, z, col, sz * 0.5, 200);
                RPG.shaders.draw(key + "t", { mesh: R.MESH.tube, shader: R.SH, x: x, y: y, z: z, ops: [["scale", 0.01]], uniforms: R.uni(col, { alphaMult: 0.85 }),
                    bloom: { bloomMode: 1 }, cull: false, depthWrite: false, ticks: 200, order: 19 });
            } else {
                o.vx = x - o.x; o.vy = y - o.y; o.vz = z - o.z; o.x = x; o.y = y; o.z = z;
                RPG.shaders.update(key, { x: x, y: y, z: z });
                var sp = Math.sqrt(o.vx * o.vx + o.vy * o.vy + o.vz * o.vz);
                var wd = 0.19 * sz;
                if (sp > 0.05) {
                    var a = angles(-o.vx, -o.vy, -o.vz);
                    RPG.shaders.update(key + "t", { x: x, y: y, z: z, ops: [["rotateY", -a.yaw], ["rotateX", a.pitch], ["scale", wd, wd, Math.min(5.5 * sz, sp * 3)]] });
                } else RPG.shaders.update(key + "t", { x: x, y: y, z: z, ops: [["scale", 0.01]] });
            }
            o.seen = 0;
        }
    }
    function orbGone(id, n) {
        var H = ORBS[id];
        if (!H || !H[n]) return;
        delete H[n];
        RPG.shaders.remove("dmzh_" + id + "_" + n); RPG.shaders.remove("dmzh_" + id + "_" + n + "t");
    }
    function hellzoneGone(id) {
        if (!ORBS[id]) return;
        delete ORBS[id];
        RPG.shaders.removePrefix("dmzh_" + id + "_");
    }

    // ---- every tick: straight shots move on (their draws ease between positions), streaks grow to full length ----
    RPG.every(1, function () {
        if (!R) return;
        for (var key in SHOTS) {
            var s = SHOTS[key];
            if (++s.age > s.life + 2) { removeShot(key); continue; }
            s.x += s.vx; s.y += s.vy; s.z += s.vz;
            RPG.shaders.update("dmzv_" + key, { x: s.x, y: s.y, z: s.z });
            RPG.shaders.update("dmzv_" + key + "t", { x: s.x, y: s.y, z: s.z, ops: trailOps(s.vx, s.vy, s.vz, Math.min(TRAIL_LEN, s.age * s.speed)) });
        }
        for (var id in ORBS) {                               // a stream that stopped coming (out of range): forget it
            var H = ORBS[id];
            for (var n in H) if (++H[n].seen > 40) orbGone(id, n);
        }
    });
})();
