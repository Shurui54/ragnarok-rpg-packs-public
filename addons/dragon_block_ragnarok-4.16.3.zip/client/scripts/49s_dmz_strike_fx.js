// =====================================================================================
//  49s_dmz_strike_fx.js - what the original's strikes draw (scripts/41s_dmz_strikes.js sends "dmz_strike_fx")
// =====================================================================================
//  shock  ShockwaveVfx: a ring that swells and fades, turned to the camera (flat on the ground with flat: 1)
//  burst  ImpactBurstVfx: spikes thrown out from the impact, two colours
//  claw   ClawSlashVfx: the wolf fang's blue claw marks (n of them; big = the final one)
//  trail  the super god fist's golden streak       dragon  the dragon fist's golden dragon head
//  beam   a short Kamehameha (kaioken attack, oozaru fist)   whirl   the blue hurricane
//  slash  SwordSlashEffect: a crescent flying straight with three fading ghosts (shining sword, dimensional slash,
//         the combos' arcs)
//  orb / orbx    a held ki ball (KiBlastEntity, render type 1) kept by id and moved by the server (meteor burst, android)
//  laser / laserx  KiLaserEntity strikes (the darkness eye beam's two eye lasers)
//  blade / bladex  KiBladeExtendS2C: the beam sword slash's ki blade, stretched to `reach` from the shoulder
//  mball  the mystic ball's pink trail (DMZPlayerRenderer.submitMysticBallTrail)
//  after  AfterimageVfx (zanzoken): a puff and a fading streak where the body was
//  kb     KiBurstVfx: the screen shakes near the striker (KiBurstShakeState)
//  rocks / dust  MainParticles ROCK / DUST spread round a point     sparks  the clash's coloured sparks
//  boom   KiExplosionVisualEntity      ring  BossTelegraphS2C (the dimensional punch's mark)
//  dfist  DimensionalFistEffect: a portal opens and a fist punches through it     wave  the shining sword's ki wave
//  scream RageScreamVfx (the darkness eye beam's roar)
// =====================================================================================
var DMZ_STRIKE_FX = (function () {
    var FX = {}, N = 0;
    function basis() {                                       // camera-facing right / up from your view
        var y = RPG.player.yaw * Math.PI / 180, p = RPG.player.pitch * Math.PI / 180;
        var f = { x: -Math.sin(y) * Math.cos(p), y: -Math.sin(p), z: Math.cos(y) * Math.cos(p) };
        var r = { x: Math.cos(y), y: 0, z: Math.sin(y) };
        var u = { x: r.y * f.z - r.z * f.y, y: r.z * f.x - r.x * f.z, z: r.x * f.y - r.y * f.x };
        return { r: r, u: u };
    }
    function ring(tri, al, c, b, r0, r1, a0, a1, flat) {
        var seg = 32;
        for (var i = 0; i < seg; i++) {
            var t0 = i / seg * Math.PI * 2, t1 = (i + 1) / seg * Math.PI * 2;
            function pt(t, rr) {
                var cs = Math.cos(t) * rr, sn = Math.sin(t) * rr;
                if (flat) return [c.x + cs, c.y, c.z + sn];
                return [c.x + b.r.x * cs + b.u.x * sn, c.y + b.r.y * cs + b.u.y * sn, c.z + b.r.z * cs + b.u.z * sn];
            }
            var a = pt(t0, r0), bb = pt(t0, r1), cc = pt(t1, r1), d = pt(t1, r0);
            tri.push(a[0], a[1], a[2], bb[0], bb[1], bb[2], cc[0], cc[1], cc[2]); al.push(a0, a1, a1);
            tri.push(a[0], a[1], a[2], cc[0], cc[1], cc[2], d[0], d[1], d[2]); al.push(a0, a1, a0);
        }
    }
    function draw(id, f) {
        var p = Math.min(1, f.age / f.life);
        if (f.t === "shock") {
            var r = f.s * 0.5 * (1 - Math.pow(1 - p, 2)), w = Math.max(0.08, f.s * 0.12 * (1 - p)), a = (1 - p) * 0.85, tri = [], al = [], b = basis();
            ring(tri, al, f, b, Math.max(0, r - w), r, 0, a, f.flat);
            ring(tri, al, f, b, r, r + w * 0.6, a, 0, f.flat);
            RPG.world3d.mesh(id, { triangles: tri, alphas: al, color: f.c, alpha: 1, blend: "additive" });
        } else if (f.t === "burst") {
            var tri2 = [], al2 = [], b2 = basis(), len = f.s * 0.5 * (0.35 + 0.65 * p), a2 = (1 - p);
            for (var i = 0; i < 10; i++) {
                var ang = (i / 10) * Math.PI * 2 + f.seed, cs = Math.cos(ang), sn = Math.sin(ang), wd = 0.12 * f.s * (1 - p);
                var dx = b2.r.x * cs + b2.u.x * sn, dy = b2.r.y * cs + b2.u.y * sn, dz = b2.r.z * cs + b2.u.z * sn;
                var px = -b2.r.x * sn + b2.u.x * cs, py = -b2.r.y * sn + b2.u.y * cs, pz = -b2.r.z * sn + b2.u.z * cs;
                var l = len * (0.7 + 0.3 * ((i * 7) % 3) / 2), s0 = len * 0.25;
                tri2.push(f.x + dx * s0 - px * wd, f.y + dy * s0 - py * wd, f.z + dz * s0 - pz * wd, f.x + dx * s0 + px * wd, f.y + dy * s0 + py * wd, f.z + dz * s0 + pz * wd,
                    f.x + dx * l, f.y + dy * l, f.z + dz * l);
                al2.push(a2, a2, 0);
            }
            RPG.world3d.mesh(id, { triangles: tri2, alphas: al2, color: i % 2 ? f.c2 : f.c, alpha: 1, blend: "additive" });
            RPG.world3d.billboard(id + "_c", { x: f.x, y: f.y, z: f.z, size: f.s * 0.35 * (1 - p * 0.5), color: f.c2 || f.c, alpha: a2 * 0.8, blend: "additive" });
        } else if (f.t === "claw") {
            var yaw = (f.yaw || 0) * Math.PI / 180, rx = Math.cos(yaw), rz = Math.sin(yaw), paths = [];
            for (var k = 0; k < f.n; k++) {
                var off = (k - (f.n - 1) / 2) * 0.22 * f.s / 1.7, pts = [], wid = [];
                var tilt = f.big ? (k % 2 ? 0.6 : -0.6) : 0.5;
                for (var j = 0; j <= 6; j++) {
                    var q = j / 6 - 0.5, h = q * f.s * 0.8, side = (q * tilt + off) * f.s * 0.6, bow = Math.cos(q * Math.PI) * 0.15 * f.s;
                    pts.push(f.x + rx * side - Math.sin(yaw + Math.PI) * bow * 0, f.y + h, f.z + rz * side);
                    wid.push(Math.sin((j / 6) * Math.PI) * 0.06 * f.s * (1 - p));
                }
                paths.push({ points: pts, widths: wid, alpha: 1 - p });
            }
            RPG.world3d.bolt(id, { paths: paths, color: f.c, alpha: 1 });
        } else if (f.t === "beam") {
            var wb = f.w * (p < 0.2 ? p / 0.2 : 1 - (p - 0.2) / 0.8 * 0.6);
            RPG.world3d.line(id + "o", { from: f.a, to: f.b, width: wb, color: f.c, alpha: 0.6 * (1 - p), blend: "additive" });
            RPG.world3d.line(id, { from: f.a, to: f.b, width: wb * 0.45, color: "#FFFFFF", alpha: 1 - p, blend: "additive" });
        } else if (f.t === "trail" || f.t === "dragon" || f.t === "whirl") {
            var sz = f.t === "dragon" ? 2.2 : f.t === "whirl" ? 3 : 1.1;
            RPG.world3d.billboard(id, { x: f.x, y: f.y + (f.t === "whirl" ? 1.5 : 0), z: f.z, size: sz * (1 - p * 0.6), color: f.c, alpha: (1 - p) * 0.8, blend: "additive",
                roll: f.t === "whirl" ? f.age * 40 : 0 });
            if (f.t === "dragon") RPG.world3d.billboard(id + "_g", { x: f.x, y: f.y, z: f.z, size: sz * 1.8 * (1 - p * 0.6), color: f.c2, alpha: (1 - p) * 0.45, blend: "additive" });
        }
    }
    function life(t) { return t === "trail" ? 6 : t === "dragon" ? 4 : t === "whirl" ? 3 : 10; }
    var EXTRA = { slash: 1, orb: 1, orbx: 1, laser: 1, laserx: 1, blade: 1, bladex: 1, mball: 1, after: 1, kb: 1, rocks: 1, dust: 1, sparks: 1, boom: 1,
        ring: 1, dfist: 1, wave: 1, scream: 1 };
    RPG.net.on("dmz_strike_fx", function (d) { play(d); });
    function play(d) {
        if (!d || !d.t) return;
        if (EXTRA[d.t]) { try { DMZ_STRIKE_FX2.play(d); } catch (e) { } return; }
        var id = "dmzsfx" + (N++) + ":";
        d.age = 0; d.life = Math.max(1, Number(d.life) || life(d.t)); d.seed = Math.random() * 6.28;
        FX[id] = d;
        if (d.t === "dragon") RPG.particle("minecraft:flame", d.x, d.y, d.z, 3, 0.4, 0.02);
        if (d.t === "whirl") RPG.particle("minecraft:cloud", d.x, d.y + 1, d.z, 3, 0.8, 0.05);
        draw(id, d);
    }
    RPG.on("tick", function () {
        for (var id in FX) {
            var f = FX[id];
            if (++f.age >= f.life) { RPG.world3d.removePrefix(id); delete FX[id]; continue; }
            draw(id, f);
        }
    });
    return { play: play };
})();
