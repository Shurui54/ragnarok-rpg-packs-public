// =====================================================================================
//  Crates - place a crate (/crate place <type>), hand out keys (/crate give <player> <type>),
//  right-click with a key to spin. Without a key, right-click shows what's inside.
//  Rewards: { item: stack or id, weight, name? } or { command: "give {player} ...", weight, name, icon }.
// =====================================================================================
(function () {
    var CRATES = {
        common: { name: "&fCommon Crate", color: "&f", rewards: [
            { item: { id: "minecraft:iron_ingot", count: 16 }, weight: 30 },
            { item: { id: "minecraft:gold_ingot", count: 8 }, weight: 20 },
            { item: { id: "minecraft:cooked_beef", count: 32 }, weight: 25 },
            { item: { id: "minecraft:experience_bottle", count: 8 }, weight: 15 },
            { item: { id: "minecraft:diamond", count: 2 }, weight: 8 },
            { item: { id: "minecraft:golden_apple", count: 1 }, weight: 2 }
        ] },
        rare: { name: "&bRare Crate", color: "&b", rewards: [
            { item: { id: "minecraft:diamond", count: 5 }, weight: 30 },
            { item: { id: "minecraft:emerald", count: 16 }, weight: 25 },
            { item: { id: "minecraft:diamond_pickaxe", name: "&bRare Pick", nbt: "{Enchantments:[{id:\"minecraft:efficiency\",lvl:4s},{id:\"minecraft:unbreaking\",lvl:3s}]}" }, weight: 15 },
            { item: { id: "minecraft:enchanted_golden_apple", count: 1 }, weight: 5 },
            { command: "eco give {player} 1000", name: "&a$1000", icon: "minecraft:gold_block", weight: 15 },
            { item: { id: "minecraft:totem_of_undying", count: 1 }, weight: 10 }
        ] },
        legendary: { name: "&6Legendary Crate", color: "&6", rewards: [
            { item: { id: "minecraft:netherite_ingot", count: 2 }, weight: 30 },
            { item: { id: "minecraft:elytra", count: 1 }, weight: 10 },
            { item: { id: "minecraft:diamond_sword", name: "&6Legendary Blade", nbt: "{Enchantments:[{id:\"minecraft:sharpness\",lvl:5s},{id:\"minecraft:fire_aspect\",lvl:2s},{id:\"minecraft:looting\",lvl:3s}]}" }, weight: 20 },
            { item: { id: "minecraft:beacon", count: 1 }, weight: 10 },
            { command: "eco give {player} 10000", name: "&a$10,000", icon: "minecraft:emerald_block", weight: 30 }
        ] }
    };
    RPG.perms.group("admin", ["crates.*"]);

    var KEY = "ragnarok_rpg:" + RPG.items.define("crate_key", { name: "&eCrate Key", model: "crates:rpg/item/crate_key", maxStack: 64 });
    var CRATE_BLOCK = "ragnarok_rpg:" + RPG.blocks.define("crate", {
        name: "&6Crate", model: "crates:rpg/block/crate", hardness: -1, drops: "none",
        onUse(player, x, y, z) { use(player, player.dimension, x, y, z); }
    });

    function posKey(d, x, y, z) { return "crate:" + d + ":" + x + ":" + y + ":" + z; }
    function keyStack(type, n) { let c = CRATES[type]; return { id: KEY, count: n, name: c.color + c.name.replace(/&./g, "") + " Key", lore: ["&7Right-click a " + c.name + "&7 to open"], data: { crate: type } }; }
    function rewardIcon(r) { return r.item ? (typeof r.item === "string" ? { id: r.item } : r.item) : { id: r.icon || "minecraft:paper", name: r.name }; }
    function total(c) { let t = 0; c.rewards.forEach((r) => t += r.weight); return t; }
    function pick(c) { let r = Math.random() * total(c); for (let i = 0; i < c.rewards.length; i++) { r -= c.rewards[i].weight; if (r <= 0) return c.rewards[i]; } return c.rewards[0]; }

    function use(p, d, x, y, z) {
        let type = RPG.data.get(posKey(d, x, y, z));
        let c = CRATES[type];
        if (!c) { p.tell("&7This crate isn't set up. An admin can /crate place <type>."); return; }
        let held = p.getHeldStack();
        if (held && held.id === KEY && held.data && held.data.crate === type) {
            held.count -= 1;
            p.setHeldStack(held.count > 0 ? held : null);
            spin(p, type);
        } else preview(p, type);
    }

    function preview(p, type) {
        let c = CRATES[type], t = total(c);
        RPG.ui.container(p, {
            title: c.name + " &8(you need a key)", rows: Math.max(1, Math.ceil(c.rewards.length / 9)), mode: "menu",
            items: c.rewards.map((r) => {
                let icon = JSON.parse(JSON.stringify(rewardIcon(r)));
                icon.lore = ["&7Chance: &f" + (Math.round(r.weight / t * 1000) / 10) + "%"];
                return icon;
            })
        });
    }

    // the reel spins past random rewards, slows down, and stops on the prize in the middle
    function spin(p, type) {
        let c = CRATES[type], prize = pick(c), reel = [];
        for (let i = 0; i < 40; i++) reel.push(rewardIcon(pick(c)));
        reel[34] = rewardIcon(prize);      // lands in the centre slot (column 4) after 30 steps
        let glass = { id: "minecraft:gray_stained_glass_pane", name: " " }, marker = { id: "minecraft:lime_stained_glass_pane", name: "&a▼" };
        let items = [];
        for (let i = 0; i < 27; i++) items.push(glass);
        items[4] = marker; items[22] = marker;
        let gui = RPG.ui.container(p, { title: c.name, rows: 3, mode: "menu", items: items });
        let step = 0, finished = false;
        function draw() { for (let col = 0; col < 9; col++) gui.set(9 + col, reel[step + col]); }
        function finish() {
            if (finished) return;
            finished = true;
            if (prize.item) p.giveStack(prize.item); else RPG.server.runCommand(prize.command.replace("{player}", p.name));
            p.playSound("minecraft:entity.player.levelup", 1, 1.2);
            let label = prize.name || (prize.item && (prize.item.name || ((prize.item.count > 1 ? prize.item.count + "x " : "") + RPG.items.name(prize.item.id || prize.item)))) || "a prize";
            p.tell("&7You won &f" + label + "&7 from the " + c.name + "&7!");
        }
        function next() {
            if (!gui.isOpen()) { step = 30; finish(); return; }       // closed early: still get the prize
            draw();
            p.playSound("minecraft:block.note_block.hat", 0.5, 1 + step / 40);
            if (step >= 30) { RPG.schedule(10, () => { finish(); RPG.schedule(30, () => gui.close()); }); return; }
            step++;
            RPG.schedule(step < 15 ? 2 : step < 24 ? 4 : 7, next);
        }
        draw();
        RPG.schedule(2, next);
    }

    RPG.commands.register("crate", {
        root: true, permission: "crates.admin", description: "/crate give <player> <type> [n] | place <type> | remove | list",
        suggest(p, args) {
            if (args.length <= 1) return ["give", "place", "remove", "list"];
            if (args[0] === "give" && args.length === 2) return RPG.server.players().map((q) => q.name);
            return Object.keys(CRATES);
        },
        run(p, args) {
            let sub = args[0] || "list";
            if (sub === "list") { if (p) p.tell("&7Crates: &f" + Object.keys(CRATES).join(", ")); return; }
            if (sub === "give") {
                let t = RPG.server.player(args[1] || ""), type = args[2], n = parseInt(args[3]) || 1;
                if (!t || !CRATES[type]) { if (p) p.tell("&c/crate give <player> <type> [n]"); return; }
                t.giveStack(keyStack(type, n));
                t.tell("&7You got &f" + n + "x " + CRATES[type].name + " Key");
                return;
            }
            if (!p) return;
            let hit = p.raycast(6, { blocks: true, entities: false });
            if (hit.hit !== "block") { p.tell("&cLook at a block."); return; }
            if (sub === "place") {
                let type = args[1];
                if (!CRATES[type]) { p.tell("&c/crate place <" + Object.keys(CRATES).join("|") + ">"); return; }
                let x = hit.blockX, y = hit.blockY + 1, z = hit.blockZ;
                RPG.world.setBlock(p.dimension, x, y, z, CRATE_BLOCK);
                RPG.data.set(posKey(p.dimension, x, y, z), type);
                p.tell("&aPlaced a " + CRATES[type].name + "&a.");
            } else if (sub === "remove") {
                let k = posKey(p.dimension, hit.blockX, hit.blockY, hit.blockZ);
                if (!RPG.data.has(k)) { p.tell("&cThat isn't a crate."); return; }
                RPG.data.remove(k);
                RPG.world.setBlock(p.dimension, hit.blockX, hit.blockY, hit.blockZ, "minecraft:air");
                p.tell("&7Crate removed.");
            }
        }
    });
})();
