# Dragon Block Ragnarok

A Dragon Ball game for the Ragnarok RPG Toolkit, written entirely in its scripting API. Licensed GPL-3.0-or-later (see `LICENSE`); credits for the original game and art are in `NOTICE.md`.

## Keys

DMZ's default keys (rebind them in Options > Controls > "Ragnarok RPG"):

| Key | Action |
|---|---|
| Alt+1..4 / Ctrl+1..4 | technique slots 1-8 |
| C (hold) | charge ki: power release climbs, ki refills faster |
| Alt+C (hold) | lower power release |
| V | stats menu (the character creator if you haven't made one) |
| F | fly |
| R | dash |
| Z | lock on |

Being rebuilt to DMZ's exact behaviour next: G (transform), H (instant transmission), X (utility menu), F4 (ki sense), right click (block), Alt+right click (ki blast).

## What matches DragonMine Z now

- The character creator: race carousel with DMZ's panoramas and racial skills, then the Body / Hair / Eyes / Face / Tattoo / Class tabs.
- The Xenoverse HUD, the stats screen (V), DMZ's eight classes and six stats, and DMZ's formulas for health, ki, stamina, damage, defence, power release, power level, TP gains, stat prices and level.

## Animations

Every player plays DragonMine Z's own animations, chosen the way DMZ chooses them (its 10 animation
controllers, ported to `client/scripts/40_animator.js`): walking and running at your speed, crouching,
swimming, climbing, the landing after a long fall, flying in every direction, the per-race ki charge,
surge, blocking, shields, punches and tool swings, eating, dashes and dodges, techniques (cast and fire),
transformations and the tail, which gets livelier the faster you move.

What other players are doing comes from the server (`scripts/12_anim_state.js`), so everyone sees the
same thing. Addons can change any of it:

```js
// client script: spin while a server flag is set
DBR_ANIMATOR.extend((pl, out) => { if (pl.shared("spinning")) out.layers.extra = "skp.meteor"; });
// a weapon stance
DBR_ANIMATOR.poses["minecraft:diamond_sword"] = "combat.pose_two_handed_sword";
// procedural bones: wag the tail harder
DBR_ANIMATOR.extend((pl, out) => { out.bones.tail1 = { ry: Math.sin(pl.tick / 3) * 15 }; });
```

## Auras

Auras are drawn the way DragonMine Z draws them: the 3D styles (Smooth, Sparking, God) with DMZ's own shaders
(`resources/assets/dbr/shaders/core/aura_*`, its noise texture and bloom), every form's DMZ aura look (colour,
layer, 3D type and style numbers, `shared/07b_dmz_aura_data.js`), charge layers, the ground waves, the lean in
fast flight, swimming bodies, and your own aura in first person (a faint shell around you, or DMZ's screen card
for 2D auras). `client/scripts/43_dmz_aura_shader.js` does it; without the shaders (an old engine) the engine's
own auras show instead.

## Form editor: auras, overlays and your own models

Operators open the form editor with `/rpgc formeditor` (or its key). Besides the stats, a form can use:

- **Aura**: any DMZ 2D aura sheet (Kakarot, Saiyan, Namekian, Frost, Majin, Bio-Android, Demon, God, God Ki,
  God Form, White God Form, UI, UE) or a pack's `textures/auras/*_aura.png` / `textures/forms/*_aura.png` (4 frames
  side by side, with `*_cross.png` next to it for the ground wave), the 3D type, layer and every 3D style number and colour, an extra aura layer, lightning.
- **Overlays**: up to six sheets drawn over the body, eyes or hair: DMZ's race sheets or any pack's
  `textures/overlays/*.png` / `textures/forms/*.png` (64x64 skin layout), each in a form colour or a fixed one,
  optionally only on some bones.
- **Model**: a GeckoLib model of your own as the form's whole body (a giant ape, a custom transformation) or as
  an overlay on it.
- **Dodge** (DMZ Ragnarok): % chances to avoid a hit outright while in the form, one each for physical hits (fists,
  weapons, mobs, arrows), strike skills and ki attacks, plus a % damage mitigation on hits that land. A dodge has no
  hurt sound, flinch or knockback; nearby players hear a whoosh and see the upper body twist aside.
- **Buffs** (DMZ Ragnarok): every hit taken in the form adds a % of each stat's base value (STR, SKP, RES, VIT, PWR,
  ENE, set per stat) as a bonus, up to "Max Bonus % of base" (100 = the stat at most doubles). It is DMZ's flat
  bonus (not multiplied by the form), shows in the stats screen (hover a stat) and ends with the form.

Every picker is a searchable list with a picture of each choice. Saving applies at once for everyone online.

### Adding a GeckoLib model

1. Export from Blockbench as a GeckoLib model ("Bedrock"/GeckoLib entity): `name.geo.json`, the texture
   `name.png`, and (optional) `name.animation.json`.
2. Put them in `ragnarok_rpg/resources/` (or an art pack) as
   `assets/<namespace>/geo/forms/name.geo.json`, `assets/<namespace>/textures/forms/name.png` and
   `assets/<namespace>/animations/forms/name.animation.json` (any namespace, lowercase).
3. In the form editor's Model tab pick the model (models under `geo/forms/` and `geo/entity/` are listed; type any
   other id), its texture and animations, and "The whole body" or "Overlay".
   Body models play the animations named `idle`, `walk`, `run`, `fly`, `jump`, `fall`, `swim` and `sneak` from their
   own file; without one they use DMZ's player animations (name the bones like DMZ's: `head`, `body`, `right_arm`,
   `left_arm`, `right_leg`, `left_leg`). Overlays follow the player's bones that share their bone names, or ride
   whole on one bone (`body` by default).
4. Save the race. Servers send `resources/` to joining players with the rest of their art, so everyone sees it.

## Commands

DBR's commands are script commands: type `/rpgc <command> ...` (Tab completes every argument; long lists such as
quests, techniques and forms can be searched by typing any part of a name). Every DragonMine Z command is here
with DMZ's arguments, permissions and messages, named without "dmz" (DMZ's `/dmzstats set STR 100` is
`/rpgc stats set STR 100`). Old DBR names (`/rpgc dmzform`, `dmztech`, `dmzskill`, `dmzquest`, `testall`, `/dmzraid`...)
still work but are no longer suggested.

**Permissions** are DMZ's nodes with `dbr.` in front of DMZ's name minus "dmz" (`dragonminez.dmzstats.set.others` is
`dbr.stats.set.others`, `dragonminez.dmz.reload` is `dbr.reload`). Operators and holders of `dbr.admin` have them all;
everyone has what DMZ gives everyone (`dbr.stats.info.self`, `skill.list.self`, `tech.list.self`, `effect.list.self`,
`points.info.self`, `quest.list.self`, `quest.info`, `quest.track.self`, `party.use`, `form.list.self`,
`alignment.info.self`, `tail.self`, `hair.self`). A `.self` node allows yourself, `.others` other players (`[targets]`
takes a name or a selector: `@a`, `@p`, `@r`, `@s`, `@a[distance=..10]`). Grant them with `/rpg perm`.

| DragonMine Z | Dragon Block Ragnarok | Arguments |
|---|---|---|
| `/dmzstats` | `/rpgc stats` | `set\|add\|remove <STR\|SKP\|RES\|VIT\|PWR\|ENE\|ALL> <amount\|min\|max> [targets]`, `relocate [targets]`, `reset [targets] [keep%] [keepSkills]` |
| `/dmzpoints` | `/rpgc points` | `set\|add\|remove <amount> [targets]` (Training Points) |
| `/dmzskill` | `/rpgc skill` | `set <skill\|all> <level> [targets]`, `add <skill\|all> [targets]`, `remove <skill\|all> [targets]` |
| `/dmzform` | `/rpgc form` | `set <form\|all> <level> [targets]`, `add <form> [targets]`, `remove <form> [targets]` (superforms, legendaryforms, godforms, androidforms, kaioken, ultimate) |
| `/dmzmastery` | `/rpgc mastery` | `set\|add current form\|stack <value> [targets]`, `set\|add ALL form\|stack\|all <value> [targets]`, `set\|add <group> <form> <value> [targets]` |
| `/dmztech` | `/rpgc tech` | `add\|remove <technique\|all> [targets]`, `experience add\|set\|remove <technique> <amount> [targets]` |
| `/dmzcooldowns` | `/rpgc cooldowns` | `<slot 1-8> <ticks> [targets]` |
| `/dmzbonus` | `/rpgc bonus` | `add <stat> <+\|-\|*> <value> <name> [applyMultipliers] [targets]`, `remove <stat> <name> [targets]`, `clear <stat> [targets]` (STR SKP DEF STM VIT PWR ENE ALL; DEF and STM share Resistance) |
| `/dmzeffect` | `/rpgc effect` | `give <mightfruit\|majin\|mutant> <seconds\|-1> [targets]`, `remove <effect\|knockout> [targets]`, `clear [targets]` |
| `/dmzalignment` | `/rpgc alignment` | `set <0-100> [targets]`, `add\|remove <amount> [targets]` |
| `/dmzclass` | `/rpgc class` | `<class> [targets]` |
| `/dmztail` | `/rpgc tail` | `cut\|grow [targets]` |
| `/dmzhalo` | `/rpgc halo` | `on\|off [targets]` |
| `/dmzhair` | `/rpgc hair` | `resync\|reset [targets]`; also `/rpgc hair [preset]` to list or pick a DMZ hair preset |
| `/dmzrevive` | `/rpgc revive` | `[targets]` |
| `/dmzracial` | `/rpgc racial` | `reset [targets]`, `reply <accept\|reject>` |
| `/dmzweight` | `/rpgc weight` | `[turtle_shell\|workout_weights\|piccolo_cape] <weight>` |
| `/dmzquest` | `/rpgc quest` | `list [player]`, `info <quest>`, `start\|finish\|fail\|reset <quest\|all> [player]`, `track <quest\|none> [player]`, `startsaga\|finishsaga\|resetsaga <saga\|all> [player]`, `difficulty [easy\|normal\|hard] [targets]`, `questnpc spawn <npc> \| list \| remove` (quest ids use `.`: `saiyan_saga.1`) |
| `/dmzdragonballs` | `/rpgc dragonballs` | `status [set]`, `regenerate <set>` (plus DBR's `<set> scatter\|give\|awaken\|dormant`) |
| `/dmzparty` | `/rpgc party` | `invite <player>`, `accept [confirm]`, `reject`, `leave`, `list`, `kick <player>`, `disband`, `pvp` |
| `/dmzworldboss` | `/rpgc worldboss` | `results`, `locate\|tp\|reset\|ready [boss]` (plus `rebuild`, `summon`, `hp`, `debug`) |
| `/dmztournament` | `/rpgc tournament` | `ring <tournament>`, `cooldown clear <players> [tournament]` |
| `/dmzraid` | `/rpgc siteraid` | `start [type]`, `stop`, `info` (plus `omen [type]`, `sites`; the old root `/dmzraid` still works) |
| `/dmzminigame` | `/rpgc minigame` | `play <game> [targets] [masterBonus]`, `learn <game\|all> [targets]` (plus `forget`) |
| `/dmzlocate` | `/rpgc locate` | `<structure>` (no argument lists every structure) |
| `/dmzstructure` | `/rpgc structure` | `here`, `npcs` |
| `/dmzconfig` | `/rpgc config` | `<config> <key \| section key> <value>` (DBR's `ragnarok_rpg/config/*.json`) |
| `/dmzreload` | `/rpgc reload` | `[all\|config\|story\|wishes]` |
| `/dmzrestoreupdate` | `/rpgc restoreupdate` | then `confirm` within 15 s: forgets the saga editor's custom sagas and side quests |
| `/dmzdebug` | `/rpgc debug` | `[ALL\|STATS\|CHARACTER\|TECHNIQUES\|QUESTS]`, `<player> [scope]` (admins); saved as `ragnarok_rpg/local/dbrdebug/<player>.json` on your computer |
| `/dmztrigger` | `/rpgc trigger` | `<target> form <group> <form>\|base`, `stackform <group> <form>\|clear`, `clear`, `racialskill majin\|namekian ...`, `cooldowns`, `rage <0-100>`, `knockout [seconds]`, `release <value>` |

DBR's own commands, renamed where they had "dmz" in them: `raidsite` (was `dmzsite`), `fusion` (`dmzfusion`),
`buildstructure` (`dmzbuild`), `aura` (`dmzaura`), `tunnels` (`dmztunnels`), `master` (`dmzmaster`), `var` (`dmzvar`),
`grantall` (`testall`); and `power`, `help`, `setup`, `arena`, `color`, `recreate`, `leave`, `otherworld`, `space`,
`saga`, `sagaeditor`, `formeditor`, `rituals`, `godritual`, `rgnpc`, `giveall`, `resetall`, `setrace`, `salvage`,
`dbrregen`, `dbrclash`. Root commands: `/character`, `/prestige`, `/raid`, `/tourney`, `/dungeon`, `/shrine`,
`/npcregion`, `/rggrave`.

**`/rpgc grantall [stat] [quests|noquests] [player]`** (ops, for testing; `testall` is the old name) unlocks everything:
the six stats set to 1,000,000 (or `[stat]`; never above the stat cap, which prestige widens), every engine skill and
DMZ skill at its top level, every form skill high enough for every form of the race (form-editor forms included),
every form and stack form fully mastered, every technique, the rituals (SSG knowledge, Super Saiyan 5, Namekian god),
every minigame, 1e9 TP and full bars. The story quests are marked done (no rewards, no spawns) so saga-locked forms
open; `quests` plays every quest out with its rewards instead, `noquests` leaves the story alone.

## The scripts

The files are in `addons/dragon_block_ragnarok/scripts/` (open them in the F8 editor under `addons/`).

| File | What's in it |
|---|---|
| `00_project.js` | Project id/name, leveling mode **"both"** (levels give skill points, TP buys stats), XP curve, TP earning and prices, Zeni, combat formulas |
| `06_hud_dmz.js` | The DMZ HUD as a script-defined layout (players can move/resize it) |
| `07_creator_dmz.js` | The DMZ character creator: race, body, skin, hair, eyes, nose, mouth, class |
| `01_toolbox.js` | Shared helpers: `sfx()` (pack sounds), `act()` (play an avatar animation, then return to flying/charging), damage formulas, `lookPoint()`, lock-on, `times()` |
| `05_ui.js` | Ragnarok theme, HUD (ki/stamina bars, portrait), race + class picker, DMZ menu tab names, colours |
| `10_stats.js` | STR, SKP, RES, VIT, PWR, ENE, three hidden "marker" stats for gear, and `powerLevel()` |
| `15_resources.js` | Ki (grows with Energy) and Stamina (grows with Vitality) |
| `20_races.js` | The six races with **avatars** built from DMZ's layered textures, their default colours, the `raceChange` hook that applies them, and `/rpgc color` |
| `25_classes.js` | Warrior and Spiritualist (each with a starting gi and technique) |
| `29_dmz_auras.js` | How auras look: 2D or DMZ's 3D styles (Smooth / Sparking / God, picked in V > Config), each form's 3D tuning, the flight lean and the ki surge's swelling aura (options in `client/scripts/43_dmz_auras.js`) |
| `30_forms.js` | `defineForm()` and 30+ forms: Kaioken x2-x20, Oozaru, Super Saiyan 1/G2/G3/2/3/4/God/Blue, Golden Oozaru, Giant/Super/Orange Namekian, the Frost Demon forms up to Golden and Metal, Semi-Perfect to Xeno, Super/Evil/Kid Majin, Super Janemba. Each swaps the avatar, adds an aura and plays a DMZ transformation animation |
| `35_projectiles.js` | Every ball, beam, laser, disk, sprite and thrown item (30 projectiles) |
| `41_dmz_techniques.js` | DMZ's techniques (data in `shared/09_dmz_techniques_data.js`): learned from masters/quests/`/rpgc tech add`, a pop-up when learned, Bind to Slot (V > Skills), 8 slots on Alt/Ctrl+1..4, ki charge to 175 %, strikes and evasions; HUD in `client/scripts/47_dmz_notifications.js` and `49_dmz_techniques.js` |
| `40_skills.js` | `kiTechnique()` / `strikeTechnique()` recipes and ~50 techniques: beams, volleys, disks, DMZ "skp" strikes, Zanzoken, Instant Transmission, Solar Flare, barriers, Absorb, Fusion Dance, passives |
| `45_keys.js` | The DMZ controls: charge ki, flight, dash, descend/meditate, lock-on, ascend, guard, power strike |
| `50_items.js` | Senzu beans (and farmable coloured beans), food, medicine, capsules, Gete stat capsules, scouters, three Dragon Ball sets and radars, weapons and guns, weights, Potara earrings, Nimbus, 40 music discs |
| `52_armor.js` | 47 DMZ outfits (skin64 armour model) and a sewing pattern for each |
| `19_outfits.js` / `19c_cosmetics.js` | The Tailor's Catalogue: 878 outfit pieces grouped by their tabs (Dragon Ball, Dragon Ball Z, Super, GT, Heroes/Xeno, Multiverse, Angels, Hakaishins, Supreme Kais, Original Outfits, Extra Slot hats), Core items and Core Ore, and 165 cosmetics (masks, glasses, scars, beards, potara earrings, scouters, horns, tails, jackets, coats...) in four cosmetic accessory slots in the inventory's accessory panel; sewn from Fabric Cores. Art: the `outfitpack` art pack (asked for automatically, credits inside) |
| `55_blocks.js` | Namek terrain, ores and trees, Earth/Hell/Demon Realm blocks, flowers, herbs, growing Senzu crops, the Time Chamber floor, a Dragon Altar |
| `60_npcs_dialogue.js` | `teacher()` and 25 DMZ masters who teach techniques, townsfolk, Namekian villagers, vehicle props, the punch machine, Shenron and Porunga |
| `65_shops.js` | Kame House, Korin, Capsule Corp., Namek, Frieza Force, Babidi, Yajirobe, Toribot's jukebox |
| `70_quests.js` | Tutorial, the Saiyan / Namek / Android / Buu sagas (21 chained quests) and side quests (tournaments, Baba, Old Kai's ritual...) |
| `75_mobs_bosses.js` | ~100 mobs (Saibamen, soldiers, robots, dinosaurs, frogs, ogres, the training shadow, the dragons) and 57 bosses, including Frieza's four forms in a row and DMZ's world bosses with their music |
| `77_dmz_world_bosses.js`, `77_dmz_world_bosses_ai.js` | DMZ's seven world bosses (Janemba, Turles, Metal Cooler Core, Tamagami 3/2/1, Gomah): lairs, sleeping / waking, group scaling, knock-outs and the Revive technique, contribution, rewards and results (`/rpgc worldboss`), and each boss's own abilities and phases; the HUD, results screen and effects are `client/scripts/68_dmz_worldboss.js` |
| `80_spawns_events.js` | Natural spawns on Earth, Namek, the Other World and in the Time Chamber (DMZ's biome modifiers; no timed random events, as in DMZ) |
| `85_world.js` | The Time Chamber, Namek and Other World dimensions, travel helpers and `/rpgc leave` |
| `86_dbr_space.js` | Space (DMZ Ragnarok's Space module): fly or pod above y 1000 to reach the `ragnarok_rpg:space` void (zero-g, no void kill), the sun and main planets (Earth, Namek, Sacred Kai, Planet Vegeta, Demon Realm, Beerus' planet, Planet Cereal) with their moons, rings and cloud shells, the generated universe (star systems with landable planets, lone stars, black holes) and the seven Super Dragon Ball bodies guarded by Gods of Destruction. Generated planets and moons are stamped squares of `ragnarok_rpg:planet_surface` (themes, seas, vegetation, weather, a garrison to beat to claim it) that wrap round; fly up past y 260 to leave. Pod autopilot from the destination list or the star map (M), stars burn, black holes pull; Black Star balls land on generated planets; `dbrDestroyPlanet`. Sky, radar, overlay and star map in `client/scripts/61_dbr_space.js`; maths in `shared/15..17`; settings `/rpg config dbr_space`; ops: `/rpgc space [planet|moon|pod|auto <id>|<id>]` |
| `88_dbr_space_cereal.js` | Planet Cereal (`ragnarok_rpg:cereal_planet`, DMZ's "Cereal Planet" pod destination): stepped mesas, canyons with teal rivers, a cratered basin, crystal fields, Cerealian villages, old city ruins and impact craters from the data pack (`tools/cereal_worldgen.py`); a body in space on DMZ Ragnarok's ring 12; the pod lands beside the nearest village. Villages fill with Cerealians (eight looks, a trader, two daily errands) the first time a player comes near; one village per world is home to Granolah and Monaito, whose three quests (level 50) end with the Cerulean Radar and Granolah's pattern. Home of the Cerulean Dragon Balls. Sky: `client/scripts/62_dbr_cereal_sky.js` |
| `89_dbr_keep_inventory.js` | Partial keep inventory and death graves (DMZ Ragnarok's KeepPartialInventory): below level 100 a death keeps everything; from it on the hotbar, armour, off hand, accessories and cosmetic armour stay and the main inventory and experience go into a grave (fence, head and name) that despawns after 10 minutes; dragon balls always go into the grave or a totem of their own. Settings `/rpg config dbr_keep_inventory` or the Server rows of the DMZ config menu; ops: `/rggrave cleannames | listballs | removeball | time` |
| `64_dmz_kishare.js` (+ client `46_dmz_kishare.js`) | DragonMine Z's Ki sharing (Ctrl + Alt + right click a player) and Super Saiyan God ritual (five pure-hearted Saiyans round a sixth in SSJ Mastered; in singleplayer the vessel can do it alone with Charge Ki: `dbr_rituals` godRitual.singleplayerRequiredDonors, default 0; DMZ's 5 elsewhere) |
| `92_dmz_raids.js` | DragonMine Z's raids: scouts at Saiyan craters, razed Namekian settlements, Gomah camps and Red Ribbon bases; kill one and you are Hunted, then five waves (bosses, boss bar, raid music), rewards or "YOU LOST!"; `/rpgc siteraid start|stop|info|omen|sites`; `dmz_raids` config |
| `95_dbr_rituals.js` (+ client `95_dbr_rituals.js`) | DMZ Ragnarok's rituals: the Knowledge of Super Saiyan God wish and the SSG charge ritual, Super Saiyan 5 (the fusion with Shenron, eleventh Earth wish, level 10000, 5000 levels), the Namekian god ritual at a Shenron / Porunga Idol (Primal Namekian, the spent set restored); singleplayer settings in `dbr_rituals` |
| `95_dmz_tournaments.js` (+ client `85_dmz_tournaments.js`) | DragonMine Z's NPC-hosted tournaments: Fortuneteller Baba's gauntlet (her palace), the Cell Games (lethal), the World Martial Arts Tournament (Budokai arena announcer) and the Otherworld Tournament (its announcer on the grounds Grand Kai sends you to). Solo or a whole party (the leader enters); everyone accepts the rules, the draw is revealed, bouts are fought one at a time in the arena's ring with a 3 s frozen countdown, nobody else within 15 blocks, a time limit, knock-out (or death in the Cell Games), walk-away and logout forfeits, re-entry cooldowns, training points and alignment for the champion. DMZ's bracket screen, countdown overlay and notification card. Settings `config/dmz_tournaments/<id>.json`; ops: `/rpgc dmztournament ring <id>`, `/rpgc dmztournament cooldown clear <player\|@a> [id]` |
| `86b_dbr_saibamen.js` | DMZ Ragnarok's Saibaman seeds: plant them on Rocky Dirt, charge ki beside the plant while it grows (faster growth, a better tier, 3 % ki a second), right-click it grown for a tamed Saibaman (six tiers, scaled from you, follows, defends, explodes at 20 %; right-click sit, sneak-right-click dismiss, 3 each); seeds in the Saibamen huts of generated planets and Vegeta; `config/dbr_saibaman_pets.json` |
| `97_dbr_look_hud.js` (+ client) | Lines for the built-in Look HUD addon: DMZ masters, quest givers and tournament hosts say what they are; a creature's battle power shows while you wear a scouter |
| `99_dbr_item_clear.js` | DMZ Ragnarok's ground item clear (off by default): dropped items are deleted every 300 s with warnings at 60/30/10/5 s and a count afterwards; dragon balls (any confined item) and `excludedItems` are never cleared. Settings `/rpg config dbr_item_clear` or the Server rows of the DMZ config menu; ops: `/rpgc clearitems now \| warn \| on \| off \| status` |
| `90_hooks.js` | Welcome, level-ups, kill streaks, regeneration, Zenkai, barrier/guard damage reduction, hurt animations, TP multipliers, overrides, and `/rpgc power`, `help`, `arena`, `setup` |

**To try it:** join, pick a race and a class, and type `/rpgc setup` (op) to place Roshi, Korin, Bulma, Mr. Popo, King Yemma and other masters around you. Talk to Roshi to start the saga. Quick tests: `/rpg learn @s kamehameha`, `/rpg learn @s super_saiyan`, `/rpg mob saibaman`, `/rpg boss frieza_first`, `/rpg event start world_boss`, `/rpgc color hair #FF0000`. After the first start, **restart once** so the three dimensions load.
