// =====================================================================================
//  07c_dmz_outline.js - DMZ's transformation outline as an engine outline spec
// =====================================================================================
//  Ported from DragonMine Z 2.2 (GPL-3.0): TransformationPostShaderManager. DMZ draws every outlined player (forms
//  with an enabled outlineShader, the Demon Eye) and outlined saga / world boss into a mask and runs its post chain
//  shaders/post/transformation_outline.json over the frame (the dmzpack copy: dmzpack:shaders/post/...). The mask
//  holds both colours of each outline (4 bits each); the chain's uniforms come from one outline, the local player's
//  when they are seen in third person, else the first one found:
//      unpack       ColorChannel = colour mode (0 pulse, 1 gradient), AnimationTime = game seconds (wraps 24000 ticks)
//      blur h/v     BloomRadius = clamp(6 + thickness * 3, 3, 28)
//      outer blur   BloomRadius = that radius in gradient mode, else 0
//      composite    OutlineRadius, FireIntensity, BodyGlow, ColorMode, BloomStrength 0.95, GlowStrength 1.35
//      bloom source ColorMode, BloomStrength 0.95, GlowStrength 1.35
//  The engine draws "mask: true" outlines through the chain set with RPG.avatar.outlineChain (client/scripts/
//  09_dmz_options.js); the other fields are its hull fallback when the chain can't load.
// =====================================================================================
var DMZ_OUTLINE = (function () {
    var CHAIN = { chain: "dmzpack:shaders/post/transformation_outline.json", mask: "entity_mask", colors: "packed", time: "AnimationTime" };
    var P = "dmzpack:transformation_";
    var GLOW_STRENGTH = 1.35, BLOOM_STRENGTH = 0.95;
    function radius(t) { return Math.max(3, Math.min(28, 6 + t * 3)); }
    /** c, c2 "#RRGGBB"; mode "pulse" | "gradient"; thickness; fire 0-3; bodyGlow 0-1 */
    function spec(c, c2, mode, thickness, fire, bodyGlow) {
        var t = Math.max(0, Number(thickness) || 0), r = radius(t), cm = mode === "gradient" ? 1 : 0;
        fire = Math.max(0, Math.min(3, Number(fire) || 0));
        bodyGlow = Math.max(0, Math.min(1, Number(bodyGlow) || 0));
        var u = {};
        u[P + "unpack"] = { ColorChannel: cm };
        u[P + "blur_h"] = { BloomRadius: r };
        u[P + "blur_v"] = { BloomRadius: r };
        u[P + "blur_outer_h"] = { BloomRadius: cm ? r : 0 };
        u[P + "blur_outer_v"] = { BloomRadius: cm ? r : 0 };
        u[P + "composite"] = { OutlineRadius: r, FireIntensity: fire, BodyGlow: bodyGlow, ColorMode: cm, BloomStrength: BLOOM_STRENGTH, GlowStrength: GLOW_STRENGTH };
        u[P + "bloom_source"] = { ColorMode: cm, BloomStrength: BLOOM_STRENGTH, GlowStrength: GLOW_STRENGTH };
        return { color: c || "#7FFFFF", color2: c2 || c || "#FFD970", mode: cm ? "gradient" : "pulse", thickness: Math.max(0.5, t),
                 fire: fire, bodyGlow: bodyGlow, glow: 0.55, alpha: 0.9, mask: true, uniforms: u };
    }
    // DBSagasEntity.OutlineStyle(primary, secondary, thickness[, fire]): pulse mode, no body glow
    function saga(c, c2, thickness, fire) { return spec(c, c2, "pulse", thickness, fire || 0, 0); }
    return { CHAIN: CHAIN, spec: spec, saga: saga, radius: radius };
})();
