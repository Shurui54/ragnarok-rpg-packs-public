// =====================================================================================
//  18_dbr_space_clash.js - the planet clash meter (server and client)
// =====================================================================================
//  Port of DragonMine Z's ClashMeter + BeamClash maths (GPL-3.0), which DMZ Ragnarok's
//  PlanetClash uses when a giant ki ball meets the planet it was thrown at: a marker sweeps a
//  bar (each sweep 44..64 ticks, alternating direction) past a target window; a press in the
//  window's core is PERFECT (1.0), elsewhere in it GOOD (1.0 .. 0.5), outside it a MISS. Each
//  press adds momentum (decays 0.94 a tick); the tug of war moves by 0.01 x the difference of the
//  two sides' pushes (momentum x (0.6 + 0.95 x share of the combined power) x traction). 0.8 wins.
//  The meter is a pure function of a seed and the time, so both sides draw/judge the same sweep.
// =====================================================================================
var DBR_CLASH = (function () {
    var U = DBR_SPACE_ORBITS.u64;
    // Difficulty (harder than DMZ's numbers, by request): the target window is WINDOW x DMZ's width, the marker sweeps
    // SPEED x as fast, and whatever pushes back (a planet, a world boss's ball) pushes OPPONENT x as hard.
    var DIFFICULTY = { WINDOW: 0.72, SPEED: 1.25, OPPONENT: 1.35 };
    var CYCLE_MIN = Math.round(44 / DIFFICULTY.SPEED), CYCLE_MAX = Math.round(64 / DIFFICULTY.SPEED), PROG_MIN = 0.42, PROG_MAX = 0.86,
        HW_MIN = 0.065 * DIFFICULTY.WINDOW, HW_MAX = 0.09 * DIFFICULTY.WINDOW;
    var PERFECT = 0.35, GOOD_MIN = 0.5, MAX_CYCLES = 64;
    var K1 = U.make(0x9E3779B9, 0x7F4A7C15), K2 = U.make(0xD1B54A32, 0xD192ED03);
    function add(a, b) { var lo = (a.lo >>> 0) + (b.lo >>> 0), c = lo >= 4294967296 ? 1 : 0; return U.make((a.hi + b.hi + c) >>> 0, lo >>> 0); }
    /** ClashMeter.hash01: seed + K1 (index+1) + K2 (salt+1), splitmix64's finaliser, top 24 bits. */
    function hash01(seed, index, salt) {
        var z = add(add(seed, U.mul(K1, U.fromInt(index + 1))), U.mul(K2, U.fromInt(salt + 1)));
        return U.shr(U.finish(z), 40).lo / 16777216;
    }
    function lerp(t, a, b) { return a + (b - a) * t; }
    function build(seed, index, start) {
        var dur = CYCLE_MIN + Math.round(hash01(seed, index, 0) * (CYCLE_MAX - CYCLE_MIN));
        var prog = lerp(hash01(seed, index, 1), PROG_MIN, PROG_MAX), hw = lerp(hash01(seed, index, 2), HW_MIN, HW_MAX), rev = (index & 1) === 1;
        return { index: index, start: start, duration: dur, end: start + dur, center: rev ? 1 - prog : prog, halfWidth: hw, reversed: rev };
    }
    var memo = { key: "", cycles: [] };
    function cycleAt(seed, time) {
        var key = seed.hi + ":" + seed.lo;
        if (memo.key !== key) memo = { key: key, cycles: [] };
        var start = 0, c = null;
        for (var i = 0; i < MAX_CYCLES; i++) {
            c = memo.cycles[i] || (memo.cycles[i] = build(seed, i, start));
            if (time < c.end) return c;
            start = c.end;
        }
        return c;
    }
    /** {cycle, marker 0..1, distance (in half-widths), grade "PERFECT"|"GOOD"|"MISS", efficiency} at a time in ticks. */
    function sample(seed, time) {
        var c = cycleAt(seed, time), ph = Math.max(0, Math.min(1, (time - c.start) / c.duration)), marker = c.reversed ? 1 - ph : ph;
        var d = Math.abs(marker - c.center) / c.halfWidth, grade, eff;
        if (d <= PERFECT) { grade = "PERFECT"; eff = 1; }
        else if (d <= 1) { grade = "GOOD"; eff = 1 - (1 - GOOD_MIN) * (d - PERFECT) / (1 - PERFECT); }
        else { grade = "MISS"; eff = 0; }
        return { cycle: c, marker: marker, distance: d, grade: grade, efficiency: eff };
    }
    // ---- BeamClash ----
    var DRIFT = 0.010, STR_FLOOR = 0.6, STR_SPAN = 0.95, MIN_TRACTION = 0.35, WIN = 0.8, DECAY = 0.94;
    function advanceBias(bias, a, b) {
        var sa = a.power / (a.power + b.power), sb = 1 - sa;
        var ta = Math.max(MIN_TRACTION, Math.min(1, 2 * bias)), tb = Math.max(MIN_TRACTION, Math.min(1, 2 * (1 - bias)));
        var pa = a.momentum * (STR_FLOOR + STR_SPAN * sa) * ta, pb = b.momentum * (STR_FLOOR + STR_SPAN * sb) * tb;
        return Math.max(0, Math.min(1, bias + DRIFT * (pa - pb)));
    }
    function visualBias(bias) { return Math.max(0, Math.min(1, (bias - (1 - WIN)) / (2 * WIN - 1))); }
    /** ClashParticipant.resolveNpcAccuracy: how well a non-player side presses. */
    function npcAccuracy(power) { return Math.min(0.92, 0.45 + Math.log(power + 1) / Math.LN10 / 3 * 0.45); }
    return { DIFFICULTY: DIFFICULTY, OPPONENT: DIFFICULTY.OPPONENT, sample: sample, advanceBias: advanceBias, visualBias: visualBias, npcAccuracy: npcAccuracy, WIN: WIN, DECAY: DECAY,
        PERFECT: PERFECT, IDLE_DISSOLVE: 140, MAX_DURATION: 600, LOSER_EXHAUST: 70 };
})();
