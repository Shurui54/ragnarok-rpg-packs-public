// =====================================================================================
//  27_dbr_quirks.js - DragonMine Z's little quirks and easter eggs (shared tables)
// =====================================================================================
//  Ported from DragonMine Z (GPL-3.0) - values copied on purpose, see NOTICE.md.
//   - client/render/HelmetFormLook.java: wearing Broly's Control Jewelry tiara (Z Broly's outfit,
//     broly_z_armor_helmet, real or cosmetic) changes the Mutant forms' look: Ikari's hair turns cyan
//     (#25C0CB, painting every strand) with a gold aura (#FFD700, 3D noise #8C7600); SSJ Hybrid gets the
//     same gold aura; SSJ Full Power a lime aura (#B5FF20, noise #415C0C). Matched by form name, like DMZ.
//   - GeneralServerConfig.helmetsThatKeepHair: the hair still shows under these three helmets
//     (every other head item hides it).
//   - common/util/HalloweenEvent.java: October 31st (the server's / client's local date).
//  Used by scripts/31_dmz_transform.js (colours), scripts/30_forms.js + shared/11_dmz_hair.js (hair),
//  client/scripts/43_dmz_aura_shader.js (3D aura) and scripts/98_dbr_quirks.js (the rest).
// =====================================================================================
var DBR_QUIRKS_DATA = (function () {
    var BROLY_Z_HELMET = "broly_z_armor_helmet";
    var HELMETS_KEEP_HAIR = ["invencible_armor_helmet", "invencible_blue_armor_helmet", "broly_z_armor_helmet"];
    var BROLY_Z = {
        ikari: { hair: "#25C0CB", aura: "#FFD700", noise: "#8C7600" },
        ssjhybrid: { aura: "#FFD700", noise: "#8C7600" },
        ssjfullpower: { aura: "#B5FF20", noise: "#415C0C" }
    };
    // HalloweenEvent.FORCE_ACTIVE (false in DMZ); scripts/98_dbr_quirks.js may set it from its config for testing
    var force = { halloween: "" };

    function bare(id) { id = String(id || ""); var i = id.indexOf(":"); return i < 0 ? id : id.substring(i + 1); }
    // script items live in placeholder slots ("broly_z_armor_helmet" -> "item_0123"): the registry id the game sees
    function placeholder(name) {
        try { var r = RPG.items && RPG.items.id ? RPG.items.id(name) : null; return r ? bare(r) : name; } catch (e) { return name; }
    }
    /** The helmets that keep the hair, as item ids for the avatar's hair `helmet` list. */
    function keepHairIds() { return HELMETS_KEEP_HAIR.map(placeholder); }
    /** The Broly Z look of a form id (any race / group, like DMZ's name match), or null. */
    function helmetLook(formId) { return Object.prototype.hasOwnProperty.call(BROLY_Z, String(formId || "")) ? BROLY_Z[formId] : null; }
    /** Whether an item id (with or without namespace) is Broly's tiara. */
    function isBrolyZHelmet(itemId) { var b = bare(itemId); return b === BROLY_Z_HELMET || (b !== "" && b !== "air" && b === placeholder(BROLY_Z_HELMET)); }
    function halloween() {
        if (force.halloween === "on") return true;
        if (force.halloween === "off") return false;
        var d = new Date();
        return d.getMonth() === 9 && d.getDate() === 31;
    }
    return { BROLY_Z_HELMET: BROLY_Z_HELMET, HELMETS_KEEP_HAIR: HELMETS_KEEP_HAIR, BROLY_Z: BROLY_Z, force: force,
        helmetLook: helmetLook, isBrolyZHelmet: isBrolyZHelmet, keepHairIds: keepHairIds, halloween: halloween, bare: bare };
})();
