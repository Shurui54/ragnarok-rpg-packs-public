// =====================================================================================
//  DMZ skills data (SkillsConfig defaults, race form-skill prices and the default form
//  trees from DefaultFormsFactory), shared by the skills screen and the server.
// =====================================================================================
var DMZ_SKILLS_DATA = (function () {
    function r10(a) { return a.slice(); }
    var LADDER = [300, 600, 900, 1200, 1500, 1800, 2100, 2400, 2700, 3000];
    var LADDER_KI = [600, 1200, 1800, 2200, 2600, 2800, 3000, 3200, 3600, 4000];

    // skill -> { costs: TP per level (index = current level), races: allowed DMZ races (empty = all) }
    var SKILLS = {
        ki_barrage: [1000], masenko: [1500], kamehameha: [2000], galick_gun: [2000], taiyoken: [2000], afterimage: [2500],
        dimensional_teleport: [12000], sleep_recovery: [[3000], ["majin"]], candy_beam: [[5000], ["majin"]], gum_bind: [[9000], ["majin"]],
        death_beam: [2500], dodonpa: [3000], fake_moon: [3000], kienzan: [3000], makkanko: [3500], burning_attack: [3500], big_bang: [4000],
        mouth_blast: [4500], assault_rain: [4500], blaster_meteor: [5000], sokidan: [4000], kienzan_doble: [4000],
        emperor_death_beam: [5000], final_flash: [5000], heat_dome: [6000], kikoho: [5000], neo_kikoho: [8000], spiritbomb: [10000], supernova: [12000],
        supernova_cooler: [15000], final_explosion: [20000], soul_punisher: [25000], kill_driver: [16000], hellzone_grenade: [6000],
        meteor: [3000], wolf_fang: [3500], kaioken_attack: [5000], dragon_fist: [6000], deadly_dance: [8000], super_god_fist: [10000],
        deadly_dance_vegetto: [12000], oozaru_fist: [15000], oozaru_slam: [4000], gum_punch: [[4000], ["majin"]], blue_hurricane: [5000],
        dimensional_punch: [18000], dimensional_sword_attack: [22000], spirit_breaking_cannon: [12000], grab: [3500], shining_sword_attack: [9000],
        combo_meteor: [7000], meteor_burst: [24000], mystic_ball: [[11000], ["majin"]], darkness_eye_beam: [[11000], ["namekian"]], death_chaser: [15000],
        android_combo: [[14000], ["android"]], perfect_rush: [[15000], ["bioandroid"]], spirit_breaker: [17000], beam_sword_slash: [16000],
        jump: r10(LADDER), sprint: r10(LADDER), fly: [1500, 600, 900, 1200, 1500, 1800, 2100, 2400, 2700, 3000], meditation: r10(LADDER), kisense: r10(LADDER),
        potentialunlock: [600, 1600, 2400, 3200, 4000, 4800, 5600, 6400, 7200, 8000, -1, 8800, 9600],
        kicontrol: [3000], kiboost: [2000, 4000, 6000, 8000],
        kimanipulation: r10(LADDER_KI), instant_transmission: r10(LADDER_KI), defense_penetration: r10(LADDER_KI), healing_reduction: r10(LADDER_KI),
        ki_infusion: r10(LADDER_KI), kiprotection: r10(LADDER_KI),
        kaioken: [1000, 1500, 2500, 4000, 7500], ultimate: [-1], fusion: [25000, 5000, 10000, 15000, 20000]
    };
    var COSTS = {}, RACES = {};
    Object.keys(SKILLS).forEach(function (k) {
        var v = SKILLS[k];
        if (v.length === 2 && v[0] instanceof Array) { COSTS[k] = v[0]; RACES[k] = v[1]; }
        else { COSTS[k] = v; RACES[k] = []; }
    });

    var KI = ["spiritbomb", "supernova", "supernova_cooler", "big_bang", "burning_attack", "sokidan", "final_flash", "heat_dome", "kikoho", "neo_kikoho",
        "kamehameha", "galick_gun", "masenko", "kienzan", "kienzan_doble", "death_beam", "makkanko", "emperor_death_beam", "dodonpa", "ki_barrage",
        "final_explosion", "soul_punisher", "fake_moon", "mouth_blast", "assault_rain", "blaster_meteor", "kill_driver", "hellzone_grenade"];
    var EVASION = ["taiyoken", "rage_scream", "afterimage", "sleep_recovery", "dimensional_teleport", "candy_beam", "gum_bind"];
    var STRIKE = ["meteor", "dragon_fist", "deadly_dance_vegetto", "deadly_dance", "kaioken_attack", "wolf_fang", "oozaru_fist", "super_god_fist", "oozaru_slam",
        "gum_punch", "blue_hurricane", "dimensional_punch", "dimensional_sword_attack", "spirit_breaking_cannon", "grab", "shining_sword_attack", "combo_meteor",
        "meteor_burst", "mystic_ball", "darkness_eye_beam", "death_chaser", "android_combo", "beam_sword_slash", "perfect_rush", "spirit_breaker"];
    var FORM_SKILLS = ["superforms", "legendaryforms", "godforms", "androidforms"];
    var STACK_SKILLS = ["kaioken", "ultimate"];
    var ANDROID_BLACKLIST = ["superforms", "legendaryforms"];

    // RaceCharacterConfig form-skill prices (index = current level; -1 = quest only)
    var FORM_COSTS = {
        human: { superforms: [21000, 42000, 65000, 104000], godforms: [], legendaryforms: [-1, -1, -1], androidforms: [42000, 104000] },
        saiyan: { superforms: [13000, 21000, 31000, 42000, 52000, 65000, 78000, 104000, -1], godforms: [], legendaryforms: [-1, -1, -1] },
        namekian: { superforms: [23000, 47000, 78000, -1], godforms: [], legendaryforms: [-1, -1, -1] },
        frostdemon: { superforms: [18000, 31000, 52000, 83000, 117000], godforms: [], legendaryforms: [-1, -1, -1] },
        bioandroid: { superforms: [26000, 57000, 88000, 125000], godforms: [], legendaryforms: [-1, -1, -1] },
        majin: { superforms: [23000, 47000, 78000, 114000], godforms: [], legendaryforms: [-1, -1, -1] },
        glind: { superforms: [18000, 31000, 52000, 83000, 117000], godforms: [], legendaryforms: [-1, -1, -1] }
    };

    // master -> skills it teaches (SkillsConfig.skillOfferings)
    var OFFERINGS = {
        roshi: ["jump", "meditation", "kicontrol", "kamehameha", "afterimage"],
        goku: ["kicontrol", "fly", "instant_transmission", "fusion", "kamehameha", "spiritbomb", "dragon_fist", "super_god_fist", "oozaru_fist", "beam_sword_slash"],
        kingkai: ["kicontrol", "kaioken", "potentialunlock", "kimanipulation", "kaioken_attack", "spiritbomb"],
        vegeta: ["kicontrol", "defense_penetration", "potentialunlock", "galick_gun", "big_bang", "final_flash", "final_explosion", "fake_moon", "deadly_dance_vegetto", "spirit_breaker", "spirit_breaking_cannon"],
        oldkai: ["kicontrol", "ki_infusion", "healing_reduction", "soul_punisher"],
        gohan: ["kicontrol", "kiboost", "kiprotection", "kisense", "masenko", "makkanko", "kamehameha", "ki_barrage"],
        piccolo: ["potentialunlock", "kicontrol", "masenko", "makkanko", "ki_barrage", "kienzan", "hellzone_grenade", "darkness_eye_beam"],
        krillin: ["kicontrol", "sprint", "kisense", "kienzan", "kienzan_doble", "ki_barrage", "taiyoken", "afterimage", "deadly_dance"],
        frieza: ["kicontrol", "fly", "jump", "sprint", "kisense", "meditation", "potentialunlock", "death_beam", "emperor_death_beam", "supernova", "kienzan_doble", "deadly_dance", "meteor", "death_chaser"],
        trunks: ["kicontrol", "kiboost", "kiprotection", "burning_attack", "heat_dome", "shining_sword_attack", "galick_gun", "ki_barrage", "meteor"],
        cell: ["kicontrol", "instant_transmission", "kimanipulation", "ki_infusion", "kiprotection", "defense_penetration", "healing_reduction", "kiboost", "kamehameha", "kienzan", "galick_gun", "masenko", "death_beam", "ki_barrage", "afterimage", "deadly_dance", "meteor", "android_combo", "perfect_rush"],
        yamcha: ["kicontrol", "ki_infusion", "wolf_fang", "sokidan", "kamehameha", "ki_barrage"],
        tien: ["kicontrol", "taiyoken", "dodonpa", "kikoho", "neo_kikoho"],
        baba_earth: ["kicontrol", "meditation"],
        buu: ["assault_rain", "gum_punch", "mystic_ball", "sleep_recovery", "candy_beam", "gum_bind"],
        "default": ["kicontrol", "jump"]
    };

    // DMZ technique id -> our technique (40_skills.js / 30_forms.js), so a bought skill can be cast
    var TECHNIQUES = {
        ki_barrage: "ki_barrage", kamehameha: "kamehameha", galick_gun: "galick_gun", final_flash: "final_flash", big_bang: "big_bang_attack",
        masenko: "masenko", makkanko: "special_beam_cannon", hellzone_grenade: "hellzone_grenade", kienzan: "destructo_disk",
        kienzan_doble: "double_destructo_disk", kikoho: "tri_beam", neo_kikoho: "neo_tri_beam", dodonpa: "dodonpa", spiritbomb: "spirit_bomb",
        burning_attack: "burning_attack", death_beam: "death_beam", supernova: "supernova", kill_driver: "kill_driver", blaster_meteor: "blaster_meteor",
        assault_rain: "assault_rain", soul_punisher: "soul_punisher", candy_beam: "candy_beam", mouth_blast: "mouth_blast", final_explosion: "self_destruct",
        meteor: "meteor_smash", combo_meteor: "meteor_combo", meteor_burst: "meteor_burst", dragon_fist: "dragon_fist", kaioken_attack: "kaioken_attack",
        spirit_breaker: "spirit_breaker", spirit_breaking_cannon: "spirit_breaking_cannon", death_chaser: "death_chaser", blue_hurricane: "blue_hurricane",
        perfect_rush: "perfect_rush", android_combo: "android_combo", gum_punch: "gum_punch", deadly_dance: "deadly_dance", super_god_fist: "super_god_fist",
        oozaru_fist: "oozaru_fist", oozaru_slam: "oozaru_slam", shining_sword_attack: "shining_sword_attack", dimensional_sword_attack: "dimensional_slash",
        beam_sword_slash: "beam_sword", wolf_fang: "wolf_fang_fist", darkness_eye_beam: "eye_laser",
        taiyoken: "solar_flare", rage_scream: "rage_scream", afterimage: "zanzoken", sleep_recovery: "sleep_recovery", gum_bind: "gum_bind",
        instant_transmission: "instant_transmission", fusion: "fusion_dance", kaioken: "kaioken"
    };

    // default form trees: race -> [[group, formType, [[name, unlockOnSkillLevel, auraColor, sagaRequisite]...]]...]
    var FORM_TREES = {"stack":[["kaioken","kaioken",[["x2",1,"#DB182C",""],["x3",2,"#DB182C",""],["x4",3,"#DB182C",""],["x10",4,"#DB182C",""],["x20",5,"#DB182C",""]]],["ultimate","ultimate",[["ultimate",1,"#FFFFFF",""]]]],"human":[["superforms","superforms",[["buffed",1,"","classic_saga:46"],["fullpower",2,"","saiyan_saga:12"],["overdrive",3,"#FFFD99","frieza_saga:10"],["solaris",4,"#FFE11A","buu_saga:35"]]],["legendaryforms","legendaryforms",[["shiyoken",1,"#A10000",""],["shin_shiyoken",2,"#A10000",""],["chou_shiyoken",3,"#A10000",""]]],["androidforms","androidforms",[["androidbase",0,"",""],["superandroid",1,"","frieza_saga:10"],["fusedandroid",2,"","buu_saga:1"]]]],"saiyan":[["oozaru","superforms",[["oozaru",0,"",""],["goldenoozaru",7,"#FFD700","buu_saga:1"],["supersaiyan4",8,"#FFD700","buu_saga:35"],["supersaiyan5",9,"#DCE2EA",""]]],["ssgrades","superforms",[["supersaiyan",1,"#FFD700","classic_saga:46"],["supersaiyangrade2",2,"#FFD700","saiyan_saga:12"],["supersaiyangrade3",3,"#FFD700","frieza_saga:5"]]],["supersaiyan","superforms",[["supersaiyanmastered",4,"#FFD700","android_saga:4"],["supersaiyan2",5,"#FFD700","android_saga:15"],["supersaiyan3",6,"#FFD700","buu_saga:1"],["supersaiyan4",8,"#FFD633","buu_saga:35"],["supersaiyan5daima",9,"#DCE2EA",""]]],["legendaryforms","legendaryforms",[["ikari",1,"#40FF00",""],["ssjhybrid",2,"#40FF00",""],["ssjfullpower",3,"#40FF00",""]]]],"namekian":[["superforms","superforms",[["giant",1,"","classic_saga:46"],["fullpower",2,"","frieza_saga:10"],["supernamekian",3,"#7FFF00","buu_saga:35"]]],["primalnamekian","superforms",[["primalnamekian",4,"#4CFF00",""]]],["legendaryforms","legendaryforms",[["evilnamek",1,"#570B0B",""],["evilgiantnamek",2,"#570B0B",""],["buffednamek",3,"#570B0B",""]]]],"frostdemon":[["evolutionforms","superforms",[["second",1,"","classic_saga:46"],["third",2,"","saiyan_saga:12"],["final",3,"","frieza_saga:10"],["fullpower",4,"","buu_saga:1"],["fifth",5,"","buu_saga:35"]]],["legendaryforms","legendaryforms",[["mecha",1,"",""],["metal",2,"",""],["metalcore",3,"",""]]]],"majin":[["pureforms","superforms",[["kid",1,"","classic_saga:46"],["evil",2,"","frieza_saga:5"],["super",3,"","buu_saga:1"],["ultra",4,"","buu_saga:35"]]],["legendaryforms","legendaryforms",[["innocencedemon",1,"",""],["giantinnocencedemon",2,"",""],["superdemon",3,"",""]]]],"glind":[["superforms","superforms",[["buffed",1,"","classic_saga:46"],["outofcontrol",2,"#E01B1B","saiyan_saga:12"],["super",3,"#2F6BFF","frieza_saga:10"],["absorption",4,"#2F6BFF","buu_saga:1"],["trueform",5,"#7B2FBE","buu_saga:35"]]],["legendaryforms","legendaryforms",[["transcended",1,"#7B2FBE",""],["darkking",2,"#B00000",""],["timepower_darkking",3,"#AD0C0C",""],["timepower_realmoflight",3,"#FFF3C4",""]]]],"bioandroid":[["bioevolution","superforms",[["semiperfect",1,"","classic_saga:46"],["perfect",2,"#FFFF69","frieza_saga:5"],["superperfect",3,"#FFFF69","buu_saga:1"],["ultraperfect",4,"#FFFF69","buu_saga:35"]]],["legendaryforms","legendaryforms",[["xeno",1,"#2C0A4A",""],["xenofp",2,"#2C0A4A",""],["xenomax",3,"#2C0A4A",""]]]]};

    // DMZ form -> our form skill (30_forms.js) learned when its level is bought
    var FORM_SKILL = {
        "human.superforms.buffed": "human_max_power",
        "saiyan.oozaru.oozaru": "oozaru", "saiyan.oozaru.goldenoozaru": "golden_oozaru", "saiyan.oozaru.supersaiyan4": "super_saiyan_4",
        "saiyan.ssgrades.supersaiyan": "super_saiyan", "saiyan.ssgrades.supersaiyangrade2": "super_saiyan_g2", "saiyan.ssgrades.supersaiyangrade3": "super_saiyan_g3",
        "saiyan.supersaiyan.supersaiyan2": "super_saiyan_2", "saiyan.supersaiyan.supersaiyan3": "super_saiyan_3", "saiyan.supersaiyan.supersaiyan4": "super_saiyan_4",
        "namekian.superforms.giant": "namekian_giant", "namekian.superforms.supernamekian": "super_namekian",
        "frostdemon.evolutionforms.second": "frost_second_form", "frostdemon.evolutionforms.third": "frost_third_form", "frostdemon.evolutionforms.final": "frost_final_form",
        "frostdemon.evolutionforms.fullpower": "frost_full_power", "frostdemon.evolutionforms.fifth": "frost_fifth_form", "frostdemon.legendaryforms.metal": "frost_metal_form",
        "majin.pureforms.kid": "kid_majin", "majin.pureforms.evil": "evil_majin", "majin.pureforms.super": "super_majin",
        "bioandroid.bioevolution.semiperfect": "bio_semi_perfect", "bioandroid.bioevolution.perfect": "bio_perfect", "bioandroid.bioevolution.superperfect": "bio_super_perfect",
        "bioandroid.bioevolution.ultraperfect": "bio_ultra", "bioandroid.legendaryforms.xeno": "bio_xeno",
        "stack.kaioken.x2": "kaioken"
    };

    function isForm(s) { return FORM_SKILLS.indexOf(s) >= 0; }
    function isStack(s) { return STACK_SKILLS.indexOf(s) >= 0; }
    function isTechnique(s) { return KI.indexOf(s) >= 0 || STRIKE.indexOf(s) >= 0 || EVASION.indexOf(s) >= 0; }
    /** SkillsConfig.isSkillAllowedForRace */
    function allowed(skill, race, androidUpgraded) {
        var list = RACES[skill];
        if (!list || !list.length) return true;
        for (var i = 0; i < list.length; i++) {
            var a = String(list[i]).toLowerCase();
            if (a === "all" || a === race || (androidUpgraded && a === "android")) return true;
        }
        return false;
    }
    /** TP to go from `level` to level + 1 (-1 = can't be bought). */
    function cost(skill, level, race) {
        var list = isForm(skill) ? ((FORM_COSTS[race] || {})[skill] || []) : (COSTS[skill] || []);
        if (level < 0 || level >= list.length || list[level] === null || list[level] === undefined) return -1;
        return list[level] < 0 ? -1 : list[level];
    }
    function maxLevel(skill, race) {
        if (isForm(skill)) return ((FORM_COSTS[race] || {})[skill] || []).length;
        var n = (COSTS[skill] || []).length;
        return skill === "potentialunlock" ? Math.min(n, 30) : Math.min(n, 50);
    }
    /** Form skills every character of a race owns from the start (level 0). */
    function raceFormSkills(race, androidUpgraded) {
        var out = [];
        Object.keys(FORM_COSTS[race] || {}).forEach(function (s) {
            if (androidUpgraded && ANDROID_BLACKLIST.indexOf(s) >= 0) return;
            if (!androidUpgraded && s === "androidforms") return;
            out.push(s);
        });
        return out;
    }

    return { COSTS: COSTS, RACES: RACES, KI: KI, STRIKE: STRIKE, EVASION: EVASION, FORM_SKILLS: FORM_SKILLS, STACK_SKILLS: STACK_SKILLS,
        FORM_COSTS: FORM_COSTS, OFFERINGS: OFFERINGS, TECHNIQUES: TECHNIQUES, FORM_TREES: FORM_TREES, FORM_SKILL: FORM_SKILL,
        isForm: isForm, isStack: isStack, isTechnique: isTechnique, allowed: allowed, cost: cost, maxLevel: maxLevel, raceFormSkills: raceFormSkills };
})();
