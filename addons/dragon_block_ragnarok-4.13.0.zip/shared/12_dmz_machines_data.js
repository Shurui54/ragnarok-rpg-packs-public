// =====================================================================================
//  12_dmz_machines_data.js - DragonMine Z's machines: data and pure logic shared by the
//  server (scripts/58_dmz_machines.js) and the client (client/scripts/60_dmz_machines.js).
// =====================================================================================
//  Ported from DragonMine Z (GPL-3.0): PatternStationMenu / PatternRecipe /
//  DMZPatternRecipeProvider (6x6 dye grids), KikonoStationBlockEntity / KikonoRecipe /
//  DMZKikonoRecipeProvider, FuelGeneratorBlockEntity, EnergyCableBlockEntity,
//  GravityDeviceBlockEntity, server/util/GravityLogic + GeneralServerConfig.GravityConfig.
//  Screen layouts are the DMZ screens' pixel positions (textures/gui/screen/*.png).
//  ES5 only (it also runs in client scripts).
// =====================================================================================
var DMZ_MACH = (function () {
    // ---- Pattern Station recipes: 6x6 grids, '#' = the blank pattern, letters = dyes ------
    var DYES = { W: "minecraft:white_dye", S: "minecraft:light_gray_dye", G: "minecraft:gray_dye", K: "minecraft:black_dye",
        N: "minecraft:brown_dye", R: "minecraft:red_dye", O: "minecraft:orange_dye", Y: "minecraft:yellow_dye", L: "minecraft:lime_dye",
        E: "minecraft:green_dye", C: "minecraft:cyan_dye", A: "minecraft:light_blue_dye", B: "minecraft:blue_dye", U: "minecraft:purple_dye",
        M: "minecraft:magenta_dye", P: "minecraft:pink_dye", Q: "minecraft:gold_nugget" };
    var PATTERNS = {
        pattern_goku_kid: ["z", ["RR  RR","RRKKRR","KRRRYK","KR#RRK"," RRRR ","BBRRBB"]],
        pattern_goku1: ["z", ["OO  OO","OOBBOO","BOBBOB","BO#OOB"," OOOO ","BBBBBB"]],
        pattern_goku_super: ["s", ["OO  OO","OOAAOO","AWAAOA","AO#OOA"," OOOO ","AAAAAA"]],
        pattern_goku_gt: ["z", ["BB  BB","BBAABB","BABBAB","BB#BBB"," BBBB ","MSSSSM"]],
        pattern_goku_whis: ["s", ["OO  OO","OOBBOO","BWBBOB","BO#OOB"," OOOO ","BBBBBB"]],
        pattern_yardrat: ["z", ["WY  YW","WBYYBW","BWBBWB","YB#BBY"," BWWB ","NYBBYN"]],
        pattern_goten: ["z", ["OO  OO","OOKKOO","BOKKOB","BO#OOB"," OOOO ","BBKKBB"]],
        pattern_goten_super: ["s", ["LL  LL","LEEEEL","ELLLLE","EL#LLE"," LEEL ","SSEESS"]],
        pattern_gohan1: ["z", ["UU  UU","UUKKUU","KUUUUK","KU#UUK"," UUUU ","BBUUBB"]],
        pattern_gohan_super: ["s", ["UU  UU","UUKKUU","KUUUUK","KU#UUK"," UUUU ","GRRRRG"]],
        pattern_future_gohan: ["z", ["OO  OO","OOBBOO","BOBBOB","BO#OOB"," OBBO ","B OO B"]],
        pattern_trunks_kid: ["z", ["CC  CC","CCKKCC","KCCCCK","KC#CCK"," CKKC ","OKCCKO"]],
        pattern_tien: ["z", ["    EE","   EE ","  E#E ","REEEER","RRRRRR","  RR  "]],
        pattern_vegetto: ["z", ["BA  AB","BBOOBB","OBOOBO","BBO#BB"," BBBB "," BBBB "]],
        pattern_vegeta_buu: ["z", ["BB  BB","BBKKBB","KBBBBK","KB#BBK"," BBBB "," KBBK "]],
        pattern_black: ["s", ["GG  GG","GGKKGG","KGKKGK","KG#GGK"," GGGG ","KRRRRK"]],
        pattern_vegeta1: ["z", ["YY  YY","OWBBWO","BWWWWB","BW#WWB","BSNYSB","BONNOB"]],
        pattern_vegeta2: ["z", ["WS  SW","BWBBWB","BWWWWB","BW#WWB","BSNYSB","BKNNKB"]],
        pattern_vegeta_z: ["z", ["NO  ON","BWBBWB","AWWWWA","AW#WWA","BSNYSB","BKNNKB"]],
        pattern_vegeta_super: ["s", ["YS  SY","CWBBWC","CWWWWC","CW#WWC","CSNYSC","KKNNKK"]],
        pattern_vegeta_whis: ["s", ["YK  KY","KWKKWK","KWWWWK","KW#WWK"," SYYS "," YYYY "]],
        pattern_bardock1: ["z", ["EE  EE","WBWWBW","WBBBBW"," B#BB ","REEEER","R KK R"]],
        pattern_bardock2: ["s", ["YY  YY","WKWWKW","KKKKKK","BK#KKB","BSWWSB","AKKKKA"]],
        pattern_turles: ["z", ["SS  SS","UBWWBU","WBBBBW"," B#BB "," BSSB "," KWWK "]],
        pattern_gine: ["z", ["YY  YY"," WYYW ","CCCCCC"," S#SS ","MSYYSM","M    M"]],
        pattern_broly_z: ["z", ["N    N","NQ  QN"," QQQQ ","  #A  ","Q    Q","QA  AQ"]],
        pattern_broly_super: ["s", ["LE  EL","WKWWKW","WKKKKW"," K#KK "," KLLK "," WKKW "]],
        pattern_gas: ["s", ["RY  YR","YRYYRY","SRYYRS","SR#RRS"," RYYR ","  YY  "]],
        pattern_piccolo: ["z", ["UU  UU","UUKKUU","UUUUUU"," U#UU "," UUUU ","RBBBBR"]],
        pattern_great_saiyaman: ["z", ["ER  RE","EEKKEE","KELLEK","KE#LEK","KEEEEK","RRRRRR"]],
        pattern_shin: ["z", ["RR  RR","CKRRKC","CCWKCC","AC#KCA","ACCCCA","WOOOOW"]],
        pattern_zamasu: ["s", ["YG  GY","GKYYKG","UKGWKU","UK#GKU","UKKKKU"," AAAA "]],
        pattern_fusionzamasu: ["s", ["RG  GR","GKRRKG","KGRGGK","KG#GGK"," KRRK ","WRRRRW"]],
        pattern_hit: ["s", ["KU  UK","UUKKUU","CUUUUC","CU#UUC"," UUUU "," KYYK "]],
        pattern_beerus: ["s", [" WNNW ","WAWWAW"," WAAW "," S#AS "," SSSS ","Y    Y"]],
        pattern_whis: ["s", ["KWKKWK","MKYYKM","MKY#KM","MKYYKM","MKYYKM"," KYYK "]],
        pattern_gamma1: ["s", ["RR  RR","OOOOOO","KSOOSK","OO#ROO","OSOOSO","NNNNNN"]],
        pattern_gamma2: ["s", ["AA  AA","OOOOOO","KSOOSK","OO#BOO","OSOOSO","NNNNNN"]],
        pattern_a16: ["z", ["LE  EL","LLWKLL","ELLLRE","KL#LLK"," ELLE ","LE  EL"]],
        pattern_a17: ["z", ["KR  RK","KROORK","KKROKK","SK#KKS","SKKKKS","WK  KW"]],
        pattern_a17_super: ["s", ["EE  EE","EKKKKE","EKWWKE","ES#WSE"," SSSS ","EK  KE"]],
        pattern_a18: ["z", ["BB  BB","BBKKBB","KBBBBK","SB#BBS"," KKKK ","SK  KS"]],
        pattern_a18_kame: ["z", ["AA  AA","ABKKBA","BAAAAB"," A#AA "," AAAA "," BAAB "]],
        pattern_a18_tournament: ["z", ["KK  KK","KGKKGK","KKKKKK","SK#KKS"," GKKG ","SK  KS"]],
        pattern_a18_cell: ["z", ["SK  KS","SWAAWS","SKWWYK"," K#WK "," KWWK "," SWWS "]],
        pattern_orange_high: ["z", ["SK  KS","SKWWKS","SKWEKS","SK#KKS"," WWWW "," ROOR "]],
        pattern_videl: ["z", ["WW  WW","WWKKWW","KWWWWK"," W#WW ","NNWENN","NN  NN"]],
        pattern_age1000: ["z", ["RR  RR","RKLLKR","KLLLLK","KL#ELK"," ELLE ","KEEEEK"]],
        pattern_trunks_z: ["z", ["UU  UU","UUKKUU","UUKKUU","UU#KUU","UUKKUU","UU  UU"]],
        pattern_trunks_super: ["s", ["AR  RA","BARRAB","BAYYAB","BA#KAB","BBKKBB","AB  BA"]],
        pattern_vegeta_gt: ["z", ["RR  RR","RRKKRR","KRRRRK","KR#RRK"," RRRR "," KRRK "]],
        pattern_majin_buu: ["z", ["UU  UU","KUUUUK","KYKKYK","YK#KKY","YUUUUY","YUUUUY"]],
        pattern_gogeta: ["s", ["EY  YE","YEKKEY","KKYYKK"," K#KK "," GKKG "," G  G "]],
        pattern_granola: ["s", ["KW  WK","ESWWSE"," SWWS "," S#YS ","NNNNNN","  GG  "]],
        pattern_majin21: ["s", ["  NN  "," KWWK ","KKKKKK","KK#KKK","KK  KK","Y    Y"]],
        pattern_kale: ["s", ["RR  RR","RRRRRR","KRRRRK"," R#RR "," RRRR ","Y    Y"]],
        pattern_caulifla: ["s", [" PMMP "," MPPM "," K#KK ","K    K","K    K","K    K"]],
        pattern_kefla: ["s", ["MM  MM"," MMMM ","YM#MMY","YMMMMY"," MMMM ","  MM  "]],
        pattern_pride_troops: ["s", ["KR  RK","RRKKRR","RKRRKR","RR#RRR","WRRRRW"," KRRK "]],
        pattern_a13: ["z", ["YY  YY","YYKKYY","YYKKYR","YY#KYY","O    O","ON  NO"]],
        pattern_a14: ["z", ["    NN","   NN ","  N#  "," YN   ","NN   N","N    N"]],
        pattern_a20: ["z", ["OO  OO","OSOOSO","OWRRWO","OS#RSO","YKWWKY","Y    Y"]],
        pattern_capsule_corp: ["z", ["BB  BB","BKWWKB","BSWWSB","BK#SKB","BKSSKB","BB  BB"]],
        pattern_chaoz: ["z", ["EE  EE","EERREE","YEEEEY","YE#WEY","YERREY","S    S"]],
        pattern_cooler_soldier: ["z", [" W  WN","UWLLWU","KLLLLK","UL#LLU","UKSSKU","K    K"]],
        pattern_dragon_clan: ["s", ["MK  KM","MUUUUM","MU#UUM","MUUUUM"," UUUU "," RRRR "]],
        pattern_evil_buu: ["z", ["BY  YB","KBKKBK","KYBBYK"," B#BB ","YBBBBY","YB  BY"]],
        pattern_fighter: ["z", ["EE  EE","EEKKEE","EEEEEE","OE#EEO"," EEEE "," SSSS "]],
        pattern_gero: ["z", ["NW  WN","OOWWOO","OOOOOO","SO#OOS","WOOOOW","W OO W"]],
        pattern_great_saiyaman_2: ["z", ["EC  CE","CCUUCC","UCCCCU","UC#CCU"," WWOW "," RRRR "]],
        pattern_kibito: ["z", ["RR  RR","RRCCRR","ARRRRA","AR#RRA"," NRRN ","COOOOC"]],
        pattern_king_vegeta: ["z", ["PR  RP","WKBBKW","WWKKWW","SW#WWS","KKPPKK","KRRRRK"]],
        pattern_mighty_majin: ["z", [" NNNN ","YYYYYY","YEYYEY","YY#YYY","UUUUUU"," UUUU "]],
        pattern_mystic: ["z", ["WW  WW","WKCCKW","WCCKCW"," C#WC "," CCCC "," SSSS "]],
        pattern_raditz: ["z", ["NN  NN","NWKKWN","WBBBBW"," B#BB "," BNNB "," W  W "]],
        pattern_slug: ["z", [" OOOO ","YOOOOY","UYRRYU","OY#UYO","OYYYYO"," YUUY "]],
        pattern_super_buu: ["z", ["Y    Y","K    K","K #  K","K    K","K    K","Y    Y"]],
        pattern_vergil: ["s", ["BB  BB","BKBBKB","BBKKBB","BB#KBB","BBKKBB"," BBBB "]],
        pattern_warrior_clan: ["s", ["UU  UU"," UUUU "," UKKU "," U#UU "," UUUU "," SSSS "]],
        pattern_wonder_majin: ["z", [" YYYY "," KYYK ","  UU  ","WU#UUW"," UUUU "," UUUU "]],
        pattern_xeno_goku: ["s", ["RR  RR","RRKKRR","NRKKRN","NR#KRN","BRKKRB","BR  RB"]],
        pattern_xeno_goku_patreon: ["s", ["SS  SS","SSKKSS","GSKKSG","GS#KSG","WSKKSW","WS  SW"]]
    };
    var ARMOR_SETS = [
        ["goku_kid_armor","pattern_goku_kid",0],
        ["goku_armor","pattern_goku1",0],
        ["goku_super_armor","pattern_goku_super",0],
        ["goku_gt_armor","pattern_goku_gt",0],
        ["yardrat_armor","pattern_yardrat",0],
        ["goten_armor","pattern_goten",0],
        ["goten_super_armor","pattern_goten_super",0],
        ["gohan_super_armor","pattern_gohan_super",0],
        ["great_saiyaman_armor","pattern_great_saiyaman",1],
        ["future_gohan_armor","pattern_future_gohan",0],
        ["vegeta_saiyan_armor","pattern_vegeta1",0],
        ["vegeta_namek_armor","pattern_vegeta2",0],
        ["vegeta_z_armor","pattern_vegeta_z",0],
        ["vegeta_buu_armor","pattern_vegeta_buu",0],
        ["vegeta_super_armor","pattern_vegeta_super",0],
        ["vegetto_armor","pattern_vegetto",0],
        ["gogeta_armor","pattern_gogeta",0],
        ["piccolo_armor","pattern_piccolo",1],
        ["demon_gi_blue_armor","pattern_gohan1",0],
        ["bardock_dbz_armor","pattern_bardock1",0],
        ["bardock_super_armor","pattern_bardock2",0],
        ["turles_armor","pattern_turles",0],
        ["tien_armor","pattern_tien",0],
        ["trunks_z_armor","pattern_trunks_z",0],
        ["trunks_super_armor","pattern_trunks_super",0],
        ["trunks_kid_armor","pattern_trunks_kid",0],
        ["broly_z_armor","pattern_broly_z",1],
        ["broly_super_armor","pattern_broly_super",0],
        ["shin_armor","pattern_shin",0],
        ["blackgoku_armor","pattern_black",0],
        ["zamasu_armor","pattern_zamasu",0],
        ["fusion_zamasu_armor","pattern_fusionzamasu",0],
        ["hit_armor","pattern_hit",0],
        ["gas_armor","pattern_gas",0],
        ["majin_buu_armor","pattern_majin_buu",0],
        ["gamma1_armor","pattern_gamma1",0],
        ["gamma2_armor","pattern_gamma2",0],
        ["pride_troops_armor","pattern_pride_troops",0],
        ["a16_armor","pattern_a16",0],
        ["a17_armor","pattern_a17",0],
        ["a18_armor","pattern_a18",0],
        ["orange_high_armor","pattern_orange_high",0],
        ["granola_armor","pattern_granola",0],
        ["age1000_armor","pattern_age1000",0],
        ["gine_armor","pattern_gine",0],
        ["kale_armor","pattern_kale",0],
        ["caulifla_armor","pattern_caulifla",0],
        ["a17_super_armor","pattern_a17_super",0],
        ["a18_kame_armor","pattern_a18_kame",0],
        ["a18_tournament_armor","pattern_a18_tournament",0],
        ["a18_cell_armor","pattern_a18_cell",0],
        ["beerus_armor","pattern_beerus",0],
        ["goku_whis_armor","pattern_goku_whis",0],
        ["kefla_armor","pattern_kefla",0],
        ["majin21_armor","pattern_majin21",0],
        ["vegeta_whis_armor","pattern_vegeta_whis",0],
        ["vegeta_gt_armor","pattern_vegeta_gt",0],
        ["videl_armor","pattern_videl",0],
        ["whis_armor","pattern_whis",0],
        ["a13_armor","pattern_a13",0],
        ["a14_armor","pattern_a14",0],
        ["a20_armor","pattern_a20",1],
        ["capsule_corp_armor","pattern_capsule_corp",0],
        ["chaoz_armor","pattern_chaoz",1],
        ["cooler_soldier_armor","pattern_cooler_soldier",0],
        ["dragon_clan_armor","pattern_dragon_clan",0],
        ["evil_buu_armor","pattern_evil_buu",0],
        ["fighter_armor","pattern_fighter",0],
        ["gero_armor","pattern_gero",0],
        ["great_saiyaman_2_armor","pattern_great_saiyaman_2",1],
        ["kibito_armor","pattern_kibito",0],
        ["king_vegeta_armor","pattern_king_vegeta",0],
        ["mighty_majin_armor","pattern_mighty_majin",0],
        ["mystic_armor","pattern_mystic",0],
        ["raditz_armor","pattern_raditz",0],
        ["slug_armor","pattern_slug",1],
        ["super_buu_armor","pattern_super_buu",0],
        ["vergil_armor","pattern_vergil",0],
        ["warrior_clan_armor","pattern_warrior_clan",0],
        ["wonder_majin_armor","pattern_wonder_majin",0],
        ["xeno_goku_armor","pattern_xeno_goku",0],
        ["xeno_goku_patreon_armor","pattern_xeno_goku_patreon",0]
    ];

    // ---- machine numbers (DMZ block entities) ---------------------------------------------
    var GEN = { capacity: 1000, transfer: 20 };            // StarEnergyStorage(1000, 20), +1 FE on 3 of 4 burning ticks
    var KIKONO = { capacity: 2000, receive: 20 };          // StarEnergyStorage(2000, 20)
    var CABLE = { transfer: 15 };                          // StarEnergyStorage(150, 15)
    // GravityDevice: capacity/max gravity/room sizes come from the gravity config below; receives 256 FE/t
    var GRAVITY_RECEIVE = 256;

    // ---- screen layouts (the DMZ screens: imageWidth x imageHeight, slot x/y inside) --------
    var SCREEN = "dmzpack:textures/gui/screen/";
    function invSlots(x, y, hotY) {
        var out = [], r, c;
        for (r = 0; r < 3; r++) for (c = 0; c < 9; c++) out.push(["p" + (9 + r * 9 + c), x + c * 18, y + r * 18]);
        for (c = 0; c < 9; c++) out.push(["p" + c, x + c * 18, hotY]);
        return out;
    }
    var LAYOUT = {
        kikono_station: { tex: SCREEN + "kikono_station_gui.png", texW: 256, texH: 256, w: 176, h: 166,
            title: "block.dragonminez.kikono_station", invLabel: [8, 72], slots: (function () {
                var s = [], r, c;
                for (r = 0; r < 3; r++) for (c = 0; c < 3; c++) s.push(["m" + (r * 3 + c), 28 + c * 18, 17 + r * 18]);
                s.push(["m9", 89, 17]); s.push(["m10", 89, 53]); s.push(["m11", 141, 35]);
                return s.concat(invSlots(8, 84, 142));
            })() },
        fuel_generator: { tex: SCREEN + "fuel_generator_gui.png", texW: 256, texH: 256, w: 176, h: 166,
            title: "block.dragonminez.fuel_generator", invLabel: [8, 72], slots: [["m0", 80, 38]].concat(invSlots(8, 84, 142)) },
        gravity_device: { tex: SCREEN + "gravity_device_gui.png", texW: 256, texH: 256, w: 176, h: 166,
            title: "block.dragonminez.gravity_device", invLabel: [8, 72], slots: invSlots(8, 84, 142) },
        pattern_station: { tex: SCREEN + "pattern_station_gui.png", texW: 512, texH: 512, w: 298, h: 146,
            title: "container.dragonminez.pattern_station", invLabel: [130, 53], slots: (function () {
                var s = [["m0", 217, 24]], r, c;
                for (r = 0; r < 6; r++) for (c = 0; c < 6; c++) s.push(["m" + (1 + r * 6 + c), 8 + c * 18, 24 + r * 18]);
                return s.concat(invSlots(130, 64, 122));
            })() }
    };

    // ---- vanilla furnace fuel (ForgeHooks.getBurnTime for vanilla items) -----------------
    var FUEL = { "minecraft:lava_bucket": 20000, "minecraft:coal_block": 16000, "minecraft:dried_kelp_block": 4001, "minecraft:blaze_rod": 2400,
        "minecraft:coal": 1600, "minecraft:charcoal": 1600, "minecraft:bamboo_raft": 1200, "minecraft:bamboo_chest_raft": 1200,
        "minecraft:bamboo_mosaic": 300, "minecraft:bamboo_mosaic_stairs": 300, "minecraft:bamboo_mosaic_slab": 150, "minecraft:bamboo_block": 300,
        "minecraft:stripped_bamboo_block": 300, "minecraft:bookshelf": 300, "minecraft:chiseled_bookshelf": 300, "minecraft:chest": 300,
        "minecraft:trapped_chest": 300, "minecraft:crafting_table": 300, "minecraft:cartography_table": 300, "minecraft:fletching_table": 300,
        "minecraft:smithing_table": 300, "minecraft:loom": 300, "minecraft:barrel": 300, "minecraft:composter": 300, "minecraft:lectern": 300,
        "minecraft:note_block": 300, "minecraft:jukebox": 300, "minecraft:daylight_detector": 300, "minecraft:ladder": 300,
        "minecraft:bow": 300, "minecraft:crossbow": 300, "minecraft:fishing_rod": 300, "minecraft:mangrove_roots": 300,
        "minecraft:stick": 100, "minecraft:bowl": 100, "minecraft:dead_bush": 100, "minecraft:azalea": 100, "minecraft:flowering_azalea": 100,
        "minecraft:bamboo": 50, "minecraft:scaffolding": 50 };
    var NOT_FLAMMABLE = /crimson|warped/;
    function burnTime(id) {
        if (!id) return 0;
        if (FUEL[id]) return FUEL[id];
        if (id.indexOf("minecraft:") !== 0 || NOT_FLAMMABLE.test(id)) return 0;
        var n = id.substring(10);
        if (/_(log|wood|planks|fence|fence_gate|trapdoor|pressure_plate|stairs|banner)$/.test(n) && !/(stone|brick|copper|iron|quartz|purpur|prismarine|sandstone|deepslate|blackstone|tuff|mud|andesite|diorite|granite|nether|end_stone)/.test(n)) {
            if (/_banner$/.test(n)) return 300;
            if (/_stairs$|_fence$|_fence_gate$|_trapdoor$|_pressure_plate$/.test(n) && !/(oak|spruce|birch|jungle|acacia|dark_oak|mangrove|cherry|bamboo)/.test(n)) return 0;
            return 300;
        }
        if (/_slab$/.test(n) && /^(oak|spruce|birch|jungle|acacia|dark_oak|mangrove|cherry|bamboo)_/.test(n)) return 150;
        if (/_(door|sign)$/.test(n) && /^(oak|spruce|birch|jungle|acacia|dark_oak|mangrove|cherry|bamboo)_/.test(n)) return 200;
        if (/_hanging_sign$/.test(n) && /^(oak|spruce|birch|jungle|acacia|dark_oak|mangrove|cherry|bamboo)_/.test(n)) return 800;
        if (/_chest_boat$|_boat$/.test(n)) return 1200;
        if (/^wooden_(sword|shovel|pickaxe|axe|hoe)$/.test(n)) return 200;
        if (/_button$/.test(n) && /^(oak|spruce|birch|jungle|acacia|dark_oak|mangrove|cherry|bamboo)_/.test(n)) return 100;
        if (/_sapling$|^mangrove_propagule$/.test(n)) return 100;
        if (/_wool$/.test(n)) return 100;
        if (/_carpet$/.test(n) && n !== "moss_carpet") return 67;
        return 0;
    }
    /** What a burnt fuel leaves behind (Item.getCraftingRemainingItem). */
    function fuelRemainder(id) { return id === "minecraft:lava_bucket" ? "minecraft:bucket" : null; }

    // ---- recipes, resolved to full item ids by the caller (resolve("kikono_cloth") -> "ragnarok_rpg:item_0123") ----
    function shrink(rows) {
        var top = 0, bottom = rows.length - 1, left = 99, right = -1, i;
        function blank(r) { return r.replace(/ /g, "") === ""; }
        while (top <= bottom && blank(rows[top])) top++;
        while (bottom >= top && blank(rows[bottom])) bottom--;
        for (i = top; i <= bottom; i++) {
            if (blank(rows[i])) continue;
            left = Math.min(left, rows[i].length - rows[i].replace(/^ +/, "").length);
            right = Math.max(right, rows[i].replace(/ +$/, "").length);
        }
        var out = [];
        for (i = top; i <= bottom; i++) out.push(rows[i].substring(left, right));
        return out;
    }
    function patternRecipes(resolve) {
        var out = [];
        Object.keys(PATTERNS).forEach(function (id) {
            var p = PATTERNS[id], rows = shrink(p[1]), blankId = resolve(p[0] === "z" ? "blank_pattern_z" : "blank_pattern_super");
            var cells = [];
            rows.forEach(function (r) { for (var i = 0; i < r.length; i++) { var c = r.charAt(i); cells.push(c === " " ? "" : c === "#" ? blankId : DYES[c]); } });
            out.push({ result: resolve(id), w: rows[0].length, h: rows.length, cells: cells });
        });
        return out;
    }
    /** PatternRecipe.matches over a 6x6 grid of item ids ("" = empty): any offset, mirrored or not. */
    function matchPattern(grid, recipes) {
        for (var r = 0; r < recipes.length; r++) {
            var rec = recipes[r];
            for (var ox = 0; ox <= 6 - rec.w; ox++) for (var oy = 0; oy <= 6 - rec.h; oy++) {
                if (cellsMatch(grid, rec, ox, oy, true) || cellsMatch(grid, rec, ox, oy, false)) return rec;
            }
        }
        return null;
    }
    function cellsMatch(grid, rec, ox, oy, mirrored) {
        for (var i = 0; i < 6; i++) for (var j = 0; j < 6; j++) {
            var k = i - ox, l = j - oy, want = "";
            if (k >= 0 && l >= 0 && k < rec.w && l < rec.h) want = rec.cells[(mirrored ? rec.w - k - 1 : k) + l * rec.w];
            if ((grid[i + j * 6] || "") !== want) return false;
        }
        return true;
    }
    // Kikono: 3x3 inputs ("C" cloth, "S" string, "M" gete ingot, "K" kikono stick, "" empty) + pattern + template
    var PIECES = {
        helmet: { tpl: "minecraft:iron_helmet", grid: ["C", "S", "C", "S", "", "S", "", "", ""] },
        chestplate: { tpl: "minecraft:iron_chestplate", grid: ["C", "", "C", "S", "S", "S", "C", "C", "C"] },
        leggings: { tpl: "minecraft:iron_leggings", grid: ["C", "C", "C", "C", "", "C", "S", "", "S"] },
        boots: { tpl: "minecraft:iron_boots", grid: ["", "", "", "C", "", "C", "S", "", "S"] }
    };
    var GETE_TOOLS = [
        ["gete_pickaxe", "minecraft:netherite_pickaxe", ["M", "M", "M", "", "K", "", "", "K", ""]],
        ["gete_axe", "minecraft:netherite_axe", ["M", "M", "", "M", "K", "", "", "K", ""]],
        ["gete_shovel", "minecraft:netherite_shovel", ["", "M", "", "", "K", "", "", "K", ""]],
        ["gete_hoe", "minecraft:netherite_hoe", ["M", "M", "", "", "K", "", "", "K", ""]]
    ];
    function kikonoRecipes(resolve) {
        var key = { C: resolve("kikono_cloth"), S: resolve("kikono_string"), M: resolve("gete_ingot"), K: resolve("kikono_stick") };
        function inputs(g) { return g.map(function (c) { return c ? key[c] : ""; }); }
        var out = [];
        ARMOR_SETS.forEach(function (set) {
            var pieces = set[2] ? ["helmet", "chestplate", "leggings", "boots"] : ["chestplate", "leggings", "boots"];
            pieces.forEach(function (pc) {
                out.push({ result: resolve(set[0] + "_" + pc), pattern: resolve(set[1]), template: PIECES[pc].tpl, inputs: inputs(PIECES[pc].grid), time: 200, energy: 1000 });
            });
        });
        GETE_TOOLS.forEach(function (t) {
            out.push({ result: resolve(t[0]), pattern: resolve("pattern_gete"), template: t[1], inputs: inputs(t[2]), time: 100, energy: 1000 });
        });
        // DBR's own Kikono recipes (19e_outfit_patterns.js: the outfits and cosmetics), same grid letters
        EXTRA_KIKONO.forEach(function (r) {
            out.push({ result: resolve(r.result), pattern: resolve(r.pattern), template: r.template, inputs: inputs(r.grid), time: r.time || 200, energy: r.energy || 1000 });
        });
        return out;
    }
    var EXTRA_KIKONO = [];

    // ---- gravity (GeneralServerConfig.GravityConfig defaults; dimension ids are this game's) ----
    var GRAVITY_DEFAULTS = {
        enabled: true,
        gravityPerWorld: { "minecraft:overworld": 1.0, "minecraft:the_nether": 8.0, "minecraft:the_end": 20.0,
            "ragnarok_rpg:time_chamber": 10.0, "ragnarok_rpg:otherworld": 1.0, "ragnarok_rpg:namek": 1.0 },
        defaultWorldGravity: 1.0, npcGravityValue: 10.0, npcGravityRange: 100.0, machineGravityEnabled: true,
        resistanceStatDivisorRatio: 0.9, resistanceScale: 100.0, maxStatValue: 1000000,
        statReductionEnabled: true, affectedStats: ["STR", "SKP", "PWR", "DEF", "STM"],
        statReductionPerGravity: 0.01, minStatReduction: 0.0, maxStatReduction: 0.9,
        hardStopThreshold: 75.0, maxMovementPenalty: 0.95, maxAttackPenalty: 0.9, penaltyCurveFactor: 1.6,
        physicalEnabled: true, maxJumpPenalty: 0.95, extraFallPerGravity: 0.02, maxExtraFall: 0.6, maxFlyPenalty: 0.95,
        tpEnabled: true, gravityBonusEnabled: true, tpPeakMultiplier: 2.0, tpGravityBonusPerGravity: 0.025, masteryBonusPerGravity: 0.0025,
        tpIdealBaseDivisor: 2.0, gravitySensitivity: 1.0, tpComfortRatioLow: 0.5, tpIdealRatioLow: 0.75, tpIdealRatioHigh: 1.25,
        tpOverloadRatio: 2.0, tpOverloadHardRatio: 2.5, tpComfortMultiplier: 1.5, tpHeavyMultiplier: 2.5, maxWeightPenalty: 0.6,
        consumptionPerGravity: 0.04,
        deviceMinRoomSize: 5, deviceMaxRoomSize: 25, deviceMaxGravity: 1000, deviceEnergyCapacity: 20000, deviceEnergyPerGravityPerSecond: 1.0
    };
    function lerp(a, b, t) { return t <= 0 ? a : t >= 1 ? b : a + (b - a) * t; }
    // GravityLogic's curves, given the net ("penalization") gravity
    function penaltyFactor(c, net) { return net <= 0 ? 0 : Math.sqrt(net / 100) * c.penaltyCurveFactor; }
    function jumpFactor(c, net) {
        if (!c.physicalEnabled || net <= 0) return 1;
        if (net >= c.hardStopThreshold) return 1 - c.maxJumpPenalty;
        return 1 - Math.min(c.maxJumpPenalty, penaltyFactor(c, net));
    }
    function flyFactor(c, net) {
        if (!c.physicalEnabled || net <= 0) return 1;
        if (net >= c.hardStopThreshold) return 0;
        return 1 - Math.min(c.maxFlyPenalty, penaltyFactor(c, net));
    }
    function fallExtra(c, net) { return !c.physicalEnabled || net <= 0 ? 0 : Math.min(c.maxExtraFall, net * c.extraFallPerGravity); }
    function weightTpMultiplier(c, r) {
        if (r <= 0) return 1;
        if (c.tpComfortRatioLow > 0 && r < c.tpComfortRatioLow) return lerp(1, c.tpComfortMultiplier, r / c.tpComfortRatioLow);
        if (r < c.tpIdealRatioLow) return lerp(c.tpComfortMultiplier, c.tpPeakMultiplier, (r - c.tpComfortRatioLow) / (c.tpIdealRatioLow - c.tpComfortRatioLow));
        if (r <= c.tpIdealRatioHigh) return c.tpPeakMultiplier;
        if (r <= c.tpOverloadRatio) return lerp(c.tpPeakMultiplier, c.tpHeavyMultiplier, (r - c.tpIdealRatioHigh) / (c.tpOverloadRatio - c.tpIdealRatioHigh));
        if (r < c.tpOverloadHardRatio) return lerp(c.tpHeavyMultiplier, 1, (r - c.tpOverloadRatio) / (c.tpOverloadHardRatio - c.tpOverloadRatio));
        return 1;
    }
    function trainingZone(c, total, ideal, eff) {
        if (total <= 0 || ideal <= 0) return 0;
        var r = eff / ideal;
        return r < c.tpIdealRatioLow ? 1 : r <= c.tpIdealRatioHigh ? 2 : r < c.tpOverloadHardRatio ? 3 : 4;
    }

    return { DYES: DYES, PATTERNS: PATTERNS, ARMOR_SETS: ARMOR_SETS, GEN: GEN, KIKONO: KIKONO, CABLE: CABLE, GRAVITY_RECEIVE: GRAVITY_RECEIVE,
        LAYOUT: LAYOUT, burnTime: burnTime, fuelRemainder: fuelRemainder, shrink: shrink, patternRecipes: patternRecipes,
        matchPattern: matchPattern, kikonoRecipes: kikonoRecipes, PIECES: PIECES, EXTRA_KIKONO: EXTRA_KIKONO, GRAVITY_DEFAULTS: GRAVITY_DEFAULTS, penaltyFactor: penaltyFactor,
        jumpFactor: jumpFactor, flyFactor: flyFactor, fallExtra: fallExtra, weightTpMultiplier: weightTpMultiplier, trainingZone: trainingZone };
})();
