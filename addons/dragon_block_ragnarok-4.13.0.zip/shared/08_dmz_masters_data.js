// =====================================================================================
//  DragonMine Z's masters and quest NPCs (MastersEntity / AllMastersEntity, QuestNPCEntity,
//  NpcDispositionService, MasterServices, NPCActionC2S, TrainingConfig, TournamentDefinition),
//  shared by the server (scripts/60_npcs_dialogue.js, scripts/61_dmz_masters.js) and the
//  dialogue / skill-shop screens (client/scripts/52_masters_screen.js).
//
//  Keys are DMZ npc ids (the ids DMZ's lang lines and quests use: "karin", "kingkai"...).
//  npc = our NPC id (kept stable: quests (47_dmz_quests.js) and structures
//  (data/dmz_structures/*.json, 65_dmz_structures.js) place and look them up by it).
// =====================================================================================
var DMZ_MASTERS_DATA = (function () {
    // DMZ id -> { npc, model (geo/entity/master/<model>), idle, scale, name (entity.dragonminez.*), yaw (frozen) }
    var MASTERS = {
        roshi:        { npc: "master_roshi", model: "master_roshi", idle: "roshi_idle", name: "Master Roshi" },
        goku:         { npc: "master_goku", model: "master_goku", name: "Master Goku" },
        karin:        { npc: "korin", model: "master_karin", name: "Master Korin" },
        dende:        { npc: "dende", model: "master_dende", name: "Dende" },
        popo:         { npc: "mr_popo", model: "master_popo", name: "Mr. Popo" },
        gero:         { npc: "master_gero", model: "master_gero", name: "Dr. Gero" },
        guru:         { npc: "guru", model: "master_guru", idle: "guru_idle", name: "Grand Elder Guru", yaw: 180 },
        kingkai:      { npc: "king_kai", model: "master_kaiosama", name: "Master King Kai" },
        enma:         { npc: "enma", model: "master_enma", name: "King Yemma", yaw: 180 },
        baba:         { npc: "dmz_baba", model: "master_uranai", idle: "uranai_idle", name: "Fortuneteller Baba" },
        toribot:      { npc: "toribot", model: "master_toribot", idle: "tori_idle", name: "Toribot" },
        grandkai:     { npc: "grand_kai", model: "master_grandkai", name: "Grand Kai" },
        otherworld_announcer: { npc: "otherworld_announcer", model: "master_otherworld_announcer", name: "Otherworld Tournament Announcer" },
        world_tournament_announcer: { npc: "world_tournament_announcer", model: "master_world_tournament_announcer", name: "World Tournament Announcer" },
        baba_earth:   { npc: "fortune_teller_baba", model: "master_uranai", idle: "uranai_idle", name: "Fortuneteller Baba" },
        tien:         { npc: "master_tien", model: "master_tien", name: "Master Tien" },
        piccolo:      { npc: "master_piccolo", model: "master_piccolo", name: "Master Piccolo" },
        gohan:        { npc: "master_gohan", model: "master_gohan", name: "Master Gohan" },
        krillin:      { npc: "master_krillin", model: "master_krillin", name: "Master Krillin", scale: 0.8 },
        vegeta:       { npc: "master_vegeta", model: "master_vegeta", name: "Master Vegeta" },
        trunks:       { npc: "master_trunks", model: "master_trunks", name: "Master Trunks" },
        yamcha:       { npc: "master_yamcha", model: "master_yamcha", name: "Master Yamcha" },
        oldkai:       { npc: "old_kai", model: "master_oldkai", name: "Master Old Kai", scale: 0.8 },
        cell:         { npc: "master_cell", model: "master_cell", name: "Master Cell", scale: 1.1 },
        frieza:       { npc: "master_frieza", model: "master_frieza", name: "Master Frieza", scale: 0.9 },
        babidi:       { npc: "master_babidi", model: "master_babidi", name: "Master Babidi" },
        // DMZ ships no model for these two: MasterGlobalModel falls back to robotxv
        beerus:       { npc: "master_beerus", model: null, name: "Master Beerus" },
        whis:         { npc: "master_whis", model: null, name: "Master Whis" }
    };

    // QuestNPCEntity ids -> our NPC id and saga look ([model, texture])
    var QUEST_NPCS = {
        bulma:    { npc: "bulma", look: ["saga_bulma"], name: "Bulma" },
        mr_satan: { npc: "mr_satan", look: ["saga_mr_satan"], name: "Mr. Satan" },
        chi_chi:  { npc: "chi_chi", name: "Chi-Chi" },                 // defined in 65_dmz_structures.js
        chiaotzu: { npc: "chiaotzu", name: "Chiaotzu" },               // defined in 65_dmz_structures.js
        buu:      { npc: "dmz_quest_buu", name: "Majin Buu" },         // defined in 65_dmz_structures.js
        videl:    { npc: "videl", look: ["saga_videl"], name: "Videl" },
        shin:     { npc: "supreme_kai", look: ["saga_shin"], name: "Supreme Kai" },
        namek_elder: { npc: "namek_elder", look: null, name: "Namekian Elder" },
        hell_ogre: { npc: "hell_ogre", look: null, name: "Hell Ogre" }            // defined in 60_otherworld.js; talks about Janemba
    };

    // client/gui/dialogue/NpcDialogueContent.TEXT_MASTERS: no Skills / Train buttons
    var TEXT_MASTERS = ["karin", "guru", "dende", "enma", "baba", "popo", "gero", "toribot", "babidi", "grandkai",
        "otherworld_announcer", "world_tournament_announcer"];
    // NpcDispositionService
    var GOOD_MASTERS = ["goku", "gohan", "kingkai", "oldkai", "roshi", "krillin"];
    var EVIL_MASTERS = ["cell", "frieza"];
    var MASTER_IDS = ["baba", "baba_earth", "babidi", "beerus", "cell", "dende", "enma", "frieza", "gero", "gohan", "goku", "grandkai",
        "guru", "karin", "kingkai", "krillin", "oldkai", "otherworld_announcer", "piccolo", "popo", "roshi", "toribot", "trunks",
        "vegeta", "whis", "yamcha"];
    var GOOD_MIN = 61, EVIL_MAX = 40;
    // MasterServices constants
    var POTENTIAL_LEVEL = 10, GURU_MIN = 50, OLDKAI_MIN = 62, BABIDI_MAX = 38, BLESS_MIN = 61;
    // TrainingConfig masterName per minigame (MINIGAMES order)
    var MINIGAMES = { rhythm: "popo", control: "krillin", memory: "gohan", precision: "trunks", gravity: "vegeta" };
    // TournamentDefinition.HOST_NPCS
    var TOURNAMENT_HOSTS = { baba_earth: "baba", cell: "cell", otherworld_announcer: "otherworld", world_tournament_announcer: "budokai" };
    // HairManager.DEFAULT_HAIR_RACES (DMZ race ids)
    var HAIR_RACES = ["human", "saiyan", "majin"];
    // RaceCharacterConfig.hasSaiyanTail
    var TAIL_RACES = ["saiyan"];

    // GeneralServerConfig defaults (ticks)
    var CONFIG = {
        senzuGiftAmount: 5, senzuGiftCooldownTicks: 18000,
        kamiBlessTpMultiplier: 1.2, kamiBlessDurationSeconds: 300, kamiBlessCooldownSeconds: 1800,
        majinPower: 1.3, maxWeightRequestable: 100000,
        npcRange: 8, actionRateTicks: 4, weightRateTicks: 200, sparRateTicks: 40, dummyCleanupRange: 128
    };

    // Cooldowns (common/stats/character/Cooldowns.java) kept in player var "dmz_cd" {key: ticks left, -1 = forever}
    var CD = { SENZU_KARIN: "senzu_karin", KARIN_NIMBUS: "karin_nimbus", KAMI_BLESS: "kami_bless", OLDKAI_ZSWORD: "oldkai_zsword" };

    function band(a) { return a > 60 ? "GOOD" : a > 40 ? "NEUTRAL" : "EVIL"; }
    function norm(id) { var s = String(id || "").toLowerCase(); var i = s.indexOf(":"); return i >= 0 ? s.substring(i + 1) : s; }
    /** NpcDispositionService.masterAlignmentBlocker -> [langKey, arg] or null */
    function masterBlocker(alignment, id) {
        var k = norm(id);
        if (GOOD_MASTERS.indexOf(k) >= 0 && alignment < GOOD_MIN) return ["message.dragonminez.npc.master_alignment_too_low", GOOD_MIN];
        if (EVIL_MASTERS.indexOf(k) >= 0 && alignment > EVIL_MAX) return ["message.dragonminez.npc.master_alignment_too_high", EVIL_MAX];
        return null;
    }
    /** MasterServices.dislikes */
    function dislikes(id, alignment) {
        if (id === "guru") return alignment < GURU_MIN;
        if (id === "babidi") return alignment > BABIDI_MAX;
        return false;
    }
    function isMaster(id) { return Object.prototype.hasOwnProperty.call(MASTERS, id); }
    function isTextMaster(id) { return TEXT_MASTERS.indexOf(id) >= 0; }
    function minigameFor(id) { for (var g in MINIGAMES) if (MINIGAMES[g] === id) return g; return null; }

    // our NPC id -> DMZ id (masters and quest NPCs)
    var BY_NPC = {};
    Object.keys(MASTERS).forEach(function (k) { BY_NPC[MASTERS[k].npc] = k; });
    Object.keys(QUEST_NPCS).forEach(function (k) { BY_NPC[QUEST_NPCS[k].npc] = k; });

    return { MASTERS: MASTERS, QUEST_NPCS: QUEST_NPCS, TEXT_MASTERS: TEXT_MASTERS, GOOD_MASTERS: GOOD_MASTERS, EVIL_MASTERS: EVIL_MASTERS,
        MASTER_IDS: MASTER_IDS, GOOD_MIN: GOOD_MIN, EVIL_MAX: EVIL_MAX, POTENTIAL_LEVEL: POTENTIAL_LEVEL, GURU_MIN: GURU_MIN,
        OLDKAI_MIN: OLDKAI_MIN, BABIDI_MAX: BABIDI_MAX, BLESS_MIN: BLESS_MIN, MINIGAMES: MINIGAMES, TOURNAMENT_HOSTS: TOURNAMENT_HOSTS,
        HAIR_RACES: HAIR_RACES, TAIL_RACES: TAIL_RACES, CONFIG: CONFIG, CD: CD, BY_NPC: BY_NPC,
        band: band, norm: norm, masterBlocker: masterBlocker, dislikes: dislikes, isMaster: isMaster, isTextMaster: isTextMaster,
        minigameFor: minigameFor };
})();
