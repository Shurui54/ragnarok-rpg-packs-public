// =====================================================================================
//  34_dbr_form_combat.js - per-form auto dodge, damage mitigation and damage-taken stat buffs
// =====================================================================================
//  Port of DMZ Ragnarok's form combat system (FormCombatData / FormCombatHandler / DodgeAnimator,
//  GPL-3.0, see NOTICE.md). Each form can carry `combat` (shared/07_dmz_forms_data.js cleanCombat,
//  edited in the form editor's Dodge and Buffs tabs):
//    dodgePhysical / dodgeMeleeSkill / dodgeEnergySkill   % chance to avoid a hit outright, by damage
//        category: a strike skill (kind "strike") uses the melee-skill chance, a ki attack (kind "ki")
//        the energy chance, any other hit with a living attacker (fists, mobs, weapons, arrows) the
//        physical chance; hits without an attacker (fall, fire, void...) are never dodged.
//    damageMitigation   % of a hit that is not dodged taken off, after DMZ's own defence and the guard.
//    statGainPercent {STR, SKP, RES, VIT, PWR, ENE}   every hit taken adds this % of the stat's BASE
//        value (bought + race + class points, snapshotted when the player transforms) as a buff,
//    maxBonusPercent    up to this % of the base per stat (100 = the stat can at most double).
//  The buff is DMZ's flat BonusStats bucket (BonusStats "*" with applyMultipliers = false: base x
//  (1 + pct) - base, not amplified by form multipliers; RES goes to DEF and STM), kept in the player
//  var dbr_form_buff {STR..ENE flat amounts, pct {...}} that dmzView / DMZ_F read (shared/02). It
//  never touches the stats themselves, so stat caps, prices, level and prestige rules are unaffected.
//  It lasts while a form with combat settings is active and is cleared when the player leaves it
//  (and on join), like FormCombatHandler.clear.
//
//  With a base form and a stack form both configured, the layers combine as DMZ Ragnarok does:
//  dodge and mitigation as independent chances (union), gains added up, the larger cap.
//
//  A dodge cancels the hit at its very start (the engine's damageAttempt event = LivingAttackEvent):
//  no damage, hurt sound, flinch or knockback. Everyone nearby hears the sweep whoosh and sees the
//  upper body twist 45 degrees to a random side and back over half a second (client/scripts/40_animator.js
//  reads the shared "dbr_dodge" value).
// =====================================================================================
var DBR_FORM_COMBAT = (function () {
    var STATS = ["STR", "SKP", "RES", "VIT", "PWR", "ENE"];
    var ST = {};              // uuid -> { key, base {STR..}, acc {STR: pct}, rev }
    var dodgeN = 0;

    function num(v) { v = Number(v); return isNaN(v) || !isFinite(v) ? 0 : v; }
    function union(a, b) { return (1 - (1 - a / 100) * (1 - b / 100)) * 100; }

    /** The active form layers (base form, stack form) that have combat settings. */
    function layers(p) {
        var out = [];
        if (typeof DMZ_TF === "undefined" || !p.getVar("dmz_created", 0)) return out;
        var f = DMZ_TF.activeForm(p), s = DMZ_TF.activeStack(p);
        if (f && f.combat) out.push(f);
        if (s && s.combat) out.push(s);
        return out;
    }
    function aggregate(list) {
        var a = { dodgePhysical: 0, dodgeMelee: 0, dodgeEnergy: 0, mitigation: 0, cap: 0, gain: {}, anyGain: false };
        list.forEach(function (f) {
            var c = f.combat;
            a.dodgePhysical = union(a.dodgePhysical, num(c.dodgePhysical));
            a.dodgeMelee = union(a.dodgeMelee, num(c.dodgeMeleeSkill));
            a.dodgeEnergy = union(a.dodgeEnergy, num(c.dodgeEnergySkill));
            a.mitigation = union(a.mitigation, num(c.damageMitigation));
            a.cap = Math.max(a.cap, c.maxBonusPercent === undefined ? 100 : num(c.maxBonusPercent));
            var g = c.statGainPercent || {};
            STATS.forEach(function (k) { var v = num(g[k]); if (v) { a.gain[k] = (a.gain[k] || 0) + v; a.anyGain = true; } });
        });
        return a;
    }
    function formsRev() { try { return DMZ_FORMS.applied().rev; } catch (e) { return 0; } }

    // ---- the buff var ------------------------------------------------------------------
    function write(p, s) {
        var out = null;
        if (s) {
            var pct = {}, any = false;
            out = {};
            STATS.forEach(function (k) {
                var a = num(s.acc[k]), b = num(s.base[k]);
                if (a > 0 && b > 0) { out[k] = Math.round(b * a / 100 * 1000) / 1000; pct[k] = Math.round(a * 1000) / 1000; any = true; }
            });
            out.pct = pct;
            if (!any) out = null;
        }
        var cur = p.getVar("dbr_form_buff", null);
        if (JSON.stringify(cur) === JSON.stringify(out)) return false;
        p.setVar("dbr_form_buff", out);
        p.refreshStats();
        // max health follows VIT at once (09_dmz_stats.js refreshes it every second too)
        try { var hp = DMZ_F.maxHealth(dmzView(p)); if (Math.abs(p.maxHealth - hp) > 0.01) p.maxHealth = hp; } catch (e) { }
        return true;
    }
    function clear(p) {
        delete ST[p.uuid];
        write(p, null);
    }

    /**
     * FormCombatHandler.onPlayerTick's edge logic, run when needed: no configured layer -> clear; the transform edge
     * (none -> some) snapshots each stat's base; a layer or config change keeps the buff but holds it to the new cap.
     */
    function sync(p) {
        var list = layers(p), s = ST[p.uuid];
        if (!list.length) { if (s || p.getVar("dbr_form_buff", null)) clear(p); return null; }
        var agg = aggregate(list), key = list.map(function (f) { return f.race + "|" + f.key; }).join(","), rev = formsRev();
        if (!s) {
            s = ST[p.uuid] = { key: key, base: {}, acc: {}, rev: rev };
            STATS.forEach(function (k) { s.base[k] = Math.max(0, num(p.baseStat(DMZ_DATA.STAT_IDS[k]))); });
        } else if (s.key !== key || s.rev !== rev) {
            s.key = key; s.rev = rev;
            var changed = false;
            STATS.forEach(function (k) {
                var want = agg.gain[k] ? Math.min(num(s.acc[k]), agg.cap) : 0;
                if (want !== num(s.acc[k])) { if (want > 0) s.acc[k] = want; else delete s.acc[k]; changed = true; }
            });
            if (changed) write(p, s);
        }
        return agg;
    }

    // ---- dodge (FormCombatHandler.onLivingAttack) ----------------------------------------
    function category(e) {
        if (e.kind === "ki") return "energy";
        if (e.kind === "strike") return "melee";
        return e.attacker ? "physical" : null;           // the engine only hands over living attackers
    }
    RPG.on("damageAttempt", function (e) {
        var t = e.target;
        if (!t || !t.isPlayer() || e.isCancelled()) return;
        var p = t.asPlayer(), agg = sync(p);
        if (!agg) return;
        var cat = category(e);
        var chance = cat === "physical" ? agg.dodgePhysical : cat === "melee" ? agg.dodgeMelee : cat === "energy" ? agg.dodgeEnergy : 0;
        if (!(chance > 0) || Math.random() * 100 >= chance) return;
        e.cancel();
        // cosmetic twist to a random side, rolled here so every viewer twists the same way
        p.setShared("dbr_dodge", { n: ++dodgeN, l: Math.random() < 0.5 ? 1 : 0 });
        // the whoosh, heard by everyone nearby including the dodger
        sfx(p, "minecraft:entity.player.attack.sweep", 0.9, 1.3 + Math.random() * 0.2);
    });

    // ---- mitigation and the damage-taken buff (after DMZ's defence and the guard: 09, 11 load first) ----
    RPG.on("damageFinal", function (e) {
        var t = e.target;
        if (!t || !t.isPlayer() || e.isCancelled()) return;
        var p = t.asPlayer(), agg = sync(p);
        if (!agg) return;
        if (agg.mitigation > 0 && e.amount > 0) e.amount = Math.max(0, e.amount * (1 - agg.mitigation / 100));
        // every hit that lands counts, also one DMZ's defence soaked up completely (a strong fighter's case)
        if (!agg.anyGain || !(agg.cap > 0)) return;
        var s = ST[p.uuid], changed = false;
        STATS.forEach(function (k) {
            var g = agg.gain[k];
            if (!g) return;
            var next = Math.min(agg.cap, num(s.acc[k]) + g);
            if (next !== num(s.acc[k])) { s.acc[k] = next; changed = true; }
        });
        if (changed) write(p, s);
    });

    // leaving the form (detransform, descend to an unconfigured form, death...) clears the buff
    RPG.every(10, function () {
        RPG.server.players().forEach(function (p) { if (ST[p.uuid] || p.getVar("dbr_form_buff", null)) sync(p); });
    });
    RPG.on("playerJoin", function (p) { clear(p); });
    RPG.on("playerLeave", function (p) { delete ST[p.uuid]; });

    return {
        /** the combined combat settings of the player's active layers, or null */
        settings: function (p) { var l = layers(p); return l.length ? aggregate(l) : null; },
        /** {stat: pct of base} the player has built up */
        buff: function (p) { var b = p.getVar("dbr_form_buff", null); return b && b.pct ? b.pct : {}; },
        clear: clear
    };
})();
