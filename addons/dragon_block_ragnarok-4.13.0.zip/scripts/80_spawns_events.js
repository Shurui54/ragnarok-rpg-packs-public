// =====================================================================================
//  80_spawns_events.js - where enemies appear, and random world events
// =====================================================================================
//  Spawns are checked every `interval` ticks per player and appear minDistance-maxDistance
//  blocks away. Pick the body with mob: (RPG.mobs), entity: (vanilla), boss: or npc:.
//    dimensions: ["minecraft:overworld", "ragnarok_rpg:namek"]
//    biomes: ["minecraft:plains", "#minecraft:is_forest"]   ids or #tags
//    time: "day" | "night" | "any"     light: "dark" | "bright" | "any"
//    group: [min, max]   maxNearby   minLevel / maxLevel (player level)
//    levelScaling: 0.05  -> +5% health & damage per player level
//    condition(player) / onSpawn(entity, player)
// =====================================================================================

var OVERWORLD = ["minecraft:overworld"];

// ---- DragonMine Z natural spawns (forge/biome_modifier/*.json, MainEntities spawn rules) ----------
// DMZ has no level gates. Saga enemies spawn only in the dark (block light <= 7) and pass 35% of the time;
// wild enemies (bandits, Red Ribbon, robots, sabertooths) need open sky. "rocky" is DMZ's own biome:
// here badlands and windswept/stony hills stand in for it.
var ROCKY = ["#minecraft:is_badlands", "minecraft:windswept_gravelly_hills", "minecraft:windswept_hills", "minecraft:stony_peaks", "minecraft:stony_shore"];
var VILLAGE_LAND = ["minecraft:plains", "minecraft:sunflower_plains", "#minecraft:is_savanna", "minecraft:snowy_plains"];

// saibamans.json: saga_saibaman1..6 weights 80/70/60/45/35/25, groups 2-4 / 2-4 / 1-3 / 1-3 / 1-2 / 1-2
[["saibaman", 80, [2, 4]], ["saibaman_2", 70, [2, 4]], ["saibaman_3", 60, [1, 3]], ["saibaman_4", 45, [1, 3]], ["saibaman_5", 35, [1, 2]], ["saibaman_6", 25, [1, 2]]]
    .forEach((s) => {
        RPG.spawns.define("dmz_" + s[0], {
            mob: s[0], dimensions: OVERWORLD, biomes: ROCKY, light: "dark", interval: 400, chance: 0.35 * s[1] / 100,
            group: s[2], maxNearby: 8,
            onSpawn(entity) { RPG.world.particle(entity.dimension, "minecraft:composter", entity.x, entity.y, entity.z, 10, 0.3, 0.1); }
        });
    });
// biomans.json: #forge:is_snowy, weight 60, 2-4
RPG.spawns.define("dmz_biomans", {
    mob: "bioman", dimensions: OVERWORLD, biomes: ["#forge:is_snowy", "minecraft:snowy_plains", "minecraft:snowy_taiga", "minecraft:ice_spikes", "minecraft:snowy_slopes"],
    light: "dark", interval: 400, chance: 0.35 * 0.6, group: [2, 4], maxNearby: 6
});
// robots.json (villages: savanna/plains/snowy): red_ribbon_soldier 30 (1-3), robot3 10, robot2 10, robot1 5
[["red_ribbon_soldier", 30, [1, 3]], ["rr_robot_3", 10, [1, 1]], ["rr_robot_2", 10, [1, 1]], ["rr_robot_1", 5, [1, 1]]].forEach((s) => {
    RPG.spawns.define("dmz_" + s[0], { mob: s[0], dimensions: OVERWORLD, biomes: VILLAGE_LAND, light: "dark", interval: 400, chance: s[1] / 100, group: s[2], maxNearby: 6 });
});
// sabertooth.json: sabertooth 18 (1-2), bandit 12 (1-2) in savanna, plains, forest, jungle
var SABER_LAND = ["#minecraft:is_savanna", "minecraft:plains", "#minecraft:is_forest", "#minecraft:is_jungle", "minecraft:dark_forest"];
RPG.spawns.define("dmz_sabertooth", { mob: "sabertooth", dimensions: OVERWORLD, biomes: SABER_LAND, interval: 400, chance: 0.18, group: [1, 2], maxNearby: 4 });
RPG.spawns.define("dmz_bandit", { mob: "bandit", dimensions: OVERWORLD, biomes: SABER_LAND, light: "dark", interval: 400, chance: 0.12, group: [1, 2], maxNearby: 4 });

// ---- Animals (dinosaurs.json, giant_turtle.json, giant_fish.json) ------------------------
var DINO_LAND = ["#minecraft:is_savanna", "#minecraft:is_badlands", "#minecraft:is_mountain", "#minecraft:is_hill"].concat(ROCKY);
RPG.spawns.define("dmz_dino1", { mob: "dinosaur", biomes: DINO_LAND, light: "dark", interval: 400, chance: 0.35 * 0.22, group: [1, 2], maxNearby: 4 });
RPG.spawns.define("dmz_dino2", { mob: "triceratops", biomes: DINO_LAND, light: "dark", interval: 400, chance: 0.35 * 0.18, group: [1, 2], maxNearby: 4 });
RPG.spawns.define("dmz_dino3", { mob: "tyrannosaurus", biomes: DINO_LAND, light: "dark", interval: 400, chance: 0.35 * 0.14, group: [1, 2], maxNearby: 2 });
RPG.spawns.define("dmz_dinokid", { mob: "baby_dino", biomes: DINO_LAND, light: "dark", interval: 400, chance: 0.35 * 0.10, group: [1, 3], maxNearby: 4 });
RPG.spawns.define("dmz_giant_turtle", { mob: "giant_turtle", biomes: ["#minecraft:is_beach"], interval: 600, chance: 0.08, group: [1, 2], maxNearby: 3 });
RPG.spawns.define("dmz_giant_fish", { mob: "giant_fish", biomes: ["#minecraft:is_ocean", "#minecraft:is_beach", "#minecraft:is_river"], interval: 600, chance: 0.10, group: [1, 2], maxNearby: 3 });

// ---- Namek and the Other World (85_world.js) ----------------------------------------------
// namek_soldiers.json: saga_friezasoldier01/02/03 weight 2 (1) each; namek_fauna.json: frogs 2 (1-3) + Ginyu frog 5 (1)
[["frieza_soldier", "dmz_namek_soldier1"], ["frieza_soldier_heavy", "dmz_namek_soldier2"], ["frieza_soldier_elite", "dmz_namek_soldier3"]].forEach((s) => {
    RPG.spawns.define(s[1], { mob: s[0], dimensions: ["ragnarok_rpg:namek"], light: "dark", interval: 400, chance: 0.35 * 0.1, group: [1, 1], maxNearby: 3 });
});
RPG.spawns.define("dmz_namek_frogs", { mob: "namek_frog", dimensions: ["ragnarok_rpg:namek"], interval: 400, chance: 0.1, group: [1, 3], maxNearby: 5 });
RPG.spawns.define("dmz_namek_frog_ginyu", { mob: "namek_frog_ginyu", dimensions: ["ragnarok_rpg:namek"], interval: 400, chance: 0.1, group: [1, 1], maxNearby: 2 });
RPG.spawns.define("namek_warriors", {
    mob: "namek_warrior", dimensions: ["ragnarok_rpg:namek"], interval: 600, chance: 0.2, group: [1, 2], maxNearby: 3
});
// hell_ogres.json: red 60 (1-2), blue 40 (1-2), only on the hell floor (y < 96), fewer than 4 ogres within 48
RPG.spawns.define("dmz_ogre_red", { mob: "ogre_red", dimensions: ["ragnarok_rpg:otherworld"], interval: 400, chance: 0.6, group: [1, 2], maxNearby: 3, countRange: 48,
    condition(p) { return p.y < 96; } });
RPG.spawns.define("dmz_ogre_blue", { mob: "ogre", dimensions: ["ragnarok_rpg:otherworld"], interval: 400, chance: 0.4, group: [1, 2], maxNearby: 3, countRange: 48,
    condition(p) { return p.y < 96; } });

// =====================================================================================
//  No timed random events: DragonMine Z has none. Its world events are the raid sites and the raids they
//  start (92_dmz_raids.js), the Hell stampede, Halloween clones and Gete raids (70_dmz_events.js), world bosses
//  in their lairs and the Dragon Balls. The Saibamen / Frieza Force / Red Ribbon "invasions", radar pings and
//  Double TP Hour that used to roll here were DBR's own and are gone (the mobs stay: natural spawns above, raids,
//  quests, structures). Event ids were never saved anywhere, so old worlds lose nothing.
// =====================================================================================

// Spawns `count` mobs in a ring around a player.
function spawnAround(player, mobId, count) {
    for (let i = 0; i < count; i++) {
        let angle = Math.random() * Math.PI * 2;
        let dist = RPG.random(6, 12);
        RPG.world.spawnMob(player.dimension, mobId, player.x + Math.cos(angle) * dist, player.y, player.z + Math.sin(angle) * dist);
    }
}

// World bosses are not a random event in DragonMine Z: they live in lairs (77_dmz_world_bosses.js).
