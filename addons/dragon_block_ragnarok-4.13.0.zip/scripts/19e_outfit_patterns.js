// =====================================================================================
//  19e_outfit_patterns.js - the outfits and cosmetics sewn the DragonMine Z way
// =====================================================================================
//  DragonMine Z makes every armour from a pattern (DMZPatternRecipeProvider, DMZKikonoRecipeProvider):
//    Pattern Station  a blank pattern (Z or Super) and a 6x6 grid of dyes -> "<Group> Pattern (<Character>)"
//    Kikono Station   that pattern + an iron armour piece as template + Kikono cloth / string in the
//                     piece's grid, 1000 FE from a Fuel Generator, 10 s -> the piece (pattern and template
//                     are used up)
//  Every outfit of the Tailor's Catalogue (19_outfits.js) and every cosmetic (19c_cosmetics.js) gets the
//  same: one pattern per outfit (all its pieces) or cosmetic, with a dye grid in the shape of one of DMZ's
//  grids, coloured like the outfit (19d_outfit_patterns_data.js, made by
//  docs/dmz-spec/tools/make_outfit_patterns.py; icons are DMZ's pattern art recoloured). Outfit pieces use
//  DMZ's own templates and grids per slot; cosmetics use a leather cap (head / face) or tunic (body).
//  The Fabric Core catalogue stays as the other way in (Core Ore, overworld); this is the Namek / Kikono way.
//
//  This file sews the outfits, 19f_cosmetic_patterns.js the cosmetics (two scripts: each stays well inside a
//  script's time budget on a busy server). 19g_machine_recipe_viewer.js shows every machine recipe in the viewer.
// =====================================================================================

/** Defines the "outfit" or "cosmetic" patterns of OUTFIT_PATTERN_DATA and their Kikono recipes; returns the piece count. */
function outfitPatternsDefine(kind) {
    let D = DMZ_MACH;
    let SLOT_PIECE = { head: "helmet", chest: "chestplate", legs: "leggings", feet: "boots" };
    // cosmetics (no armour slot): their own grids, same letters (C cloth, S string)
    let COSMETIC = {
        head: { tpl: "minecraft:leather_helmet", grid: ["S", "C", "S", "", "", "", "", "", ""] },
        face: { tpl: "minecraft:leather_helmet", grid: ["", "", "", "S", "C", "S", "", "", ""] },
        body: { tpl: "minecraft:leather_chestplate", grid: ["C", "", "C", "S", "C", "S", "", "S", ""] }
    };
    let slotOf = {};
    if (kind === "outfit") NB_ARMOR_DATA.forEach((r) => { slotOf[r[0]] = r[2]; });
    else NB_COSMETIC_DATA.forEach((r) => { slotOf[r[0]] = r[2]; });
    let prefix = kind + "_pattern_", lore = ["&7Use in a Kikono Station"], pieces = 0;
    OUTFIT_PATTERN_DATA.forEach((row) => {
        let id = row[0];
        if (id.indexOf(prefix) !== 0) return;
        RPG.items.define(id, { name: row[1], model: "dbr:rpg/item/patterns/" + id, type: "material", maxStack: 64, tab: "Tailor's Patterns", lore: lore });
        D.PATTERNS[id] = [row[2], row[3]];
        row[4].forEach((piece) => {
            let slot = slotOf[piece];
            if (!slot) return;
            let pc = kind === "outfit" ? D.PIECES[SLOT_PIECE[slot]] : COSMETIC[slot];
            D.EXTRA_KIKONO.push({ result: piece, pattern: id, template: pc.tpl, grid: pc.grid });
            pieces++;
        });
    });
    return pieces;
}
var OUTFIT_PATTERN_PIECES = outfitPatternsDefine("outfit");
