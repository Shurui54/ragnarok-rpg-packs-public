// =====================================================================================
//  77_dmz_world_bosses_ai.js - each DragonMine Z world boss's own fight
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): common/init/entities/worldboss/AllWorldBossesEntity.java (JanembaFat, SuperJanemba,
//  MiniJanemba, Turles, MetalCoolerCore + SupernovaClash, MetalCooler, MetalCoolerCopy, Tamagami 1/2/3 + TamagamiHammer /
//  TamagamiPillar, Gomah), GeteStarEntities (Bind, Scrap), StrikeCombos.MeteorBurstCombo (Turles). Every timing, radius,
//  damage ratio and cooldown is DMZ's. The saga brain (76_dmz_saga_ai.js) runs the bosses' ki skills, combos, evasions
//  and zanzokens from their DMZ kits (77_dmz_world_bosses.js BODIES); the abilities here run on top of it, holding the
//  brain while they play (setCombatFrozen). Ground warnings, lanes, shockwaves, the hammer, pillars, cables and the
//  power clash are drawn by client/scripts/68_dmz_worldboss.js ("dmz_wb_fx").
// =====================================================================================
(function () {
    var W = DMZ_WB.API, AI = DMZ_WB.AI;
    var D2R = Math.PI / 180;

    // ---- helpers -----------------------------------------------------------------------------
    function now() { return W.now(); }
    function alive(e) { return W.alive(e); }
    function rnd() { return Math.random(); }
    function hex(c) { return "#" + ("000000" + (c >>> 0).toString(16)).slice(-6).toUpperCase(); }
    function target(R) { var t = R.m.target; return t && alive(t) ? t : null; }
    function yawTo(R, x, z) { var dx = x - R.m.x, dz = z - R.m.z; if (dx * dx + dz * dz < 1e-6) return R.m.yaw; return Math.atan2(dz, dx) / D2R - 90; }
    function dirYaw(yaw) { return { x: -Math.sin(yaw * D2R), y: 0, z: Math.cos(yaw * D2R) }; }
    function face(R, yaw) { R.m.setRotation(yaw, 0); R.yaw = yaw; }
    function tp(R, x, y, z) { R.m.teleport(x, y, z); }
    function snd(R, id, vol, pitch, at) { var a = at || R.m; RPG.world.sound(R.m.dimension, id.indexOf(":") < 0 ? "dmzpack:" + id : id, a.x, a.y, a.z, vol, pitch); }
    function part(R, type, x, y, z, n, spread, speed) { RPG.world.particle(R.m.dimension, type, x, y, z, n, spread, speed || 0); }
    function ground(R, x, z, fromY) { return W.groundHeight(R.m.dimension, x, z, fromY); }
    function center(e) { return { x: e.x, y: e.y + (e.height || 1.8) * 0.5, z: e.z }; }
    function pcd(R, ticks) { return R.body.powered ? Math.round(ticks * 0.75) : ticks; }      // Tamagami.cooldown (POWERED_COOLDOWN)
    function isPlayerLike(e) { return e && e.isPlayer(); }
    /** canStrike: alive, not this boss's side, players not in creative / spectator */
    function canStrike(R, e) {
        if (!e || !alive(e) || e.uuid === R.m.uuid) return false;
        if (W.factionKey(e)) return false;
        if (e.isPlayer()) { var g = W.gm(e.asPlayer()); if (g === "creative" || g === "spectator") return false; }
        return true;
    }
    function victims(R, x, y, z, r) { return RPG.world.entitiesNear(R.m.dimension, x, y, z, r + 2).filter(function (e) { return canStrike(R, e); }); }
    function hit(R, e, dmg, kind) { if (dmg > 0) e.damageFrom(dmg, R.m, { kind: kind || "melee", ignoreIFrames: true, knockback: 0 }); }
    function kb(e, x, y, z) { try { e.push(x, y, z); } catch (er) { } }
    /** eligible players within r of the anchor (Tamagami / Gomah / announcements) */
    function nearAnchor(R, r) {
        var h = W.home(R);
        return RPG.server.players().filter(function (p) { return p.dimension === R.m.dimension && W.eligible(p) && Math.pow(p.x - h.x, 2) + Math.pow(p.y - h.y, 2) + Math.pow(p.z - h.z, 2) < r * r; });
    }
    function playersNear(R, r) { return RPG.server.players().filter(function (p) { return p.dimension === R.m.dimension && W.eligible(p) && p.distanceTo(R.m) <= r; }); }
    function announce(list, key, args, color) { list.forEach(function (p) { W.bar(p, key, args || [], color || "#FFFFFF"); }); }
    function chatAll(list, key, args, color) { list.forEach(function (p) { W.chat(p, key, args || [], color); }); }
    function bossName(R) { return { key: "entity.dragonminez." + R.body.lang, fallback: R.body.name }; }
    function mark(R, x, y, z, r, color, life, follow) { W.fx(R, { t: "mark", x: x, y: y, z: z, r: r, c: hex(color), life: life, follow: follow === undefined ? -1 : follow }); }
    function lane(R, id, a, b, w, color, life, locked) { W.fx(R, { t: "lane", id: id, a: [a.x, a.y, a.z], b: [b.x, b.y, b.z], w: w, c: hex(color), life: life, locked: !!locked }); }
    function shock(R, x, y, z, r, color, life) { W.fx(R, { t: "shock", x: x, y: y, z: z, r: r, c: hex(color), life: life }); }
    function burst(R, size) { part(R, "minecraft:explosion", R.m.x, R.m.y + R.m.height * 0.5, R.m.z, Math.max(1, Math.round(size / 4)), size * 0.15, 0); }
    function anim(R, name, mode) { if (R.anim !== name + mode) { R.anim = name + mode; R.m.playAnimation(name, mode || "hold"); } }
    function canHold(R, t) { return t && alive(t) && !(t.isPlayer() && (W.gm(t.asPlayer()) === "creative" || t.asPlayer().hasEffect("knocked_down"))); }
    function stunned(R) { return now() < (R.stunUntil || 0); }
    function stun(R, ticks) { R.stunUntil = Math.max(R.stunUntil || 0, now() + ticks); }
    function holdVictim(e, x, y, z, yaw) { if (e.isPlayer()) e.asPlayer().teleportTo(e.dimension, x, y, z, yaw, e.pitch || 0); else e.teleport(x, y, z); e.setVelocity && e.setVelocity(0, 0, 0); }
    function freezeVictim(e, ticks) { if (e.isPlayer()) e.asPlayer().addEffect("stunned", ticks); else e.addPotion("minecraft:slowness", ticks, 9); }
    function lockAnimReset(R) { R.anim = null; }
    function hasSight(R, t) { try { return R.m.canSee(t); } catch (e) { return true; } }
    function busy(R) { return DMZ_SAGA.busy(R.m) || stunned(R); }
    function meleeReach(R, t) { return 2.2 + R.m.width * 0.5 + (t.width || 0.6) * 0.5; }
    function horiz(a, b) { var dx = a.x - b.x, dz = a.z - b.z; return Math.sqrt(dx * dx + dz * dz); }

    // a scripted bolt of ki between two points (KiLaserEntity.setupStrike): the client draws it, the hit is resolved here
    function laserFx(R, a, b, size, colors, life) { W.fx(R, { t: "laser", a: [a.x, a.y, a.z], b: [b.x, b.y, b.z], size: size, c: colors, life: life }); }

    // ---- the power clash (MetalCoolerCore.SupernovaClash, also Gomah's Great Sphere) ----
    //  Players fire a beam (a ki wave / beam technique) into the ball to join; each joins the clash meter (right
    //  click on the marks, DBR_CLASH: DMZ's ClashMeter) and pushes with their momentum x 1.5 against 0.17 + 0.08 per
    //  fighter; small ki shots that reach the ball push it 0.012. bias 0.7 at the start: 0.8 = the fighters win, 0.2 or
    //  the end of the struggle (bias <= 0.5) = the boss wins. The ball rides from start to end by the visual bias.
    var K = DBR_CLASH, CLASHES = [];
    function Clash(R, ball, start, end, ownerColor, ticks, barKey, joinedKey) {
        this.R = R; this.ball = ball; this.start = start; this.stop = end; this.owner = ownerColor; this.ticks = ticks; this.barKey = barKey;
        this.joinedKey = joinedKey; this.fighters = {}; this.bias = 0.7; this.age = 0; this.shown = -1; this.id = "dmz_wb_clash_" + R.key;
        CLASHES.push(this);
    }
    function visual(c) { return K.visualBias(c.bias); }
    Clash.prototype.pos = function () { var v = 1 - visual(this), a = this.start, b = this.stop; return { x: a.x + (b.x - a.x) * v, y: a.y + (b.y - a.y) * v, z: a.z + (b.z - a.z) * v }; };
    Clash.prototype.tick = function (audience) {
        var c = this, R = c.R, pos = c.pos(), radius = Math.max(1.5, c.ball.size * 0.5);
        c.age++;
        c.ball.x = pos.x; c.ball.y = pos.y; c.ball.z = pos.z;
        Object.keys(c.fighters).forEach(function (u) {
            var f = c.fighters[u];
            f.m *= K.DECAY; f.idle++;
            if (!alive(f.p) || f.idle > 60 || !f.proj.alive) { delete c.fighters[u]; RPG.net.send(f.p, "dbr_clash", { end: true }); }
        });
        RPG.world.projectilesNear(R.m.dimension, pos.x, pos.y, pos.z, 80).forEach(function (pr) {
            var o = pr.owner;
            if (!o || !o.isPlayer() || !pr.alive) return;
            var u = String(o.uuid);
            if (pr.beam) {
                if (c.fighters[u]) { if (c.fighters[u].proj === pr) pr.setLifetime(pr.age + 40); return; }
                if (beamDistance(pr, pos) > radius + pr.size + 2.5) return;
                c.join(o.asPlayer(), pr);
            } else {
                var dx = pr.x - pos.x, dy = pr.y - pos.y, dz = pr.z - pos.z;
                if (dx * dx + dy * dy + dz * dz <= (radius + 1) * (radius + 1)) {
                    c.bias = Math.min(1, c.bias + 0.012);
                    part(R, "minecraft:poof", pr.x, pr.y, pr.z, 6, 0.2, 0.02);
                    pr.discard();
                }
            }
        });
        var push = 0, n = 0;
        Object.keys(c.fighters).forEach(function (u) { push += c.fighters[u].m * 1.5; n++; });
        var resist = (0.17 + 0.08 * n) * (K.OPPONENT || 1);      // DBR_CLASH.OPPONENT: harder clashes
        c.bias = Math.max(0, Math.min(1, c.bias + 0.010 * (push - resist)));
        var adv = visual(c);
        Object.keys(c.fighters).forEach(function (u) {
            var f = c.fighters[u];
            if (c.age % 2 === 0) RPG.net.send(f.p, "dbr_clash", { adv: adv });
            var d = f.proj.direction, reach = (pos.x - f.proj.x) * d.x + (pos.y - f.proj.y) * d.y + (pos.z - f.proj.z) * d.z - radius * 0.6;
            f.proj.length = Math.max(0.5, reach);
        });
        if (c.shown !== n) c.shown = n;
        RPG.ui.bossBar(c.id, { name: c.barName(n), color: "blue", style: "10", progress: adv, players: audience });
        if (c.bias >= 0.8) return "players";
        if (c.bias <= 0.2) return "boss";
        if (c.age >= c.ticks) return c.bias > 0.5 ? "players" : "boss";
        return "on";
    };
    Clash.prototype.barName = function (n) { return "Power clash: " + n + " fighters"; };      // worldboss.dragonminez.*.clash_bar
    Clash.prototype.join = function (p, pr) {
        var seed = DBR_SPACE_ORBITS.u64.make(Math.floor(Math.random() * 4294967296), Math.floor(Math.random() * 4294967296));
        this.fighters[String(p.uuid)] = { p: p, proj: pr, m: 0, idle: 0, seed: seed, t0: now(), consumed: -1, last: -1e9 };
        RPG.net.send(p, "dbr_clash", { start: true, hi: seed.hi, lo: seed.lo, self: "#00F8FF", foe: hex(this.owner), adv: visual(this) });
        W.bar(p, this.joinedKey, [], "#FFFFFF");
        snd(this.R, "ki_explosion_impact", 1.5, 1.2, p);
        pr.setLifetime(pr.age + 40);
    };
    Clash.prototype.end = function (playersWon) {
        var c = this;
        RPG.ui.removeBossBar(c.id);
        Object.keys(c.fighters).forEach(function (u) {
            var f = c.fighters[u], lost = playersWon === false;
            if (f.proj.alive) { if (playersWon === true) f.proj.setLifetime(f.proj.age + 60); else if (lost) f.proj.discard(); }
            if (lost) f.p.addEffect("stunned", 70);
            RPG.net.send(f.p, "dbr_clash", { end: true, exhaust: lost ? 70 : 0 });
        });
        c.fighters = {};
        var i = CLASHES.indexOf(c);
        if (i >= 0) CLASHES.splice(i, 1);
    };
    function beamDistance(pr, pt) {
        var d = pr.direction, ox = pt.x - pr.x, oy = pt.y - pr.y, oz = pt.z - pr.z;
        var along = Math.max(0, Math.min(Math.max(0.1, pr.length || 0), ox * d.x + oy * d.y + oz * d.z));
        var px = pr.x + d.x * along - pt.x, py = pr.y + d.y * along - pt.y, pz = pr.z + d.z * along - pt.z;
        return Math.sqrt(px * px + py * py + pz * pz);
    }
    RPG.net.on("dbr_clash_press", function (p, d) {
        var u = String(p.uuid);
        CLASHES.forEach(function (c) {
            var f = c.fighters[u];
            if (!f || !d) return;
            var age = now() - f.t0, t = Number(d.t);
            if (isNaN(t)) t = age;
            t = Math.max(age - 12, Math.min(age + 3, t));
            if (t <= f.last) return;
            f.last = t; f.idle = 0;
            var s = K.sample(f.seed, t);
            if (s.cycle.index <= f.consumed) return;
            f.consumed = s.cycle.index;
            if (s.grade === "MISS") return;
            f.m += s.efficiency;
        });
    });
    // the ball (KiBlastEntity death ball): drawn by the client
    function Ball(R, id, colors, size) { this.R = R; this.id = id; this.c = colors; this.size = size; this.x = R.m.x; this.y = R.m.y; this.z = R.m.z; }
    Ball.prototype.show = function () { W.fx(this.R, { t: "ball", id: this.id, x: this.x, y: this.y, z: this.z, size: this.size, c: this.c }); };
    Ball.prototype.remove = function () { W.fx(this.R, { t: "ball", id: this.id, remove: true }); };
    function explosionFx(R, x, y, z, size, colors) { W.fx(R, { t: "boom", x: x, y: y, z: z, size: size, c: colors }); }

    // =========================================================================================
    //  Janemba (JanembaFat) and Mini Janemba
    // =========================================================================================
    var JF = {
        init: function (R) { R.s = { minis: [], stompCd: 0, sumA: false, sumB: false, downed: 0 }; },
        duration: function (R, a) { return a === "stomp" ? 78 : a === "summon" ? 72 : 0; },
        tick: function (R) {
            var s = R.s;
            if (s.stompCd > 0) s.stompCd--;
            tickMinis(R);
            if (s.downed > 0) s.downed--;
            W.setResting(R, !R.ab && !R.asleep && (s.minis.length > 0 || s.downed > 0));
            if (R.ab || R.resting || now() < R.tfUntil) return;
            if (busy(R)) return;
            var f = R.m.health / R.m.maxHealth;
            if (!s.sumA && f <= 0.80) { if (W.startAbility(R, "summon")) { s.sumA = true; anim(R, "boss1.special3", "loop"); } return; }
            if (!s.sumB && f <= 0.60) { if (W.startAbility(R, "summon")) { s.sumB = true; anim(R, "boss1.special3", "loop"); } return; }
            var t = target(R);
            if (!t || !R.m.onGround || s.stompCd > 0 || R.m.distanceTo(t) > 26) return;
            if (W.startAbility(R, "stomp")) { s.stompCd = 600; s.impacted = false; anim(R, "boss1.special2", "hold"); }
        },
        tickAbility: function (R, a, t) {
            var s = R.s, m = R.m;
            if (a === "summon") { if (t === 35) spawnMinis(R); return; }
            if (a !== "stomp") return;
            var tg = target(R);
            if (t === 1 && tg) mark(R, tg.x, tg.y, tg.z, 14, 0xFF2A2A, 20, tg.entityId);
            if (t === 15) { tp(R, m.x, m.y + 4, m.z); snd(R, "oozaru_growl_player", 2.0, 1.4); return; }
            if (t > 15 && t < 21) { tp(R, m.x, m.y + 4, m.z); return; }
            if (t === 21) {
                s.sx = tg ? tg.x : m.x; s.sz = tg ? tg.z : m.z;
                var my = ground(R, s.sx, s.sz, tg ? tg.y : m.y);
                s.sy = my;
                mark(R, s.sx, my, s.sz, 14, 0xFF2A2A, 25, -1);
                return;
            }
            if (t > 21 && t < 46) return;
            if (t === 46) { tp(R, s.sx, m.y, s.sz); return; }
            if (t > 46 && !s.impacted) {
                var gy = ground(R, m.x, m.z, m.y);
                var ny = Math.max(gy, m.y - 3.6);
                tp(R, m.x, ny, m.z);
                if (ny <= gy + 0.01 || t >= 62) { s.impacted = true; stompImpact(R); }
            }
        },
        hurt: function (R, e) {
            if (R.s.minis.length) {                     // playGuardFeedback
                if (now() % 4 === 0) {
                    snd(R, "block" + (1 + Math.floor(rnd() * 3)), 1.6, 0.8);
                    part(R, "minecraft:crit", R.m.x, R.m.y + R.m.height * 0.5, R.m.z, 6, 1.2, 0.02);
                }
                return false;
            }
            maybeTransform(R, e, "wb_super_janemba", true);
        },
        lethal: function (R, e) { if (!R.s.minis.length) { startTransform(R, "wb_super_janemba", true); return false; } return false; },
        onReturnToSleep: function (R) { clearMinis(R); R.s.downed = 0; W.setResting(R, false); R.s.sumA = R.s.sumB = false; R.s.stompCd = 0; return false; },
        onDeath: function (R) { clearMinis(R); }
    };
    function stompImpact(R) {
        var m = R.m, cx = m.x, cy = m.y, cz = m.z, dmg = W.melee(R) * 1.2;
        victims(R, cx, cy, cz, 14).forEach(function (v) {
            if (String(v.rpgId || "") === "wb_mini_janemba" || v.y < cy - 3 || v.y > cy + 5) return;
            var dx = v.x - cx, dz = v.z - cz, d = Math.sqrt(dx * dx + dz * dz);
            if (d > 14) return;
            hit(R, v, dmg, "melee");
            var push = d < 0.1 ? 0 : 0.9 * (1 - d * 0.03);
            kb(v, dx * push * 0.2, 0.75, dz * push * 0.2);
        });
        part(R, "minecraft:campfire_cosy_smoke", cx, cy + 0.3, cz, 60, 14 * 0.4, 0.05);
        part(R, "minecraft:poof", cx, cy + 0.3, cz, 120, 14 * 0.5, 0.15);
        snd(R, "anchor_slam", 4.0, 0.55);
        snd(R, "ki_explosion_impact", 3.0, 0.7);
        shock(R, cx, cy + 0.2, cz, 14 * 1.4, 0xFFD700, 16);
        burst(R, 22);
    }
    function tickMinis(R) {
        var s = R.s;
        if (!s.minis.length) return;
        s.minis = s.minis.filter(function (u) { var e = RPG.world.entityByUuid(u); return alive(e); });
        if (s.minis.length) return;
        stun(R, 100);
        s.downed = 100;
        part(R, "minecraft:poof", R.m.x, R.m.y + 1, R.m.z, 70, 2.2, 0.05);
        snd(R, "knockback_character", 3.0, 0.6);
    }
    function spawnMinis(R) {
        var m = R.m, s = R.s, belly = m.y + m.height * 0.45;
        s.minis = [];
        for (var i = 0; i < 10; i++) {
            var a = Math.PI * 2 / 10 * i, sp = 3 + rnd() * 2, mx = m.x + Math.cos(a) * sp, mz = m.z + Math.sin(a) * sp;
            var e = RPG.world.spawnMob(m.dimension, "wb_mini_janemba", mx, m.y, mz);
            if (!e) continue;
            W.setupMob(e, W.MINIONS.wb_mini_janemba, 3);
            e.target = m.target;
            s.minis.push(String(e.uuid));
            part(R, "minecraft:large_smoke", mx, belly, mz, 30, 0.4, 0.03);
        }
        part(R, "minecraft:large_smoke", m.x, belly, m.z, 120, 2.0, 0.05);
        snd(R, "oozaru_growl_player", 3.0, 1.6);
    }
    function vanish(e, n) { part({ m: e }, "minecraft:large_smoke", e.x, e.y + 0.6, e.z, n || 22, 0.35, 0.02); e.remove(); }
    function clearMinis(R) {
        (R.s.minis || []).forEach(function (u) { var e = RPG.world.entityByUuid(u); if (alive(e)) vanish(e); });
        R.s.minis = [];
    }
    // the transformation (DBSagasEntity.startTransformation, 80 ticks, invulnerable): at half health or on a lethal hit
    function maybeTransform(R, e, next, full) {
        var m = R.m;
        if (now() < R.tfUntil) return;
        if (m.health - e.amount <= m.maxHealth * 0.5) {
            if (e.amount >= m.health) e.amount = Math.max(0, m.health - 1);
            startTransform(R, next, full);
        }
    }
    function startTransform(R, next, full) {
        if (now() < R.tfUntil || R.tfPending) return;
        var m = R.m, frac = m.health / m.maxHealth;
        W.stopAbility(R);
        if (AI[R.id] && AI[R.id].clearState) AI[R.id].clearState(R);
        if (R.id === "wb_janemba_fat") clearMinis(R);
        R.tfUntil = now() + 80; R.tfPending = true;
        DMZ_SAGA.freeze(m, true);
        try { m.setAI(false); } catch (er) { }
        m.health = Math.max(1, m.health);
        anim(R, "transformation_1", "hold");
        snd(R, "ki_charge_loop", 1.0, 1.2);
        var pulses = RPG.every(10, function () { if (alive(m)) part(R, "minecraft:end_rod", m.x, m.y + 1, m.z, 15, 0.8, 0.15); });
        RPG.schedule(80, function () {
            RPG.cancel(pulses);
            R.tfPending = false;
            if (!alive(m) || RT_of(m) !== R) return;
            part(R, "minecraft:explosion_emitter", m.x, m.y + 1, m.z, 1, 0, 0);
            var NR = W.transformTo(R, next, full ? {} : { fraction: Math.max(frac, 0.35) });
            NR.tfUntil = 0;
            DMZ_SAGA.freeze(m, false);
            try { m.setAI(true); } catch (er) { }
            m.stopAnimation();
        });
    }
    function RT_of(m) { return W.rt(m); }
    AI.wb_janemba_fat = JF;
    // Mini Janemba: 3% of Janemba, knocks a hit player back 1.35 and runs off 9 blocks for 26 ticks (RetreatGoal)
    var MINI_RETREAT = {};
    RPG.every(2, function () {
        var t = now();
        Object.keys(MINI_RETREAT).forEach(function (u) {
            var r = MINI_RETREAT[u], e = RPG.world.entityByUuid(u);
            if (!alive(e) || t >= r.until || !alive(r.from)) { delete MINI_RETREAT[u]; return; }
            var dx = e.x - r.from.x, dz = e.z - r.from.z, l = Math.sqrt(dx * dx + dz * dz) || 1;
            e.moveTo(e.x + dx / l * 9, e.y, e.z + dz / l * 9, 1.6);
        });
    });

    // =========================================================================================
    //  Super Janemba
    // =========================================================================================
    AI.wb_super_janemba = {
        init: function (R) { R.s = { cutsCd: 0, slashes: [] }; },
        duration: function (R, a) { return a === "cuts" ? 96 : 0; },
        tick: function (R) {
            var s = R.s;
            if (s.cutsCd > 0) s.cutsCd--;
            tickSlashes(R);
            if (R.ab || stunned(R) || DMZ_SAGA.busy(R.m)) return;
            var t = target(R);
            if (!t || s.cutsCd > 0 || R.m.distanceTo(t) < 5) return;
            if (W.startAbility(R, "cuts")) { s.cutsCd = 340; anim(R, "skp.dimensional_sword_attack", "loop"); }
        },
        tickAbility: function (R, a, t) {
            if (a !== "cuts") return;
            var tg = target(R), m = R.m;
            if (tg) face(R, yawTo(R, tg.x, tg.z));
            var el = t - 10;
            if (el < 0 || el % 12 !== 0 || el / 12 >= 6 || !tg) return;
            var o = { x: m.x, y: m.y + m.height * 0.65, z: m.z }, c = center(tg);
            var dx = c.x - o.x, dy = c.y - o.y, dz = c.z - o.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
            var sl = { x: o.x, y: o.y, z: o.z, dx: dx / l, dy: dy / l, dz: dz / l, gone: 0, hit: {}, roll: [-35, 35, 0, -60, 60, 90][(el / 12) % 6], dmg: W.ki(R) * 0.6, id: "cut" + now() + "_" + el };
            R.s.slashes.push(sl);
            W.fx(R, { t: "cut", id: sl.id, x: sl.x, y: sl.y, z: sl.z, d: [sl.dx, sl.dy, sl.dz], roll: sl.roll, scale: 10.2, c: "#7A0000", core: "#FF5A4A", speed: 1.1, life: Math.ceil(48 / 1.1) });
            snd(R, "ki_beam_fire", 1.8, 1.7);
        },
        hurt: function (R, e) { },
        onReturnToSleep: function (R) {          // turns back into the fat Janemba, asleep at home
            var m = R.m;
            part(R, "minecraft:large_smoke", m.x, m.y + 1, m.z, 60, 1.2, 0.02);
            part(R, "minecraft:campfire_cosy_smoke", m.x, m.y + 1, m.z, 25, 1.0, 0.01);
            R.s.slashes = [];
            var NR = W.transformTo(R, "wb_janemba_fat");
            var h = W.home(NR);
            tp(NR, h.x, h.y, h.z);
            W.fallAsleep(NR);
            return true;
        }
    };
    function tickSlashes(R) {
        var s = R.s;
        if (!s.slashes.length) return;
        s.slashes = s.slashes.filter(function (sl) {
            sl.x += sl.dx * 1.1; sl.y += sl.dy * 1.1; sl.z += sl.dz * 1.1; sl.gone += 1.1;
            if (sl.gone > 48) return false;
            if (RPG.world.getBlock(R.m.dimension, Math.floor(sl.x), Math.floor(sl.y), Math.floor(sl.z)) !== "minecraft:air" && sl.gone > 4) return false;
            victims(R, sl.x, sl.y, sl.z, 7.8 * 0.5).forEach(function (v) {
                if (sl.hit[v.uuid] || String(v.rpgId || "") === "wb_mini_janemba") return;
                var c = center(v), dx = c.x - sl.x, dy = c.y - sl.y, dz = c.z - sl.z;
                if (dx * dx + dy * dy + dz * dz > Math.pow(7.8 * 0.5, 2)) return;
                sl.hit[v.uuid] = true;
                hit(R, v, sl.dmg, "melee");
            });
            return true;
        });
    }

    // =========================================================================================
    //  Turles
    // =========================================================================================
    var KD_COLORS = { core: "#FFF3A0", border: "#FFC400", outline: "#E08A00" };
    AI.wb_turles = {
        init: function (R) { R.s = { might: 0, mightCd: 900, mightMelee: 0, grabCd: 60, kdCd: 100, meteorCd: 400, gap: 0 }; },
        duration: function (R, a) { return { fruit: 20, kd: 60, meteor: 201, grab: 56 }[a] || 0; },
        tick: function (R) {
            var s = R.s;
            tickMight(R);
            var t = target(R), fighting = !!t;
            if (fighting) {
                if (s.might <= 0 && s.mightCd > 0) s.mightCd--;
                if (s.grabCd > 0) s.grabCd--;
                if (s.kdCd > 0) s.kdCd--;
                if (s.meteorCd > 0) s.meteorCd--;
            }
            if (s.gap > 0) s.gap--;
            if (!fighting || R.ab || s.gap > 0 || busy(R) || now() < R.tfUntil) return;
            if (s.might <= 0 && s.mightCd <= 0 && W.startAbility(R, "fruit")) { anim(R, "boss2.special1", "hold"); return; }
            var d = R.m.distanceTo(t), sight = hasSight(R, t);
            if (s.meteorCd <= 0 && d <= 14 && sight && canHold(R, t) && W.startAbility(R, "meteor")) { s.meteorCd = 900; s.mb = { t: t }; anim(R, "skp.meteor_burst", "hold"); return; }
            if (s.grabCd <= 0 && d <= 8 + (t.width || 0.6) * 0.5 && canHold(R, t) && W.startAbility(R, "grab")) { s.grabCd = 260; anim(R, "skp.grab", "hold"); return; }
            if (s.kdCd <= 0 && d >= 6 && d <= 40 && sight && W.startAbility(R, "kd")) { s.kdCd = 380; anim(R, "ki.kill_driver_cast", "hold"); }
        },
        onStop: function (R, a) {
            var s = R.s;
            s.gap = 50;
            if (a === "fruit") R.m.setEquipment("mainhand", "minecraft:air");
            if (s.ring) { W.fx(R, { t: "ring", id: "kd_" + R.uuid, remove: true }); s.ring = null; }
            s.grab = null;
            if (s.mb && s.mb.v) releaseVictim(s.mb.v);
            s.mb = null;
        },
        tickAbility: function (R, a, t) {
            if (a === "fruit") return tickFruit(R, t);
            if (a === "kd") return tickKillDriver(R, t);
            if (a === "grab") return tickGrab(R, t);
            if (a === "meteor") return tickMeteorBurst(R, t);
        },
        onReturnToSleep: function (R) {
            var s = R.s;
            if (s.might > 0) endMight(R, false);
            s.mightCd = 900; s.grabCd = 60; s.kdCd = 100; s.meteorCd = 400; s.gap = 0;
            R.m.setEquipment("mainhand", "minecraft:air");
            return false;
        }
    };
    function tickFruit(R, t) {
        var m = R.m, tg = target(R);
        if (tg) face(R, yawTo(R, tg.x, tg.z));
        if (t === 1) {
            m.setEquipment("mainhand", "might_tree_fruit");
            part(R, "minecraft:glow", m.x, m.y + m.height * 0.55, m.z, 10, 0.15, 0.02);
            snd(R, "minecraft:block.amethyst_block.chime", 1.4, 0.6);
        }
        if (t >= 4 && t <= 11 && (t - 4) % 3 === 0) {
            part(R, "minecraft:item_slime", m.x, m.eyeY - 0.15, m.z, 6, 0.1, 0.05);
            snd(R, "minecraft:entity.generic.eat", 1.0, 0.8 + rnd() * 0.2);
        }
        if (t === 12) m.setEquipment("mainhand", "minecraft:air");
        if (t === 15) {                                        // empower
            var s = R.s;
            s.might = 600; s.mightMelee = 0;
            W.setMult(R, "might", 1.5);
            var cy = m.y + m.height * 0.5;
            part(R, "minecraft:dust", m.x, cy, m.z, 60, 0.8, 0.05);
            part(R, "minecraft:large_smoke", m.x, cy, m.z, 40, 0.7, 0.04);
            snd(R, "aura_start", 2.0, 0.7);
            snd(R, "ki_explosion_impact", 1.5, 0.6);
            shock(R, m.x, m.y + 0.2, m.z, 9, 0xC00000, 16);
            W.fx(R, { t: "outline", entity: m.entityId, c: "#B00000", c2: "#E01010", on: true });
        }
    }
    function tickMight(R) {
        var s = R.s, m = R.m;
        if (s.might <= 0) return;
        if (--s.might <= 0) { endMight(R, true); return; }
        if (s.mightMelee > 0) s.mightMelee--;
        if (now() % 4 === 0) part(R, "minecraft:dust", m.x, m.y + m.height * 0.5, m.z, 3, 0.4, 0);
        if (s.mightMelee > 0 || R.asleep || R.ab || busy(R) || now() < R.tfUntil) return;
        var t = target(R);
        if (!t || R.m.distanceTo(t) > meleeReach(R, t) || !hasSight(R, t)) return;
        s.mightMelee = 6;
        R.m.lookAt(t.x, t.eyeY, t.z);
        R.m.playAnimation("attack1_1");
        hit(R, t, W.melee(R), "melee");
    }
    function endMight(R, cd) {
        var s = R.s;
        s.might = 0;
        W.setMult(R, "might", 1);
        if (cd) s.mightCd = 1800;
        part(R, "minecraft:smoke", R.m.x, R.m.y + R.m.height * 0.5, R.m.z, 30, 0.4, 0.02);
        W.fx(R, { t: "outline", entity: R.m.entityId, on: false });
    }
    function tickGrab(R, t) {                                 // StrikeAttackHandler grab: hold 5..50, throw at 50
        var s = R.s, m = R.m, tg = target(R);
        if (t === 1) {
            if (!canHold(R, tg) || m.distanceTo(tg) > 8 + (tg.width || 0.6) * 0.5) { W.stopAbility(R); return; }
            var gap = m.width * 0.5 + (tg.width || 0.6) * 0.5 + 0.35;
            if (m.distanceTo(tg) > 3 + (tg.width || 0.6) * 0.5) {
                var dx = m.x - tg.x, dz = m.z - tg.z, l = Math.sqrt(dx * dx + dz * dz) || 1;
                tp(R, tg.x + dx / l * gap, tg.y, tg.z + dz / l * gap);
            }
            s.grab = { v: tg, yaw: yawTo(R, tg.x, tg.z) };
            face(R, s.grab.yaw);
            freezeVictim(tg, 66);
            snd(R, "punch2", 1.0, 0.8, tg);
        }
        if (!s.grab) return;
        var v = s.grab.v;
        face(R, s.grab.yaw);
        if (!alive(v) || m.distanceTo(v) > 48 || stunned(R)) { W.stopAbility(R); return; }
        var f = dirYaw(s.grab.yaw), gp = m.width * 0.5 + (v.width || 0.6) * 0.5 + 0.35;
        if (t < 50) {
            var lift = t < 5 ? 0 : 1.2 * Math.min(1, (t - 5) / 10);
            holdVictim(v, m.x + f.x * gp, m.y + lift, m.z + f.z * gp, s.grab.yaw + 180);
            return;
        }
        if (t === 50) {
            s.grab = null;
            hit(R, v, W.melee(R) * 1.6, "strike");
            snd(R, "critic_punch1", 2.0, 1.0, v);
            if (alive(v)) kb(v, f.x * 1.4, 0.5, f.z * 1.4);
        }
    }
    function tickKillDriver(R, t) {
        var s = R.s, m = R.m, tg = target(R);
        if (t < 43) { if (tg) face(R, yawTo(R, tg.x, tg.z)); }
        if (t === 1) snd(R, "ki_explosion_charge", 1.6, 0.8);
        var f = dirYaw(R.yaw || m.yaw), raise = Math.max(0, Math.min(1, (t - 32) / 8));
        var hold = { x: m.x + f.x * 0.8, y: m.y + m.height * (0.55 + 0.6 * raise), z: m.z + f.z * 0.8 };
        if (t === 17) { s.ring = true; snd(R, "ki_charge_loop", 1.4, 1.3); }
        if (s.ring && t < 43) {
            var rad = 2.25 * (0.35 + 0.65 * raise);
            if (t % 2 === 1 || t === 17) W.fx(R, { t: "ring", id: "kd_" + R.uuid, x: hold.x, y: hold.y, z: hold.z, r: rad, c: KD_COLORS });
            return;
        }
        if (t === 43 && s.ring) {
            anim(R, "ki.kill_driver_fire", "hold");
            W.fx(R, { t: "ring", id: "kd_" + R.uuid, remove: true });
            s.ring = null;
            var aim = tg ? center(tg) : { x: hold.x + f.x, y: hold.y, z: hold.z + f.z };
            var dx = aim.x - hold.x, dy = aim.y - hold.y, dz = aim.z - hold.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
            var p = RPG.world.shootFrom(m.dimension, hold.x, hold.y, hold.z, dx / l, dy / l, dz / l, "dmz_tech_disk", { size: 2.25 * 2, colors: KD_COLORS, damage: 0, speed: 1.15, lifetime: 80 }, m);
            if (p) { p.setVar("boom", 1); p.setVar("r", 5.5); p.setVar("dmg", W.ki(R) * 1.75); }
            snd(R, "ki_beam_fire", 2.5, 0.8);
        }
    }
    // MeteorBurstCombo (201 ticks): dash, punch, launch, stomp, knee, hammer slam, then six shots and the blast
    var MB = { DASH: 4, PUNCH: 14, LAUNCH: 26, STOMP: 52, KNEE: 67, SLAM: 81, LEAP: 87, CHARGE: 129, SHOTS: [163, 166, 169, 172, 175, 178], BLAST: 179, END: 201 };
    function releaseVictim(v) { if (v && v.isPlayer()) v.asPlayer().removeEffect("stunned"); }
    function tickMeteorBurst(R, t) {
        var s = R.s, mb = s.mb, m = R.m;
        if (!mb) { W.stopAbility(R); return; }
        var strike = W.melee(R) * 3.05, kiB = W.ki(R) * 1.6;
        if (t < MB.DASH) {
            if (!canHold(R, mb.t)) { W.stopAbility(R); return; }
            if (!mb.o) mb.o = { x: m.x, y: m.y, z: m.z };
            mb.yaw = yawTo(R, mb.t.x, mb.t.z); face(R, mb.yaw);
            return;
        }
        if (t === MB.DASH) {
            if (!canHold(R, mb.t) || m.distanceTo(mb.t) > 20) { W.stopAbility(R); return; }
            mb.v = mb.t; mb.yaw = yawTo(R, mb.v.x, mb.v.z);
            mb.g = { x: mb.v.x, y: mb.v.y, z: mb.v.z };
            freezeVictim(mb.v, MB.END + 20);
            snd(R, "zanzoken", 1.5, 0.9);
        }
        var v = mb.v;
        if (!v || !alive(v) || m.distanceTo(v) > 48 || stunned(R)) { W.stopAbility(R); return; }
        var f = dirYaw(mb.yaw), gap = m.width * 0.5 + (v.width || 0.6) * 0.5 + 0.35, g = mb.g;
        function at(x, y, z) { tp(R, x, y, z); face(R, mb.yaw); }
        function sh(share) { hit(R, v, strike * share, "strike"); snd(R, "punch3", 1.6, 1.0, v); part(R, "minecraft:crit", v.x, v.y + 1, v.z, 10, 0.3, 0.2); }
        var vy = g.y;
        if (t <= MB.DASH + 6) { var k = (t - MB.DASH) / 6; at(mb.o.x + (g.x - f.x * gap - mb.o.x) * k, mb.o.y + (g.y - mb.o.y) * k, mb.o.z + (g.z - f.z * gap - mb.o.z) * k); }
        if (t === MB.PUNCH) sh(0.15);
        if (t === MB.LAUNCH) sh(0.15);
        if (t > MB.LAUNCH && t <= MB.LAUNCH + 10) vy = g.y + 5 * (t - MB.LAUNCH) / 10;
        else if (t > MB.LAUNCH + 10 && t < MB.STOMP) vy = g.y + 5;
        if (t >= MB.LAUNCH + 4 && t <= MB.LAUNCH + 20) at(g.x, g.y + 6.2 * (t - MB.LAUNCH - 4) / 16, g.z);
        if (t === MB.STOMP) sh(0.2);
        if (t >= MB.STOMP && t < MB.KNEE) vy = Math.max(g.y + 2, g.y + 5 - 3 * (t - MB.STOMP) / 6);
        if (t >= MB.STOMP && t <= MB.STOMP + 7) at(g.x, vy + 1.6, g.z);
        if (t === MB.KNEE) { vy = g.y + 2.4; sh(0.15); }
        if (t > MB.KNEE && t < MB.SLAM) { vy = g.y + 2.4; at(g.x - f.x * 0.6, g.y + 2.4, g.z - f.z * 0.6); }
        if (t === MB.SLAM) { sh(0.35); vy = g.y; snd(R, "critic_punch1", 2.0, 0.9, v); part(R, "minecraft:poof", g.x, g.y, g.z, 30, 1, 0.1); }
        if (t > MB.SLAM) vy = g.y;
        if (t >= MB.LEAP && t <= MB.LEAP + 10) at(g.x - f.x * (gap + 1.8 * (t - MB.LEAP) / 10), g.y + 1.5 * Math.sin(Math.PI * (t - MB.LEAP) / 10), g.z - f.z * (gap + 1.8 * (t - MB.LEAP) / 10));
        if (t === MB.CHARGE) { snd(R, "ki_charge_loop", 1.2, 1.2); part(R, "minecraft:dragon_breath", m.x, m.y + 1, m.z, 20, 0.3, 0.02); }
        if (MB.SHOTS.indexOf(t) >= 0) {
            var o = { x: m.x + f.x * 0.6, y: m.y + 0.9, z: m.z + f.z * 0.6 }, c = { x: g.x, y: g.y + 0.5, z: g.z };
            var dx = c.x - o.x, dy = c.y - o.y, dz = c.z - o.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
            RPG.world.shootFrom(m.dimension, o.x, o.y, o.z, dx / l, dy / l, dz / l, "dmz_tech_bullet", { size: 0.7, colors: { core: "#A64DFF", border: "#6A3BFF", outline: "#4A2CE0" }, damage: 0, speed: 1.2, lifetime: 20 }, m);
            hit(R, v, kiB * 0.1, "ki");
            snd(R, "kiblast_shoot", 0.8, 1.2);
        }
        if (t === MB.BLAST) {
            hit(R, v, kiB * 0.4, "ki");
            explosionFx(R, g.x, g.y + 0.5, g.z, 5, { core: "#E9C7FF", border: "#A64DFF", outline: "#4A2CE0" });
            snd(R, "ki_explosion_impact", 2.0, 0.8);
            victims(R, g.x, g.y, g.z, 3).forEach(function (e) { if (e.uuid !== v.uuid) hit(R, e, kiB * 0.4, "ki"); });
        }
        if (alive(v)) holdVictim(v, g.x, vy, g.z, mb.yaw + 180);
        if (t >= MB.END - 1) { releaseVictim(v); mb.v = null; }
    }

    // =========================================================================================
    //  Metal Cooler Core (+ guardians, copies, cables, reassembly)
    // =========================================================================================
    var CHAMBER_RADIUS = 36, CHAMBER_REACH = 39, CHAMBER_PLAYER = 37, ROAM = 31, CHAMBER_HEIGHT = 48;
    var SN_MAIN = "#FF3866", SN_COLORS = { core: "#FF3866", border: "#A3143A", outline: "#4A0316" };
    var CORE_ABILITIES = { lasers: 1 + 25 * 2 + 30 + 15, cables: 44, overload: 240, supernova: 200 + 400 + 12 + 20 };
    function chamber(R) {
        if (R.s.ch) return R.s.ch;
        var L = W.state()[R.key], d = W.lairData ? W.lairData("gete_star") : null;
        if (L && d && typeof L.cx === "number" && typeof L.base === "number") {
            R.s.ch = { x: L.cx + d.chamber[0] + 0.5, y: L.base + d.chamber[1], z: L.cz + d.chamber[2] + 0.5,
                caps: d.capsules.map(function (c) { return { x: L.cx + c[0] + 0.5, y: L.base + c[1], z: L.cz + c[2] + 0.5 }; }) };
        } else {
            var h = W.home(R);
            R.s.ch = { x: h.x, y: h.y, z: h.z, caps: [0, 1, 2, 3].map(function (i) { var a = Math.PI / 4 + i * Math.PI / 2; return { x: h.x + Math.cos(a) * 26, y: h.y, z: h.z + Math.sin(a) * 26 }; }) };
        }
        return R.s.ch;
    }
    function inChamber(R, p) { var c = chamber(R), dx = p.x - c.x, dz = p.z - c.z, dy = p.y - c.y; return dx * dx + dz * dz <= CHAMBER_PLAYER * CHAMBER_PLAYER && dy >= -2 && dy <= CHAMBER_HEIGHT; }
    function chamberPlayers(R) { return RPG.server.players().filter(function (p) { return p.dimension === R.m.dimension && W.eligible(p) && inChamber(R, p); }); }
    function owned(R, id) { var c = chamber(R); return RPG.world.entitiesNear(R.m.dimension, c.x, c.y + 20, c.z, CHAMBER_REACH + 16 + 30).filter(function (e) { return String(e.rpgId || "") === id && e.hasTag("dmz_gete_" + R.uuid) && alive(e); }); }
    function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)), x = a[i]; a[i] = a[j]; a[j] = x; } return a; }
    AI.wb_metal_cooler_core = {
        init: function (R) { R.s = { phase: 1, overload: 0, swarmA: false, swarmB: false, gap: 0, strikeCd: 100, bindCd: 100, snCd: 200, prod: 300, waves: [], binds: [], scraps: [] }; },
        duration: function (R, a) { return CORE_ABILITIES[a] || 0; },
        scanWake: function (R) { if (now() % 20) return; var ps = chamberPlayers(R); if (ps.length) W.wakeUp(R, ps[0]); },
        sleepPose: function (R) { R.m.stopAnimation(); },
        onWake: function (R) {
            var s = R.s;
            s.strikeCd = 100; s.bindCd = 100; s.snCd = 200; s.prod = 300; s.overload = 0; s.phase = 1;
            snd(R, "minecraft:block.beacon.activate", 4.0, 0.4);
            announce(chamberPlayers(R), "worldboss.dragonminez.metal_cooler_core.awake");
        },
        tick: function (R) {
            var s = R.s, m = R.m, c = chamber(R);
            var dx = m.x - c.x, dz = m.z - c.z, d = Math.sqrt(dx * dx + dz * dz);       // stayInChamber
            if (d > ROAM && d > 1e-4) tp(R, c.x + dx * ROAM / d, m.y, c.z + dz * ROAM / d);
            var f = m.health / m.maxHealth, np = f > 0.70 ? 1 : f > 0.35 ? 2 : 3;
            if (np > s.phase) enterPhase(R, np);
            if (s.phase >= 3 && !s.swarmB && f <= 0.15) { s.swarmB = true; releaseSwarm(R, 6); }
            tickCopies(R);
            tickBinds(R);
            tickScraps(R);
            overloadBar(R);
            var t = target(R), fighting = !!t;
            if (fighting) {
                if (s.strikeCd > 0) s.strikeCd--;
                if (s.phase >= 2 && s.bindCd > 0) s.bindCd--;
                if (s.phase >= 3 && s.snCd > 0) s.snCd--;
                if (s.phase < 3 && --s.prod <= 0) { s.prod = 600; produceGuardian(R); }
            }
            if (s.gap > 0) s.gap--;
            if (!fighting || R.ab || s.gap > 0 || busy(R)) return;
            if (s.phase >= 3 && s.snCd <= 0 && W.startAbility(R, "supernova")) { s.snCd = 1200; anim(R, "ki.supernova_cooler_cast", "hold"); return; }
            if (s.phase >= 2 && s.bindCd <= 0 && bindCandidates(R).length && W.startAbility(R, "cables")) { s.bindCd = 500; anim(R, "ki_blast", "hold"); return; }
            if (s.strikeCd <= 0 && W.startAbility(R, "lasers")) { s.strikeCd = 340; anim(R, "ki.laser_fire", "loop"); }
        },
        onStop: function (R, a) {
            var s = R.s;
            s.gap = 40; s.waves = []; s.bindT = null;
            if (s.clash) { s.clash.end(null); s.clash = null; }
            if (s.ball) { s.ball.remove(); s.ball = null; }
            s.reflect = -1;
        },
        tickAbility: function (R, a, t) {
            if (a === "lasers") return tickLasers(R, t);
            if (a === "cables") return tickCables(R, t);
            if (a === "overload") { if (t % 3 === 0) { part(R, "minecraft:electric_spark", R.m.x, R.m.y + 5.5, R.m.z, 10, 2.2, 0.25); if (t % 30 === 0) { part(R, "minecraft:large_smoke", R.m.x, R.m.y + 5.5, R.m.z, 12, 1.6, 0.02); snd(R, "ki_sparks", 2.0, 0.6); } } return; }
            if (a === "supernova") return tickSupernova(R, t);
        },
        hurt: function (R, e) {
            if (R.ab === "supernova" && R.abT < 200) {
                if (e.attacker && e.attacker.isPlayer() && now() % 5 === 0) snd(R, "minecraft:item.shield.block", 2.0, 0.6, { x: R.m.x, y: R.m.y + 7, z: R.m.z });
                return false;
            }
            if (R.ab === "overload") e.amount *= 1.5;
        },
        barColor: function (R) { return "purple"; },
        onReturnToSleep: function (R) { clearCore(R); var s = R.s; s.swarmA = s.swarmB = false; s.phase = 1; s.overload = 0; s.gap = 0; return false; },
        onDeath: function (R) { clearCore(R); }
    };
    function clearCore(R) {
        var s = R.s;
        RPG.ui.removeBossBar("dmz_wb_overload");
        if (s.clash) { s.clash.end(null); s.clash = null; }
        if (s.ball) { s.ball.remove(); s.ball = null; }
        s.binds.forEach(function (b) { releaseBind(R, b, false); });
        s.binds = [];
        s.scraps.forEach(function (sc) { W.fx(R, { t: "scrap", id: sc.id, remove: true }); });
        s.scraps = [];
        owned(R, "wb_metal_cooler").concat(owned(R, "wb_metal_cooler_copy")).forEach(function (e) { part(R, "minecraft:end_rod", e.x, e.y + 1, e.z, 25, 0.4, 0.1); e.remove(); });
    }
    function enterPhase(R, np) {
        var s = R.s;
        s.phase = np;
        if (np === 2) { s.bindCd = 100; announce(chamberPlayers(R), "worldboss.dragonminez.metal_cooler_core.phase2"); }
        else if (np === 3) {
            s.snCd = 200; announce(chamberPlayers(R), "worldboss.dragonminez.metal_cooler_core.phase3");
            if (!s.swarmA) { s.swarmA = true; releaseSwarm(R, 8); }
        }
        snd(R, "minecraft:block.beacon.power_select", 3.0, 0.5);
    }
    function addOverload(R, amt) {
        var s = R.s;
        if (R.asleep || s.phase < 2 || R.ab === "overload" || R.ab === "supernova") return;
        s.overload = Math.min(1, s.overload + amt);
        if (s.overload >= 1) triggerOverload(R, true);
    }
    function triggerOverload(R, ann) {
        var s = R.s, m = R.m;
        s.overload = 0;
        R.stunUntil = 0;
        W.stopAbility(R);
        s.binds.forEach(function (b) { releaseBind(R, b, false); });
        W.startAbility(R, "overload");
        anim(R, "base.crouching", "loop");
        part(R, "minecraft:electric_spark", m.x, m.y + 7, m.z, 120, 2.6, 0.4);
        part(R, "minecraft:explosion", m.x, m.y + 7, m.z, 4, 1.8, 0);
        snd(R, "ki_explosion_impact", 3.0, 1.4, { x: m.x, y: m.y + 7, z: m.z });
        snd(R, "minecraft:entity.iron_golem.damage", 3.0, 0.5);
        if (ann) announce(chamberPlayers(R), "worldboss.dragonminez.metal_cooler_core.overload");
    }
    function overloadBar(R) {
        var s = R.s;
        if (s.phase < 2) { RPG.ui.removeBossBar("dmz_wb_overload"); return; }
        var prog = R.ab === "overload" ? 1 - R.abT / 240 : s.overload;
        if (now() % 10 === 0) RPG.ui.bossBar("dmz_wb_overload", { name: "§f" + "Core Overload", color: "yellow", style: "progress", progress: Math.max(0, Math.min(1, prog)), players: chamberPlayers(R) });
        else RPG.ui.bossBarProgress("dmz_wb_overload", Math.max(0, Math.min(1, prog)));
    }
    function tickLasers(R, t) {
        var s = R.s, tg = target(R);
        if (tg) face(R, yawTo(R, tg.x, tg.z));
        for (var w = 0; w < 3; w++) {
            var st = 1 + w * 25;
            if (t === st) markWave(R);
            if (t === st + 30 && w < s.waves.length) fireWave(R, s.waves[w]);
        }
    }
    function markWave(R) {
        var c = chamber(R), pts = [];
        function add(x, z) {
            var dx = x - c.x, dz = z - c.z;
            if (dx * dx + dz * dz > (CHAMBER_RADIUS - 2) * (CHAMBER_RADIUS - 2)) return;
            for (var i = 0; i < pts.length; i++) if (Math.pow(pts[i].x - x, 2) + Math.pow(pts[i].z - z, 2) < 36) return;
            pts.push({ x: x, y: c.y, z: z });
        }
        shuffle(chamberPlayers(R)).forEach(function (p) {
            if (pts.length >= 2) return;
            var a = rnd() * Math.PI * 2, sc = rnd() * 2;
            add(p.x + Math.cos(a) * sc, p.z + Math.sin(a) * sc);
        });
        for (var k = 0; k < 40 && pts.length < 5; k++) { var a2 = rnd() * Math.PI * 2, d = Math.sqrt(rnd()) * (CHAMBER_RADIUS - 4); add(c.x + Math.cos(a2) * d, c.z + Math.sin(a2) * d); }
        pts.forEach(function (p) { mark(R, p.x, p.y, p.z, 4, 0xFF2A2A, 32, -1); });
        R.s.waves.push(pts);
        snd(R, "ki_explosion_charge", 3.0, 0.6, { x: R.m.x, y: R.m.eyeY, z: R.m.z });
    }
    function fireWave(R, pts) {
        var dmg = W.ki(R) * 0.9;
        pts.forEach(function (p) {
            laserFx(R, { x: p.x, y: p.y + 0.05, z: p.z }, { x: p.x, y: p.y + 44, z: p.z }, 4, { core: "#FFD6D6", border: "#FF2A2A", outline: "#8A0010" }, 22);
            victims(R, p.x, p.y + 10, p.z, 30).forEach(function (v) {
                if (horiz(v, p) > 4 + (v.width || 0.6) * 0.5 || v.y < p.y - 1 || v.y > p.y + 44) return;
                hit(R, v, dmg, "ki");
            });
        });
        snd(R, "ki_beam_fire", 4.0, 0.6);
    }
    function bindCandidates(R) { var held = {}; R.s.binds.forEach(function (b) { if (b.v && !b.released) held[b.v.uuid] = true; }); return chamberPlayers(R).filter(function (p) { return !held[p.uuid]; }); }
    function tickCables(R, t) {
        var s = R.s, tg = target(R), c = chamber(R);
        if (tg) face(R, yawTo(R, tg.x, tg.z));
        if (t === 1) {
            s.bindT = shuffle(bindCandidates(R)).slice(0, 3).map(function (p) { var sp = { x: p.x, y: c.y, z: p.z }; mark(R, sp.x, sp.y, sp.z, 5, 0xA020F0, 30, -1); return { p: p, spot: sp }; });
            snd(R, "minecraft:block.piston.extend", 3.0, 0.5);
            return;
        }
        if (t !== 31 || !s.bindT) return;
        s.bindT.forEach(function (b) {
            var p = b.p, caught = alive(p) && W.eligible(p) && Math.abs(p.y - b.spot.y) <= 3 && horiz(p, b.spot) <= 5;
            var bind = { id: "bind_" + now() + "_" + p.name, x: b.spot.x, y: b.spot.y, z: b.spot.z, yaw: Math.atan2(R.m.z - b.spot.z, R.m.x - b.spot.x) / D2R - 90,
                v: caught ? p : null, age: 0, bound: 0, presses: 0, shift: false, released: false, retractAt: -1 };
            s.binds.push(bind);
            emergeBind(R, bind);
        });
    }
    function emergeBind(R, b) {
        part(R, "minecraft:poof", b.x, b.y + 0.1, b.z, 40, 1.2, 0.15);
        part(R, "minecraft:electric_spark", b.x, b.y + 0.3, b.z, 20, 1.0, 0.2);
        snd(R, "minecraft:block.piston.extend", 2.0, 0.5, b);
        snd(R, "minecraft:block.chain.place", 2.0, 0.6, b);
        W.fx(R, { t: "bind", id: b.id, x: b.x, y: b.y, z: b.z, held: b.v ? b.v.entityId : -1 });
    }
    function tickBinds(R) {
        var s = R.s;
        s.binds = s.binds.filter(function (b) {
            b.age++;
            if (b.retractAt >= 0) { if (b.age - b.retractAt >= 8) { W.fx(R, { t: "bind", id: b.id, remove: true }); return false; } return true; }
            if (!b.v) { if (b.age >= 16) retract(R, b); return true; }
            var p = b.v;
            if (!alive(p) || R.asleep || ++b.bound > 160 || p.hasEffect("knocked_down") || W.gm(p) === "creative" || R.ab === "overload") { releaseBind(R, b, false); return true; }
            holdVictim(p, b.x, b.y + 0.35, b.z, b.yaw);
            p.addEffect("stunned", 4);
            if (b.bound === 1 || b.bound % 20 === 0) {
                p.playAnimationFor("skp.gete_bind", 25);
                W.title(p, { key: "worldboss.dragonminez.metal_cooler_core.bind.title", args: [{ keybind: "key.sneak" }], color: "#FF5555", bold: true },
                    { key: "worldboss.dragonminez.metal_cooler_core.bind.subtitle", args: [{ keybind: "key.dragonminez.ki_charge" }], color: "#FFFF55" }, 2);
            }
            var sh = p.isSneaking(), pressed = sh && !b.shift;
            b.shift = sh;
            if (pressed) {
                b.presses++;
                W.bar(p, "worldboss.dragonminez.metal_cooler_core.bind.progress", [{ meter: b.presses, of: 10 }], "#FFFFFF");
                snd(R, "minecraft:block.chain.hit", 1.0, 0.8 + b.presses * 0.05, p);
                if (b.presses >= 10) { W.bar(p, "worldboss.dragonminez.metal_cooler_core.bind.escaped", [], "#55FF55"); releaseBind(R, b, true); return true; }
            }
            var torso = { x: R.m.x, y: R.m.y + 7, z: R.m.z };
            if (p.hasEffect("ki_charge")) {                        // giving your energy to Cooler
                addOverload(R, 0.004);
                if (b.age % 3 === 0) RPG.world.particleLine(R.m.dimension, "minecraft:wax_on", p.x, p.y + 1, p.z, torso.x, torso.y, torso.z, 2);
                return true;
            }
            if (b.age % 20 !== 0) return true;
            try { p.addResource("ki", -p.resourceMax("ki") * 0.05); p.addResource("stamina", -p.resourceMax("stamina") * 0.05); } catch (e) { }
            R.m.heal(R.m.maxHealth * 0.005);
            RPG.world.particleLine(R.m.dimension, "minecraft:witch", p.x, p.y + 1, p.z, torso.x, torso.y, torso.z, 1);
            snd(R, "ki_charge_loop", 0.6, 0.6, p);
            return true;
        });
    }
    function releaseBind(R, b, escaped) {
        if (b.released) return;
        b.released = true;
        if (b.v && alive(b.v)) {
            b.v.stopAnimation();
            b.v.removeEffect("stunned");
            RPG.net.send(b.v, "dmz_wb_title", { clear: true });
            if (escaped) kb(b.v, 0, 0.5, 0);
        }
        part(R, "minecraft:electric_spark", b.x, b.y + 1, b.z, 24, 0.7, 0.25);
        snd(R, "minecraft:block.chain.break", 1.6, 0.7, b);
        retract(R, b);
    }
    function retract(R, b) { if (b.retractAt < 0) { b.retractAt = b.age; W.fx(R, { t: "bind", id: b.id, retract: true }); } }
    function tickSupernova(R, t) {
        var s = R.s, m = R.m, tg = target(R), torso = { x: m.x, y: m.y + 7, z: m.z };
        if (tg && t < 200) face(R, yawTo(R, tg.x, tg.z));
        if (t === 1) {
            s.ball = new Ball(R, "sn_" + R.uuid, SN_COLORS, 2.5);
            s.reflect = -1;
            markSupernova(R, 200);
            snd(R, "ki_explosion_charge", 4.0, 0.4);
            announce(chamberPlayers(R), "worldboss.dragonminez.metal_cooler_core.supernova");
        }
        var ball = s.ball;
        if (!ball) { if (t > 1) W.stopAbility(R); return; }
        if (t < 200) {
            ball.size = 2.5 + (12 - 2.5) * t / 200;
            ball.x = m.x; ball.y = m.y + m.height + 1 + ball.size * 0.5; ball.z = m.z;
            if (t % 2 === 0) ball.show();
            if (t % 40 === 0) snd(R, "ki_charge_loop", 3.0, 0.5);
            if (t % 20 === 0) supernovaHeal(R, torso);
            return;
        }
        if (t === 200) {
            anim(R, "ki.supernova_cooler_fire", "hold");
            s.clash = new Clash(R, ball, { x: ball.x, y: ball.y, z: ball.z }, supernovaEnd(R, ball), 0xA3143A, 400,
                "worldboss.dragonminez.metal_cooler_core.clash_bar", "worldboss.dragonminez.metal_cooler_core.clash_joined");
            snd(R, "ki_beam_fire", 4.0, 0.5, ball);
            announce(chamberPlayers(R), "worldboss.dragonminez.metal_cooler_core.supernova_clash");
        }
        if (s.reflect >= 0) {
            s.reflect++;
            var k = Math.min(1, s.reflect / 12);
            ball.x = s.rf.x + (torso.x - s.rf.x) * k * k; ball.y = s.rf.y + (torso.y - s.rf.y) * k * k; ball.z = s.rf.z + (torso.z - s.rf.z) * k * k;
            ball.show();
            if (s.reflect < 12) return;
            ball.remove(); s.ball = null;
            explosionFx(R, torso.x, torso.y, torso.z, 14, SN_COLORS);
            snd(R, "minecraft:entity.generic.explode", 6.0, 0.5, torso);
            reflectDamage(R, chamberPlayers(R), 0.08);
            W.stopAbility(R);
            if (alive(m)) triggerOverload(R, false);
            return;
        }
        var c = s.clash;
        if (!c) return;
        if ((t - 200) % 100 === 0) markSupernova(R, 102);
        var r = c.tick(chamberPlayers(R));
        ball.show();
        if (r === "players") {
            c.end(true); s.clash = null; s.reflect = 0; s.rf = { x: ball.x, y: ball.y, z: ball.z };
            announce(chamberPlayers(R), "worldboss.dragonminez.metal_cooler_core.supernova_reflected");
        } else if (r === "boss") {
            var at = { x: ball.x, y: ball.y, z: ball.z };
            c.end(false); s.clash = null; ball.remove(); s.ball = null;
            detonateSupernova(R, at);
            W.stopAbility(R);
        }
    }
    function markSupernova(R, life) { var c = chamber(R); mark(R, c.x, c.y, c.z, CHAMBER_RADIUS, 0xFF3866, life, -1); }
    function supernovaEnd(R, ball) {
        var c = chamber(R), mid = { x: c.x, y: c.y + 2, z: c.z }, tg = target(R);
        var aim = tg ? { x: tg.x, y: tg.y + 1, z: tg.z } : mid;
        var fx = aim.x - ball.x, fz = aim.z - ball.z;
        if (fx * fx + fz * fz < 1e-4) { fx = mid.x - ball.x; fz = mid.z - ball.z; }
        if (fx * fx + fz * fz < 1e-4) { fx = 1; fz = 0; }
        var l = Math.sqrt(fx * fx + fz * fz), reach = Math.max(18, l);
        var ex = ball.x + fx / l * reach, ez = ball.z + fz / l * reach, dx = ex - mid.x, dz = ez - mid.z, d = Math.sqrt(dx * dx + dz * dz), lim = CHAMBER_RADIUS - 4;
        if (d > lim) { dx *= lim / d; dz *= lim / d; }
        return { x: mid.x + dx, y: Math.max(mid.y, aim.y), z: mid.z + dz };
    }
    function supernovaHeal(R, torso) {
        var m = R.m;
        if (m.health >= m.maxHealth) return;
        var amt = 0;
        owned(R, "wb_metal_cooler").forEach(function (g) { amt += m.maxHealth * 0.003; RPG.world.particleLine(m.dimension, "minecraft:electric_spark", g.x, g.y + g.height * 0.6, g.z, torso.x, torso.y, torso.z, 1.5); });
        owned(R, "wb_metal_cooler_copy").forEach(function (g) { amt += m.maxHealth * 0.001; RPG.world.particleLine(m.dimension, "minecraft:electric_spark", g.x, g.y + g.height * 0.6, g.z, torso.x, torso.y, torso.z, 1.5); });
        if (amt <= 0) return;
        m.heal(amt);
        part(R, "minecraft:happy_villager", torso.x, torso.y, torso.z, 12, 2.5, 0);
        snd(R, "minecraft:block.beacon.ambient", 2.0, 1.4, torso);
    }
    function reflectDamage(R, heroes, ratio) {
        var total = R.m.maxHealth * ratio;
        if (!heroes.length) { R.m.damageFrom(total, null, { kind: "explosion", ignoreIFrames: true }); return; }
        heroes.forEach(function (h) { R.m.damageFrom(total / heroes.length, h, { kind: "ki", ignoreIFrames: true, knockback: 0 }); });
    }
    function detonateSupernova(R, at) {
        explosionFx(R, at.x, at.y, at.z, 30, SN_COLORS);
        var dmg = W.ki(R) * 2.0;
        chamberPlayers(R).forEach(function (p) { hit(R, p, dmg, "ki"); kb(p, 0, 0.6, 0); });
        snd(R, "minecraft:entity.generic.explode", 6.0, 0.5, at);
        snd(R, "ki_explosion_impact", 6.0, 0.6, at);
        shock(R, at.x, chamber(R).y + 0.2, at.z, 44, 0xFF3866, 20);
    }
    // guardians come back from scrap at a capsule (GeteStarEntities.Scrap): 160 ticks, scattered by anyone who walks in
    function produceGuardian(R) {
        var s = R.s, c = chamber(R);
        if (!c.caps.length || owned(R, "wb_metal_cooler").length + s.scraps.length >= 3) return;
        addScrap(R, c.caps[Math.floor(rnd() * c.caps.length)]);
    }
    function addScrap(R, at) {
        var sc = { id: "scrap_" + now() + "_" + Math.floor(rnd() * 1e6), x: at.x, y: at.y, z: at.z, timer: 0 };
        R.s.scraps.push(sc);
        W.fx(R, { t: "scrap", id: sc.id, x: sc.x, y: sc.y, z: sc.z, ticks: 160 });
    }
    function tickScraps(R) {
        var s = R.s;
        s.scraps = s.scraps.filter(function (sc) {
            sc.timer++;
            var cy = sc.y + 1.6, reach = 4;
            var intruder = RPG.server.players().filter(function (p) { return p.dimension === R.m.dimension && p.isAlive() && W.gm(p) !== "spectator" && Math.pow(p.x - sc.x, 2) + Math.pow(p.y + 0.9 - cy, 2) + Math.pow(p.z - sc.z, 2) <= reach * reach; })[0];
            if (intruder) {
                intruder.giveItem("gete_scrap", 1 + Math.floor(rnd() * 2));
                part(R, "minecraft:end_rod", sc.x, cy, sc.z, 140, 1.75, 0.25);
                part(R, "minecraft:electric_spark", sc.x, cy, sc.z, 40, 1.5, 0.3);
                snd(R, "minecraft:block.amethyst_cluster.break", 2.0, 0.7, sc);
                snd(R, "minecraft:block.beacon.deactivate", 1.5, 1.2, sc);
                W.bar(intruder, "worldboss.dragonminez.metal_cooler_core.reassembly_stopped", [], "#FFFFFF");
                W.fx(R, { t: "scrap", id: sc.id, remove: true });
                return false;
            }
            if (sc.timer % 10 === 0) snd(R, "minecraft:block.amethyst_block.chime", 1.4, 0.5 + sc.timer / 160, sc);
            if (sc.timer < 160) return true;
            W.fx(R, { t: "scrap", id: sc.id, remove: true });
            if (!R.asleep) spawnGuardian(R, sc);
            return false;
        });
    }
    function spawnGuardian(R, at) {
        var g = RPG.world.spawnMob(R.m.dimension, "wb_metal_cooler", at.x, at.y, at.z);
        if (!g) return;
        g.addTag("dmz_gete_" + R.uuid);
        W.setupMob(g, W.MINIONS.wb_metal_cooler, 3);
        var ps = chamberPlayers(R);
        if (ps.length) g.target = ps[Math.floor(rnd() * ps.length)];
        part(R, "minecraft:end_rod", at.x, at.y + 1, at.z, 60, 0.8, 0.2);
        part(R, "minecraft:flash", at.x, at.y + 1, at.z, 1, 0, 0);
        snd(R, "minecraft:block.beacon.activate", 2.0, 0.8, at);
    }
    function releaseSwarm(R, n) {
        var c = chamber(R), ps = chamberPlayers(R);
        if (!c.caps.length) return;
        for (var i = 0; i < n; i++) {
            var cap = c.caps[i % c.caps.length], x = cap.x + (rnd() - 0.5), z = cap.z + (rnd() - 0.5);
            var e = RPG.world.spawnMob(R.m.dimension, "wb_metal_cooler_copy", x, cap.y, z);
            if (!e) continue;
            e.addTag("dmz_gete_" + R.uuid);
            W.setupMob(e, W.MINIONS.wb_metal_cooler_copy, 3);
            if (ps.length) e.target = ps[Math.floor(rnd() * ps.length)];
            part(R, "minecraft:large_smoke", x, cap.y + 1, z, 16, 0.5, 0.02);
        }
        c.caps.forEach(function (cap) { snd(R, "minecraft:block.piston.contract", 2.5, 0.5, cap); });
    }
    // copies latch onto a player (LATCH 120 ticks, 3 per victim): 2+ slow them, each drains 2% ki / stamina a second
    var LATCH = {};          // copy uuid -> { v, ticks, cd }
    function tickCopies(R) {
        var counts = {};
        owned(R, "wb_metal_cooler_copy").forEach(function (cp) {
            var L = LATCH[cp.uuid] || (LATCH[cp.uuid] = { v: null, ticks: 0, cd: 0 });
            if (L.cd > 0) L.cd--;
            if (L.v) {
                var v = L.v;
                if (!alive(v) || ++L.ticks > 120 || v.hasEffect("knocked_down") || W.gm(v) === "creative") { unlatch(cp, L); return; }
                var a = (Math.abs(hashCode(cp.uuid)) % 6) * Math.PI / 3 + L.ticks * 0.03;
                var x = v.x + Math.cos(a) * 0.75, z = v.z + Math.sin(a) * 0.75;
                cp.teleport(x, v.y + 0.15, z);
                cp.setRotation(Math.atan2(v.z - z, v.x - x) / D2R - 90, 0);
                counts[v.uuid] = (counts[v.uuid] || { v: v, n: 0 }); counts[v.uuid].n++;
                return;
            }
            var t = cp.target;
            if (L.cd > 0 || !t || !t.isPlayer() || !alive(t) || cp.distanceTo(t) > 2.2 + 0.3 || !canHold(R, t)) return;
            var on = 0;
            Object.keys(LATCH).forEach(function (u) { if (LATCH[u].v && LATCH[u].v.uuid === t.uuid) on++; });
            if (on >= 3) return;
            L.v = t; L.ticks = 0;
            cp.setNoGravity(true); try { cp.setAI(false); } catch (e) { }
            cp.playAnimation("skp.grab", "hold");
            snd(R, "punch2", 1.0, 0.7, cp);
        });
        Object.keys(counts).forEach(function (u) {
            var c = counts[u], v = c.v.asPlayer ? c.v.asPlayer() : c.v;
            if (c.n >= 2) v.addPotion("minecraft:slowness", 10, 3);
            if (now() % 20 !== 0) return;
            try { v.addResource("ki", -v.resourceMax("ki") * 0.02 * c.n); v.addResource("stamina", -v.resourceMax("stamina") * 0.02 * c.n); } catch (e) { }
        });
    }
    function unlatch(cp, L) {
        var v = L.v;
        L.v = null; L.cd = 100;
        cp.setNoGravity(false); try { cp.setAI(true); } catch (e) { }
        cp.stopAnimation();
        if (v) { var dx = cp.x - v.x, dz = cp.z - v.z, l = Math.sqrt(dx * dx + dz * dz) || 1; cp.setVelocity(dx / l * 0.9, 0.35, dz / l * 0.9); }
    }
    function hashCode(s) { var h = 0; s = String(s); for (var i = 0; i < s.length; i++) h = (Math.imul(h, 31) + s.charCodeAt(i)) | 0; return h; }
    // guardians regenerate 1.5% a second after 80 calm ticks; a destroyed guardian leaves scrap that reassembles
    var CALM = {};
    RPG.every(20, function () {
        Object.keys(RT_CORES()).forEach(function (u) {
            var R = RT_CORES()[u];
            owned(R, "wb_metal_cooler").forEach(function (g) {
                CALM[g.uuid] = (CALM[g.uuid] || 0) + 20;
                if (CALM[g.uuid] < 80 || g.health >= g.maxHealth) return;
                g.heal(g.maxHealth * 0.015);
                part(R, "minecraft:electric_spark", g.x, g.y + 1, g.z, 4, 0.4, 0.02);
            });
        });
        Object.keys(LATCH).forEach(function (u) { if (!alive(RPG.world.entityByUuid(u))) delete LATCH[u]; });
    });
    var CORES = {};
    function RT_CORES() { return CORES; }
    AI.onMinionDeath = function (m, killer) {
        var id = String(m.rpgId);
        delete MINI_RETREAT[m.uuid]; delete LATCH[m.uuid]; delete CALM[m.uuid];
        if (id !== "wb_metal_cooler") return;
        Object.keys(CORES).forEach(function (u) {
            var R = CORES[u];
            if (m.hasTag("dmz_gete_" + R.uuid) && alive(R.m) && !R.asleep) addScrap(R, { x: m.x, y: m.y, z: m.z });
        });
    };
    var coreInit = AI.wb_metal_cooler_core.init;
    AI.wb_metal_cooler_core.init = function (R) { coreInit(R); CORES[R.uuid] = R; };

    // =========================================================================================
    //  Tamagami (shared) + Number 3 / 2 / 1
    // =========================================================================================
    function Tama(extra) {
        var T = {
            init: function (R) { R.s = { gap: 0, fastHit: 0, oor: 0 }; extra.reset(R); },
            duration: function (R, a) { return extra.duration(R, a); },
            sleepPose: function (R) { R.m.setRotation(0, 35); },
            sleepTick: function (R) {
                R.m.setRotation(0, 35);
                if (now() % 40 < 20 || W.canWake(R)) return;            // noticeDormancy (every 40 ticks)
                var L = W.state()[R.key], left = Math.max(0, Math.ceil(((L && L.next || 0) - Date.now()) / 50));
                nearAnchor(R, W.WAKE).forEach(function (p) { W.bar(p, "worldboss.dragonminez.tamagami.dormant", [bossName(R), W.formatTicks(left)], "#AAAAAA"); });
            },
            tick: function (R) {
                var s = R.s;
                if (extra.tick) extra.tick(R);
                if (R.asleep || !alive(R.m)) return;
                stayNearPlatform(R);
                fastHits(R);
                if (s.gap > 0) s.gap--;
                var t = target(R);
                if (!t) return;
                if (R.ab) {} else {}
                extra.cooldowns(R, t);
                if (R.ab || s.gap > 0 || busy(R) || now() < R.tfUntil) return;
                extra.choose(R, t);
            },
            tickAbility: function (R, a, t) { extra.tickAbility(R, a, t); },
            onStop: function (R, a) { R.s.gap = 45; if (extra.onStop) extra.onStop(R, a); lockAnimReset(R); },
            hurt: function (R, e) {
                if (R.asleep) {
                    if (e.attacker && e.attacker.isPlayer() && W.eligible(e.attacker.asPlayer())) W.wakeUp(R, e.attacker.asPlayer());
                    return false;
                }
                if (extra.hurt && extra.hurt(R, e) === false) return false;
                if (extra.exposed(R)) e.amount *= 1.25;
                if (!R.body.powered) maybeTransform(R, e, R.id + "_powered", false);
            },
            lethal: function (R, e) {
                if (!R.body.powered) { startTransform(R, R.id + "_powered", false); return false; }
                subdue(R); return false;
            },
            clearState: function (R) { extra.clear(R); },
            barColor: function (R) { return R.body.powered ? "red" : "white"; },
            onReturnToSleep: function (R) {
                extra.clear(R);
                if (R.body.powered) { var NR = W.transformTo(R, "wb_tamagami_" + R.body.number); var h = W.home(NR); tp(NR, h.x, h.y, h.z); W.fallAsleep(NR); return true; }
                extra.reset(R); R.s.gap = 0; R.s.fastHit = 0;
                return false;
            }
        };
        return T;
    }
    function stayNearPlatform(R) {
        if (R.ab || now() < R.tfUntil) return;
        var h = W.home(R), m = R.m, dx = m.x - h.x, dz = m.z - h.z;
        if (dx * dx + dz * dz <= 56 * 56 && m.y >= h.y - 1 - 12) return;
        part(R, "minecraft:cloud", m.x, m.y + 1.5, m.z, 25, 0.8, 0.05);
        tp(R, h.x, h.y, h.z);
        snd(R, "tp_short", 1.5, 0.8);
    }
    function fastHits(R) {
        var s = R.s, iv = R.body.hitInterval;
        if (!(iv > 0)) return;
        if (s.fastHit > 0) { s.fastHit--; return; }
        if (R.ab || busy(R) || now() < R.tfUntil) return;
        var t = target(R);
        if (!t || R.m.distanceTo(t) > meleeReach(R, t) || !hasSight(R, t)) return;
        s.fastHit = iv;
        R.m.lookAt(t.x, t.eyeY, t.z);
        R.m.playAnimation("attack1_1");
        hit(R, t, W.melee(R) * R.body.hitRatio, "melee");
        if (AI[R.id].onFastHit) AI[R.id].onFastHit(R);
    }
    function subdue(R) {                                         // Tamagami.subdue: the ball, then home and dormant
        var n = R.body.number;
        W.stopAbility(R);
        if (AI[R.id].clearState) AI[R.id].clearState(R);
        R.m.target = null;
        R.m.health = R.m.maxHealth;
        W.onSubdued(R);
        var h = W.home(R), x = h.x, y = h.y + 0.5, z = h.z + 2.5;        // SLEEP_YAW 0 faces +z, 2.5 blocks out, anchor + 1.5
        RPG.world.dropItem(R.m.dimension, x, y, z, "dball" + n + "_demon", 1);
        part(R, "minecraft:end_rod", x, y + 0.5, z, 40, 0.5, 0.08);
        part(R, "minecraft:dust", x, y + 0.5, z, 30, 0.5, 0);
        snd(R, "minecraft:block.beacon.activate", 2.0, 1.4, { x: x, y: y, z: z });
        chatAll(RPG.server.players().filter(function (p) { return p.dimension === R.m.dimension && Math.pow(p.x - h.x, 2) + Math.pow(p.y - h.y, 2) + Math.pow(p.z - h.z, 2) < 64 * 64; }),
            "worldboss.dragonminez.tamagami.ball_dropped", [bossName(R), n], "#FFAA00");
        var NR = R.body.powered ? W.transformTo(R, "wb_tamagami_" + n) : R;
        if (NR !== R) { part(R, "minecraft:cloud", R.m.x, R.m.y + 1.5, R.m.z, 40, 1.0, 0.05); }
        W.applyFixedStats(NR);
        tp(NR, h.x, h.y, h.z);
        W.fallAsleep(NR);
    }
    function announceOpening(R, key) {
        nearAnchor(R, 64).forEach(function (p) {
            W.bar(p, key, [bossName(R)], "#FFFF55");
            p.playSound("minecraft:block.bell.use", 1.0, 1.4);
            p.playSound("minecraft:block.note_block.chime", 1.0, 1.2);
        });
    }
    function kite(R, t) { if (R.m.distanceTo(t) > 8) R.s.oor++; else R.s.oor = 0; }

    // ---- Tamagami Number 3: hammer throw / slam (+ follow), meteor dive, pillars, cyclone ----
    var T3 = {
        reset: function (R) { var s = R.s; s.throwCd = 80; s.slamCd = 280; s.meteorCd = 120; s.pillarCd = 80; s.cycCd = 160; s.oor = 0; s.hammer = null; s.spiked = {}; s.pillars = []; s.follow = false; },
        duration: function (R, a) {
            var s = R.s, pw = R.body.powered;
            if (a === "throw") return 26;
            if (a === "slam" || a === "follow") {
                var base = a === "slam" ? 56 : 42;
                if (!s.impacted) return base;
                if (s.follow) return s.impactTick + 6;
                if (s.stuck) return Math.max(base, s.impactTick + (pw ? 40 : 50));
                return base;
            }
            if (a === "meteor") return 42;
            if (a === "pillars") return pw ? 60 : 40;
            if (a === "cyclone") return 10 + (pw ? 80 : 60) + 30;
            return 0;
        },
        exposed: function (R) { var s = R.s; return (s.stuck && (R.ab === "slam" || R.ab === "follow")) || (R.ab === "cyclone" && R.abT >= 10 + (R.body.powered ? 80 : 60)); },
        tick: function (R) {
            tickHammer(R);
            W.setMult(R, "unarmed", R.s.hammer ? 0.6 : 1);
            tickSpiked(R);
            if (R.s.follow && !R.ab) { R.s.follow = false; if (!R.s.hammer && W.startAbility(R, "follow")) resetSlam(R); }
        },
        cooldowns: function (R, t) { var s = R.s; ["throwCd", "slamCd", "meteorCd", "pillarCd", "cycCd"].forEach(function (k) { if (s[k] > 0) s[k]--; }); kite(R, t); },
        choose: function (R, t) {
            var s = R.s;
            if (s.hammer) return;
            var d = R.m.distanceTo(t), kiting = s.oor >= 80, grounded = t.onGround || t.y - ground(R, t.x, t.z, t.y) <= 3;
            if (!grounded && (s.meteorCd <= 0 || kiting) && d <= 30 && W.startAbility(R, "meteor")) { s.meteorCd = pcd(R, 300); s.oor = 0; return; }
            if (grounded && s.slamCd <= 0 && R.m.onGround && d <= 24 && W.startAbility(R, "slam")) { s.slamCd = pcd(R, 560); s.oor = 0; resetSlam(R); return; }
            if (s.cycCd <= 0 && d <= 16 && W.startAbility(R, "cyclone")) { s.cycCd = pcd(R, 420); s.oor = 0; return; }
            if (s.pillarCd <= 0 && d <= 32 && W.startAbility(R, "pillars")) { s.pillarCd = pcd(R, 180); s.oor = 0; s.pillars = []; return; }
            if ((s.throwCd <= 0 || kiting) && d >= 6 && d <= 32 && hasSight(R, t) && W.startAbility(R, "throw")) { s.throwCd = pcd(R, 260); s.oor = 0; }
        },
        tickAbility: function (R, a, t) {
            if (a === "throw") return t3Throw(R, t);
            if (a === "slam") return t3Slam(R, t, 8, 16, 31, 44, !R.body.powered);
            if (a === "follow") return t3Slam(R, t, 2, 9, 18, 30, true);
            if (a === "meteor") return t3Meteor(R, t);
            if (a === "pillars") return t3Pillars(R, t);
            if (a === "cyclone") return t3Cyclone(R, t);
        },
        clear: function (R) {
            var s = R.s;
            if (s.hammer) { W.fx(R, { t: "hammer", id: "hm_" + R.uuid, remove: true }); s.hammer = null; }
            R.m.setEquipment("mainhand", "tamagami_hammer");
            W.setMult(R, "unarmed", 1);
            s.follow = false; s.stuck = false; s.pillars = []; s.spiked = {};
            R.m.setNoGravity(false);
        }
    };
    function resetSlam(R) { R.s.impacted = false; R.s.impactTick = 0; R.s.stuck = false; }
    function handPos(R) { var m = R.m, f = dirYaw(m.bodyYaw !== undefined ? m.bodyYaw : m.yaw), r = { x: -f.z, z: f.x }; return { x: m.x + f.x * 0.6 + r.x * 0.7, y: m.y + m.height * 0.7, z: m.z + f.z * 0.6 + r.z * 0.7 }; }
    function t3Throw(R, t) {
        var s = R.s, tg = target(R);
        if (t < 16) {
            if (tg) s.lockYaw = yawTo(R, tg.x, tg.z); else if (t === 1) s.lockYaw = R.m.yaw;
            face(R, s.lockYaw);
            if (t === 1) { snd(R, "ki_explosion_charge", 1.2, 0.6); anim(R, "ki.kienzan_cast", "hold"); }
            return;
        }
        face(R, s.lockYaw);
        if (t !== 16 || s.hammer) return;
        anim(R, "ki.kienzan_fire", "hold");
        var hp = handPos(R), aim;
        if (tg) { var c = center(tg), v = { x: tg.vx || 0, y: tg.vy || 0, z: tg.vz || 0 }; aim = { x: c.x + v.x * 6 - hp.x, y: c.y + v.y * 6 - hp.y, z: c.z + v.z * 6 - hp.z }; }
        else aim = dirYaw(s.lockYaw);
        var l = Math.sqrt(aim.x * aim.x + aim.y * aim.y + aim.z * aim.z) || 1;
        s.hammer = { x: hp.x, y: hp.y, z: hp.z, ox: hp.x, oy: hp.y, oz: hp.z, d: { x: aim.x / l, y: aim.y / l, z: aim.z / l }, back: false, struck: {}, lodged: 0, age: 0, out: 0,
            dmg: W.melee(R) * 1.3, pw: R.body.powered, curve: rnd() < 0.5 ? 1 : -1, backAt: -1 };
        R.m.setEquipment("mainhand", "minecraft:air");
        snd(R, "minecraft:item.trident.throw", 2.0, 0.5);
    }
    function tickHammer(R) {                                       // TamagamiHammer
        var s = R.s, h = s.hammer;
        if (!h) { return; }
        h.age++;
        if (++h.out > 200 || h.age > 160) { catchHammer(R); return; }
        var step;
        if (h.lodged > 0) {
            if (h.lodged % 6 === 0) { part(R, "minecraft:poof", h.x, h.y, h.z, 6, 0.3, 0.02); snd(R, "minecraft:block.gravel.break", 1.0, 0.7, h); }
            if (--h.lodged <= 0) { h.back = true; h.backAt = h.age; }
            W.fx(R, { t: "hammer", id: "hm_" + R.uuid, x: h.x, y: h.y, z: h.z, spin: false });
            return;
        }
        if (!h.back) {
            step = { x: h.d.x * 1.4, y: h.d.y * 1.4, z: h.d.z * 1.4 };
            var hitB = RPG.world.raycast(R.m.dimension, h.x, h.y, h.z, h.d.x, h.d.y, h.d.z, 1.4, { blocks: true, entities: false });
            if (hitB && hitB.hit === "block") {
                step = { x: hitB.x - h.x, y: hitB.y - h.y, z: hitB.z - h.z };
                part(R, "minecraft:poof", hitB.x, hitB.y, hitB.z, 20, 0.4, 0.15);
                snd(R, "anchor_slam", 1.5, 1.1, hitB);
                h.lodged = 30;
            }
            hammerSweep(R, h, step);
            if (Math.sqrt(Math.pow(h.x + step.x - h.ox, 2) + Math.pow(h.y + step.y - h.oy, 2) + Math.pow(h.z + step.z - h.oz, 2)) >= 34 && !h.back) { h.back = true; h.backAt = h.age; }
        } else {
            var hp = handPos(R), tx = hp.x - h.x, ty = hp.y - h.y, tz = hp.z - h.z, dist = Math.sqrt(tx * tx + ty * ty + tz * tz);
            if (dist <= 2) { catchHammer(R); return; }
            var hd = { x: tx / dist, y: ty / dist, z: tz / dist };
            if (h.pw) {
                var ang = 50 * D2R * h.curve * Math.min(1, dist / 14), c = Math.cos(ang), sn = Math.sin(ang);
                hd = { x: hd.x * c - hd.z * sn, y: hd.y, z: hd.x * sn + hd.z * c };
                if (h.age - h.backAt === 8) h.struck = {};
            }
            var sp = Math.min(1.6, dist);
            step = { x: hd.x * sp, y: hd.y * sp, z: hd.z * sp };
            hammerSweep(R, h, step);
        }
        h.x += step.x; h.y += step.y; h.z += step.z;
        if (h.age % 5 === 0) snd(R, "minecraft:entity.player.attack.sweep", 1.2, 0.5, h);
        W.fx(R, { t: "hammer", id: "hm_" + R.uuid, x: h.x, y: h.y, z: h.z, spin: true });
    }
    function hammerSweep(R, h, step) {
        var l = Math.sqrt(step.x * step.x + step.y * step.y + step.z * step.z), px = l > 1e-6 ? step.x / l : 0, pz = l > 1e-6 ? step.z / l : 0;
        var mx = h.x + step.x * 0.5, my = h.y + step.y * 0.5, mz = h.z + step.z * 0.5;
        victims(R, mx, my, mz, l * 0.5 + 1.2 + 1).forEach(function (v) {
            if (h.struck[v.uuid]) return;
            var c = center(v), ax = c.x - h.x, ay = c.y - h.y, az = c.z - h.z, tt = l > 1e-6 ? Math.max(0, Math.min(1, (ax * step.x + ay * step.y + az * step.z) / (l * l))) : 0;
            var qx = ax - step.x * tt, qy = ay - step.y * tt, qz = az - step.z * tt;
            if (qx * qx + qy * qy + qz * qz > Math.pow(1.2 + (v.width || 0.6) * 0.5 + 0.5, 2)) return;
            h.struck[v.uuid] = true;
            hit(R, v, h.dmg, "melee");
            kb(v, px * 1.4, 0.45, pz * 1.4);
            part(R, "minecraft:crit", c.x, c.y, c.z, 14, 0.3, 0.3);
            snd(R, "critic_punch1", 1.6, 0.8, v);
            if (!h.back) { h.back = true; h.backAt = h.age; }
        });
    }
    function catchHammer(R) {
        R.s.hammer = null;
        W.fx(R, { t: "hammer", id: "hm_" + R.uuid, remove: true });
        if (!alive(R.m)) return;
        R.m.setEquipment("mainhand", "tamagami_hammer");
        snd(R, "minecraft:item.trident.return", 2.0, 0.6);
    }
    function t3Slam(R, t, launch, apex, drop, force, last) {
        var s = R.s, m = R.m, tg = target(R);
        if (t === 1) { if (tg) mark(R, tg.x, tg.y, tg.z, 7, 0xFF2A2A, apex - 1, tg.entityId); snd(R, "ki_explosion_charge", 1.5, 0.5); anim(R, "ki.kienzan_cast", "hold"); }
        if (t < launch) return;
        if (t < apex) {
            if (t === launch) { part(R, "minecraft:poof", m.x, m.y + 0.2, m.z, 40, 1.2, 0.08); snd(R, "knockback_character", 2.0, 0.6); }
            tp(R, m.x, m.y + 1.3, m.z);
            return;
        }
        if (t === apex) {
            s.slx = tg ? tg.x : m.x; s.slz = tg ? tg.z : m.z; s.sly = ground(R, s.slx, s.slz, tg ? tg.y : m.y);
            mark(R, s.slx, s.sly, s.slz, 7, 0xFF2A2A, drop - apex + 6, -1);
            anim(R, "attack1_1", "hold");
            return;
        }
        if (t < drop) { tp(R, m.x + (s.slx - m.x) * 0.2, m.y, m.z + (s.slz - m.z) * 0.2); face(R, yawTo(R, s.slx, s.slz)); return; }
        if (t === drop) { tp(R, s.slx, Math.max(m.y, s.sly + 2), s.slz); return; }
        if (s.impacted) { if (s.stuck) t3Stuck(R, t); return; }
        var ny = Math.max(s.sly, m.y - 2.6);
        tp(R, m.x, ny, m.z);
        if (ny <= s.sly + 0.05 || t >= force) {
            s.impacted = true; s.impactTick = t;
            var hitP = t3SlamImpact(R);
            if (!last) s.follow = true;
            else if (!hitP) { s.stuck = true; announceOpening(R, "worldboss.dragonminez.tamagami.hammer_stuck"); snd(R, "minecraft:block.anvil.land", 1.5, 0.5); }
        }
    }
    function t3SlamImpact(R) {
        var m = R.m, cx = m.x, cy = m.y, cz = m.z, dmg = W.melee(R) * 1.6, any = false;
        victims(R, cx, cy, cz, 7).forEach(function (v) {
            if (v.y < cy - 3 || v.y > cy + 5) return;
            var dx = v.x - cx, dz = v.z - cz, d = Math.sqrt(dx * dx + dz * dz);
            if (d > 7) return;
            hit(R, v, dmg, "melee");
            var push = d < 0.1 ? 0 : 0.9 * (1 - d / 14) / d;
            kb(v, dx * push, 0.8, dz * push);
            if (v.isPlayer()) any = true;
        });
        part(R, "minecraft:poof", cx, cy + 0.3, cz, 90, 2.8, 0.35);
        part(R, "minecraft:campfire_cosy_smoke", cx, cy + 0.3, cz, 40, 3.5, 0.05);
        snd(R, "anchor_slam", 4.0, 0.6); snd(R, "ki_explosion_impact", 3.0, 0.75);
        shock(R, cx, cy + 0.2, cz, 10.5, 0xFFE0B3, 16);
        burst(R, 10);
        return any;
    }
    function t3Stuck(R, t) {
        if (t % 6 !== 0) return;
        var f = dirYaw(R.m.yaw), x = R.m.x + f.x * 1.5, z = R.m.z + f.z * 1.5;
        part(R, "minecraft:poof", x, R.m.y + 0.2, z, 8, 0.5, 0.05);
        snd(R, "minecraft:block.gravel.break", 1.2, 0.6, { x: x, y: R.m.y, z: z });
    }
    function t3Cyclone(R, t) {
        var s = R.s, m = R.m, tg = target(R), end = 10 + (R.body.powered ? 80 : 60);
        if (t < 10) { if (tg) face(R, yawTo(R, tg.x, tg.z)); if (t === 1) { snd(R, "ki_explosion_charge", 1.5, 0.7); anim(R, "ki.kienzan_cast", "hold"); } return; }
        if (t < end) {
            anim(R, "ki.kienzan_fire", "hold");
            face(R, ((R.yaw || m.yaw) + 45) % 360);
            if (tg) {
                var tx = tg.x - m.x, ty = tg.y + 0.5 - m.y, tz = tg.z - m.z, l = Math.sqrt(tx * tx + ty * ty + tz * tz);
                if (l > 1) { var sp = R.body.powered ? 0.36 : 0.28; tp(R, m.x + tx / l * sp, Math.max(ground(R, m.x, m.z, m.y), m.y + ty / l * sp), m.z + tz / l * sp); }
            }
            var c = { x: m.x, y: m.y + m.height * 0.5, z: m.z };
            if ((t - 10) % 4 === 0) victims(R, c.x, c.y, c.z, 11).forEach(function (v) {
                var cc = center(v), dx = c.x - cc.x, dy = c.y - cc.y, dz = c.z - cc.z, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (d > 11 || d <= 4.5 * 0.6) return;
                kb(v, dx * 0.55 / d, dy * 0.55 / d, dz * 0.55 / d);
            });
            if ((t - 10) % 6 === 0) victims(R, c.x, c.y, c.z, 4.5).forEach(function (v) {
                var dx = v.x - c.x, dz = v.z - c.z, d = Math.sqrt(dx * dx + dz * dz);
                if (d > 4.5 || Math.abs(v.y - c.y) > 3.5) return;
                hit(R, v, W.melee(R) * 0.4, "melee");
                var ox = d < 0.1 ? 0 : dx / d, oz = d < 0.1 ? 1 : dz / d;
                kb(v, ox * 0.5 - oz * 0.5, 0.35, oz * 0.5 + ox * 0.5);
                part(R, "minecraft:crit", v.x, v.y + 1, v.z, 8, 0.3, 0.3);
                snd(R, "critic_punch1", 1.2, 1.0, v);
            });
            if (t % 2 === 0) { part(R, "minecraft:sweep_attack", c.x, c.y, c.z, 3, 2.25, 0); part(R, "minecraft:cloud", c.x, m.y + 0.2, c.z, 6, 1.8, 0.08); }
            if (t % 4 === 0) snd(R, "minecraft:entity.player.attack.sweep", 2.0, 0.6);
            return;
        }
        if (t === end) { announceOpening(R, "worldboss.dragonminez.tamagami.dizzy"); snd(R, "minecraft:entity.player.attack.nodamage", 2.0, 0.5); anim(R, "tamagami.sleep", "loop"); }
        if (t % 4 === 0) for (var i = 0; i < 3; i++) { var a = t * 0.6 + i * Math.PI * 2 / 3; part(R, "minecraft:enchanted_hit", m.x + Math.cos(a) * 0.8, m.y + m.height + 0.3, m.z + Math.sin(a) * 0.8, 2, 0.05, 0); }
    }
    function t3Meteor(R, t) {
        var s = R.s, m = R.m, tg = target(R);
        if (t === 1) {
            if (tg) mark(R, tg.x, tg.y, tg.z, 3.5, 0xFF2A2A, 14, tg.entityId);
            if (tg && tg.isPlayer()) { W.chat(tg.asPlayer(), "worldboss.dragonminez.tamagami.meteor_warning", [bossName(R)], "#FF5555"); tg.asPlayer().playSound("minecraft:block.note_block.bell", 1.0, 0.5); tg.asPlayer().playSound("minecraft:block.note_block.bass", 1.0, 0.5); }
            s.mx = m.x; s.my = m.y + 4; s.mz = m.z;
            snd(R, "ki_explosion_charge", 1.5, 0.5);
            anim(R, "ki.kienzan_cast", "hold");
        }
        if (t <= 14) {
            if (tg) { var b = dirYaw(tg.yaw); s.mx = tg.x - b.x * 2; s.my = tg.y + (tg.height || 1.8) + 4; s.mz = tg.z - b.z * 2; }
            tp(R, m.x + (s.mx - m.x) * 0.3, m.y + (s.my - m.y) * 0.3, m.z + (s.mz - m.z) * 0.3);
            if (tg) face(R, yawTo(R, tg.x, tg.z));
            if (t === 14) { mark(R, m.x, ground(R, m.x, m.z, m.y), m.z, 3.5, 0xFF2A2A, 24 - 14 + 4, -1); snd(R, "knockback_character", 2.0, 0.5); }
            return;
        }
        if (t === 24) {
            anim(R, "attack1_1", "hold");
            var cx = m.x, cy = m.y, cz = m.z, dmg = W.melee(R);
            victims(R, cx, cy - 5, cz, 12).forEach(function (v) {
                if (v.y < cy - 10 || v.y > cy + 2 || horiz(v, m) > 3.5) return;
                hit(R, v, dmg, "melee");
                kb(v, 0, -3.2, 0);
                s.spiked[v.uuid] = { e: v, t: 0 };
                part(R, "minecraft:crit", v.x, v.y + 1, v.z, 20, 0.4, 0.4);
                snd(R, "critic_punch1", 2.0, 0.6, v);
            });
            part(R, "minecraft:cloud", cx, cy, cz, 30, 1.2, 0.08);
            snd(R, "anchor_slam", 3.0, 0.8);
            burst(R, 6);
        }
    }
    function tickSpiked(R) {
        var s = R.s;
        Object.keys(s.spiked || {}).forEach(function (u) {
            var sp = s.spiked[u], v = sp.e;
            sp.t++;
            if (!alive(v)) { delete s.spiked[u]; return; }
            var g = ground(R, v.x, v.z, v.y);
            if ((sp.t > 1 && (v.onGround || v.y - g <= 1)) || sp.t >= 24) {
                delete s.spiked[u];
                var cx = v.x, cz = v.z, cy = v.y - g <= 3 ? g : v.y, dmg = W.melee(R) * 0.6;
                victims(R, cx, cy, cz, 5).forEach(function (o) {
                    var dx = o.x - cx, dz = o.z - cz, d = Math.sqrt(dx * dx + dz * dz);
                    if (d > 5 || o.y < cy - 2 || o.y > cy + 4) return;
                    hit(R, o, dmg, "melee");
                    var push = d < 0.1 ? 0 : 0.8 / d;
                    kb(o, dx * push, 0.5, dz * push);
                });
                part(R, "minecraft:poof", cx, cy + 0.3, cz, 50, 2, 0.3);
                snd(R, "ki_explosion_impact", 2.5, 0.8, { x: cx, y: cy, z: cz });
                shock(R, cx, cy + 0.2, cz, 7.5, 0xFFE0B3, 12);
                return;
            }
            if (sp.t <= 6) kb(v, 0, -3.2, 0);
            part(R, "minecraft:cloud", v.x, v.y + (v.height || 1.8), v.z, 3, 0.25, 0.01);
        });
    }
    function t3Pillars(R, t) {
        var s = R.s, tg = target(R), pw = R.body.powered;
        if (tg) face(R, yawTo(R, tg.x, tg.z));
        if (t === 1) { snd(R, "ki_explosion_charge", 1.5, 0.4); anim(R, "ki.kienzan_cast", "hold"); }
        if (t === 12) {                                        // groundStrike
            anim(R, "attack1_1", "hold");
            var f = dirYaw(R.m.yaw), x = R.m.x + f.x * 1.8, z = R.m.z + f.z * 1.8, y = ground(R, x, z, R.m.y);
            part(R, "minecraft:poof", x, y + 0.3, z, 40, 1.0, 0.3);
            snd(R, "anchor_slam", 3.0, 0.5, { x: x, y: y, z: z });
            shock(R, x, y + 0.2, z, 4, 0xFFE0B3, 10);
        }
        if (t === 32 || (pw && t === 52)) eruptPillars(R);
        if (t === 12 || (pw && t === 32)) markPillars(R, tg);
    }
    function markPillars(R, tg) {
        var s = R.s;
        s.pillars = [];
        function add(x, reachY, z) {
            var g = ground(R, x, z, reachY);
            if (reachY - g > 40) return;
            for (var i = 0; i < s.pillars.length; i++) if (Math.pow(s.pillars[i].x - x, 2) + Math.pow(s.pillars[i].z - z, 2) < 3.5 * 3.5) return;
            s.pillars.push({ x: x, g: g, z: z, top: Math.max(g + 14, reachY + 4) });
        }
        playersNear(R, 32 + 2).forEach(function (p) { if (s.pillars.length < 6 && Math.abs(p.y - R.m.y) <= 40) add(p.x, p.y + 1.8, p.z); });
        if (tg) for (var k = 0; k < 8 && s.pillars.length < 3; k++) { var a = rnd() * Math.PI * 2, d = 4 + rnd() * 5; add(tg.x + Math.cos(a) * d, tg.y + (tg.height || 1.8), tg.z + Math.sin(a) * d); }
        s.pillars.forEach(function (p) { mark(R, p.x, p.g, p.z, 2.5, 0xFF2A2A, 20, -1); });
    }
    function eruptPillars(R) {
        var s = R.s, dmg = W.melee(R) * 1.3;
        s.pillars.forEach(function (p) {
            victims(R, p.x, (p.g + p.top) / 2, p.z, (p.top - p.g) / 2 + 3).forEach(function (v) {
                if (v.y < p.g - 1 || v.y > p.top || horiz(v, p) > 2.5 + (v.width || 0.6) * 0.5) return;
                hit(R, v, dmg, "melee");
                kb(v, 0, 1.2, 0);
            });
            var block = RPG.world.getBlock(R.m.dimension, Math.floor(p.x), Math.floor(p.g - 1), Math.floor(p.z));
            W.fx(R, { t: "pillar", x: p.x, y: p.g, z: p.z, h: p.top - p.g, r: 2.5, block: block });
            part(R, "minecraft:poof", p.x, p.g + 0.5, p.z, 40, 1.5, 0.2);
            snd(R, "anchor_slam", 2.0, 0.8, { x: p.x, y: p.g, z: p.z });
            shock(R, p.x, p.g + 0.2, p.z, 3.75, 0xFFE0B3, 10);
        });
        s.pillars = [];
    }
    AI.wb_tamagami_3 = Tama(T3); AI.wb_tamagami_3_powered = Tama(T3);

    // ---- Tamagami Number 2: whirlwinds, lunge (+ follow), gale ----
    var T2 = {
        reset: function (R) { var s = R.s; s.whirlCd = 160; s.lungeCd = 100; s.galeCd = 240; s.oor = 0; s.cols = []; s.gale = 0; s.lf = false; s.le = 0; },
        duration: function (R, a) {
            var s = R.s;
            if (a === "whirl") return 45;
            if (a === "lunge" || a === "lfollow") { var dash = a === "lunge" ? 18 : 9; if (!s.le) return dash + 12 + 6; if (s.lf) return s.le + 2; return s.le + (s.lexp ? 25 : 6); }
            if (a === "gale") return 20;
            return 0;
        },
        exposed: function (R) { return R.s.lexp && (R.ab === "lunge" || R.ab === "lfollow"); },
        tick: function (R) {
            tickGale(R);
            tickWhirlColumns(R);
            if (R.s.lf && !R.ab) { R.s.lf = false; if (W.startAbility(R, "lfollow")) resetLunge(R); }
        },
        cooldowns: function (R, t) { var s = R.s; ["whirlCd", "lungeCd", "galeCd"].forEach(function (k) { if (s[k] > 0) s[k]--; }); kite(R, t); },
        choose: function (R, t) {
            var s = R.s, d = R.m.distanceTo(t), kiting = s.oor >= 80;
            if ((s.lungeCd <= 0 || kiting) && d >= 5 && d <= 28 && hasSight(R, t) && W.startAbility(R, "lunge")) { s.lungeCd = pcd(R, 220); s.oor = 0; resetLunge(R); return; }
            if (s.whirlCd <= 0 && d <= 40 && W.startAbility(R, "whirl")) { s.whirlCd = pcd(R, 380); s.oor = 0; return; }
            if (s.galeCd <= 0 && s.gale <= 0 && d <= 40 && W.startAbility(R, "gale")) { s.galeCd = pcd(R, 500); s.oor = 0; }
        },
        tickAbility: function (R, a, t) {
            if (a === "whirl") return t2Whirl(R, t);
            if (a === "lunge") return t2Lunge(R, t, 12, 18, !R.body.powered);
            if (a === "lfollow") return t2Lunge(R, t, 6, 9, true);
            if (a === "gale") return t2GaleCast(R, t);
        },
        clear: function (R) {
            var s = R.s;
            if (s.gale > 0) W.fx(R, { t: "gale", id: "gale_" + R.uuid, remove: true });
            s.cols.forEach(function (c) { W.fx(R, { t: "whirl", id: c.id, remove: true }); });
            s.cols = []; s.spots = []; s.lf = false; s.lexp = false; s.gale = 0;
            R.m.setNoGravity(false);
        }
    };
    function t2Whirl(R, t) {
        var s = R.s, tg = target(R);
        if (tg) face(R, yawTo(R, tg.x, tg.z));
        if (t === 1) {
            anim(R, "ki.kienzan_cast", "hold");
            s.spots = [];
            function add(x, reachY, z) {
                var g = ground(R, x, z, reachY);
                if (reachY - g > 48) return;
                for (var i = 0; i < s.spots.length; i++) if (Math.pow(s.spots[i].x - x, 2) + Math.pow(s.spots[i].z - z, 2) < 16) return;
                s.spots.push({ x: x, g: g, z: z, top: Math.max(g + 12, reachY + 2) });
            }
            playersNear(R, 40 + 2).forEach(function (p) { if (s.spots.length < 5) add(p.x, p.y + 1.8, p.z); });
            if (tg) for (var k = 0; k < 8 && s.spots.length < 3; k++) { var a = rnd() * Math.PI * 2, d = 6 + rnd() * 5; add(tg.x + Math.cos(a) * d, tg.y + (tg.height || 1.8), tg.z + Math.sin(a) * d); }
            if (!s.spots.length) { W.stopAbility(R); return; }
            s.spots.forEach(function (sp) { mark(R, sp.x, sp.g, sp.z, 5, 0xFF2A2A, 31 + 6, -1); });
            snd(R, "ki_explosion_charge", 1.6, 1.3);
            return;
        }
        if (t !== 31) return;
        anim(R, "ki.kienzan_fire", "hold");
        var dmg = W.ki(R) * 1.6;
        s.spots.forEach(function (sp) {
            var segs = Math.min(4, Math.ceil((sp.top - sp.g) / 12));
            var col = { id: "wh_" + now() + "_" + Math.floor(rnd() * 1e6), x: sp.x, g: sp.g, z: sp.z, h: segs * 12, age: 0, cast: 6, firing: 80, perHit: dmg / Math.max(1, Math.floor(80 / 20)), lastHit: {} };
            s.cols.push(col);
            W.fx(R, { t: "whirl", id: col.id, x: col.x, y: col.g, z: col.z, h: col.h, life: 86, c: { core: "#FFFFFF", border: "#E4ECF4", outline: "#9FB0C2" } });
            part(R, "minecraft:cloud", sp.x, sp.g + 0.3, sp.z, 25, 1.5, 0.12);
        });
        s.spots = [];
        snd(R, "minecraft:item.elytra.flying", 1.5, 1.4);
    }
    function tickWhirlColumns(R) {                            // detached Blue Hurricanes: pull within 14, a hit a second within 4.5
        var s = R.s;
        if (!s.cols || !s.cols.length) return;
        s.cols = s.cols.filter(function (c) {
            c.age++;
            if (c.age > c.cast + c.firing) { W.fx(R, { t: "whirl", id: c.id, remove: true }); return false; }
            if (R.body.powered) {                              // drift toward the nearest player (0.08 a tick)
                var best = null, bd = 40 * 40;
                RPG.server.players().forEach(function (p) { if (p.dimension !== R.m.dimension || !W.eligible(p)) return; var d = Math.pow(p.x - c.x, 2) + Math.pow(p.z - c.z, 2); if (d < bd) { bd = d; best = p; } });
                if (best && bd >= 0.25) { var l = Math.sqrt(bd); c.x += (best.x - c.x) / l * 0.08; c.z += (best.z - c.z) / l * 0.08; if (c.age % 4 === 0) W.fx(R, { t: "whirl", id: c.id, x: c.x, y: c.g, z: c.z, move: true }); }
            }
            if (c.age < c.cast) return true;
            victims(R, c.x, c.g + c.h / 2, c.z, c.h / 2 + 14).forEach(function (v) {
                if (v.y < c.g - 4 || v.y > c.g + c.h) return;
                var dx = c.x - v.x, dz = c.z - v.z, d = Math.sqrt(dx * dx + dz * dz);
                if (d <= 4.5) {
                    var lh = c.lastHit[v.uuid] || -99;
                    if (c.age - lh >= 20) { c.lastHit[v.uuid] = c.age; hit(R, v, c.perHit, "ki"); }
                    if (d > 0) kb(v, dx / d * 0.4 - (v.vx || 0), 0.5 - (v.vy || 0) * 0.5, dz / d * 0.4 - (v.vz || 0));
                    return;
                }
                if (d <= 2 || d > 14) return;
                var st = 0.06 + 0.14 * (1 - d / 14);
                kb(v, dx / d * st - dz / d * st * 0.35, 0, dz / d * st + dx / d * st * 0.35);
            });
            return true;
        });
    }
    function resetLunge(R) { var s = R.s, f = dirYaw(R.m.yaw); s.ld = { x: f.x, y: 0, z: f.z }; s.lstruck = {}; s.lhit = false; s.lstop = false; s.lexp = false; s.le = 0; }
    function bodyC(R) { return { x: R.m.x, y: R.m.y + R.m.height * 0.5, z: R.m.z }; }
    function t2Lunge(R, t, lock, dash, last) {
        var s = R.s, m = R.m, tg = target(R);
        if (t < dash) {
            if (t <= lock && tg) { var c = center(tg), b = bodyC(R), ax = c.x - b.x, ay = c.y - b.y, az = c.z - b.z, l = Math.sqrt(ax * ax + ay * ay + az * az); if (l > 0.01) s.ld = { x: ax / l, y: ay / l, z: az / l }; }
            face(R, yawTo(R, m.x + s.ld.x, m.z + s.ld.z));
            if (t === 1) { snd(R, "ki_explosion_charge", 1.4, 1.1); anim(R, "ki.kienzan_cast", "hold"); }
            if (t === lock) snd(R, "minecraft:item.trident.return", 2.0, 0.6);
            var b0 = bodyC(R), e0 = { x: b0.x + s.ld.x * 2.2 * 12, y: b0.y + s.ld.y * 2.2 * 12, z: b0.z + s.ld.z * 2.2 * 12 };
            if (t < lock && t % 2 === 1) lane(R, m.entityId, b0, e0, 1.4, 0xFF2A2A, 3, false);
            if (t === lock) lane(R, m.entityId, b0, e0, 1.4, 0xFF2A2A, dash - lock + 3, true);
            return;
        }
        if (t < dash + 12 && !s.lstop) {
            if (t === dash) { snd(R, "minecraft:item.trident.riptide_3", 2.0, 0.8); anim(R, "ki.kienzan_fire", "hold"); }
            var from = bodyC(R), step = { x: s.ld.x * 2.2, y: s.ld.y * 2.2, z: s.ld.z * 2.2 };
            var rc = RPG.world.raycast(m.dimension, from.x, from.y, from.z, s.ld.x, s.ld.y, s.ld.z, 2.2, { blocks: true, entities: false });
            if (rc && rc.hit === "block") { step = { x: (rc.x - from.x) * 0.8, y: (rc.y - from.y) * 0.8, z: (rc.z - from.z) * 0.8 }; s.lstop = true; }
            lungeSweep(R, from, step);
            tp(R, m.x + step.x, m.y + step.y, m.z + step.z);
            return;
        }
        if (!s.le) {
            s.le = t;
            if (!last) s.lf = true;
            else if (!s.lhit) { s.lexp = true; announceOpening(R, "worldboss.dragonminez.tamagami.exposed"); }
        }
        if (s.lexp && t % 4 === 0) for (var i = 0; i < 3; i++) { var a = t * 0.6 + i * Math.PI * 2 / 3; part(R, "minecraft:enchanted_hit", m.x + Math.cos(a) * 0.8, m.y + m.height + 0.3, m.z + Math.sin(a) * 0.8, 2, 0.05, 0); }
    }
    function lungeSweep(R, from, seg) {
        var s = R.s, ll = seg.x * seg.x + seg.y * seg.y + seg.z * seg.z, dmg = W.melee(R) * 1.5;
        victims(R, from.x + seg.x / 2, from.y + seg.y / 2, from.z + seg.z / 2, Math.sqrt(ll) / 2 + 1.8 + 1).forEach(function (v) {
            if (s.lstruck[v.uuid]) return;
            var c = center(v), ax = c.x - from.x, ay = c.y - from.y, az = c.z - from.z, tt = ll < 1e-6 ? 0 : Math.max(0, Math.min(1, (ax * seg.x + ay * seg.y + az * seg.z) / ll));
            var reach = 1.8 + (v.width || 0.6) * 0.5, qx = ax - seg.x * tt, qy = ay - seg.y * tt, qz = az - seg.z * tt;
            if (qx * qx + qy * qy + qz * qz > reach * reach) return;
            s.lstruck[v.uuid] = true;
            hit(R, v, dmg, "melee");
            kb(v, s.ld.x * 1.6, 0.35, s.ld.z * 1.6);
            part(R, "minecraft:crit", c.x, c.y, c.z, 16, 0.3, 0.4);
            snd(R, "critic_punch1", 2.0, 0.9, v);
            if (v.isPlayer()) s.lhit = true;
        });
    }
    function t2GaleCast(R, t) {
        var s = R.s;
        if (t === 1) {
            anim(R, "ki.kienzan_cast", "hold");
            var tg = target(R), base = tg ? yawTo(R, tg.x, tg.z) : R.m.yaw, side = rnd() < 0.5 ? 1 : -1;
            s.gd = dirYaw(base + side * (60 + rnd() * 40));
            playersNear(R, 40).forEach(function (p) { W.bar(p, "worldboss.dragonminez.tamagami.gale", [bossName(R)], "#55FFFF"); p.playSound("minecraft:block.note_block.flute", 1.0, 0.7); });
            snd(R, "minecraft:item.elytra.flying", 3.0, 0.8);
            W.fx(R, { t: "gale", id: "gale_" + R.uuid, x: R.m.x, y: R.m.y, z: R.m.z, dx: s.gd.x, dz: s.gd.z, r: 40, k: 0.35, life: 20 });
        }
        if (t === 19) {
            s.gale = R.body.powered ? 100 : 80;
            W.fx(R, { t: "gale", id: "gale_" + R.uuid, x: R.m.x, y: R.m.y, z: R.m.z, dx: s.gd.x, dz: s.gd.z, r: 40, k: R.body.powered ? 1.3 : 1, life: s.gale });
        }
    }
    function tickGale(R) {
        var s = R.s;
        if (!(s.gale > 0)) return;
        s.gale--;
        if (s.gale % 4 !== 0) return;
        var sc = R.body.powered ? 1.3 : 1;
        playersNear(R, 40).forEach(function (p) {
            var air = !p.onGround && p.y - ground(R, p.x, p.z, p.y) > 1.5;
            if (air) kb(p, s.gd.x * 0.9 * sc, -0.35 * sc, s.gd.z * 0.9 * sc); else kb(p, s.gd.x * 0.45 * sc, 0, s.gd.z * 0.45 * sc);
        });
    }
    AI.wb_tamagami_2 = Tama(T2); AI.wb_tamagami_2_powered = Tama(T2);

    // ---- Tamagami Number 1: counter stance, flash cuts, chase, breathe, duel ----
    function flashCycles(pw) { return pw ? 3 : 1; }
    function flashStart(c) { return c === 0 ? 0 : 16 + 2 + (c - 1) * (8 + 2); }
    function flashLock(c) { return flashStart(c) + (c === 0 ? 10 : 4); }
    function flashTick(c) { return flashStart(c) + (c === 0 ? 16 : 8); }
    var T1 = {
        reset: function (R) { var s = R.s; s.stanceCd = 200; s.flashCd = 100; s.chaseCd = 0; s.duelCd = 200; s.oor = 0; s.burst = 0; s.cuts = []; s.duel = null; },
        duration: function (R, a) {
            if (a === "stance") return 30 + 4 + 24;
            if (a === "counter") return 14;
            if (a === "flash") return flashTick(flashCycles(R.body.powered) - 1) + 10 + 6;
            if (a === "chase") return 24;
            if (a === "breathe") return R.body.powered ? 24 : 30;
            return 0;
        },
        exposed: function (R) { return R.ab === "stance" && R.abT >= 34; },
        tick: function (R) {
            var s = R.s;
            s.cuts = (s.cuts || []).filter(function (c) { if (now() < c.due) return true; landCut(R, c); return false; });
            if (R.body.powered && !R.asleep) tickDuel(R);
        },
        onFastHit: function (R) { var s = R.s; if (++s.burst < (R.body.powered ? 6 : 5)) return; s.burst = 0; if (W.startAbility(R, "breathe")) anim(R, "tamagami.sleep", "loop"); },
        cooldowns: function (R, t) { var s = R.s; ["stanceCd", "flashCd", "chaseCd"].forEach(function (k) { if (s[k] > 0) s[k]--; }); kite(R, t); },
        choose: function (R, t) {
            var s = R.s, d = R.m.distanceTo(t);
            if (s.oor >= 80 && s.chaseCd <= 0 && W.startAbility(R, "chase")) { s.chaseCd = pcd(R, 200); s.chaseT = t; s.oor = 0; anim(R, "ki.kienzan_cast", "hold"); return; }
            if (s.stanceCd <= 0 && d <= 10 && W.startAbility(R, "stance")) { s.stanceCd = pcd(R, 360); s.burst = 0; return; }
            if (s.flashCd <= 0 && d >= 4 && d <= 28 && hasSight(R, t) && W.startAbility(R, "flash")) { s.flashCd = pcd(R, 240); var f = dirYaw(R.m.yaw); s.fd = { x: f.x, y: 0, z: f.z }; s.fl = 6; s.oor = 0; }
        },
        hurt: function (R, e) {
            var s = R.s, a = e.attacker;
            if (R.ab === "stance" && R.abT < 30 && R.abT >= 2 && a && alive(a) && a.uuid !== R.m.uuid) { counter(R, a); return false; }
            if (s.duel && a && a.isPlayer() && a.uuid !== s.duel.p.uuid) e.amount *= 1.5;
        },
        tickAbility: function (R, a, t) {
            if (a === "stance") return t1Stance(R, t);
            if (a === "counter") return t1Counter(R, t);
            if (a === "flash") return t1Flash(R, t);
            if (a === "chase") return t1Chase(R, t);
        },
        clear: function (R) { var s = R.s; s.cuts = []; s.duel = null; s.counterT = null; s.chaseT = null; s.burst = 0; R.m.setNoGravity(false); W.fx(R, { t: "outline", entity: R.m.entityId, on: false }); }
    };
    function t1Stance(R, t) {
        var m = R.m, tg = target(R);
        if (tg && t < 30) face(R, yawTo(R, tg.x, tg.z));
        if (t === 1) {
            anim(R, "ki.kienzan_cast", "hold");
            mark(R, m.x, m.y, m.z, 2.2, 0xFF2A2A, 30, m.entityId);
            W.fx(R, { t: "outline", entity: m.entityId, c: "#FF2020", c2: "#FF7070", w: 4, on: true });      // STANCE_OUTLINE
            nearAnchor(R, 64).forEach(function (p) { W.bar(p, "worldboss.dragonminez.tamagami.counter_stance", [bossName(R)], "#FF5555"); p.playSound("minecraft:block.note_block.bass", 1.0, 0.5); });
            snd(R, "minecraft:item.armor.equip_iron", 2.0, 0.6);
        }
        if (t === 30) {
            anim(R, "ki.kienzan_fire", "hold");
            W.fx(R, { t: "outline", entity: m.entityId, on: false });
            var dmg = W.melee(R) * 1.2;
            victims(R, m.x, m.y, m.z, 4.5).forEach(function (v) {
                var dx = v.x - m.x, dz = v.z - m.z, d = Math.sqrt(dx * dx + dz * dz);
                if (d > 4.5 || v.y < m.y - 3 || v.y > m.y + 5) return;
                hit(R, v, dmg, "melee");
                var push = d < 0.1 ? 0 : 0.9 / d;
                kb(v, dx * push, 0.4, dz * push);
            });
            part(R, "minecraft:sweep_attack", m.x, m.y + m.height * 0.5, m.z, 8, 1.8, 0);
            snd(R, "minecraft:entity.player.attack.sweep", 2.5, 0.6);
        }
        if (t === 34) { announceOpening(R, "worldboss.dragonminez.tamagami.exposed"); anim(R, "tamagami.sleep", "loop"); }
    }
    function counter(R, a) {
        R.s.counterT = a;
        W.stopAbility(R);
        W.fx(R, { t: "outline", entity: R.m.entityId, on: false });
        snd(R, "minecraft:item.shield.block", 2.5, 0.7);
        snd(R, "minecraft:block.anvil.land", 1.2, 1.8);
        R.s.gap = 0;
        if (W.startAbility(R, "counter")) anim(R, "ki.kienzan_fire", "hold");
    }
    function t1Counter(R, t) {
        if (t !== 1) return;
        var tg = R.s.counterT;
        if (!tg || !alive(tg) || tg.distanceTo(R.m) > 40) return;
        var b = dirYaw(tg.yaw);
        tp(R, tg.x - b.x * 1.6, tg.y, tg.z - b.z * 1.6);
        face(R, yawTo(R, tg.x, tg.z));
        hit(R, tg, W.melee(R) * 2.5, "melee");
        var ax = tg.x - R.m.x, az = tg.z - R.m.z, l = Math.sqrt(ax * ax + az * az);
        if (l < 0.01) { var f = dirYaw(R.m.yaw); ax = f.x; az = f.z; l = 1; }
        kb(tg, ax / l * 1.4, 0.4, az / l * 1.4);
        var c = center(tg);
        part(R, "minecraft:crit", c.x, c.y, c.z, 24, 0.4, 0.5);
        snd(R, "critic_punch1", 2.5, 0.8, tg); snd(R, "minecraft:entity.player.attack.crit", 2.0, 0.7, tg);
    }
    function t1Flash(R, t) {
        var s = R.s, m = R.m, tg = target(R);
        for (var i = 0; i < flashCycles(R.body.powered); i++) {
            var st = flashStart(i), lk = flashLock(i), fl = flashTick(i);
            if (t <= st || t > fl) continue;
            if (t === st + 1) anim(R, "ki.kienzan_cast", "hold");
            if (t <= lk && tg) {
                var c = center(tg), b = bodyC(R), ax = c.x - b.x, ay = c.y - b.y, az = c.z - b.z, l = Math.sqrt(ax * ax + ay * ay + az * az);
                if (l > 0.01) { s.fd = { x: ax / l, y: ay / l, z: az / l }; s.fl = Math.max(6, Math.min(30, l + 4)); }
            }
            face(R, yawTo(R, m.x + s.fd.x, m.z + s.fd.z));
            var b0 = bodyC(R), e0 = { x: b0.x + s.fd.x * s.fl, y: b0.y + s.fd.y * s.fl, z: b0.z + s.fd.z * s.fl };
            if (t < lk && (t - st) % 2 === 1) lane(R, m.entityId, b0, e0, 0.7, 0xFF2A2A, 3, false);
            if (t === lk) { lane(R, m.entityId, b0, e0, 0.7, 0xFF2A2A, fl - lk + 2, true); snd(R, "minecraft:item.armor.equip_iron", 2.0, 1.6); }
            if (t === fl) flashStrike(R);
        }
    }
    function flashStrike(R) {
        var s = R.s, m = R.m, from = bodyC(R), to = { x: from.x + s.fd.x * s.fl, y: from.y + s.fd.y * s.fl, z: from.z + s.fd.z * s.fl };
        var rc = RPG.world.raycast(m.dimension, from.x, from.y, from.z, s.fd.x, s.fd.y, s.fd.z, s.fl, { blocks: true, entities: false });
        if (rc && rc.hit === "block") to = { x: rc.x - s.fd.x, y: rc.y - s.fd.y, z: rc.z - s.fd.z };
        anim(R, "ki.kienzan_fire", "hold");
        tp(R, to.x, to.y - m.height * 0.5, to.z);
        face(R, yawTo(R, m.x + s.fd.x, m.z + s.fd.z));
        s.cuts.push({ a: from, b: to, due: now() + 10 });
        snd(R, "tp_short", 2.0, 1.2, from); snd(R, "minecraft:entity.player.attack.sweep", 2.0, 1.4, to);
    }
    function landCut(R, c) {
        var seg = { x: c.b.x - c.a.x, y: c.b.y - c.a.y, z: c.b.z - c.a.z }, ll = seg.x * seg.x + seg.y * seg.y + seg.z * seg.z, dmg = W.melee(R) * 1.6;
        var l = Math.sqrt(ll) || 1, push = { x: seg.x / l, z: seg.z / l };
        victims(R, c.a.x + seg.x / 2, c.a.y + seg.y / 2, c.a.z + seg.z / 2, l / 2 + 1.6 + 1).forEach(function (v) {
            var cc = center(v), ax = cc.x - c.a.x, ay = cc.y - c.a.y, az = cc.z - c.a.z, tt = ll < 1e-6 ? 0 : Math.max(0, Math.min(1, (ax * seg.x + ay * seg.y + az * seg.z) / ll));
            var reach = 1.6 + (v.width || 0.6) * 0.5, qx = ax - seg.x * tt, qy = ay - seg.y * tt, qz = az - seg.z * tt;
            if (qx * qx + qy * qy + qz * qz > reach * reach) return;
            hit(R, v, dmg, "melee");
            kb(v, push.x * 0.6, 0.5, push.z * 0.6);
            part(R, "minecraft:crit", cc.x, cc.y, cc.z, 16, 0.3, 0.4);
            snd(R, "critic_punch1", 2.0, 1.1, v);
        });
        lane(R, -1 - Math.floor(rnd() * 1e6), c.a, c.b, 0.45, 0xFFFFFF, 6, true);
        snd(R, "minecraft:entity.player.attack.sweep", 3.0, 0.7, { x: c.a.x + seg.x / 2, y: c.a.y + seg.y / 2, z: c.a.z + seg.z / 2 });
    }
    function t1Chase(R, t) {
        var s = R.s, tg = s.chaseT;
        if (!tg || !alive(tg)) return;
        if (t === 1) {
            if (tg.isPlayer()) { W.chat(tg.asPlayer(), "worldboss.dragonminez.tamagami.meteor_warning", [bossName(R)], "#FF5555"); tg.asPlayer().playSound("minecraft:block.note_block.bell", 1.0, 0.5); tg.asPlayer().playSound("minecraft:block.note_block.bass", 1.0, 0.5); }
            snd(R, "ki_explosion_charge", 1.4, 1.2);
        }
        if (t === 12) { var b = dirYaw(tg.yaw); tp(R, tg.x - b.x * 2, tg.y + 1, tg.z - b.z * 2); snd(R, "tp_short", 2.0, 1.0); }
        if (t >= 12) face(R, yawTo(R, tg.x, tg.z));
        if (t !== 16) return;
        anim(R, "ki.kienzan_fire", "hold");
        var c = center(tg), bc = bodyC(R);
        if (Math.sqrt(Math.pow(c.x - bc.x, 2) + Math.pow(c.y - bc.y, 2) + Math.pow(c.z - bc.z, 2)) > 4 + (tg.width || 0.6) * 0.5) { snd(R, "minecraft:entity.player.attack.nodamage", 2.0, 0.7); return; }
        hit(R, tg, W.melee(R) * 1.4, "melee");
        kb(tg, 0, -1.5, 0);
        part(R, "minecraft:crit", c.x, c.y, c.z, 20, 0.4, 0.4);
        snd(R, "critic_punch1", 2.5, 0.7, tg);
    }
    function tickDuel(R) {
        var s = R.s;
        if (s.duel) {
            s.duel.t--;
            var p = s.duel.p;
            if (!alive(p) || !W.eligible(p) || p.distanceTo(R.m) > 64 || s.duel.t <= 0) { s.duel = null; return; }
            if (!R.m.target || R.m.target.uuid !== p.uuid) R.m.target = p;
            if (s.duel.t % 40 === 0) mark(R, p.x, p.y, p.z, 1.6, 0xFF2A2A, Math.min(42, s.duel.t), p.entityId);
            return;
        }
        if (s.duelCd > 0) { s.duelCd--; return; }
        var fighters = playersNear(R, 32);
        if (fighters.length < 2) { s.duelCd = 40; return; }
        var d = fighters[Math.floor(rnd() * fighters.length)];
        s.duel = { p: d, t: 160 }; s.duelCd = 600;
        R.m.target = d;
        mark(R, d.x, d.y, d.z, 1.6, 0xFF2A2A, 42, d.entityId);
        W.chat(d, "worldboss.dragonminez.tamagami.duel_challenge", [bossName(R)], "#FF5555");
        d.playSound("minecraft:block.note_block.bell", 1.0, 0.5);
        fighters.forEach(function (p) { if (p.uuid === d.uuid) return; W.bar(p, "worldboss.dragonminez.tamagami.duel_others", [bossName(R), d.name], "#FFAA00"); p.playSound("minecraft:block.bell.use", 1.0, 1.4); });
    }
    AI.wb_tamagami_1 = Tama(T1); AI.wb_tamagami_1_powered = Tama(T1);

    // =========================================================================================
    //  Gomah
    // =========================================================================================
    var G_ISLAND = 62, G_TETHER = G_ISLAND - 4, G_ARENA = 110, G_FALL = 14;
    var SPH_COLORS = { core: "#F0C2FF", border: "#7A00CC", outline: "#C4002F" }, MARK_G = 0xFF1A3C, QUAKE_C = 0xC23BFF;
    var G_DUR = { sphere: 110 + 320 + 12 + 20, quake: 70, beam: 52, evil: 44, eruption: 220 };
    function gStacks(R) { return R.s.stacks || 0; }
    function hscale(R) { return W.GOMAH_SCALES[gStacks(R)] / 5.5; }
    function gParticipants(R) {
        var h = W.home(R);
        return RPG.server.players().filter(function (p) {
            if (p.dimension !== R.m.dimension || !W.eligible(p)) return false;
            var dx = p.x - h.x, dz = p.z - h.z, dy = p.y - (h.y - 1);
            return dx * dx + dz * dz <= 64 * 64 && dy > -40 && dy < G_ARENA;
        });
    }
    function gEye(R) { var f = dirYaw(R.m.bodyYaw !== undefined ? R.m.bodyYaw : R.m.yaw), k = hscale(R); return { x: R.m.x + f.x * 1.6 * k, y: R.m.eyeY + 0.4 * k, z: R.m.z + f.z * 1.6 * k }; }
    function setStacks(R, n) {
        n = Math.max(0, Math.min(5, n));
        var was = gStacks(R);
        R.s.stacks = n;
        var id = n === 0 ? "wb_gomah" : "wb_gomah_s" + n;
        if (String(R.m.rpgId) !== id) {
            var m = R.m, frac = m.health / m.maxHealth;
            var NR = W.transformTo(R, id, { keepState: true, fraction: frac });
            R = NR;
        }
        R.kiMult = 1 + 0.3 * n;
        W.setMult(R, "stack", 1 + 0.3 * n);
        return R;
    }
    var G = {
        init: function (R) { if (!R.s || R.s.stacks === undefined) R.s = { stacks: W.BODIES[R.id].stacks || 0 }; gReset(R, false); },
        duration: function (R, a) {
            if (a === "grab") { var s = R.s; return s.grabEnd >= 0 ? s.grabEnd + 12 : 24 + 60 + 12; }
            return G_DUR[a] || 0;
        },
        sleepPose: function (R) { R.m.setRotation(0, 0); },
        sleepTick: function (R) { R.m.setRotation(0, 0); },
        onWake: function (R) {
            gReset(R, true);
            snd(R, "minecraft:entity.ravager.roar", 4.0, 0.6);
            burst(R, 10);
            announce(gParticipants(R), "worldboss.dragonminez.gomah.awake", [], "#AA00AA");
        },
        barName: function (R) {
            var st = gStacks(R), s = R.s, name = R.body.name + "  §4" + new Array(st + 1).join("◉");
            if (st < 5) name += "§c" + (s.prog >= 0.75 ? "◕" : s.prog >= 0.5 ? "◑" : s.prog >= 0.25 ? "◔" : "○") + "§8" + new Array(5 - st).join("○");
            return name;
        },
        tick: function (R) {
            var s = R.s;
            stayOnIsland(R);
            tickRing(R);
            tickEscorts(R);
            if (s.gap > 0) s.gap--;
            var t = target(R);
            if (!t) return;
            if (!stunned(R)) R = addProgress(R, 1 / 400) || R;
            s = R.s;
            if (now() % 10 === 0) R = scanKO(R) || R;
            s = R.s;
            tickKing(R);
            ["evilCd", "grabCd", "sphereCd", "quakeCd", "beamCd"].forEach(function (k) { if (s[k] > 0) s[k]--; });
            if (R.ab || s.gap > 0 || busy(R)) return;
            gChoose(R, t);
        },
        onStop: function (R, a) {
            var s = R.s;
            s.gap = 50;
            if (s.clash) { s.clash.end(null); s.clash = null; }
            releaseGGrab(R, false);
            if (s.ball) { s.ball.remove(); s.ball = null; }
            s.reflect = -1; s.beamO = null; s.stance = null;
            lockAnimReset(R);
        },
        tickAbility: function (R, a, t) {
            if (a === "sphere") return gSphere(R, t);
            if (a === "quake") return gQuake(R, t);
            if (a === "beam") return gBeam(R, t);
            if (a === "evil") return gEvil(R, t);
            if (a === "grab") return gGrab(R, t);
            if (a === "eruption") return gEruption(R, t);
        },
        hurt: function (R, e) {
            if (R.asleep) { if (e.attacker && e.attacker.isPlayer() && W.eligible(e.attacker.asPlayer())) W.wakeUp(R, e.attacker.asPlayer()); return false; }
            if (e.attacker && W.factionKey(e.attacker) === "gomah") return false;
        },
        afterHurt: function (R, e, ap) { noteBackHit(R, e, ap); },
        onReturnToSleep: function (R) {
            clearG(R); clearEscorts(R);
            var NR = R;
            if (gStacks(R) !== 0) NR = setStacks(R, 0);
            gReset(NR, true);
            if (NR !== R) { W.applyFixedStats(NR); var h = W.home(NR); tp(NR, h.x, h.y, h.z); W.fallAsleep(NR); return true; }
            return false;
        },
        onDeath: function (R) { clearG(R); clearEscorts(R); }
    };
    function gReset(R, stacks) {
        var s = R.s;
        s.prog = 0; s.king = 0; s.downed = {}; s.evilCd = 120; s.grabCd = 160; s.back = 0; s.lastBack = -1e9; s.gap = 0;
        s.sphereCd = 360; s.quakeCd = 100; s.beamCd = 120; s.ring = -1; s.ringHit = {}; s.escorts = s.escorts || []; s.reflect = -1; s.grabEnd = -1;
        if (stacks && gStacks(R) !== 0) setStacks(R, 0);
        R.kiMult = 1 + 0.3 * gStacks(R); W.setMult(R, "stack", 1 + 0.3 * gStacks(R));
    }
    function clearG(R) {
        var s = R.s;
        if (s.clash) { s.clash.end(null); s.clash = null; }
        releaseGGrab(R, false);
        if (s.ball) { s.ball.remove(); s.ball = null; }
        s.reflect = -1; s.ring = -1; s.ringHit = {}; s.beamO = null; s.stance = null;
    }
    function gChoose(R, t) {
        var s = R.s, d = R.m.distanceTo(t), st = gStacks(R), sc = function (x) { return st >= 5 ? Math.round(x * 0.7) : x; };
        if (s.sphereCd <= 0 && W.startAbility(R, "sphere")) { s.sphereCd = sc(900); anim(R, "ki.large_ball_cast", "hold"); return; }
        if (st >= 4 && s.quakeCd <= 0 && R.m.onGround && d <= 30 && W.startAbility(R, "quake")) { s.quakeCd = sc(420); s.qImp = false; anim(R, "boss1.special2", "hold"); return; }
        if (st >= 3 && s.grabCd <= 0 && d <= 26 && W.startAbility(R, "grab")) { s.grabCd = sc(400); s.grab = null; s.grabSpot = null; s.grabStart = -1; s.grabEnd = -1; s.grabPresses = 0; s.grabShift = false; anim(R, "skp.grab", "hold"); return; }
        if (st >= 1 && s.evilCd <= 0 && d <= 56 && W.startAbility(R, "evil")) { s.evilCd = sc(300); anim(R, "ki.mouth_blast_cast", "loop"); return; }
        if (st >= 2 && s.beamCd <= 0 && d <= 60 && hasSight(R, t) && W.startAbility(R, "beam")) { s.beamCd = sc(260); anim(R, "ki.mouth_blast_cast", "loop"); }
    }
    function addProgress(R, amt) {
        var s = R.s;
        if (gStacks(R) >= 5) { s.prog = 0; return R; }
        s.prog += amt;
        while (s.prog >= 1 && gStacks(R) < 5) { s.prog -= 1; R = gainStack(R); s = R.s; }
        if (gStacks(R) >= 5) s.prog = 0;
        return R;
    }
    function gainStack(R) {
        var st = gStacks(R);
        if (st >= 5) return R;
        R = setStacks(R, st + 1);
        var s = R.s;
        s.back = 0;
        var e = gEye(R);
        part(R, "minecraft:dust", e.x, e.y, e.z, 40, 1.0, 0);
        snd(R, "minecraft:entity.ravager.roar", 4.0, 0.5); snd(R, "ki_explosion_charge", 3.0, 0.6);
        burst(R, 12 + 4 * st);
        announce(gParticipants(R), "worldboss.dragonminez.gomah.stack_gained", [st + 1, 5], "#AA0000");
        if (st + 1 < 5) return R;
        s.king = 0; s.prog = 0;
        burst(R, 40);
        snd(R, "minecraft:entity.wither.spawn", 4.0, 0.6);
        gParticipants(R).forEach(function (p) { W.chat(p, "worldboss.dragonminez.gomah.demon_king", [], "#AA0000"); W.chat(p, "worldboss.dragonminez.gomah.eruption_warning", [20], "#FF5555"); });
        return R;
    }
    function knockEye(R, culprit) {
        var s = R.s;
        if (R.ab) W.stopAbility(R);
        stun(R, 70);
        s.prog = 0; s.king = 0;
        var e = gEye(R);
        part(R, "minecraft:dust", e.x, e.y, e.z, 60, 0.8, 0);
        part(R, "minecraft:explosion", e.x, e.y, e.z, 2, 0.4, 0);
        snd(R, "minecraft:entity.ender_eye.death", 3.0, 0.5, e); snd(R, "minecraft:block.glass.break", 3.0, 0.6, e);
        burst(R, 8);
        var st = gStacks(R);
        if (st <= 0) { announce(gParticipants(R), "worldboss.dragonminez.gomah.eye_flicker", [culprit], "#FFAA00"); return R; }
        R = setStacks(R, st - 1);
        announce(gParticipants(R), "worldboss.dragonminez.gomah.eye_knocked", [culprit, st - 1, 5], "#FFAA00");
        callEscorts(R);
        return R;
    }
    function noteBackHit(R, e, ap) {
        if (e.kind === "ki" || e.projectile || !alive(R.m) || R.asleep) return;
        var f = dirYaw(R.m.bodyYaw !== undefined ? R.m.bodyYaw : R.m.yaw), dx = ap.x - R.m.x, dz = ap.z - R.m.z, l = Math.sqrt(dx * dx + dz * dz);
        if (l < 1e-3 || (f.x * dx + f.z * dz) / l >= -0.35) return;
        var s = R.s, t = now();
        s.back = t - s.lastBack <= 200 ? s.back + 1 : 1;
        s.lastBack = t;
        var eye = gEye(R);
        part(R, "minecraft:dust", eye.x, eye.y, eye.z, 18, 0.4 * hscale(R), 0);
        part(R, "minecraft:crit", ap.x, ap.eyeY, ap.z, 10, 0.3, 0.3);
        snd(R, "minecraft:block.amethyst_block.break", 2.5, 0.6 + 0.2 * s.back);
        if (s.back < 3) {
            var meter = new Array(s.back + 1).join("◉") + new Array(3 - s.back + 1).join("○");
            announce(gParticipants(R), "worldboss.dragonminez.gomah.back_hit", [meter, s.back, 3], "#FF5555");
            return;
        }
        s.back = 0;
        knockEye(R, ap.name);
    }
    function scanKO(R) {
        var s = R.s, h = W.home(R);
        RPG.server.players().forEach(function (p) {
            var g = W.gm(p);
            if (g === "creative" || g === "spectator" || p.dimension !== R.m.dimension || Math.pow(p.x - h.x, 2) + Math.pow(p.y - h.y, 2) + Math.pow(p.z - h.z, 2) >= 64 * 64) return;
            if (!p.hasEffect("knocked_down")) { delete s.downed[p.uuid]; return; }
            if (s.downed[p.uuid]) return;
            s.downed[p.uuid] = true;
            announce(gParticipants(R), "worldboss.dragonminez.gomah.feeds", [p.name], "#AA0000");
            R = addProgress(R, 1.0);
            s = R.s;
        });
        return R;
    }
    function tickKing(R) {
        var s = R.s;
        if (gStacks(R) < 5) { s.king = 0; return; }
        if (R.ab === "eruption") return;
        if (++s.king < 400 || R.ab || stunned(R)) return;
        if (W.startAbility(R, "eruption")) { s.king = 0; anim(R, "ki.large_ball_cast", "hold"); }
    }
    function stayOnIsland(R) {
        if (R.ab) return;
        var h = W.home(R), m = R.m, dx = m.x - h.x, dz = m.z - h.z;
        if (dx * dx + dz * dz <= G_TETHER * G_TETHER && m.y >= h.y - 1 - G_FALL && m.y <= h.y - 1 + G_ARENA - 20) return;
        part(R, "minecraft:dust", m.x, m.y + 2, m.z, 40, 1.5, 0);
        tp(R, h.x, h.y, h.z);
        snd(R, "tp_short", 2.0, 0.6);
    }
    function gSphere(R, t) {
        var s = R.s, m = R.m;
        if (s.stance) tp(R, s.stance.x, s.stance.y, s.stance.z);
        if (t === 1) {
            s.stance = { x: m.x, y: m.y, z: m.z };
            var tg = target(R), aim = tg ? { x: tg.x, y: tg.y, z: tg.z } : { x: m.x + dirYaw(m.yaw).x * 16, y: m.y, z: m.z + dirYaw(m.yaw).z * 16 };
            s.impact = { x: aim.x, y: ground(R, aim.x, aim.z, aim.y), z: aim.z };
            s.lockYaw = yawTo(R, aim.x, aim.z);
            s.ball = new Ball(R, "sph_" + R.uuid, SPH_COLORS, 5);
            holdSphere(R);
            mark(R, s.impact.x, s.impact.y, s.impact.z, 32, MARK_G, 110 + 4, -1);
            snd(R, "ki_explosion_charge", 4.0, 0.4);
            announce(gParticipants(R), "worldboss.dragonminez.gomah.sphere", [], "#FF55FF");
        }
        face(R, s.lockYaw);
        var ball = s.ball;
        if (!ball) { if (t > 1) W.stopAbility(R); return; }
        if (t < 110) {
            ball.size = 5 + (32 - 5) * t / 110;
            holdSphere(R);
            if (t % 2 === 0) ball.show();
            var lock = 110 - 20;
            if (t < lock && t % 10 === 1) lane(R, m.entityId, ball, { x: s.impact.x, y: s.impact.y + 0.5, z: s.impact.z }, 3.0, MARK_G, 12, false);
            if (t === lock) lane(R, m.entityId, ball, { x: s.impact.x, y: s.impact.y + 0.5, z: s.impact.z }, 3.0, MARK_G, 21, true);
            if (t % 40 === 0) snd(R, "ki_charge_loop", 3.0, 0.5);
            return;
        }
        if (t === 110) {
            holdSphere(R);
            anim(R, "ki.large_ball_fire", "hold");
            s.clash = new Clash(R, ball, { x: ball.x, y: ball.y, z: ball.z }, { x: s.impact.x, y: s.impact.y + 32 * 0.35, z: s.impact.z }, 0x7A00CC, 320,
                "worldboss.dragonminez.gomah.clash_bar", "worldboss.dragonminez.gomah.clash_joined");
            snd(R, "ki_beam_fire", 4.0, 0.5, ball);
            announce(gParticipants(R), "worldboss.dragonminez.gomah.sphere_clash", [], "#FF55FF");
        }
        if (s.reflect >= 0) {
            s.reflect++;
            var chest = { x: m.x, y: m.y + 6.4 * hscale(R), z: m.z }, k = Math.min(1, s.reflect / 12);
            ball.x = s.rf.x + (chest.x - s.rf.x) * k * k; ball.y = s.rf.y + (chest.y - s.rf.y) * k * k; ball.z = s.rf.z + (chest.z - s.rf.z) * k * k;
            ball.show();
            if (s.reflect < 12) return;
            ball.remove(); s.ball = null;
            explosionFx(R, chest.x, chest.y, chest.z, 26, SPH_COLORS);
            snd(R, "minecraft:entity.generic.explode", 6.0, 0.5, chest);
            reflectDamage(R, gParticipants(R), 0.05);
            W.stopAbility(R);
            if (!alive(R.m)) return;
            announce(gParticipants(R), "worldboss.dragonminez.gomah.sphere_reflected", [], "#FFAA00");
            knockEye(R, { key: "worldboss.dragonminez.gomah.the_sphere" });
            return;
        }
        var c = s.clash;
        if (!c) return;
        if ((t - 110) % 40 === 0) mark(R, s.impact.x, s.impact.y, s.impact.z, 32, MARK_G, 42, -1);
        if ((t - 110) % 10 === 0) lane(R, m.entityId, ball, { x: s.impact.x, y: s.impact.y + 0.5, z: s.impact.z }, 3.0, MARK_G, 12, false);
        var r = c.tick(gParticipants(R));
        ball.show();
        if (r === "players") { c.end(true); s.clash = null; s.reflect = 0; s.rf = { x: ball.x, y: ball.y, z: ball.z }; }
        else if (r === "boss") {
            var at = s.impact;
            c.end(false); s.clash = null; ball.remove(); s.ball = null;
            detonateSphere(R, at);
            W.stopAbility(R);
            gainStack(R);
        }
    }
    function holdSphere(R) { var b = R.s.ball; b.x = R.m.x; b.y = R.m.y + 12 * hscale(R) + 1 + b.size * 0.5; b.z = R.m.z; }
    function detonateSphere(R, at) {
        explosionFx(R, at.x, at.y + 2, at.z, 60, SPH_COLORS);
        var dmg = W.ki(R) * 2.0;
        gParticipants(R).forEach(function (p) {
            var d = Math.sqrt(Math.pow(p.x - at.x, 2) + Math.pow(p.y - at.y, 2) + Math.pow(p.z - at.z, 2));
            if (d > 52) return;
            var close = 1 - d / 52, fall = 0.2 + 0.8 * close * close;
            hit(R, p, dmg * fall, "ki");
            var px = p.x - at.x, pz = p.z - at.z, l = Math.sqrt(px * px + pz * pz);
            kb(p, l < 0.01 ? 0 : px / l * 1.6 * close, 0.5 + 0.6 * close, l < 0.01 ? 0 : pz / l * 1.6 * close);
        });
        snd(R, "minecraft:entity.generic.explode", 8.0, 0.4, at); snd(R, "ki_explosion_impact", 8.0, 0.5, at);
        part(R, "minecraft:poof", at.x, at.y + 0.5, at.z, 160, 8, 0.5);
        shock(R, at.x, at.y + 0.2, at.z, 52 * 1.2, 0x7A00CC, 24);
    }
    function gQuake(R, t) {
        var s = R.s, m = R.m, tg = target(R);
        if (t < 40 && t % 4 === 1) gParticipants(R).forEach(function (p) { if (!p.onGround && p.y - ground(R, p.x, p.z, p.y) > 1.4) kb(p, 0, -1.0, 0); });
        if (t === 1) { announce(gParticipants(R), "worldboss.dragonminez.gomah.quake_pull", [], "#FF55FF"); snd(R, "minecraft:entity.ravager.roar", 3.0, 0.7); }
        if (t < 15) return;
        if (t < 21) { tp(R, m.x, m.y + 3, m.z); return; }
        if (t === 21) {
            var h = W.home(R);
            s.qx = tg ? tg.x : m.x; s.qz = tg ? tg.z : m.z;
            var ox = s.qx - h.x, oz = s.qz - h.z, off = Math.sqrt(ox * ox + oz * oz);
            if (off > G_TETHER - 4) { s.qx = h.x + ox * (G_TETHER - 4) / off; s.qz = h.z + oz * (G_TETHER - 4) / off; }
            s.qy = ground(R, s.qx, s.qz, tg ? tg.y : m.y);
            mark(R, s.qx, s.qy, s.qz, 7, MARK_G, 40 - 21 + 4, -1);
            return;
        }
        if (t < 40) { tp(R, m.x + (s.qx - m.x) * 0.18, m.y, m.z + (s.qz - m.z) * 0.18); face(R, yawTo(R, s.qx, s.qz)); return; }
        if (t === 40) { tp(R, s.qx, m.y, s.qz); return; }
        if (s.qImp) return;
        var g = ground(R, m.x, m.z, m.y), ny = Math.max(g, m.y - 3.6);
        tp(R, m.x, ny, m.z);
        if (ny <= g + 0.01 || t >= 56) { s.qImp = true; quakeImpact(R); }
    }
    function quakeImpact(R) {
        var s = R.s, m = R.m, cx = m.x, cy = m.y, cz = m.z, dmg = W.melee(R) * 1.8;
        gParticipants(R).forEach(function (p) {
            var d = Math.sqrt(Math.pow(p.x - cx, 2) + Math.pow(p.z - cz, 2));
            if (d > 7 || Math.abs(p.y - cy) > 5) return;
            hit(R, p, dmg, "melee"); kb(p, 0, 0.9, 0);
        });
        s.ringC = { x: cx, y: cy, z: cz }; s.ring = 0; s.ringHit = {};
        part(R, "minecraft:poof", cx, cy + 0.3, cz, 160, 3.5, 0.4);
        part(R, "minecraft:campfire_cosy_smoke", cx, cy + 0.3, cz, 60, 4.2, 0.05);
        snd(R, "anchor_slam", 5.0, 0.45); snd(R, "ki_explosion_impact", 4.0, 0.6);
        shock(R, cx, cy + 0.2, cz, 38, QUAKE_C, Math.ceil(38 / 1.3));
        burst(R, 20);
    }
    function tickRing(R) {
        var s = R.s;
        if (!(s.ring >= 0) || !s.ringC) return;
        s.ring += 1.3;
        if (s.ring > 38) { s.ring = -1; s.ringHit = {}; return; }
        var dmg = W.melee(R) * 1.2, c = s.ringC;
        gParticipants(R).forEach(function (p) {
            if (s.ringHit[p.uuid]) return;
            var dx = p.x - c.x, dz = p.z - c.z, d = Math.sqrt(dx * dx + dz * dz);
            if (Math.abs(d - s.ring) > 1.8) return;
            var g = ground(R, p.x, p.z, p.y);
            if (!p.onGround && p.y - g > 1.4) return;
            if (Math.abs(g - c.y) > 6) return;
            s.ringHit[p.uuid] = true;
            hit(R, p, dmg, "melee");
            kb(p, dx / Math.max(1, d) * 0.6, 0.7, dz / Math.max(1, d) * 0.6);
        });
        if (now() % 2 === 0) for (var i = 0; i < 24; i++) { var a = Math.PI * 2 * i / 24; part(R, "minecraft:poof", c.x + Math.cos(a) * s.ring, c.y + 0.3, c.z + Math.sin(a) * s.ring, 1, 0.2, 0.05); }
    }
    function gBeam(R, t) {
        var s = R.s, m = R.m, tg = target(R);
        if (t < 30) {
            if (tg) { s.lockYaw = yawTo(R, tg.x, tg.z); var e = gEye(R), c = center(tg), dx = c.x - e.x, dy = c.y - e.y, dz = c.z - e.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1; s.beamO = e; s.beamD = { x: dx / l, y: dy / l, z: dz / l }; }
            face(R, s.lockYaw);
            if (t === 1) snd(R, "ki_explosion_charge", 2.5, 1.4);
            if (s.beamO) {
                var len = beamLen(R), end = { x: s.beamO.x + s.beamD.x * len, y: s.beamO.y + s.beamD.y * len, z: s.beamO.z + s.beamD.z * len };
                if (t < 22 && t % 2 === 1) lane(R, m.entityId, s.beamO, end, 1.3, MARK_G, 3, false);
                if (t === 22) lane(R, m.entityId, s.beamO, end, 1.3, MARK_G, 9, true);
            }
            return;
        }
        face(R, s.lockYaw);
        if (!s.beamO) { W.stopAbility(R); return; }
        var L = beamLen(R);
        if (t === 30) {
            anim(R, "ki.mouth_blast_fire", "loop");
            s.beamHit = {};
            laserFx(R, s.beamO, { x: s.beamO.x + s.beamD.x * L, y: s.beamO.y + s.beamD.y * L, z: s.beamO.z + s.beamD.z * L }, 1.4, { core: "#FFE3EC", border: "#FF1A3C", outline: "#9A0020" }, 22);
            snd(R, "ki_beam_fire", 3.0, 1.3);
        }
        if (t > 30 + 18) return;
        var reach = Math.min(L, (t - 30 + 1) * 14), dmg = W.ki(R) * 1.5;
        gParticipants(R).forEach(function (p) {
            if (s.beamHit[p.uuid]) return;
            var c = center(p), ax = c.x - s.beamO.x, ay = c.y - s.beamO.y, az = c.z - s.beamO.z, al = ax * s.beamD.x + ay * s.beamD.y + az * s.beamD.z;
            if (al < 0 || al > reach) return;
            var qx = ax - s.beamD.x * al, qy = ay - s.beamD.y * al, qz = az - s.beamD.z * al;
            if (Math.abs(qx) > 1.3 + 0.3 || Math.abs(qz) > 1.3 + 0.3 || Math.abs(qy) > 1.3 + 0.9) return;
            s.beamHit[p.uuid] = true;
            hit(R, p, dmg, "ki");
            part(R, "minecraft:dust", p.x, p.eyeY, p.z, 16, 0.3, 0);
        });
    }
    function beamLen(R) { var s = R.s, rc = RPG.world.raycast(R.m.dimension, s.beamO.x, s.beamO.y, s.beamO.z, s.beamD.x, s.beamD.y, s.beamD.z, 70, { blocks: true, entities: false }); return rc && rc.hit === "block" ? Math.sqrt(Math.pow(rc.x - s.beamO.x, 2) + Math.pow(rc.y - s.beamO.y, 2) + Math.pow(rc.z - s.beamO.z, 2)) : 70; }
    function gEvil(R, t) {
        var tg = target(R);
        if (tg) face(R, yawTo(R, tg.x, tg.z));
        if (t === 1) {
            announce(gParticipants(R), "worldboss.dragonminez.gomah.evil_eye", [], "#FF5555");
            gParticipants(R).forEach(function (p) { p.playSound("minecraft:block.note_block.bell", 1.0, 0.5); });
            snd(R, "minecraft:entity.warden.sonic_charge", 4.0, 0.6);
            W.fx(R, { t: "outline", entity: R.m.entityId, c: "#FF1A3C", c2: "#FF8AA0", w: 6, on: true });   // EVIL_EYE_OUTLINE
        }
        if (t !== 30) return;
        anim(R, "ki.mouth_blast_fire", "loop");
        W.fx(R, { t: "outline", entity: R.m.entityId, on: false });
        var eye = gEye(R);
        burst(R, 16);
        snd(R, "minecraft:entity.ender_eye.death", 4.0, 0.4, eye);
        gParticipants(R).forEach(function (p) {
            var ex = eye.x - p.x, ey = eye.y - p.eyeY, ez = eye.z - p.z, d = Math.sqrt(ex * ex + ey * ey + ez * ez);
            if (d > 56 || d < 1e-3) return;
            var yaw = p.yaw * D2R, pitch = p.pitch * D2R, lx = -Math.sin(yaw) * Math.cos(pitch), ly = -Math.sin(pitch), lz = Math.cos(yaw) * Math.cos(pitch);
            if ((lx * ex + ly * ey + lz * ez) / d < 0.5) return;
            var rc = RPG.world.raycast(p.dimension, p.x, p.eyeY, p.z, ex / d, ey / d, ez / d, d, { blocks: true, entities: false });
            if (rc && rc.hit === "block") return;
            p.addEffect("stunned", 40);
            RPG.net.send(p, "dmz_taiyoken", { ticks: 40 });
            W.bar(p, "worldboss.dragonminez.gomah.evil_eye_hit", [], "#AA0000");
            p.playSound("minecraft:entity.elder_guardian.curse", 0.8, 1.2);
        });
    }
    function gHand(R) { var k = hscale(R), f = dirYaw(R.m.bodyYaw !== undefined ? R.m.bodyYaw : R.m.yaw); return { x: R.m.x + f.x * 2.6 * k, y: R.m.y + 6.4 * k, z: R.m.z + f.z * 2.6 * k }; }
    function gGrab(R, t) {
        var s = R.s, tg = target(R);
        if (!s.grab && s.grabEnd < 0) {
            if (t === 1) { if (tg) mark(R, tg.x, tg.y, tg.z, 3.5, MARK_G, 18, tg.entityId); snd(R, "ki_explosion_charge", 3.0, 0.5); }
            if (t <= 18 && tg) face(R, yawTo(R, tg.x, tg.z));
            if (t === 18) {
                var f = dirYaw(R.m.yaw);
                s.grabSpot = tg ? { x: tg.x, y: tg.y, z: tg.z } : { x: R.m.x + f.x * 8, y: R.m.y, z: R.m.z + f.z * 8 };
                mark(R, s.grabSpot.x, ground(R, s.grabSpot.x, s.grabSpot.z, s.grabSpot.y), s.grabSpot.z, 3.5, MARK_G, 24 - 18 + 4, -1);
            }
            if (s.grabSpot) face(R, yawTo(R, s.grabSpot.x, s.grabSpot.z));
            if (t === 24) closeHand(R, t);
            return;
        }
        if (!s.grab) return;
        var held = t - s.grabStart, v = s.grab;
        if (!alive(v) || v.distanceTo(R.m) > 64 || stunned(R) || v.hasEffect("knocked_down")) { releaseGGrab(R, false); s.grabEnd = t; return; }
        var h = gHand(R);
        holdVictim(v, h.x, h.y - 0.9, h.z, (R.m.bodyYaw || R.m.yaw) + 180);
        v.addEffect("stunned", 4);
        if (held === 0 || held % 20 === 0) W.title(v, { key: "worldboss.dragonminez.metal_cooler_core.bind.title", args: [{ keybind: "key.sneak" }], color: "#FF5555", bold: true }, { key: "worldboss.dragonminez.gomah.grab.subtitle", color: "#FFFF55" }, 2);
        var sh = v.isSneaking(), pressed = sh && !s.grabShift;
        s.grabShift = sh;
        if (pressed && ++s.grabPresses >= 8) {
            W.bar(v, "worldboss.dragonminez.metal_cooler_core.bind.escaped", [], "#55FF55");
            releaseGGrab(R, true); s.grabEnd = t; stun(R, 20);
            return;
        }
        if (pressed) { W.bar(v, "worldboss.dragonminez.metal_cooler_core.bind.progress", [{ meter: s.grabPresses, of: 8 }], "#FFFFFF"); snd(R, "minecraft:block.chain.hit", 1.0, 0.8 + s.grabPresses * 0.05, v); }
        if (held > 0 && held % 10 === 0) { hit(R, v, W.melee(R) * 0.25, "melee"); snd(R, "critic_punch1", 1.6, 0.6, v); }
        if (held >= 60) {
            var fw = dirYaw(R.m.bodyYaw !== undefined ? R.m.bodyYaw : R.m.yaw);
            releaseGGrab(R, false);
            hit(R, v, W.melee(R) * 1.2, "melee");
            kb(v, fw.x * 2.0, -1.2, fw.z * 2.0);
            snd(R, "knockback_character", 2.5, 0.6, v);
            s.grabEnd = t;
        }
    }
    function closeHand(R, t) {
        var s = R.s, best = null, bd = 1e9;
        gParticipants(R).forEach(function (p) {
            if (!canHold(R, p)) return;
            var d = Math.pow(p.x - s.grabSpot.x, 2) + Math.pow(p.z - s.grabSpot.z, 2);
            if (d > 3.5 * 3.5 || Math.abs(p.y - s.grabSpot.y) > 4 || d >= bd) return;
            bd = d; best = p;
        });
        if (!best) {
            s.grabEnd = t;
            var g = ground(R, s.grabSpot.x, s.grabSpot.z, s.grabSpot.y);
            part(R, "minecraft:poof", s.grabSpot.x, g + 0.3, s.grabSpot.z, 40, 1.2, 0.3);
            snd(R, "anchor_slam", 3.0, 0.7, { x: s.grabSpot.x, y: g, z: s.grabSpot.z });
            return;
        }
        s.grab = best; s.grabStart = t;
        snd(R, "minecraft:entity.ravager.roar", 3.0, 0.7, best);
    }
    function releaseGGrab(R, escaped) {
        var s = R.s, v = s.grab;
        if (!v) return;
        s.grab = null;
        if (alive(v)) { v.removeEffect("stunned"); RPG.net.send(v, "dmz_wb_title", { clear: true }); if (escaped) kb(v, 0, 0.6, 0); }
    }
    function gEruption(R, t) {
        var s = R.s;
        if (t === 1) {
            s.lockYaw = R.m.yaw;
            var h = W.home(R);
            s.er = { x: h.x, y: ground(R, h.x, h.z, h.y + 3), z: h.z };
            gParticipants(R).forEach(function (p) { W.chat(p, "worldboss.dragonminez.gomah.eruption", [], "#AA0000"); p.playSound("minecraft:entity.elder_guardian.curse", 1.0, 0.6); });
            snd(R, "minecraft:entity.wither.spawn", 4.0, 0.5);
        }
        face(R, s.lockYaw);
        if (!s.er) return;
        if (t < 200) {
            if (t % 20 !== 1) return;
            mark(R, s.er.x, s.er.y, s.er.z, G_ISLAND, MARK_G, 22, -1);
            var sec = Math.ceil((200 - t) / 20);
            announce(gParticipants(R), "worldboss.dragonminez.gomah.eruption_countdown", [sec], "#FF5555");
            gParticipants(R).forEach(function (p) { p.playSound("minecraft:block.note_block.basedrum", 1.0, 0.6); if (sec <= 5) W.chat(p, "worldboss.dragonminez.gomah.eruption_countdown", [sec], "#FF5555"); });
            part(R, "minecraft:dust", R.m.x, R.m.y + R.m.height * 0.5, R.m.z, 20, 2 + (200 - t) * 0.02, 0);
            return;
        }
        if (t === 200) {
            var c = s.er, dmg = W.ki(R) * 2.0;
            gParticipants(R).forEach(function (p) {
                hit(R, p, dmg, "ki");
                var ax = p.x - c.x, az = p.z - c.z, l = Math.sqrt(ax * ax + az * az);
                kb(p, l < 0.01 ? 0 : ax / l * 1.2, 1.2, l < 0.01 ? 0 : az / l * 1.2);
            });
            shock(R, c.x, c.y + 0.5, c.z, G_ISLAND * 1.3, QUAKE_C, 30);
            burst(R, 60);
            snd(R, "ki_explosion_impact", 6.0, 0.4, c); snd(R, "minecraft:entity.generic.explode", 6.0, 0.5, c);
            var NR = setStacks(R, gStacks(R) - 2);
            NR.s.prog = 0; NR.s.king = 0;
            announce(gParticipants(NR), "worldboss.dragonminez.gomah.eruption_spent", [], "#FFAA00");
        }
    }
    function callEscorts(R) {
        var s = R.s;
        s.escorts = (s.escorts || []).filter(function (u) { return alive(RPG.world.entityByUuid(u)); });
        var n = Math.min(3, 4 - s.escorts.length);
        if (n <= 0) return;
        var ps = gParticipants(R), by = (R.m.bodyYaw !== undefined ? R.m.bodyYaw : R.m.yaw) * D2R;
        for (var i = 0; i < n; i++) {
            var id = i % 2 === 0 ? "wb_gomah_escort_1" : "wb_gomah_escort_2";
            var a = by + Math.PI + (i - (n - 1) / 2) * 0.7, d = R.m.width + 3, x = R.m.x - Math.sin(a) * d, z = R.m.z + Math.cos(a) * d, y = ground(R, x, z, R.m.y + 2);
            var e = RPG.world.spawnMob(R.m.dimension, id, x, y, z);
            if (!e) continue;
            W.setupMob(e, W.MINIONS[id], 3);
            if (ps.length) e.target = ps[Math.floor(rnd() * ps.length)];
            s.escorts.push(String(e.uuid));
            part(R, "minecraft:dust", x, y + 1, z, 30, 0.5, 0);
        }
        snd(R, "minecraft:entity.evoker.prepare_summon", 2.5, 0.7);
        announce(ps, "worldboss.dragonminez.gomah.escorts", [], "#AA00AA");
    }
    function tickEscorts(R) {
        var s = R.s;
        if (!s.escorts || !s.escorts.length || now() % 20 !== 0) return;
        var ps = null;
        s.escorts = s.escorts.filter(function (u) {
            var e = RPG.world.entityByUuid(u);
            if (!alive(e)) return false;
            if (!e.target || !alive(e.target)) { ps = ps || gParticipants(R); if (ps.length) e.target = ps[Math.floor(rnd() * ps.length)]; }
            return true;
        });
    }
    function clearEscorts(R) {
        (R.s.escorts || []).forEach(function (u) { var e = RPG.world.entityByUuid(u); if (alive(e)) { part(R, "minecraft:dust", e.x, e.y + 1, e.z, 20, 0.5, 0); e.remove(); } });
        R.s.escorts = [];
    }
    for (var gi = 0; gi < 6; gi++) AI[gi === 0 ? "wb_gomah" : "wb_gomah_s" + gi] = G;

    // ---- hits by the bosses' side: Mini Janemba knocks back and retreats, Gomah's melee feeds his eye ----
    RPG.on("damageFinal", function (e) {
        var a = e.attacker, t = e.target;
        if (!a || !t || e.isCancelled() || a.isPlayer()) return;
        var id = String(a.rpgId || "");
        if (id === "wb_mini_janemba" && e.kind === "melee") {
            var dx = t.x - a.x, dz = t.z - a.z, l = Math.sqrt(dx * dx + dz * dz);
            if (l > 1e-4) kb(t, dx / l * 1.35, 0.42, dz / l * 1.35);
            MINI_RETREAT[a.uuid] = { until: now() + 26, from: t };
            return;
        }
        if (id.indexOf("wb_gomah") === 0 && id.indexOf("escort") < 0 && e.kind === "melee" && t.isPlayer()) {
            var R = W.rt(a);
            if (R && !R.asleep) addProgress(R, 0.05);
        }
    });
    // a ki shot / kill driver fired by Turles carries his kill driver colours: nothing else to do here
    // Super Janemba's Mouth Blast: the red circle under the target while it charges (startCasting -> BossTelegraphS2C)
    if (DMZ_SAGA.onCast) DMZ_SAGA.onCast("wb_super_janemba", function (m, type, t) {
        if (type !== 9 || !t) return;
        var R = W.rt(m);
        if (R) mark(R, t.x, ground(R, t.x, t.z, t.y), t.z, 5, 0xFF2A2A, 37, -1);
    });
})();
