// =====================================================================================
//  88_dbr_space_vegeta.js - Planet Vegeta's people (port of DMZ Ragnarok, GPL-3.0)
// =====================================================================================
//  - Saiyan settlements: DMZR's saiyan_settlement jigsaw (crossroads, roads, turns, buildings)
//    and saibaman_hut generate in Vegeta's biomes from the data pack (datapack/data/dbr/worldgen,
//    DMZR's templates, spacing and salts). Each outpost holds a hostile squad of 4..7 saiyans,
//    rolled once the first time a player comes near it (PlanetGarrison.ensureNeutralSettlements:
//    the player's spot and four points 48 blocks out are sampled); killed saiyans stay dead.
//  - Saibaman huts keep one or two saibamen about them (DMZR's spawn_overrides: saibaman 1..6,
//    weights 100/80/60/40/25/15).
//  - The capital (DMZR's city box, -318..670 x -322..351, round the landing spot): tiled into
//    48-block cells, each filled once with 1..3 peaceful saiyan citizens and, one cell in five,
//    a saiyan trader, as players walk in.
//  - The trader (SaiyanTraderEntity): saiyan gear for emeralds. Three random offers from DMZR's
//    pool the first time he is opened, each with its own uses; trading earns him experience and
//    each villager level (10/70/150/250 xp) adds one more offer. Offers run out, no restock
//    (DMZR traders are nitwits: no workstation).
//  DMZR's Vegeta capital itself is pre-built terrain (its shipped region files): converted by
//  tools/dmzr_regions.py into regions/ragnarok_rpg/planet_vegeta/, the engine seeds it into the world
//  at DMZR's coordinates round the landing spot (155, 65, -75) before Vegeta loads; a world that already
//  generated that ground gets it too unless someone built there (regions/.../seed.json).
// =====================================================================================
var DBR_VEGETA = (function () {
    var DIM = "ragnarok_rpg:planet_vegeta", SETTLEMENT = "dbr:saiyan_settlement", HUT = "dbr:saibaman_hut";
    var CITY = { minX: -318, maxX: 670, minZ: -322, maxZ: 351, cell: 48 };
    var REACH = 48, GARRISON_MIN = 4, GARRISON_MAX = 7, CITIZENS_MIN = 1, CITIZENS_MAX = 3, TRADER_CHANCE = 0.2, ATTEMPTS = 12;

    // ---- the people: DMZR's saiyans wear the custom-character look; here the Ragnarok classic saiyan models ----
    function saiyanGeo(n) {
        var r = typeof RG_NPC_INDEX !== "undefined" ? RG_NPC_INDEX["saga_cl_saiyan" + n] : null;
        if (!r) return sagaLook("saga_raditz");
        return dmzSagaStates({ model: "dbr:geo/entity/rgnpc/" + r[1] + ".geo.json", texture: "dbr:textures/entity/rgnpc/" + r[2] + ".png",
            animation: DMZ_ANIM + "sagas/saga_base.animation.json", idle: "idle", walk: "walk", attack: "attack1_1", scale: 1.0 });
    }
    // the garrison saiyan: hostile, statted to the Vegeta saiyan tier (a Frieza soldier, DMZR applyVegetaSaiyanStats) and
    // driven by the DMZ saga brain so it fights with ki
    [1, 2].forEach(function (n) {
        RPG.mobs.define("dbr_vegeta_saiyan_" + n, {
            name: "&6Saiyan", geo: saiyanGeo(n), width: 1.0, height: 2.0,
            health: 100, damage: 15, armor: 0, speed: 0.25, followRange: 40, xp: 90, hostile: true, persistent: true,
            loot: [{ item: "minecraft:iron_ingot", count: 1 }, { item: "minecraft:emerald", chance: 0.35 }],
            onTick: function (mob) { if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onTick(mob); },
            onDeath: function (mob, killer) {
                if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onDeath(mob);
                if (typeof payKiller === "function") payKiller(killer, 20, 60);
            }
        });
        if (typeof DMZ_SAGA_ALIAS !== "undefined") DMZ_SAGA_ALIAS["dbr_vegeta_saiyan_" + n] = "saga_friezasoldier01";
        // the citizen: passive by construction (wanders, looks at players, never fights)
        RPG.npcs.define("dbr_saiyan_citizen_" + n, { name: "&fSaiyan", geo: saiyanGeo(n), width: 0.6, height: 1.8, wander: true });
        RPG.npcs.define("dbr_saiyan_trader_" + n, { name: "&eSaiyan Trader", geo: saiyanGeo(n), width: 0.6, height: 1.95, wander: true,
            onInteract: function (player, npc) { openTrades(player, npc); return false; } });
    });

    // ---- saved state: which outposts / huts / city cells are filled (PlanetGarrisonData.neutralSettlements) ----
    var MEM = null;
    function state() { if (!MEM) MEM = RPG.data.get("dbr_vegeta_pop", null) || { s: {}, c: {}, h: {} }; return MEM; }
    function save() { RPG.data.set("dbr_vegeta_pop", MEM); }

    function ground(x, z) {
        x = Math.floor(x); z = Math.floor(z);
        if (!RPG.world.isLoaded(DIM, x, z)) return null;
        var y = RPG.world.surfaceY(DIM, x, z);
        if (y <= -9999) return null;
        var below = String(RPG.world.getBlock(DIM, x, y - 1, z));
        if (below.indexOf("water") >= 0 || below.indexOf("lava") >= 0 || below === "minecraft:air") return null;
        if (String(RPG.world.getBlock(DIM, x, y, z)) !== "minecraft:air" || String(RPG.world.getBlock(DIM, x, y + 1, z)) !== "minecraft:air") return null;
        return { x: x + 0.5, y: y, z: z + 0.5 };
    }
    function spotIn(minX, maxX, minZ, maxZ) {
        for (var i = 0; i < ATTEMPTS; i++) {
            var g = ground(minX + Math.floor(Math.random() * (maxX - minX + 1)), minZ + Math.floor(Math.random() * (maxZ - minZ + 1)));
            if (g) return g;
        }
        return null;
    }
    function rint(a, b) { return a >= b ? a : a + Math.floor(Math.random() * (b - a + 1)); }

    // ---- wilderness outposts: a hostile squad each ----
    function populateSettlement(st) {
        var n = rint(GARRISON_MIN, GARRISON_MAX), spawned = 0;
        for (var i = 0; i < n; i++) {
            var g = spotIn(st.minX, st.maxX, st.minZ, st.maxZ);
            if (!g) continue;
            var m = RPG.world.spawnMob(DIM, "dbr_vegeta_saiyan_" + rint(1, 2), g.x, g.y, g.z);
            if (m) { m.addTag("dbr_vegeta_garrison"); spawned++; }
        }
        return spawned;
    }
    // ---- saibaman huts (spawn_overrides): one or two saibamen about each hut, topped up now and then ----
    var SAIBAMEN = [["saibaman", 100, 2], ["saibaman_2", 80, 2], ["saibaman_3", 60, 2], ["saibaman_4", 40, 2], ["saibaman_5", 25, 2], ["saibaman_6", 15, 1]];
    function hutTick(st, key) {
        var h = state().h, rec = h[key] || { t: 0 }, t = RPG.server.getTick();
        if (rec.t && t - rec.t < 1200) return;
        var cx = (st.minX + st.maxX) / 2, cz = (st.minZ + st.maxZ) / 2;
        // HutSaibamanCropProcessor: once per hut, saibaman plants on its floor (33 % one at the centre, 33 % 1-3 more);
        // its buried seeds come from the data pack's processors (hut_saibaman_seeds_*)
        if (!rec.sd && typeof DBR_SAIBAMEN !== "undefined" && RPG.world.isLoaded(DIM, st.minX, st.minZ) && RPG.world.isLoaded(DIM, st.maxX, st.maxZ)
            && RPG.world.isLoaded(DIM, st.minX, st.maxZ) && RPG.world.isLoaded(DIM, st.maxX, st.minZ) && DBR_SAIBAMEN.plantStructureHut(DIM, st)) rec.sd = 1;
        var near = RPG.world.entitiesNear(DIM, cx, (st.minY + st.maxY) / 2, cz, 24).filter(function (e) { return e.hasTag("dbr_hut_" + key); });
        rec.t = t; h[key] = rec; save();
        if (near.length) return;
        var total = 0; SAIBAMEN.forEach(function (e) { total += e[1]; });
        var roll = Math.random() * total, pick = SAIBAMEN[0];
        for (var i = 0; i < SAIBAMEN.length; i++) { roll -= SAIBAMEN[i][1]; if (roll < 0) { pick = SAIBAMEN[i]; break; } }
        var count = rint(1, pick[2]);
        for (var k = 0; k < count; k++) {
            var g = spotIn(st.minX - 4, st.maxX + 4, st.minZ - 4, st.maxZ + 4);
            if (!g) continue;
            var m = RPG.world.spawnMob(DIM, pick[0], g.x, g.y, g.z);
            if (m) m.addTag("dbr_hut_" + key);
        }
    }
    // ---- the capital: peaceful citizens and the odd trader, cell by cell ----
    function cityCells(p) {
        var ccx = Math.floor(p.x / CITY.cell), ccz = Math.floor(p.z / CITY.cell), c = state().c, changed = false;
        for (var a = -1; a <= 1; a++) for (var b = -1; b <= 1; b++) {
            var cx = ccx + a, cz = ccz + b;
            var minX = Math.max(cx * CITY.cell, CITY.minX), minZ = Math.max(cz * CITY.cell, CITY.minZ);
            var maxX = Math.min(cx * CITY.cell + CITY.cell - 1, CITY.maxX), maxZ = Math.min(cz * CITY.cell + CITY.cell - 1, CITY.maxZ);
            if (minX > maxX || minZ > maxZ) continue;
            var key = cx + "," + cz;
            if (c[key]) continue;
            var n = rint(CITIZENS_MIN, CITIZENS_MAX), spawned = 0;
            for (var i = 0; i < n; i++) {
                var g = spotIn(minX, maxX, minZ, maxZ);
                if (g && RPG.world.spawnNpc(DIM, "dbr_saiyan_citizen_" + rint(1, 2), g.x, g.y, g.z)) spawned++;
            }
            if (Math.random() < TRADER_CHANCE) {
                var tg = spotIn(minX, maxX, minZ, maxZ);
                if (tg && RPG.world.spawnNpc(DIM, "dbr_saiyan_trader_" + rint(1, 2), tg.x, tg.y, tg.z)) spawned++;
            }
            // marked only once someone joined (a cell whose chunks were still loading is tried again later)
            if (spawned > 0) { c[key] = 1; changed = true; }
        }
        if (changed) save();
    }
    // RPG.world.structureStart is an engine addition (structure footprints): an older engine just has no outposts filled
    var HAS_STARTS = true;
    try { RPG.world.structureStart(DIM, 0, 0, 0, SETTLEMENT); } catch (e) { HAS_STARTS = false; RPG.log("[DBR] vegeta: this engine has no RPG.world.structureStart; settlement garrisons are off"); }
    function roam(p) {
        if (p.dimension !== DIM || !p.alive) return;
        cityCells(p);
        if (!HAS_STARTS) return;
        var pts = [[0, 0], [REACH, 0], [-REACH, 0], [0, REACH], [0, -REACH]], y = Math.floor(p.y);
        pts.forEach(function (o) {
            var x = Math.floor(p.x) + o[0], z = Math.floor(p.z) + o[1];
            if (!RPG.world.isLoaded(DIM, x, z)) return;      // never force-generate a chunk for this
            var st = RPG.world.structureStart(DIM, x, y, z, SETTLEMENT);
            if (st) {
                var key = st.chunkX + "," + st.chunkZ, s = state().s;
                if (!s[key] && populateSettlement(st) > 0) { s[key] = 1; save(); }
            }
            var hut = RPG.world.structureStart(DIM, x, y, z, HUT);
            if (hut) hutTick(hut, hut.chunkX + "_" + hut.chunkZ);
        });
    }
    RPG.every(40, function () {
        if (!RPG.server.hasDimension(DIM)) return;
        RPG.server.players().forEach(function (p) { try { roam(p); } catch (err) { RPG.log("[DBR] vegeta: " + err); } });
    });

    // ---- the saiyan trader's offers (SaiyanTraderEntity.TRADES: input, second input, output, max uses, xp) ----
    var TRADES = [
        // DMZR's first offer is the Space Pod chip (64 emeralds + 16 diamonds), an item this addon doesn't have: DMZR
        // skips a trade whose item is missing, and so does this list
        [["minecraft:emerald", 24], null, ["vegeta_saiyan_armor_chestplate", 1], 4, 12],
        [["minecraft:emerald", 20], null, ["vegeta_saiyan_armor_leggings", 1], 4, 12],
        [["minecraft:emerald", 14], null, ["vegeta_saiyan_armor_boots", 1], 4, 10],
        [["minecraft:emerald", 6], null, ["red_scouter", 1], 8, 4],
        [["minecraft:emerald", 6], null, ["blue_scouter", 1], 8, 4],
        [["minecraft:emerald", 6], null, ["green_scouter", 1], 8, 4],
        [["minecraft:emerald", 6], null, ["purple_scouter", 1], 8, 4],
        [["minecraft:emerald", 4], null, ["t1_radar_chip", 1], 8, 3],
        [["minecraft:emerald", 16], null, ["t2_radar_chip", 1], 4, 6]
    ];
    var LEVEL_XP = [10, 70, 150, 250];                  // vanilla villager level thresholds
    function traderData(npc) {
        var all = RPG.data.get("dbr_saiyan_traders", null) || {}, d = all[npc.uuid];
        if (!d) {
            // updateTrades on first open: three distinct random offers
            var pool = TRADES.map(function (t, i) { return i; }), offers = [];
            for (var i = 0; i < 3 && pool.length; i++) offers.push({ t: pool.splice(Math.floor(Math.random() * pool.length), 1)[0], used: 0 });
            d = all[npc.uuid] = { offers: offers, xp: 0, level: 1 };
            RPG.data.set("dbr_saiyan_traders", all);
        }
        return d;
    }
    function saveTrader(npc, d) { var all = RPG.data.get("dbr_saiyan_traders", null) || {}; all[npc.uuid] = d; RPG.data.set("dbr_saiyan_traders", all); }
    function stack(e, extra) {
        var o = { id: e[0], count: e[1] };
        if (extra) for (var k in extra) o[k] = extra[k];
        return o;
    }
    function openTrades(player, npc) {
        var d = traderData(npc), rows = Math.max(1, Math.min(6, d.offers.length)), items = {};
        d.offers.forEach(function (o, r) {
            if (r >= 6) return;
            var t = TRADES[o.t], left = t[3] - o.used;
            items[r * 9 + 1] = stack(t[0]);
            if (t[1]) items[r * 9 + 2] = stack(t[1]);
            items[r * 9 + 4] = { id: "minecraft:arrow", count: 1, name: "&7for" };
            items[r * 9 + 6] = stack(t[2], { lore: [left > 0 ? "&7Uses left: &f" + left + "/" + t[3] : "&cOut of stock", "&eClick to trade"] });
        });
        RPG.ui.container(player, {
            title: "Saiyan Trader", rows: rows, mode: "menu", items: items,
            onClick: function (p, slot) {
                var r = Math.floor(slot / 9), o = d.offers[r];
                if (!o || slot % 9 !== 6) return false;
                var t = TRADES[o.t];
                if (o.used >= t[3]) { p.actionbar("&cHe has none of those left."); return false; }
                if (!p.hasItem(t[0][0], t[0][1]) || (t[1] && !p.hasItem(t[1][0], t[1][1]))) { p.actionbar("&cYou need " + t[0][1] + " emeralds" + (t[1] ? " and " + t[1][1] + " " + t[1][0] : "") + "."); return false; }
                p.takeItem(t[0][0], t[0][1]);
                if (t[1]) p.takeItem(t[1][0], t[1][1]);
                p.giveItem(t[2][0], t[2][1]);
                o.used++;
                d.xp += t[4];
                p.playSound("minecraft:entity.experience_orb.pickup", 1, 1);
                // a new villager level: one more offer he does not have yet
                while (d.level <= LEVEL_XP.length && d.xp >= LEVEL_XP[d.level - 1]) {
                    d.level++;
                    var have = d.offers.map(function (x) { return x.t; }), avail = TRADES.map(function (x, i) { return i; }).filter(function (i) { return have.indexOf(i) < 0; });
                    if (avail.length) d.offers.push({ t: avail[Math.floor(Math.random() * avail.length)], used: 0 });
                }
                saveTrader(npc, d);
                RPG.schedule(1, function () { openTrades(p, npc); });
                return false;
            }
        });
    }

    return { roam: roam, openTrades: openTrades, state: state };
})();
