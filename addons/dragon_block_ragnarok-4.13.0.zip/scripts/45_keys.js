// =====================================================================================
//  45_keys.js - DMZ controls: charge ki, fly, dash, lock on, instant transmission
// =====================================================================================
//  Every player has 20 action keys (Options > Controls > "Ragnarok RPG"). Keys 1-8 are DMZ's
//  technique slots (below, 41_dmz_techniques.js). The defaults follow DMZ:
//      1-4 Alt+1..4   5-8 Ctrl+1..4   9 C   10 V   11 R   12 G   13 Z   14 H
//      15 Alt+C   16 F   17 Alt+G   18 X   19 Ctrl+G   20 unbound
//  Left Alt + F switches the flight mode (44_dmz_flight.js); F4 cycles Ki Sense / the scouter info
//  (a client key, client/scripts/46_dmz_senses.js).
//
//  RPG.keys.define(n, {
//      name: "Charge Ki",                     shown in Controls and on the HUD
//      onPress(player)                        key went down
//      onHold(player, ticksHeld)              every holdInterval ticks while held
//      holdInterval: 5,
//      onRelease(player, ticksHeld)           key came up
//  })
//  Events keyPress(player, key) / keyRelease(player, key, ticks) fire for every key too.
//
//  A shooter would make key 9 "Reload" and key 11 "Sprint"; Zelda would make key 9
//  "Shield" and key 13 "Z-target". Nothing below is special to the engine.
// =====================================================================================

// ---- Alt+1..4 / Ctrl+1..4: technique slots 1-8 (DMZ KeyBinds.TECHNIQUE_SLOT_1..8) --------------
// Defining keys 1-8 replaces the engine's skill-bar cast: DMZ's own slots live in 41_dmz_techniques.js.
// Ki attacks charge while the key is held and fire on release (or by themselves, per type).
times(8, (i) => {
    defineKey(i + 1, {
        name: "Technique Slot " + (i + 1) + " (Bar " + (i < 4 ? 1 : 2) + ")",
        defaultKey: String(i % 4 + 1), modifier: i < 4 ? "alt" : "ctrl",
        onPress(player) { DMZ_TECH.press(player, i); },
        onRelease(player, ticks) { DMZ_TECH.release(player, i); }
    });
});

// ---- C: Charge Ki (hold) ---------------------------------------------------------------
// While held: the charge pose, your aura (in your own "aura" colour) and fast ki refill.
RPG.effects.define("ki_charge", {
    name: "&bCharging",
    color: "#7FFFFF",
    hidden: true,                                   // not listed on the HUD
    // color "aura" = the player's own aura colour (/rpgc color aura #FF0000)
    aura: DMZ_AURA.spec({ texture: AURA_KAKAROT, frames: 4, speed: 10, color: "aura", scale: 1.0, alpha: 0.75 }),   // 29_dmz_auras.js
    attributes: { "minecraft:generic.movement_speed": { amount: -0.6, operation: "multiply_total" } }
});

defineKey(9, {
    name: "Charge Ki",
    defaultKey: "c",
    holdInterval: 2,
    onPress(player) {
        if (typeof DMZ_SURGE !== "undefined" && DMZ_SURGE.chargeLocked(player)) return;   // a hit just broke the charge
        player.addEffect("ki_charge", -1);
        player.setVar("dmz_charge_ticks", 0);
        sfx(player, "aura_start", 1, 1);
    },
    // DMZ (TickHandler.chargePowerRelease): every 2 ticks the power release climbs, faster the
    // longer you hold, up to your cap; ki refills at 1.5x your normal rate while charging.
    onHold(player, ticks) {
        if (!player.hasEffect("ki_charge")) return;                 // interrupted by a hit (64_dmz_surge.js)
        let v = dmzView(player), charge = (Number(player.getVar("dmz_charge_ticks", 0)) || 0) + 2;
        player.setVar("dmz_charge_ticks", charge);
        let max = DMZ_F.maxRelease(Number(player.getVar("dmz_potential", 0)), player.race === "saiyan" ? 1 + Math.min(0.15, Number(player.getVar("dmz_zenkai_release", 0)) || 0) : 1, player.getVar("dmzr_release_boost", 0));
        let rel = Number(player.getVar("dmz_release", 0)) || 0;
        let step = DMZ_F.releaseStep(charge, Number(player.getVar("dmz_potential", 0)));
        rel = player.getVar("dmz_lowering", 0) ? Math.max(0, rel - step) : Math.min(max, rel + step);
        if (rel !== Number(player.getVar("dmz_release", 0))) player.setVar("dmz_release", rel);
        if (ticks % 20 === 0) {
            // (not while a saibaman plant beside you drinks the ki: 86b_dbr_saibamen.js)
            if (!(typeof DBR_SAIBAMEN !== "undefined" && DBR_SAIBAMEN.regenSuppressed(player)))
                player.addResource("ki", Math.ceil(DMZ_F.kiRegen(v, true) * DMZ_F.foodMult(player.food) * 100) / 100);
            if (ticks % 40 === 0) sfx(player, "ki_charge_loop", 0.7, 1);
        }
    },
    onRelease(player, ticks) {
        player.removeEffect("ki_charge");
        player.setVar("dmz_lowering", 0);
        resumeHeld(player);
    }
});

// ---- F: Fly (toggle) / Left Alt + F: flight mode -----------------------------------------
// DMZ flight (64_dmz_movement.js + client/scripts/44_dmz_flight.js): needs Ki Control and Fly,
// power release 5 %+. On the ground you jump and fly from the top of the jump; press again to
// slow down and land. Search mode: inertial, sprint for fast flight. Combat mode: snappy, double-tap
// a direction for an impulse. Holding Left Alt while pressing F switches the mode.
defineKey(16, {
    name: "Fly",
    defaultKey: "f",
    onPress(player) { DMZ_FLIGHT.keyPress(player); }
});

// ---- R: Dash ---------------------------------------------------------------------------
// DMZ DashHandler: in the direction you move (forward with no input), stamina on the ground and
// ki in flight, 4 s cooldown; press again within 300 ms for a double dash (12 s); right after
// being hit it becomes a perfect evasion. Not in combat flight (that has impulses).
defineKey(11, {
    name: "Dash",
    defaultKey: "r",
    onPress(player) { DMZ_FLIGHT.dashKey(player); }
});

// ---- G: DMZ action key (transform) and its chords -------------------------------------
// DMZ (KeyBinds / ClientStatsEvents): G held charges the selected action (FORM: the next form,
// STACK: the next stack form, RACIAL: your race's ability), double-tap G = instant transform,
// Alt+G descends one form (racial secondary in RACIAL mode), X opens the form menu.
// Extras: Ctrl+G charges the next stack form and key 20 the racial action, whatever the mode.
// The logic lives in 31_dmz_transform.js (DMZ_TF.KEYS).
RPG.effects.define("meditating", {           // DMZ meditation pose (other scripts still use the effect)
    name: "&3Meditating",
    color: "#5FA8D3",
    hidden: true,
    attributes: { "minecraft:generic.movement_speed": { amount: -0.9, operation: "multiply_total" } }
});

defineKey(12, {
    name: "Transform / Action (hold)",
    defaultKey: "g",
    holdInterval: 10,
    doubleTapTicks: 10,                       // DMZ: two taps within 500 ms
    onPress(player) { DMZ_TF.KEYS.actionPress(player); },
    onHold(player, ticks) { DMZ_TF.KEYS.actionHold(player); },
    onRelease(player, ticks) { DMZ_TF.KEYS.actionRelease(player); },
    onDoubleTap(player) { DMZ_TF.KEYS.actionDoubleTap(player); }
});

defineKey(17, {
    name: "Descend Form / Racial Secondary",
    defaultKey: "g", modifier: "alt",
    onPress(player) { DMZ_TF.KEYS.descendPress(player); },
    onRelease(player, ticks) { DMZ_TF.KEYS.descendRelease(player); }
});

defineKey(18, {
    name: "Form Menu",
    defaultKey: "x",
    onPress(player) { DMZ_TF.KEYS.menu(player); }
});

defineKey(19, {
    name: "Stack Transform (hold)",
    defaultKey: "g", modifier: "ctrl",
    holdInterval: 10,
    doubleTapTicks: 10,
    onPress(player) { DMZ_TF.KEYS.stackPress(player); },
    onRelease(player, ticks) { DMZ_TF.KEYS.stackRelease(player); },
    onDoubleTap(player) { DMZ_TF.KEYS.stackDoubleTap(player); }
});

defineKey(20, {
    name: "Racial Action (hold)",
    holdInterval: 10,
    onPress(player) { DMZ_TF.KEYS.racialPress(player); },
    onRelease(player, ticks) { DMZ_TF.KEYS.racialRelease(player); }
});

// ---- Z: Lock on ------------------------------------------------------------------------
// DMZ LockOnEvent: needs Ki Sense; range 15 + 5 per level (+25 android). The camera follows the
// target and a reticle spins on it (client/scripts/46_dmz_senses.js); techniques aim at it.
defineKey(13, {
    name: "Lock On",
    defaultKey: "z",
    onPress(player) { DMZ_SENSES.lockPress(player); }
});

// ---- H: Instant Transmission ------------------------------------------------------------
// Tap: appear behind the target in front of you (or your lock). Hold (level 5+): the destination
// screen (masters whose ki you know, party members, players of similar power).
defineKey(14, {
    name: "Instant Transmission",
    defaultKey: "h",
    holdInterval: 2,
    onPress(player) { DMZ_SENSES.itPress(player); },
    onHold(player, ticks) { DMZ_SENSES.itHold(player, ticks); },
    onRelease(player, ticks) { DMZ_SENSES.itRelease(player, ticks); }
});

// ---- Alt+C: Lower power release (hold) ------------------------------------------------------
defineKey(15, {
    name: "Lower Release",
    defaultKey: "c", modifier: "alt", holdInterval: 2,
    onPress(player) { player.setVar("dmz_lowering", 1); DBR_KEYS[9].onPress(player); },
    onHold(player, ticks) { DBR_KEYS[9].onHold(player, ticks); },
    onRelease(player, ticks) { DBR_KEYS[9].onRelease(player, ticks); }
});

// ---- V: Stats menu (DMZ's CharacterStatsScreen; the creator if you have no character yet) ----
defineKey(10, {
    name: "Stats Menu",
    defaultKey: "v",
    onPress(player) {
        RPG.net.send(player, player.getVar("dmz_created", 0) ? "dmz_open_stats" : "dmz_open_creator", {});
        uiSfx(player, "dmzpack:ui_menu_switch", 1, 1);
    }
});
