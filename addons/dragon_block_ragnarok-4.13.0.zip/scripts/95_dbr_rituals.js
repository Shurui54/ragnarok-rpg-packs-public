// =====================================================================================
//  95_dbr_rituals.js - DMZ Ragnarok's rituals: the Super Saiyan God charge ritual, the Super Saiyan 5 fusion with
//  Shenron and the Namekian god ritual at a dragon idol
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0) shuruisutilities ritual/{SsgRitualManager, WishRitualManager, WishRitualStore,
//  RitualSettings, RitualAnnouncer, DragonBallRecreation, ShenronIdol*, PacketIdolPrompt/Confirm, SsgKnowledgeCommand},
//  compat/dmz/{RitualForms, RitualFormsCompat, RitualRaceMergeImpl, SuSsj5Wish, SuSsgKnowledgeWish} and api/key/RitualHooks.
//  The forms: shared/07_dmz_forms_data.js (SSJ5 on both SSJ4 ladders, rung 9; Primal Namekian, rung 4), their prices
//  (-1, granted only): shared/03_dmz_skills_data.js. The grave totems for dragon balls: 89_dbr_keep_inventory.js.
//  The idol screen: client/scripts/95_dbr_rituals.js.
//
//  - Knowledge of Super Saiyan God: a Shenron wish shown to Saiyans of level 5000+ (ssgRitual.wishMinLevel). With it,
//    stand charging ki (C) with 5 other charging Saiyans within 6 blocks for 3 s and you become DragonMineZ's own
//    Super Saiyan God (the god ritual form: same timer, expiry and cooldown as DMZ's ritual, 64_dmz_kishare.js).
//    Singleplayer (nobody else can join): ssgRitual.singleplayerRequiredChargers, default 0 = the centre alone.
//  - Every granted wish counts per player and set (Earth, Namek). From the eleventh Earth wish on, a Saiyan in Super
//    Saiyan 4 at level 10000+ is offered "Fuse with Shenron": it costs 5000 levels (taken from random stats, none
//    below zero), grants Super Saiyan 5 (superforms rung 9), is announced to the whole server, and spends the Earth
//    set: its balls are gone and a Shenron Idol is left somewhere within 1000 blocks of spawn (on the Earth radar).
//  - The eleventh Namek wish spends the Namek set the same way and leaves a Porunga Idol (on the Namek radar).
//  - A namekian of level 10000+ who right-clicks an idol (in hand) is offered the bargain: all the balls of that set
//    back in their hands and the Namekian God form (Primal Namekian, superforms rung 4) for 5000 levels; accepting
//    restores the set and is announced to the server. Shift + right-click places the idol; break it to pick it up.
//  (The fusion and the recreation are in DMZ Ragnarok's private Ragnarok Key; their rules here come from the public
//  core's requirements, numbers, lang and prompt, and RitualForms' grants and level cost.)
//  Ops: /rpgc rituals info [player] | wishes <earth|namek> <n> | knowledge | ssj5 | primal | spend <earth|namek> | idol <shenron|porunga>
// =====================================================================================
// hooks 57_dragon_balls.js calls (set below)
var dbrWishVisible = null, dbrWishBlocked = null, dbrRitualWish = null, dbrWishGranted = null;
var DBR_RITUALS = (function () {
    var C = DBR_RITUALS_CFG;
    var RING_RADIUS = 6, HOLD_TICKS = 60, CHECK_INTERVAL = 10;
    var IDOL_SET = { shenron: "earth", porunga: "namek" }, SET_IDOL = { earth: "shenron", namek: "porunga" };
    function now() { return RPG.server.getTick(); }
    function uid(p) { return String(p.uuid); }
    function online(u) { var l = RPG.server.players(); for (var i = 0; i < l.length; i++) if (uid(l[i]) === u) return l[i]; return null; }
    function race(p) { return typeof DMZ_TF !== "undefined" ? DMZ_TF.race(p) : p.race; }
    function level(p) { return p.getLevel(); }
    function reqLevel() { return C.get("wishRituals.requiredLevel"); }
    function cost() { return C.get("wishRituals.levelCost"); }
    function isSsgRace(p) { var r = race(p); return r === "saiyan" || r === "half_saiyan"; }

    // ---- WishRitualStore (player vars, saved with the character) -------------------------------------
    function count(p, set) { return Number(p.getVar("dmzr_wishes_" + set, 0)) || 0; }
    function flag(p, k) { return !!p.getVar("dmzr_ritual_" + k, 0); }
    function setFlag(p, k) { p.setVar("dmzr_ritual_" + k, 1); }

    // ---- RitualAnnouncer: one chat line and a title for everyone online ---------------------------------
    function announce(chat, title, subtitle, colour) {
        RPG.server.broadcast(colour + chat);
        RPG.server.players().forEach(function (v) { v.title(colour + "§l" + title, "§7" + subtitle); });
    }

    // ---- RitualForms.applyLevelCost: remove levels from random stats, none below zero ---------------------
    function applyLevelCost(p, levels) {
        if (levels <= 0) return 0;
        var start = level(p), target = Math.max(1, start - levels), ids = DMZ_DATA.STATS.map(function (k) { return DMZ_DATA.STAT_IDS[k]; });
        var guard = 0;
        while (level(p) > target && guard++ < 400) {
            var have = ids.filter(function (id) { return p.allocated(id) > 0; });
            if (!have.length) break;
            var v = dmzView(p), cm = v.capMult > 1 ? v.capMult : 1, maxV = Math.round(1000000 * cm);
            var perLevel = Math.max(1, (maxV * 6) / Math.max(1, maxV - 1));
            var need = Math.max(1, Math.ceil((level(p) - target) * perLevel)), chunk = Math.max(1, Math.ceil(need / (have.length * 8)));
            var id = have[Math.floor(Math.random() * have.length)];
            p.addStat(id, -Math.min(chunk, p.allocated(id)));
            p.refreshStats();
            if (typeof DMZ_F !== "undefined") p.setLevel(DMZ_F.level(dmzView(p)), { silent: true });
        }
        return start - level(p);
    }
    function raiseSuperform(p, expectRace, rung) {
        if (race(p) !== expectRace || typeof DMZ_SKILLS === "undefined") return false;
        if (DMZ_SKILLS.level(p, "superforms") < rung) DMZ_SKILLS.setLevel(p, "superforms", rung, "ritual");
        if (typeof DMZ_TF !== "undefined") DMZ_TF.refresh(p);
        return true;
    }

    // ---- the wish rows (SuSsgKnowledgeWish / SuSsj5Wish), read by 57_dragon_balls.js ------------------------
    function inSsj4(p) { var f = String(p.getVar("dmz_form", "") || ""); return race(p) === "saiyan" && /:supersaiyan4$/.test(f); }
    function canWishForSsj5(p) {
        return inSsj4(p) && level(p) >= reqLevel() && count(p, "earth") >= C.get("wishRituals.wishThreshold") && !flag(p, "ssj5");
    }
    function ssgWishVisible(p) { return isSsgRace(p) && level(p) >= C.get("ssgRitual.wishMinLevel"); }
    dbrWishVisible = function (p, w) {
        var ssj5 = canWishForSsj5(p);
        if (w.ritual === "ssj5") return ssj5;
        if (w.ritual === "ssg_knowledge") return ssj5 || ssgWishVisible(p);
        return true;
    };
    dbrWishBlocked = function (p, w) {
        if (w.ritual === "ssg_knowledge") {
            if (isSsgRace(p) && level(p) >= C.get("ssgRitual.wishMinLevel") && !flag(p, "ssg_knowledge")) return false;
            if (!isSsgRace(p)) p.tell("The knowledge of Super Saiyan God means nothing to one who is not a saiyan.");
            else if (flag(p, "ssg_knowledge")) p.tell("You already carry the knowledge of Super Saiyan God.");
            else p.tell("The divine power is still beyond your reach. Grow stronger and return at level " + C.get("ssgRitual.wishMinLevel") + ".");
            return true;
        }
        if (w.ritual === "ssj5") {
            if (canWishForSsj5(p)) return false;
            if (level(p) < reqLevel()) p.tell("You feel Shenron's power stir, but you are not yet strong enough. Reach level " + reqLevel() + ".");
            return true;
        }
        return true;
    };
    dbrRitualWish = function (p, w) {
        if (w.ritual === "ssg_knowledge") {                    // SsgKnowledgeCommand.grant
            setFlag(p, "ssg_knowledge");
            p.tell("Shenron grants you the knowledge of Super Saiyan God. " + requiredChargers() + " allies must charge their ki around you while you hold your transformation.");
            RPG.log("[ritual] " + p.name + " wished for the knowledge of Super Saiyan God.");
        } else if (w.ritual === "ssj5") fuseWithShenron(p);
    };
    function fuseWithShenron(p) {
        var lost = applyLevelCost(p, cost());
        raiseSuperform(p, "saiyan", 9);
        setFlag(p, "ssj5");
        p.tell("§bYou fuse with Shenron and awaken Super Saiyan 5!");
        announce(p.name + " has fused with the eternal dragon and awakened Super Saiyan 5!", "Super Saiyan 5", p.name + " fused with Shenron", "§b");
        spendSet("earth");
        RPG.log("[ritual] " + p.name + " fused with Shenron (Super Saiyan 5), " + lost + " levels taken");
    }
    /** WishRitualManager.onWishGranted: count every wish of the Earth and Namek sets; the eleventh Namek wish spends it. */
    dbrWishGranted = function (p, set, wishes) {
        if (set !== "earth" && set !== "namek") return;
        var n = count(p, set) + wishes;
        p.setVar("dmzr_wishes_" + set, n);
        if (set === "namek" && n > C.get("wishRituals.wishThreshold") && !(dbrBallSet && dbrBallSet.isSpent("namek"))) spendSet("namek");
    };

    // ---- spent sets and the idols (ShenronIdol, the key's ShenronIdolSpawner) ----------------------------
    function idols() { var v = RPG.data.get("dbr_idols", null); return v && typeof v === "object" ? v : {}; }
    function saveIdols(v) { RPG.data.set("dbr_idols", v); }
    function spendSet(set) {
        if (!dbrBallSet) return;
        // a summoned dragon's set scatters as it leaves: spend it once that has happened
        RPG.schedule(80, function () {
            dbrBallSet.spend(set);
            var sp = RPG.world.spawnPoint(), r = 1000, v = idols(), key = set + "@" + now();
            v[key] = { dragon: SET_IDOL[set], dim: DB_SETS[set].dim, x: Math.floor((sp.x || 0) + (Math.random() * 2 - 1) * r), z: Math.floor((sp.z || 0) + (Math.random() * 2 - 1) * r), y: null };
            saveIdols(v);
            RPG.log("[ritual] the " + set + " set is spent; a " + SET_IDOL[set] + " idol waits at " + v[key].x + ", " + v[key].z);
        });
    }
    RPG.every(40, function () {                  // drop a waiting idol once its chunk is loaded (like a scattered ball)
        var v = idols(), changed = false;
        Object.keys(v).forEach(function (k) {
            var e = v[k];
            if (e.y !== null || !RPG.server.hasDimension(e.dim) || !RPG.world.isLoaded(e.dim, e.x, e.z)) return;
            var y = RPG.world.surfaceY(e.dim, e.x, e.z);
            if (y < -9000) return;
            var g = 0;
            while (g++ < 320 && /^minecraft:(water|air|cave_air|kelp|kelp_plant|seagrass|tall_seagrass)$/.test(String(RPG.world.getBlock(e.dim, e.x, y - 1, e.z)))) y--;
            RPG.world.setBlock(e.dim, e.x, y, e.z, RPG.blocks.id(e.dragon + "_idol_block"));
            e.y = y; changed = true;
        });
        if (changed) saveIdols(v);
    });
    if (typeof DBR_RADAR_EXTRA !== "undefined") DBR_RADAR_EXTRA.push(function (out) {     // registered on the dragon radar
        var v = idols();
        Object.keys(v).forEach(function (k) { var e = v[k], set = IDOL_SET[e.dragon]; if (out.sets[set]) out.sets[set].push({ x: e.x, z: e.z, d: e.dim }); });
    });
    function forgetIdolAt(dim, x, y, z) {
        var v = idols(), changed = false;
        Object.keys(v).forEach(function (k) { var e = v[k]; if (e.dim === dim && e.x === x && e.z === z && (e.y === null || Math.abs(e.y - y) <= 1)) { delete v[k]; changed = true; } });
        if (changed) saveIdols(v);
    }
    ["shenron", "porunga"].forEach(function (dragon) {
        var item = dragon + "_idol", name = dragon === "shenron" ? "&5Shenron Idol" : "&5Porunga Idol";
        RPG.blocks.define(item + "_block", {
            name: name, model: "dbr:rpg/block/" + item, itemModel: "dbr:rpg/item/" + item, hardness: 2.5, light: 7, decor: true, renderType: "translucent",
            shape: [4, 0, 4, 12, 11.2, 12], sound: "stone", drops: [{ item: item, count: 1 }], support: ["any"], fragile: false,
            onBreak: function (p, x, y, z) { forgetIdolAt(p.dimension, x, y, z); },
            onUse: function (p) { p.actionbar("&7Pick the idol up and use it from your hand."); }
        });
        RPG.items.define(item, {
            name: name, model: "dbr:rpg/item/" + item, maxStack: 1, rarity: "epic",
            lore: ["Right-click: the eternal dragon's bargain (namekians)", "Shift + right-click a block: place it"],
            onUse: function (p) {
                if (p.isSneaking()) { place(p, dragon); return; }
                openPrompt(p, dragon);
            }
        });
    });
    function place(p, dragon) {
        var hit = p.raycast(5, { blocks: true, entities: false });
        if (!hit || hit.hit !== "block") return;
        var f = { up: [0, 1, 0], down: [0, -1, 0], north: [0, 0, -1], south: [0, 0, 1], west: [-1, 0, 0], east: [1, 0, 0] }[hit.face] || [0, 1, 0];
        var x = hit.blockX + f[0], y = hit.blockY + f[1], z = hit.blockZ + f[2];
        if (!RPG.world.isReplaceable(p.dimension, x, y, z)) return;
        if (!p.takeItem(dragon + "_idol", 1)) return;
        RPG.world.setBlock(p.dimension, x, y, z, RPG.blocks.id(dragon + "_idol_block"));
    }

    // ---- DragonBallRecreation: the prompt (PacketIdolPrompt) and the confirmation (PacketIdolConfirm) ---------
    function prompt(p, dragon) {
        var set = IDOL_SET[dragon], refusal = "NONE";
        if (race(p) !== "namekian") refusal = "NOT_NAMEKIAN";
        else if (level(p) < reqLevel()) refusal = "TOO_LOW_LEVEL";
        else if (p.countItem(dragon + "_idol") <= 0) refusal = "NO_IDOL";
        else if (!dbrBallSet || !dbrBallSet.isSpent(set)) refusal = "NOTHING_TO_RESTORE";
        return { dragon: dragon, set: set, level: level(p), requiredLevel: reqLevel(), levelCost: cost(), ballCount: DB_SETS[set].stars, refusal: refusal };
    }
    function refusalText(pr) {
        return { NOT_NAMEKIAN: "Only a namekian can restore what the dragon balls lost.", TOO_LOW_LEVEL: "You are not strong enough to pay this price. Reach level " + pr.requiredLevel + ".",
            NO_IDOL: "You are not carrying a Shenron Idol.", NOTHING_TO_RESTORE: "No dragon ball set is missing. There is nothing to restore." }[pr.refusal] || "";
    }
    function openPrompt(p, dragon) { RPG.net.send(p, "dbr_idol_prompt", prompt(p, dragon)); }
    RPG.net.on("dbr_idol_confirm", function (p, d) {
        if (!p || !d || !IDOL_SET[d.dragon]) return;
        var pr = prompt(p, d.dragon);
        if (pr.refusal !== "NONE") { p.tell(refusalText(pr)); return; }
        if (!p.takeItem(d.dragon + "_idol", 1)) return;
        var lost = applyLevelCost(p, pr.levelCost);
        var n = dbrBallSet.restore(pr.set, p);
        raiseSuperform(p, "namekian", 4);
        setFlag(p, "namekian_god");
        p.tell("§aThe dragon balls are whole again. " + n + " of them are yours.");
        p.tell("§aYou recreate the shattered dragon balls and awaken Primal Namekian!");
        announce(p.name + " has gathered the scattered dragon balls. The set is whole again!", "The Balls Return", p.name + " restored what was defiled", "§a");
        RPG.log("[ritual] " + p.name + " restored the " + pr.set + " set at a " + d.dragon + " idol, " + lost + " levels taken");
    });

    // ---- SsgRitualManager: the Super Saiyan God charge ritual ------------------------------------------
    function requiredChargers() { return Math.max(0, dbrRitualSolo() ? C.get("ssgRitual.singleplayerRequiredChargers") : Math.max(1, C.get("ssgRitual.requiredChargers"))); }
    var PROGRESS = {}, ACTIVE = {};
    function chargingSaiyan(p) { return isSsgRace(p) && p.hasEffect("ki_charge") && p.getVar("dmz_created", 0); }
    function inGodForm(p) { return String(p.getVar("dmz_form", "") || "").indexOf("godritual:") === 0; }
    RPG.every(CHECK_INTERVAL, function () {
        Object.keys(ACTIVE).forEach(function (u) { var p = online(u); if (!p || !inGodForm(p)) delete ACTIVE[u]; });
        var chargers = RPG.server.players().filter(chargingSaiyan);
        Object.keys(PROGRESS).forEach(function (u) { if (!chargers.some(function (c) { return uid(c) === u; })) delete PROGRESS[u]; });
        var need = requiredChargers();
        if (chargers.length <= need) return;               // a centre plus at least this many others
        chargers.forEach(function (centre) {
            var u = uid(centre);
            if (ACTIVE[u] || inGodForm(centre) || (typeof DMZ_GOD_RITUAL !== "undefined" && DMZ_GOD_RITUAL.isParticipant(centre))) return;
            if (!flag(centre, "ssg_knowledge")) { delete PROGRESS[u]; return; }
            var ring = chargers.filter(function (o) { return o !== centre && o.dimension === centre.dimension && o.distanceTo(centre) <= RING_RADIUS; });
            if (ring.length < need) { delete PROGRESS[u]; return; }
            var held = (PROGRESS[u] || 0) + CHECK_INTERVAL;
            if (held < HOLD_TICKS) { PROGRESS[u] = held; return; }
            delete PROGRESS[u];
            trigger(centre, ring);
        });
    });
    /** RitualForms.beginTempSsg: DragonMineZ's own god ritual form, its timer and (when it ends) its cooldown. */
    function trigger(centre, ring) {
        if (!isSsgRace(centre) || typeof DMZ_TF === "undefined") return;
        centre.setVar("dmz_prev", null);
        centre.setVar("dmz_formcharge", 0);
        DMZ_TF.setForm(centre, "godritual", "supersaiyangodritual");
        centre.setVar("dmz_godritual_ticks", Math.max(20, Math.round(C.get("godRitual.durationMinutes") * 1200)));
        centre.tell("§6The ritual completes! Divine power fills you as a Super Saiyan God.");
        ring.forEach(function (o) { o.tell("§6Your energy fed the ritual and raised a Super Saiyan God."); });
        ACTIVE[uid(centre)] = ring.map(uid);
        RPG.world.sound(centre.dimension, DMZ + "transform_on", centre.x, centre.y, centre.z, 1, 0.9);
        RPG.log("[ritual] SSG charge ritual completed for " + centre.name + " with " + ring.length + " participants");
    }

    // ---- ops ----------------------------------------------------------------------------------------
    RPG.commands.register("rituals", {
        permission: 2, description: "/rpgc rituals info [player] | wishes <earth|namek> <n> | knowledge | ssj5 | primal | spend <set> | idol <shenron|porunga>",
        run: function (p, a) {
            var t = a[1] && a[0] === "info" ? RPG.server.player(a[1]) || p : p;
            if (!t) return;
            var sub = String(a[0] || "info");
            if (sub === "wishes") { t.setVar("dmzr_wishes_" + (a[1] === "namek" ? "namek" : "earth"), Number(a[2]) || 0); }
            else if (sub === "knowledge") setFlag(t, "ssg_knowledge");
            else if (sub === "ssj5") { raiseSuperform(t, "saiyan", 9); setFlag(t, "ssj5"); }
            else if (sub === "primal") { raiseSuperform(t, "namekian", 4); setFlag(t, "namekian_god"); }
            else if (sub === "spend") spendSet(a[1] === "namek" ? "namek" : "earth");
            else if (sub === "idol") t.giveItem((a[1] === "porunga" ? "porunga" : "shenron") + "_idol", 1);
            t.tell("&eRituals: earth wishes " + count(t, "earth") + ", namek wishes " + count(t, "namek") + ", SSG knowledge " + flag(t, "ssg_knowledge") +
                ", SSJ5 " + flag(t, "ssj5") + ", Namekian God " + flag(t, "namekian_god") + ", SSG chargers needed here " + requiredChargers() +
                ", earth spent " + !!(dbrBallSet && dbrBallSet.isSpent("earth")) + ", namek spent " + !!(dbrBallSet && dbrBallSet.isSpent("namek")) +
                ", SSJ5 offered " + canWishForSsj5(t));
        },
        suggest: function () { return ["info", "wishes", "knowledge", "ssj5", "primal", "spend", "idol"]; }
    });

    return { applyLevelCost: applyLevelCost, canWishForSsj5: canWishForSsj5, requiredChargers: requiredChargers, prompt: prompt };
})();
