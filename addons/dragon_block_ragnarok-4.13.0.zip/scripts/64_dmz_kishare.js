// =====================================================================================
//  64_dmz_kishare.js - DragonMine Z's Ki sharing and the Super Saiyan God ritual
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): server/events/players/{KiShareService, GodRitualService},
//  common/util/GodRitualHelper, GeneralServerConfig.{KiTransferConfig, GodRitualConfig}, the god ritual parts of
//  StatsData / Status / Cooldowns and DefaultFormsFactory's godritual group (shared/07_dmz_forms_data.js; its
//  multipliers: 31_dmz_transform.js godRitualMult). Client side (poses, ki streams, the white shell, the chord):
//  client/scripts/46_dmz_kishare.js.
//
//  Ki sharing: hold Ctrl + Alt + right click looking at a player within 8 blocks. You give 2.5 % of your max ki a
//  second (no ki regen while you give), move at 40 % speed and can't attack or use items; after 1 s every giver
//  raises the receiver's STR/SKP/DEF/PWR by 5 % (up to 5 givers), and keeps doing so 5 s per 3 s given after
//  letting go. Each 3 s given also tires you: -5 % to the same stats (up to -25 %) that wears off as long as you gave.
//  Taking 10 % of your max health in hits breaks it.
//
//  The God ritual (DMZ): five Saiyans in Super Saiyan (or SSJ Mastered), each pure of heart (alignment 90+ or 10-),
//  share their ki with a sixth in SSJ Mastered within 5 blocks. Once all five have given 1 s: they glide into a ring
//  2.5 blocks round the vessel and hold hands, the vessel channels 10 s (a gauge fills), rises up to 6 blocks over
//  2 s, glows white for 1 s and becomes a Super Saiyan God for 5 minutes. Everyone then rests 30 minutes (God Ritual
//  CD). A hit worth 25 % of someone's health, a death, a logout, leaving the dimension or dropping out of the form
//  ends it (30 s rest). A form ended early still costs the 30 minutes.
//
//  Singleplayer (DBR, ragnarok_rpg/config/dbr_rituals.json or the DMZ config menu's Server rows):
//    godRitual.requiredDonors              5   DMZ's rule: dedicated servers and worlds open to LAN
//    godRitual.singleplayerRequiredDonors  0   a singleplayer world (only its owner can join): with 0 the vessel performs
//                                             the ritual alone by holding Charge Ki for godRitual.soloChargeSeconds (3 s)
//                                             in SSJ Mastered; every other rule (pure heart, cooldown, channel, rise, glow,
//                                             timer) stays DMZ's. Set it to 5 to keep DMZ's rule in singleplayer too.
//  Op test: /rpgc godritual status | reset (clears your God Ritual CD) | end
// =====================================================================================
var DBR_RITUALS_CFG = RPG.config.define("dbr_rituals", {
    kiShare: {
        enabled: { default: true, comment: "DragonMine Z's Ki sharing (Ctrl + Alt + right click a player)" },
        kiPercentPerSecond: { default: 0.025, min: 0, max: 1, comment: "Share of the giver's max ki given each second" },
        boostDelaySeconds: { default: 1.0, min: 0, max: 60, comment: "Seconds of giving before a giver boosts the receiver (and counts for the god ritual)" },
        boostPerDonor: { default: 0.05, min: 0, max: 10, comment: "STR/SKP/DEF/PWR bonus per giver" },
        maxBoostDonors: { default: 5, min: 0, max: 100, integer: true, comment: "Most givers that add a bonus" },
        donorSpeedMultiplier: { default: 0.4, min: 0, max: 1, comment: "Giver movement speed" },
        interruptDamageRatio: { default: 0.10, min: 0.01, max: 10, comment: "Damage (share of max health) that breaks a giver's link" },
        startRange: { default: 8.0, min: 1, max: 64, comment: "Blocks to the receiver to start" },
        maxLinkDistance: { default: 32.0, min: 1, max: 256, comment: "Blocks before the link breaks" },
        intervalSeconds: { default: 3.0, min: 0.05, max: 600, comment: "Each interval given: the receiver keeps the bonus retainSecondsPerInterval longer, the giver tires one step" },
        retainSecondsPerInterval: { default: 5.0, min: 0, max: 600, comment: "Seconds of bonus kept per interval given" },
        donorPenaltyPerInterval: { default: 0.05, min: 0, max: 1, comment: "Giver penalty per interval" },
        donorPenaltyMax: { default: 0.25, min: 0, max: 0.95, comment: "Largest giver penalty" },
        restartCooldownSeconds: { default: 2.0, min: 0, max: 600, comment: "Seconds before a giver can start again" }
    },
    godRitual: {
        enabled: { default: true, client: true, comment: "DragonMine Z's Super Saiyan God ritual may start (DMZ Ragnarok's DmzGodRitualEnabled); a running form ends normally either way" },
        requiredDonors: { default: 5, min: 1, max: 100, integer: true, client: true, comment: "Pure-hearted Saiyan givers the vessel needs (DMZ: 5) on a dedicated server or a world open to LAN" },
        singleplayerRequiredDonors: { default: 0, min: 0, max: 100, integer: true, client: true, comment: "Givers needed in a singleplayer world nobody else can join. 0: the vessel performs it alone by holding Charge Ki (soloChargeSeconds) in the recipient form" },
        soloChargeSeconds: { default: 3.0, min: 0.5, max: 600, client: true, comment: "Seconds of Charge Ki that start a solo ritual" },
        donorForms: { default: ["ssgrades.supersaiyan", "supersaiyan.supersaiyanmastered"], comment: "group.form the givers must be in" },
        recipientForms: { default: ["supersaiyan.supersaiyanmastered"], comment: "group.form the vessel must be in" },
        pureGoodMinAlignment: { default: 90, min: 0, max: 100, integer: true, comment: "A pure heart: alignment at least this..." },
        pureEvilMaxAlignment: { default: 10, min: 0, max: 100, integer: true, comment: "...or at most this" },
        ritualRadius: { default: 5.0, min: 1, max: 64, comment: "Givers must be within this many blocks of the vessel (horizontally)" },
        ritualVerticalRange: { default: 3.0, min: 0, max: 64, comment: "...and this many blocks above or below" },
        ringRadius: { default: 2.5, min: 1, max: 64, comment: "Radius of the ring the givers glide into" },
        channelSeconds: { default: 10.0, min: 1, max: 600, comment: "Channel time" },
        liftHeight: { default: 6.0, min: 0, max: 64, comment: "Blocks the vessel rises (less under a ceiling)" },
        liftSeconds: { default: 2.0, min: 0.05, max: 60, comment: "Rise time" },
        glowInSeconds: { default: 1.0, min: 0.05, max: 60, comment: "White shell fade in (then the form)" },
        glowOutSeconds: { default: 1.5, min: 0.05, max: 60, comment: "White shell fade out" },
        shellColor: { default: "#6FD8FF", client: true, comment: "Shell colour" },
        interruptDamageRatio: { default: 0.25, min: 0.01, max: 10, comment: "Damage (share of max health) taken by one body that breaks the ritual" },
        interruptCooldownSeconds: { default: 30.0, min: 0, max: 86400, comment: "Rest after a broken ritual" },
        cooldownMinutes: { default: 30.0, min: 0, max: 100000, comment: "Rest after a ritual (and after the form ends)" },
        durationMinutes: { default: 5.0, min: 0.05, max: 100000, comment: "How long the Super Saiyan God form lasts" },
        powerBonus: { default: 0.30, min: 0, max: 100, comment: "The form multiplies the best form's gain by 1 + this" },
        mutantPowerBonus: { default: 0.45, min: 0, max: 100, comment: "...for a mutant" }
    },
    ssgRitual: {
        requiredChargers: { default: 5, min: 1, max: 100, integer: true, client: true, comment: "DMZ Ragnarok's Super Saiyan God charge ritual: Saiyans charging ki round the centre (dedicated / LAN)" },
        singleplayerRequiredChargers: { default: 0, min: 0, max: 100, integer: true, client: true, comment: "The same in a singleplayer world nobody else can join (0: the centre alone, charging for 3 s)" },
        wishMinLevel: { default: 5000, min: 0, max: 1000000, integer: true, comment: "Level a Saiyan needs for Shenron's Knowledge of Super Saiyan God wish (SsgWishMinLevel)" }
    },
    wishRituals: {
        requiredLevel: { default: 10000, min: 0, max: 1000000000, integer: true, comment: "Level for the Super Saiyan 5 wish and the Namekian god ritual (DMZ Ragnarok: 10000)" },
        levelCost: { default: 5000, min: 0, max: 1000000000, integer: true, comment: "Levels either ritual takes, removed from random stats (DMZ Ragnarok: 5000)" },
        wishThreshold: { default: 10, min: 0, max: 1000, integer: true, comment: "Wishes on a set before its ritual opens (the eleventh wish on)" }
    }
});
/** The singleplayer rule applies in a world nobody else can join (RPG.server.isSingleplayer: not dedicated, not open to LAN). */
function dbrRitualSolo() {
    try { return typeof RPG.server.isSingleplayer === "function" ? !!RPG.server.isSingleplayer() : RPG.server.players().length <= 1; } catch (e) { return false; }
}

// the DMZ config menu's Server rows (client/scripts/54_dmz_config_menu.js): ops change these live
(function () {
    var KEYS = { "godRitual.enabled": 1, "godRitual.requiredDonors": 1, "godRitual.singleplayerRequiredDonors": 1, "ssgRitual.requiredChargers": 1, "ssgRitual.singleplayerRequiredChargers": 1 };
    RPG.net.on("dbr_rituals_set", function (p, d) {
        var op = false;
        try { op = p.isOp(); } catch (e) { }
        if (op && d && KEYS[d.key]) DBR_RITUALS_CFG.set(String(d.key), d.value);
    });
})();
RPG.effects.define("god_ritual_cd", { name: "God Ritual CD", color: "#9A9A9A", keepOnDeath: true });
RPG.effects.define("ki_transfer_boost", { name: "Shared Ki", color: "#6FD8FF", beneficial: true, maxStacks: 100 });
RPG.effects.define("ki_transfer_drain", { name: "Ki Exhaustion", color: "#5A6E80", maxStacks: 100 });
// a giver: no attacks, items or techniques, 40 % speed (isKiShareLocked); hidden like DMZ's own status flag
RPG.effects.define("dmz_ki_sharing", { name: "Sharing Ki", hidden: true, flags: ["noAttack", "noUse", "noSkills"],
    attributes: { "minecraft:generic.movement_speed": { amount: -0.6, operation: "multiply_total" } } });
// a ritual body (Status.isStunned while isInGodRitual): pinned by the ritual, every action refused
RPG.effects.define("dmz_god_ritual", { name: "God Ritual", hidden: true, flags: ["noMove", "noJump", "noAttack", "noUse", "noKeys", "noSkills"] });

var DMZ_KISHARE = (function () {
    var C = DBR_RITUALS_CFG;
    function K(k) { return C.get("kiShare." + k); }
    var LINKS = {}, BOOSTED = {}, RETAINED = {}, RESTART_AT = {};
    var BOOST_KEYS = ["STR", "SKP", "DEF", "PWR"];
    function now() { return RPG.server.getTick(); }
    function uid(p) { return String(p.uuid); }
    function online(u) { var l = RPG.server.players(); for (var i = 0; i < l.length; i++) if (uid(l[i]) === u) return l[i]; return null; }
    function created(p) { return !!p.getVar("dmz_created", 0); }
    function gm(p) { return String(p.getGameMode()); }
    function ritualOf(p) { return typeof DMZ_GOD_RITUAL !== "undefined" && DMZ_GOD_RITUAL.isParticipant(p); }
    function canAct(p) {
        if (!p.isAlive() || gm(p) === "spectator" || !created(p)) return false;
        return !p.hasEffect("stunned") && !p.hasEffect("knocked_down") && !ritualOf(p);
    }
    function validReceiver(p) { return p.isAlive() && gm(p) !== "spectator" && created(p); }
    function receiving(u) { for (var d in LINKS) if (LINKS[d].recv === u) return true; return false; }
    function tell(p, s) { p.actionbar(s); }

    // ---- the giver's and receiver's stat factor (GodRitualHelper.kiShareMultiplier), folded into dmz_mult ------
    function stacks(p) { return Number(p.getVar("dmz_kidrain_stacks", 0)) || 0; }
    function penalty(n) { return n <= 0 ? 0 : Math.min(K("donorPenaltyMax"), n * K("donorPenaltyPerInterval")); }
    function factor(p) {
        var donors = BOOSTED[uid(p)] || 0, n = stacks(p);
        if (donors <= 0 && n <= 0) return 1;
        return (1 + Math.min(donors, K("maxBoostDonors")) * K("boostPerDonor")) * (1 - penalty(n));
    }
    function applyFactor(p) {
        var want = factor(p), had = Number(p.getVar("dmz_kishare_mult", 1)) || 1;
        if (Math.abs(want - had) < 1e-6) return;
        var m = p.getVar("dmz_mult", null) || {};
        BOOST_KEYS.forEach(function (k) { m[k] = (typeof m[k] === "number" ? m[k] : 1) / had * want; });
        p.setVar("dmz_mult", m);
        p.setVar("dmz_kishare_mult", want);
        p.refreshStats();
    }

    // ---- start / stop (requestStart, refusal, stop) -------------------------------------------
    function start(donor, target) {
        if (!K("enabled") || LINKS[uid(donor)]) return;
        if (RESTART_AT[uid(donor)] && now() < RESTART_AT[uid(donor)]) return;
        var recv = target;
        if (!recv || !recv.isPlayer() || uid(recv) === uid(donor)) return;
        recv = recv.asPlayer ? recv.asPlayer() || recv : recv;
        var refusal = null, rn = recv.name;
        if (!canAct(donor)) refusal = "§cYou cannot share your Ki right now";
        else if (!validReceiver(recv) || ritualOf(recv)) refusal = "§c" + rn + " cannot receive Ki right now";
        else if (LINKS[uid(recv)]) refusal = "§c" + rn + " is already sharing their own Ki";
        else if (receiving(uid(donor))) refusal = "§cYou cannot share Ki while you are receiving it";
        else if (donor.resource("ki") <= 0) refusal = "§cYou have no Ki left to share";
        else if (donor.dimension !== recv.dimension || donor.distanceTo(recv) > K("startRange") + 2 || !donor.canSee(recv)) refusal = "§c" + rn + " is too far away";
        if (refusal) { tell(donor, refusal); return; }
        LINKS[uid(donor)] = { recv: uid(recv), start: now(), pending: 0, dmg: 0, ticks: 0 };
        donor.removeEffect("ki_charge");
        donor.addEffect("dmz_ki_sharing", -1);
        donor.setShared("kiShare", recv.entityId);
        sfx(donor, "aura_start", 0.6, 1.2);
        tell(donor, "§bYou are sharing your Ki with " + rn);
        tell(recv, "§b" + donor.name + " is sharing their Ki with you");
    }
    function stop(u, message) {
        var link = LINKS[u];
        if (!link) return;
        delete LINKS[u];
        if (K("restartCooldownSeconds") > 0) RESTART_AT[u] = now() + Math.round(K("restartCooldownSeconds") * 20);
        var p = online(u);
        if (!p) return;
        p.removeEffect("dmz_ki_sharing");
        p.setShared("kiShare", 0);
        if (message) tell(p, message);
    }
    function releaseForRitual(recvUuid) {
        Object.keys(LINKS).forEach(function (d) { if (LINKS[d].recv === recvUuid) stop(d, null); });
        stop(recvUuid, null);
    }
    function settled(recvUuid) {
        var delay = Math.round(K("boostDelaySeconds") * 20), out = [];
        for (var d in LINKS) {
            var l = LINKS[d];
            if (l.recv !== recvUuid || now() - l.start < delay) continue;
            var p = online(d);
            if (p) out.push(p);
        }
        return out;
    }

    // ---- every tick (onServerTick) ---------------------------------------------------------
    function linkBreak(donor, recv, l) {
        if (!donor) return "";
        if (ritualOf(donor)) return "";
        if (!canAct(donor)) return "§cThe blow broke your concentration";
        if (!recv || !validReceiver(recv)) return "§cYou lost the link with your target";
        if (ritualOf(recv)) return "";
        if (donor.dimension !== recv.dimension || donor.distanceTo(recv) > K("maxLinkDistance")) return "§cYou lost the link with your target";
        return null;
    }
    function transfer(donor, recv, l) {
        l.pending += donor.maxResource("ki") * K("kiPercentPerSecond") / 20;
        var whole = Math.floor(l.pending * 4) / 4;
        if (whole <= 0) return true;
        l.pending -= whole;
        var creative = gm(donor) === "creative", have = donor.resource("ki"), given = creative ? whole : Math.min(whole, have);
        if (given <= 0) return false;
        if (!creative) donor.setResource("ki", have - given);
        var room = Math.max(0, recv.maxResource("ki") - recv.resource("ki"));
        if (room > 0) recv.addResource("ki", Math.min(room, given));
        return creative || donor.resource("ki") > 0;
    }
    function interval(donor, l) {
        var retain = Math.round(K("retainSecondsPerInterval") * 20);
        if (retain > 0) { var r = RETAINED[l.recv] || (RETAINED[l.recv] = {}); r[uid(donor)] = (r[uid(donor)] || 0) + retain; }
        if (gm(donor) === "creative") return;
        var max = K("donorPenaltyPerInterval") <= 0 ? 0 : Math.ceil(K("donorPenaltyMax") / K("donorPenaltyPerInterval") - 1e-6);
        donor.setVar("dmz_kidrain_stacks", Math.min(max, stacks(donor) + 1));
        donor.setVar("dmz_kidrain_ticks", (Number(donor.getVar("dmz_kidrain_ticks", 0)) || 0) + retain);
        DRAINED[uid(donor)] = 1;
    }
    var DRAINED = {};
    function tickDrains() {
        Object.keys(DRAINED).forEach(function (u) {
            var p = online(u);
            if (!p) { delete DRAINED[u]; return; }
            var giving = !!LINKS[u], t = Number(p.getVar("dmz_kidrain_ticks", 0)) || 0;
            if (!giving && t > 0) p.setVar("dmz_kidrain_ticks", --t);
            if (t <= 0 || !K("enabled")) {
                p.setVar("dmz_kidrain_stacks", 0); p.setVar("dmz_kidrain_ticks", 0);
                p.removeEffect("ki_transfer_drain"); applyFactor(p); delete DRAINED[u]; return;
            }
            if (now() % 20 === 0) { indicator(p, "ki_transfer_drain", giving ? -1 : t, stacks(p)); applyFactor(p); }
        });
    }
    function indicator(p, id, ticks, n) {
        if (n <= 0) { p.removeEffect(id); return; }
        if (p.effectStacks(id) !== n || ticks >= 0) { p.removeEffect(id); p.addEffectStacks(id, ticks < 0 ? -1 : ticks, n); }
    }
    RPG.on("serverTick", function () {
        var linked = Object.keys(LINKS);
        if (!linked.length && !Object.keys(BOOSTED).length && !Object.keys(RETAINED).length && !Object.keys(DRAINED).length) return;
        if (!K("enabled")) linked.forEach(function (d) { stop(d, null); });
        var boosting = {}, receivers = {}, delay = Math.round(K("boostDelaySeconds") * 20);
        Object.keys(LINKS).forEach(function (d) {
            var l = LINKS[d], donor = online(d), recv = online(l.recv);
            var why = linkBreak(donor, recv, l);
            if (why !== null) { stop(d, why || null); return; }
            if (!transfer(donor, recv, l)) { stop(d, "§cYou have no Ki left to share"); return; }
            receivers[l.recv] = 1;
            if (++l.ticks % Math.max(1, Math.round(K("intervalSeconds") * 20)) === 0) interval(donor, l);
            if (now() - l.start >= delay) (boosting[l.recv] = boosting[l.recv] || {})[d] = 1;
        });
        // tickRetained: givers who let go still boost while their retained time lasts
        Object.keys(RETAINED).forEach(function (r) {
            var map = RETAINED[r];
            Object.keys(map).forEach(function (d) {
                var still = LINKS[d] && LINKS[d].recv === r, left = still ? map[d] : map[d] - 1;
                if (left <= 0) { delete map[d]; return; }
                map[d] = left;
                (boosting[r] = boosting[r] || {})[d] = 1;
            });
            if (!Object.keys(map).length) delete RETAINED[r];
        });
        var touched = {};
        Object.keys(BOOSTED).forEach(function (r) { touched[r] = 1; });
        Object.keys(boosting).forEach(function (r) { touched[r] = 1; });
        Object.keys(touched).forEach(function (r) {
            var n = boosting[r] ? Object.keys(boosting[r]).length : 0;
            if (n > 0) BOOSTED[r] = n; else delete BOOSTED[r];
            var p = online(r);
            if (!p) return;
            if (now() % 20 === 0 || n !== p.effectStacks("ki_transfer_boost")) {
                var longest = 0, ret = RETAINED[r] || {};
                Object.keys(ret).forEach(function (d) { longest = Math.max(longest, ret[d]); });
                indicator(p, "ki_transfer_boost", receiving(r) ? -1 : longest, n);
            }
            applyFactor(p);
        });
        tickDrains();
        Object.keys(receivers).forEach(function (r) { var p = online(r); if (p && typeof DMZ_GOD_RITUAL !== "undefined") DMZ_GOD_RITUAL.evaluate(p); });
    });
    // onDamage: a giver who takes 10 % of their max health in hits stops
    RPG.on("damageFinal", function (e) {
        var t = e.target;
        if (!t || !t.isPlayer() || e.amount <= 0) return;
        var l = LINKS[String(t.uuid)];
        if (!l) return;
        l.dmg += Math.min(e.amount, t.health);
        if (l.dmg >= t.maxHealth * K("interruptDamageRatio")) stop(String(t.uuid), "§cThe blow broke your concentration");
    });
    RPG.on("death", function (p) { stop(uid(p), null); });
    RPG.on("playerLeave", function (p) {
        var u = uid(p);
        stop(u, null);
        delete BOOSTED[u]; delete RETAINED[u]; delete DRAINED[u]; delete RESTART_AT[u];
        p.setShared("kiShare", 0);
    });
    RPG.on("playerJoin", function (p) {
        p.removeEffect("dmz_ki_sharing"); p.removeEffect("ki_transfer_boost"); p.setShared("kiShare", 0);
        if ((Number(p.getVar("dmz_kidrain_ticks", 0)) || 0) > 0) DRAINED[uid(p)] = 1;
        RPG.schedule(20, function () { applyFactor(p); });
    });
    // the chord (client/scripts/46_dmz_kishare.js): {op: "start", target: entityId} / {op: "stop"}
    RPG.net.on("dmz_kishare", function (p, d) {
        if (!p || !d) return;
        if (d.op === "stop") { stop(uid(p), null); return; }
        if (d.op !== "start") return;
        var t = null;
        p.nearby(Math.max(4, K("startRange") + 4), { players: true }).forEach(function (e) { if (e.entityId === Number(d.target)) t = e; });
        if (t) start(p, t);
    });

    return { settled: settled, releaseForRitual: releaseForRitual, isDonating: function (p) { return !!LINKS[uid(p)]; }, receiving: receiving, stop: stop };
})();

// =====================================================================================
//  GodRitualService
// =====================================================================================
var DMZ_GOD_RITUAL = (function () {
    var C = DBR_RITUALS_CFG;
    function G(k) { return C.get("godRitual." + k); }
    var GATHER_TICKS = 20, CHARGE_STEP = 20, FEEDBACK_INTERVAL = 60, SLOW_FALL_TICKS = 160;
    var GROUP = "godritual", FORM = "supersaiyangodritual";
    var RITUALS = {}, PARTICIPANTS = {}, LAST_FEEDBACK = {}, SOLO = {};
    function now() { return RPG.server.getTick(); }
    function uid(p) { return String(p.uuid); }
    function online(u) { var l = RPG.server.players(); for (var i = 0; i < l.length; i++) if (uid(l[i]) === u) return l[i]; return null; }
    function race(p) { return typeof DMZ_TF !== "undefined" ? DMZ_TF.race(p) : p.race; }
    function isSaiyan(p) { return race(p) === "saiyan"; }
    function activeKey(p) { return String(p.getVar("dmz_form", "") || "").replace(":", "."); }
    function inAnyForm(p, list) {
        if (!list || p.getVar("dmz_stack", "")) return false;
        var k = activeKey(p).toLowerCase();
        return !!k && list.some(function (e) { return String(e).trim().toLowerCase() === k; });
    }
    function alignment(p) { var a = Number(p.getVar("dmz_alignment", 100)); return isNaN(a) ? 100 : a; }
    function pure(p) { var a = alignment(p); return a >= G("pureGoodMinAlignment") || a <= G("pureEvilMaxAlignment"); }
    function cooling(p) { return p.hasEffect("god_ritual_cd"); }
    function isActiveForm(p) { return String(p.getVar("dmz_form", "") || "").indexOf(GROUP + ":") === 0; }
    function required() { return dbrRitualSolo() ? G("singleplayerRequiredDonors") : G("requiredDonors"); }
    function blocked(reason, p) {
        var n = p.name;
        return { impure: "§cThe ritual cannot begin: " + n + "'s heart is not pure enough", cooldown: "§cThe ritual cannot begin: " + n + " must rest before another ritual",
            too_far: "§cThe ritual cannot begin: " + n + " is too far from the circle", unable: "§cThe ritual cannot begin: " + n + " cannot channel right now" }[reason];
    }
    function fused(p) { return p.hasEffect("dmz_fused") || !!p.getVar("dmz_fused", 0); }
    function recipientProblem(p) {
        if (fused(p)) return "§cThe ritual cannot begin: a fusion cannot become the vessel";
        if (!pure(p)) return blocked("impure", p);
        if (cooling(p)) return blocked("cooldown", p);
        if (p.hasEffect("knocked_down") || !p.isAlive()) return blocked("unable", p);
        return null;
    }
    function withinCircle(d, r) {
        if (d.dimension !== r.dimension) return false;
        var dx = d.x - r.x, dz = d.z - r.z, rad = G("ritualRadius");
        return dx * dx + dz * dz <= rad * rad && Math.abs(d.y - r.y) <= G("ritualVerticalRange");
    }
    function candidate(d, r) {
        if (!isSaiyan(d) || !inAnyForm(d, G("donorForms"))) return null;
        var problem = null;
        if (!pure(d)) problem = blocked("impure", d);
        else if (cooling(d)) problem = blocked("cooldown", d);
        else if (!withinCircle(d, r)) problem = blocked("too_far", d);
        return { p: d, n: 1, problem: problem };          // (a fused giver counts as two in DMZ; DBR's fusion keeps one body)
    }
    function feedback(r, cands, problem) {
        var last = LAST_FEEDBACK[uid(r)];
        if (last !== undefined && now() - last < FEEDBACK_INTERVAL) return;
        LAST_FEEDBACK[uid(r)] = now();
        r.actionbar(problem);
        cands.forEach(function (c) { c.p.actionbar(problem); });
    }
    /** GodRitualService.evaluate: called for every receiver while ki flows to them. */
    function evaluate(r) {
        if (!G("enabled") || PARTICIPANTS[uid(r)] || !isSaiyan(r) || !inAnyForm(r, G("recipientForms"))) return;
        var need = required();
        if (need <= 0) return;                                // the solo ritual starts from Charge Ki instead
        var cands = [], attempted = 0;
        DMZ_KISHARE.settled(uid(r)).forEach(function (d) { var c = candidate(d, r); if (c) { cands.push(c); attempted += c.n; } });
        if (attempted < need) return;
        var problem = recipientProblem(r), chosen = [], ready = 0;
        cands.forEach(function (c) {
            if (c.problem) { if (!problem) problem = c.problem; return; }
            if (ready >= need) return;
            chosen.push(c); ready += c.n;
        });
        if (ready >= need && !recipientProblem(r)) { begin(r, chosen); return; }
        if (problem) feedback(r, cands, problem);
    }

    // ---- ground / space checks (canStand, clearance) -----------------------------------------
    function solid(dim, x, y, z) { var b = RPG.world.getBlock(dim, Math.floor(x), Math.floor(y), Math.floor(z)); return !(b === "minecraft:air" || b === "minecraft:cave_air" || (typeof siteLoose === "function" && siteLoose(b) && b.indexOf("leaves") < 0)); }
    function canStand(p, x, y, z, needsGround) {
        if (solid(p.dimension, x, y + 0.1, z) || solid(p.dimension, x, y + 1.1, z)) return false;
        return !needsGround || solid(p.dimension, x, y - 0.2, z);
    }
    function clearance(p, height) {
        var free = 0;
        for (var h = 0.25; h <= height + 1e-6; h += 0.25) {
            if (solid(p.dimension, p.x, p.y + h + 1.8, p.z)) break;
            free = h;
        }
        return free;
    }

    // ---- begin / enter -------------------------------------------------------------------------
    function enter(p, role, anchor) {
        p.removeEffect("ki_charge");
        p.addEffect("dmz_god_ritual", -1);
        p.setShared("godRitual", { role: role, anchor: anchor });
        p.setSprinting && p.setSprinting(false);
    }
    function begin(r, chosen) {
        var cx = r.x, cy = r.y, cz = r.z;
        chosen.sort(function (a, b) { return Math.atan2(a.p.z - cz, a.p.x - cx) - Math.atan2(b.p.z - cz, b.p.x - cx); });
        DMZ_KISHARE.releaseForRitual(uid(r));
        var rit = { recv: uid(r), dim: r.dimension, cx: cx, cy: cy, cz: cz, donors: chosen.map(function (c) { return uid(c.p); }), slots: {}, dmg: {},
            phase: chosen.length ? "GATHER" : "CHANNEL", ticks: 0, charge: 0, liftFrom: 0, liftTo: 0 };
        if (chosen.length) {
            var base = Math.atan2(chosen[0].p.z - cz, chosen[0].p.x - cx), rad = Math.min(G("ritualRadius"), G("ringRadius")), onGround = r.onGround;
            chosen.forEach(function (c, i) {
                var d = c.p, a = base + i * Math.PI * 2 / chosen.length, x = cx + Math.cos(a) * rad, z = cz + Math.sin(a) * rad, y = cy;
                if (!canStand(d, x, y, z, onGround)) { x = d.x; y = d.y; z = d.z; }
                var yaw = Math.atan2(-(cx - x), cz - z) * 180 / Math.PI;
                rit.slots[uid(d)] = { fx: d.x, fy: d.y, fz: d.z, tx: x, ty: y, tz: z, yaw: yaw };
            });
        }
        RITUALS[rit.recv] = rit;
        bodies(rit).forEach(function (u) { PARTICIPANTS[u] = rit.recv; });
        delete LAST_FEEDBACK[rit.recv];
        enter(r, 2, r.entityId);
        r.setVar("dmz_formcharge", 0);
        chosen.forEach(function (c) { enter(c.p, 1, r.entityId); });
        RPG.world.sound(rit.dim, DMZ + "aura_start", cx, cy, cz, 1.5, 0.8);
        broadcast(rit, "§6Six pure hearts resonate as one...");
        RPG.log("[DMZ] God ritual started for " + r.name + " with " + chosen.length + " donors at " + Math.floor(cx) + " " + Math.floor(cy) + " " + Math.floor(cz));
    }
    function bodies(rit) { return rit.donors.concat([rit.recv]); }
    function broadcast(rit, text) { bodies(rit).forEach(function (u) { var p = online(u); if (p) p.actionbar(text); }); }

    // ---- the ritual, every tick ----------------------------------------------------------------
    function face(p, x, y, z, yaw) { p.teleportTo(p.dimension, x, y, z, yaw, 0); p.setVelocity(0, 0, 0); p.fallDistance = 0; }
    function glide(p, s, f) { if (p && s) face(p, s.fx + (s.tx - s.fx) * f, s.fy + (s.ty - s.fy) * f, s.fz + (s.tz - s.fz) * f, s.yaw); }
    function pin(p, s) {
        if (!p || !s) return;
        var dx = p.x - s.tx, dz = p.z - s.tz, dyaw = ((p.yaw - s.yaw) % 360 + 540) % 360 - 180;
        if (dx * dx + dz * dz <= 0.25 && Math.abs(dyaw) < 1) return;
        face(p, s.tx, p.y, s.tz, s.yaw);
    }
    function pinCenter(r, rit) {
        var dx = r.x - rit.cx, dz = r.z - rit.cz;
        if (dx * dx + dz * dz <= 0.25) return;
        r.teleportTo(r.dimension, rit.cx, r.y, rit.cz, r.yaw, r.pitch); r.setVelocity(0, 0, 0);
    }
    function tickRitual(rit) {
        var r = online(rit.recv);
        if (!r || !r.isAlive() || r.dimension !== rit.dim || !inAnyForm(r, G("recipientForms"))) { cancel(rit, "§cThe ritual was interrupted"); return; }
        for (var i = 0; i < rit.donors.length; i++) {
            var d = online(rit.donors[i]);
            if (!d || !d.isAlive() || d.dimension !== r.dimension || !inAnyForm(d, G("donorForms"))) { cancel(rit, "§cThe ritual was interrupted"); return; }
        }
        rit.ticks++;
        var each = function (fn) { rit.donors.forEach(function (u) { fn(online(u), rit.slots[u]); }); };
        if (rit.phase === "GATHER") {
            var t = Math.min(1, rit.ticks / GATHER_TICKS), e = t * t * (3 - 2 * t);
            each(function (p, s) { glide(p, s, e); });
            if (rit.ticks >= GATHER_TICKS) { rit.phase = "CHANNEL"; rit.ticks = 0; }
        } else if (rit.phase === "CHANNEL") {
            each(pin);
            pinCenter(r, rit);
            var ch = Math.max(20, Math.round(G("channelSeconds") * 20));
            if (rit.ticks % CHARGE_STEP === 0 || rit.ticks >= ch) {
                rit.charge = Math.min(100, Math.round(100 * rit.ticks / ch));
                r.setVar("dmz_formcharge", rit.charge);
                r.setShared("godRitual", { role: 2, anchor: r.entityId, charge: rit.charge });
            }
            if (rit.ticks >= ch) {
                rit.phase = "ASCEND"; rit.ticks = 0;
                rit.liftFrom = r.y; rit.liftTo = r.y + clearance(r, G("liftHeight"));
                RPG.world.sound(r.dimension, DMZ + "ki_explosion_charge", r.x, r.y, r.z, 1.0, 1.2);
            }
        } else if (rit.phase === "ASCEND") {
            each(pin);
            var lt = Math.max(1, Math.round(G("liftSeconds") * 20)), f = Math.min(1, rit.ticks / lt), eased = 1 - (1 - f) * (1 - f) * (1 - f);
            r.teleportTo(r.dimension, rit.cx, rit.liftFrom + (rit.liftTo - rit.liftFrom) * eased, rit.cz, r.yaw, r.pitch);
            r.setVelocity(0, 0, 0); r.fallDistance = 0;
            if (rit.ticks >= lt) { rit.phase = "SHELL"; rit.ticks = 0; shell(r); }
        } else if (rit.phase === "SHELL") {
            each(pin);
            r.teleportTo(r.dimension, rit.cx, rit.liftTo, rit.cz, r.yaw, r.pitch);
            r.setVelocity(0, 0, 0); r.fallDistance = 0;
            if (rit.ticks >= Math.max(1, Math.round(G("glowInSeconds") * 20))) complete(rit, r);
        }
    }
    /** Status.godRitualGlowStart: every client near the vessel draws the white shell (46_dmz_kishare.js). */
    function shell(r) {
        var spec = { id: r.entityId, inTicks: Math.max(1, Math.round(G("glowInSeconds") * 20)), outTicks: Math.max(1, Math.round(G("glowOutSeconds") * 20)), color: G("shellColor") };
        RPG.server.players().forEach(function (p) { if (p.dimension === r.dimension && p.distanceTo(r) < 128) RPG.net.send(p, "dmz_god_shell", spec); });
    }
    function clearShell(r) { RPG.server.players().forEach(function (p) { if (p.dimension === r.dimension) RPG.net.send(p, "dmz_god_shell", { id: r.entityId, off: 1 }); }); }
    function finish(rit) {
        delete RITUALS[rit.recv];
        bodies(rit).forEach(function (u) {
            delete PARTICIPANTS[u];
            var p = online(u);
            if (!p) return;
            p.removeEffect("dmz_god_ritual");
            p.setShared("godRitual", null);
            if (u === rit.recv) p.setVar("dmz_formcharge", 0);
        });
    }
    function cooldown(p, ticks) {
        if (!p || ticks <= 0) return;
        if (p.hasEffect("god_ritual_cd") && p.effectTicks && p.effectTicks("god_ritual_cd") >= ticks) return;
        p.removeEffect("god_ritual_cd");
        p.addEffect("god_ritual_cd", ticks);
    }
    function cdTicks() { return Math.round(G("cooldownMinutes") * 1200); }
    function complete(rit, r) {
        finish(rit);
        p_setForm(r);
        r.setVar("dmz_godritual_ticks", Math.max(20, Math.round(G("durationMinutes") * 1200)));
        r.setVar("dmz_formcharge", 0);
        r.fallDistance = 0;
        if (!r.hasEffect("flight")) r.addPotion("minecraft:slow_falling", SLOW_FALL_TICKS, 0);
        rit.donors.forEach(function (u) { cooldown(online(u), cdTicks()); });
        RPG.world.sound(r.dimension, DMZ + "fusion", r.x, r.y, r.z, 1.0, 1.0);
        RPG.world.sound(r.dimension, DMZ + "transform_on", r.x, r.y, r.z, 1.0, 0.9);
        r.tell("§cThe power of the gods flows through you... Super Saiyan God!");
        rit.donors.forEach(function (u) { var p = online(u); if (p) p.actionbar("§6" + r.name + " has ascended to Super Saiyan God"); });
        RPG.log("[DMZ] God ritual completed for " + r.name);
    }
    function p_setForm(r) {
        r.setVar("dmz_prev", null);
        r.setVar("dmz_formcharge", 0);
        DMZ_TF.setForm(r, GROUP, FORM);
    }
    function cancel(rit, message) {
        var lifted = rit.phase === "ASCEND" || rit.phase === "SHELL", r = online(rit.recv);
        if (r) clearShell(r);
        finish(rit);
        bodies(rit).forEach(function (u) {
            var p = online(u);
            if (!p) return;
            cooldown(p, Math.round(G("interruptCooldownSeconds") * 20));
            p.actionbar(message);
        });
        if (lifted && r) r.addPotion("minecraft:slow_falling", SLOW_FALL_TICKS, 0);
        RPG.log("[DMZ] God ritual for " + rit.recv + " cancelled in " + rit.phase);
    }
    function cancelFor(p) { var k = PARTICIPANTS[uid(p)]; if (k && RITUALS[k]) cancel(RITUALS[k], "§cThe ritual was interrupted"); }

    RPG.on("serverTick", function () {
        for (var k in RITUALS) try { tickRitual(RITUALS[k]); } catch (e) { RPG.log("[DMZ] god ritual: " + e); cancel(RITUALS[k], "§cThe ritual was interrupted"); }
    });

    // ---- the solo ritual (DBR, singleplayer): the vessel holds Charge Ki in SSJ Mastered -------------------
    RPG.every(5, function () {
        if (!G("enabled") || required() > 0) return;
        RPG.server.players().forEach(function (p) {
            var u = uid(p);
            if (PARTICIPANTS[u] || !p.hasEffect("ki_charge") || !isSaiyan(p) || !inAnyForm(p, G("recipientForms"))) { delete SOLO[u]; return; }
            var problem = recipientProblem(p);
            if (problem) { delete SOLO[u]; feedback(p, [], problem); return; }
            SOLO[u] = (SOLO[u] || 0) + 5;
            if (SOLO[u] >= Math.round(G("soloChargeSeconds") * 20)) { delete SOLO[u]; begin(p, []); }
        });
    });

    // ---- the form's timer (onPlayerTick) ----------------------------------------------------------
    function endForm(p, message) {
        if (isActiveForm(p)) {
            p.setVar("dmz_prev", null);
            DMZ_TF.setForm(p, null, null);
            sfx(p, "insta_form_off", 1, 1);
        }
        p.setVar("dmz_godritual_ticks", 0);
        cooldown(p, cdTicks());
        if (message) p.actionbar(message);
    }
    RPG.every(20, function () {
        RPG.server.players().forEach(function (p) {
            var t = Number(p.getVar("dmz_godritual_ticks", 0)) || 0;
            if (isActiveForm(p)) {
                if (t <= 0) { p.setVar("dmz_godritual_ticks", Math.max(20, Math.round(G("durationMinutes") * 1200))); return; }
                t -= 20;
                p.setVar("dmz_godritual_ticks", Math.max(0, t));
                if (t <= 0) endForm(p, "§cThe divine Ki fades away...");
            } else if (t > 0) {
                p.setVar("dmz_godritual_ticks", 0);
                cooldown(p, cdTicks());
            }
        });
    });

    // ---- interruptions ---------------------------------------------------------------------------
    RPG.on("damageFinal", function (e) {
        var t = e.target;
        if (!t || !t.isPlayer() || e.amount <= 0) return;
        var k = PARTICIPANTS[String(t.uuid)], rit = k ? RITUALS[k] : null;
        if (!rit) return;
        var u = String(t.uuid);
        rit.dmg[u] = (rit.dmg[u] || 0) + Math.min(e.amount, t.health);
        if (rit.dmg[u] > t.maxHealth * G("interruptDamageRatio")) cancel(rit, "§cThe ritual was interrupted");
    });
    RPG.on("death", function (p) { cancelFor(p); if (isActiveForm(p) || (Number(p.getVar("dmz_godritual_ticks", 0)) || 0) > 0) endForm(p, null); });
    RPG.on("playerLeave", function (p) { cancelFor(p); delete LAST_FEEDBACK[uid(p)]; delete SOLO[uid(p)]; });
    RPG.on("playerJoin", function (p) {
        if (PARTICIPANTS[uid(p)]) return;
        if (p.hasEffect("dmz_god_ritual")) p.removeEffect("dmz_god_ritual");
        p.setShared("godRitual", null);
    });
    // dimension changes: a body that is no longer in the ritual's dimension cancels it in tickRitual

    RPG.commands.register("godritual", {
        permission: 2, description: "/rpgc godritual status | reset | end - DMZ's god ritual (test)",
        run: function (p, args) {
            if (!p) return;
            var a = String(args[0] || "status");
            if (a === "reset") { p.removeEffect("god_ritual_cd"); p.tell("&aGod ritual cooldown cleared."); return; }
            if (a === "end") { endForm(p, "&7God form ended."); return; }
            p.tell("&eGod ritual: " + (G("enabled") ? "on" : "off") + ", donors needed here: " + required() + (dbrRitualSolo() ? " (singleplayer rule)" : " (DMZ rule)") +
                ", form " + activeKey(p) + ", pure " + pure(p) + ", cooldown " + cooling(p) + ", form time left " + Math.round((Number(p.getVar("dmz_godritual_ticks", 0)) || 0) / 20) + " s");
        }
    });

    return { evaluate: evaluate, isParticipant: function (p) { return !!PARTICIPANTS[uid(p)]; }, required: required, isActiveForm: isActiveForm };
})();
