// =====================================================================================
//  78_dmz_party.js - DragonMine Z's quest parties (PartyManager, PartySavedData, PartyFeedback)
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): common/quest/{PartyManager,QuestParty,PartyFeedback}.java,
//  server/world/data/PartySavedData.java, server/commands/PartyCommand.java, PartyPackets.
//   - parties are saved with the world (RPG.data "dmz_parties"); the creator owns it, the leader is
//     the owner while online (otherwise the first online member leads until the owner is back)
//   - invites last 60 s; only the leader invites (a member's invite becomes a suggestion to the
//     leader); level gap <= 500; you can only join parties on your difficulty or higher, and joining
//     a harder party needs a confirmation and raises your difficulty for good; no size limit (-1)
//   - a scoreboard team "dmzp_<id>" per party: friendly fire off unless the leader toggles PvP
//   - TP shared: every member gets 50% of the TP another member earns (partyTpShareRatio 0.5)
//   - quests (47_dmz_quests.js): members within 256 blocks start quests together, kills of quest
//     enemies count for everyone, enemies scale HP x1.25 / damage x1.1 per extra member
//   - HUD (client/scripts/61_dmz_party.js): party frames, world markers, invite toast, party screen
//  Commands: /rpgc party invite <player> | accept [confirm] | reject | leave | kick <player> |
//            disband | pvp | list | create        (the V menu's Party tab does the same)
// =====================================================================================
var DMZ_PARTY = (function () {
    var INVITE_MS = 60000, MAX_GAP = 500, MAX_MEMBERS = -1, SHARE_RANGE = 256, TP_SHARE = 0.5;
    var DIFFS = ["EASY", "NORMAL", "HARD"];
    var INVITES = {};          // invitee uuid -> [{ party, inviter, inviterName, leader, exp, diff }]
    var PARTIES = null;        // id -> { owner, leader, members: [uuid], names: {uuid: name}, pvp }

    function parties() { if (!PARTIES) PARTIES = RPG.data.get("dmz_parties", {}) || {}; return PARTIES; }
    function save() { RPG.data.set("dmz_parties", PARTIES || {}); }
    function uid(p) { return String(p.uuid); }
    function online(u) {
        var list = RPG.server.players();
        for (var i = 0; i < list.length; i++) if (String(list[i].uuid) === u) return list[i];
        return null;
    }
    function partyIdOf(u) {
        var ps = parties();
        for (var id in ps) if (ps[id].members.indexOf(u) >= 0) return id;
        return null;
    }
    function partyOf(p) { var id = partyIdOf(uid(p)); return id ? parties()[id] : null; }
    function teamName(id) { return "dmzp_" + id.replace(/-/g, "").substring(0, 11); }
    function tell(p, msg) { if (p) p.tell("&e[DBR-Party]&r " + msg); }
    function diffOf(p) {
        var v = p.getVar("dmz_quests", null);
        return (v && v.d) || "NORMAL";
    }
    function setDiff(p, d) {
        var v = p.getVar("dmz_quests", null) || { q: {}, d: null };
        v.d = d;
        p.setVar("dmz_quests", v);
        if (typeof DMZ_QUESTS !== "undefined") DMZ_QUESTS.sync(p);
    }
    function rank(d) { return Math.max(0, DIFFS.indexOf(d)); }

    // ---- teams (PartyManager.addToMinecraftTeam / applyFriendlyFire) ----
    function applyTeam(id) {
        var party = parties()[id];
        if (!party) return;
        RPG.teams.define(teamName(id), { friendlyFire: !!party.pvp || !!BOUTING[id], seeInvisible: true });
    }
    // PartyManager.setTournamentFriendlyFire: a tournament bout between two members (95_dmz_tournaments.js)
    var BOUTING = {};
    function setTournamentFriendlyFire(id, on) {
        if (!id) return;
        if (on) BOUTING[id] = true; else delete BOUTING[id];
        applyTeam(id);
    }
    // PartyManager.isPartyLocked / isInTournament / onPartyLeave (95_dmz_tournaments.js)
    function tourn() { return typeof DMZ_TOURN !== "undefined" ? DMZ_TOURN : null; }
    function locked(p) { var T = tourn(); return !!T && T.isPartyLocked(p); }
    function inTournament(p) { var T = tourn(); return !!T && !!T.runOf(p); }
    function forfeitTournament(p) { var T = tourn(); if (T) T.onPartyLeave(p); }
    var LOCKED_MSG = "&cNobody can join or be invited to a party while its tournament is underway.";
    function joinTeam(id, p) {
        var cur = RPG.teams.get(p);
        if (cur && cur.indexOf("dmzp_") !== 0) return;          // players already on another team keep it
        applyTeam(id);
        if (cur !== teamName(id)) RPG.teams.join(p, teamName(id));
    }
    function leaveTeam(p) {
        var cur = RPG.teams.get(p);
        if (!cur || cur.indexOf("dmzp_") !== 0) return;
        RPG.teams.leave(p);
        if (RPG.teams.size(cur) === 0) RPG.teams.remove(cur);
    }

    // ---- membership ----
    function members(p) {
        var party = partyOf(p);
        if (!party) return [p];
        var out = [];
        party.members.forEach(function (u) { var m = online(u); if (m) out.push(m); });
        if (!out.length) out.push(p);
        return out;
    }
    function memberIds(p) { var party = partyOf(p); return party ? party.members.slice() : [uid(p)]; }
    function nearby(p) {
        return members(p).filter(function (m) {
            if (uid(m) === uid(p)) return true;
            if (m.dimension !== p.dimension) return false;
            var dx = m.x - p.x, dy = m.y - p.y, dz = m.z - p.z;
            return dx * dx + dy * dy + dz * dz <= SHARE_RANGE * SHARE_RANGE;
        });
    }
    function sameParty(a, b) { var id = partyIdOf(uid(a)); return !!id && id === partyIdOf(uid(b)); }
    function leaderOf(p) { var party = partyOf(p); return party ? online(party.leader) : p; }
    function isLeader(p) { var party = partyOf(p); return !!party && party.leader === uid(p); }
    function difficulty(p) { var l = leaderOf(p); return l ? diffOf(l) : null; }

    function create(p) {
        var id = partyIdOf(uid(p));
        if (id) return id;
        id = String(Date.now().toString(16)) + "-" + RPG.randomInt(100000, 999999).toString(16);
        var names = {};
        names[uid(p)] = p.name;
        parties()[id] = { owner: uid(p), leader: uid(p), members: [uid(p)], names: names, pvp: false };
        save();
        joinTeam(id, p);
        syncParty(id);
        return id;
    }
    /** refreshLeadership: the owner leads while online, else the first online member (temporary). */
    function refreshLeader(id, announce) {
        var party = parties()[id];
        if (!party) return;
        var prev = party.leader, next = null;
        if (online(party.owner) && party.members.indexOf(party.owner) >= 0) next = party.owner;
        else party.members.forEach(function (u) { if (!next && online(u)) next = u; });
        if (!next) next = party.members.indexOf(party.owner) >= 0 ? party.owner : party.members[0];
        party.leader = next;
        if (party.members.indexOf(party.owner) < 0) party.owner = next;
        if (announce && prev !== next && next) {
            var name = party.names[next] || "?";
            each(id, function (m) {
                if (next === party.owner && prev !== party.owner) tell(m, name + " is back and leads the party again");
                else if (!online(prev)) tell(m, "The Party leader has disconnected. Temporary leadership transferred to " + name);
                else tell(m, name + " is now the party leader");
            });
        }
    }
    function each(id, fn) { var party = parties()[id]; if (party) party.members.forEach(function (u) { var m = online(u); if (m) fn(m); }); }

    function leave(p, quiet) {
        var id = partyIdOf(uid(p));
        if (id) forfeitTournament(p);
        leaveTeam(p);
        if (!id) { sendState(p); return; }
        var party = parties()[id];
        party.members = party.members.filter(function (u) { return u !== uid(p); });
        delete party.names[uid(p)];
        if (party.members.length === 0) { delete parties()[id]; RPG.teams.remove(teamName(id)); save(); sendState(p); return; }
        if (!quiet) each(id, function (m) { tell(m, p.name + " left the party"); });
        refreshLeader(id, true);
        save();
        syncParty(id);
        sendState(p);
        RPG.net.send(p, "dmz_party_hud", { members: [] });
    }
    function disband(p) {
        var id = partyIdOf(uid(p)), party = id ? parties()[id] : null;
        if (!party) return tell(p, "You are not in a party with other players");
        if (party.owner !== uid(p)) return tell(p, "Only the player who created the party can disband it");
        var list = party.members.slice();
        list.forEach(function (u) { var m = online(u); if (m) forfeitTournament(m); });
        delete parties()[id];
        save();
        list.forEach(function (u) {
            var m = online(u);
            if (!m) return;
            leaveTeam(m);
            tell(m, u === uid(p) ? "You disbanded the party" : p.name + " disbanded the party");
            sendState(m);
            RPG.net.send(m, "dmz_party_hud", { members: [] });
        });
        RPG.teams.remove(teamName(id));
    }
    function kick(p, target) {
        var id = partyIdOf(uid(p)), party = id ? parties()[id] : null;
        if (!party) return tell(p, "You are not in a party with other players");
        if (party.leader !== uid(p)) return tell(p, "Only the party leader can perform that action");
        if (locked(p)) return p.tell(LOCKED_MSG);
        var tu = null;
        party.members.forEach(function (u) { if (u === target || (party.names[u] || "").toLowerCase() === String(target).toLowerCase()) tu = u; });
        if (!tu) return tell(p, "That player is not in your party");
        if (tu === uid(p)) return tell(p, "You cannot kick yourself from the party");
        if (tu === party.owner) return tell(p, "You can't kick the player who created the party");
        var name = party.names[tu] || "?", m = online(tu);
        if (m) { leave(m, true); tell(m, "You have been kicked from the party"); }
        else { party.members = party.members.filter(function (u) { return u !== tu; }); delete party.names[tu]; refreshLeader(id, false); save(); syncParty(id); }
        tell(p, "&aYou kicked " + name + " from the party");
        each(id, function (o) { if (uid(o) !== uid(p)) tell(o, "&e" + name + " has been kicked from the party"); });
    }
    function togglePvp(p) {
        var id = partyIdOf(uid(p)), party = id ? parties()[id] : null;
        if (!party || party.leader !== uid(p)) return tell(p, "Only the party leader can perform that action");
        party.pvp = !party.pvp;
        save();
        applyTeam(id);
        each(id, function (m) { tell(m, (party.pvp ? "&c" : "&a") + "Party PvP status has been updated. " + (party.pvp ? "✓" : "✕")); });
        syncParty(id);
    }

    // ---- invites (PartyManager.requestInvite / sendInvite / acceptInvite) ----
    function invite(p, target) {
        if (!target) return tell(p, "That player is no longer online.");
        if (uid(target) === uid(p)) return tell(p, "You cannot invite yourself to a party!");
        if (sameParty(p, target)) return tell(p, "That player is already in your party");
        if (locked(p) || inTournament(target)) return p.tell(LOCKED_MSG);
        var party = partyOf(p), leader = party ? online(party.leader) : p;
        if (party && party.leader !== uid(p)) {
            if (!leader) return tell(p, "Only the party leader can invite players, and your leader is offline right now.");
            leader.tell("&e[DBR-Party]&r " + p.name + " has suggested " + target.name + " to join the party. &e/rpgc party invite " + target.name);
            return tell(p, "Only the leader can invite players: your suggestion to invite " + target.name + " was sent to " + leader.name + ".");
        }
        var gap = Math.abs(leader.getLevel() - target.getLevel());
        if (MAX_GAP >= 0 && gap > MAX_GAP) {
            tell(target, p.name + " tried to invite you to their party, but the level gap is too large (party leader: level " + leader.getLevel() + ", you: level " + target.getLevel() + ", max gap: " + MAX_GAP + ").");
            return tell(p, "You can't invite " + target.name + ": the level gap is too large (party leader: level " + leader.getLevel() + ", " + target.name + ": level " + target.getLevel() + ", max gap: " + MAX_GAP + ").");
        }
        var pd = diffOf(leader), td = diffOf(target);
        if (rank(pd) < rank(td)) {
            tell(target, p.name + " tried to invite you, but their party plays on " + pd + " and you play on " + td + ". You can only join parties on your difficulty or higher.");
            return tell(p, "You can't invite " + target.name + ": they play on " + td + " and your party plays on " + pd + ". Players can only join parties on their difficulty or higher.");
        }
        if (MAX_MEMBERS > 0 && party && party.members.length >= MAX_MEMBERS) return tell(p, "Your party is full (" + party.members.length + "/" + MAX_MEMBERS + " members).");
        var id = create(p);
        var list = (INVITES[uid(target)] || []).filter(function (i) { return i.party !== id && i.exp > Date.now(); });
        list.push({ party: id, inviter: uid(p), inviterName: p.name, leader: uid(leader), exp: Date.now() + INVITE_MS, diff: pd });
        INVITES[uid(target)] = list;
        tell(p, "Party invitation sent to " + target.name);
        tell(target, "You have been invited to join " + p.name + "'s party &a/rpgc party accept &7| &c/rpgc party reject");
        if (rank(pd) > rank(td)) tell(target, "This party plays on " + pd + " (you play on " + td + "). Joining it will permanently raise your difficulty.");
        RPG.net.send(target, "dmz_party_invite", { from: p.name });
        sendState(target);
    }
    function pending(p, partyId) {
        var list = (INVITES[uid(p)] || []).filter(function (i) { return i.exp > Date.now() && parties()[i.party]; });
        INVITES[uid(p)] = list;
        if (partyId) { for (var i = 0; i < list.length; i++) if (list[i].party === partyId) return list[i]; return null; }
        return list.length ? list[list.length - 1] : null;
    }
    function accept(p, confirmed, partyId) {
        var inv = pending(p, partyId);
        if (!inv) return tell(p, "You have no pending party invitations");
        var party = parties()[inv.party];
        if (!party) { drop(p, inv.party); return tell(p, "That invitation is no longer valid: the party was disbanded or changed leader."); }
        var leader = online(party.leader);
        if (!leader) { drop(p, inv.party); return tell(p, "That invitation is no longer valid: the party leader is offline."); }
        if (inTournament(p) || locked(leader)) return p.tell(LOCKED_MSG);
        var gap = Math.abs(leader.getLevel() - p.getLevel());
        if (MAX_GAP >= 0 && gap > MAX_GAP) return tell(p, "You can't join " + leader.name + "'s party: the level gap is too large (party leader: level " + leader.getLevel() + ", you: level " + p.getLevel() + ", max gap: " + MAX_GAP + ").");
        var pd = diffOf(leader), od = diffOf(p);
        if (rank(pd) < rank(od)) return tell(p, "You can't join this party: it plays on " + pd + " and you play on " + od + ". You can only join parties on your difficulty or higher.");
        if (rank(pd) > rank(od) && !confirmed) {
            RPG.net.send(p, "dmz_party_confirm", { party: inv.party, diff: pd, own: od, from: inv.inviterName });
            return tell(p, "This party plays on " + pd + " and you play on " + od + ". Joining will permanently change your difficulty to " + pd + " — it won't revert when you leave. &a/rpgc party accept confirm");
        }
        INVITES[uid(p)] = [];
        var own = partyOf(p);
        if (own && own.owner === uid(p) && own.members.length > 1) disband(p); else leave(p, false);
        if (rank(pd) > rank(od)) setDiff(p, pd);
        party.members.push(uid(p));
        party.names[uid(p)] = p.name;
        save();
        joinTeam(inv.party, p);
        tell(p, "&aYou joined the party!");
        each(inv.party, function (m) { if (uid(m) !== uid(p)) tell(m, "&a" + p.name + " joined the party!"); });
        refreshLeader(inv.party, false);
        syncParty(inv.party);
    }
    function drop(p, partyId) { INVITES[uid(p)] = (INVITES[uid(p)] || []).filter(function (i) { return i.party !== partyId; }); }
    function reject(p, partyId) {
        var inv = pending(p, partyId);
        if (!inv) return tell(p, "You have no pending party invitations");
        drop(p, inv.party);
        tell(p, "You rejected the party invitation");
        var inviter = online(inv.inviter);
        if (inviter) tell(inviter, p.name + " rejected the party invitation");
        sendState(p);
    }

    // ---- sync to the client (PartyPackets: screen state + HUD members) ----
    function memberInfo(u, party) {
        var m = online(u), o = { id: u, name: party.names[u] || "?", online: !!m, leader: party.leader === u, owner: party.owner === u };
        if (m) {
            o.name = m.name; o.level = m.getLevel(); o.race = String(m.race || ""); o.cls = String(m.playerClass || "");
            o.hp = Math.round(m.health); o.max = Math.round(m.maxHealth);
        }
        return o;
    }
    function sendState(p) {
        var id = partyIdOf(uid(p)), party = id ? parties()[id] : null;
        var inv = (INVITES[uid(p)] || []).filter(function (i) { return i.exp > Date.now() && parties()[i.party]; }).map(function (i) {
            return { party: i.party, from: i.inviterName, diff: i.diff, left: Math.ceil((i.exp - Date.now()) / 1000) };
        });
        var others = RPG.server.players().filter(function (o) { return uid(o) !== uid(p) && !sameParty(o, p) && o.getVar("dmz_created", 0); })
            .map(function (o) { return { name: o.name, level: o.getLevel() }; });
        RPG.net.send(p, "dmz_party_state", { id: id, me: uid(p), diff: diffOf(p), pvp: party ? !!party.pvp : false,
            members: party ? party.members.map(function (u) { return memberInfo(u, party); }) : [], invites: inv, players: others });
    }
    function syncParty(id) { each(id, function (m) { sendState(m); }); hud(id); }
    function hud(id) {
        var party = parties()[id];
        if (!party) return;
        var list = [];
        party.members.forEach(function (u) { var m = online(u); if (m) list.push(m); });
        if (list.length < 2) { list.forEach(function (m) { RPG.net.send(m, "dmz_party_hud", { members: [] }); }); return; }
        var data = list.map(function (m) {
            var aura = String(m.getVar("dmz_aura_color", "") || "");
            return { id: uid(m), name: m.name, hp: m.health, max: m.maxHealth, ki: m.resource("ki"), kmax: m.maxResource("ki"),
                x: m.x, y: m.y + 1.9, z: m.z, dim: m.dimension, aura: aura || "#4FC3FF", down: !m.isAlive() || m.health <= 0 };
        });
        list.forEach(function (m) { RPG.net.send(m, "dmz_party_hud", { members: data, pvp: !!party.pvp }); });
    }
    RPG.every(20, function () {
        var ps = parties();
        for (var id in ps) { try { hud(id); } catch (e) { } }
    });

    RPG.on("playerJoin", function (p) {
        var id = partyIdOf(uid(p));
        if (!id) return;
        var party = parties()[id];
        party.names[uid(p)] = p.name;
        joinTeam(id, p);
        refreshLeader(id, true);
        save();
        syncParty(id);
    });
    RPG.on("playerLeave", function (p) {
        delete INVITES[uid(p)];
        var id = partyIdOf(uid(p));
        if (!id) return;
        RPG.schedule(1, function () { refreshLeader(id, true); save(); syncParty(id); });
    });

    // TPGainEvents.shareWithParty: every other member gets partyTpShareRatio of what one earns
    var SHARE_SOURCES = { hit: 1, kill: 1, time: 1, hurt: 1, boss: 1, training: 1 };
    RPG.on("tpGain", function (p, amount, source) {
        if (!(amount > 0) || !SHARE_SOURCES[source]) return;
        var party = partyOf(p);
        if (!party || party.members.length < 2) return;
        var share = Math.floor(amount * TP_SHARE);
        if (share <= 0) return;
        party.members.forEach(function (u) {
            if (u === uid(p)) return;
            var m = online(u);
            if (m && m.getVar("dmz_created", 0)) m.addTp(share, { raw: true, events: false, source: "party" });
        });
    });

    // ---- client screen + commands ----
    RPG.net.on("dmz_party", function (p, d) {
        if (!d) return;
        var a = String(d.action || "");
        if (a === "state") return sendState(p);
        if (a === "create") { if (!partyIdOf(uid(p))) create(p); return sendState(p); }
        if (a === "invite") return invite(p, RPG.server.player(String(d.name || "")));
        if (a === "accept") return accept(p, !!d.confirm, d.party ? String(d.party) : null);
        if (a === "reject") return reject(p, d.party ? String(d.party) : null);
        if (a === "leave") { var pt = partyOf(p); if (pt && pt.owner === uid(p) && pt.members.length > 1) return disband(p); tell(p, "You left the party"); return leave(p, false); }
        if (a === "disband") return disband(p);
        if (a === "kick") return kick(p, String(d.id || ""));
        if (a === "pvp") return togglePvp(p);
    });
    function open(p) { sendState(p); RPG.net.send(p, "dmz_open_party", {}); }

    // DMZ's /dmzparty (PartyCommand): invite, accept, reject, kick, disband and pvp need dbr.party.use (everyone by default)
    var PARTY_USE = ["invite", "accept", "confirm", "reject", "kick", "disband", "pvp", "create"];
    RPG.commands.register("party", {
        description: "/rpgc party <invite|accept|reject|leave|kick|disband|pvp|list|create> [player]",
        suggest: function (p, args) {
            var use = !p || DBR_CMD.has(p, "party.use");
            if (args.length <= 1) return ["leave", "list"].concat(use ? PARTY_USE.filter(function (s) { return s !== "confirm"; }) : []);
            var sub = String(args[0]);
            if (args.length === 2 && sub === "accept") return ["confirm"];
            if (args.length === 2 && sub === "invite") return RPG.server.players().filter(function (x) { return !p || x.uuid !== p.uuid; }).map(function (x) { return x.name; });
            if (args.length === 2 && sub === "kick" && p) { var pt = partyOf(p); return pt ? pt.members.filter(function (u) { return u !== uid(p); }).map(function (u) { return pt.names[u] || u; }) : []; }
            return [];
        },
        run: function (p, args) {
            if (!p) return;
            var sub = String(args[0] || "list");
            if (PARTY_USE.indexOf(sub) >= 0 && !DBR_CMD.has(p, "party.use")) return p.tell("&cYou don't have permission.");
            if (sub === "invite") return invite(p, RPG.server.player(String(args[1] || "")));
            if (sub === "accept") return accept(p, args[1] === "confirm", null);
            if (sub === "confirm") return accept(p, true, null);
            if (sub === "reject") return reject(p, null);
            if (sub === "leave") {
                var pt = partyOf(p);
                if (!pt) return tell(p, "You are not in a party with other players");
                if (pt.owner === uid(p) && pt.members.length > 1) return disband(p);
                tell(p, "You left the party");
                return leave(p, false);
            }
            if (sub === "kick") return kick(p, String(args[1] || ""));
            if (sub === "disband") return disband(p);
            if (sub === "pvp") return togglePvp(p);
            if (sub === "create") { create(p); return tell(p, "&aParty created. Invite players with /rpgc party invite <player>"); }
            if (sub === "open") return open(p);
            // PartyCommand.listMembers: leader ⭐ gold, owner ☆, offline grey
            var party = partyOf(p);
            p.tell("&6&l=== Party Members ===");
            if (!party) return p.tell("&6  - " + p.name + " ⭐");
            party.members.forEach(function (u) {
                var isLeader = u === party.leader, isOwner = u === party.owner;
                p.tell((!online(u) ? "&7" : isLeader ? "&6" : "&e") + "  - " + (party.names[u] || u) + (isLeader ? " ⭐" : isOwner ? " ☆" : ""));
            });
            p.tell("&7PvP: " + (party.pvp ? "&con" : "&aoff"));
        }
    });

    return { members: members, memberIds: memberIds, nearby: nearby, sameParty: sameParty, leaderOf: leaderOf, isLeader: isLeader,
        difficulty: difficulty, open: open, sendState: sendState, setTournamentFriendlyFire: setTournamentFriendlyFire, partyIdOf: function (p) { return partyIdOf(uid(p)); } };
})();
