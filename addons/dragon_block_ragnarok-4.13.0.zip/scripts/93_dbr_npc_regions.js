// =====================================================================================
//  93_dbr_npc_regions.js - NPC regions (server)
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0) shuruisutilities npcregion: NpcRegionManager (store, spawner tick, tether,
//  census, behaviour, kill rewards), NpcSpawnConfig.applyTo, LevelScaledStats, KillTpModifier, CustomDrop,
//  GroundBlocks + RegionSurfacePicker, NpcRegionImport and the editor packets.
//
//  The area is drawn on the world map instead (client/scripts/83_dbr_npc_regions.js): free-form polygons per
//  dimension. Data model: shared/23_dbr_npc_regions_data.js. Each region is saved under its own RPG.data key
//  ("dbr_npcr:<id>", index "dbr_npcr_index"), so the store never meets the per-key size limit.
//
//  Spawning: NPCs only spawn near players standing in (or right at the edge of) a region, at a real ground spot
//  inside its shapes and Y band (never on a canopy or a roof when there is ground; never in water). Each NPC slot
//  keeps up to maxSpawns alive PER nearby player and refills every cooldownTicks. Mobs that wander out are pulled
//  back; ones no player is near any more are removed.
//
//  Level scaling (LevelScale): stats and rewards are set at level 1 and at scaleMaxLevel, interpolated on the DMZ
//  level (player.getLevel()). A new mob is scaled for the lowest level among the players near it and raised to a
//  stronger attacker's level when hit, keeping its health fraction.
//
//  Kill TP (KillTpModifier): DMZ's kill TP is scaled by a 10 s multi-kill window (-8% per extra kill, floor 50%)
//  and, in a region with a TP falloff level, by the killer's level above it (to a 20% floor over the range).
//  09_dmz_stats.js asks DBR_KILL_TP for it.
//
//  Commands: /npcregion edit | list | tp <id> | delete <id> | import | reload. Permission: op or rg.npcregion.
// =====================================================================================
var DBR_KILL_TP = null;
var DBR_NPCR = (function () {
    var D = DBR_NPCR_DATA;
    var PERM = "rg.npcregion", INDEX = "dbr_npcr_index", PREFIX = "dbr_npcr:", MOBS_KEY = "dbr_npcr_mobs", CHUNK = 24000;
    var TAG = "dbr_npcr";
    var FEATURE_A_WINDOW = 10000, FEATURE_A_STEP = 0.08, FEATURE_A_FLOOR = 0.5, FEATURE_B_FLOOR = 0.2;
    var ANCHOR_EDGE = 24, SPAWN_MIN = 8, SPAWN_MAX = 40, DESPAWN_RANGE = 96, PACK_RANGE = 16, PROVOKE_TICKS = 600;

    function can(p) { if (!p) return true; try { return p.isOp() || RPG.perms.has(p, PERM); } catch (e) { return false; } }
    function now() { try { return RPG.server.getTick(); } catch (e) { return 0; } }
    function strip(s) { return String(s || "").replace(/[&§][0-9a-fk-or]/gi, ""); }
    function col(s) { return String(s || "").replace(/&([0-9a-fk-or])/gi, "§$1"); }

    // =========================================================================================
    //  Store
    // =========================================================================================
    var REG = {};
    function load() {
        REG = {};
        (RPG.data.get(INDEX, []) || []).forEach(function (id) {
            var raw = RPG.data.get(PREFIX + id, null);
            if (raw) REG[id] = D.region(raw);
        });
    }
    function plain(r) { var o = D.region(r); return JSON.parse(JSON.stringify(o)); }
    function saveIndex() { RPG.data.set(INDEX, Object.keys(REG).sort()); }
    function put(r) {
        r = D.region(r);
        REG[r.id] = r;
        RPG.data.set(PREFIX + r.id, plain(r));
        saveIndex();
        return r;
    }
    function remove(id) {
        if (!REG[id]) return false;
        delete REG[id];
        RPG.data.remove(PREFIX + id);
        saveIndex();
        despawnRegion(id);
        return true;
    }
    function find(q) {
        q = String(q || "").toLowerCase();
        if (REG[q]) return REG[q];
        var id = D.idOf(q);
        if (REG[id]) return REG[id];
        for (var k in REG) if (strip(REG[k].name).toLowerCase() === q || strip(REG[k].title).toLowerCase() === q) return REG[k];
        return null;
    }
    function live() { var out = []; for (var k in REG) { var r = REG[k]; if (r.enabled && !r.eventOnly && r.shapes.length) out.push(r); } return out; }
    function regionAt(dim, x, y, z) {
        var l = live();
        for (var i = 0; i < l.length; i++) if (D.contains(l[i], dim, x, y, z)) return l[i];
        return null;
    }
    load();

    // =========================================================================================
    //  Bodies: entity ids (DMZR's, dragonminez:, rgnpc#, vanilla, this game's mobs) -> what to spawn
    // =========================================================================================
    var RG_BODIES = {};
    function rgBodyId(entry) { return "dbr_npcr_rg_" + String(entry).replace(/[^a-z0-9_]/g, "_"); }
    (function defineRgBodies() {
        if (typeof RG_NPC_INDEX === "undefined") return;
        var want = {};
        for (var k in REG) REG[k].npcs.forEach(function (c) {
            if (c.rgModelId) want[c.rgModelId] = 1;
            if (c.entityTypeId.indexOf("rgnpc#") === 0) want[c.entityTypeId.substring(6)] = 1;
        });
        Object.keys(want).forEach(function (entry) {
            var r = RG_NPC_INDEX[entry];
            if (!r) return;
            RG_BODIES[entry] = rgBodyId(entry);
            RPG.mobs.define(rgBodyId(entry), { name: "&f" + r[5], geo: dmzSagaStates({ model: "dbr:geo/entity/rgnpc/" + r[1] + ".geo.json", texture: "dbr:textures/entity/rgnpc/" + r[2] + ".png",
                animation: DMZ_ANIM + "sagas/saga_base.animation.json", idle: "idle", walk: "walk", attack: "attack1_1" }), width: r[3], height: r[4],
                health: 100, damage: 5, speed: 0.3, followRange: 16, persistent: true, xp: 0 });
        });
    })();
    function sagaMob(path) { path = String(path || "").replace(/^saga_cl_/, "saga_"); return RPG.mobs.exists("dmzq_" + path) ? "dmzq_" + path : RPG.mobs.exists("dmzq_" + path + "_v0") ? "dmzq_" + path + "_v0" : null; }   // variant 0 has no suffix (47_dmz_quests.js)
    function fighterMob() { return RPG.mobs.exists("dbr_raid_fighter") ? "dbr_raid_fighter" : null; }
    /** entity id (+ ragnarok model) -> { kind: "mob" | "entity", id } or null */
    function resolveBody(type, model) {
        type = String(type || "").trim(); model = String(model || "").trim();
        if (type.indexOf("rgnpc#") === 0) { model = type.substring(6); type = "dmz_ragnarok:rgnpc"; }
        if (type === "dmz_ragnarok:rgnpc" || type === "dmz_ragnarok:ninjin_npc" || (model && type === D.DEFAULT_ENTITY)) {
            if (model && RG_BODIES[model]) return { kind: "mob", id: RG_BODIES[model] };
            if (model && RPG.mobs.exists("dbr_raid_rg_" + model.replace(/[^a-z0-9_]/g, "_"))) return { kind: "mob", id: "dbr_raid_rg_" + model.replace(/[^a-z0-9_]/g, "_") };
            var sm = sagaMob(model) || fighterMob();
            return sm ? { kind: "mob", id: sm } : null;
        }
        if (!type || type === D.DEFAULT_ENTITY || type === "dmz_ragnarok:raid_npc") { var f = fighterMob(); return f ? { kind: "mob", id: f } : { kind: "entity", id: "minecraft:zombie" }; }
        if (RPG.mobs.exists(type)) return { kind: "mob", id: type };
        var c = type.indexOf(":"), ns = c >= 0 ? type.substring(0, c) : "", path = c >= 0 ? type.substring(c + 1) : type;
        if (ns === "" || ns === "dragonminez" || ns === "dmzpack" || ns === "dbr" || ns === "dmz_ragnarok") {
            var s = sagaMob(path);
            if (s) return { kind: "mob", id: s };
            if (RPG.mobs.exists(path)) return { kind: "mob", id: path };
        }
        return { kind: "entity", id: c >= 0 ? type : "minecraft:" + type };
    }

    // =========================================================================================
    //  Ground picking (GroundBlocks + RegionSurfacePicker): a real, standable spot on natural ground
    // =========================================================================================
    var AIR = { "minecraft:air": 1, "minecraft:cave_air": 1, "minecraft:void_air": 1 };
    var SOFT = /(^|:)(short_grass|grass|tall_grass|fern|large_fern|dead_bush|snow|.*flower.*|dandelion|poppy|.*tulip|blue_orchid|allium|azure_bluet|oxeye_daisy|cornflower|lily_of_the_valley|.*sapling|.*mushroom|sweet_berry_bush|.*_roots|nether_sprouts|seagrass)$/;
    var GROUND = /(^|:)(.*dirt.*|grass_block|podzol|mycelium|.*sand|.*stone|granite|diorite|andesite|deepslate|tuff|calcite|.*terracotta|gravel|clay|mud|moss_block|snow_block|powder_snow|soul_soil|netherrack|basalt|.*nylium|end_stone|.*grass_block|.*_soil|ice|packed_ice|blue_ice)$/;
    var BUILT = /(planks|slab|stairs|brick|_wall|glass|wool|concrete|polished|smooth_|cut_|chiseled|_log|_wood|leaves|fence|door|trapdoor|carpet|bookshelf|tiles|pillar|quartz|copper|iron_block|gold_block)/;
    function passable(b) { return !!AIR[b] || SOFT.test(b); }
    /** The block under a spot is natural ground (preferred), not a roof, a canopy or a wall. */
    function isGround(b) { return GROUND.test(b) && !BUILT.test(b); }
    /**
     * A standing spot in the column, inside minY..maxY: the surface (leaves ignored) when it is in the band, else the
     * highest air-over-solid gap below maxY (a cave floor for a band under the surface). null when none.
     */
    function columnSpot(r, x, z) {
        var dim = r.dim;
        if (!RPG.world.isLoaded(dim, x, z)) return null;
        var y = RPG.world.surfaceY(dim, x, z);
        if (y === -9999) return null;
        if (y < r.minY || y > r.maxY) {
            var top = Math.min(r.maxY, y - 1), found = null;
            for (var yy = top, n = 0; yy > r.minY && n < 96; yy--, n++) {
                if (passable(RPG.world.getBlock(dim, x, yy, z)) && passable(RPG.world.getBlock(dim, x, yy + 1, z)) && !passable(RPG.world.getBlock(dim, x, yy - 1, z))) { found = yy; break; }
            }
            if (found === null) return null;
            y = found;
        }
        if (!passable(RPG.world.getBlock(dim, x, y, z)) || !passable(RPG.world.getBlock(dim, x, y + 1, z))) return null;
        if (RPG.world.getFluid(dim, x, y, z) || RPG.world.getFluid(dim, x, y - 1, z)) return null;
        var below = RPG.world.getBlock(dim, x, y - 1, z);
        return { x: x + 0.5, y: y, z: z + 0.5, ground: isGround(below) };
    }
    /** RegionSurfacePicker.search near an anchor: genuine ground first, else a second choice, else null. */
    function pickSpot(r, ax, az) {
        var second = null;
        for (var i = 0; i < 28; i++) {
            var ang = Math.random() * Math.PI * 2, dist = SPAWN_MIN + Math.random() * (SPAWN_MAX - SPAWN_MIN);
            var x = Math.floor(ax + Math.cos(ang) * dist), z = Math.floor(az + Math.sin(ang) * dist);
            if (!D.containsColumn(r, x, z)) continue;
            var s = columnSpot(r, x, z);
            if (!s) continue;
            if (s.ground) return s;
            if (!second) second = s;
        }
        if (second) return second;
        // anchor at the edge of a small region: try columns anywhere in the region near the anchor
        var b = D.regionBounds(r);
        for (var j = 0; j < 16; j++) {
            var x2 = Math.floor(b[0] + Math.random() * (b[2] - b[0])), z2 = Math.floor(b[1] + Math.random() * (b[3] - b[1]));
            if ((x2 - ax) * (x2 - ax) + (z2 - az) * (z2 - az) > SPAWN_MAX * SPAWN_MAX * 2.25 || !D.containsColumn(r, x2, z2)) continue;
            var s2 = columnSpot(r, x2, z2);
            if (s2) return s2;
        }
        return null;
    }

    // =========================================================================================
    //  Spawned mobs: uuid -> { r, i, lv, def, home, seen, out }
    // =========================================================================================
    var MOBS = RPG.data.get(MOBS_KEY, {}) || {};
    var dirty = false;
    function markDirty() { dirty = true; }
    RPG.every(200, function () { if (dirty) { dirty = false; RPG.data.set(MOBS_KEY, MOBS); } });
    function cfgOf(rec) { var r = rec && REG[rec.r]; return r ? r.npcs[rec.i] || null : null; }

    /** Scale a region mob for a level, keeping its health fraction (LevelScaledStats.apply). */
    function applyLevel(m, rec, cfg, level) {
        var s = D.statsAt(cfg, level);
        var frac = m.maxHealth > 0 ? m.health / m.maxHealth : 1;
        if (!(frac > 0)) frac = 1;
        m.maxHealth = s.hp;
        m.health = Math.max(1, Math.min(s.hp, s.hp * frac));
        m.setAttributeBase("generic.attack_damage", s.dmg);
        rec.def = s.def;
        rec.lv = D.scales(cfg) ? Math.max(1, level) : 1;
        if (typeof DMZ_SAGA !== "undefined" && DMZ_SAGA.dmzId(m)) {
            var b = DMZ_SAGA.brainOf ? DMZ_SAGA.brainOf(m) : null;
            if (b && s.ki > 0) { b.ki = s.ki; if (b.st) b.st.ki = s.ki; }
        }
        markDirty();
    }
    /** NpcSpawnConfig.applyTo + the NPC options on a freshly spawned mob. */
    function setupMob(m, r, idx, cfg, level, spot) {
        m.addTag(TAG); m.addTag(TAG + ":" + r.id);
        try { m.setDrops(!!cfg.vanillaDrops); } catch (e) { }
        if (cfg.displayName) { try { m.setCustomName(cfg.displayName); m.setNameVisible(true); } catch (e) { } }
        try { m.setAttributeBase("generic.movement_speed", cfg.moveSpeed); } catch (e) { }
        try { m.setAttributeBase("generic.follow_range", Math.max(0, cfg.aggroRange)); } catch (e) { }
        if (cfg.scale > 0 && cfg.scale !== 1) { try { m.setScale(cfg.scale); } catch (e) { } }
        var rec = { r: r.id, i: idx, lv: 1, def: cfg.defense, home: { x: spot.x, y: spot.y, z: spot.z }, seen: now(), out: 0 };
        MOBS[m.uuid] = rec;
        if (typeof DMZ_SAGA !== "undefined" && DMZ_SAGA.dmzId(m)) {
            var st = D.statsAt(cfg, level), base = typeof dmzSagaBase === "function" ? dmzSagaBase(DMZ_SAGA.dmzId(m)) : null;
            DMZ_SAGA.setup(m, { hp: st.hp, melee: st.dmg, ki: st.ki > 0 ? st.ki : (base ? base[2] : 20), tier: cfg.aiTier + 1 + (cfg.behavior === 6 ? 1 : 0), noTransform: true, diff: { hp: 1, dmg: 1 } });
            var b = DMZ_SAGA.brainOf ? DMZ_SAGA.brainOf(m) : null;
            if (b && !cfg.kiEnabled) b.skills = [];        // Ki Attacks off: melee only
        }
        applyLevel(m, rec, cfg, level);
        m.health = m.maxHealth;
        markDirty();
        return rec;
    }
    function spawnOne(r, idx, cfg, spot, level) {
        var body = resolveBody(cfg.entityTypeId, cfg.rgModelId), m = null;
        if (!body) return null;
        try { m = body.kind === "mob" ? RPG.world.spawnMob(r.dim, body.id, spot.x, spot.y, spot.z) : RPG.world.spawn(r.dim, body.id, spot.x, spot.y, spot.z); } catch (e) { m = null; }
        if (!m) return null;
        if (!m.isAlive || m.maxHealth === undefined) { try { m.remove(); } catch (e) { } return null; }
        setupMob(m, r, idx, cfg, level, spot);
        return m;
    }
    function despawnRegion(id) {
        Object.keys(MOBS).forEach(function (u) {
            if (MOBS[u].r !== id) return;
            var e = RPG.world.entityByUuid(u);
            if (e) try { e.remove(); } catch (x) { }
            delete MOBS[u];
        });
        markDirty();
    }

    // =========================================================================================
    //  Spawner tick (1 s): anchors, census, waves
    // =========================================================================================
    var CD = {};          // "region:idx" -> ticks until the next wave
    function nearEdge(r, x, z) {
        var b = D.regionBounds(r);
        if (x < b[0] - ANCHOR_EDGE || x > b[2] + ANCHOR_EDGE || z < b[1] - ANCHOR_EDGE || z > b[3] + ANCHOR_EDGE) return false;
        if (D.containsColumn(r, Math.floor(x), Math.floor(z))) return true;
        for (var a = 0; a < 8; a++) {
            var ang = a * Math.PI / 4;
            if (D.containsColumn(r, Math.floor(x + Math.cos(ang) * ANCHOR_EDGE * 0.6), Math.floor(z + Math.sin(ang) * ANCHOR_EDGE * 0.6))) return true;
        }
        return false;
    }
    function anchorsFor(r, players) {
        return players.filter(function (p) {
            if (p.dimension !== r.dim) return false;
            try { if (p.getGameMode && p.getGameMode() === "spectator") return false; } catch (e) { }
            if (p.y < r.minY - 32 || p.y > r.maxY + 32) return false;
            return nearEdge(r, p.x, p.z);
        });
    }
    function census() {
        var count = {}, t = now();
        Object.keys(MOBS).forEach(function (u) {
            var rec = MOBS[u], e = RPG.world.entityByUuid(u);
            if (!REG[rec.r] || !cfgOf(rec)) { if (e) try { e.remove(); } catch (x) { } delete MOBS[u]; markDirty(); return; }
            if (!e) { if (t - (rec.seen || 0) > 20 * 600) { delete MOBS[u]; markDirty(); } return; }
            if (!e.isAlive()) { delete MOBS[u]; markDirty(); return; }
            rec.seen = t;
            var k = rec.r + ":" + rec.i;
            count[k] = (count[k] || 0) + 1;
        });
        return count;
    }
    function lowestLevelNear(players, x, z, dim) {
        var lv = 0;
        players.forEach(function (p) {
            if (p.dimension !== dim) return;
            var dx = p.x - x, dz = p.z - z;
            if (dx * dx + dz * dz > 64 * 64) return;
            var l = Math.max(1, p.getLevel());
            if (!lv || l < lv) lv = l;
        });
        return lv || 1;
    }
    RPG.every(20, function () {
        var players = RPG.server.players();
        if (!players.length) return;
        var count = census();
        live().forEach(function (r) {
            if (!r.npcs.length) return;
            var anchors = anchorsFor(r, players);
            r.npcs.forEach(function (cfg, i) {
                var k = r.id + ":" + i;
                // no anchor: no cooldown burns (an empty region does not stock up)
                if (!anchors.length) return;
                CD[k] = (CD[k] === undefined ? 0 : CD[k]) - 20;
                if (CD[k] > 0) return;
                CD[k] = cfg.cooldownTicks;
                var alive = count[k] || 0, cap = cfg.maxSpawns * anchors.length, want = Math.min(cap - alive, cfg.maxSpawns);
                for (var n = 0; n < want; n++) {
                    var a = anchors[Math.floor(Math.random() * anchors.length)];
                    var spot = pickSpot(r, a.x, a.z);
                    if (!spot) continue;
                    if (spawnOne(r, i, cfg, spot, lowestLevelNear(players, spot.x, spot.z, r.dim))) count[k] = (count[k] || 0) + 1;
                }
            });
        });
    });

    // =========================================================================================
    //  Tether, despawn and behaviour (NpcRegionBehavior) - every second
    // =========================================================================================
    var PROVOKE = {};     // uuid -> { by, until }
    function nearestPlayer(e, players, range) {
        var best = null, bd = range * range;
        players.forEach(function (p) {
            if (p.dimension !== e.dimension || !p.isAlive()) return;
            try { if (p.getGameMode && (p.getGameMode() === "spectator" || p.getGameMode() === "creative")) return; } catch (x) { }
            var dx = p.x - e.x, dy = p.y - e.y, dz = p.z - e.z, d = dx * dx + dy * dy + dz * dz;
            if (d < bd) { bd = d; best = p; }
        });
        return best;
    }
    RPG.every(20, function () {
        var players = RPG.server.players(), t = now();
        Object.keys(MOBS).forEach(function (u) {
            var rec = MOBS[u], r = REG[rec.r], cfg = cfgOf(rec);
            if (!r || !cfg) return;
            var e = RPG.world.entityByUuid(u);
            if (!e || !e.isAlive()) return;
            // nobody near any more: remove it (the region restocks when someone comes back)
            if (!nearestPlayer(e, players, DESPAWN_RANGE) && !players.some(function (p) { return p.dimension === e.dimension && Math.abs(p.x - e.x) < DESPAWN_RANGE && Math.abs(p.z - e.z) < DESPAWN_RANGE; })) {
                try { e.remove(); } catch (x) { }
                delete MOBS[u]; markDirty(); return;
            }
            // tether: out of the shapes for 2 checks -> back home
            if (!D.contains(r, e.dimension, e.x, e.y, e.z)) {
                rec.out = (rec.out || 0) + 1;
                if (rec.out >= 2 && rec.home) { e.target = null; e.teleport(rec.home.x, rec.home.y, rec.home.z); rec.out = 0; delete PROVOKE[u]; }
                else if (rec.home) { try { e.moveTo(rec.home.x, rec.home.y, rec.home.z, 0.4); } catch (x) { } }
                return;
            }
            rec.out = 0;
            var pv = PROVOKE[u];
            if (pv && pv.until > t) {
                var by = RPG.world.entityByUuid(pv.by);
                if (by && by.isAlive() && by.dimension === e.dimension && e.distanceTo(by) < 48) { if (!e.target || e.target.uuid !== by.uuid) e.target = by; return; }
                delete PROVOKE[u];
            } else if (pv) delete PROVOKE[u];
            var b = cfg.behavior, tg = e.target;
            if (b <= 3) {
                if (tg && tg.isPlayer()) e.target = null;
                if (b === 3) {   // Follower: stays near the nearest player
                    var f = nearestPlayer(e, players, 16);
                    if (f && e.distanceTo(f) > 3) { try { e.moveTo(f.x, f.y, f.z, 0.35); } catch (x) { } }
                } else if (b === 1 && !e.isMoving() && Math.random() < 0.3) {   // Wander
                    var wx = e.x + (Math.random() - 0.5) * 12, wz = e.z + (Math.random() - 0.5) * 12;
                    if (D.contains(r, e.dimension, wx, e.y, wz)) { try { e.moveTo(wx, e.y, wz, 0.25); } catch (x) { } }
                } else if ((b === 0 || b === 2) && e.isMoving() && !tg) { /* passive and dialogue: let them idle */ }
                return;
            }
            // Guard (4), Hostile (5), DMZ Fighter (6): acquire players inside the aggro range
            if (!tg || !tg.isAlive()) {
                var near = cfg.aggroRange > 0 ? nearestPlayer(e, players, cfg.aggroRange) : null;
                if (near) e.target = near;
                else if (b === 4 && rec.home && e.distanceTo && Math.abs(e.x - rec.home.x) + Math.abs(e.z - rec.home.z) > 6) { try { e.moveTo(rec.home.x, rec.home.y, rec.home.z, 0.35); } catch (x) { } }
            }
        });
    });

    // =========================================================================================
    //  Combat: raise to a stronger attacker, pack aggro, defense
    // =========================================================================================
    RPG.on("attack", function (ev) {
        var t = ev.target, a = ev.attacker;
        if (!t || !a || !a.isPlayer()) return;
        var rec = MOBS[t.uuid];
        if (!rec) return;
        var cfg = cfgOf(rec);
        if (!cfg) return;
        try {
            var lv = Math.max(1, a.asPlayer().getLevel());
            if (D.scales(cfg) && lv > (rec.lv || 1)) applyLevel(t, rec, cfg, lv);
        } catch (e) { }
        // pack aggro: every regionmate in notice range turns on the attacker, passive ones included
        var until = now() + PROVOKE_TICKS;
        PROVOKE[t.uuid] = { by: a.uuid, until: until };
        try {
            t.nearby(PACK_RANGE).forEach(function (o) {
                var or = MOBS[o.uuid];
                if (or && or.r === rec.r) PROVOKE[o.uuid] = { by: a.uuid, until: until };
            });
        } catch (e) { }
    });
    RPG.on("damageFinal", function (ev) {
        if (ev.isCancelled()) return;
        var t = ev.target, rec = t ? MOBS[t.uuid] : null;
        if (!rec) return;
        var dfn = rec.def || 0;
        if (dfn > 0) ev.amount = ev.amount * (1 - Math.min(0.88, dfn / (dfn + 100)));
    });

    // =========================================================================================
    //  KillTpModifier + kill rewards
    // =========================================================================================
    var RECENT = {};      // player uuid -> [ms]
    var KMULT = {};       // victim uuid -> multiplier for this kill (both callers agree)
    function featureA(pu) {
        var t = Date.now(), w = RECENT[pu] || (RECENT[pu] = []);
        while (w.length && t - w[0] > FEATURE_A_WINDOW) w.shift();
        var n = w.length + 1;
        w.push(t);
        return Math.max(FEATURE_A_FLOOR, 1 - FEATURE_A_STEP * (n - 1));
    }
    /** KillTpModifier.regionLevelFalloff */
    function falloff(r, level) {
        if (!r || r.tpFalloffLevel <= 0 || level <= r.tpFalloffLevel) return 1;
        var over = level - r.tpFalloffLevel, range = Math.max(1, r.tpFalloffRange);
        return Math.max(FEATURE_B_FLOOR, Math.min(1, 1 - (over / range) * (1 - FEATURE_B_FLOOR)));
    }
    function killMult(p, victim) {
        if (!victim || victim.isPlayer()) return 1;
        if (KMULT[victim.uuid] !== undefined) return KMULT[victim.uuid];
        var a = featureA(p.uuid), rec = MOBS[victim.uuid], cfg = cfgOf(rec), b = 1;
        if (!(cfg && D.scales(cfg))) b = falloff(regionAt(victim.dimension, victim.x, victim.y, victim.z), Math.max(1, p.getLevel()));
        var m = Math.max(0, Math.min(1, a * b));
        KMULT[victim.uuid] = m;
        var vu = victim.uuid;
        RPG.schedule(2, function () { delete KMULT[vu]; });
        return m;
    }
    /** 09_dmz_stats.js: DMZ's kill TP base for this kill (a scaled mob pays on its level 1 health). */
    DBR_KILL_TP = function (p, victim, base) {
        try {
            var rec = victim ? MOBS[victim.uuid] : null, cfg = cfgOf(rec);
            if (cfg) base = 2 + Math.round(cfg.maxHealth * 0.25);
            return base * killMult(p, victim);
        } catch (e) { return base; }
    };
    RPG.on("playerLeave", function (p) { delete RECENT[p.uuid]; });
    RPG.on("kill", function (p, victim) {
        if (!victim) return;
        var rec = MOBS[victim.uuid], cfg = cfgOf(rec);
        if (!cfg) return;
        var lv = Math.max(1, p.getLevel()), rw = D.rewardsAt(cfg, lv), mult = killMult(p, victim);
        delete MOBS[victim.uuid]; delete PROVOKE[victim.uuid]; markDirty();
        var tp = Math.floor(rw.tp * mult);
        if (tp > 0) p.addTp(tp, { raw: true, events: false, source: "kill" });
        if (rw.bal > 0) p.addMoney(rw.bal);
        if (cfg.killCommands) cfg.killCommands.split(";").forEach(function (c) {
            c = c.trim().replace(/^\//, "");
            if (c) try { RPG.server.runCommand(c.split("%player%").join(p.name)); } catch (e) { RPG.log("[NpcRegion] kill command failed: " + c); }
        });
        cfg.drops.forEach(function (d) {
            if (!d.itemId || d.chance <= 0 || (d.chance < 100 && Math.random() * 100 >= d.chance)) return;
            var lo = Math.max(0, Math.min(d.minCount, d.maxCount)), hi = Math.max(0, Math.max(d.minCount, d.maxCount));
            var n = hi <= lo ? lo : lo + Math.floor(Math.random() * (hi - lo + 1));
            if (n <= 0) return;
            var id = d.itemId;
            if (/^dmz_ragnarok:/.test(id) && RPG.items.exists(id.substring(13))) id = id.substring(13);
            try { RPG.world.dropItem(victim.dimension, victim.x, victim.y + 0.5, victim.z, d.nbt ? { id: id, nbt: d.nbt } : id, n); }
            catch (e) { RPG.log("[NpcRegion] bad drop " + d.itemId + ": " + e); }
        });
    });

    // =========================================================================================
    //  Region display: entry title + HUD (NpcRegion title/description/difficulty/showTitle/showHud)
    // =========================================================================================
    var HERE = {};
    RPG.every(10, function () {
        RPG.server.players().forEach(function (p) {
            var r = regionAt(p.dimension, p.x, p.y, p.z), id = r ? r.id : "";
            if ((HERE[p.uuid] || "") === id) return;
            HERE[p.uuid] = id;
            if (!r) { RPG.net.send(p, "dbr_npcr_here", { id: "" }); return; }
            var title = r.title || r.name;
            if (r.showTitle) p.title(col(title), col(r.difficulty ? "§7" + r.difficulty : r.description));
            RPG.net.send(p, "dbr_npcr_here", { id: r.id, title: col(title), description: col(r.description), difficulty: col(r.difficulty), hud: !!r.showHud });
        });
    });
    RPG.on("playerLeave", function (p) { delete HERE[p.uuid]; });

    // =========================================================================================
    //  Import (NpcRegionImport): DMZ Ragnarok npcregions.json
    // =========================================================================================
    /** Import regions from DMZR JSON: an array, {regions: [...]}, or a name -> region map. Returns the ids. */
    function importJson(j) {
        var list = [];
        if (!j) return list;
        if (Array.isArray(j)) list = j;
        else if (Array.isArray(j.regions)) list = j.regions;
        else if (j.name && (j.boxes || j.npcs || j.shapes)) list = [j];
        else for (var k in j) if (j[k] && typeof j[k] === "object") { var o = j[k]; if (!o.name) o.name = k; list.push(o); }
        var out = [];
        list.forEach(function (o) {
            if (!o || !o.name) return;
            var r = o.shapes ? D.region(o) : D.fromDmzr(o);
            if (r && r.shapes.length) { put(r); out.push(r.id); }
        });
        return out;
    }
    function importFiles() {
        var ids = [];
        try { ids = ids.concat(importJson(RPG.files.read("npcregions.json"))); } catch (e) { }
        try {
            var cfgFile = RPG.files.config("dbr_npcregion_import", { regions: [] });
            ids = ids.concat(importJson(cfgFile));
        } catch (e) { }
        return ids;
    }

    // =========================================================================================
    //  Editor networking
    // =========================================================================================
    function sendChunked(p, kind, obj) {
        var s = JSON.stringify(obj), n = Math.max(1, Math.ceil(s.length / CHUNK)), id = String(Date.now() % 1000000) + Math.floor(Math.random() * 1000);
        for (var i = 0; i < n; i++) RPG.net.send(p, "dbr_npcr_data", { kind: kind, id: id, i: i, n: n, s: s.substring(i * CHUNK, (i + 1) * CHUNK) });
    }
    function counts() { var c = {}; Object.keys(MOBS).forEach(function (u) { c[MOBS[u].r] = (c[MOBS[u].r] || 0) + 1; }); return c; }
    function sendAll(p, select) {
        var out = [];
        Object.keys(REG).sort().forEach(function (k) { out.push(plain(REG[k])); });
        sendChunked(p, "editor", { regions: out, alive: counts(), dim: p.dimension, select: select || "" });
    }
    function ack(p, op, ok, msg, extra) { var d = { op: op, ok: ok, msg: msg }; for (var k in extra || {}) d[k] = extra[k]; RPG.net.send(p, "dbr_npcr_ack", d); }
    var INBOX = {};
    var VANILLA = ["minecraft:zombie", "minecraft:husk", "minecraft:skeleton", "minecraft:spider", "minecraft:creeper", "minecraft:wolf", "minecraft:villager", "minecraft:iron_golem"];
    function suggestions(kind) {
        var out = [], seen = {};
        function add(id, label) { if (!id || seen[id]) return; seen[id] = 1; out.push({ id: id, label: label || id }); }
        if (kind === "entity") {
            add(D.DEFAULT_ENTITY, "DMZ fighter");
            RPG.mobs.list().forEach(function (m) { if (m.indexOf("dmzq_") === 0 && !/_v[1-9][0-9]*$/.test(m)) add("dragonminez:" + m.substring(5).replace(/_v0$/, ""), strip(RPG.mobs.name(m))); });
            if (typeof RG_NPC_MODELS !== "undefined") RG_NPC_MODELS.forEach(function (r) { add("rgnpc#" + r[0], r[5]); });
            RPG.mobs.list().forEach(function (m) { if (m.indexOf("dmzq_") !== 0 && m.indexOf("dbr_raid_rg_") !== 0 && m.indexOf("dbr_npcr_rg_") !== 0) add(m, strip(RPG.mobs.name(m))); });
            try { RPG.server.registryIds("living").forEach(function (id) { add(id); }); } catch (e) { VANILLA.forEach(function (v) { add(v); }); }
        } else if (kind === "rgmodel") {
            if (typeof RG_NPC_MODELS !== "undefined") RG_NPC_MODELS.forEach(function (r) { add(r[0], r[5]); });
        } else if (kind === "item") {
            RPG.items.list().forEach(function (i) { add(i, strip(RPG.items.name(i))); });
            try { RPG.items.list("", 20000, 0).forEach(function (o) { if (o.id !== "minecraft:air") add(o.id, strip(o.name)); }); } catch (e) { }
            try { RPG.server.registryIds("item").forEach(function (id) { if (id !== "minecraft:air") add(id); }); } catch (e) { }
        } else if (kind === "dimension") {
            try { RPG.server.dimensions().forEach(function (d) { add(d); }); } catch (e) { }
        }
        return out;
    }
    RPG.net.on("dbr_npcr", function (p, d) {
        d = d || {};
        var op = String(d.op || "");
        if (op === "hello") return;
        if (!can(p)) { ack(p, op, false, "You don't have permission (" + PERM + ")."); return; }
        if (op === "open") return sendAll(p, d.select);
        if (op === "suggest") { RPG.net.send(p, "dbr_npcr_suggestions", { kind: String(d.kind || ""), list: suggestions(String(d.kind || "")) }); return; }
        if (op === "save") {
            var box = INBOX[p.uuid];
            if (!box || box.id !== d.id) box = INBOX[p.uuid] = { id: d.id, n: Number(d.n) || 1, got: 0, s: [] };
            if (box.s[d.i] === undefined) { box.s[d.i] = String(d.s || ""); box.got++; }
            if (box.got < box.n) return;
            delete INBOX[p.uuid];
            var obj = null;
            try { obj = JSON.parse(box.s.join("")); } catch (e) { return ack(p, "save", false, "Save failed: bad data"); }
            if (!obj || !obj.region) return ack(p, "save", false, "Save failed: no region");
            var r = D.region(obj.region);
            if (!strip(r.name).trim()) return ack(p, "save", false, "Give the region a name first.");
            if (!r.shapes.length) return ack(p, "save", false, "Draw and close at least one shape on the map first.");
            var old = obj.oldId ? String(obj.oldId) : "";
            if (old !== r.id && REG[r.id]) return ack(p, "save", false, "A region with the id '" + r.id + "' already exists.");
            if (old && old !== r.id && REG[old]) remove(old);
            put(r);
            if (r.npcs.some(function (c) { var m = c.rgModelId || (c.entityTypeId.indexOf("rgnpc#") === 0 ? c.entityTypeId.substring(6) : ""); return m && !RG_BODIES[m] && !RPG.mobs.exists("dbr_raid_rg_" + m.replace(/[^a-z0-9_]/g, "_")); }))
                p.tell("§e[NpcRegion] A ragnarok NPC model new to NPC regions spawns as a stand-in until /rpg reload.");
            ack(p, "save", true, "Saved region " + r.id + " (" + D.regionArea(r) + " blocks², " + r.npcs.length + " NPC" + (r.npcs.length === 1 ? "" : "s") + ")", { id: r.id });
            return sendAll(p, r.id);
        }
        if (op === "delete") {
            var id = String(d.id || "");
            var ok = remove(id);
            ack(p, "delete", ok, ok ? "Deleted region " + id : "No region " + id, { id: id });
            return sendAll(p);
        }
        if (op === "import") {
            var ids = importFiles();
            ack(p, "import", ids.length > 0, ids.length ? "Imported " + ids.length + " region(s): " + ids.join(", ") : "Nothing to import: put DMZ Ragnarok's npcregions.json content in ragnarok_rpg/config/dbr_npcregion_import.json ({\"regions\": [...]}) or a data/npcregions.json");
            return sendAll(p);
        }
        if (op === "tp") {
            var tr = REG[String(d.id || "")];
            if (!tr) return ack(p, "tp", false, "No such region");
            var at = D.interior(tr), y = RPG.world.surfaceY(tr.dim, Math.floor(at.x), Math.floor(at.z));
            if (y === -9999) y = Math.max(tr.minY, Math.min(tr.maxY, 120));
            p.teleportTo(tr.dim, at.x + 0.5, y, at.z + 0.5);
            return ack(p, "tp", true, "Teleported to " + tr.id);
        }
        if (op === "held") {
            var st = p.getHeldStack();
            if (!st || !st.id || st.id === "minecraft:air") return ack(p, "held", false, "Hold the item to copy first.");
            RPG.net.send(p, "dbr_npcr_held", { itemId: st.id, count: st.count || 1, nbt: st.nbt || "" });
            return;
        }
        if (op === "clear") {
            var cid = String(d.id || "");
            despawnRegion(cid);
            return ack(p, "clear", true, "Removed the live NPCs of " + cid);
        }
    });

    // =========================================================================================
    //  Commands
    // =========================================================================================
    function command(p, args) {
        function tell(m) { if (p) p.tell(m); else RPG.log(strip(m)); }
        var sub = String(args[0] || "edit").toLowerCase();
        if (!can(p)) return tell("§cYou don't have permission (" + PERM + ").");
        if (sub === "edit" || sub === "editor" || sub === "gui") { if (p) RPG.net.send(p, "dbr_npcr_open", {}); return; }
        if (sub === "list") {
            var ks = Object.keys(REG).sort(), c = counts();
            if (!ks.length) return tell("§7No NPC regions. Draw one with /npcregion edit.");
            tell("§6NPC regions (" + ks.length + "):");
            ks.forEach(function (k) { var r = REG[k]; tell("§f" + k + " §7" + r.dim + " " + D.regionArea(r) + " blocks², " + r.npcs.length + " NPC(s), " + (c[k] || 0) + " alive" + (r.enabled ? "" : " §c[off]") + (r.eventOnly ? " §d[event only]" : "")); });
            return;
        }
        if (sub === "delete" || sub === "remove") { var r = find(args[1]); if (!r) return tell("§cNo region '" + (args[1] || "") + "'."); remove(r.id); return tell("§aDeleted " + r.id + "."); }
        if (sub === "tp") {
            var t = find(args[1]); if (!t || !p) return tell("§cNo region '" + (args[1] || "") + "'.");
            var at = D.interior(t), y = RPG.world.surfaceY(t.dim, Math.floor(at.x), Math.floor(at.z));
            p.teleportTo(t.dim, at.x + 0.5, y === -9999 ? 100 : y, at.z + 0.5);
            return;
        }
        if (sub === "import") { var ids = importFiles(); return tell(ids.length ? "§aImported " + ids.join(", ") : "§cNothing to import (ragnarok_rpg/config/dbr_npcregion_import.json or data/npcregions.json)."); }
        if (sub === "clear") { var cr = find(args[1]); if (!cr) return tell("§cNo region '" + (args[1] || "") + "'."); despawnRegion(cr.id); return tell("§aRemoved the live NPCs of " + cr.id + "."); }
        if (sub === "reload") { load(); return tell("§aReloaded " + Object.keys(REG).length + " region(s)."); }
        tell("§e/npcregion edit | list | tp <id> | delete <id> | clear <id> | import | reload");
    }
    RPG.commands.register("npcregion", { root: true, aliases: ["npcregions"], description: "NPC regions: /npcregion edit", run: command,
        suggest: function (p, words) {
            if (words.length <= 1) return ["edit", "list", "tp", "delete", "clear", "import", "reload"];
            return ["tp", "delete", "remove", "clear"].indexOf(String(words[0]).toLowerCase()) >= 0 ? Object.keys(REG).sort() : [];
        } });

    return { regions: function () { return REG; }, get: function (id) { return REG[id] || null; }, find: find, put: put, remove: remove, live: live, regionAt: regionAt,
        mobs: function () { return MOBS; }, importJson: importJson, resolveBody: resolveBody, pickSpot: pickSpot, falloff: falloff, killMult: killMult, can: can };
})();
