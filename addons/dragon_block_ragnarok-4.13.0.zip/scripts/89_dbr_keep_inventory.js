// =====================================================================================
//  89_dbr_keep_inventory.js - DMZ Ragnarok's partial keep inventory and death graves
// =====================================================================================
//  Port of DMZ Ragnarok's (GPL-3.0) KeepPartialInventory / GraveEventHandler / GraveManager /
//  GraveData / GraveStorage / GraveAccess, its Curios and Cosmetic Armor grave compat, the
//  dragon ball totems (DragonBallTotem) and the /rggrave command, on the engine's "deathDrops"
//  event:
//    - characters below level `fullKeepBelowLevel` (100) keep everything: items and experience;
//    - from that level on they keep the hotbar, armour, off hand, accessories and cosmetic armour,
//      and the main inventory (slots 9-35) and all their experience go into a grave where they died:
//      a small stone headstone with their name floating above it (DMZ Ragnarok's is an oak fence
//      with their head on top; graves made that way in older worlds turn into headstones when their
//      chunk is loaded or someone touches them). A grave holding nothing but dragon balls is shown
//      as those balls lying on the ground (a totem the radar leads to). Right-click it to
//      open its 27 slots (anyone can; inside claimed land only its owner, staff, or anyone when it
//      holds a dragon ball); the first opening pays out the experience; an emptied grave goes away,
//      breaking it drops everything, and after `graveMinutes` (10) it despawns with what's left;
//    - dragon balls are never kept: they come off the player (out of a Dragon Ball-Sack too) into the
//      grave, or into a totem of their own when there is no grave, also with keepInventory on or partial
//      keep off. A grave holding a ball never despawns.
//  With the vanilla keepInventory rule on, everything but the dragon balls is kept as vanilla does.
//  Settings: ragnarok_rpg/config/dbr_keep_inventory.json, /rpg config dbr_keep_inventory, or the
//  Server rows of the DMZ config menu (ops). DMZ Ragnarok's KeepPartialInventory gamerule is
//  `enabled` (it is per world there: `disabledDimensions` turns it off in single dimensions).
// =====================================================================================
var DBR_KEEPINV_CFG = RPG.config.define("dbr_keep_inventory", {
    enabled:            { default: true, client: true, comment: "Partial keep inventory and death graves (DMZ Ragnarok's KeepPartialInventory gamerule, default on). Off: normal death drops. Vanilla keepInventory on: everything is kept as vanilla does" },
    fullKeepBelowLevel: { default: 100, min: 0, max: 1000000000, integer: true, client: true, comment: "Characters below this level keep their whole inventory and experience; from it on the main inventory and experience go to a grave" },
    graveMinutes:       { default: 10, min: 1, max: 1440, integer: true, client: true, comment: "Minutes before a grave despawns, with whatever is left in it (graves holding a dragon ball never do)" },
    keepAccessories:    { default: true, client: true, comment: "Accessory slots are always kept while this is on (DMZ Ragnarok keeps every Curios slot). Off: each slot's own keepOnDeath decides" },
    keepCosmeticArmor:  { default: true, client: true, comment: "Cosmetic armour is always kept while this is on (DMZ Ragnarok never drops Cosmetic Armor slots). Off: the cosmetic armour keepOnDeath setting decides" },
    disabledDimensions: { default: [], comment: "Dimensions where partial keep is off and deaths drop normally (DMZ Ragnarok's gamerule is per world), e.g. [\"ragnarok_rpg:otherworld\"]" }
});

var DBR_GRAVES = (function () {
    var C = DBR_KEEPINV_CFG;
    var PREFIX = "dbr_grave/";                 // one RPG.data key per grave (GraveStorage)
    var PENDING_KEY = "dbr_grave_markers";     // name markers still to remove once their chunk loads
    var MARKER_TAG = "dbr_grave_marker";
    var SIZE = 27, UP_SCAN = 6, SWEEP_TICKS = 100, STAFF = 2;
    var DISP_TAG = "dbr_grave_disp";          // the block displays showing a ball totem's balls
    // the headstone (front made facing north, turned to face where the player was looking from) and the ball totem's
    // own block: nothing drawn, its balls are block displays lying on it
    RPG.blocks.define("dbr_grave", { name: "&7Grave", model: "dbr:rpg/block/dbr_grave", decor: true, hardness: 2, rotation: "horizontal",
        drops: "none", sound: "stone", shape: [[2, 0, 3, 14, 2, 13], [3, 2, 8, 13, 15, 11]] });
    RPG.blocks.define("dbr_grave_ball", { name: "&6Dragon Ball Totem", model: "dbr:rpg/block/dbr_grave_ball", decor: true, hardness: 2,
        drops: "none", light: 4, sound: typeof DB_BALL_SOUND !== "undefined" ? DB_BALL_SOUND : "amethyst", shape: [3, 0, 3, 13, 9, 13] });
    function graveId() { return RPG.blocks.id("dbr_grave"); }
    function ballTotemId() { return RPG.blocks.id("dbr_grave_ball"); }
    function bare(b) { b = String(b || ""); var i = b.indexOf("["); return i < 0 ? b : b.substring(0, i); }
    var IDX = {};                              // "dim|x|y|z" of the grave block -> data key
    var VIEW = {};                             // data key -> { uuid, handle } (one viewer at a time)
    var OPENED = {};                           // player uuid -> server tick of their last grave click (both hands fire)

    // ---- storage ------------------------------------------------------------------------------
    function posKey(dim, x, y, z) { return dim + "|" + x + "|" + y + "|" + z; }
    function dataKey(dim, x, y, z) { return PREFIX + dim + "/" + x + "/" + y + "/" + z; }
    function rec(key) { var r = RPG.data.get(key, null); return r && typeof r === "object" ? r : null; }
    function save(key, r) { RPG.data.set(key, r); }
    function at(dim, x, y, z) { return IDX[posKey(dim, x, y, z)] || null; }
    // the fence or the head one above it (GraveEventHandler.onRightClick)
    function graveAt(dim, x, y, z) { return at(dim, x, y, z) || at(dim, x, y - 1, z); }
    function index() {
        IDX = {};
        RPG.data.keys(PREFIX).forEach(function (k) {
            var r = rec(k);
            if (r) IDX[posKey(r.dim, r.x, r.y, r.z)] = k; else RPG.data.remove(k);
        });
    }
    index();
    function all() { return Object.keys(IDX).map(function (pk) { return IDX[pk]; }); }

    // stacks are kept as {slot, id, count, nbt} so they come back exactly (name colours, enchantments...)
    function pack(stack, slot) {
        if (!stack || !stack.id || stack.id === "minecraft:air") return null;
        var o = { slot: slot, id: String(stack.id), count: stack.count || 1 };
        if (stack.nbt) o.nbt = String(stack.nbt);
        return o;
    }
    function unpack(o) { var s = { id: o.id, count: o.count || 1 }; if (o.nbt) s.nbt = o.nbt; return s; }
    function itemsArray(r) {
        var out = [];
        for (var i = 0; i < SIZE; i++) out.push(null);
        (r.items || []).forEach(function (o) { if (o && o.slot >= 0 && o.slot < SIZE) out[o.slot] = unpack(o); });
        return out;
    }
    function fromScreen(items) {
        var out = [];
        for (var i = 0; i < SIZE && i < items.length; i++) { var o = pack(items[i], i); if (o) out.push(o); }
        return out;
    }
    function isEmpty(r) { return !(r.items && r.items.length) && (r.xpReleased || !(r.xp > 0)); }

    // ---- dragon balls (DragonBallSets.isDragonBall / DragonBallTotem) ----------------------------
    var BALLS = null;
    function ballIds() {
        if (BALLS) return BALLS;
        BALLS = {};
        if (typeof DB_SETS === "undefined") return BALLS;
        Object.keys(DB_SETS).forEach(function (setId) {
            var set = DB_SETS[setId];
            for (var n = 1; n <= set.stars; n++) {
                [set.block(n), set.block(n) + "_stone"].forEach(function (name) { try { var id = RPG.blocks.id(name); if (id) BALLS[id] = setId + " " + n; } catch (e) { } });
            }
        });
        return BALLS;
    }
    function ballOf(id) { return ballIds()[String(id)] || null; }
    function holdsBall(r) { return (r.items || []).some(function (o) { return o && !!ballOf(o.id); }); }
    function onlyBalls(r) { var it = r.items || []; return it.length > 0 && it.every(function (o) { return o && !!ballOf(o.id); }); }

    // ---- the grave in the world (GraveManager) ----------------------------------------------------
    function placeable(dim, x, y, z) { return RPG.world.isReplaceable(dim, x, y, z); }
    function free(dim, x, y, z) { return placeable(dim, x, y, z) && placeable(dim, x, y + 1, z) && !at(dim, x, y, z) && !at(dim, x, y + 1, z) && !at(dim, x, y - 1, z); }
    // findPlacement: the first free spot at or up to 6 above where they died, kept inside the world (a death in the
    // void lands 3 above its floor), else the top of that column. Unlike DMZ Ragnarok the head's spot must be free too,
    // so a grave never replaces a block (a chest, with its items) above the spot.
    function findPlacement(dim, x, y, z) {
        var hr = RPG.world.heightRange(dim) || { min: -64, max: 319 };
        var minY = hr.min, maxY = hr.max - 1;
        var startY = y < minY ? minY + 3 : Math.min(y, maxY);
        for (var i = 0; i <= UP_SCAN; i++) {
            var yy = startY + i;
            if (yy > maxY) break;
            if (free(dim, x, yy, z)) return yy;
        }
        var top = RPG.world.surfaceY(dim, x, z);
        var fy = Math.min(Math.max(top === -9999 ? startY : top, minY + 1), maxY);
        while (fy < maxY && !free(dim, x, fy, z)) fy++;
        return fy;
    }
    function uuidInts(u) {
        var h = String(u || "").replace(/-/g, "");
        if (h.length !== 32) return null;
        var out = [];
        for (var i = 0; i < 4; i++) out.push(parseInt(h.substr(i * 8, 8), 16) | 0);
        return out;
    }
    // ---- the look: a headstone, or the balls themselves for a grave holding nothing else -----------------
    // the headstone's front faces back the way the player was looking, as if they had set it down (rotation "horizontal")
    function facingOf(p) {
        var yaw = ((Number(p && p.yaw) || 0) % 360 + 360) % 360;
        return yaw < 45 || yaw >= 315 ? "north" : yaw < 135 ? "east" : yaw < 225 ? "south" : "west";
    }
    // how wide each set's ball model is (blocks): several balls lie in a ring, each shrunk to about four pixels
    var BALL_W = { earth: 0.5, blackstar: 0.5, cerulean: 0.25, namek: 0.625, demon: 0.625, super: 1.8 };
    function lookSig(r) {
        if (!onlyBalls(r)) return "stone";
        return "ball:" + (r.items || []).map(function (o) { return o.id; }).join(",");
    }
    function oldStyle(r) {
        return RPG.world.getBlock(r.dim, r.x, r.y, r.z) === "minecraft:oak_fence" && RPG.world.getBlock(r.dim, r.x, r.y + 1, r.z) === "minecraft:player_head";
    }
    function standing(r) {
        var b = bare(RPG.world.getBlock(r.dim, r.x, r.y, r.z));
        return b === graveId() || b === ballTotemId() || oldStyle(r);
    }
    function forget(dim, x, z, uuid) {
        if (!uuid || RPG.world.removeEntity(uuid) !== null) return;
        var list = RPG.data.get(PENDING_KEY, []) || [];
        list.push({ dim: dim, x: x, y: 0, z: z, uuid: uuid, tries: 0 });
        RPG.data.set(PENDING_KEY, list);
    }
    function clearDisplays(r) {
        (r.displays || []).forEach(function (u) { forget(r.dim, r.x, r.z, u); });
        r.displays = [];
        // strays (a crash between spawning and saving): any of ours lying on this block
        try {
            RPG.world.entityIdsNear(r.dim, r.x + 0.5, r.y + 0.3, r.z + 0.5, 1.2, "minecraft:block_display", DISP_TAG).forEach(function (u) {
                RPG.world.removeEntity(u);
            });
        } catch (e) { }
    }
    function spawnDisplays(r) {
        var balls = (r.items || []).filter(function (o) { return o && ballOf(o.id); });
        var n = balls.length;
        balls.forEach(function (o, i) {
            var set = ballOf(o.id).split(" ")[0];
            var sc = n === 1 ? 1 : Math.min(1, 0.27 / (BALL_W[set] || 0.5));
            var a = (i / n) * Math.PI * 2 - Math.PI / 2, rad = n === 1 ? 0 : 0.3;
            var h = (-sc / 2).toFixed(4), f = sc.toFixed(4);
            var u = RPG.world.spawnEntity(r.dim, "minecraft:block_display", r.x + 0.5 + Math.cos(a) * rad, r.y, r.z + 0.5 + Math.sin(a) * rad,
                "{block_state:{Name:\"" + String(o.id) + "\"},Tags:[\"" + DISP_TAG + "\"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]," +
                "translation:[" + h + "f,0f," + h + "f],scale:[" + f + "f," + f + "f," + f + "f]}}");
            if (u) r.displays.push(u);
        });
    }
    // put the right blocks and displays in place (a new grave, contents changed, an old fence-and-head grave)
    function applyLook(key, r) {
        var sig = lookSig(r);
        // never load a chunk for this: an unloaded grave gets its new look when it is loaded again (sweep below)
        if (!RPG.world.isLoaded(r.dim, r.x, r.z)) { r.lookDirty = true; save(key, r); return; }
        delete r.lookDirty;
        var ball = sig !== "stone";
        var want = ball ? ballTotemId() : graveId() + "[facing=" + (r.facing || "north") + "]";
        var cur = RPG.world.getBlock(r.dim, r.x, r.y, r.z);
        if (bare(cur) !== bare(want) || (!ball && cur.indexOf("[") > 0 && cur !== want)) RPG.world.setBlock(r.dim, r.x, r.y, r.z, want);
        if (RPG.world.getBlock(r.dim, r.x, r.y + 1, r.z) === "minecraft:player_head") RPG.world.setBlock(r.dim, r.x, r.y + 1, r.z, "minecraft:air");
        if (r.lookSig !== sig || !r.style) {
            clearDisplays(r);
            if (ball) spawnDisplays(r);
        }
        r.style = 2;
        r.lookSig = sig;
        save(key, r);
    }
    function spawnMarker(dim, x, y, z, name) {
        var e = RPG.world.spawn(dim, "minecraft:armor_stand", x + 0.5, y + 1.1, z + 0.5);
        if (!e) return null;
        e.mergeNbt("{Marker:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b,Silent:1b,NoBasePlate:1b}");
        e.setCustomName(name);
        e.setNameVisible(true);
        e.addTag(MARKER_TAG);
        return e.uuid;
    }
    function clearBlocks(dim, x, y, z) {
        if (RPG.world.getBlock(dim, x, y + 1, z) === "minecraft:player_head") RPG.world.setBlock(dim, x, y + 1, z, "minecraft:air");
        var b = bare(RPG.world.getBlock(dim, x, y, z));
        if (b === "minecraft:oak_fence" || b === graveId() || b === ballTotemId()) RPG.world.setBlock(dim, x, y, z, "minecraft:air");
    }
    function removeMarker(r) {
        if (!r.marker) return;
        if (RPG.world.removeEntity(r.marker) !== null) return;
        // its chunk (or its entities) isn't loaded yet: try again once it is (GraveManager.drainPending)
        var list = RPG.data.get(PENDING_KEY, []) || [];
        list.push({ dim: r.dim, x: r.x, y: r.y, z: r.z, uuid: r.marker, tries: 0 });
        RPG.data.set(PENDING_KEY, list);
        RPG.world.requestChunks(r.dim, r.x, r.z, 0);
    }

    // createGrave: headstone (or the balls) + floating name + the stored items and experience
    function create(p, dim, x, y, z, stacks, xp) {
        var gy = findPlacement(dim, x, y, z);
        var key = dataKey(dim, x, gy, z);
        var r = { dim: dim, x: x, y: gy, z: z, owner: p.uuid, ownerName: p.name, xp: Math.max(0, xp | 0), xpReleased: false,
            created: RPG.world.gameTime(dim), marker: null, items: [], facing: facingOf(p), style: 2, displays: [] };
        var overflow = [];
        stacks.forEach(function (s) {
            if (!s) return;
            if (r.items.length >= SIZE) { overflow.push(s); return; }     // 27 main slots plus dragon balls can be more
            var o = pack(s, r.items.length);
            if (o) r.items.push(o);
        });
        IDX[posKey(dim, x, gy, z)] = key;
        r.lookSig = null;
        applyLook(key, r);
        try { r.marker = spawnMarker(dim, x, gy, z, p.name); } catch (e) { r.marker = null; }
        save(key, r);
        // DMZ Ragnarok drops what doesn't fit on the ground, where it would despawn: a second grave keeps it instead
        if (overflow.length) create(p, dim, x, gy, z, overflow, 0);
        return r;
    }

    // removeGrave: blocks, name and record gone; what's left in it is not dropped (emptied, broken already, or expired)
    function remove(key) {
        var v = VIEW[key];
        delete VIEW[key];
        if (v && v.handle && v.handle.isOpen()) v.handle.close();      // its onClose saves the screen into the record first
        var r = rec(key);
        if (!r) { RPG.data.remove(key); return; }
        delete IDX[posKey(r.dim, r.x, r.y, r.z)];
        RPG.data.remove(key);
        clearBlocks(r.dim, r.x, r.y, r.z);
        clearDisplays(r);
        removeMarker(r);
    }

    // ---- opening (GraveManager.open, GraveAccess, GraveOpenPath) -----------------------------------
    function isStaff(p) { try { return p.isOp(); } catch (e) { return false; } }
    // land the player may not use (the Land Claims and Guilds addons): only the owner, staff, or anyone at a ball grave
    function protectedFor(p, dim, x, z) {
        try { if (typeof LandClaims !== "undefined" && LandClaims && !LandClaims.allowed(p, dim, x, z)) return true; } catch (e) { }
        try { if (typeof Guilds !== "undefined" && Guilds && !Guilds.canAffect(p, dim, x, z, "container")) return true; } catch (e) { }
        return false;
    }
    function mayOpen(p, r) {
        if (!protectedFor(p, r.dim, r.x, r.z)) return true;
        return p.uuid === r.owner || holdsBall(r) || isStaff(p);
    }
    function expired(r) {
        return !holdsBall(r) && RPG.world.gameTime(r.dim) - (r.created || 0) >= C.get("graveMinutes") * 1200;
    }
    function open(p, key) {
        var r = rec(key);
        if (!r) return;
        if (expired(r) && !VIEW[key]) { remove(key); return; }
        var v = VIEW[key];
        if (v && v.handle && v.handle.isOpen() && v.uuid !== p.uuid) { p.actionbar("&7Someone is already looking through this grave."); return; }
        if (v && v.handle && v.handle.isOpen()) return;
        if (!r.xpReleased && r.xp > 0) {
            RPG.world.dropXp(r.dim, r.x + 0.5, r.y + 0.5, r.z + 0.5, r.xp);
            r.xp = 0; r.xpReleased = true;
            save(key, r);
            if (isEmpty(r)) { remove(key); return; }       // the experience was all it held
        }
        var mine = { uuid: p.uuid, handle: null };
        VIEW[key] = mine;
        var handle = RPG.ui.container(p, {
            title: r.ownerName + "'s Grave", rows: 3, items: itemsArray(r), allowConfined: true,
            // saved on every change (an open GUI writes straight into the grave in DMZ Ragnarok too)
            onChange: function (pl, items) {
                var now = rec(key);
                if (!now) return;
                now.items = fromScreen(items);
                save(key, now);
                if (isEmpty(now)) RPG.schedule(1, function () { var again = rec(key); if (again && isEmpty(again) && VIEW[key] === mine) remove(key); });
                else if (lookSig(now) !== now.lookSig) applyLook(key, now);
            },
            onClose: function (pl, items) {
                if (VIEW[key] === mine) delete VIEW[key];
                var now = rec(key), left = fromScreen(items || []);
                if (now) {
                    now.items = left;
                    save(key, now);
                    if (isEmpty(now)) remove(key);
                    else if (lookSig(now) !== now.lookSig) applyLook(key, now);
                } else if (left.length) {
                    // the grave went away while this was open: whatever is still on the screen goes to the player
                    left.forEach(function (o) { pl.giveStack(unpack(o)); });
                }
            }
        });
        if (handle) mine.handle = handle; else delete VIEW[key];
    }

    // breakGrave: everything in it drops, the experience too, then it's gone
    function breakGrave(key) {
        var r = rec(key);
        if (!r) return;
        var v = VIEW[key];
        if (v && v.handle && v.handle.isOpen()) { delete VIEW[key]; v.handle.close(); r = rec(key); if (!r) return; }
        (r.items || []).forEach(function (o) { RPG.world.dropItem(r.dim, r.x + 0.5, r.y + 1, r.z + 0.5, unpack(o)); });
        r.items = [];
        save(key, r);
        if (!r.xpReleased && r.xp > 0) RPG.world.dropXp(r.dim, r.x + 0.5, r.y + 0.5, r.z + 0.5, r.xp);
        remove(key);
    }

    // ---- death (GraveEventHandler.onDeath / snapshotPartial / snapshotFull) -------------------------
    function enabledFor(dim) {
        if (!C.get("enabled")) return false;
        var off = C.get("disabledDimensions") || [];
        for (var i = 0; i < off.length; i++) if (String(off[i]) === String(dim)) return false;
        return true;
    }
    function fusedOnTheWayOut(p) {
        // fusionTeardownOnTheWayOut: logging out while fused kills both halves (64_dmz_fusion.js); a grave left
        // behind by someone already gone is the one grave nobody reaches, so that death keeps everything
        try { if (typeof p.isConnected === "function" && p.isConnected()) return false; } catch (e) { return false; }
        var f = p.getVar("dmz_fusion", null);
        return !!(f && typeof f === "object" && f.partner);
    }
    // a ball-only totem (DragonBallTotem.entomb); else on the ground (the old rule), else back to the player
    function entomb(p, dim, x, y, z, balls) {
        if (!balls.length) return;
        try { create(p, dim, x, y, z, balls, 0); return; } catch (e) { RPG.log("[dbr graves] ball totem failed: " + e); }
        balls.forEach(function (b) { try { RPG.world.dropItem(dim, p.x, p.y, p.z, b); } catch (e) { p.giveStack(b); } });
    }

    // a Dragon Ball-Sack (57_dragon_balls_bag.js) gives up its balls: {bag, balls}, or null for anything else
    function sackBalls(st) {
        if (!st || typeof DBR_BAG === "undefined" || !DBR_BAG.isBag(st)) return null;
        var r = DBR_BAG.takeBalls(st);
        return r.balls.length ? r : null;
    }
    RPG.on("deathDrops", function (p, drops) {
        var dim = drops.dimension;
        var x = Math.floor(drops.x), y = Math.floor(drops.y), z = Math.floor(drops.z);
        if (typeof DBR_BAG !== "undefined") DBR_BAG.closeFor(p);      // its screen writes into the sack: shut it first

        // the balls come off first: they are never kept, and they go into the grave (or a totem of their own), out of
        // a sack too (the emptied sack stays where it was); with partial keep off they still go into a totem
        var balls = [];
        for (var i = 0; i <= 40; i++) {
            var st = drops.get(i), sb;
            if (st && ballOf(st.id)) { var b = drops.take(i); if (b) balls.push(b); }
            else if ((sb = sackBalls(st))) { drops.put(i, sb.bag); balls = balls.concat(sb.balls); }
        }
        if (typeof DBR_BAG !== "undefined") {
            var worn = drops.get("accessory:" + DBR_BAG.slot), wb = sackBalls(worn);
            if (wb) { drops.put("accessory:" + DBR_BAG.slot, wb.bag); balls = balls.concat(wb.balls); }
        }
        if (!enabledFor(dim)) { entomb(p, dim, x, y, z, balls); return; }
        // accessories and cosmetic armour stay in both tiers (CuriosGraveCompat / CosArmorGraveCompat)
        if (C.get("keepAccessories")) drops.accessorySlots().forEach(function (s) { drops.keep("accessory:" + s); });
        if (C.get("keepCosmeticArmor")) ["head", "chest", "legs", "feet"].forEach(function (s) { drops.keep("cosmetic:" + s); });

        var partial = p.getLevel() >= C.get("fullKeepBelowLevel");
        if (partial && fusedOnTheWayOut(p)) {
            RPG.log("[dbr graves] " + p.name + " died while disconnecting and still fused: keeping their whole inventory instead of a grave they have already left behind");
            partial = false;
        }
        if (!partial) {
            // full keep: everything and the experience come back on the respawn; no loot grave, so the balls get a totem
            drops.keepAll();
            entomb(p, dim, x, y, z, balls);
            return;
        }
        // partial: hotbar 0-8, armour 36-39 and the off hand 40 are kept; the main inventory and all the experience go in a grave
        for (var k = 0; k <= 8; k++) drops.keep(k);
        for (var a = 36; a <= 40; a++) drops.keep(a);
        var items = [];
        for (var m = 9; m <= 35; m++) { var t = drops.take(m); if (t) items.push(t); }
        items = items.concat(balls);
        var xp = drops.takeXp();
        try {
            create(p, dim, x, y, z, items, xp);
        } catch (e) {
            // grave placement must never cost the items: keep everything on the player instead (the engine puts back
            // what this handler took when it fails, and the slots are kept)
            RPG.log("[dbr graves] could not place " + p.name + "'s grave at " + dim + " " + x + " " + y + " " + z + ", keeping their items: " + e);
            drops.keepAll();
            throw e;
        }
    });

    // ---- the world around graves ---------------------------------------------------------------------
    RPG.on("blockInteract", function (p, block, x, y, z, dim) {
        var key = graveAt(dim, x, y, z);
        if (!key) return;
        var tick = RPG.server.getTick();
        if (OPENED[p.uuid] === tick) return false;       // the off-hand click right after the main hand's
        OPENED[p.uuid] = tick;
        var r = rec(key);
        if (!r || p.getGameMode() === "spectator") return false;
        if (!r.style && oldStyle(r)) applyLook(key, r);   // an old fence-and-head grave becomes a headstone when touched
        else if (onlyBalls(r) && RPG.world.entityIdsNear(r.dim, r.x + 0.5, r.y + 0.3, r.z + 0.5, 1.2, "minecraft:block_display", DISP_TAG).length < (r.displays || []).length) {
            r.lookSig = null;                              // its balls were removed (/kill): put them back while someone is here
            applyLook(key, r);
        }
        if (!mayOpen(p, r)) return;                       // the land's protection answers
        open(p, key);
        return false;                                      // don't let vanilla place or use anything on the grave
    });
    // a grave block broken for real (not stopped by protection) drops everything: checked once the break is done
    RPG.on("blockBreak", function (p, block, x, y, z, dim) {
        var key = graveAt(dim, x, y, z);
        if (!key) return;
        RPG.schedule(1, function () {
            var r = rec(key);
            if (!r) return;
            if (standing(r)) return;
            breakGrave(key);
        });
    });
    // explosions and ki blasts leave graves standing (their items live behind those two blocks)
    RPG.on("explode", function (ev) {
        var dim = ev.dimension, any = false;
        for (var pk in IDX) if (pk.indexOf(dim + "|") === 0) { any = true; break; }
        if (!any) return;
        ev.keepBlocks(function (x, y, z) { return !!graveAt(dim, x, y, z); });
    });

    // ---- despawn sweep and late marker removal ----------------------------------------------------------
    RPG.every(SWEEP_TICKS, function () {
        all().forEach(function (key) {
            var r = rec(key);
            if (!r) { index(); return; }
            if (VIEW[key] && VIEW[key].handle && VIEW[key].handle.isOpen()) return;     // not out from under a viewer
            if (expired(r)) { remove(key); return; }
            // older worlds' fence-and-head graves become headstones (or ball totems) once their chunk is loaded
            if (r.lookDirty && r.style && RPG.world.isLoaded(r.dim, r.x, r.z)) applyLook(key, r);
            if (!r.style && RPG.world.isLoaded(r.dim, r.x, r.z)) {
                if (oldStyle(r)) applyLook(key, r);
                else if (standing(r)) { r.style = 2; save(key, r); }
            }
        });
        var list = RPG.data.get(PENDING_KEY, []) || [];
        if (!list.length) return;
        var left = [];
        list.forEach(function (m) {
            if (RPG.world.removeEntity(m.uuid) !== null) return;
            if (++m.tries < 12) { RPG.world.requestChunks(m.dim, m.x, m.z, 0); left.push(m); }
        });
        RPG.data.set(PENDING_KEY, left.length ? left : null);
    });
    RPG.on("playerLeave", function (p) { delete OPENED[p.uuid]; logoutTotem(p); });

    // DMZ Ragnarok's DragonBallTotem on logout (extract + entomb): a player never logs out holding a dragon ball; every
    // ball in the inventory goes into a ball-only totem where they stand (copied out before its slot is cleared).
    // On by default like DMZ Ragnarok's; graves holding a ball never despawn (sweep above).
    // DragonBallTotem.extract: every ball off the player, out of their sacks too (copied out before a slot is cleared)
    function extractBalls(p) {
        if (typeof DBR_BAG !== "undefined") DBR_BAG.closeFor(p);
        var balls = [];
        for (var i = 0; i <= 40; i++) {
            var st = null, sb;
            try { st = p.getStack(i); } catch (e) { continue; }
            if (!st) continue;
            if (ballOf(st.id)) { balls.push(st); p.setStack(i, null); }
            else if ((sb = sackBalls(st))) { balls = balls.concat(sb.balls); p.setStack(i, sb.bag); }
        }
        if (typeof DBR_BAG !== "undefined") {
            var wb = sackBalls(p.getAccessory(DBR_BAG.slot));
            if (wb) { balls = balls.concat(wb.balls); p.setAccessory(DBR_BAG.slot, wb.bag); }
        }
        return balls;
    }
    function logoutTotem(p) {
        if (!p.getVar("dmz_created", 0)) return;
        var balls = extractBalls(p);
        if (!balls.length) return;
        entomb(p, p.dimension, Math.floor(p.x), Math.floor(p.y), Math.floor(p.z), balls);
        RPG.log("[dbr graves] " + p.name + " logged out with " + balls.length + " dragon ball stack(s): put in a totem");
    }
    // DragonBallInventoryHandler.onDeath (the fallback): a death nothing above handled (the keepInventory rule on) still
    // never keeps a ball: they go into a ball-only totem where the player died
    RPG.on("death", function (p) {
        var balls = extractBalls(p);
        if (!balls.length) return;
        entomb(p, p.dimension, Math.floor(p.x), Math.floor(p.y), Math.floor(p.z), balls);
        RPG.log("[dbr graves] " + p.name + " died keeping their inventory with " + balls.length + " dragon ball stack(s): put in a totem");
    });
    // GraveAccess: anyone may open a grave holding a ball, inside claimed land too (the claims addons ask this first)
    RPG_CLAIM_HOOKS.exempt.push(function (p, b, x, y, z, dim, action) {
        if (action !== "interact") return false;
        var key = graveAt(dim, x, y, z), r = key && rec(key);
        return !!(r && holdsBall(r));
    });
    // RadarTotems: every grave holding a ball shows on that set's radar (dormant sets show nothing, like their balls)
    if (typeof DBR_RADAR_EXTRA !== "undefined") DBR_RADAR_EXTRA.push(function (out) {
        all().forEach(function (k) {
            var r = rec(k);
            if (!r) return;
            var seen = {};
            (r.items || []).forEach(function (o) {
                var b = o && ballOf(o.id), setId = b ? b.split(" ")[0] : null;
                if (!setId || seen[setId] || !out.sets[setId]) return;
                if (typeof dbrBallsDormant === "function" && dbrBallsDormant(setId)) return;
                seen[setId] = 1;
                out.sets[setId].push({ x: r.x, z: r.z, d: r.dim });
            });
        });
    });

    // ---- /rggrave (CommandGrave) and the lifetime setting (/rg npc totem time) -----------------------------
    function ageText(r) {
        var t = RPG.world.gameTime(r.dim) - (r.created || 0);
        if (!(t >= 0)) return "unknown";
        var s = Math.floor(t / 20), h = Math.floor(s / 3600), mi = Math.floor((s % 3600) / 60);
        return (h ? h + "h " : "") + (h || mi ? mi + "m " : "") + (s % 60) + "s";
    }
    function describeBalls(r) {
        var parts = [];
        (r.items || []).forEach(function (o) { var b = o && ballOf(o.id); if (b) parts.push(b.replace(" ", " star ")); });
        return parts.length ? parts.join(", ") : null;
    }
    function say(p, msg) { if (p) p.tell(msg); else RPG.log(msg.replace(/&./g, "")); }
    function cleanNames(p) {
        var live = {}, removed = 0;
        all().forEach(function (k) { var r = rec(k); if (r && r.marker) live[r.marker] = true; });
        var seen = {};
        RPG.server.players().forEach(function (pl) {
            RPG.world.entitiesNear(pl.dimension, pl.x, pl.y, pl.z, 256, "minecraft:armor_stand").forEach(function (e) {
                if (seen[e.uuid] || !e.hasTag(MARKER_TAG) || live[e.uuid]) return;
                seen[e.uuid] = true;
                var fy = Math.round(e.y - 1.4), fx = Math.floor(e.x), fz = Math.floor(e.z);
                if (at(e.dimension, fx, fy, fz) || at(e.dimension, fx, fy - 1, fz) || at(e.dimension, fx, fy + 1, fz)) return;
                if (RPG.world.removeEntity(e.uuid) !== null) removed++;
            });
        });
        say(p, "&aRemoved " + removed + " stale death name" + (removed === 1 ? "" : "s") + ".");
    }
    function listBalls(p, allDims, page) {
        var here = p ? p.dimension : "minecraft:overworld", rows = [];
        all().forEach(function (k) {
            var r = rec(k);
            if (!r || (!allDims && r.dim !== here)) return;
            var balls = describeBalls(r);
            if (balls) rows.push(r.dim + " &b[" + r.x + ", " + r.y + ", " + r.z + "]&6  " + balls + "&8  owner: " + (r.ownerName || "unknown") + "  age: " + ageText(r));
        });
        if (!rows.length) return say(p, allDims ? "&eNo ball-holding grave totems in any loaded dimension." : "&eNo ball-holding grave totems in this dimension.");
        var pages = Math.ceil(rows.length / 8);
        page = Math.min(Math.max(1, page || 1), pages);
        say(p, "&eBall-holding grave totems" + (allDims ? " (all loaded dimensions)" : " (this dimension)") + ": " + rows.length + " total, page " + page + "/" + pages);
        rows.slice((page - 1) * 8, page * 8).forEach(function (line) { say(p, "&7" + line); });
        say(p, "&7Remove one with /rggrave removeball <dimension> <x> <y> <z>");
    }
    function removeBall(p, args, confirmed) {
        var dim = String(args[1] || ""), x = parseInt(args[2], 10), y = parseInt(args[3], 10), z = parseInt(args[4], 10);
        if (!dim || isNaN(x) || isNaN(y) || isNaN(z)) return say(p, "&cUsage: /rggrave removeball <dimension> <x> <y> <z> [confirm]");
        if (dim.indexOf(":") < 0) dim = "minecraft:" + dim;
        var key = at(dim, x, y, z), r = key && rec(key);
        if (!r) return say(p, "&cNo grave totem at " + dim + " " + x + ", " + y + ", " + z + ".");
        var balls = describeBalls(r);
        if (!balls) return say(p, "&cThe grave at " + dim + " " + x + ", " + y + ", " + z + " holds no dragon ball; removeball only targets ball-holding totems.");
        var desc = dim + " " + x + ", " + y + ", " + z + " holding " + balls + " (owner: " + (r.ownerName || "unknown") + ")";
        if (!confirmed) {
            say(p, "&6About to remove grave totem: " + desc + ".");
            return say(p, "&eRun &c/rggrave removeball " + dim + " " + x + " " + y + " " + z + " confirm&e to confirm. This cannot be undone.");
        }
        remove(key);
        RPG.log("[audit] " + (p ? p.name : "console") + " removed dragon ball grave totem at " + dim + " " + x + ", " + y + ", " + z + " holding " + balls + " (owner: " + (r.ownerName || "unknown") + ")");
        say(p, "&aRemoved grave totem: " + desc + ".");
    }
    function totemTime(p, arg) {
        if (arg === undefined || arg === "") return say(p, "&eGrave totems currently despawn after " + C.get("graveMinutes") + " minute(s).");
        var n = parseInt(arg, 10);
        if (isNaN(n) || n < 1 || n > 1440) return say(p, "&cMinutes must be 1 to 1440.");
        C.set("graveMinutes", n);
        say(p, "&aGrave totems will now despawn after " + C.get("graveMinutes") + " minute(s).");
    }
    RPG.commands.register("rggrave", { root: true, aliases: ["sugrave"], permission: STAFF,
        description: "Death graves: /rggrave cleannames | listballs [all] [page] | removeball <dim> <x> <y> <z> [confirm] | time [minutes]",
        run: function (p, args) {
            var sub = String(args[0] || "cleannames");
            if (sub === "cleannames") return cleanNames(p);
            if (sub === "listballs") return args[1] === "all" ? listBalls(p, true, parseInt(args[2], 10)) : listBalls(p, false, parseInt(args[1], 10));
            if (sub === "removeball") return removeBall(p, args, args[5] === "confirm");
            if (sub === "time") return totemTime(p, args[1]);
            say(p, "&e/rggrave cleannames | listballs [all] [page] | removeball <dimension> <x> <y> <z> [confirm] | time [minutes]");
        },
        suggest: function (p, args) {
            if (args.length <= 1) return ["cleannames", "listballs", "removeball", "time"];
            if (args[0] === "listballs" && args.length === 2) return ["all"];
            if (args[0] === "removeball" && args.length === 2) return RPG.server.dimensions();
            if (args[0] === "removeball" && args.length === 6) return ["confirm"];
            return [];
        } });

    // the DMZ config menu's Server rows (client/scripts/54_dmz_config_menu.js): ops change these settings live
    var MENU_KEYS = { enabled: 1, fullKeepBelowLevel: 1, graveMinutes: 1, keepAccessories: 1, keepCosmeticArmor: 1 };
    RPG.net.on("dbr_keepinv_set", function (p, d) {
        if (!p || !isStaff(p) || !d || !MENU_KEYS[d.key]) return;
        C.set(String(d.key), d.value);
    });

    // for the ball rules (57_dragon_balls_rules.js): every ball lying in a grave, and taking one out
    function ballCopies() {
        var out = [];
        all().forEach(function (k) {
            var r = rec(k);
            if (!r) return;
            (r.items || []).forEach(function (o) {
                var b = o && ballOf(o.id), parts = b ? b.split(" ") : null;
                if (b) out.push({ key: k, slot: o.slot, id: o.id, ball: { set: parts[0], star: Number(parts[1]) }, dim: r.dim, x: r.x, y: r.y, z: r.z, owner: r.ownerName, open: !!(VIEW[k] && VIEW[k].handle && VIEW[k].handle.isOpen()) });
            });
        });
        return out;
    }
    function takeBall(key, slot) {
        var r = rec(key);
        if (!r || (VIEW[key] && VIEW[key].handle && VIEW[key].handle.isOpen())) return false;
        var before = (r.items || []).length;
        r.items = (r.items || []).filter(function (o) { return !(o && o.slot === slot && ballOf(o.id)); });
        if (r.items.length === before) return false;
        save(key, r);
        if (isEmpty(r)) remove(key); else applyLook(key, r);
        return true;
    }
    return { at: graveAt, open: open, remove: remove, config: C, ballCopies: ballCopies, takeBall: takeBall };
})();
