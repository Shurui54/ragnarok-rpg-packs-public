// =====================================================================================
//  19f_cosmetic_patterns.js - the cosmetics (19c_cosmetics.js) sewn the DragonMine Z way
// =====================================================================================
//  One Accessory Pattern per cosmetic (19d_outfit_patterns_data.js): Pattern Station dye grid -> pattern,
//  Kikono Station: pattern + leather cap (head / face pieces) or leather tunic (body pieces) + Kikono cloth
//  and string. See 19e_outfit_patterns.js.
// =====================================================================================

var COSMETIC_PATTERN_PIECES = outfitPatternsDefine("cosmetic");
