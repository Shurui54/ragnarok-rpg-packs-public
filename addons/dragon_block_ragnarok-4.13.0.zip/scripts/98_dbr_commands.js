// =====================================================================================
//  98_dbr_commands.js - DragonMine Z's commands (server/commands/*Command.java) under /rpgc
// =====================================================================================
//  Every DMZ command is here with DMZ's arguments, permission nodes ("dbr." + DMZ's node without "dmz",
//  07_dbr_commands_lib.js), tab completion and messages, named without "dmz":
//    /dmzstats -> /rpgc stats        /dmzpoints -> points    /dmzskill -> skill      /dmztech -> tech
//    /dmzcooldowns -> cooldowns      /dmzform -> form        /dmzmastery -> mastery  /dmzbonus -> bonus
//    /dmzeffect -> effect            /dmzalignment -> alignment                     /dmzclass -> class
//    /dmztail -> tail                /dmzhalo -> halo        /dmzhair -> hair        /dmzrevive -> revive
//    /dmzracial -> racial            /dmzweight -> weight    /dmzconfig -> config    /dmzreload -> reload
//    /dmzdebug -> debug              /dmzquest -> quest      /dmzlocate -> locate    /dmzstructure -> structure
//    /dmzrestoreupdate -> restoreupdate                      /dmztrigger -> trigger
//  The others live with their systems: dragonballs (57), party (78), worldboss (77), minigame (67),
//  tournament (95), siteraid (92_dmz_raids, DMZ's /dmzraid). Old DBR forms (/rpgc dmzform, dmztech, dmzskill,
//  dmzquest...) keep working, hidden from suggestions.
// =====================================================================================
(function () {
    var C = DBR_CMD, SD = DMZ_SKILLS_DATA;
    var STATS = DMZ_DATA.STATS, IDS = DMZ_DATA.STAT_IDS;
    function created(p) { return !!p.getVar("dmz_created", 0); }
    function race(p) { return DMZ_DATA.DMZ[p.race] || p.race || "human"; }
    function cap(p) { return typeof DBR_PRESTIGE !== "undefined" && DBR_PRESTIGE.capFor ? DBR_PRESTIGE.capFor(p) : 1000000; }
    function players(c) { return c.players("targets"); }
    /** DMZ's .success (one target) / .multiple (several) message pair. */
    function report(c, list, one, many) { c.tell(list.length === 1 ? one(list[0].name) : many(list.length)); }
    function word(c, n) { return c.words[n] === undefined ? "" : String(c.words[n]); }

    /** Max health/ki/stamina grew: heal the difference (StatsCommand.modifyStats). */
    function withBars(p, fn) {
        var hp = p.maxHealth, ki = p.maxResource("ki"), st = p.maxResource("stamina");
        fn();
        p.refreshStats();
        RPG.schedule(1, function () {
            try {
                if (p.maxHealth > hp) p.heal(p.maxHealth - hp);
                if (p.maxResource("ki") > ki) p.setResource("ki", Math.min(p.maxResource("ki"), p.resource("ki") + p.maxResource("ki") - ki));
                if (p.maxResource("stamina") > st) p.setResource("stamina", Math.min(p.maxResource("stamina"), p.resource("stamina") + p.maxResource("stamina") - st));
                if (p.health > p.maxHealth) p.health = p.maxHealth;
            } catch (e) { }
        });
    }

    // =================================================================================
    //  /rpgc stats (StatsCommand)
    // =================================================================================
    var STAT_SUG = ["STR", "SKP", "RES", "VIT", "PWR", "ENE", "ALL"], VALUE_SUG = ["100", "500", "1000", "5000", "10000", "min", "max"];
    /** StatsData.getCurrentStatValue: the stat without gear/effect bonuses. */
    function current(p, k) { return Math.floor(p.baseStat(IDS[k])); }
    function setStat(p, k, target) {
        var id = IDS[k], have = current(p, k);
        target = Math.max(0, Math.floor(target));
        // never below what the class gives for free (DMZ's 0): allocated points can't go negative
        var floor = have - p.allocated(id);
        target = Math.max(floor, target);
        if (target > have) target = have + Math.max(0, Math.min(target - have, cap(p) - have));
        if (target !== have) p.addStat(id, target - have);
    }
    function modifyStats(c, mode) {
        var stat = String(c.get("stat")).toUpperCase(), raw = String(c.get("amount"));
        if (STAT_SUG.indexOf(stat) < 0) return c.tell("&e[DBR-Stats]&r Invalid stat '" + c.get("stat") + "'. Use: STR, SKP, RES, VIT, PWR, ENE, or ALL");
        var list = players(c);
        if (!list) return;
        var value = raw.toLowerCase() === "min" ? 0 : raw.toLowerCase() === "max" ? null : Number(raw);
        if (value !== null && (isNaN(value) || Math.floor(value) !== value)) return c.tell("&e[DBR-Stats]&r Invalid number: " + raw);
        list.forEach(function (p) {
            var v = value === null ? cap(p) : value;
            withBars(p, function () {
                (stat === "ALL" ? STATS : [stat]).forEach(function (k) {
                    var have = current(p, k);
                    if (mode === "set") setStat(p, k, v);
                    else if (mode === "add") setStat(p, k, have + Math.max(0, v));
                    else setStat(p, k, have - v);
                });
            });
        });
        if (mode === "set") report(c, list, function (n) { return "&e[DBR-Stats]&r Stat " + stat + " set to " + raw + " for " + n; },
            function (m) { return "&e[DBR-Stats]&r Stat " + stat + " set to " + raw + " for " + m + " players."; });
        else if (mode === "add") report(c, list, function (n) { return "&e[DBR-Stats]&r Added " + raw + " points of " + stat + " to " + n; },
            function (m) { return "&e[DBR-Stats]&r Added " + raw + " points of " + stat + " to " + m + " players."; });
        else report(c, list, function (n) { return "&e[DBR-Stats]&r Removed " + raw + " points of " + stat + " from " + n; },
            function (m) { return "&e[DBR-Stats]&r Removed " + raw + " points of " + stat + " from " + m + " players."; });
    }
    /** StatsData.relocateStats: everything above the class's starting points comes back as points to assign. */
    function relocate(p) {
        var cls = DMZ_DATA.CLASSES[p.playerClass] || DMZ_DATA.CLASSES.warrior, gained = 0;
        withBars(p, function () {
            STATS.forEach(function (k) {
                var id = IDS[k], have = p.allocated(id), base = cls.base[k] || 0;
                if (have > base) { gained += have - base; p.addStat(id, base - have); }
            });
        });
        if (gained > 0) p.setStatPoints(p.statPoints + Math.floor(gained));
        return gained;
    }
    /** StatsData.resetPlayerProgress: back to a new character (the creator opens), keeping a share of stats/TP if asked. */
    function resetProgress(p, keep, keepSkills) {
        var saved = null;
        if (keepSkills) saved = { skills: p.getVar("dmz_skills", null), tech: p.getVar("dmz_tech", null) };
        var stats = {}, tp = p.getTp();
        STATS.forEach(function (k) { stats[k] = current(p, k); });
        try { if (typeof DMZ_FUSION !== "undefined" && DMZ_FUSION.isFused(p)) DMZ_FUSION.endFusion(p, false); } catch (e) { }
        if (typeof DBR_PRESTIGE !== "undefined" && DBR_PRESTIGE.wipe) DBR_PRESTIGE.wipe(p);
        if (keep !== null) {
            STATS.forEach(function (k) { setStat(p, k, Math.floor(stats[k] * keep / 100)); });
            p.setTp(Math.floor(tp * keep / 100));
        }
        if (saved) { p.setVar("dmz_skills", saved.skills); if (saved.tech) p.setVar("dmz_tech", saved.tech); }
        p.setVar("dbr_bonus", null); BONUS_CACHE[String(p.uuid)] = null;
        p.setStatPoints(0);
        p.setVar("dmz_created", 0);
        p.refreshStats();
        try { p.health = 20; } catch (e) { }
        RPG.net.send(p, "dmz_open_creator", {});
    }
    var STATS_TARGETS = function (perm, exec) { return { arg: "targets", type: "players", perm: function (p) { return C.has(p, perm); }, exec: exec }; };
    C.tree("stats", {
        description: "DMZ stats: set|add|remove <stat> <amount> [targets] | relocate [targets] | reset [targets] [keep%] [keepSkills]",
        canUse: function (p) { return C.check(p, "stats.info.self", "stats.info.others"); },
        children: ["set", "add", "remove"].map(function (mode) {
            var self = mode === "set" ? "stats.set" : "stats.add";       // DMZ: remove uses the add nodes
            return { lit: mode, perm: function (p) { return C.check(p, self + ".self", self + ".others"); }, children: [
                { arg: "stat", type: "word", suggest: STAT_SUG, children: [
                    { arg: "amount", type: "word", suggest: VALUE_SUG, exec: function (c) { modifyStats(c, mode); }, children: [
                        STATS_TARGETS(self + ".others", function (c) { modifyStats(c, mode); }) ] } ] } ] };
        }).concat([
            { lit: "relocate", perm: function (p) { return C.check(p, "stats.reset.self", "stats.reset.others"); },
              exec: relocateCmd, children: [STATS_TARGETS("stats.reset.others", relocateCmd)] },
            { lit: "reset", perm: function (p) { return C.check(p, "stats.reset.self", "stats.reset.others"); },
              exec: resetCmd, children: [{ arg: "targets", type: "players", perm: function (p) { return C.has(p, "stats.reset.others"); }, exec: resetCmd, children: [
                  { arg: "keepPercentage", type: "word", suggest: ["10", "25", "50", "75"], exec: resetCmd, children: [
                      { arg: "keepSkills", type: "bool", exec: resetCmd } ] } ] }] }
        ])
    });
    function relocateCmd(c) {
        var list = players(c);
        if (!list) return;
        var ok = 0;
        list.forEach(function (p) { if (relocate(p) > 0) ok++; });
        report(c, list, function (n) { return "&e[DBR-Stats]&r Stats relocated for " + n + ". Reassign the attribute points in the stats menu."; },
            function () { return "&e[DBR-Stats]&r Stats relocated for " + ok + " players."; });
    }
    function resetCmd(c) {
        var list = players(c);
        if (!list) return;
        var keep = null;
        if (c.has("keepPercentage")) {
            keep = Number(c.get("keepPercentage"));
            if (isNaN(keep) || Math.floor(keep) !== keep || keep <= -1 || keep >= 101) return c.tell("&e[DBR-Stats]&r Invalid number: " + c.get("keepPercentage"));
        }
        list.forEach(function (p) { resetProgress(p, keep, !!c.get("keepSkills", false)); });
        report(c, list, function (n) { return "&e[DBR-Stats]&r Stats reset for " + n; }, function (m) { return "&e[DBR-Stats]&r Stats reset for " + m + " players."; });
    }

    // =================================================================================
    //  /rpgc points (PointsCommand): Training Points
    // =================================================================================
    function fmtPoints(v) { return String(Math.floor(v)).replace(/\B(?=(\d{3})+(?!\d))/g, "."); }
    function pointsCmd(mode) {
        return function (c) {
            var raw = String(c.get("amount"));
            if (!/^\d+$/.test(raw) || Number(raw) > 3.4e38) return c.tell("&e[DBR-Points]&r Invalid number: " + raw);
            var list = players(c);
            if (!list) return;
            var n = Number(raw);
            list.forEach(function (p) {
                if (mode === "set") p.setTp(n);
                else if (mode === "add") p.setTp(p.getTp() + n);
                else p.setTp(Math.max(0, p.getTp() - n));
            });
            var f = fmtPoints(n);
            if (mode === "set") report(c, list, function (x) { return "&e[DBR-Points]&r Training Points set to " + f + " for " + x; }, function (m) { return "&e[DBR-Points]&r Training Points set to " + f + " for " + m + " players."; });
            else if (mode === "add") report(c, list, function (x) { return "&e[DBR-Points]&r Added " + f + " Training Points to " + x; }, function (m) { return "&e[DBR-Points]&r Added " + f + " Training Points to " + m + " players."; });
            else report(c, list, function (x) { return "&e[DBR-Points]&r Removed " + f + " Training Points from " + x; }, function (m) { return "&e[DBR-Points]&r Removed " + f + " Training Points from " + m + " players."; });
        };
    }
    C.tree("points", {
        description: "Training Points: set|add|remove <amount> [targets]",
        canUse: function (p) { return C.check(p, "points.info.self", "points.info.others"); },
        children: ["set", "add", "remove"].map(function (mode) {
            return { lit: mode, perm: function (p) { return C.check(p, "points." + mode + ".self", "points." + mode + ".others"); }, children: [
                { arg: "amount", type: "word", exec: pointsCmd(mode), children: [STATS_TARGETS("points." + mode + ".others", pointsCmd(mode))] } ] };
        })
    });

    // =================================================================================
    //  /rpgc skill (SkillsCommand): skills that aren't techniques or forms
    // =================================================================================
    function genericSkills() {
        return Object.keys(SD.COSTS).filter(function (s) { return !SD.isTechnique(s) && !SD.isForm(s) && !SD.isStack(s); }).sort();
    }
    function removeSkill(p, s) {
        var m = DMZ_SKILLS.levels(p);
        if (!Object.prototype.hasOwnProperty.call(m, s)) return;
        delete m[s];
        p.setVar("dmz_skills", m);
        if (s === "potentialunlock") p.setVar("dmz_potential", 0);
        DMZ_SKILLS.sendState(p);
    }
    function skillCmd(mode) {
        return function (c) {
            var name = String(c.get("skill")), s = name.toLowerCase(), lvl = mode === "add" ? 1 : c.get("level");
            var list = players(c);
            if (!list) return;
            var all = s === "all", skills = all ? genericSkills() : [s];
            if (!all && genericSkills().indexOf(s) < 0) return c.tell("&e[DBR-Skills]&r &cUnknown skill: " + name);
            list.forEach(function (p) { skills.forEach(function (k) { if (mode === "remove") removeSkill(p, k); else DMZ_SKILLS.setLevel(p, k, lvl, "command"); }); });
            if (mode === "remove") {
                if (all) report(c, list, function (n) { return "&e[DBR-Skills]&r &aRemoved all " + skills.length + " skills from " + n; }, function (m) { return "&e[DBR-Skills]&r &aRemoved all " + skills.length + " skills from " + m + " players."; });
                else report(c, list, function (n) { return "&e[DBR-Skills]&r &aRemoved skill '" + name + "' from " + n; }, function (m) { return "&e[DBR-Skills]&r &aRemoved skill '" + name + "' from " + m + " players."; });
            } else if (all) report(c, list, function (n) { return "&e[DBR-Skills]&r Set all " + skills.length + " skills to level " + lvl + " for " + n; }, function (m) { return "&e[DBR-Skills]&r Set all " + skills.length + " skills to level " + lvl + " for " + m + " players."; });
            else report(c, list, function (n) { return "&e[DBR-Skills]&r Set skill '" + name + "' to level " + lvl + " for " + n; }, function (m) { return "&e[DBR-Skills]&r Set skill '" + name + "' to level " + lvl + " for " + m + " players."; });
        };
    }
    var SKILL_SUG = function () { return ["all"].concat(genericSkills()); };
    C.tree("skill", {
        description: "DMZ skills: set <skill|all> <level> [targets] | add <skill|all> [targets] | remove <skill|all> [targets]",
        canUse: function (p) { return C.check(p, "skill.list.self", "skill.list.others"); },
        children: [
            { lit: "set", perm: function (p) { return C.check(p, "skill.set.self", "skill.set.others"); }, children: [
                { arg: "skill", type: "word", suggest: SKILL_SUG, children: [
                    { arg: "level", type: "int", min: 0, exec: skillCmd("set"), children: [STATS_TARGETS("skill.set.others", skillCmd("set"))] } ] } ] },
            { lit: "add", perm: function (p) { return C.check(p, "skill.add.self", "skill.add.others"); }, children: [
                { arg: "skill", type: "word", suggest: SKILL_SUG, exec: skillCmd("add"), children: [STATS_TARGETS("skill.add.others", skillCmd("add"))] } ] },
            { lit: "remove", perm: function (p) { return C.check(p, "skill.remove.self", "skill.remove.others"); }, children: [
                { arg: "skill", type: "word", suggest: SKILL_SUG, exec: skillCmd("remove"), children: [STATS_TARGETS("skill.remove.others", skillCmd("remove"))] } ] }
        ]
    });

    // =================================================================================
    //  /rpgc form (FormsCommand): the form skills (superforms, godforms...) and stack skills (kaioken, ultimate)
    // =================================================================================
    function formSkills() { return SD.FORM_SKILLS.concat(SD.STACK_SKILLS); }
    function formCmd(mode) {
        return function (c) {
            var list = players(c);
            if (!list) return;
            if (mode === "setall") {
                var lv = c.get("level"), all = formSkills();
                list.forEach(function (p) { all.forEach(function (k) { DMZ_SKILLS.setLevel(p, k, lv, "command"); }); if (typeof DMZ_TF !== "undefined") DMZ_TF.refresh(p); });
                return report(c, list, function (n) { return "&e[DBR-Forms]&r Set all " + all.length + " forms to level " + lv + " for " + n; }, function (m) { return "&e[DBR-Forms]&r Set all " + all.length + " forms to level " + lv + " for " + m + " players."; });
            }
            var name = String(c.get("form")), s = name.toLowerCase(), lvl = mode === "add" ? 1 : c.get("level");
            if (formSkills().indexOf(s) < 0) return c.tell("&e[DBR-Forms]&r &cUnknown form: " + name);
            list.forEach(function (p) { if (mode === "remove") removeSkill(p, s); else DMZ_SKILLS.setLevel(p, s, lvl, "command"); if (typeof DMZ_TF !== "undefined") DMZ_TF.refresh(p); });
            if (mode === "remove") report(c, list, function (n) { return "&e[DBR-Forms]&r &aRemoved form '" + name + "' from " + n; }, function (m) { return "&e[DBR-Forms]&r &aRemoved form '" + name + "' from " + m + " players."; });
            else report(c, list, function (n) { return "&e[DBR-Forms]&r Set form '" + name + "' to level " + lvl + " for " + n; }, function (m) { return "&e[DBR-Forms]&r Set form '" + name + "' to level " + lvl + " for " + m + " players."; });
        };
    }
    C.tree("form", {
        description: "DMZ form skills: set <form|all> <level> [targets] | add <form> [targets] | remove <form> [targets]",
        canUse: function (p) { return C.check(p, "form.list.self", "form.list.others"); },
        children: [
            { lit: "set", perm: function (p) { return C.check(p, "form.set.self", "form.set.others"); }, children: [
                { lit: "all", children: [{ arg: "level", type: "int", min: 0, exec: formCmd("setall"), children: [STATS_TARGETS("form.set.others", formCmd("setall"))] }] },
                { arg: "form", type: "word", suggest: formSkills, children: [
                    { arg: "level", type: "int", min: 0, exec: formCmd("set"), children: [STATS_TARGETS("form.set.others", formCmd("set"))] } ] } ] },
            { lit: "add", perm: function (p) { return C.check(p, "form.add.self", "form.add.others"); }, children: [
                { arg: "form", type: "word", suggest: formSkills, exec: formCmd("add"), children: [STATS_TARGETS("form.add.others", formCmd("add"))] } ] },
            { lit: "remove", perm: function (p) { return C.check(p, "form.remove.self", "form.remove.others"); }, children: [
                { arg: "form", type: "word", suggest: formSkills, exec: formCmd("remove"), children: [STATS_TARGETS("form.remove.others", formCmd("remove"))] } ] }
        ]
    });

    // =================================================================================
    //  /rpgc tech (TechCommand) and /rpgc cooldowns (CooldownsCommand)
    // =================================================================================
    var TD = DMZ_TECH_DATA;
    function techIds() { return TD.all().filter(function (id) { return id !== TD.REVIVE_ID; }); }
    function techCmd(mode) {
        return function (c) {
            var name = String(c.get("technique")), id = name.toLowerCase(), list = players(c);
            if (!list) return;
            var all = id === "all";
            if (!all && (techIds().indexOf(id) < 0)) return c.tell("&cUnknown Ki technique: " + name);
            var ids = all ? techIds() : [id];
            list.forEach(function (p) {
                ids.forEach(function (x, i) { if (mode === "add") DMZ_TECH.unlock(p, x, { source: "command", silent: all && i > 0 }); else DMZ_TECH.forget(p, x); });
                DMZ_TECH.sendState(p);
            });
            if (mode === "add") {
                if (all) report(c, list, function (n) { return "Added all " + ids.length + " techniques to " + n + "."; }, function (m) { return "Added all " + ids.length + " techniques to " + m + " players."; });
                else report(c, list, function (n) { return "Added Ki technique " + name + " to " + n + "."; }, function (m) { return "Added Ki technique " + name + " to " + m + " players."; });
            } else if (all) report(c, list, function (n) { return "Removed all " + ids.length + " techniques from " + n + "."; }, function (m) { return "Removed all " + ids.length + " techniques from " + m + " players."; });
            else report(c, list, function (n) { return "Removed Ki technique " + name + " from " + n + "."; }, function (m) { return "Removed Ki technique " + name + " from " + m + " players."; });
        };
    }
    function techXp(mode) {
        return function (c) {
            var id = String(c.get("technique")), amt = c.get("amount"), list = players(c);
            if (!list) return;
            var applied = list.filter(function (p) { return DMZ_TECH.experience(p, id, mode, amt); });
            if (!applied.length) return c.fail("Unknown Ki technique: " + id);
            if (applied.length === 1) c.tell("Updated experience of Ki technique " + id + " for " + applied[0].name + ".");
            else c.tell("Updated experience of Ki technique " + id + " for " + applied.length + " players.");
        };
    }
    var TECH_SUG = function () { return ["all"].concat(techIds()); };
    var UNLOCKED_SUG = function (c) { return c.src ? DMZ_TECH.unlocked(c.src) : []; };
    C.tree("tech", {
        description: "Ki techniques: add|remove <technique|all> [targets] | experience add|set|remove <technique> <amount> [targets]",
        legacy: [],
        canUse: function (p) { return C.check(p, "tech.list.self", "tech.list.others"); },
        children: [
            { lit: "add", perm: function (p) { return C.check(p, "tech.add.self", "tech.add.others"); }, children: [
                { arg: "technique", type: "word", suggest: TECH_SUG, exec: techCmd("add"), children: [STATS_TARGETS("tech.add.others", techCmd("add"))] } ] },
            { lit: "remove", perm: function (p) { return C.check(p, "tech.remove.self", "tech.remove.others"); }, children: [
                { arg: "technique", type: "word", suggest: TECH_SUG, exec: techCmd("remove"), children: [STATS_TARGETS("tech.remove.others", techCmd("remove"))] } ] },
            { lit: "experience", perm: function (p) { return C.check(p, "tech.experience.self", "tech.experience.others"); }, children: ["add", "set", "remove"].map(function (m) {
                return { lit: m, children: [{ arg: "technique", type: "word", suggest: UNLOCKED_SUG, children: [
                    { arg: "amount", type: "int", min: 0, exec: techXp(m), children: [STATS_TARGETS("tech.experience.others", techXp(m))] } ] }] };
            }) }
        ]
    });
    function cooldownCmd(c) {
        var slot = c.get("slot"), ticks = c.get("cooldown"), list = players(c);
        if (!list) return;
        var applied = list.filter(function (p) {
            var id = DMZ_TECH.slots(p)[slot - 1];
            if (!id || !DMZ_TECH.has(p, id)) return false;
            DMZ_TECH.setCooldown(p, id, ticks);
            DMZ_TECH.sendState(p);
            return true;
        });
        if (!applied.length) return c.fail("No technique equipped in slot " + slot + ".");
        if (applied.length === 1) c.tell("Set slot " + slot + " technique cooldown to " + ticks + " ticks for " + applied[0].name + ".");
        else c.tell("Set slot " + slot + " technique cooldown to " + ticks + " ticks for " + applied.length + " players.");
    }
    C.tree("cooldowns", {
        description: "Technique cooldowns: <slot 1-8> <ticks> [targets]",
        canUse: function (p) { return C.check(p, "cooldowns.self", "cooldowns.others"); },
        children: [{ arg: "slot", type: "int", min: 1, max: TD.SLOT_COUNT, suggest: ["1", "2", "3", "4", "5", "6", "7", "8"], children: [
            { arg: "cooldown", type: "int", min: 0, suggest: ["0", "20", "100", "200"], exec: cooldownCmd, children: [STATS_TARGETS("cooldowns.others", cooldownCmd)] } ] }]
    });

    // =================================================================================
    //  /rpgc mastery (MasteryCommand)
    // =================================================================================
    var FD = DMZ_FORMS;
    function suggestionRaces(p) { return p && created(p) ? [race(p)] : Object.keys(FD.GROUPS); }
    function groupSug(c) {
        var out = [];
        suggestionRaces(c.src).forEach(function (r) { FD.groups(r).forEach(function (g) { if (out.indexOf(g.id) < 0) out.push(g.id); }); });
        FD.STACKS.forEach(function (g) { if (out.indexOf(g.id) < 0) out.push(g.id); });
        return out;
    }
    function formSug(c) {
        var g = word(c, 1), out = [], sg = FD.stackGroup(g);
        if (sg) return sg.forms.map(function (f) { return f.id; });
        suggestionRaces(c.src).forEach(function (r) { (FD.groups(r) || []).forEach(function (gr) { if (gr.id === g) gr.forms.forEach(function (f) { if (out.indexOf(f.id) < 0) out.push(f.id); }); }); });
        return out;
    }
    function applyMastery(p, f, value, add) {
        var stack = f.race === "stack", key = stack ? "dmz_stack_mastery" : "dmz_mastery", m = p.getVar(key, null);
        if (!m || typeof m !== "object") m = {};
        var max = f.maxMastery > 0 ? f.maxMastery : 100, now = Number(m[f.key]) || 0;
        m[f.key] = Math.max(0, Math.min(max, add ? now + value : value));
        p.setVar(key, m);
    }
    function masteryMsg(add, value, group, form, who, many) {
        return add ? "&e[DBR-Mastery]&r Added " + value + " mastery for the form '" + group + " - " + form + "' to " + who + (many ? " players." : ".")
                   : "&e[DBR-Mastery]&r Set mastery to " + value + " for the form '" + group + " - " + form + "' for " + who + (many ? " players." : ".");
    }
    function masteryOne(add) {
        return function (c) {
            var g = String(c.get("group")), fid = String(c.get("form")), value = c.get("value"), list = players(c);
            if (!list) return;
            list.forEach(function (p) {
                var f = FD.stackForm(g, fid) || FD.form(race(p), g, fid);
                if (f) { applyMastery(p, f, value, add); if (typeof DMZ_TF !== "undefined") DMZ_TF.refresh(p); }
            });
            c.tell(list.length === 1 ? masteryMsg(add, value, g, fid, list[0].name, false) : masteryMsg(add, value, g, fid, list.length, true));
        };
    }
    function masteryCurrent(add, stack) {
        return function (c) {
            var value = c.get("value"), list = players(c);
            if (!list) return;
            list.forEach(function (p) {
                var f = typeof DMZ_TF === "undefined" ? null : stack ? DMZ_TF.activeStack(p) : DMZ_TF.activeForm(p);
                if (!f) return c.tell((stack ? "&c[DBR-Mastery]&r " + p.name + " has no active stack form right now." : "&c[DBR-Mastery]&r " + p.name + " has no active form right now."));
                applyMastery(p, f, value, add);
                DMZ_TF.refresh(p);
                c.tell(masteryMsg(add, value, f.group, f.id, p.name, false));
            });
        };
    }
    function masteryAll(add, forms, stacks) {
        return function (c) {
            var value = c.get("value"), list = players(c);
            if (!list) return;
            list.forEach(function (p) {
                if (forms) FD.groups(race(p)).forEach(function (g) { g.forms.forEach(function (f) { applyMastery(p, f, value, add); }); });
                if (stacks) FD.STACKS.forEach(function (g) { g.forms.forEach(function (f) { applyMastery(p, f, value, add); }); });
                if (typeof DMZ_TF !== "undefined") DMZ_TF.refresh(p);
            });
            var scope = forms && stacks ? "all" : stacks ? "stack" : "form", who = list.length === 1 ? list[0].name : list.length + " players";
            c.tell(add ? "&e[DBR-Mastery]&r Added " + value + " mastery to all '" + scope + "' forms for " + who + "."
                       : "&e[DBR-Mastery]&r Set mastery to " + value + " for all '" + scope + "' forms for " + who + ".");
        };
    }
    function withTargets(node, exec) {
        node.exec = exec;
        node.children = [{ arg: "targets", type: "players", exec: exec }];
        return node;
    }
    C.tree("mastery", {
        description: "Form mastery: set|add current form|stack <value> [targets] | set|add ALL form|stack|all <value> [targets] | set|add <group> <form> <value> [targets]",
        canUse: function (p) { return C.has(p, "mastery.set") || C.has(p, "mastery.add"); },
        children: [["set", false], ["add", true]].map(function (m) {
            return { lit: m[0], perm: function (p) { return C.has(p, m[1] ? "mastery.add" : "mastery.set"); }, children: [
                { lit: "current", children: [
                    { lit: "form", children: [withTargets({ arg: "value", type: "double", suggest: ["10", "50", "100"] }, masteryCurrent(m[1], false))] },
                    { lit: "stack", children: [withTargets({ arg: "value", type: "double", suggest: ["10", "50", "100"] }, masteryCurrent(m[1], true))] } ] },
                { lit: "ALL", children: [
                    { lit: "form", children: [withTargets({ arg: "value", type: "double" }, masteryAll(m[1], true, false))] },
                    { lit: "stack", children: [withTargets({ arg: "value", type: "double" }, masteryAll(m[1], false, true))] },
                    { lit: "all", children: [withTargets({ arg: "value", type: "double" }, masteryAll(m[1], true, true))] } ] },
                { arg: "group", type: "word", suggest: groupSug, children: [
                    { arg: "form", type: "word", suggest: formSug, children: [withTargets({ arg: "value", type: "double", suggest: ["10", "50", "100"] }, masteryOne(m[1]))] } ] }
            ] };
        })
    });

    // =================================================================================
    //  /rpgc bonus (BonusCommand) and the bonus layer (BonusStats): named +, - and * bonuses on top of a stat
    // =================================================================================
    //  Saved per player in "dbr_bonus" { STR: [{ n, o, v, m }], SKP, DEF, STM, VIT, PWR, ENE }. DEF and STM both act on
    //  Resistance here (half each), as DBR has one Resistance stat for DMZ's defence and stamina.
    var BONUS_STATS = ["STR", "SKP", "DEF", "STM", "VIT", "PWR", "ENE"];
    var BONUS_CACHE = {};
    function bonuses(p) {
        var u = String(p.uuid), b = BONUS_CACHE[u];
        if (b === undefined || b === null) {
            b = p.getVar("dbr_bonus", null);
            if (!b || typeof b !== "object") b = {};
            BONUS_CACHE[u] = b;
        }
        return b;
    }
    function saveBonuses(p, b) {
        var any = false;
        for (var k in b) if (b[k] && b[k].length) any = true;
        p.setVar("dbr_bonus", any ? b : null);
        BONUS_CACHE[String(p.uuid)] = any ? b : {};
        p.refreshStats();
    }
    RPG.on("playerLeave", function (p) { delete BONUS_CACHE[String(p.uuid)]; });
    /** BonusStats.calculateBonus over both kinds: (base x product of * bonuses - base) + sum of +/- bonuses. */
    function calc(list, base) {
        var flat = 0, mult = 1;
        (list || []).forEach(function (x) { if (x.o === "+") flat += x.v; else if (x.o === "-") flat -= x.v; else if (x.o === "*") mult *= x.v; });
        return base * mult - base + flat;
    }
    var BY_STAT = { strength: ["STR"], strike: ["SKP"], resistance: ["DEF", "STM"], vitality: ["VIT"], kipower: ["PWR"], energy: ["ENE"] };
    DBR_STAT_BONUS = function (player, statId, value) {
        var keys = BY_STAT[statId];
        if (!keys || !player || !player.getVar) return 0;
        var b = bonuses(player), sum = 0;
        if (!keys.some(function (k) { return b[k] && b[k].length; })) return 0;
        keys.forEach(function (k) { sum += calc(b[k], value); });
        return sum / keys.length;
    };
    function split(stat) { return stat === "RES" ? ["DEF", "STM"] : [stat]; }
    // scripts' own named bonuses (BonusStats.addBonusSplit / removeAllBonuses): 33_dmz_racials.js
    DBR_BONUS = {
        add: function (p, stat, name, op, value) {
            var b = bonuses(p);
            split(String(stat).toUpperCase()).forEach(function (k) {
                b[k] = (b[k] || []).filter(function (x) { return x.n !== name; });
                b[k].push({ n: name, o: op, v: value, m: true });
            });
            saveBonuses(p, b);
        },
        remove: function (p, name) {
            var b = bonuses(p), hit = false;
            BONUS_STATS.forEach(function (k) {
                if (!b[k]) return;
                var n = b[k].length;
                b[k] = b[k].filter(function (x) { return x.n !== name; });
                if (b[k].length !== n) hit = true;
            });
            if (hit) saveBonuses(p, b);
            return hit;
        },
        has: function (p, name) { var b = bonuses(p); return BONUS_STATS.some(function (k) { return (b[k] || []).some(function (x) { return x.n === name; }); }); },
        names: function (p) { var b = bonuses(p), out = []; BONUS_STATS.forEach(function (k) { (b[k] || []).forEach(function (x) { if (out.indexOf(x.n) < 0) out.push(x.n); }); }); return out; }
    };
    function addBonus(c) {
        var stat = String(c.get("stat")).toUpperCase(), op = String(c.get("operation")).replace(/"/g, ""), value = c.get("value"), name = String(c.get("bonusName"));
        if (op.toLowerCase() === "x") op = "*";
        if (BONUS_STATS.indexOf(stat) < 0 && stat !== "ALL" && stat !== "RES") return c.tell("&e[DBR-Bonus]&r Invalid stat! Use: STR, SKP, DEF, STM, VIT, PWR, ENE, or ALL");
        if (op !== "+" && op !== "-" && op !== "*") return c.tell("&e[DBR-Bonus]&r Invalid operation! Use: +, -, or *");
        var list = players(c);
        if (!list) return;
        list.forEach(function (p) {
            var b = bonuses(p);
            (stat === "ALL" ? BONUS_STATS : split(stat)).forEach(function (k) {
                b[k] = (b[k] || []).filter(function (x) { return x.n !== name; });
                b[k].push({ n: name, o: op, v: value, m: !!c.get("applyMultipliers", false) });
            });
            saveBonuses(p, b);
        });
        if (list.length === 1) c.tell("&e[DBR-Bonus]&r Added bonus '" + name + "' to " + stat + " for " + list[0].name);
        else c.tell("&e[DBR-Bonus]&r Added bonus '" + name + "' to " + list.length + " players for " + stat);
    }
    function removeBonus(c) {
        var stat = String(c.get("stat")).toUpperCase(), name = String(c.get("bonusName"));
        if (BONUS_STATS.indexOf(stat) < 0 && stat !== "RES") return c.tell("&e[DBR-Bonus]&r Invalid stat! Use: STR, SKP, DEF, STM, VIT, PWR, ENE, or ALL");
        var list = players(c);
        if (!list) return;
        list.forEach(function (p) {
            var b = bonuses(p);
            split(stat).forEach(function (k) { b[k] = (b[k] || []).filter(function (x) { return x.n !== name; }); });
            saveBonuses(p, b);
        });
        if (list.length === 1) c.tell("&e[DBR-Bonus]&r Removed bonus '" + name + "' from " + stat + " for " + list[0].name);
        else c.tell("&e[DBR-Bonus]&r Removed bonus '" + name + "' from " + list.length + " players for " + stat);
    }
    function clearBonus(c) {
        var stat = String(c.get("stat")).toUpperCase();
        if (BONUS_STATS.indexOf(stat) < 0 && stat !== "ALL" && stat !== "RES") return c.tell("&e[DBR-Bonus]&r Invalid stat! Use: STR, SKP, DEF, STM, VIT, PWR, ENE, or ALL");
        var list = players(c);
        if (!list) return;
        list.forEach(function (p) {
            var b = bonuses(p);
            (stat === "ALL" ? BONUS_STATS : split(stat)).forEach(function (k) { delete b[k]; });
            saveBonuses(p, b);
        });
        if (list.length === 1) c.tell("&e[DBR-Bonus]&r Cleared bonus from " + stat + " for " + list[0].name);
        else c.tell("&e[DBR-Bonus]&r Cleared bonus from " + list.length + " players for " + stat);
    }
    var BONUS_STAT_SUG = ["STR", "SKP", "DEF", "STM", "VIT", "PWR", "ENE", "ALL"];
    C.tree("bonus", {
        description: "Stat bonuses: add <stat> <+|-|*> <value> <name> [applyMultipliers] [targets] | remove <stat> <name> [targets] | clear <stat> [targets]",
        canUse: function (p) { return C.check(p, "bonus.add.self", "bonus.add.others"); },
        children: [
            { lit: "add", perm: function (p) { return C.check(p, "bonus.add.self", "bonus.add.others"); }, children: [
                { arg: "stat", type: "word", suggest: BONUS_STAT_SUG, children: [
                    { arg: "operation", type: "word", suggest: ["+", "-", "x", "*"], children: [
                        { arg: "value", type: "double", children: [
                            { arg: "bonusName", type: "word", exec: addBonus, children: [
                                { arg: "applyMultipliers", type: "bool", exec: addBonus, children: [STATS_TARGETS("bonus.add.others", addBonus)] } ] } ] } ] } ] } ] },
            { lit: "remove", perm: function (p) { return C.check(p, "bonus.clear.self", "bonus.clear.others"); }, children: [
                { arg: "stat", type: "word", suggest: BONUS_STAT_SUG, children: [
                    { arg: "bonusName", type: "word", suggest: function (c) {
                        if (!c.src) return [];
                        var b = bonuses(c.src), out = [];
                        split(word(c, 1).toUpperCase()).forEach(function (k) { (b[k] || []).forEach(function (x) { if (out.indexOf(x.n) < 0) out.push(x.n); }); });
                        return out;
                    }, exec: removeBonus, children: [STATS_TARGETS("bonus.clear.others", removeBonus)] } ] } ] },
            { lit: "clear", perm: function (p) { return C.check(p, "bonus.clear.self", "bonus.clear.others"); }, children: [
                { arg: "stat", type: "word", suggest: BONUS_STAT_SUG, exec: clearBonus, children: [STATS_TARGETS("bonus.clear.others", clearBonus)] } ] }
        ]
    });

    // =================================================================================
    //  /rpgc effect (EffectsCommand): DMZ's own effects (Fruit of Might, Majin mark, Mutant) and the knock-out
    // =================================================================================
    function effectPower(name) {
        var cfg = typeof DMZ_MASTERS_DATA !== "undefined" ? DMZ_MASTERS_DATA.CONFIG : null;
        if (name === "mightfruit") return 1.2;
        if (name === "majin") return Number(cfg && cfg.majinPower) || 1.3;
        if (name === "mutant") return 1.0;
        return 0;
    }
    function giveEffect(c) {
        var name = String(c.get("effect")).toLowerCase(), dur = c.get("duration"), power = effectPower(name), list = players(c);
        if (!list) return;
        if (!power) return c.tell("&e[DBR-Effects]&r Unknown effect: " + c.get("effect"));
        var ticks = dur === -1 ? -1 : dur * 20;
        list.forEach(function (p) {
            if (name === "mutant") p.setVar("dmz_mutant", 1);
            else if (name === "majin") { if (ticks === -1) p.setVar("dmz_majin", 1); p.removeEffect("dmz_majin"); p.addEffect("dmz_majin", ticks); }
            else { p.removeEffect("dmz_mightfruit"); p.addEffect("dmz_mightfruit", ticks); }
        });
        var durText = dur === -1 ? "permanent" : dur + " seconds";
        if (list.length === 1) c.tell("&e[DBR-Effects]&r Given effect '" + name + "' (x" + power + ") to " + list[0].name + " for " + durText);
        else c.tell("&e[DBR-Effects]&r Given effect '" + name + "' (x" + power + ") to " + list.length + " players for " + durText + ".");
    }
    function removeEffect(p, name) {
        if (name === "knockout") { p.removeEffect("knocked_down"); return; }
        if (name === "mutant") p.setVar("dmz_mutant", 0);
        else if (name === "majin") { p.setVar("dmz_majin", 0); p.removeEffect("dmz_majin"); }
        else if (name === "mightfruit") p.removeEffect("dmz_mightfruit");
    }
    function removeEffectCmd(c) {
        var name = String(c.get("effect")).toLowerCase(), list = players(c);
        if (!list) return;
        list.forEach(function (p) { removeEffect(p, name); });
        if (list.length === 1) c.tell("&e[DBR-Effects]&r Removed effect '" + c.get("effect") + "' from " + list[0].name);
        else c.tell("&e[DBR-Effects]&r Removed effect '" + c.get("effect") + "' from " + list.length + " players.");
    }
    function clearEffects(c) {
        var list = players(c);
        if (!list) return;
        list.forEach(function (p) {
            ["mutant", "majin", "mightfruit", "knockout"].forEach(function (n) { removeEffect(p, n); });
            try { if (typeof DMZ_FUSION !== "undefined" && DMZ_FUSION.isFused(p)) DMZ_FUSION.endFusion(p, false); } catch (e) { }
            ["dmz_fusion_cd", "god_ritual_cd", "ki_transfer_boost", "ki_transfer_drain"].forEach(function (e) { p.removeEffect(e); });
        });
        if (list.length === 1) c.tell("&e[DBR-Effects]&r Cleared all effects from " + list[0].name);
        else c.tell("&e[DBR-Effects]&r Cleared all effects from " + list.length + " players.");
    }
    C.tree("effect", {
        description: "DMZ effects: give <mightfruit|majin|mutant> <seconds|-1> [targets] | remove <effect|knockout> [targets] | clear [targets]",
        canUse: function (p) { return C.check(p, "effect.list.self", "effect.list.others"); },
        children: [
            { lit: "give", perm: function (p) { return C.check(p, "effect.give.self", "effect.give.others"); }, children: [
                { arg: "effect", type: "word", suggest: ["mightfruit", "majin", "mutant"], children: [
                    { arg: "duration", type: "int", min: -1, suggest: ["-1", "30", "60", "300"], exec: giveEffect, children: [STATS_TARGETS("effect.give.others", giveEffect)] } ] } ] },
            { lit: "remove", perm: function (p) { return C.check(p, "effect.remove.self", "effect.remove.others"); }, children: [
                { arg: "effect", type: "word", suggest: ["mightfruit", "majin", "mutant", "knockout"], exec: removeEffectCmd, children: [STATS_TARGETS("effect.remove.others", removeEffectCmd)] } ] },
            { lit: "clear", perm: function (p) { return C.check(p, "effect.clear.self", "effect.clear.others"); }, exec: clearEffects, children: [STATS_TARGETS("effect.clear.others", clearEffects)] }
        ]
    });

    // =================================================================================
    //  /rpgc alignment, /rpgc class, /rpgc tail, /rpgc halo, /rpgc hair, /rpgc revive
    // =================================================================================
    function alignOf(p) { var a = Number(p.getVar("dmz_alignment", 100)); return isNaN(a) ? 100 : a; }
    function alignCmd(mode) {
        return function (c) {
            var n = c.get("amount"), list = players(c);
            if (!list) return;
            list.forEach(function (p) {
                var v = mode === "set" ? n : mode === "add" ? alignOf(p) + n : alignOf(p) - n;
                p.setVar("dmz_alignment", Math.max(0, Math.min(100, v)));
            });
            var t = { set: ["Alignment set to " + n + " for ", ""], add: ["Added " + n + " Alignment to ", ""], remove: ["Removed " + n + " Alignment from ", ""] }[mode];
            report(c, list, function (x) { return "&e[DBR-Alignment]&r " + t[0] + x; }, function (m) { return "&e[DBR-Alignment]&r " + t[0] + m + " players."; });
        };
    }
    C.tree("alignment", {
        description: "Alignment (0-100): set <amount> [targets] | add <amount> [targets] | remove <amount> [targets]",
        canUse: function (p) { return C.check(p, "alignment.info.self", "alignment.info.others"); },
        children: [["set", 0, 100], ["add", 1, undefined], ["remove", 1, undefined]].map(function (m) {
            return { lit: m[0], perm: function (p) { return C.check(p, "alignment." + m[0] + ".self", "alignment." + m[0] + ".others"); }, children: [
                { arg: "amount", type: "int", min: m[1], max: m[2], exec: alignCmd(m[0]), children: [STATS_TARGETS("alignment." + m[0] + ".others", alignCmd(m[0]))] } ] };
        })
    });

    function classCmd(c) {
        var raw = String(c.get("class")), cls = raw.toLowerCase(), list = players(c);
        if (!list) return;
        var valid = DMZ_DATA.CLASS_ORDER.indexOf(cls) >= 0;
        function apply(p) {
            var ki = p.resource("ki") / Math.max(1, p.maxResource("ki")), st = p.resource("stamina") / Math.max(1, p.maxResource("stamina")), hp = p.health / Math.max(1, p.maxHealth);
            p.playerClass = cls;
            p.refreshStats();
            RPG.schedule(1, function () { try { p.setResource("ki", p.maxResource("ki") * ki); p.setResource("stamina", p.maxResource("stamina") * st); p.health = Math.max(1, p.maxHealth * hp); } catch (e) { } });
        }
        if (list.length === 1) {
            var p = list[0];
            if (!valid) return c.tell("&e[DBR-Class]&r '" + raw + "' is not a valid class for " + p.name + "'s race.");
            if (String(p.playerClass) === cls) return c.tell("&e[DBR-Class]&r " + p.name + " already has the class " + raw + "&r.");
            apply(p);
            return c.tell(c.src && String(c.src.uuid) === String(p.uuid) ? "&e[DBR-Class]&r Your class is now " + raw + "&r." : "&e[DBR-Class]&r Set " + p.name + "'s class to " + raw + "&r.");
        }
        var ok = 0;
        if (valid) list.forEach(function (p) { if (String(p.playerClass) !== cls) { apply(p); ok++; } });
        c.tell("&e[DBR-Class]&r Set the class to " + raw + "&r for " + ok + " players.");
    }
    C.tree("class", {
        description: "Change class: <class> [targets]",
        canUse: function (p) { return C.check(p, "class.set.self", "class.set.others"); },
        children: [{ arg: "class", type: "word", suggest: function () { return DMZ_DATA.CLASS_ORDER.slice().sort(); }, exec: classCmd, children: [STATS_TARGETS("class.set.others", classCmd)] }]
    });

    function hasTail(p) { return p.race === "saiyan" && String(p.getColor("tail") || "1") !== "0"; }
    function tailCmd(grow) {
        return function (c) {
            var list = players(c), action = grow ? "grow" : "cut";
            if (!list) return;
            function apply(p) {
                p.setColor("tail", grow ? "1" : "0");
                if (typeof DMZ_RACIAL_EXT !== "undefined" && DMZ_RACIAL_EXT.syncTail) DMZ_RACIAL_EXT.syncTail(p);
                if (!grow) sfx(p, "katana_slash", 1, 1);
            }
            if (list.length === 1) {
                var p = list[0];
                if (p.race !== "saiyan") return c.tell("&e[DBR-Tail]&r " + p.name + "'s race can't have a tail.");
                if (hasTail(p) === grow) return c.tell(grow ? "&e[DBR-Tail]&r " + p.name + " already has a tail." : "&e[DBR-Tail]&r " + p.name + " doesn't have a tail to cut.");
                apply(p);
                var me = c.src && String(c.src.uuid) === String(p.uuid);
                return c.tell(me ? (grow ? "&e[DBR-Tail]&r Your tail grew back!" : "&e[DBR-Tail]&r You cut off your tail!") : (grow ? "&e[DBR-Tail]&r Grew back " + p.name + "'s tail." : "&e[DBR-Tail]&r Cut off " + p.name + "'s tail."));
            }
            var ok = 0;
            list.forEach(function (p) { if (p.race === "saiyan" && hasTail(p) !== grow) { apply(p); ok++; } });
            c.tell(grow ? "&e[DBR-Tail]&r Grew back the tail of " + ok + " players." : "&e[DBR-Tail]&r Cut off the tail of " + ok + " players.");
        };
    }
    C.tree("tail", {
        description: "Saiyan tail: cut [targets] | grow [targets]",
        canUse: function (p) { return C.check(p, "tail.self", "tail.others"); },
        children: [
            { lit: "cut", exec: tailCmd(false), children: [STATS_TARGETS("tail.others", tailCmd(false))] },
            { lit: "grow", exec: tailCmd(true), children: [STATS_TARGETS("tail.others", tailCmd(true))] }
        ]
    });

    function haloCmd(on) {
        return function (c) {
            var list = players(c);
            if (!list) return;
            list.forEach(function (p) { p.setVar("dmz_force_halo", on ? true : null); });
            report(c, list, function (n) { return "&e[DBR-Halo]&r Halo " + (on ? "enabled" : "disabled") + " for " + n; },
                function (m) { return "&e[DBR-Halo]&r Halo " + (on ? "enabled" : "disabled") + " for " + m + " players."; });
        };
    }
    C.tree("halo", {
        description: "Show or hide a halo: on|off [targets]",
        canUse: function (p) { return C.check(p, "halo.self", "halo.others"); },
        children: [
            { lit: "on", exec: haloCmd(true), children: [STATS_TARGETS("halo.others", haloCmd(true))] },
            { lit: "off", exec: haloCmd(false), children: [STATS_TARGETS("halo.others", haloCmd(false))] }
        ]
    });

    function hairPresets(p) { var looks = DMZ_DATA.LOOKS[race(p)] || {}; return looks.hair || []; }
    function hairCmd(mode) {
        return function (c) {
            var list = players(c);
            if (!list) return;
            list.forEach(function (p) {
                if (mode === "reset") {
                    var d = DBR_RACE_DEFAULTS[p.race] || {};
                    if (d.hairStyle !== undefined) p.setColor("hairStyle", String(d.hairStyle));
                    if (d.hair !== undefined) p.setColor("hair", String(d.hair));
                } else {
                    var hs = p.getColor("hairStyle"), hc = p.getColor("hair");       // send the look again
                    p.setColor("hairStyle", hs === null || hs === undefined ? null : String(hs));
                    p.setColor("hair", hc === null || hc === undefined ? null : String(hc));
                }
            });
            c.tell(mode === "reset" ? "&e[DBR-Hair]&r Reset hair to race default for " + list.length + " player(s)." : "&e[DBR-Hair]&r Re-synced hair for " + list.length + " player(s).");
        };
    }
    function hairPreset(c) {
        var p = c.src;
        if (!p) return c.fail("A player is required to run this command here");
        var presets = hairPresets(p);
        if (!presets.length) return c.fail("Your race has no hair.");
        var id = String(parseInt(c.get("preset"), 10));
        if (presets.indexOf(id) < 0) return c.fail("No hair preset " + c.get("preset"));
        p.setColor("hairStyle", id);
        c.tell("&aHair: " + DMZ_HAIR.presetName(Number(id)));
    }
    C.tree("hair", {
        description: "Hair: resync [targets] | reset [targets] | <preset> (a DMZ hair preset, /rpgc hair lists them)",
        canUse: function (p) { return C.check(p, "hair.self", "hair.others"); },
        exec: function (c) {
            var p = c.src;
            if (!p) return;
            var presets = hairPresets(p);
            if (!presets.length) return c.fail("Your race has no hair.");
            c.tell("&6Hair presets: &7(/rpgc hair <id>)");
            presets.forEach(function (id) { c.tell("&7" + id + ": &f" + DMZ_HAIR.presetName(Number(id))); });
        },
        children: [
            { lit: "resync", exec: hairCmd("resync"), children: [STATS_TARGETS("hair.others", hairCmd("resync"))] },
            { lit: "reset", exec: hairCmd("reset"), children: [STATS_TARGETS("hair.others", hairCmd("reset"))] },
            { arg: "preset", type: "int", suggest: function (c) { return c.src ? hairPresets(c.src) : []; }, exec: hairPreset }
        ]
    });

    function reviveCmd(c) {
        var list = players(c);
        if (!list) return;
        list.forEach(function (p) { if (typeof dmzRevive === "function") dmzRevive(p, false); });
        if (list.length === 1) {
            var p = list[0];
            if (c.src && String(c.src.uuid) === String(p.uuid)) c.tell("&e[DBR-Revive]&r You have been revived!");
            else { c.tell("&e[DBR-Revive]&r " + p.name + " has been revived!"); p.tell("You have been revived! Talk to King Yemma to go back to the Overworld."); }
        } else c.tell("&e[DBR-Revive]&r " + list.length + " players have been revived!");
    }
    C.tree("revive", {
        description: "Revive yourself or players: [targets]",
        canUse: function (p) { return C.check(p, "revive.self", "revive.others"); },
        exec: reviveCmd,
        children: [STATS_TARGETS("revive.others", reviveCmd)]
    });

    // =================================================================================
    //  /rpgc racial (RacialSkillCommand): reset racial traits; reply to an assimilation request
    // =================================================================================
    function racialReset(p) {
        ["dmz_absorptions", "dmz_assimilations"].forEach(function (k) { p.setVar(k, []); });
        if (typeof DMZ_TF !== "undefined" && DMZ_TF.RACIAL && DMZ_TF.RACIAL.syncBonus) DMZ_TF.RACIAL.syncBonus(p);
        if (typeof DMZ_RACIALS !== "undefined") DMZ_RACIALS.reset(p);          // Zenkai bonuses and release, Cell Jrs and their slots
        ["absorb", "assim", "drain", "zenkai"].forEach(function (k) { p.setVar("dmz_cd_" + k, 0); });
        p.refreshStats();
    }
    function racialResetCmd(c) {
        var list = players(c);
        if (!list) return;
        list.forEach(racialReset);
        report(c, list, function (n) { return "&e[DBR-Racial]&r &aReset racial traits for " + n; }, function (m) { return "&e[DBR-Racial]&r &aReset racial traits for " + m + " players."; });
    }
    C.tree("racial", {
        description: "Racial skills: reset [targets] | reply <accept|reject>",
        children: [
            { lit: "reset", perm: function (p) { return C.check(p, "racial.reset.self", "racial.reset.others"); }, exec: racialResetCmd, children: [STATS_TARGETS("racial.reset.others", racialResetCmd)] },
            { lit: "reply", children: [{ arg: "answer", type: "word", suggest: ["accept", "reject"], exec: function (c) {
                // CaptureRequest.reply: answers a pending request (var dmz_capture_request {from, name, until}); nothing if none
                var p = c.src;
                if (!p) return;
                var req = p.getVar("dmz_capture_request", null);
                p.setVar("dmz_capture_request", null);
                if (!req || typeof req !== "object") return;
                if (Date.now() > Number(req.until)) return p.actionbar("&cThe assimilation request expired.");
                var from = RPG.server.player(String(req.name || ""));
                if (!from) return;
                if (String(c.get("answer")).toLowerCase() !== "accept") return from.actionbar("&c" + p.name + " rejected your assimilation request.");
                if (typeof dbrAcceptCapture === "function") dbrAcceptCapture(from, p);
            } }] }
        ]
    });

    // =================================================================================
    //  /rpgc weight (WeightCommand): a training weight item for yourself
    // =================================================================================
    function giveWeight(item) {
        return function (c) {
            var p = c.src, kg = c.get("weight");
            if (!p) return c.tell("&e[DBR-Weight]&r This command can only be run by a player.");
            p.giveStack({ id: item, count: 1, data: { WeightValue: kg }, lore: ["&7Weight: &f" + kg + " kg"] });
            c.tell("&e[DBR-Weight]&r Gave a Weight item with weight " + kg + " to " + p.name);
        };
    }
    C.tree("weight", {
        description: "Training weights: [turtle_shell|workout_weights|piccolo_cape] <weight>",
        canUse: function (p) { return C.has(p, "weight.give"); },
        children: [
            { lit: "turtle_shell", children: [{ arg: "weight", type: "int", min: 1, exec: giveWeight("weight_turtle_shell") }] },
            { lit: "workout_weights", children: [{ arg: "weight", type: "int", min: 1, exec: giveWeight("workout_weights") }] },
            { lit: "piccolo_cape", children: [{ arg: "weight", type: "int", min: 1, exec: giveWeight("weight_piccolo_cape") }] },
            { arg: "weight", type: "int", min: 1, exec: giveWeight("workout_weights") }
        ]
    });

    // =================================================================================
    //  /rpgc config (ConfigCommand) and /rpgc reload (ReloadCommand): DBR's settings files (ragnarok_rpg/config)
    // =================================================================================
    function sections(file) {
        var out = [];
        RPG.config.keys(file).forEach(function (k) { var d = k.indexOf("."); if (d > 0 && out.indexOf(k.substring(0, d)) < 0) out.push(k.substring(0, d)); });
        return out;
    }
    function isSection(file, s) { return sections(file).indexOf(s) >= 0; }
    function configCmd(c) {
        var file = String(c.get("configFile")), first = String(c.get("keyOrSubtype")), rest = String(c.get("rest")).trim(), key = first, value = rest;
        var sp = rest.indexOf(" ");
        if (sp > 0 && isSection(file, first)) { key = first + "." + rest.substring(0, sp).trim(); value = rest.substring(sp + 1).trim(); }
        if (!RPG.config.exists(file) || RPG.config.keys(file).indexOf(key) < 0) return c.fail("&e[DBR-Config]&r Could not find configuration key or invalid value.");
        var v = value;
        if (/^-?\d+(\.\d+)?$/.test(value)) v = Number(value);
        else if (value === "true" || value === "false") v = value === "true";
        else if (/^[\[{]/.test(value)) { try { v = JSON.parse(value); } catch (e) { v = value; } }
        try {
            if (RPG.config.set(file, key, v)) c.tell("&e[DBR-Config]&r Successfully updated " + key + " to " + value);
            else c.fail("&e[DBR-Config]&r Could not find configuration key or invalid value.");
        } catch (e) { c.fail("&e[DBR-Config]&r Error updating config: " + e); }
    }
    C.tree("config", {
        description: "Change a setting: <configFile> <key | section key> <value>",
        canUse: function (p) { return C.has(p, "admin"); },
        children: [{ arg: "configFile", type: "word", suggest: function () { return RPG.config.list().sort(); }, children: [
            { arg: "keyOrSubtype", type: "word", suggest: function (c) {
                var f = word(c, 0);
                return sections(f).concat(RPG.config.keys(f).filter(function (k) { return k.indexOf(".") < 0; }));
            }, children: [
                { arg: "rest", type: "greedy", exec: configCmd, suggest: function (c) {
                    var f = word(c, 0), first = word(c, 1), restWords = c.words.slice(2);
                    if (isSection(f, first)) {
                        if (restWords.length <= 1) return RPG.config.keys(f).filter(function (k) { return k.indexOf(first + ".") === 0; }).map(function (k) { return k.substring(first.length + 1); });
                        return RPG.config.choices(f, first + "." + restWords[0]);
                    }
                    return RPG.config.choices(f, first);
                } } ] } ] }]
    });

    function reloadCmd(c) {
        var scope = String(c.get("target", "all")).toLowerCase();
        if (["all", "config", "story", "wishes"].indexOf(scope) < 0) return c.fail("Invalid reload section: " + c.get("target"));
        c.tell("&e[DBR-Reload]&r Starting Reload...");
        try {
            if (scope === "all" || scope === "config") RPG.config.list().forEach(function (n) { RPG.config.reload(n); });
            if (scope === "all" || scope === "story") { if (typeof DBR_SAGA_EDITOR !== "undefined") DBR_SAGA_EDITOR.reload(); }
            var n = 0;
            RPG.server.players().forEach(function (p) {
                try {
                    if ((scope === "all" || scope === "config") && created(p)) { DMZ_SKILLS.ensureDefaults(p); DMZ_SKILLS.sendState(p); }
                    if ((scope === "all" || scope === "story") && typeof DMZ_QUESTS !== "undefined") DMZ_QUESTS.sync(p);
                    n++;
                } catch (e) { RPG.log("[DBR] Failed to resync " + p.name + " after /rpgc reload: " + e); }
            });
            c.tell("&e[DBR-Reload]&r Reload completed successfully!");
            c.tell("&e[DBR-Reload]&r " + n + " players had their data synchronized.");
        } catch (e) { c.fail("&e[DBR-Reload]&r &cA critic error occurred during reload: " + e); }
    }
    C.tree("reload", {
        description: "Reload DBR's settings and story: [all|config|story|wishes]",
        canUse: function (p) { return C.has(p, "reload"); },
        exec: reloadCmd,
        children: [{ arg: "target", type: "word", suggest: ["all", "config", "story", "wishes"], exec: reloadCmd }]
    });

    // =================================================================================
    //  /rpgc restoreupdate (RestoreCommand): custom sagas and side quests back to DMZ's (with a 15 s confirmation)
    // =================================================================================
    var RESTORE = {};
    function restoreKey(c) { return c.src ? String(c.src.uuid) : "console"; }
    C.tree("restoreupdate", {
        description: "Delete the custom sagas and side quests and go back to DMZ's story (then: confirm)",
        canUse: function (p) { return C.has(p, "admin"); },
        exec: function (c) {
            RESTORE[restoreKey(c)] = Date.now() + 15000;
            c.tell("&c[DBR-Restore]&r &cThis will DELETE all custom sagas and side quests and regenerate the story to its defaults!");
            c.tell("&e[DBR-Restore]&r Click to confirm (expires in 15 seconds): &c/rpgc restoreupdate confirm");
        },
        children: [{ lit: "confirm", exec: function (c) {
            var k = restoreKey(c);
            if (!RESTORE[k] || Date.now() > RESTORE[k]) { delete RESTORE[k]; return c.tell("&e[DBR-Restore]&r &cNo pending confirmation or it has expired. Run the command again."); }
            delete RESTORE[k];
            c.tell("&e[DBR-Restore]&r Restoring default files...");
            try {
                var n = typeof DBR_SAGA_EDITOR !== "undefined" && DBR_SAGA_EDITOR.restoreDefaults ? DBR_SAGA_EDITOR.restoreDefaults() : 0;
                RPG.server.players().forEach(function (p) { if (typeof DMZ_QUESTS !== "undefined") DMZ_QUESTS.sync(p); });
                c.tell("&e[DBR-Reload]&r Reload completed successfully! &7(" + n + " custom entries removed)");
            } catch (e) { c.fail("&e[DBR-Restore]&r &cA critic error occurred while deleting files: " + e); }
        } }]
    });

    // =================================================================================
    //  /rpgc debug (DebugCommand): a JSON dump of a character, saved on the asking player's computer
    // =================================================================================
    var DEBUG_SCOPES = ["ALL", "STATS", "CHARACTER", "TECHNIQUES", "QUESTS"], LAST_DEBUG = {};
    function debugJson(t, scope) {
        var j = { schemaVersion: 1, generatedAt: new Date().toISOString().replace(/\.\d+Z$/, "Z"), scope: scope,
            mod: { addon: "dragon_block_ragnarok" }, server: { dedicated: RPG.server.isDedicated() },
            player: { name: t.name, uuid: String(t.uuid) } };
        var all = scope === "ALL";
        if (all || scope === "STATS") {
            var st = {};
            STATS.forEach(function (k) { st[k] = { total: t.stat(IDS[k]), base: t.baseStat(IDS[k]), allocated: t.allocated(IDS[k]) }; });
            j.Stats = st;
            j.BonusStats = bonuses(t);
            j.Resources = { health: t.health, maxHealth: t.maxHealth, ki: t.resource("ki"), maxKi: t.maxResource("ki"), stamina: t.resource("stamina"),
                maxStamina: t.maxResource("stamina"), trainingPoints: t.getTp(), statPoints: t.statPoints, level: t.getLevel(),
                powerRelease: t.getVar("dmz_release", 0), potential: t.getVar("dmz_potential", 0), alignment: alignOf(t) };
            j.Status = { form: t.getVar("dmz_form", ""), stackForm: t.getVar("dmz_stack", ""), fused: !!t.getVar("dmz_fused", 0), alive: typeof owIsAlive === "function" ? owIsAlive(t) : true };
            j.Cooldowns = { general: t.getVar("dmz_cd", null), techniques: t.getVar("dmz_tech_cd", null) };
            j.Skills = DMZ_SKILLS.levels(t);
        }
        if (all || scope === "CHARACTER") j.Character = { race: t.race, class: t.playerClass, created: created(t), mastery: t.getVar("dmz_mastery", null), stackMastery: t.getVar("dmz_stack_mastery", null),
            hairStyle: t.getColor("hairStyle"), hair: t.getColor("hair"), tail: t.race === "saiyan" ? hasTail(t) : null, absorptions: t.getVar("dmz_absorptions", null), assimilations: t.getVar("dmz_assimilations", null) };
        if (all || scope === "TECHNIQUES") j.Techniques = { unlocked: DMZ_TECH.unlocked(t), slots: DMZ_TECH.slots(t) };
        if (all || scope === "QUESTS") j.PlayerQuestData = t.getVar("dmz_quests", null);
        return JSON.stringify(j, null, 2);
    }
    function debugWrite(c, target, scope) {
        scope = String(scope || "ALL").toUpperCase();
        if (DEBUG_SCOPES.indexOf(scope) < 0) return c.tell("&e[DBR-Debug]&r Invalid debug value '" + scope + "'. Use: ALL, STATS, CHARACTER, TECHNIQUES, QUESTS");
        var src = c.src;
        if (src && !C.has(src, "admin")) {
            var last = LAST_DEBUG[String(src.uuid)] || 0, now = Date.now();
            if (now - last < 5000) return c.tell("&e[DBR-Debug]&r Please wait " + Math.ceil((5000 - (now - last)) / 1000) + " seconds before using this command again");
            LAST_DEBUG[String(src.uuid)] = now;
        }
        if (!created(target)) return c.tell("&e[DBR-Debug]&r No stats data available for " + target.name);
        var json = debugJson(target, scope);
        if (src) {                                  // DebugFileS2C: the asking player's own computer keeps it
            var tx = Date.now() + "_" + Math.floor(Math.random() * 1e6), n = Math.ceil(json.length / 9000);
            if (n > 200) return c.tell("&e[DBR-Debug]&r Failed to create debug file: dump too large to send");
            for (var i = 0; i < n; i++) RPG.net.send(src, "dbr_debug_file", { tx: tx, i: i, n: n, name: target.name, part: json.substring(i * 9000, (i + 1) * 9000) });
            return;
        }
        try {
            RPG.files.writeShared("dbrdebug/" + target.name + ".json", JSON.parse(json));
            c.tell("&e[DBR-Debug]&r Debug file for " + target.name + " created at: " + RPG.files.sharedPath("dbrdebug/" + target.name + ".json"));
        } catch (e) { c.tell("&e[DBR-Debug]&r Failed to create debug file: " + e); }
    }
    C.tree("debug", {
        description: "Character dump: [ALL|STATS|CHARACTER|TECHNIQUES|QUESTS] | <player> [scope] (admins)",
        exec: function (c) { if (!c.src) return c.fail("A player is required to run this command here"); debugWrite(c, c.src, "ALL"); },
        children: [{ arg: "value", type: "word", suggest: function (c) {
            return DEBUG_SCOPES.concat(c.src && !C.has(c.src, "admin") ? [] : RPG.server.players().map(function (x) { return x.name; }));
        }, exec: function (c) {
            var v = String(c.get("value"));
            if (DEBUG_SCOPES.indexOf(v.toUpperCase()) < 0 && C.has(c.src, "admin")) {
                var named = RPG.server.selectPlayers(v, c.src);
                if (named.length === 1) return debugWrite(c, named[0], "ALL");
            }
            if (!c.src) return c.fail("A player is required to run this command here");
            debugWrite(c, c.src, v);
        }, children: [{ arg: "scope", type: "word", suggest: DEBUG_SCOPES, perm: function (p) { return C.has(p, "admin"); }, exec: function (c) {
            var named = RPG.server.selectPlayers(String(c.get("value")), c.src);
            if (named.length !== 1) return c.fail("No player was found");
            debugWrite(c, named[0], c.get("scope"));
        } }] }]
    });

    // =================================================================================
    //  /rpgc quest (StoryCommand): story and side quests
    // =================================================================================
    var QL = DMZ_QL;
    function qcmd() { return DMZ_QUESTS.cmd; }
    function norm(id) { return String(id).replace(/\./g, ":"); }
    var QIDS = null, QIDS_AT = "";
    function questIds() {                       // cached for tab completion: rebuilt when the saga editor changes the story
        var at = (QL.CUSTOM.version || 0) + ":" + QL.SAGA_LIST.length + ":" + QL.SIDE.length;
        if (!QIDS || QIDS_AT !== at) { QIDS = Object.keys(QL.BY_KEY).sort().map(function (k) { return k.replace(/:/g, "."); }); QIDS_AT = at; }
        return QIDS.slice();
    }
    function sagaIds() { return QL.SAGA_LIST.map(function (s) { return s.id; }); }
    function notFound(c, key) { c.fail("Quest not found: " + key + "  (tip: use '.' instead of ':' — e.g. classic_saga.1)"); }
    function questTargets(c) {
        if (c.has("player")) return c.get("player");
        if (!c.src) { c.fail("No valid players found."); return null; }
        return [c.src];
    }
    function questTitle(q, key) { return String(q.title_text || q.name || q.title || key); }
    function statusText(v, key) {
        var s = QL.status(v, key);
        return s === QL.COMPLETED ? "&a[SUCCESS]" : s === QL.ACCEPTED ? "&e[ACTIVE]" : s === QL.FAILED ? "&c[FAILED]" : "&7[NOT STARTED]";
    }
    function forceAccept(p, v, e) {
        var party = typeof DMZ_PARTY !== "undefined" ? DMZ_PARTY.members(p).length : 1;
        v.q[e.key] = { s: QL.ACCEPTED, p: e.quest.objectives.map(function () { return 0; }), c: [], d: (v.d || "NORMAL"), dim: p.dimension,
            rq: e.quest.objectives.map(function (o) { return qcmd().scaledRequired(e.quest, o, party); }) };
    }
    function finishOne(p, v, e) {
        if (QL.status(v, e.key) !== QL.ACCEPTED) forceAccept(p, v, e);
        var r = v.q[e.key];
        r.p = e.quest.objectives.map(function (o, i) { return r.rq && typeof r.rq[i] === "number" ? r.rq[i] : QL.required(o); });
        qcmd().complete(p, v, e);
    }
    function resetOne(p, v, key) { qcmd().despawn(p, key); delete v.q[key]; if (v.tr === key) v.tr = null; }
    function eachQuest(c, which, fn, verb) {
        var raw = String(c.get(which === "saga" ? "saga" : "quest")), all = raw.toLowerCase() === "all", list = questTargets(c);
        if (!list) return;
        var keys;
        if (which === "saga") {
            if (!all && !QL.SAGAS[raw]) return c.fail("Saga not found: " + raw);
            keys = [];
            (all ? QL.SAGA_LIST : [QL.SAGAS[raw]]).forEach(function (s) { s.quests.forEach(function (q) { keys.push(s.id + ":" + q.id); }); });
        } else {
            var key = norm(raw);
            if (!all && !QL.entry(key)) return notFound(c, key);
            keys = all ? Object.keys(QL.BY_KEY) : [key];
        }
        list.forEach(function (p) {
            var v = qcmd().view(p);
            keys.forEach(function (k) { var e = QL.entry(k); if (e || verb.indexOf("Reset") === 0) fn(p, v, e, k); });
            qcmd().save(p, v); qcmd().sync(p, v);
        });
        var label = which === "saga" ? (all ? verb + " all sagas" : verb + " saga " + raw) : (all ? verb + " all " + (verb === "Failed" ? "active quests" : "quests") : verb + " quest " + norm(raw));
        c.tell(label + " for " + list.length + " player(s).");
    }
    function questList(c) {
        var p = c.has("player") ? c.get("player")[0] : c.src;
        if (!p) return c.fail("No valid players found.");
        var v = qcmd().view(p), keys = Object.keys(QL.BY_KEY).sort();
        if (!keys.length) return c.fail("No quests are loaded.");
        c.tell("Quest progress for " + p.name + ":");
        keys.forEach(function (k) {
            var e = QL.entry(k);
            c.tell(statusText(v, k) + " &f" + questTitle(e.quest, k) + " &7[" + k + "]");
            if (QL.status(v, k) === QL.ACCEPTED) e.quest.objectives.forEach(function (o, i) {
                var have = QL.progress(v, k, i), need = v.q[k].rq && typeof v.q[k].rq[i] === "number" ? v.q[k].rq[i] : QL.required(o);
                c.tell("  " + (have >= need ? "[DONE]" : "[" + have + "/" + need + "]") + " " + String(o.type || "") + (o.entity || o.item || o.npcId ? " " + (o.entity || o.item || o.npcId) : ""));
            });
        });
    }
    function questInfo(c) {
        var key = norm(c.get("quest")), e = QL.entry(key);
        if (!e) return notFound(c, key);
        var q = e.quest;
        c.tell("=== Quest: " + key + " ===");
        c.tell("Title : " + questTitle(q, key));
        c.tell("Type  : " + (e.side ? "SIDE" : "SAGA"));
        c.tell("Saga  : " + (e.saga ? e.saga.id : "none"));
        if (q.quest_giver) c.tell("Giver : " + q.quest_giver);
        if (q.turn_in) c.tell("TurnIn: " + q.turn_in);
        c.tell("Objectives (" + q.objectives.length + "):");
        q.objectives.forEach(function (o, i) { c.tell("  [" + i + "] " + String(o.type || "") + " x" + QL.required(o) + (o.entity || o.item || o.npcId ? " " + (o.entity || o.item || o.npcId) : "")); });
        c.tell("Rewards: " + (q.rewards || []).length);
        c.tell("Secret : " + !!q.secret);
        c.tell("Claim  : " + String(q.claim_mode || "ANY"));
        if (q.prerequisites) c.tell("Has prerequisites: yes");
        if (q.requirements) c.tell("Has start requirements: yes");
    }
    function questTrack(c) {
        var raw = String(c.get("quest")), key = raw.toLowerCase() === "none" ? null : norm(raw), list = questTargets(c);
        if (!list) return;
        if (key && !QL.entry(key)) return notFound(c, key);
        list.forEach(function (p) { var v = qcmd().view(p); v.tr = key; qcmd().save(p, v); qcmd().sync(p, v); });
        c.tell("Set tracked quest to '" + (key || "none") + "' for " + list.length + " player(s).");
    }
    function diffName(d) { d = String(d || "NORMAL").toLowerCase(); return d.charAt(0).toUpperCase() + d.substring(1); }
    function questDifficulty(c) {
        var list = players(c);
        if (!list) return;
        if (!c.has("difficulty")) {
            list.forEach(function (p) { var v = qcmd().view(p); c.tell("&e[DBR-Quest]&r " + p.name + " plays the story on " + diffName(v.d) + "."); });
            return;
        }
        var raw = String(c.get("difficulty")), d = raw.toUpperCase();
        if (!QL.DIFFICULTY[d]) return c.tell("&c[DBR-Quest]&r Unknown difficulty '" + raw + "'. Use easy, normal or hard.");
        var done = {};
        list.forEach(function (p) {
            var owner = typeof DMZ_PARTY !== "undefined" && DMZ_PARTY.leaderOf ? DMZ_PARTY.leaderOf(p) || p : p;
            if (done[String(owner.uuid)]) return;
            done[String(owner.uuid)] = 1;
            var v = qcmd().view(owner); v.d = d; qcmd().save(owner, v); qcmd().sync(owner, v);
            var members = typeof DMZ_PARTY !== "undefined" ? DMZ_PARTY.members(owner) : [owner];
            members.forEach(function (m) { m.tell("&e[DBR-Quest]&r Your story difficulty is now " + diffName(d) + "."); });
            if (members.length > 1) c.tell("&7" + owner.name + " leads a party of " + members.length + " players: the whole party now plays on " + diffName(d) + ".");
        });
        report(c, list, function (n) { return "&e[DBR-Quest]&r Story difficulty set to " + diffName(d) + " for " + n + "."; },
            function (m) { return "&e[DBR-Quest]&r Story difficulty set to " + diffName(d) + " for " + m + " players."; });
    }
    var QUEST_NPC_RADIUS = 16;
    function questNpcs(p) {
        return p.nearby(QUEST_NPC_RADIUS).filter(function (e) { return e.isAlive() && !e.isPlayer() && e.rpgId && RPG.npcs.exists(String(e.rpgId)); });
    }
    function questNpcSpawn(c) {
        var p = c.src;
        if (!p) return c.fail("A player is required to run this command here");
        var id = String(c.get("npcId")), npc = qcmd().npcOf(id) || id;
        if (!RPG.npcs.exists(npc)) return c.tell("&e[DBR-Story]&r &cFailed to spawn quest NPC: unknown NPC " + id);
        var e = RPG.world.spawnNpc(p.dimension, npc, p.x, p.y, p.z);
        if (!e) return c.fail("Failed to create the quest NPC.");
        e.addTag("dbr_quest_npc");
        c.tell("Spawned quest NPC '" + id + "'.");
    }
    function playerOnly(p) { return { arg: "player", type: "player", perm: p }; }
    function questBranch(lit, which, sugg, fn, verb) {
        var exec = function (c) { eachQuest(c, which, fn, verb); };
        var node = { arg: which === "saga" ? "saga" : "quest", type: "word", suggest: sugg, exec: exec, children: [] };
        node.children.push({ arg: "player", type: "player", perm: function (p) { return C.has(p, "quest." + lit + ".others"); }, exec: exec });
        return { lit: lit, perm: function (p) { return C.check(p, "quest." + lit + ".self", "quest." + lit + ".others"); }, children: [node] };
    }
    var Q_ALL = function () { return questIds().concat(["all"]); }, S_ALL = function () { return sagaIds().concat(["all"]); };
    C.tree("quest", {
        description: "Story quests: list | info | start | finish | fail | reset | track | startsaga | finishsaga | resetsaga | difficulty | questnpc",
        canUse: function (p) { return C.check(p, "quest.list.self", "quest.list.others"); },
        children: [
            { lit: "list", exec: questList, children: [{ arg: "player", type: "player", perm: function (p) { return C.has(p, "quest.list.others"); }, exec: questList }] },
            { lit: "info", perm: function (p) { return C.has(p, "quest.info"); }, children: [{ arg: "quest", type: "word", suggest: questIds, exec: questInfo }] },
            questBranch("start", "quest", Q_ALL, function (p, v, e) { var s = QL.status(v, e.key); if (s !== QL.ACCEPTED && s !== QL.COMPLETED) forceAccept(p, v, e); }, "Started"),
            questBranch("finish", "quest", Q_ALL, function (p, v, e) { finishOne(p, v, e); }, "Finished"),
            questBranch("fail", "quest", Q_ALL, function (p, v, e) { if (QL.status(v, e.key) === QL.ACCEPTED) qcmd().fail(p, v, e.key, null); }, "Failed"),
            questBranch("reset", "quest", Q_ALL, function (p, v, e, k) { resetOne(p, v, k); }, "Reset"),
            { lit: "track", perm: function (p) { return C.check(p, "quest.track.self", "quest.track.others"); }, children: [
                { arg: "quest", type: "word", suggest: function () { return questIds().concat(["none"]); }, exec: questTrack, children: [
                    { arg: "player", type: "player", perm: function (p) { return C.has(p, "quest.track.others"); }, exec: questTrack }] }] },
            questBranch("startsaga", "saga", S_ALL, function (p, v, e) { var s = QL.status(v, e.key); if (s !== QL.ACCEPTED && s !== QL.COMPLETED) forceAccept(p, v, e); }, "Started"),
            questBranch("finishsaga", "saga", S_ALL, function (p, v, e) { finishOne(p, v, e); }, "Finished"),
            questBranch("resetsaga", "saga", S_ALL, function (p, v, e, k) { resetOne(p, v, k); }, "Reset"),
            { lit: "difficulty", perm: function (p) { return C.check(p, "quest.difficulty.self", "quest.difficulty.others"); }, exec: questDifficulty, children: [
                { arg: "difficulty", type: "word", suggest: ["easy", "normal", "hard"], exec: questDifficulty, children: [STATS_TARGETS("quest.difficulty.others", questDifficulty)] }] },
            { lit: "questnpc", perm: function (p) { return p.isOp(); }, children: [
                { lit: "spawn", children: [{ arg: "npcId", type: "word", suggest: function () { return typeof DMZ_MASTERS_DATA !== "undefined" ? Object.keys(DMZ_MASTERS_DATA.MASTERS).concat(Object.keys(DMZ_MASTERS_DATA.QUEST_NPCS)) : []; },
                    exec: questNpcSpawn, children: [{ arg: "model", type: "word", exec: questNpcSpawn, children: [{ arg: "texture", type: "word", exec: questNpcSpawn }] }] }] },
                { lit: "list", exec: function (c) {
                    if (!c.src) return;
                    var l = questNpcs(c.src);
                    if (!l.length) return c.fail("No quest NPCs within " + QUEST_NPC_RADIUS + " blocks.");
                    c.tell("Quest NPCs within " + QUEST_NPC_RADIUS + " blocks (" + l.length + "):");
                    l.forEach(function (e) { c.tell(" - " + e.rpgId + " at " + Math.floor(e.x) + ", " + Math.floor(e.y) + ", " + Math.floor(e.z) + " (" + Math.round(c.src.distanceTo(e)) + " blocks)"); });
                } },
                { lit: "remove", exec: function (c) {
                    if (!c.src) return;
                    var l = questNpcs(c.src).sort(function (a, b) { return c.src.distanceTo(a) - c.src.distanceTo(b); });
                    if (!l.length) return c.fail("No quest NPCs within " + QUEST_NPC_RADIUS + " blocks.");
                    var id = l[0].rpgId; l[0].remove();
                    c.tell("Removed quest NPC '" + id + "'.");
                } }
            ] }
        ]
    });

    // =================================================================================
    //  /rpgc locate (LocateCommand) and /rpgc structure (StructureCommand)
    // =================================================================================
    function structureNames() { return Object.keys(DMZ_UNIQUE).concat(Object.keys(DMZ_FIXED)); }
    function locateCmd(c) {
        var p = c.src, want = String(c.get("structure"));
        if (!p) return c.fail("A player is required to run this command here");
        var best = null, bd = Infinity, plans = dmzPlans(), built = dmzBuilt(), elsewhere = null;
        function consider(name, dim, x, z) {
            var n = String(name || "");
            if (n !== want && n.indexOf(want + "_") !== 0 && n.indexOf(want + "@") !== 0) return;
            if (dim !== p.dimension) { elsewhere = elsewhere || dim; return; }
            var d = Math.sqrt((x - p.x) * (x - p.x) + (z - p.z) * (z - p.z));
            if (d < bd) { bd = d; best = { x: x, z: z }; }
        }
        for (var k in plans) consider(plans[k].name || k, plans[k].dim, plans[k].x, plans[k].z);
        for (var k2 in built) consider(built[k2].name, built[k2].dim, built[k2].x + Math.floor(built[k2].sx / 2), built[k2].z + Math.floor(built[k2].sz / 2));
        if (structureNames().indexOf(want) < 0 && !best && !elsewhere) return c.tell("&e[DBR-Locate]&r Unknown structure '" + want + "'.");
        if (best) return c.tell("&e[DBR-Locate]&r The nearest " + want + " is at &a[" + best.x + ", ~, " + best.z + "]&r (" + Math.floor(bd) + " blocks away)");
        if (elsewhere) return c.tell("&e[DBR-Locate]&r You can't locate structures in another dimension. &7(" + want + " is in " + elsewhere + ")");
        c.tell("&e[DBR-Locate]&r Could not find a location for " + want + " nearby.");
    }
    function locateAll(c) {
        var plans = dmzPlans(), built = dmzBuilt();
        for (var k in plans) c.tell("&6" + k + " &7" + plans[k].dim + " &f" + plans[k].x + ", " + plans[k].z + " &8(" + plans[k].state + ")");
        for (var k2 in built) if (!plans[k2]) c.tell("&e" + k2 + " &7" + built[k2].dim + " &f" + built[k2].x + ", " + built[k2].y + ", " + built[k2].z + (built[k2].done ? "" : " &8(building)"));
        if (DMZ_PLAN_QUEUE && DMZ_PLAN_QUEUE.length) c.tell("&7Still looking for sites: " + DMZ_PLAN_QUEUE.map(function (j) { return j.name; }).join(", "));
    }
    C.tree("locate", {
        description: "Where DMZ's structures are: <structure> (the nearest) | no argument: every one",
        legacy: ["dmzlocate"],
        canUse: function (p) { return C.has(p, "locate"); },
        exec: locateAll,
        children: [{ arg: "structure", type: "word", suggest: structureNames, exec: locateCmd }]
    });
    function structureAt(p) {
        var built = dmzBuilt();
        for (var k in built) {
            var b = built[k];
            if (b.dim === p.dimension && p.x >= b.x && p.x < b.x + b.sx && p.y >= b.y && p.y < b.y + b.sy && p.z >= b.z && p.z < b.z + b.sz) return { key: k, b: b };
        }
        return null;
    }
    C.tree("structure", {
        description: "The structure you stand in: here | npcs",
        canUse: function (p) { return C.has(p, "structure"); },
        children: [
            { lit: "here", exec: function (c) {
                if (!c.src) return c.fail("A player is required to run this command here");
                var s = structureAt(c.src);
                if (!s) return c.tell("&e[DBR-Structure]&r You are not inside a structure.");
                var lx = Math.floor(c.src.x) - s.b.x, ly = Math.floor(c.src.y) - s.b.y, lz = Math.floor(c.src.z) - s.b.z;
                c.tell("&e[DBR-Structure]&r " + s.key + " · template " + s.b.name + " · local " + lx + ", " + ly + ", " + lz + " · yaw " + Math.round(((c.src.yaw % 360) + 360) % 360));
                c.tell("&7[" + s.b.name + "] [\"npc_id\", " + lx + ", " + ly + ", " + lz + ", " + Math.round(((c.src.yaw % 360) + 360) % 360) + "]");
            } },
            { lit: "npcs", exec: function (c) {
                if (!c.src) return c.fail("A player is required to run this command here");
                var s = structureAt(c.src);
                if (!s) return c.tell("&e[DBR-Structure]&r You are not inside a structure.");
                var m = dmzManifest(s.b.name), npcs = (m && m.npcs) || [];
                if (!npcs.length) return c.tell("&e[DBR-Structure]&r " + s.key + " has no structure NPCs.");
                npcs.forEach(function (n) {
                    var x = s.b.x + n[1], y = s.b.y + n[2], z = s.b.z + n[3];
                    var found = c.src.nearby(Math.max(8, c.src.distanceTo({ x: x, y: y, z: z, dimension: c.src.dimension }) + 4)).some(function (e) {
                        return String(e.rpgId || "") === String(n[0]) && Math.abs(e.x - x) < 4 && Math.abs(e.z - z) < 4;
                    });
                    c.tell("&e[DBR-Structure]&r " + n[0] + " at " + x + ", " + y + ", " + z + " · " + (found ? "spawned" : "not spawned yet"));
                });
            } }
        ]
    });

    // =================================================================================
    //  /rpgc trigger (TriggerCommand): test forms and racial skills without costs, unlocks or mastery
    // =================================================================================
    function trig(fn) {
        return function (c) {
            var t = c.get("target")[0], self = c.src && String(c.src.uuid) === String(t.uuid);
            if (c.src && !self && !C.has(c.src, "trigger.others")) return c.tell("&e[DBR-Trigger]&r &cYou can only target yourself with this command.");
            if (!created(t)) return c.tell("&e[DBR-Trigger]&r &c" + t.name + " has no character yet.");
            fn(c, t);
        };
    }
    function stackGroups() { return FD.STACKS.map(function (g) { return g.id; }); }
    var R = function () { return DMZ_RACIALS; };
    function hasRacial(c, t, id) {
        if (race(t) === id) return true;
        c.tell("&e[DBR-Trigger]&r &c" + t.name + " does not have the '" + id + "' racial skill.");
        return false;
    }
    function fmt(v) { v = Math.round(Number(v) * 100) / 100; return String(v); }
    // TriggerCommand.zenkai: temp = SaiyanZenkai.applyTemporaryBuff; real = 1 HP, then the full Zenkai (knockout, cooldown)
    function zenkaiTrigger(c, t, pct, real) {
        if (!hasRacial(c, t, "saiyan")) return;
        var potency = pct / 100;
        if (real) {
            t.health = 1;
            R().triggerZenkai(t, potency, pct >= 100);
            c.tell("&e[DBR-Trigger]&r &aTriggered a full Zenkai at " + fmt(pct) + "% potency on " + t.name + ".");
        } else {
            R().tempZenkai(t, potency);
            c.tell("&e[DBR-Trigger]&r &aApplied a temporary Zenkai at " + fmt(pct) + "% potency to " + t.name + ".");
        }
    }
    function targetGroupSug(c) { var t = RPG.server.selectPlayers(word(c, 0), c.src)[0] || c.src; return t ? FD.groups(race(t)).map(function (g) { return g.id; }) : []; }
    function targetFormSug(c) { var t = RPG.server.selectPlayers(word(c, 0), c.src)[0] || c.src, g = t ? FD.group(race(t), word(c, 2)) : null; return g ? g.forms.map(function (f) { return f.id; }) : []; }
    C.tree("trigger", {
        description: "Test forms and racial skills: <target> form <group> <form>|base | stackform <group> <form>|clear | clear | racialskill ... | cooldowns | rage <0-100> | knockout [seconds] | release <value>",
        canUse: function (p) { return C.check(p, "trigger.self", "trigger.others"); },
        children: [{ arg: "target", type: "player", children: [
            { lit: "form", children: [
                { lit: "base", exec: trig(function (c, t) { DMZ_TF.setForm(t, null, null); c.tell("&e[DBR-Trigger]&r &aReverted " + t.name + " to their base form."); }) },
                { arg: "group", type: "word", suggest: targetGroupSug, children: [{ arg: "form", type: "word", suggest: targetFormSug, exec: trig(function (c, t) {
                    var g = String(c.get("group")), f = FD.form(race(t), g, String(c.get("form")));
                    if (!FD.groups(race(t)).some(function (x) { return x.id === g; })) return c.tell("&e[DBR-Trigger]&r &cUnknown form group '" + g + "' for " + t.name + ".");
                    if (!f) return c.tell("&e[DBR-Trigger]&r &cUnknown form '" + c.get("form") + "' in group '" + g + "'.");
                    DMZ_TF.setForm(t, f.group, f.id);
                    c.tell("&e[DBR-Trigger]&r &aTriggered " + f.id + " on " + t.name + " &7(test: no costs, unlocks or mastery)");
                }) }] }
            ] },
            { lit: "stackform", children: [
                { lit: "clear", exec: trig(function (c, t) { DMZ_TF.setStack(t, null, null); c.tell("&e[DBR-Trigger]&r &aCleared the stack form of " + t.name + "."); }) },
                { arg: "group", type: "word", suggest: stackGroups, children: [{ arg: "form", type: "word", suggest: function (c) { var g = FD.stackGroup(word(c, 2)); return g ? g.forms.map(function (f) { return f.id; }) : []; },
                    exec: trig(function (c, t) {
                        var g = String(c.get("group")), sg = FD.stackGroup(g);
                        if (!sg) return c.tell("&e[DBR-Trigger]&r &cUnknown stack form group '" + g + "'.");
                        var f = FD.stackForm(g, String(c.get("form")));
                        if (!f) return c.tell("&e[DBR-Trigger]&r &cUnknown form '" + c.get("form") + "' in group '" + g + "'.");
                        DMZ_TF.setStack(t, f.group, f.id);
                        c.tell("&e[DBR-Trigger]&r &aTriggered " + f.id + " on " + t.name + " &7(test: no costs, unlocks or mastery)");
                    }) }] }
            ] },
            { lit: "clear", exec: trig(function (c, t) { DMZ_TF.setStack(t, null, null); DMZ_TF.setForm(t, null, null); c.tell("&e[DBR-Trigger]&r &aCleared the form and stack form of " + t.name + "."); }) },
            { lit: "racialskill", children: [
                { lit: "saiyan", exec: trig(function (c, t) { zenkaiTrigger(c, t, 100, false); }), children: [{ arg: "potency", type: "double", min: 0, max: 100, suggest: ["25", "50", "100"], exec: trig(function (c, t) { zenkaiTrigger(c, t, c.get("potency"), false); }),
                    children: [{ lit: "temp", exec: trig(function (c, t) { zenkaiTrigger(c, t, c.get("potency"), false); }) }, { lit: "real", exec: trig(function (c, t) { zenkaiTrigger(c, t, c.get("potency"), true); }) }] }] },
                { lit: "majin", children: [{ arg: "potency", type: "double", min: 0, max: 100, suggest: ["4", "50", "100"], children: [{ arg: "mob", type: "word", suggest: function () { return RPG.server.registryIds("living"); },
                    exec: trig(function (c, t) {
                        if (race(t) !== "majin") return c.tell("&e[DBR-Trigger]&r &c" + t.name + " does not have the 'majin' racial skill.");
                        var l = t.getVar("dmz_absorptions", null); l = l && l.length !== undefined ? l : [];
                        if (l.length >= 3) return c.tell("&e[DBR-Trigger]&r &c" + t.name + " has no free racial slots. Use /rpgc racial reset to clear them.");
                        var pct = c.get("potency") / 100, hp = 100, s = {};
                        ["STR", "SKP", "PWR"].forEach(function (k) { s[k] = Math.max(1, Math.floor(hp * pct)); });
                        l.push({ n: String(c.get("mob")), s: s, t: Date.now() }); t.setVar("dmz_absorptions", l);
                        if (DMZ_TF.RACIAL && DMZ_TF.RACIAL.syncBonus) DMZ_TF.RACIAL.syncBonus(t);
                        c.tell("&e[DBR-Trigger]&r &a" + t.name + " absorbed a virtual " + c.get("mob") + " (" + hp + " HP, " + c.get("potency") + "% copied).");
                    }) }] }] },
                { lit: "namekian", exec: trig(function (c, t) { namekTrigger(c, t, 7.5); }), children: [{ arg: "potency", type: "double", min: 0, max: 100, suggest: ["7.5", "25", "50"], exec: trig(function (c, t) { namekTrigger(c, t, c.get("potency")); }) }] },
                { lit: "human", children: [{ lit: "adrenaline", exec: trig(function (c, t) {
                    if (!hasRacial(c, t, "human")) return;
                    R().triggerAdrenaline(t);
                    c.tell("&e[DBR-Trigger]&r &aTriggered Adrenaline on " + t.name + ".");
                }) }] },
                { lit: "frostdemon", children: [{ lit: "reserve", children: [{ arg: "percent", type: "double", min: 0, max: 100, suggest: ["25", "50", "100"], exec: trig(function (c, t) {
                    if (!hasRacial(c, t, "frostdemon")) return;
                    R().setReserve(t, c.get("percent"));
                    c.tell("&e[DBR-Trigger]&r &aSet the energy reserve of " + t.name + " to " + fmt(c.get("percent")) + "%.");
                }) }] }] },
                { lit: "bioandroid", children: [{ lit: "explode", exec: trig(function (c, t) {
                    if (!hasRacial(c, t, "bioandroid")) return;
                    R().triggerExplosion(t);
                    c.tell("&e[DBR-Trigger]&r &aTriggered self-destruct on " + t.name + ".");
                }) }, { lit: "celljr", exec: trig(function (c, t) {
                    if (!hasRacial(c, t, "bioandroid")) return;
                    var before = R().cellJrs(t).length;
                    R().summonCellJr(t);
                    if (R().cellJrs(t).length <= before) return c.tell("&e[DBR-Trigger]&r &cCell Jr. limit reached for " + t.name + ".");
                    c.tell("&e[DBR-Trigger]&r &aSummoned a Cell Jr. for " + t.name + ".");
                }) }] }
            ] },
            { lit: "cooldowns", exec: trig(function (c, t) {
                var n = 0;
                ["absorb", "assim", "drain"].forEach(function (k) { if (Number(t.getVar("dmz_cd_" + k, 0)) > Date.now()) n++; t.setVar("dmz_cd_" + k, 0); });
                if (typeof DMZ_RACIALS !== "undefined") n += DMZ_RACIALS.clearCooldowns(t);   // adrenaline, zenkai, self-destruct, Cell Jr. slots
                c.tell("&e[DBR-Trigger]&r &aCleared " + n + " racial cooldowns of " + t.name + ".");
            }) },
            { lit: "rage", children: [{ arg: "value", type: "double", min: 0, max: 100, suggest: ["25", "50", "100"], exec: trig(function (c, t) {
                if (t.race !== "saiyan") return c.tell("&e[DBR-Trigger]&r &c" + t.name + " has no Rage meter (requires Mutant or False Super Saiyan).");
                t.setVar("dmz_rage", c.get("value"));
                c.tell("&e[DBR-Trigger]&r &aSet the Rage of " + t.name + " to " + c.get("value") + ".");
            }) }] },
            { lit: "knockout", exec: trig(function (c, t) { knock(c, t, 10); }), children: [{ arg: "seconds", type: "int", min: 1, max: 3600, exec: trig(function (c, t) { knock(c, t, c.get("seconds")); }) }] },
            { lit: "release", children: [{ arg: "value", type: "int", min: 0, suggest: ["0", "50", "100"], exec: trig(function (c, t) {
                var max = DMZ_F.maxRelease(Number(t.getVar("dmz_potential", 0)), t.race === "saiyan" ? 1 + Math.min(0.15, Number(t.getVar("dmz_zenkai_release", 0)) || 0) : 1, t.getVar("dmzr_release_boost", 0));
                var v = Math.min(max, c.get("value"));
                t.setVar("dmz_release", v);
                t.refreshStats();
                c.tell("&e[DBR-Trigger]&r &aSet the power release of " + t.name + " to " + v + "% (max " + max + "%).");
            }) }] }
        ] }]
    });
    function namekTrigger(c, t, pct) {
        if (race(t) !== "namekian") return c.tell("&e[DBR-Trigger]&r &c" + t.name + " does not have the 'namekian' racial skill.");
        var l = t.getVar("dmz_assimilations", null); l = l && l.length !== undefined ? l : [];
        if (l.length >= 4) return c.tell("&e[DBR-Trigger]&r &c" + t.name + " has no free racial slots. Use /rpgc racial reset to clear them.");
        var s = {};
        ["STR", "SKP", "PWR"].forEach(function (k) { s[k] = Math.max(1, Math.floor(t.stat(IDS[k]) * pct / 100)); });
        l.push({ n: "Virtual warrior", s: s, t: Date.now() }); t.setVar("dmz_assimilations", l);
        if (DMZ_TF.RACIAL && DMZ_TF.RACIAL.syncBonus) DMZ_TF.RACIAL.syncBonus(t);
        c.tell("&e[DBR-Trigger]&r &a" + t.name + " assimilated a virtual warrior (" + pct + "% boost).");
    }
    function knock(c, t, sec) {
        t.addEffect("knocked_down", sec * 20);
        c.tell("&e[DBR-Trigger]&r &aKnocked out " + t.name + " for " + sec + " seconds.");
    }
})();
