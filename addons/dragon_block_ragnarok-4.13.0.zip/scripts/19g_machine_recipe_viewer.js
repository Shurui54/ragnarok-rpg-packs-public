// =====================================================================================
//  19g_machine_recipe_viewer.js - DragonMine Z's machine recipes in the recipe viewer
// =====================================================================================
//  The Pattern Station (6x6 dye grids) and Kikono Station (3x3 + pattern + template) recipes are done by
//  58_dmz_machines.js, not by the game's crafting, so the recipe viewer (and anything else reading
//  RPG.recipes.forItem / uses) learns them here with RPG.recipes.addDisplay: DMZ's own and the outfit and
//  cosmetic patterns of 19e / 19f.
// =====================================================================================

var DMZ_MACHINE_RECIPES_SHOWN = (function () {
    let D = DMZ_MACH;
    let memo = {};
    function resolve(name) {
        if (name.indexOf(":") >= 0) return name;
        if (memo.hasOwnProperty(name)) return memo[name];
        let id = RPG.items.id(name) || (typeof BLOCK_IDS !== "undefined" ? BLOCK_IDS[name] : null);
        return (memo[name] = id ? "ragnarok_rpg:" + id : null);
    }
    // ~1,900 recipes: built here, handed over 150 a tick once the server runs (each batch is its own short call)
    let list = [];
    try {
        let patStation = resolve("pattern_station"), kikStation = resolve("kikono_station");
        D.patternRecipes((n) => resolve(n) || "minecraft:barrier").forEach((r, i) => {
            if (r.result === "minecraft:barrier") return;
            list.push(["dbr_pattern_" + i, { station: "Pattern Station", stationItem: patStation, width: r.w, height: r.h,
                grid: r.cells, result: r.result, note: "Any position in the 6x6 grid, mirrored or not." }]);
        });
        D.kikonoRecipes((n) => resolve(n) || "minecraft:barrier").forEach((r, i) => {
            if (r.result === "minecraft:barrier") return;
            list.push(["dbr_kikono_" + i, { station: "Kikono Station", stationItem: kikStation, width: 3, height: 3,
                grid: r.inputs, extras: [{ label: "Pattern", item: r.pattern, count: 1 }, { label: "Template", item: r.template, count: 1 }],
                result: r.result, note: r.energy + " FE from a Fuel Generator, " + (r.time / 20) + " s. Pattern and template are used up." }]);
        });
    } catch (e) { RPG.log("[DBR] machine recipes for the recipe viewer: " + e); }
    let at = 0;
    function batch() {
        let end = Math.min(list.length, at + 150);
        for (; at < end; at++) RPG.recipes.addDisplay(list[at][0], list[at][1]);
        if (at < list.length) RPG.schedule(1, batch);
    }
    RPG.schedule(1, batch);
    return list.length;
})();
