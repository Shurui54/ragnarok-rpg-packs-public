// =====================================================================================
//  57_dragon_balls_rules.js - DMZ Ragnarok's server rules for dragon balls
// =====================================================================================
//  Port of DMZ Ragnarok's (GPL-3.0) BallUniqueness, BallDimensionSweep, ScatterGuard, DragonBallClaimGuard,
//  RadarDimensionReport, BallSetCommands and BallLocatorCommand, and the ball exemptions of its claim and region
//  protection, on top of 57_dragon_balls.js (the sets) and 57_dragon_balls_bag.js (where balls may be):
//    - one of each star per set on the server: every 5 seconds (and a few seconds after a login) extra copies are
//      deleted, keeping a placed ball block first, then one in a grave, then the one held by the player online
//      longest, then one lying on the ground; a waiting scatter spot is dropped when the star already exists;
//    - a ball item lost for good (despawned, burnt, fallen into the void, killed) goes back to its set's home: the
//      star is scattered again (Super balls go back to their gods);
//    - at start-up, balls tracked outside their set's home dimension are moved home (scattered again there);
//    - scatter spots are never in claimed land or a protected structure and at least 16 blocks inside the world
//      border (57_dragon_balls.js re-rolls them);
//    - land claims and guild claims can't take a chunk holding a ball or a grave holding one; balls can be placed,
//      broken and used inside claims and protected structures;
//    - right-clicking a radar lists in chat where its sets' balls are: per dimension, how many, about where, and
//      how many lie in graves;
//    - ops: /rpgc ballset scatter|gather|awaken|unawaken <set> confirm, /rpgc ballset dormancy,
//      /rpgc balllocate [set] (every ball's exact place: blocks, scatter spots, graves, players, the ground).
// =====================================================================================
(function () {
    var API = dbrBallsApi, BAG = DBR_BAG, C = DBR_BALL_CFG;
    if (!API || !BAG) return;
    function setIds() { return Object.keys(DB_SETS); }
    function home(setId) { return DB_SETS[setId].dim; }
    function bare(b) { var s = String(b || ""), i = s.indexOf("["); return i < 0 ? s : s.substring(0, i); }
    function graves() { return typeof DBR_GRAVES !== "undefined" && DBR_GRAVES && DBR_GRAVES.ballCopies ? DBR_GRAVES : null; }
    function prettyDim(dim) {
        var id = String(dim || "").replace(/^.*:/, "").replace(/_/g, " ");
        return id.replace(/\b\w/g, function (c) { return c.toUpperCase(); });
    }

    // ---- claims and protected places (DragonBallClaimGuard, RegionEventHandler, ScatterGuard) -------------------
    function chunkHasBall(dim, cx, cz) {
        var hit = false;
        setIds().forEach(function (setId) {
            if (hit) return;
            var s = API.state(setId);
            for (var n in s.active) { var a = s.active[n]; if ((a.dim || home(setId)) === dim && (a.x >> 4) === cx && (a.z >> 4) === cz) { hit = true; return; } }
            if (home(setId) === dim) for (var m in s.pending) { var q = s.pending[m]; if ((q.x >> 4) === cx && (q.z >> 4) === cz) { hit = true; return; } }
        });
        if (hit) return true;
        var g = graves();
        return !!g && g.ballCopies().some(function (c) { return c.dim === dim && (c.x >> 4) === cx && (c.z >> 4) === cz; });
    }
    RPG_CLAIM_HOOKS.veto.push(function (dim, cx, cz) {
        return chunkHasBall(dim, cx, cz) ? "A dragon ball is in this chunk: it can't be claimed while it's there." : null;
    });
    RPG_CLAIM_HOOKS.exempt.push(function (p, b, x, y, z, dim, action) {
        if (dbrIsBallBlock(b)) return true;
        // placing one: the held item is the ball
        return action === "place" && !!BAG.ballOf(p.heldItem);
    });
    function claimedChunk(dim, x, z) {
        try { if (typeof LandClaims !== "undefined" && LandClaims && LandClaims.ownerAt(dim, x, z)) return true; } catch (e) { }
        try { if (typeof Guilds !== "undefined" && Guilds && Guilds.ownerAt(dim, x, z)) return true; } catch (e) { }
        return false;
    }
    dbrBallSpotOk = function (dim, x, z) {
        var b = RPG.world.border(dim);
        if (b && (x < b.minX + 16 || x > b.maxX - 16 || z < b.minZ + 16 || z > b.maxZ - 16)) return false;
        if (claimedChunk(dim, x, z)) return false;
        try { if (typeof dmzBoxAt === "function" && typeof DMZ_BUILD_PROTECTED !== "undefined" && dmzBoxAt(dim, x, 64, z, DMZ_BUILD_PROTECTED)) return false; } catch (e) { }
        return true;
    };

    // ---- BallUniqueness ------------------------------------------------------------------------------------------
    var LOGIN = {};
    RPG.on("playerJoin", function (p) { LOGIN[p.uuid] = RPG.server.getTick(); RPG.schedule(60, enforce); });
    RPG.on("playerLeave", function (p) { delete LOGIN[p.uuid]; });
    function heldCopies(p, add) {
        var since = LOGIN[p.uuid] === undefined ? 0 : LOGIN[p.uuid];
        RPG.items.confinedOf(p).forEach(function (e) {
            var st = e.stack, slot = e.slot, b = BAG.ballOf(st.id);
            if (typeof slot === "string") {
                if (slot === "accessory:" + BAG.slot && BAG.isBag(st))
                    bagCopies(p, since, st, add, function () { return p.getAccessory(BAG.slot); }, function (bag) { p.setAccessory(BAG.slot, bag); });
                return;
            }
            if (b) {
                for (var c = 0; c < (st.count || 1); c++)
                    add(b, 2, since, "held by " + p.name, function () {
                        var now = p.getStack(slot);
                        if (!now) return;
                        now.count = (now.count || 1) - 1;
                        p.setStack(slot, now.count > 0 ? now : null);
                    });
            } else if (BAG.isBag(st)) bagCopies(p, since, st, add, function () { return p.getStack(slot); }, function (bag) { p.setStack(slot, bag); });
        });
    }
    function bagCopies(p, since, bag, add, get, put) {
        BAG.contents(bag).forEach(function (st, k) {
            var b = st && BAG.ballOf(st.id);
            if (!b) return;
            add(b, 2, since, "in " + p.name + "'s sack", function () {
                var now = get();
                if (!now || !BAG.isBag(now)) return;
                var c = BAG.contents(now);
                c[k] = null;
                put(RPG.items.setContents(now, c));
                BAG.closeFor(p);
            });
        });
    }
    function enforce() {
        if (!C.get("duplicateCheck")) return 0;
        var copies = {};
        function add(b, kind, order, where, removeFn) {
            if (!b || !DB_SETS[b.set] || !(b.star >= 1)) return;
            var k = b.set + "#" + b.star;
            (copies[k] = copies[k] || []).push({ kind: kind, order: order, where: where, remove: removeFn });
        }
        setIds().forEach(function (setId) {
            var s = API.state(setId), set = DB_SETS[setId];
            for (var n in s.active) (function (n, a) {
                var dim = a.dim || home(setId);
                if (!RPG.world.isLoaded(dim, a.x, a.z)) return;       // can't verify without loading it: not counted
                var blk = bare(RPG.world.getBlock(dim, a.x, a.y, a.z));
                if (blk !== RPG.blocks.id(API.liveName(setId, Number(n))) && blk !== RPG.blocks.id(API.stoneName(setId, Number(n)))) return;
                add({ set: setId, star: Number(n) }, 0, 0, "block " + dim + " " + a.x + " " + a.y + " " + a.z, function () {
                    RPG.world.setBlock(dim, a.x, a.y, a.z, "minecraft:air");
                    var st = API.state(setId); delete st.active[n]; API.save(setId, st);
                });
            })(n, s.active[n]);
            for (var m in s.pending) (function (m) {
                add({ set: setId, star: Number(m) }, 4, 0, "scatter spot " + home(setId) + " " + s.pending[m].x + " " + s.pending[m].z, function () {
                    var st = API.state(setId); delete st.pending[m]; API.save(setId, st);
                });
            })(m);
        });
        var g = graves();
        if (g) g.ballCopies().forEach(function (c) {
            if (c.open) return;                 // being looked through: next pass
            add(c.ball, 1, 0, "grave of " + c.owner + " " + c.dim + " " + c.x + " " + c.y + " " + c.z, function () { g.takeBall(c.key, c.slot); });
        });
        var players = RPG.server.players();
        players.forEach(function (p) { heldCopies(p, add); });
        RPG.items.confinedDropped().forEach(function (e) {
                var st = e.stack, b = st && BAG.ballOf(st.id);
                if (!b) return;
                for (var c = 0; c < (st.count || 1); c++)
                    add(b, 3, 0, "dropped item " + e.dimension + " " + Math.floor(e.x) + " " + Math.floor(e.y) + " " + Math.floor(e.z), function () {
                        st.count = (st.count || 1) - 1;
                        RPG.world.setDroppedItem(e.uuid, st.count > 0 ? st : null);
                    });
        });
        var deleted = 0;
        Object.keys(copies).forEach(function (k) {
            var list = copies[k];
            if (list.length <= 1) return;
            var real = list.filter(function (c) { return c.kind !== 4; }).length;
            list.sort(function (a, b) { return a.kind - b.kind || a.order - b.order; });
            var kept = null;
            list.forEach(function (c) {
                if (!kept && (c.kind !== 4 || real === 0)) { kept = c; return; }
                try { c.remove(); deleted++; } catch (e) { RPG.log("[dragon balls] could not remove a duplicate: " + e); return; }
                RPG.log("[dragon balls] duplicate " + k.replace("#", " star ") + " deleted (" + c.where + "); kept: " + (kept ? kept.where : "?"));
            });
        });
        return deleted;
    }
    RPG.every(100, enforce);

    // ---- a ball lost for good goes home (BallUniqueness.lost / BallDimensionSweep.rehome) ---------------------------
    RPG.on("itemLost", function (st, dim, x, y, z, how) {
        var b = st && BAG.ballOf(st.id);
        if (!b) return;
        var s = API.state(b.set);
        if (s.held) delete s.held[b.star];
        API.save(b.set, s);
        RPG.log("[dragon balls] a " + b.set + " star " + b.star + " ball " + how + " at " + dim + " " + Math.floor(x) + " " + Math.floor(y) + " " + Math.floor(z) + "; sending it home");
        if (DB_SETS[b.set].natural) API.scatter(b.set);
        else if (b.set === "super" && typeof dbrSuperBallsReturn === "function") dbrSuperBallsReturn([b.star]);
    });

    // ---- BallDimensionSweep: at start-up, balls tracked outside their home dimension go home ---------------------------
    RPG.schedule(100, function () {
        setIds().forEach(function (setId) {
            var s = API.state(setId), moved = 0;
            for (var n in s.active) {
                var a = s.active[n], dim = a.dim || home(setId);
                if (dim === home(setId)) continue;
                var live = RPG.blocks.id(API.liveName(setId, Number(n))), stone = RPG.blocks.id(API.stoneName(setId, Number(n)));
                var blk = bare(RPG.world.getBlock(dim, a.x, a.y, a.z));
                if (blk === live || blk === stone) RPG.world.setBlock(dim, a.x, a.y, a.z, "minecraft:air");
                delete s.active[n];
                moved++;
            }
            if (!moved) return;
            API.save(setId, s);
            RPG.log("[dragon balls] " + moved + " " + setId + " ball(s) outside " + home(setId) + " went home");
            if (DB_SETS[setId].natural) API.scatter(setId);
            else if (setId === "super" && typeof dbrSuperBallsReturn === "function") {
                var stars = [];
                for (var k = 1; k <= DB_SETS.super.stars; k++) if (!API.state("super").active[k]) stars.push(k);
                dbrSuperBallsReturn(stars);
            }
        });
    });

    // ---- RadarDimensionReport: a radar's right-click names where its balls are ------------------------------------
    var RADAR_SETS = { dball_radar: ["earth"], namekdball_radar: ["namek"], fused_dball_radar: ["earth", "namek"], super_dball_radar: ["super"],
                       blackstar_dball_radar: ["blackstar"], cerulean_dball_radar: ["cerulean"] };
    function about(v) { return Math.round(v / 10) * 10; }
    function radarReport(p, sets) {
        sets.forEach(function (setId) {
            var name = (DB_SET_TITLES[setId] || setId) + " Dragon Balls";
            if (API.isDormant(setId)) { p.tell("&e[" + name + "] &7" + API.dormancyLine(setId).replace(/&./g, "")); return; }
            var places = {}, order = [];
            function place(dim) { if (!places[dim]) { places[dim] = { loose: [], graves: [] }; order.push(dim); } return places[dim]; }
            var s = API.state(setId);
            for (var n in s.active) { var a = s.active[n]; place(a.dim || home(setId)).loose.push(a); }
            for (var m in s.pending) place(home(setId)).loose.push(s.pending[m]);
            var g = graves();
            if (g) g.ballCopies().forEach(function (c) { if (c.ball.set === setId) place(c.dim).graves.push(c); });
            if (!order.length) { p.tell("&e[" + name + "] &7No balls of this set are anywhere in the world right now."); return; }
            var parts = [];
            order.forEach(function (dim) {
                var pl = places[dim];
                function list(arr) { return arr.slice(0, 4).map(function (q) { return "~" + about(q.x) + ", " + about(q.z); }).join("; ") + (arr.length > 4 ? " (+" + (arr.length - 4) + " more)" : ""); }
                if (pl.loose.length) parts.push("&f" + pl.loose.length + " in " + prettyDim(dim) + ": " + list(pl.loose));
                if (pl.graves.length) parts.push("&b" + pl.graves.length + " in a totem in " + prettyDim(dim) + ": " + list(pl.graves));
            });
            p.tell("&e[" + name + "] " + parts.join("&7 | "));
        });
    }
    var RADAR_IDS = null;
    RPG.on("itemUse", function (p, itemId) {
        if (!RADAR_IDS) {
            RADAR_IDS = {};
            Object.keys(RADAR_SETS).forEach(function (k) { var id = RPG.items.id(k); if (id) { RADAR_IDS[id] = RADAR_SETS[k]; RADAR_IDS["ragnarok_rpg:" + id] = RADAR_SETS[k]; } });
        }
        var sets = RADAR_IDS[String(itemId)];
        if (sets) radarReport(p, sets);
    });

    // ---- ops: BallSetCommands and BallLocatorCommand -------------------------------------------------------------------
    function wipe(setId) {
        var s = API.state(setId), removed = 0;
        for (var n in s.active) {
            var a = s.active[n], dim = a.dim || home(setId);
            var blk = bare(RPG.world.getBlock(dim, a.x, a.y, a.z));
            if (blk === RPG.blocks.id(API.liveName(setId, Number(n))) || blk === RPG.blocks.id(API.stoneName(setId, Number(n)))) { RPG.world.setBlock(dim, a.x, a.y, a.z, "minecraft:air"); removed++; }
        }
        s.active = {}; s.pending = {}; s.held = {};
        API.save(setId, s);
        return removed;
    }
    RPG.commands.register("ballset", {
        permission: 2, description: "/rpgc ballset scatter|gather|awaken|unawaken <set> confirm | dormancy",
        suggest: function (p, a) {
            if (a.length <= 1) return ["scatter", "gather", "awaken", "unawaken", "dormancy"];
            if (a.length === 2 && a[0] !== "dormancy") return setIds();
            if (a.length === 3 && a[0] !== "dormancy") return ["confirm"];
            return [];
        },
        run: function (p, args) {
            var say = function (t) { if (p) p.tell(t); else RPG.log(t.replace(/&./g, "")); };
            var verb = String(args[0] || ""), setId = String(args[1] || "").toLowerCase();
            if (verb === "dormancy" || verb === "") { setIds().forEach(function (id) { say("&7" + id + ": " + API.dormancyLine(id)); }); return; }
            if (["scatter", "gather", "awaken", "unawaken"].indexOf(verb) < 0) return say("&cUsage: /rpgc ballset scatter|gather|awaken|unawaken <set> confirm | dormancy");
            if (!DB_SETS[setId]) return say("&cUnknown dragon ball set '" + setId + "'. Known sets: " + setIds().join(", "));
            if (args[2] !== "confirm") return say("&eRun &f/rpgc ballset " + verb + " " + setId + " confirm&e to do it.");
            if (verb === "scatter") {
                API.wake(setId, false);
                var r = wipe(setId);
                if (DB_SETS[setId].natural) API.scatter(setId);
                else if (setId === "super" && typeof dbrSuperBallsReturn === "function") dbrSuperBallsReturn([1, 2, 3, 4, 5, 6, 7]);
                say("&aScattered a single fresh " + setId + " set (removed " + r + " placed ball(s)).");
            } else if (verb === "gather") {
                if (!p) return say("Run /rpgc ballset gather as a player: there is nobody to hand the balls to.");
                API.wake(setId, false);
                wipe(setId);
                for (var n = 1; n <= DB_SETS[setId].stars; n++) { p.giveItem(DB_SETS[setId].block(n), 1); }
                var s = API.state(setId); s.held = {}; for (var k = 1; k <= DB_SETS[setId].stars; k++) s.held[k] = true; s.first = true; API.save(setId, s);
                say("&aGathered the " + setId + " set into your inventory.");
            } else if (verb === "awaken") {
                say(API.wake(setId, false) ? "&aWoke the " + setId + " set: its balls are usable and on the radar again." : "&eThe " + setId + " set was not dormant. Nothing to do.");
            } else {
                API.wake(setId, false);
                API.markDormant(setId);
                say("&7Turned the " + setId + " set to stone (" + API.dormancyLine(setId) + "&7).");
            }
            RPG.log("[audit] " + (p ? p.name : "console") + " ran ballset " + verb + " " + setId);
        }
    });
    RPG.commands.register("balllocate", {
        permission: 2, description: "/rpgc balllocate [set]: the exact place of every dragon ball",
        suggest: function (p, a) { return a.length <= 1 ? setIds() : []; },
        run: function (p, args) {
            var say = function (t) { if (p) p.tell(t); else RPG.log(t.replace(/&./g, "")); };
            var want = args[0] ? String(args[0]).toLowerCase() : null;
            if (want && !DB_SETS[want]) return say("&cUnknown dragon ball set '" + want + "'.");
            var rows = {};
            function row(setId, star, text) { (rows[setId] = rows[setId] || []).push([star, text]); }
            setIds().forEach(function (setId) {
                if (want && setId !== want) return;
                var s = API.state(setId);
                for (var n in s.active) { var a = s.active[n]; row(setId, Number(n), "block " + (a.dim || home(setId)) + " " + a.x + " " + a.y + " " + a.z); }
                for (var m in s.pending) row(setId, Number(m), "scatter spot " + home(setId) + " " + s.pending[m].x + " ~ " + s.pending[m].z + " (chunk not loaded yet)");
            });
            var g = graves();
            if (g) g.ballCopies().forEach(function (c) { if (!want || c.ball.set === want) row(c.ball.set, c.ball.star, "grave of " + c.owner + " " + c.dim + " " + c.x + " " + c.y + " " + c.z); });
            RPG.server.players().forEach(function (pl) {
                heldCopies(pl, function (b, kind, order, where) { if (!want || b.set === want) row(b.set, b.star, where + " (" + pl.dimension + " " + Math.floor(pl.x) + " " + Math.floor(pl.y) + " " + Math.floor(pl.z) + ")"); });
            });
            RPG.items.confinedDropped().forEach(function (e) {
                var st = e.stack, b = st && BAG.ballOf(st.id);
                if (b && (!want || b.set === want)) row(b.set, b.star, "dropped item " + e.dimension + " " + Math.floor(e.x) + " " + Math.floor(e.y) + " " + Math.floor(e.z));
            });
            var any = false;
            setIds().forEach(function (setId) {
                if (!rows[setId]) return;
                any = true;
                say("&e" + (DB_SET_TITLES[setId] || setId) + " &7(" + API.dormancyLine(setId).replace(/&./g, "") + ")");
                rows[setId].sort(function (a, b) { return a[0] - b[0]; }).forEach(function (r) { say("&f  " + r[0] + "★ &7" + r[1]); });
            });
            if (!any) say("&7No dragon balls found" + (want ? " for " + want : "") + ".");
        }
    });
})();
