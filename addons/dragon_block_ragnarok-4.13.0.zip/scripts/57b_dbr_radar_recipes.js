// =====================================================================================
//  57b_dbr_radar_recipes.js - crafting every Dragon Radar (57_dragon_balls.js defines them)
// =====================================================================================
//  DragonMine Z's two radars are crafted the way DMZ does it (ShapedDragonRadarRecipeDefinition: observer,
//  chips, radar pieces round the CPU):
//      O C O        O observer, C the radar's chip, G its CPU, P Radar's Piece
//      P G P        Dragon Radar = Earth chip + Earth CPU, Namek Dragon Radar = Namek chip + Namek CPU
//      C P C
//  DMZ leaves the Bi-Dimensional Radar a quest reward and DMZ Ragnarok gives its Super, Black Star and Cerulean
//  radars no recipe. Here they follow the same shape one tier up each, every radar built on the one before it:
//      Bi-Dimensional  Dragon Radar + Namek Dragon Radar + Bi-Dimensional chips / CPU
//      Cerulean        Dragon Radar + hearts of the sea + Bi-Dimensional chips / CPU (the overworld's other set)
//      Black Star      Bi-Dimensional Radar + Black Star chips / CPU (Gete, echo shards, crying obsidian)
//      Super           Black Star Radar + Divine chips / CPU + nether stars (Kikono, Gete blocks)
//  The higher-tier parts are DMZ's own radar parts in their recipes' shapes, a tier up, with DMZ's art recoloured
//  (docs/dmz-spec/tools/make_radar_tints.py): Refined Radar's Piece (gold), Bi-Dimensional (cyan), Black Star
//  (charcoal) and Divine (gold) chips and CPUs.
// =====================================================================================

var DBR_RADAR_PARTS = [
    ["refined_radar_piece", "Refined Radar's Piece"],
    ["t3_radar_chip", "Radar's Chip (Bi-Dimensional)"], ["t3_radar_cpu", "Radar's CPU (Bi-Dimensional)"],
    ["t4_radar_chip", "Radar's Chip (Black Star)"], ["t4_radar_cpu", "Radar's CPU (Black Star)"],
    ["t5_radar_chip", "Radar's Chip (Divine)"], ["t5_radar_cpu", "Radar's CPU (Divine)"]
];
(function () {
    DBR_RADAR_PARTS.forEach((p, i) => {
        RPG.items.define(p[0], { name: p[1], model: "dbr:rpg/item/" + p[0], type: "material", maxStack: 16,
            rarity: i === 0 ? "uncommon" : i < 3 ? "rare" : "epic" });
    });

    // resolved now (RPG.recipes reads names through the previous load's registry, see 17_dmz_recipes.js)
    function ref(n) {
        if (n.indexOf(":") >= 0 || n.charAt(0) === "#") return n;
        let id = RPG.items.id(n);
        if (!id) throw new Error("57b_dbr_radar_recipes.js: unknown item '" + n + "'");
        return "ragnarok_rpg:" + id;
    }
    function shaped(id, pattern, keys, result) {
        let k = {};
        Object.keys(keys).forEach((c) => k[c] = ref(keys[c]));
        RPG.recipes.addShaped("dbr_" + id, pattern, k, { id: ref(result), count: 1 });
    }
    let OBS = "minecraft:observer";

    // ---- DMZ's own radars (bootstrap earth_radar_recipe / namek_radar_recipe) ----
    shaped("dball_radar", ["OCO", "PGP", "CPC"], { O: OBS, C: "t1_radar_chip", G: "t1_radar_cpu", P: "radar_piece" }, "dball_radar");
    shaped("namekdball_radar", ["OCO", "PGP", "CPC"], { O: OBS, C: "t2_radar_chip", G: "t2_radar_cpu", P: "radar_piece" }, "namekdball_radar");

    // ---- parts, a tier up each (shapes of DMZ's radar piece / chip / CPU recipes) ----
    shaped("refined_radar_piece", ["GDG", "PRP", "GDG"], { G: "minecraft:gold_ingot", D: "minecraft:diamond", P: "radar_piece", R: "minecraft:redstone_block" }, "refined_radar_piece");
    shaped("t3_radar_chip", ["ROR", "EPN", "TTT"], { R: "minecraft:redstone_torch", O: OBS, E: "t1_radar_chip", N: "t2_radar_chip", P: "refined_radar_piece", T: "t2_radar_cpu" }, "t3_radar_chip");
    shaped("t3_radar_cpu", ["RCR", "TET", "OCO"], { R: "minecraft:comparator", O: OBS, C: "t3_radar_chip", T: "t2_radar_cpu", E: "minecraft:ender_eye" }, "t3_radar_cpu");
    shaped("t4_radar_chip", ["SXS", "CPC", "STS"], { S: "gete_scrap", X: "minecraft:echo_shard", C: "t3_radar_chip", P: "refined_radar_piece", T: "t3_radar_cpu" }, "t4_radar_chip");
    shaped("t4_radar_cpu", ["RCR", "TGT", "OCO"], { R: "minecraft:comparator", O: "minecraft:crying_obsidian", C: "t4_radar_chip", T: "t3_radar_cpu", G: "gete_ingot" }, "t4_radar_cpu");
    shaped("t5_radar_chip", ["KNK", "CPC", "KTK"], { K: "kikono_block", N: "minecraft:nether_star", C: "t4_radar_chip", P: "refined_radar_piece", T: "t4_radar_cpu" }, "t5_radar_chip");
    shaped("t5_radar_cpu", ["RCR", "TBT", "OCO"], { R: "minecraft:comparator", O: OBS, C: "t5_radar_chip", T: "t4_radar_cpu", B: "gete_block" }, "t5_radar_cpu");

    // ---- the radars past DMZ's two, each on the one before ----
    shaped("fused_dball_radar", ["OCO", "EGN", "CPC"], { O: OBS, C: "t3_radar_chip", G: "t3_radar_cpu", E: "dball_radar", N: "namekdball_radar", P: "refined_radar_piece" }, "fused_dball_radar");
    shaped("cerulean_dball_radar", ["HCH", "PGP", "CRC"], { H: "minecraft:heart_of_the_sea", C: "t3_radar_chip", G: "t3_radar_cpu", P: "refined_radar_piece", R: "dball_radar" }, "cerulean_dball_radar");
    shaped("blackstar_dball_radar", ["OCO", "PGP", "CRC"], { O: "minecraft:crying_obsidian", C: "t4_radar_chip", G: "t4_radar_cpu", P: "refined_radar_piece", R: "fused_dball_radar" }, "blackstar_dball_radar");
    shaped("super_dball_radar", ["NCN", "PGP", "CRC"], { N: "minecraft:nether_star", C: "t5_radar_chip", G: "t5_radar_cpu", P: "refined_radar_piece", R: "blackstar_dball_radar" }, "super_dball_radar");
})();
