// =====================================================================================
//  30_forms.js - what a DMZ transformation LOOKS like (and the non-form buffs)
// =====================================================================================
//  DragonMine Z forms (shared/07_dmz_forms_data.js) are driven by 31_dmz_transform.js:
//  hold G to charge the next form of your selected group, Alt+G to descend, X for the menu.
//  This file turns every DMZ form into an engine EFFECT that carries its look:
//
//    dmzf_<race>_<group>_<form>   one per race form: avatar (model, layers, scale), speed and
//                                 attack-speed attributes. Only one is active at a time.
//    dmzb_<race>                  the race's base body drawn with the form colour names, used
//                                 while charging from base or in a stack form without a form
//                                 (so colours can blend / take the Kaioken tint)
//    dmzs_<group>_<form>          stack forms (Kaioken, Ultimate): no body, speed attributes
//    dmz_aura_<n>                 the DMZ aura (kakarot_aura.png) at size step n
//    dmzp_<race>_<hair>           form editor preview bodies (never given to players)
//
//  Forms ops add or edit in game (/rpgc formeditor) are merged into DMZ_FORMS by shared/07 before
//  this file runs, so they get their dmzf_ effects here like every default form.
//
//  Every form avatar paints with colour names the transform script sets per player:
//      fBody1 fBody2 fBody3 fHair fEye1 fEye2      (form value, else the player's own)
//  and look values dmzModel (geo file: hbuffed / hbuffed_slim / hbuffed_fem...), dmzSlim
//  ("" | "slim", SSJ4 fur sheets) and dmzGender (android overlay). DMZ's per-model texture
//  sets come from SkinGathererProvider / DMZSkinLayer (spec 02 section 4.3 / 4.4).
// =====================================================================================

// ---- Auras ---------------------------------------------------------------------------
// DMZ's aura sheets are 4 frames side by side. color: "#hex" or a player colour name.
var AURA_KAKAROT = DMZ_TEX + "races/aura/kakarot_aura.png";     // the classic flame aura (every DMZ form)
var AURA_SPIKY = DMZ_TEX + "races/aura/kakarot_cross.png";      // DMZ's top-down sheet (kept for other scripts)
var AURA_GOD = DMZ_TEX + "races/aura/god_aura.png";             // the calm god-ki aura
var AURA_GOD_SPIKY = DMZ_TEX + "races/aura/god_cross.png";

function aura(texture, color, scale, alpha) {
    return { texture: texture, frames: 4, speed: 10, color: color, scale: scale || 1.0, alpha: alpha || 0.8 };
}

// ---- Shared helpers (kept for other scripts / addons) ---------------------------------

// Spends ki every second; powers down when it runs out.
function drainForm(player, effectId, kiPerSecond) {
    if (kiPerSecond > 0 && !player.consume("ki", kiPerSecond)) {
        player.actionbar("&cOut of ki! You power down.");
        sfx(player, "no_ki_form", 0.8, 1);
        player.removeEffect(effectId);
    }
}

// A one-shot transformation flourish for non-DMZ buffs (fusions, items). DMZ forms play their
// transf.* animation WHILE charging and only transform_on when done (31_dmz_transform.js).
function transformFx(player, animation, sound, shout, flashParticle) {
    act(player, animation, 40);
    sfx(player, sound || "transform_on", 1, 1);
    burst(player, flashParticle || "minecraft:end_rod", 30, 0.8, 0.2);
    if (shout) player.title(shout, "");
}

// Every DMZ form group by race ("saiyan.ssgrades" -> ["supersaiyan", ...]); filled below.
var FORM_GROUPS = {};

// Legacy one-step form (effect + skill, cast to toggle) for addons that still want one.
// The DMZ forms do NOT use this.
function defineForm(id, spec) {
    let group = spec.group || spec.race || "universal";
    (FORM_GROUPS[group] = FORM_GROUPS[group] || []).push(id);
    RPG.effects.define(id, {
        name: spec.name, color: spec.color, maxStacks: 1, stats: spec.stats, attributes: spec.attributes,
        avatar: spec.avatar, aura: spec.aura, tickInterval: 20,
        onTick(player) { drainForm(player, id, spec.drain || 0); if (spec.onTick) spec.onTick(player); },
        onRemove(player) { if (spec.onRemove) spec.onRemove(player); }
    });
    RPG.skills.define(id, {
        name: spec.skillName || String(spec.name || id).replace(/&./g, ""),
        description: (spec.description || "") + " Cast again to power down.",
        requires: merge({ level: spec.level || 1 }, spec.race ? { race: spec.race } : {}),
        skillPointCost: spec.skillPointCost || 2, cost: { ki: spec.cost || 20 }, cooldown: 40,
        canCast(player) { return spec.canCast && !player.hasEffect(id) ? spec.canCast(player) : true; },
        onCast(ctx) {
            let p = ctx.player;
            if (p.hasEffect(id)) { p.removeEffect(id); return false; }
            FORM_GROUPS[group].forEach((other) => { if (other !== id) p.removeEffect(other); });
            p.addEffect(id, -1);
            transformFx(p, spec.animation || "transf.generic", spec.sound, spec.shout, spec.particle);
            return true;
        }
    });
}

// =====================================================================================
//  DMZ form looks
// =====================================================================================
var DMZ_LOOK = (function () {
    var FD = DMZ_FORMS;
    var OUR = DMZ_DATA.OUR;                       // DMZ race -> our race id
    var COLOR_NAMES = ["fBody1", "fBody2", "fBody3", "fHair", "fEye1", "fEye2"];

    function effectId(race, f) { return "dmzf_" + race + "_" + (f.group === "oozaru" ? "o" : f.group) + "_" + f.id; }
    function baseId(race) { return "dmzb_" + race; }
    function stackId(f) { return "dmzs_" + f.group + "_" + f.id; }

    // ---- geo file for a model key (DMZPlayerModel.java:139-279) ----
    function variant(bodyType) {
        let t = String(bodyType || "");
        return t.indexOf("female") === 0 ? "female" : t.indexOf("slim") >= 0 ? "slim" : "male";
    }
    function modelFile(race, f, bodyType, bodyModel) {
        let v = variant(bodyType), fem = v === "female";
        let base = { human: bodyModel || "human", saiyan: bodyModel || "human", glind: bodyModel || "human", namekian: "human",
            frostdemon: "frostdemon", bioandroid: f ? "bioandroid_perfect" : "bioandroid", majin: bodyModel || "majin" }[race] || "human";
        let key = f ? f.model || "" : "";
        if (!key) return base;
        let three = function (m, s, w) { return fem ? w : v === "slim" ? s : m; };
        switch (key) {
            case "buffed": case "ssj4gt": return three("hbuffed", "hbuffed_slim", "hbuffed_fem");
            case "buffedg3": case "ssj4d": return three("hbuffedg3", "hbuffed_slimg3", "hbuffed_femg3");
            case "4arms": return three("h4arms", "h4armsslim", "h4armsfem");
            case "namekian_buffed": case "namekian_orange": return "hbuffed";
            case "majin_kid": case "majin_evil": return fem ? "majin_slim" : "human_slim";
            case "majin_super": return fem ? "majin_slim" : "human";
            case "majin_ultra": return fem ? "hbuffed_fem" : "hbuffed";
            case "frostdemon_final": case "frostdemon_mecha": return "frostdemon";
            case "trascended": return fem ? "trascended_fem" : "trascended";
            case "finalbase": return base;
            default: return key;               // oozaru, janemba_*, frostdemon_*, bioandroid_*, glind*
        }
    }

    // ---- faces ----
    function humanFace(f) {
        let fc = "humansaiyan/faces/humansaiyan_", out = [];
        out.push(lay(fc + "eye_{eyeStyle}_0", (f && f.sclera) || "#FFFFFF", ["head"]));
        out.push(lay(fc + "eye_{eyeStyle}_1", "fEye1", ["head"]));
        out.push(lay(fc + "eye_{eyeStyle}_2", "fEye2", ["head"]));
        out.push(lay(fc + "eye_{eyeStyle}_3", "fHair", ["head"]));                    // eyebrows = hair colour
        if (f && f.hair === "ssj3") out.push(lay("humansaiyan/faces/ssj3eyebrows_eye_{eyeStyle}", "fBody1", ["head"]));
        if (f && f.ssj4) out.push(lay("humansaiyan/faces/ssj4_eyes_{eyeStyle}", f.furHair ? "fHair" : "fBody2", ["head"]));
        if (f && f.shiyoken) {
            out.push(lay("humansaiyan/faces/shiyoken_eye0", "#FFFFFF", ["head"]));
            out.push(lay("humansaiyan/faces/shiyoken_eye1", "fEye1", ["head"]));
        }
        out.push(lay(fc + "nose_{nose}", "fBody1", ["head"]));
        out.push(lay(fc + "mouth_{mouth}", "fBody1", ["head"]));
        return out;
    }
    // DMZ strand hair (shared/11_dmz_hair.js): the form's hairType picks the slot of the player's preset
    // (no hairType = the base style, "empty" = none); the hair_base scalp is drawn under it (DMZSkinLayer).
    function hairSlot(f) {
        if (f && (f.hair === "empty" || f.model === "oozaru")) return "";
        return f && f.hair ? f.hair : "base";
    }
    function hairCap(f) {
        return hairSlot(f) ? [hairCapLayer("fHair")] : [];
    }
    function hairBlock(race, f) {
        if (race !== "human" && race !== "saiyan" && race !== "glind") return null;
        // a form hair colour (SSJ gold...) paints every strand, strand colours included (HairStyleResolver force)
        // Broly's tiara paints Ikari's hair cyan (HelmetFormLook): forced only while it's worn ("dmzHelmF", 31_dmz_transform.js)
        var forced = !!(f && f.c && f.c.hair);
        if (!forced && f && DBR_QUIRKS_DATA.helmetLook(f.id) && DBR_QUIRKS_DATA.helmetLook(f.id).hair) forced = "{dmzHelmF}";
        return DMZ_HAIR.avatarHair(hairSlot(f), "fHair", forced);
    }
    // a form's extra overlays: a DMZ race sheet or any pack picture ("ns:path.png"), a colour, optional bones
    function extra(f) {
        return f && f.layers ? f.layers.map(function (l) {
            var o = l[0].indexOf(":") > 0 ? { texture: l[0], color: l[1] } : lay(l[0], l[1]);
            if (l[2] && l[2].length) o.bones = l[2];
            return o;
        }) : [];
    }

    // ---- per family ----
    function oozaruLayers() {
        return [lay("humansaiyan/oozaru_layer1", "fBody2"), lay("humansaiyan/oozaru_layer2", "fBody1"), lay("humansaiyan/oozaru_layer3", "#FFFFFF")];
    }
    function humanLayers(race, f) {
        let key = f ? f.model || "" : "", out = [];
        if (key === "glindtrueform") { out.push(lay("glind/trueform_layer1", "fBody1")); out.push(lay("glind/trueform_layer2", "fBody2")); }
        else {
            out.push(lay("humansaiyan/bodytype_{bodyType}_layer1", "fBody1"));
            if (key === "glinddark") { out.push(lay("glind/darkking_layer2", "fBody2")); out.push(lay("glind/darkking_layer3", "fBody3")); }
            if (key === "trascended") out.push(lay("glind/trascended_layer2", "fBody2"));
        }
        if (race === "saiyan" || (race === "glind" && f && f.ssj4)) TAIL_LAYERS("fBody2").forEach((l) => out.push(l));
        if (f && f.ssj4) out.push(lay("humansaiyan/ssj4" + f.ssj4 + "{dmzSlim}_layer1", f.furHair ? "fHair" : "fBody2"));
        if (f && f.android) out.push(lay("{dmzGender}_android", "#FFFFFF"));
        extra(f).forEach((l) => out.push(l));
        humanFace(f).forEach((l) => out.push(l));
        hairCap(f).forEach((l) => out.push(l));
        return out;
    }
    function namekLayers(f) {
        let fc = "namekian/faces/namekian_";
        let out = [lay("namekian/bodytype_{bodyType}_layer1", "fBody1"), lay("namekian/bodytype_{bodyType}_layer2", "fBody2"),
            lay("namekian/bodytype_{bodyType}_layer3", "fBody3"), lay("namekian/bodytype_{bodyType}_layer4", "fHair")];
        extra(f).forEach((l) => out.push(l));
        [lay(fc + "eye_{eyeStyle}_0", "#FFFFFF", ["head"]), lay(fc + "eye_{eyeStyle}_1", "fEye1", ["head"]), lay(fc + "eye_{eyeStyle}_2", "fEye2", ["head"]),
         lay(fc + "eye_{eyeStyle}_3", "fBody1", ["head"]), lay(fc + "nose_{nose}", "fBody1", ["head"]), lay(fc + "mouth_{mouth}", "fBody1", ["head"])].forEach((l) => out.push(l));
        return out;
    }
    function frostLayers(f) {
        let key = f ? f.model || "frostdemon" : "frostdemon", out = [];
        let bulky = key === "frostdemon_second" || key === "frostdemon_third" || (key === "frostdemon" && (!f || f.id === "second"));
        if (bulky) {
            let p = "frostdemon/" + (key === "frostdemon_third" ? "thirdform_bodytype" : "bodytype") + "_{bodyType}_layer";
            out.push(lay(p + "1", "fBody1")); out.push(lay(p + "2", "fBody2")); out.push(lay(p + "3", "fBody3")); out.push(lay(p + "4", "fHair"));
            out.push(lay(p + "5", "#E67D40", null, "bodyType=0"));                 // the gems: body type 0 only
        } else {
            let p = "frostdemon/" + (key === "frostdemon_fifth" ? "fifth_bodytype" : "finalform_bodytype") + "_{bodyType}_layer";
            out.push(lay(p + "1", "fBody1"));
            out.push(lay(p + "2", "fHair", null, "bodyType!=1"));
            out.push(lay(p + "2", "fBody2", null, "bodyType=1"));
            out.push(lay(p + "3", "fBody3", null, "bodyType=1"));
            out.push(lay(p + "4", "fHair", null, "bodyType=1"));
            out.push(lay(p + "3", "fHair", null, "bodyType=2"));
        }
        extra(f).forEach((l) => out.push(l));
        let fc = "frostdemon/faces/frostdemon_";
        out.push(lay(fc + "eye_{eyeStyle}_0", "#FFFFFF", ["head"]));
        out.push(lay(fc + "eye_{eyeStyle}_1", "fEye1", ["head"]));
        out.push(lay(fc + "eye_{eyeStyle}_2", "fEye2", ["head"]));
        out.push(lay(fc + "nose_{nose}", "fBody1", ["head"]));
        out.push(lay(key === "frostdemon_fifth" ? "frostdemon/faces/frostdemon_fifth_mouth" : fc + "mouth_{mouth}", "fBody1", ["head"]));
        return out;
    }
    function bioLayers(f) {
        let key = f ? f.model || "bioandroid" : "bioandroid";
        let phase = !f ? "base" : key === "bioandroid_semi" ? "semiperfect" : "perfect";
        let p = "bioandroid/" + phase + "_{bodyType}_layer";
        let out = [lay(p + "1", "fBody1"), lay(p + "2", "fBody2"), lay(p + "3", "fBody3"), lay(p + "4", "fHair")];
        if (!f || !f.noStinger) out.push(lay(p + "5", "#EDD747"));
        let xenoModel = key === "bioandroid_xeno" || key === "bioandroid_xenofp";
        if ((f && f.xeno) || xenoModel) out.push(lay("bioandroid/xenoform_layer1", "#FFFFFF"));
        if (xenoModel) out.push(lay("bioandroid/xenoform_layer2", "#FFFFFF"));
        extra(f).forEach((l) => out.push(l));
        out.push(lay("bioandroid/faces/" + phase + "_eye_layer0", "fEye2", ["head"]));
        out.push(lay("bioandroid/faces/" + phase + "_eye_layer1", "fEye1", ["head"]));
        return out;
    }
    function majinLayers(f) {
        let key = f ? f.model || "" : "", out = [];
        let jf = "majin/faces/janemba_";
        if (key.indexOf("janemba_") === 0) {
            if (key === "janemba_super") ["1", "2", "3"].forEach((n, i) => out.push(lay("majin/janembasuper_0_male_layer" + n, ["fBody1", "fBody2", "fBody3"][i])));
            else if (key === "janemba_fat") { out.push(lay("majin/janembafat_0_male_layer1", "fBody1")); out.push(lay("majin/janembafat_0_male_layer2", "fBody2")); }
            else out.push(lay("majin/janemba_0_male_layer1", "fBody1"));
            out.push(lay(jf + "eye_0", "#FFFFFF", ["head"]));
            out.push(lay(jf + "eye_1", "fEye1", ["head"]));
            out.push(lay(jf + "mouth", "fBody1", ["head"]));
            return out;
        }
        out.push(lay("majin/bodytype_{bodyType}_layer1", "fBody1"));
        out.push(lay("majin/bodytype_{bodyType}_layer2", "fBody2"));
        out.push(lay("majin/bodytype_{bodyType}_layer3", "fBody3"));
        extra(f).forEach((l) => out.push(l));
        let fc = "majin/faces/majin_";
        out.push(lay(fc + "eye_{eyeStyle}_0", "#FFFFFF", ["head"]));
        out.push(lay(fc + "eye_{eyeStyle}_1", "fEye1", ["head"]));
        out.push(lay(fc + "eye_{eyeStyle}_2", "fEye2", ["head"]));
        out.push(lay(fc + "nose_{nose}", "fBody1", ["head"]));
        out.push(lay(fc + "mouth_{mouth}", "fBody1", ["head"]));
        return out;
    }

    // default colours: the race's, with the form colour names starting at the race colours
    function defaults(race) {
        let our = OUR[race] || race, c = merge(RACE_COLORS[our] || {}, RACE_LOOKS[our] || {});
        c.fBody1 = c.body1; c.fBody2 = c.body2; c.fBody3 = c.body3; c.fHair = c.hair; c.fEye1 = c.eyes;
        c.fEye2 = race === "bioandroid" ? "#FFFFFF" : c.eyes;
        c.dmzModel = modelFile(race, null, c.bodyType, c.bodyModel); c.dmzSlim = ""; c.dmzGender = "male";
        return c;
    }

    // which of the model's own tail bones show (BoneVisibilityHandler): tail1 = the tail, tail1m = the female
    // Majin's head tentacle (and Time Power: Dark King's), hidden on everyone else
    function hiddenBones(race, f) {
        let key = f ? f.model || "" : "";
        if (key === "oozaru") return { hide: ["armor*"] };
        if (race === "saiyan" || race === "frostdemon" || race === "bioandroid") return { hide: ["armor*", "tail1m"] };
        if (race === "glind") {
            if (key === "glinddark") return { hide: ["armor*"].concat(PLAIN_TAIL_BONES) };
            if (key === "glindtrueform" || key === "trascended" || (f && f.ssj4)) return { hide: ["armor*", "tail1m"] };
        }
        if (race === "majin") {
            if (key === "janemba_super" || key === "janemba_fat") return { hide: ["armor*"] };
            // Kid, Super and Ultra keep the female tentacle; Evil Majin never shows it
            if (key === "majin_evil") return { hide: ["armor*", "tail*"] };
            return { hide: ["armor*"].concat(PLAIN_TAIL_BONES), when: MAJIN_FEMALE_TENTACLE };
        }
        return { hide: ["armor*", "tail*"] };
    }

    // a form's dropped-in GeckoLib model (form editor "Model" tab, shared/07 geo): "body" replaces the avatar with the
    // model, its texture and (optionally) its own animation file; "overlay" draws it over the form's body, following the
    // avatar bones it names (same-named bones copy their pose) or attached whole to one bone (default "body")
    function customGeo(race, f, base) {
        var g = f.geo, scale = (g.scale || 1) * (f.scale ? f.scale[1] : FD.D.scale);
        if (g.mode === "overlay") {
            var part = { model: g.model, texture: g.texture, color: g.color || "#FFFFFF" };
            if (g.bones && g.bones.length) part.bones = g.bones; else { part.attach = g.attach || "body"; if (g.scale) part.scale = g.scale; }
            if (g.glow) part.emissive = true;
            base.parts = (base.parts || []).concat([part]);
            return base;
        }
        var out = { model: g.model, texture: g.texture, colors: base.colors, scale: scale, headLook: true, hideBones: ["armor*"],
            animation: g.anim || base.animation, animations: g.anim ? [g.anim] : base.animations,
            states: g.anim ? { idle: "idle", walk: "walk", run: "run", fly: "fly", jump: "jump", fall: "fall", swim: "swim", sneak: "sneak" } : base.states,
            animLayers: g.anim ? undefined : base.animLayers, rightHand: base.rightHand, leftHand: base.leftHand };
        if (!out.animLayers) delete out.animLayers;
        if (base.outline) out.outline = base.outline;
        return out;
    }
    function avatarFor(race, f) {
        var built = avatarFor0(race, f);
        return f && f.geo ? customGeo(race, f, built) : built;
    }
    function avatarFor0(race, f) {
        let layers, states = BASE_STATES, noTattoo = false, hb = hiddenBones(race, f);
        if (f && f.model === "oozaru") {
            layers = oozaruLayers(); noTattoo = true;
            states = merge(BASE_STATES, { idle: "base.idle_ozaru", walk: "base.walk_ozaru", run: "base.walk_ozaru" });
        } else if (race === "human" || race === "saiyan" || race === "glind") layers = humanLayers(race, f);
        else if (race === "namekian") layers = namekLayers(f);
        else if (race === "frostdemon") layers = frostLayers(f);
        else if (race === "bioandroid") layers = bioLayers(f);
        else layers = majinLayers(f);
        let scale = f ? f.scale[1] : (FD.RACE_SCALE[race] || FD.D.scale);
        // race parts (ears, antennae, horns, Majin tentacles) only while the form keeps the base head bones
        let parts = !f || f.keepHead ? headParts(OUR[race] || race, race === "frostdemon" ? "#1A1A1A" : "fBody1") : [];
        return avatar({ model: "{dmzModel}", layers: layers, colors: defaults(race), scale: scale, states: states, hideBones: hb.hide, hideWhen: hb.when,
                        parts: parts, noTattoo: noTattoo,
                        tailColor: race === "saiyan" && !(f && f.model === "oozaru") ? "fBody2" : null, hair: hairBlock(race, f),
                        outline: outlineFor(f) });
    }

    // DMZ's transformation outline (TransformationPostShaderManager): drawn by DMZ's own post chain round the
    // silhouette (shared/07c_dmz_outline.js, "mask: true"). Each viewer can switch outlines off in the V menu's
    // Config (client/scripts/09_dmz_options.js -> RPG.avatar.outlines).
    function outlineFor(f) {
        var o = f && f.ol;
        if (!o) return null;
        return DMZ_OUTLINE.spec(o.c, o.c2, o.m, o.t, o.fire, o.bg);
    }

    // ---- effects ----
    function speedAttrs(f) {
        let a = {};
        if (f.spd !== 1) a["minecraft:generic.movement_speed"] = { amount: f.spd - 1, operation: "multiply_total" };
        if (f.atk !== 1) a["minecraft:generic.attack_speed"] = { amount: Math.max(0.25, f.atk) - 1, operation: "multiply_total" };
        return a;
    }
    // (again after the form editor applies a save: 32_dbr_form_editor.js)
    function defineFormEffects() {
    Object.keys(FORM_GROUPS).forEach(function (k) { if (k.indexOf("stack.") !== 0) delete FORM_GROUPS[k]; });
    Object.keys(FD.GROUPS).forEach(function (race) {
        RPG.effects.define(baseId(race), { name: "Base", hidden: true, keepOnDeath: false, avatar: avatarFor(race, null) });
        FD.GROUPS[race].forEach(function (g) {
            FORM_GROUPS[race + "." + g.id] = g.forms.map((f) => f.id);
            g.forms.forEach(function (f) {
                RPG.effects.define(effectId(race, f), {
                    name: f.n, color: f.aura || "#FFFFFF", hidden: true, beneficial: true,
                    avatar: avatarFor(race, f), attributes: speedAttrs(f)
                });
            });
        });
    });
    }
    defineFormEffects();
    FD.STACKS.forEach(function (g) {
        FORM_GROUPS["stack." + g.id] = g.forms.map((f) => f.id);
        g.forms.forEach(function (f) {
            RPG.effects.define(stackId(f), { name: g.n + " " + f.n, color: f.aura || "#FFFFFF", hidden: true, beneficial: true, attributes: speedAttrs(f) });
        });
    });

    // Form editor previews (client/scripts/70_form_editor.js): a plain body per race and hair slot, so a form
    // that is new or edited (and has no effect of its own until /rpg reload) still shows its model, colours and
    // hair in the editor. Never given to players.
    var PREVIEW_HAIR = ["base", "ssj", "ssj2", "ssj3", "ssj4", "empty"];
    Object.keys(FD.GROUPS).forEach(function (race) {
        let slots = race === "human" || race === "saiyan" || race === "glind" ? PREVIEW_HAIR : ["base"];
        slots.forEach(function (h) {
            let proxy = { id: "preview", hair: h, model: "", scale: [FD.D.scale, FD.D.scale, FD.D.scale], c: { hair: "#FFFFFF" }, keepHead: 1 };
            RPG.effects.define("dmzp_" + race + "_" + h, { name: "Form preview", hidden: true, beneficial: true, avatar: avatarFor(race, proxy) });
        });
    });

    // DMZ aura (AuraRenderer 2D): kakarot_aura, 4 frames at 10 fps; height = 2 x 2.2 x auraScale x modelScale.
    // One effect per 0.5-block size step (the engine has one static size per aura).
    var AURA_MIN = 3.0, AURA_STEP = 0.5, AURA_STEPS = 60;
    for (let i = 0; i < AURA_STEPS; i++) {
        RPG.effects.define("dmz_aura_" + i, {
            name: "Aura", hidden: true,
            // the sheet is the form's 2D aura type (look value dmzAuraTex, 31_dmz_transform.js; kakarot by default)
            aura: DMZ_AURA.spec({ texture: "{dmzAuraTex}", frames: 4, speed: 10, color: "dmzAura", alpha: 0.85, height: AURA_MIN + AURA_STEP * i, aspect: 1, priority: 10 })   // 3D / flight / boost: 29_dmz_auras.js
        });
    }
    function auraStep(height) { return Math.max(0, Math.min(AURA_STEPS - 1, Math.round((height - AURA_MIN) / AURA_STEP))); }

    return { COLOR_NAMES: COLOR_NAMES, effectId: effectId, baseId: baseId, stackId: stackId, modelFile: modelFile, variant: variant,
        defaults: defaults, auraStep: auraStep, AURA_STEPS: AURA_STEPS, defineFormEffects: defineFormEffects };
})();

// Markers other scripts check (40_skills.js: Kaioken attack needs "kaioken", Oozaru techniques need "oozaru").
RPG.effects.define("kaioken", { name: "&cKaioken", color: "#FF4040", hidden: true });
RPG.effects.define("oozaru", { name: "&6Oozaru", color: "#A0522D", hidden: true });
RPG.effects.define("golden_oozaru", { name: "&6&lGolden Oozaru", color: "#FFC83D", hidden: true });

// King Kai teaches "kaioken" (60_npcs_dialogue.js): learning it gives the DMZ stack skill level 1.
RPG.skills.define("kaioken", {
    name: "Kaioken", icon: "dbr:textures/skill/kaioken.png", passive: true, noLearn: true,
    description: "King Kai's technique. A stack form: select it in the form menu (X) and hold the stack key to go x2 -> x20. Upgrade it with TP in the skills screen.",
    onLearn(player) {
        if (typeof DMZ_SKILLS !== "undefined" && DMZ_SKILLS.level(player, "kaioken") < 1) DMZ_SKILLS.setLevel(player, "kaioken", 1);
    }
});

// Old Kai's ritual (70_quests.js reward): unlocks one more level of potential (power release cap).
RPG.skills.define("potential_unleashed", {
    name: "Potential Unleashed", icon: "dbr:textures/skill/potential_unleashed.png", passive: true, noLearn: true,
    description: "Old Kai awakened your hidden potential: +1 Potential Unlock level (higher power release cap).",
    onLearn(player) {
        if (typeof DMZ_SKILLS === "undefined") return;
        let lvl = DMZ_SKILLS.level(player, "potentialunlock");
        if (lvl < 10) DMZ_SKILLS.setLevel(player, "potentialunlock", lvl + 1);
    }
});

// =====================================================================================
//  Non-form buffs (no skill, given by items, quests and techniques)
// =====================================================================================
RPG.effects.define("well_fed", {
    name: "Well Fed",
    color: "#FFD080",
    stats: { vitality: 5 },
    onApply(player, stacks) { player.addResource("stamina", 1000); }
});

// Potara earrings (50_items.js): two warriors become one, for 5 minutes.
RPG.effects.define("potara_fusion", {
    name: "&b&lPotara Fusion",
    color: "#3FA9FF",
    stats: { strength: 60, strike: 60, kipower: 60, resistance: 40, vitality: 40, energy: 40 },
    aura: aura(AURA_KAKAROT, "#7FD4FF", 1.1),
    onApply(player, stacks) { player.title("&b&lFUSION!", "&7Potara Fusion - 5 minutes"); },
    onRemove(player, stacks) { player.tell("&7The fusion wears off."); sfx(player, "transform_off", 1, 0.8); }
});

// The Fusion Dance (40_skills.js): weaker than Potara but needs no earrings.
RPG.effects.define("dance_fusion", {
    name: "&6Metamoran Fusion",
    color: "#FF9A2E",
    stats: { strength: 40, strike: 40, kipower: 40, resistance: 25, vitality: 25 },
    aura: aura(AURA_KAKAROT, "#FFB347", 1.05),
    onRemove(player, stacks) { player.tell("&7Your 30 minutes... er, 3 minutes are up."); }
});

// The Zenkai Lotus and a Saiyan's comeback (90_hooks.js).
RPG.effects.define("zenkai_boost", {
    name: "&6Zenkai",
    color: "#FFAA00",
    stats: { strength: 10, vitality: 10, resistance: 5 }
});
