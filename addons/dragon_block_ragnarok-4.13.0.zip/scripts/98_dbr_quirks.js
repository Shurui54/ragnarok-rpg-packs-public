// =====================================================================================
//  98_dbr_quirks.js - DragonMine Z's little quirks and easter eggs
// =====================================================================================
//  Ported from DragonMine Z (GPL-3.0) - behaviour and numbers copied on purpose, see NOTICE.md.
//  Elsewhere (shared tables in shared/27_dbr_quirks.js):
//   - Broly's tiara turns Ikari's hair cyan and the Mutant auras gold / lime (HelmetFormLook):
//     31_dmz_transform.js, 30_forms.js, 11_dmz_hair.js, client/scripts/43_dmz_aura_shader.js.
//   - The hair shows under the Super Hero and Broly helmets (helmetsThatKeepHair): 11_dmz_hair.js.
//   - Halloween evil clones (70_dmz_events.js), the 1% "YUSE" / "SHOKKOH" memory minigame codes
//     (13_dmz_minigames.js), only the pure of heart ride the Nimbus (56_vehicles.js).
//  Here:
//   - Halloween (HalloweenPumpkinLayer): on October 31st every master wears a carved pumpkin.
//   - Rare spawn variants (GiantFishEntity / GiantTurtleEntity / SabertoothEntity / NamekFrogEntity
//     finalizeSpawn): a giant fish is the special golden one 3% of the time; turtles, sabertooths
//     and frogs pick one of their three skins.
//   - Namekian frogs croak now and then and laugh (froglaugh) one time in five when they die; the
//     Ginyu frog (NamekFrogGinyuEntity) is its own frog: skin 0, Ginyu's poses, 40 HP.
//   - Akkuman hits evil hearts twice as hard (AkkumanEntity: +100% attack damage vs EVIL alignment).
//   - Hell's ogres only go after evil players and call the others when one is hit (SagaOgreEntity).
//   - Kamikaze: a Saibaman at 25% health has a 5% chance (Chaoz 50%, never as a spar partner) to cling
//     to the nearest player's back and blow up 3 s later (SagaSaibamanEntity / ChaozEntity).
//   - The Invisible Man is always invisible (InvisibleManEntity.setInvisible(true)).
//   - DMZ's death lines (DMZDamageSource / MainDamageTypes + en_us.json): "%1$s was vaporized by
//     %2$s's Kamehameha", "...battered into oblivion by %2$s's Meteor Combination" and the rest.
//  Not ported (tied to real people's accounts): the beta testers' calm aura particles and divine
//  sparkles (ClientStatsEvents, BetaWhitelist), their larger tattoo canvas (SkinPixels), Red Ribbon
//  soldiers wearing random beta testers' skins (RedRibbonSoldierEntity) and the beta whitelist kick.
// =====================================================================================
var DBR_QUIRKS_CFG = RPG.config.define("dbr_quirks", {
    halloween: { default: "auto", options: ["auto", "on", "off"],
        comment: "auto: October 31st, like DragonMine Z. on / off force the Halloween pumpkins and evil clones (testing)" },
    deathMessages: { default: true, comment: "DragonMine Z's death lines for ki attacks and strikes" }
});

var DBR_QUIRKS = (function () {
    var Q = DBR_QUIRKS_DATA;
    function syncForce() { Q.force.halloween = String(DBR_QUIRKS_CFG.get("halloween", "auto")); }
    syncForce();
    DBR_QUIRKS_CFG.onChange(syncForce);

    function alignment(p) { var a = Number(p.getVar("dmz_alignment", 100)); return isNaN(a) ? 100 : a; }
    function evil(p) { return alignment(p) <= 40; }                      // AlignmentBand.EVIL
    function survival(p) { var g = String(p.getGameMode()); return g !== "creative" && g !== "spectator"; }
    function dmzId(m) { return typeof DMZ_SAGA !== "undefined" && DMZ_SAGA.dmzId ? DMZ_SAGA.dmzId(m) || "" : ""; }

    // ---------------------------------------------------------------------------------
    //  Halloween: a carved pumpkin on every master's head (HalloweenPumpkinLayer)
    // ---------------------------------------------------------------------------------
    var MASTER_NPC = {};
    Object.keys(DMZ_MASTERS_DATA.MASTERS).forEach(function (id) { MASTER_NPC[DMZ_MASTERS_DATA.MASTERS[id].npc] = true; });
    RPG.every(100, function () {
        var on = Q.halloween(), seen = {};
        RPG.server.players().forEach(function (p) {
            RPG.world.entitiesNear(p.dimension, p.x, p.y, p.z, 96, "ragnarok_rpg:npc").forEach(function (e) {
                if (seen[e.uuid] || !MASTER_NPC[e.rpgId]) return;
                seen[e.uuid] = true;
                var has = e.hasTag("dbr_halloween");
                if (on && !has) { e.setEquipment("head", "minecraft:carved_pumpkin"); e.addTag("dbr_halloween"); }
                else if (!on && has) { e.setEquipment("head", ""); e.removeTag("dbr_halloween"); }
            });
        });
    });

    // ---------------------------------------------------------------------------------
    //  Spawn variants (finalizeSpawn): rolled once, the first second a base mob is alive
    // ---------------------------------------------------------------------------------
    var VARIANTS = {
        giant_fish: function () { return Math.random() < 0.03 ? 3 : Math.floor(Math.random() * 3); },   // SPECIAL_CHANCE 0.03
        giant_turtle: function () { return Math.floor(Math.random() * 3); },
        sabertooth: function () { return Math.floor(Math.random() * 3); },
        namek_frog: function () { return Math.floor(Math.random() * 3); }
    };
    function rollVariant(mob) {
        var base = String(mob.rpgId || "");
        if (!VARIANTS[base] || mob.hasTag("dbr_variant")) return;
        mob.addTag("dbr_variant");
        var n = VARIANTS[base]();
        if (n > 0) mob.transform(base + "_" + n, { heal: false });
    }

    // ---------------------------------------------------------------------------------
    //  Namekian frogs: croaks (getAmbientSound: frogsound1-3) and a 1-in-5 death laugh
    // ---------------------------------------------------------------------------------
    function frogTick(mob, seconds) {
        rollVariant(mob);
        // Mob ambient sounds come every ~6 s on average (interval 80 ticks + the rising per-tick roll)
        if (Math.random() < 1 / 6) sfx(mob, "frogsound" + (1 + Math.floor(Math.random() * 3)), 1, 1 + (Math.random() - Math.random()) * 0.2);
    }
    function frogDeath(mob) {
        if (Math.random() < 0.2) sfx(mob, "froglaugh", 1, 1);
    }

    // ---------------------------------------------------------------------------------
    //  Akkuman: double melee damage against evil players
    // ---------------------------------------------------------------------------------
    RPG.on("hurt", function (e) {
        var a = e.attacker, t = e.target;
        if (!a || a.isPlayer() || !t || !t.isPlayer()) return;
        if (KAMIKAZE[a.uuid]) { e.cancel(); return; }                     // doHurtTarget: false while exploding
        if (e.kind !== "melee") return;
        if ((a.rpgId === "akkuman" || dmzId(a) === "saga_akkuman") && evil(t.asPlayer())) e.amount = e.amount * 2;
    });

    // ---------------------------------------------------------------------------------
    //  Ogres: NearestAttackableTargetGoal(Player, evil only) + HurtByTargetGoal.setAlertOthers
    // ---------------------------------------------------------------------------------
    function isOgre(m) { var r = String(m.rpgId || ""); return r === "ogre" || r === "ogre_red" || /^saga_ogre/.test(dmzId(m)); }
    function ogreTick(mob) {
        var t = mob.target;
        if (t && t.isAlive()) return;
        var best = null, bestD = 21;
        mob.nearby(20, { players: true }).forEach(function (e) {
            var p = e.asPlayer();
            if (!p || !p.alive || !survival(p) || !evil(p) || !mob.canSee(e)) return;
            var d = mob.distanceTo(e);
            if (d < bestD) { best = e; bestD = d; }
        });
        if (best) mob.target = best;
    }
    function ogreHurt(mob, attacker) {
        if (!attacker || !attacker.isAlive() || attacker.uuid === mob.uuid) return;
        var ap = attacker.asPlayer();
        if (ap && !survival(ap)) return;
        mob.nearby(20, { rpg: true }).forEach(function (o) {
            if (!isOgre(o) || Math.abs(o.y - mob.y) > 10) return;
            var ot = o.target;
            if (!ot || !ot.isAlive()) o.target = attacker;
        });
    }

    // ---------------------------------------------------------------------------------
    //  Kamikaze: Saibamen and Chaoz cling to a player's back and explode
    // ---------------------------------------------------------------------------------
    var KAMIKAZE = {};
    function kamikazeKind(m) {
        var r = String(m.rpgId || ""), d = dmzId(m);
        if (/^saibaman(_\d)?$/.test(r) || /^saga_saibaman/.test(d)) return { chance: 0.05, range: 10, speed: 1.5, radius: 4, mult: 3, anim: "explode" };
        if (d === "saga_chaoz") return { chance: 0.5, range: 15, speed: 1.8, radius: 5, mult: 4, anim: "cell_absorb", spar: true };
        return null;
    }
    RPG.on("damageFinal", function (e) {
        var t = e.target;
        if (!t || t.isPlayer() || e.isCancelled() || KAMIKAZE[t.uuid] || t.hasTag("dbr_kz_rolled")) return;
        var k = kamikazeKind(t);
        if (!k) return;
        var after = t.health - e.amount;
        if (after <= 0 || after > t.maxHealth * 0.25) return;
        t.addTag("dbr_kz_rolled");                                       // hasCheckedExplosionChance: one roll
        if (k.spar && t.hasTag("dmzq_spar")) return;                      // QuestService.isSparPartner
        if (Math.random() >= k.chance) return;
        KAMIKAZE[t.uuid] = { m: t, k: k, fuse: 0, attached: false };
        t.playAnimation(k.anim, "hold");
    });
    function nearestPlayer(m, range) {
        var best = null, bd = range + 1;
        m.nearby(range, { players: true }).forEach(function (e) {
            var p = e.asPlayer();
            if (!p || !p.alive || String(p.getGameMode()) === "spectator") return;
            var d = m.distanceTo(e);
            if (d < bd) { best = e; bd = d; }
        });
        return best;
    }
    function explode(s) {
        var m = s.m, k = s.k, dmg = m.attribute("generic.attack_damage") * k.mult;
        m.nearby(k.radius).forEach(function (e) {
            if (e.isAlive() && m.distanceTo(e) <= k.radius) e.damageFrom(dmg, m, { kind: "explosion", armor: true });
        });
        RPG.world.explode(m.dimension, m.x, m.y, m.z, k.radius, RPG.world.mobGriefing(m.dimension), m);
        m.remove();
    }
    RPG.every(1, function () {
        for (var u in KAMIKAZE) {
            var s = KAMIKAZE[u], m = s.m;
            try {
                if (!m.isAlive()) { delete KAMIKAZE[u]; continue; }
                var t = m.target;
                if (!t || !t.isAlive()) { t = nearestPlayer(m, s.k.range); if (t) m.target = t; }
                if (!t) continue;
                if (s.attached || m.distanceTo(t) <= 2) {
                    s.attached = true;
                    var yaw = t.yaw * Math.PI / 180, pitch = t.pitch * Math.PI / 180;
                    var lx = -Math.sin(yaw) * Math.cos(pitch), lz = Math.cos(yaw) * Math.cos(pitch);
                    m.teleport(t.x - lx * 0.8, t.y, t.z - lz * 0.8);
                    m.lookAt(t.x, t.eyeY, t.z);
                    m.setVelocity(0, 0, 0);
                    m.stopMoving();
                    s.fuse++;
                    if (s.fuse === 1 || s.fuse % 15 === 0) sfx(m, "minecraft:entity.creeper.primed", 1, 0.5 + s.fuse / 60);
                    if (s.fuse >= 3 * 20) { delete KAMIKAZE[u]; explode(s); }
                } else if (!m.isMoving() || RPG.server.getTick() % 10 === 0) m.moveTo(t.x, t.y, t.z, s.k.speed);
            } catch (err) { delete KAMIKAZE[u]; }
        }
    });

    // ---------------------------------------------------------------------------------
    //  Saga enemies' per-second hook (DMZ_SAGA.onTick): the Invisible Man, ogres
    // ---------------------------------------------------------------------------------
    if (typeof DMZ_SAGA !== "undefined" && DMZ_SAGA.onTick) {
        var sagaTick = DMZ_SAGA.onTick;
        DMZ_SAGA.onTick = function (m) {
            try {
                var d = dmzId(m);
                if (d === "saga_invisible_man") m.setInvisible(true);
                if (isOgre(m)) ogreTick(m);
            } catch (err) { }
            return sagaTick(m);
        };
    }
    RPG.on("bossSpawn", function (boss, id) { if (id === "invisible_man") boss.setInvisible(true); });

    // ---------------------------------------------------------------------------------
    //  Death lines (en_us.json death.attack.*)
    // ---------------------------------------------------------------------------------
    var KI_LINES = {
        small_ball: ["%1$s was pierced by %2$s's %3$s", "%1$s couldn't dodge %2$s's %3$s"],
        medium_ball: ["%1$s was blasted apart by %2$s's %3$s", "%1$s was overwhelmed by %2$s's %3$s"],
        giant_ball: ["%1$s was crushed beneath %2$s's %3$s", "%1$s was swallowed whole by %2$s's %3$s"],
        wave: ["%1$s was vaporized by %2$s's %3$s", "%1$s was engulfed in %2$s's %3$s"],
        laser: ["%1$s was shot clean through by %2$s's %3$s", "%1$s was struck down by %2$s's %3$s"],
        beam: ["%1$s was bored through by %2$s's %3$s", "%1$s was impaled by %2$s's %3$s"],
        disk: ["%1$s was sliced apart by %2$s's %3$s", "%1$s was cut down by %2$s's %3$s"],
        explosion: ["%1$s was caught in %2$s's %3$s", "%1$s was blown away by %2$s's %3$s"],
        shield: ["%1$s was repelled to death by %2$s's %3$s", "%1$s shattered against %2$s's %3$s"],
        barrage: ["%1$s was riddled by %2$s's %3$s", "%1$s was overwhelmed by %2$s's %3$s"],
        area: ["%1$s was consumed by %2$s's %3$s", "%1$s was caught in %2$s's %3$s"]
    };
    var STRIKE_LINES = {
        generic: "%1$s was beaten to death by %2$s",
        meteor: "%1$s was battered into oblivion by %2$s's Meteor Combination",
        dragon_fist: "%1$s was pierced by %2$s's Dragon Fist",
        deadly_dance_vegetto: "%1$s was torn apart by %2$s's Deadly Dance",
        deadly_dance: "%1$s was overwhelmed by %2$s's Deadly Dance",
        kaioken_attack: "%1$s was crushed by %2$s's Kaioken Assault",
        wolf_fang: "%1$s was shredded by %2$s's Wolf Fang Fist",
        oozaru_fist: "%1$s was smashed by %2$s's Oozaru Fist",
        super_god_fist: "%1$s was obliterated by %2$s's Super God Fist",
        gum_punch: "%1$s was sent flying by %2$s's Gum Punch",
        blue_hurricane: "%1$s was swept away by %2$s's Blue Hurricane",
        oozaru_slam: "%1$s was crushed by %2$s's Oozaru Slam",
        spirit_breaking_cannon: "%1$s was broken by %2$s's Spirit Breaking Cannon",
        dimensional_punch: "%1$s was struck across dimensions by %2$s's Dimensional Fist",
        dimensional_sword_attack: "%1$s was cut through space by %2$s's Dimensional Slash",
        grab: "%1$s was slammed into the ground by %2$s's Grab Throw",
        shining_sword_attack: "%1$s was cut down by %2$s's Shining Sword Attack",
        combo_meteor: "%1$s was pummeled by %2$s's Meteor Combo",
        meteor_burst: "%1$s was crushed by %2$s's Meteor Burst",
        mystic_ball: "%1$s was bounced into the ground by %2$s's Mystic Ball Attack",
        darkness_eye_beam: "%1$s was burned away by %2$s's Darkness Eye Beam",
        death_chaser: "%1$s was stomped into the ground by %2$s's Death Chaser",
        perfect_rush: "%1$s was driven into the ground by %2$s's Perfect Rush",
        spirit_breaker: "%1$s was broken by %2$s's Spirit Breaker",
        android_combo: "%1$s was blown apart by %2$s's Android Combo",
        beam_sword_slash: "%1$s was cut down by %2$s's Beam Sword Slash"
    };
    // projectile id -> DMZ KiType when the shot carries no technique (41_dmz_techniques.js)
    var PROJ_TYPE = { dmz_tech_wave: "WAVE", dmz_tech_beam: "BEAM", dmz_tech_laser: "LASER", dmz_tech_disk: "DISK",
        dmz_tech_bullet: "BARRAGE", dmz_tech_ball: "SMALL_BALL", dmz_tech_orb: "SMALL_BALL" };
    function kiLine(tech, type) {
        if (tech === "oozaru_fist" || tech === "dragon_fist") return STRIKE_LINES[tech];          // OzaruFistEntity / SPDragonFistEntity
        var name = tech ? DMZ_TECH_DATA.english(tech) : "ki attack";                            // death.attack.dmz.ki_generic
        if (tech === "soul_punisher") return "%1$s's soul was punished by %2$s's " + name;
        var lines = KI_LINES[String(type || "SMALL_BALL").toLowerCase()] || KI_LINES.small_ball;
        return lines[Math.floor(Math.random() * 2)].replace("%3$s", name);                    // KI_VARIANTS = 2
    }
    RPG.on("deathMessage", function (victim, attacker, kind, tag, proj) {
        if (!attacker || !DBR_QUIRKS_CFG.get("deathMessages", true)) return;
        tag = String(tag || "");
        if (kind === "strike") {
            var sid = tag.indexOf("dmzstrike:") === 0 ? tag.substring(10) : "";
            return STRIKE_LINES[sid] || STRIKE_LINES.generic;
        }
        if (kind !== "ki") return;
        var tech = tag.indexOf("dmzki:") === 0 ? tag.substring(6) : "";
        if (!tech && proj) { try { tech = String(proj.getVar("tech", "") || ""); } catch (err) { } }
        if (tech && !DMZ_TECH_DATA.KI[tech] && !DMZ_TECH_DATA.STRIKE[tech]) tech = "";
        if (tech || PROJ_TYPE[tag]) return kiLine(tech, tech && DMZ_TECH_DATA.KI[tech] ? DMZ_TECH_DATA.KI[tech].type : PROJ_TYPE[tag]);
        return "%1$s was blasted by %2$s's ki";                                                  // death.attack.kiblast.player
    });

    return { rollVariant: rollVariant, frogTick: frogTick, frogDeath: frogDeath, ogreTick: ogreTick, ogreHurt: ogreHurt, isOgre: isOgre,
        kamikaze: function () { return KAMIKAZE; } };
})();
