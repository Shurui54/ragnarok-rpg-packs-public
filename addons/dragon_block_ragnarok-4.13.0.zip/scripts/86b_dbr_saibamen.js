// =====================================================================================
//  86b_dbr_saibamen.js - DMZ Ragnarok's Saibaman seeds, plants and tamed Saibamen
// =====================================================================================
//  Ported from DMZ Ragnarok's shuruisutilities (GPL-3.0): SaibamanCropRegistry, SaibamanSeedItem, SaibamanCropBlock,
//  SaibamanCropBlockEntity, SaibamanKiRegenSuppression, SaibamanGrowItem, SaibamanCropEvents, ConfigSaibamanPet,
//  SaibamanPetEntity / SaibamanPetRegistry, HutSaibamanCropProcessor and SurfaceStamp.plantHutSeeds; art and models
//  from its assets (credited in NOTICE.md).
//
//  - Saibaman Seed: plants a Saibaman Plant on Rocky Dirt (and only there; it pops off when the dirt goes).
//  - The plant grows through four stages at wheat's pace (31,200 ticks, a third per stage) on a tick counter, never
//    from random ticks or bone meal. Once a second it looks for players charging ki (C) within 5 blocks: if any, that
//    second counts three times (flat, not per player) and every charging player pays 3 % of their max ki, with their
//    charging regen held off for that second. Breaking it gives the seed back at any stage.
//  - Right-clicking a grown plant hatches a tamed Saibaman (1 seed back one harvest in ten). Its tier is the share of
//    the plant's growth someone spent charging beside it (0 / 20 / 40 / 60 / 80 / 95 %): Feeble, Scrappy, Sturdy,
//    Fierce, Savage, Elite, one per saibaman colour. It takes 50 % x 1.1^(tier-1) of its owner's max health and melee
//    (melee without form multipliers) at the moment it hatches, follows its owner (teleporting back from 12 blocks),
//    defends them from monsters and joins their fights against monsters, fights back when hurt (never its owner or
//    their other pets), and blows up at 20 % health (3 blocks, 6 x the tier's percentage at the centre, owner and
//    their pets spared). Right-click: sit / follow; sneak + right-click a sitting one: dismiss it. At most 3 per
//    player on the server (counted with ones in unloaded chunks).
//  - Saibaman Growth Rod (creative or operators): right-click a growing plant to finish it.
//  - Buried Saibaman Seed: a dirt block in Vegeta's Saibamen huts; one in five (22 %) gives a seed when dug up.
//  - Huts: a Saibamen hut on a generated stony / overworld planet (86_dbr_space.js) and on Vegeta (88_dbr_space_vegeta.js)
//    has a 33 % chance of a growing plant at its floor's centre and, independently, 33 % of 1-3 more around it.
//
//  Saved: RPG.data "dbr_saiba_crops" {"dim|x|y|z": [counter, totalTicks, chargedTicks]} and "dbr_saiba_pets"
//  {petUuid: ownerUuid}. Pet tags: dbr_saibapet, dbr_saibapet_owner:<uuid>, dbr_saibapet_tier:<n>, dbr_saibapet_sit.
// =====================================================================================
var DBR_SAIBAMEN = (function () {
    // ---- SaibamanCropBlockEntity / ConfigSaibamanPet numbers ----
    var GROWTH_TICKS = 31200, PER_STAGE = Math.floor(GROWTH_TICKS / 3), CHARGE_INTERVAL = 20, CHARGE_RADIUS = 5, CHARGE_MULTIPLIER = 3;
    var KI_DRAIN_FRACTION = 0.03, SEED_RETURN_CHANCE = 0.10, INERT_SEED_CHANCE = 0.22, HUT_CHANCE = 0.33;
    var CFG = dbrConfig("dbr_saibaman_pets", { moveSpeed: 0.3, explosionThreshold: 0.2, explosionRadius: 3.0, explosionDamage: 6.0, maxPetsPerPlayer: 3,
        maxHealth: 20.0, attackDamage: 4.0 });
    var TIER_BASE = 0.50, TIER_STEP = 0.10, TIER_FLOOR = [0.0, 0.20, 0.40, 0.60, 0.80, 0.95];
    var TIERS = [["Feeble", "&7"], ["Scrappy", "&f"], ["Sturdy", "&a"], ["Fierce", "&b"], ["Savage", "&d"], ["Elite", "&6"]];
    var FOLLOW_SPEED = 1.6, FOLLOW_START = 12, TARGET_RANGE = 24;
    var TAG = "dbr_saibapet", OWNER = "dbr_saibapet_owner:", TIER_TAG = "dbr_saibapet_tier:", SIT = "dbr_saibapet_sit";

    function tierMult(t) { t = Math.max(1, Math.min(6, t)); return TIER_BASE * Math.pow(1 + TIER_STEP, t - 1); }
    function tierFrom(charged, total) {
        if (!(total > 0) || !(charged > 0)) return 1;
        var r = charged / total, t = 1;
        for (var i = 0; i < TIER_FLOOR.length; i++) if (r >= TIER_FLOOR[i]) t = i + 1;
        return t;
    }
    function creative(p) { return String(p.getGameMode()) === "creative"; }

    // ---- items and blocks (ids appended: named, so they never take another's slot) ----
    var SEED = RPG.items.define("saibaman_seed", { name: "Saibaman Seed", model: "dbr:rpg/item/saibaman_seed", type: "material", maxStack: 64,
        lore: ["&7Plant it on Rocky Dirt. Charge ki beside the plant", "&7while it grows for a stronger Saibaman."] });
    var ROD = RPG.items.define("saibaman_grow_tool", { name: "Saibaman Growth Rod", model: "dbr:rpg/item/saibaman_grow_tool", type: "material", maxStack: 1,
        lore: ["&7Admin: right-click a growing saibaman plant to finish it instantly."] });
    var SEED_REF = "ragnarok_rpg:" + SEED, ROD_REF = "ragnarok_rpg:" + ROD;
    var SHAPES = [[2, 0, 2, 14, 4, 14], [2, 0, 2, 14, 8, 14], [1, 0, 1, 15, 13, 15], [1, 0, 1, 15, 16, 15]];
    var CROP = [], CROP_AGE = {};                     // age -> full block id, full block id -> age
    function rocky() { return typeof blockRef === "function" ? blockRef("rocky_dirt") : null; }
    for (var age = 0; age < 4; age++) (function (a) {
        var id = RPG.blocks.define(a === 0 ? "saibaman_crop" : "saibaman_crop_age" + a, {
            name: "Saibaman Plant" + (a ? " (age " + a + ")" : ""), model: "dbr:rpg/block/saibaman_crop_stage" + a, hardness: 0, sound: "crop",
            collision: false, decor: true, shape: SHAPES[a], support: rocky() ? [rocky()] : ["any"], drops: "none",
            onBreak: function (player, x, y, z) {
                forget(player.dimension, x, y, z);
                if (!creative(player)) RPG.world.dropItem(player.dimension, x + 0.5, y + 0.5, z + 0.5, SEED, 1);     // getDrops: always the seed
            },
            onUse: function (player, x, y, z) { useCrop(player, a, x, y, z); },
            onRandomTick: function (dim, x, y, z) { if (a < 3) track(dim, x, y, z); }     // plants placed without a record (old data, other tools)
        });
        CROP[a] = "ragnarok_rpg:" + id;
        CROP_AGE[CROP[a]] = a;
    })(age);
    // the buried seed: dirt-strong, gravel-sounding; numbered so Vegeta's hut processors (data pack) can name it
    var INERT = RPG.blocks.define(2047, { key: "saibaman_seed_inert", name: "Buried Saibaman Seed", model: "dbr:rpg/block/saibaman_seed_inert",
        hardness: 0.6, sound: "gravel", drops: "none",
        onBreak: function (player, x, y, z) {
            if (!creative(player) && Math.random() < INERT_SEED_CHANCE) RPG.world.dropItem(player.dimension, x + 0.5, y + 0.5, z + 0.5, SEED, 1);
        } });
    if (INERT !== "block_2047") console.warn("[DBR] WARNING: saibaman_seed_inert wanted block_2047 but got " + INERT + ": Vegeta's hut seeds point at the wrong block!");

    // ---- the plants' growth counters (SaibamanCropBlockEntity) ----
    var CROPS = null, dirtyCrops = false;
    function crops() { if (!CROPS) CROPS = RPG.data.get("dbr_saiba_crops", null) || {}; return CROPS; }
    function key(dim, x, y, z) { return dim + "|" + x + "|" + y + "|" + z; }
    function track(dim, x, y, z) { var c = crops(), k = key(dim, x, y, z); if (!c[k]) { c[k] = [0, 0, 0]; dirtyCrops = true; } return c[k]; }
    function forget(dim, x, y, z) { var c = crops(), k = key(dim, x, y, z); if (c[k]) { delete c[k]; dirtyCrops = true; } }
    function ageAt(dim, x, y, z) { var a = CROP_AGE[String(RPG.world.getBlock(dim, x, y, z))]; return a === undefined ? -1 : a; }
    function plant(dim, x, y, z, a) {
        RPG.world.setBlock(dim, x, y, z, CROP[a || 0]);
        var r = track(dim, x, y, z);
        r[0] = 0;
        return r;
    }

    // SaibamanKiRegenSuppression: charging beside a plant pours ki into it, so that second's charging regen is held off
    var NOREGEN = {};
    function regenSuppressed(p) { return (NOREGEN[p.uuid] || 0) >= RPG.server.getTick(); }
    function chargingNear(dim, x, y, z) {
        var any = false, cx = x + 0.5, cy = y + 0.5, cz = z + 0.5, now = RPG.server.getTick();
        RPG.server.players().forEach(function (p) {
            if (p.dimension !== dim || !p.alive || !p.hasEffect("ki_charge")) return;
            var dx = p.x - cx, dy = p.y - cy, dz = p.z - cz;
            if (dx * dx + dy * dy + dz * dz > CHARGE_RADIUS * CHARGE_RADIUS) return;
            any = true;
            NOREGEN[p.uuid] = now + CHARGE_INTERVAL;
            var cost = p.maxResource("ki") * KI_DRAIN_FRACTION;
            if (cost > 0) p.addResource("ki", -Math.min(cost, p.resource("ki")));
        });
        return any;
    }
    RPG.every(CHARGE_INTERVAL, function () {
        var c = crops();
        for (var k in c) {
            var parts = k.split("|"), dim = parts[0], x = +parts[1], y = +parts[2], z = +parts[3];
            if (!RPG.server.hasDimension(dim) || !RPG.world.isLoaded(dim, x, z)) continue;       // ticks only while loaded, like a block entity
            var a = ageAt(dim, x, y, z);
            if (a < 0) { delete c[k]; dirtyCrops = true; continue; }
            if (a >= 3) continue;                                                                // grown: no work, the record keeps the tier
            var r = c[k];
            r[0] += CHARGE_INTERVAL; r[1] += CHARGE_INTERVAL;
            if (chargingNear(dim, x, y, z)) {
                r[0] += (CHARGE_MULTIPLIER - 1) * CHARGE_INTERVAL;
                r[2] += CHARGE_INTERVAL;
                RPG.world.particle(dim, "minecraft:happy_villager", x + 0.5, y + 0.4, z + 0.5, 4, 0.3, 0);
            }
            if (r[0] >= PER_STAGE) { r[0] = 0; RPG.world.setBlock(dim, x, y, z, CROP[a + 1]); }
            dirtyCrops = true;
        }
        if (dirtyCrops) { dirtyCrops = false; RPG.data.set("dbr_saiba_crops", c); }
    });

    // ---- planting (SaibamanSeedItem: only on rocky_dirt) and the growth rod ----
    RPG.on("blockInteract", function (player, blockId, x, y, z, dim) {
        if (String(player.getHeldItem()) !== SEED_REF) return;
        if (blockId !== rocky() || String(RPG.world.getBlock(dim, x, y + 1, z)) !== "minecraft:air") return;
        plant(dim, x, y + 1, z, 0);
        if (!creative(player)) player.takeItem(SEED_REF, 1);
        RPG.world.sound(dim, "minecraft:item.crop.plant", x + 0.5, y + 1, z + 0.5, 1, 1);
        return false;
    });
    function useCrop(player, a, x, y, z) {
        var dim = player.dimension;
        if (String(player.getHeldItem()) === ROD_REF) {                                        // SaibamanGrowItem
            if (!(creative(player) || player.isOp()) || a >= 3) return;
            RPG.world.setBlock(dim, x, y, z, CROP[3]);
            player.tell("The saibaman plant grew to full.");
            return;
        }
        if (a < 3) return;
        harvest(player, x, y, z);
    }

    // ---- tamed Saibamen (SaibamanPetEntity) ----
    var PETS = null;
    function pets() { if (!PETS) PETS = RPG.data.get("dbr_saiba_pets", null) || {}; return PETS; }
    function savePets() { RPG.data.set("dbr_saiba_pets", PETS); }
    function countLive(ownerUuid) { var n = 0, m = pets(); for (var u in m) if (m[u] === ownerUuid) n++; return n; }
    function untrack(petUuid) { var m = pets(); if (m[petUuid]) { delete m[petUuid]; savePets(); } }
    function ownerOf(mob) {
        var tags = mob.getTags ? mob.getTags() : null, m = pets()[String(mob.uuid)];
        if (m) return m;
        if (tags) for (var i = 0; i < tags.length; i++) if (String(tags[i]).indexOf(OWNER) === 0) return String(tags[i]).substring(OWNER.length);
        return null;
    }
    function tierOf(mob) { for (var t = 6; t >= 1; t--) if (mob.hasTag(TIER_TAG + t)) return t; return 1; }
    function online(uuid) { var ps = RPG.server.players(); for (var i = 0; i < ps.length; i++) if (String(ps[i].uuid) === uuid) return ps[i]; return null; }
    function isPet(e) { return !!e && typeof e.getRpgId === "function" && String(e.getRpgId()).indexOf("saibaman_pet") === 0; }
    // isSameOwnerParty: the owner, or another pet of the same owner
    function sameParty(mob, ownerUuid, t) {
        if (!t || !ownerUuid) return false;
        if (String(t.uuid) === ownerUuid) return true;
        return isPet(t) && ownerOf(t) === ownerUuid;
    }
    ["", "_2", "_3", "_4", "_5", "_6"].forEach(function (suffix, i) {
        RPG.mobs.define("saibaman_pet" + suffix, {
            name: "&aSaibaman",
            geo: { model: DMZ_GEO + "sagas/saga_saibaman.geo.json", texture: DMZ_TEX + "sagas/saga_saibaman" + (i + 1) + ".png",
                animation: DMZ_ANIM + "sagas/saga_saibaman.animation.json", idle: "idle", walk: "walk" },
            health: CFG.maxHealth, damage: CFG.attackDamage, speed: CFG.moveSpeed, followRange: TARGET_RANGE, xp: 0,
            hostile: false, attacks: true, persistent: true,
            onTick: function (mob) { petTick(mob); },
            onHurt: function (mob, attacker) {
                var o = ownerOf(mob);
                if (attacker && sameParty(mob, o, attacker)) RPG.schedule(1, function () { if (mob.isAlive() && mob.target && sameParty(mob, o, mob.target)) mob.target = null; });
            },
            onDeath: function (mob) { untrack(String(mob.uuid)); }
        });
    });
    function bake(pet, owner, tier) {
        var mult = tierMult(tier), hp = 0, melee = 0;
        if (owner) {
            hp = owner.maxHealth;
            try { var v = dmzView(owner); v.mult = function () { return 1; }; melee = DMZ_F.maxMelee(v); } catch (e) { melee = 0; }   // getMeleeDamageNoMultipliers
        }
        pet.maxHealth = Math.max(1, hp > 0 ? hp * mult : CFG.maxHealth * mult);
        pet.health = pet.maxHealth;
        pet.setAttributeBase("generic.attack_damage", Math.max(0, melee > 0 ? melee * mult : CFG.attackDamage * mult));
        pet.setAttributeBase("generic.movement_speed", CFG.moveSpeed);
    }
    function harvest(player, x, y, z) {
        var dim = player.dimension, uuid = String(player.uuid), live = countLive(uuid), cap = Math.max(1, CFG.maxPetsPerPlayer);
        if (live >= cap) { player.tell("You already have " + live + " of " + cap + " saibaman pets on this server."); return; }
        var r = crops()[key(dim, x, y, z)], tier = r ? tierFrom(r[2], r[1]) : 1;
        var pet = RPG.world.spawnMob(dim, "saibaman_pet" + (tier > 1 ? "_" + tier : ""), x + 0.5, y, z + 0.5);
        if (!pet) return;                                                                    // the plant stays standing
        pet.setRotation(Math.random() * 360, 0);
        pet.addTag(TAG); pet.addTag(OWNER + uuid); pet.addTag(TIER_TAG + tier);
        bake(pet, player, tier);
        var t = TIERS[tier - 1];
        pet.setCustomName(t[1] + t[0] + " Saibaman");
        pets()[String(pet.uuid)] = uuid; savePets();
        RPG.world.setBlock(dim, x, y, z, "minecraft:air");
        forget(dim, x, y, z);
        if (Math.random() < SEED_RETURN_CHANCE) RPG.world.dropItem(dim, x + 0.5, y + 0.5, z + 0.5, SEED, 1);
        player.tell("The seed produced a saibaman of " + t[1] + t[0] + "&r quality.");
    }
    // FollowOwnerGoal (canFly: teleports back from 12 blocks), the target goals and the near-death self-destruct
    function petTick(mob) {
        if (!mob.isAlive()) return;
        if (mob.maxHealth > 0 && mob.health > 0 && mob.health <= mob.maxHealth * CFG.explosionThreshold) { detonate(mob); return; }
        var ou = ownerOf(mob), owner = ou ? online(ou) : null;
        if (mob.hasTag(SIT)) { if (mob.target) mob.target = null; return; }
        var t = mob.target;
        if (t && (!t.isAlive() || sameParty(mob, ou, t))) { mob.target = null; t = null; }
        if (!t) {                                                                            // NearestAttackableTargetGoal<Monster>
            var best = null, bd = 1e9;
            mob.nearby(TARGET_RANGE).forEach(function (c) {
                try {
                    if (!c.isAlive() || c.isPlayer() || !c.isHostile() || isPet(c)) return;
                    var d = mob.distanceTo(c); if (d < bd) { bd = d; best = c; }
                } catch (e) { }
            });
            if (best) { mob.target = best; t = best; }
        }
        if (!owner || owner.dimension !== mob.getDimension() || t) return;
        if (mob.distanceTo(owner) >= FOLLOW_START) {
            for (var i = 0; i < 10; i++) {                                                   // teleportToOwner: a spot 2-3 blocks off, in the air if need be
                var dx = Math.floor(Math.random() * 7) - 3, dz = Math.floor(Math.random() * 7) - 3, dy = Math.floor(Math.random() * 3) - 1;
                if (Math.abs(dx) < 2 && Math.abs(dz) < 2) continue;
                var bx = Math.floor(owner.x) + dx, by = Math.floor(owner.y) + dy, bz = Math.floor(owner.z) + dz;
                if (String(RPG.world.getBlock(owner.dimension, bx, by, bz)) !== "minecraft:air" || String(RPG.world.getBlock(owner.dimension, bx, by + 1, bz)) !== "minecraft:air") continue;
                mob.teleport(bx + 0.5, by, bz + 0.5);
                return;
            }
        } else if (mob.distanceTo(owner) > 3) mob.moveTo(owner.x, owner.y, owner.z, FOLLOW_SPEED);
    }
    function detonate(mob) {
        var dim = mob.getDimension(), x = mob.x, y = mob.y + 0.8, z = mob.z, ou = ownerOf(mob);
        var radius = Math.max(0, CFG.explosionRadius), dmg = Math.max(0, CFG.explosionDamage * tierMult(tierOf(mob)));
        if (radius > 0 && dmg > 0) {
            mob.nearby(radius + 1).forEach(function (v) {
                try {
                    if (!v.isAlive() || sameParty(mob, ou, v)) return;
                    var dx = v.x - x, dy = v.y - y, dz = v.z - z, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (d > radius) return;
                    var dealt = dmg * (1 - d / radius);
                    if (dealt > 0) v.damageFrom(dealt, mob);
                } catch (e) { }
            });
            RPG.world.particle(dim, "minecraft:explosion_emitter", x, y, z, 1, 0, 0);
        }
        RPG.world.sound(dim, "minecraft:entity.generic.explode", x, y, z, 4, (1 + (Math.random() - Math.random()) * 0.2) * 0.7);
        untrack(String(mob.uuid));
        mob.remove();
    }
    // mobInteract: right-click sits / stands; sneak + right-click a sitting one sends it away (frees a slot)
    var LAST_USE = {};
    RPG.on("entityInteract", function (player, e) {
        if (!isPet(e)) return;
        var now = RPG.server.getTick();
        if (LAST_USE[player.uuid] === now) return false;                                     // the main and off hand both ask
        LAST_USE[player.uuid] = now;
        if (ownerOf(e) !== String(player.uuid)) return;
        var name = e.customName || "Saibaman";
        if (player.isSneaking()) {
            if (e.hasTag(SIT)) { player.tell(name + "&r was dismissed."); untrack(String(e.uuid)); e.remove(); }
            else player.tell("Tell the saibaman to sit before dismissing it.");
            return false;
        }
        if (e.hasTag(SIT)) { e.removeTag(SIT); e.setAI(true); }
        else { e.addTag(SIT); e.target = null; e.stopMoving(); e.setAI(false); }
        return false;
    });
    // OwnerHurtByTargetGoal / OwnerHurtTargetGoal: only ever against monsters (wantsToAttack)
    RPG.on("damageFinal", function (ev) {
        if (ev.isCancelled() || !ev.attacker || !ev.target) return;
        var m = pets(), any = false;
        for (var u in m) { any = true; break; }
        if (!any) return;
        var owner = ev.target.isPlayer() ? ev.target : ev.attacker.isPlayer() ? ev.attacker : null;
        if (!owner) return;
        var foe = owner === ev.target ? ev.attacker : ev.target;
        if (!foe.isHostile() || isPet(foe)) return;
        var ou = String(owner.uuid);
        for (var pu in m) {
            if (m[pu] !== ou) continue;
            var pet = RPG.world.entityByUuid(pu);
            if (pet && pet.isAlive() && !pet.hasTag(SIT) && !pet.target && pet.distanceTo(owner) < TARGET_RANGE) pet.target = foe;
        }
    });

    // ---- huts (SurfaceStamp.plantHutSeeds / HutSaibamanCropProcessor) ----
    var HUT_INTERIOR = [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
    /** A generated planet's hut: floor at groundY, centre wx/wz; rnd is the hut's own seeded random (after its doorway roll). */
    function plantPlanetHut(dim, wx, groundY, wz, rnd) {
        var dirt = rocky();
        if (!dirt) return 0;
        var planted = rnd() < HUT_CHANCE, harvest2 = rnd() < HUT_CHANCE, placed = 0;
        function seed(x, z) { RPG.world.setBlock(dim, x, groundY, z, dirt); plant(dim, x, groundY + 1, z, 0); placed += 2; }
        if (planted) seed(wx, wz);
        if (harvest2) {
            var count = 1 + Math.floor(rnd() * 3);
            for (var i = planted ? 1 : 0; i < HUT_INTERIOR.length && count > 0; i++, count--) seed(wx + HUT_INTERIOR[i][0], wz + HUT_INTERIOR[i][1]);
        }
        return placed;
    }
    /** A Vegeta hut (structure start box): the lowest layer's rocky dirt (or buried seed) cells with air above, nearest the
     *  centre first, as HutSaibamanCropProcessor reads its piece. */
    function plantStructureHut(dim, st) {
        var dirt = rocky(), inert = "ragnarok_rpg:" + INERT;
        if (!dirt) return false;
        var planted = Math.random() < HUT_CHANCE, harvest2 = Math.random() < HUT_CHANCE;
        if (!planted && !harvest2) return true;
        var count = (planted ? 1 : 0) + (harvest2 ? 1 + Math.floor(Math.random() * 3) : 0);
        var cx = (st.minX + st.maxX) / 2, cz = (st.minZ + st.maxZ) / 2, floors = [];
        var y = st.minY;
        for (var x = st.minX; x <= st.maxX; x++) for (var z = st.minZ; z <= st.maxZ; z++) {
            var b = String(RPG.world.getBlock(dim, x, y, z));
            if ((b === dirt || b === inert) && String(RPG.world.getBlock(dim, x, y + 1, z)) === "minecraft:air") floors.push([x, y, z]);
        }
        floors.sort(function (a, b) { return (a[0] - cx) * (a[0] - cx) + (a[2] - cz) * (a[2] - cz) - (b[0] - cx) * (b[0] - cx) - (b[2] - cz) * (b[2] - cz); });
        for (var n = 0; n < floors.length && n < count; n++) {
            var f = floors[n];
            RPG.world.setBlock(dim, f[0], f[1], f[2], dirt);
            plant(dim, f[0], f[1] + 1, f[2], 0);
        }
        return true;
    }

    return { SEED: SEED, ROD: ROD, INERT: INERT, CROP: CROP, regenSuppressed: regenSuppressed, plantPlanetHut: plantPlanetHut,
        plantStructureHut: plantStructureHut, tierFrom: tierFrom, tierMult: tierMult, countLive: countLive };
})();
