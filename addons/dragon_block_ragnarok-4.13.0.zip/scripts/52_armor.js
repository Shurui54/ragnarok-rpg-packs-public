// =====================================================================================
//  52_armor.js - 47 DMZ outfits: gis, Saiyan armour, Capsule Corp jackets...
// =====================================================================================
//  type "armor" + slot ("head" | "chest" | "legs" | "feet") makes a real wearable piece.
//  The toolkit has 50 placeholder slots per armour piece (head/chest/legs/feet), so this
//  file uses 47 chest/legs/feet slots and leaves room for a few of your own.
//
//  How it looks when worn:
//    armorTexture: "dmzpack:textures/armor/goku_gi_layer{n}.png"
//        {n} becomes 1 for head/chest/feet and 2 for legs (Minecraft's two armour layers)
//    armorModel: "skin64"
//        DMZ paints armour like a 64x64 player skin (separate left arm/leg, outer layer).
//        Vanilla's armour model is 64x32 and mirrors the left limbs, so DMZ textures need
//        the "skin64" model. On a DMZ avatar the armour is drawn on the model's own
//        armorHead / armorBody / armorRightArm... bones, so it fits every race and form.
//    model: "dmzpack:rpg/item/armors_goku_armor_chestplate"   the inventory icon
//
//  Any game: a Zelda tunic is the same three lines with your own texture.
// =====================================================================================

// tier 1-6: armour points and toughness grow with it.
// set: [id, display name, item model base, texture base, tier, stats, level, head?]
function armorSet(id, name, modelBase, textureBase, tier, stats, level, withHead) {
    let pieces = [
        { slot: "chest", suffix: "_chest", label: "", model: "_chestplate", armor: 3 + tier },
        { slot: "legs", suffix: "_legs", label: " Pants", model: "_leggings", armor: 2 + tier },
        { slot: "feet", suffix: "_boots", label: " Boots", model: "_boots", armor: 1 + Math.ceil(tier / 2) }
    ];
    if (withHead) pieces.push({ slot: "head", suffix: "_head", label: " Headgear", model: "_helmet", armor: 1 + Math.ceil(tier / 2) });
    pieces.forEach((pc) => {
        RPG.items.define(id + pc.suffix, {
            name: name + pc.label,
            model: DMZ + "rpg/item/armors_" + modelBase + "_armor" + pc.model,
            type: "armor",
            slot: pc.slot,
            armor: pc.armor,
            toughness: Math.floor(tier / 2),
            durability: 400 + tier * 300,
            levelReq: level || 0,
            stats: stats,
            rarity: tier >= 5 ? "epic" : tier >= 3 ? "rare" : tier >= 2 ? "uncommon" : "common",
            armorModel: "skin64",
            armorTexture: DMZ + "textures/armor/" + textureBase + "_layer{n}.png"
        });
    });
    ARMOR_SETS[id] = { name: name, head: !!withHead };
}
var ARMOR_SETS = {};

// ---- Turtle School & friends ---------------------------------------------------------------
armorSet("turtle_gi", "Turtle School Gi", "goku", "goku_gi", 1, { strike: 2 }, 0);
armorSet("kid_goku_gi", "Kid Goku's Gi", "goku_kid", "goku_kid", 1, { strike: 1, vitality: 1 }, 0);
armorSet("super_goku_gi", "Goku's Gi (Super)", "goku_super", "goku_super", 4, { strike: 6, strength: 3 }, 40);
armorSet("gt_goku_gi", "Blue Master Gi (GT)", "goku_gt", "goku_gt", 5, { strike: 8, kipower: 4 }, 60);
armorSet("whis_goku_gi", "Whis-Symbol Gi (Goku)", "goku_whis", "gokuwhis", 6, { strike: 10, energy: 5 }, 80);
armorSet("yardrat_outfit", "Yardrat Outfit", "yardrat", "yardrat_gi", 3, { energy: 5, kipower: 2 }, 30);
armorSet("goten_gi", "Goten's Gi", "goten", "goten_gi", 2, { strike: 3 }, 15);
armorSet("goten_jacket", "Goten's Jacket (Super)", "goten_super", "goten_dbs", 4, { strike: 5, energy: 3 }, 45);
armorSet("tien_gi", "Crane School Gi", "tien", "tenshinhan_armor", 2, { kipower: 3, strike: 1 }, 12);
armorSet("videl_outfit", "Videl's Outfit", "videl", "videl", 2, { strike: 3, vitality: 1 }, 15);

// ---- Demon Clan / Gohan ------------------------------------------------------------------
armorSet("demon_gi", "Demon Clan Gi", "piccolo", "piccolo_gi", 1, { kipower: 2, energy: 1 }, 0, true);
armorSet("gohan_demon_gi", "Gohan's Demon Gi", "demon_gi_blue", "demon_gi_gohan", 2, { kipower: 3, energy: 1 }, 10);
armorSet("gohan_super_gi", "Demon Gi (Gohan, Super)", "gohan_super", "gohan_dbs", 5, { kipower: 8, strike: 4 }, 60);
armorSet("future_gohan_gi", "Future Gohan's Gi", "future_gohan", "future_gohan", 3, { strike: 4, kipower: 3 }, 30);
armorSet("great_saiyaman", "Great Saiyaman Suit", "great_saiyaman", "saiyaman_gi", 3, { strike: 3, vitality: 3 }, 25, true);

// ---- Saiyan armour ---------------------------------------------------------------------
armorSet("saiyan_armor", "Saiyan Battle Armor", "vegeta_saiyan", "vegeta_saiyan_armor", 3, { resistance: 4 }, 15);
armorSet("namek_saiyan_armor", "Saiyan Armor (Namek)", "vegeta_namek", "vegetanamek_armor", 3, { resistance: 5, strength: 1 }, 25);
armorSet("cell_saiyan_armor", "Saiyan Armor (Cell Games)", "vegeta_z", "vegetaz_armor", 4, { resistance: 6, strength: 3 }, 35);
armorSet("vegeta_training_wear", "Vegeta's Training Wear", "vegeta_buu", "vegetabuu", 4, { strength: 6, strike: 2 }, 45);
armorSet("super_saiyan_armor", "Saiyan Armor (Super)", "vegeta_super", "vegetasuper", 5, { resistance: 8, strength: 5 }, 60);
armorSet("gt_vegeta_outfit", "Vegeta's Outfit (GT)", "vegeta_gt", "vegetagt", 5, { strength: 8, kipower: 3 }, 60);
armorSet("bardock_armor", "Bardock's Armor", "bardock_dbz", "bardock_armor", 3, { strength: 4, vitality: 2 }, 20);
armorSet("turles_armor", "Turles' Armor", "turles", "turles_armor", 4, { strength: 5, kipower: 3 }, 35);
armorSet("raditz_armor", "Raditz's Armor", "raditz", "raditz", 2, { resistance: 3, strength: 1 }, 10);
armorSet("king_vegeta_armor", "Royal Saiyan Armor", "king_vegeta", "king_vegeta", 4, { resistance: 6, energy: 3 }, 40);
armorSet("broly_jewelry", "Control Jewelry Set", "broly_z", "broly_dbz", 5, { strength: 10, vitality: 4 }, 55, true);
armorSet("broly_super_armor", "Broly's Armor (Super)", "broly_super", "broly_dbs", 6, { strength: 12, resistance: 6 }, 75);

// ---- Fusions & gods ---------------------------------------------------------------------
armorSet("vegetto_gi", "Vegito's Gi", "vegetto", "vegetto", 6, { strike: 8, strength: 8, kipower: 6 }, 80);
armorSet("gogeta_vest", "Metamoran Vest", "gogeta", "gogeta", 6, { strike: 8, strength: 8, kipower: 6 }, 80);
armorSet("whis_robe", "Angel's Robe (Whis)", "whis", "whis", 6, { energy: 12, kipower: 8 }, 90);
armorSet("beerus_robe", "God of Destruction Robe", "beerus", "beerus", 6, { kipower: 14, energy: 6 }, 90);
armorSet("hit_coat", "Assassin's Coat (Hit)", "hit", "hit", 5, { strike: 10, energy: 3 }, 65);
armorSet("zamasu_robe", "Kaioshin Robe (Zamasu)", "zamasu", "zamasu_gi", 5, { kipower: 9, resistance: 4 }, 70);
armorSet("black_goku_gi", "Black Gi", "blackgoku", "blackgoku", 6, { strike: 10, kipower: 6 }, 85);
armorSet("supreme_kai_robe", "Supreme Kai's Robe", "shin", "kaioshin", 4, { energy: 8, kipower: 3 }, 45);

// ---- Androids, Majins and villains -----------------------------------------------------
armorSet("android_17_outfit", "Android 17's Outfit", "a17", "a17", 4, { energy: 6, strike: 3 }, 35);
armorSet("android_18_outfit", "Android 18's Outfit", "a18", "a18", 4, { energy: 6, kipower: 3 }, 35);
armorSet("android_16_armor", "Android 16's Armor", "a16", "a16", 4, { resistance: 7, vitality: 2 }, 35);
armorSet("gero_outfit", "Dr. Gero's Outfit", "gero", "gero", 3, { energy: 5, kipower: 2 }, 25);
armorSet("majin_buu_vest", "Majin Vest (Buu)", "majin_buu", "majinbuu_gi", 3, { vitality: 5, resistance: 2 }, 30);
armorSet("super_buu_pants", "Majin Garb (Super Buu)", "super_buu", "super_buu", 5, { vitality: 8, kipower: 4 }, 55);
armorSet("frieza_force_armor", "Frieza Force Armor", "cooler_soldier", "cooler_soldier", 2, { resistance: 3 }, 10);
armorSet("slug_robe", "Lord Slug's Robe", "slug", "slug", 4, { kipower: 6, resistance: 3 }, 40, true);
armorSet("chiaotzu_outfit", "Chiaotzu's Outfit", "chaoz", "chaoz", 2, { kipower: 3, energy: 2 }, 12, true);

// ---- Everyday ----------------------------------------------------------------------------
armorSet("capsule_corp_jacket", "Capsule Corp. Jacket", "capsule_corp", "capsule_corp", 2, { energy: 2, vitality: 2 }, 5);
armorSet("trunks_jacket", "Trunks' Jacket (Super)", "trunks_super", "trunks_dbs", 5, { strength: 6, strike: 4 }, 55);
armorSet("fighter_outfit", "Fighter's Outfit", "fighter", "fighter", 1, { strength: 2 }, 0);

// =====================================================================================
//  Armour patterns: right-click with an Armour Crafting Kit in your inventory -> the full set
// =====================================================================================
// [set id, pattern model under rpg/item/patterns_]
[
    ["turtle_gi", "goku1"], ["kid_goku_gi", "goku_kid"], ["super_goku_gi", "goku_super"], ["gt_goku_gi", "goku_gt"],
    ["whis_goku_gi", "goku_whis"], ["yardrat_outfit", "yardrat"], ["goten_gi", "goten"], ["goten_jacket", "goten_super"],
    ["tien_gi", "tien"], ["videl_outfit", "videl"], ["demon_gi", "piccolo"], ["gohan_demon_gi", "gohan1"],
    ["gohan_super_gi", "gohan_super"], ["future_gohan_gi", "future_gohan"], ["great_saiyaman", "great_saiyaman"],
    ["saiyan_armor", "vegeta1"], ["namek_saiyan_armor", "vegeta2"], ["cell_saiyan_armor", "vegeta_z"], ["vegeta_training_wear", "vegeta_buu"],
    ["super_saiyan_armor", "vegeta_super"], ["gt_vegeta_outfit", "vegeta_gt"], ["bardock_armor", "bardock1"], ["turles_armor", "turles"],
    ["raditz_armor", "raditz"], ["king_vegeta_armor", "king_vegeta"], ["broly_jewelry", "broly_z"], ["broly_super_armor", "broly_super"],
    ["vegetto_gi", "vegetto"], ["gogeta_vest", "gogeta"], ["whis_robe", "whis"], ["beerus_robe", "beerus"], ["hit_coat", "hit"],
    ["zamasu_robe", "zamasu"], ["black_goku_gi", "black"], ["supreme_kai_robe", "shin"], ["android_17_outfit", "a17"],
    ["android_18_outfit", "a18"], ["android_16_armor", "a16"], ["gero_outfit", "gero"], ["majin_buu_vest", "majin_buu"],
    ["super_buu_pants", "super_buu"], ["frieza_force_armor", "cooler_soldier"], ["slug_robe", "slug"], ["chiaotzu_outfit", "chaoz"],
    ["capsule_corp_jacket", "capsule_corp"], ["trunks_jacket", "trunks_super"], ["fighter_outfit", "fighter"]
].forEach((p) => {
    let set = ARMOR_SETS[p[0]];
    RPG.items.define("pattern_" + p[0], {
        name: "&ePattern: &f" + set.name,
        model: DMZ + "rpg/item/patterns_pattern_" + p[1],
        type: "tool", rarity: "uncommon", maxStack: 16, value: 400,
        lore: ["Right-click with an Armour Crafting Kit", "in your inventory to sew the full set."],
        onUse(player) {
            if (!player.takeItem("armor_crafting_kit", 1)) { player.actionbar("&7You need an Armour Crafting Kit."); return false; }
            ["_chest", "_legs", "_boots"].concat(set.head ? ["_head"] : []).forEach((s) => player.giveItem(p[0] + s, 1));
            player.title("&e" + set.name, "&7sewn!");
            uiSfx(player, "confirm_menu", 1, 1);
        }
    });
});
