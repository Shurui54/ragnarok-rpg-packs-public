// =====================================================================================
//  99_testall.js - test commands for ops
//    /rpgc grantall [stat] [quests|noquests] [player]   unlock everything: all six stats to 1,000,000 (or [stat]),
//                                    every skill, form (form-editor and ritual forms too) and technique at its top level,
//                                    full mastery, the rituals, minigames, TP, full bars; the story quests are marked
//                                    done so saga-locked forms open ("quests" plays them out with rewards instead,
//                                    "noquests" leaves them). /rpgc testall is the old name.
//    /rpgc giveall [page]   every Dragon Block item, 36 per page (/rpgc giveall 2 for the next ones)
//    /rpgc resetall         back to a fresh character (opens the creator)
// =====================================================================================
(function () {
    var GRANT_STAT = 1000000;
    function grantAll(p, each, questMode) {
        var race = DMZ_DATA.DMZ[p.race] || p.race;
        // ---- the six stats: set (not add) to 1,000,000, inside the stat cap (prestige widens it; 92_dbr_raids_zsouls.js)
        var cap = typeof DBR_PRESTIGE !== "undefined" && DBR_PRESTIGE.capFor ? DBR_PRESTIGE.capFor(p) : GRANT_STAT;
        var want = Math.min(each, cap);
        DMZ_DATA.STATS.forEach(function (k) {
            var id = DMZ_DATA.STAT_IDS[k], have = Math.floor(p.baseStat(id));
            if (have < want) p.addStat(id, want - have);
        });
        p.addTp(1e9, { raw: true, events: false, source: "script" });
        // ---- engine skills (40_skills.js / 30_forms.js), each at its top level
        var n = 0;
        RPG.skills.list().forEach(function (id) {
            try { var d = RPG.skills.get(id), max = d && Number(d.maxLevel) > 0 ? Number(d.maxLevel) : 10; p.learnSkill(id); p.setSkillLevel(id, max); n++; } catch (err) { }
        });
        if (typeof DMZ_SKILLS !== "undefined" && typeof DMZ_SKILLS_DATA !== "undefined") {
            var SD = DMZ_SKILLS_DATA, android = !!p.getVar("dmz_android", 0);
            // every DMZ skill the race may have, at its top level (potentialunlock raises the release cap)
            Object.keys(SD.COSTS).concat(SD.FORM_SKILLS).forEach(function (sk) {
                try { if (!SD.allowed(sk, race, android)) return; var max = SD.maxLevel(sk, race); if (max > 0 && DMZ_SKILLS.level(p, sk) < max) DMZ_SKILLS.setLevel(p, sk, max, "command"); } catch (err) { }
            });
            // forms added later (the form editor, ritual forms) may sit above DMZ's ladder or on a skill of their own:
            // raise each group's skill to its highest form's unlock level
            if (typeof DMZ_FORMS !== "undefined") {
                var need = {};
                (DMZ_FORMS.groups(race) || []).forEach(function (g) {
                    var sk = DMZ_FORMS.skillFor(g.type);
                    g.forms.forEach(function (f) { if (sk && f.lvl > (need[sk] || 0)) need[sk] = f.lvl; });
                });
                (DMZ_FORMS.STACKS || []).forEach(function (g) { g.forms.forEach(function (f) { if (f.lvl > (need[g.type] || 0)) need[g.type] = f.lvl; }); });
                Object.keys(need).forEach(function (sk) { try { if (DMZ_SKILLS.level(p, sk) < need[sk]) DMZ_SKILLS.setLevel(p, sk, need[sk], "command"); } catch (err) { } });
            }
        }
        // ---- every form and stack form fully mastered (31_dmz_transform.js)
        if (typeof DMZ_FORMS !== "undefined") {
            var fm = {}, sm = {};
            (DMZ_FORMS.groups(race) || []).forEach(function (g) { g.forms.forEach(function (f) { fm[f.key] = f.maxMastery > 0 ? f.maxMastery : 100; }); });
            (DMZ_FORMS.STACKS || []).forEach(function (g) { g.forms.forEach(function (f) { sm[f.key] = f.maxMastery > 0 ? f.maxMastery : 100; }); });
            p.setVar("dmz_mastery", fm);
            p.setVar("dmz_stack_mastery", sm);
        }
        // ---- every technique (41_dmz_techniques.js)
        if (typeof DMZ_TECH !== "undefined" && typeof DMZ_TECH_DATA !== "undefined") {
            DMZ_TECH_DATA.all().forEach(function (id, i) { try { DMZ_TECH.unlock(p, id, { source: "command", silent: i > 0 }); } catch (err) { } });
            DMZ_TECH.sendState(p);
        }
        // ---- the rituals' unlocks (95_dbr_rituals.js): SSG knowledge, Super Saiyan 5, Namekian god
        ["ssg_knowledge", "ssj5", "namekian_god"].forEach(function (k) { p.setVar("dmzr_ritual_" + k, 1); });
        // ---- minigames known (67_dmz_minigames.js)
        if (typeof DMZ_MG !== "undefined") {
            var mg = p.getVar("dmz_mg", null) || {};
            var known = (mg.known || []).slice();
            DMZ_MG.IDS.forEach(function (id) { if (known.indexOf(id) < 0) known.push(id); });
            p.setVar("dmz_mg", { known: known, runs: mg.runs || {}, songs: mg.songs || [] });
        }
        // ---- the story: saga-locked forms need their saga quests
        if (questMode === "quests") RPG.quests.list().forEach(function (q) { try { if (!p.isQuestDone(q)) p.completeQuest(q); } catch (err) { } });
        if (questMode !== "noquests" && typeof DMZ_QUESTS !== "undefined" && DMZ_QUESTS.cmd) {
            var QC = DMZ_QUESTS.cmd, v = QC.view(p);
            Object.keys(DMZ_QL.BY_KEY).forEach(function (key) {
                var r = v.q[key];
                if (questMode === "quests") {                           // DMZ's own completion: rewards to claim
                    var e = DMZ_QL.entry(key);
                    if (!r || r.s !== DMZ_QL.COMPLETED) { v.q[key] = { s: DMZ_QL.ACCEPTED, p: e.quest.objectives.map(function (o) { return DMZ_QL.required(o); }), c: [], d: v.d || "NORMAL" }; QC.complete(p, v, e); }
                } else if (!r || r.s !== DMZ_QL.COMPLETED) {
                    // marked done without rewards or spawns; every reward counted as claimed
                    var en = DMZ_QL.entry(key);
                    v.q[key] = { s: DMZ_QL.COMPLETED, p: en.quest.objectives.map(function (o) { return DMZ_QL.required(o); }),
                        c: (en.quest.rewards || []).map(function (x, i) { return i; }), d: v.d || "NORMAL", at: Date.now() };
                }
            });
            v.tr = null;
            QC.save(p, v); QC.sync(p, v);
        }
        if (typeof DMZ_TF !== "undefined") DMZ_TF.refresh(p);
        p.refreshStats();
        RPG.schedule(5, function () {                         // once the new maximums are in
            p.refreshStats();
            ["ki", "stamina"].forEach(function (r) { p.setResource(r, p.maxResource(r)); });
            p.setHealth(p.maxHealth);
            if (typeof DMZ_F !== "undefined") p.setVar("dmz_release", DMZ_F.maxRelease(Number(p.getVar("dmz_potential", 0)), 1, p.getVar("dmzr_release_boost", 0)));
        });
        return n;
    }
    var GRANT = {
        permission: 2,
        description: "/rpgc grantall [stat] [quests|noquests] [player] - unlock everything: stats to 1,000,000, every skill, form, technique, mastery and ritual (testing)",
        suggest: function (p, args) {
            if (args.length === 1) return ["1000000", "100000", "10000"];
            if (args.length === 2) return ["quests", "noquests"];
            if (args.length === 3) return DBR_CMD.selectors();
            return [];
        },
        run: function (p, args) {
            var targets = args[2] ? RPG.server.selectPlayers(String(args[2]), p) : p ? [p] : [];
            if (!targets.length) return DBR_CMD.fail(p, args[2] ? "No player was found" : "A player is required to run this command here");
            var each = args[0] !== undefined && !isNaN(Number(args[0])) ? Math.max(0, Math.floor(Number(args[0]))) : GRANT_STAT;
            var mode = String(args[1] || "").toLowerCase();
            targets.forEach(function (t) {
                if (!t.getVar("dmz_created", 0)) { DBR_CMD.fail(p, t.name + ": make the character first (it opens on join, or /rpgc recreate)."); return; }
                var n = grantAll(t, each, mode);
                DBR_CMD.tell(p, "&a[Grant] " + t.name + ": every stat " + Math.min(each, typeof DBR_PRESTIGE !== "undefined" && DBR_PRESTIGE.capFor ? DBR_PRESTIGE.capFor(t) : each) +
                    ", " + n + " skills, every DMZ skill, form, technique and mastery, the rituals, 1e9 TP" +
                    (mode === "noquests" ? "." : mode === "quests" ? ", every quest played out." : ", the story marked done."));
            });
            DBR_CMD.tell(p, "&7/rpgc giveall for every item, /rpgc resetall to start over.");
        }
    };
    DBR_CMD.renamed("grantall", "testall", GRANT);

    RPG.commands.register("giveall", {
        permission: 2,
        description: "/rpgc giveall [page] - every Dragon Block item, 36 per page",
        run(p, args) {
            let ids = RPG.items.list().concat(RPG.blocks.list ? RPG.blocks.list() : []);
            let page = Math.max(1, Math.floor(Number(args[0]) || 1)), per = 36, pages = Math.max(1, Math.ceil(ids.length / per));
            ids.slice((page - 1) * per, page * per).forEach((id) => {
                try { p.giveItem(id, 1); } catch (err) { }
            });
            p.tell("&a[Test] Page " + page + " of " + pages + " (" + ids.length + " items in all)." + (page < pages ? " &7/rpgc giveall " + (page + 1) + " for more." : ""));
        }
    });

    RPG.commands.register("resetall", {
        permission: 2,
        description: "/rpgc resetall - wipe this character and make a new one",
        run(p, args) {
            DMZ_DATA.STATS.forEach((k) => { let id = DMZ_DATA.STAT_IDS[k]; p.addStat(id, -p.allocated(id)); });
            RPG.skills.list().forEach((id) => { try { if (p.hasSkill(id)) p.forgetSkill(id); } catch (err) { } });
            if (typeof DMZ_TECH !== "undefined") DMZ_TECH.clearAll(p);
            p.setVar("dmz_release", 0);
            p.setVar("dmz_potential", 0);
            p.setVar("dmz_created", 0);
            p.refreshStats();
            RPG.net.send(p, "dmz_open_creator", {});
            p.tell("&e[Test] Character reset.");
        }
    });

    RPG.commands.register("setrace", {
        permission: 2,
        description: "/rpgc setrace <race> - switch race, keeping this character's looks",
        run(p, args) {
            let race = String(args[0] || "");
            if (RPG.races.list().indexOf(race) < 0) { p.tell("&cRaces: " + RPG.races.list().join(", ")); return; }
            p.race = race;
            let d = DBR_RACE_DEFAULTS[race] || {};
            for (let k in d) p.setColor(k, String(d[k]));
            p.refreshStats();
            p.tell("&a[Test] Race set to " + race + ".");
        }
    });

    DBR_CMD.renamed("var", "dmzvar", {
        permission: 2,
        description: "/rpgc var <name> - show one of your script variables (for testing)",
        run(p, args) { p.tell("&7" + args[0] + " = &f" + JSON.stringify(p.getVar(String(args[0] || ""), null))); }
    });
})();
