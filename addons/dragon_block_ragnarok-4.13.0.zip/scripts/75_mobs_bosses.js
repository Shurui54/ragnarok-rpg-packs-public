// =====================================================================================
//  75_mobs_bosses.js - enemies, animals, the dragons, and every saga villain
// =====================================================================================
//  RPG.mobs.define makes a brand new creature drawn with a GeckoLib model:
//    geo: { model, texture, animation, idle, walk, run, attack, fly, swim, hurt, death, loops, scale }
//         (file paths inside a resource pack; animation names are the keys of the
//          "animations" object in the .animation.json file - see dmzpack_catalog.json)
//    health, damage, armor, speed, hostile (default true), attackRange, followRange,
//    xp (kill XP), loot: [{ item, count, chance }], scale, persistent
//    onTick(mob, seconds) / onHurt(mob, attacker) / onDeath(mob, killer)
//  Spawn one by hand:  /rpg mob saibaman     From code:  RPG.world.spawnMob(dim, id, x, y, z)
//
//  RPG.bosses.define adds boss rules on top of a mob body (mob: "id"): a boss bar, phases,
//  rewards for everyone who helped, announcements. Spawn with /rpg boss raditz, or from
//  code with player.spawnBoss("raditz"). Natural spawning is in 80_spawns_events.js.
// =====================================================================================

// Gives Zeni to whoever landed the killing blow (killer can be null or a mob).
// Mr. Satan's badge (offhand, 50_items.js) adds 25%.
function payKiller(killer, min, max) {
    let player = killer ? killer.asPlayer() : null;
    if (!player) return;
    let zeni = RPG.randomInt(min, max);
    if (player.stat("fame") > 0) zeni = Math.floor(zeni * 1.25);
    player.addMoney(zeni);
}

// A DMZ saga model as a mob body (sagaLook is in 60_npcs_dialogue.js).
function sagaMob(id, spec) {
    RPG.mobs.define(id, {
        name: spec.name,
        geo: sagaLook(spec.model, spec.texture, spec.scale),
        health: spec.health, damage: spec.damage, armor: spec.armor || 0, speed: spec.speed || 0.3,
        followRange: 40, xp: spec.xp || spec.health,
        hostile: spec.hostile !== false,
        loot: spec.loot || [],
        onHurt: spec.onHurt,
        // spec.kit: a DMZ saga kit id (43_dmz_saga_kits.js) - the DMZ enemy brain drives it (76_dmz_saga_ai.js)
        onTick: spec.kit || spec.onTick ? function (mob, s) {
            if (spec.kit && typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onTick(mob);
            else if (spec.onTick) spec.onTick(mob, s);
        } : undefined,
        onDeath(mob, killer) {
            if (spec.kit && typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onDeath(mob);
            payKiller(killer, spec.zeni ? spec.zeni[0] : 5, spec.zeni ? spec.zeni[1] : 20);
            if (spec.onDeath) spec.onDeath(mob, killer);
        }
    });
    if (spec.kit) DMZ_SAGA_ALIAS[id] = spec.kit;
}
// mob id -> DMZ kit id, read by 76_dmz_saga_ai.js
var DMZ_SAGA_ALIAS = {};

// =====================================================================================
//  Common enemies
// =====================================================================================

// Saibamen: six colour variants of one model. At 25% health one in twenty clings to a player's back and
// explodes (SagaSaibamanEntity, 98_dbr_quirks.js).
["", "_2", "_3", "_4", "_5", "_6"].forEach((suffix, i) => {
    RPG.mobs.define("saibaman" + suffix, {
        name: "&aSaibaman",
        geo: {
            model: DMZ_GEO + "sagas/saga_saibaman.geo.json",
            texture: DMZ_TEX + "sagas/saga_saibaman" + (i + 1) + ".png",
            animation: DMZ_ANIM + "sagas/saga_saibaman.animation.json",
            idle: "idle", walk: "walk", run: "run1", attack: "attack"
        },
        health: 80, damage: 15, armor: 0, speed: 0.2, followRange: 32, xp: 30 + i * 5,       // DMZ: 80 HP, 15 attack, 0.20 speed
        loot: [{ item: "senzu_bean", chance: 0.03 }, { item: "green_capsule", chance: 0.04 }],
        onDeath(mob, killer) { payKiller(killer, 5, 15); }
    });
});

// The DMZ enemy models each come with their own animation file.
function enemyGeo(name, texture) {
    return {
        model: DMZ_GEO + "enemies/" + name + ".geo.json",
        texture: DMZ_TEX + "enemies/" + (texture || name) + ".png",
        animation: DMZ_ANIM + "enemies/" + name + ".animation.json",
        idle: "idle", walk: "walk", run: "run", attack: name === "namekian" ? "attack1" : "attack",
        // every enemy file has "run" (NamekWarriorEntity/RedRibbonEntity chase with it); robotxv and namekian can fly
        fly: name === "robotxv" ? "fly" : name === "namekian" ? "fly_front" : undefined
    };
}

RPG.mobs.define("bandit", {
    name: "&7Desert Bandit",
    geo: enemyGeo("bandit"),
    health: 75, damage: 10, speed: 0.2, xp: 20,                     // entities.json: bandit 75 / 10
    loot: [
        { item: "cooked_dino_meat", chance: 0.3 },
        { item: "yellow_capsule", chance: 0.05 },
        { item: "radar_piece", chance: 0.01 }
    ],
    onDeath(mob, killer) {
        payKiller(killer, 5, 20);
        let player = killer ? killer.asPlayer() : null;
        if (!player) return;
        // The quest Dragon Ball: 25% while saga III is active, otherwise a rare 1%.
        let chance = player.isQuestActive("saiyan_3_dragon_ball") ? 0.25 : 0.01;
        if (RPG.chance(chance)) {
            player.giveItem("dball4", 1);
            player.tell("&6The bandit dropped the 4-Star Dragon Ball!");
        }
    }
});

RPG.mobs.define("red_ribbon_soldier", {
    name: "&cRed Ribbon Soldier",
    geo: enemyGeo("red_ribbon_soldier"),
    health: 40, damage: 5, armor: 0, speed: 0.2, attackRange: 2.5, xp: 45,      // entities.json: 40 / 5
    loot: [{ item: "minecraft:redstone", count: 2 }, { item: "minecraft:iron_nugget", count: 2 }],  // loot_tables/entities/red_ribbon_soldier
    onDeath(mob, killer) { payKiller(killer, 15, 40); }
});

// Red Ribbon robots: three paint jobs, and a flying XV model.
[1, 2, 3].forEach((n) => {
    RPG.mobs.define("rr_robot_" + n, {
        name: "&cRed Ribbon Robot Mk." + n,
        geo: enemyGeo("robot1", "robot" + n),
        health: 120, damage: 15, armor: 0, speed: 0.2, xp: 50 + n * 15,           // entities.json: robot1/2/3 120 / 15
        loot: [{ item: "minecraft:iron_ingot", count: 1 }, { item: "minecraft:redstone", count: 1 }, { item: "minecraft:iron_ingot", chance: 0.5 }, { item: "minecraft:redstone", chance: 0.5 }],
        onDeath(mob, killer) { payKiller(killer, 20, 50); RPG.world.particle(mob.dimension, "minecraft:large_smoke", mob.x, mob.y + 1, mob.z, 15, 0.4, 0.05); }
    });
});

RPG.mobs.define("battle_jacket", {
    name: "&cBattle Jacket",
    geo: enemyGeo("robotxv"),
    health: 120, damage: 12, armor: 10, speed: 0.28, xp: 150,
    loot: [{ item: "vehicle_engine", chance: 0.1 }, { item: "gete_ingot", chance: 0.2 }],
    onTick(mob, seconds) {
        if (seconds % 4 !== 0) return;
        mob.playAnimation("kiattack");
        mob.shoot("blaster_shot", { damage: 8 });
    },
    onDeath(mob, killer) { payKiller(killer, 40, 90); }
});

RPG.mobs.define("namek_warrior", {
    name: "&aNamekian Warrior",
    geo: enemyGeo("namekian", "namek_warrior_" + 0),
    hostile: false, health: 80, damage: 9, speed: 0.3, xp: 60,
    loot: [{ item: "namek_moss", chance: 0.5 }],
    onHurt(mob, attacker) { sfx(mob, "entity.namekian.vill.hurt", 1, 1); },
    onDeath(mob, killer) { sfx(mob, "entity.namekian.vill.death", 1, 1); }
});

// Frieza Force soldiers (three ranks).
[["frieza_soldier", "saga_friezasoldier01", "saga_friezasoldier01", "&dFrieza Soldier", 60, 9],
 ["frieza_soldier_heavy", "saga_friezasoldier02", "saga_friezasoldier02_1", "&dFrieza Heavy Trooper", 90, 12],
 ["frieza_soldier_elite", "saga_friezasoldier03", "saga_friezasoldier03_2", "&5Frieza Elite", 130, 15]].forEach((f) => {
    sagaMob(f[0], {
        name: f[3], model: f[1], texture: f[2], health: 100, damage: 15, armor: 0, speed: 0.2, xp: f[4], zeni: [20, 60], kit: f[1],
        loot: [{ item: "minecraft:iron_ingot", count: 1 }, { item: "minecraft:iron_ingot", chance: 0.5 }, { item: "blaster_cannon", chance: 0.05 }],
        onHurt(mob, attacker) { sfx(mob, "entity.frieza.s.hurt", 1, 1); },
        onDeath(mob, killer) { sfx(mob, "entity.frieza.s.death", 1, 1); }
    });
});

// Bioman (snowy biomes): 70 HP, 0.31 speed, 13 attack, follow 32, knockback resistance 0.5
sagaMob("bioman", { name: "&2Bioman", model: "saga_bioman", health: 70, damage: 13, speed: 0.31, xp: 70, zeni: [5, 20], kit: "saga_bioman" });
sagaMob("cell_jr", { name: "&2Cell Jr.", model: "saga_cell_jr", health: 220, damage: 18, armor: 8, speed: 0.36, xp: 400, zeni: [80, 160],
    loot: [{ item: "senzu_bean", chance: 0.1 }] });
// A Bio-Android's own Cell Jr. (BioAndroidEvolution.summonCellJr, CellJrEntity): never picks on anyone by itself, fights
// what 33_dmz_racials.js targets for it (anything but its owner and the owner's other Jrs), flies with the DMZ saga brain
// (kit bio_cell_jr, ELITE). Health and damage are set from the owner when it is summoned.
RPG.mobs.define("bio_cell_jr", {
    name: "&2Cell Jr.", geo: sagaLook("saga_cell_jr"), health: 20, damage: 2, speed: 0.35, followRange: 32, xp: 0,
    hostile: false, attacks: true, persistent: true,
    onTick(mob) { if (typeof DMZ_RACIALS !== "undefined") DMZ_RACIALS.cellJrTick(mob); },
    onDeath(mob) {
        if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onDeath(mob);
        if (typeof DMZ_RACIALS !== "undefined") DMZ_RACIALS.cellJrDied(mob);
    }
});
DMZ_SAGA_ALIAS["bio_cell_jr"] = "bio_cell_jr";
sagaMob("majin_soldier", { name: "&5Majin Soldier", model: "saga_morosoldier", health: 260, damage: 20, armor: 10, xp: 450, zeni: [90, 180],
    loot: [{ item: "majilite", chance: 0.3 }, { item: "demon_eye", chance: 0.02 }] });
sagaMob("gete_robot", { name: "&7Gete Star Drone", model: "saga_gete_robot", health: 300, damage: 22, armor: 14, speed: 0.25, xp: 500, zeni: [100, 200],
    loot: [{ item: "gete_scrap", count: 2 }, { item: "gete_ingot", chance: 0.3 }, { item: "gete_red_capsule", chance: 0.02 }] });
sagaMob("pilaf_robot", { name: "&ePilaf Machine", model: "saga_pilaf_robot", health: 90, damage: 9, armor: 8, speed: 0.22, xp: 120, zeni: [30, 80],
    loot: [{ item: "radar_piece", chance: 0.05 }, { item: "vehicle_plating", chance: 0.1 }] });
sagaMob("slug_soldier", { name: "&2Slug Soldier", model: "saga_slug_soldier", health: 110, damage: 11, armor: 6, xp: 150, zeni: [30, 70] });
sagaMob("gomah_soldier", { name: "&4Demon Soldier", model: "saga_gomah_soldier_1", health: 350, damage: 24, armor: 12, xp: 600, zeni: [120, 240] });

// Ogres of the Other World: two colours. They only go after evil players and call the others when one is hit
// (SagaOgreEntity targeting, 98_dbr_quirks.js).
["blue", "red"].forEach((c) => {
    sagaMob(c === "blue" ? "ogre" : "ogre_red", { name: "&9Ogre Warden", model: "saga_ogre", texture: "saga_ogre_" + c, armor: 0,
        health: 200, damage: 20, speed: 0.23, xp: 250, zeni: [40, 90], loot: [], kit: "saga_ogre_" + c, hostile: false,
        onHurt(mob, attacker) { if (typeof DBR_QUIRKS !== "undefined") DBR_QUIRKS.ogreHurt(mob, attacker); } });
});

// The training shadow: a sparring dummy that fires ki waves (it lives in the Time Chamber).
RPG.mobs.define("shadow_dummy", {
    name: "&8Training Shadow",
    geo: { model: DMZ_GEO + "sagas/shadow_dummy.geo.json", texture: DMZ_TEX + "sagas/shadow_dummy.png",
           animation: DMZ_ANIM + "sagas/shadow_dummy.animation.json", idle: "idle", walk: "walk", run: "run", fly: "fly", attack: "attack1" },
    health: 100, damage: 6, speed: 0.32, xp: 60,
    onTick(mob, seconds) {
        if (seconds % 5 !== 0) return;
        mob.playAnimation("kiwave");
        mob.shoot("ki_blast", { damage: 5, colors: { core: "#DDDDDD", border: "#555555", outline: "#111111" } });
    },
    onDeath(mob, killer) { let p = killer ? killer.asPlayer() : null; if (p) p.addTp(15); }
});

// =====================================================================================
//  Animals (peaceful until hit)
// =====================================================================================
// DMZ animates animal tails (sabertooth, dinosaurs) on a second controller: geo.loops plays "tail" the same way.
// Sabertooth and the Namek frogs run while chasing / fleeing; the giant fish swims.
function animalGeo(name, texture) {
    return {
        model: DMZ_GEO + "animal/" + name + ".geo.json",
        texture: DMZ_TEX + "animal/" + (texture || name) + ".png",
        animation: DMZ_ANIM + "animal/" + name + ".animation.json",
        idle: "idle", walk: name === "giantfish" ? "swim" : "walk",
        run: name === "sabertooth" ? "run" : undefined,
        swim: name === "giantfish" ? "swim" : undefined,
        attack: name === "giantturtle" ? undefined : "attack",       // turtles have no attack animation
        loops: /^(sabertooth|dino\d)$/.test(name) ? ["tail"] : undefined
    };
}

RPG.mobs.define("dinosaur", {
    name: "Dinosaur", geo: animalGeo("dino1"), hostile: false, health: 60, damage: 6, speed: 0.22, xp: 25,
    loot: [{ item: "raw_dino_meat", count: 2 }, { item: "dino_tail_raw", chance: 0.3 }]
});
RPG.mobs.define("triceratops", {
    name: "Triceratops", geo: animalGeo("dino2"), hostile: false, health: 90, damage: 9, speed: 0.2, xp: 35,
    loot: [{ item: "raw_dino_meat", count: 3 }]
});
RPG.mobs.define("tyrannosaurus", {
    name: "&6Tyrannosaurus", geo: animalGeo("dino3"), health: 140, damage: 14, speed: 0.26, xp: 80,
    loot: [{ item: "raw_dino_meat", count: 4 }, { item: "dino_tail_raw", count: 1 }]
});
RPG.mobs.define("baby_dino", {
    name: "Baby Dinosaur", geo: { model: DMZ_GEO + "animal/dinokid.geo.json", texture: DMZ_TEX + "animal/dinokid.png",
        animation: DMZ_ANIM + "animal/dinokid.animation.json", idle: "idle", walk: "walk", loops: ["tail"] },
    hostile: false, health: 16, damage: 1, speed: 0.3, xp: 8, loot: [{ item: "raw_baby_dino_meat", count: 1 }]
});

// DMZ rolls the skin when an animal spawns (finalizeSpawn; the giant fish's golden skin is a 3% rarity): 98_dbr_quirks.js
function dbrRollVariant(mob) { if (typeof DBR_QUIRKS !== "undefined") DBR_QUIRKS.rollVariant(mob); }
// Animals with several skins: one mob per skin, same model.
[0, 1, 2].forEach((n) => {
    RPG.mobs.define("sabertooth" + (n ? "_" + n : ""), {
        name: "&6Sabertooth", geo: animalGeo("sabertooth", "sabertooth_" + n), health: 35, damage: 6, speed: 0.34, xp: 30,
        loot: [], onTick: dbrRollVariant
    });
    RPG.mobs.define("giant_turtle" + (n ? "_" + n : ""), {
        name: "Giant Turtle", geo: animalGeo("giantturtle", "giantturtle_" + n), hostile: false, health: 50, damage: 2, speed: 0.12, xp: 15,
        loot: [{ item: "giant_turtle_raw", count: 1 }, { item: "turtle_scale", count: 2 }], onTick: dbrRollVariant
    });
    // NamekFrogEntity: three skins, 10 HP, speed 0.22; croaks and the 1-in-5 death laugh in 98_dbr_quirks.js
    RPG.mobs.define("namek_frog" + (n ? "_" + n : ""), {
        name: "&aNamekian Frog",
        geo: { model: DMZ_GEO + "animal/namekfrog.geo.json", texture: DMZ_TEX + "animal/namekfrog_" + n + ".png",
               animation: DMZ_ANIM + "animal/namekfrog.animation.json", idle: "idle", walk: "walk", run: "run" },
        hostile: false, health: 10, damage: 0, speed: 0.22, xp: 4, loot: [{ item: "frog_legs_raw", count: 1 }],
        onTick(mob, s) { if (typeof DBR_QUIRKS !== "undefined") DBR_QUIRKS.frogTick(mob, s); },
        onDeath(mob) { if (typeof DBR_QUIRKS !== "undefined") DBR_QUIRKS.frogDeath(mob); }
    });
});
// NamekFrogGinyuEntity: Captain Ginyu in a frog's body - skin 0 with his poses, 40 HP, speed 0.22
RPG.mobs.define("namek_frog_ginyu", {
    name: "&aNamekian Frog",
    geo: { model: DMZ_GEO + "animal/namekfrog.geo.json", texture: DMZ_TEX + "animal/namekfrog_0.png",
           animation: DMZ_ANIM + "animal/namekfrog.animation.json", idle: "idleginyu", walk: "walkginyu", run: "runginyu" },
    hostile: false, health: 40, damage: 0, speed: 0.22, xp: 4, loot: [{ item: "frog_legs_raw", count: 1 }],
    onTick(mob, s) { if (typeof DBR_QUIRKS !== "undefined") DBR_QUIRKS.frogTick(mob, s); },
    onDeath(mob) { if (typeof DBR_QUIRKS !== "undefined") DBR_QUIRKS.frogDeath(mob); }
});
[0, 1, 2, 3].forEach((n) => {
    RPG.mobs.define("giant_fish" + (n ? "_" + n : ""), {
        name: "Giant Fish", geo: animalGeo("giantfish", "giantfish_" + n), hostile: false, health: 30, damage: 4, speed: 0.3, xp: 12,
        loot: [{ item: "giant_fish_raw", count: 1 }], onTick: dbrRollVariant
    });
});

// =====================================================================================
//  The Eternal Dragons (summoned in 60_npcs_dialogue.js)
// =====================================================================================
RPG.mobs.define("shenron", {
    name: "&a&lShenron",
    geo: { model: DMZ_GEO + "dragon/shenron.geo.json", texture: DMZ_TEX + "dragon/shenron.png",
           animation: DMZ_ANIM + "dragon/shenron.animation.json", idle: "idle", scale: 3.5 },   // DragonWishEntity.getRenderScale
    hostile: false, health: 1000, armor: 30, speed: 0
});
RPG.mobs.define("porunga", {
    name: "&a&lPorunga",
    geo: { model: DMZ_GEO + "dragon/porunga.geo.json", texture: DMZ_TEX + "dragon/porunga.png",
           animation: DMZ_ANIM + "dragon/porunga.animation.json", idle: "idle", scale: 3.5 },   // DragonWishEntity.getRenderScale
    hostile: false, health: 1000, armor: 30, speed: 0
});
RPG.mobs.define("porunga_daima", {
    name: "&5&lDemon Realm Dragon",
    geo: { model: DMZ_GEO + "dragon/porunga_daima.geo.json", texture: DMZ_TEX + "dragon/porunga_daima.png",
           animation: DMZ_ANIM + "dragon/porunga_daima.animation.json", idle: "idle", scale: 7 },   // DragonWishEntity.getRenderScale
    hostile: false, health: 1000, armor: 30, speed: 0
});
// DMZ Ragnarok's dragons (SuDragonBallDefinitions: dragon assets and render scales). Apophis is DMZ's Shenron with the
// red Black Star skin; Super and Cerulean Shenron are DMZ Ragnarok's HD dragons.
RPG.mobs.define("apophis", {
    name: "&4&lApophis",
    geo: { model: DMZ_GEO + "dragon/shenron.geo.json", texture: "dbr:textures/entity/dragon/shenron_apophis.png",
           animation: DMZ_ANIM + "dragon/shenron.animation.json", idle: "idle", scale: 3 },
    hostile: false, health: 1000, armor: 30, speed: 0
});
RPG.mobs.define("super_shenron", {
    name: "&e&lSuper Shenron",
    geo: { model: "dbr:geo/entity/dragon/shenron_super.geo.json", texture: "dbr:textures/entity/dragon/shenron_super.png",
           animation: "dbr:animations/entity/dragon/shenron_hd.animation.json", idle: "idle", scale: 4 },
    hostile: false, health: 1000, armor: 30, speed: 0
});
RPG.mobs.define("cerulean_shenron", {
    name: "&b&lCerulean Shenron",
    geo: { model: "dbr:geo/entity/dragon/shenron_cerulean.geo.json", texture: "dbr:textures/entity/dragon/shenron_cerulean.png",
           animation: "dbr:animations/entity/dragon/shenron_hd.animation.json", idle: "idle", scale: 3 },
    hostile: false, health: 1000, armor: 30, speed: 0
});

// =====================================================================================
//  Bosses
// =====================================================================================
// defineBoss(id, spec) makes the mob body AND the boss rules in one go.
// spec: name, model, texture, scale, health, damage, armor, speed, xp, money, tp, loot,
//       color (boss bar), announce, death, ki: [projectile ids it fires], kiEvery (seconds),
//       next (the form it changes into instead of dying: Frieza's forms), music, phases.
function defineBoss(id, spec) {
    RPG.mobs.define(id, {
        name: spec.name,
        geo: sagaLook(spec.model, spec.texture, spec.scale),
        health: spec.health, damage: spec.damage, speed: spec.speed || 0.3, followRange: 48,
        persistent: true
    });
    RPG.bosses.define(id, {
        mob: id,
        name: spec.name,
        health: spec.health, damage: spec.damage, armor: spec.armor || 0, speed: spec.speed || 0.3,
        knockbackResistance: spec.knockbackResistance || 0.6,
        bossBar: { color: spec.color || "red", style: "notched_10" },
        range: 64,
        announce: spec.announce || "",
        deathMessage: spec.death || "",
        // Instead of dying, the boss transforms in place into `next` (same fight, new model and stats).
        nextForm: spec.next || "",
        xp: spec.xp || spec.health * 2, money: spec.money || spec.health, tp: spec.tp || Math.floor(spec.health / 2),
        loot: spec.loot || [],
        phases: spec.phases || [{
            at: 0.5,
            message: spec.rage || "",
            onEnter(boss) {
                boss.playAnimation("transformation_1");
                boss.addPotion("minecraft:speed", 20 * 60, 1);
                sfx(boss, "transform_on", 1.5, 0.8);
            }
        }],
        onSpawn(boss) { if (spec.music) sfx(boss, spec.music, 1.5, 1); },
        // Runs once a second. phase = how many phases have started.
        onTick(boss, seconds, phase) {
            let every = Math.max(2, (spec.kiEvery || 5) - phase);
            if (!spec.ki || seconds % every !== 0) return;
            let players = boss.nearby(24).filter((e) => e.isPlayer());
            if (players.length === 0) return;
            let shot = spec.ki[RPG.randomInt(0, spec.ki.length - 1)];
            boss.playAnimation(PROJECTILES[shot].shape === "beam" ? "grab_ki" : "ki_blast");
            boss.shoot(shot, { damage: spec.damage * (PROJECTILES[shot].shape === "beam" ? 0.6 : 0.8) });
        },
        onTransform(boss, nextId) {
            // a burst of power as the next form takes over
            RPG.world.particle(boss.dimension, "minecraft:explosion_emitter", boss.x, boss.y + 1, boss.z, 1, 0, 0);
            sfx(boss, "transform_on", 2, 0.7);
            boss.playAnimation("transformation_1");
        },
        onDeath(boss, killer) {
            RPG.world.particle(boss.dimension, "minecraft:explosion_emitter", boss.x, boss.y + 1, boss.z, 1, 0, 0);
        }
    });
}

// ---- Saiyan Saga -------------------------------------------------------------------------
defineBoss("raditz", { name: "&c&lRaditz", model: "saga_raditz", health: 450, damage: 12, armor: 6, speed: 0.32,
    announce: "&4&lRaditz has landed! &cHis power level is over 1,500!", death: "&6Raditz has been defeated!",
    rage: "&cRaditz: &fYou're stronger than I thought... but not strong enough! &4&lDOUBLE SUNDAY!",
    ki: ["boss_ki_blast"], loot: [{ item: "raditz_armor_legs", chance: 0.5 }] });

defineBoss("nappa", { name: "&c&lNappa", model: "saga_nappa", health: 800, damage: 16, armor: 10, speed: 0.28,
    announce: "&4Nappa: &f'Vegeta! Can I play with them?'", death: "&6Nappa has fallen!",
    ki: ["boss_ki_blast", "boss_beam"], loot: [{ item: "saiyan_armor_boots", chance: 0.5 }] });

defineBoss("vegeta_saiyan", { name: "&b&lVegeta", model: "saga_vegeta", health: 1200, damage: 20, armor: 12, speed: 0.34,
    announce: "&b&lVegeta: &f'I'll show you the power of the Saiyan elite!'", rage: "&bVegeta: &f'GALICK GUN!'",
    ki: ["galick_gun", "boss_ki_blast"], next: "oozaru_vegeta",
    death: "&7Vegeta makes an artificial moon...", loot: [{ item: "saiyan_armor_chest", chance: 0.5 }] });

defineBoss("oozaru_vegeta", { name: "&6&lGreat Ape Vegeta", model: "saga_ozaru", texture: "saga_ozaruvegeta", scale: 2.5, health: 1800, damage: 26,
    armor: 14, speed: 0.22, knockbackResistance: 1, color: "yellow",
    announce: "&6&lVegeta transforms into a Great Ape!", death: "&6Vegeta retreats to his pod... Saiyan Saga complete!",
    ki: ["mouth_blast"], kiEvery: 6, loot: [{ item: "oozaru_root", count: 3 }],
    phases: [{ at: 0.3, message: "&6Vegeta: &f'I'll crush you in my hand!'", onEnter(boss) { sfx(boss, "vegeta_oozaru_growl", 2, 1); } }] });

// ---- Namek Saga ---------------------------------------------------------------------------
defineBoss("dodoria", { name: "&d&lDodoria", model: "saga_dodoria", health: 1500, damage: 22, armor: 14, speed: 0.26,
    announce: "&dDodoria: &f'Frieza wants the Dragon Balls. You're in the way.'", ki: ["boss_beam"], death: "&6Dodoria has been defeated!" });

defineBoss("zarbon", { name: "&a&lZarbon", model: "saga_zarbon", health: 1700, damage: 22, armor: 12, speed: 0.33,
    announce: "&aZarbon: &f'Such an ugly fight... let's end it beautifully.'", ki: ["boss_ki_blast"], next: "zarbon_monster",
    death: "&2Zarbon: &f'Now you've done it. Behold my true form!'" });

defineBoss("zarbon_monster", { name: "&2&lZarbon (Transformed)", model: "saga_zarbont1", health: 2200, damage: 28, armor: 16, speed: 0.3,
    ki: ["boss_beam", "boss_ki_blast"], death: "&6Zarbon is finished!", loot: [{ item: "pattern_namek_saiyan_armor", chance: 0.5 }] });

[["guldo", "&a&lGuldo", 1400, "&aGuldo: &f'I can stop time! ...briefly!'"], ["recoome", "&6&lRecoome", 2600, "&6Recoome: &f'RECOOME... ERASER GUN!'"],
 ["burter", "&9&lBurter", 2200, "&9Burter: &f'The fastest in the universe!'"], ["jeice", "&c&lJeice", 2200, "&cJeice: &f'Crusher Ball!'"],
 ["ginyu", "&5&lCaptain Ginyu", 3200, "&5Ginyu: &f'BODY... CHANGE!'"]].forEach((g) => {
    defineBoss(g[0], { name: g[1], model: "saga_" + g[0], health: g[2], damage: 26, armor: 14, speed: g[0] === "burter" ? 0.42 : 0.32,
        color: "purple", announce: g[3], ki: ["boss_ki_blast"], kiEvery: 4, death: "&6" + g[1].replace(/&./g, "") + " is down!",
        loot: [{ item: "blue_scouter", chance: 0.2 }] });
});

// Frieza: four forms, one after another (each form transforms into its `next` instead of dying).
defineBoss("frieza_first", { name: "&5&lFrieza", model: "saga_frieza_first", health: 3000, damage: 30, armor: 16, color: "purple",
    announce: "&5&lFrieza: &f'Do you know what my power level is? 530,000.'", ki: ["death_beam"], kiEvery: 3, next: "frieza_second",
    death: "&5Frieza: &f'I'll show you my second form!'" });
defineBoss("frieza_second", { name: "&5&lFrieza (Second Form)", model: "saga_frieza_second", health: 3800, damage: 34, armor: 18, color: "purple",
    ki: ["death_beam", "boss_ki_blast"], kiEvery: 3, next: "frieza_third", death: "&5Frieza: &f'Third form. Prepare yourself.'" });
defineBoss("frieza_third", { name: "&5&lFrieza (Third Form)", model: "saga_frieza_third", health: 4600, damage: 38, armor: 20, color: "purple",
    ki: ["death_beam", "boss_beam"], kiEvery: 3, next: "frieza_final", death: "&5Frieza: &f'Now... my FINAL form.'" });
defineBoss("frieza_final", { name: "&5&lFrieza (Final Form)", model: "saga_frieza_base", health: 5600, damage: 44, armor: 22, color: "purple",
    ki: ["death_beam", "supernova"], kiEvery: 4, next: "frieza_full_power", death: "&5Frieza: &f'100%! I'LL USE 100%!'" });
defineBoss("frieza_full_power", { name: "&5&l100% Full Power Frieza", model: "saga_frieza_fp", health: 7000, damage: 52, armor: 24, color: "purple",
    ki: ["death_beam", "supernova", "boss_beam"], kiEvery: 3, death: "&6&lFrieza has been defeated!",
    loot: [{ item: "kaioshin_fruit", chance: 0.25 }, { item: "frieza_capsule", chance: 0.2 }] });

// ---- Android Saga -------------------------------------------------------------------------
defineBoss("android_19", { name: "&f&lAndroid 19", model: "saga_a19", health: 4000, damage: 36, armor: 18, ki: ["eye_laser"], kiEvery: 3,
    announce: "&fAndroid 19: &f'Energy absorption... ready.'", loot: [{ item: "t1_radar_cpu", chance: 0.5 }] });
defineBoss("dr_gero", { name: "&7&lDr. Gero (Android 20)", model: "saga_drgero", health: 4200, damage: 36, armor: 18, ki: ["eye_laser", "boss_ki_blast"],
    announce: "&7Dr. Gero: &f'My revenge on Goku begins now.'", loot: [{ item: "pattern_gero_outfit", chance: 0.5 }] });
defineBoss("android_17", { name: "&b&lAndroid 17", model: "saga_a17", health: 6000, damage: 44, armor: 22, ki: ["boss_ki_blast", "boss_beam"],
    loot: [{ item: "pattern_android_17_outfit", chance: 0.3 }] });
defineBoss("android_18", { name: "&e&lAndroid 18", model: "saga_a18", health: 6000, damage: 44, armor: 22, ki: ["destructo_disk", "boss_ki_blast"],
    loot: [{ item: "pattern_android_18_outfit", chance: 0.3 }] });
defineBoss("cell_imperfect", { name: "&2&lImperfect Cell", model: "saga_cell_imperfect", health: 6500, damage: 46, armor: 22, color: "green",
    ki: ["kamehameha", "special_beam_cannon"], next: "cell_semi_perfect", death: "&2Cell absorbs Android 17... Semi-Perfect!" });
defineBoss("cell_semi_perfect", { name: "&2&lSemi-Perfect Cell", model: "saga_cell_semiperfect", health: 7500, damage: 50, armor: 24, color: "green",
    ki: ["kamehameha", "boss_beam"], next: "cell_perfect", death: "&2Cell absorbs Android 18... PERFECT!" });
defineBoss("cell_perfect", { name: "&2&lPerfect Cell", model: "saga_cell_perfect", health: 9000, damage: 56, armor: 26, color: "green",
    ki: ["kamehameha", "kill_driver", "final_flash"], death: "&6Perfect Cell has been defeated!", loot: [{ item: "mastery_capsule", chance: 0.5 }] });
defineBoss("cell_super_perfect", { name: "&e&lSuper Perfect Cell", model: "saga_cell_perfect", texture: "saga_cell_superperfect", health: 12000, damage: 64,
    armor: 28, color: "yellow", ki: ["kamehameha", "kill_driver", "final_flash"], kiEvery: 3,
    announce: "&e&lCell: &f'I've come back... even stronger!'", death: "&6&lCell is destroyed for good!" });

// ---- Majin Buu Saga -------------------------------------------------------------------------
defineBoss("spopovitch", { name: "&5&lSpopovitch", model: "saga_spopovitch", health: 8000, damage: 50, armor: 24, color: "purple" });
defineBoss("pui_pui", { name: "&5&lPui Pui", model: "saga_puipui", health: 8500, damage: 52, armor: 24, color: "purple", ki: ["boss_ki_blast"] });
defineBoss("yakon", { name: "&5&lYakon", model: "saga_yakon", health: 10000, damage: 56, armor: 26, color: "purple", loot: [{ item: "light_shield", count: 4 }] });
defineBoss("dabura", { name: "&4&lDabura", model: "saga_dabura", health: 13000, damage: 64, armor: 28, color: "red", ki: ["boss_beam", "boss_ki_blast"],
    loot: [{ item: "demon_eye", count: 2 }] });
defineBoss("majin_buu", { name: "&d&lMajin Buu", model: "saga_buufat", health: 16000, damage: 66, armor: 30, color: "pink", ki: ["candy_beam", "planet_burst"],
    knockbackResistance: 1, death: "&dBuu splits in two... and the evil half eats the good one." });
defineBoss("super_buu", { name: "&d&lSuper Buu", model: "saga_superbuu", health: 20000, damage: 76, armor: 32, color: "pink",
    ki: ["planet_burst", "boss_beam"], kiEvery: 3, death: "&dSuper Buu reverts... to his original form." });
defineBoss("kid_buu", { name: "&d&lKid Buu", model: "saga_kidbuu", health: 25000, damage: 86, armor: 34, color: "pink", speed: 0.38,
    ki: ["planet_burst", "boss_beam", "spirit_bomb"], kiEvery: 4, death: "&6&lKid Buu is finally gone!", music: "worldboss_music.janemba" });

// ---- Tournament & side bosses -----------------------------------------------------------
defineBoss("tournament_nam", { name: "&eNam", model: "saga_nam", health: 600, damage: 10, color: "yellow" });
defineBoss("tournament_giran", { name: "&eGiran", model: "saga_giran", health: 800, damage: 12, color: "yellow" });
defineBoss("jackie_chun", { name: "&e&lJackie Chun", model: "saga_jackie_chun", health: 1100, damage: 14, color: "yellow", ki: ["kamehameha"], kiEvery: 8,
    next: "jackie_chun_max", death: "&eJackie Chun: &f'Ho ho... MAX POWER!'" });
defineBoss("jackie_chun_max", { name: "&e&lJackie Chun (Max Power)", model: "saga_jackie_chun_fp", health: 900, damage: 18, color: "yellow", ki: ["kamehameha"] });
defineBoss("pikkon", { name: "&f&lPikkon", model: "saga_paikuhan", health: 9000, damage: 50, armor: 24, color: "white", ki: ["boss_beam"], kiEvery: 4 });
defineBoss("dracula_man", { name: "&5Dracula Man", model: "saga_dracula", health: 500, damage: 9, color: "purple" });
defineBoss("invisible_man", { name: "&7Invisible Man", model: "saga_invisible_man", health: 450, damage: 10, color: "white",
    phases: [{ at: 0.6, message: "&7...where did he go?", onEnter(boss) { boss.addPotion("minecraft:invisibility", 200, 0); } }] });
defineBoss("akkuman", { name: "&4Akkuman", model: "saga_akkuman", health: 700, damage: 12, color: "red", ki: ["boss_beam"], kiEvery: 7 });

// ---- World bosses (random events in 80_spawns_events.js) ---------------------------------
defineBoss("turles", { name: "&5&lTurles", model: "saga_turles", health: 9000, damage: 50, armor: 22, ki: ["boss_ki_blast", "boss_beam"],
    announce: "&5&lTurles has planted the Tree of Might!", music: "worldboss_music.turles",
    loot: [{ item: "might_tree_fruit", count: 1 }, { item: "pattern_turles_armor", chance: 0.4 }] });
defineBoss("lord_slug", { name: "&2&lLord Slug", model: "saga_slug", health: 9500, damage: 50, armor: 24, color: "green", ki: ["boss_beam"],
    announce: "&2&lLord Slug wants to freeze the Earth!", loot: [{ item: "pattern_slug_robe", chance: 0.4 }] });
defineBoss("cooler", { name: "&5&lCooler", model: "saga_cooler", health: 11000, damage: 56, armor: 26, color: "purple", ki: ["death_beam", "supernova"],
    next: "cooler_final", announce: "&5&lCooler has come to avenge his brother!" });
defineBoss("cooler_final", { name: "&5&lCooler (Final Form)", model: "saga_cooler_5ta", health: 13000, damage: 62, armor: 28, color: "purple",
    ki: ["supernova", "boss_beam"], loot: [{ item: "kaioshin_fruit", chance: 0.3 }] });
defineBoss("metal_cooler", { name: "&7&lMetal Cooler Core", model: "saga_metal_cooler_core", health: 18000, damage: 60, armor: 34, color: "white",
    ki: ["boss_beam", "eye_laser"], music: "worldboss_music.metal_cooler_core", announce: "&7&lThe Big Gete Star has arrived!",
    loot: [{ item: "gete_ingot", count: 6 }, { item: "gete_blue_capsule", chance: 0.3 }, { item: "gete_purple_capsule", chance: 0.3 }] });
defineBoss("broly", { name: "&a&lBroly", model: "saga_broly_lssj", health: 22000, damage: 80, armor: 30, color: "green", speed: 0.36,
    ki: ["blaster_meteor", "boss_beam"], kiEvery: 3, announce: "&a&l'KAKAROT!!!' &2A Legendary Super Saiyan is rampaging!",
    loot: [{ item: "pattern_broly_jewelry", chance: 0.4 }, { item: "pattern_broly_super_armor", chance: 0.2 }] });
defineBoss("bojack", { name: "&3&lBojack", model: "saga_bojack", health: 12000, damage: 58, armor: 26, color: "blue", ki: ["boss_beam"],
    next: "bojack_full_power", announce: "&3&lBojack's Galaxy Soldiers crash the tournament!" });
defineBoss("bojack_full_power", { name: "&3&lBojack (Full Power)", model: "saga_bojack_fp", health: 14000, damage: 64, armor: 28, color: "blue", ki: ["boss_beam"] });
defineBoss("janemba", { name: "&4&lSuper Janemba", model: "saga_super_janemba", health: 24000, damage: 82, armor: 32, color: "red",
    ki: ["boss_beam", "planet_burst"], music: "worldboss_music.janemba", announce: "&4&lReality is breaking: Janemba is here!",
    loot: [{ item: "dimensional_sword", chance: 0.25 }] });
defineBoss("hirudegarn", { name: "&6&lHirudegarn", model: "saga_hirudegarn", scale: 1.5, health: 26000, damage: 78, armor: 34, color: "yellow",
    ki: ["boss_beam"], announce: "&6&lThe phantom beast Hirudegarn awakens!" });
defineBoss("baby_vegeta", { name: "&f&lBaby Vegeta", model: "saga_baby_vegeta", health: 24000, damage: 80, armor: 30, color: "white",
    ki: ["boss_beam", "galick_gun"], announce: "&f&lBaby has taken over Vegeta's body!" });
defineBoss("super_17", { name: "&8&lSuper 17", model: "saga_super_17", health: 25000, damage: 82, armor: 32, color: "white",
    ki: ["boss_beam", "eye_laser"], announce: "&8&lHell's gates open: Super 17 emerges!" });
defineBoss("omega_shenron", { name: "&f&lOmega Shenron", model: "saga_omega_shenron", health: 32000, damage: 95, armor: 36, color: "white",
    ki: ["spirit_bomb", "boss_beam"], kiEvery: 4, announce: "&f&lThe Dragon Balls have turned evil!",
    loot: [] });
defineBoss("gomah", { name: "&4&lGomah", model: "saga_gomah_third_eye", health: 28000, damage: 88, armor: 34, color: "red",
    ki: ["boss_beam"], music: "worldboss_music.gomah", announce: "&4&lThe Demon King Gomah invades!",
    loot: [] });

// The Tamagami: the three guardians of the Dragon Balls, each with its own boss music.
[1, 2, 3].forEach((n) => {
    defineBoss("tamagami_" + n, {
        name: "&6&lTamagami No. " + n, model: "saga_tamagami_" + n, health: 20000 + n * 5000, damage: 70 + n * 8, armor: 30 + n * 2,
        color: "yellow", ki: ["boss_beam", "boss_ki_blast"], music: "worldboss_music.tamagami_" + n,
        announce: "&6&lTamagami No. " + n + " awakens to test you!",
        loot: [{ item: ["tamagami_sword", "tamagami_hammer", "tamagami_trident"][n - 1], chance: 0.3 }, { item: "dball" + n + "_demon", count: 1 }]
    });
});
