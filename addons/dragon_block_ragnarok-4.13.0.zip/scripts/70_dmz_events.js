// =====================================================================================
//  70_dmz_events.js - DragonMine Z's world events
// =====================================================================================
//  Ported from DragonMine Z (GPL-3.0):
//   - Hell stampede (server/events/HellStampedeEvents.java): stay in Hell (Other World, y < 96)
//     8-14 minutes and 20 Mini Janembas charge at you.
//   - Halloween evil clones (common/util/HalloweenEvent.java, EvilCloneEntity, biome_modifier
//     evil_clones.json): on October 31st, at night, evil Goku/Vegeta/Piccolo/Nappa/Krillin roam.
//   - Gete Star robots raid Namek villages (server/events/GeteSpawnEvents.java).
//  DMZ has no other timed world events: its Dragon Balls (57_dragon_balls.js), world bosses and
//  raids are separate systems.
// =====================================================================================

// ---- mobs these events need ---------------------------------------------------------------
// MiniJanembaStampedeEntity: 20 HP, speed 0.42, damage 2, hitbox 0.45 x 0.95, despawns after 40 s
// or 1 s without a target; never saved.
RPG.mobs.define("mini_janemba_stampede", {
    name: "&eMini Janemba",
    geo: sagaLook("saga_janemba_fat", "saga_janemba_fat"),
    health: 20, damage: 2, speed: 0.42, followRange: 48, xp: 5, scale: 0.5,
    onTick(mob, seconds) {
        if (seconds >= 40 || (seconds > 1 && !mob.target)) {
            RPG.world.particle(mob.dimension, "minecraft:large_smoke", mob.x, mob.y + 0.4, mob.z, 12, 0.25, 0.02);
            mob.remove();
        }
    }
});

// EvilCloneEntity: 1800 HP, speed 0.25, damage 90, knockback resistance 0.6, follow 32, small ki blasts.
[["goku", "saga_goku_ssj2", 1.0], ["vegeta", "saga_vegeta", 1.0], ["piccolo", "saga_piccolo_kami", 1.0],
 ["nappa", "saga_nappa", 1.0], ["krillin", "saga_vegeta", 0.8]].forEach((c) => {
    RPG.mobs.define("evil_clone_" + c[0], {
        name: "&4Evil " + c[0].charAt(0).toUpperCase() + c[0].substring(1),
        geo: sagaLook(c[1], "evil_clone_" + c[0], c[2]),
        health: 1800, damage: 90, speed: 0.25, followRange: 32, xp: 1200,
        onTick(mob, seconds) {
            if (seconds % 4 === 0 && mob.target) mob.shoot("ki_blast", { damage: 140, colors: { core: "#FF2A3A", border: "#4A0008", outline: "#1A0003" } });
        }
    });
});

// ---- Hell stampede ---------------------------------------------------------------------------
var STAMPEDE_AT = {};                   // uuid -> seconds left (DMZ keeps this in memory too)
function dmzInHell(p) {
    let g = String(p.getGameMode());
    return p.dimension === "ragnarok_rpg:otherworld" && p.y < 96 && g !== "creative" && g !== "spectator";
}
RPG.on("playerTick", (p) => {
    let id = p.getUuid();
    if (!dmzInHell(p)) { delete STAMPEDE_AT[id]; return; }
    if (STAMPEDE_AT[id] === undefined) STAMPEDE_AT[id] = RPG.randomInt(8 * 60, 14 * 60);
    if (--STAMPEDE_AT[id] > 0) return;
    delete STAMPEDE_AT[id];
    dmzSpawnStampede(p);
});
RPG.on("playerLeave", (p) => { delete STAMPEDE_AT[p.getUuid()]; });

// 20 Mini Janembas in a band 20 blocks ahead, 16 wide, 6 deep, all charging the player.
function dmzSpawnStampede(p) {
    let a = Math.random() * Math.PI * 2, fx = Math.cos(a), fz = Math.sin(a), sx = -fz, sz = fx;
    let ox = p.x + fx * 20, oz = p.z + fz * 20, spawned = 0;
    for (let i = 0; i < 20; i++) {
        let side = (Math.random() - 0.5) * 16, depth = Math.random() * 6;
        let x = ox + sx * side + fx * depth, z = oz + sz * side + fz * depth;
        let y = dmzFindGround(p.dimension, Math.floor(x), Math.floor(p.y), Math.floor(z));
        if (y === null) continue;
        let m = RPG.world.spawnMob(p.dimension, "mini_janemba_stampede", Math.floor(x) + 0.5, y, Math.floor(z) + 0.5);
        if (!m) continue;
        m.target = p;
        spawned++;
    }
    if (spawned === 0) return;
    p.actionbar("&cYou've lingered in Hell too long... a Mini Janemba stampede is coming!");
    RPG.world.sound(p.dimension, "minecraft:entity.ravager.roar", ox, p.y, oz, 1.5, 1.6);
}
// HellStampedeEvents.findGround: from 6 above to 10 below, solid floor with two free blocks.
function dmzFindGround(dim, x, y, z) {
    if (!RPG.world.isLoaded(dim, x, z)) return null;
    for (let dy = 6; dy >= -10; dy--) {
        let feet = y + dy;
        let below = RPG.world.getBlock(dim, x, feet - 1, z);
        if (below === "minecraft:air" || below.indexOf("cloud") >= 0) continue;
        if (RPG.world.getBlock(dim, x, feet, z) !== "minecraft:air" || RPG.world.getBlock(dim, x, feet + 1, z) !== "minecraft:air") continue;
        return feet;
    }
    return null;
}

// ---- Halloween evil clones (natural spawns only on Oct 31, at night) ---------------------------
function dmzHalloween() { return DBR_QUIRKS_DATA.halloween(); }     // shared/27_dbr_quirks.js (config dbr_quirks halloween)
// biome_modifier evil_clones.json: weight 10 each (krillin 1-2), monster spawn rules (dark, night)
["goku", "vegeta", "piccolo", "nappa", "krillin"].forEach((c) => {
    RPG.spawns.define("dmz_evil_clone_" + c, {
        mob: "evil_clone_" + c, dimensions: ["minecraft:overworld"], time: "night", light: "dark",
        interval: 600, chance: 0.1, group: c === "krillin" ? [1, 2] : [1, 1], maxNearby: 2,
        minDistance: 24, maxDistance: 48, condition: () => dmzHalloween()
    });
});

// ---- Gete Star robots raid Namek villages ------------------------------------------------------
// Every 400 ticks: villages within 6 chunks of a player, 25% chance each, at most 3 robots per
// village; a wave of 1-2 robots 8-20 blocks outside the village, at least 16 from players.
RPG.every(400, () => {
    let built = typeof dmzBuilt === "function" ? dmzBuilt() : {};
    let players = RPG.server.players().filter((p) => p.dimension === "ragnarok_rpg:namek" && String(p.getGameMode()) !== "spectator");
    if (players.length === 0) return;
    for (let k in built) {
        let v = built[k];
        if (!v.done || v.dim !== "ragnarok_rpg:namek" || v.name.indexOf("village_") !== 0) continue;
        let cx = v.x + v.sx / 2, cz = v.z + v.sz / 2;
        if (!players.some((p) => Math.abs(p.x - cx) < 96 + v.sx / 2 && Math.abs(p.z - cz) < 96 + v.sz / 2)) continue;
        if (!RPG.chance(0.25)) continue;
        let radius = Math.min(80, Math.max(v.sx, v.sz) / 2);
        let have = RPG.world.entitiesNear(v.dim, cx, v.y + 10, cz, radius + 48, "ragnarok_rpg:mob").filter((e) => e.getRpgId() === "gete_robot").length;
        let room = 3 - have;
        if (room <= 0) continue;
        let size = Math.min(room, RPG.randomInt(1, 2)), angle = Math.random() * Math.PI * 2;
        for (let i = 0; i < size; i++) {
            for (let tries = 0; tries < 8; tries++) {
                let a = angle + (Math.random() - 0.5) * 0.6, d = radius + RPG.randomInt(8, 20);
                let x = Math.floor(cx + Math.cos(a) * d), z = Math.floor(cz + Math.sin(a) * d);
                if (players.some((p) => (p.x - x) * (p.x - x) + (p.z - z) * (p.z - z) < 256)) continue;
                if (!RPG.world.isLoaded(v.dim, x, z)) continue;
                let y = RPG.world.surfaceY(v.dim, x, z);
                if (y <= -9999) continue;
                let robot = RPG.world.spawnMob(v.dim, "gete_robot", x + 0.5, y, z + 0.5);
                if (robot) robot.moveTo(cx, y, cz, 1.0);                 // heads for the village
                break;
            }
        }
    }
});
