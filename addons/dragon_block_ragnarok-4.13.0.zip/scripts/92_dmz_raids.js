// =====================================================================================
//  92_dmz_raids.js - DragonMine Z's raids (the "random" raids at raid sites)
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): server/world/raid/{Raid, RaidManager, RaidSiteManager, RaidTriggerEvents,
//  RaidFeedback, RaidReward, RaidTeams, RaidEntityResolver, RaidSavedData, RaidTypes, RaidType},
//  common/config/{RaidDefaults, RaidDefinition}, server/commands/RaidCommand, client/systems/raid/RaidMusicManager,
//  common/init/entities/sagas/SagaSaiyanInvadersEntity (the soldiers and elites, and the elites' fake moon) and
//  MainEffects RAID_WRATH ("Hunted") / WORLD_HERO.
//  (DMZ Ragnarok's sign-up raid bosses, rifts and Z-Souls are a different feature: 92_dbr_raids*.js.)
//
//  How a raid happens (DMZ):
//   - Raid sites: Saiyan craters (Overworld), razed Namekian settlements (Namek), Gomah camps (Demon Realm) are
//     built by 66_dmz_sites.js, Red Ribbon bases (Overworld) by 65_dmz_structures.js. Every 2 seconds the sites
//     within reach of a player get their crew if it is missing (a Saiyan pod and a scout, a Frieza soldier, a Demon
//     soldier, or the Red Ribbon commander with 16 soldiers and 3 robots on the base's own spots), smoke at their
//     centre, and each player who comes within 80 blocks is told once ("Your scouter picks up a Saiyan pod...").
//   - Kill the scout and you are Hunted (60 s, the preparation music plays, "With his last breath the Saiyan
//     called for backup..."). The site is spent. When Hunted runs out the raid starts where you stand, with your
//     whole party; milk / dying / leaving cancels it.
//   - A raid is 5 waves around that spot (soldiers first; the bosses of a wave stay dormant until its escort is
//     dead). Boss bar "<raid> - Wave n/5 - k left" (purple on a boss wave), raid music, mobs glow every 10 s,
//     5 s between waves. Leave 80 blocks for 15 s, die or log out and you are out; when nobody is left the raid
//     is lost: "YOU LOST!" and the alignment cost. Win: rewards (TP, Hero of the Village + World Hero, items),
//     the victory music, a totem burst and fireworks.
//  Op test command (DMZ's /dmzraid): /rpgc siteraid start [saiyan_assault|frieza_invasion|gomah_assault|red_ribbon_assault]
//  | stop | info   (the old /dmzraid still works), and /rpgc siteraid omen [type] to be Hunted at once.
//  Config: ragnarok_rpg/config/dmz_raids.json (/rpg config dmz_raids): enabled, and each raid on or off.
//  Approximations: DMZ draws Saiyan invaders with the player renderer (random hair, skin, armour, scouter); here
//  they use DMZ's own saga Saiyan models (Raditz / Turles soldiers, Nappa / Vegeta elites). The trigger chance on
//  naturally spawned saga mobs is 0 in every DMZ default, so natural spawns never mark a scout.
// =====================================================================================
var DMZ_RAIDS_CFG = RPG.config.define("dmz_raids", {
    enabled: { default: true, client: true, comment: "DragonMine Z's raids: scouts at raid sites, the Hunted omen and the raid waves (off: no scouts are placed and no raid starts)" },
    saiyan_assault: { default: true, comment: "Saiyan Assault (Saiyan craters, Overworld)" },
    frieza_invasion: { default: true, comment: "Frieza's Invasion (razed Namekian settlements, Namek)" },
    gomah_assault: { default: true, comment: "Gomah's Army (Gomah camps, Demon Realm)" },
    red_ribbon_assault: { default: true, comment: "Red Ribbon Army Assault (Red Ribbon bases, Overworld)" }
});

// the DMZ config menu's Server row (client/scripts/54_dmz_config_menu.js): ops switch the raids on or off live
RPG.net.on("dmz_raids_set", function (p, d) {
    var op = false;
    try { op = p.isOp(); } catch (e) { }
    if (op && d && d.key === "enabled") DMZ_RAIDS_CFG.set("enabled", !!d.value);
});
var DMZ_RAIDS = (function () {
    var C = DMZ_RAIDS_CFG;
    var DATA_KEY = "dmz_raids", SITES_KEY = "dmz_raid_sites";
    // Raid
    var SKY_SPAWN_HEIGHT = 22, GLOW_INTERVAL = 200, GLOW_DURATION = 200, LEASH_GRACE = 15 * 20;
    var GROUND_SEARCH_UP = 24, WALKER_SEARCH_UP = 4, GROUND_SEARCH_DOWN = 32, MISSING_BEFORE_LOST = 30 * 20;
    // RaidFeedback
    var VICTORY_MUSIC = "dmzpack:menu_music_12", HERO_TICKS = 20 * 60 * 10;
    // RaidSiteManager
    var SCAN_INTERVAL = 40, ANNOUNCE_RADIUS = 80, ANNOUNCE_HEIGHT = 48, MISSING_CHECKS_BEFORE_LOST = 3, SCOUT_LEASH = 10;
    var LOOKUP_RANGE = 128;

    // ---- the four raids (RaidDefaults: same numbers) -------------------------------------------
    function mob(e, n, hp, melee, ki, tier) { return { e: e, n: n, hp: hp, melee: melee, ki: ki, tier: tier }; }
    function boss(e, hp, melee, ki, tier) { var s = mob(e, 1, hp, melee, ki, tier); s.dormant = true; return s; }
    function noTf(s) { s.noTf = true; return s; }
    var MUSIC = { prep: "dmzpack:menu_music_11", battle: "dmzpack:raid_ost_1" };
    var FRIEZA = "#dragonminez:frieza_soldiers", GOMAH = "#dragonminez:gomah_soldiers", ROBOTS = "#dragonminez:red_ribbon_robots";
    var SOLDIER = "dragonminez:saga_saiyan_soldier", ELITE = "dragonminez:saga_saiyan_elite", RR = "dragonminez:red_ribbon_soldier";
    var TYPES = {
        frieza_invasion: {
            name: "Frieza's Invasion", dim: "ragnarok_rpg:namek", site: "namek_ruins",
            trigger: { e: FRIEZA, hp: 400, melee: 18, ki: 12, tier: 1,
                announce: "§c[DBR-Raid]§r You sense an evil ki... Frieza's soldiers just razed a Namekian settlement nearby!",
                omen: "§c[DBR-Raid]§r The Emperor is displeased... brace for the incoming hordes.",
                start: "§cFrieza:§r Now you shall know the wrath of the Emperor..." },
            waves: [
                [mob(FRIEZA, 5, 100, 15, 10, 1)],
                [mob(FRIEZA, 10, 130, 18, 12, 1)],
                [mob(FRIEZA, 15, 160, 22, 15, 1), boss("dragonminez:saga_cui", 5500, 45, 40, 2)],
                [mob(FRIEZA, 15, 190, 26, 18, 1), boss("dragonminez:saga_dodoria", 7000, 60, 50, 2),
                    (function () { var b = boss("dragonminez:saga_zarbon", 6800, 65, 55, 2); b.tfHp = 10200; return b; })()],
                [mob(FRIEZA, 15, 220, 30, 20, 1), boss("dragonminez:saga_guldo", 6000, 55, 60, 2), boss("dragonminez:saga_recoome", 10000, 90, 50, 2),
                    boss("dragonminez:saga_burter", 10000, 70, 55, 3), boss("dragonminez:saga_jeice", 10000, 70, 65, 3), boss("dragonminez:saga_ginyu", 14000, 110, 85, 3)]],
            rewards: { tp: 30000, effects: [["minecraft:hero_of_the_village", 600, 0], ["world_hero", 600, 1]],
                items: [["minecraft:golden_carrot", 16], ["senzu_bean", 3], ["blaster_cannon", 1]] },
            defeat: { sub: "You couldn't defend Namek from Frieza...", align: -20 }
        },
        saiyan_assault: {
            name: "Saiyan Assault", dim: "minecraft:overworld", site: "saiyan_crater",
            trigger: { e: SOLDIER, hp: 500, melee: 12, ki: 10, tier: 1,
                announce: "§c[DBR-Raid]§r Your scouter picks up a Saiyan pod that just crashed nearby...",
                omen: "§c[DBR-Raid]§r With his last breath the Saiyan called for backup... brace yourself!",
                start: "§cSaiyan:§r Wipe them out! This planet belongs to us now!" },
            waves: [
                [mob(SOLDIER, 4, 500, 12, 10, 1)],
                [mob(SOLDIER, 6, 550, 14, 11, 1)],
                [mob(SOLDIER, 6, 600, 15, 12, 1), noTf(mob(ELITE, 2, 700, 17, 14, 2))],
                [mob(SOLDIER, 6, 650, 16, 13, 1), noTf(mob(ELITE, 4, 750, 18, 15, 2))],
                [mob(SOLDIER, 6, 700, 17, 14, 1), (function () { var s = mob(ELITE, 3, 800, 20, 16, 2); s.dormant = true; s.tfHp = 1500; s.tfMelee = 55; s.tfKi = 45; return s; })()]],
            rewards: { tp: 10000, effects: [["minecraft:hero_of_the_village", 600, 0], ["world_hero", 600, 0]],
                items: [["minecraft:golden_carrot", 8], ["senzu_bean", 2], ["green_scouter", 1]] },
            defeat: { sub: "You couldn't defend Earth from the Saiyans...", align: -10 }
        },
        gomah_assault: {
            name: "Gomah's Army", dim: "ragnarok_rpg:demon_realm", site: "gomah_camp",
            trigger: { e: GOMAH, hp: 10000, melee: 900, ki: 800, tier: 2,
                announce: "§c[DBR-Raid]§r You sense many hostile ki... a camp of Gomah's soldiers is nearby.",
                omen: "§c[DBR-Raid]§r The camp sounded the alarm... Gomah's army is coming for you!",
                start: "§cGomah's soldier:§r In the name of the Supreme Demon King, crush the intruder!" },
            waves: [
                [mob(GOMAH, 6, 8000, 750, 650, 1)],
                [mob(GOMAH, 8, 10000, 900, 800, 1)],
                [mob(GOMAH, 10, 12000, 1100, 950, 2)],
                [mob(GOMAH, 10, 14000, 1300, 1100, 2), boss("dragonminez:saga_glorio", 450000, 19000, 17000, 3)],
                [mob(GOMAH, 10, 16000, 1500, 1300, 2), boss("dragonminez:saga_majin_kuu", 750000, 31000, 28000, 3), boss("dragonminez:saga_majin_duu", 800000, 33000, 30000, 3)]],
            rewards: { tp: 350000, effects: [["minecraft:hero_of_the_village", 600, 0], ["world_hero", 600, 2]],
                items: [["minecraft:golden_carrot", 16], ["medi_bug_ant", 4]] },
            defeat: { sub: "You couldn't stop Gomah's army...", align: -30 }
        },
        red_ribbon_assault: {
            name: "Red Ribbon Army Assault", dim: "minecraft:overworld", site: "red_ribbon_base",
            trigger: { e: RR, hp: 150, melee: 8, ki: 0, tier: 1,
                announce: "§c[DBR-Raid]§r You spot a Red Ribbon Army base nearby... its commander must be inside the headquarters.",
                omen: "§c[DBR-Raid]§r The alarm is blaring! The whole Red Ribbon Army is mobilizing against you!",
                start: "§cGeneral Red:§r Send every soldier we have! Nobody humiliates the Red Ribbon Army!" },
            waves: [
                [mob(RR, 8, 60, 6, 0, 1)],
                [mob(RR, 10, 70, 7, 0, 1), mob(ROBOTS, 3, 150, 10, 0, 1)],
                [mob(RR, 10, 80, 8, 0, 1), boss("dragonminez:saga_colonel_silver", 560, 26, 10, 2)],
                [mob(RR, 12, 90, 9, 0, 1), mob(ROBOTS, 3, 170, 12, 0, 1), boss("dragonminez:saga_sergeant_metallic", 740, 36, 0, 2), boss("dragonminez:saga_ninja_murasaki", 640, 31, 12, 2)],
                [mob(RR, 12, 100, 10, 0, 1), boss("dragonminez:saga_general_blue", 820, 38, 20, 2), boss("dragonminez:saga_general_black_robot", 1100, 54, 45, 3)]],
            rewards: { tp: 5700, effects: [["minecraft:hero_of_the_village", 600, 0], ["world_hero", 600, 0]],
                items: [["minecraft:golden_carrot", 8], ["senzu_bean", 2], ["red_capsule", 1], ["blue_capsule", 1]] },
            defeat: { sub: "You couldn't stop the Red Ribbon Army...", align: -5 }
        }
    };
    var DEFAULT_ID = "saiyan_assault", ACTIVATION_RADIUS = 48, LEASH = 80, INTER_WAVE = 5 * 20, PREP_TICKS = 60 * 20;
    function typeOk(id) { return !!TYPES[id] && C.get("enabled") !== false && C.get(id) !== false; }
    function isBossWave(w) { return w.some(function (s) { return s.dormant; }); }

    // ---- Effects (MainEffects.RAID_WRATH / WORLD_HERO) --------------------------------------------
    RPG.effects.define("raid_wrath", { name: "Hunted", color: "#9B30D9" });
    // World Hero: +25 % TP per level (PotionEffectHelper.getMultiplierFromEffect, amplifier + 1 stacks here)
    RPG.effects.define("world_hero", { name: "World Hero", color: "#F2C438", beneficial: true, maxStacks: 10 });
    (function () {
        var base = typeof dmzOtherworldTpMult === "function" ? dmzOtherworldTpMult : null;
        if (base && base.__worldHero) return;
        var wrapped = function (p) {
            var m = base ? base(p) : 1;
            if (p && p.hasEffect && p.hasEffect("world_hero")) m *= 1 + 0.25 * Math.max(1, p.effectStacks("world_hero"));
            return m;
        };
        wrapped.__worldHero = true;
        wrapped.__kamiBless = base && base.__kamiBless;
        dmzOtherworldTpMult = wrapped;
    })();

    // ---- bodies (RaidEntityResolver + the Saiyan invaders) ----------------------------------------
    // SagaSaiyanInvadersEntity.Soldier / Elite: the soldier's and the elite's own kits (KI colours 0xFFE36B / 0xFF9A1F)
    if (typeof DMZ_SAGA_KITS !== "undefined") {
        DMZ_SAGA_KITS.saga_saiyan_soldier = { fly: 1, fs: 0.32, ks: 1.1, ev: 100, cb: [160, "BASIC", "RAPID_KICKS"], sk: [[11, 70, 1.0, "#FFE36B", "#FF9A1F", null]], g: 0 };
        DMZ_SAGA_KITS.saga_saiyan_elite = { fly: 1, fs: 0.38, ks: 1.3, ev: 60, cb: [120, "BASIC", "AIR", "RAPID_KICKS"],
            sk: [[11, 50, 1.0, "#FFE36B", "#FF9A1F", null], [8, 220, 1.1, "#FFE36B", "#FF9A1F", null], [34, 260, 1.4]], g: 0 };
    }
    function sagaHooks(o) {
        o.onTick = function (m) { if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onTick(m); moonTick(m); };
        o.onDeath = function (m) { if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onDeath(m); };
        return o;
    }
    var SAIYAN_LOOKS = { soldier: ["saga_raditz", "saga_turles"], elite: ["saga_nappa", "saga_vegeta"] };
    ["soldier", "elite"].forEach(function (k) {
        SAIYAN_LOOKS[k].forEach(function (model, v) {
            var id = "dmzq_saga_saiyan_" + k + "_v" + v, base = dmzSagaBase("saga_saiyan_" + k);
            if (RPG.mobs.exists(id)) return;
            RPG.mobs.define(id, sagaHooks({ name: k === "elite" ? "&cSaiyan Elite" : "&cSaiyan Soldier", geo: sagaLook(model, model),
                health: base[0], damage: base[2], speed: base[1], followRange: base[3], hostile: true, persistent: true, xp: 0 }));
        });
    });
    if (!RPG.mobs.exists("dmzq_saga_saiyan_oozaru_v0")) {
        var ob = dmzSagaBase("saga_saiyan_oozaru");
        RPG.mobs.define("dmzq_saga_saiyan_oozaru_v0", sagaHooks({ name: "&cOozaru", geo: sagaLook("saga_ozaru", "saga_ozaru", 1.0),
            health: ob[0], damage: ob[2], speed: ob[1], followRange: ob[3], hostile: true, persistent: true, xp: 0 }));
    }
    var TAGS = {
        "#dragonminez:frieza_soldiers": ["frieza_soldier", "frieza_soldier_heavy", "frieza_soldier_elite"],
        "#dragonminez:gomah_soldiers": ["dmzq_saga_gomah_soldier_1", "dmzq_saga_gomah_soldier_2"],
        "#dragonminez:red_ribbon_robots": ["rr_robot_1", "rr_robot_2", "rr_robot_3"],
        "dragonminez:saga_saiyan_soldier": ["dmzq_saga_saiyan_soldier_v0", "dmzq_saga_saiyan_soldier_v1"],
        "dragonminez:saga_saiyan_elite": ["dmzq_saga_saiyan_elite_v0", "dmzq_saga_saiyan_elite_v1"],
        "dragonminez:red_ribbon_soldier": ["red_ribbon_soldier"]
    };
    function resolve(e) {
        var list = TAGS[e];
        if (!list) { var path = String(e).split(":").pop(); list = ["dmzq_" + path, "dmzq_" + path + "_v0", path]; }   // 47_dmz_quests.js: variant 0 has no suffix
        list = list.filter(function (id) { return RPG.mobs.exists(id); });
        if (!list.length) { RPG.log("[DMZ raid] no body for " + e + "; skipping it"); return null; }
        return TAGS[e] ? list[Math.floor(Math.random() * list.length)] : list[0];
    }
    function isSagaBody(id) { return typeof DMZ_SAGA !== "undefined" && (String(id).indexOf("dmzq_") === 0 || (typeof DMZ_SAGA_ALIAS !== "undefined" && !!DMZ_SAGA_ALIAS[id])); }
    function diffOf(p) {
        var v = p ? p.getVar("dmz_quests", null) : null, d = v && v.d ? String(v.d) : "NORMAL";
        return QL_DIFF()[d] ? d : "NORMAL";
    }
    function QL_DIFF() { return (typeof DMZ_QL !== "undefined" && DMZ_QL.DIFFICULTY) || { EASY: { hp: 0.75, dmg: 0.5 }, NORMAL: { hp: 1, dmg: 1 }, HARD: { hp: 2, dmg: 1.5 } }; }
    /** Raid.applySpawnOptions + applyStats: absolute stats x difficulty; transform absolutes x difficulty on transform. */
    function applyStats(m, s, diffName) {
        var d = QL_DIFF()[diffName] || { hp: 1, dmg: 1 };
        var st = { hp: s.hp * d.hp, melee: s.melee * d.dmg, ki: s.ki * d.dmg, tier: s.tier, diff: { hp: d.hp, dmg: d.dmg }, noTransform: !!s.noTf };
        if (s.tfHp || s.tfMelee || s.tfKi) st.tf = { hp: s.tfHp || 0, melee: s.tfMelee || 0, ki: s.tfKi || 0 };
        if (isSagaBody(m.rpgId) && DMZ_SAGA.dmzId(m)) DMZ_SAGA.setup(m, st);
        else { m.maxHealth = st.hp; m.health = st.hp; if (s.melee) m.setAttributeBase("generic.attack_damage", st.melee); }
    }

    // ---- ground (Raid.groundNear / findSpawnPos) --------------------------------------------------
    function open(dim, x, y, z) { var b = RPG.world.getBlock(dim, x, y, z); return siteLoose(b) && b.indexOf("water") < 0 && b.indexOf("lava") < 0 || b === "minecraft:air" || b === "minecraft:cave_air"; }
    function groundNear(dim, cy, x, z, up) {
        if (!RPG.world.isLoaded(dim, x, z)) return null;
        var top = Math.min(RPG.world.surfaceY(dim, x, z), cy + up), bottom = cy - GROUND_SEARCH_DOWN, y = top, above = open(dim, x, y, z);
        while (y > bottom) {
            y--;
            var o = open(dim, x, y, z);
            if (!o && above) return y + 1;
            above = o;
        }
        return null;
    }
    function spawnPos(r, airborne) {
        for (var a = 0; a < 12; a++) {
            var ang = Math.random() * Math.PI * 2, dist = 6 + Math.random() * 10;
            var x = r.x + Math.round(Math.cos(ang) * dist), z = r.z + Math.round(Math.sin(ang) * dist);
            var g = groundNear(r.dim, r.y, x, z, airborne ? GROUND_SEARCH_UP : WALKER_SEARCH_UP);
            if (g === null || !open(r.dim, x, g, z) || !open(r.dim, x, g + 1, z)) continue;
            if (!airborne) return [x, g, z];
            var sky = g + SKY_SPAWN_HEIGHT;
            return open(r.dim, x, sky, z) && open(r.dim, x, sky + 1, z) ? [x, sky, z] : [x, g, z];
        }
        return airborne ? [r.x, r.y + SKY_SPAWN_HEIGHT, r.z] : [r.x, r.y, r.z];
    }

    // ---- raid state (RaidSavedData: saved with the world) -------------------------------------------
    var RAIDS = RPG.data.get(DATA_KEY, {}) || {};
    var BARS = {}, MUSIC_ON = {};
    function save() { RPG.data.set(DATA_KEY, RAIDS); }
    function player(u) { var list = RPG.server.players(); for (var i = 0; i < list.length; i++) if (String(list[i].uuid) === u) return list[i]; return null; }
    function music(p, id) { RPG.net.send(p, "dmz_raid_music", { id: id || "" }); }
    function alive(e) { try { return e && e.isAlive(); } catch (x) { return false; } }
    function newId() { return "r" + Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36); }
    function findNearby(dim, x, y, z, range) {
        var best = null, bd = range * range;
        Object.keys(RAIDS).forEach(function (k) {
            var r = RAIDS[k];
            if (r.status !== "ACTIVE" || r.dim !== dim) return;
            var dx = r.x - x, dy = r.y - y, dz = r.z - z, d = dx * dx + dy * dy + dz * dz;
            if (d <= bd) { bd = d; best = r; }
        });
        return best;
    }
    /** RaidManager.startRaid: the initiator and their party, the initiator's quest difficulty. */
    function startRaid(p, typeId) {
        var id = TYPES[typeId] ? typeId : DEFAULT_ID;
        if (!typeOk(id)) return null;
        var x = Math.floor(p.x), y = Math.floor(p.y), z = Math.floor(p.z);
        if (findNearby(p.dimension, x, y, z, ACTIVATION_RADIUS)) return null;
        var parts = typeof DMZ_PARTY !== "undefined" ? DMZ_PARTY.memberIds(p).map(String) : [];
        if (parts.indexOf(String(p.uuid)) < 0) parts.unshift(String(p.uuid));
        var r = { id: newId(), type: id, dim: p.dimension, x: x, y: y, z: z, parts: parts, diff: diffOf(p), status: "ACTIVE",
            wave: -1, mobs: {}, escort: {}, delay: 0, total: 0 };
        RAIDS[r.id] = r;
        save();
        RPG.log("[DMZ raid] started '" + id + "' at " + x + " " + y + " " + z + " with " + parts.length + " participant(s)");
        return r;
    }

    // ---- per-tick (Raid.tick), every tick like DMZ's level tick ---------------------------------------
    var OUTSIDE = {}, MISSING = {};
    function activeParts(r) {
        var out = [], leash2 = LEASH * LEASH, o = OUTSIDE[r.id] || {};
        r.parts.forEach(function (u) {
            var p = player(u);
            if (!p || p.dimension !== r.dim || String(p.getGameMode()) === "spectator" || !p.isAlive() || p.health <= 0) return;
            var dx = p.x - r.x - 0.5, dy = p.y - r.y - 0.5, dz = p.z - r.z - 0.5;
            if (dx * dx + dy * dy + dz * dz > leash2 && (o[u] || 0) >= LEASH_GRACE) return;
            out.push(p);
        });
        return out;
    }
    function updateLeash(r) {
        var leash2 = LEASH * LEASH, o = OUTSIDE[r.id] || (OUTSIDE[r.id] = {});
        r.parts.forEach(function (u) {
            var p = player(u);
            var dx = p ? p.x - r.x - 0.5 : 0, dy = p ? p.y - r.y - 0.5 : 0, dz = p ? p.z - r.z - 0.5 : 0;
            if (!p || p.dimension !== r.dim || !p.isAlive() || dx * dx + dy * dy + dz * dz <= leash2) { delete o[u]; return; }
            var t = o[u] = (o[u] || 0) + 1;
            if (t > LEASH_GRACE || (t - 1) % 20 !== 0) return;
            p.actionbar("§cGet back to the raid area! §f" + Math.floor((LEASH_GRACE - t + 1 + 19) / 20) + "s");
        });
    }
    function bar(r, alive) {
        var T = TYPES[r.type], wn = Math.max(1, r.wave + 1), boss = r.wave >= 0 && isBossWave(T.waves[r.wave]);
        var prog = r.delay > 0 ? 1 : r.total > 0 ? Math.max(0, Math.min(1, alive / r.total)) : 1;
        RPG.ui.bossBar("dmz_raid_" + r.id, { name: T.name + " — Wave " + wn + "/" + T.waves.length + " — " + Math.max(0, alive) + " left",
            color: boss ? "purple" : "red", style: "10", progress: prog, players: BARS[r.id] || [] });
    }
    function refreshBar(r, active) { BARS[r.id] = active; }
    // Raid.countAliveMobs: a mob that is gone while the chunk it was last seen in is loaded has died or been removed;
    // one out of sight in an unloaded chunk still counts, until the raid's centre has been loaded 30 s without it
    function countAlive(r) {
        var n = 0, loaded = RPG.world.isLoaded(r.dim, r.x, r.z), miss = MISSING[r.id] || (MISSING[r.id] = {});
        Object.keys(r.mobs).forEach(function (u) {
            var e = RPG.world.entityByUuid(u), last = r.mobs[u];
            if (e && alive(e)) {
                delete miss[u]; n++;
                if (RPG.server.getTick() % 20 === 0) r.mobs[u] = [Math.floor(e.x), Math.floor(e.z)];
                return;
            }
            if (!e && !(last && last.length && RPG.world.isLoaded(r.dim, last[0], last[1]))) {
                var m = loaded ? (miss[u] = (miss[u] || 0) + 1) : (miss[u] || 0);
                if (m < MISSING_BEFORE_LOST) { n++; return; }
                RPG.log("[DMZ raid] " + r.id + " lost track of mob " + u + "; counting it as defeated");
            }
            delete miss[u]; delete r.mobs[u]; delete r.escort[u];
        });
        return n;
    }
    function wake(r) {
        Object.keys(r.mobs).forEach(function (u) {
            var e = RPG.world.entityByUuid(u);
            if (!e || !e.hasTag("dmz_raid_dormant")) return;
            e.removeTag("dmz_raid_dormant");
        });
    }
    function escortState(r) {
        var ids = Object.keys(r.escort);
        if (!ids.length) { if (!r.woke) { r.woke = true; wake(r); } return; }
        // setRaidDormant: a dormant boss has no target and refuses new ones until hurt by a participant
        Object.keys(r.mobs).forEach(function (u) { if (r.escort[u]) return; var e = RPG.world.entityByUuid(u); if (e && e.target && e.hasTag("dmz_raid_dormant")) e.target = null; });
        ids.forEach(function (u) { var e = RPG.world.entityByUuid(u); if (e && !alive(e)) delete r.escort[u]; else if (!e && !r.mobs[u]) delete r.escort[u]; });
        if (!Object.keys(r.escort).length) wake(r);
    }
    function glow(r) {
        if (RPG.server.getTick() % GLOW_INTERVAL !== 0) return;
        Object.keys(r.mobs).forEach(function (u) { var e = RPG.world.entityByUuid(u); if (e && alive(e)) e.addPotion("minecraft:glowing", GLOW_DURATION, 0); });
    }
    function nearestPart(r) {
        var best = null, bd = 1e18;
        activeParts(r).forEach(function (p) { var dx = p.x - r.x, dy = p.y - r.y, dz = p.z - r.z, d = dx * dx + dy * dy + dz * dz; if (d < bd) { bd = d; best = p; } });
        return best;
    }
    function spawnWave(r, i) {
        var T = TYPES[r.type];
        if (i >= T.waves.length) { win(r, activeParts(r)); return; }
        r.wave = i; r.mobs = {}; r.escort = {}; r.woke = false; MISSING[r.id] = {};
        var focus = nearestPart(r), count = 0;
        T.waves[i].forEach(function (s) {
            for (var k = 0; k < s.n; k++) {
                var id = resolve(s.e);
                if (!id) continue;
                var air = isSagaBody(id), pos = spawnPos(r, air);
                var m = RPG.world.spawnMob(r.dim, id, pos[0] + 0.5, pos[1], pos[2] + 0.5);
                if (!m) continue;
                m.addTag("dmz_raid");
                m.addTag("dmz_raid:" + r.id);
                try { m.setDrops(false); } catch (x) { }
                applyStats(m, s, r.diff);
                if (air && pos[1] > r.y + 4) m.addPotion("minecraft:slow_falling", 120, 0);
                if (s.dormant) m.addTag("dmz_raid_dormant");
                else { r.escort[m.uuid] = 1; if (focus) m.target = focus; }
                if (s.tfHp && !s.noTf && /saga_saiyan_elite/.test(String(m.rpgId))) m.addTag("dmz_moon_caller");
                r.mobs[m.uuid] = [Math.floor(m.x), Math.floor(m.z)]; count++;
            }
        });
        if (!Object.keys(r.escort).length) wake(r);
        r.total = Math.max(1, count);
        bar(r, count);
        save();
        RPG.log("[DMZ raid] " + r.id + " spawned wave " + (i + 1) + "/" + T.waves.length + " (" + count + " mobs)" + (isBossWave(T.waves[i]) ? " [BOSS]" : ""));
    }
    function battleMusic(r, active) {
        var on = MUSIC_ON[r.id] || (MUSIC_ON[r.id] = {});
        active.forEach(function (p) { if (!on[p.uuid]) { on[p.uuid] = 1; music(p, MUSIC.battle); } });
    }
    function stopMusic(r) { Object.keys(MUSIC_ON[r.id] || {}).forEach(function (u) { var p = player(u); if (p) music(p, ""); }); delete MUSIC_ON[r.id]; }
    function discard(r) {
        Object.keys(r.mobs).forEach(function (u) { var e = RPG.world.entityByUuid(u); if (e) { if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onDeath(e); e.remove(); } });
        r.mobs = {}; r.escort = {};
    }
    function close(r, status) {
        r.status = status;
        RPG.ui.removeBossBar("dmz_raid_" + r.id);
        stopMusic(r);
        discard(r);
        delete BARS[r.id]; delete OUTSIDE[r.id]; delete MISSING[r.id];
        delete RAIDS[r.id];
        save();
    }
    /** RaidReward.grant + RaidFeedback.celebrate */
    function win(r, winners) {
        var T = TYPES[r.type], W = T.rewards, lines = [];
        close(r, "VICTORY");
        winners.forEach(function (p, i) {
            var first = i === 0;
            if (W.tp > 0) { p.addTp(W.tp, { raw: true, events: false, source: "script" }); if (first) lines.push("§b" + W.tp + "§r TP"); }
            W.effects.forEach(function (e) {
                if (e[0].indexOf("minecraft:") === 0) p.addPotion(e[0], e[1] * 20, e[2]);
                else { p.removeEffect(e[0]); p.addEffectStacks(e[0], e[1] * 20, e[2] + 1); }
                if (first) lines.push((e[0] === "world_hero" ? "World Hero" + (e[2] > 0 ? " " + ["", "II", "III", "IV", "V"][e[2]] : "") : "Hero of the Village") + " §7(" + Math.floor(e[1] / 60) + " min)§r");
            });
            W.items.forEach(function (it) {
                var id = it[0].indexOf(":") > 0 ? it[0] : RPG.items.id(it[0]);
                if (!id) { RPG.log("[DMZ raid] reward points at unknown item '" + it[0] + "'; skipping it"); return; }
                try { p.giveItem(id, it[1]); } catch (x) { RPG.log("[DMZ raid] could not give " + it[0] + ": " + x); return; }
                if (first) lines.push("§f" + it[1] + "x§r " + RPG.items.name(id));
            });
        });
        winners.forEach(function (p) {
            p.tell("§c[DBR-Raid]§r §aCongratulations! You defeated the raid!");
            if (lines.length) { p.tell("§c[DBR-Raid]§r §6Your rewards:"); lines.forEach(function (l) { p.tell("  §7•§r " + l); }); }
            p.playSound("minecraft:entity.player.levelup", 1, 1);
            music(p, VICTORY_MUSIC);
            if (!p.hasEffect("world_hero")) p.addEffectStacks("world_hero", HERO_TICKS, 1);      // level I unless the rewards gave more
            RPG.world.particle(p.dimension, "minecraft:totem_of_undying", p.x, p.y + p.height * 0.5, p.z, 80, 0.8, 0.35);
        });
        fireworks(r);
        RPG.log("[DMZ raid] " + r.id + " completed (victory)");
    }
    function fireworks(r) {
        var shapes = [0, 1, 2], colors = "[I;14602026,11743532,8073150]";        // DyeColor YELLOW, RED, PURPLE firework colours
        for (var i = 0; i < 6; i++) {
            var x = r.x + 0.5 + (Math.random() - 0.5) * 10, z = r.z + 0.5 + (Math.random() - 0.5) * 10, sh = shapes[Math.floor(Math.random() * 3)];
            RPG.server.runCommand("execute in " + r.dim + " run summon minecraft:firework_rocket " + x.toFixed(2) + " " + (r.y + 1) + " " + z.toFixed(2) +
                " {LifeTime:20,FireworksItem:{id:\"minecraft:firework_rocket\",Count:1b,tag:{Fireworks:{Flight:1b,Explosions:[{Type:" + sh + "b,Colors:" + colors + ",Trail:1b}]}}}}");
        }
        RPG.world.particle(r.dim, "minecraft:firework", r.x + 0.5, r.y + 1.5, r.z + 0.5, 60, 2, 0.05);
    }
    /** RaidFeedback.mourn */
    function fail(r) {
        var T = TYPES[r.type], parts = r.parts.slice();
        close(r, "DEFEAT");
        parts.forEach(function (u) {
            var p = player(u);
            if (!p) return;
            p.title("§cYOU LOST!", T.defeat.sub);
            p.playSound("minecraft:block.beacon.deactivate", 1, 0.6);
            if (T.defeat.align) {
                var before = Number(p.getVar("dmz_alignment", 100)); if (isNaN(before)) before = 100;
                var after = Math.max(0, Math.min(100, before + T.defeat.align));
                p.setVar("dmz_alignment", after);
                if (after < before) p.tell("§c[DBR-Raid]§r You lost §c" + (before - after) + "§r alignment.");
            }
        });
        RPG.log("[DMZ raid] " + r.id + " ended (all participants died or left)");
    }
    function cancel(r) { close(r, "DEFEAT"); RPG.log("[DMZ raid] " + r.id + " cancelled"); }
    function tick(r) {
        var T = TYPES[r.type];
        if (!T) { RPG.log("[DMZ raid] " + r.id + " has no type '" + r.type + "' any more; cancelling it"); cancel(r); return; }
        updateLeash(r);
        var active = activeParts(r);
        refreshBar(r, active);
        if (!active.length) { fail(r); return; }
        if (r.wave < 0) { spawnWave(r, 0); return; }
        if (r.delay > 0) {
            r.delay--;
            if (r.delay % 10 === 0) bar(r, r.total);
            if (r.delay === 0) spawnWave(r, r.wave + 1);
            return;
        }
        battleMusic(r, active);
        var n = countAlive(r);
        escortState(r);
        glow(r);
        if (RPG.server.getTick() % 5 === 0) bar(r, n);
        if (n <= 0) {
            if (r.wave === T.waves.length - 1) win(r, active);
            else { r.delay = INTER_WAVE; save(); }
        }
    }
    RPG.on("serverTick", function () {
        for (var k in RAIDS) { var r = RAIDS[k]; if (r.status === "ACTIVE") try { tick(r); } catch (e) { RPG.log("[DMZ raid] tick: " + e); } }
    });
    // a dormant boss hit by a participant wakes and turns on them (DBSagasEntity.hurt)
    RPG.on("damageFinal", function (e) {
        var t = e.target, a = e.attacker;
        if (!t || !a || !a.isPlayer() || !t.hasTag("dmz_raid_dormant")) return;
        var gm = String(a.asPlayer().getGameMode());
        if (gm === "creative" || gm === "spectator") return;
        for (var k in RAIDS) if (t.hasTag("dmz_raid:" + k) && RAIDS[k].parts.indexOf(String(a.uuid)) >= 0) { t.removeTag("dmz_raid_dormant"); t.target = a; }
    });
    // orphans: raid mobs whose raid is over (onOrphanRaidMobJoin), looked for near players every 10 s
    RPG.every(200, function () {
        RPG.server.players().forEach(function (p) {
            p.nearby(96, { tag: "dmz_raid" }).forEach(function (e) {
                var rid = null;
                for (var u in RAIDS) if (e.hasTag("dmz_raid:" + u)) rid = u;
                if (!rid) { if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onDeath(e); e.remove(); }
            });
        });
    });
    RPG.on("playerJoin", function (p) { music(p, ""); });

    // ---- the Saiyan elites' fake moon (SagaSaiyanInvadersEntity.Soldier.tickMoon) ----------------------
    var MOONS = [], MOON_AWAKE_DELAY = 60, MOON_THROW = 30, MOON_END = 44, MOON_LIFE = 20 * 60;
    var CALL = {};                // uuid -> { awake, calling }
    function moonNear(m) {
        var t = RPG.server.getTick();
        MOONS = MOONS.filter(function (o) { return o.until > t; });
        for (var i = 0; i < MOONS.length; i++) {
            var o = MOONS[i];
            if (o.dim === m.dimension && Math.abs(o.x - m.x) <= 96 && Math.abs(o.z - m.z) <= 96 && t >= o.parked) return o;
        }
        return null;
    }
    function moonTick(m) {          // once a second from the mob definition
        if (!m.hasTag("dmz_moon_caller") || m.hasTag("dmz_raid_dormant")) return;
        var c = CALL[m.uuid] || (CALL[m.uuid] = { awake: 0, calling: false });
        if (c.calling) return;
        var engaged = !!(m.target && alive(m.target));
        c.awake = engaged ? c.awake + 20 : 0;
        if (!engaged) return;
        if (moonNear(m)) { m.removeTag("dmz_moon_caller"); m.addTag("dmz_moon_sighted"); delete CALL[m.uuid]; if (typeof dmzSagaForceTransform === "function") dmzSagaForceTransform(m); return; }
        if (c.awake < MOON_AWAKE_DELAY) return;
        var others = m.nearby(64, { tag: "dmz_moon_caller" }).some(function (o) { return CALL[o.uuid] && CALL[o.uuid].calling; });
        if (others) return;
        c.calling = true;
        m.setAI(false);
        sfx(m, "ki_explosion_charge", 1.5, 0.8);
        RPG.schedule(MOON_THROW, function () {
            if (!alive(m)) return;
            var ball = m.shoot("dmz_tech_ball", { size: 2.5, colors: { core: "#F5F3D0", border: "#FFFFFF", outline: "#FFFFFF" }, damage: 0 });
            if (ball) { ball.fire({ speed: 1, lifetime: 30, size: 2.5 }); ball.setVelocity(0, 1, 0); }
            sfx(m, "kiblast_attack", 2, 0.6);
            var t = RPG.server.getTick(), moon = { dim: m.dimension, x: m.x, y: m.y + 31, z: m.z, parked: t + 30, until: t + MOON_LIFE };
            MOONS.push(moon);
            var glowTask = RPG.every(20, function () {
                if (RPG.server.getTick() >= moon.until) { RPG.cancel(glowTask); return; }
                if (RPG.server.getTick() >= moon.parked) RPG.world.particle(moon.dim, "minecraft:end_rod", moon.x, moon.y, moon.z, 30, 1.6, 0.0);
            });
            RPG.server.players().forEach(function (p) {
                if (p.dimension === m.dimension && p.distanceTo(m) <= 96) p.tell("§cSaiyan:§r Look up at the moon... and witness the true power of a Saiyan!");
            });
        });
        RPG.schedule(MOON_END, function () { c.calling = false; if (alive(m)) m.setAI(true); });
    }

    // ---- the omen (RaidTriggerEvents.onMarkedMobKilled / onOmenExpired / onOmenRemoved) -----------------
    function announce(p, text) { if (!text) return; p.tell(text); p.playSound("minecraft:block.note_block.pling", 1, 1.2); }
    function omen(p, typeId) {
        var T = TYPES[typeId];
        if (!T || !typeOk(typeId) || p.hasEffect("raid_wrath")) return false;
        p.setVar("dmz_raid_pending", { type: typeId, due: RPG.server.getTick() + PREP_TICKS });
        p.addEffect("raid_wrath", PREP_TICKS);
        music(p, MUSIC.prep);
        announce(p, T.trigger.omen);
        RPG.log("[DMZ raid] " + p.name + " killed a raid trigger for '" + typeId + "'; omen running for " + PREP_TICKS + " ticks");
        return true;
    }
    RPG.every(10, function () {
        RPG.server.players().forEach(function (p) {
            var pend = p.getVar("dmz_raid_pending", null);
            if (!pend || typeof pend !== "object" || p.hasEffect("raid_wrath")) return;
            p.setVar("dmz_raid_pending", null);
            if (RPG.server.getTick() < Number(pend.due) - 20 || !p.isAlive()) { music(p, ""); return; }      // removed early (milk, death)
            var r = startRaid(p, pend.type);
            if (!r) { RPG.log("[DMZ raid] omen for '" + pend.type + "' expired but the raid could not start (one is already nearby?)"); return; }
            r.parts.forEach(function (u) { var q = player(u); if (q) announce(q, TYPES[r.type].trigger.start); });
        });
    });
    RPG.on("playerJoin", function (p) {          // the effect is not saved across a logout the same way: a pending omen on login is dropped
        if (p.getVar("dmz_raid_pending", null) && !p.hasEffect("raid_wrath")) p.setVar("dmz_raid_pending", null);
    });

    // ---- raid sites (RaidSiteManager) ------------------------------------------------------------
    var SITE_KIND = { saiyan_crater: "saiyan_assault", namek_ruins: "frieza_invasion", gomah_camp: "gomah_assault", red_ribbon_base: "red_ribbon_assault" };
    function sites() { var s = RPG.data.get(SITES_KEY, null); if (!s || typeof s !== "object") s = {}; return s; }
    var SITES = sites(), SITE_MISS = {}, SITES_DIRTY = false;
    function saveSites() { RPG.data.set(SITES_KEY, SITES); SITES_DIRTY = false; }
    /** 66_dmz_sites.js calls this when it builds a crater / ruins / camp. */
    function addSite(kind, key, dim, x, y, z, half) {
        if (SITES[key]) return;
        SITES[key] = { kind: kind, dim: dim, x: x, y: y, z: z, half: half || 24, consumed: false, scout: null, announced: {} };
        saveSites();
    }
    // sites built before this file existed: the craters / ruins / camps 66_dmz_sites.js remembers, and the Red Ribbon bases
    (function migrate() {
        var changed = false;
        if (typeof DMZ_SITES !== "undefined" && typeof siteCells === "function" && typeof dmzSpreadChunk === "function") {
            var cells = siteCells();
            Object.keys(cells).forEach(function (k) {
                if (cells[k] !== "built" || SITES[k]) return;
                var m = k.match(/^(\w+)@(-?\d+),(-?\d+)$/);
                if (!m || !DMZ_SITES[m[1]]) return;
                var ch = dmzSpreadChunk(DMZ_SITES[m[1]], Number(m[2]), Number(m[3]));
                SITES[k] = { kind: m[1], dim: DMZ_SITES[m[1]].dim, x: ch[0] * 16 + 8, y: null, z: ch[1] * 16 + 8, half: m[1] === "namek_ruins" ? 48 : 24,
                    consumed: false, scout: null, announced: {} };
                changed = true;
            });
        }
        if (changed) saveSites();
    })();
    function redRibbonBases() {
        if (typeof dmzBuilt !== "function") return;
        var b = dmzBuilt();
        Object.keys(b).forEach(function (k) {
            var e = b[k];
            if (!e || e.name !== "red_ribbon_base" || !e.done || SITES["rrbase:" + k]) return;
            SITES["rrbase:" + k] = { kind: "red_ribbon_base", dim: e.dim, x: e.x + Math.floor(e.sx / 2), y: e.y, z: e.z + Math.floor(e.sz / 2), ox: e.x, oy: e.y, oz: e.z,
                half: Math.max(e.sx, e.sz) / 2, consumed: false, scout: null, announced: {} };
            SITES_DIRTY = true;
        });
    }
    function floorOf(s, x, z) {
        if (s.kind === "gomah_camp" && s.y !== null && typeof siteNear === "function") return siteNear(s.dim, x, z, s.y);
        var g = typeof siteGround === "function" ? siteGround(s.dim, x, z) : null;
        return g === null ? (s.y !== null ? s.y : null) : g;
    }
    function nearSite(s) {
        var out = [];
        RPG.server.players().forEach(function (p) {
            if (p.dimension !== s.dim || String(p.getGameMode()) === "spectator") return;
            var dx = p.x - s.x - 0.5, dz = p.z - s.z - 0.5;
            if (s.y !== null && Math.abs(p.y - s.y) > ANNOUNCE_HEIGHT) return;
            if (dx * dx + dz * dz <= ANNOUNCE_RADIUS * ANNOUNCE_RADIUS) out.push(p);
        });
        return out;
    }
    /** RaidSiteManager.createScout: the trigger's stats, AI tier, persistent, leashed near home, tagged to its site. */
    function createScout(s, key, x, y, z) {
        var T = TYPES[SITE_KIND[s.kind]], id = resolve(T.trigger.e);
        if (!id) return null;
        var m = RPG.world.spawnMob(s.dim, id, x + 0.5, y, z + 0.5);
        if (!m) return null;
        m.addTag("dmz_raid_scout");
        m.addTag("dmz_site:" + key);
        m.addTag("dmz_scout_type:" + SITE_KIND[s.kind]);
        applyStats(m, { hp: T.trigger.hp, melee: T.trigger.melee, ki: T.trigger.ki, tier: T.trigger.tier }, "NORMAL");
        return m;
    }
    // RedRibbonGarrison: the commander and 16 soldiers + 3 robots on the base's spots (template x, z; walk level 1)
    var RR_COMMANDER = [48, 100];
    var RR_GUARDS = [[39, 121], [47, 121], [25, 117], [55, 117], [70, 117], [14, 80], [14, 50], [25, 27], [37, 27], [49, 27], [70, 60], [70, 30], [30, 11], [60, 11], [30, 98], [60, 100]];
    var RR_ROBOTS = [[37, 48], [20, 118], [71, 90]];
    function garrison(s, key) {
        var all = [RR_COMMANDER].concat(RR_GUARDS, RR_ROBOTS);
        for (var i = 0; i < all.length; i++) if (!RPG.world.isLoaded(s.dim, s.ox + all[i][0], s.oz + all[i][1])) return null;
        var c = createScout(s, key, s.ox + RR_COMMANDER[0], s.oy + 1, s.oz + RR_COMMANDER[1]);
        if (!c) return null;
        c.setCustomName("&cRed Ribbon Commander"); c.setNameVisible(true);
        function guard(id, xz) {
            if (!id) return;
            var g = RPG.world.spawnMob(s.dim, id, s.ox + xz[0] + 0.5, s.oy + 1, s.oz + xz[1] + 0.5);
            if (g) g.addTag("dmz_rr_guard");
        }
        RR_GUARDS.forEach(function (xz) { guard(resolve(RR), xz); });
        RR_ROBOTS.forEach(function (xz) { guard(resolve(ROBOTS), xz); });
        RPG.log("[DMZ raid] Red Ribbon base at " + (s.ox + RR_COMMANDER[0]) + " " + (s.oy + 1) + " " + (s.oz + RR_COMMANDER[1]) + " garrisoned with 16 soldiers and 3 robots");
        return c;
    }
    function spawnCrew(s, key) {
        if (s.kind === "red_ribbon_base") return garrison(s, key);
        var fy = floorOf(s, s.x, s.z);
        if (fy === null) return null;
        if (s.kind === "saiyan_crater") {
            var pods = RPG.world.entitiesNear(s.dim, s.x, fy, s.z, s.half + 16).filter(function (e) { return e.vehicleId === "spacepod"; });
            if (!pods.length) RPG.world.spawnVehicle(s.dim, "spacepod", s.x + 0.5, fy + 1, s.z + 0.5, Math.random() * 360);
        }
        var sx = s.kind === "namek_ruins" ? s.x : s.x + 3, sz = s.kind === "namek_ruins" ? s.z : s.z + 1, sy = floorOf(s, sx, sz);
        if (sy === null) return null;
        var m = createScout(s, key, sx, sy + 1, sz);
        if (m) RPG.log("[DMZ raid] raid site at " + s.x + " " + fy + " " + s.z + " had no scout; placed one");
        return m;
    }
    function findScout(near, key) { var list = near[0].nearby(LOOKUP_RANGE + 48, { tag: "dmz_site:" + key }); return list.filter(alive)[0] || null; }
    function scoutLost(s, key) {
        var e = s.scout ? RPG.world.entityByUuid(s.scout) : null;
        if (e && alive(e)) { delete SITE_MISS[key]; return false; }
        if (!RPG.world.isLoaded(s.dim, s.x, s.z)) { delete SITE_MISS[key]; return false; }
        var n = SITE_MISS[key] = (SITE_MISS[key] || 0) + 1;
        if (n < MISSING_CHECKS_BEFORE_LOST) return false;
        delete SITE_MISS[key];
        RPG.log("[DMZ raid] raid site scout " + s.scout + " vanished; the site at " + s.x + " " + s.z + " is spent");
        return true;
    }
    function visit(s, key) {
        if (s.consumed || !typeOk(SITE_KIND[s.kind])) return;
        var near = nearSite(s);
        if (!near.length) return;
        if (!s.scout) {
            if (!RPG.world.isLoaded(s.dim, s.x, s.z)) return;
            var ex = findScout(near, key), m = ex || spawnCrew(s, key);
            if (!m) return;
            s.scout = String(m.uuid);
            SITES_DIRTY = true;
        } else if (scoutLost(s, key)) {
            s.consumed = true; s.announced = {}; SITES_DIRTY = true;
            return;
        }
        var fy = floorOf(s, s.x, s.z);
        if (fy !== null) RPG.world.particle(s.dim, "minecraft:campfire_cosy_smoke", s.x + 0.5, fy + 1, s.z + 0.5, 3, 0.6, 0.01);
        var text = TYPES[SITE_KIND[s.kind]].trigger.announce;
        near.forEach(function (p) { if (!s.announced[p.uuid]) { s.announced[p.uuid] = 1; announce(p, text); SITES_DIRTY = true; } });
    }
    RPG.every(SCAN_INTERVAL, function () {
        if (C.get("enabled") === false || !RPG.server.players().length) return;
        redRibbonBases();
        var dims = {};
        RPG.server.players().forEach(function (p) { dims[p.dimension] = 1; });
        for (var k in SITES) { var s = SITES[k]; if (dims[s.dim]) try { visit(s, k); } catch (e) { RPG.log("[DMZ raid] site " + k + ": " + e); } }
        if (SITES_DIRTY) saveSites();
    });
    // the scout dies (onScoutDeath consumes the site; onMarkedMobKilled gives the killer the omen)
    RPG.on("kill", function (p, victim) {
        if (!victim || !victim.hasTag || !victim.hasTag("dmz_raid_scout")) return;
        for (var k in SITES) if (victim.hasTag("dmz_site:" + k)) { SITES[k].consumed = true; SITES[k].announced = {}; saveSites(); }
        var tags = ["saiyan_assault", "frieza_invasion", "gomah_assault", "red_ribbon_assault"].filter(function (t) { return victim.hasTag("dmz_scout_type:" + t); });
        if (tags.length && p) omen(p, tags[0]);
    });

    // ---- /rpgc siteraid (DMZ's RaidCommand; the old root /dmzraid keeps working) -------------------
    var RAID_CMD = {
        permission: 2, description: "Raids at raid sites: /rpgc siteraid start [type] | stop | info | omen [type] | sites",
        run: function (p, args) {
            if (!p) return;
            var sub = String(args[0] || "");
            if (sub === "start" || sub === "omen") {
                var t = args[1] ? String(args[1]) : DEFAULT_ID;
                if (!TYPES[t]) { p.tell("§c[DBR-Raid]§r Unknown raid '" + t + "'."); return; }
                if (sub === "omen") { if (!omen(p, t)) p.tell("§c[DBR-Raid]§r You are already Hunted (or that raid is off)."); return; }
                var r = startRaid(p, t);
                p.tell(r ? "§e[DBR-Raid]§r Started raid '" + t + "'." : "§c[DBR-Raid]§r Could not start a raid here (one may already be active nearby).");
                return;
            }
            var near = findNearby(p.dimension, p.x, p.y, p.z, LOOKUP_RANGE);
            if (sub === "stop") { if (!near) p.tell("§c[DBR-Raid]§r No active raid nearby."); else { cancel(near); p.tell("§e[DBR-Raid]§r Cancelled the nearest raid."); } return; }
            if (sub === "info") {
                if (!near) { p.tell("§c[DBR-Raid]§r No active raid nearby."); return; }
                p.tell("Raid " + near.id + " | type=" + near.type + " | status=" + near.status + " | wave=" + (near.wave + 1) + " | participants=" + near.parts.length +
                    " | alive=" + Object.keys(near.mobs).length + " | center=" + near.x + ", " + near.y + ", " + near.z);
                return;
            }
            if (sub === "sites") {
                Object.keys(SITES).forEach(function (k) { var s = SITES[k]; p.tell("§e" + k + " §7" + s.kind + " " + s.dim + " " + s.x + " " + s.z + (s.consumed ? " §8(spent)" : s.scout ? " §a(scout)" : "")); });
                return;
            }
            p.tell("§c/rpgc siteraid start [" + Object.keys(TYPES).join("|") + "] | stop | info | omen [type] | sites");
        },
        suggest: function (p, args) { return args.length <= 1 ? ["start", "stop", "info", "omen", "sites"] : (args[0] === "start" || args[0] === "omen") && args.length === 2 ? Object.keys(TYPES) : []; }
    };
    RPG.commands.register("siteraid", RAID_CMD);
    RPG.commands.register("dmzraid", { root: true, hidden: true, permission: 2, description: "Old name of /rpgc siteraid", run: RAID_CMD.run, suggest: RAID_CMD.suggest });

    return { TYPES: TYPES, startRaid: startRaid, omen: omen, addSite: addSite, active: function () { return RAIDS; }, sites: function () { return SITES; } };
})();
