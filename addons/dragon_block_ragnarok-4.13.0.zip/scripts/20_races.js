// =====================================================================================
//  20_races.js - the six DMZ races and their player models ("avatars")
// =====================================================================================
//  Players pick one when they first join (ui.chooseRaceOnJoin in 05_ui.js).
//    stats / statsPerLevel   flat bonus, and extra bonus every level
//    tpMultiplier            1.25 = earns 25% more TP
//    skills                  techniques the race starts with
//    attributes              direct Minecraft attribute bonuses
//    onSelect(player)        runs once when the race is chosen
//    avatar: {...}           the player model (below)
//
//  ---- Avatars: how DMZ bodies work --------------------------------------------------
//  A DMZ body is ONE GeckoLib model drawn several times, each time with a different
//  greyscale texture tinted with one of the player's colours:
//
//      layer 1  body   (tinted "body1")   + automatic shading from body..._shadow.png
//      layer 2  eyes   (tinted "eyes")      only on the head bone
//      layer 3  hair   (tinted "hair")      the scalp (hair_base); the hair itself is DMZ's
//                                           strand hair: the avatar's `hair` block (shared/11_dmz_hair.js)
//
//  The avatar block says which model, which layers, which colours by default, and which
//  animation plays in each movement state. Players get their own colours with
//  player.setColor("hair", "#FFE34D") (see /rpgc color at the bottom of this file).
//  Forms (30_forms.js) give an effect its own avatar, which wins over the race's.
//
//  Nothing here is Dragon Ball specific: point `model` at a Link model and the layers at
//  a tunic texture tinted "tunic" and you have Zelda (README > Avatars).
// =====================================================================================

// ---- The default colours of each race (DMZ's own defaults) ----------------------------
// body1/body2/body3 = skin areas, hair, eyes, aura = the charging aura (45_keys.js).
// colours and looks per race come from shared/01_race_defaults.js (DMZ's defaults; the creator uses them too)
// headBone = DMZ's activeHeadBone: the raceparts bone a Namekian (ears1-3), Frost Demon (horns1-5), Majin (majin1-3)
// or Glind (ears1) wears on the head; "none" = nothing (see RACE_HEAD_PARTS below)
var LOOK_KEYS = ["bodyType", "bodyModel", "eyeStyle", "nose", "mouth", "hairStyle", "tattoo", "headBone"];
var RACE_COLORS = {}, RACE_LOOKS = {};
Object.keys(DBR_RACE_DEFAULTS).forEach(function (race) {
    RACE_COLORS[race] = {}; RACE_LOOKS[race] = {};
    let d = DBR_RACE_DEFAULTS[race];
    for (let k in d) (LOOK_KEYS.indexOf(k) >= 0 ? RACE_LOOKS[race] : RACE_COLORS[race])[k] = d[k];
});

// ---- Avatar building blocks ------------------------------------------------------------
// Every DMZ race model shares these animation files (names: resources/dmzpack_catalog.json).
var RACE_ANIMATIONS = ["combat", "ki", "transf", "skp", "evs"].map((f) => DMZ_ANIM + "races/" + f + ".animation.json");

// The animation layers every DBR avatar has, in DMZ's controller order (later ones win on shared bones).
// transition = ticks to blend in. Addons can add layers by pushing onto this list before races are defined.
var DBR_ANIM_LAYERS = [
    { name: "base", transition: 4 },        // movement, charging, transforming, flying...
    { name: "attack", transition: 0 },      // punches and weapon swings
    { name: "mining", transition: 0 },      // tools and placing blocks
    { name: "block", transition: 3 },       // guarding
    { name: "shield", transition: 3 },      // holding up a shield
    { name: "tail", transition: 0 },        // the tail's own sway (Saiyans, Frost Demons, Bio-Androids...)
    { name: "dash", transition: 0 },        // dashes and dodges
    { name: "pose", transition: 4 },        // weapon stances
    { name: "eat", transition: 3 },         // eating and drinking
    { name: "ki", transition: 4 },          // techniques: cast and fire, evasions (always on top)
    { name: "extra", transition: 4 }        // free for addons: anything here wins over everything else
];

// Which animation plays in which movement state (used when no client animator is running).
var BASE_STATES = {
    idle: "base.idle", walk: "base.walk", run: "base.run",
    sneak: "base.crouching", sneakWalk: "base.crouching_walk", jump: "base.jump",
    swim: "base.swimming", fly: "base.fly_idle", flyFast: "base.fly_fast",
    attack: "base.attack1", mine: "base.mining1", sit: "base.sit"
};

// Copies b's keys over a's into a new object (scripts can't rely on Object.assign).
function merge(a, b) {
    let out = {};
    for (let ka in a) out[ka] = a[ka];
    for (let kb in b) out[kb] = b[kb];
    return out;
}

// One tinted layer: texture under textures/entity/races/, a colour name or "#hex", optional bones.
// when: optional condition on look values, e.g. "tail!=0".
function lay(texture, color, bones, when) {
    let l = { texture: DMZ_TEX + "races/" + texture + ".png", color: color };
    if (bones) l.bones = bones;
    if (when) l.when = when;
    return l;
}

// The Saiyan tail: the plain one-pixel layer, then DMZ's fur look on top (engine fur layers; older engines skip it).
// Hidden with the look value tail = "0" (Dende removes it); tailWrap = "1" wraps it round the waist (63_dmz_tail.js).
function TAIL_LAYERS(color) {
    return [lay("tail1", color, ["tail1"], "tail!=0&&tailWrap!=1"),
            { texture: DMZ_TEX + "races/tail_fur.png", color: color, bones: ["tail1"], fur: true, when: "tail!=0&&tailWrap!=1" }];
}

// The avatar block itself. `spec`: model, layers, colors, scale, states, hideBones.
// DMZ draws the tattoo over the skin, under the face and hair, in its own colours.
var TATTOO_LAYER = { texture: DMZ_TEX + "races/tattoos/tattoo_{tattoo}.png", color: "#FFFFFF", when: "tattoo" };
function withTattoo(layers) {
    let out = [], added = false;
    (layers || []).forEach((l) => {
        let faceOrHair = l.bones && l.bones.length === 1 && l.bones[0] === "head";
        if (!added && faceOrHair) { out.push(TATTOO_LAYER); added = true; }
        out.push(l);
    });
    if (!added) out.push(TATTOO_LAYER);
    return out;
}

// DMZ draws the hair_base scalp under the strands whenever the player has visible hair
// (Character.hasVisibleHair: not the bald preset 5, not "no hair" 0).
var HAIR_CAP_WHEN = "hairStyle!=5&&hairStyle!=0&&hairStyle!=bald";
function hairCapLayer(color) { return lay("hair_base", color, ["head"], HAIR_CAP_WHEN); }

// ---- DMZ race parts (DMZRacePartsLayer): bones of raceparts.geo.json drawn on the head ----------
// Each race picks one head bone (look value "headBone", DMZ's activeHeadBone, chosen in the creator's hair tab):
//   Namekian  ears1|ears2|ears3 + the antennae (antennas1) always, both in the skin colour
//   Majin     majin1|majin2|majin3 (the head tentacle "hair") + the ears (ears3) always, skin colour
//   Frost Demon horns1..horns5, always #1A1A1A
//   Glind     ears1, skin colour
// skin = the colour name of the skin (body1, or fBody1 in forms: a form's body colour paints them too).
// DMZ only draws them while the form keeps the base head bones (FormData.keepBaseFormHeadBones, "keepHead"
// in shared/07_dmz_forms_data.js): 30_forms.js leaves them out of the other forms.
var RACEPARTS_GEO = DMZ_GEO + "raceparts.geo.json", RACEPARTS_TEX = DMZ_TEX + "races/raceparts.png";
var HEAD_BONE_WHEN = "headBone&&headBone!=hair";
function racePart(bones, color, when) {
    let part = { model: RACEPARTS_GEO, texture: RACEPARTS_TEX, bones: bones, color: color };
    if (when) part.when = when;
    return part;
}
var RACE_HEAD_PARTS = {
    namekian: (skin) => [racePart(["{headBone}"], skin, HEAD_BONE_WHEN), racePart(["antennas1"], skin)],
    majin: (skin) => [racePart(["{headBone}"], skin, HEAD_BONE_WHEN), racePart(["ears3"], skin)],
    frost_demon: (skin) => [racePart(["{headBone}"], "#1A1A1A", HEAD_BONE_WHEN)],
    glind: (skin) => [racePart(["{headBone}"], skin, HEAD_BONE_WHEN)]
};
function headParts(race, skin) { return RACE_HEAD_PARTS[race] ? RACE_HEAD_PARTS[race](skin) : []; }

// The female Majin's long head tentacle is a bone of the slim models (tail1m): DMZ shows it only on
// female bodies (BoneVisibilityHandler). Other races' copies of the bone stay hidden.
var MAJIN_FEMALE_TENTACLE = [{ bones: ["tail1m"], when: "bodyType!^=female" }];
// a tailless race's hidden tail bones, the Majin tentacle (tail1m) left alone
var PLAIN_TAIL_BONES = ["tail1", "tail2", "tail3", "tail4", "tail5", "tail6"];

// DMZ's ki weapons (DMZWeaponsLayer / KiWeaponRenderer): the weapon model drawn on the right arm while the
// look value kiWeapon names it (79_dmz_kiweapon.js sets it while Ki Manipulation is on and the hand is empty),
// in the ki colour, see-through (0.65) and full-bright. The claw lance is tilted 35/35 degrees and pushed forward.
var KI_WEAPON_PARTS = DMZ_COMBAT.KI_WEAPON_ORDER.map((t) => {
    let part = { model: "dmzpack:geo/weapons/kiweapon_" + t + ".geo.json", texture: DMZ_TEX + "weapons/kiweapon_" + t + ".png",
                 attach: "right_arm", color: "kiWeaponColor", alpha: 0.65, emissive: true, when: "kiWeapon=" + t };
    if (t === "clawlance") { part.rotate = [35, 35, 0]; part.offset = [0, -0.1, -1]; }
    return part;
});

function avatar(spec) {
    let out = {
        model: DMZ_GEO + "races/" + spec.model + ".geo.json",
        // no `texture`: the base pass is invisible, the layers draw everything
        layers: spec.noTattoo ? spec.layers : withTattoo(spec.layers),
        colors: spec.colors,
        animation: DMZ_ANIM + "races/movement.animation.json",
        animations: RACE_ANIMATIONS,
        states: spec.states || BASE_STATES,
        // DMZ's animation controllers, bottom to top (client/scripts/40_animator.js picks what each plays)
        animLayers: DBR_ANIM_LAYERS,
        // DMZ race parts drawn from raceparts.geo.json: the halo of the dead (60_otherworld.js sets "halo")
        parts: [{ model: DMZ_GEO + "raceparts.geo.json", texture: DMZ_TEX + "races/raceparts.png", bones: ["halo"],
                  color: "#FFF461", alpha: 0.75, emissive: true, when: "halo" }].concat(spec.parts || []).concat(KI_WEAPON_PARTS).concat(spec.tailColor ? [
                // the Saiyan tail wrapped round the waist (DMZ's tailenrolled)
                { model: DMZ_GEO + "raceparts.geo.json", texture: DMZ_TEX + "races/raceparts.png", bones: ["tailenrolled"],
                  color: spec.tailColor, when: "tail!=0&&tailWrap=1" }] : []),
        scale: spec.scale || 0.9375,
        headLook: true,
        hideBones: spec.hideBones || ["armor*"],      // the armour reference cubes never draw as body
        hideWhen: spec.hideWhen || [],
        rightHand: "right_hand_item", leftHand: "left_hand_item"
        // armorBones: {...} is left at the default: worn armour is drawn on armorHead/armorBody/...
    };
    // DMZ strand hair (shared/11_dmz_hair.js): spec.hair = DMZ_HAIR.avatarHair(slot, colour name, forced)
    if (spec.hair) out.hair = spec.hair;
    if (spec.outline) out.outline = spec.outline;     // a form's flaming outline (30_forms.js outlineFor)
    if (spec.armorGeo) out.armorGeo = spec.armorGeo;
    if (spec.armorExtraGeo) out.armorExtraGeo = spec.armorExtraGeo;
    return out;
}

// ---- Human & Saiyan --------------------------------------------------------------------
// opts: body (texture), hair/eyes/brows (colour names), browTexture, tail, extra (more layers on top)
function humanFace(eyes, brows, browTexture) {
    let f = "humansaiyan/faces/humansaiyan_";
    return [
        lay(f + "eye_{eyeStyle}_0", "#FFFFFF", ["head"]),        // sclera
        lay(f + "eye_{eyeStyle}_1", eyes, ["head"]),             // iris
        lay(f + "eye_{eyeStyle}_2", eyes, ["head"]),             // pupil
        lay(browTexture || f + "eye_{eyeStyle}_3", brows, ["head"]),   // eyebrows follow the hair colour
        lay(f + "nose_{nose}", "body1", ["head"]),
        lay(f + "mouth_{mouth}", "body1", ["head"])              // mouth_N_shadow.png shades it
    ];
}

function humanLayers(opts) {
    let layers = [lay(opts.body || "humansaiyan/bodytype_{bodyType}_layer1", "body1")];
    if (opts.tail) TAIL_LAYERS("body2").forEach((l) => layers.push(l));   // the Saiyan tail, furred
    (opts.extra || []).forEach((l) => layers.push(l));
    let hairColor = opts.hair && opts.hair !== "none" ? opts.hair : "hair";
    humanFace(opts.eyes || "eyes", opts.brows || hairColor, opts.browTexture).forEach((l) => layers.push(l));
    if (opts.hair !== "none") layers.push(hairCapLayer(opts.hair || "hair"));
    return layers;
}

function humanAvatar(race, opts) {
    return avatar({
        model: opts.model || "{bodyModel}",
        layers: humanLayers(merge(opts, { tail: race === "saiyan" })),
        colors: merge(merge(RACE_COLORS[race], RACE_LOOKS[race]), opts.colors || {}),
        scale: opts.scale,
        hideBones: race === "saiyan" ? ["armor*", "tail1m"] : ["armor*", "tail*"],
        parts: headParts(race, "body1"),          // Glind ears
        tailColor: race === "saiyan" ? "body2" : null,
        hair: opts.hair === "none" ? null : DMZ_HAIR.avatarHair("base", opts.hair || "hair", false)
    });
}

// ---- Namekian --------------------------------------------------------------------------
function namekianAvatar(opts) {
    let f = "namekian/faces/namekian_";
    let colors = opts.colors || {};
    return avatar({
        model: opts.model || "human",
        layers: [
            lay("namekian/bodytype_{bodyType}_layer1", opts.skin || "body1"),
            lay("namekian/bodytype_{bodyType}_layer2", "body2"),        // muscles
            lay("namekian/bodytype_{bodyType}_layer3", "body3"),        // the pink patches
            lay("namekian/bodytype_{bodyType}_layer4", "hair"),         // antenna & ridges (type 0 has none)
            lay(f + "eye_{eyeStyle}_0", "#FFFFFF", ["head"]),
            lay(f + "eye_{eyeStyle}_1", "eyes", ["head"]),
            lay(f + "eye_{eyeStyle}_2", "eyes", ["head"]),
            lay(f + "eye_{eyeStyle}_3", opts.skin || "body1", ["head"]),
            lay(f + "nose_{nose}", opts.skin || "body1", ["head"]),
            lay(f + "mouth_{mouth}", opts.skin || "body1", ["head"])
        ],
        colors: merge(merge(RACE_COLORS.namekian, RACE_LOOKS.namekian), colors),
        scale: opts.scale,
        hideBones: ["armor*", "tail*"],
        parts: headParts("namekian", opts.skin || "body1")
    });
}

// ---- Frost Demon -----------------------------------------------------------------------
// prefix picks the form's texture set: "bodytype", "thirdform_bodytype", "finalform_bodytype"...
// (the player's bodyType number is added: "finalform_bodytype_1"). Missing layers are skipped.
function frostAvatar(opts) {
    let p = "frostdemon/" + (opts.prefix || "bodytype") + "_{bodyType}_layer";
    let c = opts.paint || ["body1", "body2", "body3", "hair"];
    let layers = [lay(p + "1", c[0]), lay(p + "2", c[1]), lay(p + "3", c[2]), lay(p + "4", c[3])];
    if (opts.layer5) layers.push(lay(p + "5", opts.layer5));      // only body type 0 has the gems layer
    let f = "frostdemon/faces/frostdemon_";
    layers.push(lay(f + "eye_{eyeStyle}_0", "#FFFFFF", ["head"]));
    layers.push(lay(f + "eye_{eyeStyle}_1", "eyes", ["head"]));
    layers.push(lay(f + "eye_{eyeStyle}_2", "eyes", ["head"]));
    layers.push(lay(f + "nose_{nose}", c[0], ["head"]));
    layers.push(lay(opts.mouth || f + "mouth_{mouth}", c[0], ["head"]));
    return avatar({
        model: opts.model || "frostdemon",
        layers: layers,
        colors: merge(merge(RACE_COLORS.frost_demon, RACE_LOOKS.frost_demon), opts.colors || {}),
        scale: opts.scale || 0.7375,
        parts: headParts("frost_demon", c[0])
    });
}

// ---- Bio-Android -----------------------------------------------------------------------
// stage: "base", "semiperfect" or "perfect" (textures and eyes of that stage).
function bioAvatar(opts) {
    let stage = opts.stage || "base";
    let p = "bioandroid/" + stage + "_{bodyType}_layer";
    return avatar({
        model: opts.model || "bioandroid",
        layers: [
            lay(p + "1", "body1"),            // carapace
            lay(p + "2", "body2"),            // spots
            lay(p + "3", "body3"),            // face & hands
            lay(p + "4", "hair"),             // wings & crest
            lay(p + "5", "#FFFFFF"),
            lay("bioandroid/faces/" + stage + "_eye_layer0", "#FFFFFF", ["head"]),
            lay("bioandroid/faces/" + stage + "_eye_layer1", "eyes", ["head"])
        ],
        colors: merge(merge(RACE_COLORS.bio_android, RACE_LOOKS.bio_android), opts.colors || {}),
        scale: opts.scale
    });
}

// ---- Majin -----------------------------------------------------------------------------
// The base body follows the player's look values; forms pass a fixed body and eyeSet
// (0 = calm, 1 = angry, 2 = feral Kid). body/body2 = textures under majin/.
function majinAvatar(opts) {
    let f = "majin/faces/majin_";
    let e = opts.eyeSet === undefined ? "{eyeStyle}" : String(opts.eyeSet);
    let layers = [lay("majin/" + (opts.body || "bodytype_{bodyType}_layer1"), opts.skin || "body1")];
    let body2 = opts.body2 || (opts.body ? null : "bodytype_{bodyType}_layer2");             // only the _1 bodies have one
    if (body2) layers.push(lay("majin/" + body2, "body2"));
    layers.push(lay(f + "eye_" + e + "_0", "#FFFFFF", ["head"]));
    layers.push(lay(f + "eye_" + e + "_1", "eyes", ["head"]));
    if (e !== "2") layers.push(lay(f + "eye_" + e + "_2", "eyes", ["head"]));   // feral eyes have no third layer
    layers.push(lay(f + "nose_" + (opts.eyeSet === undefined ? "{nose}" : "0"), opts.skin || "body1", ["head"]));
    layers.push(lay(f + "mouth_" + (opts.eyeSet === undefined ? "{mouth}" : (opts.eyeSet > 0 ? "1" : "0")), opts.skin || "body1", ["head"]));
    return avatar({
        model: opts.model || "{bodyModel}",
        layers: layers,
        colors: merge(merge(RACE_COLORS.majin, RACE_LOOKS.majin), opts.colors || {}),
        scale: opts.scale,
        hideBones: ["armor*"].concat(PLAIN_TAIL_BONES),
        hideWhen: MAJIN_FEMALE_TENTACLE,
        parts: headParts("majin", opts.skin || "body1"),
        // DMZ's Majin armour add-on: a belly piece drawn with the chest armour (armormajinfat / armormajinslim)
        armorExtraGeo: "dmzpack:geo/armor/armor{majinArmor}.geo.json"
    });
}

// =====================================================================================
//  The races
// =====================================================================================

RPG.races.define("human", {
    name: "Human",
    description: "Earth's martial artists. Fewer transformations, but they learn faster than anyone: +25% TP.",
    stats: { strike: 3, resistance: 2, energy: 2 },
    statsPerLevel: { strike: 0.2 },
    tpMultiplier: 1.25,
    skills: ["ki_blast", "zanzoken"],
    avatar: humanAvatar("human", {}),
    onSelect(player) {
        player.tell("&eA Human! Discipline beats talent. Visit &6Master Roshi&e to begin training.");
    }
});

RPG.races.define("saiyan", {
    name: "Saiyan",
    description: "A warrior race that grows stronger after every beating. Oozaru at night, Super Saiyan at level 20.",
    stats: { strength: 5, strike: 2, vitality: 1 },
    statsPerLevel: { strength: 0.3 },
    tpMultiplier: 1.0,
    skills: ["ki_blast", "zanzoken", "zenkai"],      // zenkai: passive, see 90_hooks.js
    avatar: humanAvatar("saiyan", {}),
    onSelect(player) {
        player.tell("&6A Saiyan! Lose a fight and come back stronger. Your tail hides a monster...");
    }
});

RPG.races.define("glind", {
    name: "Glind",
    description: "An ancient race of lilac skin, almost identical to humans. Their ki is hidden from scouters.",
    stats: { strike: 2, energy: 3, resistance: 2 },
    tpMultiplier: 1.0,
    skills: ["ki_blast", "zanzoken"],
    avatar: humanAvatar("glind", {}),
    onSelect(player) {
        player.tell("&9A Glind! Your divine ki hides you from scouters.");
    }
});

RPG.races.define("namekian", {
    name: "Namekian",
    description: "Calm warriors from Namek. They regenerate, heal with ki and can grow giant.",
    stats: { vitality: 3, energy: 3, kipower: 1 },
    statsPerLevel: { vitality: 0.2 },
    tpMultiplier: 1.05,
    skills: ["ki_blast", "healing_ki", "regeneration"],
    avatar: namekianAvatar({}),
    onSelect(player) {
        player.tell("&aA Namekian! Your wounds close on their own.");
    }
});

RPG.races.define("frost_demon", {
    name: "Frost Demon",
    description: "Cruel and fast, with huge ki reserves. They hide their power in forms they unleash later.",
    stats: { kipower: 4, energy: 3, strike: 1 },
    statsPerLevel: { kipower: 0.3 },
    tpMultiplier: 0.95,
    skills: ["ki_blast", "death_beam"],
    attributes: { "minecraft:generic.movement_speed": 0.01 },
    // Frost demons are short in their sealed form (DMZ scale 0.7375); layer 5 = the orange gems
    avatar: frostAvatar({ layer5: "#E67D40" }),           // bodytype_{bodyType}_layer1..5
    onSelect(player) {
        player.tell("&dA Frost Demon! Each form you unlock removes another seal.");
    }
});

RPG.races.define("bio_android", {
    name: "Bio-Android",
    description: "Built from the cells of the strongest fighters. Tough, absorbs others, and evolves to perfection.",
    stats: { resistance: 4, vitality: 2, kipower: 2 },
    statsPerLevel: { resistance: 0.2, kipower: 0.1 },
    tpMultiplier: 1.0,
    skills: ["ki_blast", "solar_flare", "regeneration"],
    avatar: bioAvatar({}),
    onSelect(player) {
        player.tell("&2A Bio-Android! Absorb power to reach your perfect form.");
    }
});

RPG.races.define("majin", {
    name: "Majin",
    description: "Rubbery and nearly impossible to kill. Regenerates quickly and turns Super Majin.",
    stats: { vitality: 5, resistance: 2 },
    statsPerLevel: { vitality: 0.3 },
    tpMultiplier: 0.9,
    skills: ["ki_blast", "regeneration"],
    attributes: { "minecraft:generic.knockback_resistance": 0.3 },
    avatar: majinAvatar({}),
    onSelect(player) {
        player.tell("&dA Majin! Hungry? Turn your enemies into candy.");
    }
});

// A hidden race only ops can give (/rpg race <player> android):
// RPG.races.define("android", { name: "Android", selectable: false, stats: { energy: 20 },
//     avatar: humanAvatar("human", { colors: { eyes: "#3FA9FF" } }) });
// A female body: model "human_slim" (or "majin_slim") with body "humansaiyan/bodytype_female_1_layer1".
// Or one that needs a condition:  levelReq: 30,  canSelect: (player) => player.isQuestDone("saiyan_6_vegeta"),

// =====================================================================================
//  Player colours
// =====================================================================================
// The first time a race is chosen, copy its default colours onto the player (only the ones
// they haven't set). When an op changes someone's race, the old race's colours are replaced.
function applyRaceColors(player, race, overwrite) {
    let colors = RACE_COLORS[race];
    if (!colors) return;
    for (let part in colors) {
        if (overwrite || !player.getColor(part)) player.setColor(part, colors[part]);
    }
    // Look values (bodyType, eyeStyle...) are race specific: after a race change, drop the old
    // race's so the new race's avatar defaults apply.
    if (overwrite) LOOK_KEYS.forEach((k) => player.setColor(k, ""));
}

RPG.on("raceChange", (player, race, old) => {
    applyRaceColors(player, race, !!old && old !== race);
});

// The body texture decides the model file: slim and female bodies need the slim model, the
// fat Majin body the fat one. Checked once a second, so it follows the character creator,
// /rpgc color bodyType ..., or anything else that changes bodyType.
function bodyModelFor(race, bodyType) {
    let t = String(bodyType || "");
    if (race === "majin") return t === "" || t === "male_0" ? "majin" : t.indexOf("female") === 0 ? "majin_slim" : "human";
    return t.indexOf("female") === 0 || t.indexOf("slim") >= 0 ? "human_slim" : "human";
}

// A look value the current race has no art for (left over from another race: a Majin's "male_0" body on a Saiyan)
// draws nothing, so the body vanished. Any such value goes back to the race's own default, keeping male/female.
function fixLooksForRace(player, race) {
    let dmzId = null;
    for (let k in DMZ_DATA.OUR) if (DMZ_DATA.OUR[k] === race) dmzId = k;
    let L = dmzId && DMZ_DATA.LOOKS[dmzId], def = (typeof DBR_RACE_DEFAULTS !== "undefined" && DBR_RACE_DEFAULTS[race]) || {};
    if (!L) return;
    let bt = String(player.getColor("bodyType") || "");
    if (bt && L.bodies && L.bodies.length && L.bodies.indexOf(bt) < 0) {
        let female = bt.indexOf("female") === 0, pick = def.bodyType || L.bodies[0];
        if (female) L.bodies.forEach((b) => { if (pick.indexOf("female") !== 0 && b.indexOf("female") === 0) pick = b; });
        player.setColor("bodyType", pick);
    }
    [["eyeStyle", L.eyes], ["nose", L.nose], ["mouth", L.mouth], ["headBone", L.headBones]].forEach((e) => {
        let v = String(player.getColor(e[0]) || "");
        if (v && e[1] && e[1].length && e[1].indexOf(v) < 0) player.setColor(e[0], def[e[0]] !== undefined ? String(def[e[0]]) : "");
    });
}

RPG.on("playerTick", (player) => {
    let race = player.getRace();
    try { fixLooksForRace(player, race); } catch (e) { }
    if (!RACE_LOOKS[race] || !RACE_LOOKS[race].bodyModel) return;
    let want = bodyModelFor(race, player.getColor("bodyType"));
    if (player.getColor("bodyModel") !== want) player.setColor("bodyModel", want);
    if (race === "majin") {
        let armor = want === "majin" ? "majinfat" : want === "majin_slim" ? "majinslim" : "none";
        if (player.getColor("majinArmor") !== armor) player.setColor("majinArmor", armor);
    }
});

// Players who picked a race before colours existed get them on their next login.
RPG.on("playerJoin", (player) => {
    if (player.getRace() && !player.getColor("body1")) applyRaceColors(player, player.getRace(), false);
    // hair styles were "base" / "bald" before DMZ's presets: base -> the race's default preset, bald -> 5
    let hs = String(player.getColor("hairStyle") || "");
    if (hs === "base" || hs === "bald") player.setColor("hairStyle", String(DMZ_HAIR.presetOf(hs, player.getRace())));
});

// /rpgc color                 lists your colours
// /rpgc color hair #FFE34D    changes one (any name an avatar layer uses: body1, body2, body3,
//                             hair, eyes, aura, and the form colours ssjHair, ssjEyes, ssj4Fur...)
// /rpgc color eyeStyle 7      look values work too (bodyType, eyeStyle, nose, mouth, hairStyle)
// /rpgc color hairStyle 2     DMZ hair preset 1-28 (5 = bald), see /rpgc hair
// /rpgc color reset           back to your race's defaults
RPG.commands.register("color", {
    description: "Change your character's colours (body1 body2 body3 hair eyes aura ...)",
    run(player, args) {
        if (!player) return;
        if (args.length === 0) {
            player.tell("&6Your colours: &7(/rpgc color <part> <#RRGGBB>)");
            ["body1", "body2", "body3", "hair", "eyes", "aura", "ssjHair", "ssjEyes"].forEach((part) => {
                let c = player.getColor(part);
                player.tell("&7" + part + ": &f" + (c || "(race default)"));
            });
            return;
        }
        if (args[0] === "reset") {
            applyRaceColors(player, player.getRace(), true);
            player.tell("&aColours reset to the " + RPG.races.name(player.getRace()) + " defaults.");
            return;
        }
        if (LOOK_KEYS.indexOf(String(args[0])) >= 0) {                 // a look value, not a colour
            player.setColor(String(args[0]), String(args[1] || ""));
            player.tell("&a" + args[0] + " is now " + (args[1] || "the race default"));
            return;
        }
        let hex = String(args[1] || "");
        if (hex.charAt(0) !== "#") hex = "#" + hex;
        if (!/^#[0-9a-fA-F]{6}$/.test(hex)) {
            player.tell("&cUse a colour like #FFE34D");
            return;
        }
        player.setColor(String(args[0]), hex);
        player.tell("&a" + args[0] + " is now " + hex);
        uiSfx(player, "pip_menu", 0.6, 1.2);
    }
});

// /rpgc hair [<preset> | resync | reset] (DMZ's /dmzhair plus the preset picker) is in 98_dbr_commands.js
