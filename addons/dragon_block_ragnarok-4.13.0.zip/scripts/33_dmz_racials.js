// =====================================================================================
//  33_dmz_racials.js - DragonMine Z's racial skills beyond the racial action core
// =====================================================================================
//  Ported from DragonMine Z (GPL-3.0): common/racial/impl/{HumanAdaptation, FrostDemonReserve,
//  SaiyanZenkai, BioAndroidEvolution}.java, common/racial/capture/CaptureRequest.java,
//  common/init/entities/bioandroid/CellJrEntity.java, client/systems/BioSwellRenderState.java,
//  client/gui/hud/KiReserveHUD.java and RacialSkillsConfig (same defaults). The racial action key itself
//  (charging, Vital Drain, Absorption, Assimilation) lives in 31_dmz_transform.js (RACIAL) and calls in here.
//
//   Human      Adrenaline: at or below 25 % health (re-armed above it), unless on its 180 s cooldown, 15 s of
//              +25 % attack speed, +25 % movement speed and 30 % less damage taken ("Adrenaline" effect).
//   Frost Demon Power Reserve: in base or Second/Third/Final with release <= 25 % it fills (50 % of max ki,
//              full in 30 s); in a form at 100 % release or more it feeds the form for 10 s: no ki upkeep,
//              form multipliers' gain +15 %, white lightning. HUD: the Power Reserve meter (client 11_hud_ragnarok.js).
//   Saiyan     Zenkai: a lethal blow from an attacker (level 100+, not on its 900 s cooldown, not more than
//              100 % of max health) leaves 1 HP, knocks down for 10 s (40 % health, 80 % ki and stamina come
//              back), and buffs STR/SKP/PWR by 1-10 % of the base stat by the biggest hit of the last 10 s
//              (25 % of max health = full). A full one is permanent (3 max, +5 % max release each, 15 % cap),
//              else it lasts 120-240 s. "Zenkai CD" effect for the cooldown.
//   Bio-Android Semi-Perfect + Self-Destruct (radial menu): hold the racial key 5 s (the body swells), let go
//              to explode: 36 blocks, max health x 5 at the centre falling off to 0, terrain carved (follows
//              dbr_destruction), 600 s cooldown; you are left at 1 % health, knocked down 30 s and can't heal.
//              Let go early and the swell settles over 4 s before it can be armed again.
//              Perfect and above: hold 5 s to summon a Cell Jr. (3 max, 30 on the server): 20 % of your health
//              and melee damage, costs 10 % of every stat while it lives, follows you (64-block leash), fights
//              anything but you and your other Jrs; Alt + G dismisses them. A lost Jr's slot takes 240 s.
//   Namekian   Assimilation request (CaptureRequest): assimilating a Namekian player who is not knocked down
//              asks them first: clickable [Accept] / [Reject] for 30 s (/rpgc racial reply accept|reject).
//
//  Vars: dmz_cd_<adrenaline|zenkai|bio_explode> (ms), dmz_adrenaline_armed, dmz_reserve / dmz_reserve_max /
//  dmz_reserve_active, dmz_zenkai_count / dmz_zenkai_release / dmz_zenkai_temp {n, until}, dmz_bio_skill,
//  dmz_cell_jrs [uuid], dmz_celljr_slots [{u, until}], dmz_capture_request {from, name, until}.
//  Shared: bioSwell 0..1 and bioDet (ticks to detonation) for the client swell (client/scripts/45_transform.js).
//  Settings: ragnarok_rpg/config/dmz_racial_skills.json (/rpg config dmz_racial_skills).
// =====================================================================================
var DMZ_RACIAL_CFG = RPG.config.define("dmz_racial_skills", {
    enableRacialSkills: { default: true, comment: "DragonMine Z's racial skills (Zenkai needs this too)" },
    saiyanEnabled: { default: true, comment: "Saiyan Zenkai" },
    saiyanMinLevel: { default: 100, min: 0, max: 100000, integer: true, comment: "Lowest level for a Zenkai" },
    saiyanCooldownSeconds: { default: 900, min: 0, max: 86400, integer: true, comment: "Seconds between Zenkais" },
    saiyanKnockoutSeconds: { default: 10, min: 1, max: 600, integer: true, comment: "Seconds knocked down after a Zenkai" },
    saiyanKnockoutHealthRegen: { default: 0.40, min: 0, max: 1, comment: "Share of max health recovered over the knockout" },
    saiyanKnockoutStaminaRegen: { default: 0.80, min: 0, max: 1, comment: "Share of max stamina recovered over the knockout" },
    saiyanKnockoutEnergyRegen: { default: 0.80, min: 0, max: 1, comment: "Share of max ki recovered over the knockout" },
    saiyanOverkillThreshold: { default: 1.0, min: 0, max: 100, comment: "No Zenkai when the blow is bigger than max health x this" },
    saiyanPeakWindowSeconds: { default: 10, min: 1, max: 600, integer: true, comment: "Seconds the biggest hit is remembered" },
    saiyanMaxBuffHitRatio: { default: 0.25, min: 0.01, max: 10, comment: "Biggest hit / max health for a full Zenkai" },
    saiyanMinBuffPct: { default: 0.01, min: 0, max: 10, comment: "Buff at the weakest Zenkai (share of the stat)" },
    saiyanMaxBuffPct: { default: 0.10, min: 0, max: 10, comment: "Buff at a full Zenkai (share of the stat)" },
    saiyanPermanentMaxBuffs: { default: 3, min: 0, max: 100, integer: true, comment: "Full Zenkais that stay forever" },
    saiyanTempBuffMinSeconds: { default: 120, min: 1, max: 86400, integer: true, comment: "Temporary Zenkai at the weakest" },
    saiyanTempBuffMaxSeconds: { default: 240, min: 1, max: 86400, integer: true, comment: "Temporary Zenkai at the strongest" },
    saiyanReleaseBonusPerZenkai: { default: 0.05, min: 0, max: 1, comment: "Max power release added by each full Zenkai" },
    saiyanReleaseBonusCap: { default: 0.15, min: 0, max: 1, comment: "Most max power release Zenkais add" },
    humanEnabled: { default: true, comment: "Human Adrenaline" },
    humanAdrenalineThreshold: { default: 0.25, min: 0, max: 1, comment: "Health share that triggers Adrenaline" },
    humanAdrenalineSeconds: { default: 15, min: 1, max: 600, integer: true, comment: "Seconds of Adrenaline" },
    humanAdrenalineDamageReduction: { default: 0.30, min: 0, max: 1, comment: "Less damage taken during Adrenaline" },
    humanAdrenalineAttackSpeed: { default: 0.25, min: 0, max: 10, comment: "Attack speed bonus (applies after a reload)" },
    humanAdrenalineMoveSpeed: { default: 0.25, min: 0, max: 10, comment: "Movement speed bonus (applies after a reload)" },
    humanAdrenalineCooldownSeconds: { default: 180, min: 0, max: 86400, integer: true, comment: "Seconds between Adrenalines" },
    frostdemonEnabled: { default: true, comment: "Frost Demon Power Reserve" },
    frostdemonReserveChargeReleaseThreshold: { default: 25, min: 0, max: 1000, integer: true, comment: "The reserve fills at or below this release %" },
    frostdemonReserveMaxRatio: { default: 0.50, min: 0, max: 10, comment: "Reserve size as a share of max ki" },
    frostdemonReserveFullChargeSeconds: { default: 30, min: 1, max: 3600, integer: true, comment: "Seconds to fill the reserve" },
    frostdemonReserveDurationSeconds: { default: 10, min: 1, max: 3600, integer: true, comment: "Seconds a full reserve feeds a form" },
    frostdemonReserveFormBonus: { default: 0.15, min: 0, max: 10, comment: "Extra gain on the form multipliers while it feeds" },
    frostdemonReserveChargeForms: { default: "second,third,final", comment: "Forms (besides base) the reserve fills in" },
    bioandroidEnabled: { default: true, comment: "Bio-Android Self-Destruct and Cell Jr." },
    bioandroidExplodeChargeSeconds: { default: 5, min: 1, max: 120, integer: true, comment: "Seconds to arm the self-destruct" },
    bioandroidExplodeRevertSeconds: { default: 4, min: 1, max: 120, integer: true, comment: "Seconds the swell takes to settle" },
    bioandroidExplodeDamageRatio: { default: 5.0, min: 0, max: 1000, comment: "Damage at the centre = your max health x this" },
    bioandroidExplodeRadius: { default: 36, min: 1, max: 128, integer: true, comment: "Blast radius (terrain: also capped by dbr_destruction maxRadius)" },
    bioandroidExplodeKillsUser: { default: false, comment: "The self-destruct kills you" },
    bioandroidExplodeKnockdownSeconds: { default: 30, min: 1, max: 3600, integer: true, comment: "Seconds knocked down after it" },
    bioandroidExplodeCooldownSeconds: { default: 600, min: 0, max: 86400, integer: true, comment: "Seconds between self-destructs" },
    bioandroidCellJrMax: { default: 3, min: 0, max: 20, integer: true, comment: "Cell Jrs. per player" },
    bioandroidCellJrStatRatio: { default: 0.20, min: 0, max: 10, comment: "A Jr.'s health and damage as a share of yours" },
    bioandroidCellJrOwnerPenalty: { default: 0.10, min: 0, max: 1, comment: "Share of every stat a living Jr. costs you" },
    bioandroidCellJrChargeCooldownSeconds: { default: 240, min: 0, max: 86400, integer: true, comment: "Seconds before a lost Jr.'s slot is free" },
    bioandroidCellJrLeashRange: { default: 64, min: 8, max: 512, integer: true, comment: "A Jr. further than this vanishes" },
    bioandroidCellJrGlobalCap: { default: 30, min: 0, max: 1000, integer: true, comment: "Cell Jrs. on the whole server" },
    namekianAssimilationRequestTimeoutSeconds: { default: 30, min: 1, max: 600, integer: true, comment: "Seconds to answer an assimilation request" }
});

RPG.effects.define("dmz_adrenaline", { name: "&6Adrenaline", color: "#FF9F1C", beneficial: true,
    attributes: {
        "minecraft:generic.attack_speed": { amount: Number(DMZ_RACIAL_CFG.get("humanAdrenalineAttackSpeed")), operation: "multiply_total" },
        "minecraft:generic.movement_speed": { amount: Number(DMZ_RACIAL_CFG.get("humanAdrenalineMoveSpeed")), operation: "multiply_total" }
    } });
RPG.effects.define("dmz_zenkai_cd", { name: "Zenkai CD", color: "#E8B04A", beneficial: false });
RPG.effects.define("dmz_bio_explode_cd", { name: "Explosion CD", color: "#FFFC42", beneficial: false });

var DMZ_RACIALS = (function () {
    var C = DMZ_RACIAL_CFG;
    var STATS7 = ["STR", "SKP", "DEF", "STM", "VIT", "PWR", "ENE"];
    var BIO_ANIM = "base.explodecell";
    var BLAST_MAIN = "#FFFC42", BLAST_BORDER = "#FF8A3D", BLAST_OUTLINE = "#FFFFFF";
    var ST = {};                 // uuid -> transient state
    var JR = {};                 // Cell Jr uuid -> owner uuid (CellJrEntity.GLOBAL_LIVE_IDS)
    var JR_TAG = "dbr_celljr", JR_OWNER = "dbr_celljr_owner:";

    function cfg(k) { return C.get(k); }
    function n(k) { return Number(C.get(k)); }
    function num(v, d) { v = Number(v); return isNaN(v) ? d : v; }
    function now() { return Date.now(); }
    function st(p) { return ST[p.uuid] || (ST[p.uuid] = { peak: 0, peakUntil: 0, bioTicks: 0, swellLocked: false, swell: 0, dim: null }); }
    function race(p) { return DMZ_DATA.DMZ[p.race] || p.race || "human"; }
    function created(p) { return !!p.getVar("dmz_created", 0); }
    function deadSoul(p) { return typeof dmzIsDead === "function" && dmzIsDead(p); }
    function on() { return !!cfg("enableRacialSkills"); }
    function cd(p, k) { return Math.max(0, num(p.getVar("dmz_cd_" + k, 0), 0) - now()); }
    function setCd(p, k, sec) { p.setVar("dmz_cd_" + k, sec > 0 ? now() + sec * 1000 : 0); }
    function lerp(a, b, t) { return a + (b - a) * t; }
    function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
    function bar(p, t) { p.actionbar(t); }
    function pair(v) { v = String(v || ""); var i = v.indexOf(":"); return i > 0 ? { g: v.substring(0, i), f: v.substring(i + 1) } : null; }
    function formId(p) { var x = pair(p.getVar("dmz_form", "")); return x ? x.f : ""; }
    function stackId(p) { var x = pair(p.getVar("dmz_stack", "")); return x ? x.f : ""; }
    function hasActiveForm(p) { var f = formId(p); return (!!f && f !== "base") || !!stackId(p); }
    function release(p) { return num(p.getVar("dmz_release", 0), 0); }
    function stat(p, k) { return p.baseStat(DMZ_DATA.STAT_IDS[k === "DEF" || k === "STM" ? "RES" : k]); }
    function refreshTf(p) { if (typeof DMZ_TF !== "undefined") DMZ_TF.refresh(p); }
    function bonusAdd(p, k, name, op, v) { if (DBR_BONUS) DBR_BONUS.add(p, k, name, op, v); }
    function bonusRemove(p, name) { return DBR_BONUS ? DBR_BONUS.remove(p, name) : false; }
    function list(v) { return v && typeof v === "object" && typeof v.length === "number" ? v : []; }

    // =================================================================================
    //  Human: Adrenaline (HumanAdaptation)
    // =================================================================================
    function adrenalineTick(p) {
        var below = p.health / Math.max(1, p.maxHealth) <= n("humanAdrenalineThreshold");
        var armed = num(p.getVar("dmz_adrenaline_armed", 1), 1) !== 0;
        if (!below) { if (!armed) p.setVar("dmz_adrenaline_armed", 1); return; }
        if (!armed) return;
        p.setVar("dmz_adrenaline_armed", 0);
        if (on() && cfg("humanEnabled") && cd(p, "adrenaline") <= 0) triggerAdrenaline(p);
    }
    function triggerAdrenaline(p) {
        setCd(p, "adrenaline", n("humanAdrenalineCooldownSeconds"));
        p.addEffect("dmz_adrenaline", n("humanAdrenalineSeconds") * 20);
        bar(p, "&6Adrenaline surges through you!");
    }

    // =================================================================================
    //  Frost Demon: Power Reserve (FrostDemonReserve)
    // =================================================================================
    function reserve(p) { return num(p.getVar("dmz_reserve", 0), 0); }
    function reserveMax(p) { return p.maxResource("ki") * n("frostdemonReserveMaxRatio"); }
    /** isReserveFeeding: the form is fed (no ki upkeep, stronger multipliers, white lightning). */
    function reserveFeeding(p) { return race(p) === "frostdemon" && !!num(p.getVar("dmz_reserve_active", 0), 0) && reserve(p) > 0; }
    function chargeable(p) {
        if (!hasActiveForm(p)) return true;
        if (stackId(p)) return false;
        var f = formId(p).toLowerCase();
        return String(cfg("frostdemonReserveChargeForms") || "").split(",").some(function (x) { return x.trim().toLowerCase() === f; });
    }
    function setReserve(p, value, active) {
        var max = reserveMax(p), v = Math.round(clamp(value, 0, max) * 100) / 100;
        if (Math.abs(num(p.getVar("dmz_reserve_max", 0), 0) - max) > 0.5) p.setVar("dmz_reserve_max", Math.round(max));
        if (v !== reserve(p)) p.setVar("dmz_reserve", v);
        var a = active ? 1 : 0;
        if (num(p.getVar("dmz_reserve_active", 0), 0) !== a) { p.setVar("dmz_reserve_active", a); refreshTf(p); }
    }
    function reserveSecond(p) {
        if (!cfg("frostdemonEnabled")) { if (reserve(p) > 0 || p.getVar("dmz_reserve_active", 0)) setReserve(p, 0, false); return; }
        var max = reserveMax(p), before = reserve(p);
        var consuming = hasActiveForm(p) && release(p) >= 100;
        var active = consuming && before > 0, v = before;
        if (active) v = Math.max(0, before - max / n("frostdemonReserveDurationSeconds"));
        else if (!consuming && release(p) <= n("frostdemonReserveChargeReleaseThreshold") && chargeable(p))
            v = Math.min(max, before + max / n("frostdemonReserveFullChargeSeconds"));
        setReserve(p, v, active);
    }
    /** FrostDemonReserve.modifyFormStatMultiplier: the gain over x1 grows by reserveFormBonus while feeding. */
    function formMult(p, m) {
        if (m <= 1 || !reserveFeeding(p)) return m;
        return 1 + (m - 1) * (1 + n("frostdemonReserveFormBonus"));
    }

    // =================================================================================
    //  Saiyan: Zenkai (SaiyanZenkai)
    // =================================================================================
    var ZENKAI_STATS = ["STR", "SKP", "PWR"];
    function zenkaiCount(p) { return num(p.getVar("dmz_zenkai_count", 0), 0); }
    function removeTempZenkai(p) {
        var t = p.getVar("dmz_zenkai_temp", null);
        if (!t || typeof t !== "object" || !t.n) return false;
        bonusRemove(p, String(t.n));
        p.setVar("dmz_zenkai_temp", null);
        return true;
    }
    function applyZenkaiBuff(p, buffPct, isMax, potency) {
        var count = zenkaiCount(p), permanent = isMax && count < n("saiyanPermanentMaxBuffs");
        var name = permanent ? "Zenkai_" + (count + 1) : "Zenkai_Temp_" + RPG.server.getTick();
        if (!permanent) removeTempZenkai(p);
        ZENKAI_STATS.forEach(function (k) { bonusAdd(p, k, name, "+", Math.max(1, Math.floor(stat(p, k) * buffPct))); });
        if (permanent) p.setVar("dmz_zenkai_count", count + 1);
        else p.setVar("dmz_zenkai_temp", { n: name, until: now() + Math.floor(lerp(n("saiyanTempBuffMinSeconds"), n("saiyanTempBuffMaxSeconds"), potency)) * 1000 });
        if (isMax) p.setVar("dmz_zenkai_release", Math.min(n("saiyanReleaseBonusCap"), num(p.getVar("dmz_zenkai_release", 0), 0) + n("saiyanReleaseBonusPerZenkai")));
    }
    function triggerZenkai(p, potency, isMax) {
        applyZenkaiBuff(p, lerp(n("saiyanMinBuffPct"), n("saiyanMaxBuffPct"), potency), isMax, potency);
        var ko = n("saiyanKnockoutSeconds");
        p.addEffect("knocked_down", ko * 20);
        p.setVar("dmz_zenkai_ko", now() + ko * 1000);
        setCd(p, "zenkai", n("saiyanCooldownSeconds"));
        var s = st(p); s.peak = 0; s.peakUntil = 0;
        bar(p, "&aZenkai Boost used! You feel stronger!");
        sfx(p, "transform_on", 1, 1);
        p.addEffect("dmz_zenkai_cd", n("saiyanCooldownSeconds") * 20);
        p.refreshStats();
    }
    /** SaiyanZenkai.applyTemporaryBuff (the trigger command): a temporary buff, no knockout or cooldown. */
    function tempZenkai(p, potency) {
        removeTempZenkai(p);
        applyZenkaiBuff(p, lerp(n("saiyanMinBuffPct"), n("saiyanMaxBuffPct"), potency), false, potency);
        bar(p, "&aZenkai Boost used! You feel stronger!");
        sfx(p, "transform_on", 1, 1);
        p.refreshStats();
    }
    function zenkaiSecond(p) {
        if (num(p.getVar("dmz_zenkai_ko", 0), 0) > now() && p.hasEffect("knocked_down")) {
            var secs = Math.max(1, n("saiyanKnockoutSeconds"));
            p.heal(p.maxHealth * n("saiyanKnockoutHealthRegen") / secs);
            p.addResource("stamina", p.maxResource("stamina") * n("saiyanKnockoutStaminaRegen") / secs);
            p.addResource("ki", p.maxResource("ki") * n("saiyanKnockoutEnergyRegen") / secs);
        }
        var t = p.getVar("dmz_zenkai_temp", null);
        if (t && typeof t === "object" && num(t.until, 0) <= now() && removeTempZenkai(p)) p.refreshStats();
    }
    function zenkaiBlock(p, finalDamage) {
        if (p.getLevel() < n("saiyanMinLevel")) return "&cYour body is not developed enough for a Zenkai yet.";
        if (cd(p, "zenkai") > 0) return "&cYour body cannot take another Zenkai yet.";
        if (finalDamage > p.maxHealth * n("saiyanOverkillThreshold")) return "&cThat blow was far past what a Zenkai could save you from.";
        return null;
    }

    // =================================================================================
    //  Bio-Android: Self-Destruct (BioAndroidEvolution, semi-perfect)
    // =================================================================================
    function bioTier(p) { var f = formId(p); return !f || f === "base" ? "imperfect" : f === "semiperfect" ? "semi" : "perfect"; }
    function explodeSelected(p) { return race(p) === "bioandroid" && bioTier(p) === "semi" && String(p.getVar("dmz_bio_skill", "drain")) === "explode"; }
    function canArm(p) {
        if (!cfg("bioandroidEnabled") || deadSoul(p)) return false;
        if (cd(p, "bio_explode") > 0) return false;
        return !st(p).swellLocked;
    }
    /** warnExplosionUnavailable (once a second while the key is held) */
    function armWarning(p) {
        if (cd(p, "bio_explode") > 0) return "&cThis ability is on cooldown, " + Math.floor(cd(p, "bio_explode") / 1000) + " &cseconds remaining.";
        if (st(p).swellLocked) return "&eYour body is still settling down...";
        return null;
    }
    function shareSwell(p, s) {
        var q = Math.round(s.swell * 20) / 20, req = Math.max(1, n("bioandroidExplodeChargeSeconds") * 20);
        var det = s.bioTicks > 0 ? Math.max(0, req - s.bioTicks) : null;
        if (p.getShared("bioSwell", null) !== (q > 0 ? q : null)) p.setShared("bioSwell", q > 0 ? q : null);
        if (p.getShared("bioDet", null) !== det) p.setShared("bioDet", det);
    }
    /** tickExplosionCharge, every 2 ticks */
    function bioTick(p) {
        var s = st(p), req = Math.max(1, n("bioandroidExplodeChargeSeconds") * 20);
        var kind = typeof DMZ_TF !== "undefined" && DMZ_TF.chargingKind ? DMZ_TF.chargingKind(p) : null;
        var charging = explodeSelected(p) && kind === "racial" && String(p.getVar("dmz_action", "")) === "RACIAL" && canArm(p);
        if (charging) {
            if (s.bioTicks === 0) startExplosionCharge(p);
            s.bioTicks += 2;
            s.swell = Math.min(1, s.bioTicks / req);
            shareSwell(p, s);
            return;
        }
        if (s.bioTicks > 0) {
            var charged = s.bioTicks >= req;
            s.bioTicks = 0;
            if (charged) { triggerExplosion(p); shareSwell(p, s); return; }
            s.swellLocked = true;
        }
        if (s.swell <= 0) { s.swellLocked = false; shareSwell(p, s); return; }
        s.swell = Math.max(0, s.swell - 2 / Math.max(1, n("bioandroidExplodeRevertSeconds") * 20));
        if (s.swell <= 0) s.swellLocked = false;
        shareSwell(p, s);
    }
    function startExplosionCharge(p) {
        bar(p, "&cCharging self-destruct...");
        sfx(p, "transform_on", 1, 0.6);
    }
    function triggerExplosion(p) {
        var s = st(p);
        s.swell = 0; s.swellLocked = false; s.bioTicks = 0;
        if (typeof DMZ_TF !== "undefined") DMZ_TF.stopCharge(p, -2);
        var cdSec = n("bioandroidExplodeCooldownSeconds");
        setCd(p, "bio_explode", cdSec);
        if (cdSec > 0) p.addEffect("dmz_bio_explode_cd", cdSec * 20);
        var radius = n("bioandroidExplodeRadius"), dim = p.dimension;
        var cx = p.x, cy = p.y + 0.9, cz = p.z;
        // KiExplosionVisualEntity (yellow core, orange rim, white outline; size radius / 2), KI_EXPLOSION + DUST bursts
        RPG.server.players().forEach(function (o) {
            if (o.dimension === dim && o.distanceTo(p) <= Math.max(128, radius * 3))
                RPG.net.send(o, "dmz_wb_fx", { t: "boom", x: cx, y: cy, z: cz, size: radius / 2, c: { core: BLAST_MAIN, border: BLAST_MAIN, outline: BLAST_BORDER } });
        });
        RPG.world.particle(dim, "minecraft:explosion_emitter", cx, cy, cz, 6, radius * 0.25, 0);
        RPG.world.particle(dim, "minecraft:campfire_cosy_smoke", cx, p.y + 0.1, cz, 140, radius * 0.18, 0.06);
        RPG.world.particle(dim, "minecraft:cloud", cx, cy, cz, 47, radius * 0.2, 0.2);
        RPG.world.sound(dim, "dmzpack:ki_explosion_impact", cx, cy, cz, 5, 0.6);
        // every living thing in the radius but you and allies (same party without PvP): max health x 5 x falloff
        var maxHp = p.maxHealth;
        RPG.world.entitiesNear(dim, p.x, p.y, p.z, radius).forEach(function (e) {
            try {
                if (e.uuid === p.uuid || !e.isAlive() || p.isAlly(e)) return;
                var d = e.distanceTo(p);
                if (d > radius) return;
                var dmg = maxHp * n("bioandroidExplodeDamageRatio") * Math.max(0, 1 - d / radius);
                if (dmg > 0) e.damageFrom(dmg, p, { kind: "ki", tag: "dmz_bio_explode", ignoreIFrames: true });
            } catch (err) { }
        });
        carveBlast(p, cx, cy, cz, radius);
        if (cfg("bioandroidExplodeKillsUser")) { p.kill(); return; }
        var ko = n("bioandroidExplodeKnockdownSeconds");
        p.setHealth(Math.max(1, p.maxHealth * 0.01));
        p.addEffect("knocked_down", ko * 20);
        p.setVar("dmz_bio_recovery", now() + ko * 1000);
    }
    /** carveShell over 20 ticks, growing as the cube root of time; the size and regrowth follow dbr_destruction. */
    function carveBlast(p, x, y, z, radius) {
        if (typeof DBR_DESTRUCTION === "undefined") return;
        var D = DBR_DESTRUCTION.config;
        if (!D.get("enabled") || !D.get("players") || D.get("maxBlocksPerBlast") <= 0) return;
        var maxR = Math.min(radius, Number(D.get("maxRadius")) || radius), dim = p.dimension, owner = p;
        [1, 2, 3, 4, 5].forEach(function (k) {
            RPG.schedule(k * 4, function () {
                var r = maxR * Math.cbrt(k / 5);
                if (r < 1) return;
                try {
                    RPG.world.destroy(dim, { type: "sphere", x: x, y: y, z: z, r: r }, { regen: D.get("regenSeconds"), drops: false, debris: k === 5 ? 3 : 0,
                        scorch: k === 5, protectPlaced: D.get("protectPlayerBuilt"), maxBlocks: D.get("maxBlocksPerBlast"), maxResistance: 1199 }, owner);
                } catch (e) { RPG.log("bio self-destruct terrain: " + e); }
            });
        });
    }
    function recovering(p) { return num(p.getVar("dmz_bio_recovery", 0), 0) > now() && p.hasEffect("knocked_down"); }
    function selectBioSkill(p, v) {
        if (race(p) !== "bioandroid") return;
        if (st(p).swell > 0) { bar(p, "&eYour body is still settling down..."); return; }
        p.setVar("dmz_bio_skill", String(v) === "explode" ? "explode" : "drain");
    }

    // =================================================================================
    //  Bio-Android: Cell Jr. (BioAndroidEvolution perfect tier + CellJrEntity)
    // =================================================================================
    function jrList(p) { return list(p.getVar("dmz_cell_jrs", null)); }
    function jrSlots(p) { var t = now(); return list(p.getVar("dmz_celljr_slots", null)).filter(function (x) { return num(x.until, 0) > t; }); }
    function globalJrs() { var c = 0; for (var k in JR) c++; return c; }
    function canSummonCellJr(p) {
        if (!cfg("bioandroidEnabled")) return false;
        if (jrList(p).length + jrSlots(p).length >= n("bioandroidCellJrMax")) return false;
        return globalJrs() < n("bioandroidCellJrGlobalCap");
    }
    function summonCellJr(p) {
        if (!canSummonCellJr(p)) { bar(p, "&cYou have reached the limit of absorptions."); return false; }
        var yaw = p.yaw * Math.PI / 180, x = p.x - Math.sin(yaw) * 2, z = p.z + Math.cos(yaw) * 2;
        var jr = RPG.world.spawnMob(p.dimension, "bio_cell_jr", x, p.y, z);
        if (!jr) return false;
        var ratio = n("bioandroidCellJrStatRatio");
        jr.addTag(JR_TAG);
        jr.addTag(JR_OWNER + p.uuid);
        jr.maxHealth = Math.max(1, p.maxHealth * ratio);
        jr.health = jr.maxHealth;
        jr.setAttributeBase("generic.attack_damage", Math.max(1, DMZ_F.maxMelee(dmzView(p)) * ratio));
        if (typeof DMZ_SAGA !== "undefined" && DMZ_SAGA.setup) DMZ_SAGA.setup(jr, { tier: 3 });     // AiTier.ELITE
        JR[jr.uuid] = String(p.uuid);
        var l = jrList(p); l.push(String(jr.uuid)); p.setVar("dmz_cell_jrs", l);
        var name = "CellJr_" + jr.uuid, pen = n("bioandroidCellJrOwnerPenalty");
        STATS7.forEach(function (k) { var v = stat(p, k); if (v > 0) bonusAdd(p, k, name, "-", Math.max(1, v * pen)); });
        p.refreshStats();
        sfx(p, "tp_short", 1, 1);
        return true;
    }
    function ownerUuid(jr) {
        if (JR[jr.uuid]) return JR[jr.uuid];
        var ps = RPG.server.players();                     // after a restart: the owner's tag (an offline owner = no owner)
        for (var i = 0; i < ps.length; i++) if (jr.hasTag(JR_OWNER + ps[i].uuid)) return String(ps[i].uuid);
        return null;
    }
    /** onCellJrRemoved: the penalty goes, the slot waits cellJrChargeCooldownSeconds. */
    function cellJrRemoved(jrUuid, ownerId) {
        jrUuid = String(jrUuid);
        delete JR[jrUuid];
        var o = ownerId ? RPG.server.players().filter(function (q) { return String(q.uuid) === String(ownerId); })[0] : null;
        if (!o) return;
        var l = jrList(o), i = l.indexOf(jrUuid);
        if (i < 0) return;
        l.splice(i, 1); o.setVar("dmz_cell_jrs", l);
        bonusRemove(o, "CellJr_" + jrUuid);
        var slots = jrSlots(o); slots.push({ u: jrUuid, until: now() + n("bioandroidCellJrChargeCooldownSeconds") * 1000 });
        o.setVar("dmz_celljr_slots", slots);
        o.refreshStats();
    }
    function discardJr(jr) {
        var u = String(jr.uuid), owner = ownerUuid(jr);
        try { jr.remove(); } catch (e) { }
        cellJrRemoved(u, owner);
    }
    function dismissAll(p) {
        var any = false;
        jrList(p).slice().forEach(function (u) {
            var jr = RPG.world.entityByUuid(u);
            if (jr) { discardJr(jr); any = true; }
        });
        return any;
    }
    /** onLogin: Jrs that are gone take their penalty with them (no slot cooldown). */
    function reconcileJrs(p) {
        var l = jrList(p), keep = [], changed = false;
        l.forEach(function (u) {
            var jr = RPG.world.entityByUuid(u);
            if (jr && jr.isAlive()) { keep.push(u); JR[u] = String(p.uuid); return; }
            bonusRemove(p, "CellJr_" + u); changed = true;
        });
        if (changed) { p.setVar("dmz_cell_jrs", keep); p.refreshStats(); }
    }
    function despawnAll(p) { jrList(p).slice().forEach(function (u) { var jr = RPG.world.entityByUuid(u); if (jr) discardJr(jr); }); }

    // CellJrEntity.isValidTarget
    function validJrTarget(jr, owner, c) {
        if (!c || !c.isAlive() || c.uuid === owner.uuid || c.uuid === jr.uuid) return false;
        var type = String(c.getType());
        if (type.indexOf(":npc") >= 0 || type === "minecraft:armor_stand") return false;      // masters and other NPCs
        if (c.hasTag && c.hasTag(JR_TAG)) return ownerUuid(c) !== String(owner.uuid);
        var cp = c.asPlayer();
        if (cp) {
            var gm = String(cp.getGameMode());
            if (gm === "creative" || gm === "spectator") return false;
            if (typeof DMZ_PARTY !== "undefined" && DMZ_PARTY.sameParty(owner, cp)) {
                if (cp.race === "bio_android") return false;
                return !owner.isAlly(cp);                       // party PvP on
            }
        }
        return true;
    }
    /** CellJrEntity.tick + its goals, once a second (the saga brain adds flight and dodges). */
    function cellJrTick(jr) {
        var ou = ownerUuid(jr), owner = ou ? RPG.server.players().filter(function (q) { return String(q.uuid) === ou; })[0] : null;
        if (!owner || !owner.alive) { discardJr(jr); return; }
        JR[jr.uuid] = ou;
        var leash = n("bioandroidCellJrLeashRange");
        if (owner.dimension !== jr.dimension || jr.distanceTo(owner) > leash) { discardJr(jr); return; }
        var t = jr.target;
        if (t && !validJrTarget(jr, owner, t)) { jr.target = null; t = null; }
        if (!t || !t.isAlive()) {
            var best = null, bd = 1e9;
            jr.nearby(20, {}).forEach(function (c) {
                try { if (!validJrTarget(jr, owner, c)) return; var d = jr.distanceTo(c); if (d < bd) { bd = d; best = c; } } catch (e) { }
            });
            if (best) { jr.target = best; t = best; }
        }
        if (!t && jr.distanceTo(owner) > 8) jr.moveTo(owner.x, owner.y, owner.z, 1.2);    // FollowOwnerGoal (start 8, stop 4)
        if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onTick(jr);
    }

    // =================================================================================
    //  Namekian: assimilation request (CaptureRequest)
    // =================================================================================
    function sendCaptureRequest(from, target) {
        var secs = n("namekianAssimilationRequestTimeoutSeconds");
        target.setVar("dmz_capture_request", { from: String(from.uuid), name: from.name, until: now() + secs * 1000 });
        var line = ["", { text: from.name + " wants to assimilate you! ", color: "yellow" }, { text: "(" + secs + " s) ", color: "white" },
            { text: "[Accept]", color: "green", bold: true, clickEvent: { action: "run_command", value: "/rpgc racial reply accept" } },
            { text: " / ", color: "white" },
            { text: "[Reject]", color: "red", bold: true, clickEvent: { action: "run_command", value: "/rpgc racial reply reject" } }];
        try { RPG.server.runCommand("tellraw " + target.name + " " + JSON.stringify(line)); }
        catch (e) { target.tell("&e" + from.name + " wants to assimilate you! &f(" + secs + " s) &a/rpgc racial reply accept &f/ &c/rpgc racial reply reject"); }
        bar(from, "&eAssimilation request sent to " + target.name + ".");
    }

    // =================================================================================
    //  Loops and events
    // =================================================================================
    RPG.every(2, function () {
        RPG.server.players().forEach(function (p) {
            if (!created(p) || !p.alive) return;
            var r = race(p);
            if (r === "human") adrenalineTick(p);
            else if (r === "bioandroid") { var s = st(p); if (s.bioTicks > 0 || s.swell > 0 || explodeSelected(p)) bioTick(p); }
        });
    });
    RPG.every(20, function () {
        RPG.server.players().forEach(function (p) {
            if (!created(p)) return;
            var s = st(p), r = race(p);
            if (s.dim !== null && s.dim !== p.dimension) dimensionChanged(p, r);
            s.dim = p.dimension;
            if (!p.alive) return;
            if (r === "frostdemon") reserveSecond(p);
            else if (r === "saiyan") zenkaiSecond(p);
            if (s.peakUntil && s.peakUntil <= now()) { s.peak = 0; s.peakUntil = 0; }
            if (p.hasEffect("dmz_adrenaline") && r !== "human") p.removeEffect("dmz_adrenaline");
        });
    });
    function dimensionChanged(p, r) {
        if (r === "human") p.removeEffect("dmz_adrenaline");
        if (r === "frostdemon") setReserve(p, 0, false);
        if (r === "bioandroid") despawnAll(p);
    }

    // damage taken: Adrenaline's 30 % off; the Saiyan's biggest hit (after mitigation and guard, 09/11)
    RPG.on("damageFinal", function (e) {
        var t = e.target;
        if (e.isCancelled() || !t || !t.isPlayer() || e.amount <= 0) return;
        var p = t.asPlayer();
        if (!created(p)) return;
        var r = race(p);
        if (r === "human" && p.hasEffect("dmz_adrenaline")) e.amount = e.amount * (1 - n("humanAdrenalineDamageReduction"));
        if (r === "saiyan") {
            var s = st(p);
            if (e.amount > s.peak) s.peak = e.amount;
            s.peakUntil = now() + n("saiyanPeakWindowSeconds") * 1000;
        }
    });
    // SaiyanZenkai.onLethalDamage: before every other knock-out (Baba, tournaments, world bosses)
    RPG.on("lethal", function (e) {
        var t = e.target;
        if (e.isCancelled() || !t || !t.isPlayer()) return;
        var p = t.asPlayer();
        if (!created(p) || race(p) !== "saiyan" || !on() || !cfg("saiyanEnabled")) return;
        if (deadSoul(p) || !e.attacker) return;
        if (e.type === "minecraft:out_of_world" || e.type === "minecraft:generic_kill") return;
        var why = zenkaiBlock(p, e.amount);
        if (why) { bar(p, why); return; }
        var maxH = Math.max(1, p.maxHealth), ratio = Math.max(st(p).peak, e.amount) / maxH, full = n("saiyanMaxBuffHitRatio");
        e.cancel();
        p.health = 1;
        triggerZenkai(p, clamp(ratio / full, 0, 1), ratio >= full);
    });
    // no healing while recovering from the self-destruct (blockSelfHealingDuringExplosionRecovery)
    RPG.on("heal", function (ent, amount) {
        var p = ent && ent.isPlayer() ? ent.asPlayer() : null;
        if (p && race(p) === "bioandroid" && recovering(p)) return false;
    });
    RPG.on("death", function (p) {
        var r = race(p), s = st(p);
        if (r === "frostdemon") setReserve(p, 0, false);
        if (r === "bioandroid") { despawnAll(p); s.bioTicks = 0; s.swell = 0; s.swellLocked = false; shareSwell(p, s); }
        if (r === "human") p.removeEffect("dmz_adrenaline");
        p.setVar("dmz_zenkai_ko", 0);
        p.setVar("dmz_bio_recovery", 0);
    });
    RPG.on("playerJoin", function (p) {
        delete ST[p.uuid];
        p.removeEffect("dmz_adrenaline");                 // HumanAdaptation.onLogin
        RPG.schedule(20, function () { if (race(p) === "bioandroid") reconcileJrs(p); });
    });
    RPG.on("playerLeave", function (p) { if (race(p) === "bioandroid") despawnAll(p); delete ST[p.uuid]; });

    /** RacialReset (the racial-reset wish and /rpgc racial reset): Zenkai bonuses, Cell Jrs and their slots. */
    function reset(p) {
        despawnAll(p);
        if (DBR_BONUS) DBR_BONUS.names(p).forEach(function (nm) { if (/^(Zenkai_|CellJr_)/.test(nm)) DBR_BONUS.remove(p, nm); });
        ["dmz_zenkai_temp", "dmz_celljr_slots"].forEach(function (k) { p.setVar(k, null); });
        ["dmz_zenkai_release", "dmz_zenkai_count"].forEach(function (k) { p.setVar(k, 0); });
        p.setVar("dmz_cell_jrs", []);
        p.setVar("dmz_cd_zenkai", 0);
        p.removeEffect("dmz_zenkai_cd");
        p.refreshStats();
    }
    /** /rpgc trigger <p> cooldowns: the cooldowns that live here. Returns how many were running. */
    function clearCooldowns(p) {
        var c = 0;
        ["adrenaline", "zenkai", "bio_explode"].forEach(function (k) { if (cd(p, k) > 0) c++; p.setVar("dmz_cd_" + k, 0); });
        c += jrSlots(p).length;
        p.setVar("dmz_celljr_slots", null);
        p.removeEffect("dmz_zenkai_cd");
        p.removeEffect("dmz_bio_explode_cd");
        return c;
    }

    return {
        cfg: C, reserveFeeding: reserveFeeding, formMult: formMult, setReserve: function (p, pct) { setReserve(p, reserveMax(p) * pct / 100, !!num(p.getVar("dmz_reserve_active", 0), 0)); },
        triggerAdrenaline: triggerAdrenaline, triggerZenkai: triggerZenkai, tempZenkai: tempZenkai, zenkaiCount: zenkaiCount,
        explodeSelected: explodeSelected, canArm: canArm, armWarning: armWarning, triggerExplosion: triggerExplosion, bioTier: bioTier,
        canSummonCellJr: canSummonCellJr, summonCellJr: summonCellJr, dismissAll: dismissAll, cellJrTick: cellJrTick,
        cellJrDied: function (jr) { cellJrRemoved(jr.uuid, ownerUuid(jr)); }, cellJrs: jrList,
        sendCaptureRequest: sendCaptureRequest, selectBioSkill: selectBioSkill, reset: reset, clearCooldowns: clearCooldowns
    };
})();

// the radial menu's Self-Destruct / Vital Drain choice (62_dmz_radial.js routes "bio_skill" here; 63_dmz_tail.js keeps it)
var DMZ_RACIAL_EXT = (function () {
    var out = typeof DMZ_RACIAL_EXT !== "undefined" && DMZ_RACIAL_EXT ? DMZ_RACIAL_EXT : {};
    out.selectBioSkill = function (p, v) { DMZ_RACIALS.selectBioSkill(p, v); };
    return out;
})();

/** CaptureRequest.reply on accept (98_dbr_commands.js /rpgc racial reply): the requester assimilates the target. */
function dbrAcceptCapture(from, target) {
    if (!from.alive || !target.alive || from.dimension !== target.dimension || from.distanceTo(target) > 16) return;
    if (typeof DMZ_TF === "undefined" || !DMZ_TF.RACIAL || !DMZ_TF.RACIAL.applyAssimilation) return;
    var l = from.getVar("dmz_assimilations", null);
    if (l && l.length >= 4) return;
    DMZ_TF.RACIAL.applyAssimilation(from, target);
}
