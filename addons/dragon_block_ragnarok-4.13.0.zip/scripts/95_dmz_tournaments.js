// =====================================================================================
//  95_dmz_tournaments.js - DragonMine Z's tournaments (server)
// =====================================================================================
//  Port of DragonMine Z's tournament system (GPL-3.0, credited in NOTICE.md):
//  server/world/tournament/Tournament.java (Bracket, Run, Progress, RingAnchor, Manager, Service),
//  FighterIdentity, common/config/TournamentDefinition (+ Defaults), TournamentPackets,
//  server/events/ArenaProtectionHandler (the match rules), CombatEvent's tournament knock-outs,
//  PartyManager's tournament locks and TournamentCommand (/dmztournament).
//  The bracket screen and the countdown overlay are client/scripts/85_dmz_tournaments.js.
//
//  Four hosts run one tournament each (TournamentDefinition.HOST_NPCS):
//    Fortuneteller Baba in her palace  -> "baba"        Fortuneteller Baba's Tournament (gauntlet, 1 star)
//    Cell in the Cell Games arena      -> "cell"        The Cell Games (bracket, lethal, 4 stars)
//    the World Tournament Announcer    -> "budokai"     The World Martial Arts Tournament (bracket, 4 stars)
//    the Otherworld Announcer          -> "otherworld"  The Otherworld Tournament (bracket, 5 stars), on the grounds
//                                                      Grand Kai sends you to (60_otherworld.js)
//  A solo player or a whole party (the leader signs up) enters; everyone accepts the rules, the draw is
//  revealed, and bouts are fought one at a time in the arena's ring against DMZ's saga fighters (or,
//  when the draw pairs two party members, against each other). Lose once and you're out with a re-entry
//  cooldown; win the ladder (qualifiers, semi-final against the host's semifinalist, the final, the
//  title match) for training points and alignment.
//
//  Settings: ragnarok_rpg/config/dmz_tournaments/<id>.json (DMZ's config/tournaments/<id>.json, same keys).
//  Runs and re-entry cooldowns are saved with the world (DMZ's dragonminez_tournaments saved data).
//  /rpgc tournament ring <id>                              (ops) the ring sits where you stand
//  /rpgc tournament cooldown clear <player|@a> [tournament] (ops)
//
//  This is separate from 94_dbr_tournaments.js (DMZ Ragnarok's scheduled multi-player tournaments, /tourney).
// =====================================================================================

var DMZ_TOURN = (function () {
    var MD = DMZ_MASTERS_DATA;
    var OVERWORLD = "minecraft:overworld";
    var K_PROGRESS = "dmz_tournaments";           // DMZ: dragonminez_tournaments
    var MATCH_TAG = "dmz_tournament_match";

    // Tournament.Manager constants
    var COUNTDOWN_SECONDS = 3, PREVIEW_SECONDS = 5, EXCLUSION_RADIUS = 15.0, DEFAULT_HEALTH = 100.0;
    var FORFEIT_DISTANCE_SQR = 60.0 * 60.0, PUSH_SPEED = 0.6, MAX_NPC_DISTANCE_SQR = 12.0 * 12.0;

    var PLAYER_SLOT = "@player", HIDDEN_SLOT = "?", PLAYER_PREFIX = "@player:";
    var SOURCE_SEMIFINALIST = -1, SOURCE_CHAMPION = -2, SOURCE_FINALIST = -3;

    // ---- the four tournaments (TournamentDefinition.Defaults) ---------------------------------------------
    function fighter(entityId, health, melee, ki, aiTier, perRoundScaling, halo) {
        var f = { entityId: entityId, health: health, meleeDamage: melee, kiDamage: ki, aiTier: aiTier, perRoundScaling: perRoundScaling };
        if (halo) f.halo = true;
        return f;
    }
    var BUDOKAI_POOL = "#dragonminez:npc_budokai", CELL_POOL = "#dragonminez:z_fighters_cell", BUU_POOL = "#dragonminez:npc_buusaga";
    var DEFAULTS = {
        baba: { configVersion: "2.2.0", enabled: true, displayName: "tournament.dragonminez.baba", format: "GAUNTLET", difficultyStars: 1,
            reentryCooldownSeconds: 20 * 60, matchTimeoutSeconds: 300, nextRoundSeconds: 30, rulesAcceptSeconds: 60, returnSeconds: 15, arrivalSeconds: 60,
            ring: { x: 70, y: 4, z: 61, radius: 4 },
            champion: fighter("dragonminez:saga_kid_goku", 400, 34, 30, 3, 1.0),
            semifinalist: fighter("dragonminez:saga_masked_warrior", 280, 26, 20, 2, 1.0),
            contenders: [fighter("dragonminez:saga_dracula", 130, 13, 8, 1, 1.1), fighter("dragonminez:saga_invisible_man", 140, 14, 10, 1, 1.1),
                fighter("dragonminez:saga_akkuman", 155, 15, 14, 1, 1.1), fighter("dragonminez:saga_mummy", 175, 17, 6, 1, 1.1)],
            rewards: { trainingPoints: 10000, alignment: 5, commands: [] } },
        cell: { configVersion: "2.2.0", enabled: true, displayName: "tournament.dragonminez.cell", format: "BRACKET", difficultyStars: 4, qualifierSlots: 8,
            reentryCooldownSeconds: 60 * 60, matchTimeoutSeconds: 420, nextRoundSeconds: 30, rulesAcceptSeconds: 60, returnSeconds: 15, arrivalSeconds: 60, lethal: true,
            ring: { x: 37, y: 6, z: 37, radius: 6 },
            champion: fighter("dragonminez:saga_cell_superperfect", 287000, 11700, 10540, 3, 1.0),
            semifinalist: fighter("dragonminez:saga_gohan_mid_ssj", 245000, 10200, 9180, 3, 1.0),
            contenders: [fighter(CELL_POOL, 66500, 2700, 2420, 1, 1.08), fighter(CELL_POOL, 70000, 2850, 2550, 1, 1.08), fighter(CELL_POOL, 84000, 3400, 3060, 2, 1.08),
                fighter(CELL_POOL, 150500, 5940, 6545, 2, 1.08), fighter(CELL_POOL, 168000, 6600, 5950, 2, 1.08), fighter(CELL_POOL, 189000, 7500, 6800, 3, 1.08),
                fighter(CELL_POOL, 196000, 8100, 7310, 3, 1.08), fighter(CELL_POOL, 203000, 8400, 7650, 3, 1.08), fighter(CELL_POOL, 210000, 8700, 7820, 3, 1.08)],
            rewards: { trainingPoints: 1000000, alignment: 10, commands: [] } },
        otherworld: { configVersion: "2.2.0", enabled: true, displayName: "tournament.dragonminez.otherworld", format: "BRACKET", difficultyStars: 5, qualifierSlots: 8,
            reentryCooldownSeconds: 90 * 60, matchTimeoutSeconds: 480, nextRoundSeconds: 30, rulesAcceptSeconds: 60, returnSeconds: 15, arrivalSeconds: 60, lethal: false,
            ring: { x: 110, y: 98, z: 110, radius: 8 },
            semifinalist: fighter("dragonminez:saga_paikuhan", 805000, 33600, 30600, 3, 1.0),
            finalist: fighter("dragonminez:saga_goku_end_ssj", 900000, 37800, 34200, 3, 1.0, true),
            champion: fighter("dragonminez:saga_gogeta_ssj", 1330000, 55800, 50700, 4, 1.0),
            contenders: [fighter(BUU_POOL, 238000, 9900, 8840, 2, 1.08), fighter(BUU_POOL, 273000, 11400, 10370, 2, 1.08), fighter(BUU_POOL, 308000, 12900, 11730, 2, 1.08),
                fighter(BUU_POOL, 343000, 14400, 12920, 2, 1.08), fighter(BUU_POOL, 402500, 16800, 15300, 3, 1.08), fighter(BUU_POOL, 472500, 19800, 17850, 3, 1.08),
                fighter(BUU_POOL, 507500, 21300, 19380, 3, 1.08), fighter(BUU_POOL, 542500, 22800, 20740, 3, 1.08), fighter(BUU_POOL, 612500, 25800, 23460, 3, 1.08)],
            rewards: { trainingPoints: 3000000, alignment: 10, commands: [] } },
        budokai: { configVersion: "2.2.0", enabled: true, displayName: "tournament.dragonminez.budokai", format: "BRACKET", difficultyStars: 4, qualifierSlots: 8,
            reentryCooldownSeconds: 75 * 60, matchTimeoutSeconds: 420, nextRoundSeconds: 30, rulesAcceptSeconds: 60, returnSeconds: 15, arrivalSeconds: 60, lethal: false,
            ring: { x: 86, y: 27, z: 258, radius: 8 },
            semifinalist: fighter("dragonminez:saga_gohan_end_base", 462000, 19200, 17400, 3, 1.0),
            finalist: fighter("dragonminez:saga_vegeta_majin", 640000, 26700, 24300, 3, 1.0),
            champion: fighter("dragonminez:saga_mr_satan", 96000, 4200, 1500, 2, 1.0),
            contenders: [fighter(BUDOKAI_POOL, 147000, 6100, 5500, 2, 1.08), fighter(BUDOKAI_POOL, 168000, 7000, 6300, 2, 1.08), fighter(BUDOKAI_POOL, 189000, 7900, 7100, 2, 1.08),
                fighter(BUDOKAI_POOL, 213500, 8900, 8000, 2, 1.08), fighter(BUDOKAI_POOL, 245000, 10200, 9200, 3, 1.08), fighter(BUDOKAI_POOL, 280000, 11700, 10500, 3, 1.08),
                fighter(BUDOKAI_POOL, 315000, 13100, 11800, 3, 1.08), fighter(BUDOKAI_POOL, 350000, 14600, 13100, 3, 1.08), fighter(BUDOKAI_POOL, 392000, 16300, 14700, 3, 1.08)],
            rewards: { trainingPoints: 1800000, alignment: 5, commands: [] } }
    };
    // TournamentDefinition.HOST_NPCS (DMZ master id -> tournament)
    var HOST_NPCS = MD.TOURNAMENT_HOSTS;
    // Which built DMZ structure holds each tournament's arena (RingAnchor: BUILD_PROTECTED structures + the Otherworld grounds)
    var ARENAS = ["baba_palace", "cell_arena", "budokai_tenkaichi", "ow_tournament"];

    // DMZEntityTypeTagGenerator: the fighter pools the configs draw from (minus NON_FIGHTERS)
    var TAGS = {
        "#dragonminez:npc_budokai": ["saga_kid_goku", "saga_kid_krillin", "saga_teen_yamcha", "saga_young_yamcha", "saga_jackie_chun", "saga_jackie_chun_fp", "saga_nam", "saga_giran",
            "saga_young_tien", "saga_chaoz", "saga_goku_t23", "saga_yamcha_t23", "saga_tien_t23", "saga_chichi", "saga_majunia", "saga_krillin", "saga_tao_pai_pai_cyborg", "saga_mr_satan",
            "saga_goku_end_base", "saga_vegeta_end_base", "saga_vegeta_majin", "saga_gohan_end_base", "saga_piccolo", "saga_videl", "saga_a18", "saga_kid_trunks", "saga_goten", "saga_shin",
            "saga_kibito", "saga_spopovitch", "saga_buufat", "saga_uub", "saga_pan", "saga_goku_gt"],
        "#dragonminez:npc_buusaga": ["saga_goku_end_base", "saga_goku_end_ssj", "saga_goku_end_ssj2", "saga_goku_end_ssj3", "saga_vegeta_end_base", "saga_vegeta_end_ssj", "saga_vegeta_end_ssj2",
            "saga_vegeta_majin", "saga_gohan_end_base", "saga_gohan_end_ssj", "saga_gohan_end_ssj2", "saga_gohan_end_ultimate", "saga_goten", "saga_goten_ssj", "saga_kid_trunks", "saga_kid_trunks_ssj",
            "saga_gotenks", "saga_gotenks_ssj", "saga_gotenks_ssj3", "saga_shin", "saga_videl", "saga_mr_satan", "saga_bulma", "saga_kibito", "saga_spopovitch", "saga_puipui", "saga_yakon",
            "saga_dabura", "saga_babidi", "saga_buufat", "saga_evilbuu", "mini_buu", "saga_superbuu", "saga_superbuu_piccolo", "saga_superbuu_gotenks", "saga_superbuu_gohan", "saga_kidbuu",
            "saga_vegetto_base", "saga_vegetto_ssj"],
        "#dragonminez:z_fighters_cell": ["saga_goku_mid_base", "saga_goku_mid_ssj", "saga_gohan_mid_base", "saga_gohan_mid_ssj", "saga_gohan_mid_ssj2", "saga_vegeta_mid_base", "saga_vegeta_mid_ssj",
            "saga_ftrunks_base", "saga_ftrunks_ssj", "saga_piccolo_kami", "saga_krillin", "saga_tien_early", "saga_yamcha", "saga_a16", "saga_mr_satan"],
        "#dragonminez:npc_babafighters": ["saga_masked_warrior", "saga_dracula", "saga_akkuman", "saga_invisible_man", "saga_mummy"]
    };
    var NON_FIGHTERS = ["saga_bulma", "saga_world_tournament_announcer"];

    // DBSagasEntity.getGeckolibModelName / getGeckolibTextureName (and the _1, _2... texture variants) of every fighter the
    // tournaments can field: [model ("" = the entity's own name), texture ("" = same), variants]. 47_dmz_quests.js defines
    // the saga fighters its quests use; the ones only tournaments field are defined here the same way (dmzq_<path>[_v<n>]).
    var FIGHTER_MODELS = {
        "mini_buu":["saga_buufat","",1], "saga_a16":["","",1], "saga_a18":["","",1], "saga_akkuman":["","",1], "saga_babidi":["","",1], "saga_bulma":["","",1],
        "saga_buufat":["","",1], "saga_cell_superperfect":["saga_cell_perfect","",1], "saga_chaoz":["","",1], "saga_chichi":["saga_videl","",1],
        "saga_dabura":["","",1], "saga_dracula":["","",1], "saga_evilbuu":["","",1], "saga_ftrunks_base":["saga_trunks","",2],
        "saga_ftrunks_ssj":["saga_trunks_ssj","",2], "saga_giran":["","",1], "saga_gogeta_ssj":["","",1], "saga_gohan_end_base":["saga_gohan_end","",3],
        "saga_gohan_end_ssj":["","",3], "saga_gohan_end_ssj2":["","",3], "saga_gohan_end_ultimate":["saga_gohan_end_ssj2","",3],
        "saga_gohan_mid_base":["saga_gohan_mid","",4], "saga_gohan_mid_ssj":["saga_gohan_mid","",4], "saga_gohan_mid_ssj2":["","",4],
        "saga_goku_end_base":["saga_goku","",1], "saga_goku_end_ssj":["saga_goku_ssj","",1], "saga_goku_end_ssj2":["saga_goku_ssj2","",1],
        "saga_goku_end_ssj3":["saga_goku_ssj3","",1], "saga_goku_gt":["saga_kid_goku","",1], "saga_goku_mid_base":["saga_goku","",3],
        "saga_goku_mid_ssj":["saga_goku_ssj","",3], "saga_goku_t23":["saga_goku","",2], "saga_goten":["saga_kid_goku","",1], "saga_goten_ssj":["","",1],
        "saga_gotenks":["","",1], "saga_gotenks_ssj":["saga_gotenks","",1], "saga_gotenks_ssj3":["","",1], "saga_invisible_man":["","",1],
        "saga_jackie_chun":["","",1], "saga_jackie_chun_fp":["","",1], "saga_kibito":["","",1], "saga_kid_goku":["","",3],
        "saga_kid_krillin":["saga_kid_goku","",2], "saga_kid_trunks":["","",1], "saga_kid_trunks_ssj":["","",1], "saga_kidbuu":["","",1],
        "saga_krillin":["saga_vegeta","",3], "saga_majunia":["saga_piccolo","",1], "saga_masked_warrior":["","",1], "saga_mr_satan":["","",1],
        "saga_mummy":["saga_sergeant_metallic","",1], "saga_nam":["","",1], "saga_paikuhan":["","",1], "saga_pan":["saga_videl","",1],
        "saga_piccolo":["","",2], "saga_piccolo_kami":["","",1], "saga_puipui":["","",1], "saga_shin":["","",1], "saga_spopovitch":["","",1],
        "saga_superbuu":["","",1], "saga_superbuu_gohan":["saga_superbuugohan","",1], "saga_superbuu_gotenks":["saga_superbuu","",1],
        "saga_superbuu_piccolo":["saga_superbuu","",1], "saga_tao_pai_pai_cyborg":["saga_tao_pai_pai","",1], "saga_teen_yamcha":["saga_yamcha","",1],
        "saga_tien_early":["saga_goku","",1], "saga_tien_t23":["saga_goku","",1], "saga_uub":["","",1], "saga_vegeta_end_base":["saga_vegeta","",1],
        "saga_vegeta_end_ssj":["saga_vegeta","",1], "saga_vegeta_end_ssj2":["saga_vegeta_ssj2","",1], "saga_vegeta_majin":["saga_vegeta_ssg2","",1],
        "saga_vegeta_mid_base":["saga_vegeta","",1], "saga_vegeta_mid_ssj":["saga_vegeta","",1], "saga_vegetto_base":["","",1], "saga_vegetto_ssj":["","",1],
        "saga_videl":["","",1], "saga_yakon":["","",1], "saga_yamcha":["","",1], "saga_yamcha_t23":["","",1], "saga_young_tien":["saga_young_yamcha","",1],
        "saga_young_yamcha":["","",1]
    };
    function fighterTitle(path) {
        return path.replace(/^saga_/, "").replace(/_/g, " ").replace(/\b[a-z]/g, function (c) { return c.toUpperCase(); });
    }
    Object.keys(FIGHTER_MODELS).forEach(function (path) {
        var f = FIGHTER_MODELS[path], model = f[0] || path, tex = f[1] || path, kit = (typeof DMZ_SAGA_KITS !== "undefined" && DMZ_SAGA_KITS[path]) || {};
        var base = typeof dmzSagaBase === "function" ? dmzSagaBase(path) : [100, 0.25, 10, 32];
        for (var v = 0; v < f[2]; v++) {
            var id = "dmzq_" + path + (v ? "_v" + v : "");
            if (RPG.mobs.exists(id)) continue;
            RPG.mobs.define(id, {
                name: "&c" + fighterTitle(path),
                geo: dmzSagaStates({ model: DMZ_GEO + "sagas/" + model + ".geo.json", texture: DMZ_TEX + "sagas/" + tex + (v ? "_" + v : "") + ".png",
                    animation: DMZ_ANIM + "sagas/saga_base.animation.json", idle: "idle", walk: "walk", attack: "attack1_1", scale: kit.sc || 1 }),
                health: base[0], damage: base[2], speed: base[1], followRange: base[3], hostile: true, persistent: true, xp: 0,
                onTick: function (m) { if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onTick(m); },
                onDeath: function (m) { if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onDeath(m); }
            });
        }
    });

    // ---- messages (DMZ's en_us lines; colours from the ChatFormatting DMZ gives each) ---------------------
    var L = {
        unavailable: "This tournament is not available right now.", in_progress: "A tournament is already underway here. Wait for it to finish.",
        busy_elsewhere: "You are still entered in another tournament. Finish it or walk away from its ring first.",
        cooldown: "You must wait %s before entering again.", party_leader_only: "Only your party leader can enter the party into a tournament.",
        member_busy: "%s is already entered in another tournament.", member_cooldown: "%s entered this tournament recently. The party must wait %s.",
        entered: "You have entered %s.", not_entered: "You are not entered in this tournament.",
        rules_accepted: "You accepted the rules. Waiting for the rest of the party.", member_accepted: "%s accepted the rules.",
        rules_declined: "You declined the rules and left the tournament.", member_declined: "%s declined the rules and is out.",
        rules_settled: "Everybody is in. The draw is revealed!", cancelled: "Nobody accepted the rules. The tournament is called off.",
        pvp_bout: "%s versus %s — the draw put you against each other!",
        your_turn: "Your bout is next! Press Ready in the tournament menu within %s seconds or you are disqualified. Speak to the host to reopen the menu.",
        turn_of: "%s's bout is next. They have %s seconds to accept it.", member_ready: "%s is ready to fight.",
        next_round_expired: "You did not accept your bout in time and were disqualified.",
        already_fighting: "You are already in the middle of a bout.", not_your_turn: "It is not your turn yet.",
        keep_away: "Stay %s blocks away from the fighters!", returned: "You are back in the arena.",
        withdrawing: "%s is walking out of the tournament! They have %s seconds to return or they are eliminated.",
        summoned: "%s was called into the tournament and has %s seconds to reach the arena.", return_timer: "Return to the arena! %ss",
        opponent_knockout: "Your opponent is knocked out and cannot continue!", knockout: "You were knocked out cold. The bout is over.",
        withdrew: "%s abandoned the tournament and was eliminated.", left_party: "%s left the party and was disqualified from the tournament.",
        round_won: "You won round %s of the tournament (%s)! Return to the host for your next fight.",
        round_lost: "You lost round %s of the tournament (%s). You may enter again in %s.",
        timeout: "The bout ran out of time and was declared void.", eliminated_broadcast: "%s is out of the tournament.",
        forfeit: "You walked away from the ring and forfeited the tournament. You may enter again in %s.",
        run_over: "The tournament is over. The arena is open again.", champion_broadcast: "%s is the champion!",
        victory: "You have won the tournament!", reward_tp: "Reward: %s training points",
        no_ring: "The ring could not be found. Speak to the host inside the arena.",
        party_locked: "Nobody can join or be invited to a party while its tournament is underway.",
        "round.qualifier": "Qualifier %s", "round.semi": "Semi-final", "round.final": "Final", "round.title": "Title Match"
    };
    var NAMES = { baba: "Fortuneteller Baba's Tournament", cell: "The Cell Games", otherworld: "The Otherworld Tournament", budokai: "The World Martial Arts Tournament" };
    function fmt(s, args) {
        var i = 0;
        return String(s).replace(/%s/g, function () { var v = args && args[i++]; return v === undefined || v === null ? "" : String(v); });
    }
    function line(key, args, color) { return (color || "") + fmt(L[key] || key, args); }

    // ---- settings ---------------------------------------------------------------------------------------
    var DEFS = {};
    function loadDefs() {
        DEFS = {};
        Object.keys(DEFAULTS).forEach(function (id) {
            try { DEFS[id] = RPG.files.config("dmz_tournaments/" + id, DEFAULTS[id]); }
            catch (e) { RPG.log("[DMZ tournaments] config " + id + ": " + e); DEFS[id] = JSON.parse(JSON.stringify(DEFAULTS[id])); }
        });
    }
    loadDefs();
    function getDef(id) { var d = DEFS[id]; return d && d.enabled !== false ? d : null; }
    function num(v, d) { var n = Number(v); return v === undefined || v === null || isNaN(n) ? d : n; }
    function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
    // TournamentDefinition's xxxOr accessors
    function formatOf(def) { return String(def.format || "BRACKET").toUpperCase() === "GAUNTLET" ? "GAUNTLET" : "BRACKET"; }
    function stars(def) { return def.difficultyStars !== undefined ? clamp(Math.floor(num(def.difficultyStars, 1)), 1, 5) : 1; }
    function qualifierSlots(def, fb) { var v = clamp(Math.floor(num(def.qualifierSlots, fb)), 2, 16); var h = 1; while (h * 2 <= v) h *= 2; return h; }
    function reentry(def, fb) { return def.reentryCooldownSeconds !== undefined ? Math.max(0, Math.floor(num(def.reentryCooldownSeconds, fb))) : fb; }
    function victoryCooldown(def, fb) { return def.victoryCooldownSeconds !== undefined ? Math.max(0, Math.floor(num(def.victoryCooldownSeconds, fb))) : reentry(def, fb); }
    function matchTimeout(def, fb) { return def.matchTimeoutSeconds !== undefined ? Math.max(30, Math.floor(num(def.matchTimeoutSeconds, fb))) : fb; }
    function nextRound(def, fb) { return def.nextRoundSeconds !== undefined ? Math.max(5, Math.floor(num(def.nextRoundSeconds, fb))) : fb; }
    function rulesAccept(def, fb) { return def.rulesAcceptSeconds !== undefined ? Math.max(10, Math.floor(num(def.rulesAcceptSeconds, fb))) : fb; }
    function returnSecs(def, fb) { return def.returnSeconds !== undefined ? Math.max(3, Math.floor(num(def.returnSeconds, fb))) : fb; }
    function arrivalSecs(def, fb) { return def.arrivalSeconds !== undefined ? Math.max(5, Math.floor(num(def.arrivalSeconds, fb))) : fb; }
    function lethalOf(def) { return def.lethal === true; }
    function usable(f) { return !!(f && f.entityId && String(f.entityId).trim()); }
    function isTagF(f) { return !!(f && f.entityId && String(f.entityId).charAt(0) === "#"); }
    function hasFinalistDef(def) { return usable(def.finalist); }
    function ringRadius(def) { return def.ring ? Math.max(1, Math.floor(num(def.ring.radius, 4))) : 4; }
    function displayName(def, id) { return def && def.displayName ? def.displayName : "tournament.dragonminez." + id; }
    function plainName(id) { return NAMES[id] || id; }

    // ---- fighters ------------------------------------------------------------------------------------------
    function pathOf(entityId) { var s = String(entityId || ""), c = s.indexOf(":"); return c >= 0 ? s.substring(c + 1) : s; }
    // 47_dmz_quests.js registers each saga fighter as dmzq_<path> (texture variant 0) and dmzq_<path>_v<n>
    function mobIdOf(entityId) {
        var base = "dmzq_" + pathOf(entityId);
        if (RPG.mobs.exists(base)) return base;
        return RPG.mobs.exists(base + "_v0") ? base + "_v0" : null;
    }
    function fighterName(entityId) {
        var mid = mobIdOf(entityId);
        var n = mid ? String(RPG.mobs.name(mid) || "") : "";
        n = n.replace(/[&§][0-9a-fk-or]/gi, "");
        return n || pathOf(entityId).replace(/^saga_/, "").replace(/_/g, " ");
    }
    // FighterIdentity.of
    var FORM_SUFFIXES = ["_base", "_ssj", "_ssj2", "_ssj3", "_ssj4", "_ssg2", "_ssg3", "_lssj", "_restricted", "_ultimate", "_fp", "_transformed", "_giant", "_powered", "_noweights", "_baby"];
    var ALIASES = {};
    function alias(identity) { for (var i = 1; i < arguments.length; i++) ALIASES[arguments[i]] = identity; }
    alias("saga_frieza", "saga_frieza_first", "saga_frieza_second", "saga_frieza_third");
    alias("saga_zarbon", "saga_zarbont1");
    alias("saga_vegeta", "saga_ozaruvegeta");
    alias("saga_cell", "saga_cell_imperfect", "saga_cell_semiperfect", "saga_cell_perfect", "saga_cell_superperfect");
    alias("saga_superbuu", "saga_superbuu_piccolo", "saga_superbuu_gotenks", "saga_superbuu_gohan");
    alias("saga_piccolo_daimao", "saga_piccolo_daimao_old", "saga_piccolo_daimao_young");
    alias("saga_tao_pai_pai", "saga_tao_pai_pai_cyborg");
    alias("saga_cooler", "saga_cooler_5ta");
    alias("saga_metal_cooler", "saga_metal_cooler_core");
    alias("saga_a13", "saga_super_a13");
    alias("saga_janemba", "saga_janemba_fat", "saga_super_janemba");
    alias("saga_hirudegarn", "saga_hirudegarn_incomplete1", "saga_hirudegarn_incomplete2", "saga_super_hirudegarn");
    alias("saga_gogeta_gt", "saga_gogeta_ssj4");
    alias("saga_uub", "saga_majuub");
    alias("saga_baby", "saga_baby_vegeta", "saga_super_baby_vegeta", "saga_super_baby_vegeta2", "saga_baby_golden_ozaru");
    alias("saga_rilldo", "saga_metal_rilldo", "saga_hyper_rilldo");
    alias("saga_omega_shenron", "saga_syn_shenron");
    alias("saga_gomah", "saga_gomah_mini", "saga_gomah_third_eye");
    alias("saga_goku_daima", "saga_goku_mini");
    alias("saga_vegeta_daima", "saga_vegeta_mini");
    function identity(entityId) {
        if (!entityId) return "";
        var s = String(entityId), c = s.indexOf(":"), ns = c >= 0 ? s.substring(0, c + 1) : "", path = c >= 0 ? s.substring(c + 1) : s;
        if (ALIASES[path]) return ns + ALIASES[path];
        var stripped = true;
        while (stripped) {
            stripped = false;
            for (var i = 0; i < FORM_SUFFIXES.length; i++) {
                var suf = FORM_SUFFIXES[i];
                if (path.length > suf.length && path.substring(path.length - suf.length) === suf && path.lastIndexOf("_", path.length - suf.length - 1) >= 0) {
                    path = path.substring(0, path.length - suf.length); stripped = true; break;
                }
            }
        }
        return ns + (ALIASES[path] || path);
    }
    function pick(list) { return list[Math.floor(Math.random() * list.length)]; }
    function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
    // Bracket.resolveFighter: an id stays; a #tag picks an unused member (one this addon has a fighter for)
    function resolveFighter(entityId, used) {
        if (!entityId || !String(entityId).trim()) return "";
        if (String(entityId).charAt(0) !== "#") { used[identity(entityId)] = true; return entityId; }
        var members = (TAGS[entityId] || []).filter(function (p) { return NON_FIGHTERS.indexOf(p) < 0 && !!mobIdOf(p); })
            .map(function (p) { return "dragonminez:" + p; });
        if (!members.length) { RPG.log("[DMZ tournaments] fighter tag '" + entityId + "' is empty or unknown"); return ""; }
        var fresh = members.filter(function (m) { return !used[identity(m)]; });
        if (!fresh.length) return "";
        var picked = pick(fresh);
        used[identity(picked)] = true;
        return picked;
    }

    // ---- Bracket -------------------------------------------------------------------------------------------
    function slotFor(uuid) { return PLAYER_PREFIX + uuid; }
    function isPlayerSlot(s) { return !!s && (s === PLAYER_SLOT || String(s).indexOf(PLAYER_PREFIX) === 0); }
    function playerOf(s) { return s && String(s).indexOf(PLAYER_PREFIX) === 0 ? String(s).substring(PLAYER_PREFIX.length) : null; }

    function draw(tid, def, players) {
        var b = { tournament: tid, format: "BRACKET", round: 0, eliminated: false, completed: false, seeds: [], winners: [],
            semifinalist: "", finalist: "", champion: "", sources: {} };
        var used = {};
        b.semifinalist = resolveFighter(def.semifinalist && def.semifinalist.entityId, used);
        setSource(b, b.semifinalist, SOURCE_SEMIFINALIST);
        if (hasFinalistDef(def)) { b.finalist = resolveFighter(def.finalist.entityId, used); setSource(b, b.finalist, SOURCE_FINALIST); }
        b.champion = resolveFighter(def.champion && def.champion.entityId, used);
        setSource(b, b.champion, SOURCE_CHAMPION);
        var pool = [], contenders = def.contenders || [];
        for (var pass = 0; pass < 2; pass++) {
            for (var i = 0; i < contenders.length; i++) {
                var f = contenders[i];
                if (!usable(f) || isTagF(f) !== (pass === 1)) continue;
                var r = resolveFighter(f.entityId, used);
                if (!r || b.sources[r] !== undefined) continue;
                setSource(b, r, i);
                pool.push(r);
            }
        }
        shuffle(pool);
        if (!pool.length) RPG.log("[DMZ tournaments] '" + tid + "' drew no contenders; check the entity ids and tags in its config");
        b.format = formatOf(def);
        if (b.format === "GAUNTLET") { b.seeds = pool; return b; }
        var entrants = Math.max(1, players.length), slots = qualifierSlots(def, 4);
        while (slots < entrants && slots < 16) slots *= 2;
        while (slots > 2 && slots > entrants && pool.length < slots - entrants) slots /= 2;
        var board = new Array(slots), block = Math.max(1, Math.floor(slots / entrants));
        for (var k = 0; k < entrants && k < slots; k++) {
            var off = block > 1 ? Math.floor(Math.random() * block) : 0;
            board[Math.min(slots - 1, k * block + off)] = slotFor(players[k]);
        }
        var next = 0;
        for (var j = 0; j < slots; j++) { if (board[j] !== undefined) continue; board[j] = next < pool.length ? pool[next++] : ""; }
        b.seeds = board;
        return b;
    }
    function setSource(b, slot, src) { if (slot) b.sources[slot] = src; }
    function sourceOf(b, slot) { return slot && b.sources[slot] !== undefined ? b.sources[slot] : null; }
    function isGauntletB(b) { return b.format === "GAUNTLET"; }
    function hasContenders(b) { return b.seeds.some(function (s) { return s && !isPlayerSlot(s); }); }
    function hasFinalist(b) { return !!b.finalist; }
    function qualifierRounds(b) {
        if (isGauntletB(b)) return b.seeds.length;
        var r = 0;
        for (var rem = b.seeds.length; rem > 1; rem = Math.floor(rem / 2)) r++;
        return r;
    }
    function semiRound(b) { return qualifierRounds(b); }
    function finalistRound(b) { return hasFinalist(b) ? qualifierRounds(b) + 1 : -1; }
    function finalRound(b) { return qualifierRounds(b) + (hasFinalist(b) ? 2 : 1); }
    function totalRounds(b) { return finalRound(b) + 1; }
    function isQualifierRound(b, r) { return r < qualifierRounds(b); }
    function bActive(b) { return !b.eliminated && !b.completed; }
    function currentOpponent(b) {
        if (b.round === semiRound(b)) return b.semifinalist;
        if (b.round === finalistRound(b)) return b.finalist;
        if (b.round === finalRound(b)) return b.champion;
        if (!isQualifierRound(b, b.round)) return "";
        return b.round < b.seeds.length ? b.seeds[b.round] : "";
    }
    function advance(b) {
        if (!bActive(b)) return;
        b.round++;
        if (b.round >= totalRounds(b)) { b.round = totalRounds(b); b.completed = true; }
    }
    function pairCount(b, r) { return r < qualifierRounds(b) ? Math.max(1, Math.floor((b.seeds.length >> r) / 2)) : 1; }
    function winnersOf(b, r) { while (b.winners.length <= r) b.winners.push([]); return b.winners[r]; }
    function slotAt(b, r, pos) {
        if (r === 0) return pos >= 0 && pos < b.seeds.length ? b.seeds[pos] : "";
        var prev = winnersOf(b, r - 1);
        return pos >= 0 && pos < prev.length ? prev[pos] : "";
    }
    function nextMatchIndex(b, r) { return winnersOf(b, r).length; }
    function matchSlots(b, r, m) {
        if (r < qualifierRounds(b)) return [slotAt(b, r, m * 2), slotAt(b, r, m * 2 + 1)];
        if (r === semiRound(b)) {
            var q = winnersOf(b, Math.max(0, qualifierRounds(b) - 1));
            return [q.length ? q[0] : slotAt(b, 0, 0), b.semifinalist];
        }
        var prev = winnersOf(b, r - 1);
        return [prev.length ? prev[0] : "", r === finalistRound(b) ? b.finalist : b.champion];
    }
    function recordWinner(b, r, slot) { winnersOf(b, r).push(slot || ""); }
    function advanceRound(b) { if (b.round <= finalRound(b)) b.round++; }
    function replaceSeed(b, slot, rep) { var i = b.seeds.indexOf(slot); if (i < 0) return false; b.seeds[i] = rep || ""; return true; }
    function hiddenSeeds(b) { return b.seeds.map(function () { return HIDDEN_SLOT; }); }
    function finalWinner(b) { var last = winnersOf(b, finalRound(b)); return last.length ? last[0] : null; }

    // ---- Run / Progress -------------------------------------------------------------------------------------
    var PROGRESS = null;
    function progress() {
        if (!PROGRESS) {
            PROGRESS = RPG.data.get(K_PROGRESS, null) || {};
            if (!PROGRESS.runs) PROGRESS.runs = {};
            if (!PROGRESS.cooldowns) PROGRESS.cooldowns = {};
        }
        return PROGRESS;
    }
    // saved as soon as it changes (only on events, never every tick), so a reload or a crash keeps it
    function setDirty() { flush(); }
    function flush() {
        if (!PROGRESS) return;
        var now = Date.now(), cds = PROGRESS.cooldowns;
        Object.keys(cds).forEach(function (u) {
            Object.keys(cds[u]).forEach(function (t) { if (cds[u][t] <= now) delete cds[u][t]; });
            if (!Object.keys(cds[u]).length) delete cds[u];
        });
        RPG.data.set(K_PROGRESS, PROGRESS);
    }
    function getRun(tid) { var r = progress().runs[tid]; return r && !r.finished ? r : null; }
    function runOf(uuid) {
        var runs = progress().runs;
        for (var k in runs) { var r = runs[k]; if (r && !r.finished && r.participants.indexOf(uuid) >= 0) return r; }
        return null;
    }
    function activeRuns() { var out = [], runs = progress().runs; for (var k in runs) if (runs[k] && !runs[k].finished) out.push(runs[k]); return out; }
    function putRun(run) { progress().runs[run.tournament] = run; setDirty(); }
    function removeRun(tid) { if (progress().runs[tid]) { delete progress().runs[tid]; setDirty(); } }
    function remainingCooldown(uuid, tid) {
        var per = progress().cooldowns[uuid], until = per ? per[tid] : undefined;
        if (until === undefined) return 0;
        var left = until - Date.now();
        return left <= 0 ? 0 : Math.floor((left + 999) / 1000);
    }
    function startCooldown(uuid, tid, seconds) {
        if (seconds <= 0) { clearCooldown(uuid, tid); return; }
        var cds = progress().cooldowns;
        (cds[uuid] || (cds[uuid] = {}))[tid] = Date.now() + seconds * 1000;
        setDirty();
    }
    function clearCooldown(uuid, tid) {
        var per = progress().cooldowns[uuid];
        if (!per || per[tid] === undefined) return false;
        delete per[tid];
        if (!Object.keys(per).length) delete progress().cooldowns[uuid];
        setDirty();
        return true;
    }
    function clearAllCooldowns(uuid) {
        var per = progress().cooldowns[uuid];
        if (!per) return 0;
        delete progress().cooldowns[uuid];
        setDirty();
        return Object.keys(per).length;
    }

    function has(list, u) { return list.indexOf(u) >= 0; }
    function add(list, u) { if (list.indexOf(u) < 0) list.push(u); }
    function del(list, u) { var i = list.indexOf(u); if (i >= 0) list.splice(i, 1); }
    function isParticipant(run, u) { return has(run.participants, u); }
    function isElim(run, u) { return has(run.eliminated, u); }
    function isAlive(run, u) { return isParticipant(run, u) && !isElim(run, u); }
    function hasAnswered(run, u) { return has(run.accepted, u) || has(run.declined, u); }
    function accept(run, u) { del(run.declined, u); add(run.accepted, u); }
    function decline(run, u) { del(run.accepted, u); add(run.declined, u); }
    function aliveParticipants(run) { return run.participants.filter(function (u) { return !isElim(run, u); }); }
    function unanswered(run) { return aliveParticipants(run).filter(function (u) { return !hasAnswered(run, u); }); }
    function runEliminate(run, u) { add(run.eliminated, u); delete run.away[u]; }
    function isGauntlet(run) { return isGauntletB(run.bracket); }
    function createRun(tid, def, members, names, partyId, ring, dim, rulesDeadline) {
        return { tournament: tid, party: partyId || null, participants: members.slice(), names: names, eliminated: [], accepted: [], declined: [], ready: [],
            bracket: draw(tid, def, members), phase: "RULES", phaseDeadline: rulesDeadline, revealed: false,
            active: members.length ? members[0] : null, rival: null, finished: false, ring: ring, dim: dim, standing: null, away: {}, arrived: [] };
    }

    // ---- helpers ------------------------------------------------------------------------------------------
    function gameTime() { return RPG.world.gameTime(OVERWORLD); }
    // RPG.server.player takes a name; participants are kept by uuid
    function online(u) {
        if (!u) return null;
        var e = RPG.world.entityByUuid(u);
        return e && e.isPlayer() ? e.asPlayer() : null;
    }
    function uid(p) { return String(p.uuid); }
    function nameOf(run, u) { var p = online(u); return p ? p.name : (run.names && run.names[u]) || "???"; }
    function formatDuration(seconds) {
        var m = Math.floor(seconds / 60), r = seconds % 60;
        return m > 0 ? m + "m " + r + "s" : r + "s";
    }
    function broadcast(run, text) { run.participants.forEach(function (u) { var p = online(u); if (p) p.tell(text); }); }
    function pling(p, pitch) { p.playSound("minecraft:block.note_block.pling", 1, pitch); }
    function centreOf(run) { return { x: run.ring[0] + 0.5, y: run.ring[1], z: run.ring[2] + 0.5 }; }
    function distSqr(p, c) { var dx = p.x - c.x, dy = p.y - c.y, dz = p.z - c.z; return dx * dx + dy * dy + dz * dz; }

    // party (PartyManager via 78_dmz_party.js)
    function partyApi() { return typeof DMZ_PARTY !== "undefined" ? DMZ_PARTY : null; }
    function partyIdOf(p) { var P = partyApi(); return P ? P.partyIdOf(p) : null; }
    function inParty(p) { return !!partyIdOf(p); }
    function isPartyLeader(p) { var P = partyApi(); return !!P && P.isLeader(p); }
    function partyMembers(p) { var P = partyApi(); return P && inParty(p) ? P.members(p) : [p]; }
    function setFriendlyFire(partyId, on) { var P = partyApi(); if (P && P.setTournamentFriendlyFire) P.setTournamentFriendlyFire(partyId, on); }

    // ---- active bouts (Manager.ACTIVE, in memory like DMZ's) ----------------------------------------------
    var ACTIVE = {};          // player uuid -> { opp, pvp, round, match, self, rival, deadline, ring, dim, fightAt }
    function inGrace(m, t) { return t < m.fightAt; }
    function isFighting(u) { return !!ACTIVE[u]; }
    function arePvpRivals(a, b) { var m = a && ACTIVE[a]; return !!m && m.pvp && m.opp === b; }
    function canDamageFighter(u, attacker, t) {
        var m = ACTIVE[u];
        if (!m || !attacker) return true;
        if (inGrace(m, t)) return false;
        return String(attacker.uuid) === m.opp;
    }
    function isInGrace(u, t) { var m = ACTIVE[u]; return !!m && inGrace(m, t); }
    // Manager.ownerOf: the player a tournament opponent belongs to
    var OWNERS = {};          // mob uuid -> player uuid
    function ownerOf(e) {
        if (!e || e.isPlayer()) return null;
        var u = String(e.uuid);
        if (OWNERS[u]) return OWNERS[u];
        if (!e.hasTag(MATCH_TAG)) return null;
        var runs = activeRuns();
        for (var i = 0; i < runs.length; i++) if (runs[i].standing === u) return runs[i].active;
        return null;
    }

    // ---- sign-up (Manager.signUp) -------------------------------------------------------------------------
    function signUp(p, tid, ring, dim) {
        var def = getDef(tid);
        if (!def) return line("unavailable");
        var running = getRun(tid), me = uid(p);
        if (running) return isAlive(running, me) ? null : line("in_progress");
        if (runOf(me)) return line("busy_elsewhere");
        var cd = remainingCooldown(me, tid);
        if (cd > 0) return line("cooldown", [formatDuration(cd)]);
        var party = inParty(p);
        if (party && !isPartyLeader(p)) return line("party_leader_only");
        var members = [me], names = {};
        names[me] = p.name;
        if (party) {
            var list = partyMembers(p);
            for (var i = 0; i < list.length; i++) {
                var m = list[i], mu = uid(m);
                if (mu === me) continue;
                if (runOf(mu)) return line("member_busy", [m.name]);
                var mcd = remainingCooldown(mu, tid);
                if (mcd > 0) return line("member_cooldown", [m.name, formatDuration(mcd)]);
                members.push(mu);
                names[mu] = m.name;
            }
        }
        var run = createRun(tid, def, members, names, party ? partyIdOf(p) : null, ring, dim, gameTime() + rulesAccept(def, 60) * 20);
        if (!hasContenders(run.bracket)) {
            RPG.log("[DMZ tournaments] '" + tid + "' refused a sign-up: no contender could be resolved from its config");
            return line("unavailable");
        }
        putRun(run);
        broadcast(run, line("entered", [plainName(tid)], "&6"));
        openForAll(run);
        return null;
    }

    function answerRules(p, yes) {
        var me = uid(p), run = runOf(me);
        if (!run || !isAlive(run, me)) { p.actionbar(line("not_entered")); return; }
        if (run.phase !== "RULES" || hasAnswered(run, me)) return;
        if (yes) {
            accept(run, me);
            p.tell(line("rules_accepted", null, "&a"));
            broadcast(run, line("member_accepted", [p.name], "&7"));
        } else {
            decline(run, me);
            dropOut(run, p);
        }
        setDirty();
        if (!unanswered(run).length) settleRules(run); else pushBracket(run);
    }
    function dropOut(run, p) {
        var me = uid(p);
        runEliminate(run, me);
        if (!isGauntlet(run)) replaceSeed(run.bracket, slotFor(me), replacementFighter(getDef(run.tournament), run.bracket));
        p.tell(line("rules_declined", null, "&c"));
        broadcast(run, line("member_declined", [p.name], "&c"));
        setDirty();
    }
    function replacementFighter(def, b) {
        if (!def) return "";
        var taken = {};
        b.seeds.forEach(function (s) { if (s && !isPlayerSlot(s)) taken[identity(s)] = true; });
        taken[identity(b.semifinalist)] = true; taken[identity(b.finalist)] = true; taken[identity(b.champion)] = true;
        var drawn = {};
        b.seeds.forEach(function (s) { var src = sourceOf(b, s); if (src !== null && src >= 0) drawn[src] = true; });
        var unused = [], usableIdx = [], cs = def.contenders || [];
        for (var i = 0; i < cs.length; i++) { if (!usable(cs[i])) continue; usableIdx.push(i); if (!drawn[i]) unused.push(i); }
        var pool = unused.length ? unused : usableIdx;
        if (!pool.length) return "";
        for (var a = 0; a < pool.length * 2; a++) {
            var idx = pick(pool), used = {};
            for (var k in taken) used[k] = true;
            var r = resolveFighter(cs[idx].entityId, used);
            if (!r || taken[identity(r)]) continue;
            setSource(b, r, idx);
            return r;
        }
        return "";
    }
    function settleRules(run) {
        unanswered(run).forEach(function (u) {
            decline(run, u);
            var p = online(u);
            if (p) dropOut(run, p); else runEliminate(run, u);
        });
        if (!aliveParticipants(run).length) { cancelRun(run); return; }
        run.revealed = true;
        setDirty();
        broadcast(run, line("rules_settled", null, "&6"));
        syncTurn(run);
    }
    function cancelRun(run) { broadcast(run, line("cancelled", null, "&c")); finishRun(run); }

    // ---- bouts (Manager.nextBout / syncTurn) ---------------------------------------------------------------
    function alivePlayerOf(run, slot) { var u = playerOf(slot); return u && isAlive(run, u) ? u : null; }
    function roll(l, r) {
        if (isPlayerSlot(l) || !l) return r;
        if (isPlayerSlot(r) || !r) return l;
        return Math.random() < 0.5 ? l : r;
    }
    function nextBout(run) {
        var b = run.bracket;
        for (var guard = 0; guard < 256; guard++) {
            var r = b.round;
            if (r > finalRound(b)) return null;
            var m = nextMatchIndex(b, r);
            if (m >= pairCount(b, r)) { advanceRound(b); continue; }
            var pair = matchSlots(b, r, m), left = alivePlayerOf(run, pair[0]), right = alivePlayerOf(run, pair[1]);
            if (!left && !right) { recordWinner(b, r, roll(pair[0], pair[1])); continue; }
            if (!left && isPlayerSlot(pair[0])) { recordWinner(b, r, pair[1]); continue; }
            if (!right && isPlayerSlot(pair[1])) { recordWinner(b, r, pair[0]); continue; }
            if (!pair[0] || !pair[1]) { recordWinner(b, r, !pair[0] ? pair[1] : pair[0]); continue; }
            var bout = { round: r, match: m, left: pair[0], right: pair[1], leftPlayer: left, rightPlayer: right };
            bout.pvp = !!(left && right);
            bout.fighter = left || right;
            bout.fighterSlot = left ? pair[0] : pair[1];
            bout.opponentSlot = left ? pair[1] : pair[0];
            return bout;
        }
        return null;
    }
    function syncTurn(run) {
        if (run.finished) return;
        if (!aliveParticipants(run).length) { run.bracket.eliminated = true; finishRun(run); return; }
        if (isGauntlet(run)) { syncGauntletTurn(run); return; }
        var bout = nextBout(run);
        if (!bout) {
            var champ = playerOf(finalWinner(run.bracket));
            if (champ && isAlive(run, champ)) { run.bracket.completed = true; crown(run, champ); return; }
            finishRun(run);
            return;
        }
        run.active = bout.pvp ? bout.leftPlayer : bout.fighter;
        run.rival = bout.pvp ? bout.rightPlayer : null;
        startIntermission(run, bout.pvp);
    }
    function syncGauntletTurn(run) {
        var alive = aliveParticipants(run);
        if (!alive.length) { finishRun(run); return; }
        var cur = run.active, next;
        if (cur && has(alive, cur)) next = cur;
        else {
            var pool = alive.filter(function (u) { return u !== cur; });
            next = pool.length ? pick(pool) : alive[0];
        }
        run.active = next;
        run.rival = null;
        startIntermission(run, false);
    }
    function startIntermission(run, pvp) {
        var def = getDef(run.tournament), seconds = def ? nextRound(def, 30) : 30;
        run.phase = "INTERMISSION";
        run.phaseDeadline = gameTime() + seconds * 20;
        run.ready = [];
        setDirty();
        var active = online(run.active), rival = run.rival ? online(run.rival) : null;
        if (pvp && active && rival) broadcast(run, line("pvp_bout", [active.name, rival.name], "&d"));
        run.participants.forEach(function (u) {
            var p = online(u);
            if (!p || isElim(run, u)) return;
            if (u === run.active || u === run.rival) p.tell(line("your_turn", [seconds], "&6"));
            else if (active) p.tell(line("turn_of", [active.name, seconds], "&e"));
        });
        openForAll(run);
        sendPhase(run, "NEXT_ROUND", seconds);
    }
    function ready(p) {
        var me = uid(p), run = runOf(me);
        if (!run || run.phase !== "INTERMISSION" || !isAlive(run, me)) return;
        if (me !== run.active && me !== run.rival) return;
        if (has(run.ready, me)) return;
        add(run.ready, me);
        setDirty();
        broadcast(run, line("member_ready", [p.name], "&a"));
        var rivalReady = !run.rival || has(run.ready, run.rival);
        if (has(run.ready, run.active) && rivalReady) startPreview(run); else pushBracket(run);
    }
    function startPreview(run) {
        run.phase = "PREVIEW";
        run.phaseDeadline = gameTime() + PREVIEW_SECONDS * 20;
        setDirty();
        openForAll(run);
        sendPhase(run, "PREVIEW", PREVIEW_SECONDS);
    }
    function beginMatch(p, run) {
        var me = uid(p);
        if (isFighting(me)) return line("already_fighting");
        if (!isAlive(run, me)) return line("not_entered");
        if (me !== run.active) return line("not_your_turn");
        var def = getDef(run.tournament);
        if (!def) return line("unavailable");
        var refusal = isGauntlet(run) ? beginGauntletMatch(run, def, p) : beginBracketMatch(run, def, p);
        if (refusal) return refusal;
        run.phase = "BOUT";
        run.phaseDeadline = 0;
        setDirty();
        pushBracket(run);
        sendPhase(run, "COUNTDOWN", COUNTDOWN_SECONDS);
        return null;
    }
    function beginGauntletMatch(run, def, p) {
        var b = run.bracket;
        if (!bActive(b)) return line("not_entered");
        var oid = currentOpponent(b), f = fighterFor(def, b, oid);
        if (!f) return line("unavailable");
        var radius = ringRadius(def), mob = reuseStandingOpponent(run, oid);
        if (!mob) mob = spawnOpponent(run, f, oid, radius, b.round, p);
        else { OWNERS[String(mob.uuid)] = uid(p); mob.target = p; }
        if (!mob) return line("unavailable");
        run.standing = String(mob.uuid);
        startBout(run, def, p, mob, null, b.round, 0, PLAYER_SLOT, oid, radius);
        return null;
    }
    function beginBracketMatch(run, def, p) {
        var bout = nextBout(run);
        if (!bout || uid(p) !== (bout.pvp ? bout.leftPlayer : bout.fighter)) return line("not_your_turn");
        var radius = ringRadius(def);
        if (bout.pvp) {
            var rival = online(bout.rightPlayer);
            if (!rival || isFighting(bout.rightPlayer)) return line("not_your_turn");
            setFriendlyFire(run.party, true);
            startBout(run, def, p, null, rival, bout.round, bout.match, bout.left, bout.right, radius);
            startBout(run, def, rival, null, p, bout.round, bout.match, bout.right, bout.left, -radius);
            return null;
        }
        var f = fighterFor(def, run.bracket, bout.opponentSlot);
        if (!f) return line("unavailable");
        if (run.standing) { despawnOpponent(run.standing); run.standing = null; }      // a leftover from before a restart
        var mob = spawnOpponent(run, f, bout.opponentSlot, radius, bout.round, p);
        if (!mob) return line("unavailable");
        run.standing = String(mob.uuid);
        startBout(run, def, p, mob, null, bout.round, bout.match, bout.fighterSlot, bout.opponentSlot, radius);
        return null;
    }
    function startBout(run, def, p, mob, rival, round, match, selfSlot, rivalSlot, offset) {
        var ring = run.ring;
        p.teleportTo(run.dim, ring[0] + 0.5 - offset, ring[1], ring[2] + 0.5, offset >= 0 ? 90 : 270, 0);
        p.setVelocity(0, 0, 0);
        if (mob) { mob.setAI(false); mob.target = null; }
        var fightAt = gameTime() + COUNTDOWN_SECONDS * 20;
        ACTIVE[uid(p)] = { opp: mob ? String(mob.uuid) : uid(rival), pvp: !!rival, round: round, match: match, self: selfSlot, rival: rivalSlot,
            deadline: fightAt + matchTimeout(def, 300) * 20, ring: ring, dim: run.dim, fightAt: fightAt };
        setFrozen(p, true);
        if (mob && mob.hasTag("dmz_halo")) sendHalo(mob);
        clearBystanders(p, ACTIVE[uid(p)]);
    }
    // StatsData.status.matchFrozen: no moving, attacking, charging or forms during the countdown
    RPG.effects.define("dmz_match_frozen", { name: "&6Get Ready", hidden: true, beneficial: false, keepOnDeath: false,
        flags: ["noMove", "noJump", "noAttack", "noUse", "noSkills", "noKeys"] });
    function setFrozen(p, on) {
        if (on) { p.addEffect("dmz_match_frozen", COUNTDOWN_SECONDS * 20 + 2); p.setVelocity(0, 0, 0); }
        else if (p.hasEffect("dmz_match_frozen")) p.removeEffect("dmz_match_frozen");
    }
    function reuseStandingOpponent(run, entityId) {
        if (!isGauntlet(run) || !run.standing) return null;
        var mob = RPG.world.entityByUuid(run.standing);
        if (!mob || !mob.isAlive()) { run.standing = null; return null; }
        if (mob.rpgId !== mobIdOf(entityId)) { mob.remove(); run.standing = null; return null; }
        return mob;
    }

    // ---- the tick (Manager.tick) ---------------------------------------------------------------------------
    function tick() {
        var hasActive = false;
        for (var k in ACTIVE) { hasActive = true; break; }
        if (hasActive) tickMatches();
        var runs = activeRuns();
        for (var i = 0; i < runs.length; i++) tickRun(runs[i]);
    }
    function tickMatches() {
        var t = gameTime(), outcomes = [];
        Object.keys(ACTIVE).forEach(function (u) {
            var m = ACTIVE[u], p = online(u);
            if (!m || !p) return;
            if (p.dimension !== m.dim) return;
            clearBystanders(p, m);
            var timedOut = t > m.deadline;
            if (m.pvp) {
                var rival = online(m.opp);
                if (!p.isAlive()) { delete ACTIVE[u]; outcomes.push(function () { resolvePvp(p, m, false); }); }
                else if (!rival || !rival.isAlive()) { delete ACTIVE[u]; outcomes.push(function () { resolvePvp(p, m, true); }); }
                else if (timedOut) { delete ACTIVE[u]; outcomes.push(function () { voidPvp(p, m); }); }
                return;
            }
            var mob = RPG.world.entityByUuid(m.opp);
            if (mob && mob.isAlive() && (t - m.fightAt) % 100 === 0 && mob.hasTag("dmz_halo")) sendHalo(mob);
            if (mob && mob.isAlive()) {
                if (!inGrace(m, t) && !mob.hasAI()) { mob.setAI(true); mob.target = p; }
                else if (!inGrace(m, t)) { var tg = mob.target; if (!tg || String(tg.uuid) !== u) mob.target = p; }
            }
            var gone = !mob || !mob.isAlive();
            if (!p.isAlive()) { delete ACTIVE[u]; outcomes.push(function () { loseMatch(p, m); }); }
            else if (gone) { delete ACTIVE[u]; outcomes.push(function () { winMatch(p, m); }); }
            else if (timedOut) { delete ACTIVE[u]; outcomes.push(function () { voidMatch(p, m, mob); }); }
        });
        outcomes.forEach(function (f) { f(); });
    }
    // DBSagasEntity.setCharacterAlive(false): the halo of the dead over a fighter (Goku in the Otherworld Tournament),
    // drawn by the client (85_dmz_tournaments.js) like SagaHaloLayer; refreshed every 5 s for players who come near
    function sendHalo(mob) {
        RPG.world.entitiesNear(mob.dimension, mob.x, mob.y, mob.z, 96, "minecraft:player").forEach(function (o) {
            var op = o.asPlayer();
            if (op) RPG.net.send(op, "dmz_tourn_halo", { id: mob.entityId, ticks: 120 });
        });
    }
    // Nobody else within 15 blocks of a fighter: pushed out to the edge (players get a warning once a second)
    function clearBystanders(p, m) {
        var cx = p.x, cz = p.z, t = gameTime();
        p.nearby(EXCLUSION_RADIUS).forEach(function (e) {
            var eu = String(e.uuid);
            if (eu === m.opp || !e.isAlive()) return;
            if (e.rpgId && MD.BY_NPC[e.rpgId]) return;                 // MastersEntity
            if (e.isPlayer() && String(e.asPlayer().getGameMode()) === "spectator") return;
            if (ACTIVE[eu] || ownerOf(e)) return;
            var dx = e.x - cx, dz = e.z - cz, dy = e.y - p.y;
            if (Math.sqrt(dx * dx + dy * dy + dz * dz) >= EXCLUSION_RADIUS) return;
            var flat = Math.sqrt(dx * dx + dz * dz), nx, nz;
            if (flat * flat < 1e-4) { nx = Math.cos(e.entityId); nz = Math.sin(e.entityId); } else { nx = dx / flat; nz = dz / flat; }
            var tx = cx + nx * (EXCLUSION_RADIUS + 0.5), tz = cz + nz * (EXCLUSION_RADIUS + 0.5);
            if (e.isPlayer()) {
                var o = e.asPlayer();
                o.teleportTo(o.dimension, tx, o.y, tz, o.yaw, o.pitch);
                o.setVelocity(nx * PUSH_SPEED, 0, nz * PUSH_SPEED);
                if (t % 20 === 0) o.actionbar(line("keep_away", [Math.floor(EXCLUSION_RADIUS)], "&c"));
            } else {
                e.teleport(tx, e.y, tz);
                e.setVelocity(nx * PUSH_SPEED, 0, nz * PUSH_SPEED);
            }
        });
    }
    function tickRun(run) {
        var t = gameTime(), def = getDef(run.tournament);
        var retS = def ? returnSecs(def, 15) : 15, arrS = def ? arrivalSecs(def, 60) : 60, c = centreOf(run);
        var alive = aliveParticipants(run);
        for (var i = 0; i < alive.length; i++) {
            var u = alive[i], p = online(u);
            if (!p) continue;
            var away = p.dimension !== run.dim || distSqr(p, c) > FORFEIT_DISTANCE_SQR, deadline = run.away[u];
            if (!away) {
                if (!has(run.arrived, u)) { add(run.arrived, u); setDirty(); }
                if (deadline !== undefined) { delete run.away[u]; setDirty(); p.actionbar(line("returned", null, "&a")); }
                continue;
            }
            if (deadline === undefined) {
                var grace = has(run.arrived, u) ? retS : arrS;
                run.away[u] = t + grace * 20;
                setDirty();
                broadcast(run, line(has(run.arrived, u) ? "withdrawing" : "summoned", [p.name, grace], "&c"));
                continue;
            }
            if (t >= deadline) { withdraw(run, p); if (run.finished) return; continue; }
            var left = deadline - t;
            p.actionbar(line("return_timer", [Math.floor((left + 19) / 20)], "&c"));
            if (left % 20 === 0) pling(p, 0.8);
        }
        if (run.finished) return;
        switch (run.phase) {
            case "RULES": if (t >= run.phaseDeadline) settleRules(run); break;
            case "INTERMISSION": tickIntermission(run, t); break;
            case "PREVIEW": tickPreview(run, t); break;
            case "BOUT":
                var fighting = (run.active && isFighting(run.active)) || (run.rival && isFighting(run.rival));
                if (!fighting) syncTurn(run);
                break;
        }
    }
    function tickIntermission(run, t) {
        var a = run.active;
        if (!a || isElim(run, a)) { syncTurn(run); return; }
        if (isFighting(a)) return;
        var left = run.phaseDeadline - t;
        if (left > 0) { if (left % 20 === 0) sendPhase(run, "NEXT_ROUND", Math.floor(left / 20)); return; }
        var late = [];
        if (!has(run.ready, a)) late.push(a);
        if (run.rival && !has(run.ready, run.rival)) late.push(run.rival);
        if (!late.length) { startPreview(run); return; }
        late.forEach(function (u) {
            if (run.finished || !isAlive(run, u)) return;
            var p = online(u);
            if (!p) return;
            p.tell(line("next_round_expired", null, "&c"));
            eliminate(run, p, null);
        });
    }
    function tickPreview(run, t) {
        var left = run.phaseDeadline - t;
        if (left > 0) { if (left % 20 === 0) sendPhase(run, "PREVIEW", Math.floor(left / 20)); return; }
        var active = online(run.active);
        if (!active || isElim(run, run.active)) { syncTurn(run); return; }
        var refusal = beginMatch(active, run);
        if (refusal) { active.actionbar(refusal); skipUnplayableBout(run, active); }
    }
    function skipUnplayableBout(run, active) {
        var b = run.bracket;
        if (isGauntlet(run)) {
            RPG.log("[DMZ tournaments] '" + run.tournament + "': opponent '" + currentOpponent(b) + "' could not be fielded, skipping it");
            advance(b);
            setDirty();
            if (b.completed) { crown(run, uid(active)); return; }
            syncGauntletTurn(run);
            return;
        }
        var bout = nextBout(run);
        if (bout && !bout.pvp && nextMatchIndex(b, bout.round) === bout.match) {
            RPG.log("[DMZ tournaments] '" + run.tournament + "': opponent '" + bout.opponentSlot + "' could not be fielded, " + active.name + " advances by walkover");
            recordWinner(b, bout.round, bout.fighterSlot);
            setDirty();
        }
        syncTurn(run);
    }

    // ---- knock-outs (ArenaProtectionHandler / CombatEvent) ---------------------------------------------------
    function isNonLethalOpponent(mob) {
        var owner = ownerOf(mob);
        if (!owner) return false;
        var m = ACTIVE[owner];
        if (!m || m.pvp || String(mob.uuid) !== m.opp) return false;
        var run = runOf(owner), def = run ? getDef(run.tournament) : null;
        return !!def && !lethalOf(def);
    }
    function knockOutOpponent(mob) {
        var owner = ownerOf(mob);
        if (!owner) return;
        var m = ACTIVE[owner], p = online(owner);
        delete ACTIVE[owner];
        if (!m || !p) return;
        mob.health = Math.max(1, mob.maxHealth * 0.05);
        p.tell(line("opponent_knockout", null, "&a"));
        mob.remove();
        winMatch(p, m);
    }
    function isInNonLethalMatch(u) {
        var m = ACTIVE[u];
        if (!m || m.pvp) return false;
        var run = runOf(u), def = run ? getDef(run.tournament) : null;
        return !!def && !lethalOf(def);
    }
    function knockOut(p) {
        var u = uid(p), m = ACTIVE[u];
        delete ACTIVE[u];
        if (!m) return;
        p.health = Math.max(1, p.maxHealth * 0.1);
        p.setFire(0);
        p.tell(line("knockout", null, "&c"));
        if (m.pvp) resolvePvp(p, m, false); else loseMatch(p, m);
    }
    function onKnockedDown(p, attacker) {
        if (!attacker || !arePvpRivals(uid(p), String(attacker.uuid))) return;
        var m = ACTIVE[uid(p)];
        delete ACTIVE[uid(p)];
        if (!m) return;
        p.tell(line("knockout", null, "&c"));
        resolvePvp(p, m, false);
    }
    function onPlayerDeath(p) {
        var u = uid(p), m = ACTIVE[u];
        delete ACTIVE[u];
        if (!m) return;
        if (m.pvp) resolvePvp(p, m, false); else loseMatch(p, m);
    }
    function onPlayerLogout(p) {
        var u = uid(p), run = runOf(u);
        if (!run || isElim(run, u)) { delete ACTIVE[u]; return; }
        if (run.phase === "RULES") {
            decline(run, u);
            dropOut(run, p);
            if (!unanswered(run).length) settleRules(run); else pushBracket(run);
            return;
        }
        broadcast(run, line("withdrew", [p.name], "&c"));
        eliminate(run, p, null);
    }
    function onPartyLeave(p) {
        var u = uid(p), run = runOf(u);
        if (!run || isElim(run, u)) return;
        broadcast(run, line("left_party", [p.name], "&c"));
        eliminate(run, p, null);
    }

    // ---- results (winMatch / loseMatch / resolvePvp / eliminate / crown) ----------------------------------------
    function roundName(b, r) {
        if (r === finalRound(b)) return L[hasFinalist(b) ? "round.title" : "round.final"];
        if (r === finalistRound(b)) return L["round.final"];
        if (r === semiRound(b)) return L["round.semi"];
        return fmt(L["round.qualifier"], [r + 1]);
    }
    function winMatch(p, m) {
        setFrozen(p, false);
        var run = runOf(uid(p));
        if (!run) return;
        var b = run.bracket;
        run.standing = null;
        p.tell(line("round_won", [m.round + 1, roundName(b, m.round)], "&a"));
        p.playSound("minecraft:block.note_block.pling", 1, 1.6);
        if (isGauntlet(run)) {
            advance(b);
            setDirty();
            if (b.completed) { crown(run, uid(p)); return; }
            syncGauntletTurn(run);
            return;
        }
        if (nextMatchIndex(b, m.round) === m.match) recordWinner(b, m.round, m.self);
        setDirty();
        syncTurn(run);
    }
    function loseMatch(p, m) {
        setFrozen(p, false);
        var run = runOf(uid(p));
        if (!run) return;
        var def = getDef(run.tournament), cd = def ? reentry(def, 1200) : 1200;
        p.tell(line("round_lost", [m.round + 1, roundName(run.bracket, m.round), formatDuration(cd)], "&c"));
        p.playSound("minecraft:block.note_block.bass", 1, 0.6);
        eliminate(run, p, m);
    }
    function resolvePvp(p, m, won) {
        var run = runOf(uid(p));
        if (!run) return;
        var b = run.bracket;
        if (nextMatchIndex(b, m.round) !== m.match) return;
        delete ACTIVE[uid(p)]; delete ACTIVE[m.opp];
        setFriendlyFire(run.party, false);
        var rival = online(m.opp), winner = won ? p : rival, loser = won ? rival : p;
        recordWinner(b, m.round, won ? m.self : m.rival);
        setDirty();
        if (winner) {
            setFrozen(winner, false);
            winner.tell(line("round_won", [m.round + 1, roundName(b, m.round)], "&a"));
            winner.playSound("minecraft:block.note_block.pling", 1, 1.6);
        }
        if (loser) {
            var def = getDef(run.tournament), cd = def ? reentry(def, 1200) : 1200;
            loser.tell(line("round_lost", [m.round + 1, roundName(b, m.round), formatDuration(cd)], "&c"));
            eliminate(run, loser, null);
            return;
        }
        syncTurn(run);
    }
    function voidPvp(p, m) {
        delete ACTIVE[uid(p)]; delete ACTIVE[m.opp];
        var run = runOf(uid(p));
        if (!run) return;
        setFriendlyFire(run.party, false);
        setFrozen(p, false);
        p.tell(line("timeout"));
        var rival = online(m.opp);
        if (rival) { setFrozen(rival, false); rival.tell(line("timeout")); }
        syncTurn(run);
    }
    function eliminate(run, p, match) {
        var u = uid(p);
        if (isElim(run, u)) return;
        var active = match || ACTIVE[u];
        delete ACTIVE[u];
        setFrozen(p, false);
        var b = run.bracket, gauntlet = isGauntlet(run);
        if (!gauntlet && active && nextMatchIndex(b, active.round) === active.match) {
            recordWinner(b, active.round, active.rival);
            if (active.pvp) { delete ACTIVE[active.opp]; setFriendlyFire(run.party, false); }
        }
        runEliminate(run, u);
        var def = getDef(run.tournament);
        startCooldown(u, run.tournament, def ? reentry(def, 1200) : 1200);
        var oppId = active && !active.pvp ? active.opp : run.standing;
        if (gauntlet && aliveParticipants(run).length) { freezeOpponent(oppId); run.standing = oppId || null; }
        else { despawnOpponent(oppId); run.standing = null; }
        broadcast(run, line("eliminated_broadcast", [p.name], "&c"));
        setDirty();
        if (!aliveParticipants(run).length) { b.eliminated = true; finishRun(run); return; }
        if (run.phase === "RULES") { if (!unanswered(run).length) settleRules(run); else pushBracket(run); return; }
        if (gauntlet) syncGauntletTurn(run); else syncTurn(run);
    }
    function withdraw(run, p) {
        var def = getDef(run.tournament), cd = def ? reentry(def, 1200) : 1200;
        broadcast(run, line("withdrew", [p.name], "&c"));
        p.tell(line("forfeit", [formatDuration(cd)], "&c"));
        eliminate(run, p, null);
    }
    function finishRun(run) {
        run.participants.forEach(function (u) {
            delete ACTIVE[u];
            var p = online(u);
            if (p) setFrozen(p, false);
        });
        setFriendlyFire(run.party, false);
        despawnOpponent(run.standing);
        run.standing = null;
        run.finished = true;
        broadcast(run, line("run_over", null, "&7"));
        sendPhase(run, "CLEAR", 0);
        pushBracket(run);
        removeRun(run.tournament);
    }
    function crown(run, champId) {
        var def = getDef(run.tournament), champ = online(champId);
        if (champ) { celebrate(champ, run); broadcast(run, line("champion_broadcast", [champ.name], "&6")); }
        var vcd = def ? victoryCooldown(def, 1200) : 1200;
        if (isGauntlet(run)) {
            run.participants.forEach(function (u) {
                if (has(run.declined, u)) return;
                var p = online(u);
                if (p) grantRewards(p, def);
                startCooldown(u, run.tournament, vcd);
            });
        } else if (champ) {
            grantRewards(champ, def);
            startCooldown(champId, run.tournament, vcd);
        }
        finishRun(run);
    }
    // celebrate + RaidFeedback.launchFireworks (6 rockets, yellow / red / purple, small ball / large ball / star)
    var ROCKET_SHAPES = [0, 1, 2];     // FireworkRocketItem.Shape ids: SMALL_BALL, LARGE_BALL, STAR
    function celebrate(p, run) {
        p.tell("&6&l" + L.victory);
        p.playSound("minecraft:entity.player.levelup", 1, 1);
        RPG.net.send(p, "dmz_wb_music", { id: "dmzpack:menu_music_12", once: true });
        var c = run.ring;
        for (var i = 0; i < 6; i++) {
            var x = c[0] + 0.5 + (Math.random() - 0.5) * 10, z = c[2] + 0.5 + (Math.random() - 0.5) * 10, y = c[1] + 1;
            var shape = ROCKET_SHAPES[Math.floor(Math.random() * 3)];
            RPG.server.runCommand("execute in " + run.dim + " run summon minecraft:firework_rocket " + x.toFixed(2) + " " + y.toFixed(2) + " " + z.toFixed(2)
                + " {LifeTime:20,FireworksItem:{id:\"minecraft:firework_rocket\",Count:1b,tag:{Fireworks:{Flight:1b,Explosions:[{Type:" + shape
                + "b,Trail:1b,Colors:[I;14602026,11743532,8073150]}]}}}}");
        }
        RPG.world.particle(run.dim, "minecraft:firework", c[0] + 0.5, c[1] + 1.5, c[2] + 0.5, 60, 2.0, 0.05);
        RPG.world.particle(p.dimension, "minecraft:totem_of_undying", p.x, p.y + p.height * 0.5, p.z, 80, 0.6, 0.35);
    }
    function grantRewards(p, def) {
        if (!def || !def.rewards) return;
        var r = def.rewards, tp = Math.max(0, Math.floor(num(r.trainingPoints, 0))), align = Math.floor(num(r.alignment, 0));
        if (tp > 0) p.addTp(tp, { source: "script", raw: true });
        if (align !== 0) p.setVar("dmz_alignment", clamp(num(p.getVar("dmz_alignment", 100), 100) + align, 0, 100));
        if (tp > 0) p.tell(line("reward_tp", [tp], "&e"));
        (r.commands || []).forEach(function (cmd) {
            if (!cmd || !String(cmd).trim()) return;
            RPG.server.runCommand(String(cmd).split("%player%").join(p.name));
        });
    }
    function voidMatch(p, m, mob) {
        if (mob) mob.remove();
        p.tell(line("timeout"));
        setFrozen(p, false);
        var run = runOf(uid(p));
        if (!run) return;
        run.standing = null;
        if (isGauntlet(run)) syncGauntletTurn(run); else syncTurn(run);
    }
    function freezeOpponent(id) {
        if (!id) return;
        var mob = RPG.world.entityByUuid(id);
        if (!mob || !mob.isAlive()) return;
        mob.setAI(false);
        mob.target = null;
    }
    function despawnOpponent(id) {
        if (!id) return;
        delete OWNERS[id];
        var mob = RPG.world.entityByUuid(id);
        if (mob) mob.remove();
    }
    function fighterFor(def, b, slot) {
        if (!slot || isPlayerSlot(slot)) return null;
        var src = b ? sourceOf(b, slot) : null;
        if (src === SOURCE_CHAMPION) return def.champion;
        if (src === SOURCE_SEMIFINALIST) return def.semifinalist;
        if (src === SOURCE_FINALIST) return def.finalist;
        var cs = def.contenders || [];
        if (src !== null && src >= 0 && src < cs.length) return cs[src];
        if (def.champion && slot === def.champion.entityId) return def.champion;
        if (def.semifinalist && slot === def.semifinalist.entityId) return def.semifinalist;
        if (hasFinalistDef(def) && slot === def.finalist.entityId) return def.finalist;
        for (var i = 0; i < cs.length; i++) if (slot === cs[i].entityId) return cs[i];
        return null;
    }
    // Manager.spawnOpponent + applyStats: the saga fighter at the ring's +X edge facing in, frozen until the bell
    function spawnOpponent(run, f, entityId, radius, round, target) {
        var mid = mobIdOf(entityId);
        if (!mid) { RPG.log("[DMZ tournaments] fighter '" + entityId + "' is not a fighter this addon has"); return null; }
        var r = run.ring, x = r[0] + 0.5 + radius, y = r[1], z = r[2] + 0.5;
        var mob = RPG.world.spawnMob(run.dim, mid, x, y, z);
        if (!mob) return null;
        mob.teleportTo(run.dim, x, y, z, 270, 0);
        mob.addTag(MATCH_TAG);
        if (f.halo) mob.addTag("dmz_halo");
        OWNERS[String(mob.uuid)] = uid(target);
        var scaling = Math.pow(Math.max(1, num(f.perRoundScaling, 1)), round);
        var st = { hp: Math.max(1, num(f.health, DEFAULT_HEALTH)) * scaling, melee: Math.max(0, num(f.meleeDamage, 5)) * scaling,
            ki: Math.max(0, num(f.kiDamage, 5)) * scaling, tier: Math.max(0, Math.floor(num(f.aiTier, 2))) || 1, noTransform: true };
        if (typeof DMZ_SAGA !== "undefined" && DMZ_SAGA.dmzId(mob)) DMZ_SAGA.setup(mob, st);
        else { mob.maxHealth = st.hp; mob.health = st.hp; mob.setAttributeBase("generic.attack_damage", st.melee); }
        mob.health = mob.maxHealth;
        mob.setAI(false);
        return mob;
    }

    // ---- the protection rules (ArenaProtectionHandler) -----------------------------------------------------------
    RPG.on("damageFinal", function (e) {
        var t = e.target;
        if (!t || e.isCancelled()) return;
        var hasActive = false;
        for (var k in ACTIVE) { hasActive = true; break; }
        if (!hasActive) return;
        var gt = gameTime(), a = e.attacker;
        if (!t.isPlayer()) {
            var owner = ownerOf(t);
            if (!owner) return;
            if (!a || !a.isPlayer() || String(a.uuid) !== owner) { e.cancel(); return; }
            if (isInGrace(owner, gt)) e.cancel();
            return;
        }
        if (!canDamageFighter(String(t.uuid), a, gt)) e.cancel();
    });
    RPG.on("lethal", function (e) {
        var t = e.target;
        if (!t || e.isCancelled()) return;
        var hasActive = false;
        for (var k in ACTIVE) { hasActive = true; break; }
        if (!hasActive) return;
        if (!t.isPlayer()) {
            if (!isNonLethalOpponent(t)) return;
            e.cancel();
            knockOutOpponent(t);
            return;
        }
        var p = t.asPlayer(), u = uid(p);
        if (e.type === "minecraft:out_of_world" || e.type === "minecraft:generic_kill") return;      // BYPASSES_INVULNERABILITY
        if (isInNonLethalMatch(u)) { e.cancel(); knockOut(p); return; }
        // a party rival's finishing blow knocks down instead of killing (CombatEvent friendlyKnockdown) and ends the bout
        if (e.attacker && arePvpRivals(u, String(e.attacker.uuid))) {
            e.amount = Math.max(0, p.health - 1);
            if (typeof DMZ_KIWEAPON !== "undefined" && DMZ_KIWEAPON.knockDown) DMZ_KIWEAPON.knockDown(p);
            else p.addEffect("knocked_down", 100);
            onKnockedDown(p, e.attacker);
        }
    });
    RPG.on("death", function (p) { if (ACTIVE[uid(p)]) onPlayerDeath(p); });
    RPG.on("playerLeave", function (p) { if (ACTIVE[uid(p)] || runOf(uid(p))) onPlayerLogout(p); });
    // no item use / interaction during the countdown (onInteract / onUseItem): the frozen effect's noUse covers it

    // ---- the client (Service.sendBracket / pushBracket / openForAll / sendPhase) --------------------------------------
    function pushBracket(run) { run.participants.forEach(function (u) { var p = online(u); if (p) sendBracket(p, run.tournament, -1, true); }); }
    function openForAll(run) { aliveParticipants(run).forEach(function (u) { var p = online(u); if (p) sendBracket(p, run.tournament, -1, false); }); }
    function opponentLabel(run) {
        var slot;
        if (isGauntlet(run)) slot = currentOpponent(run.bracket);
        else { var bout = nextBout(run); slot = bout ? bout.opponentSlot : ""; }
        if (!slot || isPlayerSlot(slot)) return { t: "" };
        return { k: "entity.dragonminez." + pathOf(slot), t: fighterName(slot) };
    }
    function sendPhase(run, phase, seconds) {
        var left = { t: run.active ? nameOf(run, run.active) : "" };
        var right = run.rival ? { t: nameOf(run, run.rival) } : opponentLabel(run);
        run.participants.forEach(function (u) {
            var p = online(u);
            if (!p) return;
            var isFighter = phase !== "CLEAR" && !isElim(run, u) && (u === run.active || u === run.rival);
            RPG.net.send(p, "dmz_tourn_phase", { phase: phase, seconds: seconds, fighter: isFighter, left: left, right: right });
        });
    }
    function memberState(run, u) {
        if (has(run.declined, u)) return "DECLINED";
        if (isElim(run, u)) return "OUT";
        if (run.phase === "RULES") return has(run.accepted, u) ? "ACCEPTED" : "PENDING";
        return "ALIVE";
    }
    function usableContenders(def) { return Math.max(1, (def.contenders || []).filter(usable).length); }
    function previewId(f) { if (!usable(f)) return ""; return isTagF(f) ? HIDDEN_SLOT : f.entityId; }
    // what the client needs to draw a fighter: its name and its model (FighterIdentity stays server side)
    function fighterInfo(out, id) {
        if (!id || id === HIDDEN_SLOT || isPlayerSlot(id) || out[id]) return;
        var mid = mobIdOf(id), g = mid ? (RPG.mobs.get(mid) || {}).geo : null;
        out[id] = { name: fighterName(id), key: "entity.dragonminez." + pathOf(id),
            geo: g ? { model: g.model, texture: g.texture, animation: g.animation, idle: g.idle, scale: g.scale || 1 } : null };
    }
    function putStats(stats, id, f, round) {
        if (!usable(f) || !id || id === HIDDEN_SLOT) return;
        var s = Math.pow(Math.max(1, num(f.perRoundScaling, 1)), round);
        stats[id] = { health: Math.round(Math.max(1, num(f.health, 100)) * s), melee: Math.round(Math.max(0, num(f.meleeDamage, 5)) * s),
            ki: Math.round(Math.max(0, num(f.kiDamage, 5)) * s) };
    }
    function collectStats(def, b) {
        var stats = {};
        if (!b) {
            (def.contenders || []).forEach(function (f) { putStats(stats, previewId(f), f, 0); });
            putStats(stats, previewId(def.semifinalist), def.semifinalist, 1);
            if (hasFinalistDef(def)) putStats(stats, previewId(def.finalist), def.finalist, 2);
            putStats(stats, previewId(def.champion), def.champion, hasFinalistDef(def) ? 3 : 2);
            return stats;
        }
        b.seeds.forEach(function (s) { if (s && !isPlayerSlot(s)) putStats(stats, s, fighterFor(def, b, s), b.round); });
        putStats(stats, b.semifinalist, fighterFor(def, b, b.semifinalist), semiRound(b));
        if (hasFinalist(b)) putStats(stats, b.finalist, fighterFor(def, b, b.finalist), finalistRound(b));
        putStats(stats, b.champion, fighterFor(def, b, b.champion), finalRound(b));
        return stats;
    }
    function sendBracket(p, tid, npc, push) {
        var def = getDef(tid);
        if (!def) { if (!push) p.actionbar(line("unavailable")); return; }
        var run = getRun(tid), me = uid(p);
        var participant = !!run && isParticipant(run, me), b = participant ? run.bracket : null;
        var eliminated = participant && isElim(run, me), revealed = participant && run.revealed;
        var gauntlet = b ? isGauntletB(b) : formatOf(def) === "GAUNTLET";
        var signUpView = !run || !participant, lockedByOther = !!run && !participant;
        var phase = "NONE", phaseSeconds = 0;
        if (participant) {
            phase = run.phase;
            if (run.phaseDeadline > 0) { var left = run.phaseDeadline - gameTime(); phaseSeconds = left <= 0 ? 0 : Math.floor((left + 19) / 20); }
        }
        var seeds, winners;
        if (!b) { seeds = []; var hidden = gauntlet ? usableContenders(def) : qualifierSlots(def, 4); for (var i = 0; i < hidden; i++) seeds.push(HIDDEN_SLOT); winners = []; }
        else if (!revealed) { seeds = hiddenSeeds(b); winners = []; }
        else { seeds = b.seeds.slice(); winners = b.winners.map(function (w) { return w.slice(); }); }
        var members = [], slotNames = {}, myState = "PENDING", ents = {};
        if (run) {
            var leader = run.participants.length ? run.participants[0] : null;
            run.participants.forEach(function (u) {
                var name = nameOf(run, u), st = memberState(run, u), mp = online(u);
                members.push({ name: name, state: st, leader: u === leader, active: u === run.active || u === run.rival, ready: has(run.ready, u) });
                slotNames[slotFor(u)] = name;
                if (mp && mp.dimension === p.dimension) ents[slotFor(u)] = mp.entityId;
                if (u === me) myState = st;
            });
        } else if (inParty(p)) {
            var P = partyApi(), lead = P.leaderOf(p);
            partyMembers(p).forEach(function (m) {
                var cooling = remainingCooldown(uid(m), tid) > 0;
                members.push({ name: m.name, state: cooling ? "OUT" : "PENDING", leader: !!lead && uid(m) === uid(lead), active: false, ready: false });
            });
        } else members.push({ name: p.name, state: "PENDING", leader: true, active: false, ready: false });
        var partyLeader = !inParty(p) || isPartyLeader(p), myReady = !!run && has(run.ready, me);
        var activeSlot = "", rivalSlot = "";
        if (run && revealed && !isGauntlet(run) && run.active) {
            activeSlot = slotFor(run.active);
            if (run.rival) rivalSlot = slotFor(run.rival);
            else { var bout = nextBout(run); if (bout) rivalSlot = bout.opponentSlot; }
        }
        var semi = b ? b.semifinalist : previewId(def.semifinalist), fin = b ? b.finalist : hasFinalistDef(def) ? previewId(def.finalist) : "",
            champ = b ? b.champion : previewId(def.champion);
        var fighters = {};
        seeds.forEach(function (s) { fighterInfo(fighters, s); });
        [semi, fin, champ, rivalSlot].forEach(function (s) { fighterInfo(fighters, s); });
        var rw = def.rewards || {};
        RPG.net.send(p, "dmz_tourn_open", {
            id: tid, displayName: displayName(def, tid), stars: stars(def), gauntlet: gauntlet, lethal: lethalOf(def), phase: phase, phaseSeconds: phaseSeconds,
            revealed: revealed, seeds: seeds, winners: winners, semifinalist: semi, finalist: fin, champion: champ, round: b ? b.round : 0,
            eliminated: eliminated || (!!b && b.eliminated), completed: !!b && b.completed, signUp: signUpView, lockedByOther: lockedByOther,
            partyLeader: partyLeader, cooldown: remainingCooldown(me, tid), npc: npc, push: !!push, stats: collectStats(def, b), members: members,
            slotNames: slotNames, entities: ents, mySlot: slotFor(me), activeSlot: activeSlot, rivalSlot: rivalSlot, myState: myState, myReady: myReady,
            fighters: fighters,
            rules: { seeds: seeds.length, matchTimeout: matchTimeout(def, 300), reentry: reentry(def, 1200), returnSeconds: returnSecs(def, 15),
                rulesAccept: rulesAccept(def, 60), nextRound: nextRound(def, 10), tp: Math.max(0, Math.floor(num(rw.trainingPoints, 0))),
                alignment: Math.floor(num(rw.alignment, 0)), exclusion: Math.floor(EXCLUSION_RADIUS), forfeit: Math.floor(Math.sqrt(FORFEIT_DISTANCE_SQR)),
                countdown: COUNTDOWN_SECONDS }
        });
    }

    // ---- hosts and the ring (Service.handleAction / resolveNpc / resolveRing) ---------------------------------------
    var LAST_NPC = {};       // player -> the DMZ master id they last opened a tournament from
    function resolveNpc(p, dmzId) {
        if (!dmzId || !HOST_NPCS[dmzId]) return null;
        var rid = (MD.MASTERS[dmzId] || {}).npc || dmzId, best = null, bd = 1e9;
        p.nearby(12, { rpg: true }).forEach(function (e) {
            if (String(e.rpgId) !== rid) return;
            var dx = e.x - p.x, dy = e.y - p.y, dz = e.z - p.z, d = dx * dx + dy * dy + dz * dz;
            if (d <= MAX_NPC_DISTANCE_SQR && d < bd) { bd = d; best = e; }
        });
        return best;
    }
    // RingAnchor.areaAt: the built arena (DMZ structure, rotation NONE) around a point
    function arenaAt(dim, x, y, z) {
        if (typeof dmzBuilt !== "function") return null;
        var built = dmzBuilt();
        for (var k in built) {
            var b = built[k];
            if (!b || b.dim !== dim || !b.done || ARENAS.indexOf(String(b.name)) < 0) continue;
            if (x >= b.x && x < b.x + b.sx && y >= b.y - 2 && y < b.y + b.sy && z >= b.z && z < b.z + b.sz) return b;
        }
        return null;
    }
    function ringOverride(tid) { return RPG.data.get("dmz_tournament_ring:" + tid, null); }
    function resolveRing(p, npc, tid) {
        var def = getDef(tid);
        if (!def) return null;
        var area = arenaAt(npc.dimension, npc.x, npc.y, npc.z) || arenaAt(p.dimension, p.x, p.y, p.z);
        if (!area) return null;
        var ring = ringOverride(tid) || def.ring;
        if (ring && (ring.x !== undefined || ring.y !== undefined || ring.z !== undefined))
            return [area.x + Math.floor(num(ring.x, 0)), area.y + Math.floor(num(ring.y, 0)), area.z + Math.floor(num(ring.z, 0))];
        // groundInFrontOf: radius + 1 blocks in front of the host, on the first solid block below
        var dist = (ring ? Math.max(1, Math.floor(num(ring.radius, 4))) : 4) + 1, yaw = npc.yaw * Math.PI / 180;
        var x = Math.round(npc.x - Math.sin(yaw) * dist), z = Math.round(npc.z + Math.cos(yaw) * dist), floor = Math.max(area.y, Math.round(npc.y) - 8);
        for (var y = Math.round(npc.y) + 2; y > floor; y--) {
            var below = String(RPG.world.getBlock(npc.dimension, x, y - 1, z));
            if (below !== "minecraft:air" && below !== "minecraft:void_air" && below !== "minecraft:cave_air") return [x, y, z];
        }
        return [x, Math.round(npc.y), z];
    }
    function handleAction(p, action, dmzId) {
        switch (action) {
            case "ACCEPT_RULES": answerRules(p, true); return;
            case "DECLINE_RULES": answerRules(p, false); return;
            case "READY": ready(p); return;
            case "OPEN_BRACKET": case "SIGN_UP":
                var id = dmzId || LAST_NPC[uid(p)], npc = resolveNpc(p, id);
                if (!npc) return;
                var tid = HOST_NPCS[id];
                if (!tid) return;
                LAST_NPC[uid(p)] = id;
                if (action === "OPEN_BRACKET") { sendBracket(p, tid, id, false); return; }
                var ring = resolveRing(p, npc, tid);
                if (!ring) { p.actionbar(line("no_ring")); return; }
                var refusal = signUp(p, tid, ring, npc.dimension);
                if (refusal) { p.actionbar(refusal); return; }
                sendBracket(p, tid, id, false);
                return;
        }
    }
    var RATE = {};
    RPG.net.on("dmz_tourn", function (p, d) {
        if (!p || !d) return;
        var now = RPG.server.getTick(), k = uid(p);
        if (RATE[k] !== undefined && now - RATE[k] < 4 && now >= RATE[k]) return;      // PacketRateLimiter
        RATE[k] = now;
        handleAction(p, String(d.a || ""), d.npc ? String(d.npc) : null);
    });
    RPG.on("playerLeave", function (p) { delete RATE[uid(p)]; delete LAST_NPC[uid(p)]; });

    // ---- the loop -----------------------------------------------------------------------------------------------------
    RPG.every(1, function () {
        if (!PROGRESS && !RPG.data.has(K_PROGRESS)) return;
        try { tick(); } catch (err) { RPG.log("[DMZ tournaments] tick: " + err); }
    });
    // a restart forgets the bouts in progress (Manager.reset): the run picks up again at its next turn
    (function restore() {
        var runs = activeRuns();
        runs.forEach(function (run) {
            if (!run.away) run.away = {};
            if (!run.arrived) run.arrived = [];
            if (run.phase === "BOUT" && !isGauntlet(run) && run.standing) { despawnOpponent(run.standing); run.standing = null; }
        });
        if (runs.length) setDirty();
    })();

    // ---- party locks (PartyManager.isPartyLocked) -------------------------------------------------------------------
    function isPartyLocked(p) {
        var P = partyApi(), ids = P && inParty(p) ? P.memberIds(p) : [uid(p)];
        for (var i = 0; i < ids.length; i++) if (runOf(ids[i])) return true;
        return false;
    }

    // ---- /rpgc tournament (TournamentCommand) -----------------------------------------------------------------------
    DBR_CMD.renamed("tournament", "dmztournament", {
        description: "DMZ tournaments (ops): ring <tournament> | cooldown clear <player|@a> [tournament]",
        permission: 2,
        run: function (player, args) {
            var tell = function (s) { if (player) player.tell(s); else RPG.log(s.replace(/&./g, "")); };
            var sub = String(args[0] || "");
            if (sub === "ring") {
                var tid = String(args[1] || "");
                if (!player || !DEFS[tid]) { tell("&c/rpgc tournament ring <" + Object.keys(DEFS).join("|") + ">"); return; }
                var area = arenaAt(player.dimension, player.x, player.y, player.z);
                if (!area) { tell("&cYou are not standing inside a tournament arena structure."); return; }
                var r = { x: Math.floor(player.x) - area.x, y: Math.floor(player.y) - area.y, z: Math.floor(player.z) - area.z,
                    radius: ringRadius(DEFS[tid]) };
                RPG.data.set("dmz_tournament_ring:" + tid, r);
                tell("&aRing for '" + tid + "' saved at template offset " + r.x + ", " + r.y + ", " + r.z + " (structure rotation: NONE).");
                return;
            }
            if (sub === "cooldown" && String(args[1] || "") === "clear") {
                var who = String(args[2] || ""), t = args[3] ? String(args[3]) : null;
                if (t && !DEFS[t]) { tell("&cUnknown tournament '" + t + "'."); return; }
                var targets = who ? RPG.server.selectPlayers(who, player) : [];
                if (!targets.length) { tell("&cNo player was found"); return; }
                var cleared = 0;
                targets.forEach(function (o) { cleared += t ? (clearCooldown(uid(o), t) ? 1 : 0) : clearAllCooldowns(uid(o)); });
                flush();
                tell(cleared ? "&aCleared " + cleared + " tournament cooldown(s) across " + targets.length + " player(s)." : "&cThere were no tournament cooldowns to clear.");
                return;
            }
            tell("&e/rpgc tournament ring <tournament> &7| &e/rpgc tournament cooldown clear <player|@a> [tournament]");
        },
        suggest: function (player, args) {
            if (args.length <= 1) return ["ring", "cooldown"];
            if (args[0] === "ring") return Object.keys(DEFS);
            if (args[0] === "cooldown" && args.length === 2) return ["clear"];
            if (args[0] === "cooldown" && args.length === 3) return DBR_CMD.selectors();
            if (args[0] === "cooldown" && args.length === 4) return Object.keys(DEFS);
            return [];
        }
    });

    /** 61_dmz_masters.js: a host's "Tournament" option (TournamentPackets.ActionC2S OPEN_BRACKET). */
    function openBracket(p, host, dmzId) { handleAction(p, "OPEN_BRACKET", dmzId); }

    return { openBracket: openBracket, handleAction: handleAction, isPartyLocked: isPartyLocked, onPartyLeave: onPartyLeave,
        isEntered: function (p) { var r = runOf(uid(p)); return !!r && !isElim(r, uid(p)); },
        isFighting: function (p) { return isFighting(uid(p)); }, arePvpRivals: arePvpRivals, ownerOf: ownerOf,
        runOf: function (p) { return runOf(uid(p)); }, defs: function () { return DEFS; }, reload: loadDefs, HOST_NPCS: HOST_NPCS, L: L };
})();

/** The hook 61_dmz_masters.js looks for (TournamentPackets OPEN_BRACKET): DMZ's own NPC-hosted tournaments. */
var DMZ_TOURNAMENTS = DMZ_TOURN;
