// =====================================================================================
//  70_quests.js - the sagas (quest chains) and side quests
// =====================================================================================
//  Objective types:
//    { type: "kill", target: "saibaman", count: 10 }     entity id, "#tag", "*", mob/boss/NPC id
//    { type: "collect", item: "raw_dino_meat", count: 3, consume: true }
//    { type: "talk", npc: "korin" }
//    { type: "level", level: 5 }
//    { type: "skill", skill: "kamehameha", level: 1 }
//    { type: "location", x: 0, y: 64, z: 0, radius: 10, dimension: "minecraft:overworld" }
//    { type: "custom", key: "meditate", count: 5 }  -> scripts call player.progressQuest("meditate", 1)
//  Add description: "..." to any objective to change the text shown in the quest log.
//
//  turnIn: "npc_id"   wait until the player talks to that NPC (else it completes instantly)
//  next: "quest_id"   start the next quest automatically (that's how a saga chains)
//  rewards: { xp, money, statPoints, skillPoints, items, skills, effects, commands }
//  onStart(player) / onComplete(player)   requires: { level, quests: [...], class }
//  Admin shortcuts: /rpg quest start|complete|reset <player> <quest>
//
//  The sagas: Saiyan (6 quests) -> Namek (5) -> Androids (4) -> Majin Buu (6).
// =====================================================================================

// A boss arrives next to the player: warning, a few seconds of suspense, a crash landing.
// pod: an NPC prop to drop with it ("saiyan_pod" / "frieza_pod"), music: a DMZ boss track.
function bossArrives(player, bossId, warning, pod, music) {
    player.title("&c&lWARNING", warning);
    sfx(player, "minecraft:entity.elder_guardian.curse", 0.6, 0.6);
    RPG.schedule(60, () => {
        let x = player.x + 8, z = player.z;
        RPG.world.lightning(player.dimension, x, player.y, z, true);
        RPG.world.particle(player.dimension, "minecraft:explosion_emitter", x, player.y, z, 1, 0, 0);
        sfx(player, pod === "frieza_pod" ? "vehicle.frieza_capsule.land" : "ship_landing_open", 1.5, 1);
        if (pod) RPG.world.spawnNpc(player.dimension, pod, x + 2, player.y, z + 2);
        if (music) sfx(player, music, 1, 1);
        let boss = player.spawnBoss(bossId);
        if (boss) boss.teleport(x, player.y, z);
    });
}

// =====================================================================================
//  Tutorial
// =====================================================================================
RPG.quests.define("tutorial_basics", {
    name: "Bukujutsu Basics",
    description: "Every fighter starts here. Learn to charge your ki, fly and use a technique.",
    objectives: [
        { type: "custom", key: "charge_ki", count: 1, description: "Hold C until your ki is full" },
        { type: "custom", key: "fly", count: 1, description: "Press V to fly (level 3)" },
        { type: "custom", key: "cast_technique", count: 3, description: "Cast techniques with Alt+1..4" }
    ],
    rewards: { xp: 100, money: 200, skillPoints: 1, items: [{ item: "senzu_bean", count: 1 }] },
    onComplete(player) { player.tell("&aNice! Now find &6Master Roshi&a to start the Saiyan Saga."); }
});

// =====================================================================================
//  Saiyan Saga
// =====================================================================================
RPG.quests.define("saiyan_1_arrival", {
    name: "Saiyan Saga I: Korin's Tower",
    description: "Master Roshi wants you to prove yourself. Grow stronger, then find Korin.",
    objectives: [
        { type: "level", level: 5 },
        { type: "talk", npc: "korin", description: "Speak to Korin at the top of his tower" }
    ],
    turnIn: "master_roshi",
    rewards: { xp: 150, money: 250, items: [{ item: "senzu_bean", count: 2 }] },
    next: "saiyan_2_saibamen"
});

RPG.quests.define("saiyan_2_saibamen", {
    name: "Saiyan Saga II: Saibamen",
    description: "Strange green creatures are sprouting from the ground at night. Stop them!",
    objectives: [{ type: "kill", target: "saibaman", count: 10, description: "Defeat Saibamen" }],
    rewards: { xp: 400, money: 500, items: ["red_scouter"] },
    // Rewards have no TP field, so give it in code:
    onComplete(player) { player.addTp(200); player.tell("&b+200 TP"); },
    next: "saiyan_3_dragon_ball"
});

RPG.quests.define("saiyan_3_dragon_ball", {
    name: "Saiyan Saga III: The 4-Star Ball",
    description: "Roshi senses a Dragon Ball nearby. Bandits on the plains might have it.",
    objectives: [{ type: "collect", item: "dragon_ball_4", count: 1, description: "Find the 4-Star Dragon Ball" }],
    turnIn: "master_roshi",
    rewards: { xp: 500, skillPoints: 2, items: ["dragon_radar"] },
    next: "saiyan_4_raditz",
    onStart(player) { player.tell("&7(Bandits drop the 4-Star Ball more often while this quest is active.)"); }
});

RPG.quests.define("saiyan_4_raditz", {
    name: "Saiyan Saga IV: Raditz",
    description: "A Saiyan named Raditz has landed. He's coming for you!",
    objectives: [{ type: "kill", target: "raditz", count: 1, description: "Defeat Raditz" }],
    rewards: {
        xp: 1500, money: 2000, skillPoints: 3,
        // Lists must be all "names" or all { item, count } objects - don't mix the two.
        items: [{ item: "raditz_armor_chest" }, { item: "senzu_bean", count: 3 }],
        effects: [{ id: "well_fed", duration: 6000 }]
    },
    onStart(player) { bossArrives(player, "raditz", "&7A huge power level is approaching... 1,500!", "saiyan_pod", null); },
    onComplete(player) {
        player.addTp(1000);
        RPG.broadcast("&6" + player.name + " &edefeated Raditz! &7King Kai wants to meet them... (King Yemma, level 20)");
    },
    next: "saiyan_5_nappa"
});

RPG.quests.define("saiyan_5_nappa", {
    name: "Saiyan Saga V: Nappa",
    description: "Two more Saiyans arrive. The big bald one wants to play first.",
    requires: { level: 18 },
    objectives: [
        { type: "kill", target: "saibaman", count: 6, description: "Clear Nappa's Saibamen" },
        { type: "kill", target: "nappa", count: 1, description: "Defeat Nappa" }
    ],
    rewards: { xp: 2500, money: 3000, skillPoints: 2, items: [{ item: "saiyan_armor_chest" }, { item: "saiyan_armor_legs" }] },
    onStart(player) { bossArrives(player, "nappa", "&7Two power levels... one is over 4,000!", "saiyan_pod", null); },
    next: "saiyan_6_vegeta"
});

RPG.quests.define("saiyan_6_vegeta", {
    name: "Saiyan Saga VI: The Prince",
    description: "Vegeta. Beat him - and whatever he becomes when he sees the moon.",
    requires: { level: 22 },
    objectives: [{ type: "kill", target: "oozaru_vegeta", count: 1, description: "Defeat Vegeta... and his Great Ape form" }],
    rewards: { xp: 5000, money: 5000, skillPoints: 3, statPoints: 2, items: [{ item: "pattern_saiyan_armor" }, { item: "purple_capsule", count: 2 }] },
    onStart(player) { bossArrives(player, "vegeta_saiyan", "&7Power level: &c18,000&7. The Prince of all Saiyans.", "saiyan_pod", null); },
    onComplete(player) {
        player.addTp(2000);
        player.title("&6Saiyan Saga complete!", "&7Next: Namek. Ask Mr. Popo at the Lookout.");
    },
    next: "namek_1_arrival"
});

// =====================================================================================
//  Namek Saga
// =====================================================================================
RPG.quests.define("namek_1_arrival", {
    name: "Namek Saga I: A New World",
    description: "Frieza's soldiers are hunting Namek's Dragon Balls. Mr. Popo can send you there.",
    objectives: [
        { type: "location", x: 0, y: 56, z: 0, radius: 64, dimension: "ragnarok_rpg:namek", description: "Reach Planet Namek (Mr. Popo)" },
        { type: "kill", target: "frieza_soldier", count: 12, description: "Defeat Frieza Force soldiers" }
    ],
    rewards: { xp: 4000, money: 4000, items: [{ item: "t2_radar_chip" }, { item: "frieza_force_armor_chest" }] },
    next: "namek_2_dodoria"
});

RPG.quests.define("namek_2_dodoria", {
    name: "Namek Saga II: Dodoria",
    description: "Frieza's pink brute is burning villages.",
    objectives: [{ type: "kill", target: "dodoria", count: 1 }],
    rewards: { xp: 5000, money: 4000, skillPoints: 2, items: ["t2_radar_cpu"] },
    onStart(player) { bossArrives(player, "dodoria", "&7Something big and pink is coming.", null, null); },
    next: "namek_3_zarbon"
});

RPG.quests.define("namek_3_zarbon", {
    name: "Namek Saga III: Zarbon",
    description: "Frieza's elegant right hand. He's hiding a monstrous form.",
    objectives: [{ type: "kill", target: "zarbon_monster", count: 1, description: "Defeat Zarbon's true form" }],
    rewards: { xp: 6500, money: 5000, skillPoints: 2, items: [{ item: "pattern_namek_saiyan_armor" }, { item: "radar_piece" }] },
    onStart(player) { bossArrives(player, "zarbon", "&7'Beauty and power, in one package.'", null, null); },
    next: "namek_4_ginyu"
});

RPG.quests.define("namek_4_ginyu", {
    name: "Namek Saga IV: The Ginyu Force",
    description: "Recoome! Burter! Jeice! Guldo! Ginyu! Together they are... the Ginyu Force!",
    requires: { level: 35 },
    objectives: [
        { type: "kill", target: "guldo", count: 1 }, { type: "kill", target: "recoome", count: 1 },
        { type: "kill", target: "burter", count: 1 }, { type: "kill", target: "jeice", count: 1 },
        { type: "kill", target: "ginyu", count: 1 }
    ],
    rewards: { xp: 12000, money: 10000, skillPoints: 4, items: [{ item: "purple_scouter" }] },
    onStart(player) {
        bossArrives(player, "guldo", "&d&lTHE GINYU FORCE!", null, null);
        ["recoome", "burter", "jeice", "ginyu"].forEach((b, i) => RPG.schedule(80 + i * 20, () => {
            let boss = player.spawnBoss(b);
            if (boss) boss.teleport(player.x - 6 + i * 3, player.y, player.z + 6);
        }));
    },
    next: "namek_5_frieza"
});

RPG.quests.define("namek_5_frieza", {
    name: "Namek Saga V: Frieza",
    description: "The Emperor of the Universe. He has four forms, and he'll use all of them.",
    requires: { level: 40 },
    objectives: [{ type: "kill", target: "frieza_full_power", count: 1, description: "Defeat 100% Full Power Frieza" }],
    rewards: { xp: 25000, money: 20000, skillPoints: 5, statPoints: 5, items: [{ item: "namek_dragon_radar" }, { item: "kaioshin_fruit" }] },
    onStart(player) { bossArrives(player, "frieza_first", "&5&l'I'll show you a real nightmare...'", "frieza_pod", null); },
    onComplete(player) {
        player.addTp(5000);
        RPG.broadcast("&6&l" + player.name + " defeated Frieza! &eA golden legend is born.");
    },
    next: "android_1_gero"
});

// =====================================================================================
//  Android Saga
// =====================================================================================
RPG.quests.define("android_1_gero", {
    name: "Android Saga I: Dr. Gero",
    description: "A boy from the future warned of androids. Here they are: 19 and Gero himself.",
    requires: { level: 42 },
    objectives: [{ type: "kill", target: "android_19", count: 1 }, { type: "kill", target: "dr_gero", count: 1 }],
    rewards: { xp: 15000, money: 12000, skillPoints: 3, items: [{ item: "pattern_gero_outfit" }] },
    onStart(player) {
        bossArrives(player, "android_19", "&7No power levels on the scouter... machines.", null, null);
        RPG.schedule(100, () => { let b = player.spawnBoss("dr_gero"); if (b) b.teleport(player.x - 6, player.y, player.z); });
    },
    next: "android_2_twins"
});

RPG.quests.define("android_2_twins", {
    name: "Android Saga II: 17 and 18",
    description: "Gero's 'masterpieces' are loose, and they don't take orders.",
    requires: { level: 45 },
    objectives: [{ type: "kill", target: "android_17", count: 1 }, { type: "kill", target: "android_18", count: 1 }],
    rewards: { xp: 18000, money: 15000, skillPoints: 3, items: [{ item: "pattern_android_17_outfit" }, { item: "pattern_android_18_outfit" }] },
    onStart(player) {
        bossArrives(player, "android_17", "&7Infinite energy, endless stamina.", null, null);
        RPG.schedule(80, () => { let b = player.spawnBoss("android_18"); if (b) b.teleport(player.x - 6, player.y, player.z); });
    },
    next: "android_3_cell"
});

RPG.quests.define("android_3_cell", {
    name: "Android Saga III: Perfection",
    description: "A creature made from the cells of the strongest fighters is absorbing people.",
    requires: { level: 48 },
    objectives: [{ type: "kill", target: "cell_perfect", count: 1, description: "Stop Cell from becoming perfect... then stop Perfect Cell" }],
    rewards: { xp: 30000, money: 20000, skillPoints: 4, statPoints: 4, items: [{ item: "mastery_capsule", count: 2 }] },
    onStart(player) { bossArrives(player, "cell_imperfect", "&2'I am Cell. And I am not yet... complete.'", null, null); },
    next: "android_4_cell_games"
});

RPG.quests.define("android_4_cell_games", {
    name: "Android Saga IV: The Cell Games",
    description: "Cell's tournament. Seven Cell Juniors, then Super Perfect Cell.",
    requires: { level: 52 },
    objectives: [{ type: "kill", target: "cell_jr", count: 7 }, { type: "kill", target: "cell_super_perfect", count: 1 }],
    rewards: { xp: 45000, money: 30000, skillPoints: 5, items: [{ item: "pattern_cell_saiyan_armor" }, { item: "senzu_bean_bag" }] },
    onStart(player) {
        player.title("&2&lTHE CELL GAMES", "&7Seven Cell Juniors appear!");
        for (let i = 0; i < 7; i++) RPG.schedule(20 + i * 10, () => spawnAround(player, "cell_jr", 1));      // 80_spawns_events.js
        RPG.schedule(400, () => bossArrives(player, "cell_super_perfect", "&e&lSUPER PERFECT CELL", null, null));
    },
    onComplete(player) { player.addTp(8000); player.title("&6Android Saga complete!", "&7Something stirs in a sealed ball..."); },
    next: "buu_1_spopovitch"
});

// Cell's own repeatable tournament (from talking to the Cell master).
RPG.quests.define("cell_games", {
    name: "The Cell Games (rematch)",
    description: "Cell wants another round. Defeat his Juniors for a prize.",
    repeatable: true,
    requires: { level: 35 },
    objectives: [{ type: "kill", target: "cell_jr", count: 5 }],
    rewards: { money: 4000, items: [{ item: "mastery_capsule" }] },
    onStart(player) { spawnAround(player, "cell_jr", 5); }
});

// =====================================================================================
//  Majin Buu Saga
// =====================================================================================
RPG.quests.define("buu_1_spopovitch", {
    name: "Buu Saga I: The Tournament Trap",
    description: "Babidi's minions steal energy at the World Tournament.",
    requires: { level: 55 },
    objectives: [{ type: "kill", target: "spopovitch", count: 1 }, { type: "kill", target: "majin_soldier", count: 10 }],
    rewards: { xp: 30000, money: 20000, skillPoints: 3 },
    onStart(player) { bossArrives(player, "spopovitch", "&7A swollen fighter with an 'M' on his forehead...", null, null); },
    next: "buu_2_babidi_ship"
});

RPG.quests.define("buu_2_babidi_ship", {
    name: "Buu Saga II: Babidi's Ship",
    description: "Floor by floor: Pui Pui, then Yakon.",
    objectives: [{ type: "kill", target: "pui_pui", count: 1 }, { type: "kill", target: "yakon", count: 1 }],
    rewards: { xp: 35000, money: 22000, skillPoints: 3, items: [{ item: "demon_eye" }] },
    onStart(player) {
        bossArrives(player, "pui_pui", "&5Floor one: Pui Pui.", null, null);
        RPG.schedule(160, () => bossArrives(player, "yakon", "&5Floor two: Yakon. Turn on the lights!", null, null));
    },
    next: "buu_3_dabura"
});

RPG.quests.define("buu_3_dabura", {
    name: "Buu Saga III: The Demon King",
    description: "Dabura, King of the Demon Realm. Don't let him spit on you.",
    objectives: [{ type: "kill", target: "dabura", count: 1 }],
    rewards: { xp: 45000, money: 30000, skillPoints: 4, items: [{ item: "demon_dragon_ball_1" }] },
    onStart(player) { bossArrives(player, "dabura", "&4The Demon King steps forward.", null, null); },
    next: "buu_4_majin_buu"
});

RPG.quests.define("buu_4_majin_buu", {
    name: "Buu Saga IV: Majin Buu",
    description: "The ball opened. Out came something pink, hungry and nearly indestructible.",
    requires: { level: 60 },
    objectives: [{ type: "kill", target: "majin_buu", count: 1 }],
    rewards: { xp: 60000, money: 40000, skillPoints: 4, items: [{ item: "pattern_majin_buu_vest" }] },
    onStart(player) { bossArrives(player, "majin_buu", "&d'Buu turn you into candy!'", null, null); },
    next: "buu_5_super_buu"
});

RPG.quests.define("buu_5_super_buu", {
    name: "Buu Saga V: Super Buu",
    description: "Evil Buu ate the good one. Now he's tall, smart and furious.",
    requires: { level: 65 },
    objectives: [{ type: "kill", target: "super_buu", count: 1 }],
    rewards: { xp: 80000, money: 50000, skillPoints: 5, items: [{ item: "pattern_super_buu_pants" }] },
    onStart(player) { bossArrives(player, "super_buu", "&d&lSUPER BUU", null, null); },
    next: "buu_6_kid_buu"
});

RPG.quests.define("buu_6_kid_buu", {
    name: "Buu Saga VI: Kid Buu",
    description: "Pure Majin Buu: no mind, no mercy. The final battle.",
    requires: { level: 70 },
    objectives: [{ type: "kill", target: "kid_buu", count: 1 }],
    rewards: { xp: 120000, money: 80000, skillPoints: 6, statPoints: 6, items: [{ item: "kaioshin_fruit", count: 2 }] },
    onStart(player) { bossArrives(player, "kid_buu", "&d&lKID BUU", null, "worldboss_music.janemba"); },
    onComplete(player) {
        player.addTp(20000);
        RPG.broadcast("&6&l" + player.name + " saved the universe from Majin Buu!");
        player.tell("&dThe Supreme Kai wants to thank you.");
    }
});

// =====================================================================================
//  Side quests
// =====================================================================================
RPG.quests.define("korin_dino_meat", {
    name: "Korin's Grocery Run",
    description: "Korin wants dino meat. Senzu beans don't grow on... well, actually they do.",
    repeatable: true,
    requires: { quests: ["saiyan_1_arrival"] },
    objectives: [{ type: "collect", item: "raw_dino_meat", count: 3, consume: true }],
    turnIn: "korin",
    rewards: { money: 150, items: ["senzu_bean"] }
});

RPG.quests.define("korin_sacred_water", {
    name: "The Ultra Divine Water",
    description: "Korin will let you drink the Sacred Water if you train with weights: defeat 25 enemies while wearing any weighted clothing.",
    requires: { level: 30 },
    objectives: [{ type: "custom", key: "weighted_kill", count: 25, description: "Defeat enemies while wearing weights" }],
    turnIn: "korin",
    rewards: { items: ["sacred_water"] }
});

RPG.quests.define("old_kai_ritual", {
    name: "The Ritual of Old Kai",
    description: "Ten long meditation sessions while Old Kai dances. Hold G and keep still.",
    requires: { level: 60 },
    objectives: [{ type: "custom", key: "meditate", count: 10, description: "Meditate (hold G, 5 seconds each)" }],
    turnIn: "old_kai",
    rewards: { skills: ["potential_unleashed"] },
    onComplete(player) { player.title("&b&lPOTENTIAL UNLEASHED", "&7Cast it from your skill bar!"); }
});

RPG.quests.define("baba_fighters", {
    name: "Baba's Five Fighters",
    description: "Fortune Teller Baba's champions. Win, and your future is free.",
    requires: { level: 15 },
    objectives: [
        { type: "kill", target: "dracula_man", count: 1 }, { type: "kill", target: "invisible_man", count: 1 },
        { type: "kill", target: "akkuman", count: 1 }
    ],
    turnIn: "fortune_teller_baba",
    rewards: { xp: 3000, money: 3000, items: [{ item: "orange_capsule", count: 2 }] },
    onStart(player) {
        ["dracula_man", "invisible_man", "akkuman"].forEach((b, i) => RPG.schedule(40 + i * 60, () => {
            let boss = player.spawnBoss(b);
            if (boss) boss.teleport(player.x + 6, player.y, player.z + i * 2);
        }));
    }
});

RPG.quests.define("world_tournament", {
    name: "The World Martial Arts Tournament",
    description: "Three rounds against the best on Earth. Mr. Satan is waiting in the final... sort of.",
    requires: { level: 15 },
    objectives: [
        { type: "kill", target: "tournament_nam", count: 1, description: "Round 1: Nam" },
        { type: "kill", target: "tournament_giran", count: 1, description: "Round 2: Giran" },
        { type: "kill", target: "jackie_chun", count: 1, description: "Final: Jackie Chun (he looks familiar...)" }
    ],
    rewards: { xp: 4000, money: 10000, items: [{ item: "music_disc_10" }] },
    onStart(player) {
        bossArrives(player, "tournament_nam", "&eRound 1!", null, null);
        RPG.schedule(300, () => bossArrives(player, "tournament_giran", "&eRound 2!", null, null));
        RPG.schedule(600, () => bossArrives(player, "jackie_chun", "&e&lTHE FINAL!", null, null));
    },
    onComplete(player) { RPG.broadcast("&6" + player.name + " is the new World Champion! &7(Mr. Satan has a badge for them.)"); }
});

RPG.quests.define("otherworld_tournament", {
    name: "The Other World Tournament",
    description: "Defeat the ogre wardens, then Pikkon, the champion of the West.",
    requires: { level: 50 },
    objectives: [{ type: "kill", target: "ogre", count: 5 }, { type: "kill", target: "pikkon", count: 1 }],
    turnIn: "grand_kai",
    rewards: { xp: 40000, money: 25000, skillPoints: 4, items: [{ item: "kaioshin_fruit" }] },
    onStart(player) {
        spawnAround(player, "ogre", 5);
        RPG.schedule(400, () => bossArrives(player, "pikkon", "&fPikkon enters the ring.", null, null));
    }
});

RPG.quests.define("namek_frogs", {
    name: "Frog Hunt",
    description: "One of these frogs is Captain Ginyu. Probably. Catch five.",
    repeatable: true,
    requires: { quests: ["namek_4_ginyu"] },
    objectives: [{ type: "kill", target: ["namek_frog", "namek_frog_1", "namek_frog_2", "namek_frog_ginyu"], count: 5 }],
    rewards: { money: 800, items: [{ item: "frog_legs_cooked", count: 3 }] }
});

RPG.quests.define("first_lesson", {
    name: "A Master's Lesson",
    description: "Masters teach techniques you can't learn alone. Learn one from any master.",
    objectives: [{ type: "custom", key: "learn_technique", count: 1, description: "Learn a technique from a master" }],
    rewards: { xp: 300, skillPoints: 1 }
});
