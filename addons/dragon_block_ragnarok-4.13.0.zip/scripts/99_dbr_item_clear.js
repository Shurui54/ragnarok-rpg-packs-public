// =====================================================================================
//  99_dbr_item_clear.js - DMZ Ragnarok's ground item clear
// =====================================================================================
//  Port of DMZ Ragnarok's (GPL-3.0) shuruisutilities ItemClearHandler and its ItemClear* settings (SUConfig):
//  dropped items lying on the ground are deleted every `intervalSeconds` (300), with a broadcast countdown at the
//  `warnSeconds` (60, 30, 10, 5) and a line saying how many went, the way a clearlag plugin does.
//    - Off by default, as in DMZ Ragnarok: it destroys players' property, so an operator has to turn it on.
//    - Dragon balls are never cleared, whatever is set (DMZ Ragnarok checks DragonBallSets.isDragonBall before the
//      exclusion list): here every confined item (RPG.items.confine: the balls and a sack holding one) is spared by
//      the engine's sweep. Balls a player died or logged out with are in a grave or totem, not on the ground.
//    - `excludedItems`: item ids never cleared.
//    - The countdown only advances while the clear is on; turning it off resets it. A warning second larger than the
//      interval never comes up. A clear that removed nothing is silent. An empty message silences that step.
//    - An operator's countdown (/rpgc clearitems warn) runs even while the scheduled clear is off, from the largest
//      warning second, and resets the scheduled cycle when it clears (ItemClearHandler.startCountdown / manualTicks).
//  Cheap: one check a second; item entities are only scanned when a clear actually runs (RPG.world.clearDroppedItems).
//  Settings: ragnarok_rpg/config/dbr_item_clear.json (/rpg config dbr_item_clear) or the Server rows of the DMZ
//  config menu (ops). Ops: /rpgc clearitems now | warn | on | off | status.
// =====================================================================================
var DBR_ITEM_CLEAR_CFG = RPG.config.define("dbr_item_clear", {
    enabled:         { default: false, client: true, comment: "Periodically delete dropped items lying on the ground, the way a clearlag plugin does. OFF by default and deliberately so: this destroys players' property. Dragon balls are NEVER cleared, whatever else is set here" },
    intervalSeconds: { default: 300, min: 10, max: 86400, integer: true, client: true, comment: "Seconds between one clear and the next. The countdown restarts the moment a clear runs, so 300 means a clear every five minutes. Only counts while enabled is true; turning the feature off resets the countdown rather than pausing it" },
    warnSeconds:     { default: "60,30,10,5", comment: "Seconds-before-the-clear at which a warning is broadcast, comma separated and in any order. Each value must be smaller than intervalSeconds to ever be reached. Leave empty for a silent clear with no warnings at all" },
    warnMessage:     { default: "&e[!] &fDropped items will be cleared in &c{seconds}&f seconds.", comment: "The warning line. {seconds} is replaced with how many seconds remain. Colour codes are written with &. Set to an empty string to suppress the warning while still clearing on schedule" },
    doneMessage:     { default: "&e[!] &fCleared &c{count}&f dropped items.", comment: "The line broadcast after a clear. {count} is replaced with how many item entities were removed. Empty suppresses it. Nothing is broadcast when a clear removed nothing" },
    excludedItems:   { default: "", comment: "Item ids never cleared, comma separated, e.g. \"minecraft:diamond,minecraft:netherite_ingot\". Every dragon ball is spared regardless of this list" }
});

// the DMZ config menu's Server rows (client/scripts/54_dmz_config_menu.js): ops change these live
RPG.net.on("dbr_item_clear_set", function (p, d) {
    var op = false;
    try { op = p.isOp(); } catch (e) { }
    if (!op || !d) return;
    if (d.key === "enabled") DBR_ITEM_CLEAR_CFG.set("enabled", !!d.value);
    else if (d.key === "intervalSeconds") DBR_ITEM_CLEAR_CFG.set("intervalSeconds", Math.round(Number(d.value)));
});

var DBR_ITEM_CLEAR = (function () {
    var C = DBR_ITEM_CLEAR_CFG;
    var seconds = 0;          // whole seconds counted since the last clear (ItemClearHandler.ticks / 20)
    var manual = -1;          // seconds left in an operator's countdown, -1 when none
    var warnSpec = null, warnSet = [], exclSpec = null, exclList = [];

    function warnSeconds() {
        var spec = String(C.get("warnSeconds", "") || "");
        if (spec !== warnSpec) {
            warnSet = [];
            spec.split(",").forEach(function (part) {
                var n = parseInt(part.trim(), 10);
                if (n > 0 && warnSet.indexOf(n) < 0) warnSet.push(n);   // a typo costs that one warning, not the clear
            });
            warnSpec = spec;
        }
        return warnSet;
    }
    function excluded() {
        var spec = String(C.get("excludedItems", "") || "");
        if (spec !== exclSpec) {
            exclList = spec.split(",").map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 0; })
                .map(function (s) { return s.indexOf(":") < 0 ? "minecraft:" + s : s; });
            exclSpec = spec;
        }
        return exclList;
    }
    function broadcast(key, token, value) {
        var t = C.get(key, "");
        if (t === null || t === undefined || String(t).trim() === "") return;     // an empty message: this step is silent
        RPG.server.broadcast(String(t).split(token).join(String(value)));
    }
    /** Remove every clearable dropped item in every loaded level; returns how many went. */
    function clearNow() { return RPG.world.clearDroppedItems({ exclude: excluded() }); }
    function clearAndAnnounce() {
        var n = clearNow();
        if (n > 0) broadcast("doneMessage", "{count}", n);
        return n;
    }
    /** Start an operator's countdown from the largest warning second; 0 (and nothing started) when there are none. */
    function startCountdown() {
        var longest = 0;
        warnSeconds().forEach(function (s) { longest = Math.max(longest, s); });
        if (longest <= 0) return 0;
        manual = longest;
        broadcast("warnMessage", "{seconds}", longest);
        return longest;
    }
    function remaining() { return Math.max(0, Math.max(1, C.get("intervalSeconds", 300)) - seconds); }

    RPG.every(20, function () {
        if (manual > 0) {
            manual--;
            if (manual > 0) {
                if (warnSeconds().indexOf(manual) >= 0) broadcast("warnMessage", "{seconds}", manual);
            } else {
                manual = -1;
                seconds = 0;
                clearAndAnnounce();
                return;
            }
        }
        if (!C.get("enabled", false)) { seconds = 0; return; }
        seconds++;
        var left = Math.max(1, C.get("intervalSeconds", 300)) - seconds;
        if (left > 0) {
            if (warnSeconds().indexOf(left) >= 0) broadcast("warnMessage", "{seconds}", left);
            return;
        }
        seconds = 0;
        clearAndAnnounce();
    });
    C.onChange(function (key) { if (key === "enabled" || key === "intervalSeconds") seconds = 0; });

    RPG.commands.register("clearitems", {
        permission: 2, description: "/rpgc clearitems now | warn | on | off | status: the ground item clear",
        suggest: function (p, a) { return a.length <= 1 ? ["now", "warn", "on", "off", "status"] : []; },
        run: function (p, args) {
            var say = function (t) { if (p) p.tell(t); else RPG.log(t.replace(/&./g, "")); };
            var verb = String(args[0] || "status").toLowerCase();
            if (verb === "now") {
                seconds = 0; manual = -1;
                var n = clearAndAnnounce();
                say("&aCleared " + n + " dropped item" + (n === 1 ? "" : "s") + ".");
            } else if (verb === "warn") {
                var s = startCountdown();
                if (s > 0) say("&aDropped items will be cleared in " + s + " seconds.");
                else { var m = clearAndAnnounce(); say("&eNo warning seconds are set, so the clear ran at once: " + m + " removed."); }
            } else if (verb === "on" || verb === "off") {
                C.set("enabled", verb === "on");
                say(verb === "on" ? "&aThe ground item clear is on: every " + C.get("intervalSeconds", 300) + " seconds." : "&eThe ground item clear is off.");
            } else if (verb === "status") {
                say("&eGround item clear: " + (C.get("enabled", false) ? "&aon" : "&coff") + "&7, every " + C.get("intervalSeconds", 300) + " s"
                    + (C.get("enabled", false) ? ", next in " + remaining() + " s" : "") + (manual > 0 ? ", countdown: " + manual + " s" : "")
                    + "; warnings at " + (warnSeconds().slice().sort(function (a, b) { return b - a; }).join(", ") || "none")
                    + "; excluded: " + (excluded().join(", ") || "none") + " (dragon balls always).");
            } else say("&cUsage: /rpgc clearitems now | warn | on | off | status");
            if (verb !== "status") RPG.log("[audit] " + (p ? p.name : "console") + " ran clearitems " + verb);
        }
    });
    return { clearNow: clearNow, startCountdown: startCountdown, remaining: remaining };
})();
