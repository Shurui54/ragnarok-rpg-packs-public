// =====================================================================================
//  32_dbr_form_editor.js - the in-game form editor (server side)
// =====================================================================================
//  Port of DMZ Ragnarok's form editor workflow (FormFileManager + Save/Delete/OpenFormEditor
//  packets, GPL-3.0): ops pick a race, its groups, a group's ladder and a form, edit it in
//  client/scripts/70_form_editor.js and save. Saved races live in world storage:
//      RPG.data "dbr_forms_race_<race>" = { groups: [...raw groups...], by, at }
//      RPG.data "dbr_forms_rev"         = save counter
//  shared/07_dmz_forms_data.js merges them into DMZ_FORMS when scripts load, before
//  30_forms.js defines the form effects. A save also applies at once (applyLive below, like DMZ
//  Ragnarok's SaveFormPacket): DMZ_FORMS is rebuilt, the form effects are defined again and resent
//  to every player (RPG.server.syncDefinitions), clients get the new DMZ_FORMS and every player's
//  transformation (radial) menu state is sent again. No /rpg reload or relog needed.
//
//  Net (all chunked under ~24 KB per message):
//    server -> client "dbr_fe_data" {kind, id, i, n, s}: kind "applied" (what this load merged,
//      every player, for the client's copy of DMZ_FORMS) or "editor" (saved data, ops only)
//    client -> server "dbr_fe" {op: hello | open | save (chunked) | reset}
//    server -> client "dbr_fe_ack" {ok, op, race, msg, warnings, rev, appliedRev}
// =====================================================================================
var DBR_FORM_EDITOR = (function () {
    var FD = DMZ_FORMS, E = FD.EDIT, CHUNK = 24000, MAX_PARTS = 24;
    var inbox = {};               // uuid -> { id, race, n, parts, got, at }
    var seq = 0;

    function isOp(p) { try { return !!p && p.isOp(); } catch (e) { return false; } }
    function rev() { try { return Number(RPG.data.get(E.REV_KEY, 0)) || 0; } catch (e) { return 0; } }
    function saved() {
        var out = {};
        FD.RACES.forEach(function (r) {
            var v = RPG.data.get(E.DATA_PREFIX + r, null);
            if (v && v.groups) out[r] = v.groups;
        });
        return out;
    }
    function sendChunks(p, kind, payload) {
        var s = JSON.stringify(payload), n = Math.max(1, Math.ceil(s.length / CHUNK)), id = kind + "_" + (++seq);
        for (var i = 0; i < n; i++) RPG.net.send(p, "dbr_fe_data", { kind: kind, id: id, i: i, n: n, s: s.substring(i * CHUNK, (i + 1) * CHUNK) });
    }
    function appliedPayload() { var a = FD.applied(); return { rev: a.rev, races: a.races }; }
    function syncApplied(p) { sendChunks(p, "applied", appliedPayload()); }
    function ack(p, o) { o.rev = rev(); o.appliedRev = FD.applied().rev; RPG.net.send(p, "dbr_fe_ack", o); }

    function openFor(p) {
        if (!isOp(p)) { p.tell("&cThe form editor is for operators."); return; }
        sendChunks(p, "editor", { rev: rev(), appliedRev: FD.applied().rev, races: saved() });
    }

    function bump(p, what) {
        var r = RPG.data.add(E.REV_KEY, 1);
        RPG.log("[form editor] " + (p ? p.name : "console") + " " + what + " (rev " + r + ")");
        return r;
    }
    // Like DMZ Ragnarok's SaveFormPacket (writes the form config, reloads DMZ's configs and resyncs every client):
    // the saved forms go live at once. DMZ_FORMS is rebuilt from storage, the form effects (looks, speed) are
    // defined again and sent to every player, every client gets the new DMZ_FORMS, and every player's
    // transformation menu state is sent again, so new and edited forms show in the radial menu right away.
    function applyLive() {
        var a = FD.applyCustom(saved(), rev());
        try { if (typeof DMZ_LOOK !== "undefined" && DMZ_LOOK.defineFormEffects) DMZ_LOOK.defineFormEffects(); } catch (e) { RPG.log("[form editor] effects: " + e); }
        try { if (RPG.server.syncDefinitions) RPG.server.syncDefinitions(); } catch (e) { RPG.log("[form editor] sync: " + e); }
        RPG.server.players().forEach(function (q) {
            syncApplied(q);
            try { if (typeof DMZ_TF !== "undefined") DMZ_TF.sendState(q, false); } catch (e) { }
        });
        return a;
    }
    function save(p, race, groups) {
        if (FD.RACES.indexOf(race) < 0) { ack(p, { ok: false, op: "save", race: race, msg: "Unknown race " + race }); return; }
        var san = FD.sanitizeRace(groups);
        if (!san.groups.length) { ack(p, { ok: false, op: "save", race: race, msg: "Nothing to save: " + (san.errors[0] || "no valid groups"), warnings: san.errors.slice(0, 8) }); return; }
        RPG.data.set(E.DATA_PREFIX + race, { groups: san.groups, by: p.name, at: Date.now() });
        bump(p, "saved " + race + " forms");
        applyLive();
        ack(p, { ok: true, op: "save", race: race, msg: "Saved and applied.", warnings: san.errors.slice(0, 8) });
        p.tell("&a[Form editor] Saved &f" + race + "&a forms: they are live now (transformation menu, looks and stats).");
    }
    function reset(p, race) {
        if (FD.RACES.indexOf(race) < 0) { if (p) ack(p, { ok: false, op: "reset", race: race, msg: "Unknown race " + race }); return false; }
        RPG.data.remove(E.DATA_PREFIX + race);
        bump(p, "reset " + race + " forms to defaults");
        applyLive();
        if (p) {
            ack(p, { ok: true, op: "reset", race: race, msg: "Back to defaults (applied)." });
            p.tell("&a[Form editor] &f" + race + "&a forms reset to defaults (applied).");
        }
        return true;
    }

    RPG.net.on("dbr_fe", function (p, d) {
        if (!p || !d) return;
        var op = String(d.op || "");
        if (op === "hello") { syncApplied(p); return; }
        if (!isOp(p)) return;                                   // everything below edits the world
        if (op === "open") openFor(p);
        else if (op === "reset") reset(p, String(d.race || ""));
        else if (op === "save") {
            var n = Math.floor(Number(d.n)), i = Math.floor(Number(d.i)), id = String(d.id || ""), race = String(d.race || "");
            if (!(n >= 1 && n <= MAX_PARTS && i >= 0 && i < n) || typeof d.s !== "string" || d.s.length > 32000) return;
            var box = inbox[p.uuid];
            if (!box || box.id !== id) box = inbox[p.uuid] = { id: id, race: race, n: n, parts: [], got: 0, at: Date.now() };
            if (box.parts[i] === undefined) { box.parts[i] = d.s; box.got++; }
            if (box.got < box.n) return;
            delete inbox[p.uuid];
            var groups = null;
            try { groups = JSON.parse(box.parts.join("")); } catch (e) { ack(p, { ok: false, op: "save", race: race, msg: "Save data was damaged, try again" }); return; }
            save(p, box.race, groups);
        }
    });
    // stale half-sent saves
    RPG.every(1200, function () { var now = Date.now(); Object.keys(inbox).forEach(function (k) { if (now - inbox[k].at > 60000) delete inbox[k]; }); });

    // every client keeps the same DMZ_FORMS as the server
    RPG.on("playerJoin", function (p) { syncApplied(p); });
    RPG.on("reload", function () { RPG.schedule(10, function () { RPG.server.players().forEach(syncApplied); }); });

    RPG.commands.register("formeditor", {
        permission: 2, description: "/rpgc formeditor [status | reset <race>] - edit DMZ forms in game (saves apply at once)",
        run: function (p, args) {
            var sub = String(args[0] || "");
            if (sub === "reset") {
                if (!reset(p, String(args[1] || ""))) { if (p) p.tell("&cRaces: " + FD.RACES.join(", ")); }
                else if (!p) RPG.log("[form editor] reset " + args[1] + " (applied)");
                return;
            }
            if (sub === "status" || !p) {
                var s = saved(), lines = [];
                FD.RACES.forEach(function (r) { lines.push(r + (s[r] ? " &e(edited, " + s[r].length + " groups)" : " &7(defaults)")); });
                var a = FD.applied(), r0 = rev();
                var head = "&6Form editor: &fsave " + r0 + (a.rev === r0 ? " &a(applied)" : " &c(not applied)");
                if (p) { p.tell(head); lines.forEach(function (l) { p.tell("&7 - &f" + l); }); }
                else RPG.log(head.replace(/&./g, "") + " " + lines.join(", ").replace(/&./g, ""));
                return;
            }
            openFor(p);
        }
    });

    return { openFor: openFor, saved: saved, reset: reset, rev: rev, syncApplied: syncApplied };
})();
