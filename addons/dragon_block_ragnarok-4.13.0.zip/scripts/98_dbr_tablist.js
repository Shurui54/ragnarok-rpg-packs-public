// =====================================================================================
//  DBR - DMZ Ragnarok's tab list (server side): the header and footer
// =====================================================================================
//  Port of DMZ Ragnarok's (GPL-3.0) tab list: a server banner above the header, the
//  server's header and footer, rows sorted by rank with the rank badge before each name
//  (client/scripts/98_dbr_tablist.js draws it). Here: the header / footer text, sent
//  to each player when they join and when the player count changes (never per tick).
//  Rank badges and prefixes come from the Ranks & Kits rank editor (/rank).
// =====================================================================================

var DBR_TAB_CFG = RPG.config.define("dbr_tablist", {
    enabled: { default: true, client: true, comment: "Draw DMZ Ragnarok's tab list (taller rows, rank badges, most senior rank first, banner) instead of the vanilla one" },
    header: { default: "&6&lDragon Block Ragnarok", comment: "Header line(s) above the players (& colours, &{icon:ns:path} pictures, \\n for a new line). Tokens: {online} {player}. Empty: none" },
    footer: { default: "&7Players online: &f{online}", comment: "Footer line(s) under the players. Same tokens. Empty: none" },
    banner: { default: "", client: true, comment: "A picture drawn across the top of the tab list, above the header (a texture in a pack, e.g. dbr:textures/gui/tab_banner.png; DMZ Ragnarok: tablist/banner.png). Up to 32 pixels tall. Empty: none" },
    showAlone: { default: true, client: true, comment: "Show the tab list in single player with nobody else on (vanilla and DMZ Ragnarok show nothing then)" }
});

var DBR_TAB = (function () {
    var last = {};
    function fill(text, p, online) {
        return String(text || "").replace(/\{online\}/g, String(online)).replace(/\{player\}/g, p.name);
    }
    function send(p, online, force) {
        var on = DBR_TAB_CFG.get("enabled");
        var h = on ? fill(DBR_TAB_CFG.get("header"), p, online) : "", f = on ? fill(DBR_TAB_CFG.get("footer"), p, online) : "";
        var key = h + "\u0000" + f;
        if (!force && last[p.uuid] === key) return;
        last[p.uuid] = key;
        p.setTabList(h, f);
    }
    function all(force, leaving) {
        var ps = RPG.server.players().filter(function (q) { return !leaving || q.uuid !== leaving.uuid; });
        ps.forEach(function (q) { send(q, ps.length, force); });
    }
    RPG.on("playerJoin", function (p) { RPG.schedule(1, function () { all(false); send(p, RPG.server.players().length, true); }); });
    RPG.on("playerLeave", function (p) { delete last[p.uuid]; all(false, p); });
    DBR_TAB_CFG.onChange(function () { all(true); });
    RPG.schedule(1, function () { all(true); });
    return { refresh: function () { all(true); } };
})();
