// =====================================================================================
//  92_dbr_raids.js - DMZ Ragnarok's raid bosses (sign-ups, arenas, scaling, phases, rewards, schedules)
// =====================================================================================
//  Port of DMZ Ragnarok (GPL-3.0) shuruis_raid_bosses: Config, raid/{RaidManager,RaidInstance,Scheduler,
//  RaidDamageTracker}, reward/RewardManager, util/Announcer, entity/RaidNpcs, item/RaidSoulItem,
//  event/ForgeEventHandler, command/RaidCommand and the GUI packets. Data model + tokens: shared/22_dbr_raids_data.js.
//  Dimensional tears (rifts): 92_dbr_raids_rifts.js. Z-Souls (the zsoul.* options): 92_dbr_raids_zsouls.js.
//  Screens: client/scripts/82_dbr_raids*.js.
//
//  Raid types: STANDARD (one boss scaled by fighters), PARALLEL_QUEST (sequential enemy waves, MVP by damage +
//  kill weight, optional boss finale), BOSS_RUSH (bosses in order, a delay before each, per-stage allies and
//  side swaps). Any raid can bring allies; a raid with a random pool draws one pooled raid into its own arena.
//  Flow: IDLE -> SIGNUP (announce + clickable Join, reminders) -> COUNTDOWN (teleported, healed) -> ACTIVE ->
//  FINISHED (rewards: participant / #1 top / #2-4 runner-up, 10 s in the arena, then home).
//  Death-save: a lethal raid hit sends the fighter home healed and eliminated. Per-hit ceiling (% of max HP).
//
//  Commands (DMZR's /rg raid ... is /raid ... here; /raidboss and /srb also work, and /rpgc raid ...):
//    /raid list | join <name> | leave <name> | status <name>
//    /raid edit | open <name> | start <name> | cancel <name> | create <id> [name]          (rg.raid.* nodes, ops)
//    /raid npc spawn <name> | npc bind <name> | npc remove [name] | soul <name>
//    /raid rift ...  (92_dbr_raids_rifts.js)
//  Config: ragnarok_rpg/config/dbr_raids.json (/rpg config dbr_raids) - DMZR's option names and defaults; they
//  seed new raids, which are then edited per raid in the editor (/raid edit).
//  Not ported: the cross-server raid network, SDU custom transformation chains, boss scale.
// =====================================================================================
var DBR_RAIDS = (function () {
    var D = DBR_RAIDS_DATA;
    var STEP = 5;                                  // the manager ticks every 5 game ticks
    var VICTORY_HOLD = 200, NULL_GRACE = 200, CONFINE_MARGIN = 1.0;

    // ---- Config (Config.java: same keys, defaults and ranges) ----
    var BIG = 1e300;
    var CFG = RPG.config.define("dbr_raids", {
        boss: {
            entityType: { default: "minecraft:warden", comment: "Default entity used as the raid boss (any registered entity id, a DBR mob id or a DMZ saga id like dragonminez:saga_frieza_first_form)." },
            name: { default: "Raid Boss", comment: "Default display name shown above the raid boss and on its boss bar." }
        },
        scaling: {
            baseHealth: { default: 500.0, min: 1, max: BIG, comment: "Base max health of the boss for a single participant." },
            healthPerPlayer: { default: 250.0, min: 0, max: BIG, comment: "Extra max health added per additional participant (linear health scaling)." },
            maxHealthCap: { default: 0.0, min: 0, max: BIG, comment: "Hard cap on the scaled max health (0 = no cap)." },
            scaleAttackDamage: { default: false, comment: "Also scale the boss's attack damage with the number of participants." },
            attackDamagePerPlayer: { default: 2.0, min: 0, max: BIG, comment: "Extra attack damage added per additional participant (only if scaleAttackDamage is on)." },
            maxDamagePercentPerHit: { default: 2.5, min: 0, max: 100, comment: "Most damage a SINGLE hit may do to a raid boss, as a percent of its max health (0 = no ceiling). Default for new raids; set per raid in the editor." }
        },
        rules: {
            allowPvpInArena: { default: false, comment: "Allow players to damage each other inside the raid arena." },
            preventReentry: { default: false, comment: "Players who are not active participants of a running raid are bounced out of its arena. Toggleable per raid." },
            healOnStart: { default: true, comment: "Fully heal all participants (health, ki, stamina) when the fight begins." },
            countdownSeconds: { default: 5, min: 0, max: 60, integer: true, comment: "Countdown after participants are teleported in, before the boss spawns." },
            fightTimeLimitSeconds: { default: 600, min: 0, max: 7200, integer: true, comment: "Fight time limit in seconds (0 = unlimited). On timeout the boss despawns and nobody is rewarded." }
        },
        signup: {
            maxParticipants: { default: 10, min: 0, max: 256, integer: true, comment: "Maximum participants per raid. 0 = unlimited." },
            minParticipants: { default: 1, min: 1, max: 256, integer: true, comment: "Minimum participants required or the raid is cancelled." },
            durationMinutes: { default: 5, min: 1, max: 1440, integer: true, comment: "How long sign-ups stay open before an auto-scheduled raid begins." },
            reminderSeconds: { default: 30, min: 0, max: 3600, integer: true, comment: "Repeat the sign-up announcement every N seconds while sign-ups are open. 0 = announce once." },
            requireDmzCharacter: { default: true, comment: "Require the player to have created a DragonMine Z character to sign up." }
        },
        npc: {
            name: { default: "Raid Master", comment: "Display name of the sign-up NPC." },
            lookRadius: { default: 8.0, min: 0, max: 64, comment: "How far (in blocks) a sign-up NPC turns to face the nearest player. 0 disables look-at." }
        },
        schedule: {
            hour: { default: 20, min: 0, max: 23, integer: true, comment: "Hour (server local time, 0-23) sign-ups auto-open on a scheduled day." },
            minute: { default: 0, min: 0, max: 59, integer: true, comment: "Minute of the hour for the auto-open time." },
            dayOfWeek: { default: 0, min: 0, max: 7, integer: true, comment: "Day of week for weekly scheduling (0=ignore/daily, 1=Monday .. 7=Sunday)." },
            dayOfMonth: { default: 0, min: 0, max: 28, integer: true, comment: "Day of month for monthly scheduling (0=ignore, 1-28)." }
        },
        announce: {
            useOnScreenTitles: { default: true, comment: "Show announcements as on-screen titles in addition to chat." },
            sound: { default: "minecraft:ui.toast.challenge_complete", comment: "Sound played to everyone on major announcements (empty to disable)." },
            signupOpen: { default: "&c[Raid] &fSign-ups are OPEN for {name}! Talk to {npc} or use /rg raid join {name}.", comment: "Sign-ups open. {name} {id} {npc} {boss}" },
            starting: { default: "&6[Raid] &f{name} begins with {count} fighters!", comment: "Raid starts. {name} {count} {boss}" },
            bossSpawn: { default: "&4[Raid] &f{boss} has appeared with &c{health} &fHP!", comment: "Boss spawns. {name} {boss} {health}" },
            victory: { default: "&6[Raid] &f{boss} has been defeated! Top damage: &e{top} &f({top_percent}%)", comment: "Victory. {name} {boss} {top} {top_percent} {mvp} {kills}" },
            timeout: { default: "&c[Raid] &fTime is up. {boss} escaped. Better luck next time!", comment: "Timeout / wipe. {name} {boss}" }
        },
        rewards: {
            participant: { default: ["command:give %player% minecraft:diamond 2", "message:&aYou dealt %damage_percent%% of the damage (rank #%rank%)!"],
                comment: "Rewards for every player who dealt damage. Tokens: command:<cmd> item:<id>:<count> skill:<dmzSkillId>:<levels> tp:<amount> message:<text> chance:<pct>:<token>. Placeholders: %player% %damage% %damage_percent% %rank% %kills% %boss% %total_damage%" },
            topDamage: { default: ["command:give %player% minecraft:netherite_ingot 1", "message:&6You dealt the most damage, %damage_percent%%!"], comment: "Extra rewards for the #1 damage dealer (MVP)." },
            runnerUp: { default: ["command:give %player% minecraft:gold_ingot 3", "message:&eRunner-up! You placed #%rank% with %damage_percent%%."], comment: "Extra rewards for the runner-up damage dealers (ranks 2-4)." }
        },
        // Z-Souls (92_dbr_raids_zsouls.js): DMZ Ragnarok's zsoul.* keys, defaults and ranges
        zsoul: {
            enable: { default: true, comment: "Master switch for the Z-Soul stat-cap system (worn in the Z-Soul accessory slots, B)." },
            slotCount: { default: 6, min: 1, max: 6, integer: true, comment: "How many Z-Souls a player can wear at once (how many of the six Z-Soul slots take one)." },
            bronzePercent: { default: 25.0, min: 0, max: BIG, comment: "Bronze Z-Soul: how far a stat may be pushed past the global cap, as a % of the cap. No upper ceiling on these percentages." },
            silverPercent: { default: 50.0, min: 0, max: BIG, comment: "Silver Z-Soul: extra cap headroom as a % of the global cap." },
            goldPercent: { default: 76.0, min: 0, max: BIG, comment: "Gold Z-Soul: extra cap headroom as a % of the global cap." },
            prismaticPercent: { default: 100.0, min: 0, max: BIG, comment: "Prismatic Z-Soul (top tier): extra cap headroom as a % of the global cap (100% = double the cap)." },
            autoConvertTrainingPoints: { default: true, comment: "If true, training points are automatically converted into beyond-cap growth while a soul is worn and its base stat is already at the global cap. If false, players spend TP on beyond-cap growth themselves (the Z-Soul + buttons in the stats screen, or /raid zsoul)." },
            trainingPointsPerPoint: { default: 1.0, min: 0.01, max: 100000, comment: "Training points spent per 1 point of beyond-cap stat growth (auto-convert)." },
            autoGrowthPerSecond: { default: 25, min: 1, max: 1000000, integer: true, comment: "Maximum beyond-cap points auto-converted per second, per stat (when autoConvert is on)." }
        }
    });

    /** RaidBossDef.createDefault: a fresh definition seeded from the config. */
    function createDefault(id, name) {
        var d = D.defaults(id, name);
        d.bossEntityType = CFG.get("boss.entityType"); d.bossName = CFG.get("boss.name");
        d.baseHealth = CFG.get("scaling.baseHealth"); d.healthPerPlayer = CFG.get("scaling.healthPerPlayer"); d.maxHealthCap = CFG.get("scaling.maxHealthCap");
        d.maxDamagePercentPerHit = CFG.get("scaling.maxDamagePercentPerHit"); d.scaleDamage = CFG.get("scaling.scaleAttackDamage"); d.damagePerPlayer = CFG.get("scaling.attackDamagePerPlayer");
        d.signupMinutes = CFG.get("signup.durationMinutes"); d.signupReminderSeconds = CFG.get("signup.reminderSeconds");
        d.minParticipants = CFG.get("signup.minParticipants"); d.maxParticipants = CFG.get("signup.maxParticipants"); d.requireCharacter = CFG.get("signup.requireDmzCharacter");
        d.pvpInArena = CFG.get("rules.allowPvpInArena"); d.preventReentry = CFG.get("rules.preventReentry"); d.healOnStart = CFG.get("rules.healOnStart");
        d.countdownSeconds = CFG.get("rules.countdownSeconds"); d.fightTimeLimit = CFG.get("rules.fightTimeLimitSeconds");
        d.npcName = CFG.get("npc.name");
        d.scheduleHour = CFG.get("schedule.hour"); d.scheduleMinute = CFG.get("schedule.minute"); d.scheduleDayOfWeek = CFG.get("schedule.dayOfWeek"); d.scheduleDayOfMonth = CFG.get("schedule.dayOfMonth");
        d.useTitles = CFG.get("announce.useOnScreenTitles"); d.announceSound = CFG.get("announce.sound");
        d.msgSignupOpen = CFG.get("announce.signupOpen"); d.msgStarting = CFG.get("announce.starting"); d.msgBossSpawn = CFG.get("announce.bossSpawn");
        d.msgVictory = CFG.get("announce.victory"); d.msgTimeout = CFG.get("announce.timeout");
        d.participantRewards = list(CFG.get("rewards.participant")); d.topRewards = list(CFG.get("rewards.topDamage")); d.runnerUpRewards = list(CFG.get("rewards.runnerUp"));
        return d;
    }
    function list(v) { var o = []; if (v) for (var i = 0; i < v.length; i++) o.push(String(v[i])); return o; }

    // =========================================================================================
    //  Persisted definitions (RaidData)
    // =========================================================================================
    var DEFS = null;
    function defs() {
        if (!DEFS) {
            DEFS = {};
            var raw = RPG.data.get("dbr_raids_defs", {}) || {};
            Object.keys(raw).forEach(function (k) { var d = D.normalize(raw[k]); if (d.id) DEFS[d.id] = d; });
        }
        return DEFS;
    }
    function saveDefs() { RPG.data.set("dbr_raids_defs", DEFS || {}); }
    function getDef(id) { return id ? defs()[String(id).toLowerCase()] || null : null; }
    function putDef(d) { d = D.normalize(d); if (!d.id) return null; defs()[d.id] = d; saveDefs(); return d; }
    function removeDef(id) { if (!getDef(id)) return false; delete defs()[String(id).toLowerCase()]; saveDefs(); return true; }
    function strip(s) { return String(s || "").replace(/[&§][0-9a-fk-or]/gi, ""); }
    /** /rg raid join "Name" - by id, then display name (colour codes ignored). */
    function findDef(name) {
        if (!name) return null;
        var n = String(name).replace(/^"|"$/g, "").trim(), d = getDef(n);
        if (d) return d;
        var low = strip(n).toLowerCase(), hit = null;
        Object.keys(defs()).forEach(function (k) { if (!hit && strip(defs()[k].name).toLowerCase() === low) hit = defs()[k]; });
        return hit;
    }
    function lastRun(id) { return Number((RPG.data.get("dbr_raids_lastrun", {}) || {})[id] || 0); }
    function setLastRun(id, ms) { var m = RPG.data.get("dbr_raids_lastrun", {}) || {}; m[id] = ms; RPG.data.set("dbr_raids_lastrun", m); }

    // =========================================================================================
    //  Small helpers
    // =========================================================================================
    function now() { return RPG.server.getTick(); }
    function alive(e) { try { return !!e && e.isAlive(); } catch (x) { return false; } }
    function player(uuid) { var e = uuid ? RPG.world.entityByUuid(uuid) : null; return e && e.isPlayer() ? e.asPlayer() : null; }
    function entity(uuid) { return uuid ? RPG.world.entityByUuid(uuid) : null; }
    function isOp(p) { try { return !p || p.isOp(); } catch (e) { return false; } }
    function can(p, node) { if (!p) return true; try { return p.isOp() || RPG.perms.has(p, node); } catch (e) { return false; } }
    function hasCharacter(p) { return !!p.getVar("dmz_created", 0); }
    function fmtPercent(v) { return (Math.round(v * 10) / 10).toFixed(1); }
    function fmtDur(s) { s = Math.max(0, Math.round(s)); return s >= 60 ? Math.floor(s / 60) + "m " + (s % 60) + "s" : s + "s"; }
    function fullHeal(p) {
        try { p.health = p.maxHealth; } catch (e) { }
        try { p.setResource("ki", p.maxResource("ki")); p.setResource("stamina", p.maxResource("stamina")); } catch (e) { }
    }
    function inRegion(r, dim, x, z, margin) {
        if (!r || r.dim !== dim) return false;
        margin = margin || 0;
        if (x < r.x1 - margin || x >= r.x2 + 1 + margin || z < r.z1 - margin || z >= r.z2 + 1 + margin) return false;
        if (r.r > 0) { var dx = x - r.cx, dz = z - r.cz, lim = r.r + margin; if (lim <= 0 || dx * dx + dz * dz > lim * lim) return false; }
        return true;
    }
    function inArena(r, e, margin) { return !!e && inRegion(r, e.dimension, e.x, e.z, margin); }
    function clampInside(r, x, z, margin) {
        var loX = r.x1 + margin, hiX = r.x2 + 1 - margin, loZ = r.z1 + margin, hiZ = r.z2 + 1 - margin;
        x = hiX >= loX ? Math.min(Math.max(x, loX), hiX) : (loX + hiX) / 2;
        z = hiZ >= loZ ? Math.min(Math.max(z, loZ), hiZ) : (loZ + hiZ) / 2;
        if (r.r > 0) {
            var lim = Math.max(1, r.r - margin), dx = x - r.cx, dz = z - r.cz, d = Math.sqrt(dx * dx + dz * dz);
            if (d > lim && d > 1e-4) { x = r.cx + dx * lim / d; z = r.cz + dz * lim / d; }
        }
        return { x: x, z: z };
    }
    function floorCenter(r) { return { x: (r.x1 + r.x2) / 2 + 0.5, y: r.y1 + 1, z: (r.z1 + r.z2) / 2 + 0.5 }; }
    var PASS = /(^|:)(air|cave_air|void_air|short_grass|grass|tall_grass|fern|large_fern|snow|dead_bush|dandelion|poppy|light)$|_flower$|_sapling$|_carpet$|torch$|_button$|_sign$|_pressure_plate$|vine$/;
    function passable(b) { b = String(b || ""); return !b || PASS.test(b); }
    function solid(b) { b = String(b || ""); return !!b && !passable(b) && b.indexOf("water") < 0 && b.indexOf("lava") < 0; }
    function standable(dim, x, y, z) {
        var bx = Math.floor(x), bz = Math.floor(z);
        return solid(RPG.world.getBlock(dim, bx, y - 1, bz)) && passable(RPG.world.getBlock(dim, bx, y, bz)) && passable(RPG.world.getBlock(dim, bx, y + 1, bz));
    }
    /** surfaceSnap / ceilingSurfaceSnap: a standable Y in the column, scanning down from the region's top. */
    function snapY(r, dim, x, z, keepHeight) {
        var top = Math.min(r.y2 + (keepHeight ? 1 : 2), 318), bottom = Math.max(r.y1 - (keepHeight ? 0 : 1), -63);
        for (var y = top; y >= bottom; y--) if (standable(dim, x, y, z)) return y;
        if (!keepHeight && RPG.world.isLoaded(dim, x, z)) { var s = RPG.world.surfaceY(dim, Math.floor(x), Math.floor(z)); if (s !== -9999 && s >= r.y1 - 2 && s <= r.y2 + 40) return s; }
        return null;
    }
    function randomIn(r) {
        for (var i = 0; i < 24; i++) {
            var x = r.x1 + 0.5 + Math.floor(Math.random() * (r.x2 - r.x1 + 1)), z = r.z1 + 0.5 + Math.floor(Math.random() * (r.z2 - r.z1 + 1));
            if (!(r.r > 0) || inRegion(r, r.dim, x, z, 0)) return { x: x, z: z };
        }
        var c = floorCenter(r);
        return { x: c.x, z: c.z };
    }
    /** safeSurfaceSpot: a random standable spot in the region, or a fallback. */
    function safeSpot(r, fallback, keepHeight) {
        for (var i = 0; i < 12; i++) {
            var p = randomIn(r), y = snapY(r, r.dim, p.x, p.z, keepHeight);
            if (y !== null) return { x: p.x, y: y, z: p.z };
        }
        if (fallback) return fallback;
        var c = floorCenter(r), cy = snapY(r, r.dim, c.x, c.z, keepHeight);
        return { x: c.x, y: cy === null ? r.y1 + 1 : cy, z: c.z };
    }

    // =========================================================================================
    //  Announcer
    // =========================================================================================
    function fmt(template, def) {
        return String(template || "").split("{name}").join(def.name).split("{id}").join(def.id).split("{npc}").join(def.npcName)
            .split("{boss}").join(def.bossName).split("/rg raid ").join("/raid ");
    }
    function sec(s) { return String(s || "").replace(/&([0-9a-fk-or])/gi, "§$1"); }
    function soundTo(p, def) { if (def && def.announceSound) try { p.playSound(def.announceSound, 1, 1); } catch (e) { } }
    function titleTo(p, title, sub, def) { if (def && def.useTitles && title) try { p.title(title, sub || ""); } catch (e) { } }
    function broadcast(msg) { RPG.broadcast(msg); }
    function announce(msg, title, def) {
        RPG.server.players().forEach(function (p) { if (msg) p.tell(msg); titleTo(p, title, "", def); soundTo(p, def); });
    }
    function announceTo(uuids, msg, title, def, opsToo) {
        var seen = {};
        uuids.forEach(function (u) { var p = player(u); if (!p) return; seen[u] = 1; if (msg) p.tell(msg); titleTo(p, title, "", def); soundTo(p, def); });
        if (opsToo) RPG.server.players().forEach(function (p) { if (!seen[p.uuid] && isOp(p) && msg) p.tell(msg); });
    }
    function tellTo(uuids, msg, opsToo) { announceTo(uuids, msg, null, null, opsToo); }
    /** Announcer.announceSignup: chat with a clickable [JOIN] button, on-screen title, sound. */
    function announceSignup(msg, title, def, cmd) {
        var json = JSON.stringify([{ text: sec(msg) + " " }, { text: "[JOIN]", color: "green", bold: true,
            clickEvent: { action: "run_command", value: cmd }, hoverEvent: { action: "show_text", contents: "§aClick to join the raid!" } }]);
        RPG.server.runCommand("tellraw @a " + json);
        RPG.server.players().forEach(function (p) { titleTo(p, title, strip(def.name), def); soundTo(p, def); });
    }
    function msgTo(p, text, color) { if (p) RPG.net.send(p, "dbr_raid_msg", { text: text, color: color || "#FFFFFF" }); }

    // =========================================================================================
    //  Rewards (RewardManager)
    // =========================================================================================
    function fill(s, p, ph) {
        var out = String(s).split("%player%").join(p.name).split("{player}").join(p.name).split("%uuid%").join(p.uuid);
        for (var k in ph) out = out.split(k).join(ph[k]);
        return out.split("%%").join("%");
    }
    function giveAll(p, tokens, ph) {
        (tokens || []).forEach(function (t) { try { applyReward(p, String(t).trim(), ph); } catch (e) { RPG.log("[Raid] Failed to apply reward '" + t + "': " + e); } });
    }
    function applyReward(p, token, ph) {
        var c = token.indexOf(":");
        if (c < 0) return;
        var type = token.substring(0, c).toLowerCase(), arg = token.substring(c + 1);
        if (type === "chance") {
            var i = arg.indexOf(":");
            if (i < 0) return;
            if (Math.random() * 100 < D.num(arg.substring(0, i), 0)) applyReward(p, arg.substring(i + 1).trim(), ph);
        } else if (type === "command") {
            RPG.server.runCommand(fill(arg, p, ph).replace(/^\//, ""));
        } else if (type === "message") {
            p.tell(fill(arg, p, ph));
        } else if (type === "item") {
            var r = D.reward(token), id = r.item;
            // DMZ Ragnarok item ids (dmz_ragnarok:z_soul_strength_gold) carry over to this addon's items of the same name
            if (/^dmz_ragnarok:/.test(id) && RPG.items.exists(id.substring(13))) id = id.substring(13);
            if (RPG.items.exists(id)) p.giveItem(id, Math.max(1, r.count));
            else p.giveItem(id.indexOf(":") < 0 ? "minecraft:" + id : id, Math.max(1, r.count));
        } else if (type === "tp") {
            var amt = D.num(arg, 0);
            if (amt) p.addTp(amt, { raw: true, events: false, source: "boss" });
        } else if (type === "skill" || type === "form") {
            var parts = arg.split(":"), sid = parts[0], lv = parts.length >= 2 ? D.int(parts[1], 1) : 1;
            if (typeof DMZ_SKILLS !== "undefined" && typeof DMZ_SKILLS_DATA !== "undefined" && DMZ_SKILLS_DATA.COSTS[sid]) DMZ_SKILLS.setLevel(p, sid, DMZ_SKILLS.level(p, sid) + lv);
            else if (typeof DMZ_TECH !== "undefined" && DMZ_TECH.unlock) DMZ_TECH.unlock(p, sid, { source: "raid" });
            else if (RPG.skills.exists(sid)) p.setSkillLevel(sid, p.skillLevel(sid) + lv);
        } else RPG.log("[Raid] Unknown reward type '" + type + "'");
    }

    // =========================================================================================
    //  Spawning: entity ids -> DBR bodies
    // =========================================================================================
    RPG.teams.define("dbr_raid_enemy", { name: "Raid Enemies", color: "red", friendlyFire: false, nametags: "always" });
    RPG.teams.define("dbr_raid_ally", { name: "Raid Allies", color: "green", friendlyFire: false, nametags: "always" });
    // DMZR's raid_npc (a player-skinned fighter) and the sign-up host
    RPG.mobs.define("dbr_raid_fighter", { name: "&fFighter", geo: { model: DMZ_GEO + "enemies/robotxv.geo.json", texture: DMZ_TEX + "enemies/robotxv.png",
        animation: DMZ_ANIM + "master/masters.animation.json", idle: "idle", walk: "walk", loops: ["tail"] }, health: 200, damage: 10, speed: 0.3, followRange: 48, persistent: true, xp: 0 });
    RPG.npcs.define("dbr_raid_master", { name: "&eRaid Master", skin: "minecraft:textures/entity/player/wide/steve.png", wander: false, invulnerable: true, showName: true });
    // ragnarok NPC characters (dmz_ragnarok:rgnpc + model) as fighters: one body per model a saved raid uses
    // (models added later need /rpg reload). Statue NPCs (62_rg_npcs.js) can't be hurt, so these are mobs.
    var RG_FIGHTERS = {};
    function rgFighterId(entry) { return "dbr_raid_rg_" + String(entry).replace(/[^a-z0-9_]/g, "_"); }
    (function defineRgFighters() {
        if (typeof RG_NPC_INDEX === "undefined") return;
        var want = {};
        function scan(d) {
            if (!d) return;
            if (d.bossModelId) want[d.bossModelId] = 1;
            (d.enemies || []).forEach(function (t) { var m = D.wave(t).rgModelId; if (m) want[m] = 1; });
            (d.allies || []).forEach(function (t) { var m = D.ally(t).rgModelId; if (m) want[m] = 1; });
            (d.rushStages || []).forEach(function (t) { var s = D.stage(t); if (s.rgModelId) want[s.rgModelId] = 1; s.allies.forEach(function (a) { var m = D.ally(a).rgModelId; if (m) want[m] = 1; }); });
        }
        Object.keys(defs()).forEach(function (k) { scan(defs()[k]); });
        var rifts = RPG.data.get("dbr_raids_rifts", {}) || {};
        Object.keys(rifts).forEach(function (k) { scan(rifts[k] && rifts[k].encounter); });
        Object.keys(want).forEach(function (entry) {
            var r = RG_NPC_INDEX[entry];
            if (!r) return;
            RG_FIGHTERS[entry] = rgFighterId(entry);
            RPG.mobs.define(rgFighterId(entry), { name: "&f" + r[5], geo: dmzSagaStates({ model: "dbr:geo/entity/rgnpc/" + r[1] + ".geo.json", texture: "dbr:textures/entity/rgnpc/" + r[2] + ".png",
                animation: DMZ_ANIM + "sagas/saga_base.animation.json", idle: "idle", walk: "walk", attack: "attack1_1" }), health: 200, damage: 10, speed: 0.3, followRange: 48, persistent: true, xp: 0 });
        });
    })();
    function sagaMob(path) { path = String(path || "").replace(/^saga_cl_/, "saga_"); return RPG.mobs.exists("dmzq_" + path) ? "dmzq_" + path : RPG.mobs.exists("dmzq_" + path + "_v0") ? "dmzq_" + path + "_v0" : null; }   // variant 0 has no suffix (47_dmz_quests.js)
    /** entity id (+ ragnarok model) -> { kind: "mob" | "npc" | "entity", id } */
    function resolveBody(type, model) {
        type = String(type || "").trim(); model = String(model || "").trim();
        if (type.indexOf("rgnpc#") === 0) { model = type.substring(6); type = "dmz_ragnarok:rgnpc"; }
        if (type === "dmz_ragnarok:rgnpc" || type === "dmz_ragnarok:ninjin_npc") {
            if (model && RG_FIGHTERS[model]) return { kind: "mob", id: RG_FIGHTERS[model] };
            var sm = sagaMob(model);
            return { kind: "mob", id: sm || "dbr_raid_fighter" };
        }
        if (!type || type === "dmz_ragnarok:raid_npc") return { kind: "mob", id: "dbr_raid_fighter" };
        if (RPG.mobs.exists(type)) return { kind: "mob", id: type };
        var c = type.indexOf(":"), ns = c >= 0 ? type.substring(0, c) : "", path = c >= 0 ? type.substring(c + 1) : type;
        if (ns === "" || ns === "dragonminez" || ns === "dmzpack" || ns === "dbr") {
            var s = sagaMob(path);
            if (s) return { kind: "mob", id: s };
            if (RPG.mobs.exists(path)) return { kind: "mob", id: path };
        }
        return { kind: "entity", id: c >= 0 ? type : "minecraft:" + type };
    }

    // =========================================================================================
    //  Live tracking: enemies/allies -> their run
    // =========================================================================================
    var INST = {};          // defId -> Instance (public raids)
    var RUNS = [];          // every live Instance (public + rift runs)
    var ENEMY = {};         // uuid -> Instance
    var ALLY = {};          // uuid -> Instance
    var DEFENSE = {};       // uuid -> defense stat

    function Instance(defId, fixedDef) {
        this.defId = defId; this.fixed = fixedDef || null; this.silent = !!fixedDef; this.state = "IDLE";
        this.signups = []; this.names = {}; this.loc = {}; this.participants = []; this.eliminated = {};
        this.enemies = {}; this.allies = {}; this.dmg = {}; this.kills = {}; this.stageDeaths = 0;
        this.phaseTimer = 0; this.active = 0; this.rushIndex = 0; this.rushDelay = 0; this.wave = 0; this.parallelBoss = false;
        this.picked = null; this.pickedCache = null; this.signupEnd = 0; this.reminder = 0; this.returnWhenFinished = false;
        this.outcomeSent = false; this.onOutcome = null; this.onStage = null; this.hudMax = 0; this.music = {}; this.musicId = "";
        RUNS.push(this);
    }
    var I = Instance.prototype;

    I.def = function () {
        if (this.fixed) return this.fixed;
        var host = getDef(this.defId);
        if (!host) return null;
        if (!this.picked) return host;
        if (this.pickedCache && this.pickedCache.id === this.picked) return this.pickedCache;
        var pooled = getDef(this.picked);
        if (!pooled) return host;
        var copy = D.normalize(JSON.parse(JSON.stringify(pooled)));
        copy.arena = host.arena; copy.playerSpawn = host.playerSpawn; copy.randomPool = [];
        this.pickedCache = copy;
        return copy;
    };
    I.rollRandomRaid = function () {
        this.picked = null; this.pickedCache = null;
        var host = this.fixed ? null : getDef(this.defId);
        if (!host || !host.randomPool.length) return;
        var pool = host.randomPool.filter(function (id) { return id !== host.id && getDef(id); });
        if (pool.length) this.picked = pool[Math.floor(Math.random() * pool.length)];
    };
    I.isSignedUp = function (u) { return this.signups.indexOf(String(u)) >= 0; };
    I.isParticipant = function (u) { return this.participants.indexOf(String(u)) >= 0; };
    I.started = function () { return this.state === "COUNTDOWN" || this.state === "ACTIVE"; };
    I.sendOutcome = function (won) {
        if (this.outcomeSent) return;
        this.outcomeSent = true;
        if (this.onOutcome) try { this.onOutcome(won); } catch (e) { RPG.log("[Raid] outcome listener: " + e); }
    };
    I.joinCommand = function () { var host = getDef(this.defId), n = host ? strip(host.name) : this.defId; return "/rpgc raid join " + n; };
    I.announceSignupOpen = function (def) { if (!this.silent) announceSignup(fmt(def.msgSignupOpen, def), "§cRaid Sign-ups Open!", def, this.joinCommand()); };
    I.rememberLocation = function (p) { this.loc[p.uuid] = { dim: p.dimension, x: p.x, y: p.y, z: p.z }; };

    I.openSignups = function (minutes) {
        var def = this.def();
        if (!def || this.state !== "IDLE" || !def.arena || def.eventOnly) return false;
        this.rollRandomRaid();
        def = this.def();
        this.signups = []; this.names = {}; this.loc = {};
        this.state = "SIGNUP";
        this.signupEnd = Date.now() + Math.max(1, minutes) * 60000;
        this.reminder = def.signupReminderSeconds > 0 ? def.signupReminderSeconds * 20 : 0;
        this.announceSignupOpen(def);
        return true;
    };
    /** JoinResult: OK CLOSED ALREADY FULL NO_CHARACTER NO_SUCH_RAID */
    I.join = function (p) {
        var def = this.def();
        if (!def) return "NO_SUCH_RAID";
        if (this.state !== "SIGNUP" || def.eventOnly) return "CLOSED";
        if (this.isSignedUp(p.uuid)) return "ALREADY";
        if (def.maxParticipants > 0 && this.signups.length >= def.maxParticipants) return "FULL";
        if (def.requireCharacter && !hasCharacter(p)) return "NO_CHARACTER";
        this.signups.push(String(p.uuid)); this.names[p.uuid] = String(p.name);
        this.rememberLocation(p);
        if (def.maxParticipants > 0 && this.signups.length >= def.maxParticipants) {
            if (!this.silent) broadcast("§a[" + sec(def.name) + "§a] Raid is full, starting now!");
            this.begin(this.signups.slice());
        }
        return "OK";
    };
    I.leave = function (u) { var i = this.signups.indexOf(String(u)); if (i < 0) return false; this.signups.splice(i, 1); return true; };
    I.forceStart = function () { if (this.state !== "SIGNUP") return false; this.begin(this.signups.slice()); return true; };
    /** Raid Soul / rift: skip sign-ups, the initiator plus anyone signed up starts now. */
    I.startImmediate = function (p) {
        var def = this.def();
        if (!def || !def.arena || (this.state !== "IDLE" && this.state !== "SIGNUP") || (def.eventOnly && !this.fixed)) return false;
        var seed = this.signups.slice();
        if (p) { if (seed.indexOf(String(p.uuid)) < 0) seed.push(String(p.uuid)); this.names[p.uuid] = String(p.name); this.rememberLocation(p); }
        this.begin(seed);
        return true;
    };
    I.begin = function (seed) {
        if (!this.picked) this.rollRandomRaid();
        var def = this.def(), self = this;
        this.outcomeSent = false;
        this.participants = seed.map(String).filter(function (u) { return !!player(u); });
        this.eliminated = {};
        if (this.participants.length < Math.max(1, def.minParticipants)) {
            if (!this.silent) broadcast("§c[" + sec(def.name) + "§c] Not enough fighters. Cancelled.");
            this.resetToIdle();
            return;
        }
        this.participants.forEach(function (u) {
            var p = player(u);
            if (!p) return;
            if (!self.loc[u]) self.rememberLocation(p);
            self.teleport(p);
            if (def.healOnStart) fullHeal(p);
        });
        if (!this.silent) announce(fmt(def.msgStarting, def).split("{count}").join(String(this.participants.length)), "§6" + sec(def.name) + "!", def);
        this.dmg = {}; this.kills = {}; this.stageDeaths = 0; this.rushIndex = 0; this.rushDelay = 0; this.wave = 0; this.parallelBoss = false; this.active = 0;
        this.phaseTimer = Math.max(1, def.countdownSeconds) * 20;
        this.state = "COUNTDOWN";
    };
    I.teleport = function (p) {
        var def = this.def();
        if (!def) return;
        var at;
        if (def.playerSpawn) at = safeSpot(def.playerSpawn, null, true), p.teleportTo(def.playerSpawn.dim, at.x, at.y, at.z);
        else if (def.arena) { var b = this.firstLiveEnemyPos(); at = safeSpot(def.arena, b, false); p.teleportTo(def.arena.dim, at.x, at.y, at.z); }
        try { p.setVelocity(0, 0, 0); p.fallDistance = 0; } catch (e) { }
    };
    I.firstLiveEnemyPos = function () {
        for (var u in this.enemies) { var e = entity(u); if (alive(e)) return { x: e.x, y: e.y, z: e.z }; }
        return null;
    };

    // ---- the encounter ----
    I.startEncounter = function () {
        var def = this.def();
        if (!def || !def.arena) { this.resetToIdle(); return; }
        if (def.raidType === "PARALLEL_QUEST") this.spawnParallelWave(def, firstWave(def));
        else if (def.raidType === "BOSS_RUSH") this.spawnRushStage(def, 0);
        else this.spawnStandard(def);
        this.spawnAllies(def, def.allies);
        if (!Object.keys(this.enemies).length) {
            if (!this.silent) broadcast("§c[" + sec(def.name) + "§c] Nothing to fight. Check the raid config. Cancelled.");
            this.resetToIdle();
            return;
        }
        this.state = "ACTIVE";
        this.active = 0;
    };
    I.spawnStandard = function (def) {
        this.stageDeaths = 0;
        var health = scaledHealth(def, this.participants.length);
        var boss = this.createEnemy(def, def.bossEntityType, this.bossSpawnPos(def), health, 0, 0, def.bossScale, 0, def.kiMoves, def.bossName, def.bossModelId);
        if (!boss) return;
        if (def.scaleDamage && this.participants.length > 1) {
            var base = boss.getAttributeBase("generic.attack_damage") || 0;
            boss.setAttributeBase("generic.attack_damage", base + def.damagePerPlayer * (this.participants.length - 1));
        }
        if (!this.silent) announceTo(this.participants, fmt(def.msgBossSpawn, def).split("{health}").join(String(Math.round(health))), "§4" + sec(def.bossName), def, true);
        this.hudMax = 0;
    };
    I.bossSpawnPos = function (def) {
        var c = floorCenter(def.arena);
        if (def.spawnOnObsidian && def.spawnAnchorBlock) {
            var a = findAnchor(def.arena, def.spawnAnchorBlock);
            if (a) return a;
            RPG.log("[Raid] " + strip(def.name) + ": no " + def.spawnAnchorBlock + " found in the arena, spawning the boss at the centre.");
        }
        var y = snapY(def.arena, def.arena.dim, c.x, c.z, false);
        return { x: c.x, y: y === null ? c.y : y, z: c.z };
    };
    I.spawnParallelWave = function (def, wave) {
        var self = this, n = this.participants.length;
        this.stageDeaths = 0;
        this.wave = wave;
        def.enemies.forEach(function (tok) {
            var w = D.wave(tok);
            if (w.wave !== wave) return;
            for (var i = 0; i < w.count; i++) {
                var at = safeSpot(def.arena, null, false);
                self.createEnemy(def, w.entityType, at, w.health, w.meleeDamage, w.kiPower, w.scale, w.defense, [], null, w.rgModelId);
            }
        });
        var waves = waveNumbers(def);
        if (!this.silent) tellTo(this.participants, "§4" + sec(def.name) + " §7: §eWave " + (waves.indexOf(wave) + 1) + "/" + waves.length, true);
        this.hudMax = 0;
        void n;
    };
    I.spawnParallelBoss = function (def) {
        this.parallelBoss = true;
        this.spawnStandard(def);
    };
    I.spawnRushStage = function (def, index) {
        var s = D.stage(def.rushStages[index]);
        if (!s) return;
        this.stageDeaths = 0;
        if (s.swapSides) this.swapSides();
        var health = s.health > 0 ? s.health : scaledHealth(def, this.participants.length);
        this.createEnemy(def, s.entityType, this.bossSpawnPos(def), health, s.meleeDamage, s.kiPower, s.scale, s.defense, s.kiMoves, s.bossName, s.rgModelId);
        this.spawnAllies(def, s.allies);
        if (!this.silent) announceTo(this.participants, null, "§4" + (index + 1) + "/" + def.rushStages.length + " : " + sec(s.bossName), def, false);
        if (this.onStage) try { this.onStage(index + 1, def.rushStages.length, s.bossName); } catch (e) { }
        this.hudMax = 0;
    };
    I.createEnemy = function (def, type, pos, health, melee, ki, scale, defense, kiMoves, name, model) {
        var body = resolveBody(type, model), dim = def.arena.dim, m = null;
        try { m = body.kind === "mob" ? RPG.world.spawnMob(dim, body.id, pos.x, pos.y, pos.z) : RPG.world.spawn(dim, body.id, pos.x, pos.y, pos.z); } catch (e) { m = null; }
        if (!m) { if (!this.silent) broadcast("§c[" + sec(def.name) + "§c] Invalid entity '" + type + "'."); return null; }
        m.addTag("dbr_raid"); m.addTag("dbr_raid_enemy");
        try { m.setDrops(!!def.vanillaDrops); } catch (e) { }
        if (name) { try { m.setCustomName(name); m.setNameVisible(true); } catch (e) { } }
        applyStats(m, def, health, melee || def.baseMeleeDamage, ki || def.kiBlastDamage, kiMoves);
        DEFENSE[m.uuid] = defense > 0 ? defense : def.baseDefense;
        this.enemies[m.uuid] = { last: { x: m.x, y: m.y, z: m.z }, nul: 0 };
        ENEMY[m.uuid] = this;
        RPG.teams.join(m, "dbr_raid_enemy");
        m.setGlowing(true);
        var t = this.nearestParticipant(m);
        if (t) m.target = t;
        return m;
    };
    I.spawnAllies = function (def, tokens) {
        var self = this;
        (tokens || []).forEach(function (tok) {
            var a = D.ally(tok);
            for (var i = 0; i < a.count; i++) {
                var at = safeSpot(def.arena, null, false), body = resolveBody(a.entityType, a.rgModelId), m = null;
                try { m = body.kind === "mob" ? RPG.world.spawnMob(def.arena.dim, body.id, at.x, at.y, at.z) : RPG.world.spawn(def.arena.dim, body.id, at.x, at.y, at.z); } catch (e) { m = null; }
                if (!m) continue;
                m.addTag("dbr_raid");
                try { m.setDrops(false); } catch (e) { }
                if (a.name) { try { m.setCustomName(a.name); m.setNameVisible(true); } catch (e) { } }
                // an ally's own ki loadout, never the boss's (empty = none)
                applyStats(m, def, a.health, a.meleeDamage || def.baseMeleeDamage, a.kiPower || def.kiBlastDamage, a.kiMoves, true);
                DEFENSE[m.uuid] = a.defense > 0 ? a.defense : def.baseDefense;
                self.setSide(m, true);
            }
        });
    };
    /** Move a live entity between the enemy and ally sets (no respawn: health and damage dealt are kept). */
    I.setSide = function (m, ally) {
        var u = m.uuid;
        delete this.enemies[u]; delete this.allies[u]; delete ENEMY[u]; delete ALLY[u];
        if (ally) { this.allies[u] = 1; ALLY[u] = this; m.addTag("dbr_raid_ally"); m.removeTag("dbr_raid_enemy"); RPG.teams.join(m, "dbr_raid_ally"); }
        else { this.enemies[u] = { last: { x: m.x, y: m.y, z: m.z }, nul: 0 }; ENEMY[u] = this; m.removeTag("dbr_raid_ally"); m.addTag("dbr_raid_enemy"); RPG.teams.join(m, "dbr_raid_enemy"); }
        m.setGlowing(true);
        m.target = null;
    };
    I.swapSides = function () {
        var self = this, en = Object.keys(this.enemies), al = Object.keys(this.allies);
        en.forEach(function (u) { var e = entity(u); if (alive(e)) self.setSide(e, true); else { delete self.enemies[u]; delete ENEMY[u]; } });
        al.forEach(function (u) { var e = entity(u); if (alive(e)) self.setSide(e, false); else { delete self.allies[u]; delete ALLY[u]; } });
    };

    function scaledHealth(def, n) {
        var h = def.baseHealth + def.healthPerPlayer * Math.max(0, n - 1);
        if (def.maxHealthCap > 0) h = Math.min(h, def.maxHealthCap);
        return Math.max(1, h);
    }
    function waveNumbers(def) {
        var s = {};
        def.enemies.forEach(function (t) { s[D.wave(t).wave] = 1; });
        return Object.keys(s).map(Number).sort(function (a, b) { return a - b; });
    }
    function firstWave(def) { var w = waveNumbers(def); return w.length ? w[0] : 1; }
    /** The nearest anchor block to the arena centre (bounded scan). */
    function findAnchor(r, block) {
        var c = floorCenter(r), want = block.indexOf(":") < 0 ? "minecraft:" + block : block, budget = 24000;
        var maxR = Math.min(48, Math.max(r.x2 - r.x1, r.z2 - r.z1)), y0 = r.y1, y1 = Math.min(r.y2 + 1, r.y1 + 48);
        for (var rad = 0; rad <= maxR; rad++) {
            for (var dx = -rad; dx <= rad; dx++) for (var dz = -rad; dz <= rad; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) !== rad) continue;
                var x = Math.floor(c.x) + dx, z = Math.floor(c.z) + dz;
                if (!inRegion(r, r.dim, x + 0.5, z + 0.5, 0)) continue;
                for (var y = y0; y <= y1; y++) {
                    if (--budget <= 0) return null;
                    if (RPG.world.getBlock(r.dim, x, y, z) === want) return { x: x + 0.5, y: y + 1, z: z + 0.5 };
                }
            }
        }
        return null;
    }
    var AI_TIER = { 1: 1, 2: 2, 3: 3 };
    /** applyConfiguredStats / applyDmzStats: 0 keeps the entity's own value. */
    function applyStats(m, def, health, melee, ki, kiMoves, isAlly) {
        if (health > 0) { m.maxHealth = health; m.health = health; }
        if (melee > 0) m.setAttributeBase("generic.attack_damage", melee);
        if (def.moveSpeed > 0) m.setAttributeBase("generic.movement_speed", def.moveSpeed);
        if (typeof DMZ_SAGA !== "undefined" && DMZ_SAGA.dmzId(m)) {
            var base = typeof dmzSagaBase === "function" ? dmzSagaBase(DMZ_SAGA.dmzId(m)) : null;
            DMZ_SAGA.setup(m, { hp: health > 0 ? health : 0, melee: melee > 0 ? melee : 0, ki: ki > 0 ? ki : (base ? base[2] : 20),
                tier: AI_TIER[def.aiTier] || 2, noTransform: !def.useDefaultTransform, diff: { hp: 1, dmg: 1 } });
            if ((kiMoves && kiMoves.length) || isAlly) setKiMoves(m, kiMoves || []);
        }
    }
    function setKiMoves(m, tokens) {
        var b = DMZ_SAGA.brainOf(m);
        if (!b) return;
        var t = now();
        b.skills = tokens.map(function (tk) {
            var k = D.ki(tk), n = D.KI_TYPES.indexOf(k.type) + 1, d = n > 0 ? DMZ_SAGA.SK[n] : null;
            if (!d) return null;
            return { type: n, def: d, cd: Math.max(10, k.cooldown), size: k.size || 1,
                c: [(d.c && d.c[0]) || "#FFFFFF", (d.c && d.c[1]) || "#FFD24A", (d.c && d.c[2]) || null], ready: t + 80 };
        }).filter(function (x) { return x; });
    }

    // ---- targeting ----
    I.activeFighters = function () {
        var self = this, def = this.def(), out = [];
        this.participants.forEach(function (u) {
            if (self.eliminated[u]) return;
            var p = player(u);
            if (p && p.isAlive() && (!def || inArena(def.arena, p, 0))) out.push(p);
        });
        return out;
    };
    function nearest(from, list) {
        var best = null, bd = 1e18;
        list.forEach(function (e) { var d = from.distanceTo(e); if (d < bd) { bd = d; best = e; } });
        return best;
    }
    I.nearestParticipant = function (from) { return nearest(from, this.activeFighters()); };
    I.liveList = function (set) { var out = []; for (var u in set) { var e = entity(u); if (alive(e)) out.push(e); } return out; };
    I.tickFocus = function (def) {
        var fighters = this.activeFighters(), allies = this.liveList(this.allies), enemies = this.liveList(this.enemies);
        enemies.forEach(function (e) {
            var t = e.target;
            if (t && alive(t) && (t.isPlayer() ? fighters.some(function (f) { return String(f.uuid) === String(t.uuid); }) : !!ALLY[t.uuid])) return;
            var pick = nearest(e, fighters.concat(allies));
            e.target = pick;
        });
        allies.forEach(function (a) {
            var t = a.target;
            if (t && alive(t) && ENEMY[t.uuid]) return;
            a.target = nearest(a, enemies);
        });
        void def;
    };
    I.confine = function (def) {
        var self = this;
        this.liveList(this.enemies).concat(this.liveList(this.allies)).forEach(function (e) {
            if (inArena(def.arena, e, -CONFINE_MARGIN)) return;
            var c = clampInside(def.arena, e.x, e.z, CONFINE_MARGIN);
            if (e.dimension !== def.arena.dim) e.teleportTo(def.arena.dim, c.x, e.y, c.z); else e.teleport(c.x, e.y, c.z);
            e.setVelocity(0, 0, 0);
            if (e.target && !inArena(def.arena, e.target, 0)) e.target = ENEMY[e.uuid] ? self.nearestParticipant(e) : null;
        });
    };
    I.confineParticipants = function (def) {
        var self = this;
        this.participants.forEach(function (u) {
            if (self.eliminated[u]) return;
            var p = player(u);
            if (!p || !p.isAlive() || inArena(def.arena, p, 0)) return;
            var g = String(p.getGameMode());
            if (g === "spectator" || g === "creative") return;
            var c = clampInside(def.arena, p.x, p.z, 2), y = snapY(def.arena, def.arena.dim, c.x, c.z, false);
            p.teleportTo(def.arena.dim, c.x, y === null ? Math.max(p.y, def.arena.y1 + 1) : y, c.z);
            p.tell("§ePulled back into the arena.");
        });
    };
    /** enforceEliminatedLockout: eliminated fighters (and, with preventReentry, anyone else) are bounced out. */
    I.lockout = function (def) {
        var self = this;
        RPG.server.players().forEach(function (p) {
            if (!inArena(def.arena, p, 0)) return;
            var g = String(p.getGameMode());
            if (g === "spectator" || g === "creative") return;
            var u = p.uuid, out = self.eliminated[u] || (def.preventReentry && !self.isParticipant(u));
            if (out) self.bounceOut(p);
        });
    };
    I.bounceOut = function (p) {
        if (!this.returnToStart(p)) { var s = RPG.world.spawnPoint(); p.teleportTo("minecraft:overworld", s.x + 0.5, s.y, s.z + 0.5); }
    };
    I.returnToStart = function (p) {
        var l = this.loc[p.uuid];
        if (!l) return false;
        p.teleportTo(l.dim, l.x, l.y, l.z);
        try { p.setVelocity(0, 0, 0); p.fallDistance = 0; } catch (e) { }
        return true;
    };
    I.returnAll = function () {
        var self = this;
        this.participants.forEach(function (u) { var p = player(u); if (p && (!self.def() || inArena(self.def().arena, p, 4) || (self.def().playerSpawn && inArena(self.def().playerSpawn, p, 4)))) self.returnToStart(p); });
    };

    // ---- HUD + music ----
    I.updateHud = function () {
        var def = this.def(), list = this.liveList(this.enemies);
        if (!def) return;
        var data;
        var bossFight = list.length === 1 && (def.raidType !== "PARALLEL_QUEST" || this.parallelBoss);
        if (bossFight) {
            var b = list[0];
            data = { active: true, mode: 1, label: b.getCustomName ? (b.customName || b.name) : b.name, cur: b.health, max: b.maxHealth };
        } else {
            var n = Object.keys(this.enemies).length;
            if (n > this.hudMax) this.hudMax = n;
            var label = sec(def.name);
            if (def.raidType === "PARALLEL_QUEST") { var ws = waveNumbers(def); label += " : Wave " + (ws.indexOf(this.wave) + 1) + "/" + ws.length; }
            data = { active: true, mode: 0, label: label, cur: n, max: Math.max(1, this.hudMax) };
        }
        var self = this;
        this.participants.forEach(function (u) { var p = player(u); if (p) RPG.net.send(p, "dbr_raid_hud", self.eliminated[u] ? { active: false } : data); });
    };
    I.clearHud = function () {
        this.participants.forEach(function (u) { var p = player(u); if (p) RPG.net.send(p, "dbr_raid_hud", { active: false }); });
    };
    I.reconcileMusic = function () {
        var def = this.def(), id = def ? def.bossMusic : "", self = this;
        if (!id) { this.stopMusic(); return; }
        this.participants.forEach(function (u) {
            var p = player(u), want = !!p && p.isAlive() && !self.eliminated[u] && (inArena(def.arena, p, 4) || (def.playerSpawn && inArena(def.playerSpawn, p, 4)));
            if (want && self.music[u] !== id) { self.music[u] = id; RPG.net.send(p, "dbr_raid_music", { id: id }); }
            else if (!want && self.music[u]) { delete self.music[u]; if (p) RPG.net.send(p, "dbr_raid_music", { id: "" }); }
        });
    };
    I.stopMusic = function () {
        for (var u in this.music) { var p = player(u); if (p) RPG.net.send(p, "dbr_raid_music", { id: "" }); }
        this.music = {};
    };

    // ---- the state machine ----
    I.tick = function () {
        var def;
        if (this.state === "SIGNUP") {
            if (Date.now() >= this.signupEnd) this.begin(this.signups.slice());
            else if (this.reminder > 0 && (this.reminder -= STEP) <= 0) {
                def = this.def();
                if (def) { this.announceSignupOpen(def); this.reminder = def.signupReminderSeconds > 0 ? def.signupReminderSeconds * 20 : 0; }
            }
        } else if (this.state === "COUNTDOWN") {
            this.reconcileMusic();
            if (this.phaseTimer % 20 === 0 && this.phaseTimer > 0) tellTo(this.participants, "§e" + (this.phaseTimer / 20) + "...", !this.silent);
            if ((this.phaseTimer -= STEP) <= 0) this.startEncounter();
        } else if (this.state === "ACTIVE") {
            this.reconcileMusic();
            this.tickActive();
        } else if (this.state === "FINISHED") {
            if ((this.phaseTimer -= STEP) <= 0) {
                if (this.returnWhenFinished) this.returnAll();
                this.resetToIdle();
            }
        }
    };
    I.tickActive = function () {
        var def = this.def(), self = this;
        if (!def || !def.arena) { this.cancel(); return; }
        this.active += STEP;
        if (this.rushDelay > 0) {
            if (this.rushDelay % 20 === 0 && !this.silent) tellTo(this.participants, "§eNext boss in §c" + fmtDur(this.rushDelay / 20) + "§e...", false);
            if ((this.rushDelay -= STEP) <= 0) this.spawnRushStage(def, this.rushIndex);
            return;
        }
        // prune: a resolvable dead enemy is a real death; an unresolvable one gets a grace window (unloaded chunk),
        // unless it took a lethal hit just before vanishing (then it died)
        var graceFailure = false, tk = now();
        Object.keys(this.enemies).forEach(function (u) {
            var rec = self.enemies[u], e = entity(u);
            if (e && e.isAlive()) { rec.nul = 0; rec.last = { x: e.x, y: e.y, z: e.z }; return; }
            if (e || (rec.lethalAt && tk - rec.lethalAt < 60)) { self.enemyGone(u, true); return; }
            rec.nul += STEP;
            if (rec.nul >= NULL_GRACE) { self.enemyGone(u, false); graceFailure = true; }
        });
        Object.keys(this.allies).forEach(function (u) { if (!alive(entity(u))) { delete self.allies[u]; delete ALLY[u]; delete DEFENSE[u]; } });
        if (this.tryResolveClearedStage(def)) return;
        if (graceFailure && !Object.keys(this.enemies).length) { this.wipe(); return; }
        this.confine(def);
        this.tickFocus(def);
        if (this.active % 10 === 0) { this.updateHud(); this.lockout(def); this.confineParticipants(def); }
        if (Object.keys(this.enemies).length && this.allEliminated()) { this.wipe(); return; }
        if (def.fightTimeLimit > 0 && this.active >= def.fightTimeLimit * 20) this.timeout();
    };
    I.enemyGone = function (u, died) {
        var e = entity(u);
        if (e) { try { e.setGlowing(false); } catch (x) { } }
        delete this.enemies[u]; delete ENEMY[u]; delete DEFENSE[u];
        if (died) this.stageDeaths++;
    };
    I.tryResolveClearedStage = function (def) {
        if (Object.keys(this.enemies).length || this.stageDeaths <= 0) return false;
        if (def.raidType === "BOSS_RUSH" && this.rushIndex + 1 < def.rushStages.length) this.advanceRush(def);
        else if (def.raidType === "PARALLEL_QUEST" && this.nextParallelStep(def)) return true;
        else this.resolveVictory(def);
        return true;
    };
    I.nextParallelStep = function (def) {
        var waves = waveNumbers(def), at = waves.indexOf(this.wave);
        if (at >= 0 && at + 1 < waves.length) {
            if (!this.silent) tellTo(this.participants, "§e[" + sec(def.name) + "§e] Wave " + (at + 2) + "/" + waves.length + " incoming!", true);
            this.spawnParallelWave(def, waves[at + 1]);
            return Object.keys(this.enemies).length > 0;
        }
        if (def.parallelBoss && !this.parallelBoss) {
            if (!this.silent) tellTo(this.participants, "§4[" + sec(def.name) + "§4] The boss has appeared!", true);
            this.spawnParallelBoss(def);
            return Object.keys(this.enemies).length > 0;
        }
        return false;
    };
    I.advanceRush = function (def) {
        this.rushIndex++;
        var next = D.stage(def.rushStages[this.rushIndex]);
        this.rushDelay = Math.max(0, next.delaySeconds) * 20;
        if (this.rushDelay === 0) this.spawnRushStage(def, this.rushIndex);
    };
    I.allEliminated = function () {
        var self = this;
        return this.participants.length > 0 && this.participants.every(function (u) { return self.eliminated[u] || !player(u); });
    };
    I.resolveVictory = function (def) {
        var self = this, dmg = this.dmg, total = 0, everyone = {};
        Object.keys(dmg).forEach(function (u) { total += dmg[u]; everyone[u] = 1; });
        Object.keys(this.kills).forEach(function (u) { everyone[u] = 1; });
        var mvp = def.raidType === "PARALLEL_QUEST";
        function score(u) { return (dmg[u] || 0) + (mvp ? def.mvpKillWeight * (self.kills[u] || 0) : 0); }
        var ranked = Object.keys(everyone).sort(function (a, b) { return score(b) - score(a); });
        var topName = ranked.length ? (this.names[ranked[0]] || nameOf(ranked[0])) : "nobody";
        var topDmg = ranked.length ? dmg[ranked[0]] || 0 : 0, topPct = total > 0 ? topDmg / total * 100 : 0, topKills = ranked.length ? this.kills[ranked[0]] || 0 : 0;
        ranked.forEach(function (u, i) {
            var p = player(u);
            if (!p) return;
            var d = dmg[u] || 0, ph = { "%damage%": String(Math.round(d)), "%damage_percent%": fmtPercent(total > 0 ? d / total * 100 : 0), "%kills%": String(self.kills[u] || 0),
                "%rank%": String(i + 1), "%boss%": def.bossName, "%total_damage%": String(Math.round(total)) };
            giveAll(p, def.participantRewards, ph);
            if (i === 0) giveAll(p, def.topRewards, ph);
            else if (i <= 3) giveAll(p, def.runnerUpRewards, ph);
        });
        var victory = fmt(def.msgVictory, def).split("{top}").join(topName).split("{top_percent}").join(fmtPercent(topPct))
            .split("{mvp}").join(topName).split("{kills}").join(String(topKills));
        if (!this.silent) announceTo(this.participants, victory, mvp ? "§6MVP: " + topName : "§6Victory!", def, true);
        this.ranking = ranked.map(function (u) { return { name: self.names[u] || nameOf(u), dmg: dmg[u] || 0, kills: self.kills[u] || 0 }; });
        this.returnWhenFinished = true;
        this.cleanupEnemies();
        this.phaseTimer = VICTORY_HOLD;
        this.state = "FINISHED";
        this.sendOutcome(true);
    };
    function nameOf(u) { var p = player(u); return p ? p.name : "?"; }
    I.timeout = function () {
        var def = this.def();
        if (!this.silent) announceTo(this.participants, fmt(def.msgTimeout, def), "§cRaid Failed", def, true);
        this.endFailed();
    };
    I.wipe = function () {
        var def = this.def();
        if (!this.silent) announceTo(this.participants, def ? fmt(def.msgTimeout, def) : "The raid has failed.", "§cRaid Failed", def, true);
        this.endFailed();
    };
    I.endFailed = function () {
        this.returnAll();
        this.cleanupEnemies();
        this.phaseTimer = 5 * 20;
        this.state = "FINISHED";
        this.sendOutcome(false);
    };
    I.cancel = function (byAdmin) {
        if (this.state === "IDLE") return;
        var def = this.def();
        if (byAdmin && !this.silent) broadcast("§c[" + sec(def ? def.name : this.defId) + "§c] Raid cancelled by an administrator.");
        this.returnAll();
        this.cleanupEnemies();
        this.sendOutcome(false);
        this.resetToIdle();
    };
    I.abandon = function () { this.cancel(false); };
    I.cleanupEnemies = function () {
        var self = this;
        Object.keys(this.enemies).concat(Object.keys(this.allies)).forEach(function (u) {
            var e = entity(u);
            if (e) { try { RPG.teams.leave(e); } catch (x) { } try { e.remove(); } catch (x) { } }
            delete ENEMY[u]; delete ALLY[u]; delete DEFENSE[u];
        });
        this.enemies = {}; this.allies = {};
        this.clearHud();
        this.stopMusic();
        void self;
    };
    I.resetToIdle = function () {
        this.sendOutcome(false);
        this.cleanupEnemies();
        this.state = "IDLE"; this.picked = null; this.pickedCache = null;
        this.signups = []; this.loc = {}; this.participants = []; this.eliminated = {}; this.dmg = {}; this.kills = {};
        this.stageDeaths = 0; this.active = 0; this.rushIndex = 0; this.rushDelay = 0; this.returnWhenFinished = false;
        if (this.fixed) this.dispose();
    };
    I.dispose = function () { var i = RUNS.indexOf(this); if (i >= 0) RUNS.splice(i, 1); };
    /** death-save: a lethal raid hit sends the fighter back where they signed up, healed, out for this raid. */
    I.rescueFromLethal = function (p) {
        if (this.state !== "ACTIVE" || !this.isParticipant(p.uuid) || this.eliminated[p.uuid]) return false;
        if (!this.returnToStart(p)) return false;
        fullHeal(p);
        this.eliminated[p.uuid] = true;
        this.release(p);
        return true;
    };
    I.onParticipantDeath = function (p) {
        if (this.state === "ACTIVE" && this.isParticipant(p.uuid)) { this.eliminated[p.uuid] = true; this.release(p); }
    };
    I.release = function (p) {
        RPG.net.send(p, "dbr_raid_hud", { active: false });
        if (this.music[p.uuid]) { delete this.music[p.uuid]; RPG.net.send(p, "dbr_raid_music", { id: "" }); }
        var u = String(p.uuid);
        this.liveList(this.enemies).forEach(function (e) { if (e.target && String(e.target.uuid) === u) e.target = null; });
    };
    I.stateLabel = function () {
        return { IDLE: "No raid running", SIGNUP: "Sign-ups are OPEN", COUNTDOWN: "Raid starting", ACTIVE: "Boss fight in progress", FINISHED: "Raid finished" }[this.state];
    };
    I.status = function () {
        var def = this.def(), n = def ? sec(def.name) : this.defId;
        if (this.state === "SIGNUP") return "§6[Raid] §f" + n + " §7- §aSign-ups open §7(" + this.signups.length + " signed up, " + Math.max(0, Math.ceil((this.signupEnd - Date.now()) / 1000)) + "s left)";
        if (this.state === "COUNTDOWN") return "§6[Raid] §f" + n + " §7- §eStarting in " + Math.ceil(this.phaseTimer / 20) + "s";
        if (this.state === "ACTIVE") return "§6[Raid] §f" + n + " §7- §cIn progress §7(" + this.activeFighters().length + "/" + this.participants.length + " fighters, " + Object.keys(this.enemies).length + " enemies, " + fmtDur(this.active / 20) + ")";
        if (this.state === "FINISHED") return "§6[Raid] §f" + n + " §7- §7Finishing";
        var next = nextRunMillis(def);
        return "§6[Raid] §f" + n + " §7- Idle" + (next > 0 ? " §7(next sign-ups " + new Date(next).toLocaleString() + ")" : "");
    };

    function instance(id) {
        id = String(id || "").toLowerCase();
        if (!getDef(id)) return null;
        if (!INST[id]) INST[id] = new Instance(id, null);
        return INST[id];
    }
    function runOfPlayer(u) {
        for (var i = 0; i < RUNS.length; i++) { var r = RUNS[i]; if (r.started() && r.isParticipant(u) && !r.eliminated[u]) return r; }
        return null;
    }

    // ---- manager tick ----
    RPG.every(STEP, function () {
        RUNS.slice().forEach(function (r) {
            try { r.tick(); } catch (e) { RPG.log("[Raid] " + r.defId + ": " + e); }
        });
        Object.keys(INST).forEach(function (id) { if (!getDef(id) && INST[id].state === "IDLE") { INST[id].dispose(); delete INST[id]; } });
    });
    RPG.every(20, function () {
        Object.keys(defs()).forEach(function (id) { try { tickSchedule(id); } catch (e) { RPG.log("[Raid] schedule " + id + ": " + e); } });
        lookAtPlayers();
    });
    // leftovers from a restart mid-fight (a run never survives one)
    RPG.schedule(40, function () {
        RPG.server.players().forEach(function (p) {
            RPG.world.entitiesNear(p.dimension, p.x, p.y, p.z, 96).forEach(function (e) { if (e.hasTag("dbr_raid") && !ENEMY[e.uuid] && !ALLY[e.uuid]) e.remove(); });
        });
    });

    // =========================================================================================
    //  Scheduler
    // =========================================================================================
    function parseHhMm(s) {
        var m = /^\s*(\d{1,2})\s*:\s*(\d{1,2})\s*$/.exec(String(s || ""));
        if (!m) return null;
        var h = Number(m[1]), mi = Number(m[2]);
        return h >= 0 && h <= 23 && mi >= 0 && mi <= 59 ? [h, mi] : null;
    }
    function dayOfWeek(d) { var w = d.getDay(); return w === 0 ? 7 : w; }           // 1=Monday .. 7=Sunday
    function daysIn(y, m) { return new Date(y, m + 1, 0).getDate(); }
    function at(d, h, m) { return new Date(d.getFullYear(), d.getMonth(), d.getDate(), h, m, 0, 0); }
    function addDays(d, n) { return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n, d.getHours(), d.getMinutes(), 0, 0); }
    function mostRecentTimeSlot(nowD, def, h, m) {
        if (def.scheduleDayOfMonth > 0) {
            var dom = Math.min(def.scheduleDayOfMonth, daysIn(nowD.getFullYear(), nowD.getMonth()));
            var s = new Date(nowD.getFullYear(), nowD.getMonth(), dom, h, m);
            if (s > nowD) { var py = nowD.getMonth() === 0 ? nowD.getFullYear() - 1 : nowD.getFullYear(), pm = (nowD.getMonth() + 11) % 12; s = new Date(py, pm, Math.min(def.scheduleDayOfMonth, daysIn(py, pm)), h, m); }
            return s;
        }
        if (def.scheduleDayOfWeek > 0) {
            var d = at(nowD, h, m), target = Math.min(7, def.scheduleDayOfWeek);
            while (dayOfWeek(d) !== target) d = addDays(d, -1);
            if (d > nowD) d = addDays(d, -7);
            return d;
        }
        var today = at(nowD, h, m);
        return nowD < today ? addDays(today, -1) : today;
    }
    function mostRecentCadenceDay(nowD, def) {
        var d = at(nowD, 0, 0), i;
        if (def.scheduleDayOfMonth > 0) { for (i = 0; i < 62; i++) { if (Math.min(def.scheduleDayOfMonth, daysIn(d.getFullYear(), d.getMonth())) === d.getDate()) return d; d = addDays(d, -1); } return null; }
        if (def.scheduleDayOfWeek > 0) { while (dayOfWeek(d) !== Math.min(7, def.scheduleDayOfWeek)) d = addDays(d, -1); return d; }
        return d;
    }
    function mostRecentSlot(nowD, def) {
        var best = null;
        function later(s) { if (s && (!best || s > best)) best = s; }
        if (def.scheduleTimes.length) def.scheduleTimes.forEach(function (t) { var hm = parseHhMm(t); if (hm) later(mostRecentTimeSlot(nowD, def, hm[0], hm[1])); });
        else later(mostRecentTimeSlot(nowD, def, RPG.clamp(def.scheduleHour, 0, 23), RPG.clamp(def.scheduleMinute, 0, 59)));
        if (def.scheduleIntervalMinutes > 0) {
            var day = mostRecentCadenceDay(nowD, def), iv = Math.max(1, def.scheduleIntervalMinutes);
            if (day) {
                var limit = day.getTime() === at(nowD, 0, 0).getTime() ? nowD.getHours() * 60 + nowD.getMinutes() : 23 * 60 + 59;
                later(new Date(day.getTime() + Math.floor(limit / iv) * iv * 60000));
            }
        }
        return best;
    }
    function nextRunMillis(def) {
        if (!def || !def.scheduleEnabled) return -1;
        var nowD = new Date(), h = RPG.clamp(def.scheduleHour, 0, 23), m = RPG.clamp(def.scheduleMinute, 0, 59), s;
        if (def.scheduleDayOfMonth > 0) {
            s = new Date(nowD.getFullYear(), nowD.getMonth(), Math.min(def.scheduleDayOfMonth, daysIn(nowD.getFullYear(), nowD.getMonth())), h, m);
            if (s <= nowD) { var ny = nowD.getMonth() === 11 ? nowD.getFullYear() + 1 : nowD.getFullYear(), nm = (nowD.getMonth() + 1) % 12; s = new Date(ny, nm, Math.min(def.scheduleDayOfMonth, daysIn(ny, nm)), h, m); }
        } else if (def.scheduleDayOfWeek > 0) {
            s = at(nowD, h, m);
            while (dayOfWeek(s) !== Math.min(7, def.scheduleDayOfWeek)) s = addDays(s, 1);
            if (s <= nowD) s = addDays(s, 7);
        } else { s = at(nowD, h, m); if (s <= nowD) s = addDays(s, 1); }
        return s.getTime();
    }
    function tickSchedule(id) {
        var def = getDef(id);
        if (!def || !def.scheduleEnabled || def.eventOnly) return;
        var slot = mostRecentSlot(new Date(), def);
        if (!slot) return;
        var ms = slot.getTime(), window = def.scheduleIntervalMinutes > 0 ? Math.min(12 * 3600000, def.scheduleIntervalMinutes * 60000) : 12 * 3600000;
        if (ms > lastRun(id) && Date.now() - ms <= window) {
            var inst = instance(id);
            if (inst && inst.state === "IDLE" && inst.openSignups(def.signupMinutes)) setLastRun(id, ms);
            else if (inst && inst.state !== "IDLE") setLastRun(id, ms);
        }
    }

    // =========================================================================================
    //  Combat hooks (ForgeEventHandler)
    // =========================================================================================
    RPG.on("damageFinal", function (e) {
        if (e.isCancelled()) return;
        var t = e.target, a = e.attacker;
        if (!t) return;
        if (t.isPlayer()) {
            if (a && ALLY[a.uuid]) { e.cancel(); return; }
            if (a && a.isPlayer() && a.uuid !== t.uuid) {
                var ds = defs();
                for (var k in ds) if (!ds[k].pvpInArena && inArena(ds[k].arena, t, 0)) { e.cancel(); return; }
                for (var i = 0; i < RUNS.length; i++) { var fd = RUNS[i].fixed; if (fd && !fd.pvpInArena && RUNS[i].started() && inArena(fd.arena, t, 0)) { e.cancel(); return; } }
            }
            return;
        }
        if (ALLY[t.uuid]) { if (a && (a.isPlayer() || ALLY[a.uuid])) e.cancel(); return; }
        var run = ENEMY[t.uuid];
        if (!run) return;
        if (a && ENEMY[a.uuid]) { e.cancel(); return; }
        var def = run.def();
        var dfn = DEFENSE[t.uuid] || 0;
        if (dfn > 0) e.amount = e.amount * (1 - Math.min(0.88, dfn / (dfn + 100)));
        if (def && def.maxDamagePercentPerHit > 0) e.amount = Math.min(e.amount, Math.max(1e-6, t.maxHealth * def.maxDamagePercentPerHit / 100));
        if (a && a.isPlayer() && run.isParticipant(a.uuid)) {
            if (run.eliminated[a.uuid]) { e.cancel(); return; }
            run.dmg[a.uuid] = (run.dmg[a.uuid] || 0) + Math.min(e.amount, t.health);
        }
    });
    RPG.on("lethal", function (e) {
        if (e.isCancelled()) return;
        var t = e.target, a = e.attacker;
        if (!t) return;
        if (t.isPlayer()) {
            var run = a ? ENEMY[a.uuid] : null;
            if (run && run.rescueFromLethal(t.asPlayer())) e.cancel();
            return;
        }
        var r = ENEMY[t.uuid];
        if (r && r.enemies[t.uuid]) r.enemies[t.uuid].lethalAt = now();
    });
    RPG.on("kill", function (p, victim) {
        var r = victim ? ENEMY[victim.uuid] : null;
        if (r && r.isParticipant(p.uuid)) r.kills[p.uuid] = (r.kills[p.uuid] || 0) + 1;
        if (r && r.enemies[victim.uuid]) r.enemies[victim.uuid].lethalAt = now();
    });
    RPG.on("death", function (p) {
        RUNS.slice().forEach(function (r) { r.onParticipantDeath(p); });
    });
    RPG.on("playerLeave", function (p) {
        RUNS.slice().forEach(function (r) {
            if (r.state === "SIGNUP") r.leave(p.uuid);
            if (r.music[p.uuid]) delete r.music[p.uuid];
        });
    });

    // =========================================================================================
    //  Sign-up hosts (RaidNpcs) and the Raid Soul (RaidSoulItem)
    // =========================================================================================
    RPG.items.define("raid_soul", { name: "&dRaid Soul", model: "dbr:rpg/item/raids/raid_soul", rarity: "epic", maxStack: 16, type: "material",
        lore: ["&7Right-click a raid host to start", "&7its raid at once, no sign-ups."] });
    function hosts() { return RPG.data.get("dbr_raid_hosts", {}) || {}; }
    function saveHosts(h) { RPG.data.set("dbr_raid_hosts", h); }
    function hostBody(def) {
        var t = def.npcEntityType || "dmz_ragnarok:raid_npc";
        if (def.npcModelId && typeof rgNpcId === "function" && RPG.npcs.exists(rgNpcId(def.npcModelId))) return { kind: "npc", id: rgNpcId(def.npcModelId) };
        if (t.indexOf("rgnpc#") === 0 && typeof rgNpcId === "function") return { kind: "npc", id: rgNpcId(t.substring(6)) };
        if (t === "dmz_ragnarok:raid_npc" || !t) return { kind: "npc", id: "dbr_raid_master" };
        if (RPG.npcs.exists(t)) return { kind: "npc", id: t };
        var b = resolveBody(t, "");
        return b.kind === "mob" ? b : { kind: "entity", id: b.id };
    }
    function makeHost(e, def) {
        e.addTag("dbr_raid_host");
        e.addTag("dbr_raid_host:" + def.id);
        try { e.setCustomName(def.npcName || CFG.get("npc.name")); e.setNameVisible(true); } catch (x) { }
        if (!e.rpgId || !RPG.npcs.exists(e.rpgId)) { e.setAI(false); e.invulnerable = true; e.setImmovable(true); try { e.setDrops(false); } catch (x) { } }
        var h = hosts();
        h[e.uuid] = { raid: def.id, dim: e.dimension, x: e.x, y: e.y, z: e.z };
        saveHosts(h);
    }
    function hostRaid(e) {
        if (!e || !e.hasTag("dbr_raid_host")) return null;
        var h = hosts()[e.uuid];
        return h ? h.raid : "";
    }
    function lookAtPlayers() {
        var r = CFG.get("npc.lookRadius");
        if (!(r > 0)) return;
        var h = hosts();
        Object.keys(h).forEach(function (u) {
            var e = entity(u);
            if (!alive(e)) return;
            var best = null, bd = r;
            RPG.server.players().forEach(function (p) { if (p.dimension !== e.dimension) return; var d = p.distanceTo(e); if (d <= bd) { bd = d; best = p; } });
            if (best) e.lookAt(best.x, best.eyeY, best.z);
        });
    }
    RPG.on("entityInteract", function (p, e) {
        if (!e || hostRaid(e) === null) return;
        var held = p.getHeldStack(), soul = held && held.data && held.data.raid ? String(held.data.raid) : null;
        if (soul) useSoul(p, soul, held);
        else openBrowser(p);
        return false;
    });
    RPG.on("npcInteract", function (p, npc) { if (npc && npc.hasTag("dbr_raid_host")) return false; });
    function useSoul(p, raidId, held) {
        var def = getDef(raidId);
        if (!def) { p.tell("§cThis Raid Soul points to a raid that no longer exists."); return; }
        var inst = instance(def.id);
        if (inst && inst.startImmediate(p)) {
            held.count = held.count - 1;
            p.setHeldStack(held.count > 0 ? held : null);
            p.tell("§6[Raid] §fThe soul ignites, §e" + sec(def.name) + " §fbegins!");
        } else p.tell("§c" + sec(def.name) + "§c can't start right now (already running, or no arena set).");
    }
    function giveSoul(p, def) {
        p.giveStack({ id: RPG.items.id("raid_soul"), count: 1, name: "&dRaid Soul: &f" + def.name, data: { raid: def.id },
            lore: ["&7Raid: &f" + def.name, "&7Right-click a raid host to start it now."] });
    }

    // =========================================================================================
    //  Screens (OpenBrowser / OpenSignup / OpenHub / OpenEditor / Save / Delete / SetBounds packets)
    // =========================================================================================
    function stateIndex(s) { return D.STATES.indexOf(s); }
    function openBrowser(p) {
        var entries = [];
        Object.keys(defs()).forEach(function (id) {
            var d = defs()[id];
            if (!d.showInNpcMenu || d.eventOnly) return;
            var inst = INST[id];
            entries.push({ id: id, name: d.name, category: d.category, type: d.raidType, state: inst ? stateIndex(inst.state) : 0 });
        });
        RPG.net.send(p, "dbr_raid_open_browser", { entries: entries });
    }
    function openSignup(p, id) {
        var def = getDef(id);
        if (!def) return;
        var inst = instance(id), party = 0;
        try { if (typeof DMZ_PARTY !== "undefined" && DMZ_PARTY.isLeader(p)) party = DMZ_PARTY.members(p).length; } catch (e) { }
        RPG.net.send(p, "dbr_raid_open_signup", { id: id, name: (inst.def() || def).name, open: inst.state === "SIGNUP", signedUp: inst.isSignedUp(p.uuid),
            count: inst.signups.length, state: stateIndex(inst.state), party: party });
    }
    function listRows() {
        return Object.keys(defs()).sort().map(function (id) {
            var d = defs()[id], inst = INST[id];
            return { id: id, name: d.name, type: d.raidType, ready: !!d.arena, state: inst ? stateIndex(inst.state) : 0, signups: inst ? inst.signups.length : 0 };
        });
    }
    function sendList(p) { RPG.net.send(p, "dbr_raid_open_list", { rows: listRows() }); }
    function pickId(base) {
        var id = String(base || "raid").toLowerCase().replace(/[^a-z0-9_]+/g, "_").replace(/^_+|_+$/g, "") || "raid", n = id, i = 2;
        while (getDef(n)) n = id + "_" + (i++);
        return n;
    }
    RPG.net.on("dbr_raid_req", function (p, d) {
        d = d || {};
        var what = String(d.what || ""), id = d.id ? String(d.id) : "";
        if (what === "browser") return openBrowser(p);
        if (what === "signup") return openSignup(p, id);
        if (!can(p, "rg.raid.edit")) { msgTo(p, "You can't edit raids.", "#FF5555"); return; }
        if (what === "hub") return RPG.net.send(p, "dbr_raid_open_hub", {});
        if (what === "list") return sendList(p);
        if (what === "new") { var nd = putDef(createDefault(pickId(d.name || "raid"), d.name || "New Raid")); return RPG.net.send(p, "dbr_raid_open_editor", { def: nd, pool: poolChoices() }); }
        if (what === "copy") {
            var src = getDef(id);
            if (!src) return;
            var cp = JSON.parse(JSON.stringify(src));
            cp.id = pickId(src.id + "_copy"); cp.name = src.name + " (copy)";
            putDef(cp);
            return sendList(p);
        }
        if (what === "edit") { var ed = getDef(id); if (ed) RPG.net.send(p, "dbr_raid_open_editor", { def: ed, pool: poolChoices() }); return; }
        if (what === "delete") { var di = INST[id]; if (di) di.cancel(true); removeDef(id); msgTo(p, "Deleted raid " + id, "#55FF55"); return sendList(p); }
        if (what === "open" || what === "start" || what === "cancel") { adminAction(p, what, id); return sendList(p); }
        if (what === "rift" && typeof DBR_RAIDS.riftRequest === "function") return DBR_RAIDS.riftRequest(p, d);
    });
    function poolChoices() { return Object.keys(defs()).sort().map(function (k) { return { id: k, name: defs()[k].name, type: defs()[k].raidType }; }); }
    RPG.net.on("dbr_raid_save", function (p, d) {
        if (!can(p, "rg.raid.edit") || !d || !d.def) return;
        var def = D.normalize(d.def);
        if (!def.id) { msgTo(p, "That raid has no id and was not saved.", "#FF5555"); return; }
        if (d.target === "rift" && typeof DBR_RAIDS.saveRiftEncounter === "function") { DBR_RAIDS.saveRiftEncounter(p, String(d.riftId || ""), def); return; }
        putDef(def);
        msgTo(p, "Saved raid " + strip(def.name), "#55FF55");
    });
    /** SetBoundsPacket: from the WorldEdit selection (we_sel) or two typed corners in the player's dimension. */
    RPG.net.on("dbr_raid_bounds", function (p, d) {
        if (!can(p, "rg.raid.edit") || !d) return;
        var r = null;
        if (d.mode === "we") {
            var s = p.getVar("we_sel", null);
            if (!s || !s.p1 || !s.p2) { msgTo(p, "Make a WorldEdit selection first (wand, or //pos1 and //pos2).", "#FF5555"); return; }
            r = D.region({ dim: s.dim || p.dimension, x1: s.p1[0], y1: s.p1[1], z1: s.p1[2], x2: s.p2[0], y2: s.p2[1], z2: s.p2[2] });
        } else if (d.mode === "manual") {
            var a = (d.min || []).map(Number), b = (d.max || []).map(Number);
            if (a.length !== 3 || b.length !== 3 || a.concat(b).some(isNaN)) { msgTo(p, "Type both corners as x y z.", "#FF5555"); return; }
            r = D.region({ dim: p.dimension, x1: a[0], y1: a[1], z1: a[2], x2: b[0], y2: b[1], z2: b[2] });
        } else if (d.mode === "clear") r = null;
        RPG.net.send(p, "dbr_raid_bounds_result", { which: d.which, region: r });
    });
    /** Suggestions for the editor's pickers. */
    var VANILLA = ["minecraft:warden", "minecraft:wither", "minecraft:ender_dragon", "minecraft:zombie", "minecraft:husk", "minecraft:skeleton", "minecraft:wither_skeleton",
        "minecraft:spider", "minecraft:creeper", "minecraft:blaze", "minecraft:piglin_brute", "minecraft:vindicator", "minecraft:evoker", "minecraft:ravager", "minecraft:iron_golem",
        "minecraft:villager", "minecraft:wolf", "minecraft:enderman", "minecraft:elder_guardian", "minecraft:hoglin"];
    RPG.net.on("dbr_raid_suggest", function (p, d) {
        if (!can(p, "rg.raid.edit") || !d) return;
        var q = String(d.q || "").toLowerCase(), kind = String(d.kind || ""), out = [];
        var cap = d.all ? 3000 : 60;   // the editor's dropdowns fetch everything once and filter as you type
        function add(id, label) { if (out.length < cap && (!q || id.toLowerCase().indexOf(q) >= 0 || String(label || "").toLowerCase().indexOf(q) >= 0)) out.push({ id: id, label: label || id }); }
        if (kind === "entity") {
            add("dmz_ragnarok:raid_npc", "Raid fighter");
            RPG.mobs.list().forEach(function (m) { if (m.indexOf("dmzq_") === 0 && !/_v[1-9][0-9]*$/.test(m)) add("dragonminez:" + m.substring(5).replace(/_v0$/, ""), strip(RPG.mobs.name(m))); });
            if (typeof RG_NPC_MODELS !== "undefined") RG_NPC_MODELS.forEach(function (r) { add("rgnpc#" + r[0], r[5]); });
            RPG.mobs.list().forEach(function (m) { if (m.indexOf("dmzq_") !== 0 && m.indexOf("dbr_raid_rg_") !== 0) add(m, strip(RPG.mobs.name(m))); });
            VANILLA.forEach(function (v) { add(v); });
        } else if (kind === "rgmodel") {
            if (typeof RG_NPC_MODELS !== "undefined") RG_NPC_MODELS.forEach(function (r) { add(r[0], r[5]); });
        } else if (kind === "raid") {
            Object.keys(defs()).sort().forEach(function (k) { add(k, strip(defs()[k].name)); });
        } else if (kind === "skill") {
            if (typeof DMZ_SKILLS_DATA !== "undefined" && DMZ_SKILLS_DATA.COSTS) Object.keys(DMZ_SKILLS_DATA.COSTS).forEach(function (s) { add(s); });
        }
        RPG.net.send(p, "dbr_raid_suggestions", { kind: kind, q: d.q || "", list: out });
    });
    RPG.net.on("dbr_raid_signup_action", function (p, d) {
        d = d || {};
        var id = String(d.id || ""), def = getDef(id);
        if (!def) return;
        var inst = instance(id), a = String(d.action || "");
        if (a === "join") reportJoin(p, def, inst.join(p));
        else if (a === "leave") p.tell(inst.leave(p.uuid) ? "§7You withdrew from §f" + sec(def.name) + "§7." : "§cYou are not signed up for that raid.");
        else if (a === "tp") {
            if (!inst.isSignedUp(p.uuid) && !inst.isParticipant(p.uuid)) { p.tell("§cSign up first."); return; }
            if (inst.started() && inst.isParticipant(p.uuid) && !inst.eliminated[p.uuid]) inst.teleport(p);
            else if (def.arena) { inst.rememberLocation(p); var at2 = safeSpot(def.playerSpawn || def.arena, null, !!def.playerSpawn); p.teleportTo((def.playerSpawn || def.arena).dim, at2.x, at2.y, at2.z); }
        } else if (a === "status") p.tell(inst.status());
        else if (a === "party") {
            if (typeof DMZ_PARTY === "undefined" || !DMZ_PARTY.isLeader(p)) { p.tell("§cOnly a party leader can sign the party up."); return; }
            DMZ_PARTY.members(p).forEach(function (m) { if (m && m.isAlive && m.isAlive()) reportJoin(m, def, inst.join(m)); });
        }
        if (a !== "status") openSignup(p, id);
    });
    function reportJoin(p, def, res) {
        var n = sec(def.name);
        var msg = { OK: "§a[Raid] You signed up for §f" + n + "§a!", CLOSED: "§cSign-ups for " + n + "§c are not open.", ALREADY: "§7You are already signed up for " + n + "§7.",
            FULL: "§c" + n + "§c is full.", NO_CHARACTER: "§cCreate your character first.", NO_SUCH_RAID: "§cNo such raid." }[res];
        p.tell(msg || res);
    }
    function adminAction(p, what, id) {
        var def = getDef(id);
        if (!def) { if (p) p.tell("§cNo raid called '" + id + "'."); return; }
        var inst = instance(def.id), tell = function (s) { if (p) p.tell(s); else RPG.log(strip(s)); };
        if (what === "open") {
            if (!def.arena) return tell("§c" + sec(def.name) + "§c has no arena yet: set one in /raid edit.");
            if (def.eventOnly) return tell("§c" + sec(def.name) + "§c is event-only and runs only inside a timed event.");
            tell(inst.openSignups(def.signupMinutes) ? "§aSign-ups opened for " + sec(def.name) + "§a." : "§c" + sec(def.name) + "§c is already running.");
        } else if (what === "start") {
            if (inst.state === "SIGNUP") tell(inst.forceStart() ? "§aStarting " + sec(def.name) + "§a." : "§cCould not start.");
            else tell(inst.state === "IDLE" ? "§cOpen sign-ups first (/raid open), or use a Raid Soul." : "§c" + sec(def.name) + "§c is already running.");
        } else if (what === "cancel") { inst.cancel(true); tell("§aCancelled " + sec(def.name) + "§a."); }
    }

    // =========================================================================================
    //  Commands (RaidCommand)
    // =========================================================================================
    var SUBS = {};               // extra subcommands (rift -> 92_dbr_raids_rifts.js)
    function rest(args, from) { return args.slice(from).join(" ").replace(/^"|"$/g, ""); }
    function raidCommand(p, args) {
        var sub = String(args[0] || "").toLowerCase(), name = rest(args, 1);
        var tell = function (s) { if (p) p.tell(s); else RPG.log(strip(s)); };
        if (SUBS[sub]) return SUBS[sub](p, args.slice(1));
        if (!sub || sub === "help") {
            tell("§6[Raid] §f/raid list | join <name> | leave <name> | status <name>");
            tell("§6[Raid] §f/raid zsoul [info] §7- your Z-Souls (beyond-cap stats)");
            if (can(p, "rg.raid.edit")) tell("§6[Raid] §7admin: edit | create <id> [name] | open | start | cancel <name> | npc spawn|bind|remove <name> | soul <name> | rift ... | zsoul reset [player] | zsoul give <stat> <tier> [player]");
            return;
        }
        if (sub === "list") {
            var ids = Object.keys(defs()).sort();
            if (!ids.length) return tell("§7No raids yet." + (can(p, "rg.raid.edit") ? " Make one with /raid edit." : ""));
            ids.forEach(function (id) { var inst = INST[id]; tell(inst ? inst.status() : "§6[Raid] §f" + sec(defs()[id].name) + " §7(" + id + ") - Idle"); });
            return;
        }
        if (sub === "join" || sub === "leave" || sub === "status") {
            if (!p && sub !== "status") return;
            var def = findDef(name);
            if (!def) return tell("§cNo raid called '" + name + "'.");
            var inst = instance(def.id);
            if (sub === "join") return reportJoin(p, def, inst.join(p));
            if (sub === "leave") return tell(inst.leave(p.uuid) ? "§7You withdrew from §f" + sec(def.name) + "§7." : "§cYou are not signed up for that raid.");
            return tell(inst.status());
        }
        var node = sub === "create" ? "rg.raid.edit" : "rg.raid." + sub;
        if (!can(p, node)) return tell("§cYou don't have permission (" + node + ").");
        if (sub === "edit") { if (p) RPG.net.send(p, "dbr_raid_open_hub", {}); return; }
        if (sub === "create") {
            var id = String(args[1] || "").toLowerCase().replace(/[^a-z0-9_]/g, "");
            if (!id) return tell("§c/raid create <id> [name]");
            if (getDef(id)) return tell("§cA raid called '" + id + "' already exists.");
            putDef(createDefault(id, rest(args, 2) || id));
            return tell("§aCreated raid §f" + id + "§a. Set its arena in /raid edit.");
        }
        if (sub === "open" || sub === "start" || sub === "cancel") { var d2 = findDef(name); return adminAction(p, sub, d2 ? d2.id : name); }
        if (sub === "soul") {
            if (!p) return;
            var sd = findDef(name);
            if (!sd) return tell("§cNo raid called '" + name + "'.");
            giveSoul(p, sd);
            return tell("§aGave a Raid Soul for " + sec(sd.name) + "§a.");
        }
        if (sub === "npc") {
            var op = String(args[1] || "").toLowerCase(), nn = rest(args, 2);
            if (op === "remove") {
                var h = hosts(), n = 0;
                Object.keys(h).forEach(function (u) {
                    if (nn) { var nd = findDef(nn); if (!nd || h[u].raid !== nd.id) return; }
                    var e = entity(u);
                    if (e) e.remove();
                    delete h[u]; n++;
                });
                saveHosts(h);
                return tell("§aRemoved " + n + " raid host(s)" + (n && !nn ? "" : "") + ".");
            }
            if (!p) return;
            var hd = findDef(nn);
            if (!hd) return tell("§cNo raid called '" + nn + "'.");
            if (op === "spawn") {
                var b = hostBody(hd), e2 = b.kind === "npc" ? RPG.world.spawnNpc(p.dimension, b.id, p.x, p.y, p.z) : b.kind === "mob" ? RPG.world.spawnMob(p.dimension, b.id, p.x, p.y, p.z) : RPG.world.spawn(p.dimension, b.id, p.x, p.y, p.z);
                if (!e2) return tell("§cCould not spawn " + b.id + ".");
                makeHost(e2, hd);
                return tell("§aSpawned a raid host for " + sec(hd.name) + "§a.");
            }
            if (op === "bind") {
                var t = p.target(8);
                if (!t || t.isPlayer()) return tell("§cLook at the entity to bind (within 8 blocks).");
                makeHost(t, hd);
                return tell("§aBound " + t.name + "§a as a raid host for " + sec(hd.name) + "§a.");
            }
            return tell("§c/raid npc spawn <name> | bind <name> | remove [name]");
        }
        tell("§cUnknown subcommand. /raid help");
    }
    function suggest(p, words) {
        var n = words.length;
        if (n <= 1) return ["list", "join", "leave", "status", "edit", "create", "open", "start", "cancel", "npc", "soul", "rift", "zsoul", "help"];
        var sub = String(words[0]).toLowerCase();
        if (sub === "npc" && n === 2) return ["spawn", "bind", "remove"];
        if (SUBS[sub] && SUBS[sub].suggest) return SUBS[sub].suggest(p, words.slice(1));
        if (["join", "leave", "status", "open", "start", "cancel", "soul"].indexOf(sub) >= 0 || (sub === "npc" && n === 3)) return Object.keys(defs()).sort();
        return [];
    }
    RPG.commands.register("raid", { root: true, aliases: ["raidboss", "srb"], description: "Raid bosses: /raid help", run: raidCommand, suggest: suggest });

    return {
        CFG: CFG, Instance: Instance, defs: defs, getDef: getDef, putDef: putDef, findDef: findDef, createDefault: createDefault, instance: instance,
        runs: function () { return RUNS; }, runOfPlayer: runOfPlayer, SUBS: SUBS, msgTo: msgTo, can: can, strip: strip, sec: sec, inArena: inArena,
        safeSpot: safeSpot, giveAll: giveAll, resolveBody: resolveBody, poolChoices: poolChoices, riftRequest: null, saveRiftEncounter: null
    };
})();
