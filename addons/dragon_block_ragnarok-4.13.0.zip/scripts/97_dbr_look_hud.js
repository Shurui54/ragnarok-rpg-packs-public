// =====================================================================================
//  97_dbr_look_hud.js - DBR lines for the Look HUD addon (server side)
// =====================================================================================
//  A creature's battle power (10_stats.js powerLevel) when the player looking at it wears a scouter, like DMZ's
//  scouter readout; a hidden ki (ki cloak, Glind) reads as 5 there too. Harmless without the Look HUD addon.
// =====================================================================================
var LOOK_HUD_LINES = typeof LOOK_HUD_LINES !== "undefined" ? LOOK_HUD_LINES : [];
LOOK_HUD_LINES.push(function (target, player) {
    if (target.kind !== "entity" || !target.info.living || !String(player.getVar("dmz_scouter", "") || "")) return null;
    var bp = typeof powerLevel === "function" ? powerLevel(target.entity) : 0;
    if (!(bp > 0)) return null;
    return "&aBattle power: &f" + String(Math.floor(bp)).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
});
