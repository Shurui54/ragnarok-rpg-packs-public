// =====================================================================================
//  88_dbr_space_cereal.js - Planet Cereal and its people (Dragon Block Ragnarok's own, GPL-3.0)
// =====================================================================================
//  DragonMine Z names Planet Cereal (its space pod destination dragonminez:cereal_planet, "Cereal Planet",
//  icon 4; Instant Transmission's 12000 ki fee; Granolah's Cereal armour and the Cerealian pattern) and DMZ
//  Ragnarok gives it a place in the sky and the Cerulean Dragon Balls, but neither builds the world. DBR does:
//  - the dimension ragnarok_rpg:cereal_planet (datapack/, written by tools/cereal_worldgen.py): a once-ruined
//    world of stepped mesas and plateaus in banded pink-grey rock, canyons with teal rivers, a scarred basin of
//    old impact craters, crystal fields, sparse teal grass and twisted trees; Cerealian villages, the ruins of
//    the old cities and the craters generate with the terrain (dbr:cerealian_village / cereal_ruins / cereal_crater)
//  - a body in space (shared/15_dbr_space_orbits.js), the pod destination (56_vehicles.js), the star map, the
//    landing beside the nearest village, and Cereal's sky (client/scripts/62_dbr_cereal_sky.js)
//  - the Cerulean Dragon Balls' home (57_dragon_balls.js DB_SETS.cerulean.dim)
//  - its people: Cerealian villagers (eight hand-painted looks, tools/cereal_art.py), a trader and two with
//    errands, and in one village per world Granolah and Monaito, the old Namekian who raised him, with
//    Monaito's three quests. A village is peopled the first time a player comes near it.
// =====================================================================================
var dbrCerealLanding = null;    // 56_vehicles.js: the pod's landing spot on Cereal
var DBR_CEREAL = (function () {
    var DIM = "ragnarok_rpg:cereal_planet", VILLAGE = "dbr:cerealian_village";
    var GEO = "dbr:geo/entity/cereal/cerealian.geo.json", TEX = "dbr:textures/entity/cereal/";
    var REACH = 48, HOME_CHANCE = 0.35, HOME_FORCE = 4;

    function look(tex) {
        return dmzSagaStates({ model: GEO, texture: TEX + tex + ".png", animation: DMZ_ANIM + "sagas/saga_base.animation.json",
            idle: "idle", walk: "walk", attack: "attack1_1", scale: 1.0 });
    }

    // ---- the villagers ----
    var LINES = [
        "Cereal was a green world once. The Saiyans and Frieza's soldiers came, and most of us were gone in a single night.",
        "The crystals grow back faster than the trees. My grandmother said they remember what the planet looked like.",
        "We Cerealians see far with our right eye. Far enough to count every crater from the old war.",
        "The two Cerulean Dragon Balls lie somewhere on this planet. One wish, they say, and only one.",
        "Watch the canyons after a rain: the rivers come up fast and they don't care who's standing in them.",
        "Strangers in pods don't usually bring good news here. You look different. Don't make me regret saying that.",
        "We rebuilt the village from the stones of the old city. Every wall here used to be part of something bigger.",
        "The Heeters send their hired guns out here now and then. Granolah deals with them, when he feels like it."
    ];
    for (var i = 0; i < 8; i++) (function (n) {
        var def = { name: "&dCerealian", geo: look("cerealian_" + n), width: 0.6, height: 1.9, wander: true, dialogue: "dbr_cerealian_" + n };
        if (n === 6) def.title = "&7Trader";
        RPG.npcs.define("dbr_cerealian_" + n, def);
        var opts = [];
        if (n === 6) opts.push({ text: "Show me what you have.", openShop: "cereal_shop" });
        if (n === 1) opts.push({ text: "Do you need help with anything?", ifQuestAvailable: "cereal_shrine_shards", startQuest: "cereal_shrine_shards" });
        if (n === 4) opts.push({ text: "Do you need help with anything?", ifQuestAvailable: "cereal_crater_glass", startQuest: "cereal_crater_glass" });
        opts.push({ text: "Tell me about Cereal.", next: "lore" }, { text: "Goodbye." });
        RPG.dialogues.define("dbr_cerealian_" + n, { speaker: "Cerealian", nodes: {
            start: { text: LINES[n], options: opts },
            lore: { text: LINES[(n + 3) % LINES.length], options: [{ text: "Thank you." }] }
        } });
    })(i);
    RPG.shops.define("cereal_shop", {
        name: "Cerealian Trader",
        items: [
            { item: "minecraft:bread", count: 4, buy: 20 }, { item: "minecraft:beetroot_soup", buy: 25 }, { item: "minecraft:carrot", count: 8, buy: 15 },
            { item: "minecraft:amethyst_shard", count: 4, buy: 60 }, { item: "minecraft:calcite", count: 16, buy: 40 },
            { item: "minecraft:mud_bricks", count: 16, buy: 40 }, { item: "minecraft:cyan_terracotta", count: 16, buy: 40 },
            { item: "senzu_bean", buy: 2500, levelReq: 40 },
            { item: "minecraft:amethyst_shard", sell: 8 }, { item: "minecraft:crying_obsidian", sell: 40 }
        ]
    });

    // ---- Granolah (dialogue only: DMZ has no fight for him) and Monaito ----
    RPG.npcs.define("dbr_granolah", { name: "&dGranolah", title: "&7The Last Cerealian", geo: look("granolah"), width: 0.6, height: 1.95,
        wander: false, invulnerable: true, dialogue: "dbr_granolah" });
    RPG.dialogues.define("dbr_granolah", { speaker: "Granolah", nodes: {
        start: { text: function (p) { return p.isQuestDone("cereal_monaito_2") ? "Monaito says you ran the Heeters' men off. ...Fine. You can stay. Don't touch my scope."
                : "Another pod. If you're here for the Dragon Balls, turn around. If you're here for a fight, you'll get one, just not the one you want."; },
            options: [{ text: "What happened to this planet?", next: "war" }, { text: "Who is Monaito?", next: "monaito" },
                      { text: "The Cerulean Dragon Balls?", next: "balls" }, { text: "Never mind." }] },
        war: { text: "Saiyans, working for Frieza. They burned the cities and hunted us down. I was a child; my mother hid me. Every crater you walk past is a grave.",
            options: [{ text: "I'm sorry.", next: "start" }] },
        monaito: { text: "The old Namekian who found me in the ruins and raised me. He worries too much. Help him if he asks; he won't ask twice.",
            options: [{ text: "I will.", next: "start" }] },
        balls: { text: "Two balls, one wish, and the dragon sleeps a long time after. Cereal's balls are for Cereal. Remember that.",
            options: [{ text: "Understood.", next: "start" }] }
    } });
    RPG.npcs.define("dbr_monaito", { name: "&aMonaito", title: "&7Old Namekian", width: 0.6, height: 1.9, scale: 0.95, wander: false, invulnerable: true,
        geo: { model: DMZ_GEO + "enemies/namekian.geo.json", texture: TEX + "monaito.png", animation: DMZ_ANIM + "enemies/namekian.animation.json", idle: "idle", walk: "walk" },
        dialogue: "dbr_monaito", onInteract: function (player, npc) { sfx(npc, "entity.namekian.vill.ambient", 1, 0.85); } });
    RPG.dialogues.define("dbr_monaito", { speaker: "Monaito", nodes: {
        start: { text: function (p) {
                if (p.isQuestDone("cereal_monaito_3")) return "Granolah smiles more these days. Don't tell him I said so. You are always welcome at our fire.";
                return "Oh! A visitor, and not one of the Heeters' men. Forgive an old Namekian his nerves. I am Monaito. I came to Cereal long ago, and I stayed.";
            },
            options: [{ text: "A Namekian, so far from Namek?", next: "why" }, { text: "Is there anything I can do?", next: "help" }, { text: "Farewell." }] },
        why: { text: "My ship came down here after the war. I found a little Cerealian boy alone among the ruins. Someone had to look after him. That boy is Granolah.",
            options: [{ text: "He's lucky to have you.", next: "start" }] },
        help: { text: "Perhaps. We grow what we can, and the crystals give us a little to trade. Talk to me when you're ready to lend a hand.",
            options: [{ text: "I'm ready.", ifQuestAvailable: "cereal_monaito_1", startQuest: "cereal_monaito_1" },
                      { text: "I'm ready.", ifQuestAvailable: "cereal_monaito_2", startQuest: "cereal_monaito_2" },
                      { text: "I'm ready.", ifQuestAvailable: "cereal_monaito_3", startQuest: "cereal_monaito_3" },
                      { text: "Later.", next: "start" }] }
    } });

    // ---- Monaito's quests ----
    var CAT = "Planet Cereal";
    RPG.quests.define("cereal_monaito_1", {
        name: "Cereal I: The Old Namekian's Garden", category: CAT, giver: "dbr_monaito", turnIn: "dbr_monaito",
        description: "Monaito's garden barely feeds the village. Bring him food from Cereal's fields and shards from its crystals to trade.",
        requires: { level: 50 },
        objectives: [{ type: "collect", item: "minecraft:beetroot", count: 12, consume: true, description: "Gather beetroot from the village fields" },
                     { type: "collect", item: "minecraft:amethyst_shard", count: 8, consume: true, description: "Break amethyst from Cereal's crystal outcrops" }],
        rewards: { xp: 20000, money: 12000, items: [{ item: "senzu_bean", count: 2 }] },
        onComplete: function (p) { p.addTp(1500); p.tell("&b+1500 TP"); }
    });
    RPG.quests.define("cereal_monaito_2", {
        name: "Cereal II: Hired Guns", category: CAT, giver: "dbr_monaito", turnIn: "dbr_monaito",
        description: "Mercenaries working for the Heeters are coming for the village's crystal stores. Granolah is away. Protect the village.",
        requires: { level: 50, quests: ["cereal_monaito_1"] },
        objectives: [{ type: "kill", target: "dbr_cereal_raider", count: 5, description: "Drive off the Heeters' mercenaries" }],
        rewards: { xp: 35000, money: 20000, skillPoints: 3 },
        onStart: function (p) { raid(p); },
        onComplete: function (p) { p.addTp(3000); p.tell("&b+3000 TP"); }
    });
    RPG.quests.define("cereal_monaito_3", {
        name: "Cereal III: One Wish", category: CAT, giver: "dbr_monaito", turnIn: "dbr_granolah",
        description: "Monaito trusts you with the Cerulean Radar. Find a Cerulean Dragon Ball and show it to Granolah, so he knows Cereal's balls are in good hands.",
        requires: { level: 50, quests: ["cereal_monaito_2"] },
        objectives: [{ type: "collect", item: "dball1_cerulean", count: 1, description: "Find the 1-Star Cerulean Dragon Ball (radar)" },
                     { type: "talk", npc: "dbr_granolah", description: "Show it to Granolah" }],
        rewards: { xp: 60000, money: 40000, skillPoints: 4, items: [{ item: "pattern_granola" }] },
        onStart: function (p) { if (!p.hasItem("cerulean_dball_radar", 1)) { p.giveItem("cerulean_dball_radar", 1); p.tell("&aMonaito hands you the &bCerulean Radar&a."); } },
        onComplete: function (p) { p.addTp(5000); p.tell("&b+5000 TP"); }
    });
    // the villagers' errands (daily)
    RPG.quests.define("cereal_shrine_shards", {
        name: "Shards for the Shrine", category: CAT, giver: "dbr_cerealian_1", turnIn: "dbr_cerealian_1", repeatable: true, repeatDelay: 86400,
        description: "The village shrine is fed with crystal shards. Bring some from the outcrops.",
        requires: { level: 40 },
        objectives: [{ type: "collect", item: "minecraft:amethyst_shard", count: 12, consume: true }],
        rewards: { xp: 6000, money: 4000 }
    });
    RPG.quests.define("cereal_crater_glass", {
        name: "Glass from the Craters", category: CAT, giver: "dbr_cerealian_4", turnIn: "dbr_cerealian_4", repeatable: true, repeatDelay: 86400,
        description: "The impacts left weeping black glass in the hearts of the craters. The village's smith wants some.",
        requires: { level: 40 },
        objectives: [{ type: "collect", item: "minecraft:crying_obsidian", count: 4, consume: true }],
        rewards: { xp: 8000, money: 6000 }
    });

    // ---- the Heeters' mercenaries (Monaito's second quest): Frieza Force soldiers' rig, the DMZ saga brain ----
    RPG.mobs.define("dbr_cereal_raider", {
        name: "&cHeeter Mercenary", geo: sagaLook("saga_friezasoldier02"), width: 1.0, height: 2.0,
        health: 300, damage: 30, armor: 4, speed: 0.25, followRange: 40, xp: 400, hostile: true, persistent: true,
        loot: [{ item: "minecraft:emerald", chance: 0.5 }, { item: "minecraft:amethyst_shard", count: [1, 3] }],
        onTick: function (mob) { if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onTick(mob); },
        onDeath: function (mob, killer) { if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onDeath(mob); if (typeof payKiller === "function") payKiller(killer, 60, 160); }
    });
    if (typeof DMZ_SAGA_ALIAS !== "undefined") DMZ_SAGA_ALIAS.dbr_cereal_raider = "saga_friezasoldier02";
    function raid(p) {
        if (p.dimension !== DIM) { p.tell("&7Monaito: &fThey will come to the village. Be here when they do."); }
        var go = function (tries) {
            if (!p.alive || !p.isQuestActive("cereal_monaito_2")) return;
            if (p.dimension !== DIM) { if (tries > 0) RPG.schedule(200, function () { go(tries - 1); }); return; }
            p.title("&cHeeter Mercenaries", "&7Protect the village!");
            sfx(p, "minecraft:entity.elder_guardian.curse", 0.5, 0.7);
            for (var k = 0; k < 5; k++) {
                var a = Math.random() * Math.PI * 2, d = 14 + Math.random() * 8;
                var g = ground(p.x + Math.cos(a) * d, p.z + Math.sin(a) * d) || { x: p.x, y: p.y, z: p.z };
                RPG.world.spawnMob(DIM, "dbr_cereal_raider", g.x, g.y, g.z);
            }
        };
        RPG.schedule(80, function () { go(90); });
    }

    // ---- peopling the villages ----
    var MEM = null;
    function state() { if (!MEM) MEM = RPG.data.get("dbr_cereal_pop", null) || { v: {}, home: "", seen: 0 }; return MEM; }
    function save() { RPG.data.set("dbr_cereal_pop", MEM); }
    function ground(x, z) {
        x = Math.floor(x); z = Math.floor(z);
        if (!RPG.world.isLoaded(DIM, x, z)) return null;
        var y = RPG.world.surfaceY(DIM, x, z);
        if (y <= -9999) return null;
        var below = String(RPG.world.getBlock(DIM, x, y - 1, z));
        if (below.indexOf("water") >= 0 || below.indexOf("lava") >= 0 || below === "minecraft:air") return null;
        return { x: x + 0.5, y: y, z: z + 0.5 };
    }
    function spotIn(st) {
        for (var i = 0; i < 16; i++) {
            var g = ground(st.minX + 3 + Math.random() * (st.maxX - st.minX - 6), st.minZ + 3 + Math.random() * (st.maxZ - st.minZ - 6));
            if (g) return g;
        }
        return null;
    }
    function spawnIn(st, id, tag) {
        var g = spotIn(st);
        var e = g ? RPG.world.spawnNpc(DIM, id, g.x, g.y, g.z) : null;
        if (e && tag) e.addTag(tag);
        return e;
    }
    function people(st, key) {
        var s = state(), n = 3 + Math.floor(Math.random() * 3), got = 0;
        var picks = [0, 1, 2, 3, 4, 5, 6, 7];
        for (var i = picks.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = picks[i]; picks[i] = picks[j]; picks[j] = t; }
        for (var k = 0; k < n; k++) if (spawnIn(st, "dbr_cerealian_" + picks[k])) got++;
        if (!got) return false;
        s.seen++;
        // Granolah and Monaito share one house: one village per world, picked at random (by the fourth village at the latest)
        if (!s.home && (Math.random() < HOME_CHANCE || s.seen >= HOME_FORCE)) { s.home = key; s.homeBox = st; }
        return true;
    }
    var lastCheck = {};
    function keepHome(st, key) {
        var t = RPG.server.getTick();
        if (t - (lastCheck[key] || -9999) < 400) return;
        lastCheck[key] = t;
        var cx = (st.minX + st.maxX) / 2, cz = (st.minZ + st.maxZ) / 2, cy = (st.minY + st.maxY) / 2;
        var near = RPG.world.entitiesNear(DIM, cx, cy, cz, 64);
        [["dbr_monaito", "dbr_cereal_monaito"], ["dbr_granolah", "dbr_cereal_granolah"]].forEach(function (w) {
            if (near.some(function (e) { return e.hasTag(w[1]); })) return;
            spawnIn(st, w[0], w[1]);
        });
    }
    function roam(p) {
        if (p.dimension !== DIM || !p.alive) return;
        var pts = [[0, 0], [REACH, 0], [-REACH, 0], [0, REACH], [0, -REACH]], s = state(), dirty = false;
        pts.forEach(function (o) {
            var x = Math.floor(p.x) + o[0], z = Math.floor(p.z) + o[1];
            if (!RPG.world.isLoaded(DIM, x, z)) return;
            // the village's box only spans its own height: ask at the ground there, not at the player's height
            // (someone flying over, or standing on a mesa beside it, would otherwise never find it)
            var y = RPG.world.surfaceY(DIM, x, z);
            if (y <= -9999) return;
            var st = RPG.world.structureStart(DIM, x, y - 1, z, VILLAGE);
            if (!st) return;
            var key = st.chunkX + "," + st.chunkZ;
            if (!s.v[key] && people(st, key)) { s.v[key] = 1; dirty = true; }
            if (s.home === key) keepHome(st, key);
        });
        if (dirty) save();
    }
    var HAS_STARTS = true;
    try { RPG.world.structureStart(DIM, 0, 0, 0, VILLAGE); } catch (e) { HAS_STARTS = false; }
    RPG.every(40, function () {
        if (!HAS_STARTS || !RPG.server.hasDimension(DIM)) return;
        RPG.server.players().forEach(function (p) { try { roam(p); } catch (err) { RPG.log("[DBR] cereal: " + err); } });
    });

    // ---- the landing: beside the Cerealian village nearest the middle of the world (found from the placement rules,
    // nothing loaded), worked out once per world ----
    function landing() {
        var saved = RPG.server.getData("dbr_cereal_landing", "");
        if (saved) { var a = String(saved).split(" ").map(Number); if (a.length === 3) return a; }
        if (!RPG.server.hasDimension(DIM)) return null;
        var best = null;
        [[0, 0], [256, 0], [-256, 0], [0, 256], [0, -256], [256, 256], [-256, -256], [256, -256], [-256, 256]].some(function (c) {
            try {
                RPG.world.structuresNear(DIM, c[0], c[1], 16).forEach(function (s) {
                    if (s.id !== VILLAGE) return;
                    var x = s.chunkX * 16, z = s.chunkZ * 16, d = x * x + z * z;
                    if (!best || d < best.d) best = { x: x, z: z, d: d };
                });
            } catch (e) { return true; }
            return !!best;
        });
        var out = best ? [best.x + 0.5, 100, best.z + 0.5] : [0.5, 100, 0.5];
        RPG.server.setData("dbr_cereal_landing", out.join(" "));
        return out;
    }
    dbrCerealLanding = landing;
    RPG.schedule(40, function () {
        try { var l = landing(); if (l && typeof DBR_SPACE_ORBITS !== "undefined") DBR_SPACE_ORBITS.byId("cereal_planet").landing = l; } catch (e) { RPG.log("[DBR] cereal landing: " + e); }
    });

    return { roam: roam, state: state, landing: landing };
})();
