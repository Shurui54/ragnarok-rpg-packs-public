// =====================================================================================
//  57_dragon_balls_bag.js - DMZ Ragnarok's Dragon Ball-Sack and where dragon balls may be
// =====================================================================================
//  Port of DMZ Ragnarok's (GPL-3.0) dragonballbag/* (DragonBallBagItem / Menu / Screen / Inventory /
//  Carry / Confine / ContainerEject / EntityGuard / InventoryHandler) and compat/dungeons/DungeonPvpBridge,
//  on the engine's RPG.items.confine:
//    - dragon balls (live or stone) may only be in a player's inventory or a Dragon Ball-Sack. Chests,
//      ender chests, shulker boxes, hoppers, droppers, furnaces, crafting grids, our Backpacks and Player
//      Vaults, bundles, item frames, armour stands, allays and every other container or entity refuse
//      them: a ball put in one goes straight back to the player (dropped at their feet when full), a ball
//      found in a container when it is opened goes to the opener, a container found holding one when its
//      chunk loads (and a hopper that swallowed one from the ground) puts it beside itself, mobs can't pick
//      dropped balls up and magnets/item vacuums leave them alone (PreventRemoteMovement). Inventory viewers
//      (/invsee) can't take balls or a full sack out of somebody's inventory. Graves may hold balls.
//    - the Dragon Ball-Sack: 7 slots (one set), worn in its own accessory slot (B), opened with the Open
//      Dragon Ball-Sack key (K) or by right-clicking it (which puts it on). It takes only balls of the set
//      you are collecting. Holding balls it may only be in your inventory or its slot (an empty one goes
//      anywhere); no sack in a sack. Its contents live in the item (RPG.items.setContents).
//    - one dragon at a time: a ball of a different set than the one you carry is not picked up (nor taken in
//      a trade); picked-up balls go into the worn sack first, then the inventory.
//    - the Auction House and Player Vaults refuse balls and a sack holding them (confined items); the
//      Trading addon's window takes them and hands them straight to the other player's inventory.
//    - carrying a ball in a dungeon dimension makes you fair game: other players can hit you there even
//      with the dungeon's PvP off.
//  Settings: ragnarok_rpg/config/dbr_dragon_balls.json (/rpg config dbr_dragon_balls).
// =====================================================================================
var DBR_BALL_CFG = RPG.config.define("dbr_dragon_balls", {
    oneSetAtATime:             { default: true, comment: "DMZ Ragnarok's one dragon at a time: a ball of a different set than the one you carry can't be picked up or put in your sack" },
    superMinPlacementDistance: { default: 3, min: 1, max: 16, integer: true, comment: "Hand-placed Super Dragon Balls must be at least this many blocks apart (DMZ Ragnarok: 3; the model is about 2.9 blocks across)" },
    superDormancyRealDay:      { default: true, comment: "A used Super set sleeps one real day (DMZ Ragnarok); off: one Minecraft week like the other sets" },
    duplicateCheck:            { default: true, comment: "DMZ Ragnarok's BallUniqueness: one of each star per set on the server; extra copies are removed every 5 seconds and on login" },
    dungeonPvpWithBall:        { default: true, comment: "Carrying a dragon ball in a dungeon dimension lets other players hit you there whatever the dungeon's PvP rule says" }
});
// SuSuperBallPlacementHandler's distance and the Super set's real-day dormancy, from the settings
if (typeof DB_SETS !== "undefined" && DB_SETS.super) DB_SETS.super.minSpacing = DBR_BALL_CFG.get("superMinPlacementDistance");
if (typeof DB_DORMANCY !== "undefined") DB_DORMANCY.wallSets.super = !!DBR_BALL_CFG.get("superDormancyRealDay");

// shared with the Land Claims and Guilds addons (see their scripts): exemptions and claim vetoes
var RPG_CLAIM_HOOKS = typeof RPG_CLAIM_HOOKS !== "undefined" && RPG_CLAIM_HOOKS ? RPG_CLAIM_HOOKS : { exempt: [], veto: [] };
// shared with the Trading addon: a swap it may refuse
var RPG_TRADE_HOOKS = typeof RPG_TRADE_HOOKS !== "undefined" && RPG_TRADE_HOOKS ? RPG_TRADE_HOOKS : { veto: [] };
var dbrIsBallBlock = null;    // (blockId) -> true for a dragon ball block, live or stone
var dbrBallSpotOk = null;     // (dimension, x, z) -> may a ball be scattered there (57_dragon_balls_rules.js)
var dbrCarriesBall = null;    // (player) -> true when a ball is in their inventory or sack

var DBR_BAG = (function () {
    var C = DBR_BALL_CFG;
    var SLOT = "dragonball_bag", SIZE = 7;
    // DragonBallBagMenu: the seven sockets painted on the sack's belly, then the inventory grid below it
    var SOCKET_X = [66, 84, 57, 75, 93, 66, 84], SOCKET_Y = [81, 81, 93, 93, 93, 105, 105];

    // ---- which items are balls (DragonBallSets) ----------------------------------------------------
    var BALLS = {}, BALL_LIST = [], BY_SET = {};
    Object.keys(DB_SETS).forEach(function (setId) {
        var set = DB_SETS[setId];
        BY_SET[setId] = [];
        for (var n = 1; n <= set.stars; n++) {
            [set.block(n), set.block(n) + "_stone"].forEach(function (name) {
                var id = RPG.blocks.id(name);
                if (!id) return;
                BALLS[id] = { set: setId, star: n, stone: name !== set.block(n) };
                BALL_LIST.push(id);
                BY_SET[setId].push(id);
            });
        }
    });
    function ballOf(id) { return BALLS[String(id)] || null; }
    dbrIsBallBlock = function (b) { var s = String(b || ""), i = s.indexOf("["); return !!BALLS[i < 0 ? s : s.substring(0, i)]; };

    // ---- the sack ---------------------------------------------------------------------------------------
    RPG.slots.define(SLOT, { name: "Dragon Ball-Sack", icon: "dbr:textures/gui/slot/dragonball_bag.png", order: 210 });
    var BAG_ID = "ragnarok_rpg:" + RPG.items.define("dragonball_bag", {
        name: "&6Dragon Ball-Sack", model: "dbr:rpg/item/dragonball_bag", maxStack: 1, accessory: SLOT, type: "accessory",
        lore: ["&7Holds one set of Dragon Balls", "&8Wear it in its slot (B), open it with K or right-click"],
        onUse: function (p) { useHeld(p); return true; }
    });
    function isBag(st) { return !!st && String(st.id) === BAG_ID; }

    // only players carry balls; the sack carries them too (and a sack holding one is held to the same rule)
    RPG.items.confine({ items: BALL_LIST, carriers: [BAG_ID],
        message: "&cDragon balls can only be kept in your inventory or a Dragon Ball-Sack, so it was returned to you." });

    function contents(bag) { return RPG.items.contents(bag, SIZE); }
    function setOfBag(bag) {
        var c = contents(bag);
        for (var i = 0; i < c.length; i++) { var b = c[i] && ballOf(c[i].id); if (b) return b.set; }
        return null;
    }
    /** The sack with its balls taken out: {bag, balls}. */
    function takeBalls(bag) {
        var c = contents(bag), balls = [], left = [], any = false;
        c.forEach(function (st) { if (st && ballOf(st.id)) { balls.push(st); any = true; left.push(null); } else left.push(st); });
        return { bag: any ? RPG.items.setContents(bag, left) : bag, balls: balls };
    }

    // DragonBallCarry.carriedSet: the set of the first ball in the inventory, else in the worn sack (skipWorn: not the
    // worn sack, whose screen is being edited). RPG.items.confinedOf hands over only the balls and full sacks.
    function carriedSet(p, skipWorn) {
        var list = RPG.items.confinedOf(p), worn = null;
        for (var i = 0; i < list.length; i++) {
            var e = list[i], st = e.stack;
            if (typeof e.slot === "string") { if (e.slot === "accessory:" + SLOT) worn = st; continue; }
            var b = ballOf(st.id);
            if (b) return b.set;
            if (isBag(st)) { var s = setOfBag(st); if (s) return s; }
        }
        return worn && !skipWorn && isBag(worn) ? setOfBag(worn) : null;
    }
    dbrCarriesBall = function (p) { return RPG.items.confinedOf(p).length > 0; };

    // ---- the sack's screen (DragonBallBagMenu / DragonBallBagScreen) ---------------------------------------
    var OPEN = {};                       // player uuid -> workbench handle
    function useHeld(p) {
        var worn = p.getAccessory(SLOT);
        if (!worn) {
            // DragonBallBagItem.use: right-click puts it on (into the empty slot), then it opens
            var held = p.getHeldStack();
            if (!isBag(held)) return;
            p.setHeldStack(null);
            p.setAccessory(SLOT, held);
            p.playSound("minecraft:item.armor.equip_leather", 0.8, 1.1);
        }
        open(p);
    }
    function open(p) {
        var worn = p.getAccessory(SLOT);
        if (!worn || !isBag(worn)) { p.tell("&cYou have no Dragon Ball-Sack equipped."); return; }
        var h = OPEN[p.uuid];
        if (h && h.isOpen()) return;
        var c = contents(worn), set = C.get("oneSetAtATime") ? carriedSet(p) : null;
        var accepts = set ? BY_SET[set] : BALL_LIST;
        var slots = [];
        for (var i = 0; i < SIZE; i++) slots.push({ x: SOCKET_X[i], y: SOCKET_Y[i], accepts: accepts, frame: false });
        var handle = RPG.ui.workbench(p, {
            title: "", background: "dbr:textures/gui/dragonball_bag.png", width: 176, height: 222, textureWidth: 256, textureHeight: 256,
            inventory: { x: 8, y: 140, label: false }, slots: slots, returnOnClose: false, allowConfined: true,
            // write straight back into the worn sack on every change, so nothing ever lives only in the screen
            onChange: function (pl, bench) { writeBack(pl, bench); },
            onClose: function (pl, items) { if (OPEN[pl.uuid] === handle) delete OPEN[pl.uuid]; }
        });
        if (!handle) return;
        for (var k = 0; k < SIZE; k++) if (c[k]) handle.set(k, c[k]);
        OPEN[p.uuid] = handle;
        p.playSound("minecraft:item.armor.equip_leather", 0.6, 1.3);
    }
    function writeBack(p, bench) {
        var worn = p.getAccessory(SLOT);
        if (!worn || !isBag(worn)) { bench.close(); return; }
        var items = bench.items(), back = [];
        // one dragon at a time inside the sack too: the sack keeps the set of its first ball; a ball of another set
        // (possible only when the sack was opened carrying none) is handed back. Never touch the inventory from in
        // here: a click is still moving stacks around it, so the hand-back waits for the next tick.
        if (C.get("oneSetAtATime")) {
            var set = null;
            for (var i = 0; i < items.length; i++) {
                var b = items[i] && ballOf(items[i].id);
                if (!b) continue;
                if (!set) { set = b.set; continue; }
                if (b.set !== set) { back.push(items[i]); items[i] = null; }
            }
        }
        p.setAccessory(SLOT, RPG.items.setContents(worn, items));
        if (!back.length) return;
        for (var k = 0; k < items.length; k++) if (!items[k] && bench.get(k)) bench.set(k, null);
        refuse(p);
        RPG.schedule(1, function () { back.forEach(function (st) { p.giveStack(st); }); });
    }
    function closeFor(p) {
        var h = OPEN[p.uuid];
        delete OPEN[p.uuid];
        if (h && h.isOpen()) h.close();
    }
    RPG.net.on("dbr_bag_open", function (p) { open(p); });

    // ---- pickups (DragonBallInventoryHandler.onPickup): one set at a time, into the sack first ---------------
    var REFUSED = {};
    function refuse(p) {
        var now = Date.now();
        if (REFUSED[p.uuid] && now - REFUSED[p.uuid] < 3000) return;
        REFUSED[p.uuid] = now;
        p.tell("&cOnly one dragon can be sought at a time. No hoarding dragon balls.");
    }
    RPG.on("itemPickup", function (p, st) {
        var b = st && ballOf(st.id);
        if (!b) return;
        if (C.get("oneSetAtATime")) {
            var have = carriedSet(p);
            if (have && have !== b.set) { refuse(p); return false; }
        }
        var id = String(st.id);
        RPG.schedule(1, function () { intoSack(p, id); });
    });
    function intoSack(p, id) {
        if (OPEN[p.uuid] && OPEN[p.uuid].isOpen()) return;
        var worn = p.getAccessory(SLOT);
        if (!worn || !isBag(worn)) return;
        var c = contents(worn), free = -1;
        for (var i = 0; i < SIZE; i++) if (!c[i]) { free = i; break; }
        if (free < 0) return;
        for (var s = 0; s <= 35; s++) {
            var st = p.getStack(s);
            if (!st || String(st.id) !== id) continue;
            var one = JSON.parse(JSON.stringify(st));
            one.count = 1;
            c[free] = one;
            st.count = (st.count || 1) - 1;
            p.setStack(s, st.count > 0 ? st : null);
            p.setAccessory(SLOT, RPG.items.setContents(worn, c));
            return;
        }
    }
    RPG.on("playerLeave", function (p) { delete REFUSED[p.uuid]; delete OPEN[p.uuid]; });

    // ---- trades (the Trading addon): balls may be traded (Auction House and Player Vaults refuse them as confined
    // items), but one dragon at a time still holds: no balls of a set other than the one the receiver carries --------
    RPG_TRADE_HOOKS.veto.push(function (receiver, incoming) {
        if (!C.get("oneSetAtATime")) return null;
        var sets = {};
        function note(st) { var b = st && ballOf(st.id); if (b) sets[b.set] = true; }
        incoming.forEach(function (st) { note(st); if (isBag(st)) contents(st).forEach(note); });
        var inc = Object.keys(sets);
        if (!inc.length) return null;
        if (inc.length > 1) return "Only one dragon can be sought at a time: that offer holds dragon balls of more than one set.";
        var have = carriedSet(receiver);       // what they give away is on the table already, not in their inventory
        if (have && have !== inc[0])
            return "Only one dragon can be sought at a time: " + receiver.name + " carries " + (DB_SET_TITLES[have] || have) + " Dragon Balls, not " + (DB_SET_TITLES[inc[0]] || inc[0]) + " ones.";
        return null;
    });

    // ---- DungeonPvpBridge: a ball carrier in a dungeon is fair game ---------------------------------------------
    // (90_dbr_dungeons.js asks dbrFairGame before it cancels a hit between players)
    return { slot: SLOT, size: SIZE, bagId: BAG_ID, isBag: isBag, ballOf: ballOf, takeBalls: takeBalls, contents: contents,
             carriedSet: carriedSet, closeFor: closeFor, open: open, ballIds: function () { return BALL_LIST.slice(); } };
})();
