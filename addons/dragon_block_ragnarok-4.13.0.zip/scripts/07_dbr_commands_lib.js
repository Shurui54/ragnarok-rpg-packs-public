// =====================================================================================
//  07_dbr_commands_lib.js - command trees for /rpgc commands (DragonMine Z's command shapes)
// =====================================================================================
//  DBR_CMD.tree(name, spec) registers /rpgc <name> from a small Brigadier-like tree, so a command keeps DMZ's exact
//  arguments, permission nodes per branch, tab completion (searchable) and usage errors:
//
//    DBR_CMD.tree("points", { description: "...", canUse: (p) => DBR_CMD.check(p, "points.info.self", "points.info.others"),
//        legacy: ["oldname"],                     // old names kept working, hidden from /rpgc suggestions
//        children: [ { lit: "set", perm: (p) => ..., children: [
//            { arg: "amount", type: "word", suggest: ["100", "1000"], exec: (c) => ..., children: [
//                { arg: "targets", type: "players", perm: (p) => DBR_CMD.has(p, "points.set.others"), exec: (c) => ... } ] } ] } ] });
//
//  Argument types: word, int, double, bool, player(s) (a vanilla target: name, @a, @p, @r, @s, @a[...]), greedy (the rest).
//  exec(c): c.src (player or null for the console), c.get(name), c.players(name) (the parsed targets, else [src]),
//  c.tell(text), c.fail(text). Nodes: perm(p) hides a branch from players without it (the console may use everything).
//
//  Permission nodes are DMZ's (DMZPermissions) without "dmz", under "dbr." ("dbr.stats.set.self"); operators
//  (level 2) and holders of "dbr.admin" have them all; the ones DMZ gives everyone are in the "default" group.
// =====================================================================================
/** Set by 98_dbr_commands.js (DMZ's BonusStats): extra points on a stat, added by the stats' formula (92_dbr_raids_zsouls.js). */
var DBR_STAT_BONUS = null;
/** Set by 98_dbr_commands.js: named bonuses from scripts (Zenkai, Cell Jr. penalties): add(p, stat, name, op, value), remove(p, name). */
var DBR_BONUS = null;
var DBR_CMD = (function () {
    var PREFIX = "dbr.";
    // DMZPermissions nodes whose default resolver is true
    var DEFAULT_TRUE = ["stats.info.self", "skill.list.self", "tech.list.self", "effect.list.self", "points.info.self", "quest.list.self",
        "quest.info", "quest.track.self", "party.use", "form.list.self", "alignment.info.self", "tail.self", "hair.self"];
    try { RPG.perms.group("default", DEFAULT_TRUE.map(function (n) { return PREFIX + n; })); } catch (e) { }

    /** DMZPermissions.hasPermission: the node, "dbr.admin" or op level 2; the console always. */
    function has(p, node) {
        if (!p) return true;
        if (p.isOp()) return true;
        try { return RPG.perms.has(p, PREFIX + "admin") || RPG.perms.has(p, PREFIX + node); } catch (e) { return false; }
    }
    /** DMZPermissions.check: self or others. */
    function check(p, self, others) { return has(p, self) || has(p, others); }

    function strip(s) { return String(s).replace(/[&§][0-9a-fk-or]/gi, ""); }
    function tell(src, text) { if (src) src.tell(String(text)); else RPG.log(strip(text)); }
    function fail(src, text) { tell(src, "&c" + text); }
    function selectors() { return ["@a", "@p", "@r", "@s"].concat(RPG.server.players().map(function (x) { return x.name; })); }

    function parseArg(node, words, i, src) {
        var w = words[i], t = node.type || "word";
        if (t === "greedy") return { ok: true, value: words.slice(i).join(" "), used: words.length - i };
        if (w === undefined) return { ok: false };
        if (t === "int" || t === "double") {
            var n = Number(w);
            if (w === "" || isNaN(n) || (t === "int" && Math.floor(n) !== n)) return { ok: false, error: "Invalid " + (t === "int" ? "integer" : "double") + " '" + w + "'" };
            if (node.min !== undefined && n < node.min) return { ok: false, error: (t === "int" ? "Integer" : "Double") + " must not be less than " + node.min + ", found " + n };
            if (node.max !== undefined && n > node.max) return { ok: false, error: (t === "int" ? "Integer" : "Double") + " must not be more than " + node.max + ", found " + n };
            return { ok: true, value: n, used: 1 };
        }
        if (t === "bool") {
            if (w !== "true" && w !== "false") return { ok: false, error: "Invalid boolean, expected 'true' or 'false' but found '" + w + "'" };
            return { ok: true, value: w === "true", used: 1 };
        }
        if (t === "players" || t === "player") {
            var list = RPG.server.selectPlayers(String(w), src);
            if (!list || !list.length) return { ok: false, error: "No player was found" };
            if (t === "player" && list.length > 1) return { ok: false, error: "Only one player is allowed, but the provided selector allows more than one" };
            return { ok: true, value: list, used: 1 };
        }
        return { ok: true, value: String(w), used: 1 };
    }
    function allowed(node, src) { return !node.perm || !src || node.perm(src); }

    function label(node) { return node.lit !== undefined ? node.lit : "<" + node.arg + ">"; }
    function usageOf(name, path, node, src) {
        var kids = (node.children || []).filter(function (k) { return allowed(k, src); });
        var base = "/rpgc " + name + (path.length ? " " + path.join(" ") : "");
        if (!kids.length) return [base];
        return kids.map(function (k) {
            var more = (k.children || []).filter(function (kk) { return allowed(kk, src); });
            var tail = more.length ? " " + (k.exec ? "[" : "") + more.map(label).join("|") + (k.exec ? "]" : "") + (more.some(function (m) { return m.children && m.children.length; }) ? " ..." : "") : "";
            return base + " " + label(k) + tail;
        });
    }

    function run(name, spec, src, words) {
        var node = spec, values = {}, path = [], i = 0, error = null;
        while (i < words.length) {
            var next = null, kids = (node.children || []).filter(function (k) { return allowed(k, src); });
            for (var a = 0; a < kids.length && !next; a++) {
                var k = kids[a];
                if (k.lit !== undefined) { if (String(words[i]).toLowerCase() === String(k.lit).toLowerCase()) { next = k; i++; path.push(k.lit); } }
            }
            for (var b = 0; b < kids.length && !next; b++) {
                var k2 = kids[b];
                if (k2.arg === undefined) continue;
                var r = parseArg(k2, words, i, src);
                if (r.ok) { values[k2.arg] = r.value; next = k2; path.push(words.slice(i, i + r.used).join(" ")); i += r.used; }
                else if (r.error && !error) error = r.error;
            }
            if (!next) {
                if (error) fail(src, error);
                else fail(src, "Unknown or incomplete command: '" + words.slice(i).join(" ") + "'");
                usageOf(name, path, node, src).slice(0, 8).forEach(function (u) { tell(src, "&7" + u); });
                return;
            }
            node = next;
            error = null;
        }
        if (!node.exec) {
            fail(src, "Unknown or incomplete command, see below for error");
            usageOf(name, path, node, src).slice(0, 8).forEach(function (u) { tell(src, "&7" + u); });
            return;
        }
        var ctx = {
            src: src, name: name,
            get: function (k, d) { return values[k] === undefined ? d : values[k]; },
            has: function (k) { return values[k] !== undefined; },
            /** the parsed targets, else the one running it (null from the console: an error is shown) */
            players: function (k) {
                if (values[k || "targets"] !== undefined) return values[k || "targets"];
                if (!src) { fail(null, "A player is required to run this command here"); return null; }
                return [src];
            },
            tell: function (t) { tell(src, t); }, fail: function (t) { fail(src, t); }
        };
        try { node.exec(ctx); }
        catch (e) { fail(src, "An unexpected error occurred trying to execute that command"); RPG.log("[DBR] /rpgc " + name + ": " + e); }
    }

    function suggest(spec, src, words) {
        var node = spec, i = 0;
        while (i < words.length - 1) {
            var next = null, kids = (node.children || []).filter(function (k) { return allowed(k, src); });
            for (var a = 0; a < kids.length && !next; a++) if (kids[a].lit !== undefined && String(words[i]).toLowerCase() === String(kids[a].lit).toLowerCase()) { next = kids[a]; i++; }
            for (var b = 0; b < kids.length && !next; b++) {
                var k = kids[b];
                if (k.arg === undefined) continue;
                if (k.type === "greedy") { next = k; i = words.length - 1; break; }
                var r = parseArg(k, words, i, src);
                if (r.ok) { next = k; i += r.used; }
            }
            if (!next) return [];
            node = next;
            if (node.type === "greedy") break;
        }
        var out = [], ctx = { src: src, words: words, word: function (n) { return words[n]; } };
        if (node.type === "greedy" && node.suggest) return list(node.suggest, ctx);
        (node.children || []).forEach(function (k) {
            if (!allowed(k, src)) return;
            if (k.lit !== undefined) out.push(k.lit);
            else if (k.suggest) out = out.concat(list(k.suggest, ctx));
            else if (k.type === "players" || k.type === "player") out = out.concat(selectors());
            else if (k.type === "bool") out.push("true", "false");
        });
        return out;
    }
    /** The engine hands a Java list: a plain array of strings. */
    function arr(a) { var out = []; if (a) for (var i = 0; i < a.length; i++) out.push(String(a[i])); return out; }
    function list(s, ctx) { try { var r = typeof s === "function" ? s(ctx) : s; return (r || []).map(String); } catch (e) { return []; } }

    /** Register /rpgc <name> (and hidden legacy names) from a tree spec. */
    function tree(name, spec) {
        var def = {
            description: spec.description || "", permission: spec.permission === undefined ? 0 : spec.permission,
            run: function (p, args) { run(name, spec, p, arr(args)); },
            suggest: function (p, args) { return suggest(spec, p, arr(args)); }
        };
        if (spec.canUse) def.canUse = spec.canUse;
        if (spec.root) def.root = true;
        RPG.commands.register(name, def);
        (spec.legacy || []).forEach(function (old) { legacy(old, def, name); });
        return def;
    }
    /** An old name for a command: same behaviour, left out of /rpgc's suggestions. */
    function legacy(old, def, now) {
        var d = {};
        for (var k in def) d[k] = def[k];
        d.hidden = true;
        d.description = "Old name of /rpgc " + now;
        RPG.commands.register(old, d);
    }

    /** A command under a new name, the old one kept working (hidden from suggestions). */
    function renamed(name, old, def) {
        RPG.commands.register(name, def);
        legacy(old, def, name);
    }

    /** "Steve" for one target, else null (DMZ's .success / .multiple messages). */
    function single(list) { return list && list.length === 1 ? list[0].name : null; }

    return { PREFIX: PREFIX, has: has, check: check, tell: tell, fail: fail, tree: tree, legacy: legacy, renamed: renamed, single: single,
        selectors: selectors, strip: strip };
})();
