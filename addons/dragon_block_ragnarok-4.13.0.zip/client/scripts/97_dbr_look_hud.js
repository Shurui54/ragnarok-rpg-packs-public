// =====================================================================================
//  97_dbr_look_hud.js - DBR lines for the Look HUD addon (client side)
// =====================================================================================
//  When the built-in Look HUD addon is on, DMZ's masters and quest NPCs say what they are: a master who trains
//  you (and which minigame), a dialogue-only master, a quest giver or a tournament host. Read from the shared
//  DMZ masters data, so nothing is asked from the server. Battle power comes from the server side
//  (scripts/97_dbr_look_hud.js) and only shows through a scouter, as in DMZ. Harmless without the Look HUD.
// =====================================================================================
var LOOK_HUD_CLIENT_LINES = typeof LOOK_HUD_CLIENT_LINES !== "undefined" ? LOOK_HUD_CLIENT_LINES : [];
LOOK_HUD_CLIENT_LINES.push(function (info) {
    if (info.type !== "entity" || info.rpgKind !== "npc" || typeof DMZ_MASTERS_DATA === "undefined") return null;
    var M = DMZ_MASTERS_DATA, id = M.BY_NPC[info.rpgId];
    if (!id) return null;
    var out = [];
    if (M.TOURNAMENT_HOSTS[id]) out.push("&6Tournament host");
    if (M.isMaster(id)) {
        if (M.isTextMaster(id)) out.push("&eMaster &7(talk)");
        else {
            var game = M.minigameFor(id);
            out.push("&eMaster &7- skills and training" + (game ? " &8(" + game + ")" : ""));
        }
        if (M.GOOD_MASTERS.indexOf(id) >= 0) out.push("&8Teaches good fighters");
        else if (M.EVIL_MASTERS.indexOf(id) >= 0) out.push("&8Teaches evil fighters");
    } else if (M.QUEST_NPCS[id]) out.push("&eQuest giver");
    return out;
});
