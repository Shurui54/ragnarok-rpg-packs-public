// DMZ Ragnarok's Open Dragon Ball-Sack key (SUKeybinds.OPEN_DRAGONBALL_BAG; B there, which is the Accessories key here):
// opens the sack worn in its accessory slot (scripts/57_dragon_balls_bag.js). Rebind it in Controls.
RPG.keys.register("dbr_dragonball_bag", { name: "Open Dragon Ball-Sack", key: "k" });
RPG.on("keybind", (id, down) => { if (id == "dbr_dragonball_bag" && down) RPG.net.send("dbr_bag_open", {}); });
