// =====================================================================================
//  46_dmz_racials.js - the client side of DragonMine Z's racial skills (scripts/33_dmz_racials.js)
// =====================================================================================
//  Ported from DragonMine Z (GPL-3.0):
//    client/gui/hud/KiReserveHUD.java + HudSideMeters (the Frost Demon "Power Reserve" meter: the capsule with the
//      reserve diamond, a vertical bar below it filling from the bottom in the aura colour, white-ish and pulsing
//      while it feeds a form, the % under it; on the left edge, centred, fading in only while there is a reserve).
//      Art: dmzpack:textures/gui/hud/hud_reserve.png (DMZ's own sheet). HUD editor region "dmz_reserve".
//    client/systems/BioSwellRenderState.java + ClientStatsEvents / EffectsEvents (the Bio-Android self-destruct:
//      the body swells up to 30 % bigger, eased 0.18 a tick, dust and rubble around it, and the camera shakes for
//      the one charging and, fading with distance, anyone within the blast radius x 1.5).
//  The server shares bioSwell (0..1) and bioDet (ticks left to detonation) per player.
// =====================================================================================
(function () {
    var X = XV, clamp = X.clamp, mix = X.mix, hex = X.hex;
    var SHEET = "dmzpack:textures/gui/hud/hud_reserve.png", SW = 128, SH = 256;
    var CAPSULE = 23, BORDER = 3, BAR_W = 17, BAR_H = 144;
    var BOX_W = CAPSULE, BOX_H = CAPSULE + BAR_H + BORDER + 7;
    var REFERENCE_HEIGHT = 360;
    var VIS = new X.Smoother(0.18, 0.01), ACTIVE = new X.Smoother(0.15), FILL = new X.Smoother(0.55, 0.002);

    function opt(key, def) { try { var v = RPG.storage.get(key, def); return v === undefined || v === null ? def : v; } catch (e) { return def; } }
    function num(v, d) { v = Number(v); return isNaN(v) ? d : v; }
    function quad(ctx, u, v, w, h, x, y, dw, dh, rgb, alpha) { ctx.quad(SHEET, x, y, dw, dh, u / SW, v / SH, (u + w) / SW, (v + h) / SH, hex(rgb), alpha); }

    // ---- KiReserveHUD ----
    function renderReserve(ctx) {
        var p = RPG.player;
        if (!p.present || opt("dmz_hud_hidden", false)) return;
        var editing = ctx.isEditing(), created = X.created();
        var frost = created && String(p.race || "") === "frost_demon";
        var max = Math.max(1, num(RPG.getVar("dmz_reserve_max", 0), 0)), res = frost ? Math.max(0, num(RPG.getVar("dmz_reserve", 0), 0)) : 0;
        var feeding = frost && !!num(RPG.getVar("dmz_reserve_active", 0), 0);
        var vis = editing ? 1 : VIS.update(frost && (res > 0 || feeding) ? 1 : 0);
        if (editing) VIS.snap(1);
        if (vis <= 0.01) return;
        var frac = editing && !frost ? 0.65 : FILL.update(clamp(res / max, 0, 1));
        var active = ACTIVE.update(feeding ? 1 : 0);
        var pulse = active * (0.5 + 0.5 * Math.sin(X.clock() * 8));
        var aura = X.parse(RPG.getVar("dmz_aura_color", "") || p.color("aura", "#7FD4FF"));
        var color = mix(aura, 0xFFFFFF, active * 0.35);
        var unit = Math.max(0.25, ctx.height / REFERENCE_HEIGHT);
        var x = 2 * unit, y = ctx.height / 2 - BOX_H * unit / 2;
        if (!ctx.group("dmz_reserve", "Power Reserve", x, y, BOX_W * unit, BOX_H * unit)) return;
        ctx.push();
        ctx.translate(x, y);
        ctx.scale(unit, unit);
        // frame, fill from the bottom (tinted, pulsing white while feeding), the bright top edge, then the capsule and icon
        quad(ctx, 0, 0, 23, 150, 0, CAPSULE - BORDER, 23, 150, 0xFFFFFF, vis);
        if (frac > 0) {
            var fh = BAR_H * frac;
            ctx.quad(SHEET, BORDER, CAPSULE + BAR_H - fh, BAR_W, fh, 25 / SW, (BAR_H - fh) / SH, 42 / SW, BAR_H / SH, hex(mix(color, 0xFFFFFF, pulse * 0.35)), vis);
            ctx.quad(SHEET, BORDER, CAPSULE + BAR_H - fh, BAR_W, Math.min(1, fh), 25 / SW, 0, 42 / SW, 1 / SH, "#FFFFFF", vis * 0.7);
        }
        quad(ctx, 63, 0, 23, 23, 0, 0, 23, 23, 0xFFFFFF, vis);
        quad(ctx, 88, 0, 17, 17, BORDER, BORDER, 17, 17, mix(color, 0xFFFFFF, 0.45), vis);
        if (!opt("dmz_hud_hide_numbers", false))
            ctx.textStyled(Math.round(frac * 100) + "%", CAPSULE / 2, CAPSULE + BAR_H + BORDER + 2, 0.5, hex(mix(color, 0xFFFFFF, 0.7)), vis, 0.5, null, "#000000");
        ctx.pop();
        ctx.endGroup();
    }
    RPG.on("load", function () { RPG.hud.onRender(renderReserve); });

    // ---- BioSwellRenderState: the body swells (root bone), eased like DMZ ----
    var BODY_GROWTH = 0.30, EASE = 0.18, SHAKE_RANGE_MULT = 1.5, BLAST_RADIUS = 36;
    if (typeof DBR_ANIMATOR !== "undefined") DBR_ANIMATOR.extend(function (pl, out, m) {
        var target = clamp(num(pl.shared("bioSwell", 0), 0), 0, 1), cur = m.bioSwell || 0;
        if (target <= 0 && cur <= 0.001) { m.bioSwell = 0; return; }
        if (m.bioTick !== pl.tick) { m.bioTick = pl.tick; cur = cur + (target - cur) * EASE; m.bioSwell = cur; }
        if (cur > 0.001) out.bones.root = { scale: 1 + cur * BODY_GROWTH };
    });

    // dust and rubble around a swelling body; camera shake for the one charging and anyone near
    RPG.on("tick", function () {
        if (!RPG.player.present) return;
        var me = RPG.player, shook = false;
        RPG.avatar.players().forEach(function (pl) {
            var sw = clamp(num(pl.shared("bioSwell", 0), 0), 0, 1);
            if (sw <= 0.02) return;
            if (Math.random() < 0.6) RPG.particle("minecraft:campfire_cosy_smoke", pl.x, pl.y + 0.2, pl.z, 1, 0.6 + sw, 0.01);
            if (pl.onGround && Math.random() < 0.35 + sw * 0.4) RPG.particle("minecraft:poof", pl.x + (Math.random() - 0.5) * 3, pl.y + 0.1, pl.z + (Math.random() - 0.5) * 3, 1, 0.2, 0.02);
            if (shook) return;
            var intensity;
            if (pl.local) intensity = sw;
            else {
                var dx = pl.x - me.x, dy = pl.y - me.y, dz = pl.z - me.z, d = Math.sqrt(dx * dx + dy * dy + dz * dz), r = BLAST_RADIUS * SHAKE_RANGE_MULT;
                if (d > r) return;
                intensity = (1 - d / r) * sw * 0.6;
            }
            if (intensity > 0.02) { RPG.camera.shake(intensity * 1.2, 2); shook = true; }
        });
    });
})();
