// =====================================================================================
//  DBR - DMZ Ragnarok's tab list and prefix badges (client)
// =====================================================================================
//  Port of DMZ Ragnarok's (GPL-3.0) MixinPlayerTabOverlay and RankClientEvents
//  (shuruisutilities core/mixin/client, ranks/client): the vanilla layout with
//    - each row's bar 14 pixels tall (the 12-pixel rank badge with 1 pixel of bar above
//      and below, RankBadgeMetrics), rows 15 apart, face / name / ping on one line,
//      the badge dead-centre (text drawn 3 pixels below the bar top),
//    - most senior rank first, vanilla's own order within a rank (a stable sort),
//    - the server banner across the top (up to 32 pixels tall, half the width at most),
//      above the header; header and footer keep vanilla's 9-pixel lines,
//    - rank badges 12 pixels tall in the tab list and over heads (DMZ Ragnarok's
//      "ranks" font); chat keeps them one line tall (a chat row is 9 pixels here).
//  Badges and prefixes are the Ranks & Kits rank's (rank editor: /rank); the badge art
//  (resources/assets/dbr/textures/badges/dmzr/) is DMZ Ragnarok's.
// =====================================================================================
var DBR_TABLIST = (function () {
    var BADGE_H = 12;                 // RankBadgeMetrics.HEIGHT
    var BG_H = BADGE_H + 2;           // a row's coloured bar
    var ROW_H = BG_H + 1;             // row pitch
    var CONTENT_Y = 3;                // RankBadgeMetrics.PAD - GLYPH_TOP_OFFSET: text (and the badge) from the bar top
    var BANNER_MAX_H = 32;
    var HALF_BLACK = "#80000000";     // Integer.MIN_VALUE, vanilla's header / list backdrop

    function cfg(key, fallback) { try { var v = RPG.config.get("dbr_tablist", key, fallback); return v === undefined || v === null ? fallback : v; } catch (e) { return fallback; } }

    /** How senior a row's rank is: Ranks & Kits names its rank teams rkNNNN_<id> with NNNN = 9999 - tab order. */
    function seniority(row) {
        var m = /^rk(\d{4})_/.exec(row.team || "");
        return m ? 9999 - Number(m[1]) : -1;
    }

    function render(ctx, tab) {
        if (tab.alone && !cfg("showAlone", true)) return;
        var width = tab.width;
        var list = tab.rows.map(function (r, i) { r.order = i; return r; });
        list.sort(function (a, b) { return seniority(b) - seniority(a) || a.order - b.order; });

        var nameW = 0, scoreW = 0, hasScore = false;
        list.forEach(function (r) {
            nameW = Math.max(nameW, ctx.richWidth(r.text, BADGE_H));
            if (r.score !== null && r.score !== undefined) { hasScore = true; if (!tab.hearts) scoreW = Math.max(scoreW, ctx.textWidth(" " + r.score)); }
        });
        var count = list.length, rows = count, cols;
        for (cols = 1; rows > 20; rows = Math.floor((count + cols - 1) / cols)) ++cols;
        var secure = tab.secure;
        var extra = hasScore ? (tab.hearts ? 90 : scoreW) : 0;
        var colW = Math.floor(Math.min(cols * ((secure ? 9 : 0) + nameW + extra + 13), width - 50) / cols);
        var left = Math.floor(width / 2) - Math.floor((colW * cols + (cols - 1) * 5) / 2);
        var y = 10;
        var bgW = colW * cols + (cols - 1) * 5;

        var headerLines = tab.header ? ctx.richLines(tab.header, width - 50) : null;
        if (headerLines) headerLines.forEach(function (l) { bgW = Math.max(bgW, ctx.richWidth(l)); });
        var footerLines = tab.footer ? ctx.richLines(tab.footer, width - 50) : null;
        if (footerLines) footerLines.forEach(function (l) { bgW = Math.max(bgW, ctx.richWidth(l)); });
        var half = Math.floor(width / 2), hb = Math.floor(bgW / 2);

        // the server's banner across the top, above the header
        var banner = String(cfg("banner", "") || "");
        var size = banner ? RPG.images.size(banner) : null;
        if (size) {
            var scale = Math.min(Math.min((width - 50) / 2 / size.w, BANNER_MAX_H / size.h), 1);
            var bw = Math.max(1, Math.round(size.w * scale)), bh = Math.max(1, Math.round(size.h * scale));
            ctx.image(banner, half - Math.floor(bw / 2), y, bw, bh, 0, 0, size.w, size.h, size.w, size.h);
            y += bh + 2;
            bgW = Math.max(bgW, bw); hb = Math.floor(bgW / 2);
        }

        if (headerLines) {
            ctx.rect(half - hb - 1, y - 1, hb * 2 + 2, headerLines.length * 9 + 1, HALF_BLACK);
            headerLines.forEach(function (l) { ctx.rich(l, half - Math.floor(ctx.richWidth(l) / 2), y, "#FFFFFFFF", true); y += 9; });
            ++y;
        }

        ctx.rect(half - hb - 1, y - 1, hb * 2 + 2, rows * ROW_H + 1, HALF_BLACK);
        for (var i = 0; i < count; i++) {
            var col = Math.floor(i / rows), row = i % rows;
            var cx = left + col * colW + col * 5, cy = y + row * ROW_H;
            ctx.rect(cx, cy, colW, BG_H, tab.rowColor);
            var r = list[i], textY = cy + CONTENT_Y, x = cx;
            if (secure) { ctx.face(r.uuid, x, textY, 8); x += 9; }
            ctx.rich(r.text, x, textY, r.spectator ? "#90FFFFFF" : "#FFFFFFFF", true, BADGE_H);
            if (hasScore && !r.spectator && !tab.hearts && r.score !== null && r.score !== undefined) {
                var sx2 = x + nameW + 1 + extra, s = "&e" + r.score;
                if (extra > 5) ctx.text(s, sx2 - ctx.textWidth(s), textY, "#FFFFFF", true);
            }
            ctx.ping(r.ping, cx + colW - 11, textY);
        }

        if (footerLines) {
            y += rows * ROW_H + 1;
            ctx.rect(half - hb - 1, y - 1, hb * 2 + 2, footerLines.length * 9 + 1, HALF_BLACK);
            footerLines.forEach(function (l) { ctx.rich(l, half - Math.floor(ctx.richWidth(l) / 2), y, "#FFFFFFFF", true); y += 9; });
        }
    }

    function apply() {
        var on = cfg("enabled", true);
        if (on) RPG.tablist.onRender(render); else RPG.tablist.clear();
        // DMZ Ragnarok draws the badge in its full 12-pixel "ranks" font over heads too
        RPG.icons.height("nametag", on ? BADGE_H : 0);
    }
    apply();
    RPG.on("config", function (name) { if (name === "dbr_tablist") apply(); });
    return { render: render, apply: apply };
})();
