// =====================================================================================
//  95_dbr_rituals.js - DMZ Ragnarok's idol screen (client/gui/ShenronIdolScreen, PacketIdolPrompt / Confirm)
// =====================================================================================
//  "The Eternal Dragon's Bargain": what the namekian receives (every ball of the spent set, the Namekian God form)
//  and what it costs (levels, taken permanently), decided on the server (scripts/95_dbr_rituals.js) so the screen
//  never promises what the ritual then refuses. A refusal shows its reason and only a Close button.
// =====================================================================================
(function () {
    var FONT = "dmzpack:smooth", W = 230, H = 168;
    var REFUSAL = {
        NOT_NAMEKIAN: "Only a namekian can restore what the dragon balls lost.",
        TOO_LOW_LEVEL: "You are not strong enough to pay this price. Reach level %s.",
        NO_IDOL: "You are not carrying a Shenron Idol.",
        NOTHING_TO_RESTORE: "No dragon ball set is missing. There is nothing to restore."
    };
    function fmt(n) { return String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
    RPG.net.on("dbr_idol_prompt", function (d) {
        if (!d) return;
        var ok = d.refusal === "NONE", y0 = -H / 2, lines = [];
        var el = [
            { id: "panel", type: "rect", anchor: "center", x: -W / 2, y: y0, w: W, h: H, color: "#E0101420" },
            { id: "edge", type: "rect", anchor: "center", x: -W / 2, y: y0, w: W, h: 2, color: "#FFD24A" },
            { id: "idol", type: "item", anchor: "center", x: -W / 2 + 8, y: y0 + 8, item: (d.dragon || "shenron") + "_idol" },
            { id: "title", type: "text", anchor: "center", x: 0, y: y0 + 9, text: "&6The Eternal Dragon's Bargain", align: "center", font: FONT, scale: 1.1, outline: "#000000" },
            { id: "sub", type: "text", anchor: "center", x: 0, y: y0 + 23, text: "&7The idol answers only a namekian", align: "center", font: FONT, scale: 0.8 },
            { id: "gain", type: "text", anchor: "center", x: -W / 2 + 12, y: y0 + 42, text: "&aYou will receive", font: FONT, outline: "#000000" },
            { id: "gain1", type: "text", anchor: "center", x: -W / 2 + 18, y: y0 + 56, text: "&f- All " + d.ballCount + " dragon balls, restored to your hands", font: FONT, scale: 0.85 },
            { id: "gain2", type: "text", anchor: "center", x: -W / 2 + 18, y: y0 + 68, text: "&f- The Namekian God form", font: FONT, scale: 0.85 },
            { id: "cost", type: "text", anchor: "center", x: -W / 2 + 12, y: y0 + 86, text: "&cIt will cost you", font: FONT, outline: "#000000" },
            { id: "cost1", type: "text", anchor: "center", x: -W / 2 + 18, y: y0 + 100, text: "&f- " + fmt(d.levelCost) + " levels, taken permanently", font: FONT, scale: 0.85 },
            { id: "cost2", type: "text", anchor: "center", x: -W / 2 + 18, y: y0 + 112, text: (d.level >= d.requiredLevel ? "&7" : "&c") + "- Your level: " + fmt(d.level) + " (need " + fmt(d.requiredLevel) + ")", font: FONT, scale: 0.85 }
        ];
        if (!ok) el.push({ id: "why", type: "text", anchor: "center", x: 0, y: y0 + 126, text: "&c" + String(REFUSAL[d.refusal] || "").replace("%s", fmt(d.requiredLevel)), align: "center", font: FONT, scale: 0.8, wrap: W - 16 });
        if (ok) {
            el.push({ id: "accept", type: "button", anchor: "center", x: -W / 2 + 18, y: y0 + H - 26, w: 90, h: 18, label: "Accept",
                onClick: function () { RPG.net.send("dbr_idol_confirm", { dragon: d.dragon }); RPG.screen.close(); } });
            el.push({ id: "cancel", type: "button", anchor: "center", x: W / 2 - 108, y: y0 + H - 26, w: 90, h: 18, label: "Not yet", onClick: function () { RPG.screen.close(); } });
        } else el.push({ id: "close", type: "button", anchor: "center", x: -45, y: y0 + H - 26, w: 90, h: 18, label: "Close", onClick: function () { RPG.screen.close(); } });
        RPG.screen.open({ id: "dbr_idol", background: "dim", closeOnEsc: true, elements: el });
    });
})();
