// =====================================================================================
//  53_dmz_minigames.js - DragonMine Z's training minigames (client side): the game
//  screens, Old Kai's challenge, the rhythm song picker and audio calibration, and the
//  V menu's Minigames tab.
// =====================================================================================
//  Ported from DragonMine Z (GPL-3.0): client/gui/character/minigames/BaseMinigameScreen,
//  RythmGameScreen, ControlGameScreen, MemoryGameScreen, PrecisionGameScreen,
//  GravityGameScreen, RhythmCalibrationScreen, UltimateChallenge, SmoothValue and
//  client/gui/character/MinigamesScreen. Textures: dmzpack:textures/gui/minigame/*.png.
//
//  The game runs here at 20 ticks a second with the server's seed (shared/13_dmz_minigames.js);
//  every input is stamped with its tick and sent once a second, and the server replays them
//  (scripts/67_dmz_minigames.js) before paying TP.
// =====================================================================================
var DMZ_MG_CLIENT = (function () {
    var U = DMZ_UI, MG = DMZ_MG, FONT = U.FONT, R = MG.RHYTHM;
    var BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var SHEETS = { rhythm: "rhythm", control: "control", memory: "memory", precision: "precision", gravity: "gravity" };
    function sheet(game) { return "dmzpack:textures/gui/minigame/" + (SHEETS[game] || "rhythm") + ".png"; }
    var BUTTON_W = 74, BUTTON_H = 20, INFO_LINE_Y = 53, HUD_RESERVE = 66, UI_V = 240;
    var FILL_GOLD = 0, FILL_GREEN = 1, FILL_CYAN = 2, FILL_RED = 3;
    var PAUSE_FADE = 0.3, PAUSE_CLOSE = 0.25, COUNTDOWN_SECONDS = 3, KEEP_ALIVE_TICKS = 100;
    var RESULTS_FADE = 0.35, RESULTS_LINE_DELAY = 0.06, RESULTS_INPUT_DELAY = 0.45;
    var FLUSH_INTERVAL_TICKS = 20, CONNECT_TIMEOUT_TICKS = 100, VERIFY_TIMEOUT_TICKS = 100;

    var sg = U.seg;
    var SMALL_PANEL = U.Skin("dmzpack:textures/gui/menu/menusmall.png", 256, 256, 0, 0,
        [sg.fixed(14), sg.tile(63), sg.decor(28, 0), sg.tile(21), sg.fixed(15)],
        [sg.fixed(14), sg.band(21), sg.fixed(7), sg.decor(28, 0), sg.tile(7), sg.fixed(17)]);
    var NPC_PANEL = U.Skin("dmzpack:textures/gui/menu/menunpc.png", 512, 512, 0, 0,
        [sg.fixed(14), sg.tile(63), sg.decor(28, 1), sg.tile(175), sg.decor(28, 2), sg.tile(22), sg.fixed(15)],
        [sg.fixed(14), sg.band(21), sg.fixed(7), sg.decor(35, 0), sg.fixed(17)]);

    // ---- small helpers -----------------------------------------------------------------
    function now() { return RPG.nowMs(); }
    function secs(t) { return !t ? 99 : (now() - t) / 1000; }
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function tr() { return U.tr.apply(null, arguments); }
    function hex(rgb) { var s = (rgb & 0xFFFFFF).toString(16); while (s.length < 6) s = "0" + s; return "#" + s.toUpperCase(); }
    function T(ctx, text, x, y, color, alpha, scale, align) {
        ctx.textStyled(String(text), x, y, scale || 1, color, alpha === undefined ? 1 : Math.max(0.03, alpha), align === undefined ? 0.5 : align, FONT, "#000000");
    }
    /** DMZ's "translate(x, y + 4); scale(s); draw at -4": text centred on its middle line */
    function TS(ctx, text, x, y, scale, color, alpha) { T(ctx, text, x, y + 4 - 4 * scale, color, alpha, scale, 0.5); }
    function W(ctx, text) { return U.width(ctx, String(text)); }
    function blit(ctx, tex, x, y, w, h, u, v, uw, vh, tint, alpha) {
        if (w <= 0 || h <= 0 || uw <= 0 || vh <= 0) return;
        ctx.quad(tex, x, y, w, h, u / 256, v / 256, (u + uw) / 256, (v + vh) / 256, tint || "#FFFFFF", alpha === undefined ? 1 : alpha);
    }
    function rect(ctx, x, y, w, h, color, alpha) { if (w > 0 && h > 0) ctx.fill(x, y, w, h, color, alpha === undefined ? 1 : alpha); }
    function outline(ctx, x, y, w, h, t, color, alpha) {
        rect(ctx, x, y, w, t, color, alpha); rect(ctx, x, y + h - t, w, t, color, alpha);
        rect(ctx, x, y + t, t, h - 2 * t, color, alpha); rect(ctx, x + w - t, y + t, t, h - 2 * t, color, alpha);
    }
    function ring(ctx, cx, cy, r, thick, color, alpha) { if (r > 0) ctx.arc(cx, cy, Math.max(0, r - thick), r, 0, 360, color, alpha); }
    function disc(ctx, cx, cy, r, color, alpha) { if (r > 0) ctx.arc(cx, cy, 0, r, 0, 360, color, alpha); }
    function lerp(a, b, t) { return a + (b - a) * t; }
    function mixRgb(a, b, t) {
        var r = Math.round(lerp((a >> 16) & 255, (b >> 16) & 255, t)), g = Math.round(lerp((a >> 8) & 255, (b >> 8) & 255, t)), bl = Math.round(lerp(a & 255, b & 255, t));
        return (r << 16) | (g << 8) | bl;
    }
    /** a vertical-gradient quad (TL, TR, BR, BL), as a few slices */
    function quadGrad(ctx, x0, y0, x1, y1, x2, y2, x3, y3, topRgb, topA, botRgb, botA) {
        var n = Math.abs(topRgb - botRgb) + Math.abs(topA - botA) < 0.0001 ? 1 : 5;
        for (var i = 0; i < n; i++) {
            var t0 = i / n, t1 = (i + 1) / n, tm = (t0 + t1) / 2;
            ctx.poly([lerp(x0, x3, t0), lerp(y0, y3, t0), lerp(x1, x2, t0), lerp(y1, y2, t0), lerp(x1, x2, t1), lerp(y1, y2, t1), lerp(x0, x3, t1), lerp(y0, y3, t1)],
                hex(mixRgb(topRgb, botRgb, tm)), lerp(topA, botA, tm));
        }
    }
    function easeOut(t) { var u = 1 - clamp(t, 0, 1); return 1 - u * u * u; }
    function easeOutBack(t) { t = clamp(t, 0, 1); var c1 = 1.70158, c3 = c1 + 1, u = t - 1; return 1 + c3 * u * u * u + c1 * u * u; }
    function floorMod(a, n) { return ((a % n) + n) % n; }
    function inside(r, x, y) { return !!r && x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3]; }
    function playUi(sound, pitch, volume) { RPG.sound(sound, volume, pitch); }
    function playHit(perfect) { playUi("minecraft:entity.experience_orb.pickup", perfect ? 1.5 : 1.0, 0.3); }
    function playMiss() { playUi("minecraft:block.note_block.bass", 0.5, 0.4); }
    function click() { playUi("minecraft:ui.button.click", 1.0, 0.5); }
    function store(key, fallback) { try { return RPG.storage.get(key, fallback); } catch (e) { return fallback; } }
    function storeSet(key, v) { try { RPG.storage.set(key, v); } catch (e) { } }

    /** SmoothValue */
    function Smooth() { this.value = 0; this.init = false; this.last = 0; }
    Smooth.prototype.update = function (target, speed) {
        var t = now();
        if (!this.init) { this.value = target; this.init = true; this.last = t; return target; }
        var dt = Math.min(0.1, (t - this.last) / 1000);
        this.last = t;
        this.value += (target - this.value) * (1 - Math.exp(-dt * speed));
        return this.value;
    };
    Smooth.prototype.snap = function (v) { this.value = v; this.init = true; this.last = now(); };

    function drawBarH(ctx, tex, x, y, w, pct, fill) {
        pct = clamp(pct, 0, 1);
        blit(ctx, tex, x, y, 4, 9, 0, UI_V, 4, 9);
        blit(ctx, tex, x + 4, y, w - 8, 9, 4, UI_V, 1, 9);
        blit(ctx, tex, x + w - 4, y, 4, 9, 5, UI_V, 4, 9);
        var inner = (w - 4) * pct;
        if (inner > 0) {
            blit(ctx, tex, x + 2, y + 2, inner, 5, 18 + fill, UI_V, 1, 5);
            if (pct < 1) rect(ctx, x + 2 + inner - 1, y + 2, 1, 5, "#FFFFFF", 0.69);
        }
    }
    function drawBarV(ctx, tex, x, y, h, pct, fill) {
        pct = clamp(pct, 0, 1);
        blit(ctx, tex, x, y, 9, 4, 9, UI_V, 9, 4);
        blit(ctx, tex, x, y + 4, 9, h - 8, 9, UI_V + 4, 9, 1);
        blit(ctx, tex, x, y + h - 4, 9, 4, 9, UI_V + 5, 9, 4);
        var inner = (h - 4) * pct;
        if (inner > 0) {
            blit(ctx, tex, x + 2, y + 2 + (h - 4) - inner, 5, inner, 24, UI_V + fill, 5, 1);
            if (pct < 1) rect(ctx, x + 2, y + 2 + (h - 4) - inner, 5, 1, "#FFFFFF", 0.69);
        }
    }
    function drawHearts(ctx, tex, cx, y, lives, max, scale, lostAt) {
        var step = 9 * scale, x0 = cx - (max * step - 2 * scale) / 2, lostAge = secs(lostAt);
        for (var i = 0; i < max; i++) {
            var s = scale, dy = 0;
            if (i === lives && lostAge < 0.5) { s *= 1 + 0.5 * (1 - lostAge / 0.5); dy = -4 * (1 - lostAge / 0.5); }
            var size = 7 * s;
            blit(ctx, tex, x0 + i * step + (7 * scale - size) / 2, y + dy + (7 * scale - size) / 2, size, size, i < lives ? 32 : 40, UI_V, 7, 7);
        }
    }
    function legend(ctx, key, cx, y) { T(ctx, tr(key), cx, y, "#B8C0DC", 1, 0.75); }
    function gradeLetter(p) { return p >= 0.9 ? "S" : p >= 0.75 ? "A" : p >= 0.55 ? "B" : p >= 0.35 ? "C" : "D"; }
    function gradeColor(g) { return g === "S" ? "#FFD700" : g === "A" ? "#55FF55" : g === "B" ? "#7CFDD6" : g === "C" ? "#FFAA55" : "#FF5555"; }
    function mmss(seconds) { seconds = Math.max(0, Math.floor(seconds)); var s = seconds % 60; return Math.floor(seconds / 60) + ":" + (s < 10 ? "0" : "") + s; }
    function panel(ctx, cx, cy, contentW, contentH, alpha) {
        var w = contentW + 32, h = contentH + 32;
        NPC_PANEL.draw(ctx, cx - w / 2, cy - h / 2, w, h, alpha);
    }
    function wrap(ctx, text, width) { return U.wrap(ctx, text, width); }

    // ===================================================================================
    //  The game screen (BaseMinigameScreen)
    // ===================================================================================
    var S = null;              // the open screen's state
    var SCREEN_ID = "dmz_minigame";

    function fresh(d) {
        return {
            game: String(d.game), origin: String(d.origin || "MENU"), npc: d.npc || null, stage: Math.floor(Number(d.stage) || 0),
            stages: Math.floor(Number(d.stages) || MG.CHALLENGE_STAGES.length), cfg: MG.mergeCfg(d.cfg), known: !!d.known, tracks: d.tracks || [],
            st: "READY", logic: null, sid: -1, chunkStart: 0, wait: 0, outbox: [], logicalDown: [], physicalDown: {},
            startInfo: null, progressInfo: null, finalInfo: null, rejectKey: "", lastLevels: 0, hudTp: new Smooth(),
            levelPopAt: 0, gradePopAt: 0, lastGrade: "", finishedAt: 0, pausedAt: 0, pauseClosingAt: 0, resumeAt: 0, pauseClosing: false,
            keepAlive: 0, lastTickAt: now(), readyScale: 1, playRect: null, resumeRect: null, finishRect: null,
            fieldScale: 1, fieldLeft: 0, fieldTop: 0, w: 0, h: 0, mx: 0, my: 0, v: {}
        };
    }
    function isChallenge() { return S && S.origin === "CHALLENGE"; }
    function running() { return S && (S.st === "PLAYING" || S.st === "PAUSED" || S.st === "RESUMING"); }
    function partial() { return S && S.st === "PLAYING" ? clamp((now() - S.lastTickAt) / 50, 0, 0.999) : 0; }
    function isPlaying() { return S && S.st === "PLAYING"; }

    function open(d) {
        if (!d || !MG.isValidId(String(d.game))) return;
        var mine = fresh(d);
        S = mine;
        GAMES[mine.game].init && GAMES[mine.game].init(mine);
        RPG.screen.open({ id: SCREEN_ID, background: "dim", pause: false, closeOnEsc: false, elements: [],
            onRender: render, onKey: onKey, onMouse: onMouse, onScroll: onScroll,
            onClose: function () { if (S === mine) removed(); } });
    }
    function removed() {
        if (running()) { flush(true); S.logic.forceFinish(); S.st = "VERIFYING"; }
        stopMusic();
        S = null;
        RPG.net.send("dmz_mg", { a: "close" });
    }
    function closeScreen() { var s = S; if (s) removed(); RPG.screen.close(); }
    function quitToHub() {
        if (isChallenge() || S.origin !== "MENU") { closeScreen(); return; }
        removed();
        RPG.net.send("dmz_mg", { a: "hub" });
    }

    function requestStart() {
        S.st = "CONNECTING"; S.wait = 0;
        var d = { a: "start", game: S.game, origin: S.origin, stage: isChallenge() ? S.stage : 0 };
        var g = GAMES[S.game];
        if (g.startOption && !isChallenge()) { var o = g.startOption(); for (var k in o) d[k] = o[k]; }
        RPG.net.send("dmz_mg", d);
    }

    RPG.net.on("dmz_mg_open", function (d) { open(d); });
    RPG.net.on("dmz_mg_start", function (d) {
        if (!S || S.st !== "CONNECTING" || !d || String(d.game) !== S.game) return;
        if (!d.ok) { S.st = "REJECTED"; S.rejectKey = String(d.reject || ""); playMiss(); return; }
        S.startInfo = d;
        S.sid = Number(d.sid);
        S.cfg = MG.mergeCfg(d.cfg);
        var chart = d.chart ? new MG.Chart(d.chart) : null;
        S.logic = MG.create(S.game, S.cfg, Number(d.seed) | 0, chart, Number(d.difficulty), Number(d.variant));
        if (Number(d.target) > 0) S.logic.setTargetLevelsCleared(Number(d.target));
        S.chunkStart = 0; S.lastLevels = 0; S.outbox = []; S.physicalDown = {}; S.logicalDown = [];
        S.st = "PLAYING"; S.lastTickAt = now();
        var g = GAMES[S.game];
        if (g.started) g.started(S);
    });
    RPG.net.on("dmz_mg_result", function (d) {
        if (!S || !d || Number(d.sid) !== S.sid) return;
        if (!d.final) { S.progressInfo = d; return; }
        S.finalInfo = d;
        enterFinished();
        if (isChallenge()) {
            if (d.challenge === "cleared") { RPG.net.send("dmz_mg", { a: "challenge_next" }); return; }
            if (d.challenge === "completed") { playUi("minecraft:ui.toast.challenge_complete", 1, 0.8); closeScreen(); return; }
            playMiss();
        } else if (d.tp > 0) playUi("minecraft:entity.player.levelup", 1.0, 0.6);
    });

    function flush(fin, keepAlive) {
        if (!S || !S.logic || S.sid < 0) return;
        var t = S.logic.tickN, chunk = [], rest = [];
        S.outbox.forEach(function (e) { if (fin || e[0] < t) chunk.push(e); else rest.push(e); });
        S.outbox = rest;
        RPG.net.send("dmz_mg", { a: "in", sid: S.sid, from: S.chunkStart, to: t, fin: !!fin, ka: !!keepAlive, ev: chunk });
        S.chunkStart = t;
    }
    function endByPlayer() {
        if (!running()) return;
        flush(true);
        S.logic.forceFinish();
        S.st = "VERIFYING"; S.wait = 0;
        stopMusic();
    }
    function pauseGame() {
        if (S.st !== "PLAYING") return;
        releaseAllHeld();
        S.st = "PAUSED"; S.pausedAt = now(); S.pauseClosing = false; S.keepAlive = 0;
        playUi("minecraft:ui.button.click", 0.8, 0.4);
    }
    function canResume() { var g = GAMES[S.game]; return !(g.canResume && !g.canResume()); }
    function requestResume() {
        if (S.st === "PAUSED" && !S.pauseClosing && canResume()) { S.pauseClosing = true; S.pauseClosingAt = now(); playUi("minecraft:ui.button.click", 1.2, 0.4); }
    }
    function releaseAllHeld() {
        for (var k = 0; k < MG.KEY_COUNT; k++) {
            if (S.logicalDown[k] > 0) emit(MG.keyEvent(S.logic.tickN, false, k, partial()), true);
            S.logicalDown[k] = 0;
        }
        S.physicalDown = {};
    }
    function enterFinished() { S.st = "FINISHED"; S.finishedAt = now(); stopMusic(); }
    function continueAfterFinish() {
        if (S.st === "FINISHED" && secs(S.finishedAt) < RESULTS_INPUT_DELAY) return;
        if (isChallenge() && S.finalInfo && S.finalInfo.challenge === "failed") { RPG.net.send("dmz_mg", { a: "challenge_restart" }); return; }
        if (isChallenge() && S.st === "REJECTED") { closeScreen(); return; }
        quitToHub();
    }

    // ---- ticking (Screen.tick) ----
    RPG.on("tick", function () {
        if (!S || RPG.screen.getOpen() !== SCREEN_ID) return;
        var g = GAMES[S.game];
        if (S.st === "CONNECTING") {
            if (++S.wait > CONNECT_TIMEOUT_TICKS) { S.st = "REJECTED"; S.rejectKey = "gui.dragonminez.minigame.reject.timeout"; }
        } else if (S.st === "PLAYING") {
            S.logic.tick();
            S.lastTickAt = now();
            if (g.tick) g.tick(S);
            if (S.logic.levelsCleared > S.lastLevels) {
                S.lastLevels = S.logic.levelsCleared; S.levelPopAt = now();
                playUi("minecraft:entity.player.levelup", 1.2, 0.5);
            }
            if (S.logic.finished) { flush(true); S.st = "VERIFYING"; S.wait = 0; stopMusic(); }
            else if (S.logic.tickN - S.chunkStart >= FLUSH_INTERVAL_TICKS) flush(false);
        } else if (S.st === "PAUSED") {
            keepAlive();
            if (S.pauseClosing && secs(S.pauseClosingAt) >= PAUSE_CLOSE) { S.st = "RESUMING"; S.resumeAt = now(); }
        } else if (S.st === "RESUMING") {
            keepAlive();
            if (secs(S.resumeAt) >= COUNTDOWN_SECONDS) { S.st = "PLAYING"; S.lastTickAt = now(); }
        } else if (S.st === "VERIFYING") {
            if (++S.wait > VERIFY_TIMEOUT_TICKS) enterFinished();
        }
        if (g.afterTick) g.afterTick(S);
    });
    function keepAlive() { if (++S.keepAlive >= KEEP_ALIVE_TICKS) { S.keepAlive = 0; flush(false, true); } }

    // ---- input ----
    function keyName(k) { var s = String(k || ""); return s.indexOf("key.keyboard.") === 0 ? s.substring(13) : s; }
    function isConfirm(n) { return n === "enter" || n === "keypad.enter" || n === "space"; }
    function defaultMap(n) {
        if (n === "mouse.0" || n === "space") return MG.ACTION;
        if (n === "left" || n === "a") return MG.LEFT;
        if (n === "right" || n === "d") return MG.RIGHT;
        if (n === "up" || n === "w") return MG.UP;
        if (n === "down" || n === "s") return MG.DOWN;
        return -1;
    }
    function pressPhysical(n) {
        var g = GAMES[S.game], mapped = g.mapKey ? g.mapKey(n) : defaultMap(n);
        var logical = mapped < 0 ? -1 : g.remap ? g.remap(mapped) : mapped;
        if (logical < 0) return false;
        if (S.physicalDown[n] !== undefined) return true;
        S.physicalDown[n] = logical;
        S.logicalDown[logical] = (S.logicalDown[logical] || 0) + 1;
        if (S.logicalDown[logical] === 1) emit(MG.keyEvent(S.logic.tickN, true, logical, partial()));
        return true;
    }
    function releasePhysical(n) {
        var logical = S.physicalDown[n];
        if (logical === undefined) return false;
        delete S.physicalDown[n];
        S.logicalDown[logical] = Math.max(0, (S.logicalDown[logical] || 0) - 1);
        if (S.logicalDown[logical] === 0) emit(MG.keyEvent(S.logic.tickN, false, logical, partial()));
        return true;
    }
    function emitClick(fx, fy) { emit(MG.clickEvent(S.logic.tickN, fx, fy, partial())); }
    function emit(e, force) {
        if (!force && S.st !== "PLAYING") return;
        if (!S.logic || S.logic.finished) return;
        S.logic.applyEvent(e);
        S.outbox.push(e);
        var g = GAMES[S.game];
        if (g.input) g.input(S, e);
    }
    function readyToUiX(mx) { var cx = S.w / 2; return cx + (mx - cx) / S.readyScale; }
    function readyToUiY(my) { var cy = S.h / 2; return cy + (my - cy) / S.readyScale; }

    function onKey(k, action) {
        if (!S) return;
        var n = keyName(k), g = GAMES[S.game];
        if (S.calib) { if (action === "down") calibKey(n); return false; }
        if (action === "up") {
            if (S.st === "PLAYING") { if (g.keyUp) g.keyUp(n); releasePhysical(n); }
            return false;
        }
        switch (S.st) {
            case "READY":
                if (n === "escape") quitToHub();
                else if (!(g.readyKey && g.readyKey(n)) && isConfirm(n) && canPlay()) { click(); requestStart(); }
                return false;
            case "CONNECTING": case "PREPARING": case "VERIFYING":
                if (n === "escape") quitToHub();
                return false;
            case "PAUSED":
                if (n === "escape" || isConfirm(n)) requestResume();
                return false;
            case "RESUMING":
                if (n === "escape") { S.st = "PAUSED"; S.pausedAt = now(); S.pauseClosing = false; }
                return false;
            case "PLAYING":
                if (n === "escape") { pauseGame(); return false; }
                if (g.playingKey && g.playingKey(n)) return false;
                pressPhysical(n);
                return false;
            default:
                continueAfterFinish();
                return false;
        }
    }
    function onMouse(x, y, button, action) {
        if (!S) return;
        S.mx = x; S.my = y;
        if (action === "drag") { if (S.st === "READY" && GAMES[S.game].readyDrag) GAMES[S.game].readyDrag(readyToUiX(x), readyToUiY(y)); return; }
        var n = "mouse." + button, g = GAMES[S.game];
        if (action === "up") {
            if (S.st === "READY" && g.readyRelease) g.readyRelease();
            if (S.st === "PLAYING") releasePhysical(n);
            return false;
        }
        if (S.calib) { calibClick(x, y); return false; }
        switch (S.st) {
            case "READY":
                var ux = readyToUiX(x), uy = readyToUiY(y);
                if (g.readyClick && g.readyClick(ux, uy)) return false;
                if (inside(S.playRect, ux, uy)) {
                    if (!canPlay()) { playMiss(); return false; }
                    click(); requestStart();
                }
                return false;
            case "PAUSED":
                if (S.pauseClosing) return false;
                var px = readyToUiX(x), py = readyToUiY(y);
                if (inside(S.resumeRect, px, py)) requestResume();
                else if (inside(S.finishRect, px, py)) { playUi("minecraft:ui.button.click", 0.9, 0.5); endByPlayer(); }
                return false;
            case "RESUMING": return false;
            case "FINISHED": case "REJECTED": continueAfterFinish(); return false;
            case "PLAYING":
                if (g.usesClicks) { if (button === 0) emitClick((x - S.fieldLeft) / S.fieldScale, (y - S.fieldTop) / S.fieldScale); }
                else pressPhysical(n);
                return false;
        }
        return false;
    }
    function onScroll(x, y, delta) { if (S && S.st === "READY" && GAMES[S.game].readyScroll) GAMES[S.game].readyScroll(readyToUiX(x), readyToUiY(y), delta); }
    function canPlay() { var g = GAMES[S.game]; return !g.canPlay || g.canPlay(); }

    function layoutField(fw, fh, topReserve, bottomReserve, maxScale) {
        var availW = S.w - 20, availH = Math.max(40, S.h - topReserve - bottomReserve);
        S.fieldScale = Math.min(maxScale, Math.min(availW / fw, availH / fh));
        S.fieldLeft = (S.w - fw * S.fieldScale) / 2;
        S.fieldTop = topReserve + (availH - fh * S.fieldScale) / 2;
    }
    function pushField(ctx) { ctx.push(); ctx.translate(S.fieldLeft, S.fieldTop); ctx.scale(S.fieldScale, S.fieldScale); }

    // ---- render ----
    function render(ctx) {
        if (!S) return;
        S.w = ctx.width; S.h = ctx.height; S.mx = ctx.mouseX; S.my = ctx.mouseY;
        var g = GAMES[S.game];
        if (g.layout) g.layout(S);
        if (S.logic) g.render(ctx, partial());
        T(ctx, tr("gui.dragonminez.minigame." + S.game + ".howto"), S.w / 2, S.h - 16, "#B0B0B0", 1, 1);
        T(ctx, "§l" + tr("gui.dragonminez.minigame." + S.game), S.w / 2, 14, "#FFD700", 1, 3);
        if (running() || S.st === "VERIFYING") runningHud(ctx);
        switch (S.st) {
            case "READY": readyOverlay(ctx); break;
            case "PAUSED": pauseOverlay(ctx); break;
            case "RESUMING": countdown(ctx); break;
            case "CONNECTING": messageOverlay(ctx, tr("gui.dragonminez.minigame.connecting"), "#FFFFFF"); break;
            case "VERIFYING": messageOverlay(ctx, tr("gui.dragonminez.minigame.verifying"), "#FFFFFF"); break;
            case "FINISHED": finishedOverlay(ctx); break;
            case "REJECTED": messageOverlay(ctx, tr(S.rejectKey || "gui.dragonminez.minigame.reject.unavailable"), "#FF7777"); break;
        }
        if (S.calib) calibRender(ctx);
    }

    function runningHud(ctx) {
        var L = S.logic;
        if (!L) return;
        var cx = S.w / 2, grade = gradeLetter(L.performance);
        if (grade !== S.lastGrade) { if (S.lastGrade) S.gradePopAt = now(); S.lastGrade = grade; }
        var la = secs(S.levelPopAt), ga = secs(S.gradePopAt);
        var ls = la < 0.45 ? 1 + 0.6 * Math.exp(-la * 9) : 1, gs = ga < 0.45 ? 1 + 0.5 * Math.exp(-ga * 9) : 1;
        var lt = tr("gui.dragonminez.training.level", L.level()), gt = tr("gui.dragonminez.minigame.grade", grade);
        var lw = W(ctx, lt), gw = W(ctx, gt), gap = 16;
        var lx = cx - (lw + gap + gw) / 2 + lw / 2, gx = lx + lw / 2 + gap + gw / 2;
        TS(ctx, lt, lx, 40, ls, la < 0.45 ? "#FFFFFF" : "#FFD700");
        TS(ctx, gt, gx, 40, gs, gradeColor(grade));
        var parts = [];
        if (S.progressInfo && S.progressInfo.tp > 0) parts.push([tr("gui.dragonminez.minigame.tps_so_far", Math.round(S.hudTp.update(S.progressInfo.tp, 5))), "#55FF55"]);
        var si = S.startInfo;
        if (si && si.mentor) parts.push([tr("gui.dragonminez.minigame.mentor_bonus", Math.round(S.cfg.mentorBonus * 100)), "#7CFDD6"]);
        if (si && !si.known && S.origin === "MASTER")
            parts.push([tr("gui.dragonminez.minigame.learning", si.runs, si.needRuns, si.needLevel), L.level() >= si.needLevel ? "#55FF55" : "#FFAA55"]);
        if (si && isChallenge() && si.target > 0)
            parts.push([tr("gui.dragonminez.minigame.challenge_stage", S.stage + 1, S.stages, Math.min(L.levelsCleared, si.target), si.target), "#FFD700"]);
        if (!parts.length) return;
        var sep = "  •  ", total = 0;
        parts.forEach(function (p, i) { total += W(ctx, p[0]) + (i ? W(ctx, sep) : 0); });
        var x = cx - total / 2;
        parts.forEach(function (p, i) {
            if (i) { T(ctx, sep, x, INFO_LINE_Y, "#8890A8", 1, 1, 0); x += W(ctx, sep); }
            T(ctx, p[0], x, INFO_LINE_Y, p[1], 1, 1, 0); x += W(ctx, p[0]);
        });
    }

    function drawButton(ctx, r, label, alpha, mx, my) {
        var hover = alpha > 0.5 && inside(r, mx, my);
        blit(ctx, BUTTONS, r[0], r[1], BUTTON_W, BUTTON_H, 0, hover ? 48 : 28, BUTTON_W, BUTTON_H, "#FFFFFF", alpha);
        T(ctx, label, r[0] + r[2] / 2, r[1] + 6, hover ? "#FFD700" : "#FFFFFF", alpha);
        return hover;
    }
    function scaledAround(ctx, scale, dy) {
        var cx = S.w / 2, cy = S.h / 2;
        ctx.push(); ctx.translate(cx, cy + (dy || 0)); ctx.scale(scale, scale); ctx.translate(-cx, -cy);
    }

    function readyOverlay(ctx) {
        rect(ctx, 0, 0, S.w, S.h, "#000000", 0.73);
        var g = GAMES[S.game];
        if (g.readyCustom && !isChallenge() && g.readyCustom(ctx)) { S.playRect = null; return; }
        var cx = S.w / 2, cy = S.h / 2, wrapW = Math.max(120, Math.min(260, S.w - 90));
        var lines = wrap(ctx, tr("gui.dragonminez.minigame." + S.game + ".howto"), wrapW);
        var contentH = 16 + lines.length * 10 + 6 + BUTTON_H;
        var scale = Math.min(1, (S.h - 40) / (contentH + 32));
        S.readyScale = scale;
        var mx = readyToUiX(S.mx), my = readyToUiY(S.my);
        scaledAround(ctx, scale);
        panel(ctx, cx, cy, wrapW + 20, contentH);
        var top = cy - contentH / 2;
        T(ctx, tr("gui.dragonminez.minigame.start"), cx, top, "#FFD700");
        var y = top + 16;
        lines.forEach(function (l) { T(ctx, l, cx, y, "#B0B0B0"); y += 10; });
        S.playRect = [cx - BUTTON_W / 2, y + 6, BUTTON_W, BUTTON_H];
        drawButton(ctx, S.playRect, tr("gui.dragonminez.minigame.play"), canPlay() ? 1 : 0.35, mx, my);
        ctx.pop();
    }

    function pauseOverlay(ctx) {
        var appear = S.pauseClosing ? 1 - easeOut(secs(S.pauseClosingAt) / PAUSE_CLOSE) : easeOut(secs(S.pausedAt) / PAUSE_FADE);
        rect(ctx, 0, 0, S.w, S.h, "#000000", 0.78 * appear);
        if (appear <= 0.02) return;
        var cx = S.w / 2, cy = S.h / 2, wrapW = Math.max(120, Math.min(260, S.w - 90)), L = S.logic;
        var rules = wrap(ctx, tr("gui.dragonminez.minigame." + S.game + ".howto"), wrapW);
        var progress = tr("gui.dragonminez.minigame.summary", L ? L.level() : 1, mmss(L ? L.tickN / 20 : 0), L ? gradeLetter(L.performance) : "-");
        var tpLine = S.progressInfo && S.progressInfo.tp > 0 ? tr("gui.dragonminez.minigame.tps_so_far", Math.round(S.hudTp.value)) : null;
        var contentH = 18 + 12 + (tpLine ? 12 : 0) + 8 + rules.length * 10 + 10 + BUTTON_H;
        var fit = Math.min(1, (S.h - 40) / (contentH + 32)), scale = fit * (0.9 + 0.1 * easeOutBack(Math.min(1, secs(S.pausedAt) / PAUSE_FADE)));
        S.readyScale = scale;
        var mx = readyToUiX(S.mx), my = readyToUiY(S.my);
        scaledAround(ctx, scale, (1 - appear) * 14);
        panel(ctx, cx, cy, wrapW + 20, contentH, Math.max(0.02, appear));
        var y = cy - contentH / 2;
        T(ctx, tr("gui.dragonminez.minigame.paused"), cx, y, "#FFD700", appear); y += 18;
        T(ctx, progress, cx, y, "#FFFFFF", appear); y += 12;
        if (tpLine) { T(ctx, tpLine, cx, y, "#55FF55", appear); y += 12; }
        y += 8;
        rules.forEach(function (l) { T(ctx, l, cx, y, "#B0B0B0", appear); y += 10; });
        y += 10;
        S.resumeRect = [cx - BUTTON_W - 6, y, BUTTON_W, BUTTON_H];
        S.finishRect = [cx + 6, y, BUTTON_W, BUTTON_H];
        drawButton(ctx, S.resumeRect, tr("gui.dragonminez.minigame.resume"), canResume() ? appear : Math.min(appear, 0.35), mx, my);
        drawButton(ctx, S.finishRect, tr("gui.dragonminez.minigame.finish"), appear, mx, my);
        ctx.pop();
    }

    function countdown(ctx) {
        var el = secs(S.resumeAt), dim = 1 - Math.min(1, el / COUNTDOWN_SECONDS);
        rect(ctx, 0, 0, S.w, S.h, "#000000", 0.44 * dim);
        var n = Math.max(1, Math.ceil(COUNTDOWN_SECONDS - el)), within = el - Math.floor(el);
        var pop = 1 + 0.8 * Math.exp(-within * 7), alpha = within > 0.75 ? 1 - (within - 0.75) / 0.25 : 1;
        TS(ctx, String(n), S.w / 2, S.h / 2 - 4, 3.5 * pop, "#FFD700", alpha);
    }

    function messageOverlay(ctx, message, color) {
        rect(ctx, 0, 0, S.w, S.h, "#000000", 0.6);
        var cx = S.w / 2, cy = S.h / 2, lines = wrap(ctx, message, 260);
        panel(ctx, cx, cy, 280, lines.length * 10 + 4);
        var y = cy - lines.length * 5;
        lines.forEach(function (l) { T(ctx, l, cx, y, color); y += 10; });
    }

    function finishedOverlay(ctx) {
        var el = secs(S.finishedAt), appear = easeOut(el / RESULTS_FADE);
        rect(ctx, 0, 0, S.w, S.h, "#000000", 0.73 * appear);
        var cx = S.w / 2, cy = S.h / 2, lines = [], f = S.finalInfo;
        var failed = f && f.challenge === "failed";
        if (failed) lines.push([tr("gui.dragonminez.minigame.challenge_failed"), "#FF7777"]);
        else if (!f) lines.push([tr("gui.dragonminez.minigame.unverified"), "#FFAA55"]);
        else if (f.invalid) lines.push([tr("gui.dragonminez.minigame.invalid"), "#FF7777"]);
        else {
            lines.push([tr("gui.dragonminez.minigame.summary", f.levels + 1, mmss(f.ticks / 20), gradeLetter(f.perf)), "#FFFFFF"]);
            lines.push([tr("gui.dragonminez.minigame.tps_won", f.tp), "#55FF55"]);
            var g = GAMES[S.game];
            if (g.resultLines) g.resultLines(lines);
            if (f.mentor) lines.push([tr("gui.dragonminez.minigame.mentor_bonus", Math.round(S.cfg.mentorBonus * 100)), "#7CFDD6"]);
            var si = S.startInfo;
            if (f.learned) lines.push([tr("gui.dragonminez.minigame.learned", tr("gui.dragonminez.minigame." + S.game)), "#FFD700"]);
            else if (si && !si.known && S.origin === "MASTER")
                lines.push([tr(f.counted ? "gui.dragonminez.minigame.learn_counted" : "gui.dragonminez.minigame.learn_not_counted", f.runs, f.needRuns, si.needLevel), f.counted ? "#55FF55" : "#FFAA55"]);
        }
        var contentH = 30 + lines.length * 14, scale = 0.85 + 0.15 * easeOutBack(el / RESULTS_FADE);
        scaledAround(ctx, scale, (1 - appear) * 18);
        panel(ctx, cx, cy, 280, contentH, Math.max(0.02, appear));
        var y = cy - contentH / 2 + 2;
        if (appear > 0.05) T(ctx, tr("gui.dragonminez.minigame.finished"), cx, y, "#FFD700", appear);
        y += 16;
        lines.forEach(function (l, i) {
            var la = easeOut((el - RESULTS_FADE * 0.5 - i * RESULTS_LINE_DELAY) / 0.25);
            if (la > 0.05) T(ctx, l[0], cx - (1 - la) * 10, y, l[1], la);
            y += 14;
        });
        var pa = easeOut((el - RESULTS_INPUT_DELAY) / 0.3);
        if (pa > 0.05) T(ctx, tr(failed ? "gui.dragonminez.minigame.challenge_retry" : "gui.dragonminez.minigame.continue"), cx, y + 2, "#777777", pa);
        ctx.pop();
    }

    // ===================================================================================
    //  Ki Control (ControlGameScreen)
    // ===================================================================================
    var CONTROL = (function () {
        var FIELD_WIDTH = 140, TRACK_X = 36, TRACK_W = 40, TRACK_CAP = 6, TRACK_TILE = 8, KI_BAR_W = 26, ORB_SIZE = 16, METER_X = 94, ICON_X = 12;
        return {
            init: function (s) { s.v = { meter: new Smooth(), glow: new Smooth(), held: 0, shown: 0 }; },
            layout: function (s) { layoutField(FIELD_WIDTH, Math.max(60, s.cfg.control.trackHeight) + 8, HUD_RESERVE + 10, 26, 1.4); },
            remap: function (k) { return k === MG.UP || k === MG.ACTION ? MG.ACTION : -1; },
            started: function (s) { s.v.meter.snap(s.logic.progress); s.v.shown = 0; },
            input: function (s, e) { if (e[2] === MG.ACTION) s.v.held = e[1] === MG.KEY_DOWN ? 1 : 0; },
            render: function (ctx, pt) {
                var c = S.logic, v = S.v, tex = sheet("control"), h = c.trackHeight, barH = c.barHeight();
                var barY = clamp(c.barY + (isPlaying() ? c.barVelocity * pt : 0), 0, h - barH);
                var orbY = clamp(c.orbY + (isPlaying() ? c.orbVelocity * pt : 0), 0, h);
                var glow = v.glow.update(c.inside ? 1 : 0, 10);
                pushField(ctx);
                ctx.translate(0, 4);
                blit(ctx, tex, TRACK_X, -4, TRACK_W, TRACK_CAP, 0, 0, TRACK_W, TRACK_CAP);
                for (var y = -4 + TRACK_CAP; y < h + 4 - TRACK_CAP; y += TRACK_TILE) {
                    var tile = Math.min(TRACK_TILE, h + 4 - TRACK_CAP - y);
                    blit(ctx, tex, TRACK_X, y, TRACK_W, tile, 0, TRACK_CAP, TRACK_W, tile);
                }
                blit(ctx, tex, TRACK_X, h + 4 - TRACK_CAP, TRACK_W, TRACK_CAP, 0, TRACK_CAP + TRACK_TILE, TRACK_W, TRACK_CAP);
                var bx = TRACK_X + (TRACK_W - KI_BAR_W) / 2, top = h - barY - barH, u = glow > 0.5 ? 0 : 28;
                if (glow > 0.05) rect(ctx, bx - 2, top - 2, KI_BAR_W + 4, barH + 4, "#7CFDD6", 0.25 * glow);
                blit(ctx, tex, bx, top, KI_BAR_W, 4, u, 24, KI_BAR_W, 4);
                blit(ctx, tex, bx, top + 4, KI_BAR_W, barH - 8, u, 28, KI_BAR_W, 4);
                blit(ctx, tex, bx, top + barH - 4, KI_BAR_W, 4, u, 32, KI_BAR_W, 4);
                var pulse = 1 + 0.08 * Math.sin(now() / 90), os = ORB_SIZE * pulse, ocx = TRACK_X + TRACK_W / 2;
                blit(ctx, tex, ocx - os / 2, h - orbY - os / 2, os, os, c.darting ? 16 : 0, 40, ORB_SIZE, ORB_SIZE);
                var held = v.held > 0, is = held ? 1.6 : 1.4;
                blit(ctx, tex, ICON_X - 11 * is / 2 + 5, h / 2 - 11 * is / 2 + (held ? -2 : 0), 11 * is, 11 * is, held ? 14 : 0, 60, 11, 11);
                if (c.levelsCleared !== v.shown) { v.shown = c.levelsCleared; v.meter.snap(1); }
                var shown = v.meter.update(clamp(c.progress, 0, 1), 9);
                drawBarV(ctx, tex, METER_X, -4, h + 8, shown, shown > 0.6 ? FILL_GREEN : shown > 0.3 ? FILL_GOLD : FILL_RED);
                ctx.pop();
                legend(ctx, "gui.dragonminez.minigame.legend.focus", S.fieldLeft + (METER_X + 4.5) * S.fieldScale, S.fieldTop - 6);
            }
        };
    })();

    // ===================================================================================
    //  Gravity (GravityGameScreen)
    // ===================================================================================
    var GRAVITY = (function () {
        var G = MG.GRAVITY, BODY_V = 0, CAP_BOTTOM_V = 16, CAP_TOP_V = 34, GROUND_V = 52, GROUND_W = 64, POD_U = 80, FLAME_U = 104, FLAME_W = 10, FLAME_H = 8, FLAME_TICKS = 6;
        var ROCKS_W = 256, FAR_V = 76, FAR_H = 72, MID_V = 150, MID_H = 60;
        function tileRocks(ctx, tex, v, height, y, offset, width) {
            var start = -floorMod(Math.round(offset), ROCKS_W);
            for (var x = start; x < width; x += ROCKS_W) blit(ctx, tex, x, y, ROCKS_W, height, 0, v, ROCKS_W, height);
        }
        function pillar(ctx, tex, p, cx, groundTop) {
            var bv = p.variant & 1, cv = (p.variant >> 1) & 1, gt = Math.round(MG.gapTop(p)), gb = Math.round(MG.gapBottom(p));
            var bx = cx - G.BODY_WIDTH / 2, capX = cx - G.CAP_WIDTH / 2, y;
            for (y = gb + G.CAP_HEIGHT; y < groundTop; y += G.BODY_TILE_HEIGHT) blit(ctx, tex, bx, y, G.BODY_WIDTH, G.BODY_TILE_HEIGHT, bv * G.BODY_WIDTH, BODY_V, G.BODY_WIDTH, G.BODY_TILE_HEIGHT);
            for (y = gt - G.CAP_HEIGHT - G.BODY_TILE_HEIGHT; y > -G.BODY_TILE_HEIGHT; y -= G.BODY_TILE_HEIGHT) blit(ctx, tex, bx, y, G.BODY_WIDTH, G.BODY_TILE_HEIGHT, bv * G.BODY_WIDTH, BODY_V, G.BODY_WIDTH, G.BODY_TILE_HEIGHT);
            blit(ctx, tex, capX, gb, G.CAP_WIDTH, G.CAP_HEIGHT, cv * G.CAP_WIDTH, CAP_BOTTOM_V, G.CAP_WIDTH, G.CAP_HEIGHT);
            blit(ctx, tex, capX, gt - G.CAP_HEIGHT, G.CAP_WIDTH, G.CAP_HEIGHT, cv * G.CAP_WIDTH, CAP_TOP_V, G.CAP_WIDTH, G.CAP_HEIGHT);
        }
        function levelProgress(g, scroll) {
            var per = Math.max(1, g.c.pillarsPerLevel), podX = scroll + G.PLAYER_X, next = null, prev = null;
            g.pillars.forEach(function (p) {
                if (p.passed) { if (!prev || p.x > prev.x) prev = p; }
                else if (!next || p.x < next.x) next = p;
            });
            var approach = 0;
            if (next) { var from = prev ? prev.x : next.x - g.c.baseSpacing; approach = clamp((podX - from) / Math.max(1, next.x - from), 0, 0.9); }
            return Math.min(1, (g.passedThisLevel + approach) / per);
        }
        return {
            init: function (s) { s.v = { bar: new Smooth(), lives: 0, lostAt: 0, shown: -1, fillAt: 0 }; },
            layout: function (s) { layoutField(G.VIEW_WIDTH, G.VIEW_HEIGHT, HUD_RESERVE + 16, 30, 4); },
            remap: function (k) { return k === MG.UP || k === MG.ACTION ? MG.ACTION : -1; },
            started: function (s) { s.v.lives = s.logic.lives; s.v.shown = s.logic.levelsCleared; s.v.bar.snap(0); },
            tick: function (s) { if (s.logic.lives < s.v.lives) { playMiss(); s.v.lostAt = now(); } s.v.lives = s.logic.lives; },
            input: function (s, e) { if (e[1] === MG.KEY_DOWN && e[2] === MG.ACTION) playUi("minecraft:item.firecharge.use", 1.8, 0.12); },
            render: function (ctx, pt) {
                var g = S.logic, v = S.v, tex = sheet("gravity"), w = G.VIEW_WIDTH, h = G.VIEW_HEIGHT, groundTop = h - G.GROUND_HEIGHT;
                var scroll = g.worldX + (isPlaying() ? g.scrollSpeed() * pt : 0);
                var podY = clamp(g.podY + (isPlaying() ? g.velocity * pt : 0), G.POD_HITBOX_RADIUS, groundTop - G.POD_HITBOX_RADIUS);
                ctx.clip(Math.floor(S.fieldLeft), Math.floor(S.fieldTop), Math.ceil(w * S.fieldScale), Math.ceil(h * S.fieldScale));
                pushField(ctx);
                rect(ctx, 0, 0, w, h, "#0A1428", 0.72);
                tileRocks(ctx, tex, FAR_V, FAR_H, groundTop - FAR_H + 10, scroll * 0.15, w);
                tileRocks(ctx, tex, MID_V, MID_H, groundTop - MID_H + 6, scroll * 0.35, w);
                g.pillars.forEach(function (p) {
                    var cx = Math.round(p.x - scroll);
                    if (cx + G.CAP_WIDTH < 0 || cx - G.CAP_WIDTH > w) return;
                    pillar(ctx, tex, p, cx, groundTop);
                });
                for (var x = -floorMod(Math.round(scroll), GROUND_W); x < w; x += GROUND_W) blit(ctx, tex, x, groundTop, GROUND_W, G.GROUND_HEIGHT, 0, GROUND_V, GROUND_W, G.GROUND_HEIGHT);
                var blink = g.invulnerable > 0 && Math.floor(g.invulnerable / 3) % 2 === 0;
                if (!blink) {
                    var size = G.POD_SPRITE_SIZE, podTop = Math.round(podY) - size / 2, since = g.tickN - g.flapTick;
                    if (since < FLAME_TICKS) blit(ctx, tex, G.PLAYER_X - FLAME_W / 2, podTop + size - 3, FLAME_W, FLAME_H, FLAME_U + (since < FLAME_TICKS / 2 ? 12 : 0), 0, FLAME_W, FLAME_H);
                    blit(ctx, tex, G.PLAYER_X - size / 2, podTop, size, size, POD_U, 0, size, size);
                }
                ctx.pop();
                ctx.unclip();
                pushField(ctx);
                outline(ctx, -2, -2, w + 4, h + 4, 1, "#6F9AD8", 1);
                outline(ctx, -1, -1, w + 2, h + 2, 1, "#30507A", 0.38);
                ctx.pop();
                if (g.levelsCleared !== v.shown) { v.shown = g.levelsCleared; v.fillAt = now(); }
                var fa = secs(v.fillAt), target = fa < 0.25 ? 1 : levelProgress(g, scroll);
                if (fa >= 0.25 && fa < 0.3) v.bar.snap(0);
                var shown = v.bar.update(target, 7), barY = S.fieldTop + h * S.fieldScale + 7;
                drawBarH(ctx, tex, S.w / 2 - 80, barY, 160, shown, FILL_GOLD);
                legend(ctx, "gui.dragonminez.minigame.legend.level_progress", S.w / 2, barY + 11);
                drawHearts(ctx, tex, S.w / 2, S.fieldTop - 17, g.lives, Math.max(1, g.c.lives), 1.3, v.lostAt);
            }
        };
    })();

    // ===================================================================================
    //  Shadow Boxing / memory (MemoryGameScreen)
    // ===================================================================================
    var MEMORY = (function () {
        var CAP_W = 22, CAP_H = 24, PRESSED_U = 24, M = MG.MEMORY;
        function easeCubic(t) { var u = 1 - clamp(t, 0, 1); return 1 - u * u * u; }
        function letter(ctx, ch, x, y, scale, color, alpha) {
            ctx.textStyled(MG.CHARACTERS.charAt(ch), x, y - 3 * scale * 1.15, scale * 1.15, color, Math.max(0.03, alpha), 0.5, FONT, null);
        }
        function feedback(s) {
            var m = s.logic, v = s.v, t = now();
            if (m.remapCount !== v.remap) { v.remap = m.remapCount; v.remapAt = t; v.index = 0; v.total.snap(1); v.key.snap(1); }
            if (m.index > v.index) { playHit(true); v.hitAt = t; v.index = m.index; }
            if (m.wrongTick !== v.wrongTick) { v.wrongTick = m.wrongTick; v.wrongAt = t; playMiss(); }
            if (m.phase !== v.phase) { v.phase = m.phase; v.phaseAt = t; }
            if (m.lives < v.lives) v.lostAt = t;
            v.lives = m.lives;
        }
        return {
            init: function (s) { s.v = { total: new Smooth(), key: new Smooth(), phase: 0, index: 0, remap: -1, lives: 3, remapAt: 0, hitAt: 0, wrongAt: 0, lostAt: 0, phaseAt: 0, wrongTick: -100 }; },
            mapKey: function (n) {
                if (/^[0-9]$/.test(n)) return MG.CHAR_BASE + 26 + Number(n);
                if (/^keypad\.[0-9]$/.test(n)) return MG.CHAR_BASE + 26 + Number(n.charAt(7));
                if (/^[a-z]$/.test(n)) return MG.CHAR_BASE + (n.charCodeAt(0) - 97);
                return -1;
            },
            started: function (s) { var m = s.logic; s.v.phase = m.phase; s.v.index = 0; s.v.lives = m.lives; s.v.remap = -1; s.v.total.snap(1); s.v.key.snap(1); },
            tick: function (s) { feedback(s); },
            input: function (s) { feedback(s); },
            render: function (ctx) {
                var m = S.logic, v = S.v, tex = sheet("memory"), seq = m.sequence, len = seq.length;
                var cx = S.w / 2, cy = S.h / 2 + 6, scale = Math.min(2.2, S.w * 0.8 / (len * (CAP_W + 3)));
                var capW = CAP_W * scale, capH = CAP_H * scale, gap = 3 * scale, rowW = len * capW + (len - 1) * gap, x0 = cx - rowW / 2;
                var ra = secs(v.remapAt), ha = secs(v.hitAt), wa = secs(v.wrongAt), pa = secs(v.phaseAt);
                var success = m.phase === M.SUCCESS, timeout = m.phase === M.TIMEOUT, t = now();
                for (var i = 0; i < len; i++) {
                    var slide = easeCubic((ra - i * 0.04) / 0.25);
                    if (slide <= 0) continue;
                    var x = x0 + i * (capW + gap) + (1 - slide) * 40, y = cy - capH / 2;
                    var done = i < m.index, current = i === m.index && m.phase === M.TYPING, sc = 1, dx = 0, dy = 0;
                    if (current) {
                        dy = -2 * scale * Math.abs(Math.sin(t / 160));
                        if (wa < 0.3) dx = 3 * Math.exp(-wa * 10) * Math.sin(wa * 70);
                    }
                    if (i === m.index - 1 && ha < 0.35) sc = 1 + 0.25 * Math.exp(-ha * 12);
                    if (success) dy = -4 * scale * Math.exp(-pa * 6) * Math.abs(Math.sin(pa * 12 + i * 0.6));
                    if (timeout && pa < 0.5) dx = 3 * Math.exp(-pa * 8) * Math.sin(pa * 60 + i);
                    var r = 1, g = 1, b = 1, a = Math.min(1, slide * 1.5);
                    if (done || success) { r = 0.7; b = 0.7; }
                    else if (timeout) { g = 0.5; b = 0.5; }
                    else if (current && wa < 0.3) { g = 0.45 + wa * 1.8; b = g; }
                    else if (!current) { r = g = b = 0.78; }
                    if (current) outline(ctx, x + dx - 2, y + dy - 2, capW + 4, capH + 2, 1, "#FFD700", 0.55 + 0.45 * Math.abs(Math.sin(t / 220)));
                    var pressed = done || success, w = capW * sc, hh = capH * sc, kx = x + dx - (w - capW) / 2, ky = y + dy - (hh - capH) / 2;
                    var tint = hex((Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(b * 255));
                    blit(ctx, tex, kx, ky, w, hh, pressed ? PRESSED_U : 0, 0, CAP_W, CAP_H, tint, a);
                    letter(ctx, seq[i], kx + w / 2, ky + (pressed ? 10 : 8) * scale * sc, scale * sc, pressed ? "#E6E6EE" : "#2A2A34", a);
                    if (current && m.keyTicks > 0) {
                        var kp = v.key.update(m.keyRemaining / m.keyTicks, 18);
                        drawBarH(ctx, tex, x + dx, y + capH + 4, capW, kp, kp < 0.3 ? FILL_RED : FILL_GOLD);
                        legend(ctx, "gui.dragonminez.minigame.legend.key_time", x + dx + capW / 2, y + capH + 15);
                    }
                }
                if (m.wrongChar >= 0 && wa < 0.5 && m.phase === M.TYPING) {
                    var size = 0.7, wx = x0 + m.index * (capW + gap) + capW * (1 - size) / 2, wy = cy - capH / 2 - capH * size - 6 - wa * 16, fade = Math.max(0.05, 1 - wa * 2);
                    blit(ctx, tex, wx, wy, capW * size, capH * size, 0, 0, CAP_W, CAP_H, "#FF6666", fade);
                    letter(ctx, m.wrongChar, wx + capW * size / 2, wy + 8 * scale * size, scale * size, "#A02020", fade);
                }
                var barW = Math.max(160, rowW), totalPct = m.totalTicks > 0 ? m.totalRemaining / m.totalTicks : 0;
                var fast = m.fastDrain > 0, shownTotal = v.total.update(totalPct, fast ? 25 : 12), flash = fast && Math.floor(t / 80) % 2 === 0;
                drawBarH(ctx, tex, cx - barW / 2, cy + capH / 2 + 26, barW, shownTotal, flash || shownTotal < 0.25 ? FILL_RED : FILL_CYAN);
                legend(ctx, "gui.dragonminez.minigame.legend.time", cx, cy + capH / 2 + 38);
                drawHearts(ctx, tex, cx, cy - capH / 2 - 34, m.lives, Math.max(1, m.c.lives), 1.5, v.lostAt);
            }
        };
    })();

    // ===================================================================================
    //  Precision (PrecisionGameScreen)
    // ===================================================================================
    var PRECISION = (function () {
        var P = MG.PRECISION, TARGET_SIZE = 32, BURST_SECONDS = 0.3, MISS_SECONDS = 0.5;
        var RING_FRAMES = [[0, 48, 42], [87, 48, 39], [168, 48, 36], [0, 136, 33], [69, 136, 30], [132, 136, 27], [189, 136, 24],
            [50, 206, 21], [95, 206, 18], [134, 206, 15], [167, 206, 12], [194, 206, 9], [215, 206, 6]];
        function changes(s) {
            var p = s.logic, v = s.v, score = p.score;
            if (score > v.score) playHit(score - v.score >= p.c.perfectPoints);
            else if (score < v.score) playMiss();
            if (score !== v.score) v.pop.snap(1);
            v.score = score;
            var t = now(), cur = {};
            p.targets.forEach(function (c) {
                cur[c.id] = { fading: c.fading, x: c.x, y: c.y };
                var before = v.tracked[c.id];
                if (c.fading && (!before || !before.fading)) v.effects.push({ x: c.x, y: c.y, hit: false, at: t });
            });
            for (var id in v.tracked) if (!cur[id] && !v.tracked[id].fading) v.effects.push({ x: v.tracked[id].x, y: v.tracked[id].y, hit: true, at: t });
            v.tracked = cur;
        }
        function approach(ctx, tex, x, y, radius, closeness) {
            var best = RING_FRAMES[0];
            RING_FRAMES.forEach(function (f) { if (Math.abs(f[2] - radius) < Math.abs(best[2] - radius)) best = f; });
            var size = 2 * best[2] + 3, drawn = size * radius / best[2];
            blit(ctx, tex, x - drawn / 2, y - drawn / 2, drawn, drawn, best[0], best[1], size, size, "#FFFFFF", closeness > 0.6 ? 1 : 0.7 + 0.3 * closeness);
        }
        return {
            usesClicks: true,
            init: function (s) { s.v = { tracked: {}, effects: [], bar: new Smooth(), pop: new Smooth(), score: 0, shown: 0, space: false }; },
            layout: function (s) { layoutField(P.FIELD_WIDTH, P.FIELD_HEIGHT, HUD_RESERVE + 26, 22, 1.25); },
            playingKey: function (n) {
                if (n !== "space") return false;
                if (!S.v.space) { S.v.space = true; emitClick((S.mx - S.fieldLeft) / S.fieldScale, (S.my - S.fieldTop) / S.fieldScale); }
                return true;
            },
            keyUp: function (n) { if (n === "space") S.v.space = false; },
            started: function (s) { s.v.score = s.logic.score; s.v.tracked = {}; s.v.effects = []; s.v.bar.snap(0); s.v.shown = 0; },
            tick: function (s) { changes(s); },
            input: function (s) { changes(s); },
            render: function (ctx, pt) {
                var p = S.logic, v = S.v, c = p.c, tex = sheet("precision"), cx = S.w / 2;
                pushField(ctx);
                rect(ctx, 0, 0, P.FIELD_WIDTH, P.FIELD_HEIGHT, "#0A1428", 0.72);
                outline(ctx, -2, -2, P.FIELD_WIDTH + 4, P.FIELD_HEIGHT + 4, 1, "#6F9AD8", 1);
                outline(ctx, -1, -1, P.FIELD_WIDTH + 2, P.FIELD_HEIGHT + 2, 1, "#30507A", 0.38);
                var speed = p.ringSpeed(), active = p.targets.filter(function (t) { return !t.fading; });
                active.sort(function (a, b) { return a.ringRadius - b.ringRadius; });
                for (var i = active.length - 1; i >= 0; i--) {
                    var t = active[i], rr = Math.max(1, t.ringRadius - (isPlaying() ? speed * pt : 0));
                    var close = 1 - Math.min(1, Math.abs(rr - c.targetRadius) / Math.max(1, c.goodWindow));
                    blit(ctx, tex, t.x - TARGET_SIZE / 2, t.y - TARGET_SIZE / 2, TARGET_SIZE, TARGET_SIZE, (close > 0.6 ? 1 : 0) * TARGET_SIZE, 0, TARGET_SIZE, TARGET_SIZE);
                    approach(ctx, tex, t.x, t.y, rr, close);
                    var ns = i === 0 ? 1.25 : 1;
                    T(ctx, String(i + 1), t.x, t.y - 3 * ns, i === 0 ? "#FFE680" : "#E0E0E0", 1, ns);
                }
                var tnow = now();
                v.effects = v.effects.filter(function (e) {
                    var age = (tnow - e.at) / 1000;
                    if (e.hit) {
                        if (age >= BURST_SECONDS) return false;
                        var frame = Math.min(2, Math.floor(age / BURST_SECONDS * 3));
                        blit(ctx, tex, e.x - 16, e.y - 16, 32, 32, 64 + frame * 32, 0, 32, 32);
                        return true;
                    }
                    if (age >= MISS_SECONDS) return false;
                    var size = 14 * (1 + 0.4 * Math.exp(-age * 12));
                    blit(ctx, tex, e.x - size / 2, e.y - size / 2 - age * 10, size, size, 1, 33, 14, 14);
                    return true;
                });
                ctx.pop();
                var span = Math.max(1, p.nextThreshold - p.levelStartScore), target = clamp((p.score - p.levelStartScore) / span, 0, 1);
                if (p.levelsCleared !== v.shown) { v.shown = p.levelsCleared; v.bar.snap(1); }
                var shown = v.bar.update(target, 8), lw = W(ctx, tr("gui.dragonminez.minigame.legend.level_progress")) * 0.75;
                drawBarH(ctx, tex, cx - 80, HUD_RESERVE, 160, shown, FILL_GOLD);
                legend(ctx, "gui.dragonminez.minigame.legend.level_progress", cx - 80 - 6 - lw / 2, HUD_RESERVE + 2);
                var pop = v.pop.update(0, 9);
                TS(ctx, p.score + " / " + p.nextThreshold, cx, HUD_RESERVE + 15 - 4, 1 + 0.3 * pop, "#FFFFFF");
            }
        };
    })();

    // ===================================================================================
    //  Rhythm (RythmGameScreen + RhythmCalibrationScreen)
    // ===================================================================================
    var RHYTHM = (function () {
        var LANE_COLORS = [0x5AD0E8, 0x6FD08A, 0xE8C75A, 0xB07CE8], JUDGE_KEYS = ["gui.dragonminez.minigame.judge.miss", "gui.dragonminez.minigame.judge.good", "gui.dragonminez.minigame.judge.perfect"];
        var JUDGE_COLORS = ["#FF5555", "#7CFDD6", "#FFD700"], DIFF_COLORS = [0x7CFD8A, 0xD2D7F1, 0xFFB347, 0xFF5E5E];
        var TOP_SCALE = 0.5, BOARD_HEIGHT_FRACTION = 0.75, EFFECT_TICKS = 8, NOTES_U = 112, KEY_W = 36, KEY_H = 22, NOTE_W = 36, NOTE_H = 12;
        var LIST_ROW_H = 12, LIST_ROWS = 12, LIST_W = 172, DETAIL_W = 192, PANEL_GAP = 10, PANEL_W = LIST_W + PANEL_GAP + DETAIL_W, PANEL_H = 12 + LIST_ROWS * LIST_ROW_H + 2 + 4;
        var DIFF_W = 45, DIFF_H = 14, DIFF_GAP = 2, VAR_W = 92, VAR_H = 14;
        var remembered = { track: 0, difficulty: 1, variant: 0 };
        function laneKeys() {
            var k = store("dmz_rhythm_keys", null);
            return k && k.length === 4 ? [String(k[0]), String(k[1]), String(k[2]), String(k[3])] : ["a", "s", "k", "l"];
        }
        function laneLabel(lane) {
            var n = laneKeys()[lane];
            if (n === "left") return "←"; if (n === "down") return "↓"; if (n === "up") return "↑"; if (n === "right") return "→"; if (n === "space") return "SPC";
            n = n.toUpperCase();
            return n.length > 3 ? n.substring(0, 3) : n;
        }
        function audioOffset() { return clamp(Math.round(Number(store("dmz_rhythm_offset", 60)) || 0), -500, 500); }
        function track() { var v = S.v; return v.tracks[v.index] || null; }
        function diffName(i) { return tr("gui.dragonminez.minigame.rhythm.difficulty." + MG.clampDifficulty(i)); }
        function varName(i) { return tr("gui.dragonminez.minigame.rhythm.variant." + MG.clampVariant(i)); }
        function mult(x) { var t = (Math.round(x * 100) / 100).toFixed(2); while (t.charAt(t.length - 1) === "0") t = t.substring(0, t.length - 1); if (t.charAt(t.length - 1) === ".") t = t.substring(0, t.length - 1); return t; }
        function recommended() { var t = track(); return t && t.rec ? t.rec[S.v.variant] : 1; }
        function choose(i) {
            var v = S.v;
            if (i < 0 || i >= v.tracks.length) return;
            v.index = i; remembered.track = i;
            var t = track();
            if (t && t.kind !== "free") {
                if (!t.vocals) v.variant = 0;
                v.difficulty = recommended(); remembered.difficulty = v.difficulty;
            }
            ensureVisible();
        }
        function ensureVisible() {
            var v = S.v, top = v.index * LIST_ROW_H, view = LIST_ROWS * LIST_ROW_H;
            if (top < v.scroll) v.scroll = top;
            if (top + LIST_ROW_H > v.scroll + view) v.scroll = top + LIST_ROW_H - view;
            v.scroll = clamp(v.scroll, 0, Math.max(0, v.tracks.length * LIST_ROW_H - view));
        }
        function setDifficulty(d) { var v = S.v; if (v.difficulty === d) return; v.difficulty = d; remembered.difficulty = d; playHit(d === recommended()); }
        function setVariant(x) { var v = S.v; x = MG.clampVariant(x); if (v.variant === x) return; v.variant = x; remembered.variant = x; playHit(false); }

        // geometry
        function laneX(lane, s) { var v = S.v, lw = v.bottomWidth / R.LANES; return v.cx + (lane + 0.5 - R.LANES / 2) * lw * s; }
        function edgeX(b, s) { var v = S.v, lw = v.bottomWidth / R.LANES; return v.cx + (b - R.LANES / 2) * lw * s; }
        function yFor(s) { var v = S.v; return v.vpY + (v.hitY - v.vpY) * s; }
        function scaleFor(remaining, travel) { var z = remaining / Math.max(1, travel); return 1 / (1 + z * (1 / TOP_SCALE - 1)); }
        function trap(ctx, bl, br, sTop, sBot, topRgb, topA, botRgb, botA) {
            var yt = yFor(sTop), yb = yFor(sBot);
            quadGrad(ctx, edgeX(bl, sTop), yt, edgeX(br, sTop), yt, edgeX(br, sBot), yb, edgeX(bl, sBot), yb, topRgb, topA, botRgb, botA);
        }

        // music
        function startMusic(chart) {
            S.v.musicStarted = true;
            if (!chart.sound) return;
            try { S.v.music = RPG.soundHandle(chart.sound, 1, 1); } catch (e) { S.v.music = 0; }
        }

        function judgements(s) {
            var r = s.logic, v = s.v, t = now();
            for (var lane = 0; lane < R.LANES; lane++) {
                var tick = r.laneJudgeTick[lane];
                if (tick === v.seen[lane]) continue;
                v.seen[lane] = tick;
                var j = r.laneJudge[lane];
                if (j === R.JUDGE_MISS) { playMiss(); v.keyMiss[lane] = t; board(true, 1); continue; }
                var perfect = j === R.JUDGE_PERFECT;
                playHit(perfect); v.keyHit[lane] = t;
                sparks(lane, perfect ? 14 : 8);
                board(false, perfect ? 1 : 0.65);
                if (perfect) { v.glowColor = LANE_COLORS[lane]; v.glowTick = r.tickN; }
            }
        }
        function board(miss, strength) {
            var v = S.v;
            if (!miss && v.boardMiss && secs(v.boardAt) < 0.25) return;
            v.boardAt = now(); v.boardMiss = miss; v.boardStrength = strength;
        }
        function sparks(lane, count) {
            var v = S.v, x = laneX(lane, 1);
            for (var i = 0; i < count; i++) {
                var a = -Math.PI / 2 + (Math.random() - 0.5) * Math.PI * 0.9, sp = 60 + Math.random() * 110;
                v.sparks.push([x, v.hitY, Math.cos(a) * sp, Math.sin(a) * sp, 0.35 + Math.random() * 0.25, LANE_COLORS[lane]]);
            }
        }

        // ---- calibration (RhythmCalibrationScreen) ----
        function calibStart(mandatory) { S.calib = { mandatory: !!mandatory, samples: [], next: now() + 1200, last: 0, played: 0, done: false, suggested: 0, doneAt: 0 }; }

        var api = {
            init: function (s) {
                s.v = { tracks: s.tracks && s.tracks.length ? s.tracks : [{ key: "", kind: "free" }], index: 0, scroll: 0, difficulty: remembered.difficulty, variant: remembered.variant,
                    seen: [-100, -100, -100, -100], keyHit: [0, 0, 0, 0], keyMiss: [0, 0, 0, 0], sparks: [], glowColor: 0, glowTick: -100, boardAt: 0, boardMiss: false, boardStrength: 0,
                    health: new Smooth(), level: new Smooth(), acc: new Smooth(), comboPop: new Smooth(), shownLevel: 0, shownCombo: 0, restShown: -1, restPopAt: 0,
                    music: 0, musicStarted: false, lastFrame: 0, rects: {}, dragging: false };
                var v = s.v;
                v.index = remembered.track >= 0 && remembered.track < v.tracks.length ? remembered.track : 0;
                if (s.origin === "CHALLENGE") v.index = 0;
                var t = v.tracks[v.index];
                if (t && t.kind !== "free" && !t.vocals) v.variant = 0;
                if (s.origin !== "CHALLENGE" && !store("dmz_rhythm_calibrated", false)) { s.calib = null; v.promptCalib = true; }
            },
            layout: function (s) {
                var v = s.v, boardBottom = s.h - 24;
                v.cx = s.w / 2;
                v.topY = Math.max(HUD_RESERVE + 22, boardBottom - s.h * BOARD_HEIGHT_FRACTION);
                v.bottomWidth = Math.min(Math.min(280, s.w * 0.46), (boardBottom - v.topY) * 0.95);
                var ks = v.bottomWidth / R.LANES * 0.82 / KEY_W;
                v.hitY = boardBottom - 4 - KEY_H * ks;
                v.vpY = (v.topY - v.hitY * TOP_SCALE) / (1 - TOP_SCALE);
                if (v.promptCalib && s.st === "READY") { v.promptCalib = false; calibStart(true); }
            },
            mapKey: function (n) {
                var keys = laneKeys();
                for (var lane = 0; lane < 4; lane++) if (n === keys[lane]) return lane;
                return n === "left" ? MG.LEFT : n === "down" ? MG.DOWN : n === "up" ? MG.UP : n === "right" ? MG.RIGHT : -1;
            },
            remap: function (k) { return k === MG.ACTION ? -1 : k; },
            canPlay: function () { return true; },
            canResume: function () { return !(S.logic && S.logic.chart); },        // a song can't be paused mid-way (its music keeps playing)
            startOption: function () {
                var t = track();
                if (!t || t.kind === "free") return { track: "" };
                return { track: t.key, difficulty: S.v.difficulty, variant: S.v.variant };
            },
            started: function (s) {
                var v = s.v;
                v.musicStarted = false; v.sparks = []; v.seen = [-100, -100, -100, -100];
                v.activeTrack = s.logic.chart ? track() : null;
            },
            tick: function (s) { judgements(s); },
            input: function (s) { judgements(s); },
            afterTick: function (s) {
                var r = s.logic, v = s.v;
                if (!r) return;
                if (s.st === "PLAYING" && r.chart && !v.musicStarted && r.songTimeMs() >= -audioOffset() - R.MS_PER_TICK / 2) startMusic(r.chart);
                if (s.st === "PAUSED" && r.chart) stopMusic();
                if (!running()) stopMusic();
            },
            readyKey: function (n) {
                var v = S.v, t = track();
                if (n === "up" || n === "down") { if (v.tracks.length > 1) choose(floorMod(v.index + (n === "up" ? -1 : 1), v.tracks.length)); playHit(false); return true; }
                if (n === "left" || n === "right") { if (t && t.kind !== "free") setDifficulty(floorMod(v.difficulty + (n === "right" ? 1 : -1), 4)); return true; }
                if (n === "tab") { if (t && t.vocals) setVariant(1 - v.variant); return true; }
                return false;
            },
            readyClick: function (x, y) {
                var v = S.v, r = v.rects, t = track();
                if (inside(r.list, x, y)) {
                    var rel = y - r.list[1] - 1;
                    if (rel < LIST_ROWS * LIST_ROW_H) {
                        var row = Math.floor((Math.max(0, rel) + v.scroll) / LIST_ROW_H);
                        if (row >= 0 && row < v.tracks.length && row !== v.index) { choose(row); playHit(true); }
                    }
                    return true;
                }
                if (inside(r.calib, x, y)) { playHit(false); calibStart(false); return true; }
                if (inside(r.play, x, y)) { click(); requestStart(); return true; }
                if (t && t.kind !== "free") {
                    for (var i = 0; i < 4; i++) if (inside(r["d" + i], x, y)) { setDifficulty(i); return true; }
                    if (t.vocals) for (var j = 0; j < 2; j++) if (inside(r["v" + j], x, y)) { setVariant(j); return true; }
                }
                return false;
            },
            readyScroll: function (x, y, delta) {
                var v = S.v;
                if (!inside(v.rects.list, x, y)) return;
                v.scroll = clamp(v.scroll - (delta > 0 ? LIST_ROW_H : -LIST_ROW_H), 0, Math.max(0, v.tracks.length * LIST_ROW_H - LIST_ROWS * LIST_ROW_H));
            },
            readyCustom: function (ctx) {
                var v = S.v, cxs = S.w / 2, cys = S.h / 2;
                var scale = Math.min(1, Math.min((S.h - 44) / (PANEL_H + 32), (S.w - 16) / (PANEL_W + 32)));
                S.readyScale = scale;
                var mx = readyToUiX(S.mx), my = readyToUiY(S.my);
                scaledAround(ctx, scale);
                panel(ctx, cxs, cys, PANEL_W, PANEL_H);
                var left = Math.round(cxs - PANEL_W / 2), top = Math.round(cys - PANEL_H / 2);
                songList(ctx, left, top, mx, my);
                details(ctx, left + LIST_W + PANEL_GAP, top, mx, my);
                ctx.pop();
                return true;
            },
            render: function (ctx, pt) { renderBoard(ctx, pt); },
            resultLines: function (lines) {
                var r = S.logic;
                if (!r) return;
                var hits = r.perfects + r.goods, acc = r.accuracy(), stars = acc >= 0.95 ? 3 : acc >= 0.85 ? 2 : acc >= 0.7 ? 1 : 0, st = "";
                for (var i = 0; i < 3; i++) st += i < stars ? "★" : "☆";
                lines.push([st, "#FFD700"]);
                lines.push([tr("gui.dragonminez.minigame.rhythm.stats", hits, r.judgedNotes(), r.misses, (acc * 100).toFixed(1) + "%", r.maxCombo), "#B8E8FF"]);
                if (r.chart) lines.push([tr("gui.dragonminez.minigame.rhythm.difficulty_result", diffName(r.difficultyIndex), mult(r.songDifficulty.rewardMultiplier)), hex(DIFF_COLORS[r.difficultyIndex])]);
                if (S.finalInfo && S.finalInfo.song) lines.push([tr("gui.dragonminez.minigame.rhythm.song_learned"), "#7CFD8A"]);
            }
        };

        function menuBox(ctx, x, y, w, h) {
            rect(ctx, x, y, w, h, "#081410", 0.94);
            outline(ctx, x - 1, y - 1, w + 2, h + 2, 1, "#0C0C12", 1);
            outline(ctx, x, y, w, h, 1, "#909AC3", 1);
            rect(ctx, x, y, w, 1, "#D2D7F1", 1); rect(ctx, x, y, 1, h, "#D2D7F1", 1);
        }
        function trackName(t) { return t.kind === "free" ? tr("gui.dragonminez.minigame.rhythm.free") : String(t.name || t.key); }
        function trackSub(t) { return t.kind === "free" ? tr("gui.dragonminez.minigame.rhythm.free_subtitle") : t.sub ? String(t.sub) : tr("gui.dragonminez.minigame.rhythm.music_disc"); }
        function songList(ctx, left, top, mx, my) {
            var v = S.v;
            T(ctx, tr("gui.dragonminez.minigame.rhythm.songs"), left + 2, top, "#FFD700", 1, 1, 0);
            var hint = tr("gui.dragonminez.minigame.rhythm.calibrate_link", audioOffset()), hw = W(ctx, hint) * 0.7;
            v.rects.calib = [left + LIST_W - 2 - hw, top, hw, 8];
            T(ctx, hint, left + LIST_W - 2, top + 2, inside(v.rects.calib, mx, my) ? "#FFD700" : "#909AC3", 1, 0.7, 1);
            var boxTop = top + 12, boxH = LIST_ROWS * LIST_ROW_H + 2;
            v.rects.list = [left, boxTop, LIST_W, boxH];
            menuBox(ctx, left, boxTop, LIST_W, boxH);
            var hover = -1;
            if (inside(v.rects.list, mx, my)) { var rel = my - boxTop - 1; if (rel < LIST_ROWS * LIST_ROW_H) hover = Math.floor((rel + v.scroll) / LIST_ROW_H); }
            ctx.clip(left + 1, boxTop + 1, LIST_W - 2, LIST_ROWS * LIST_ROW_H);   // canvas coordinates: the scale applies
            v.tracks.forEach(function (t, i) {
                var rowY = boxTop + 1 + i * LIST_ROW_H - v.scroll;
                if (rowY + LIST_ROW_H < boxTop || rowY > boxTop + boxH) return;
                var selected = i === v.index;
                if (selected) rect(ctx, left + 2, rowY, LIST_W - 8, LIST_ROW_H, "#D2D7F1", 0.31);
                else if (i === hover) rect(ctx, left + 2, rowY, LIST_W - 8, LIST_ROW_H, "#FFFFFF", 0.16);
                var prefix = t.kind === "builtin" ? "★ " : t.kind === "disc" ? "♪ " : "", tx = left + 6;
                if (prefix) { T(ctx, prefix, tx, rowY + 2, t.kind === "builtin" ? "#FFD700" : t.learned ? "#7CFD8A" : "#B0B8D8", 1, 1, 0); tx += W(ctx, prefix); }
                var dur = t.kind === "free" ? "" : mmss((t.dur || 0) / 1000), dw = dur ? W(ctx, dur) + 4 : 0;
                T(ctx, U.ellipsis(ctx, trackName(t), LIST_W - 16 - (tx - left) - dw), tx, rowY + 2, selected ? "#FFD700" : "#E0E4F4", 1, 1, 0);
                if (dur) T(ctx, dur, left + LIST_W - 8, rowY + 2, selected ? "#D2D7F1" : "#808898", 1, 1, 1);
            });
            ctx.unclip();
            var total = v.tracks.length * LIST_ROW_H, view = LIST_ROWS * LIST_ROW_H;
            if (total > view) {
                var th = Math.max(8, view * view / total), ty = boxTop + 1 + (view - th) * (v.scroll / (total - view));
                rect(ctx, left + LIST_W - 4, ty, 2, th, "#D2D7F1", 1);
            }
        }
        function choice(ctx, r, label, tint, selected, hover) {
            var bx = r[0], by = r[1], w = r[2], h = r[3];
            if (selected) rect(ctx, bx, by, w, h, hex(mixRgb(tint, 0, 0.55)), 0.95); else rect(ctx, bx, by, w, h, "#0C1A14", hover ? 0.95 : 0.85);
            outline(ctx, bx - 1, by - 1, w + 2, h + 2, 1, "#0C0C12", 1);
            outline(ctx, bx, by, w, h, 1, selected ? hex(tint) : hover ? "#D2D7F1" : "#909AC3", 1);
            T(ctx, U.ellipsis(ctx, label, w - 4), bx + w / 2, by + 3, selected ? "#FFFFFF" : hex(hover ? mixRgb(tint, 0xFFFFFF, 0.3) : tint), selected ? 1 : 0.9);
        }
        function details(ctx, x, top, mx, my) {
            var v = S.v, t = track(), rc = S.cfg.rhythm;
            if (!t) return;
            T(ctx, U.ellipsis(ctx, (t.kind === "builtin" ? "★ " : "") + trackName(t), DETAIL_W), x, top, "#FFD700", 1, 1, 0);
            T(ctx, U.ellipsis(ctx, trackSub(t), DETAIL_W), x, top + 11, "#B0B8D8", 1, 1, 0);
            var y = top + 22;
            for (var i = 0; i < 4; i++) v.rects["d" + i] = null;
            v.rects.v0 = v.rects.v1 = null;
            if (t.kind !== "free") {
                var info = mmss((t.dur || 0) / 1000) + (t.bpm ? "  •  " + t.bpm + " BPM" : "");
                T(ctx, info, x, y, "#D2D7F1", 1, 1, 0);
                if (t.learned) T(ctx, "  •  " + tr("gui.dragonminez.minigame.rhythm.learned_tag"), x + W(ctx, info), y, "#7CFD8A", 1, 1, 0);
                y += 14;
                var rec = recommended();
                var rl = tr("gui.dragonminez.minigame.rhythm.recommended", "");
                T(ctx, rl, x, y, "#FFFFFF", 1, 1, 0);
                T(ctx, diffName(rec), x + W(ctx, rl), y, hex(DIFF_COLORS[Math.max(0, rec)]), 1, 1, 0);
                var rowY = y + 12;
                for (var d = 0; d < 4; d++) {
                    var bx = x + d * (DIFF_W + DIFF_GAP);
                    v.rects["d" + d] = [bx, rowY, DIFF_W, DIFF_H];
                    choice(ctx, v.rects["d" + d], diffName(d), DIFF_COLORS[d], d === v.difficulty, inside(v.rects["d" + d], mx, my));
                    if (d === rec) T(ctx, "★", bx + DIFF_W - 3, rowY - 4, "#FFD700", 1, 0.7);
                }
                var ny = rowY + DIFF_H + 6;
                if (t.vocals) {
                    for (var k = 0; k < 2; k++) {
                        v.rects["v" + k] = [x + k * (VAR_W + DIFF_GAP), ny, VAR_W, VAR_H];
                        choice(ctx, v.rects["v" + k], varName(k), k === 1 ? 0xF2A6FF : 0x7CE8FF, k === v.variant, inside(v.rects["v" + k], mx, my));
                    }
                    ny += VAR_H + 6;
                }
                var m = MG.difficultyOf(rc, v.difficulty).rewardMultiplier;
                T(ctx, tr("gui.dragonminez.minigame.rhythm.tp_mult", mult(m)), x, ny, m > 1 ? "#7CFD8A" : m < 1 ? "#FFB347" : "#D2D7F1", 1, 1, 0);
            } else {
                wrap(ctx, tr("gui.dragonminez.minigame.rhythm.free_desc"), DETAIL_W).forEach(function (l) { T(ctx, l, x, y, "#B0B0B0", 1, 1, 0); y += 10; });
                if (S.v.tracks.length <= 1 + MG.SONGS.length) {
                    y += 6;
                    wrap(ctx, tr("gui.dragonminez.minigame.rhythm.no_discs"), DETAIL_W).forEach(function (l) { T(ctx, l, x, y, "#909AC3", 1, 1, 0); y += 10; });
                }
            }
            var bxp = x + DETAIL_W - BUTTON_W, byp = top + PANEL_H - BUTTON_H - 4;
            v.rects.play = [bxp, byp, BUTTON_W, BUTTON_H];
            S.playRect = null;
            drawButton(ctx, v.rects.play, tr("gui.dragonminez.minigame.play"), 1, mx, my);
            if (t.kind === "disc" && !t.learned) {
                var lines = wrap(ctx, tr("gui.dragonminez.minigame.rhythm.learn_hint", Math.round(rc.learnSongAccuracy * 100)), (DETAIL_W - BUTTON_W - 8) / 0.7);
                for (var li = 0; li < Math.min(2, lines.length); li++) T(ctx, lines[li], x, byp + 3 + li * 7, "#909AC3", 1, 0.7, 0);
            }
        }

        function renderBoard(ctx, pt) {
            var r = S.logic, v = S.v, c = r.c, tex = sheet("rhythm"), tnow = now();
            var t = r.songTimeMs() + (isPlaying() ? pt * R.MS_PER_TICK : 0);
            var ga = r.tickN - v.glowTick;
            if (ga >= 0 && ga < 12) {
                var alpha = 0.35 * (1 - ga / 12);
                for (var i = 0; i < 40; i += 2) {
                    var a = alpha * (1 - i / 40);
                    rect(ctx, i, 0, 2, S.h, hex(v.glowColor), a); rect(ctx, S.w - 2 - i, 0, 2, S.h, hex(v.glowColor), a);
                }
            }
            var bt = secs(v.boardAt), decay = Math.exp(-bt * (v.boardMiss ? 8 : 10));
            var dx = v.boardMiss ? 5 * decay * Math.sin(bt * 62) : 0;
            var dy = v.boardMiss ? 2 * decay * Math.sin(bt * 47) : 3 * v.boardStrength * decay * Math.sin(bt * 38 + 0.4);
            var sc = 1 + (v.boardMiss ? 0.02 : 0.012 * v.boardStrength) * decay;
            ctx.push(); ctx.translate(v.cx + dx, v.hitY + dy); ctx.scale(sc, sc); ctx.translate(-v.cx, -v.hitY);
            trap(ctx, 0, R.LANES, TOP_SCALE, 1.08, 0x0A1220, 0.82, 0x162234, 0.88);
            if (v.boardMiss && decay > 0.02) trap(ctx, 0, R.LANES, TOP_SCALE, 1.08, 0xFF3030, 0.05 * decay, 0xFF3030, 0.32 * decay);
            var yT = yFor(TOP_SCALE), yB = yFor(1.08), b;
            for (b = 1; b < R.LANES; b++)
                quadGrad(ctx, edgeX(b, TOP_SCALE) - 0.3, yT, edgeX(b, TOP_SCALE) + 0.3, yT, edgeX(b, 1.08) + 0.6, yB, edgeX(b, 1.08) - 0.6, yB, 0xFFFFFF, 0.19, 0xFFFFFF, 0.31);
            var rail = v.boardMiss && decay > 0.1 ? 0xFF8080 : 0xD8F4FF;
            [0, R.LANES].forEach(function (side) {
                quadGrad(ctx, edgeX(side, TOP_SCALE) - 1, yT, edgeX(side, TOP_SCALE) + 1, yT, edgeX(side, 1.08) + 2, yB, edgeX(side, 1.08) - 2, yB, 0x7CE8FF, 0.56, rail, 0.94);
            });
            var beatMs = 60000 / (r.chart && r.chart.bpm > 0 ? r.chart.bpm : c.freeBaseBpm), travel = r.travelMs();
            for (var beat = Math.ceil(t / beatMs) * beatMs; beat < t + travel; beat += beatMs) {
                var s = scaleFor(beat - t, travel);
                rect(ctx, edgeX(0, s), yFor(s), edgeX(R.LANES, s) - edgeX(0, s), Math.max(0.5, s), "#FFFFFF", 0.09);
            }
            for (var lane = 0; lane < R.LANES; lane++) {
                var age = r.tickN - r.laneJudgeTick[lane];
                if (age < 0 || age >= EFFECT_TICKS || r.laneJudge[lane] === R.JUDGE_MISS) continue;
                var fade = 1 - (age + (isPlaying() ? pt : 0)) / EFFECT_TICKS;
                trap(ctx, lane + 0.1, lane + 0.9, 0.62, 1, LANE_COLORS[lane], 0, LANE_COLORS[lane], 0.55 * fade);
            }
            r.notes.forEach(function (n) {
                if (n.lengthMs <= 0 || n.state === R.DONE) return;
                var head = n.state === R.HOLDING ? 0 : n.timeMs - t, tail = n.timeMs + n.lengthMs - t;
                if (tail < 0) return;
                var sH = scaleFor(Math.max(head, -0.1 * n.travelMs), n.travelMs), sT = scaleFor(Math.min(tail, n.travelMs), n.travelMs);
                var al = n.state === R.HOLDING ? 0.85 : 0.55;
                trap(ctx, n.lane + 0.36, n.lane + 0.64, sT, sH, LANE_COLORS[n.lane], al * 0.7, LANE_COLORS[n.lane], al);
            });
            r.notes.forEach(function (n) {
                if (n.state !== R.PENDING) return;
                var rem = n.timeMs - t;
                if (rem > n.travelMs || rem < -0.12 * n.travelMs) return;
                var s2 = scaleFor(rem, n.travelMs), k = v.bottomWidth / R.LANES * 0.8 * s2 / NOTE_W;
                blit(ctx, tex, laneX(n.lane, s2) - NOTE_W * k / 2, yFor(s2) - NOTE_H * k / 2, NOTE_W * k, NOTE_H * k, NOTES_U, n.lane * NOTE_H, NOTE_W, NOTE_H);
            });
            quadGrad(ctx, edgeX(0, 1), v.hitY - 2, edgeX(R.LANES, 1), v.hitY - 2, edgeX(R.LANES, 1), v.hitY + 2, edgeX(0, 1), v.hitY + 2, 0xFFFFFF, 0.75, 0xA0D8FF, 0.38);
            for (lane = 0; lane < R.LANES; lane++) keyCap(ctx, tex, lane, r);
            // sparks
            var dt = v.lastFrame ? Math.min(0.05, (tnow - v.lastFrame) / 1000) : 0;
            v.lastFrame = tnow;
            v.sparks = v.sparks.filter(function (p) {
                p[0] += p[2] * dt; p[1] += p[3] * dt; p[3] += 260 * dt; p[4] -= dt;
                if (p[4] <= 0) return false;
                rect(ctx, p[0] - 1, p[1] - 1, 2, 2, hex(p[5]), Math.min(1, p[4] * 3));
                return true;
            });
            centerTexts(ctx, r);
            healthBars(ctx, tex, r);
            if (t < 0) countdownRing(ctx, t);
            else if (r.resting) restCountdown(ctx, r);
            ctx.pop();
            topBar(ctx, tex, r, t);
        }
        function keyCap(ctx, tex, lane, r) {
            var v = S.v, k = v.bottomWidth / R.LANES * 0.82 / KEY_W, disabled = r.resting, held = !disabled && r.isHeld(lane);
            var sh = disabled ? 99 : secs(v.keyHit[lane]), sm = disabled ? 99 : secs(v.keyMiss[lane]);
            var state = sh < 0.12 ? 2 : held ? 1 : 0, pop = sh < 0.5 ? 1 + 0.16 * Math.exp(-sh * 14) : 1;
            var shake = sm < 0.4 ? 2 * Math.exp(-sm * 12) * Math.sin(sm * 70) : 0;
            var cx = laneX(lane, 1) + shake, cy = v.hitY + 4 + KEY_H * k / 2;
            if (sh < 0.3) { var p = sh / 0.3, grow = 1 + p * 0.8, w = KEY_W * k * grow, h = KEY_H * k * grow; outline(ctx, cx - w / 2, cy - h / 2, w, h, 1, hex(LANE_COLORS[lane]), 0.85 * (1 - p)); }
            var tint = "#FFFFFF";
            if (sm < 0.35) { var red = sm / 0.35, gb = Math.round((0.45 + 0.55 * red) * 255); tint = hex((255 << 16) | (gb << 8) | gb); }
            else if (disabled) tint = "#6B707F";
            var kw = KEY_W * k * pop, kh = KEY_H * k * pop;
            blit(ctx, tex, cx - kw / 2, cy - kh / 2, kw, kh, state * KEY_W, lane * KEY_H, KEY_W, KEY_H, tint, 1);
            var off = state === 0 ? 0 : 3, ts = Math.max(1, k * 0.75);
            TS(ctx, laneLabel(lane), cx, cy + (off - 3.5) * k * pop - 4, ts, disabled ? "#6A6E7A" : state === 2 ? "#1A2230" : "#FFFFFF");
        }
        function centerTexts(ctx, r) {
            var v = S.v, age = r.tickN - r.lastJudgementTick, midY = yFor(0.8);
            if (age >= 0 && age < 14 && r.lastJudgement >= 0) {
                var j = clamp(r.lastJudgement, 0, 2);
                TS(ctx, "§l" + tr(JUDGE_KEYS[j]), v.cx, midY - 12 - 4, 1 + 0.45 * Math.exp(-age * 0.9), JUDGE_COLORS[j], Math.max(0.1, 1 - age / 14));
            }
            if (r.combo !== v.shownCombo) { if (r.combo > v.shownCombo) v.comboPop.snap(1); v.shownCombo = r.combo; }
            var pop = v.comboPop.update(0, 9);
            if (r.combo >= 2) {
                TS(ctx, "x" + r.combo, v.cx, midY + 2 - 4, 1.8 * (1 + 0.35 * pop), r.combo >= 20 ? "#FFD700" : "#FFFFFF");
                T(ctx, tr("gui.dragonminez.minigame.rhythm.combo"), v.cx, midY + 16, "#AAAAAA");
            }
        }
        function healthBars(ctx, tex, r) {
            var v = S.v, h = v.hitY - yFor(0.6), y = v.hitY - h;
            var health = v.health.update(clamp(r.health, 0, 1), 8);
            drawBarV(ctx, tex, edgeX(R.LANES, 1) + 10, y, h, health, health > 0.5 ? FILL_GREEN : health > 0.25 ? FILL_GOLD : FILL_RED);
            legend(ctx, "gui.dragonminez.minigame.legend.health", edgeX(R.LANES, 1) + 14.5, y - 9);
            var level = v.level.update(clamp(r.progress / r.c.progressMax, 0, 1), 7);
            if (r.levelsCleared !== v.shownLevel) { v.shownLevel = r.levelsCleared; v.level.snap(0); level = 0; }
            drawBarV(ctx, tex, edgeX(0, 1) - 19, y, h, level, FILL_GOLD);
            legend(ctx, "gui.dragonminez.minigame.legend.level", edgeX(0, 1) - 14.5, y - 9);
        }
        function restCountdown(ctx, r) {
            var v = S.v, seconds = Math.max(1, Math.ceil(r.restRemainingMs / 1000));
            if (seconds !== v.restShown) { v.restShown = seconds; v.restPopAt = now(); }
            var pop = 1 + 0.35 * Math.exp(-secs(v.restPopAt) * 9), midY = yFor(0.7);
            disc(ctx, v.cx, midY, 24, "#101828", 0.56);
            ring(ctx, v.cx, midY, 24, 2, "#D2D7F1", 0.75);
            ring(ctx, v.cx, midY, 27, 1, "#FFFFFF", 0.25 + 0.5 * clamp((r.restRemainingMs % 1000) / 1000, 0, 1));
            TS(ctx, String(seconds), v.cx, midY - 4, 2.2 * pop, "#FFFFFF");
            T(ctx, tr("gui.dragonminez.minigame.rhythm.rest"), v.cx, midY - 40, "#D2D7F1");
        }
        function countdownRing(ctx, t) {
            var v = S.v, seconds = Math.ceil(-t / 1000), midY = yFor(0.7);
            ring(ctx, v.cx, midY, 26, 2, "#7CE8FF", 0.75);
            ring(ctx, v.cx, midY, 22, 1.5, "#FFFFFF", Math.max(0.2, (-t / 1000) % 1));
            TS(ctx, String(Math.max(1, seconds)), v.cx, midY - 4, 2.5, "#FFFFFF");
        }
        function topBar(ctx, tex, r, t) {
            var v = S.v, at = v.activeTrack, barTop = Math.round(v.topY - 22);
            var title = "♪ " + (at && r.chart ? trackName(at) + "  •  " + diffName(r.difficultyIndex) + (r.variant === R.VARIANT_VOCAL ? "  •  " + varName(1) : "") : tr("gui.dragonminez.minigame.rhythm.free"));
            T(ctx, title, v.cx, barTop, "#FFFFFF");
            var x0 = v.cx - 110;
            if (r.chart) {
                drawBarH(ctx, tex, x0, barTop + 10, 220, r.chart.durationMs > 0 ? clamp(t / r.chart.durationMs, 0, 1) : 0, FILL_CYAN);
                var lw = W(ctx, tr("gui.dragonminez.minigame.legend.song")) * 0.75;
                legend(ctx, "gui.dragonminez.minigame.legend.song", x0 - 6 - lw / 2, barTop + 12);
            }
            T(ctx, v.acc.update(r.accuracy() * 100, 6).toFixed(1) + "%", x0 + 226, barTop + 11, "#B8E8FF", 1, 1, 0);
        }
        return api;
    })();

    function stopMusic() {
        if (S && S.v && S.v.music) { try { RPG.soundStop(S.v.music); } catch (e) { } S.v.music = 0; }
    }

    // ---- audio calibration overlay (RhythmCalibrationScreen) ----
    var CAL_WARMUP = 4, CAL_SAMPLES = 12, CAL_INTERVAL = 500;
    function calibMedian(c) { var s = c.samples.slice().sort(function (a, b) { return a - b; }); return s[Math.floor(s.length / 2)]; }
    function calibOffset() { return clamp(Math.round(Number(store("dmz_rhythm_offset", 60)) || 0), -500, 500); }
    function calibTap() {
        var c = S.calib;
        if (c.done || !c.last) return;
        var t = now(), since = t - c.last, until = c.next - t, delta = since <= until ? since : -until;
        if (c.played <= CAL_WARMUP) return;
        c.samples.push(Math.round(clamp(delta, -250, 400)));
        if (c.samples.length >= CAL_SAMPLES) {
            c.done = true; c.doneAt = t; c.suggested = clamp(calibMedian(c), -200, 400);
            playUi("minecraft:entity.player.levelup", 1.0, 0.5);
        }
    }
    function calibApply() { storeSet("dmz_rhythm_offset", S.calib.suggested); storeSet("dmz_rhythm_calibrated", true); S.calib = null; }
    function calibClose() { if (S.calib.mandatory) storeSet("dmz_rhythm_calibrated", true); S.calib = null; }
    function calibKey(n) {
        var c = S.calib;
        if (n === "escape") { if (!c.mandatory) calibClose(); return; }
        if (c.done) { if (n === "enter" || n === "keypad.enter") calibApply(); return; }
        calibTap();
    }
    function calibClick(x, y) {
        var c = S.calib;
        if (inside(c.back, x, y)) { calibClose(); return; }
        if (c.done) {
            if (inside(c.apply, x, y)) calibApply();
            else if (inside(c.retry, x, y)) { var m = c.mandatory; S.calib = { mandatory: m, samples: [], next: now() + 1200, last: 0, played: 0, done: false, suggested: 0, doneAt: 0 }; }
            return;
        }
        calibTap();
    }
    function calibRender(ctx) {
        var c = S.calib, t = now();
        if (!c.done) while (t >= c.next) { RPG.sound("minecraft:block.note_block.hat", 1, 1); c.last = now(); c.played++; c.next += CAL_INTERVAL; }
        rect(ctx, 0, 0, S.w, S.h, "#000000", 0.6);
        var cx = S.w / 2, cy = S.h / 2, cw = 250, ch = c.mandatory ? 132 : 118, mx = S.mx, my = S.my;
        panel(ctx, cx, cy, cw, ch);
        var top = cy - ch / 2;
        T(ctx, tr("gui.dragonminez.minigame.rhythm.calibration.title"), cx, top, "#FFD700");
        var y = top + 14;
        if (c.mandatory) { wrap(ctx, tr("gui.dragonminez.minigame.rhythm.calibration.first_time"), cw).forEach(function (l) { T(ctx, l, cx, y, "#7CFDD6"); y += 10; }); y += 4; }
        wrap(ctx, tr("gui.dragonminez.minigame.rhythm.calibration.howto"), cw).forEach(function (l) { T(ctx, l, cx, y, "#B0B0B0"); y += 10; });
        y += 6;
        c.apply = c.retry = c.back = null;
        if (!c.done) {
            var listening = c.played <= CAL_WARMUP, since = c.last ? (t - c.last) / 1000 : 1;
            TS(ctx, listening ? tr("gui.dragonminez.minigame.rhythm.calibration.listen") : tr("gui.dragonminez.minigame.rhythm.calibration.progress", c.samples.length, CAL_SAMPLES),
                cx, y, 1 + 0.25 * Math.exp(-since * 10), listening ? "#D2D7F1" : "#FFFFFF");
            y += 14;
            if (c.samples.length >= 3) T(ctx, tr("gui.dragonminez.minigame.rhythm.calibration.live", calibMedian(c)), cx, y, "#909AC3");
            y += 12;
            T(ctx, tr("gui.dragonminez.minigame.rhythm.calibration.current", calibOffset()), cx, y, "#808898");
            if (!c.mandatory) { c.back = [cx - BUTTON_W / 2, top + ch - BUTTON_H, BUTTON_W, BUTTON_H]; drawButton(ctx, c.back, tr("gui.dragonminez.minigame.rhythm.calibration.back"), 1, mx, my); }
        } else {
            var appear = Math.min(1, (t - c.doneAt) / 350);
            TS(ctx, tr("gui.dragonminez.minigame.rhythm.calibration.result", c.suggested), cx, y + 2, 1.4 + 0.3 * (1 - appear), c.suggested === calibOffset() ? "#D2D7F1" : "#7CFD8A");
            y += 18;
            T(ctx, tr("gui.dragonminez.minigame.rhythm.calibration.current", calibOffset()), cx, y, "#808898");
            var by = top + ch - BUTTON_H;
            if (c.mandatory) { c.apply = [cx - BUTTON_W - 3, by, BUTTON_W, BUTTON_H]; c.retry = [cx + 3, by, BUTTON_W, BUTTON_H]; }
            else {
                c.apply = [cx - BUTTON_W * 1.5 - 6, by, BUTTON_W, BUTTON_H]; c.retry = [cx - BUTTON_W / 2, by, BUTTON_W, BUTTON_H]; c.back = [cx + BUTTON_W / 2 + 6, by, BUTTON_W, BUTTON_H];
                drawButton(ctx, c.back, tr("gui.dragonminez.minigame.rhythm.calibration.back"), 1, mx, my);
            }
            drawButton(ctx, c.apply, tr("gui.dragonminez.minigame.rhythm.calibration.apply"), 1, mx, my);
            drawButton(ctx, c.retry, tr("gui.dragonminez.minigame.rhythm.calibration.retry"), 1, mx, my);
        }
    }

    var GAMES = { rhythm: RHYTHM, control: CONTROL, memory: MEMORY, precision: PRECISION, gravity: GRAVITY };

    // ===================================================================================
    //  The V menu's Minigames tab (MinigamesScreen)
    // ===================================================================================
    var HUB = (function () {
        var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png", NAV = "dmzpack:textures/gui/buttons/menubuttons.png";
        var LIST = ["rhythm", "control", "memory", "precision", "gravity", "shadowdummy"], ITEM_H = 20;
        var H = null, info = { known: {}, runs: {}, needRuns: 3, needLevel: 5, masters: {} };
        function access(i) { var id = LIST[i]; return id !== "shadowdummy" && !!info.known[id]; }
        function openHub(d) {
            info = d || info;
            var mine = { sel: H ? H.sel : 0, scroll: 0 };
            H = mine;
            var els = [{ id: "model", group: "center", type: "entity", anchor: "center", x: -35, y: -30, w: 80, h: 100, rotation: 180, followMouse: false, size: 75 }];
            var nav = [[-110, 120, "party"], [-70, 0, "stats"], [-30, 20, "skills"], [10, 60, "quests"], [50, 140, "minigames"], [90, 100, "config"]];
            nav.forEach(function (n) {
                els.push({ id: "nav_" + n[2], type: "button", anchor: "bottom", x: n[0], y: -30, w: 20, h: 20, texture: NAV, texW: 256, texH: 256,
                    u: n[1], v: 0, uw: 20, vh: 20, hoverU: n[1], hoverV: 20, tooltip: n[2].charAt(0).toUpperCase() + n[2].slice(1),
                    onClick: function () { RPG.sound("dmzpack:ui_menu_switch", 1, 1); if (n[2] !== "minigames") DMZ_MENU_FX.switchTo(n[2]); } });
            });
            RPG.screen.open(DMZ_MENU_FX.wrap({ id: "dmz_minigames_hub", referenceHeight: DMZ_OPTS.menuRef(), elements: els, onRender: render, onMouse: mouse, onScroll: scroll,
                onClose: function () { if (H === mine) H = null; } }));
        }
        function render(ctx) {
            if (!H) return;
            // MinigamesScreen: the list panel takes the left offset, the details panel the right one (BaseMenuScreen)
            var Wd = ctx.width, cy = Math.floor(ctx.height / 2), mx = ctx.mouseX, my = ctx.mouseY, py = cy - 105;
            var lx = 12 + Math.round(DMZ_MENU_FX.left()), rx = Wd - 158 + Math.round(DMZ_MENU_FX.right());
            H.cy = cy; H.rx = rx; H.lx = lx;
            ctx.image(MENU_BIG, lx, py, 141, 213, 0, 0, 141, 213, 256, 256);
            ctx.image(MENU_BIG, lx + 17, py + 10, 107, 21, 142, 22, 107, 21, 256, 256);
            U.bordered(ctx, "§l" + tr("gui.dragonminez.minigames.list"), lx + 70, py + 17, "#FFD700", 0.5);
            LIST.forEach(function (id, i) {
                var iy = py + 38 + i * ITEM_H, sel = i === H.sel, hov = mx >= lx + 18 && mx <= lx + 123 && my >= iy - 2 && my <= iy + 10;
                U.bordered(ctx, tr("gui.dragonminez.minigame." + id), lx + 20, iy, sel ? "#FFD700" : hov ? "#7CFDD6" : access(i) ? "#FFFFFF" : "#888888", 0);
            });
            ctx.image(MENU_BIG, rx, py, 141, 213, 0, 0, 141, 213, 256, 256);
            ctx.image(MENU_BIG, rx + 17, py + 10, 107, 21, 142, 22, 107, 21, 256, 256);
            var id = LIST[H.sel];
            U.bordered(ctx, "§l" + tr("gui.dragonminez.minigame." + id), rx + 70, py + 17, "#FFD700", 0.5);
            var lines = [], descH = 142;
            if (id === "shadowdummy") {
                desc(ctx, rx, py, wrap(ctx, tr("gui.dragonminez.minigame.shadowdummy.desc"), 118 / 0.75), 100);
                small(ctx, wrap(ctx, tr("gui.dragonminez.minigames.soon"), 118 / 0.75), rx, py + 213 - 30, "#FF7777");
                H.play = null;
                return;
            }
            if (!access(H.sel)) {
                var learn = tr("gui.dragonminez.minigames.learn") + " " + tr("entity.dragonminez.questnpc." + (info.masters[id] || ""));
                var prog = tr("gui.dragonminez.minigames.learn_progress", Number(info.runs[id]) || 0, info.needRuns, info.needLevel);
                var a = wrap(ctx, learn, 118 / 0.75), b = wrap(ctx, prog, 118 / 0.75), blockH = (a.length + b.length) * 9 + 3, blockTop = py + 213 - 12 - blockH;
                descH = Math.max(40, Math.min(142, blockTop - 4 - (py + 40)));
                lines = wrap(ctx, tr("gui.dragonminez.minigame." + id + ".desc"), 118 / 0.75);
                desc(ctx, rx, py, lines, descH);
                var y2 = small(ctx, a, rx, blockTop, "#FF7777") + 3;
                small(ctx, b, rx, y2, "#FFAA55");
                H.play = null;
                return;
            }
            lines = wrap(ctx, tr("gui.dragonminez.minigame." + id + ".desc"), 118 / 0.75);
            desc(ctx, rx, py, lines, descH);
            // Play (menubuttons 0,50 105x20)
            var bx = rx + 18, by = py + 213 - 28, over = U.inside(mx, my, bx, by, 105, 20);
            H.play = [bx, by, 105, 20];
            ctx.image(NAV, bx, by, 105, 20, 0, 50, 105, 20, 256, 256);
            U.bordered(ctx, tr("gui.dragonminez.minigames.play"), bx + 52, by + 6, over ? "#FFFFA0" : "#FFFFFF", 0.5);
        }
        function desc(ctx, rx, py, lines, viewH) {
            var top = py + 40, total = lines.length * 9;
            H.descMax = Math.max(0, total - viewH);
            H.scroll = clamp(H.scroll, 0, H.descMax);
            ctx.clip(rx + 10, top, 120, viewH);
            lines.forEach(function (l, i) { var y = top + i * 9 - H.scroll; if (y > top - 9 && y < top + viewH) ctx.textStyled(l, rx + 12, y, 0.75, "#E0E0E0", 1, 0, FONT, "#000000"); });
            ctx.unclip();
            if (H.descMax > 0) { var th = Math.max(20, viewH * viewH / total); ctx.fill(rx + 130, top + (viewH - th) * H.scroll / H.descMax, 2, th, "#D2D7F1", 1); }
        }
        function small(ctx, lines, rx, y, color) { lines.forEach(function (l) { ctx.textStyled(l, rx + 70, y, 0.75, color, 1, 0.5, FONT, "#000000"); y += 9; }); return y; }
        function mouse(x, y, button, action) {
            if (!H || action !== "down" || button !== 0) return;
            var py = H.cy - 105;
            for (var i = 0; i < LIST.length; i++) {
                var iy = py + 38 + i * ITEM_H;
                if (x >= (H.lx || 12) + 18 && x <= (H.lx || 12) + 123 && y >= iy - 2 && y <= iy + 10) { if (H.sel !== i) { H.sel = i; H.scroll = 0; RPG.sound("dmzpack:pip_menu", 1, 1); } return false; }
            }
            if (H.play && U.inside(x, y, H.play[0], H.play[1], H.play[2], H.play[3]) && access(H.sel)) {
                click();
                RPG.net.send("dmz_mg", { a: "open", game: LIST[H.sel] });
                return false;
            }
        }
        function scroll(x, y, d) { if (H && x >= H.rx) H.scroll = clamp(H.scroll - (d > 0 ? 12 : -12), 0, H.descMax || 0); }
        RPG.net.on("dmz_mg_hub", function (d) { DMZ_MENU_FX.open("minigames", function () { openHub(d); }); });
        return { open: openHub };
    })();

    return { open: open, openHub: HUB.open, state: function () { return S; } };
})();
