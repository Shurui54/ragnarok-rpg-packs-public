// =====================================================================================
//  85_dmz_tournaments.js - DragonMine Z's tournament screens (client)
// =====================================================================================
//  Port of DragonMine Z's client/gui/tournament/TournamentBracketScreen (sign-up, rules,
//  bracket tree and gauntlet ladder, party chips, fighter tooltips) and TournamentOverlay (the
//  3-2-1 countdown, FIGHT!, the duel preview and the "tournament" notification card), plus
//  SagaHaloLayer for a dead fighter's halo. GPL-3.0, credited in NOTICE.md. Art: dmzpack's
//  menubig panel, characterbuttons and gui/tournament/slots.png; text: dmzpack's DMZ lang.
//  Server side: scripts/95_dmz_tournaments.js ("dmz_tourn_open", "dmz_tourn_phase",
//  "dmz_tourn_halo" in; "dmz_tourn" {a, npc} out).
// =====================================================================================
var DMZ_TOURN_SCREEN = (function () {
    var U = DMZ_UI, tr = U.tr, FONT = U.FONT;
    var BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var SLOT_FRAMES = "dmzpack:textures/gui/tournament/slots.png";
    var PANEL = U.Skin("dmzpack:textures/gui/menu/menubig.png", 256, 256, 0, 0,
        [U.seg.fixed(14), U.seg.tile(63), U.seg.decor(28, 0), U.seg.tile(21), U.seg.fixed(15)],
        [U.seg.fixed(14), U.seg.band(21), U.seg.fixed(7), U.seg.decor(28, 2), U.seg.tile(28), U.seg.decor(21, 1), U.seg.tile(77), U.seg.fixed(17)]);

    // TournamentBracketScreen constants
    var PANEL_FRACTION = 0.8, PADDING = 10, HEADER_HEIGHT = 30, MEMBERS_HEIGHT = 16, FOOTER_HEIGHT = 26;
    var BUTTON_WIDTH = 74, BUTTON_HEIGHT = 20, SCROLLBAR = 4;
    var SLOT = 34, FRAME_SOURCE = 48, TREE_PITCH = 42, ROW_PITCH = 54, LABEL_MARGIN = 68, GAUNTLET_PITCH = 58, GAUNTLET_MARGIN = 36;
    var SCROLL_STEP = 28, MAX_UPSCALE = 1.5, DECLINE_ARM_MS = 3000, MIN_GUI_WIDTH = 420;
    var TITLE_COLOR = "#FFD54F", STARS_COLOR = "#FFAA00", TEXT_COLOR = "#E8ECF2", MUTED_COLOR = "#9FB8AE", ACCENT_COLOR = "#7CFDD6", WARN_COLOR = "#FF6D6D";
    var LINE_COLOR = "#6D8CFF", LINE_DONE_COLOR = "#FFD54F", LINE_NOW_COLOR = "#FF5555";
    var PLAYER_SLOT = "@player", HIDDEN_SLOT = "?", PLAYER_PREFIX = "@player:";
    // SlotState frame u, v in slots.png
    var FRAME = { UPCOMING: [0, 0], PLAYER: [48, 0], CURRENT: [0, 48], DEFEATED: [48, 0], HIDDEN: [0, 0], EMPTY: [0, 0], PENDING: [0, 0], CROWN: [48, 0] };

    var D = null;                // the last OpenBracketS2C
    var open = false, npc = null, phaseEnd = 0, cooldownEnd = 0, declineArmedUntil = 0, pendingFocus = true, lastView = null;
    var scroll = { pos: 0, target: 0, max: 0, horizontal: false, dragging: false, grab: 0, grabThumb: 0, view: [0, 0, 0, 0], last: 0, active: 0 };
    var buttons = [], slotHits = [], memberHits = [], hoveredSlot = null, hoveredMember = null, contentScale = 1, originX = 0, originY = 0;

    function isPlayerSlot(s) { return !!s && (s === PLAYER_SLOT || String(s).indexOf(PLAYER_PREFIX) === 0); }
    function now() { return RPG.nowMs(); }
    function phaseSecondsLeft() { return Math.max(0, Math.ceil((phaseEnd - now()) / 1000)); }
    function cooldownLeft() { return Math.max(0, Math.ceil((cooldownEnd - now()) / 1000)); }
    function formatDuration(s) { var m = Math.floor(s / 60), r = s % 60; return m > 0 ? m + "m " + r + "s" : r + "s"; }
    function send(action) { RPG.net.send("dmz_tourn", { a: action, npc: npc }); RPG.uiSound("minecraft:ui.button.click", 0.25, 1); }

    function view() {
        if (D.lockedByOther) return "LOCKED";
        if (D.signUp) return "SIGNUP";
        if (D.phase === "RULES" && !D.eliminated) return "RULES";
        return "BRACKET";
    }
    function me() { for (var i = 0; i < D.members.length; i++) if (D.members[i].name === RPG.player.name) return D.members[i]; return null; }
    function isMyBout() { var m = me(); return !!m && m.active && !D.eliminated && !D.completed; }
    function awaitingMyReady() { return D.phase === "INTERMISSION" && isMyBout() && !D.myReady; }

    // ---- data in (TournamentBracketScreen.open / refresh) ----
    RPG.net.on("dmz_tourn_open", function (d) {
        if (!d) return;
        var cur = RPG.screen.getOpen();
        if (open && cur === "dmz_tournament" && D && D.id === d.id) { refresh(d); return; }
        if (d.push) return;
        D = d;
        npc = d.npc && d.npc !== -1 ? d.npc : npc;
        phaseEnd = now() + d.phaseSeconds * 1000;
        cooldownEnd = now() + d.cooldown * 1000;
        declineArmedUntil = 0; pendingFocus = true; lastView = view();
        resetScroll();
        openScreen();
    });
    function refresh(d) {
        var previewOver = D.phase === "PREVIEW" && d.phase === "BOUT", before = view();
        D = d;
        if (d.npc && d.npc !== -1) npc = d.npc;
        phaseEnd = now() + d.phaseSeconds * 1000;
        cooldownEnd = now() + d.cooldown * 1000;
        if (previewOver) { RPG.screen.close(); return; }
        if (before !== view()) { resetScroll(); pendingFocus = true; }
    }
    function openScreen() {
        open = true;
        RPG.screen.open({ id: "dmz_tournament", referenceHeight: DMZ_OPTS.menuRef(), background: "none", pause: false, elements: [],
            onRender: render, onMouse: mouse, onScroll: wheel, onClose: function () { open = false; } });
    }

    // ---- layout (ScaledScreen at least 420 wide, panel 80% of it) ----
    var L = {};
    function layout(ctx) {
        var s = ctx.width < MIN_GUI_WIDTH ? ctx.width / MIN_GUI_WIDTH : 1;
        L.s = s; L.w = ctx.width / s; L.h = ctx.height / s;
        L.gw = Math.round(L.w * PANEL_FRACTION); L.gh = Math.round(L.h * PANEL_FRACTION);
        L.gl = Math.floor((L.w - L.gw) / 2); L.gt = Math.floor((L.h - L.gh) / 2);
        L.cx = L.gl + PADDING; L.cy = L.gt + PADDING + HEADER_HEIGHT + MEMBERS_HEIGHT;
        L.cw = L.gw - PADDING * 2; L.ch = L.gh - PADDING * 2 - HEADER_HEIGHT - MEMBERS_HEIGHT - FOOTER_HEIGHT;
    }
    function buildButtons() {
        var list = [], v = view();
        if (v === "SIGNUP" && cooldownLeft() <= 0 && D.partyLeader) list.push({ key: "tournament.dragonminez.enter", act: function () { send("SIGN_UP"); } });
        if (v === "RULES" && D.myState === "PENDING") {
            list.push({ key: "tournament.dragonminez.accept", act: function () { send("ACCEPT_RULES"); } });
            list.push({ key: declineArmedUntil > now() ? "tournament.dragonminez.decline.confirm" : "tournament.dragonminez.decline", act: onDecline });
        }
        if (v === "BRACKET" && awaitingMyReady()) list.push({ key: "tournament.dragonminez.ready", act: function () { send("READY"); } });
        list.push({ key: "gui.dragonminez.close", act: function () { RPG.screen.close(); } });
        var total = list.length * BUTTON_WIDTH + (list.length - 1) * 6, x = L.gl + Math.floor((L.gw - total) / 2), y = L.gt + L.gh - PADDING - BUTTON_HEIGHT;
        list.forEach(function (b) { b.x = x; b.y = y; x += BUTTON_WIDTH + 6; });
        buttons = list;
    }
    function onDecline() {
        if (declineArmedUntil !== 0 && now() <= declineArmedUntil) { declineArmedUntil = 0; send("DECLINE_RULES"); return; }
        declineArmedUntil = now() + DECLINE_ARM_MS;
        RPG.uiSound("minecraft:ui.button.click", 0.25, 1);
    }

    // ---- render ----
    function render(ctx) {
        if (!D) return;
        if (D.phase === "PREVIEW" && phaseSecondsLeft() <= 0 && phaseEnd > 0) { RPG.screen.close(); return; }
        if (declineArmedUntil !== 0 && now() > declineArmedUntil) declineArmedUntil = 0;
        layout(ctx);
        ctx.gradient(0, 0, ctx.width, ctx.height, "#C0101010", "#D0101010");
        ctx.push();
        ctx.scale(L.s, L.s);
        var mx = ctx.mouseX / L.s, my = ctx.mouseY / L.s;
        L.mx = mx; L.my = my;
        slotHits = []; memberHits = []; hoveredSlot = null; hoveredMember = null;
        buildButtons();
        PANEL.draw(ctx, L.gl, L.gt, L.gw, L.gh);
        renderHeader(ctx);
        renderMembers(ctx, mx, my);
        if (view() === "RULES") renderRules(ctx); else renderLadder(ctx, mx, my);
        renderBar(ctx, mx, my);
        renderFooter(ctx);
        buttons.forEach(function (b) {
            var over = U.inside(mx, my, b.x, b.y, BUTTON_WIDTH, BUTTON_HEIGHT);
            ctx.image(BUTTONS, b.x, b.y, BUTTON_WIDTH, BUTTON_HEIGHT, 0, over ? 48 : 28, BUTTON_WIDTH, BUTTON_HEIGHT, 256, 256);
            U.bordered(ctx, tr(b.key), b.x + BUTTON_WIDTH / 2, b.y + 6, over ? "#FFFFA0" : "#FFFFFF", 0.5);
        });
        renderTooltips(ctx, mx, my);
        ctx.pop();
    }
    function chip(ctx, text, x, y, w, color, plate) {
        ctx.fill(x, y - 2, w, 13, plate.c, plate.a);
        U.bordered(ctx, text, x + 4, y, color);
    }
    function renderHeader(ctx) {
        var cx = L.gl + L.gw / 2, y = L.gt + PADDING;
        var title = tr(D.displayName), stars = "";
        for (var i = 0; i < 5; i++) stars += i < D.stars ? "★" : "☆";
        var tw = U.width(ctx, title), total = tw + 6 + U.width(ctx, stars), x = Math.round(cx - total / 2);
        U.bordered(ctx, title, x, y, TITLE_COLOR);
        U.bordered(ctx, stars, x + tw + 6, y, STARS_COLOR);
        var chips = [tr(D.gauntlet ? "tournament.dragonminez.format.gauntlet" : "tournament.dragonminez.format.bracket"),
            tr(D.lethal ? "tournament.dragonminez.lethal" : "tournament.dragonminez.non_lethal")];
        var chipX = L.gl + L.gw - PADDING;
        for (var c = chips.length - 1; c >= 0; c--) {
            var w = U.width(ctx, chips[c]) + 8, warn = c === 1 && D.lethal;
            chipX -= w;
            chip(ctx, chips[c], chipX, y, w, warn ? WARN_COLOR : ACCENT_COLOR, warn ? { c: "#FF6D6D", a: 0.25 } : { c: "#FFFFFF", a: 0.11 });
            chipX -= 4;
        }
        var color = D.eliminated ? WARN_COLOR : D.completed ? TITLE_COLOR : awaitingMyReady() ? ACCENT_COLOR : TEXT_COLOR;
        U.bordered(ctx, statusLine(), cx, y + 14, color, 0.5);
    }
    function statusLine() {
        if (D.lockedByOther) return tr("tournament.dragonminez.in_progress");
        if (D.completed) return tr("tournament.dragonminez.status.champion");
        if (D.eliminated) return tr("tournament.dragonminez.status.eliminated");
        if (D.signUp) return cooldownLeft() > 0 ? tr("tournament.dragonminez.status.cooldown", formatDuration(cooldownLeft())) : tr("tournament.dragonminez.status.open");
        var s = phaseSecondsLeft();
        switch (D.phase) {
            case "RULES": return D.myState === "PENDING" ? tr("tournament.dragonminez.status.rules", s) : tr("tournament.dragonminez.status.rules_waiting", pendingNames(), s);
            case "INTERMISSION":
                if (isMyBout()) return !D.myReady ? tr("tournament.dragonminez.status.accept", s) : tr("tournament.dragonminez.status.accepted", opponentName());
                return tr("tournament.dragonminez.status.waiting_accept", notReadyNames(), s);
            case "PREVIEW": return tr("tournament.dragonminez.status.preview", boutLine());
            case "BOUT": return tr("tournament.dragonminez.status.bout", boutLine());
        }
        return tr("tournament.dragonminez.status.open");
    }
    function pendingNames() { var n = D.members.filter(function (m) { return m.state === "PENDING"; }).map(function (m) { return m.name; }); return n.length ? n.join(", ") : "-"; }
    function notReadyNames() { var n = D.members.filter(function (m) { return m.active && !m.ready; }).map(function (m) { return m.name; }); return n.length ? n.join(", ") : "-"; }
    function fighterNames() {
        var f = D.members.filter(function (m) { return m.active; }).map(function (m) { return m.name; });
        if (f.length === 1) {
            var opp = D.rivalSlot ? slotName(D.rivalSlot) : null;
            if (!opp && D.gauntlet) opp = gauntletOpponentName();
            if (opp) f.push(opp);
        }
        return f;
    }
    function opponentName() {
        var f = fighterNames();
        for (var i = 0; i < f.length; i++) if (f[i] !== RPG.player.name) return f[i];
        return f.length ? f[0] : tr("tournament.dragonminez.slot.hidden");
    }
    function boutLine() {
        var f = fighterNames();
        if (!f.length) return tr("tournament.dragonminez.you");
        if (f.length < 2) return f[0];
        return tr("tournament.dragonminez.title.versus", f[0], f[1]);
    }
    function gauntletOpponentName() { var card = gauntletCard(), r = D.round; return r >= 0 && r < card.length ? slotName(card[r]) : null; }

    function stateGlyph(m) {
        if (m.active) return m.ready ? "✓" : "⚔";
        return { PENDING: "…", ACCEPTED: "✓", DECLINED: "✗", OUT: "✗", ALIVE: "" }[m.state] || "";
    }
    function memberColor(m) {
        if (m.active) return TITLE_COLOR;
        return { PENDING: TEXT_COLOR, ACCEPTED: "#9FFF9F", ALIVE: "#9FFF9F", DECLINED: "#7A7A85", OUT: "#7A7A85" }[m.state] || TEXT_COLOR;
    }
    function renderMembers(ctx, mx, my) {
        var y = L.gt + PADDING + HEADER_HEIGHT, names = [], total = 0;
        D.members.forEach(function (m) {
            var glyph = D.signUp && m.state !== "OUT" ? "" : stateGlyph(m);
            var n = (m.leader ? "★ " : "") + m.name + (glyph ? " " + glyph : "");
            names.push(n);
            total += U.width(ctx, n) + 8 + 4;
        });
        total = Math.max(0, total - 4);
        var x = Math.round(L.gl + L.gw / 2 - total / 2);
        D.members.forEach(function (m, i) {
            var w = U.width(ctx, names[i]) + 8, hov = mx >= x && mx < x + w && my >= y && my < y + 13;
            ctx.fill(x, y, w, 13, "#FFFFFF", hov ? 0.19 : 0.11);
            U.bordered(ctx, names[i], x + 4, y + 2, memberColor(m));
            var hit = { x: x, y: y, w: w, m: m };
            memberHits.push(hit);
            if (hov) hoveredMember = hit;
            x += w + 4;
        });
    }

    // ---- rules ----
    function renderRules(ctx) {
        var width = L.cw - 24 - SCROLLBAR, rules = buildRules(ctx, width), lh = 10, total = 0;
        rules.forEach(function (r) { total += r.lines.length * lh + 4; });
        total += 9 + 6;
        scroll.horizontal = false; contentScale = 1;
        layoutScroll(L.cx, L.cy, L.cw, L.ch, total);
        ctx.clip(L.cx, L.cy, L.cw, L.ch);
        var y = L.cy + 2 - scroll.pos;
        U.bordered(ctx, tr("tournament.dragonminez.rules.title"), L.cx + 4, y, TITLE_COLOR);
        y += 9 + 6;
        rules.forEach(function (r) {
            U.bordered(ctx, r.n + ".", L.cx + 4, y, ACCENT_COLOR);
            r.lines.forEach(function (l) { U.bordered(ctx, l, L.cx + 20, y, r.color); y += lh; });
            y += 4;
        });
        ctx.unclip();
    }
    function buildRules(ctx, width) {
        var R = D.rules, t = [], c = [];
        t.push(tr("tournament.dragonminez.rules.accept_bout", R.nextRound)); c.push(TEXT_COLOR);
        t.push(tr("tournament.dragonminez.rules.lose", formatDuration(R.reentry))); c.push(TEXT_COLOR);
        t.push(tr("tournament.dragonminez.rules.leave", R.forfeit, R.returnSeconds)); c.push(TEXT_COLOR);
        t.push(tr("tournament.dragonminez.rules.timeout", formatDuration(R.matchTimeout))); c.push(TEXT_COLOR);
        t.push(tr("tournament.dragonminez.rules.interference", R.exclusion)); c.push(TEXT_COLOR);
        t.push(tr("tournament.dragonminez.rules.countdown", R.countdown)); c.push(TEXT_COLOR);
        t.push(tr(D.lethal ? "tournament.dragonminez.rules.lethal" : "tournament.dragonminez.rules.knockout")); c.push(D.lethal ? WARN_COLOR : TEXT_COLOR);
        t.push(tr(D.gauntlet ? "tournament.dragonminez.rules.party.gauntlet" : "tournament.dragonminez.rules.party.bracket", R.rulesAccept)); c.push(TEXT_COLOR);
        return t.map(function (s, i) { return { n: i + 1, lines: U.wrap(ctx, s, width), color: c[i] }; });
    }

    // ---- the ladder (tree or gauntlet) ----
    function qualifierRounds() { var r = 0; for (var n = D.seeds.length; n > 1; n = Math.floor(n / 2)) r++; return r; }
    function challengers() { var c = [D.semifinalist]; if (D.finalist) c.push(D.finalist); c.push(D.champion); return c; }
    function challengerLabel(i, count) {
        if (i === 0) return "tournament.dragonminez.round.semi";
        if (i === count - 1 && count > 2) return "tournament.dragonminez.round.title";
        return "tournament.dragonminez.round.final";
    }
    function treeSize() {
        var seeds = Math.max(2, D.seeds.length), rows = qualifierRounds() + challengers().length + 1;
        return [LABEL_MARGIN + seeds * TREE_PITCH + TREE_PITCH * 1.5 + SLOT, rows * ROW_PITCH + 6];
    }
    function rowY(row, h) { return h - 4 - (row + 1) * ROW_PITCH + (ROW_PITCH - SLOT) / 2; }
    function treeCentreX(row, i) { return LABEL_MARGIN + (i + 0.5) * TREE_PITCH * (1 << row); }
    function entrantAt(round, pos) {
        var src = round === 0 ? D.seeds : (round - 1 < D.winners.length ? D.winners[round - 1] : []);
        return pos >= 0 && pos < src.length ? src[pos] : "";
    }
    function winnerOf(round, i) { if (round >= D.winners.length) return ""; var w = D.winners[round]; return i < w.length ? w[i] : ""; }
    function gauntletCard() { return D.seeds.concat(challengers()); }
    function showGauntletPlayer() { return D.revealed && !D.eliminated && D.phase !== "RULES"; }
    function gauntletSize() { var cells = gauntletCard().length + (showGauntletPlayer() ? 1 : 0); return [cells * GAUNTLET_PITCH - (GAUNTLET_PITCH - SLOT) + GAUNTLET_MARGIN * 2, SLOT + 34]; }

    function renderLadder(ctx, mx, my) {
        var size = D.gauntlet ? gauntletSize() : treeSize();
        var fitBoth = Math.min(L.cw / size[0], L.ch / size[1]);
        var scale = fitBoth >= 1 ? Math.min(MAX_UPSCALE, fitBoth) : Math.min(1, Math.max(L.cw / size[0], L.ch / size[1]));
        contentScale = scale;
        var sw = size[0] * scale, sh = size[1] * scale, vertical = sw <= L.cw + 0.5;
        scroll.horizontal = !vertical;
        layoutScroll(L.cx, L.cy, L.cw, L.ch, vertical ? sh : sw);
        if (pendingFocus) {
            pendingFocus = false;
            if (!D.gauntlet && vertical && scroll.max > 0) {
                var focusRow = D.completed ? qualifierRounds() + challengers().length : D.round;
                var centre = (rowY(focusRow, size[1]) + SLOT / 2) * scale;
                jumpTo(D.revealed ? Math.max(0, Math.min(scroll.max, centre - L.ch / 2)) : 0);
            }
        }
        if (vertical) {
            originX = L.cx + (L.cw - sw) / 2;
            originY = scroll.max > 0 ? L.cy - scroll.pos : L.cy + (L.ch - sh) / 2;
        } else {
            originX = L.cx - scroll.pos;
            originY = L.cy + (L.ch - sh) / 2;
        }
        var lx = (mx - originX) / scale, ly = (my - originY) / scale, inside = mx >= L.cx && mx < L.cx + L.cw && my >= L.cy && my < L.cy + L.ch;
        ctx.clip(L.cx, L.cy, L.cw, L.ch);
        ctx.push();
        ctx.translate(originX, originY);
        ctx.scale(scale, scale);
        if (D.gauntlet) renderGauntlet(ctx); else renderTree(ctx, size);
        ctx.pop();
        ctx.unclip();
        if (inside) slotHits.forEach(function (h) { if (lx >= h.x && lx < h.x + SLOT && ly >= h.y && ly < h.y + SLOT) hoveredSlot = h; });
    }
    function rect(ctx, x, y, w, h, color) { ctx.fill(x, y, w, h, color, 1); }
    function renderTree(ctx, size) {
        var q = qualifierRounds(), seeds = Math.max(2, D.seeds.length), cur = D.signUp || !D.revealed ? -1 : D.round;
        var playing = D.revealed && !D.completed && !D.eliminated && D.phase !== "RULES", h = size[1];
        for (var row = 0; row < q; row++) {
            var entries = seeds >> row, y = rowY(row, h), parentY = rowY(row + 1, h);
            for (var i = 0; i < entries; i++) {
                var id = entrantAt(row, i), winner = winnerOf(row, Math.floor(i / 2)), decided = !!winner;
                var current = playing && row === cur && isCurrentPair(row, i);
                var state = slotState(id, decided && winner !== id, current, row === 0);
                var cx = treeCentreX(row, i), x = cx - SLOT / 2, busY = parentY + SLOT + (y - parentY - SLOT) / 2;
                var color = current ? LINE_NOW_COLOR : decided && winner === id ? LINE_DONE_COLOR : LINE_COLOR;
                rect(ctx, cx - 0.5, busY, 1, y - busY, color);
                var pcx = treeCentreX(row + 1, Math.floor(i / 2)), left = Math.min(cx, pcx), right = Math.max(cx, pcx);
                rect(ctx, left - 0.5, busY, right - left + 1, 1, color);
                if (i % 2 === 0) rect(ctx, pcx - 0.5, parentY + SLOT, 1, busY - parentY - SLOT, decided ? LINE_DONE_COLOR : color);
                drawSlot(ctx, x, y, id, state);
            }
            drawRowLabel(ctx, tr("tournament.dragonminez.round.qualifier", row + 1), y, row === cur);
        }
        var trunkCx = treeCentreX(q, 0), chCx = trunkCx + TREE_PITCH * 1.5 + SLOT / 2, ch = challengers();
        var survivor = q === 0 ? (D.seeds.length ? D.seeds[0] : "") : winnerOf(q - 1, 0);
        for (var c = 0; c < ch.length; c++) {
            var round = q + c, w = winnerOf(round, 0), ry = rowY(round, h), nowRow = playing && cur === round;
            drawChallengerRow(ctx, ry, trunkCx, chCx, survivor, ch[c], w, nowRow, rowY(round + 1, h));
            drawRowLabel(ctx, tr(challengerLabel(c, ch.length)), ry, nowRow);
            survivor = w;
        }
        var topY = rowY(q + ch.length, h), crown = D.completed ? survivor : "";
        drawSlot(ctx, trunkCx - SLOT / 2, topY, crown, crown ? "PLAYER" : "CROWN");
        U.bordered(ctx, "★", Math.round(trunkCx), Math.round(topY) - 11, TITLE_COLOR, 0.5);
        drawRowLabel(ctx, tr("tournament.dragonminez.round.champion"), topY, D.completed);
    }
    function drawChallengerRow(ctx, y, trunkCx, chCx, trunkId, chId, winner, nowRow, parentY) {
        var decided = !!winner, color = nowRow ? LINE_NOW_COLOR : decided ? LINE_DONE_COLOR : LINE_COLOR, midY = y + SLOT / 2;
        rect(ctx, trunkCx + SLOT / 2, midY - 0.5, chCx - SLOT / 2 - trunkCx - SLOT / 2, 1, color);
        U.bordered(ctx, tr("tournament.dragonminez.vs"), Math.round((trunkCx + chCx) / 2), Math.round(midY) - 9, nowRow ? "#FF5555" : MUTED_COLOR, 0.5);
        rect(ctx, trunkCx - 0.5, parentY + SLOT, 1, y - parentY - SLOT, decided ? LINE_DONE_COLOR : color);
        drawSlot(ctx, trunkCx - SLOT / 2, y, trunkId, slotState(trunkId, decided && winner !== trunkId, nowRow, false));
        drawSlot(ctx, chCx - SLOT / 2, y, chId, slotState(chId, decided && winner !== chId, nowRow, false));
    }
    function drawRowLabel(ctx, label, y, hi) {
        U.bordered(ctx, label, LABEL_MARGIN - 10 - U.width(ctx, label), Math.round(y + SLOT / 2 - 4), hi ? TITLE_COLOR : MUTED_COLOR);
    }
    function seedPosition(slot, row) { if (!slot) return -1; var s = D.seeds.indexOf(slot); return s < 0 ? -1 : s >> row; }
    function isCurrentPair(row, i) {
        var a = seedPosition(D.activeSlot, row), r = seedPosition(D.rivalSlot, row);
        if (a < 0 && r < 0) return false;
        if (a >= 0 && (i === a || i === (a ^ 1))) return true;
        return r >= 0 && (i === r || i === (r ^ 1));
    }
    function slotState(id, defeated, current, seedRow) {
        if (id === HIDDEN_SLOT) return "HIDDEN";
        if (!id) return seedRow ? "EMPTY" : D.revealed ? "PENDING" : "HIDDEN";
        if (defeated) return "DEFEATED";
        if (current) return "CURRENT";
        if (isPlayerSlot(id)) return "PLAYER";
        return "UPCOMING";
    }
    function renderGauntlet(ctx) {
        var card = gauntletCard(), cur = D.revealed ? D.round : -1, showPlayer = showGauntletPlayer();
        var cells = [], states = [], rounds = [], versusAfter = -1;
        for (var i = 0; i < card.length; i++) {
            if (showPlayer && i === cur && !D.completed) { versusAfter = cells.length; cells.push(PLAYER_SLOT); states.push("PLAYER"); rounds.push(-1); }
            var id = card[i];
            cells.push(id); rounds.push(i);
            if (id === HIDDEN_SLOT) states.push("HIDDEN");
            else if (cur >= 0 && i < cur) states.push("DEFEATED");
            else if (i === cur && showPlayer && !D.completed) states.push("CURRENT");
            else states.push("UPCOMING");
        }
        if (showPlayer && D.completed) { cells.push(PLAYER_SLOT); states.push("PLAYER"); rounds.push(-1); }
        var top = 22, left = GAUNTLET_MARGIN;
        for (var c = 0; c < cells.length; c++) {
            var x = left + c * GAUNTLET_PITCH, st = states[c];
            if (c < cells.length - 1 && c !== versusAfter) rect(ctx, x + SLOT + 3, top + SLOT / 2, GAUNTLET_PITCH - SLOT - 6, 1, st === "DEFEATED" ? LINE_DONE_COLOR : LINE_COLOR);
            drawSlot(ctx, x, top, cells[c], st);
            var round = rounds[c];
            if (round >= 0) {
                var chI = round - D.seeds.length, chCount = card.length - D.seeds.length;
                var label = chI >= 0 ? tr(challengerLabel(Math.min(chI, chCount - 1), chCount)) : tr("tournament.dragonminez.round.qualifier", round + 1);
                U.bordered(ctx, label, Math.round(x + SLOT / 2), Math.round(top) - 12, st === "CURRENT" ? TITLE_COLOR : MUTED_COLOR, 0.5);
            }
        }
        if (versusAfter >= 0) {
            var vsX = left + versusAfter * GAUNTLET_PITCH + SLOT + (GAUNTLET_PITCH - SLOT) / 2;
            U.bordered(ctx, tr("tournament.dragonminez.vs"), Math.round(vsX), Math.round(top + SLOT / 2) - 4, "#FF5555", 0.5);
        }
    }
    function drawSlot(ctx, x, y, id, state) {
        slotHits.push({ x: x, y: y, id: id, state: state });
        ctx.fill(x, y, SLOT, SLOT, state === "DEFEATED" ? "#080810" : "#101018", 0.82);
        if (state === "HIDDEN" || state === "CROWN") {
            ctx.push();
            ctx.translate(x + SLOT / 2, y + SLOT / 2);
            ctx.scale(2, 2);
            U.bordered(ctx, state === "CROWN" ? "★" : "?", 0, -4, state === "CROWN" ? TITLE_COLOR : MUTED_COLOR, 0.5);
            ctx.pop();
        } else if (state !== "EMPTY" && state !== "PENDING") {
            renderPortrait(ctx, id, x, y, isPlayerSlot(id), state === "DEFEATED");
        }
        var dim = state === "DEFEATED" || state === "PENDING" || state === "EMPTY", f = FRAME[state] || FRAME.UPCOMING;
        ctx.quad(SLOT_FRAMES, x, y, SLOT, SLOT, f[0] / 256, f[1] / 256, (f[0] + FRAME_SOURCE) / 256, (f[1] + FRAME_SOURCE) / 256, dim ? "#737380" : "#FFFFFF", 1);
    }
    // fighters draw from their model (still, facing you, feet 30% down + height); players from the world when loaded
    function renderPortrait(ctx, id, bx, by, isPlayer, greyed) {
        var clipX = bx + 1, clipY = by + 1;
        if (isPlayer) {
            var mine = id === PLAYER_SLOT || id === D.mySlot, eid = D.entities ? D.entities[id] : null, ent = eid ? RPG.world.entity(eid) : null;
            if (!mine && !ent) {
                U.bordered(ctx, slotName(id), Math.round(bx + SLOT / 2), Math.round(by + SLOT / 2) - 4, greyed ? "#7A7A85" : "#FFFFFF", 0.5);
                return;
            }
            var hgt = 1.8, sc = Math.max(6, Math.min(140, Math.round((SLOT - 4) / (hgt * 0.8)))), feet = Math.round(by + SLOT * 0.3 + hgt * sc);
            ctx.clip(clipX, clipY, SLOT - 2, SLOT - 2);
            if (mine) ctx.player(Math.round(bx + SLOT / 2), feet, sc, 180, { still: true });
            else ctx.entity(eid, Math.round(bx + SLOT / 2), feet, sc, 0);
            ctx.unclip();
        } else {
            var info = D.fighters ? D.fighters[id] : null;
            if (!info || !info.geo) return;
            var h = Math.max(0.6, 1.9 * (info.geo.scale || 1)), s = Math.max(6, Math.min(140, Math.round((SLOT - 4) / (h * 0.8))));
            ctx.clip(clipX, clipY, SLOT - 2, SLOT - 2);
            ctx.npc("dmzt:" + id, { geo: info.geo, name: "" }, Math.round(bx + SLOT / 2), Math.round(by + SLOT * 0.3 + h * s), s, 0);
            ctx.unclip();
        }
        if (greyed) ctx.fill(clipX, clipY, SLOT - 2, SLOT - 2, "#0A0A14", 0.62);       // GreyingVertexConsumer: grey at 32%
    }
    function slotName(id) {
        if (id === PLAYER_SLOT) return RPG.player.name || tr("tournament.dragonminez.you");
        if (isPlayerSlot(id)) return (D.slotNames && D.slotNames[id]) || tr("tournament.dragonminez.you");
        if (id === HIDDEN_SLOT) return tr("tournament.dragonminez.slot.hidden");
        if (!id) return "-";
        var info = D.fighters ? D.fighters[id] : null;
        if (info && U.hasTr(info.key)) return tr(info.key);
        return info ? info.name : id;
    }

    function renderFooter(ctx) {
        var y = L.gt + L.gh - PADDING - BUTTON_HEIGHT + 6, hint = hintLine();
        var bw = buttons.length * BUTTON_WIDTH + Math.max(0, buttons.length - 1) * 6, maxW = Math.max(60, (L.gw - bw) / 2 - PADDING - 8);
        var lines = U.wrap(ctx, hint, maxW);
        for (var i = 0; i < Math.min(2, lines.length); i++) U.bordered(ctx, lines[i], L.gl + PADDING, y - 4 + i * 9, MUTED_COLOR);
        if (D.phase === "PREVIEW" && !D.signUp) {
            var cd = tr("tournament.dragonminez.preview_countdown", Math.max(1, phaseSecondsLeft()));
            ctx.push();
            ctx.translate(L.gl + L.gw - PADDING, y + 4);
            ctx.scale(1.3, 1.3);
            U.bordered(ctx, cd, 0, -4, TITLE_COLOR, 1);
            ctx.pop();
        }
    }
    function hintLine() {
        switch (view()) {
            case "SIGNUP": return tr("tournament.dragonminez.hint.signup");
            case "LOCKED": return tr("tournament.dragonminez.hint.locked");
            case "RULES": return D.myState === "PENDING" ? tr("tournament.dragonminez.hint.rules") : tr("tournament.dragonminez.hint.answered");
        }
        return awaitingMyReady() ? tr("tournament.dragonminez.hint.accept") : D.gauntlet ? tr("tournament.dragonminez.hint.gauntlet") : tr("tournament.dragonminez.hint.bracket");
    }

    // TextUtil.renderAdvancedTooltip: centred title, a rule, centred lines, edge colour 6D8CFF
    function advTooltip(ctx, title, lines, extras, mx, my) {
        var rows = [], w = U.width(ctx, title);
        lines.forEach(function (l) { w = Math.max(w, U.width(ctx, l[0])); });
        (extras || []).forEach(function (l) { w = Math.max(w, U.width(ctx, l[0])); });
        var h = 12 + lines.length * 10 + (extras && extras.length ? 8 + extras.length * 10 : 0) + 4, bw = w + 12;
        var x = Math.max(4, Math.min(L.w - bw - 4, mx - bw / 2)), y = my + 12;
        if (y + h > L.h) y = my - h - 4;
        ctx.fill(x, y, bw, h, "#100010", 0.94);
        ctx.fill(x, y, bw, 1, "#6D8CFF", 0.9); ctx.fill(x, y + h - 1, bw, 1, "#6D8CFF", 0.5);
        ctx.fill(x, y, 1, h, "#6D8CFF", 0.7); ctx.fill(x + bw - 1, y, 1, h, "#6D8CFF", 0.7);
        var cx = x + bw / 2, yy = y + 3;
        U.plain(ctx, title, cx, yy, "#FFFFFF", 0.5); yy += 9;
        ctx.fill(x + 3, yy, bw - 6, 1, "#6D8CFF", 0.5); yy += 3;
        lines.forEach(function (l) { U.plain(ctx, l[0], cx, yy, l[1], 0.5); yy += 10; });
        if (extras && extras.length) {
            yy += 3; ctx.fill(x + 3, yy, bw - 6, 1, "#6D8CFF", 0.5); yy += 5;
            extras.forEach(function (l) { U.plain(ctx, l[0], cx, yy, l[1], 0.5); yy += 10; });
        }
    }
    function renderTooltips(ctx, mx, my) {
        if (hoveredSlot) {
            var s = hoveredSlot, title, lines = [];
            if (s.state === "HIDDEN") { title = tr("tournament.dragonminez.slot.hidden"); lines.push([tr("tournament.dragonminez.slot.hidden_hint"), "#AAAAAA"]); }
            else if (s.state === "EMPTY") title = tr("tournament.dragonminez.slot.empty");
            else if (s.state === "PENDING") title = tr("tournament.dragonminez.slot.pending");
            else if (s.state === "CROWN") { title = tr("tournament.dragonminez.slot.champion_seat"); lines.push([tr("tournament.dragonminez.slot.pending"), "#AAAAAA"]); }
            else {
                title = slotName(s.id);
                var st = D.stats ? D.stats[s.id] : null;
                if (st) {
                    lines.push([tr("tournament.dragonminez.stat.health", st.health), "#FF5555"]);
                    lines.push([tr("tournament.dragonminez.stat.melee", st.melee), "#FFAA00"]);
                    lines.push([tr("tournament.dragonminez.stat.ki", st.ki), "#55FFFF"]);
                }
                if (s.id === PLAYER_SLOT || s.id === D.mySlot) lines.push([tr("tournament.dragonminez.slot.you"), "#55FF55"]);
            }
            advTooltip(ctx, title, lines, null, mx, my);
            return;
        }
        if (hoveredMember) {
            var m = hoveredMember.m, d = [];
            if (m.leader) d.push([tr(D.members.length > 1 ? "tournament.dragonminez.member.leader" : "tournament.dragonminez.member.solo"), "#FFAA00"]);
            if (m.active && m.ready) d.push([tr("tournament.dragonminez.member.ready"), "#FFFFFF"]);
            else d.push([tr(m.active ? "tournament.dragonminez.member.active" : "tournament.dragonminez.member." + String(m.state).toLowerCase()), "#FFFFFF"]);
            advTooltip(ctx, m.name, d, null, mx, my);
        }
    }

    // ---- ScrollbarState (bar 4 wide, min thumb 12, step 28, smooth 0.08 s) ----
    function resetScroll() { scroll.pos = 0; scroll.target = 0; scroll.dragging = false; }
    function layoutScroll(x, y, w, h, content) {
        scroll.view = [x, y, w, h];
        scroll.max = Math.max(0, content - (scroll.horizontal ? w : h));
        scroll.active = now();
        var t = now(), dt = scroll.last ? Math.min(0.1, (t - scroll.last) / 1000) : 0;
        scroll.last = t;
        scroll.target = Math.max(0, Math.min(scroll.max, scroll.target));
        if (scroll.dragging || dt === 0) scroll.pos = scroll.target;
        else scroll.pos += (scroll.target - scroll.pos) * (1 - Math.exp(-dt / 0.08));
        if (Math.abs(scroll.pos - scroll.target) < 0.05) scroll.pos = scroll.target;
        scroll.pos = Math.max(0, Math.min(scroll.max, scroll.pos));
    }
    function jumpTo(v) { scroll.target = Math.max(0, Math.min(scroll.max, v)); scroll.pos = scroll.target; }
    function track() {
        var v = scroll.view;
        return scroll.horizontal ? { cross: v[1] + v[3] - SCROLLBAR, start: v[0], len: v[2], view: v[2] } : { cross: v[0] + v[2] - SCROLLBAR, start: v[1], len: v[3], view: v[3] };
    }
    function thumbSize(t) { if (scroll.max <= 0) return t.len; return Math.max(Math.min(12, t.len), Math.min(t.len, t.len * t.view / (t.view + scroll.max))); }
    function thumbStart(t, th) { return scroll.max <= 0 ? t.start : t.start + (t.len - th) * Math.max(0, Math.min(1, scroll.pos / scroll.max)); }
    function overTrack(mx, my) {
        if (scroll.max <= 0) return false;
        var t = track(), along = scroll.horizontal ? mx : my, cross = scroll.horizontal ? my : mx;
        return cross >= t.cross - 4 && cross <= t.cross + SCROLLBAR + 4 && along >= t.start && along <= t.start + t.len;
    }
    function renderBar(ctx, mx, my) {
        if (scroll.max <= 0) return;
        var t = track(), th = thumbSize(t), st = thumbStart(t, th), act = scroll.dragging || (overTrack(mx, my) && (scroll.horizontal ? mx : my) >= st && (scroll.horizontal ? mx : my) <= st + th);
        var thumbColor = act ? "#C9DCFF" : "#A9C7FF", thumbA = act ? 1 : 0.75;
        if (scroll.horizontal) { ctx.fill(t.start, t.cross, t.len, SCROLLBAR, "#000000", 0.31); ctx.fill(st, t.cross, th, SCROLLBAR, thumbColor, thumbA); }
        else { ctx.fill(t.cross, t.start, SCROLLBAR, t.len, "#000000", 0.31); ctx.fill(t.cross, st, SCROLLBAR, th, thumbColor, thumbA); }
    }
    function pointerScroll(along) {
        var t = track(), travel = t.len - scroll.grabThumb;
        if (travel <= 0 || scroll.max <= 0) return 0;
        return Math.max(0, Math.min(1, (along - scroll.grab - t.start) / travel)) * scroll.max;
    }

    // ---- input ----
    function mouse(x, y, button, action) {
        if (!D) return;
        var mx = x / (L.s || 1), my = y / (L.s || 1);
        if (action === "down" && button === 0) {
            if (overTrack(mx, my)) {
                var t = track(), along = scroll.horizontal ? mx : my, th = thumbSize(t), st = thumbStart(t, th);
                scroll.grabThumb = th;
                scroll.grab = along >= st && along <= st + th ? along - st : th / 2;
                scroll.dragging = true;
                jumpTo(pointerScroll(along));
                return true;
            }
            for (var i = 0; i < buttons.length; i++) {
                var b = buttons[i];
                if (U.inside(mx, my, b.x, b.y, BUTTON_WIDTH, BUTTON_HEIGHT)) { b.act(); return true; }
            }
        } else if (action === "drag" && scroll.dragging) {
            jumpTo(pointerScroll(scroll.horizontal ? mx : my));
            return true;
        } else if (action === "up" && button === 0) scroll.dragging = false;
    }
    function wheel(x, y, delta) {
        if (scroll.max <= 0 || !delta) return;
        scroll.target = Math.max(0, Math.min(scroll.max, scroll.target - (delta > 0 ? 1 : -1) * SCROLL_STEP));
    }

    // =====================================================================================
    //  TournamentOverlay: countdown / FIGHT! / preview on screen, and the notification card
    // =====================================================================================
    var O = { phase: null, end: 0, total: 1, fightUntil: 0, lastSecond: -1, fighter: false, left: "", right: "" };
    var FIGHT_MS = 1500;                     // FIGHT_TICKS 30
    function nameOf(n) { if (!n) return ""; if (n.k && U.hasTr(n.k)) return tr(n.k); return n.t || ""; }
    RPG.net.on("dmz_tourn_phase", function (m) {
        if (!m) return;
        if (m.phase === "CLEAR") { clearOverlay(); return; }
        var changed = O.phase !== m.phase;
        O.phase = m.phase; O.fighter = !!m.fighter; O.left = nameOf(m.left); O.right = nameOf(m.right);
        var ms = Math.max(0, m.seconds) * 1000;
        O.end = now() + ms;
        if (changed || ms > O.total) O.total = Math.max(1, ms);
        O.lastSecond = secondsLeft();
        if (changed) O.fightUntil = 0;
        DMZ_NOTIFY.pin("tournament", notification, DMZ_NOTIFY.PRIORITY.TOURNAMENT);
    });
    function secondsLeft() { return Math.max(0, Math.ceil((O.end - now()) / 1000)); }
    function clearOverlay() { O.phase = null; O.fightUntil = 0; O.end = 0; DMZ_NOTIFY.unpin("tournament"); }
    function fighting() { return O.fightUntil > now(); }
    function notification() {
        if (!O.phase) return null;
        if (O.fighter && O.phase !== "NEXT_ROUND") return null;
        var versus = O.phase !== "NEXT_ROUND" || fighting();
        return { title: tr("tournament.dragonminez.title"), subtitle: versus ? tr("tournament.dragonminez.title.versus", O.left, O.right) : null,
            description: noticeText(),
            extra: fighting() || O.phase === "NEXT_ROUND" ? null : tr("tournament.dragonminez.notice.seconds_left", Math.max(1, secondsLeft())) };
    }
    function noticeText() {
        if (!O.phase) return "";
        if (fighting()) return tr("tournament.dragonminez.fight");
        var s = Math.max(1, secondsLeft());
        switch (O.phase) {
            case "NEXT_ROUND": return O.fighter ? tr("tournament.dragonminez.notice.accept", s) : tr("tournament.dragonminez.notice.waiting_accept", O.left, s);
            case "PREVIEW": return tr("tournament.dragonminez.title.preview", s);
            case "COUNTDOWN": return tr("tournament.dragonminez.notice.countdown_short");
        }
        return "";
    }
    // TournamentOverlay.tick: a pling each countdown second for the fighter, the dragon's growl at FIGHT!
    RPG.every(1, function () {
        if (!O.phase) return;
        if (O.fightUntil) { if (now() >= O.fightUntil) clearOverlay(); return; }
        if (O.end <= 0) return;
        var s = secondsLeft();
        if (s !== O.lastSecond) {
            O.lastSecond = s;
            if (O.fighter && s > 0 && O.phase === "COUNTDOWN") RPG.sound("minecraft:block.note_block.pling", 1, 1);
        }
        if (now() >= O.end && O.phase === "COUNTDOWN") {
            O.end = 0;
            O.fightUntil = now() + FIGHT_MS;
            if (O.fighter) RPG.sound("minecraft:entity.ender_dragon.growl", 1, 1);
        }
    });
    function drawTitle(ctx, text, cx, y, scale, color) {
        ctx.textStyled(text, cx, y - 4.5 * scale, scale, color, 1, 0.5, FONT, null);
    }
    function drawOverlay(ctx) {
        if (!O.phase || !O.fighter || O.phase === "NEXT_ROUND") return;
        if (RPG.screen.getOpen() === "dmz_tournament") return;
        var cx = ctx.width / 2, y = ctx.height / 3;
        if (fighting()) { drawTitle(ctx, tr("tournament.dragonminez.fight"), cx, y, 4, "#FF5555"); return; }
        var s = Math.max(1, secondsLeft());
        if (O.phase === "COUNTDOWN") drawTitle(ctx, String(s), cx, y, 5, "#FFD700");
        else if (O.phase === "PREVIEW") drawTitle(ctx, tr("tournament.dragonminez.title.preview", s), cx, y, 2, "#FFD700");
    }

    // ---- SagaHaloLayer: the halo of the dead over a fighter. raceparts.geo.json's "halo" bone drawn on the head: a square
    // ring of 1 px bars, 8 px across, 4 px above the top of the head, FFF461 at 0.75, glowing (ModRenderTypes.energy) ----
    var PX = 0.9375 / 16;                     // one model pixel at the player-sized model scale
    RPG.net.on("dmz_tourn_halo", function (d) {
        if (!d || !d.id) return;
        var e = RPG.world.entity(d.id);
        if (!e) return;
        var y = e.height + 4.5 * PX, h = 3.5 * PX, sides = [[-h, -h, h, -h], [h, -h, h, h], [h, h, -h, h], [-h, h, -h, -h]];
        sides.forEach(function (s, i) {
            RPG.world3d.line("dmzt_halo_" + d.id + "_" + i, { entity: d.id, from: [s[0], y, s[1]], to: [s[2], y, s[3]],
                width: PX, color: "#FFF461", alpha: 0.75, blend: "additive", emissive: true, ticks: d.ticks || 120 });
        });
    });

    RPG.on("load", function () { RPG.hud.onRender(drawOverlay); });
    RPG.on("unload", function () { clearOverlay(); });
    return { isOpen: function () { return open; } };
})();
