// =====================================================================================
//  61_dbr_space.js - space on the player's computer (port of DMZ Ragnarok's Space client)
// =====================================================================================
//  The space sky (SpaceDimensionEffects + SpaceBodyRenderer), drawn with RPG.sky: the
//  starfield and dust; the sun and every star as DMZR's animated solar-flare sun model
//  tinted to its colour; the main planets with DMZR's sheets, tints, cloud shells,
//  glowing rims, rings and moons; the generated systems' planets; black holes (a dark
//  core, a swirling accretion disc). On generated planets and moons the same sky hangs
//  overhead, with that world's weather (PlanetWeather). Also: the autopilot and landing
//  descent, black-hole pull on the pod, the planet info
//  overlay, the radar dial (SuRadarHud) and the star map (SpaceStarMapScreen; M).
// =====================================================================================
(function () {
    var O = DBR_SPACE_ORBITS, G = DBR_SPACE_GEN, B = DBR_SPACE_BODIES, SPACE = O.SPACE, SURFACE = B.SURFACE;
    var TEX = "dbr:textures/space/", MODEL = "dbr:space/";
    var FONT = "dmzpack:smooth", RADAR = "dmzpack:textures/gui/radar.png";
    var S = { autopilot: "", offset: 0, origin: "", surface: "", info: {}, superBalls: [], superRadar: false };
    // Super Dragon Ball bodies: in the 3D sky only within 2000 blocks; on the star map (and the Super radar) from any
    // distance, for someone carrying the Super Dragon Radar
    var SUPER_SHOW = 2000;
    // for the Super radar (58_dragon_balls.js): where each Super planet is now, in space coordinates
    dbrSuperPlanets = function () {
        var out = [], ep = Date.now();
        try { B.superList().forEach(function (sp) { if (!B.isDestroyed("susuper:" + sp.star)) { var q = B.superPos(sp, ep); out.push({ x: q.x, z: q.z, star: sp.star }); } }); } catch (e) { }
        return out;
    };
    function superVisible(pos) { return RPG.player.dimension === SPACE && dist(me(), pos) <= SUPER_SHOW + B.SUPER_RADIUS; }
    function superOnMap() { return !!S.superRadar; }
    var NAMES = { overworld: "Earth", namek: "Namek", sacredkaiplanet: "Sacred Kai", demon_realm: "Demon Realm", planet_vegeta: "Planet Vegeta", beerus_planet: "Beerus' Planet", cereal_planet: "Planet Cereal", sun: "Sun" };

    function cfg(k, fb) { var v = RPG.config.get("dbr_space", k, fb); return v === null || v === undefined ? fb : Number(v); }
    function now() { return Date.now() + S.offset; }
    function me() { return { x: RPG.player.x, y: RPG.player.y, z: RPG.player.z }; }
    function dist(a, b) { var dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z; return Math.sqrt(dx * dx + dy * dy + dz * dz); }
    function fmt(d) { return d >= 10000 ? (d / 1000).toFixed(1) + "k" : String(Math.round(d)); }
    var lastCfg = "";
    function syncCfg() {
        var k = cfg("distanceScale", 0.25) + "/" + cfg("bodyPlaneY", 0);
        if (k === lastCfg) return false;
        lastCfg = k;
        B.configure(cfg("distanceScale", 0.25), cfg("bodyPlaneY", 0));
        return true;
    }
    syncCfg();
    function nameOf(b) {
        if (!b) return "?";
        if (b.kind === "fixed" || b.kind === "sun") return NAMES[b.id] || b.id;
        if (b.kind === "moon") return (NAMES[b.moon.parent.id] || b.moon.parent.id) + " Moon";
        if (b.kind === "planet") return "Planet " + b.id.substring(6, 12).toUpperCase();
        if (b.kind === "star") return b.lone ? "Star" : "Sun " + b.id.substring(7, 11).toUpperCase();
        if (b.kind === "hole") return "Black Hole";
        if (b.kind === "super") return "Super Dragon Ball Planet " + b.star;
        return b.id;
    }

    // ---- DMZR looks (SpaceBodyRenderer) ----
    function rgb(c) { return [(c >> 16) & 255, (c >> 8) & 255, c & 255]; }
    function hex(r, g, b) { return O.hex((Math.max(0, Math.min(255, Math.round(r))) << 16) | (Math.max(0, Math.min(255, Math.round(g))) << 8) | Math.max(0, Math.min(255, Math.round(b)))); }
    /** tint x min(1/sheet mean, 1/max channel): DMZR lifts grayscale sheets back to the tint's brightness */
    function lift(c, mean) { var v = rgb(c), m = Math.max(v[0], v[1], v[2]) / 255, k = Math.min(1 / mean, m > 0 ? 1 / m : 1); return hex(v[0] * k, v[1] * k, v[2] * k); }
    function brightenSaturate(c) {
        var v = rgb(c), max = Math.max(1, v[0], v[1], v[2]), k = 245 / max, r = v[0] * k, g = v[1] * k, b = v[2] * k, grey = (r + g + b) / 3;
        return hex(grey + (r - grey) * 1.4, grey + (g - grey) * 1.4, grey + (b - grey) * 1.4);
    }
    function ringTint(c) {
        var v = rgb(c), mean = (v[0] + v[1] + v[2]) / 3, r = v[0] + (mean - v[0]) * 0.5, g = v[1] + (mean - v[1]) * 0.5, b = v[2] + (mean - v[2]) * 0.5;
        r += (0xE8 - r) * 0.55; g += (0xDE - g) * 0.55; b += (0xC8 - b) * 0.55;
        return (Math.round(r) << 16) | (Math.round(g) << 8) | Math.round(b);
    }
    var MEAN = { mercury: 0.561, venus: 0.734, mars: 0.585, jupiter: 0.707, neptune: 0.531, earth: 0.633, sun: 1 };
    var SWATCH = { earth: 0x89F3FF, mars: 0xFF9556, venus: 0xFDCC79, neptune: 0x6CBDFF, jupiter: 0xFFD397, mercury: 0xD5C0B1 };
    var MAIN_POOL = ["jupiter", "mars", "mercury", "neptune", "venus"], GEN_POOL = ["mercury", "venus", "mars", "jupiter", "neptune"];
    var PALETTE = [0x9E5B3E, 0xA9744E, 0x82613F, 0xB08A50, 0xC2A47A, 0x9A8467, 0x8C4C3B, 0x8F8579, 0x3E5F70, 0x89A4B2, 0x5E6B42, 0x3F6A62];
    var FIXED_TINT = { "dragonminez:namek": 0x33B24D, "dragonminez:sacredkaiplanet": 0x42B43C, "dmz_ragnarok:planet_vegeta": 0x9A5F32 };
    var BOX = { size: 64, north: [8, 8, 16, 16], south: [24, 8, 32, 16], west: [0, 8, 8, 16], east: [16, 8, 24, 16], down: [16, 0, 24, 8], up: [8, 0, 16, 8] };
    var SPIN = 5, STAR_SPIN = 3, TILT = 20;          // DMZR 0.25 / 0.15 degrees a tick

    function cloud(key) { var g = O.cloudGrey(key) * 255; return { shape: "cube", texture: TEX + "cloud_texture.png", uv: BOX, scale: 1.125, color: hex(g, g, g), cull: "back", shading: "entity" }; }
    function rim(color) { return { shape: "cube", scale: 1.06, color: color, alpha: 0.85, cull: "front", shading: "entity" }; }
    function ringLayers(key, base, tilt, own) {
        var bands = O.ringBands(key);
        if (!bands) return [];
        var uranus = O.floorMod(O.packHash(key, "ringtex"), 2) === 1, tex = TEX + (uranus ? "uranus_rings_grayscale.png" : "saturn_rings_grayscale.png");
        var col = lift(ringTint(base), uranus ? 0.954 : 0.822), out = [];
        for (var i = 0; i < bands; i++) {
            var l = { shape: "plane", texture: tex, scale: 2.1 + i * 0.55, color: col, cull: "none" };
            if (own) { l.spin = SPIN; l.tilt = tilt; }
            out.push(l);
        }
        return out;
    }
    /** A main planet (drawFixedBody): body sheet or model, rings (the uranus plane at 45 degrees), cloud shell, rim. */
    function fixedLook(b) {
        var key = b.key, earth = b.id === "overworld", vegeta = b.id === "planet_vegeta";
        var base = earth ? 0xFFFFFF : (FIXED_TINT[key] !== undefined ? FIXED_TINT[key] : b.tint);
        var modelName = MAIN_POOL[O.floorMod(O.packHash(key, "mainbody"), 5)];
        var spec = { radius: b.radius, spin: SPIN, tilt: TILT, shading: "entity", minSize: 0.5 };
        if (earth) { spec.shape = "cube"; spec.texture = TEX + "earf.png"; spec.uv = BOX; spec.color = "#FFFFFF"; }
        else if (vegeta) { spec.model = MODEL + "vegeta"; spec.color = "#FFFFFF"; }
        else { spec.model = MODEL + modelName + "_grayscale"; spec.color = lift(base, MEAN[modelName]); }
        var rimColor = earth ? O.hex(SWATCH.earth) : brightenSaturate(base);
        spec.layers = (earth ? [] : ringLayers(key, base, 45, true)).concat([cloud(key), rim(rimColor)]);
        return spec;
    }
    function moonLook(m) {
        var g = 0xB0;
        return { radius: m.radius, shape: "cube", texture: TEX + "earf_grayscale.png", uv: BOX, color: hex(g, g, g), spin: SPIN, tilt: TILT, shading: "entity", minSize: 0.3,
            layers: [rim(brightenSaturate(0xB0B0B0))] };
    }
    /** A generated planet (drawPlanet): a grayscale pack model in a dull palette colour, tilted rings, rim; plus a cloud shell. */
    function planetLook(id) {
        var base = PALETTE[O.floorMod(O.packHash(id, "ptint"), PALETTE.length)], modelName = GEN_POOL[O.floorMod(O.packHash(id, "planet"), 5)];
        var tilt = O.ringBands(id) > 0 ? O.ringTilt(id) : TILT;
        return { model: MODEL + modelName + "_grayscale", color: lift(base, MEAN[modelName]), spin: SPIN, tilt: tilt, shading: "entity", minSize: 0.35,
            layers: ringLayers(id, base, tilt, false).concat([cloud(id), rim(brightenSaturate(base))]) };
    }
    /**
     * A sun or star (drawStar, pack-model path): the grayscale sun model x3, tinted, 0.15 degrees a tick, tilted 20; its
     * four flare planes cross the body and carry 10-frame flare loops (3 ticks a frame) that rise off an edge and arc
     * back into the surface. DMZR draws the whole model as entityCutout: opaque, depth-writing and back-face culled, so
     * each loop's root disappears into the body and the planes hide each other and the rim behind them; blend "cutout"
     * is that. Then the rim shell, and no corona (DMZR's halo billboards are only its no-model fallback).
     */
    function starLook(radius, tint) {
        return { model: MODEL + "sun_grayscale", color: lift(tint, 1), radius: radius * 3, spin: STAR_SPIN, tilt: TILT, shading: "entity", minSize: 1.0,
            blend: "cutout", layers: [rim(brightenSaturate(tint))] };
    }
    /** A Super Dragon Ball body (drawSuper): flat grey while its God of Destruction lives; then the warm ball with its star showing through. */
    // drawSuper: the dball_super4x ball as its 13 overlapping slabs, drawn as ONE surface (depth prepass, then colour
    // where depth is equal); unclaimed flat grey and opaque, claimed the warm ball colour at 0.7 with the red star sprite
    // inside; the rim is the slabs' convex hull 1.10x, far faces only, a lighter shade. 0.4 degrees a tick, tilted 12.
    var SUPER_GEO = [[-0.8261, -0.9348, -0.8261, 0.8261, -0.1087, 0.8261], [-0.8261, 0.0217, -0.8261, 0.8261, 0.8043, 0.8261], [-0.6609, -0.9783, -0.6609, 0.6609, -0.2391, 0.6609],
        [-0.6696, 0.1087, -0.6696, 0.6696, 0.8913, 0.6696], [-0.4957, 0.2826, -0.5826, 0.4957, 0.9783, 0.5826], [-0.6696, -0.6826, -1.0, 0.6609, 0.5435, -0.2174],
        [-0.8261, -0.8478, 0.0870, 0.8261, 0.7174, 0.9130], [-0.6522, -0.7174, 0.2174, 0.6522, 0.5870, 1.0], [-0.8261, -0.8478, -0.9130, 0.8261, 0.7174, -0.0870],
        [0.0435, -0.8478, -0.8261, 0.9130, 0.7174, 0.8261], [-0.9130, -0.8478, -0.8261, -0.0435, 0.7174, 0.8261], [-1.0, -0.7174, -0.6522, -0.2174, 0.5870, 0.6522],
        [0.2174, -0.7174, -0.6522, 1.0, 0.5870, 0.6522]];
    var SUPER_HULL = [-1.1, 0.6457, 0.7174, -1.1, 0.6457, -0.7174, -1.1, -0.7891, -0.7174, -1.1, 0.6457, 0.7174, -1.1, -0.7891, -0.7174, -1.1, -0.7891, 0.7174, -1.0043, -0.9326, 0.9087, -1.1, -0.7891, 0.7174, -1.1, -0.7891, -0.7174, -1.0043, -0.9326, 0.9087, -1.1, -0.7891, -0.7174, -1.0043, -0.9326, -0.9087, -1.1, 0.6457, -0.7174, -1.0043, 0.7891, -0.9087, -1.0043, -0.9326, -0.9087, -1.1, 0.6457, -0.7174, -1.0043, -0.9326, -0.9087, -1.1, -0.7891, -0.7174, -1.0043, 0.7891, 0.9087, -1.1, 0.6457, 0.7174, -1.1, -0.7891, 0.7174, -1.0043, 0.7891, 0.9087, -1.1, -0.7891, 0.7174, -1.0043, -0.9326, 0.9087, -1.0043, 0.7891, 0.9087, -1.0043, 0.7891, -0.9087, -1.1, 0.6457, -0.7174, -1.0043, 0.7891, 0.9087, -1.1, 0.6457, -0.7174, -1.1, 0.6457, 0.7174, -1.0043, -0.9326, 0.9087, -1.0043, -0.9326, -0.9087, -0.9087, -1.0283, -0.9087, -1.0043, -0.9326, 0.9087, -0.9087, -1.0283, -0.9087, -0.9087, -1.0283, 0.9087, -1.0043, 0.7891, -0.9087, -0.9087, 0.7891, -1.0043, -0.9087, -0.9326, -1.0043, -1.0043, 0.7891, -0.9087, -0.9087, -0.9326, -1.0043, -1.0043, -0.9326, -0.9087, -1.0043, -0.9326, -0.9087, -0.9087, -0.9326, -1.0043, -0.9087, -1.0283, -0.9087, -0.9087, 0.7891, 1.0043, -1.0043, 0.7891, 0.9087, -1.0043, -0.9326, 0.9087, -0.9087, 0.7891, 1.0043, -1.0043, -0.9326, 0.9087, -0.9087, -0.9326, 1.0043, -0.9087, -0.9326, 1.0043, -1.0043, -0.9326, 0.9087, -0.9087, -1.0283, 0.9087, -0.9087, 0.8847, 0.9087, -0.9087, 0.8847, -0.9087, -1.0043, 0.7891, -0.9087, -0.9087, 0.8847, 0.9087, -1.0043, 0.7891, -0.9087, -1.0043, 0.7891, 0.9087, -1.0043, 0.7891, -0.9087, -0.9087, 0.8847, -0.9087, -0.9087, 0.7891, -1.0043, -0.9087, 0.7891, 1.0043, -0.9087, 0.8847, 0.9087, -1.0043, 0.7891, 0.9087, -0.9087, -1.0283, -0.9087, -0.727, -1.0761, -0.727, -0.727, -1.0761, 0.727, -0.9087, -1.0283, -0.9087, -0.727, -1.0761, 0.727, -0.9087, -1.0283, 0.9087, -0.9087, -0.9326, -1.0043, 0.9087, -0.9326, -1.0043, 0.9087, -1.0283, -0.9087, -0.9087, -0.9326, -1.0043, 0.9087, -1.0283, -0.9087, -0.9087, -1.0283, -0.9087, 0.9087, -1.0283, -0.9087, 0.727, -1.0761, -0.727, -0.727, -1.0761, -0.727, 0.9087, -1.0283, -0.9087, -0.727, -1.0761, -0.727, -0.9087, -1.0283, -0.9087, 0.9087, -0.9326, 1.0043, -0.9087, -0.9326, 1.0043, -0.9087, -1.0283, 0.9087, 0.9087, -0.9326, 1.0043, -0.9087, -1.0283, 0.9087, 0.9087, -1.0283, 0.9087, 0.727, -1.0761, 0.727, 0.9087, -1.0283, 0.9087, -0.9087, -1.0283, 0.9087, 0.727, -1.0761, 0.727, -0.9087, -1.0283, 0.9087, -0.727, -1.0761, 0.727, -0.9087, 0.7891, -1.0043, -0.7366, 0.5978, -1.1, -0.7366, -0.7509, -1.1, -0.9087, 0.7891, -1.0043, -0.7366, -0.7509, -1.1, -0.9087, -0.9326, -1.0043, -0.9087, -0.9326, -1.0043, -0.7366, -0.7509, -1.1, 0.727, -0.7509, -1.1, -0.9087, -0.9326, -1.0043, 0.727, -0.7509, -1.1, 0.9087, -0.9326, -1.0043, -0.7174, 0.6457, 1.1, -0.9087, 0.7891, 1.0043, -0.9087, -0.9326, 1.0043, -0.7174, 0.6457, 1.1, -0.9087, -0.9326, 1.0043, -0.7174, -0.7891, 1.1, 0.9087, -0.9326, 1.0043, 0.7174, -0.7891, 1.1, -0.7174, -0.7891, 1.1, 0.9087, -0.9326, 1.0043, -0.7174, -0.7891, 1.1, -0.9087, -0.9326, 1.0043, -0.9087, 0.8847, -0.9087, 0.9087, 0.8847, -0.9087, 0.9087, 0.7891, -1.0043, -0.9087, 0.8847, -0.9087, 0.9087, 0.7891, -1.0043, -0.9087, 0.7891, -1.0043, -0.9087, 0.7891, -1.0043, 0.9087, 0.7891, -1.0043, 0.727, 0.5978, -1.1, -0.9087, 0.7891, -1.0043, 0.727, 0.5978, -1.1, -0.7366, 0.5978, -1.1, 0.9087, 0.8847, 0.9087, -0.9087, 0.8847, 0.9087, -0.9087, 0.7891, 1.0043, 0.9087, 0.8847, 0.9087, -0.9087, 0.7891, 1.0043, 0.9087, 0.7891, 1.0043, 0.9087, 0.7891, 1.0043, -0.9087, 0.7891, 1.0043, -0.7174, 0.6457, 1.1, 0.9087, 0.7891, 1.0043, -0.7174, 0.6457, 1.1, 0.7174, 0.6457, 1.1, -0.9087, 0.8847, 0.9087, -0.7366, 0.9804, 0.7366, -0.7366, 0.9804, -0.7366, -0.9087, 0.8847, 0.9087, -0.7366, 0.9804, -0.7366, -0.9087, 0.8847, -0.9087, -0.5453, 1.0761, -0.6409, -0.9087, 0.8847, -0.9087, -0.7366, 0.9804, -0.7366, -0.9087, 0.8847, -0.9087, -0.5453, 1.0761, -0.6409, 0.5453, 1.0761, -0.6409, -0.9087, 0.8847, -0.9087, 0.5453, 1.0761, -0.6409, 0.9087, 0.8847, -0.9087, -0.9087, 0.8847, 0.9087, -0.5453, 1.0761, 0.6409, -0.7366, 0.9804, 0.7366, 0.9087, 0.8847, 0.9087, 0.5453, 1.0761, 0.6409, -0.5453, 1.0761, 0.6409, 0.9087, 0.8847, 0.9087, -0.5453, 1.0761, 0.6409, -0.9087, 0.8847, 0.9087, -0.7366, 0.5978, -1.1, 0.727, 0.5978, -1.1, 0.727, -0.7509, -1.1, -0.7366, 0.5978, -1.1, 0.727, -0.7509, -1.1, -0.7366, -0.7509, -1.1, -0.7366, 0.9804, 0.7366, -0.5453, 1.0761, 0.6409, -0.5453, 1.0761, -0.6409, -0.7366, 0.9804, 0.7366, -0.5453, 1.0761, -0.6409, -0.7366, 0.9804, -0.7366, 0.727, -1.0761, -0.727, 0.727, -1.0761, 0.727, -0.727, -1.0761, 0.727, 0.727, -1.0761, -0.727, -0.727, -1.0761, 0.727, -0.727, -1.0761, -0.727, 0.7174, 0.6457, 1.1, -0.7174, 0.6457, 1.1, -0.7174, -0.7891, 1.1, 0.7174, 0.6457, 1.1, -0.7174, -0.7891, 1.1, 0.7174, -0.7891, 1.1, 0.5453, 1.0761, 0.6409, 0.5453, 1.0761, -0.6409, -0.5453, 1.0761, -0.6409, 0.5453, 1.0761, 0.6409, -0.5453, 1.0761, -0.6409, -0.5453, 1.0761, 0.6409, 0.7366, 0.9804, -0.7366, 0.5453, 1.0761, -0.6409, 0.5453, 1.0761, 0.6409, 0.7366, 0.9804, -0.7366, 0.5453, 1.0761, 0.6409, 0.7366, 0.9804, 0.7366, 0.5453, 1.0761, -0.6409, 0.7366, 0.9804, -0.7366, 0.9087, 0.8847, -0.9087, 0.9087, 0.8847, 0.9087, 0.7366, 0.9804, 0.7366, 0.5453, 1.0761, 0.6409, 0.9087, 0.7891, 1.0043, 0.7174, 0.6457, 1.1, 0.7174, -0.7891, 1.1, 0.9087, 0.7891, 1.0043, 0.7174, -0.7891, 1.1, 0.9087, -0.9326, 1.0043, 0.9087, -1.0283, -0.9087, 0.9087, -1.0283, 0.9087, 0.727, -1.0761, 0.727, 0.9087, -1.0283, -0.9087, 0.727, -1.0761, 0.727, 0.727, -1.0761, -0.727, 0.727, 0.5978, -1.1, 0.9087, 0.7891, -1.0043, 0.9087, -0.9326, -1.0043, 0.727, 0.5978, -1.1, 0.9087, -0.9326, -1.0043, 0.727, -0.7509, -1.1, 0.9087, 0.8847, -0.9087, 0.7366, 0.9804, -0.7366, 0.7366, 0.9804, 0.7366, 0.9087, 0.8847, -0.9087, 0.7366, 0.9804, 0.7366, 0.9087, 0.8847, 0.9087, 1.0043, -0.9326, -0.9087, 1.0043, -0.9326, 0.9087, 0.9087, -1.0283, 0.9087, 1.0043, -0.9326, -0.9087, 0.9087, -1.0283, 0.9087, 0.9087, -1.0283, -0.9087, 0.9087, -0.9326, -1.0043, 1.0043, -0.9326, -0.9087, 0.9087, -1.0283, -0.9087, 1.0043, -0.9326, 0.9087, 0.9087, -0.9326, 1.0043, 0.9087, -1.0283, 0.9087, 0.9087, 0.7891, -1.0043, 1.0043, 0.7891, -0.9087, 1.0043, -0.9326, -0.9087, 0.9087, 0.7891, -1.0043, 1.0043, -0.9326, -0.9087, 0.9087, -0.9326, -1.0043, 1.0043, 0.7891, 0.9087, 0.9087, 0.7891, 1.0043, 0.9087, -0.9326, 1.0043, 1.0043, 0.7891, 0.9087, 0.9087, -0.9326, 1.0043, 1.0043, -0.9326, 0.9087, 0.9087, 0.7891, -1.0043, 0.9087, 0.8847, -0.9087, 1.0043, 0.7891, -0.9087, 1.0043, 0.7891, 0.9087, 0.9087, 0.8847, 0.9087, 0.9087, 0.7891, 1.0043, 0.9087, 0.8847, -0.9087, 0.9087, 0.8847, 0.9087, 1.0043, 0.7891, 0.9087, 0.9087, 0.8847, -0.9087, 1.0043, 0.7891, 0.9087, 1.0043, 0.7891, -0.9087, 1.0043, -0.9326, -0.9087, 1.1, -0.7891, -0.7174, 1.1, -0.7891, 0.7174, 1.0043, -0.9326, -0.9087, 1.1, -0.7891, 0.7174, 1.0043, -0.9326, 0.9087, 1.0043, 0.7891, -0.9087, 1.1, 0.6457, -0.7174, 1.1, -0.7891, -0.7174, 1.0043, 0.7891, -0.9087, 1.1, -0.7891, -0.7174, 1.0043, -0.9326, -0.9087, 1.1, 0.6457, 0.7174, 1.0043, 0.7891, 0.9087, 1.0043, -0.9326, 0.9087, 1.1, 0.6457, 0.7174, 1.0043, -0.9326, 0.9087, 1.1, -0.7891, 0.7174, 1.0043, 0.7891, -0.9087, 1.0043, 0.7891, 0.9087, 1.1, 0.6457, 0.7174, 1.0043, 0.7891, -0.9087, 1.1, 0.6457, 0.7174, 1.1, 0.6457, -0.7174, 1.1, 0.6457, -0.7174, 1.1, 0.6457, 0.7174, 1.1, -0.7891, 0.7174, 1.1, 0.6457, -0.7174, 1.1, -0.7891, 0.7174, 1.1, -0.7891, -0.7174];
    function lighten(c) { var v = rgb(c); return hex(v[0] + (255 - v[0]) * 0.4, v[1] + (255 - v[1]) * 0.4, v[2] + (255 - v[2]) * 0.4); }
    function superLook(e) {
        var claimed = S.superBalls.indexOf(e.star) >= 0, c = claimed ? 0xFFDE26 : 0x9A9A9A;
        var shell = { shape: "boxes", boxes: SUPER_GEO, color: O.hex(c), alpha: claimed ? 0.7 : 1, prepass: true, shading: "entity", cull: "back", depthWrite: true };
        var rimL = { shape: "mesh", mesh: SUPER_HULL, color: lighten(c), alpha: 0.9, cull: "front", shading: "entity" };
        if (!claimed) { shell.radius = e.radius; shell.spin = 8; shell.yaw = 0; shell.tilt = 12; shell.layers = [rimL]; return shell; }
        // the star first, then the glass over it
        shell.scale = 1 / 0.62; rimL.scale = 1 / 0.62;
        return { radius: e.radius * 0.62, shape: "billboard", texture: TEX + "dball_stars/star" + e.star + ".png", color: "#DB2105", shading: "flat", spin: 8, tilt: 12,
            layers: [shell, rimL] };
    }
    function holeLook(r) {
        return { radius: r, shape: "sphere", color: "#000000", shading: "flat", minSize: 0.6, spin: 34,
            glow: { color: "#6A2FBF", size: r * 3.5, alpha: 0.45 },
            layers: [{ shape: "plane", texture: TEX + "black_hole_swirl.png", scale: 3.2, color: "#FFB060", blend: "additive", cull: "none", spin: 12, tilt: 18 },
                     { shape: "sphere", scale: 1.06, color: "#9A6BFF", alpha: 0.85, cull: "front" }] };
    }

    // ---- the sky: which bodies are drawn, and where ----
    var DRAWN = {};                // id -> entry kind (bodies currently in the sky)
    var LIST = [];                 // the last near() list with live positions
    function lookFor(e) {
        var spec;
        if (e.kind === "fixed") spec = fixedLook(e.body);
        else if (e.kind === "moon") spec = moonLook(e.moon);
        else if (e.kind === "planet") { spec = planetLook(e.id); spec.radius = e.radius; }
        else if (e.kind === "sun") spec = starLook(O.SUN.radius, O.SUN.tint);
        else if (e.kind === "star") spec = starLook(e.radius, e.tint);
        else if (e.kind === "hole") spec = holeLook(e.radius);
        else if (e.kind === "super") spec = superLook(e);
        spec.visible = true;
        return spec;
    }
    // DMZR SpaceDimensionEffects: field, band, cluster and deep stars; nebulae, band dust, deep nebula complexes,
    // galaxies with cores, bright glows and comets on a radius-100 sky; a slow drift. Its numbers, the engine's generator.
    var BAND = [1, 2, 1];
    var BACKDROP = {
        starLayers: [
            { count: 4500, seed: 6049511, brightness: [0.35, 0.95], curve: 2.2, bright: { fraction: 0.03, scale: 1.7 }, size: [0.10, 0.14],
              palette: [[0.78, 0.85, 1, 5], [1, 1, 1, 6], [1, 0.96, 0.84, 4], [1, 0.86, 0.66, 2], [1, 0.74, 0.48, 1.2], [1, 0.56, 0.44, 0.8]] },
            { count: 2600, seed: 9118196, band: { normal: BAND, sigma: 0.18, max: 0.55 }, brightness: [0.22, 0.60], size: [0.09, 0.07],
              palette: [[0.82, 0.88, 1, 4], [1, 1, 1, 5], [1, 0.95, 0.82, 2]] },
            { seed: 7459749, clusters: { count: 7, stars: [40, 75], sigma: 2.4 }, brightness: [0.30, 0.70], size: [0.09, 0.07],
              palette: [[0.82, 0.88, 1, 4], [1, 1, 1, 5], [1, 0.95, 0.82, 2]] },
            { count: 9000, seed: 3010197, brightness: [0.10, 0.32], size: [0.045, 0.03], palette: [[0.85, 0.9, 1, 3], [1, 1, 1, 4], [1, 0.92, 0.8, 2]] }
        ],
        blobs: [
            { count: 7, seed: 8297233, lumps: { min: 5, max: 9, spread: 0.32 }, radius: [14, 34], alpha: [0.05, 0.11], segments: 24,
              palette: [[0.34, 0.44, 0.70], [0.30, 0.36, 0.62], [0.50, 0.35, 0.66], [0.42, 0.30, 0.58], [0.28, 0.54, 0.54], [0.58, 0.34, 0.56], [0.60, 0.40, 0.32]] },
            { count: 20, seed: 5124785, radius: [12, 55], alpha: [0.08, 0.30], segments: 24, band: { normal: BAND, fraction: 0.45, sigma: 0.15, max: 0.4 },
              palette: [[0.34, 0.44, 0.70], [0.30, 0.36, 0.62], [0.50, 0.35, 0.66], [0.42, 0.30, 0.58], [0.28, 0.54, 0.54], [0.58, 0.34, 0.56], [0.60, 0.40, 0.32]] },
            { count: 14, seed: 3120135, along: [12, 30], across: [3.5, 8], alpha: [0.06, 0.15], segments: 22, band: { normal: BAND, fraction: 1, sigma: 0.08, max: 0.2, align: true },
              palette: [[0.66, 0.62, 0.56], [0.72, 0.66, 0.54], [0.58, 0.60, 0.66]] },
            { count: 55, seed: 6952905, radius: [2, 12], flatten: [0.22, 0.85], alpha: [0.28, 0.60], segments: 18, core: { over: 6.5, scale: 0.42, alpha: 0.35 },
              palette: [[0.72, 0.78, 0.92], [0.66, 0.74, 0.90], [0.82, 0.84, 0.92], [0.70, 0.80, 0.86]],
              warm: { fraction: 0.20, palette: [[0.82, 0.56, 0.36], [0.80, 0.68, 0.48], [0.80, 0.54, 0.58]] } },
            { count: 12, seed: 4090765, radius: [1.2, 2.2], alpha: [0.22, 0.40], segments: 16, palette: [[0.80, 0.88, 1.00]] },
            { count: 2, seed: 803954, radius: [1.4, 2.0], alpha: [0.50, 0.50], segments: 14, tail: { length: [16, 24], alpha: 0.18 }, palette: [[0.78, 0.86, 1.00]] }
        ]
    };
    function baseSky() {
        return { color: "#000000", sun: false, moon: false, clouds: false, drift: 0.075,
            starLayers: BACKDROP.starLayers, blobs: BACKDROP.blobs, bodies: [] };
    }
    var skyDim = "";
    function where() { return RPG.player.dimension === SPACE ? SPACE : RPG.player.dimension === SURFACE && S.surface ? SURFACE : ""; }
    // the viewpoint in space: yourself, or (on a planet's surface) that planet
    function viewpoint() {
        if (where() === SURFACE) { var b = B.find(S.surface, now()); if (b) return b.pos; }
        return me();
    }
    function refreshSky(force) {
        var t0 = RPG.nowMs();
        refreshSkyInner(force);
        var ms = RPG.nowMs() - t0;
        if (ms > 40) RPG.log("[DBR] space sky refresh " + Math.round(ms) + " ms");
    }
    function refreshSkyInner(force) {
        var dim = where();
        if (!dim) { if (skyDim) { RPG.sky.remove(skyDim); skyDim = ""; DRAWN = {}; } return; }
        if (dim !== skyDim || force) {
            if (skyDim && skyDim !== dim) RPG.sky.remove(skyDim);
            var spec = baseSky();
            if (dim === SURFACE) { spec.color = "#04060F"; spec.fog = { color: "#0A0E1C", start: 96, end: 220 }; lastWeather = ""; }
            RPG.sky.define(dim, spec);
            skyDim = dim; DRAWN = {};
        }
        G.setBudget(6);                                   // a few new sectors a tick; the rest fill in over the next refreshes
        var vp = viewpoint(), list = B.near(vp, 30000, now()), keep = {};
        G.setBudget(0);
        LIST = list.filter(function (e) {
            if (e.kind === "super" && !superVisible(e.pos)) return false;
            if (dim === SURFACE && e.id === S.surface) return false;            // not the ground under your feet
            if (e.kind === "planet" && dist(vp, e.pos) > 12000) return false;
            return true;
        });
        LIST.forEach(function (e) {
            keep[e.id] = true;
            if (!DRAWN[e.id]) { RPG.sky.update(dim, e.id, lookFor(e)); DRAWN[e.id] = e.kind; }
        });
        for (var id in DRAWN) if (!keep[id]) { RPG.sky.removeBody(dim, id); delete DRAWN[id]; }
        moveBodies(true);
    }
    function livePos(e, ep) {
        if (e.kind === "fixed") return B.fixedPos(e.body, ep);
        if (e.kind === "moon") return B.moonPos(e.moon.parent, ep);
        if (e.kind === "planet") return G.planetPos(e.planet, ep);
        if (e.kind === "super") return B.superPos(e.sup, ep);
        return e.pos;
    }
    function moveBodies(all) {
        var dim = skyDim;
        if (!dim) return;
        var ep = now(), vp = viewpoint(), p = me(), u = {}, surface = dim === SURFACE;
        LIST.forEach(function (e) {
            if (!all && e.kind !== "fixed" && e.kind !== "moon" && e.kind !== "planet" && e.kind !== "super") return;
            e.pos = livePos(e, ep);
            if (!all && dist(vp, e.pos) > 6000) return;
            // on a surface the sky is seen from that planet: shift everything so the planet sits under you
            // (lifted onto the sky dome: the bodies share the planet's orbital plane, which would sit on the horizon)
            var q = e.pos;
            if (surface) {
                var dx = e.pos.x - vp.x, dz = e.pos.z - vp.z, h = Math.sqrt(dx * dx + dz * dz);
                q = { x: dx + p.x, y: Math.abs(e.pos.y - vp.y) + h * 0.45 + p.y, z: dz + p.z };
            }
            u[e.id] = { x: q.x, y: q.y, z: q.z };
        });
        RPG.sky.updateAll(dim, u);
    }

    RPG.net.on("dbr_space_state", function (d) {
        if (!d) return;
        S.autopilot = String(d.autopilot || "");
        S.origin = String(d.origin || "");
        S.surface = String(d.surface || "");
        var cell = String(d.surfaceCell || "").split(",");
        if (cell.length === 2) G.systemAt(Number(cell[0]), Number(cell[1]));
        if (d.epoch) S.offset = Number(d.epoch) - Date.now();
        if (d.supers) B.setSuper(d.supers);
        if (d.destroyed) B.setDestroyed(d.destroyed);
        if (d.superBalls) S.superBalls = d.superBalls.map(Number);
        S.superRadar = !!d.superRadar;
        if (!S.autopilot && RPG.player.vehicleSteered && !S.descend) RPG.player.stopVehicleSteer();
        refreshSky(true);
    });
    RPG.on("load", function () { RPG.net.send("dbr_space_hello", {}); });
    RPG.net.on("dbr_space_info", function (d) { if (d && d.id) S.info[d.id] = d; });

    // ---- autopilot: climb straight up out of the planet, then cruise to the body (DMZR driveAutopilot) ----
    function avoid(from, to) {
        // go round the sun and any star or black hole on the way instead of through it
        var out = to;
        LIST.forEach(function (e) {
            if (e.kind !== "sun" && e.kind !== "star" && e.kind !== "hole") return;
            var danger = e.kind === "sun" ? O.SUN.danger + 150 : e.kind === "hole" ? e.hole.pull * 0.6 : e.radius * 12.5 + 100;
            var dx = out.x - from.x, dy = out.y - from.y, dz = out.z - from.z, len2 = dx * dx + dy * dy + dz * dz;
            if (len2 < 1) return;
            var t = Math.max(0, Math.min(1, ((e.pos.x - from.x) * dx + (e.pos.y - from.y) * dy + (e.pos.z - from.z) * dz) / len2));
            var cx = from.x + dx * t - e.pos.x, cy = from.y + dy * t - e.pos.y, cz = from.z + dz * t - e.pos.z, c = Math.sqrt(cx * cx + cy * cy + cz * cz);
            if (c >= danger || t >= 1) return;
            if (c < 1) { cx = -dz; cy = 0; cz = dx; c = Math.sqrt(cx * cx + cz * cz) || 1; }
            out = { x: e.pos.x + cx / c * (danger + 200), y: e.pos.y + cy / c * (danger + 200), z: e.pos.z + cz / c * (danger + 200) };
        });
        return out;
    }
    // landing descent: fly the pod down to the ground the server found (DMZR lands the pod, it doesn't drop it)
    RPG.net.on("dbr_space_descend", function (d) { if (d) S.descend = { x: Number(d.x), y: Number(d.y), z: Number(d.z), until: tick + 600 }; RPG.log("[DBR] space: landing descent to y " + Math.round(Number(d.y))); });
    function targetEntry() {
        for (var i = 0; i < LIST.length; i++) if (LIST[i].id === S.autopilot) return LIST[i];
        return B.find(S.autopilot, now());
    }
    function steer() {
        if (S.descend) {
            var dd = S.descend, pp = me();
            if (RPG.player.vehicleId !== "spacepod") { if (tick > dd.until) S.descend = null; return; }   // the remount may arrive after this
            if (tick > dd.until || Math.abs(pp.y - dd.y) < 0.8 && Math.abs(pp.x - dd.x) + Math.abs(pp.z - dd.z) < 2) {
                S.descend = null;
                RPG.player.stopVehicleSteer();
            } else RPG.player.steerVehicle(dd.x, dd.y, dd.z, Math.min(3, Math.max(0.6, (pp.y - dd.y) / 20)));
            return;
        }
        if (!S.autopilot || RPG.player.vehicleId !== "spacepod") {
            if (RPG.player.vehicleSteered) RPG.player.stopVehicleSteer();
            return;
        }
        var p = me();
        if (RPG.player.dimension !== SPACE) {
            if (RPG.player.dimension === SURFACE) { RPG.player.steerVehicle(p.x, cfg("surfaceLeaveAltitude", 260) + 12, p.z, cfg("ascentSpeed", 4)); return; }
            if (!O.byDim(RPG.player.dimension)) return;
            RPG.player.steerVehicle(p.x, cfg("entryAltitude", 1000) + 16, p.z, cfg("ascentSpeed", 4));
            return;
        }
        var e = targetEntry();
        if (!e) return;
        var t = livePos(e, now()), w = avoid(p, t);
        RPG.player.steerVehicle(w.x, w.y, w.z, cfg("cruiseSpeed", 9));
    }

    // ---- black holes pull the pod (SpaceHazardModule.dragPod: the rider's computer moves the pod) ----
    function pullStep(d, outer, inner, pnr, influence) {
        var denom = 1 / (pnr * pnr) - 1 / (influence * influence);
        if (denom <= 1e-12) return outer + (inner - outer) * Math.max(0, Math.min(1, (influence - d) / Math.max(influence - pnr, 1e-6)));
        var a = (inner - outer) / denom, b = outer - a / (influence * influence), pull = Math.max(a / (d * d) + b, outer);
        return d <= pnr ? Math.max(pull, inner) : pull;
    }
    function holePull() {
        if (RPG.player.vehicleId !== "spacepod" || RPG.player.dimension !== SPACE) return;
        var p = me();
        LIST.forEach(function (e) {
            if (e.kind !== "hole") return;
            var d = dist(p, e.pos);
            if (d >= e.hole.pull || d < 1) return;
            var pnr = Math.max(Math.min(e.hole.horizon * 3, e.hole.pull * 0.5), e.hole.horizon + 0.001);
            var step = Math.min(9, pullStep(d, cfg("blackHolePullOuter", 0.25), Math.max(cfg("blackHolePullInner", 6), 6), pnr, e.hole.pull), d);
            RPG.player.pushVehicle((e.pos.x - p.x) / d * step, (e.pos.y - p.y) / d * step, (e.pos.z - p.z) / d * step);
        });
    }

    // ---- pod trails (PodTrailRenderer) and the pod aura: 44_dbr_trails.js, for every pod in view; it asks this ----
    dbrPodAutopilot = function () { return S.autopilot; };

    // ---- zero-g on foot: push off along your look (W/S, A/D, Space up, Shift down); ki flight and pods move as usual ----
    function drift() {
        if (RPG.player.riding || RPG.player.flying || RPG.player.hasEffect("flight") || RPG.screen.getOpen()) return;
        var k = function (n) { return RPG.isKeyDown("key.keyboard." + n) ? 1 : 0; };
        var f = k("w") - k("s"), st = k("d") - k("a"), up = k("space") - k("left.shift");
        if (!f && !st && !up) return;
        var l = RPG.player.look, yaw = RPG.player.yaw * Math.PI / 180, a = 0.035;
        var vx = RPG.player.vx + (l.x * f - Math.cos(yaw) * st * 0.7) * a, vy = RPG.player.vy + (l.y * f + up) * a, vz = RPG.player.vz + (l.z * f - Math.sin(yaw) * st * 0.7) * a;
        var len = Math.sqrt(vx * vx + vy * vy + vz * vz), max = 1.2;
        if (len > max) { vx *= max / len; vy *= max / len; vz *= max / len; }
        RPG.player.setVelocity(vx, vy, vz);
    }

    // ---- weather on generated planets (PlanetWeather + SurfaceWeatherClient) ----
    var WEATHER = {
        rain: { particle: "minecraft:falling_water", n: 9, fog: "#3A4552", far: 120 },
        storm: { particle: "minecraft:falling_water", n: 18, fog: "#252C36", far: 80, flash: true },
        snow: { particle: "minecraft:snowflake", n: 16, fog: "#9AA6B4", far: 110 },
        blizzard: { particle: "minecraft:snowflake", n: 40, fog: "#C8D0DA", far: 40 },
        dust: { particle: "minecraft:white_ash", n: 26, fog: "#8C7556", far: 60 },
        ash: { particle: "minecraft:ash", n: 30, fog: "#3A2A24", far: 70 },
        meteor: { particle: "minecraft:lava", n: 2, fog: "#2A1C24", far: 180, meteor: true }
    };
    var lastWeather = "";
    function weather() {
        if (where() !== SURFACE) { lastWeather = ""; return; }
        var w = B.weather(S.surface, now()), def = WEATHER[w.state], key = w.state + Math.round(w.intensity * 5);
        if (key !== lastWeather) {
            lastWeather = key;
            var spec = baseSky();
            spec.color = "#04060F";
            spec.fog = def ? { color: def.fog, start: 8, end: 220 - (220 - def.far) * w.intensity } : { color: "#0A0E1C", start: 96, end: 220 };
            RPG.sky.define(SURFACE, spec); DRAWN = {}; skyDim = SURFACE;
            refreshSky(false);
        }
        if (!def || w.intensity <= 0) return;
        var p = me(), n = Math.round(def.n * w.intensity);
        if (n > 0) RPG.particle(def.particle, p.x, p.y + 14, p.z, n, 16, 0.02);
        if (def.meteor && Math.random() < 0.04 * w.intensity) {
            var mx = p.x + (Math.random() - 0.5) * 60, mz = p.z + (Math.random() - 0.5) * 60;
            RPG.particle("minecraft:flame", mx, p.y + 30, mz, 30, 1.5, 0.15);
            RPG.soundAt("minecraft:entity.generic.explode", mx, p.y + 20, mz, 0.4, 0.6);
        }
        if (def.flash && Math.random() < 0.004) RPG.soundAt("minecraft:entity.lightning_bolt.thunder", p.x, p.y, p.z, 0.8 * w.intensity, 1);
    }

    var tick = 0;
    RPG.on("tick", function () {
        tick++;
        var d = where();
        if (syncCfg()) refreshSky(true);
        if (d) {
            if (tick % 10 === 0 || d !== skyDim) refreshSky(false); else moveBodies(false);
            if (d === SPACE) { drift(); holePull(); }
            weather();
        } else if (skyDim) refreshSky(false);
        steer();
        if (d === SPACE && tick % 40 === 0 && target) RPG.net.send("dbr_space_info", infoReq(target));
    });
    function infoReq(id) {
        var e = null;
        LIST.forEach(function (x) { if (x.id === id) e = x; });
        return e && e.kind === "planet" ? { id: id, cx: e.planet.system.cx, cz: e.planet.system.cz } : { id: id };
    }

    // ---- HUD: labels + info overlay (PlanetInfoOverlay) and the radar dial (SuRadarHud) ----
    var target = null, hudList = [], hudAt = -100;
    var inHud = false;
    RPG.hud.onRender(function (ctx) {
        if (inHud) RPG.log("[DBR] space HUD was stopped mid-draw");
        inHud = true;
        var t0 = RPG.nowMs();
        hudDraw(ctx);
        inHud = false;
        var ms = RPG.nowMs() - t0;
        if (ms > 25) RPG.log("[DBR] space HUD took " + Math.round(ms) + " ms");
    });
    function hudDraw(ctx) {
        if (ctx.isEditing()) {
            // the HUD editor: show the planet info panel's place so it can be moved, resized or hidden anywhere
            var ex = ctx.width / 2 + 14, ey = ctx.height / 2 - 30;
            if (ctx.group("dbr_planet_info", "Planet info", ex, ey, 130, 62)) {
                ctx.fill(ex, ey, 130, 62, "#100010", 0.8);
                ctx.fill(ex, ey, 130, 1, "#5000FF", 0.8);
                ctx.textStyled("§lPlanet info", ex + 5, ey + 5, 1, "#FFD700", 1, 0, FONT, "#000000");
                ctx.endGroup();
            }
            return;
        }
        if (RPG.player.dimension !== SPACE || RPG.screen.getOpen()) return;
        var p = me(), cx = ctx.width / 2, cy = ctx.height / 2, best = null, bestD = 1e9;
        // labels for what's close enough to matter, refreshed a few times a second (projection is per frame)
        if (tick - hudAt >= 5) {
            hudAt = tick;
            hudList = LIST.filter(function (e) { var d = dist(p, e.pos); return e.kind === "fixed" || e.kind === "sun" || (e.kind === "super" && superVisible(e.pos)) || d < (e.kind === "moon" ? 3000 : 8000); });
            // labels for the nearest few only (each is a projected, outlined text every frame)
            hudList.sort(function (a, b) { return dist(p, a.pos) - dist(p, b.pos); });
            if (hudList.length > 16) hudList.length = 16;
        }
        // a name shows only for the body you look straight at, and only within 2000 blocks of its surface
        var look = null, lookD = 1e9, lookP = null;
        hudList.forEach(function (b) {
            var sp = RPG.project(b.pos.x, b.pos.y, b.pos.z);
            if (!sp.visible) return;
            var sd = Math.abs(sp.x - cx) + Math.abs(sp.y - cy);
            if ((b.kind === "fixed" || b.kind === "moon" || b.kind === "planet" || b.kind === "super") && sd < bestD && sd < 80) { best = b; bestD = sd; }
            // on screen, the body covers about its projected radius around its centre (top edge projected the same way)
            var top = RPG.project(b.pos.x, b.pos.y + (b.radius || 0), b.pos.z);
            var pr = top.visible ? Math.abs(top.y - sp.y) : 0;
            var cd = Math.sqrt((sp.x - cx) * (sp.x - cx) + (sp.y - cy) * (sp.y - cy));
            if (cd <= Math.max(24, pr) && cd < lookD) { look = b; lookD = cd; lookP = sp; }
        });
        if (look && dist(p, look.pos) - look.radius <= 2000) {
            var ld = dist(p, look.pos);
            var col = look.id === S.autopilot ? "#40FF80" : look.kind === "sun" || look.kind === "star" ? "#FFD27F" : look.kind === "hole" ? "#C090FF" : "#20E0FF";
            ctx.textStyled(nameOf(look) + " §7" + fmt(Math.max(0, ld - look.radius)), lookP.x, lookP.y + 8, 0.8, col, 0.85, 0.5, FONT, "#000000");
        }
        target = best ? best.id : null;
        if (best && INFO.on && ctx.group("dbr_planet_info", "Planet info", cx + 14, cy - 30, 130, 62)) {
            var i = S.info[best.id] || {}, x = cx + 14, y = cy - 30, w = 130, d = dist(p, best.pos) - best.radius;
            ctx.fill(x, y, w, 62, "#100010", 0.8);
            ctx.fill(x, y, w, 1, "#5000FF", 0.8);
            ctx.textStyled("§l" + nameOf(best), x + 5, y + 5, 1, "#FFD700", 1, 0, FONT, "#000000");
            ctx.textStyled("Distance: " + fmt(d), x + 5, y + 17, 0.8, "#FFFFFF", 1, 0, FONT, null);
            ctx.textStyled("Fighters: " + (i.count === undefined ? "?" : i.count), x + 5, y + 27, 0.8, "#FFFFFF", 1, 0, FONT, null);
            if (best.kind !== "fixed") ctx.textStyled("World: " + (B.themeFor(best.id).id) + ", " + B.surfaceSize(best.id) + " blocks", x + 5, y + 37, 0.8, "#FFFFFF", 1, 0, FONT, null);
            ctx.textStyled(i.owner ? "Owner: " + i.owner : i.visited ? "Visited" : "Unexplored", x + 5, y + 49, 0.8, i.owner ? "#FFD700" : i.visited ? "#80FF80" : "#A0A0A0", 1, 0, FONT, null);
            ctx.endGroup();
        }
        // (no radar dial in space: the minimap and the star map cover it)
        if (S.autopilot) {
            var te = targetEntry(), t = te ? livePos(te, now()) : null, dd = t ? dist(p, t) : 0, eta = Math.round(dd / Math.max(1, cfg("cruiseSpeed", 9)) / 20);
            ctx.textStyled("Autopilot: " + nameOf(te) + " §7" + fmt(dd) + " (" + eta + "s)", cx, ctx.height - 62, 1, "#40FF80", 1, 0.5, FONT, "#000000");
        }
    }
    function drawRadar(ctx, p, all) {
        // right edge, under the minimap (movable in the HUD editor)
        var x = ctx.width - 70, y = Math.floor(ctx.height / 2) + 6, sc = 66 / 121;
        if (!ctx.group("dbr_space_radar", "Space radar", x, y, 66, 80)) return;
        ctx.image(RADAR, x, y, 66, 80, 0, 0, 121, 146, 256, 256);
        var ccx = x + 61 * sc, ccy = y + 87 * sc, reach = 50 * sc;
        var range = 1000 + 21000 * cfg("distanceScale", 0.25), yaw = RPG.player.yaw * Math.PI / 180, nearest = 1e12;
        all.forEach(function (b) {
            var dx = b.pos.x - p.x, dz = b.pos.z - p.z, d = Math.sqrt(dx * dx + dz * dz);
            nearest = Math.min(nearest, Math.max(0, dist(p, b.pos) - b.radius));
            // turn so straight ahead is up (DMZ radar dials are heading-up)
            var rx = dx * Math.cos(yaw) + dz * Math.sin(yaw), rz = -dx * Math.sin(yaw) + dz * Math.cos(yaw);
            var k = Math.min(1, Math.sqrt(d / range)) * reach / Math.max(1, d);
            var bx = ccx - rx * k, by = ccy - rz * k;
            var col = b.kind === "sun" || b.kind === "star" ? "#FFCD53" : b.kind === "hole" ? "#B070FF" : b.id === S.autopilot ? "#40FF80" : "#FBFF4B";
            ctx.fill(bx - 2, by - 2, 4, 4, "#000000", 1);
            ctx.fill(bx - 1.5, by - 1.5, 3, 3, col, 1);
        });
        ctx.textStyled(fmt(nearest), x + 33, y + 72, 0.7, "#FFD54A", 1, 0.5, FONT, "#000000");
        ctx.endGroup();
    }

    // ---- the star map (SpaceStarMapScreen) ----
    try { RPG.keys.register("dbr_star_map", { name: "Star Map", key: "m" }); } catch (e) { }
    // the planet info panel (PlanetInfoOverlay): its own key (I by default) turns it on or off, remembered per world
    var INFO = { on: true };
    try { var st = RPG.storage.get("dbr_planet_info", true); INFO.on = st !== false && st !== "false"; } catch (e) { }
    try { RPG.keys.register("dbr_planet_info", { name: "Planet Info Panel", key: "i" }); } catch (e) { }
    RPG.on("keybind", function (id, down) {
        if (id !== "dbr_planet_info" || !down || RPG.screen.getOpen()) return;
        INFO.on = !INFO.on;
        try { RPG.storage.set("dbr_planet_info", INFO.on); } catch (e) { }
        if (typeof DMZ_UI !== "undefined") DMZ_UI.showStatus("Planet info " + (INFO.on ? "on" : "off"), INFO.on ? "#80FF80" : "#A0A0A0");
    });
    RPG.on("keybind", function (id, down) {
        // in space, or flying the pod; elsewhere M stays the minimap's world map
        var podded = RPG.player.vehicleId === "spacepod";
        if (id === "dbr_star_map" && down && !RPG.screen.getOpen() && (RPG.player.dimension === SPACE || podded)) openMap();
    });
    // the minimap's world map shares M: in space (nothing to map) that key opens the star map instead
    MINIMAP_WORLDMAP_OVERRIDE = function () {
        var podded = RPG.player.vehicleId === "spacepod";
        if (RPG.player.dimension !== SPACE && !podded) return false;
        if (!RPG.screen.getOpen()) openMap();
        return true;
    };

    var M = null;
    function openMap() {
        var far = 0;
        O.BODIES.forEach(function (b) { far = Math.max(far, b.orbitRadius * cfg("distanceScale", 0.25)); });
        M = { cx: 0, cz: 0, zoom: 150 / Math.max(1, far), sel: S.autopilot || null, selEntry: null, drag: null, moved: 0, items: [] };
        O.BODIES.forEach(function (b) { RPG.net.send("dbr_space_info", { id: b.id }); });
        RPG.sound("dmzpack:ui_menu_switch", 1, 1);
        RPG.screen.open({ id: "dbr_star_map", referenceHeight: 300, background: "#000008", elements: [], onRender: drawMap,
            onMouse: mapMouse, onScroll: function (x, y, delta) {
                if (!M) return;
                var f = delta > 0 ? 1.25 : 0.8, w = toWorld(x, y);
                M.zoom = Math.max(0.0002, Math.min(4, M.zoom * f));
                var w2 = toWorld(x, y);
                M.cx += w.x - w2.x; M.cz += w.z - w2.z;
            }, onClose: function () { M = null; } });
    }
    var VIEW = { x: 0, y: 0, w: 0, h: 0 };
    function toScreen(x, z) { return { x: VIEW.x + VIEW.w / 2 + (x - M.cx) * M.zoom, y: VIEW.y + VIEW.h / 2 + (z - M.cz) * M.zoom }; }
    function toWorld(sx, sy) { return { x: M.cx + (sx - VIEW.x - VIEW.w / 2) / M.zoom, z: M.cz + (sy - VIEW.y - VIEW.h / 2) / M.zoom }; }
    var BUTTONS = [];
    function mapMouse(x, y, button, action) {
        if (!M) return;
        if (action === "down") {
            for (var i = 0; i < BUTTONS.length; i++) {
                var b = BUTTONS[i];
                if (x >= b.x && y >= b.y && x < b.x + 74 && y < b.y + 20) { b.fn(); return false; }
            }
            M.drag = { x: x, y: y, cx: M.cx, cz: M.cz }; M.moved = 0;
        } else if (action === "drag" && M.drag) {
            M.cx = M.drag.cx - (x - M.drag.x) / M.zoom; M.cz = M.drag.cz - (y - M.drag.y) / M.zoom;
            M.moved += 1;
        } else if (action === "up" && M.drag) {
            if (M.moved < 3) {
                var pick = null, pd = 12;
                M.items.forEach(function (it) { var d = Math.abs(it.sx - x) + Math.abs(it.sy - y); if (it.pickable && d < pd) { pd = d; pick = it.e; } });
                if (pick) { M.sel = pick.id; M.selEntry = pick; RPG.sound("dmzpack:pip_menu", 1, 1); RPG.net.send("dbr_space_info", infoReqFor(pick)); }
            }
            M.drag = null;
        }
    }
    function infoReqFor(e) { return e.kind === "planet" ? { id: e.id, cx: e.planet.system.cx, cz: e.planet.system.cz } : { id: e.id }; }
    var ICON = {};
    /** A ringed planet's rings on the map: a tilted ellipse band in the ring colour round its icon. */
    function mapRing(ctx, key, s, r, base, tiltDeg) {
        var bands = O.ringBands(key);
        if (!bands) return;
        var col = lift(ringTint(base), O.floorMod(O.packHash(key, "ringtex"), 2) === 1 ? 0.954 : 0.822);
        var squash = Math.max(0.25, Math.cos(tiltDeg * Math.PI / 180) * 0.55), rot = (O.floorMod(O.packHash(key, "ringrot"), 360)) * Math.PI / 180;
        for (var b = 0; b < bands; b++) {
            var ro = r * (2.1 + b * 0.55), ri = ro - Math.max(1, r * 0.35), seg = 28;
            for (var k = 0; k < seg; k++) {
                var a0 = Math.PI * 2 * k / seg, a1 = Math.PI * 2 * (k + 1) / seg, pts = [];
                [[ro, a0], [ro, a1], [ri, a1], [ri, a0]].forEach(function (q) {
                    var ex = Math.cos(q[1]) * q[0], ey = Math.sin(q[1]) * q[0] * squash;
                    pts.push(s.x + ex * Math.cos(rot) - ey * Math.sin(rot), s.y + ex * Math.sin(rot) + ey * Math.cos(rot));
                });
                ctx.poly(pts, col, 0.75);
            }
        }
    }
    function bodyIcon(ctx, e, s, r) {
        var l = ICON[e.id];
        if (!l) {
            if (e.kind === "fixed") l = fixedLook(e.body);
            else if (e.kind === "moon") l = moonLook(e.moon);
            else l = planetLook(e.id);
            l = ICON[e.id] = { texture: l.texture, color: l.color };
        }
        if (l.texture) ctx.quad(l.texture, s.x - r, s.y - r, r * 2, r * 2, 8 / 64, 8 / 64, 16 / 64, 16 / 64, l.color, 1);
        else ctx.arc(s.x, s.y, 0, r, 0, 360, l.color, 1);
    }
    function drawMap(ctx) {
        if (!M) return;
        var pad = 12, ep = now();
        VIEW = { x: pad, y: pad, w: ctx.width - pad * 2 - 130, h: ctx.height - pad * 2 };
        if (typeof DMZ_UI !== "undefined") DMZ_UI.QUEST_PANEL.draw(ctx, 4, 4, ctx.width - 8, ctx.height - 8, 1);
        ctx.fill(VIEW.x, VIEW.y, VIEW.w, VIEW.h, "#000006", 0.92);
        ctx.clip(VIEW.x, VIEW.y, VIEW.w, VIEW.h);
        for (var i = 0; i < 140; i++) {
            var hx = (Math.sin(i * 12.9898) * 43758.5453) % 1, hy = (Math.sin(i * 78.233) * 12543.123) % 1;
            ctx.fill(VIEW.x + Math.abs(hx) * VIEW.w, VIEW.y + Math.abs(hy) * VIEW.h, 1, 1, "#FFFFFF", 0.25 + (i % 5) * 0.12);
        }
        M.items = [];
        // the main system: rings, sun, planets, moons
        var c0 = toScreen(0, 0);
        O.BODIES.forEach(function (b) {
            var r = b.orbitRadius * cfg("distanceScale", 0.25) * M.zoom;
            if (r > 2) ctx.arc(c0.x, c0.y, r - 0.5, r + 0.5, 0, 360, "#3A4A80", 0.6);
        });
        ctx.arc(c0.x, c0.y, 0, Math.max(3, O.SUN.danger * M.zoom), 0, 360, "#FF6020", 0.15);
        ctx.arc(c0.x, c0.y, 0, Math.max(3, O.SUN.radius * 3 * M.zoom), 0, 360, "#FFE7A8", 1);
        // the generated universe in view
        var tl = toWorld(VIEW.x, VIEW.y), br = toWorld(VIEW.x + VIEW.w, VIEW.y + VIEW.h);
        var mid = { x: (tl.x + br.x) / 2, z: (tl.z + br.z) / 2 }, half = Math.max(br.x - tl.x, br.z - tl.z) / 2;
        // the systems in view, looked up again only when the view moves a good way (a few sectors a frame)
        var vkey = Math.round(mid.x / (half / 4 + 1)) + "," + Math.round(mid.z / (half / 4 + 1)) + "," + Math.round(Math.log(half) * 4);
        if (M.vkey !== vkey || M.vpartial) {
            G.setBudget(16);
            M.systems = half < 400000 ? G.systemsNear(mid.x, mid.z, half * 1.2) : [];
            M.vpartial = false;
            G.setBudget(1); if (G.systemsNear(mid.x, mid.z, half * 1.2).length > M.systems.length) M.vpartial = true;
            G.setBudget(0);
            M.vkey = vkey;
        }
        var showPlanets = M.zoom * 3380 > 30;
        if (half < 400000) {
            M.systems.forEach(function (sys) {
                var s = toScreen(sys.x, sys.z), sr = Math.max(1.5, sys.radius * 3 * M.zoom);
                if (s.x < VIEW.x - 200 || s.y < VIEW.y - 200 || s.x > VIEW.x + VIEW.w + 200 || s.y > VIEW.y + VIEW.h + 200) return;
                if (showPlanets) sys.planets.forEach(function (pl) { var r = pl.ring * M.zoom; ctx.arc(s.x, s.y, r - 0.4, r + 0.4, 0, 360, "#2C3460", 0.5); });
                ctx.arc(s.x, s.y, 0, sr, 0, 360, O.hex(sys.tint), 1);
                if (showPlanets) sys.planets.forEach(function (pl) {
                    var pp = G.planetPos(pl, ep), ps = toScreen(pp.x, pp.z), r = Math.max(2.5, pl.radius * M.zoom);
                    var e = { kind: "planet", id: pl.id, planet: pl, pos: pp, radius: pl.radius };
                    if (M.sel === pl.id) ctx.arc(ps.x, ps.y, r + 2, r + 3.5, 0, 360, "#FFD700", 1);
                    if (S.autopilot === pl.id) ctx.arc(ps.x, ps.y, r + 4, r + 5, 0, 360, "#40FF80", 1);
                    mapRing(ctx, pl.id, ps, r, PALETTE[O.floorMod(O.packHash(pl.id, "ptint"), PALETTE.length)], O.ringTilt(pl.id));
                    bodyIcon(ctx, e, ps, r);
                    M.items.push({ e: e, sx: ps.x, sy: ps.y, pickable: true });
                });
            });
        }
        if (half < 30000 && M.vkey2 !== vkey) {
            G.setBudget(16);
            M.stars = G.loneStarsNear(mid.x, cfg("bodyPlaneY", 0), mid.z, half);
            M.holes = G.blackHolesNear(mid.x, cfg("bodyPlaneY", 0), mid.z, half);
            G.setBudget(0);
            M.vkey2 = vkey;
        }
        if (half < 30000) {
            (M.stars || []).forEach(function (st) { var s = toScreen(st.x, st.z); ctx.arc(s.x, s.y, 0, Math.max(1.2, st.radius * 3 * M.zoom), 0, 360, O.hex(st.tint), 0.9); });
            (M.holes || []).forEach(function (h) {
                var s = toScreen(h.x, h.z), r = Math.max(2, h.radius * M.zoom);
                ctx.arc(s.x, s.y, r, r + Math.max(1, h.pull * M.zoom * 0.08), 0, 360, "#7A3FCF", 0.6);
                ctx.arc(s.x, s.y, 0, r, 0, 360, "#000000", 1);
            });
        }
        O.BODIES.forEach(function (b) {
            var e = { kind: "fixed", id: b.id, body: b, pos: B.fixedPos(b, ep), radius: b.radius }, s = toScreen(e.pos.x, e.pos.z), r = Math.max(4, b.radius * M.zoom);
            if (M.sel === b.id) ctx.arc(s.x, s.y, r + 2, r + 3.5, 0, 360, "#FFD700", 1);
            if (S.autopilot === b.id) ctx.arc(s.x, s.y, r + 4, r + 5, 0, 360, "#40FF80", 1);
            if (b.id !== "overworld") mapRing(ctx, b.key, s, r, FIXED_TINT[b.key] !== undefined ? FIXED_TINT[b.key] : b.tint, 45);
            bodyIcon(ctx, e, s, r);
            ctx.textStyled(NAMES[b.id], s.x, s.y + r + 4, 0.8, RPG.player.dimension === b.dim ? "#80FF80" : "#20E0FF", 1, 0.5, FONT, "#000000");
            M.items.push({ e: e, sx: s.x, sy: s.y, pickable: true });
            if (M.zoom * b.radius * 2.6 > 8) {
                var m = B.moonById("moon_" + b.id), mp = B.moonPos(b, ep), ms = toScreen(mp.x, mp.z), mr = Math.max(2, m.radius * M.zoom);
                var me2 = { kind: "moon", id: m.key, moon: m, pos: mp, radius: m.radius };
                if (M.sel === m.key) ctx.arc(ms.x, ms.y, mr + 2, mr + 3, 0, 360, "#FFD700", 1);
                bodyIcon(ctx, me2, ms, mr);
                M.items.push({ e: me2, sx: ms.x, sy: ms.y, pickable: true });
            }
        });
        B.superList().forEach(function (sp) {
            var id = "susuper:" + sp.star;
            if (B.isDestroyed(id) || !superOnMap()) return;
            var e = { kind: "super", id: id, star: sp.star, sup: sp, pos: B.superPos(sp, ep), radius: B.SUPER_RADIUS }, s = toScreen(e.pos.x, e.pos.z), r = Math.max(3, e.radius * M.zoom);
            if (M.sel === id) ctx.arc(s.x, s.y, r + 2, r + 3.5, 0, 360, "#FFD700", 1);
            ctx.arc(s.x, s.y, 0, r, 0, 360, S.superBalls.indexOf(sp.star) >= 0 ? "#FFB52E" : "#8C8C8C", 1);
            ctx.textStyled("§e" + sp.star + "★", s.x, s.y + r + 3, 0.7, "#FFE08A", 1, 0.5, FONT, "#000000");
            M.items.push({ e: e, sx: s.x, sy: s.y, pickable: true });
        });
        if (RPG.player.dimension === SPACE) {
            var ps = toScreen(RPG.player.x, RPG.player.z), yaw = RPG.player.yaw * Math.PI / 180;
            var fx = -Math.sin(yaw), fz = Math.cos(yaw);
            ctx.poly([ps.x + fx * 6, ps.y + fz * 6, ps.x - fz * 3.5 - fx * 3, ps.y + fx * 3.5 - fz * 3, ps.x + fz * 3.5 - fx * 3, ps.y - fx * 3.5 - fz * 3], "#FFFFFF", 1);
            var te = S.autopilot ? targetEntry() : null;
            if (te) { var t = livePos(te, ep), ts = toScreen(t.x, t.z); line(ctx, ps.x, ps.y, ts.x, ts.y, "#40FF80"); }
        }
        ctx.unclip();
        // side panel
        var px = ctx.width - pad - 124, py = pad + 4;
        BUTTONS = [];
        ctx.textStyled("§lStar Map", px + 60, py, 1.2, "#FFD700", 1, 0.5, FONT, "#000000");
        py += 18;
        var sel = M.sel ? (M.selEntry && M.selEntry.id === M.sel ? M.selEntry : B.find(M.sel, ep)) : null;
        if (sel) {
            var info = S.info[M.sel] || {}, bp = livePos(sel, ep), rows = [];
            ctx.textStyled("§l" + nameOf(sel), px + 4, py, 1, "#20E0FF", 1, 0, FONT, "#000000"); py += 14;
            if (sel.kind === "fixed") rows.push(["Orbit", fmt(sel.body.orbitRadius * cfg("distanceScale", 0.25)) + " blocks"], ["Year", Math.round(O.periodMillis(sel.body.orbitRadius) / 60000) + " min"]);
            else if (sel.kind === "planet") rows.push(["Orbit", fmt(sel.planet.ring) + " blocks"], ["Year", Math.round(O.periodMillis(sel.planet.ring) / 60000) + " min"], ["World", B.themeFor(sel.id).id]);
            else if (sel.kind === "super") rows.push(["Orbit", fmt(sel.sup.ring * cfg("distanceScale", 0.25)) + " blocks"], ["Ball", S.superBalls.indexOf(sel.star) >= 0 ? "§eunguarded" : "§5a God of Destruction guards it"]);
            else rows.push(["World", "stony moon"]);
            rows.push(["Size", Math.round(sel.radius * 2) + " blocks"], ["Distance", RPG.player.dimension === SPACE ? fmt(Math.max(0, dist(me(), bp) - sel.radius)) : "-"],
                ["Fighters", info.count === undefined ? "?" : String(info.count)], ["", info.loaded === false ? "§cNot loaded" : info.owner ? "§6Owner: " + info.owner : info.visited ? "§aVisited" : "§7Unexplored"]);
            rows.forEach(function (r) { ctx.textStyled((r[0] ? "§7" + r[0] + ": §f" : "") + r[1], px + 4, py, 0.85, "#FFFFFF", 1, 0, FONT, null); py += 11; });
            if (info.players && info.players.length) { ctx.textStyled("§7" + info.players.join(", "), px + 4, py, 0.7, "#FFFFFF", 1, 0, FONT, null); py += 10; }
            py += 6;
            var riding = RPG.player.vehicleId === "spacepod";
            var can = riding && !(sel.kind === "fixed" && RPG.player.dimension === sel.body.dim) && S.autopilot !== M.sel;
            if (typeof DMZ_UI !== "undefined") DMZ_UI.button(ctx, "Autopilot", px + 24, py, can);
            if (can) BUTTONS.push({ x: px + 24, y: py, fn: function () { var req = infoReqFor(sel); RPG.net.send("dbr_space_autopilot", req); RPG.sound("dmzpack:ui_nave_takeoff", 1, 1); RPG.screen.close(); } });
            py += 24;
            if (!riding) { ctx.textStyled("§7Ride a space pod to use the autopilot.", px + 4, py, 0.7, "#FFFFFF", 1, 0, FONT, null); py += 12; }
        } else {
            ctx.textStyled("§7Click a planet.", px + 4, py, 0.85, "#FFFFFF", 1, 0, FONT, null); py += 14;
        }
        if (S.autopilot) {
            ctx.textStyled("§aAutopilot: " + nameOf(targetEntry()), px + 4, py, 0.85, "#FFFFFF", 1, 0, FONT, null); py += 12;
            if (typeof DMZ_UI !== "undefined") DMZ_UI.button(ctx, "Stop", px + 24, py, true);
            BUTTONS.push({ x: px + 24, y: py, fn: function () { RPG.net.send("dbr_space_autopilot", { id: "" }); } });
        }
        ctx.textStyled("§7Drag: move   Scroll: zoom", px + 4, ctx.height - pad - 12, 0.7, "#FFFFFF", 1, 0, FONT, null);
    }
    function line(ctx, x0, y0, x1, y1, col) {
        var dx = x1 - x0, dy = y1 - y0, len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1) return;
        var nx = -dy / len * 0.6, ny = dx / len * 0.6;
        ctx.poly([x0 + nx, y0 + ny, x1 + nx, y1 + ny, x1 - nx, y1 - ny, x0 - nx, y0 - ny], col, 0.7);
    }
    // ---- the planet buster (PlanetBusterModule): the giant ball on its way, the clash, the doom ramp and the shatter ----
    var BT = { tick: 0, balls: {}, clash: null, exhausted: 0, exhaustTicks: 0, doom: {}, shatters: [] };
    var KIBLAST = "dmzpack:textures/entity/ki/kiblast.png", HUDTEX = "dmzpack:textures/gui/hud/kicharge_hud.png";
    RPG.net.on("dbr_buster", function (d) {
        if (!d) return;
        var id = "dbr_bust_" + d.n, b = BT.balls[d.n];
        if (d.end) {
            RPG.world3d.remove(id); RPG.world3d.remove(id + "g");
            delete BT.balls[d.n];
            if (d.boom) {
                RPG.particle("minecraft:explosion_emitter", d.x, d.y, d.z, 3, d.size * 0.5, 0);
                RPG.soundAt("minecraft:entity.generic.explode", d.x, d.y, d.z, 4, 0.5);
            }
            return;
        }
        if (!b) {
            b = BT.balls[d.n] = { x: d.x, y: d.y, z: d.z, vx: 0, vy: 0, vz: 0 };
            RPG.world3d.billboard(id + "g", { x: d.x, y: d.y, z: d.z, size: d.size * 2.2, color: d.border || "#00F8FF", alpha: 0.45, blend: "additive", seeThrough: false });
            RPG.world3d.billboard(id, { x: d.x, y: d.y, z: d.z, size: d.size * 1.4, texture: KIBLAST, color: d.color || "#FFFFFF", alpha: 1, blend: "additive" });
        } else { b.vx = (d.x - b.x) / 2; b.vy = (d.y - b.y) / 2; b.vz = (d.z - b.z) / 2; b.x = d.x; b.y = d.y; b.z = d.z; }
        b.clash = !!d.clash; b.seen = BT.tick;
        if (b.clash) { b.vx = 0; b.vy = 0; b.vz = 0; }
    });
    RPG.net.on("dbr_clash", function (d) {
        if (!d) return;
        if (d.start) { BT.clash = { seed: O.u64.make(Number(d.hi), Number(d.lo)), start: BT.tick, adv: 0.5, self: d.self || "#00F8FF", foe: d.foe || "#66CCFF", consumed: -1, grade: null, gradeAt: 0 }; return; }
        if (d.end) { BT.clash = null; if (d.exhaust) { BT.exhausted = BT.tick + Number(d.exhaust); BT.exhaustTicks = Number(d.exhaust); } return; }
        if (BT.clash && d.adv !== undefined) BT.clash.adv = Number(d.adv);
    });
    function clashTime(partial) { return BT.clash ? Math.max(0, BT.tick - BT.clash.start + (partial || 0)) : 0; }
    // right click while the marker crosses the window (ClientBeamClashState.onLocalPress)
    RPG.on("mouse", function (button, down) {
        if (!BT.clash || button !== 1 || !down) return;
        var t = Math.max(0, clashTime(BT.lastPartial || 0) - 0.5), smp = DBR_CLASH.sample(BT.clash.seed, t);
        if (smp.cycle.index > BT.clash.consumed) { BT.clash.consumed = smp.cycle.index; BT.clash.grade = smp.grade; BT.clash.gradeAt = RPG.nowMs(); }
        RPG.net.send("dbr_clash_press", { t: t, m: smp.marker });
        return false;
    });
    // ---- the doom sequence (DMZR PlanetDoomEffects + SpaceBodyRenderer.drawShatter) ----
    // RAMP: the body reddens over redRampTicks with a cubic ease-in (r -> 1, g and b -> 0; its rim keeps its colour).
    // SHATTER: over shatterTicks, 24 cubes of the planet's sheet (DMZR's tinted placeholder sheets, picked by the id's
    // hash) fly out along hashed directions (cosine-uniform elevation) at 0.55-1.45 x speed to 2.5 x the radius,
    // spinning (hashed start + 540 degrees x speed, 0.6 of that about x), shrinking to 0.4 x 0.22 x the radius and fading
    // out; they start red-hot and cool to the planet's tint. The first 45% is the detonation flash: three halo discs at
    // the planet (orange x3, pale x1.8, white x1 of a radius growing to 3x), fading as (1 - p / 0.45)^2. The bang plays at
    // the listener, 0.35-1 volume over 600 blocks, pitch 0.55. Drawn as sky bodies, so far debris stays where the planet was.
    var SHARD_COUNT = 24, SHARD_SPREAD = 2.5, SHARD_SIZE = 0.22, FLASH_WINDOW = 0.45, FLASH_GROWTH = 2.0;
    var SALT_AZIMUTH = 0x5A1, SALT_ELEVATION = 0xE1E, SALT_SPEED = 0x59D, SALT_SPIN = 0x591;
    var DETONATION_FALLOFF = 600, DETONATION_MIN = 0.35;
    function javaHash(str) { var h = 0; for (var i = 0; i < str.length; i++) h = (Math.imul(h, 31) + str.charCodeAt(i)) | 0; return h; }
    // splitmix64 over (id hash, index, salt) as DMZR's shardHash (64-bit), 0..1 from the top 24-bit window
    var U = O.u64, K_ID = U.C1, K_INDEX = U.make(0xC2B2AE3D, 0x27D4EB4F), K_SALT = U.make(0x165667B1, 0x9E3779F9);
    var K_A = U.make(0xBF58476D, 0x1CE4E5B9), K_B = U.make(0x94D049BB, 0x133111EB);
    function shardUnit(id, index, salt) {
        var z = U.xor(U.xor(U.mul(U.fromInt(javaHash(id)), K_ID), U.mul(U.fromInt(index), K_INDEX)), U.mul(U.fromInt(salt), K_SALT));
        z = U.mul(U.xor(z, U.shr(z, 30)), K_A);
        z = U.mul(U.xor(z, U.shr(z, 27)), K_B);
        z = U.xor(z, U.shr(z, 31));
        return ((z.lo >>> 24) | ((z.hi & 0xFFFF) << 8)) / 16777216;
    }
    RPG.net.on("dbr_planet_doom", function (d) {
        if (!d || !d.id) return;
        if (d.phase === "ramp") { BT.doom[d.id] = { start: BT.tick, ticks: Math.max(1, Number(d.ticks) || 60) }; return; }
        var e = null;
        LIST.forEach(function (x) { if (x.id === d.id) e = x; });
        delete BT.doom[d.id];
        if (!e || !skyDim) return;
        var sh = { id: d.id, pos: { x: e.pos.x, y: e.pos.y, z: e.pos.z }, r: e.kind === "star" ? e.radius * 3 : e.radius, start: BT.tick,
            ticks: Math.max(1, Number(d.ticks) || 40), dim: skyDim, tint: e.tint !== undefined ? Number(e.tint) : 0xFFFFFF, shards: [] };
        sh.tex = TEX + "planet_placeholder_" + O.floorMod(javaHash(d.id), 3) + ".png";
        for (var i = 0; i < SHARD_COUNT; i++) {
            var az = shardUnit(d.id, i, SALT_AZIMUTH) * Math.PI * 2, cosEl = shardUnit(d.id, i, SALT_ELEVATION) * 2 - 1, sinEl = Math.sqrt(Math.max(0, 1 - cosEl * cosEl));
            sh.shards.push({ ux: Math.cos(az) * sinEl, uy: cosEl, uz: Math.sin(az) * sinEl, speed: 0.55 + shardUnit(d.id, i, SALT_SPEED) * 0.9, spin: shardUnit(d.id, i, SALT_SPIN) * 360 });
        }
        var used = {};
        BT.shatters.forEach(function (o) { used[o.slot] = true; });
        for (sh.slot = 0; used[sh.slot]; sh.slot++) { }
        BT.shatters.push(sh);
        if (DRAWN[d.id]) RPG.sky.update(skyDim, d.id, { visible: false });       // gone at once; the next refresh drops it
        var dx = e.pos.x - RPG.player.x, dy = e.pos.y - RPG.player.y, dz = e.pos.z - RPG.player.z;
        var falloff = 1 - Math.min(1, Math.sqrt(dx * dx + dy * dy + dz * dz) / DETONATION_FALLOFF);
        RPG.sound("minecraft:entity.generic.explode", DETONATION_MIN + (1 - DETONATION_MIN) * falloff, 0.55);
    });
    // one frame of a shatter: the flash discs and the 24 shards as sky bodies (ids by slot, so a few are reused); false
    // when it is over (bodies removed). The look is sent once, then only what moves.
    function drawShatter(sh, partial) {
        var p = (BT.tick - sh.start + (partial || 0)) / sh.ticks, n, u = {}, pre = "dbr_shatter" + sh.slot + "_";
        if (p >= 1 || sh.dim !== skyDim) {
            if (sh.dim === skyDim) for (n = 0; n < SHARD_COUNT + 3; n++) RPG.sky.removeBody(sh.dim, pre + n);
            return false;
        }
        p = Math.max(0, p);
        var R = sh.r, heat = 1 - p, t = rgb(sh.tint), first = !sh.drawn;
        var col = hex(t[0] + (255 - t[0]) * heat, t[1] * (1 - heat), t[2] * (1 - heat));
        var flash = 1 - Math.min(1, p / FLASH_WINDOW), ease = flash * flash, grow = R * (1 + FLASH_GROWTH * (1 - flash));
        for (n = 0; n < 3; n++) {
            var f = FLASH_DISCS[n], b = { radius: grow * f[0], alpha: f[2] * ease, visible: flash > 0 };
            if (first) { b.x = sh.pos.x; b.y = sh.pos.y; b.z = sh.pos.z; b.shape = "billboard"; b.texture = TEX + "star_halo.png"; b.color = f[1]; b.shading = "flat"; }
            u[pre + (SHARD_COUNT + n)] = b;
        }
        for (n = 0; n < SHARD_COUNT; n++) {
            var s = sh.shards[n], travel = R * SHARD_SPREAD * p * s.speed, spin = s.spin + p * 540 * s.speed;
            var c = { x: sh.pos.x + s.ux * travel, y: sh.pos.y + s.uy * travel, z: sh.pos.z + s.uz * travel, radius: R * SHARD_SIZE * (1 - p * 0.6),
                color: col, alpha: 1 - p, yaw: spin, tilt: spin * 0.6 };
            if (first) { c.shape = "cube"; c.texture = sh.tex; c.uv = BOX; c.shading = "flat"; c.spin = 0; c.minSize = 0; c.visible = true; c.layers = []; }
            u[pre + n] = c;
        }
        sh.drawn = true;
        RPG.sky.updateAll(sh.dim, u);
        return true;
    }
    // DMZR's flash discs: size x the growing radius, colour, peak alpha
    var FLASH_DISCS = [[3.0, "#FF731F", 0.75], [1.8, "#FFD98C", 0.95], [1.0, "#FFFFFF", 1.0]];
    // the red ramp (DMZR's packDoom): the body colour's red goes to full and green and blue to nothing, eased in cubically
    function redden(c, k) {
        var v = typeof c === "string" ? parseInt(c.replace("#", ""), 16) : (c === undefined ? 0xFFFFFF : c), rr = (v >> 16) & 255, gg = (v >> 8) & 255, bb = v & 255;
        return hex(rr + (255 - rr) * k, gg * (1 - k), bb * (1 - k));
    }
    RPG.on("tick", function () {
        BT.tick++;
        for (var n in BT.balls) {
            var b = BT.balls[n];
            if (BT.tick - b.seen > 60) { RPG.world3d.remove("dbr_bust_" + n); RPG.world3d.remove("dbr_bust_" + n + "g"); delete BT.balls[n]; continue; }
            b.x += b.vx; b.y += b.vy; b.z += b.vz;
            RPG.world3d.update("dbr_bust_" + n, { x: b.x, y: b.y, z: b.z, roll: (BT.tick * 7) % 360 });
            RPG.world3d.update("dbr_bust_" + n + "g", { x: b.x, y: b.y, z: b.z, alpha: b.clash ? 0.45 + 0.25 * Math.sin(BT.tick * 0.6) : 0.45 });
        }
        // the red ramp on a doomed body
        if (skyDim) for (var id in BT.doom) {
            var dm = BT.doom[id], k = Math.min(1, (BT.tick - dm.start) / dm.ticks), e = null;
            if (BT.tick - dm.start > dm.ticks * 2) { delete BT.doom[id]; continue; }        // a ramp with no shatter after it
            LIST.forEach(function (x) { if (x.id === id) e = x; });
            if (!e || !DRAWN[id]) continue;
            RPG.sky.update(skyDim, id, { color: redden(lookFor(e).color, k * k * k) });
        }
    });
    // the clash HUD (DragonMine Z BeamClashOverlay): the tug-of-war bar and the sweeping press meter, on DMZ's ki bar art
    RPG.hud.onRender(function (ctx) {
        BT.lastPartial = ctx.partial;
        if (BT.shatters.length) BT.shatters = BT.shatters.filter(function (sh) { return drawShatter(sh, ctx.partial); });
        var W = ctx.width, H = ctx.height, PW = 252, PH = 94, BW = 212, BH = 14;
        var px = (W - PW) / 2, py = H - PH - 34, bx = px + (PW - BW) / 2;
        if (!BT.clash) {
            if (BT.exhausted > BT.tick) {
                var rem = (BT.exhausted - BT.tick) / Math.max(1, BT.exhaustTicks), pulse = 0.75 + 0.25 * Math.sin(RPG.nowMs() / 1000 * 9);
                ctx.textStyled("§lEXHAUSTED", W / 2, py + 30, 1.6, "#FF5A5A", Math.min(1, rem * 3) * pulse, 0.5, FONT, "#000000");
            }
            return;
        }
        var c = BT.clash, t = clashTime(ctx.partial), smp = DBR_CLASH.sample(c.seed, t), cy = smp.cycle, adv = Math.max(0, Math.min(1, c.adv));
        var tugY = py + 27, swY = py + 60;
        ctx.fill(px, py, PW, PH, "#0A0E18", 0.75);
        ctx.fill(px + 2, py + 2, PW - 4, PH - 4, "#000000", 0.38);
        ctx.fill(px, py, PW, 1, c.self, 1); ctx.fill(px, py + PH - 1, PW, 1, c.foe, 1);
        ctx.textStyled("§c§lPLANET CLASH!", W / 2, py + 7, 1, "#FFFFFF", 1, 0.5, FONT, "#000000");
        ctx.textStyled("YOU", bx, tugY - 11, 0.9, c.self, 1, 0, FONT, "#000000");
        ctx.textStyled("PLANET", bx + BW, tugY - 11, 0.9, c.foe, 1, 1, FONT, "#000000");
        var split = Math.round(BW * adv);
        ctx.quad(HUDTEX, bx, tugY, BW, BH, 0, 0, 148 / 256, 14 / 256, "#FFFFFF", 1);
        if (split > 0) ctx.quad(HUDTEX, bx, tugY, split, BH, 0, 14 / 256, 148 * (split / BW) / 256, 28 / 256, c.self, 1);
        if (split < BW) ctx.quad(HUDTEX, bx + split, tugY, BW - split, BH, 148 * (split / BW) / 256, 14 / 256, 148 / 256, 28 / 256, c.foe, 1);
        ctx.fill(bx + BW / 2, tugY - 1, 1, BH + 2, "#FFFFFF", 0.35);
        ctx.fill(bx + split - 1, tugY - 2, 2, BH + 4, "#FFFFFF", 1);
        ctx.quad(HUDTEX, bx, swY, BW, BH, 0, 0, 148 / 256, 14 / 256, "#FFFFFF", 1);
        var lowX = bx + BW * (cy.center - cy.halfWidth), highX = bx + BW * (cy.center + cy.halfWidth);
        ctx.quad(HUDTEX, lowX, swY, highX - lowX, BH, 148 * (cy.center - cy.halfWidth) / 256, 14 / 256, 148 * (cy.center + cy.halfWidth) / 256, 28 / 256, c.self, 0.55);
        var core = BW * cy.halfWidth * DBR_CLASH.PERFECT, cx0 = bx + BW * cy.center;
        ctx.fill(cx0 - core, swY + 1, core * 2, BH - 2, "#FFFFFF", 0.45);
        ctx.fill(lowX, swY - 1, 1, BH + 2, "#FFFFFF", 0.9); ctx.fill(highX - 1, swY - 1, 1, BH + 2, "#FFFFFF", 0.9);
        var mx = bx + BW * smp.marker, age = c.grade ? (RPG.nowMs() - c.gradeAt) / 750 : 1;
        if (c.grade && age < 0.25) ctx.fill(lowX, swY, highX - lowX, BH, c.grade === "PERFECT" ? "#FFD84A" : c.grade === "MISS" ? "#FF5A5A" : "#FFFFFF", 0.65 * (1 - age / 0.25));
        ctx.fill(mx - 1, swY - 3, 2, BH + 6, "#FFFFFF", 1);
        ctx.poly([mx - 5, swY - 10, mx + 5, swY - 10, mx, swY - 5], c.self, 1);
        if (c.grade && age < 1) ctx.textStyled(c.grade === "PERFECT" ? "§lPERFECT!" : c.grade === "GOOD" ? "GOOD" : "MISS", W / 2, py - 16 - 8 * age, 1.3,
            c.grade === "PERFECT" ? "#FFD84A" : c.grade === "MISS" ? "#FF5A5A" : "#FFFFFF", 1 - age * age, 0.5, FONT, "#000000");
        ctx.textStyled("Right Click when the marker hits the window!", W / 2, swY + BH + 7, 0.8, "#B9C7D6", 1, 0.5, FONT, null);
    });
})();
