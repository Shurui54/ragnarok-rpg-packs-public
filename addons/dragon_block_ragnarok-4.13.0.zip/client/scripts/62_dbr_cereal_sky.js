// =====================================================================================
//  62_dbr_cereal_sky.js - Planet Cereal's sky (Dragon Block Ragnarok's own, GPL-3.0)
// =====================================================================================
//  The biomes give the colours (a pale lilac sky, warm haze, teal water; datapack/data/dbr/worldgen/biome/cereal_*.json);
//  over the normal sun, moon and clouds hang Cereal's neighbours, drawn with DragonMine Z's own sky sheets
//  (textures/environment/demon_realm: the pale moon twice and the great banded planet), the way DMZ hangs worlds
//  over its Demon Realm (CustomSpecialEffects.DemonRealmEffects drawBody: yaw, elevation, size, alpha).
// =====================================================================================
(function () {
    var DIM = "ragnarok_rpg:cereal_planet", ENV = "dmzpack:textures/environment/demon_realm/";
    function dir(yaw, elev) {
        var y = yaw * Math.PI / 180, e = elev * Math.PI / 180;
        return [Math.cos(e) * Math.cos(y), Math.sin(e), Math.cos(e) * Math.sin(y)];
    }
    function body(id, tex, yaw, elev, size, alpha) {
        return { id: id, texture: ENV + tex, shape: "billboard", dir: dir(yaw, elev), radius: size, alpha: alpha, shading: "flat" };
    }
    RPG.sky.define(DIM, { vanilla: true, bodies: [
        body("cereal_giant", "mega_planet", 300, 24, 16, 0.85),
        body("cereal_moon_a", "pale_moon", 120, 16, 7, 0.7),
        body("cereal_moon_b", "pale_moon", 150, 34, 3, 0.55)
    ] });
})();
