// =====================================================================================
//  29_dmz_menu_fx.js - DMZ's menu transitions (BaseMenuScreen), for every V-menu screen
// =====================================================================================
//  DragonMine Z (GPL-3.0) client/gui/character/util/BaseMenuScreen.java:
//   - opening a menu: the dark background fades in (easeOutCubic of twice the progress) while
//     the panels slide in over 520 ms with easeOutBack: left panels from 190 px to the left,
//     right panels from 190 px to the right, the top panel from 90 px above, the centre model
//     from 260 px below;
//   - switching menus with the navigation row (or a tab key): the panels slide out over 140 ms
//     with easeInBack (the background stays), then the next menu's panels slide in (no fade);
//     when both menus show the player model in the middle it stays put instead of sliding;
//   - closing (Esc or the menu key): panels out and the background fades over 180 ms, then the
//     screen closes, and the menu key can't reopen it for 450 ms;
//   - no input reaches a menu while its panels are on their way out.
//  The navigation row itself never moves.
//
//  A screen uses it like this:
//    DMZ_MENU_FX.open("stats", function () { RPG.screen.open(DMZ_MENU_FX.wrap({ id: ..., elements: ... })); });
//    elements carry group: "left" | "right" | "top" | "bottom" | "center" to slide with their side;
//    what the screen draws itself it translates by DMZ_MENU_FX.left() / right() / top() / center();
//    the navigation row calls DMZ_MENU_FX.switchTo(tab) instead of sending "dmz_menu" itself.
//  The next menu's data comes from the server while the old panels slide out; it opens as soon as
//  both are done (on the client tick, like BaseMenuScreen.tick).
// =====================================================================================
var DMZ_MENU_FX = (function () {
    var ENTER_MS = 520, EXIT_MS = 140, CLOSE_MS = 180, REOPEN_MS = 450, WAIT_MS = 2500;
    var SIDE = 190, TOP = 90, CENTER = 260;
    // BaseMenuScreen.hasCenterModel(): the screens that draw the player in the middle (DMZ's party menu does too,
    // DBR's simplified party page doesn't, so the model slides away when switching to it)
    var CENTER_TABS = { stats: 1, skills: 1, minigames: 1 };
    var S = null;              // the open menu's transition: { tab, id, center, state, t0, fading, centerAnimated, closing }
    var carried = null;        // a switch finished: { centerCarried } for the menu that opens next
    var queued = null;         // the next menu's open, waiting for the panels to finish leaving
    var reopenBlockedUntil = 0;

    function now() { return RPG.nowMs(); }
    function clamp01(t) { return t < 0 ? 0 : t > 1 ? 1 : t; }
    function easeOutBack(t) { var c1 = 1.70158, c3 = c1 + 1, p = t - 1; return 1 + c3 * p * p * p + c1 * p * p; }
    function easeInBack(t) { var c1 = 1.70158, c3 = c1 + 1; return c3 * t * t * t - c1 * t * t; }
    function easeOutCubic(t) { var i = 1 - clamp01(t); return 1 - i * i * i; }
    function moving() { return S && (S.state === "enter" || S.state === "exit" || S.state === "gone"); }
    function progress() {
        if (!S || S.state === "none") return 1;
        if (S.state === "gone") return 1;
        var d = S.state === "enter" ? ENTER_MS : S.closing ? CLOSE_MS : EXIT_MS;
        return clamp01((now() - S.t0) / d);
    }
    /** BaseMenuScreen's offsets: 0 when still, from -1 (fully away) on the entering / leaving curve. */
    function amount() {
        if (!moving()) return 0;
        if (S.state === "gone") return -1;
        var p = progress();
        return S.state === "enter" ? easeOutBack(p) - 1 : -easeInBack(p);
    }
    /** getPanelExitProgress: easeInBack of the way out (0 unless leaving; 1 once gone). */
    function exitProgress() {
        if (!S || (S.state !== "exit" && S.state !== "gone")) return 0;
        return S.state === "gone" ? 1 : easeInBack(progress());
    }
    function left() { return amount() * SIDE; }
    function right() { return -amount() * SIDE; }
    function top() { return amount() * TOP; }
    function bottom() { return -amount() * TOP; }
    function center() { return S && S.centerAnimated ? -amount() * CENTER : 0; }
    /** renderMenuBackground's visibility: fades in on a fresh open, out on close, full while switching. */
    function visibility() {
        if (!S) return 1;
        if (S.fading && S.state === "enter") return clamp01(easeOutCubic(progress() * 2));
        if (S.fading && S.state === "exit") return clamp01(1 - progress());
        return 1;
    }
    /** BaseMenuScreen blocks input while EXITING. */
    function blocked() { return !!S && (S.state === "exit" || S.state === "gone"); }

    /** A menu screen wants to open (fn calls RPG.screen.open). */
    function open(tab, fn) {
        var t = now();
        var openId = RPG.screen.getOpen(), menuOpen = !!S && !!S.id && openId === S.id && !S.closing;
        if (menuOpen && S.tab === tab && S.state !== "exit" && S.state !== "gone") { fn(); return; }   // a refresh: no new animation
        if (menuOpen && S.state === "exit") { queued = { tab: tab, fn: fn }; return; }
        // another menu replaces the open one (its panels already left, or the server switched it): no background fade
        var switching = !!carried || menuOpen;
        if (!switching && tab === "stats" && t < reopenBlockedUntil) return;       // statsMenuReopenBlockedUntilMs
        var centerCarried = carried ? carried.centerCarried : menuOpen && S.state !== "gone" ? !!(S.center && CENTER_TABS[tab]) : false;
        carried = null; queued = null;
        S = { tab: tab, id: null, center: !!CENTER_TABS[tab], state: "enter", t0: t, fading: !switching,
              centerAnimated: switching ? !centerCarried : true, closing: false };
        fn();
        S.id = RPG.screen.getOpen();
    }
    /** The navigation row / a tab key: slide this menu out and ask the server for the next one. */
    function switchTo(tab, send) {
        if (!S || S.closing || S.state === "exit" || S.state === "gone") return false;
        if (tab === S.tab) return false;
        S.state = "exit"; S.t0 = now(); S.fading = false;
        S.centerAnimated = !(S.center && CENTER_TABS[tab]);
        S.next = tab;
        if (send) send(); else RPG.net.send("dmz_menu", { tab: tab });
        return true;
    }
    /** Esc / the menu key: startCloseTransition. */
    function close() {
        if (!S) { if (RPG.screen.getOpen()) RPG.screen.close(); return; }
        if (S.closing) return;
        S.closing = true; S.fading = true; S.centerAnimated = true; S.state = "exit"; S.t0 = now();
        reopenBlockedUntil = now() + REOPEN_MS;
    }
    /** A wrapped screen closed: forget the transition unless the next menu is replacing it. */
    function closed(id) {
        if (!S || S.id !== id) return;
        if (S.state === "gone" || (S.state === "exit" && !S.closing)) return;
        S = null;
    }

    RPG.on("tick", function () {
        if (!S) return;
        var openId = RPG.screen.getOpen();
        if (S.id && openId !== S.id && S.state !== "gone") { S = null; queued = null; return; }   // closed some other way
        var p = progress();
        if (S.state === "enter" && p >= 1) { S.state = "none"; S.fading = false; }
        if (S.state === "exit" && p >= 1) {
            if (S.closing) { var id = S.id; S = null; if (RPG.screen.getOpen() === id) RPG.screen.close(); return; }
            S.state = "gone"; S.goneAt = now();
            carried = { centerCarried: !S.centerAnimated };
            if (queued) { var q = queued; queued = null; open(q.tab, q.fn); return; }
        }
        // the server never answered (no permission, a slow link): slide this menu back in
        if (S.state === "gone" && now() - S.goneAt > WAIT_MS) { carried = null; S.state = "enter"; S.t0 = now(); }
    });

    function menuKey(k) { try { return k === String(RPG.actionKey(10)); } catch (e) { return false; } }   // "Stats Menu" (45_keys.js)

    /**
     * The screen spec with DMZ's transition behaviour: no engine background (the menu draws its own fading dim),
     * the sides' offsets applied to grouped elements every frame, input held while leaving, Esc / the menu key
     * closing with the animation.
     */
    function wrap(spec) {
        var bgFn = spec.onBackground, mouseFn = spec.onMouse, keyFn = spec.onKey, scrollFn = spec.onScroll, closeFn = spec.onClose;
        var id = spec.id;
        spec.background = "none";
        spec.closeOnEsc = false;
        spec.onBackground = function (ctx) {
            var v = visibility();
            // Screen.renderBackground's gradient (0xC0101010 -> 0xD0101010) at the menu's visibility
            if (v > 0) ctx.gradient(0, 0, ctx.width, ctx.height, argb(0xC0 * v), argb(0xD0 * v));
            var l = left(), r = right(), t = top(), b = bottom(), c = center();
            RPG.screen.groupOffset("left", l, 0);
            RPG.screen.groupOffset("right", r, 0);
            RPG.screen.groupOffset("top", 0, t);
            RPG.screen.groupOffset("bottom", 0, b);
            RPG.screen.groupOffset("center", 0, c);
            if (bgFn) return bgFn(ctx);
        };
        spec.onMouse = function (x, y, b, a) {
            if (blocked()) return false;
            return mouseFn ? mouseFn(x, y, b, a) : undefined;
        };
        spec.onScroll = function (x, y, d) {
            if (blocked()) return;
            if (scrollFn) return scrollFn(x, y, d);
        };
        spec.onKey = function (k, a) {
            if (blocked()) return false;
            var r = keyFn ? keyFn(k, a) : undefined;
            if (r === false) return false;
            if (a === "down" && (k === "key.keyboard.escape" || menuKey(k))) { close(); return false; }
            return r;
        };
        spec.onClose = function () { closed(id); if (closeFn) closeFn(); };
        return spec;
    }
    function argb(a) {
        var h = Math.max(0, Math.min(255, Math.round(a))).toString(16);
        return "#" + (h.length < 2 ? "0" + h : h) + "101010";
    }

    return { open: open, wrap: wrap, switchTo: switchTo, close: close, closed: closed, blocked: blocked,
        amount: amount, exitProgress: exitProgress, easeOutBack: easeOutBack, left: left, right: right, top: top, bottom: bottom, center: center, visibility: visibility,
        active: function () { return S ? S.tab : null; }, moving: moving };
})();
