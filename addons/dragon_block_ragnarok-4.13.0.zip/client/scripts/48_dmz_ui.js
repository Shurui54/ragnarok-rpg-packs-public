// =====================================================================================
//  Drawing helpers shared by the DMZ skills and quest screens: DMZ's PanelSkin (sliced
//  panel textures), bordered text, word wrap, textured buttons, tooltips and the short
//  status messages the server sends ("dmz_msg").
// =====================================================================================
var DMZ_UI = (function () {
    var FONT = "dmzpack:smooth";
    var BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var GRID = 7;

    // ---- PanelSkin (client/util/PanelSkin.java) ----
    function seg(kind, length, period, priority) { return { kind: kind, length: length, period: period, priority: priority || 0 }; }
    function fixed(n) { return seg("fixed", n, 1); }
    function tile(n) { return seg("tile", n, GRID); }
    function stretch(n) { return seg("tile", n, 1); }
    function decor(n, p) { return seg("decor", n, 1, p); }
    function band(n) { return seg("band", n, GRID); }
    function shrink(n) { return seg("band", n, 1); }
    function total(s) { var t = 0; s.forEach(function (x) { t += x.length; }); return t; }

    function distribute(s, kind, amount, lengths) {
        var nativeTotal = 0, last = -1, i;
        for (i = 0; i < s.length; i++) if (s[i].kind === kind) { nativeTotal += s[i].length; last = i; }
        if (last < 0) return;
        if (amount === nativeTotal) { for (i = 0; i < s.length; i++) if (s[i].kind === kind) lengths[i] = s[i].length; return; }
        var rem = [], used = 0, bumped = [];
        for (i = 0; i < s.length; i++) {
            if (s[i].kind !== kind) continue;
            var ideal = amount * s[i].length / nativeTotal / s[i].period, units = Math.floor(ideal);
            lengths[i] = units * s[i].period; rem[i] = ideal - units; used += lengths[i];
        }
        while (true) {
            var best = -1;
            for (i = 0; i < s.length; i++) {
                if (s[i].kind !== kind || bumped[i] || used + s[i].period > amount) continue;
                if (best < 0 || rem[i] > rem[best]) best = i;
            }
            if (best < 0 || rem[best] <= 0) break;
            bumped[best] = true; lengths[best] += s[best].period; used += s[best].period;
        }
        lengths[last] += amount - used;
    }

    function layout(s, target, strict) {
        var fixedLen = 0, bandLen = 0, tileLen = 0, decors = [], i;
        for (i = 0; i < s.length; i++) {
            if (s[i].kind === "fixed") fixedLen += s[i].length;
            else if (s[i].kind === "band") bandLen += s[i].length;
            else if (s[i].kind === "tile") tileLen += s[i].length;
            else decors.push(i);
        }
        decors.sort(function (a, b) { return s[b].priority - s[a].priority; });
        var flexNative = total(s) - fixedLen - bandLen, flexTarget = target - fixedLen - bandLen;
        var keep = flexTarget >= flexNative || flexNative <= 0 ? decors.length
            : Math.max(0, Math.min(decors.length, Math.round(decors.length * flexTarget / flexNative)));
        var decorLength = 0;
        for (i = 0; i < keep; i++) decorLength += s[decors[i]].length;
        while (keep > 0 && decorLength > Math.max(flexTarget, 0)) { keep--; decorLength -= s[decors[keep]].length; }
        var available = flexTarget - decorLength, bandLength = bandLen, deficit = 0;
        if (available > 0 && tileLen === 0) { if (strict) return null; bandLength += available; available = 0; }
        if (available < 0) {
            bandLength = bandLen + available; available = 0;
            if (bandLength < 0) { deficit = -bandLength; bandLength = 0; }
        }
        var lengths = [];
        for (i = 0; i < s.length; i++) lengths[i] = s[i].kind === "fixed" ? s[i].length : 0;
        for (i = 0; i < keep; i++) lengths[decors[i]] = s[decors[i]].length;
        distribute(s, "tile", available, lengths);
        distribute(s, "band", bandLength, lengths);
        var firstFixed = -1, lastFixed = -1;
        for (i = 0; i < s.length; i++) if (s[i].kind === "fixed") { if (firstFixed < 0) firstFixed = i; lastFixed = i; }
        var cropFirst = Math.floor((deficit + 1) / 2), cropLast = deficit - cropFirst;
        var pieces = [], position = 0, start = 0;
        for (i = 0; i < s.length; i++) {
            var length = lengths[i], source = start;
            if (i === firstFixed && cropFirst > 0) length = Math.max(0, length - cropFirst);
            if (i === lastFixed && cropLast > 0) { source += Math.min(cropLast, s[i].length); length = Math.max(0, length - cropLast); }
            if (length > 0) {
                if (s[i].kind === "tile" || s[i].kind === "band") {
                    var chunk = Math.max(s[i].period, Math.floor(s[i].length / s[i].period) * s[i].period);
                    for (var off = 0; off < length; off += chunk) pieces.push([position + off, Math.min(chunk, length - off), source]);
                } else pieces.push([position, length, source]);
            }
            position += length; start += s[i].length;
        }
        return pieces;
    }

    function Skin(texture, aw, ah, u, v, cols, rows) {
        var cache = {};
        return {
            draw: function (ctx, x, y, w, h, alpha) {
                w = Math.round(w); h = Math.round(h);
                if (w <= 0 || h <= 0) return;
                var key = w + "x" + h, l = cache[key];
                if (!l) { l = cache[key] = { xs: layout(cols, w, false), ys: layout(rows, h, false) }; }
                if (!l.xs || !l.ys) return;
                for (var c = 0; c < l.xs.length; c++) {
                    var xc = l.xs[c];
                    for (var r = 0; r < l.ys.length; r++) {
                        var yr = l.ys[r];
                        ctx.quad(texture, x + xc[0], y + yr[0], xc[1], yr[1], (u + xc[2]) / aw, (v + yr[2]) / ah,
                            (u + xc[2] + xc[1]) / aw, (v + yr[2] + yr[1]) / ah, "#FFFFFF", alpha === undefined ? 1 : alpha);
                    }
                }
            }
        };
    }
    var QUEST_PANEL = Skin("dmzpack:textures/gui/menu/questmenu.png", 512, 512, 1, 0,
        [fixed(14), tile(63), decor(49, 1), tile(91), decor(28, 2), tile(21), fixed(15)],
        [fixed(14), band(21), fixed(7), tile(7), decor(21, 5), tile(35), decor(21, 4), tile(35), decor(21, 3), tile(35), decor(21, 2), tile(35), decor(21, 1), tile(112), fixed(17)]);

    // ---- text ----
    function bordered(ctx, t, x, y, color, align, alpha) { ctx.textStyled(t, x, y, 1, color, alpha === undefined ? 1 : alpha, align || 0, FONT, "#000000"); }
    function plain(ctx, t, x, y, color, align, alpha) { ctx.textStyled(t, x, y, 1, color, alpha === undefined ? 1 : alpha, align || 0, FONT, null); }
    function width(ctx, t) { return ctx.textWidthIn(t, FONT); }
    function strip(s) { return String(s || "").replace(/§[0-9a-fk-or]/gi, ""); }

    /** TextUtil.wrap: words into lines no wider than maxWidth. */
    var wrapCache = {}, wrapCount = 0;
    function wrap(ctx, text, maxWidth) {
        var ck = maxWidth + "|" + text, hit = wrapCache[ck];
        if (hit) return hit;
        if (++wrapCount > 300) { wrapCache = {}; wrapCount = 0; }
        return (wrapCache[ck] = wrapRaw(ctx, text, maxWidth));
    }
    function wrapRaw(ctx, text, maxWidth) {
        var out = [];
        String(text || "").split("\n").forEach(function (para) {
            var words = para.split(" "), line = "";
            words.forEach(function (w) {
                var next = line ? line + " " + w : w;
                if (line && width(ctx, next) > maxWidth) { out.push(line); line = w; }
                else line = next;
                while (width(ctx, line) > maxWidth && line.length > 1) {
                    var cut = line.length - 1;
                    while (cut > 1 && width(ctx, line.substring(0, cut)) > maxWidth) cut--;
                    out.push(line.substring(0, cut)); line = line.substring(cut);
                }
            });
            out.push(line);
        });
        return out;
    }
    function ellipsis(ctx, text, maxWidth) {
        if (width(ctx, text) <= maxWidth) return text;
        var t = text;
        while (t.length > 0 && width(ctx, t + "...") > maxWidth) t = t.substring(0, t.length - 1);
        return t + "...";
    }

    /** RPG.translate with DMZ's %s / %1$s arguments filled in. */
    function tr(key) {
        var args = Array.prototype.slice.call(arguments, 1);
        var s = RPG.translate(key), i = 0;
        s = s.replace(/%(\d+)\$s/g, function (m, n) { var v = args[Number(n) - 1]; return v === undefined ? "" : String(v); });
        s = s.replace(/%s|%d/g, function () { var v = args[i++]; return v === undefined ? "" : String(v); });
        return s;
    }
    function hasTr(key) { return RPG.hasTranslation(key); }
    function humanize(raw) {
        if (!raw) return "?";
        var v = String(raw).replace(/^#/, ""), c = v.indexOf(":");
        var t = c >= 0 ? v.substring(c + 1) : v;
        if (t.indexOf("is_") === 0) t = t.substring(3);
        return t.split(/[_\- ]+/).filter(function (x) { return x; }).map(function (x) { return x.charAt(0).toUpperCase() + x.substring(1).toLowerCase(); }).join(" ");
    }

    // ---- textured button (TexturedTextButton, characterbuttons 0,28 / hover 0,48, 74x20) ----
    function inside(mx, my, x, y, w, h) { return mx >= x && my >= y && mx < x + w && my < y + h; }
    function button(ctx, label, x, y, active) {
        var over = active && inside(ctx.mouseX, ctx.mouseY, x, y, 74, 20);
        ctx.image(BUTTONS, x, y, 74, 20, 0, over ? 48 : 28, 74, 20, 256, 256);
        if (!active) ctx.fill(x + 2, y + 2, 70, 16, "#000000", 0.35);
        bordered(ctx, label, x + 37, y + 6, active ? (over ? "#FFFFA0" : "#FFFFFF") : "#A0A0A0", 0.5);
        return over;
    }

    // ---- tooltip (TextUtil.renderAdvancedTooltip look: dark box, coloured edge) ----
    function tooltip(ctx, lines, mx, my, edge) {
        if (!lines || !lines.length) return;
        var w = 0;
        lines.forEach(function (l) { w = Math.max(w, width(ctx, l[0])); });
        var h = lines.length * 10 + 6, x = mx + 10, y = my - 4;
        if (x + w + 8 > ctx.width) x = mx - w - 16;
        if (y + h > ctx.height) y = ctx.height - h - 2;
        if (y < 2) y = 2;
        ctx.fill(x - 1, y - 1, w + 10, h + 2, "#100010", 0.94);
        ctx.fill(x - 1, y - 1, w + 10, 1, edge || "#5000FF", 0.8);
        ctx.fill(x - 1, y + h, w + 10, 1, edge || "#5000FF", 0.5);
        lines.forEach(function (l, i) { plain(ctx, l[0], x + 4, y + 4 + i * 10, l[1] || "#FFFFFF"); });
    }

    // ---- "dmz_msg": a short status line from the server, shown on the open screen or the HUD ----
    var status = { text: "", color: "#FFFFFF", until: 0 };
    function showStatus(text, color) {
        status.text = text; status.color = color || "#FFFFFF"; status.until = RPG.nowMs() + 3000;
        if (!RPG.screen.getOpen()) {
            RPG.hud.set("dmz_msg", { type: "text", anchor: "bottom", x: 0, y: -70, text: text, color: status.color, shadow: true });
            // re-checks until it has expired: ticks can run slightly ahead of the clock, and a single check that
            // came early left the message on screen for good
            var shown = text;
            (function sweep() {
                RPG.schedule(10, function () {
                    if (status.text !== shown && RPG.nowMs() < status.until) return;   // a newer message took over (it sweeps itself)
                    if (RPG.nowMs() >= status.until - 50) RPG.hud.remove("dmz_msg"); else sweep();
                });
            })();
        }
    }
    function drawStatus(ctx, x, y) {
        var left = status.until - RPG.nowMs();
        if (left <= 0 || !status.text) return;
        bordered(ctx, status.text, x, y, status.color, 0.5, Math.min(1, left / 1000));
    }
    RPG.net.on("dmz_msg", function (d) {
        if (!d) return;
        var args = (d.args || []).slice();
        if (d.quest && typeof DMZ_QUEST_NAMES !== "undefined") args = [DMZ_QUEST_NAMES.label(d.quest)];
        if (typeof DMZ_WB_CLIENT !== "undefined") args = args.map(function (a) { return a && typeof a === "object" ? DMZ_WB_CLIENT.arg(a) : a; });   // boss names as lang keys
        showStatus(d.key ? tr.apply(null, [d.key].concat(args)) : String(d.text || ""), d.color);
    });

    // ---- 9-slice drawing and the searchable dropdown in DMZ's look ----
    /** Part u, v (uw x vh) of a 256x256 texture 9-sliced into x, y, w, h: b-texel corners kept, edges stretched one way. */
    function slice9(ctx, tex, x, y, w, h, u, v, uw, vh, b, texW, texH) { ctx.nineSlice(tex, x, y, w, h, u, v, uw, vh, texW || 256, texH || 256, b); }
    /** characterbuttons' 74x20 button at any size (rounded corners kept). */
    function buttonArt(ctx, x, y, w, h, over) { slice9(ctx, BUTTONS, x, y, w, h, 0, over ? 48 : 28, 74, 20, 4); }
    /** characterbuttons' text-field frame (orange edge, black inside) at any size. */
    function fieldArt(ctx, x, y, w, h) { slice9(ctx, BUTTONS, x, y, w, h, 0, 108, 107, 18, 3); }
    /** Props that skin a "dropdown" element (or a textured "button") in the DMZ look. */
    var DROP_SKIN = { texture: BUTTONS, texW: 256, texH: 256, u: 0, v: 108, uw: 107, vh: 18, slice: 3, font: FONT,
        bg: "#000000", listBg: "#F0060814", border: "#E07A10", highlight: "#8A4A08", text: "#FFFFFF", selectedText: "#FFD700", placeholderColor: "#9A9A9A" };
    var BUTTON_SKIN = { texture: BUTTONS, texW: 256, texH: 256, u: 0, v: 28, uw: 74, vh: 20, hoverU: 0, hoverV: 48, slice: 4, font: FONT };
    /**
     * A searchable pick-one dropdown in DMZ's look. options: ["a", ...] or [{value, label, icon, tooltip}];
     * onChange(value). extra: more element props (anchor, search, placeholder, maxVisible, custom...).
     */
    function dropdown(id, x, y, w, h, options, value, onChange, extra) {
        var e = { id: id, type: "dropdown", anchor: "center", x: x, y: y, w: w, h: h, options: options, value: value,
            onChange: function (eid, v) { if (onChange) onChange(v, eid); } };
        for (var k in DROP_SKIN) e[k] = DROP_SKIN[k];
        for (var k2 in extra || {}) e[k2] = extra[k2];
        return e;
    }

    function ease(t) { if (t <= 0) return 0; if (t >= 1) return 1; return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }
    function approach(cur, target, step) { return cur < target ? Math.min(target, cur + step) : cur > target ? Math.max(target, cur - step) : cur; }

    return { FONT: FONT, BUTTONS: BUTTONS, QUEST_PANEL: QUEST_PANEL, bordered: bordered, plain: plain, width: width, strip: strip, wrap: wrap,
        ellipsis: ellipsis, tr: tr, hasTr: hasTr, humanize: humanize, inside: inside, button: button, tooltip: tooltip,
        showStatus: showStatus, drawStatus: drawStatus, ease: ease, approach: approach,
        slice9: slice9, buttonArt: buttonArt, fieldArt: fieldArt, dropdown: dropdown, DROP_SKIN: DROP_SKIN, BUTTON_SKIN: BUTTON_SKIN,
        Skin: Skin, seg: { fixed: fixed, tile: tile, stretch: stretch, decor: decor, band: band } };
})();
