// =====================================================================================
//  99_dbr_debug_file.js - /rpgc debug (DMZ's DebugFileS2C): the server sends a character dump in pieces;
//  it is saved on this computer as ragnarok_rpg/local/dbrdebug/<player>.json
// =====================================================================================
(function () {
    var PARTS = {};
    RPG.net.on("dbr_debug_file", function (d) {
        if (!d || !d.tx) return;
        var t = PARTS[d.tx] || (PARTS[d.tx] = { n: d.n, got: 0, parts: [] });
        if (t.parts[d.i] === undefined) { t.parts[d.i] = String(d.part || ""); t.got++; }
        if (t.got < t.n) return;
        delete PARTS[d.tx];
        var name = String(d.name || "player").replace(/[^A-Za-z0-9_]/g, "_"), file = "dbrdebug/" + name + ".json";
        try {
            RPG.files.writeLocal(file, JSON.parse(t.parts.join("")));
            var dir = RPG.files.localPath(file);
            RPG.chat([{ text: "[DBR-Debug] ", color: "#FFFF55" }, { text: "Debug file for " + d.name + " created at: " },
                { text: dir, color: "#55FFFF", underline: true, hover: "Click to open folder", suggest: dir }]);
        } catch (e) {
            RPG.chat("&e[DBR-Debug]&r Failed to create debug file: " + e);
        }
    });
})();
