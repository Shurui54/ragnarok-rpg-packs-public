// =====================================================================================
//  46_dmz_kishare.js - DragonMine Z's Ki sharing and God ritual on this computer
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0) client/systems/kishare/{KiShareInput, KiSharePose, KiShareVisuals} and
//  client/render/effects/GodRitualShellEffect. Server side: scripts/64_dmz_kishare.js.
//   - Ctrl + Alt + right click (held) looking at a player within 8 blocks shares your ki with them; let go to stop.
//   - Givers hold both hands out to the receiver; ki streams from their hands into the receiver's chest.
//   - Ritual givers face the vessel and join hands with their neighbours (two or fewer reach for the vessel); ki runs
//     round the ring, its colour turning from their aura to the god form's as the vessel's channel fills.
//   - The vessel glows in a white shell (the ritual's shell colour) as it becomes a Super Saiyan God.
// =====================================================================================
(function () {
    var RETRY = 10, STOP_RESEND = 10, START_RANGE = 8;
    var requested = false, retry = 0, stopCd = 0;
    var GOD_AURA = "#FF5A36", TRAIL = "dmzpack:textures/particle/ki_trail0.png";
    var SHOULDER_H = 22 / 16, SHOULDER_SIDE = 5 / 16, HAND_REACH = 9 / 16, RING_DROOP = 0.35, CHEST = 0.6;

    function chord() { return RPG.isKeyDown("key.keyboard.left.control") && RPG.isKeyDown("key.keyboard.left.alt"); }
    function cfg(k, d) { try { var v = RPG.config.get("dbr_rituals", k, d); return v === undefined || v === null ? d : v; } catch (e) { return d; } }
    /** KiShareInput.pickTarget: the player nearest your crosshair line within 8 blocks. */
    function pickTarget() {
        var me = RPG.player, eye = { x: me.x, y: me.eyeY, z: me.z }, look = me.look, best = null, bd = 1e9;
        RPG.avatar.players().forEach(function (pl) {
            if (pl.local || pl.spectator || pl.dead) return;
            var cx = pl.x - eye.x, cy = pl.y + 1 - eye.y, cz = pl.z - eye.z, along = cx * look.x + cy * look.y + cz * look.z;
            if (along <= 0 || along > START_RANGE + 1) return;
            var px = cx - look.x * along, py = cy - look.y * along, pz = cz - look.z * along, off = Math.sqrt(px * px + py * py + pz * pz);
            if (off > 1.2 || off >= bd) return;
            bd = off; best = pl;
        });
        return best;
    }
    RPG.every(1, function () {
        if (!RPG.player.present) { requested = false; return; }
        var holding = chord() && RPG.isKeyDown("key.mouse.right");
        if (stopCd > 0) stopCd--;
        var me = RPG.avatar.players().filter(function (pl) { return pl.local; })[0], sharing = !!(me && me.shared("kiShare", 0));
        if (!holding) {
            if ((requested || sharing) && stopCd === 0) { RPG.net.send("dmz_kishare", { op: "stop" }); stopCd = STOP_RESEND; }
            requested = false; retry = 0;
            return;
        }
        stopCd = 0;
        if (sharing) return;
        if (retry > 0) { retry--; return; }
        var t = pickTarget();
        if (!t) return;
        RPG.net.send("dmz_kishare", { op: "start", target: t.id });
        requested = true; retry = RETRY;
    });

    // ---- KiSharePose ----------------------------------------------------------------------------
    function rad(d) { return d * Math.PI / 180; }
    function rightOf(pl) { var y = rad(pl.bodyYaw); return { x: -Math.cos(y), z: -Math.sin(y) }; }
    function fwdOf(pl) { var y = rad(pl.bodyYaw); return { x: -Math.sin(y), z: Math.cos(y) }; }
    function shoulder(pl, right) {
        var r = rightOf(pl), s = (right ? 1 : -1) * SHOULDER_SIDE * pl.modelSize;
        return { x: pl.x + r.x * s, y: pl.y + SHOULDER_H * pl.modelSize, z: pl.z + r.z * s };
    }
    function hand(pl, right, target) {
        var sh = shoulder(pl, right), dx = target.x - sh.x, dy = target.y - sh.y, dz = target.z - sh.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1e-3) return sh;
        var k = HAND_REACH * pl.modelSize / l;
        return { x: sh.x + dx * k, y: sh.y + dy * k, z: sh.z + dz * k };
    }
    function chest(pl) { return { x: pl.x, y: pl.y + 1.8 * pl.modelSize * CHEST, z: pl.z }; }
    function meeting(a, b) { return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 + SHOULDER_H * a.modelSize - RING_DROOP, z: (a.z + b.z) / 2 }; }
    function byId(id) { return id ? RPG.avatar.player(Number(id)) : null; }
    function ritualOf(pl) { var g = pl.shared("godRitual", null); return g && typeof g === "object" ? g : null; }
    /** KiSharePose.ring: the vessel and every giver round it, sorted by angle. */
    function ring(pl) {
        var g = ritualOf(pl), center = g ? byId(g.anchor) : null;
        if (!g) return null;
        var donors = RPG.avatar.players().filter(function (o) { var og = ritualOf(o); return og && og.role === 1 && og.anchor === g.anchor; });
        var c = center || donors[0];
        if (!c) return null;
        donors.sort(function (a, b) { return Math.atan2(a.z - c.z, a.x - c.x) - Math.atan2(b.z - c.z, b.x - c.x); });
        return { center: center, donors: donors };
    }
    /** KiSharePose.resolve: where each hand reaches, or null. */
    function aim(pl) {
        var g = ritualOf(pl);
        if (g && g.role === 1) {
            var r = ring(pl);
            if (!r) return null;
            var i = r.donors.indexOf(pl);
            if (i < 0) return null;
            if (r.donors.length < 3) { if (!r.center) return null; var c = chest(r.center); return { right: c, left: c }; }
            var prev = r.donors[(i - 1 + r.donors.length) % r.donors.length], next = r.donors[(i + 1) % r.donors.length];
            var tp = meeting(pl, prev), tn = meeting(pl, next), rr = rightOf(pl);
            var ps = (tp.x - pl.x) * rr.x + (tp.z - pl.z) * rr.z, ns = (tn.x - pl.x) * rr.x + (tn.z - pl.z) * rr.z;
            return ps >= ns ? { right: tp, left: tn } : { right: tn, left: tp };
        }
        var recv = byId(pl.shared("kiShare", 0));
        if (!recv) return null;
        var t = chest(recv);
        return { right: clampFront(pl, true, t), left: clampFront(pl, false, t) };
    }
    function clampFront(pl, right, t) {
        var sh = shoulder(pl, right), dx = t.x - sh.x, dz = t.z - sh.z, h = Math.sqrt(dx * dx + dz * dz);
        if (h < 1e-4) return t;
        var f = fwdOf(pl), r = rightOf(pl), fw = (dx * f.x + dz * f.z) / h, sd = (dx * r.x + dz * r.z) / h, ang = Math.atan2(sd, fw), max = rad(100);
        if (Math.abs(ang) <= max) return t;
        var cl = ang < 0 ? -max : max, nx = f.x * Math.cos(cl) + r.x * Math.sin(cl), nz = f.z * Math.cos(cl) + r.z * Math.sin(cl);
        return { x: sh.x + nx * h, y: t.y, z: sh.z + nz * h };
    }
    /** aimBone: the arm points from its shoulder at the target. */
    function armEdit(pl, right, t) {
        var sh = shoulder(pl, right), dx = t.x - sh.x, dy = t.y - sh.y, dz = t.z - sh.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1e-3) return null;
        dx /= l; dy /= l; dz /= l;
        var f = fwdOf(pl), r = rightOf(pl), fw = dx * f.x + dz * f.z, sd = dx * r.x + dz * r.z;
        var rx = Math.asin(Math.max(-1, Math.min(1, fw))), rz = Math.atan2(sd, -dy);
        return { rx: rx * 180 / Math.PI, ry: 0, rz: rz * 180 / Math.PI, absolute: true };
    }
    if (typeof DBR_ANIMATOR !== "undefined") DBR_ANIMATOR.extend(function (pl, out) {
        if (!pl.shared("kiShare", 0) && !ritualOf(pl)) return;
        var g = ritualOf(pl);
        if (g && g.role === 2) { out.layers.ki = { anim: DBR_ANIMATOR.chargeAnimations[pl.race] || "base.ki_charge_saiyan", mode: "loop" }; return; }
        var a = aim(pl);
        if (!a) return;
        var re = armEdit(pl, true, a.right), le = armEdit(pl, false, a.left);
        if (re) out.bones.right_arm = re;
        if (le) out.bones.left_arm = le;
        out.layers.attack = null; out.layers.mining = null;
    });

    // ---- KiShareVisuals: streams and the ring's tracers (billboards re-placed every tick) ------------------
    var LIVE = {};
    function hex(c) { return typeof c === "number" ? "#" + ("000000" + c.toString(16)).slice(-6) : c; }
    function lerpHex(a, b, t) {
        var pa = parseInt(hex(a).substring(1), 16), pb = parseInt(hex(b).substring(1), 16), r = 0;
        for (var sh = 16; sh >= 0; sh -= 8) { var ca = (pa >> sh) & 255, cb = (pb >> sh) & 255; r |= Math.round(ca + (cb - ca) * t) << sh; }
        return "#" + ("000000" + r.toString(16)).slice(-6);
    }
    function dot(id, p, color, size) {
        LIVE[id] = 1;
        RPG.world3d.billboard(id, { x: p.x, y: p.y, z: p.z, size: size, texture: TRAIL, color: color, alpha: 0.9, blend: "additive", ticks: 3 });
    }
    function along(path, d) {
        var lens = [0], total = 0;
        for (var i = 1; i < path.length; i++) { var a = path[i - 1], b = path[i]; total += Math.sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y) + (a.z - b.z) * (a.z - b.z)); lens.push(total); }
        var want = total * d;
        for (var k = 1; k < path.length; k++) {
            if (want > lens[k] && k < path.length - 1) continue;
            var seg = lens[k] - lens[k - 1], f = seg > 1e-6 ? Math.max(0, Math.min(1, (want - lens[k - 1]) / seg)) : 0, p0 = path[k - 1], p1 = path[k];
            return { x: p0.x + (p1.x - p0.x) * f, y: p0.y + (p1.y - p0.y) * f, z: p0.z + (p1.z - p0.z) * f };
        }
        return path[path.length - 1];
    }
    function frac(x) { return x - Math.floor(x); }
    RPG.every(1, function () {
        var seen = {}, t = RPG.time();
        RPG.avatar.players().forEach(function (pl) {
            var g = ritualOf(pl), give = pl.shared("kiShare", 0);
            if (!give && !(g && g.role === 1)) return;
            var a = aim(pl);
            if (!a) return;
            var own = hex(pl.color("aura", 0x7FC8FF)), color = own, path, seed = pl.id;
            if (g && g.role === 1) {
                var r = ring(pl), center = r && r.center, cg = center ? ritualOf(center) : null;
                color = lerpHex(own, GOD_AURA, Math.max(0, Math.min(1, ((cg && cg.charge) || 0) / 100)));
                if (r && r.donors.length >= 3) {
                    var i = r.donors.indexOf(pl), next = r.donors[(i + 1) % r.donors.length], m = meeting(pl, next);
                    var rr = rightOf(pl), nr = rightOf(next), pr = (m.x - pl.x) * rr.x + (m.z - pl.z) * rr.z >= 0, nxr = (m.x - next.x) * nr.x + (m.z - next.z) * nr.z >= 0;
                    path = [shoulder(pl, pr), hand(pl, pr, m), hand(next, nxr, m), shoulder(next, nxr)];
                } else if (center) {
                    var c = chest(center);
                    path = [shoulder(pl, true), hand(pl, true, c), c];
                } else return;
                for (var k = 0; k < 3; k++) {          // TRACERS_PER_WAY, both ways (speeds 0.03 / 0.022 a tick)
                    var off = k / 3 + seed * 0.137;
                    dot("dkr_" + pl.id + "_f" + k, along(path, frac(t * 0.03 + off)), color, 0.32);
                    dot("dkr_" + pl.id + "_b" + k, along(path, 1 - frac(t * 0.022 + off + 0.5 / 3)), color, 0.32);
                    seen["dkr_" + pl.id + "_f" + k] = seen["dkr_" + pl.id + "_b" + k] = 1;
                }
                return;
            }
            var recv = byId(give);
            if (!recv) return;
            var to = chest(recv);
            [true, false].forEach(function (right) {           // emitStream: a steady flow from each hand
                var from = hand(pl, right, right ? a.right : a.left);
                for (var k2 = 0; k2 < 4; k2++) {
                    var id = "dks_" + pl.id + (right ? "r" : "l") + k2, f = frac(t / 9.6 + k2 / 4 + (right ? 0.125 : 0));
                    dot(id, { x: from.x + (to.x - from.x) * f, y: from.y + (to.y - from.y) * f, z: from.z + (to.z - from.z) * f }, color, 0.3);
                    seen[id] = 1;
                }
            });
        });
        Object.keys(LIVE).forEach(function (id) { if (!seen[id]) { RPG.world3d.remove(id); delete LIVE[id]; } });
    });

    // ---- GodRitualShellEffect: the vessel drawn white in the shell colour, fading in then out --------------
    var SHELLS = {};
    RPG.net.on("dmz_god_shell", function (d) {
        if (!d) return;
        if (d.off) { delete SHELLS[d.id]; RPG.avatar.clearOutline(Number(d.id)); return; }
        SHELLS[d.id] = { start: RPG.time(), inT: d.inTicks || 20, outT: d.outTicks || 30, color: d.color || cfg("godRitual.shellColor", "#6FD8FF") };
    });
    RPG.every(1, function () {
        Object.keys(SHELLS).forEach(function (id) {
            var s = SHELLS[id], e = RPG.time() - s.start, a;
            if (e < s.inT) a = e / s.inT;
            else { var o = (e - s.inT) / s.outT; if (o >= 1) { delete SHELLS[id]; RPG.avatar.clearOutline(Number(id)); return; } var f = 1 - o; a = f * f * (3 - 2 * f); }
            RPG.avatar.setOutline(Number(id), { color: "#FFFFFF", color2: s.color, mode: "solid", thickness: 0.6, glow: a, bodyGlow: a, alpha: a });
        });
    });
})();
