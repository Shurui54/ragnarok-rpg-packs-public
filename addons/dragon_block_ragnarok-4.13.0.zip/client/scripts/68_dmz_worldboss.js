// =====================================================================================
//  DMZ world bosses on the client (server: scripts/77_dmz_world_bosses*.js). Ports of DragonMine Z (GPL-3.0):
//   - client/gui/hud/WorldBossContributionHUD: the 150 px panel (HudRender.panel, boss name FFD54F, fight clock
//     B8C0CC), up to 8 rows ([rank] name - local FFE066, knocked out FF7A7A "(KO)" - share / points alternating every
//     10 s, the aura-coloured bar), rows sliding in and moving smoothly; lingers 15 s after the fight. Movable.
//   - client/gui/hud/WorldBossReviveOverlay: "Reviving <name>" + percent over the green kicharge_hud bar.
//   - client/gui/worldboss/WorldBossResultsScreen: the contribution ranking with segmented bars, the selected
//     player's reward chances, tooltips, scrollbars (ScrollbarState), the Close button.
//   - client/systems/worldboss/ClientWorldBossState, RaidMusicManager (boss music once at 0.5, victory sting),
//     server titles / chat lines in DMZ's language, client/render/effects/TelegraphEffect (ground warnings and
//     lanes), ShockwaveVfx, the Kill Driver ring, the Tamagami hammer and pillars, Gete cables / reassembly, the
//     Supernova / Great Sphere and the boss lasers ("dmz_wb_fx").
// =====================================================================================
var DMZ_WB_CLIENT = (function () {
    var U = DMZ_UI, FONT = "dmzpack:smooth";
    var STATE = {};                                     // key -> {known, x, y, z, alive, respawn}

    // ---- text: lang keys with DMZ's arguments (strings, numbers, nested keys, key binds, meters, lists) ----
    function arg(a) {
        if (a === null || a === undefined) return "";
        if (typeof a !== "object") return String(a);
        if (a.keybind) return RPG.hasTranslation(a.keybind) ? RPG.translate(a.keybind) : a.keybind;
        if (a.meter !== undefined) return "§a" + rep("|", a.meter) + "§8" + rep("|", Math.max(0, a.of - a.meter)) + "§r";
        if (a.list) return a.list.map(function (x) { return "§e" + arg(x) + "§r"; }).join(", ");
        if (a.skill) return skillName(a.skill);
        if (a.text) return a.text;
        if (a.key) {
            if (!RPG.hasTranslation(a.key)) return a.fallback || a.key;
            var s = tr.apply(null, [a.key].concat(a.args || []));
            return a.pending ? s + "§8" + tr("command.dragonminez.worldboss.status.lair_pending") : s;
        }
        return "";
    }
    function rep(c, n) { var s = ""; for (var i = 0; i < n; i++) s += c; return s; }
    function tr(key) {
        var args = Array.prototype.slice.call(arguments, 1).map(arg), i = 0;
        var s = RPG.hasTranslation(key) ? String(RPG.translate(key)) : key;
        s = s.replace(/%(\d+)\$s/g, function (m, n) { var v = args[Number(n) - 1]; return v === undefined ? "" : v; });
        return s.replace(/%s|%d/g, function () { var v = args[i++]; return v === undefined ? "" : v; }).replace(/%%/g, "%");
    }
    function skillName(id) {
        var keys = ["technique.dragonminez." + id, "skill.dragonminez." + id];
        for (var i = 0; i < keys.length; i++) if (RPG.hasTranslation(keys[i])) return RPG.translate(keys[i]);
        return typeof DMZ_TECH_DATA !== "undefined" ? DMZ_TECH_DATA.english(id) : U.humanize(id);
    }
    function legacy(color) {                            // ChatFormatting colours the server names
        var map = { "#FF5555": "§c", "#AAAAAA": "§7", "#FFAA00": "§6", "#FFFF55": "§e", "#55FF55": "§a", "#AA0000": "§4", "#55FFFF": "§b", "#AA00AA": "§5", "#FF55FF": "§d", "#FFFFFF": "§f" };
        return map[String(color || "").toUpperCase()] || "";
    }
    function line(o) { return o ? legacy(o.color) + (o.bold ? "§l" : "") + arg(o) : ""; }
    function fmtDec(v, places, grouping) {
        var f = Math.pow(10, places), r = Math.round(Math.abs(v) * f) / f, ip = Math.floor(r), fp = Math.round((r - ip) * f);
        var s = (grouping ? String(ip).replace(/\B(?=(\d{3})+(?!\d))/g, ",") : String(ip)) + (fp > 0 ? "." + String(fp + f).substring(1).replace(/0+$/, "") : "");
        return (v < 0 && r > 0 ? "-" : "") + s;
    }
    function oneDecimal(v) { return fmtDec(v, 1, true); }
    function large(n) {
        n = Number(n) || 0;
        if (n <= 999) return fmtDec(n, 2, true);
        var suf = ["K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc"], i = suf.length - 1;
        while (i > 0 && n < Math.pow(10, 3 * (i + 1))) i--;
        return fmtDec(n / Math.pow(10, 3 * (i + 1)), 2, false) + suf[i];
    }
    function hexOf(n) { return "#" + ("000000" + ((n >>> 0) & 0xFFFFFF).toString(16)).slice(-6).toUpperCase(); }

    // ---- server messages ----
    RPG.net.on("dmz_wb_state", function (d) { if (d) STATE = d; });
    RPG.net.on("dmz_wb_title", function (d) {
        if (!d) return;
        if (d.clear) { RPG.title("", "", 0, 1, 0); return; }
        RPG.title(line(d.title), line(d.sub), d.fadeIn || 10, d.stay || 70, d.fadeOut || 10);
    });
    RPG.net.on("dmz_wb_chat", function (d) {
        if (!d) return;
        var parts = [{ text: legacy(d.color) + tr.apply(null, [d.key].concat(d.args || [])), suggest: d.suggest || undefined, hover: d.suggest ? tr("command.dragonminez.worldboss.click_tp") : undefined }];
        if (d.more) parts.push({ text: " " }, { text: tr(d.more.key), color: d.more.color, underline: true, command: d.more.command, hover: tr(d.more.hover) });
        RPG.chat(parts);
    });
    // RaidMusicManager: the boss theme, played once (not looped) at 0.5; the victory sting the same way
    RPG.net.on("dmz_wb_music", function (d) { RPG.music(d && d.id ? d.id : "", 0.5, false); });
    RPG.net.on("dmz_wb_results", function (d) { if (d) openResults(d); });

    // =========================================================================================
    //  contribution HUD (WorldBossContributionHUD)
    // =========================================================================================
    var MAX_ROWS = 8, W = 150, HEADER = 14, ROW = 15, HEIGHT = HEADER + MAX_ROWS * ROW, TEXT = 0.75, BAR_H = 4, PAD = 4;
    var C = null, CAT = 0, VIEWS = {}, PANEL_A = 0, PANEL_ROWS = 1;
    var PREVIEW = [{ id: "p1", name: "Goku", points: 12600000, share: 0.46, aura: 0x4FC3FF }, { id: "p2", name: "Vegeta", points: 8100000, share: 0.29, aura: 0xFFD54F },
        { id: "p3", name: "Piccolo", points: 4400000, share: 0.16, aura: 0x7CFDD6, ko: true }, { id: "p4", name: "Krillin", points: 2500000, share: 0.09, aura: 0xFF8A65 }];
    RPG.net.on("dmz_wb_contrib", function (d) {
        if (!d) return;
        if (d.cleared) { C = d; C.finished = true; CAT = RPG.nowMs(); return; }
        C = d; CAT = RPG.nowMs();
    });
    function smooth(cur, target, rate, snap) { var v = cur + (target - cur) * rate; return Math.abs(target - v) < snap ? target : v; }
    function lingerMs() { return Math.max(0, (C && C.linger !== undefined ? C.linger : 15)) * 1000; }
    function active() {
        if (!C) return false;
        if (!C.finished) return RPG.nowMs() - CAT < 5000 || true;
        return RPG.nowMs() - CAT < lingerMs();
    }
    function mix(a, b, t) {
        var ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
        return (Math.round(ar + (br - ar) * t) << 16) | (Math.round(ag + (bg - ag) * t) << 8) | Math.round(ab + (bb - ab) * t);
    }
    function dmzText(ctx, t, x, y, color, align, a) { if (a * 255 > 3 && t) ctx.textStyled(t, x, y, TEXT, color, a, align, FONT, "#000000"); }
    function drawContribution(ctx) {
        var editing = ctx.isEditing(), on = active();
        PANEL_A = editing ? 1 : smooth(PANEL_A, on ? 1 : 0, 0.18, 0.005);
        if (PANEL_A <= 0.01 && !on && !editing) { VIEWS = {}; if (C && C.finished && RPG.nowMs() - CAT > lingerMs()) C = null; return; }
        var sc = 0.8, bx = ctx.width - 6 - W * sc, by = ctx.height / 2 - HEIGHT * sc / 2;      // HudPlacement(1, 0.5, -6, 0, 0.8)
        if (!ctx.group("dmz_wb_contribution", tr("gui.dragonminez.hud_editor.element.boss_contribution") === "gui.dragonminez.hud_editor.element.boss_contribution" ? "Boss Contribution" : tr("gui.dragonminez.hud_editor.element.boss_contribution"), bx, by, W * sc, HEIGHT * sc)) return;
        var alpha = PANEL_A;
        if (!editing && C && C.finished) alpha *= 1 - Math.max(0, Math.min(1, ((RPG.nowMs() - CAT) / Math.max(1, lingerMs()) - 0.85) / 0.15));
        var entries = (editing && (!C || !C.entries.length)) ? PREVIEW : (C ? C.entries : []);
        var me = String(RPG.player.uuid || ""), myName = RPG.player.name;
        function isMe(e) { return e.id === me || e.name === myName; }
        var visible = entries.slice(0, MAX_ROWS), li = -1;
        entries.forEach(function (e, i) { if (isMe(e)) li = i; });
        if (li >= MAX_ROWS && visible.length) visible[visible.length - 1] = entries[li];
        var best = entries.length ? Math.max(1e-6, entries[0].points) : 1, pct = Math.floor(Date.now() / 10000) % 2 === 0;
        Object.keys(VIEWS).forEach(function (k) { VIEWS[k].present = false; });
        visible.forEach(function (e, slot) {
            var v = VIEWS[e.id] || (VIEWS[e.id] = { slot: -1, appear: 0, fill: 0 });
            if (v.slot < 0 || v.appear <= 0.01) { v.slot = slot; v.fill = e.points / best; }
            if (editing) v.appear = 1;
            v.present = true; v.e = e; v.target = slot; v.rank = entries.indexOf(e) + 1;
        });
        PANEL_ROWS = editing ? MAX_ROWS : smooth(PANEL_ROWS, Math.max(1, visible.length), 0.16, 0.01);
        var ph = HEADER + PANEL_ROWS * ROW + 2, shift = (HEIGHT - ph) * 0.5;
        ctx.push();
        ctx.translate(bx, by);
        ctx.scale(sc, sc);
        ctx.translate(0, shift);
        // HudRender.panel: 141B25 at 0.78, 070A0F frame at 0.92
        ctx.fill(1, 1, W - 2, ph - 2, "#141B25", 0.78 * alpha);
        ctx.fill(0, 0, W, 1, "#070A0F", 0.92 * alpha); ctx.fill(0, ph - 1, W, 1, "#070A0F", 0.92 * alpha);
        ctx.fill(0, 1, 1, ph - 2, "#070A0F", 0.92 * alpha); ctx.fill(W - 1, 1, 1, ph - 2, "#070A0F", 0.92 * alpha);
        ctx.fill(PAD, HEADER - 2, W - PAD * 2, 1, "#000000", 0.35 * alpha);
        var bossName = C && C.nameKey ? (RPG.hasTranslation(C.nameKey) ? RPG.translate(C.nameKey) : C.name) : tr("gui.dragonminez.hud_editor.sample.boss_name");
        dmzText(ctx, bossName, PAD, 3, "#FFD54F", 0, alpha);
        var el = C && !editing ? C.elapsed + (C.finished ? 0 : (RPG.nowMs() - CAT) / 50) : 20 * 330, sec = Math.max(0, Math.floor(el / 20));
        dmzText(ctx, Math.floor(sec / 60) + ":" + (sec % 60 < 10 ? "0" : "") + (sec % 60), W - PAD, 3, "#B8C0CC", 1, alpha);
        Object.keys(VIEWS).forEach(function (k) {
            var v = VIEWS[k];
            v.appear = smooth(v.appear, v.present ? 1 : 0, 0.14, 0.01);
            if (!v.present && (v.appear <= 0.01 || editing)) { delete VIEWS[k]; return; }
            v.slot = smooth(v.slot, v.target, 0.12, 0.01);
            v.fill = smooth(v.fill, v.e.points / best, 0.2, 0.001);
            var e = v.e, y = HEADER + v.slot * ROW, a = alpha * v.appear, slide = (1 - v.appear) * 24;
            ctx.push(); ctx.translate(-slide, y);
            var rl = "[" + v.rank + "]";
            dmzText(ctx, rl, PAD, 1, "#B8C0CC", 0, a);
            var rw = ctx.textWidthIn(rl, FONT) * TEXT;
            dmzText(ctx, e.ko ? e.name + " " + tr("gui.dragonminez.worldboss.contribution.knocked_out") : e.name, PAD + rw + 3, 1, e.ko ? "#FF7A7A" : isMe(e) ? "#FFE066" : "#FFFFFF", 0, a);
            dmzText(ctx, pct ? Math.round(e.share * 100) + "%" : large(e.points), W - PAD, 1, "#E8ECF2", 1, a);
            var barY = ROW - BAR_H - 2, bw = W - PAD * 2, fw = bw * Math.max(0, Math.min(1, v.fill));
            ctx.fill(PAD, barY, bw, BAR_H, "#000000", 0.5 * a);
            var col = e.ko ? mix(e.aura, 0x555555, 0.6) : e.aura;
            ctx.gradient ? 0 : 0;
            var steps = 8;
            for (var i = 0; i < steps; i++) ctx.fill(PAD + fw * i / steps, barY, fw / steps + 0.01, BAR_H, hexOf(mix(mix(col, 0, 0.25), col, (i + 0.5) / steps)), 0.95 * a);
            if (fw > 1.5) ctx.fill(PAD + fw - 1, barY, 1, BAR_H, "#FFFFFF", 0.7 * a);
            ctx.pop();
        });
        ctx.pop();
        ctx.endGroup();
    }

    // =========================================================================================
    //  revive overlay (WorldBossReviveOverlay) and the player's fight state (WorldBossPlayerStateS2C)
    // =========================================================================================
    var PS = { active: false }, REV_A = 0, REV_P = 0;
    RPG.net.on("dmz_wb_player", function (d) { PS = d || { active: false }; });
    function drawRevive(ctx) {
        var casting = !!(PS.active && PS.casting);
        REV_A = smooth(REV_A, casting ? 1 : 0, 0.1, 0.01);
        if (REV_A <= 0.01) { if (!casting) REV_P = 0; return; }
        REV_P = smooth(REV_P, casting ? Math.max(0, Math.min(1, PS.progress || 0)) : REV_P, 0.12, 0.002);
        var tex = "dmzpack:textures/gui/hud/kicharge_hud.png", s = 1.125, bw = 145 * s, x = (ctx.width - bw) / 2, y = ctx.height - 72;
        ctx.quad(tex, x, y, 145 * s, 14 * s, 0, 0, 145 / 256, 14 / 256, "#FFFFFF", REV_A);
        ctx.quad(tex, x, y, 148 * s * REV_P, 14 * s, 0, 14 / 256, (148 * REV_P) / 256, 28 / 256, "#5BD64A", REV_A);
        var py = Math.round(y) - 4 - 9;
        ctx.textStyled(Math.round(REV_P * 100) + "%", ctx.width / 2, py, 1, "#B9FFA8", REV_A, 0.5, FONT, null);
        ctx.textStyled(tr("gui.dragonminez.worldboss.revive.casting", PS.target || ""), ctx.width / 2, py - 2 - 9, 1, "#B9FFA8", REV_A, 0.5, FONT, null);
    }

    // =========================================================================================
    //  results screen (WorldBossResultsScreen)
    // =========================================================================================
    var sg = U.seg;
    var SMALL_PANEL = U.Skin("dmzpack:textures/gui/menu/menusmall.png", 256, 256, 0, 0,
        [sg.fixed(14), sg.tile(63), sg.decor(28, 0), sg.tile(21), sg.fixed(15)],
        [sg.fixed(14), sg.band(21), sg.fixed(7), sg.decor(28, 0), sg.tile(7), sg.fixed(17)]);
    var PW = 340, PH = 216, P = 12, DIV = 186, LIST_TOP = 44, LIST_H = 138, RH = 24, BADGE_W = 34, BADGE_H = 12, BAR_MAX = 96, BAR_HH = 7;
    var REW_H = PH - P - 20 - 6 - LIST_TOP, LH = 10;
    var COL = { title: "#FFD54F", dur: "#FF6B6B", name: "#FFE066", text: "#E8ECF2", muted: "#9FB8AE", recv: "#7CFDD6", dmg: "#E53935", mit: "#3F8CFF", rdmg: "#FF8F2B", heal: "#5BD64A" };
    var RS = null;
    // ScrollbarState: smooth (tau 0.08 s), 3 px bar, 333333 track, AAAAAA thumb (white while active), draggable
    function Bar(step) { return { step: step, scroll: 0, target: 0, max: 0, x: 0, y: 0, w: 0, h: 0, cross: 0, drag: false, grab: 0, last: 0 }; }
    function layout(b, x, y, w, h, content) {
        b.x = x; b.y = y; b.w = w; b.h = h; b.max = Math.max(0, content - h);
        var t = RPG.nowMs(), dt = b.last ? Math.min(0.1, (t - b.last) / 1000) : 0;
        b.last = t;
        b.target = Math.max(0, Math.min(b.max, b.target));
        if (b.drag || dt === 0) b.scroll = b.target; else b.scroll += (b.target - b.scroll) * (1 - Math.exp(-dt / 0.08));
        if (Math.abs(b.scroll - b.target) < 0.05) b.scroll = b.target;
    }
    function thumb(b) { if (b.max <= 0) return { s: b.y, l: b.h }; var l = Math.max(Math.min(14, b.h), b.h * b.h / (b.h + b.max)); return { s: b.y + (b.h - l) * (b.scroll / b.max), l: l }; }
    function drawBar(ctx, b, mx, my) {
        if (b.max <= 0) return;
        var th = thumb(b), over = mx >= b.cross - 4 && mx <= b.cross + 7 && my >= b.y && my <= b.y + b.h;
        ctx.fill(b.cross, b.y, 3, b.h, "#333333", 1);
        ctx.fill(b.cross, th.s, 3, th.l, b.drag || over ? "#FFFFFF" : "#AAAAAA", 1);
    }
    function overTrack(b, mx, my) { return b.max > 0 && mx >= b.cross - 4 && mx <= b.cross + 7 && my >= b.y && my <= b.y + b.h; }
    function scrollFor(b, my) { var th = thumb(b), travel = b.h - th.l; return travel <= 0 ? 0 : Math.max(0, Math.min(1, (my - b.grab - b.y) / travel)) * b.max; }
    function rankLabel(r) {
        return r === 0 ? tr("gui.dragonminez.worldboss.results.rank.mvp") : r === 1 ? tr("gui.dragonminez.worldboss.results.rank.second")
            : r === 2 ? tr("gui.dragonminez.worldboss.results.rank.third") : tr("gui.dragonminez.worldboss.results.rank.nth", r + 1);
    }
    function sum(a) { var t = 0; (a || []).forEach(function (v) { t += v; }); return t; }
    function recvTotal(e) { var t = 0; (e.recv || []).forEach(function (r) { t += r.amount; }); return t; }
    function durationText(t) {                              // QuestTextFormatter.formatGameTimeDuration
        if (t <= 0) return "0s";
        var s = Math.max(1, Math.floor(t / 20)), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
        if (h > 0) return m > 0 ? h + "h " + m + "m" : h + "h";
        if (m > 0) return r > 0 ? m + "m " + r + "s" : m + "m";
        return r + "s";
    }
    function rewardName(r) {                               // WorldBossRewardText.name
        if (r.type === "ITEM") return r.itemName || r.item;
        if (r.type === "ATTRIBUTES") return tr("worldboss.dragonminez.results.attributes", r.amount);
        if (r.type === "SKILL") return skillName(r.skill);
        return r.type;
    }
    function rewardDescribe(r, amount) {                   // WorldBossRewardText.describe
        if (r.type === "ITEM") return tr("worldboss.dragonminez.results.item", Math.max(1, Math.round(amount)), r.itemName || r.item);
        if (r.type === "ATTRIBUTES" && amount > 0) return tr("worldboss.dragonminez.results.attributes", Math.round(amount));
        return rewardName(r);
    }
    function rewardTooltip(r) {                            // QuestReward.getDescription
        if (r.type === "ITEM") return tr("gui.dragonminez.quests.rewards.item", r.count || 1, r.itemName || r.item);
        if (r.type === "ATTRIBUTES") return tr("gui.dragonminez.quests.rewards.attributes", r.amount);
        if (r.type === "SKILL") return tr("gui.dragonminez.quests.rewards.skill", skillName(r.skill), r.level || 1);
        return r.type;
    }
    function rewardIcon(r) { return r.type === "ITEM" ? r.item : r.type === "SKILL" ? "gete_blue_capsule" : null; }
    function percent(c) { return oneDecimal(c * 100) + "%"; }
    function openResults(d) {
        var me = String(RPG.player.uuid || ""), shown = (d.players || []).slice(0, 10), sel = null;
        (d.players || []).forEach(function (e) { if (e.id === me || e.name === RPG.player.name) sel = e.id; });
        if (!sel && shown.length) sel = shown[0].id;
        RS = { d: d, shown: shown, sel: sel, list: Bar(RH), rew: Bar(24), rows: [], segs: [], rewHits: [], layoutKey: null, blocks: [], header: [], content: 0 };
        RPG.screen.open({ id: "dmz_wb_results", referenceHeight: DMZ_OPTS.menuRef(), background: "dim", closeOnEsc: true, elements: [],
            onRender: renderResults, onMouse: mouseResults, onScroll: scrollResults, onClose: function () { RS = null; } });
    }
    function find(id) { return (RS.d.players || []).filter(function (e) { return e.id === id; })[0] || null; }
    function renderResults(ctx) {
        if (!RS) return;
        var d = RS.d, gx = Math.floor((ctx.width - PW) / 2), gy = Math.floor((ctx.height - PH) / 2), mx = ctx.mouseX, my = ctx.mouseY;
        RS.gx = gx; RS.gy = gy; RS.rows = []; RS.segs = []; RS.rewHits = [];
        SMALL_PANEL.draw(ctx, gx, gy, PW, PH);
        var bossName = RPG.hasTranslation(d.nameKey) ? RPG.translate(d.nameKey) : d.name;
        U.bordered(ctx, tr("gui.dragonminez.worldboss.results.title", bossName), gx + PW / 2, gy + 10, COL.title, 0.5);
        U.bordered(ctx, durationText(d.duration), gx + PW - P, gy + 10, COL.dur, 1);
        // contribution
        var left = gx + P, width = DIV - P * 2, top = gy + LIST_TOP;
        U.bordered(ctx, tr("gui.dragonminez.worldboss.results.contribution"), left, gy + 30, COL.title);
        layout(RS.list, left, top, width, LIST_H, RS.shown.length * RH);
        RS.list.cross = left + width + 3;
        var best = RS.shown.length ? Math.max(1e-6, RS.shown[0].points) : 1, inList = mx >= left && mx < left + width && my >= top && my < top + LIST_H;
        ctx.clip(left - 1, top - 1, width + 2, LIST_H + 1);
        RS.shown.forEach(function (e, i) {
            var rowY = top + i * RH - RS.list.scroll;
            if (rowY + RH < top || rowY > top + LIST_H) return;
            var selRow = e.id === RS.sel, hov = inList && my >= rowY && my < rowY + RH;
            if (selRow || hov) ctx.fill(left - 2, rowY, width + 4, RH - 1, "#FFFFFF", selRow ? 0x30 / 255 : 0x1C / 255);
            var by2 = rowY + 2;
            ctx.fill(left, by2, BADGE_W, BADGE_H, "#101018", 0xAA / 255);
            ctx.fill(left, by2, BADGE_W, 1, "#D9DEE6", 1); ctx.fill(left, by2 + BADGE_H - 1, BADGE_W, 1, "#D9DEE6", 1);
            ctx.fill(left, by2, 1, BADGE_H, "#D9DEE6", 1); ctx.fill(left + BADGE_W - 1, by2, 1, BADGE_H, "#D9DEE6", 1);
            U.bordered(ctx, rankLabel(e.rank), left + BADGE_W / 2, by2 + 2, "#FFFFFF", 0.5);
            var nx = left + BADGE_W + 6, isMe = e.id === String(RPG.player.uuid || "") || e.name === RPG.player.name;
            U.bordered(ctx, e.name + (isMe ? " §7" + tr("gui.dragonminez.worldboss.results.you") : ""), nx, rowY + 1, COL.name);
            var barY = rowY + 13, bw = Math.max(2, Math.round(BAR_MAX * Math.max(0, Math.min(1, e.points / best))));
            ctx.fill(nx - 1, barY - 1, BAR_MAX + 2, BAR_HH + 2, "#000000", 0x66 / 255);
            var wsum = [sum(e.dmg), sum(e.mit), recvTotal(e), e.healVal || 0], tot = wsum[0] + wsum[1] + wsum[2] + wsum[3], cols = [COL.dmg, COL.mit, COL.rdmg, COL.heal], cur = nx;
            for (var s = 0; s < 4; s++) {
                if (tot <= 0 || wsum[s] <= 0) continue;
                var sw = bw * wsum[s] / tot;
                ctx.fill(cur, barY, sw, BAR_HH, cols[s], 1);
                RS.segs.push({ x: Math.round(cur), y: barY, w: Math.max(1, Math.round(sw)), h: BAR_HH, seg: s, e: e });
                cur += sw;
            }
            U.bordered(ctx, oneDecimal(e.share * 100) + "%", left + width, barY - 1, COL.text, 1);
            RS.rows.push({ x: left, y: rowY, w: width, h: RH, e: e });
        });
        ctx.unclip();
        drawBar(ctx, RS.list, mx, my);
        ctx.fill(gx + DIV, gy + 30, 1, PH - 44, "#FFFFFF", 0x99 / 255);
        renderRewards(ctx, gx, gy, mx, my);
        // Close (TexturedTextButton 74 x 20, characterbuttons 0,28 / 0,48)
        RS.close = { x: gx + PW - P - 74, y: gy + PH - P - 20 };
        U.button(ctx, tr("gui.dragonminez.worldboss.results.close"), RS.close.x, RS.close.y, true);
        tooltips(ctx, mx, my);
    }
    function renderRewards(ctx, gx, gy, mx, my) {
        var d = RS.d, left = gx + DIV + P, width = PW - DIV - P * 2, top = gy + LIST_TOP;
        U.bordered(ctx, tr("gui.dragonminez.worldboss.results.rewards"), left, gy + 30, COL.title);
        var key = RS.sel + "|" + width;
        if (RS.layoutKey !== key) {
            RS.layoutKey = key; RS.header = []; RS.blocks = [];
            var t = RS.sel ? find(RS.sel) : null, y = 0;
            if (t) {
                RS.header = U.wrap(ctx, tr("gui.dragonminez.worldboss.results.chances_for", t.name), width).concat(
                    U.wrap(ctx, tr("gui.dragonminez.worldboss.results.total_points", large(t.points), oneDecimal(t.share * 100)), width));
                y = RS.header.length * LH + 4;
            }
            (d.rewards || []).forEach(function (r, j) {
                var base = r.chance, ch = t && j < t.chances.length ? t.chances[j] : base, amt = t && j < t.amounts.length ? t.amounts[j] : 0, got = amt > 0;
                var name = got ? rewardDescribe(r, amt) : rewardName(r);
                var cl = base >= 1 ? tr("gui.dragonminez.worldboss.results.guaranteed") : Math.abs(ch - base) < 0.0005 ? percent(base) : "§m" + percent(base) + "§r" + (got ? "§b" : "§7") + " -> " + percent(ch);
                if (got) cl += " " + tr("gui.dragonminez.worldboss.results.received");
                var nl = U.wrap(ctx, name, width - 20), cls = U.wrap(ctx, cl, width - 20), h = Math.max(16, (nl.length + cls.length) * LH) + 4;
                RS.blocks.push({ j: j, r: r, nl: nl, cl: cls, got: got, y: y, h: h });
                y += h;
            });
            RS.content = y;
        }
        layout(RS.rew, left, top, width, REW_H, RS.content);
        RS.rew.cross = left + width + 2;
        var inList = mx >= left && mx < left + width && my >= top && my < top + REW_H;
        ctx.clip(left - 1, top - 1, width + 2, REW_H + 1);
        var hy = top - RS.rew.scroll;
        RS.header.forEach(function (l) { U.bordered(ctx, l, left, hy, COL.muted); hy += LH; });
        RS.blocks.forEach(function (b) {
            var by = top + b.y - RS.rew.scroll;
            if (by + b.h < top || by > top + REW_H) return;
            var icon = rewardIcon(b.r);
            if (icon) ctx.item(icon, left, by);
            else ctx.image("dmzpack:textures/gui/quest/reward_generic.png", left, by, 16, 16, 0, 0, 16, 16, 16, 16);
            var ly = by;
            b.nl.forEach(function (l) { U.bordered(ctx, l, left + 20, ly, b.got ? COL.recv : COL.text); ly += LH; });
            b.cl.forEach(function (l) { U.bordered(ctx, l, left + 20, ly, b.got ? COL.recv : COL.muted); ly += LH; });
            if (inList) RS.rewHits.push({ x: left, y: by, w: width, h: b.h - 2, r: b.r });
        });
        ctx.unclip();
        drawBar(ctx, RS.rew, mx, my);
    }
    function tooltips(ctx, mx, my) {
        var t = null, edge = "#FFFFFF";
        RS.segs.forEach(function (h) {
            if (t || mx < h.x || mx >= h.x + h.w || my < h.y || my >= h.y + h.h) return;
            var e = h.e, lines = [], add = function (key, v) { if (v > 0) lines.push([tr(key) + ": " + large(v), "#FFFFFF"]); };
            var titles = [["gui.dragonminez.worldboss.results.damage", COL.dmg], ["gui.dragonminez.worldboss.results.mitigated", COL.mit], ["gui.dragonminez.worldboss.results.received_damage", COL.rdmg], ["gui.dragonminez.worldboss.results.healed", COL.heal]];
            if (h.seg === 0) { add("gui.dragonminez.worldboss.results.damage.melee", e.dmg[0]); add("gui.dragonminez.worldboss.results.damage.strike", e.dmg[1]); add("gui.dragonminez.worldboss.results.damage.ki", e.dmg[2]); add("gui.dragonminez.worldboss.results.damage.other", e.dmg[3]); }
            if (h.seg === 1) { add("gui.dragonminez.worldboss.results.mitigated.defense", e.mit[0]); add("gui.dragonminez.worldboss.results.mitigated.block", e.mit[1]); add("gui.dragonminez.worldboss.results.mitigated.shield", e.mit[2]); }
            if (h.seg === 2) (e.recv || []).forEach(function (r) { if (r.amount > 0) lines.push([(r.key ? (RPG.hasTranslation(r.key) ? RPG.translate(r.key) : r.key) : tr("gui.dragonminez.worldboss.results.unknown_source")) + ": " + large(r.amount), "#FFFFFF"]); });
            if (h.seg === 3) { add("gui.dragonminez.worldboss.results.healed.self", e.heal[0]); add("gui.dragonminez.worldboss.results.healed.allies", e.heal[1]); }
            if (!lines.length) lines.push([tr("gui.dragonminez.worldboss.results.none"), "#AAAAAA"]);
            t = [[tr(titles[h.seg][0]), titles[h.seg][1]]].concat(lines);
        });
        RS.rewHits.forEach(function (h) {
            if (t || mx < h.x || mx >= h.x + h.w || my < h.y || my >= h.y + h.h) return;
            t = [[rewardName(h.r), "#FFFFFF"], [rewardTooltip(h.r), "#FFFFFF"]];
        });
        if (t) U.tooltip(ctx, t, mx, my, edge);
    }
    function mouseResults(x, y, button, action) {
        if (!RS) return;
        var bars = [RS.list, RS.rew];
        if (action === "up") { bars.forEach(function (b) { b.drag = false; }); return; }
        if (action === "drag") { bars.forEach(function (b) { if (b.drag) { b.target = scrollFor(b, y); b.scroll = b.target; } }); return; }
        if (button !== 0) return;
        if (RS.close && U.inside(x, y, RS.close.x, RS.close.y, 74, 20)) { RPG.uiSound("minecraft:ui.button.click", 1, 1); RPG.screen.close(); return; }
        for (var i = 0; i < bars.length; i++) {
            var b = bars[i];
            if (!overTrack(b, x, y)) continue;
            var th = thumb(b);
            b.grab = y >= th.s && y <= th.s + th.l ? y - th.s : th.l / 2;
            b.drag = true; b.target = scrollFor(b, y); b.scroll = b.target;
            return;
        }
        var top = RS.gy + LIST_TOP;
        if (y < top || y > top + LIST_H) return;
        RS.rows.forEach(function (h) {
            if (x < h.x || x >= h.x + h.w || y < h.y || y >= h.y + h.h) return;
            RS.sel = h.e.id; RS.layoutKey = null; RS.rew.target = 0;
            RPG.uiSound("minecraft:ui.button.click", 1, 1);
        });
    }
    function scrollResults(x, y, delta) {
        if (!RS || !delta) return;
        var gx = RS.gx, gy = RS.gy;
        if (x < gx + DIV && x >= gx + P && RS.list.max > 0) { RS.list.target -= (delta > 0 ? 1 : -1) * RS.list.step; return; }
        if (x >= gx + DIV && x < gx + PW && y >= gy && y < gy + PH && RS.rew.max > 0) RS.rew.target -= (delta > 0 ? 1 : -1) * RS.rew.step;
    }

    // =========================================================================================
    //  world effects ("dmz_wb_fx")
    // =========================================================================================
    var FX = {}, SEG = 32, TICK = 0;
    function cam() { var p = RPG.player; return { x: p.x, y: p.eyeY !== undefined ? p.eyeY : p.y + 1.62, z: p.z }; }
    function hexNum(c) { return parseInt(String(c || "#FFFFFF").replace("#", ""), 16) || 0xFFFFFF; }
    function ring(tri, al, cx, cy, cz, inner, outer, ai, ao) {
        for (var i = 0; i < SEG; i++) {
            var a0 = Math.PI * 2 * i / SEG, a1 = Math.PI * 2 * (i + 1) / SEG, c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
            tri.push(cx + c0 * inner, cy, cz + s0 * inner, cx + c0 * outer, cy, cz + s0 * outer, cx + c1 * outer, cy, cz + s1 * outer);
            al.push(ai, ao, ao);
            tri.push(cx + c0 * inner, cy, cz + s0 * inner, cx + c1 * outer, cy, cz + s1 * outer, cx + c1 * inner, cy, cz + s1 * inner);
            al.push(ai, ao, ai);
        }
    }
    function drawMark(id, m) {                             // TelegraphEffect.drawMark
        var p = Math.max(0, Math.min(1, m.age / m.life)), pulse = 0.8 + 0.2 * Math.sin(p * 28), urg = 0.6 + 0.4 * p;
        var fr = m.follow >= 0 ? 0 : m.r * p, fill = 0.30 * pulse * urg, ra = 0.75 * pulse, th = 0.45, y = m.y + 0.06;
        var tri = [], al = [];
        if (fr > 0.05) ring(tri, al, m.x, y, m.z, 0, fr, fill, fill * 0.45);
        ring(tri, al, m.x, y, m.z, Math.max(0, m.r - th), m.r, ra, ra);
        ring(tri, al, m.x, y, m.z, m.r, m.r + th * 1.6, ra * 0.55, 0);
        RPG.world3d.mesh(id, { triangles: tri, alphas: al, color: m.c, alpha: 1, blend: "translucent" });
        if (fr > 0.05) {
            var t2 = [], a2 = [];
            ring(t2, a2, m.x, y + 0.005, m.z, Math.max(0, fr - th * 0.5), fr, ra * 0.8, ra * 0.8);
            RPG.world3d.mesh(id + "_f", { triangles: t2, alphas: a2, color: "#FFD9CC", alpha: 1 });
        }
    }
    function drawLane(id, l) {                              // TelegraphEffect.drawLane (camera-facing band, chevrons)
        var c = cam(), ax = l.b[0] - l.a[0], ay = l.b[1] - l.a[1], az = l.b[2] - l.a[2], len = Math.sqrt(ax * ax + ay * ay + az * az);
        if (len < 0.1) return;
        var dx = ax / len, dy = ay / len, dz = az / len, mx = l.a[0] + ax / 2 - c.x, my = l.a[1] + ay / 2 - c.y, mz = l.a[2] + az / 2 - c.z;
        var sx = dy * mz - dz * my, sy = dz * mx - dx * mz, sz = dx * my - dy * mx, sl = Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (sl < 1e-6) { sx = -dz; sy = 0; sz = dx; sl = Math.sqrt(sx * sx + sz * sz) || 1; }
        sx /= sl; sy /= sl; sz /= sl;
        var age = l.age, p = Math.max(0, Math.min(1, age / l.life)), pulse = 0.8 + 0.2 * Math.sin(age * 0.9), w = l.w;
        var fa = (l.locked ? 0.32 : 0.16) * pulse, ea = (l.locked ? 0.95 : 0.5) * pulse, edge = 0.18, tri = [], al = [];
        function band(from, to, fA, tA, t0, t1) {
            var x0 = l.a[0] + ax * t0, y0 = l.a[1] + ay * t0, z0 = l.a[2] + az * t0, x1 = l.a[0] + ax * t1, y1 = l.a[1] + ay * t1, z1 = l.a[2] + az * t1;
            tri.push(x0 + sx * from, y0 + sy * from, z0 + sz * from, x0 + sx * to, y0 + sy * to, z0 + sz * to, x1 + sx * to, y1 + sy * to, z1 + sz * to);
            al.push(fA, tA, tA);
            tri.push(x0 + sx * from, y0 + sy * from, z0 + sz * from, x1 + sx * to, y1 + sy * to, z1 + sz * to, x1 + sx * from, y1 + sy * from, z1 + sz * from);
            al.push(fA, tA, fA);
        }
        band(-w, -w * 0.15, fa * 0.35, fa, 0, 1); band(-w * 0.15, w * 0.15, fa, fa, 0, 1); band(w * 0.15, w, fa, fa * 0.35, 0, 1);
        band(-w - edge, -w, 0, ea, 0, 1); band(w, w + edge, ea, 0, 0, 1);
        var arm = w * 0.75, off = (age * 0.45 * (l.locked ? 2 : 1)) % 2.2, ca = (l.locked ? 0.9 : 0.45) * pulse;
        for (var d = off + arm; d < len - 0.2; d += 2.2) {
            var tx = l.a[0] + dx * d, ty = l.a[1] + dy * d, tz = l.a[2] + dz * d;
            [1, -1].forEach(function (sd) {
                var bx = tx - dx * arm + sx * arm * sd, by = ty - dy * arm + sy * arm * sd, bz = tz - dz * arm + sz * arm * sd, t = 0.14;
                tri.push(tx, ty, tz, bx, by, bz, bx - dx * t * 2, by - dy * t * 2, bz - dz * t * 2); al.push(ca, ca, ca);
                tri.push(tx, ty, tz, bx - dx * t * 2, by - dy * t * 2, bz - dz * t * 2, tx - dx * t * 2, ty - dy * t * 2, tz - dz * t * 2); al.push(ca, ca, ca);
            });
        }
        RPG.world3d.mesh(id, { triangles: tri, alphas: al, color: l.c, alpha: 1 });
        if (l.locked) {
            var core = w * 0.35, t3 = [], a3 = [], tt = Math.max(1 / 24, p), x1 = l.a[0] + ax * tt, y1 = l.a[1] + ay * tt, z1 = l.a[2] + az * tt, ca2 = ea * 0.55;
            t3.push(l.a[0] - sx * core, l.a[1] - sy * core, l.a[2] - sz * core, l.a[0] + sx * core, l.a[1] + sy * core, l.a[2] + sz * core, x1 + sx * core, y1 + sy * core, z1 + sz * core);
            t3.push(l.a[0] - sx * core, l.a[1] - sy * core, l.a[2] - sz * core, x1 + sx * core, y1 + sy * core, z1 + sz * core, x1 - sx * core, y1 - sy * core, z1 - sz * core);
            a3 = [ca2, ca2, ca2, ca2, ca2, ca2];
            RPG.world3d.mesh(id + "_c", { triangles: t3, alphas: a3, color: "#FFD9CC", alpha: 1 });
        }
    }
    function drawShock(id, s) {                             // ShockwaveVfx: an expanding ring on the ground
        var p = Math.max(0, Math.min(1, s.age / s.life)), r = s.r * (1 - Math.pow(1 - p, 2)), a = (1 - p) * 0.8, tri = [], al = [];
        ring(tri, al, s.x, s.y + 0.08, s.z, Math.max(0, r - 1.2), r, a, 0);
        ring(tri, al, s.x, s.y + 0.08, s.z, r, r + 0.5, a, 0);
        RPG.world3d.mesh(id, { triangles: tri, alphas: al, color: s.c, alpha: 1, blend: "additive" });
    }
    var KIBLAST = "dmzpack:textures/entity/ki/kiblast.png";
    RPG.net.on("dmz_wb_fx", function (d) {
        if (!d || !d.t) return;
        var t = d.t;
        if (t === "mark") { var id = "dwb_m" + (TICK++); FX[id] = { k: "mark", x: d.x, y: d.y, z: d.z, r: d.r, c: d.c, life: Math.max(1, d.life), follow: d.follow, age: 0 }; return; }
        if (t === "lane") {
            var lid = "dwb_l" + d.id;
            Object.keys(FX).forEach(function (k) { if (k === lid) { RPG.world3d.remove(k); RPG.world3d.remove(k + "_c"); } });
            FX[lid] = { k: "lane", a: d.a, b: d.b, w: d.w, c: d.c, life: Math.max(1, d.life), locked: d.locked, age: 0 }; return;
        }
        if (t === "shock") { FX["dwb_s" + (TICK++)] = { k: "shock", x: d.x, y: d.y, z: d.z, r: d.r, c: d.c, life: Math.max(1, d.life), age: 0 }; return; }
        if (t === "laser") {
            var c = d.c || {}, id2 = "dwb_z" + (TICK++);
            RPG.world3d.line(id2 + "o", { from: d.a, to: d.b, width: d.size * 1.0, color: c.outline || c.border, alpha: 0.5, blend: "additive", ticks: d.life });
            RPG.world3d.line(id2 + "b", { from: d.a, to: d.b, width: d.size * 0.6, color: c.border, alpha: 0.85, blend: "additive", ticks: d.life });
            RPG.world3d.line(id2 + "c", { from: d.a, to: d.b, width: d.size * 0.25, color: c.core || "#FFFFFF", alpha: 1, blend: "additive", ticks: d.life });
            return;
        }
        if (t === "ball") {
            var bid = "dwb_b" + d.id;
            if (d.remove) { RPG.world3d.remove(bid); RPG.world3d.remove(bid + "g"); RPG.world3d.remove(bid + "o"); return; }
            var bc = d.c || {};
            RPG.world3d.billboard(bid + "o", { x: d.x, y: d.y, z: d.z, size: d.size * 1.35, texture: KIBLAST, color: bc.outline || bc.border, alpha: 0.7, blend: "additive" });
            RPG.world3d.billboard(bid + "g", { x: d.x, y: d.y, z: d.z, size: d.size * 1.1, texture: KIBLAST, color: bc.border, alpha: 0.9, blend: "additive" });
            RPG.world3d.billboard(bid, { x: d.x, y: d.y, z: d.z, size: d.size * 0.75, texture: KIBLAST, color: bc.core || "#FFFFFF", alpha: 1, blend: "additive" });
            return;
        }
        if (t === "boom") {                                  // KiExplosionVisualEntity
            var xc = d.c || {}, xid = "dwb_x" + (TICK++);
            FX[xid] = { k: "boom", x: d.x, y: d.y, z: d.z, size: d.size, c: xc, life: 24, age: 0 };
            RPG.particle("minecraft:explosion_emitter", d.x, d.y, d.z, Math.max(1, Math.round(d.size / 10)), d.size * 0.25, 0);
            return;
        }
        if (t === "cut") { FX["dwb_c" + d.id] = { k: "cut", x: d.x, y: d.y, z: d.z, d: d.d, roll: d.roll, scale: d.scale, c: d.c, core: d.core, speed: d.speed, life: d.life, age: 0 }; return; }
        if (t === "ring") {                                  // the Kill Driver held over Turles' head
            var rid = "dwb_r" + d.id;
            if (d.remove) { RPG.world3d.removePrefix(rid); delete FX[rid]; return; }
            FX[rid] = { k: "ring", x: d.x, y: d.y, z: d.z, r: d.r, c: d.c, life: 1e9, age: 0 };
            return;
        }
        if (t === "hammer") {
            var hid = "dwb_h" + d.id;
            if (d.remove) { RPG.world3d.remove(hid); delete FX[hid]; return; }
            var h = FX[hid] || (FX[hid] = { k: "hammer", spin: 0, life: 1e9, age: 0 });
            h.x = d.x; h.y = d.y; h.z = d.z; h.spinning = d.spin; h.seen = 0;
            return;
        }
        if (t === "pillar") { FX["dwb_p" + (TICK++)] = { k: "pillar", x: d.x, y: d.y, z: d.z, h: d.h, r: d.r, block: d.block, life: 4 + 40 + 16, age: 0 }; return; }
        if (t === "whirl") {
            var wid = "dwb_w" + d.id;
            if (d.remove) { RPG.world3d.removePrefix(wid); delete FX[wid]; return; }
            if (d.move && FX[wid]) { FX[wid].x = d.x; FX[wid].z = d.z; return; }
            FX[wid] = { k: "whirl", x: d.x, y: d.y, z: d.z, h: d.h, c: d.c, life: d.life || 86, age: 0 };
            return;
        }
        if (t === "gale") {
            var gid = "dwb_g" + d.id;
            if (d.remove) { delete FX[gid]; return; }
            FX[gid] = { k: "gale", x: d.x, y: d.y, z: d.z, dx: d.dx, dz: d.dz, r: d.r, kk: d.k, life: d.life, age: 0 };
            return;
        }
        if (t === "bind") {
            var nid = "dwb_n" + d.id;
            if (d.remove) { RPG.world3d.removePrefix(nid); delete FX[nid]; return; }
            if (d.retract) { if (FX[nid]) FX[nid].retract = FX[nid].age; return; }
            FX[nid] = { k: "bind", x: d.x, y: d.y, z: d.z, held: d.held, life: 400, age: 0 };
            return;
        }
        if (t === "scrap") {
            var sid = "dwb_q" + d.id;
            if (d.remove) { RPG.world3d.removePrefix(sid); delete FX[sid]; return; }
            FX[sid] = { k: "scrap", x: d.x, y: d.y, z: d.z, ticks: d.ticks, life: d.ticks + 4, age: 0 };
            return;
        }
        if (t === "outline") {                                // the bosses' glow (Turles' Fruit of Might, Tamagami's stance, the Evil Eye)
            // DMZ's saga outline (DBSagasEntity.OutlineStyle): the transformation outline chain, pulse mode, no fire
            try { if (d.on) RPG.avatar.setOutline(d.entity, DMZ_OUTLINE.saga(d.c, d.c2 || d.c, Number(d.w) || 3)); else RPG.avatar.clearOutline(d.entity); } catch (e) { }
        }
    });
    RPG.every(1, function () {
        var ids = Object.keys(FX);
        if (!ids.length) return;
        ids.forEach(function (id) {
            var f = FX[id];
            f.age++;
            if (f.age > f.life) {
                delete FX[id];
                RPG.world3d.removePrefix(id);
                return;
            }
            try {
                if (f.k === "mark") {
                    if (f.follow >= 0) { var e = RPG.world.entity ? RPG.world.entity(f.follow) : null; if (e) { f.x = e.x; f.z = e.z; f.y = e.y; } }
                    if (f.age % 2 === 1 || f.age === f.life) drawMark(id, f);
                } else if (f.k === "lane") drawLane(id, f);
                else if (f.k === "shock") drawShock(id, f);
                else if (f.k === "boom") {
                    var p = f.age / f.life, sz = f.size * (0.3 + 0.7 * Math.sqrt(p)), a = 1 - p;
                    RPG.world3d.billboard(id + "o", { x: f.x, y: f.y, z: f.z, size: sz * 1.3, texture: KIBLAST, color: f.c.outline || f.c.border, alpha: a * 0.6, blend: "additive" });
                    RPG.world3d.billboard(id, { x: f.x, y: f.y, z: f.z, size: sz, texture: KIBLAST, color: f.c.border || "#FFFFFF", alpha: a, blend: "additive" });
                } else if (f.k === "cut") {                       // SwordSlashManager: a dark red crescent flying out
                    f.x += f.d[0] * f.speed; f.y += f.d[1] * f.speed; f.z += f.d[2] * f.speed;
                    var len = f.scale * 0.45, rl = f.roll * Math.PI / 180, sx = -f.d[2], sz2 = f.d[0], sl = Math.sqrt(sx * sx + sz2 * sz2) || 1;
                    sx /= sl; sz2 /= sl;
                    var ux = Math.cos(rl) * sx, uy = Math.sin(rl), uz = Math.cos(rl) * sz2, pts = [], ws = [];
                    for (var i = 0; i <= 10; i++) { var k = i / 10 * 2 - 1, bend = (1 - k * k) * len * 0.35; pts.push(f.x + ux * k * len + f.d[0] * bend, f.y + uy * k * len + f.d[1] * bend, f.z + uz * k * len + f.d[2] * bend); ws.push(0.6 * (1 - Math.abs(k))); }
                    RPG.world3d.bolt(id, { paths: [{ points: pts, widths: ws, alpha: 1 - f.age / f.life * 0.5 }], color: f.c, core: f.core, glow: 0.6 });
                } else if (f.k === "ring") {
                    var rp = [], rw = [];
                    for (var j = 0; j <= 24; j++) { var aa = Math.PI * 2 * j / 24 + f.age * 0.4; rp.push(f.x + Math.cos(aa) * f.r, f.y + Math.sin(aa) * 0.15, f.z + Math.sin(aa) * f.r); rw.push(0.18); }
                    RPG.world3d.bolt(id, { paths: [{ points: rp, widths: rw, alpha: 1 }], color: f.c.border, core: f.c.core, glow: 0.8 });
                } else if (f.k === "hammer") {
                    if (f.spinning) f.spin += 40;
                    RPG.world3d.billboard(id, { x: f.x, y: f.y, z: f.z, size: 1.4, texture: "dmzpack:textures/item/tamagami_hammer.png", roll: f.spin % 360, emissive: false });
                    if (++f.seen > 40) { delete FX[id]; RPG.world3d.remove(id); }
                } else if (f.k === "pillar") {                    // TamagamiPillar: rises 4 ticks, holds 40, sinks 16
                    var hh = f.age <= 4 ? f.h * f.age / 4 : f.age <= 44 ? f.h : f.h * Math.max(0, 1 - (f.age - 44) / 16);
                    var tex = blockTexture(f.block);
                    RPG.world3d.line(id, { from: [f.x, f.y, f.z], to: [f.x, f.y + Math.max(0.05, hh), f.z], width: f.r * 2, texture: tex, uv: [0, 0, 1, Math.max(1, hh / (f.r * 2))], emissive: false });
                } else if (f.k === "whirl") {
                    if (f.age % 2 === 0) {
                        var paths = [], segs = Math.max(1, Math.round(f.h / 3));
                        for (var q = 0; q < 3; q++) {
                            var pp = [], pw = [];
                            for (var s = 0; s <= segs * 4; s++) { var hy = f.y + f.h * s / (segs * 4), rr = 1.5 + 2.5 * Math.pow(s / (segs * 4), 1.35), an = s * 0.6 + f.age * 0.5 + q * 2.09; pp.push(f.x + Math.cos(an) * rr, hy, f.z + Math.sin(an) * rr); pw.push(0.12 + 0.1 * s / (segs * 4)); }
                            paths.push({ points: pp, widths: pw, alpha: f.age < 6 ? f.age / 6 : 0.85 });
                        }
                        RPG.world3d.bolt(id, { paths: paths, color: f.c.border, core: f.c.core, glow: 0.4, ticks: 3 });
                    }
                } else if (f.k === "gale") {
                    if (f.age % 2 === 0) for (var g = 0; g < Math.round(10 * f.kk); g++) {
                        var gx = f.x + (Math.random() * 2 - 1) * f.r, gz = f.z + (Math.random() * 2 - 1) * f.r, gy = f.y + Math.random() * 8;
                        RPG.particle("minecraft:cloud", gx, gy, gz, 1, 0.1, 0);
                    }
                } else if (f.k === "bind") {                      // Gete cables: chains springing from the floor around the victim
                    var up = f.retract !== undefined ? Math.max(0, 1 - (f.age - f.retract) / 8) : Math.min(1, f.age / 6), bp = [];
                    var tgt = f.held >= 0 && RPG.world.entity ? RPG.world.entity(f.held) : null, topY = tgt ? tgt.y + 1.2 : f.y + 2.5;
                    for (var cn = 0; cn < 4; cn++) {
                        var ca = cn * Math.PI / 2 + 0.6, bx = f.x + Math.cos(ca) * 1.6, bz = f.z + Math.sin(ca) * 1.6, ex = tgt ? tgt.x : f.x, ez = tgt ? tgt.z : f.z;
                        var pts2 = [];
                        for (var u = 0; u <= 6; u++) { var kk = u / 6 * up; pts2.push(bx + (ex - bx) * kk, f.y + (topY - f.y) * kk + Math.sin(kk * Math.PI) * 0.6, bz + (ez - bz) * kk); }
                        bp.push({ points: pts2, width: 0.12, alpha: 1 });
                    }
                    RPG.world3d.bolt(id, { paths: bp, color: "#5A5A66", core: "#B8B8C8", glow: 0.1 });
                } else if (f.k === "scrap") {                     // the reassembly sphere (r 3.5, lifted 1.6), collapsing at the end
                    var pr = f.age / f.ticks, col = (f.age - (f.ticks - 24)) / 24, rad = 3.5 * (1 - 0.85 * Math.max(0, Math.min(1, col)));
                    for (var n = 0; n < 6 + Math.round(pr * 4); n++) {
                        var yy = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2, rg = Math.sqrt(1 - yy * yy);
                        RPG.particle("minecraft:end_rod", f.x + Math.cos(th) * rg * rad, f.y + 1.6 + yy * rad, f.z + Math.sin(th) * rg * rad, 1, 0, 0);
                    }
                    if (f.age % 3 === 0) RPG.particle("minecraft:witch", f.x, f.y + 1.6, f.z, 2, rad * 0.5, 0);
                }
            } catch (err) { delete FX[id]; RPG.world3d.removePrefix(id); }
        });
    });
    function blockTexture(b) {
        var id = String(b || "minecraft:stone").replace(/\[.*$/, ""), c = id.indexOf(":"), ns = c > 0 ? id.substring(0, c) : "minecraft", path = c > 0 ? id.substring(c + 1) : id;
        if (path === "air" || path === "cave_air") { ns = "minecraft"; path = "stone"; }
        return ns + ":textures/block/" + path + ".png";
    }

    RPG.on("load", function () { RPG.hud.onRender(drawContribution); RPG.hud.onRender(drawRevive); });
    return { state: function () { return STATE; }, tr: tr, arg: arg };
})();
