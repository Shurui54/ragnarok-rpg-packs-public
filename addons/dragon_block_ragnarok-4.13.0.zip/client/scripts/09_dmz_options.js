// =====================================================================================
//  09_dmz_options.js - DragonMine Z's per-player options (GeneralUserConfig), read by the
//  features that use them and set from the options screen (54_dmz_config_menu.js)
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): GeneralUserConfig's defaults and limits, ScaledScreen's menu
//  scale, UtilityMenuScreen's scale, TutorialManager's on/off + seen list, SoundManagerMixin's
//  "Ki Sound Volume" and the ReserveFirstHotbarSlotC2S sync. Values live in RPG.storage (this
//  player's computer, per world/server), like every other DBR option.
// =====================================================================================
var DMZ_OPTS = (function () {
    var KEYS = {
        advancedDescription: "dmz_cfg_adv_desc",            // HUD bar values shown at all (HudBar.drawValue)
        advancedDescriptionPercentage: "dmz_hud_percent",   // ...as a % (was DBR's "HUD Values as %")
        hexagonStatsDisplay: "dmz_cfg_hexagon_stats",
        menuScaleMultiplier: "dmz_cfg_menu_scale",
        utilityMenuScaleMultiplier: "dmz_cfg_utility_scale",
        tutorialsEnabled: "dmz_cfg_tutorials",
        tutorialsSeen: "dmz_tutorials_seen",
        cameraMovementDuringFlight: "dmz_cfg_flight_camera",
        flightTurnSensitivity: "dmz_cfg_flight_turn",
        reserveFirstHotbarSlot: "dmz_cfg_reserve_slot",
        kiSoundVolume: "dmz_cfg_ki_volume",
        transformationOutlines: "dmz_cfg_outlines",          // TransformationPostShaderManager (engine avatar outline)
        impactFramesEnabled: "dmz_cfg_impact_frames",       // ImpactFramesHandler (57_dmz_impact_frames.js)
        firstPersonAnimated: "dmz_cfg_fp_animated",         // DMZPOVPlayerRenderer (engine first-person body)
        overShoulderMode: "dmz_os_mode", overShoulderLeft: "dmz_os_left", overShoulderBack: "dmz_os_back",
        overShoulderUp: "dmz_os_up", overShoulderSide: "dmz_os_side", overShoulderSmoothing: "dmz_os_smoothing"
    };
    var DEFAULT_MENU_SCALE = 0.75, MIN_MENU_SCALE = 0.5, MAX_MENU_SCALE = 2.5, REFERENCE_HEIGHT = 270;

    function get(key, def) { try { var v = RPG.storage.get(key, def); return v === undefined || v === null ? def : v; } catch (e) { return def; } }
    function set(key, v) { try { RPG.storage.set(key, v); } catch (e) { } }
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function num(key, def) { var v = Number(get(key, def)); return isNaN(v) || !isFinite(v) ? def : v; }
    function bool(key, def) { return !!get(key, def); }

    // ---- menus (ScaledScreen / UtilityMenuScreen) ----
    function menuScale() { var m = num(KEYS.menuScaleMultiplier, DEFAULT_MENU_SCALE); return m <= 0 ? DEFAULT_MENU_SCALE : clamp(m, MIN_MENU_SCALE, MAX_MENU_SCALE); }
    function utilityScale() { var m = num(KEYS.utilityMenuScaleMultiplier, 1); return m <= 0 ? 1 : clamp(m, 0.5, 2.5); }
    /** ScaledScreen.calculateUiScale: (height / 270) x the menu scale, never past what fits 320 x 240. */
    function menuUiScale(w, h) {
        w = Math.max(1, w); h = Math.max(1, h);
        var fit = Math.max(0.25, Math.min(w / 320, h / 240));
        return clamp(h / REFERENCE_HEIGHT * menuScale(), 0.25, fit);
    }
    /** The referenceHeight a DMZ-style screen opens with (360 at DMZ's default 0.75). */
    function menuRef() {
        var w = 0, h = 0;
        try { w = RPG.screenWidth; h = RPG.screenHeight; } catch (e) { }
        if (!(w > 0 && h > 0)) return REFERENCE_HEIGHT / menuScale();
        return h / menuUiScale(w, h);
    }

    // ---- tutorials (TutorialManager) ----
    function seenMap() { var m = get(KEYS.tutorialsSeen, null); return m && typeof m === "object" ? m : {}; }
    var tutorials = {
        enabled: function () { return bool(KEYS.tutorialsEnabled, true); },
        hasSeen: function (id) { return !!seenMap()[id]; },
        shouldRun: function (id) { return tutorials.enabled() && !tutorials.hasSeen(id); },
        markSeen: function (id) { var m = seenMap(), out = {}; for (var k in m) out[k] = m[k]; out[id] = true; set(KEYS.tutorialsSeen, out); },
        resetSeen: function () { set(KEYS.tutorialsSeen, {}); set("dmz_rhythm_calibrated", false); }
    };

    // ---- Ki Sound Volume (SoundManagerMixin: sounds named ki_*, kiblast_shoot and laserbeam, any namespace) ----
    function kiVolume() { return Math.round(clamp(num(KEYS.kiSoundVolume, 100), 0, 100)); }
    function applyKiVolume() {
        if (typeof RPG.soundVolume !== "function") return;
        var m = kiVolume() / 100;
        ["ki_", "kiblast_shoot", "laserbeam"].forEach(function (p) { RPG.soundVolume(p, m); });
    }

    // ---- Visuals: outlines and the first-person body are engine switches on this computer ----
    // GeneralUserConfig defaults: transformationOutlines true, impactFramesEnabled false, firstPersonAnimated true
    function outlines() { return bool(KEYS.transformationOutlines, true); }
    function impactFrames() { return bool(KEYS.impactFramesEnabled, false); }
    function firstPersonAnimated() { return bool(KEYS.firstPersonAnimated, true); }
    function applyVisuals() {
        var av = RPG.avatar;
        if (!av) return;
        if (typeof av.outlines === "function") av.outlines(outlines());           // yours and everyone else's
        // DMZ's transformation outline post chain (shared/07c_dmz_outline.js) draws the "mask" outlines
        if (typeof av.outlineChain === "function") av.outlineChain(DMZ_OUTLINE.CHAIN);
        if (typeof av.firstPerson === "function") av.firstPerson(firstPersonAnimated() ? "animated" : "arms");
    }

    // ---- Reserve First Hotbar Slot (sent to the server on join and on change, like DMZ) ----
    function syncReserve() { RPG.net.send("dmz_user_opts", { reserve: bool(KEYS.reserveFirstHotbarSlot, false) }); }

    var synced = false;
    RPG.on("load", function () { synced = false; applyKiVolume(); applyVisuals(); });
    RPG.every(20, function () {
        if (!RPG.player.present) { synced = false; return; }
        if (!synced) { synced = true; syncReserve(); applyKiVolume(); applyVisuals(); }
    });

    return {
        KEYS: KEYS, get: get, set: set, num: num, bool: bool, clamp: clamp,
        DEFAULT_MENU_SCALE: DEFAULT_MENU_SCALE, MIN_MENU_SCALE: MIN_MENU_SCALE, MAX_MENU_SCALE: MAX_MENU_SCALE,
        menuScale: menuScale, utilityScale: utilityScale, menuUiScale: menuUiScale, menuRef: menuRef,
        advancedDescription: function () { return bool(KEYS.advancedDescription, true); },
        advancedPercent: function () { return bool(KEYS.advancedDescriptionPercentage, true); },
        hexagon: function () { return bool(KEYS.hexagonStatsDisplay, false); },
        flightCamera: function () { return bool(KEYS.cameraMovementDuringFlight, true); },
        /** GeneralUserConfig.getFlightTurnSensitivity: 0.75 by default, 0.2..2. */
        flightTurn: function () { return clamp(num(KEYS.flightTurnSensitivity, 0.75), 0.2, 2); },
        reserveSlot: function () { return bool(KEYS.reserveFirstHotbarSlot, false); },
        kiVolume: kiVolume, applyKiVolume: applyKiVolume, syncReserve: syncReserve,
        outlines: outlines, impactFrames: impactFrames, firstPersonAnimated: firstPersonAnimated, applyVisuals: applyVisuals,
        tutorials: tutorials
    };
})();
