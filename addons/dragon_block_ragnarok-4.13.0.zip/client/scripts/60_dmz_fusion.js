// =====================================================================================
//  60_dmz_fusion.js - the client side of DMZ fusion (scripts/64_dmz_fusion.js)
// =====================================================================================
//  - Fusion timer (drawn in DMZ Ragnarok's HUD art): a movable HUD piece ("Fusion" in the HUD editor) while you are fused,
//    showing the fused name, the kind (Fusion Dance / Potara / Beetle) and the time left
//    (DMZ shows the same as the "Fused" effect's duration). Reads the var dmz_fusion_hud.
//  - Toasts (DMZ_NOTIFY, 47_dmz_notifications.js): a nearby player started the Fusion Dance
//    (the "request": answer it by picking Fusion in the X menu and holding the action key),
//    and "you fused".
// =====================================================================================
(function () {
    var FONT = "dmzpack:smooth";
    var TYPES = { METAMORU: "Fusion Dance", POTHALA: "Potara", BEETLE: "Medi-Bug Beetle" };
    var COLORS = { METAMORU: "#FFB347", POTHALA: "#FFE066", BEETLE: "#7FE08A" };
    var W = 140, H = 31 * 140 / 209 + 9, RTEX = "dbr:textures/gui/hud/ragnarok/";

    function tr(key, fallback) {
        try { if (RPG.hasTranslation(key)) return RPG.translate(key); } catch (e) { /* older client */ }
        return fallback;
    }
    function clock(sec) {
        sec = Math.max(0, Math.floor(sec));
        var m = Math.floor(sec / 60), s = sec % 60;
        return m + ":" + (s < 10 ? "0" : "") + s;
    }
    function strip(s) { return String(s || "").replace(/§[0-9a-fk-or]/gi, "").replace(/&[0-9a-fk-or]/gi, ""); }

    // the server sends the seconds left once a second; count down smoothly in between
    var last = null, lastAt = 0;
    function state() {
        var v = RPG.getVar("dmz_fusion_hud", null);
        if (!v || typeof v !== "object" || !v.n) { last = null; return null; }
        if (!last || last.l !== v.l || last.n !== v.n) { last = { n: v.n, t: v.t, l: Number(v.l) || 0, tot: Number(v.tot) || 1, lead: !!v.lead, pn: v.pn, c: v.c }; lastAt = RPG.nowMs(); }
        return last;
    }

    RPG.hud.onRender(function (ctx) {
        var s = state(), editing = ctx.isEditing();
        if (!s && !editing) return;
        var sample = !s;
        if (sample) s = { n: "Gogeta", t: "METAMORU", l: 754, tot: 900, lead: true, pn: "Vegeta" };
        var x = Math.round(ctx.width / 2 - W / 2), y = 34;
        // the box takes in DMZ's HUD cloud peeking out past the housing's top-left corner
        if (!ctx.group("dmz_fusion", tr("gui.dragonminez.hud_editor.element.fusion", "Fusion"), x - 5, y - 7, W + 5, H + 7)) return;
        var left = sample ? s.l : Math.max(0, s.l - (RPG.nowMs() - lastAt) / 1000), frac = Math.max(0, Math.min(1, left / Math.max(1, s.tot)));
        var accent = COLORS[s.t] || "#55FFFF";
        if (s.t === "POTHALA" && s.c === "green") accent = "#7FE08A";
        // DMZ Ragnarok's HUD art: the gold-trimmed navy housing, its bar draining with the time left in the fusion
        // kind's colour, the fused name and the clock over it, the kind (and who leads) under it
        var k = W / 209, fw = W, fh = 31 * k, bx = x + 17 * k, by = y + 7 * k, bw = 188 * k, bh = 20 * k;
        // DMZ's own HUD cloud (xenoversehud, HudSprites.XENOVERSE.cloud) behind the cloudless housing's top-left corner,
        // drawn first like DMZ's Xenoverse HUD draws it under its bars
        ctx.quad("dmzpack:textures/gui/hud/xenoversehud.png", x - 5, y - 7, 30, 13.4, 368 / 512, 20 / 512, 480 / 512, 70 / 512, "#FFFFFF", 1);
        ctx.quad(RTEX + "main_frame_bare.png", x, y, fw, fh, 0, 0, 1, 1, "#FFFFFF", 1);
        if (frac > 0) ctx.quad(RTEX + "health_fill_grey.png", bx, by, bw * frac, bh, 0, 0, frac, 1, accent, 0.9);
        ctx.textStyled(strip(s.n), bx + 4, by + bh / 2 - 3.5, 0.85, "#FFE066", 1, 0, FONT, "#000000");
        ctx.textStyled(clock(left), bx + bw - 4, by + bh / 2 - 3.5, 0.85, left <= 30 ? "#FF5555" : "#FFFFFF", 1, 1, FONT, "#000000");
        var sub = (TYPES[s.t] || "Fusion") + (s.lead ? "" : " - " + strip(s.pn));
        ctx.textStyled(sub, bx + 2, y + fh + 1, 0.7, "#C7EAFC", 1, 0, FONT, "#000000");
        ctx.endGroup();
    });

    RPG.net.on("dmz_fusion", function (d) {
        if (!d || typeof DMZ_NOTIFY === "undefined") return;
        var P = DMZ_NOTIFY.PRIORITY;
        if (d.op === "request") {
            var keyLabel = RPG.actionKeyLabel(12) || "G";
            DMZ_NOTIFY.push({
                title: tr("actionmode.dragonminez.fusion", "Fusion"),
                subtitle: strip(d.name) + " is doing the Fusion Dance",
                description: d.mode ? "Hold " + keyLabel + " next to them to fuse." : "Pick Fusion in the menu, then hold " + keyLabel + " next to them.",
                extra: "Same race, same form, similar power."
            }, P.HIGH);
            RPG.sound("dmzpack:pip_menu", 0.6, 1.2);
        } else if (d.op === "fused") {
            DMZ_NOTIFY.push({
                title: tr("effect.dragonminez.fused", "Fused"),
                subtitle: strip(d.name),
                description: d.lead ? "You lead the fusion." : "You ride along as a spectator.",
                extra: TYPES[d.type] || null
            }, P.HIGH);
        }
    });
})();
