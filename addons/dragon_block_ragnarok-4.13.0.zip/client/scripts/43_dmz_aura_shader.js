// =====================================================================================
//  43_dmz_aura_shader.js - DMZ's 3D auras, drawn with DMZ's own shaders
// =====================================================================================
//  Ported from DragonMine Z 2.2 (GPL-3.0): AuraRenderer (layers per form and stack form, the charge layer,
//  growth / fade, per-layer motion and style blending, flight and swim lean, first person, the ground
//  pulses), Aura3DRenderer (smooth / sparking / god shells: sizes, pivots, passes, back faces), AuraStyle
//  (uniforms from FormConfig.Aura3DStyle and the aura colour), AuraMeshFactory (droplet, sparking flame and
//  god flame meshes), AuraNoiseTexture (resources/assets/dbr/textures/fx/aura_noise.png, generated with its
//  algorithm), BloomPipeline (three blurred levels laid back over the frame), and the first-person 2D aura
//  overlay. The GLSL is DMZ's (resources/assets/dbr/shaders/core/aura_*.json/vsh/fsh, bloom_*), drawn by the
//  engine's RPG.shaders.
//
//  The server shares what each player shows as "dmzAuraFx" (scripts/31_dmz_transform.js): forms, charge
//  target and progress, race colour, 3D choice and aura scale. Players drawn here have the engine's own aura
//  turned off on this computer (RPG.auras.suppress); everyone else (2D auras, other effects) keeps it.
// =====================================================================================
var DMZ_AURA_SHADER = (function () {
    var SH = { smooth: "dbr:aura_smooth", sparking: "dbr:aura_sparking", god: "dbr:aura_god", flat: "dbr:aura" };
    var NOISE = "dbr:textures/fx/aura_noise.png";
    var AURA_TEX = "dmzpack:textures/entity/races/aura/";
    var MESH = { droplet: "dbr:aura_droplet", sparking: "dbr:aura_sparking", god: "dbr:aura_god", quad: "dbr:aura_quad" };

    // Aura3DRenderer / AuraRenderer constants
    var SMOOTH_SCALE_REFERENCE = 1.05 * 0.9375, SMOOTH_CENTER = 1.15, SMOOTH_RADIUS = 0.80, SMOOTH_HALF_HEIGHT = 1.35;
    var SMOOTH_BACKFACE = 0.01, BACKFACE_INSIDE = 1.0, SMOOTH_FP_ALPHA = 0.45, SMOOTH_FLIGHT_LEAD = 0.25;
    var SPARKING_TIME_SCALE = 0.67, SPARKING_PULSE_TIME_SCALE = 0.50, SPARKING_WIDTH = 0.936, SPARKING_HEIGHT = 1.325, SPARKING_PIVOT = 0.889;
    var SPARKING_CORE = 0.45, SPARKING_LAYER_WIDTH = 0.26, AURA_3D_BACKFACE = 0.02, AURA_3D_BACKFACE_FP = 0.85, AURA_3D_FP_ALPHA = 0.15, AURA_3D_FLIGHT_LEAD = 1.10;
    var GOD_BACKFACE = 0.45, GOD_PULSE_WIDTH = 1.2, GOD_PULSE_HEIGHT = 0.9, GOD_PULSE_ALPHA = 0.7, GOD_CENTER = 1.28, GOD_FP_ALPHA = 0.35, GOD_WORLD_DROP = 0.15;
    var GROWTH_RATE = 4.0, SHRINK_RATE = 3.0, STYLE_BLEND_RATE = 6.0;
    var PULSE_RATE = 0.6;          // PULSE_SPEED 0.01 a frame, at 60 frames a second
    var MODEL_SCALE = 0.9375;      // a normal body's model scale (FormVisualTransition)
    var FLAT_FADE = 0.005 * 60;    // FADE_SPEED a frame (2D first-person overlay)
    var CORE_LIGHTEN = 0.45, BRIGHTNESS = 0.85;
    var DT = 0.05;

    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function lerp(a, b, t) { return a + (b - a) * t; }
    function rgb(h) { h = String(h || "#FFFFFF").replace("#", ""); var n = parseInt(h, 16); if (isNaN(n)) n = 0xFFFFFF; return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; }
    function hexLerp(a, b, t) { var x = rgb(a), y = rgb(b); return [lerp(x[0], y[0], t), lerp(x[1], y[1], t), lerp(x[2], y[2], t)]; }

    // ---- meshes (AuraMeshFactory) ------------------------------------------------------------
    function buildMesh(which) {
        var r = [], y = [], i, t, yy;
        if (which === 0) {
            var n = 96;
            for (i = 0; i <= n; i++) { t = i / n; yy = t * 2 - 1; y.push(yy); r.push((0.8 + 0.5 * Math.pow(1 - t, 1.5)) * Math.sqrt(Math.max(0, 1 - yy * yy))); }
            RPG.shaders.lathe(MESH.droplet, { format: "position", rings: n, segments: n, radius: r, y: y });
        } else if (which === 1) {
            var rings = 72, peak = 0;
            for (i = 0; i <= rings; i++) { t = i / rings; yy = t * 2 - 1; var v = (0.84 + 0.42 * Math.pow(1 - t, 1.25)) * Math.sqrt(Math.max(0, 1 - yy * yy)); r.push(v); y.push(-1 + i * (2 / rings)); if (v > peak) peak = v; }
            if (peak <= 0) peak = 1;
            for (i = 0; i <= rings; i++) r[i] /= peak;
            RPG.shaders.lathe(MESH.sparking, { format: "position_color_normal", rings: rings, segments: 128, radius: r, y: y });
        } else if (which === 2) {
            var g = 96;
            for (i = 0; i <= g; i++) { t = i / g; yy = t * 2 - 1; r.push(Math.pow(Math.sqrt(Math.max(0, 1 - yy * yy)), 0.9) * (0.86 + 0.30 * Math.pow(1 - t, 1.3))); y.push(t); }
            RPG.shaders.lathe(MESH.god, { format: "position_tex", rings: g, segments: g, radius: r, y: y });
        } else RPG.shaders.mesh(MESH.quad, { format: "position_tex", vertices: [-1, -1, 0, 0, 1, 1, -1, 0, 1, 1, 1, 1, 0, 1, 0, -1, 1, 0, 0, 0] });
    }

    // shaders compile on the engine's next frame (RPG.shaders.status), meshes one a tick: ready after a few ticks
    var ready = false, failed = false, stage = 0;
    var NEEDED = [[SH.smooth, "position"], [SH.sparking, "position_color_normal"], [SH.god, "position_tex"], [SH.flat, "position_tex"],
        ["dbr:bloom_down", "position"], ["dbr:bloom_blur", "position"], ["dbr:bloom_composite", "position"]];
    function setup() {
        if (ready || failed) return ready;
        if (!RPG.shaders || !RPG.shaders.status) { failed = true; return false; }
        var waiting = false;
        for (var i = 0; i < NEEDED.length; i++) {
            var st = RPG.shaders.status(NEEDED[i][0], NEEDED[i][1]);
            if (st === "failed") { failed = true; RPG.log("[DBR] DMZ aura shader " + NEEDED[i][0] + " did not load; using the engine's auras"); return false; }
            if (st !== "ready") waiting = true;
        }
        if (waiting) return false;
        if (stage === 0) buildMesh(0);
        else if (stage === 1) buildMesh(1);
        else if (stage === 2) buildMesh(2);
        else {
            buildMesh(3);
            RPG.shaders.bloom({ down: "dbr:bloom_down", blur: "dbr:bloom_blur", composite: "dbr:bloom_composite", levels: [6, 8, 10], intensity: 1.0, spread: 0.6 });
            ready = true;
            RPG.log("[DBR] DMZ aura shaders ready");
        }
        stage++;
        return ready;
    }

    // ---- AuraStyle.resolve / blendTowards -------------------------------------------------------
    var D = DMZ_AURA_DATA.DEFAULT_STYLE;
    function cfg(over) {
        var c = {}, k;
        for (k in D) c[k] = D[k];
        for (k in (over || {})) c[k] = over[k];
        return c;
    }
    function resolve(over, color) {
        var c = cfg(over), base = color || [1, 1, 1], s = {}, i;
        var size = c.size || [1.1, 1.17, 1.02];
        s.size = [Math.max(0.05, size[0]), Math.max(0.05, size[1]), Math.max(0.05, size[2])];
        s.peaks = clamp(c.flamePeaks, 1, 64); s.waveFrequency = Math.max(0, c.waveFrequency); s.waveSpeed = c.waveSpeed; s.waveAmplitude = Math.max(0, c.waveAmplitude);
        s.noiseDetail = Math.max(0, c.noiseDetail); s.upwardBias = clamp(c.upwardBias, 0, 1); s.coreAlpha = clamp(c.coreAlpha, 0, 1); s.rimAlpha = clamp(c.rimAlpha, 0, 1);
        s.rimPower = Math.max(0.1, c.rimPower); s.rimThreshold = Math.max(0.001, c.rimThreshold); s.bloomIntensity = Math.max(0, c.bloomIntensity);
        s.spikeDensity = clamp(c.spikeDensity, 4, 32); s.spikeBurstRate = Math.max(0, c.spikeBurstRate); s.spikeRarity = Math.max(0.1, c.spikeRarity); s.bandStart = clamp(c.bandStart, 0.05, 0.95);
        s.rimColor = c.rimColor ? rgb(c.rimColor) : base.slice();
        if (c.coreColor) s.coreColor = rgb(c.coreColor);
        else {
            var peak = Math.max(base[0], base[1], base[2]);
            s.coreColor = [];
            for (i = 0; i < 3; i++) s.coreColor.push(lerp(base[i], peak > 1e-4 ? base[i] / peak : base[i], CORE_LIGHTEN));
        }
        if (c.noiseColor) { s.noiseColor = rgb(c.noiseColor); s.noiseFactor = 1; } else { s.noiseColor = s.rimColor.slice(); s.noiseFactor = 0; }
        if (c.secondBorderColor) { s.secondBorderColor = rgb(c.secondBorderColor); s.secondBorderFactor = 1; } else { s.secondBorderColor = s.rimColor.slice(); s.secondBorderFactor = 0; }
        for (i = 0; i < 3; i++) { s.coreColor[i] *= BRIGHTNESS; s.rimColor[i] *= BRIGHTNESS; s.noiseColor[i] *= BRIGHTNESS; }
        return s;
    }
    var SCALARS = ["peaks", "waveFrequency", "waveSpeed", "waveAmplitude", "noiseDetail", "upwardBias", "coreAlpha", "rimAlpha", "rimPower", "rimThreshold",
        "noiseFactor", "bloomIntensity", "spikeDensity", "spikeBurstRate", "spikeRarity", "bandStart", "secondBorderFactor"];
    var VECS = ["size", "coreColor", "rimColor", "noiseColor", "secondBorderColor"];
    function copy(s) { var o = {}; SCALARS.forEach(function (k) { o[k] = s[k]; }); VECS.forEach(function (k) { o[k] = s[k].slice(); }); return o; }
    function blendTowards(a, b, t) {
        if (t <= 0) return a;
        if (t >= 1) return copy(b);
        SCALARS.forEach(function (k) { a[k] = lerp(a[k], b[k], t); });
        VECS.forEach(function (k) { for (var i = 0; i < 3; i++) a[k][i] = lerp(a[k][i], b[k][i], t); });
        return a;
    }

    // ---- AuraRenderer.getAuraLayers from the shared description --------------------------------
    function pair(v) { var s = String(v || ""), i = s.indexOf(":"); return i < 0 ? null : { g: s.substring(0, i), f: s.substring(i + 1) }; }
    // a form's aura look: the form editor's fields first (form.aura3d), then DMZ's table
    function lookOf(race, group, id, stack) {
        var f = stack ? DMZ_FORMS.stackForm(group, id) : DMZ_FORMS.form(race, group, id);
        var d = (stack ? DMZ_AURA_DATA.findStack(group, id) : DMZ_AURA_DATA.find(race, group, id)) || {};
        var out = { t2: (f && f.aura2d) || d.t || "kakarot", color: f ? f.aura || "" : "", t3: d.t3 || "userPreference", layer: d.l !== undefined ? d.l : (stack ? 1 : 0), style: d.s || {}, extra: d.x || null };
        if (stack && d.l === undefined && group === "ultimate") out.layer = 0;
        if (f && f.aura3d) {
            var e = f.aura3d;
            if (e.t3) out.t3 = e.t3;
            if (typeof e.l === "number") out.layer = e.l;
            if (e.s) out.style = e.s;
            if (e.x !== undefined) out.extra = e.x;
        }
        return out;
    }
    function sanitize(pref, race) {
        pref = String(pref || "").toLowerCase();
        if (pref === "sparking") return "sparking";
        if (pref === "god") return race === "glind" ? "god" : "smooth";
        return "smooth";
    }
    function resolveType(t3, pref, race) {
        if (!t3 || String(t3).toLowerCase() === "userpreference") return sanitize(pref, race);
        t3 = String(t3).toLowerCase();
        return t3 === "sparking" || t3 === "god" ? t3 : "smooth";
    }
    // HelmetFormLook: with Broly's tiara on (fx.hl), the Mutant forms take its aura colour and 3D noise colour
    function helm(l, fx, id) {
        var h = fx.hl && typeof DBR_QUIRKS_DATA !== "undefined" ? DBR_QUIRKS_DATA.helmetLook(id) : null;
        if (!h) return l;
        var st = {}, key;
        for (key in l.style) st[key] = l.style[key];
        st.noiseColor = h.noise;
        l.color = h.aura; l.style = st;
        return l;
    }
    function layersFor(fx) {
        var race = fx.r, map = {}, k = clamp(Number(fx.k) || 0, 0, 1);
        function put(id, l) { if (id < 0) return; id = clamp(id, 0, 6); l.layerId = id; map[id] = l; }
        function shifting(id, l) { if (id < 0) return; id = clamp(id, 0, 6); while (map[id] && id < 6) id++; l.layerId = id; map[id] = l; }
        var normalHex = fx.base || "#FFFFFF", normalT3 = "userPreference", normalLayer = 0, normalStyle = {}, normalChargeStyle = null, fl = null;
        if (fx.f) {
            fl = helm(lookOf(race, fx.fg, fx.f, false), fx, fx.f);
            if (fl.color) normalHex = fl.color;
            normalT3 = fl.t3; normalLayer = fl.layer; normalStyle = fl.style;
        }
        var normalColor = rgb(normalHex), chargeLayer = null, nf = pair(fx.nf);
        if (nf && !fx.s) {
            var nl = helm(lookOf(race, nf.g, nf.f, false), fx, nf.f), targetHex = nl.color || normalHex;
            if (nl.layer === normalLayer) { normalColor = hexLerp(normalHex, targetHex, k); normalChargeStyle = nl.style; }
            else {
                var tc = rgb(targetHex);
                chargeLayer = { t3: nl.t3 || normalT3, color: tc, alpha: k, style: resolve(nl.style, tc) };
                chargeLayer.lid = nl.layer;
            }
        }
        var normal = { t2: fl ? fl.t2 : "kakarot", t3: normalT3, color: normalColor, alpha: 1, style: resolve(normalStyle, normalColor) };
        if (normalChargeStyle) blendTowards(normal.style, resolve(normalChargeStyle, normalColor), k);
        put(normalLayer, normal);
        if (chargeLayer) put(chargeLayer.lid, chargeLayer);
        if (fl && fl.extra && fl.extra.l >= 0) {
            var xc = rgb(fl.extra.c || "#FFFFFF");
            shifting(fl.extra.l, { t3: fl.extra.t3 || "userPreference", color: xc, alpha: 1, style: resolve(fl.extra.s, xc) });
        }
        var ns = pair(fx.ns);
        if (fx.s) {
            var sl = lookOf(race, fx.sg, fx.s, true), stackHex = sl.color || "#FFFFFF", stackColor = rgb(stackHex);
            var stackLayer = { t2: sl.t2, t3: sl.t3, color: stackColor, alpha: 1, style: null };
            var nsl = ns ? lookOf(race, ns.g, ns.f, true) : null;
            if (nsl) stackLayer.color = stackColor = hexLerp(stackHex, nsl.color || stackHex, k);
            stackLayer.style = resolve(sl.style, stackColor);
            if (nsl) blendTowards(stackLayer.style, resolve(nsl.style, stackColor), k);
            put(sl.layer, stackLayer);
            if (sl.extra && sl.extra.l >= 0) {
                var sx = rgb(sl.extra.c || "#FFFFFF");
                shifting(sl.extra.l, { t3: sl.extra.t3 || "userPreference", color: sx, alpha: 1, style: resolve(sl.extra.s, sx) });
            }
        } else if (ns) {
            var cl = lookOf(race, ns.g, ns.f, true), th = cl.color || "#FFFFFF";
            if (cl.layer === normalLayer) {
                var base = map[normalLayer];
                if (base) { base.color = hexLerp(normalHex, th, k); blendTowards(base.style, resolve(cl.style, base.color), k); }
            } else {
                var cc = rgb(th);
                put(cl.layer, { t3: cl.t3, color: cc, alpha: k, style: resolve(cl.style, cc) });
            }
        }
        var out = [];
        for (var id in map) out.push(map[id]);
        out.sort(function (a, b) { return a.layerId - b.layerId; });
        out.forEach(function (l) { l.type = resolveType(l.t3, fx.pref, race); });
        return out;
    }

    // ---- per player ---------------------------------------------------------------------------
    var ST = {};                      // entity id -> {growth, motions, ids, flat}
    function surgeMult(p) {
        // AuraFxState.isSurging: CombatConfig surgeAuraScaleMultiplier / surgeAuraSpeedMultiplier while the surge runs
        // (shared dmzSurge, 64_dmz_surge.js) or the ki burst is armed and its bar filling (auraBoost)
        var boost = Number(p.shared("auraBoost", 0)) || 0;
        var active = !!p.shared("dmzSurge", null) || boost > 0;
        return { scale: active ? 1.25 : 1, speed: active ? 1.5 : 1 };
    }
    function smoothFade(g) { return clamp(g * 3, 0, 1); }

    function common(st, p, e) {
        return { mesh: "", shader: "", entity: p.id, visible: true, samplers: { NoiseTex: NOISE }, ticks: 6, order: 10 };
    }
    function styleUniforms(s, alpha, growth, back) {
        return { Size: s.size, Growth: clamp(growth, 0, 1), Peaks: Math.max(1, Math.round(s.peaks)), WaveFrequency: s.waveFrequency, WaveAmplitude: s.waveAmplitude,
            NoiseDetail: s.noiseDetail, UpwardBias: s.upwardBias, CoreColor: s.coreColor, RimColor: s.rimColor, NoiseColor: s.noiseColor, NoiseFactor: s.noiseFactor,
            CoreAlpha: s.coreAlpha, RimAlpha: s.rimAlpha, RimPower: s.rimPower, RimThreshold: s.rimThreshold, Alpha: clamp(alpha, 0, 1), BackFace: back,
            BloomIntensity: s.bloomIntensity, BloomPass: 0 };
    }
    // lean: 90 - pitch in fast flight; a swimming body's aura lies along it (AuraRenderer.auraLeanDegrees)
    function leanExpr(fast, p) {
        if (fast) return { c: 90, k: { pitch: -1 } };
        if (p.inWater) return { c: -90, k: { pitch: -1 }, mul: { k: { swim: 1 } } };
        return { k: { swim: -90 } };
    }
    function growFn(prog) { return function (r0) { return { c: prog.c, k: prog.k, frac: true, mul: 3 * r0, add: r0 }; }; }
    function phaseExpr(phase, rate, now) { return { c: phase - rate * now, k: { clock: rate }, frac: true }; }

    function drawLayers(p, st, fx, layers, fast, laid, fp) {
        var ms = (Number(p.modelSize) || 1) * MODEL_SCALE, sm = surgeMult(p);
        var auraScale = (Number(fx.as) || 1.05) * sm.scale * ms;        // getAuraScale: base x surge x model scale
        var bbH = 1.8 * (Number(p.modelSize) || 1), now = RPG.shaders.clock(), used = {};
        layers.forEach(function (layer) {
            var m = st.motions[layer.layerId];
            if (!m) m = st.motions[layer.layerId] = { style: copy(layer.style), phase: 0 };
            else blendTowards(m.style, layer.style, 1 - Math.exp(-DT * STYLE_BLEND_RATE));
            m.phase = (m.phase + DT * m.style.waveSpeed * sm.speed) % 1;
            var s = m.style, id = "dmzaura_" + p.id + "_" + layer.layerId, spec = common(st, p), ops = [];
            var growth = st.growth, fade = smoothFade(growth);
            used[id] = true;
            if (layer.type === "sparking") {
                var boost = 1 + layer.layerId * 0.15, wb = 1 + layer.layerId * SPARKING_LAYER_WIDTH;
                var sx = auraScale * SPARKING_WIDTH * wb, sy = auraScale * SPARKING_HEIGHT * boost;
                if (laid) {
                    ops.push(["rotateY", { c: 180, k: { bodyYaw: -1 } }], ["translate", 0, bbH * 0.5, 0], ["rotateX", leanExpr(fast, p)], ["translate", 0, -SPARKING_CORE * sy, 0]);
                    if (fast) ops.push(["translate", 0, -AURA_3D_FLIGHT_LEAD, 0]);
                }
                ops.push(["scale", sx, sy, sx], ["translate", 0, SPARKING_PIVOT, 0]);
                // auraPhase / 10 (0.5 a tick, faster in a surge), then SPARKING_TIME_SCALE
                var rate = 0.5 / 10 * sm.speed * SPARKING_TIME_SCALE;
                st.sparkT = (st.sparkT === undefined ? p.tick * rate : st.sparkT + rate);
                var u = { Size: s.size, Time: { c: st.sparkT - rate * p.tick, k: { age: rate } }, Growth: clamp(growth, 0, 1), SpikeDensity: Math.max(4, Math.round(s.spikeDensity)),
                    SpikeBurstRate: s.spikeBurstRate, SpikeRarity: s.spikeRarity, BandStart: s.bandStart, WaveSpeed: s.waveSpeed, WaveAmplitude: s.waveAmplitude,
                    NoiseDetail: s.noiseDetail, CoreColor: s.coreColor, RimColor: s.rimColor, SecondBorderColor: s.secondBorderColor, SecondBorderFactor: s.secondBorderFactor,
                    CoreAlpha: s.coreAlpha, RimAlpha: s.rimAlpha, RimPower: s.rimPower, RimThreshold: s.rimThreshold,
                    Alpha: clamp((fp ? AURA_3D_FP_ALPHA : 1) * layer.alpha * fade, 0, 1), BackFace: fp ? AURA_3D_BACKFACE_FP : AURA_3D_BACKFACE,
                    BloomIntensity: s.bloomIntensity, BloomPass: 0 };
                spec.mesh = MESH.sparking; spec.shader = SH.sparking; spec.uniforms = u; spec.passes = [{ LayerPass: 1 }, { LayerPass: 0 }];
                delete spec.samplers;
            } else {
                var god = layer.type === "god", b = (1 + layer.layerId * 0.15) / SMOOTH_SCALE_REFERENCE, k = auraScale * b;
                ops.push(["rotateY", { c: 180, k: { bodyYaw: -1 } }]);
                if (laid) {
                    ops.push(["translate", 0, bbH * 0.5, 0], ["rotateX", leanExpr(fast, p)], ["translate", 0, -(god ? GOD_CENTER : SMOOTH_CENTER) * k, 0]);
                    if (fast) ops.push(["translate", 0, -SMOOTH_FLIGHT_LEAD, 0]);
                } else if (god) ops.push(["translate", 0, -GOD_WORLD_DROP * k, 0]);
                var alpha = (fp ? (god ? GOD_FP_ALPHA : SMOOTH_FP_ALPHA) : 1) * layer.alpha * fade;
                var u2 = styleUniforms(s, alpha, growth, fp ? BACKFACE_INSIDE : (god ? GOD_BACKFACE : SMOOTH_BACKFACE));
                u2.Time = { k: { age: 0.05 } };
                if (god) {
                    ops.push(["scale", k, k, k]);
                    u2.Hollow = 0;
                    spec.mesh = MESH.god; spec.shader = SH.god;
                    spec.passes = [{ Layer: 1, Faces: 1 }, { Layer: 0, Faces: 0 }, { Layer: 1, Faces: 2 }];
                } else {
                    ops.push(["translate", 0, SMOOTH_CENTER * k, 0], ["scale", SMOOTH_RADIUS * k, SMOOTH_HALF_HEIGHT * k, SMOOTH_RADIUS * k]);
                    u2.Phase = phaseExpr(m.phase, m.style.waveSpeed * sm.speed, now);
                    spec.mesh = MESH.droplet; spec.shader = SH.smooth; spec.passes = [];
                }
                spec.uniforms = u2;
            }
            spec.ops = ops;
            spec.bloom = { BloomPass: 1 };
            spec.order = 10 + layer.layerId;
            RPG.shaders.draw(id, spec);
        });
        // the ground pulses under the top layer (renderShaderPulseAura / drawSinglePulse3D)
        var top = layers[layers.length - 1];
        if (top && p.onGround) {
            var tm = st.motions[top.layerId];
            for (var n = 0; n < 2; n++) {
                var pid = "dmzaura_" + p.id + "_pulse" + n, sp = common(st, p), lb = 1 + top.layerId * 0.15;
                used[pid] = true;
                var width = top.type === "sparking" ? SPARKING_WIDTH : 0.9;
                var R = auraScale * lb * width * 0.75, H = auraScale * 0.22;
                var prog = { c: st.pulse + 0.5 * n - PULSE_RATE * now, k: { clock: PULSE_RATE }, frac: true };
                var grow = growFn(prog);
                var a = { c: prog.c, k: prog.k, frac: true, sin: true, mul: 0.5 * top.alpha * smoothFade(st.growth) * (top.type === "god" ? GOD_PULSE_ALPHA : 1) };
                var ops2 = [["translate", 0, 0.05, 0], ["rotateY", { k: { gameTime: 2.5 } }]];
                if (top.type === "god") {
                    ops2.push(["scale", grow(R * GOD_PULSE_WIDTH), H * GOD_PULSE_HEIGHT, grow(R * GOD_PULSE_WIDTH)]);
                    var gu = styleUniforms(tm.style, 1, 1, GOD_BACKFACE);
                    gu.Time = { k: { age: 0.05 } }; gu.Alpha = a; gu.Hollow = 1; gu.Layer = 1; gu.Faces = 0;
                    sp.mesh = MESH.god; sp.shader = SH.god; sp.uniforms = gu; sp.passes = [];
                } else if (top.type === "sparking") {
                    ops2.push(["scale", grow(R), H, grow(R)], ["translate", 0, 0.9, 0]);
                    var r2 = 0.5 / 10 * SPARKING_PULSE_TIME_SCALE * surgeMult(p).speed, s2 = tm.style;
                    sp.mesh = MESH.sparking; sp.shader = SH.sparking; delete sp.samplers;
                    sp.uniforms = { Size: s2.size, Time: { k: { age: r2 } }, Growth: 1, SpikeDensity: Math.max(4, Math.round(s2.spikeDensity)), SpikeBurstRate: s2.spikeBurstRate,
                        SpikeRarity: s2.spikeRarity, BandStart: s2.bandStart, WaveSpeed: s2.waveSpeed, WaveAmplitude: s2.waveAmplitude, NoiseDetail: s2.noiseDetail,
                        CoreColor: s2.coreColor, RimColor: s2.rimColor, SecondBorderColor: s2.secondBorderColor, SecondBorderFactor: s2.secondBorderFactor,
                        CoreAlpha: s2.coreAlpha, RimAlpha: s2.rimAlpha, RimPower: s2.rimPower, RimThreshold: s2.rimThreshold, Alpha: a, BackFace: AURA_3D_BACKFACE,
                        BloomIntensity: s2.bloomIntensity, BloomPass: 0 };
                    sp.passes = [{ LayerPass: 1 }, { LayerPass: 0 }];
                } else {
                    ops2.push(["scale", grow(R), H, grow(R)], ["translate", 0, 0.9, 0]);
                    var su = styleUniforms(tm.style, 1, 1, SMOOTH_BACKFACE);
                    su.Time = { k: { age: 0.05 } }; su.Alpha = a; su.Phase = phaseExpr(tm.phase, tm.style.waveSpeed * surgeMult(p).speed, now);
                    sp.mesh = MESH.droplet; sp.shader = SH.smooth; sp.uniforms = su; sp.passes = [];
                }
                sp.ops = ops2;
                sp.bloom = { BloomPass: 1 };
                sp.order = 5;
                RPG.shaders.draw(pid, sp);
            }
        }
        return used;
    }

    // the 2D aura in your own first person: a screen card 0.7 in front, 0.6 below, scaled by the aura (AuraRenderer)
    function drawFlatOverlay(p, st, fx, layers) {
        var used = {}, ms = (Number(p.modelSize) || 1) * MODEL_SCALE, sm = surgeMult(p);
        var base = (Number(fx.as) || 1.05) * sm.scale;               // auraScale / modelScale
        st.flatAlpha = Math.min(1, (st.flatAlpha || 0) + FLAT_FADE * DT);
        st.flatPhase = (st.flatPhase || 0) + 0.5 * sm.speed;           // auraPhase: 0.5 a tick
        layers.forEach(function (layer) {
            var c = layer.color, fin = 0.5 * st.flatAlpha * layer.alpha, sc = base * 2.2 * (1 + layer.layerId * 0.15) * 3;
            var colors = { color1: [lerp(c[0], 1, 0.55), lerp(c[1], 1, 0.55), lerp(c[2], 1, 0.55), 1], color2: [c[0] * 1.75, c[1] * 1.75, c[2] * 1.75, 1],
                color3: [c[0] * 1.45, c[1] * 1.45, c[2] * 1.45, 0.95], color4: [c[0] * 1.1, c[1] * 1.1, c[2] * 1.1, 0.8] };
            var speed = { c: st.flatPhase - 0.5 * sm.speed * p.tick, k: { age: 0.5 * sm.speed } };
            var sheet = String(layer.t2 || "kakarot"), tex = sheet.indexOf(":") > 0 ? sheet : AURA_TEX + sheet + "_aura.png";
            [["main", tex, [sc, sc, 1]], ["spark", AURA_TEX + "sparking_effects.png", [sc * 0.6, sc * 0.45, 1]]].forEach(function (q) {
                var id = "dmzaura_" + p.id + "_fp" + layer.layerId + q[0];
                used[id] = true;
                var u = { speed: speed, alp1: fin * 0.45, bloomMode: 0 };
                for (var k in colors) u[k] = colors[k];
                RPG.shaders.draw(id, { mesh: MESH.quad, shader: SH.flat, anchor: "view", x: 0, y: -0.6, z: -0.7, ops: [["scale", q[2][0], q[2][1], 1]],
                    modelUniform: "modelMatrix", uniforms: u, samplers: { Sampler0: q[1] }, view: "first", entity: p.id, ticks: 6, order: 30 + layer.layerId });
            });
        });
        return used;
    }

    function threeD(p) {
        // whose 3D style shows here: your own choice, others' when "Enemy Auras - 3D Style" is on
        if (!p.local && typeof DMZ_AURAS !== "undefined" && !DMZ_AURAS.others()) return false;
        return true;
    }

    RPG.on("tick", function () {
        if (!RPG.player.present || !RPG.avatar) return;
        var seen = {};
        RPG.avatar.players().forEach(function (p) {
            var fx = p.shared("dmzAuraFx", null);
            if (!fx || typeof fx !== "object") return;
            var st = ST[p.id];
            var on = !!fx.v && !p.invisible && !p.spectator;
            if (!on && !st) return;
            var pref = String(fx.pref || "");
            if (!pref || !threeD(p)) {
                // 2D aura: the engine draws it; in your own first person, DMZ's screen overlay
                if (st) { RPG.shaders.removePrefix("dmzaura_" + p.id + "_"); delete ST[p.id]; }
                if (on && p.local && p.firstPerson && setup()) {
                    st = ST[p.id] = ST[p.id] || { growth: 0, motions: {}, flatOnly: true };
                    st.flatOnly = true;
                    var used2 = drawFlatOverlay(p, st, fx, layersFor(fx));
                    seen[p.id] = true;
                    st.used = used2;
                }
                return;
            }
            if (!setup()) return;
            if (!st || st.flatOnly) { if (st) RPG.shaders.removePrefix("dmzaura_" + p.id + "_"); st = ST[p.id] = { growth: 0, motions: {}, pulse: 0 }; }
            st.growth = on ? Math.min(1, st.growth + DT * GROWTH_RATE) : Math.max(0, st.growth - DT * SHRINK_RATE);
            if (st.growth <= 0 && !on) { RPG.shaders.removePrefix("dmzaura_" + p.id + "_"); delete ST[p.id]; RPG.auras.suppress(p.id, 0); return; }
            seen[p.id] = true;
            RPG.auras.suppress(p.id, 4);
            var layers = st.layers = on ? layersFor(fx) : (st.layers || layersFor(fx));
            var fast = !!p.shared("flyFast", null), laid = fast || p.swimming || p.crawling, fp = p.local && p.firstPerson;
            var used = drawLayers(p, st, fx, layers, fast, laid, fp);
            for (var id in (st.used || {})) if (!used[id]) RPG.shaders.remove(id);
            st.used = used;
        });
        for (var pid in ST) if (!seen[pid]) { RPG.shaders.removePrefix("dmzaura_" + pid + "_"); delete ST[pid]; }
    });
    RPG.on("unload", function () { ST = {}; ready = false; failed = false; stage = 0; });

    return { layersFor: layersFor, resolve: resolve, ready: function () { return ready; } };
})();
