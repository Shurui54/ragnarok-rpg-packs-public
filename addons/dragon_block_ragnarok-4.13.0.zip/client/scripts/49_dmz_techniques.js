// =====================================================================================
//  DMZ techniques on the client: state from the server (41_dmz_techniques.js), the
//  "technique learned" pop-up, DMZ's TechniqueHotbarHUD and TechniqueChargeOverlay, and the
//  Solar Flare blind screen. Port of DragonMine Z (GPL-3.0).
//
//  Hotbar (TechniqueHotbarHUD): hold Left Alt to see slots 1-4, Ctrl for 5-8 (the bars of the
//  Alt+1..4 / Ctrl+1..4 keys). Bottom-left ladder of 4 rows: an 11x11 key badge, the name in
//  DMZ's font (grey while cooling) and the cooldown "%.1fs" in FFD200. With no modifier held,
//  the slot with the shortest cooldown in each row lingers at 55 % and blinks 3x when ready.
//  Charge bar (TechniqueChargeOverlay): kicharge_hud.png centred at H - 72, scale 1.125, fill
//  tinted with the technique's border colour, overcharge (100-175 %) at half brightness.
//  Both are movable in the HUD editor ("Techniques", "Technique charge").
//
//  DMZ_TECH_CLIENT (for screens and the radial menu):
//     .state            { u: {id: {x, d, c, r}}, s: [8 ids], cd: {id: ticks}, info: {id: {...}}, kc, fl, race, android }
//     .name(id)         translated technique name     .cooldown(id) seconds left   .unlocked(kind?) ids
//     .equip(slot, id)  .forget(id)   .upgrade(id, stat)   .request()   .kindOf(id)
// =====================================================================================
var DMZ_TECH_CLIENT = (function () {
    var TD = DMZ_TECH_DATA, FONT = "dmzpack:smooth";
    var state = { u: {}, s: ["", "", "", "", "", "", "", ""], cd: {}, info: {}, kc: false, fl: false, race: "human", android: false, at: 0 };
    var charge = { pct: 0, id: "", c: false };
    var listeners = [];

    RPG.net.on("dmz_tech_state", function (d) {
        if (!d) return;
        state.u = d.u || {}; state.s = d.s || state.s; state.cd = d.cd || {}; state.info = d.info || {};
        state.kc = !!d.kc; state.fl = !!d.fl; state.race = d.race || "human"; state.android = !!d.android;
        state.at = RPG.nowMs();
        listeners.forEach(function (fn) { try { fn(state); } catch (e) { } });
    });
    RPG.net.on("dmz_tech_charge", function (d) { if (d) { charge.pct = Number(d.pct) || 0; charge.id = d.id || ""; charge.c = !!d.c; } });

    function tr(key, fallback) { return RPG.hasTranslation(key) ? RPG.translate(key) : fallback; }
    function name(id) {
        if (!id) return "";
        var k = TD.nameKey(id);
        if (k) return tr(k, TD.english(id));
        var n = RPG.defName("skill", id);
        return n || id;
    }
    function kindOf(id) {
        var k = TD.kind(id);
        if (k) return k;
        var kd = String(RPG.defField("skill", id, "kind") || "");
        return kd === "ki" ? "ki" : kd === "strike" ? "strike" : "evasion";
    }
    function cooldown(id) {
        var t = Number(state.cd[id]) || 0;
        if (t <= 0) return 0;
        return Math.max(0, t / 20 - (RPG.nowMs() - state.at) / 1000);
    }
    function unlocked(kind) { return Object.keys(state.u).filter(function (id) { return !kind || kindOf(id) === kind; }); }
    function equip(slot, id) { RPG.net.send("dmz_tech", { action: "equip", slot: slot, id: id || "" }); }
    function forget(id) { RPG.net.send("dmz_tech", { action: "forget", id: id }); }
    function upgrade(id, stat) { RPG.net.send("dmz_tech", { action: "upgrade", id: id, stat: stat }); }
    function request() { RPG.net.send("dmz_tech", { action: "state" }); }
    function typeLabel(id) {
        var k = TD.kind(id);
        if (k === "ki") return tr("technique.type." + TD.KI[id].type.toLowerCase(), TD.KI[id].type);
        if (k === "strike") return tr("technique.type.strike", "Strike");
        if (k === "evasion") return tr("technique.type.evasion", "Evasion");
        return "";
    }

    // ---- numbers for techniques we haven't learned yet (masters' shop), from the synced stats ----
    function view(noForms) {
        var mult = RPG.getVar("dmz_mult", null) || {}, fb = RPG.getVar("dbr_form_buff", null);
        return { stat: function (k) { return RPG.player.stat(DMZ_DATA.STAT_IDS[k]); }, cls: RPG.player.playerClass || "warrior",
            bonus: function (k) { return fb ? Number(fb[k === "DEF" || k === "STM" ? "RES" : k]) || 0 : 0; },
            release: Number(RPG.getVar("dmz_release", 0)) || 0, mult: function (k) { return !noForms && typeof mult[k] === "number" ? mult[k] : 1; } };
    }
    function preview(id) {
        var k = TD.kind(id), v = view(false), nf = view(true), out = { kind: k };
        if (k === "ki") {
            var T = TD.KI[id];
            out.dmg = Math.floor(DMZ_F.ki(v) * T.dmg); out.cost = TD.kiCost(id, DMZ_F.ki(nf)); out.cd = TD.kiCooldown(id, 1, 0);
            out.cast = TD.TYPES[T.type].cast;
        } else if (k === "strike") {
            out.dmg = Math.floor(DMZ_F.strike(v) * TD.STRIKE[id].dmg); out.cost = TD.strikeCost(id, DMZ_F.strike(nf), 0); out.cd = TD.strikeCooldown(id, 0); out.cast = 0;
        } else if (k === "evasion") {
            out.dmg = Math.floor(TD.evasionHit(id, v.stat("SKP"), v.stat("PWR"))); out.cost = TD.evasionCost(id, v.stat("SKP"), v.stat("PWR"), 0);
            out.cd = TD.evasionCooldown(id, 0); out.dur = TD.evasionDuration(id, 0);
        }
        return out;
    }

    // ---- the pop-up when a technique is learned (DMZ's NotificationHUD card + chime) ----
    RPG.net.on("dmz_tech_learned", function (d) {
        if (!d || !d.id || typeof DMZ_NOTIFY === "undefined") return;
        var tab = d.kind === "strike" ? tr("gui.dragonminez.skills.tab.strikeattacks", "Strike Attacks")
            : d.kind === "evasion" ? tr("gui.dragonminez.skills.tab.evasionattacks", "Evasion Attacks") : tr("gui.dragonminez.skills.tab.kiattacks", "Ki Attacks");
        DMZ_NOTIFY.push({
            title: tr("gui.dbr.technique.learned", "Technique Learned"),
            subtitle: name(d.id),
            description: tr("gui.dbr.technique.learned.hint", "Skills > " + tab + " > " + tr("gui.dragonminez.skills.bind_to_slot", "Bind to Slot")),
            extra: typeLabel(d.id)
        }, DMZ_NOTIFY.PRIORITY.NORMAL);
        if (RPG.nowMs() - lastChime > 200) RPG.sound("minecraft:block.note_block.chime", 1.0, 1.2);   // one chime for a batch
        lastChime = RPG.nowMs();
    });
    var lastChime = 0;

    // ---- Solar Flare: the blind screen (TaiyokenBlindS2C) ----
    var blind = { until: 0, total: 1 };
    RPG.net.on("dmz_taiyoken", function (d) { var t = Math.max(1, Number(d && d.ticks) || 60) * 50; blind.until = RPG.nowMs() + t; blind.total = t; });

    // ---------------------------------------------------------------------------------
    //  TechniqueHotbarHUD
    // ---------------------------------------------------------------------------------
    var BAR = TD.BAR_SLOTS, BADGE = 11, GAP = 5, COOLDOWN_ALPHA = 0.55, READY_LINGER = 1500, READY_BLINK = 750, READY_BLINKS = 3;
    var SKILL_SCALE = 1.25, LADDER = 8, MARGIN_X = 12, MARGIN_BOTTOM = 66, ROW_W = 120, ROW_H = 13;
    function Smoother(tau, eps) { this.tau = tau; this.eps = eps; this.init = false; this.value = 0; this.last = 0; }
    Smoother.prototype.update = function (t) {
        var now = RPG.nowMs();
        if (!this.init) { this.init = true; this.value = t; this.last = now; return t; }
        var dt = Math.min(0.25, (now - this.last) / 1000);
        this.last = now;
        if (dt <= 0) return this.value;
        this.value += (t - this.value) * (1 - Math.exp(-dt / this.tau));
        if (Math.abs(t - this.value) <= this.eps) this.value = t;
        return this.value;
    };
    var VIEWS = [];
    for (var vi = 0; vi < TD.SLOT_COUNT; vi++) VIEWS.push({ alpha: new Smoother(0.06, 0.01), id: null, cooling: false, seconds: 0, readyAt: -1 });

    function created() { return !!RPG.getVar("dmz_created", 0); }
    function down(k) { return RPG.isKeyDown(k); }
    // the bars open while the modifier of their keys is held (Alt for slots 1-4, Ctrl for 5-8 unless rebound)
    function modOf(n, fallback) { return typeof RPG.actionKeyModifier === "function" ? RPG.actionKeyModifier(n) : fallback; }
    function modHeld(m) {
        if (m === "alt") return down("key.keyboard.left.alt") || down("key.keyboard.right.alt");
        if (m === "ctrl") return down("key.keyboard.left.control") || down("key.keyboard.right.control");
        if (m === "shift") return down("key.keyboard.left.shift") || down("key.keyboard.right.shift");
        return false;
    }
    function openBar() {
        if (modHeld(modOf(5, "ctrl"))) return 1;
        if (modHeld(modOf(1, "alt"))) return 0;
        return -1;
    }
    // the badge shows the slot's real key ("1", "G"...) when the engine can tell us
    function badgeText(slot) {
        if (typeof RPG.actionKey !== "function") return String(slot % BAR + 1);
        var k = String(RPG.actionKey(slot + 1)), last = k.substring(k.lastIndexOf(".") + 1);
        return last === "unknown" ? "-" : last.length <= 2 ? last.toUpperCase() : last.charAt(0).toUpperCase();
    }
    function lingering(row) {
        var best = -1, bs = 1e9;
        for (var slot = row; slot < TD.SLOT_COUNT; slot += BAR) {
            var v = VIEWS[slot];
            if (!v.id || (!v.cooling && v.readyAt < 0)) continue;
            var s = v.cooling ? v.seconds : 0;
            if (s < bs) { best = slot; bs = s; }
        }
        return best;
    }
    function drawRow(ctx, x, y, scale, slot, v, a, preview) {
        ctx.push();
        ctx.translate(x, y);
        ctx.scale(scale, scale);
        var by = Math.round((ROW_H - BADGE) / 2), ty = Math.round((ROW_H - 9) / 2);
        ctx.fill(0, by, BADGE, BADGE, "#000000", 0.69 * a);                              // B0000000
        ctx.fill(0, by, BADGE, 1, "#FFFFFF", 0.4 * a); ctx.fill(0, by + BADGE - 1, BADGE, 1, "#FFFFFF", 0.4 * a);
        ctx.fill(0, by + 1, 1, BADGE - 2, "#FFFFFF", 0.4 * a); ctx.fill(BADGE - 1, by + 1, 1, BADGE - 2, "#FFFFFF", 0.4 * a);
        ctx.textStyled(badgeText(slot), BADGE / 2 + 0.5, by + 2, 1, "#FFFFFF", a, 0.5, FONT, null);
        var label = v.id ? name(v.id) : preview ? tr("gui.dragonminez.hud_editor.skill_sample", "Technique %s").replace("%s", String(slot % BAR + 1)) : null;
        if (label) {
            var nx = BADGE + GAP;
            ctx.textStyled(label, nx, ty, 1, v.cooling ? "#8A8A8A" : "#FFFFFF", a, 0, FONT, null);
            if (v.cooling && v.seconds > 0.05) ctx.textStyled(v.seconds.toFixed(1) + "s", nx + ctx.textWidthIn(label, FONT) + GAP, ty, 1, "#FFD200", a, 0, FONT, null);
        }
        ctx.pop();
    }
    function renderHotbar(ctx) {
        if (!RPG.player.present || !created()) return;
        var W = ctx.width, H = ctx.height, unit = Math.max(0.25, H / 360), sc = SKILL_SCALE * unit, rowH = ROW_H * sc;
        var gx = MARGIN_X * unit, gy = H - MARGIN_BOTTOM * unit - 4 * rowH, gw = (LADDER * 3) * unit + ROW_W * sc, gh = 4 * rowH;
        var preview = ctx.isEditing();
        if (!ctx.group("dmz_techniques", "Techniques", gx, gy, gw, gh)) return;
        var bar = preview ? 0 : openBar(), now = RPG.nowMs();
        for (var i = 0; i < TD.SLOT_COUNT; i++) {
            var v = VIEWS[i], id = state.s[i] || "", cd = id ? cooldown(id) : 0, cooling = cd > 0;
            if (id !== v.id) v.readyAt = -1;
            else if (v.cooling && !cooling) v.readyAt = now;
            if (cooling) v.readyAt = -1;
            if (v.readyAt >= 0 && now - v.readyAt >= READY_LINGER) v.readyAt = -1;
            v.id = id; v.cooling = cooling; v.seconds = cd;
        }
        for (var row = 0; row < BAR; row++) {
            var linger = bar < 0 ? lingering(row) : -1;
            var rx = gx + LADDER * row * unit, ry = gy + row * rowH;
            for (var b = 0; b < TD.SLOT_COUNT / BAR; b++) {
                var slot = b * BAR + row, view = VIEWS[slot];
                var target = bar === b ? 1 : slot === linger ? COOLDOWN_ALPHA : 0;
                var a = preview ? target : view.alpha.update(target);
                if (slot === linger && view.readyAt >= 0) {
                    var el = now - view.readyAt;
                    if (el < READY_BLINK) { var pulse = Math.abs(Math.sin(Math.PI * READY_BLINKS * el / READY_BLINK)); a = a + (1 - a) * pulse; }
                }
                if (a <= 0.02) continue;
                drawRow(ctx, rx, ry, sc, slot, view, a, preview);
            }
        }
        ctx.endGroup();
    }

    // ---------------------------------------------------------------------------------
    //  TechniqueChargeOverlay
    // ---------------------------------------------------------------------------------
    var CHARGE_TEX = "dmzpack:textures/gui/hud/kicharge_hud.png", shown = 0;
    function dim(hex, f) {
        var n = parseInt(String(hex).replace("#", ""), 16) || 0xFFFFFF;
        var r = Math.floor(((n >> 16) & 255) * f), g = Math.floor(((n >> 8) & 255) * f), b = Math.floor((n & 255) * f);
        return "#" + ("000000" + ((r << 16) | (g << 8) | b).toString(16)).slice(-6);
    }
    function renderCharge(ctx) {
        if (!RPG.player.present || !created()) return;
        var editing = ctx.isEditing();
        var T = TD.KI[charge.id];
        var active = T && !TD.isInstant(charge.id) && (charge.pct > 0 || charge.c);
        if (!active) shown = 0;
        if (!active && !editing) return;
        var W = ctx.width, H = ctx.height, scale = 1.125, barW = Math.round(148 * scale);
        var x = (W - barW) / 2, y = H - 72, top = y - 4 - 9 - 2 - 9;
        if (!ctx.group("dmz_tech_charge", "Technique charge", x, top, barW, y + 14 * scale - top)) return;
        var target = editing && !active ? 60 : charge.pct;
        var lerped = shown + (target - shown) * 0.2;
        if (Math.abs(lerped - target) <= 0.3) lerped = target;
        shown = Math.max(0, Math.min(200, lerped));
        var color = T ? T.colors.border : "#29D8FF";
        var normal = Math.round(148 * Math.max(0, Math.min(1, shown / 100)));
        var over = Math.round(148 * Math.max(0, Math.min(1, (shown - 100) / Math.max(1, TD.OVERCHARGE_MAX - 100))));
        ctx.push();
        ctx.translate(x, y);
        ctx.scale(scale, scale);
        ctx.quad(CHARGE_TEX, 0, 0, 145, 14, 0, 0, 145 / 256, 14 / 256, "#FFFFFF", 1);
        if (normal > 0) ctx.quad(CHARGE_TEX, 0, 0, normal, 14, 0, 14 / 256, normal / 256, 28 / 256, color, 1);
        if (over > 0) ctx.quad(CHARGE_TEX, 0, 0, over, 14, 0, 14 / 256, over / 256, 28 / 256, dim(color, 0.5), 1);
        ctx.pop();
        var charging = shown < 99.99;
        var hint = charging ? tr("technique.charge.charging", "Charging - hold to overcharge") : tr("technique.charge.overcharging", "Overcharging - release to fire");
        var col = charging ? "#FFFFFF" : "#FFD200";
        var pctY = y - 4 - 9, hintY = pctY - 2 - 9;
        ctx.textAt(hint, W / 2, hintY, 1, col, 1, "center", true);
        ctx.textStyled(Math.round(shown) + "%", W / 2, pctY, 1, col, 1, 0.5, FONT, null);
        ctx.endGroup();
    }

    function renderBlind(ctx) {
        var left = blind.until - RPG.nowMs();
        if (left <= 0) return;
        ctx.fill(0, 0, ctx.width, ctx.height, RPG.storage.get("dmz_cfg_taiyoken_invert", false) ? "#000000" : "#FFFFFF", Math.min(1, left / Math.max(1, blind.total) * 1.6) * 0.95);
    }

    RPG.on("load", function () {
        RPG.hud.onRender(renderHotbar);
        RPG.hud.onRender(renderCharge);
        RPG.hud.onRender(renderBlind);
        RPG.schedule(20, request);
    });

    return { state: state, charge: charge, name: name, kindOf: kindOf, cooldown: cooldown, unlocked: unlocked, equip: equip, forget: forget,
        upgrade: upgrade, request: request, typeLabel: typeLabel, preview: preview, onState: function (fn) { listeners.push(fn); } };
})();
