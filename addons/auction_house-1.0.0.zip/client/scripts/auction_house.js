// =====================================================================================
//  Auction House - the screen (Browse | My Listings | Claim)
// =====================================================================================
//  Only draws what the server sends and asks the server to act; every action is checked
//  there. Layout: a 300 x 260 vanilla window (the engine's ctx.panel/button/field/slot/scrollbar pieces), a tab
//  row, item rows in a recessed list with Bid / Buy Now, and a footer form.
// =====================================================================================
(function () {
    var NS = "auction_house";
    // vanilla text colours: dark grey on the grey window, light ones in the black list
    var COL = { title: "#FF404040", label: "#FF404040", hint: "#FF6F6F6F", value: "#FFFFFF55", row: "#FFE0E0E0", off: "#FF808080",
        muted: "#FFA0A0A0", bad: "#FFFF5555", good: "#FF55FF55", badW: "#FFAA0000", goodW: "#FF00AA00" };
    var UW = 300, UH = 260, FOOT = 238, ROWH = 22, ROWS = 7, CTRL = 219;
    var SORTS = [["ending_soon", "Ending soon"], ["newest", "Newest"], ["price_low", "Price: low"], ["price_high", "Price: high"]];
    var CATS = [["all", "All items"], ["weapons", "Weapons"], ["armor", "Armour"], ["tools", "Tools"], ["blocks", "Blocks"], ["food", "Food"],
        ["potions", "Potions"], ["books", "Books"], ["misc", "Misc"]];
    var TABS = ["Browse", "My Listings", "Claim"];

    // tab and sort survive closing and reopening, so a bid never bounces you back to Browse
    var S = { tab: 0, sort: "ending_soon", cat: "all", q: "", off: 0, dur: 0, d: null, at: 0, note: "", bad: false, noteAt: 0,
        dd: null, drag: false, hits: [], ox: 0, oy: 0, closing: false, typed: 0 };

    // ---- small helpers -------------------------------------------------------------------------------

    function num(n) { return String(Math.floor(n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
    function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
    function plain(s) { return String(s || "").replace(/&[0-9a-fk-or]/gi, ""); }
    function left(ms) {
        if (ms <= 0) return "expired";
        let m = Math.floor(ms / 60000), d = Math.floor(m / 1440), h = Math.floor(m % 1440 / 60), mm = m % 60;
        if (d > 0) return d + "d " + h + "h";
        if (h > 0) return h + "h " + mm + "m";
        if (mm > 0) return mm + "m";
        return "<1m";
    }
    function val(id) { let v = RPG.screen.value(id); return v === null || v === undefined ? "" : String(v).trim(); }
    function intOf(s) { s = String(s).replace(/[, _]/g, ""); return /^\d{1,15}$/.test(s) ? parseInt(s, 10) : NaN; }
    function send(d) { RPG.net.send("ah", d); }
    function note(text, bad) { S.note = text || ""; S.bad = !!bad; S.noteAt = RPG.nowMs(); }
    function isOpen() { return RPG.screen.getOpen() === "auction_house"; }
    function listTop() { return S.tab === 0 ? 61 : 48; }
    function cur() { return S.d ? S.d.currency : ""; }
    function sound(id) { RPG.sound(id || "minecraft:ui.button.click", 0.25, 1); }

    // ---- drawing kit: the engine's vanilla pieces ------------------------------------------------------------

    function box(ctx, x, y, w, h) { ctx.field(x, y, w, h, false); }
    function fit(ctx, text, w) {
        text = String(text);
        if (ctx.textWidth(text) <= w) return text;
        while (text.length > 1 && ctx.textWidth(text + "...") > w) text = text.substring(0, text.length - 1);
        return text + "...";
    }
    function label(ctx, text, x, y, color, w) { ctx.text(w ? fit(ctx, text, w) : String(text), x, y, color, false); }
    function centered(ctx, text, cx, y, color) { ctx.text(text, Math.round(cx - ctx.textWidth(text) / 2), y, color, false); }
    function over(mx, my, x, y, w, h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    /** A vanilla button; registers its click area. */
    function button(ctx, mx, my, x, y, w, h, text, fn, disabled) {
        ctx.button(fit(ctx, text, w - 8), x, y, w, h, !disabled && !S.dd);
        S.hits.push({ x: x, y: y, w: w, h: h, fn: disabled ? null : fn, sound: true });
    }
    /** The engine's searchable dropdown (a vanilla text-field box). */
    function dropEl(list, id, x, y, w, h, options, onPick) {
        return el(list, { id: id, type: "dropdown", x: x, y: y, w: w, h: h, options: options, value: options.length ? options[0].value : null, visible: false,
            padding: 4, rowHeight: 13, onChange: (eid, v) => { sound(); onPick(v); } });
    }
    function scrollbar(ctx, x, top, h, total, rows, off) {
        if (total <= rows) return;
        let max = total - rows, th = Math.max(8, Math.round(h * rows / total));
        ctx.scrollbar(x, top, 12, h, off / max, rows / total);
        S.bar = { x: x, top: top, h: h, th: th, max: max };
    }

    // ---- the screen ------------------------------------------------------------------------------------

    function el(list, e) { e.anchor = "center"; e.x = -UW / 2 + e.x; e.y = -UH / 2 + e.y; list.push(e); return e; }

    function build() {
        let els = [];
        // the window, the recessed list and the slots are elements, so they draw under the item icons; the rest is drawn in onRender
        el(els, { id: "win", type: "panel", x: 0, y: 0, w: UW, h: UH });
        el(els, { id: "list", type: "panel", style: "inset", x: 8, y: 0, w: 270, h: ROWS * ROWH });
        for (let i = 0; i < ROWS; i++) {
            el(els, { id: "sl" + i, type: "panel", style: "slot", x: 10, y: 0, w: 18, h: 18, visible: false });
            el(els, { id: "it" + i, type: "item", item: "minecraft:stone", x: 11, y: 0, w: 16, h: 16, tooltip: "item", visible: false });
        }
        el(els, { id: "slh", type: "panel", style: "slot", x: 10, y: 218, w: 18, h: 18, visible: false });
        el(els, { id: "ith", type: "item", item: "minecraft:stone", x: 11, y: 219, w: 16, h: 16, tooltip: "item", visible: false });
        el(els, { id: "q", type: "input", x: 14, y: 48, w: 152, h: 9, bordered: false, maxLength: 40, value: S.q, hint: "&7Search items or sellers",
            onChange: () => { S.typed = RPG.time(); } });
        el(els, { id: "amt", type: "input", x: 182, y: CTRL + 2, w: 82, h: 9, bordered: false, maxLength: 15, hint: "&7amount" });
        el(els, { id: "start", type: "input", x: 60, y: 206, w: 52, h: 9, bordered: false, maxLength: 15 });
        el(els, { id: "buynow", type: "input", x: 180, y: 206, w: 52, h: 9, bordered: false, maxLength: 15, hint: "&7optional" });
        // category, sort and duration: searchable pick lists
        dropEl(els, "dd_cat", 176, 46, 102, 11, CATS.map((c) => ({ value: c[0], label: c[1] })), (v) => { S.cat = v; S.off = 0; request(); });
        dropEl(els, "dd_sort", 10, CTRL, 96, 11, SORTS.map((c) => ({ value: c[0], label: c[1] })), (v) => { S.sort = v; S.off = 0; request(); });
        dropEl(els, "dd_dur", 240, 204, 38, 11, [], (v) => { S.dur = v; });
        S.closing = false;
        // GUI pixels like a chest screen; only a window too small for the panel scales it down to fit
        RPG.screen.open({ id: "auction_house", referenceHeight: RPG.screenHeight < UH + 4 ? UH + 4 : 0, title: "Auction House", background: "dim", elements: els, onRender: render,
            onMouse: mouse, onScroll: scroll, onKey: key, onClose: () => {
                S.dd = null;
                if (!S.closing) send({ a: "close" });
            } });
        syncElements();
    }

    /** Put the item icons and inputs where the current tab wants them. */
    function syncElements() {
        if (!isOpen() || !S.d) return;
        let d = S.d, top = listTop(), hide = !!S.dd;
        RPG.screen.update("list", { y: -UH / 2 + top });
        for (let i = 0; i < ROWS; i++) {
            let r = d.rows[i], st = r ? r.item : null, y = -UH / 2 + top + i * ROWH + 2;
            RPG.screen.update("sl" + i, { visible: !!st, y: y });
            if (st) RPG.screen.update("it" + i, { visible: !hide, y: y + 1, item: st.id, count: st.count, nbt: st.nbt || "", tooltip: hide ? null : "item" });
            else RPG.screen.update("it" + i, { visible: false });
        }
        let held = S.tab === 1 && d.held;
        RPG.screen.update("slh", { visible: !!held });
        if (held) RPG.screen.update("ith", { visible: !hide, item: held.id, count: held.count, nbt: held.nbt || "", tooltip: hide ? null : "item" });
        else RPG.screen.update("ith", { visible: false });
        RPG.screen.update("q", { visible: S.tab === 0 });
        RPG.screen.update("amt", { visible: S.tab === 0 && d.bidding });
        RPG.screen.update("start", { visible: S.tab === 1 });
        RPG.screen.update("buynow", { visible: S.tab === 1 && d.bidding && d.buyNow });
        RPG.screen.update("dd_cat", { visible: S.tab === 0, value: S.cat });
        RPG.screen.update("dd_sort", { visible: S.tab === 0, value: S.sort });
        let durs = d.durations || [];
        if (durs.length > 1 && (!S.dur || durs.indexOf(S.dur) < 0)) S.dur = d.dur;
        RPG.screen.update("dd_dur", { visible: S.tab === 1 && durs.length > 1, options: durs.map((h) => ({ value: h, label: h + "h" })), value: S.dur, listWidth: 60 });
    }

    function request(extra) {
        let d = { a: "view", tab: S.tab, sort: S.sort, cat: S.cat, q: S.q, off: S.off, rows: ROWS };
        if (extra) Object.keys(extra).forEach((k) => { d[k] = extra[k]; });
        send(d);
    }
    function setTab(i) { if (S.tab === i) return; S.tab = i; S.off = 0; S.dd = null; note(""); request(); }

    function render(ctx) {
        let d = S.d;
        if (!d) return;
        S.ox = Math.round(ctx.width / 2 - UW / 2); S.oy = Math.round(ctx.height / 2 - UH / 2);
        let mx = ctx.mouseX - S.ox, my = ctx.mouseY - S.oy;
        S.hits = []; S.bar = null;
        ctx.push(); ctx.translate(S.ox, S.oy);

        // header: title left, wallet right
        label(ctx, "Auction House", 8, 9, COL.title);
        let bal = num(d.balance) + " " + d.currency;
        ctx.text(bal, UW - 8 - ctx.textWidth(bal), 9, COL.title, false);

        // tabs (claim tab shows how many payouts are waiting)
        let cw = Math.floor((280 - 4) / 3);
        TABS.forEach((t, i) => {
            let x = 10 + i * (cw + 2), on = i === S.tab;
            let cap = t + (i === 2 && d.claims > 0 ? " (" + d.claims + ")" : "");
            ctx.tabButton(cap, x, 26, cw, 16, on);
            S.hits.push({ x: x, y: 28, w: cw, h: 14, sound: true, fn: () => setTab(i) });
        });

        if (S.tab === 0) renderBrowse(ctx, mx, my, d);
        else if (S.tab === 1) renderMine(ctx, mx, my, d);
        else renderClaim(ctx, mx, my, d);

        scrollbar(ctx, 280, listTop(), ROWS * ROWH, d.total, ROWS, d.off);

        // footer: status line, Refresh, Close
        if (S.note && RPG.nowMs() - S.noteAt < 6000) label(ctx, S.note, 10, FOOT + 4, S.bad ? COL.badW : COL.goodW, 156);
        button(ctx, mx, my, 170, FOOT, 60, 14, "Refresh", () => request());
        button(ctx, mx, my, 234, FOOT, 60, 14, "Close", () => RPG.screen.close());

        ctx.pop();
    }

    function renderBrowse(ctx, mx, my, d) {
        // search + category filter
        box(ctx, 10, 46, 160, 11);
        let top = listTop();
        if (!d.rows.length) centered(ctx, d.total ? "" : (S.q || S.cat !== "all" ? "No listings match." : "Nothing is for sale yet."), 145, top + 30, COL.muted);
        let elapsed = RPG.nowMs() - S.at;
        d.rows.forEach((r, i) => {
            let ry = top + i * ROWH;
            let price = r.bid > 0 ? "Bid " + num(r.bid) : "Start " + num(r.start);
            if (!d.bidding) price = "Price " + num(r.buyNow || r.start);
            let sub = r.seller + " · " + left(r.left - elapsed) + (d.bidding && r.buyNow > 0 ? " · Buy " + num(r.buyNow) : "");
            let bx = 232, bw = 46, gx = 188, gw = 40;
            if (d.admin) {
                button(ctx, mx, my, 32 + 132, ry + 2, 14, 14, "x", () => send({ a: "remove", id: r.id }));
            }
            let textW = (d.admin ? 164 : gx) - 34;
            label(ctx, price + (r.top ? "  (you)" : ""), 32, ry + 2, r.top ? COL.good : COL.value, textW);
            label(ctx, sub, 32, ry + 12, COL.muted, textW);
            if (r.own) {
                label(ctx, "Yours", gx + 8, ry + 6, COL.off);
            } else {
                if (d.bidding) button(ctx, mx, my, gx, ry + 2, gw, 14, "Bid", () => submitBid(r), !d.canBid);
                if (r.buyNow > 0) button(ctx, mx, my, bx, ry + 2, bw, 14, d.bidding ? "Buy Now" : "Buy", () => send({ a: "buy", id: r.id }), !d.canBid);
            }
        });
        // controls: sort + the bid amount every Bid button uses
        if (d.bidding) {
            label(ctx, "Bid:", 116, CTRL + 2, COL.label);
            box(ctx, 178, CTRL, 90, 11);
        }
    }

    function submitBid(r) {
        let raw = val("amt"), amount = raw === "" ? r.min : intOf(raw);
        if (!(amount > 0)) { note("Enter a valid bid amount.", true); return; }
        if (amount < r.min) { note("Your bid must be at least " + num(r.min) + ".", true); return; }
        send({ a: "bid", id: r.id, amount: amount });
    }

    function renderMine(ctx, mx, my, d) {
        let top = listTop(), elapsed = RPG.nowMs() - S.at;
        if (!d.rows.length) centered(ctx, "You have nothing listed. Hold an item and list it below.", 145, top + 30, COL.muted);
        d.rows.forEach((r, i) => {
            let ry = top + i * ROWH;
            label(ctx, num(r.bid > 0 ? r.bid : r.start) + " " + d.currency, 32, ry + 2, COL.value, 190);
            let sub = (r.bid > 0 ? "Top: " + r.bidder : "No bids") + " · " + left(r.left - elapsed) + (r.buyNow > 0 && d.bidding ? " · Buy " + num(r.buyNow) : "");
            label(ctx, sub, 32, ry + 12, COL.muted, 190);
            if (r.bid > 0) label(ctx, "Bid placed", 226 - 4, ry + 6, COL.off);
            else button(ctx, mx, my, 226, ry + 2, 52, 14, "Cancel", () => send({ a: "cancel", id: r.id }));
        });
        // the form: start bid (or price), buy-now, duration; the list button on its own row below
        label(ctx, d.bidding ? "Start:" : "Price:", 10, 206, COL.label);
        box(ctx, 56, 204, 60, 11);
        if (d.bidding && d.buyNow) { label(ctx, "Buy now:", 122, 206, COL.label); box(ctx, 176, 204, 60, 11); }
        let fee = d.fee > 0 || d.feePct > 0 ? "Fee " + (d.fee > 0 ? num(d.fee) : "") + (d.fee > 0 && d.feePct > 0 ? "+" : "") + (d.feePct > 0 ? d.feePct + "%" : "") : "No fee";
        let info = d.active + "/" + d.max + " listed · " + fee + (d.tax > 0 ? " · Tax " + d.tax + "%" : "");
        label(ctx, d.held ? info : "Hold the item to sell. " + info, d.held ? 32 : 10, 223, COL.hint, d.held ? 122 : 144);
        button(ctx, mx, my, 158, 220, 120, 14, "List held item", submitList, !d.canList || !d.held);
    }

    function submitList() {
        let d = S.d;
        if (!d.canList) { note("You have too many active listings.", true); return; }
        let start = intOf(val("start"));
        if (!(start >= 1)) { note(d.bidding ? "Enter a valid starting bid." : "Enter a valid price.", true); return; }
        let bn = 0, raw = val("buynow");
        if (d.bidding && d.buyNow && raw !== "") {
            bn = intOf(raw);
            if (!(bn >= 0)) { note("Enter a valid buy-now price.", true); return; }
            if (bn > 0 && bn < start) { note("Buy-now must be at least the starting bid.", true); return; }
        }
        send({ a: "create", start: start, buyNow: bn, dur: S.dur || d.dur });
        RPG.screen.update("start", { value: "" });
        RPG.screen.update("buynow", { value: "" });
    }

    function renderClaim(ctx, mx, my, d) {
        let top = listTop();
        if (!d.rows.length) centered(ctx, "Nothing to claim.", 145, top + 30, COL.muted);
        d.rows.forEach((c, i) => {
            let ry = top + i * ROWH;
            if (c.item) label(ctx, c.reason, 32, ry + 7, COL.row, 240);
            else {
                label(ctx, num(c.money) + " " + d.currency, 32, ry + 2, COL.value, 240);
                label(ctx, c.reason, 32, ry + 12, COL.muted, 240);
            }
        });
        button(ctx, mx, my, 10, 218, 96, 14, "Collect all", () => send({ a: "claim" }), d.total === 0);
        if (d.total > 0) label(ctx, d.total + " payout" + (d.total === 1 ? "" : "s") + " waiting", 112, 221, COL.hint, 166);
    }

    // ---- input -------------------------------------------------------------------------------------------

    function mouse(x, y, button, action) {
        let mx = x - S.ox, my = y - S.oy;
        if (action === "drag") { if (S.drag) dragBar(my); return; }
        if (action === "up") { if (S.drag) { S.drag = false; request(); } return; }
        if (action !== "down" || button !== 0) return;
        let b = S.bar;
        if (b && over(mx, my, b.x, b.top, 12, b.h)) { S.drag = true; dragBar(my); return false; }
        for (let i = S.hits.length - 1; i >= 0; i--) {
            let h = S.hits[i];
            if (!over(mx, my, h.x, h.y, h.w, h.h)) continue;
            if (h.fn) { if (h.sound) sound(); h.fn(); }
            return false;
        }
    }
    function dragBar(my) {
        let b = S.bar, d = S.d;
        if (!b || !d) return;
        let t = (my - b.top - b.th / 2) / Math.max(1, b.h - b.th);
        let off = Math.round(clamp(t, 0, 1) * b.max);
        if (off !== S.off) { S.off = off; d.off = off; request(); }
    }
    function scroll(x, y, delta) {
        let d = S.d;
        if (!d || S.dd || d.total <= ROWS) return;
        let off = clamp(S.off + (delta < 0 ? 1 : -1), 0, d.total - ROWS);
        if (off !== S.off) { S.off = off; request(); }
    }
    function key(k, action) {
        if (action !== "down") return;
        if (k === "key.keyboard.enter" || k === "key.keyboard.keypad.enter") {
            if (S.tab === 1) { submitList(); return false; }
            if (S.tab === 0) { S.q = val("q"); S.off = 0; request(); return false; }
        }
    }

    // search as you type, a moment after the last key
    RPG.every(4, () => {
        if (!S.typed || RPG.time() - S.typed < 6 || !isOpen()) return;
        S.typed = 0;
        let q = val("q");
        if (q !== S.q) { S.q = q; S.off = 0; request(); }
    });

    // ---- from the server -----------------------------------------------------------------------------------

    RPG.net.on("ah_view", (v) => {
        if (!v) return;
        S.d = v; S.at = RPG.nowMs();
        S.tab = v.tab; S.sort = v.sort; S.cat = v.cat; S.off = v.off;
        if (v.note) { note(v.note, v.bad); RPG.sound(v.bad ? "minecraft:block.note_block.bass" : "minecraft:block.note_block.pling", 0.4, v.bad ? 0.8 : 1.6); }
        if (v.open && !isOpen()) { S.dd = null; S.dur = 0; build(); return; }
        if (!isOpen()) return;
        syncElements();
    });
})();
