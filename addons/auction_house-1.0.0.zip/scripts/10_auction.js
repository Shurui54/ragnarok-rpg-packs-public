// =====================================================================================
//  Auction House - listings, bids, claims and the screen's server side
// =====================================================================================
//  Saved with the world (RPG.data):
//    ah.listing.<id>   { id, seller, sellerName, item: {id, count, nbt}, name, cat, start, buyNow,
//                        bid, bidder, bidderName, posted, expires }        (times in ms)
//    ah.claims.<uuid>  [ { item } or { money }, with reason and time ]   what that player is owed
//    ah.log            the last auction events (/ah admin log)
//
//  Why nothing is copied or lost:
//    - A listed item lives ONLY on its listing from the moment it leaves the seller's hand until
//      it is moved into somebody's claim queue (sold, won, unsold, cancelled or removed).
//    - Bid money leaves the bidder's wallet when they bid. The listing only records it; when they
//      are outbid (or a buy-now beats them) it becomes a refund claim. The winning bid becomes the
//      seller's claim. Money is only paid out again when a claim is collected.
//    - Collecting removes the whole claim queue from the saved data first, then hands it over;
//      items that don't fit drop at the player's feet instead of vanishing.
//    - Settling, refunding and cancelling are pure moves between saved records in one tick, and
//      everything here is saved together with the player inventories on the world save.
// =====================================================================================
var AH_API = {};       // other addons: AH_API.open(player) opens the auction house for that player
(function () {
    var L = {};                     // listing id -> listing (mirror of ah.listing.*)
    var VIEW = {};                  // player uuid -> last view request (to refresh open screens)
    var SORTS = ["ending_soon", "newest", "price_low", "price_high"];
    var CATS = ["all", "weapons", "armor", "tools", "blocks", "food", "potions", "books", "misc"];
    var ROWS_MAX = 12;
    var NBT_MAX = 6000;             // longer item data is not sent to screens (the item still shows, without glint)

    RPG.data.keys("ah.listing.").forEach((k) => { let l = RPG.data.get(k, null); if (l && l.id && l.item) L[l.id] = l; });

    function now() { return Date.now(); }
    function saveListing(l) { L[l.id] = l; RPG.data.set("ah.listing." + l.id, l); }
    function dropListing(l) { delete L[l.id]; RPG.data.remove("ah.listing." + l.id); }
    function claimsOf(uuid) { let c = RPG.data.get("ah.claims." + uuid, []); return Array.isArray(c) ? c : []; }
    var SEQ = 0;
    /** A number that only grows, even across a crash that rolls the world data back (it starts from the clock). */
    function seq() { return now() * 1000 + (SEQ++ % 1000); }
    /**
     * A player's claims, minus any they already collected. The player variable "ah.collected" is saved with the
     * player's inventory, so if the world data is rolled back after they collected (say a crash right after they
     * logged out), the old copy of the claims can't be collected a second time.
     */
    function liveClaims(p) {
        let all = claimsOf(p.uuid), done = p.getVar("ah.collected", 0) || 0;
        let live = all.filter((c) => !(c.n <= done));
        if (live.length !== all.length) { if (live.length) RPG.data.set("ah.claims." + p.uuid, live); else RPG.data.remove("ah.claims." + p.uuid); }
        return live;
    }
    function addClaim(uuid, entry) {
        entry.at = now();
        entry.n = seq();
        let c = claimsOf(uuid);
        c.push(entry);
        RPG.data.set("ah.claims." + uuid, c);
        let p = ahOnline(uuid);
        if (p) refresh(p);
    }
    function newId() { return now().toString(36) + Math.floor(Math.random() * 1679616).toString(36); }
    function cleanStack(st) {
        if (!st || !st.id || st.id === "minecraft:air") return null;
        let o = { id: String(st.id), count: Math.max(1, st.count || 1) };
        if (st.nbt) o.nbt = String(st.nbt);
        return o;
    }
    function stackName(st) {
        if (st.name) return String(st.name);
        return RPG.items.name(st.id) || st.id;
    }
    function confined(st) { try { return !!st && RPG.items.isConfined(st); } catch (e) { return false; } }
    function refusesConfined() { return !!AH_CFG.get("listings.refuseConfined"); }
    function freeSlots(p) { let n = 0; for (let i = 0; i < 36; i++) if (!p.getStack(i)) n++; return n; }
    function itemLabel(it, name) { return (it.count > 1 ? it.count + "x " : "") + (name || stackName(it)); }
    function going(l) { return l.bid > 0 ? l.bid : l.start; }
    function hasBid(l) { return l.bid > 0 && !!l.bidder; }
    function hasBuyNow(l) { return l.buyNow > 0 && (!hasBid(l) || l.bid < l.buyNow); }
    function minNext(l) { return hasBid(l) ? l.bid + Math.max(1, AH_CFG.get("bidding.minIncrement")) : l.start; }
    function afterTax(n) { let t = AH_CFG.get("saleTaxPercent"); return Math.max(0, n - Math.floor(n * t / 100)); }
    function isAdmin(p) { return ahHas(p, "auction.admin"); }

    function log(type, who, text, amount) {
        let max = AH_CFG.get("logSize");
        if (max <= 0) return;
        let lg = RPG.data.get("ah.log", []);
        if (!Array.isArray(lg)) lg = [];
        lg.push({ t: now(), type: type, who: who || "", text: text || "", amount: amount || 0 });
        while (lg.length > max) lg.shift();
        RPG.data.set("ah.log", lg);
    }
    function notify(uuid, text) {
        if (!AH_CFG.get("notify")) return;
        let p = ahOnline(uuid);
        if (p) { ahMsg(p, text); p.playSound("minecraft:entity.experience_orb.pickup", 0.5, 1.2); }
    }

    function maxListings(p) {
        if (ahHas(p, "auction.listings.unlimited")) return 100000;
        let n = AH_CFG.get("listings.maxPerPlayer");
        for (let i = n + 1; i <= 200; i++) if (RPG.perms.has(p, "auction.listings." + i)) n = i;
        return n;
    }
    function activeCount(uuid) { return Object.keys(L).filter((k) => L[k].seller === uuid).length; }
    function durations() {
        let d = AH_CFG.get("listings.durations");
        d = Array.isArray(d) ? d.map((x) => parseFloat(x)).filter((x) => x > 0 && x <= 720) : [];
        return d.length ? d : [AH_CFG.get("listings.durationHours")];
    }
    function defaultDuration() {
        let d = durations(), want = AH_CFG.get("listings.durationHours");
        return d.indexOf(want) >= 0 ? want : d[Math.min(d.length - 1, Math.floor(d.length / 2))];
    }

    // ---- categories: a best guess from the item id, or the owner's own list ---------------------------

    function category(id) {
        let own = AH_CFG.get("categories") || {};
        if (own[id] && CATS.indexOf(String(own[id])) > 0) return String(own[id]);
        let s = String(id).split(":").pop();
        let m = /^item_(\d+)$/.exec(s);
        if (m) { let n = parseInt(m[1]); return n >= 801 && n <= 1000 || n >= 5201 ? "armor" : "misc"; }
        if (/^block_\d+$/.test(s)) return "blocks";
        if (/sword|(^|_)bow$|crossbow|trident|mace|arrow$/.test(s)) return /tipped_arrow/.test(s) ? "potions" : "weapons";
        if (/helmet|chestplate|leggings|boots|shield|elytra|horse_armor|turtle_helmet/.test(s)) return "armor";
        if (/pickaxe|shovel|(^|_)axe$|hoe$|shears|fishing_rod|flint_and_steel|brush|spyglass|compass|clock|lead$|bucket$/.test(s)) return "tools";
        if (/potion|experience_bottle|dragon_breath|brewing|blaze_powder|nether_wart|ghast_tear/.test(s)) return "potions";
        if (/book|written_book|name_tag/.test(s)) return "books";
        if (/apple|bread|beef|porkchop|chicken|mutton|rabbit|cod|salmon|potato|carrot|melon_slice|cookie|cake|pie|stew|soup|berries|dried_kelp|honey_bottle|beetroot|tropical_fish|chorus_fruit|senzu|bean/.test(s)) return "food";
        if (/_block$|planks|_log$|_wood$|stone|brick|_ore$|glass|wool|concrete|terracotta|sand$|dirt|gravel|slab|stairs|_wall$|fence|door|leaves|sapling|deepslate|obsidian|netherrack|quartz_|prismarine|purpur|chest$|barrel|furnace|table$|lantern|torch|carpet|bed$|rail|piston|hopper|log$/.test(s)) return "blocks";
        return "misc";
    }

    // ---- what the screen gets ----------------------------------------------------------------------

    function viewStack(it) {
        let o = { id: it.id, count: it.count };
        if (it.nbt && it.nbt.length <= NBT_MAX) o.nbt = it.nbt;
        return o;
    }
    function rowOf(l, p, t) {
        return { id: l.id, item: viewStack(l.item), name: l.name, seller: l.sellerName, start: l.start, buyNow: hasBuyNow(l) ? l.buyNow : 0,
            bid: l.bid, bidder: l.bidderName || "", left: Math.max(0, l.expires - t), own: l.seller === p.uuid, top: l.bidder === p.uuid,
            min: minNext(l) };
    }
    function matches(l, q, cat) {
        if (cat && cat !== "all" && l.cat !== cat) return false;
        if (!q) return true;
        return (String(l.name) + " " + l.item.id + " " + l.sellerName).toLowerCase().indexOf(q) >= 0;
    }
    function sorted(list, sort) {
        let f = sort === "newest" ? (a, b) => b.posted - a.posted
            : sort === "price_low" ? (a, b) => going(a) - going(b) || a.expires - b.expires
            : sort === "price_high" ? (a, b) => going(b) - going(a) || a.expires - b.expires
            : (a, b) => a.expires - b.expires;
        return list.sort(f);
    }

    function view(p, req) {
        req = req || VIEW[p.uuid] || {};
        let tab = req.tab === 1 || req.tab === 2 ? req.tab : 0;
        let sort = SORTS.indexOf(req.sort) >= 0 ? req.sort : "ending_soon";
        let cat = CATS.indexOf(req.cat) >= 0 ? req.cat : "all";
        let q = String(req.q || "").toLowerCase().trim().substring(0, 40);
        let rows = RPG.clamp(Math.floor(req.rows || 7), 1, ROWS_MAX);
        let off = Math.max(0, Math.floor(req.off || 0));
        VIEW[p.uuid] = { tab: tab, sort: sort, cat: cat, q: q, rows: rows, off: off, open: !!(VIEW[p.uuid] && VIEW[p.uuid].open) };
        let t = now(), all, out = [];
        if (tab === 2) {
            all = liveClaims(p);
            off = Math.min(off, Math.max(0, all.length - rows));
            all.slice(off, off + rows).forEach((c) => out.push(c.item ? { item: viewStack(c.item), reason: c.reason } : { money: c.money, reason: c.reason }));
        } else {
            all = Object.keys(L).map((k) => L[k]).filter((l) => tab === 1 ? l.seller === p.uuid : matches(l, q, cat));
            all = sorted(all, sort);
            off = Math.min(off, Math.max(0, all.length - rows));
            all.slice(off, off + rows).forEach((l) => out.push(rowOf(l, p, t)));
        }
        let held = cleanStack(p.getHeldStack());
        let max = maxListings(p), active = activeCount(p.uuid);
        return {
            tab: tab, sort: sort, cat: cat, q: q, off: off, total: all.length, rows: out,
            claims: liveClaims(p).length, currency: AH_CUR.name(), balance: AH_CUR.balance(p),
            canList: ahHas(p, "auction.sell") && active < max, canBid: ahHas(p, "auction.bid"), admin: isAdmin(p),
            max: max, active: active, fee: AH_CFG.get("listings.fee"), feePct: AH_CFG.get("listings.feePercent"),
            tax: AH_CFG.get("saleTaxPercent"), inc: AH_CFG.get("bidding.minIncrement"),
            bidding: AH_CFG.get("bidding.enabled"), buyNow: AH_CFG.get("buyNow"),
            durations: durations(), dur: defaultDuration(), held: held ? viewStack(held) : null
        };
    }
    function send(p, open, note, bad) {
        let v = view(p, null);
        v.open = !!open;
        if (note) { v.note = note; v.bad = !!bad; }
        RPG.net.send(p, "ah_view", v);
    }
    /** Push a fresh view to a player who has the screen open (after something changed for them). */
    function refresh(p) { if (VIEW[p.uuid] && VIEW[p.uuid].open) send(p, false); }
    function refreshAll() { RPG.server.players().forEach(refresh); }

    function open(p) {
        if (!ahHas(p, "auction.use")) { ahMsg(p, "&cYou can't use the auction house."); return; }
        sweep();
        VIEW[p.uuid] = VIEW[p.uuid] || {};
        VIEW[p.uuid].open = true;
        send(p, true);
        p.playSound("minecraft:block.chest.open", 0.5, 1.1);
    }

    // ---- actions -----------------------------------------------------------------------------------

    function create(p, start, buyNow, hours) {
        if (!ahHas(p, "auction.sell")) return "You can't sell on the auction house.";
        let raw = p.getHeldStack(), st = cleanStack(raw);
        if (!st) return "Hold the item you want to list in your main hand.";
        let bl = AH_CFG.get("listings.blacklist") || [];
        if (bl.indexOf(st.id) >= 0) return "That item can't be auctioned.";
        if (refusesConfined() && confined(raw)) return "That item can only be carried by players, so it can't be auctioned.";
        let max = maxListings(p);
        if (activeCount(p.uuid) >= max) return "You may have at most " + max + " active listings.";
        let lo = AH_CFG.get("listings.minPrice"), hi = AH_CFG.get("listings.maxPrice");
        start = Math.floor(start);
        buyNow = Math.floor(buyNow || 0);
        if (!(start >= lo)) return "The starting bid must be at least " + ahNum(lo) + ".";
        if (start > hi) return "The highest allowed price is " + ahNum(hi) + ".";
        if (!AH_CFG.get("bidding.enabled")) buyNow = start;                 // fixed price: the price is the buy-now
        else if (!AH_CFG.get("buyNow")) buyNow = 0;
        if (buyNow > 0 && buyNow < start) return "The buy-now price must be at least the starting bid.";
        if (buyNow > hi) return "The highest allowed price is " + ahNum(hi) + ".";
        let durs = durations();
        hours = parseFloat(hours);
        if (durs.indexOf(hours) < 0) hours = defaultDuration();
        let fee = AH_CFG.get("listings.fee") + Math.floor(start * AH_CFG.get("listings.feePercent") / 100);
        if (fee > 0 && !AH_CUR.take(p, fee)) return "You cannot afford the listing fee (" + AH_CUR.fmt(fee) + ").";
        // the item leaves the hand in the same tick it becomes the listing
        p.setHeldStack(null);
        let t = now();
        let l = { id: newId(), seller: p.uuid, sellerName: p.name, item: st, name: stackName(raw), cat: category(st.id),
            start: start, buyNow: buyNow, bid: 0, bidder: "", bidderName: "", posted: t, expires: t + Math.round(hours * 3600000) };
        saveListing(l);
        log("list", p.name, itemLabel(st, l.name) + " start " + start + (buyNow ? " buy " + buyNow : "") + (fee ? " fee " + fee : ""), start);
        p.playSound("minecraft:entity.villager.yes", 0.5, 1.2);
        refreshAll();
        return null;
    }

    function bid(p, id, amount) {
        if (!ahHas(p, "auction.bid")) return "You can't bid.";
        if (!AH_CFG.get("bidding.enabled")) return "Bidding is turned off here.";
        let l = L[id];
        if (!l || l.expires <= now()) return "That listing is no longer available.";
        if (l.seller === p.uuid) return "You cannot bid on your own listing.";
        amount = Math.floor(amount);
        let min = minNext(l);
        if (!(amount >= min)) return "Your bid must be at least " + ahNum(min) + ".";
        if (amount > AH_CFG.get("listings.maxPrice")) return "The highest allowed bid is " + ahNum(AH_CFG.get("listings.maxPrice")) + ".";
        if (!AH_CUR.take(p, amount)) return "You cannot afford that.";
        // the old top bid goes back to its bidder as a refund claim
        if (hasBid(l)) {
            addClaim(l.bidder, { money: l.bid, reason: "Outbid refund" });
            if (l.bidder !== p.uuid) notify(l.bidder, "&eYou were outbid on &f" + itemLabel(l.item, l.name) + "&e. Your " + AH_CUR.fmt(l.bid) + " is in the Claim tab (/ah).");
        }
        l.bid = amount; l.bidder = p.uuid; l.bidderName = p.name;
        let snipe = AH_CFG.get("bidding.antiSnipeSeconds") * 1000;
        if (snipe > 0 && l.expires - now() < snipe) l.expires = now() + snipe;
        saveListing(l);
        log("bid", p.name, itemLabel(l.item, l.name) + " from " + l.sellerName, amount);
        refreshAll();
        return null;
    }

    function buy(p, id) {
        if (!ahHas(p, "auction.bid")) return "You can't buy.";
        let l = L[id];
        if (!l || l.expires <= now()) return "That listing is no longer available.";
        if (l.seller === p.uuid) return "You cannot buy your own listing.";
        if (!hasBuyNow(l)) return "That listing has no buy-now price.";
        let price = l.buyNow;
        if (!AH_CUR.take(p, price)) return "You cannot afford that.";
        if (hasBid(l)) {
            addClaim(l.bidder, { money: l.bid, reason: "Outbid refund" });
            notify(l.bidder, "&e" + itemLabel(l.item, l.name) + " &ewas bought outright. Your " + AH_CUR.fmt(l.bid) + " is in the Claim tab (/ah).");
        }
        dropListing(l);
        addClaim(l.seller, { money: afterTax(price), reason: "Sale proceeds" });
        addClaim(p.uuid, { item: l.item, reason: "Bought item" });
        notify(l.seller, "&aSold &f" + itemLabel(l.item, l.name) + "&a to " + p.name + " for " + AH_CUR.fmt(price) + ". Collect it from the Claim tab (/ah).");
        log("buy", p.name, itemLabel(l.item, l.name) + " from " + l.sellerName, price);
        p.playSound("minecraft:entity.player.levelup", 0.4, 1.4);
        refreshAll();
        return null;
    }

    function cancel(p, id) {
        let l = L[id];
        if (!l) return "That listing is no longer available.";
        if (l.seller !== p.uuid) return "That is not your listing.";
        if (hasBid(l)) return "You cannot cancel a listing that has a bid.";
        dropListing(l);
        addClaim(l.seller, { item: l.item, reason: "Cancelled listing" });
        log("cancel", p.name, itemLabel(l.item, l.name));
        refreshAll();
        return null;
    }

    /** Admin: take a listing down. The item goes back to the seller, a standing bid back to its bidder. */
    function remove(admin, id) {
        let l = L[id];
        if (!l) return "That listing is no longer available.";
        if (hasBid(l)) addClaim(l.bidder, { money: l.bid, reason: "Listing removed (refund)" });
        dropListing(l);
        addClaim(l.seller, { item: l.item, reason: "Removed by staff" });
        notify(l.seller, "&eYour listing &f" + itemLabel(l.item, l.name) + "&e was removed by staff. The item is in the Claim tab (/ah).");
        log("remove", admin ? admin.name : "console", itemLabel(l.item, l.name) + " of " + l.sellerName);
        refreshAll();
        return null;
    }

    /** Settle every listing whose time is up: winner gets the item, seller the (taxed) bid; unsold goes back. */
    function sweep(force) {
        let t = now(), any = false;
        Object.keys(L).forEach((k) => {
            let l = L[k];
            if (!force && l.expires > t) return;
            any = true;
            dropListing(l);
            if (hasBid(l)) {
                addClaim(l.seller, { money: afterTax(l.bid), reason: "Sale proceeds" });
                addClaim(l.bidder, { item: l.item, reason: "Won auction" });
                notify(l.seller, "&aYour auction &f" + itemLabel(l.item, l.name) + "&a sold to " + l.bidderName + " for " + AH_CUR.fmt(l.bid) + ". Collect it from the Claim tab (/ah).");
                notify(l.bidder, "&aYou won &f" + itemLabel(l.item, l.name) + "&a for " + AH_CUR.fmt(l.bid) + ". Collect it from the Claim tab (/ah).");
                log("won", l.bidderName, itemLabel(l.item, l.name) + " from " + l.sellerName, l.bid);
            } else {
                addClaim(l.seller, { item: l.item, reason: "Unsold listing" });
                notify(l.seller, "&eYour auction &f" + itemLabel(l.item, l.name) + "&e ended without bids. The item is in the Claim tab (/ah).");
                log("expired", l.sellerName, itemLabel(l.item, l.name));
            }
        });
        if (any) refreshAll();
        return any;
    }

    /** Hand over everything a player is owed. The queue leaves the saved data before anything is given. */
    function collect(p) {
        let q = liveClaims(p);
        if (!q.length) return "You have nothing to collect.";
        RPG.data.remove("ah.claims." + p.uuid);
        let top = p.getVar("ah.collected", 0) || 0;
        q.forEach((c) => { if (c.n > top) top = c.n; });
        p.setVar("ah.collected", top);      // saved with the inventory the items are about to land in
        let money = 0, items = 0, free = freeSlots(p), wait = [];
        q.forEach((c) => {
            // an item only players may carry goes only into a free slot (never dropped); the rest waits in the queue
            if (c.item && confined(c.item) && refusesConfined()) { if (free > 0) { p.giveStack(c.item); items++; free--; } else wait.push(c); }
            else if (c.item) { p.giveStack(c.item); items++; }
            else if (c.money > 0) money += c.money;
        });
        if (money > 0) AH_CUR.give(p, money);
        // queued again with new numbers, above the "collected" mark just saved
        wait.forEach((c) => addClaim(p.uuid, { item: c.item, reason: c.reason }));
        if (wait.length) ahMsg(p, "&eMake room in your inventory: " + wait.length + " item(s) that only players may carry are still waiting in the Claim tab.");
        log("collect", p.name, items + " item(s)", money);
        p.playSound("minecraft:entity.item.pickup", 0.6, 1);
        if (q.length === wait.length) return null;
        ahMsg(p, "&aCollected " + (q.length - wait.length) + " payout(s)" + (money > 0 ? ": &e" + AH_CUR.fmt(money) : "") + (items > 0 ? (money > 0 ? "&a and " : ": &f") + items + " item(s)" : "") + "&a.");
        return null;
    }

    // ---- the screen talks to us here (never trusted: every action is checked again) -------------------

    RPG.net.on("ah", (p, d) => {
        if (!d || typeof d !== "object") return;
        if (!ahHas(p, "auction.use")) return;
        let err = null, ok = null;
        switch (String(d.a)) {
            case "view": RPG.net.send(p, "ah_view", view(p, d)); VIEW[p.uuid].open = true; return;
            case "close": if (VIEW[p.uuid]) VIEW[p.uuid].open = false; return;
            case "create": err = create(p, parseFloat(d.start), parseFloat(d.buyNow || 0), d.dur); ok = "Item listed."; break;
            case "bid": err = bid(p, String(d.id), parseFloat(d.amount)); ok = "Bid placed."; break;
            case "buy": err = buy(p, String(d.id)); ok = "Purchase complete. Collect it from the Claim tab."; break;
            case "cancel": err = cancel(p, String(d.id)); ok = "Listing cancelled. Collect the item from the Claim tab."; break;
            case "remove": err = isAdmin(p) ? remove(p, String(d.id)) : "You can't do that."; ok = "Listing removed."; break;
            case "claim": err = collect(p); ok = "Collected."; break;
            default: return;
        }
        if (VIEW[p.uuid]) VIEW[p.uuid].open = true;
        send(p, false, err || ok, !!err);
    });

    // ---- ways in: command, block, NPCs -------------------------------------------------------------------

    var ADMIN_HELP = "&7/ah admin remove <id> &8| &7expire <id|all> &8| &7list <player> &8| &7claims <player> &8| &7log [n] &8| &7block";

    function listingByPrefix(s) {
        s = String(s || "");
        let hit = Object.keys(L).filter((k) => k.indexOf(s) === 0);
        return hit.length === 1 ? L[hit[0]] : null;
    }

    function adminCmd(p, args) {
        let sub = String(args[1] || "").toLowerCase();
        if (sub === "remove" || sub === "expire") {
            if (sub === "expire" && String(args[2]).toLowerCase() === "all") {
                let n = Object.keys(L).length;
                sweep(true);
                ahMsg(p, "&aEnded " + n + " listing(s).");
                return;
            }
            let l = listingByPrefix(args[2]);
            if (!l) { ahMsg(p, "&cNo single listing starts with that id. /ah admin list <player> shows ids."); return; }
            if (sub === "expire") { l.expires = now() - 1; saveListing(l); sweep(); ahMsg(p, "&aEnded that listing."); }
            else { remove(p, l.id); ahMsg(p, "&aRemoved that listing."); }
            return;
        }
        if (sub === "list") {
            let name = String(args[2] || "").toLowerCase();
            let rows = Object.keys(L).map((k) => L[k]).filter((l) => !name || l.sellerName.toLowerCase() === name);
            ahMsg(p, "&6" + rows.length + " listing(s)" + (name ? " by " + args[2] : "") + ":");
            sorted(rows, "ending_soon").slice(0, 30).forEach((l) => {
                if (p) p.tell("  &8" + l.id.substring(0, 8) + " &f" + itemLabel(l.item, l.name) + " &7by " + l.sellerName + " &e" + ahNum(going(l)) + (hasBid(l) ? " &7(top " + l.bidderName + ")" : "") + " &8" + ahDur(l.expires - now()));
            });
            return;
        }
        if (sub === "claims") {
            let t = RPG.server.player(String(args[2] || ""));
            if (!t) { ahMsg(p, "&cThat player isn't online."); return; }
            let c = claimsOf(t.uuid), money = 0, items = 0;
            c.forEach((e) => { if (e.item) items++; else money += e.money || 0; });
            ahMsg(p, "&f" + t.name + "&7 is owed &e" + AH_CUR.fmt(money) + "&7 and &f" + items + "&7 item(s).");
            return;
        }
        if (sub === "log") {
            let n = RPG.clamp(parseInt(args[2]) || 15, 1, 100);
            let lg = RPG.data.get("ah.log", []);
            ahMsg(p, "&6Last " + Math.min(n, lg.length) + " auction events:");
            lg.slice(-n).forEach((e) => {
                let ago = ahDur(now() - e.t);
                if (p) p.tell("  &8" + ago + " ago &e" + e.type + " &f" + e.who + " &7" + e.text + (e.amount ? " &6" + ahNum(e.amount) : ""));
                else RPG.log(ago + " " + e.type + " " + e.who + " " + e.text + " " + (e.amount || ""));
            });
            return;
        }
        if (sub === "block") {
            if (!p) return;
            if (!AH_BLOCK) { ahMsg(p, "&cThe Auction Block is turned off (config: block)."); return; }
            p.giveItem(AH_BLOCK, 1);
            ahMsg(p, "&aHere is an Auction Block.");
            return;
        }
        ahMsg(p, ADMIN_HELP);
    }

    RPG.commands.register("ah", {
        root: true, aliases: ["auction", "auctionhouse"], permission: "auction.use",
        description: "The auction house: /ah, /ah sell <start> [buy-now] [hours], /ah collect",
        suggest(p, args) {
            if (args.length <= 1) return ["sell", "collect"].concat(isAdmin(p) ? ["admin"] : []);
            if (args[0] === "admin" && args.length === 2) return ["remove", "expire", "list", "claims", "log", "block"];
            if (args[0] === "admin" && (args[1] === "list" || args[1] === "claims")) return RPG.server.players().map((q) => q.name);
            if (args[0] === "sell" && args.length === 4) return durations().map(String);
            return [];
        },
        run(p, args) {
            let sub = String(args[0] || "").toLowerCase();
            if (sub === "admin") { if (!isAdmin(p)) { ahMsg(p, "&cYou can't do that."); return; } adminCmd(p, args); return; }
            if (!p) { ahMsg(p, "Use /ah admin ... from the console."); return; }
            if (sub === "sell") {
                let err = create(p, parseFloat(args[1]), parseFloat(args[2] || 0), args[3]);
                ahMsg(p, err ? "&c" + err : "&aItem listed.");
                return;
            }
            if (sub === "collect" || sub === "claim") { let err = collect(p); if (err) ahMsg(p, "&7" + err); refresh(p); return; }
            open(p);
        }
    });

    var AH_BLOCK = null;
    if (AH_CFG.get("block")) {
        AH_BLOCK = "ragnarok_rpg:" + RPG.blocks.define("auction_block", {
            name: "&6Auction Block", model: "auction_house:rpg/block/auction_block", hardness: 3,
            onUse(player) { open(player); }
        });
    }

    RPG.on("npcInteract", (p, npc, npcId) => {
        let ids = AH_CFG.get("npcs") || [];
        if (ids.indexOf(String(npcId)) < 0) return;
        open(p);
        return false;
    });

    RPG.on("playerJoin", (p) => {
        delete VIEW[p.uuid];
        if (!AH_CFG.get("notify")) return;
        let n = liveClaims(p).length;
        if (n > 0) RPG.schedule(60, () => ahMsg(p, "&eYou have " + n + " auction payout" + (n === 1 ? "" : "s") + " waiting. &f/ah &7(Claim tab)"));
    });
    RPG.on("playerLeave", (p) => { delete VIEW[p.uuid]; });

    var lastSweep = 0;
    RPG.on("serverTick", () => {
        let t = now();
        if (t - lastSweep < AH_CFG.get("sweepSeconds") * 1000) return;
        lastSweep = t;
        sweep();
    });

    // listings made before an item became one only players may carry go back to their sellers (a standing bid back
    // to its bidder), once every addon has said what is confined
    RPG.schedule(40, () => {
        if (!refusesConfined()) return;
        let any = false;
        Object.keys(L).forEach((k) => {
            let l = L[k];
            if (!confined(l.item)) return;
            any = true;
            if (hasBid(l)) addClaim(l.bidder, { money: l.bid, reason: "Listing withdrawn (refund)" });
            dropListing(l);
            addClaim(l.seller, { item: l.item, reason: "Can't be auctioned" });
            log("remove", "auction house", itemLabel(l.item, l.name) + " of " + l.sellerName + " (only players may carry it)");
        });
        if (any) refreshAll();
    });

    AH_API.open = open;
    AH_API.refresh = refresh;
})();
