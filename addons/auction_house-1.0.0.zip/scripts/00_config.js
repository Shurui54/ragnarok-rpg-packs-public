// =====================================================================================
//  Auction House - settings (ragnarok_rpg/config/auction_house.json, or /rpg config auction_house ...)
// =====================================================================================
//  Open it with /ah (also /auction, /auctionhouse), the Auction Block, or an NPC listed in "npcs".
//  Players list the item in their main hand with a starting bid and an optional buy-now
//  price, bid on other listings, and collect everything they are owed from the Claim tab:
//  sale proceeds, outbid refunds, won or bought items, and unsold or cancelled items.
//
//  Permissions (operators have them all; change with /rpg perm):
//    auction.use     open the auction house          auction.sell   list items
//    auction.bid     bid and buy                      auction.admin  remove any listing, /ah admin
//    auction.listings.<n>   allow n active listings (e.g. auction.listings.20), auction.listings.unlimited
// =====================================================================================

var AH_CFG = RPG.config.define("auction_house", {
    prefix: { default: "&6[&eAuction&6] &r", comment: "Put before this addon's chat messages" },
    currency: {
        type: { default: "money", options: ["money", "item", "tp"],
            comment: "What prices are paid in: money (the project's currency, e.g. Zeni), item (an item, see currency.item) or tp" },
        item: { default: "minecraft:emerald", comment: "The item used as money when currency.type is item" },
        name: { default: "", comment: "Name shown after amounts (empty: the project's currency name, or the item's name)" }
    },
    listings: {
        maxPerPlayer: { default: 5, min: 0, max: 1000, integer: true,
            comment: "Active listings a player may have (auction.listings.<n> raises it for a group)" },
        durationHours: { default: 24, min: 0.05, max: 720, comment: "How long a listing runs when the seller doesn't pick" },
        durations: { default: [6, 12, 24, 48], comment: "Hours a seller can pick from in My Listings (empty list: always durationHours)" },
        minPrice: { default: 1, min: 1, max: 1e12, integer: true, comment: "Lowest starting bid / price" },
        maxPrice: { default: 1000000000, min: 1, max: 1e15, integer: true, comment: "Highest starting bid, buy-now price or bid" },
        fee: { default: 0, min: 0, max: 1e12, integer: true, comment: "Flat fee to put an item up (a money sink, never refunded)" },
        feePercent: { default: 0, min: 0, max: 100, comment: "Extra listing fee: this percent of the starting bid (never refunded)" },
        blacklist: { default: [], comment: "Item ids that can't be listed, e.g. [\"minecraft:bedrock\"]" },
        refuseConfined: { default: true, comment: "Items only players may carry (RPG.items.confine, e.g. dragon balls or a pouch holding them) can't be listed; old listings of them go back to their sellers, and they are only handed out into a free inventory slot, never dropped" }
    },
    bidding: {
        enabled: { default: true, comment: "Allow bids. Off: every listing is a fixed price you buy outright" },
        minIncrement: { default: 1, min: 1, max: 1e12, integer: true, comment: "A new bid must beat the current one by at least this" },
        antiSnipeSeconds: { default: 0, min: 0, max: 3600, integer: true,
            comment: "A bid in a listing's last N seconds extends it to N seconds left (0: off)" }
    },
    buyNow: { default: true, comment: "Allow buy-now prices" },
    saleTaxPercent: { default: 5, min: 0, max: 100, comment: "Percent of every sale kept by the house (a money sink)" },
    categories: { default: {}, comment: "Put items in a category by hand: {\"minecraft:totem_of_undying\": \"misc\"}. Categories: weapons, armor, tools, blocks, food, potions, books, misc" },
    npcs: { default: [], comment: "RPG.npcs ids that open the auction house when talked to" },
    block: { default: true, comment: "Add the Auction Block (right-click to open the auction house; /ah admin block gives one)" },
    notify: { default: true, comment: "Tell players when they are outbid, sell or win, and on join when they have things to collect" },
    sweepSeconds: { default: 5, min: 1, max: 300, integer: true, comment: "How often expired listings are settled" },
    logSize: { default: 300, min: 0, max: 5000, integer: true, comment: "Auction events kept for /ah admin log" }
});

RPG.perms.group("default", ["auction.use", "auction.sell", "auction.bid"]);
RPG.perms.group("vip", ["auction.listings.10"]);
RPG.perms.group("admin", ["auction.*"]);

// ---- currency: the project's money, an item, or TP ----------------------------------------------------

var AH_CUR = {
    type() { return AH_CFG.get("currency.type") || "money"; },
    name() {
        let n = AH_CFG.get("currency.name");
        if (n) return n;
        if (this.type() === "tp") return "TP";
        if (this.type() === "item") return RPG.items.name(AH_CFG.get("currency.item")) || "Items";
        return ((RPG.currency.get() || {}).name) || "Money";
    },
    balance(p) {
        let t = this.type();
        if (t === "tp") return Math.floor(p.getTp());
        if (t === "item") return p.countItem(AH_CFG.get("currency.item"));
        return Math.floor(p.getMoney());
    },
    /** Take n if the player has it; false (and nothing taken) otherwise. */
    take(p, n) {
        n = Math.floor(n);
        if (n <= 0) return true;
        let t = this.type();
        if (t === "tp") { if (p.getTp() < n) return false; p.setTp(p.getTp() - n); return true; }
        if (t === "item") { let it = AH_CFG.get("currency.item"); return p.countItem(it) >= n && p.takeItem(it, n); }
        return p.takeMoney(n);
    },
    give(p, n) {
        n = Math.floor(n);
        if (n <= 0) return;
        let t = this.type();
        if (t === "tp") p.setTp(p.getTp() + n);
        else if (t === "item") p.giveItem(AH_CFG.get("currency.item"), n);
        else p.addMoney(n);
    },
    fmt(n) { return ahNum(n) + " " + this.name(); }
};

function ahNum(n) { return String(Math.floor(n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
function ahMsg(p, text) { if (p) p.tell(AH_CFG.get("prefix") + text); else RPG.log(String(text).replace(/&./g, "")); }
function ahHas(p, node) { return !p || RPG.perms.has(p, node); }
function ahOnline(uuid) { let out = null; RPG.server.players().forEach((q) => { if (q.uuid === uuid) out = q; }); return out; }
function ahDur(ms) {
    if (ms <= 0) return "expired";
    let m = Math.floor(ms / 60000), d = Math.floor(m / 1440), h = Math.floor(m % 1440 / 60), mm = m % 60;
    if (d > 0) return d + "d " + h + "h";
    if (h > 0) return h + "h " + mm + "m";
    if (mm > 0) return mm + "m";
    return "<1m";
}
