// =====================================================================================
//  99_dbr_nametags.js - no hover name tags on script mobs (the original shows none); see the
//  server's 99y_dbr_nametags.js. Entities the server lists keep the game's own tag rules.
// =====================================================================================
(function () {
    function apply() { try { RPG.render.type("ragnarok_rpg:mob", { nameplate: false }); } catch (e) { } }
    RPG.on("load", apply);
    apply();
    // an entity option wins over the type option: with no nameplate field the game decides (hover, or always when
    // the server made the name visible); it runs out unless the next list (every 2 s) renews it
    RPG.net.on("dbr_nametags", function (d) {
        var ids = d && d.ids;
        if (!ids) return;
        for (var i = 0; i < ids.length; i++) { try { RPG.render.entity(Number(ids[i]), { ticks: 60 }); } catch (e) { } }
    });
})();
