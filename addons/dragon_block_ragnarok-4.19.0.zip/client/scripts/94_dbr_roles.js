// =====================================================================================
//  94_dbr_roles.js - the Ragnarok original's god roles on the player's computer
// =====================================================================================
//  Port of the Ragnarok original (GPL-3.0, see NOTICE.md, by Shurui), shuruisutilities:
//    client/hud/EnergyClientCache + EnergyClientEvents (your own role bar, cleared on leaving),
//    client/SUKeybinds.ROLE_ABILITY (one key; the server decides what it does from the role you hold),
//    and the outline the key's roles/GlowOutline puts round a God of Destruction's aura (light purple) and an Angel's
//    state (white), drawn here as the God Ki outline (the original's transformation_outline post chain, 07c_dmz_outline.js,
//    RPG.avatar.setOutline) in each role's colours (shared/28_dbr_roles.js OUTLINE).
//  The bar is drawn by the Ragnarok HUD (11_hud_ragnarok.js, the fourth bar) and the Angel's Staff wheel entry by
//  45_transform.js; both read DBR_ROLE_CLIENT. Server side: scripts/94c_dbr_roles.js.
//
//  Role Ability key ("Dragon Block Ragnarok" in Controls, default U; the original's V opens DBR's stats menu):
//    God of Destruction -> the destruction aura   Angel -> the angelic state   Grand Zeno -> both, raised and lowered together
// =====================================================================================
var DBR_ROLE_CLIENT = (function () {
    var R = { k: "", v: 0, a: 0 };
    function clear() { R = { k: "", v: 0, a: 0 }; }
    RPG.net.on("dbr_role", function (d) {
        if (!d) return;
        R = { k: String(d.k || ""), v: Math.max(0, Math.min(100, Number(d.v) || 0)), a: Number(d.a) || 0 };
    });
    RPG.on("load", function () { clear(); try { RPG.net.send("dbr_role", { a: "sync" }); } catch (e) { } });
    RPG.on("unload", function () { clear(); dropOutlines(); });

    try { RPG.keys.register("dbr_role_ability", { name: "Role Ability (God of Destruction / Angel)", key: "u", category: "Dragon Block Ragnarok" }); } catch (e) { }
    RPG.on("keybind", function (id, down) {
        if (id === "dbr_role_ability" && down) RPG.net.send("dbr_role", { a: "ability" });
    });

    // ---- the role outline: every player whose aura or state is up (shared "dbr_role_mode") ----
    var SHOWN = {};                              // entity id -> mode shown
    function dropOutlines() { for (var id in SHOWN) { try { RPG.avatar.setOutline(Number(id), null); } catch (e) { } } SHOWN = {}; }
    RPG.on("tick", function () {
        if (!RPG.player.present) return;
        var seen = {}, eye = {};
        RPG.avatar.players().forEach(function (pl) {
            var m = pl.shared("dbr_role_mode", null);
            // the Demon Eye's red outline (43_dmz_auras.js) keeps the body it is on
            if (pl.shared("dmzDemonEye", null)) { eye[pl.id] = true; return; }
            if (!m || pl.spectator || pl.invisible) return;
            m = String(m);
            seen[pl.id] = true;
            if (SHOWN[pl.id] === m) return;
            var spec = DBR_ROLE_DATA.outlineSpec(m);
            if (!spec) return;
            SHOWN[pl.id] = m;
            RPG.avatar.setOutline(pl.id, spec);
        });
        for (var id in SHOWN) if (!seen[id]) { if (!eye[id]) RPG.avatar.setOutline(Number(id), null); delete SHOWN[id]; }
    });

    return {
        /** "destruction" | "angelic" | "" (no role: no fourth bar). */
        kind: function () { return R.k; },
        value: function () { return R.v; },
        destruction: function () { return (R.a & 1) !== 0; },
        angelic: function () { return (R.a & 2) !== 0; }
    };
})();
