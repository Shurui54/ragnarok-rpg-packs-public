// =====================================================================================
//  Original melee and guard input (MinecraftMixin / CombatAttackRequestC2S, BLOCK_KEY)
//  Left click with empty hands: the next step of the fist combo, animated at once on your
//  screen and sent to the server (which shows it to everyone and applies the damage).
//  Hold right click with empty hands: guard (a quick press is a parry).
// =====================================================================================
(function () {
    var C = DMZ_COMBAT, st = { count: 0, last: -1000, hitAt: -1e9, guarding: false, relock: 0 };

    function emptyHands() {
        var h = RPG.player.heldItem;
        return !h || h === "minecraft:air";
    }
    function created() { return !!RPG.getVar("dmz_created", 0); }
    // a ki weapon out (scripts/79_dmz_kiweapon.js): Ki Manipulation on, hands empty -> its table entry, else null
    function kiWeapon() {
        var on = RPG.getVar("dmz_skill_active", null), t = String(RPG.getVar("dmz_kiweapon", "") || "");
        return on && typeof on === "object" && on.kimanipulation && C.KI_WEAPONS[t] ? C.KI_WEAPONS[t] : null;
    }
    function now() { return RPG.nowMs(); }
    function onEntity() { try { var tg = RPG.target(); return !!tg && tg.type === "entity"; } catch (e) { return false; } }

    // ---- the swing (MinecraftMixin.startAttack / tick / executeAttack) ----
    // With a server that can take client-timed hits (it says so with "dmz_melee_v"), the swing runs here like the
    // original's client: the animation and the swing sound start on the click, the wind-up counts down on this
    // computer, and when the swing connects the target under the crosshair is sent with "dmz_hit"; the server checks
    // the timing, the combo step, the slot and the range and lands it. The click itself is cancelled (no vanilla hit),
    // except on a block with nobody in front (mining). A click up to 1 tick before the cooldown ends is queued
    // (for 4 ticks); holding the button keeps swinging. Older servers: the vanilla hit, delayed on the server.
    var V2 = false, Q = null;                                     // Q: the swing waiting to connect
    RPG.net.on("dmz_melee_v", function (d) { V2 = !!(d && d.v >= 2); });
    RPG.on("load", function () { try { RPG.net.send("dmz_melee_hello", {}); } catch (e) { } });
    function target() { try { return RPG.target() || { type: "miss" }; } catch (e) { return { type: "miss" }; } }
    function timingNow(kw) { return C.timing(4 + (kw ? kw.attackSpeed : 0)); }
    // Status.isKiShareLocked (giving ki, a god ritual: 46_dmz_kishare.js) refuses attacks and the guard like a stun
    function kiShareLocked() { return RPG.player.hasEffect("dmz_ki_sharing") || RPG.player.hasEffect("dmz_god_ritual"); }
    function canSwing() { return created() && emptyHands() && !st.guarding && !RPG.player.hasEffect("stunned") && !kiShareLocked() && !RPG.screen.getOpen(); }
    function startAttack() {
        if (Q || !canSwing()) return;
        var kw = kiWeapon(), t = timingNow(kw), ms = now();
        var left = st.hitAt + t.cooldown * 50 - ms;
        if (left > 0) {                                           // ATTACK_QUEUE_WINDOW_TICKS = 1
            if (left <= 50) { st.queued = true; st.queuedTicks = 0; }
            return;
        }
        st.queued = false;
        if (ms - st.hitAt > (t.cooldown + C.CFG.comboResetExtra) * 50) st.count = 0;
        if (kw !== st.weapon) { st.weapon = kw; st.count = 0; }
        var infusion = RPG.player.hasEffect("ki_infusion") && RPG.player.level >= 5;
        var atk = kw ? kw.attacks[st.count % kw.attacks.length] : C.attackFor(st.count, infusion);
        Q = { left: C.windup(t, kw ? 0.5 : atk.upswing), c: st.count, slot: RPG.player.hotbarSlot };
        st.last = ms;
        DBR_ANIMATOR.playMelee(atk.anim, t.speed);
        try { if (RPG.avatar.refresh) RPG.avatar.refresh(RPG.player.id); } catch (e0) { }   // on this frame, not the next tick
        // playLocalAttackFeedback: the swing sound on this computer at once (the server plays it to the others)
        try { RPG.soundAt(kw ? "dmzpack:" + atk.sound : "dmzpack:fist_punch", RPG.player.x, RPG.player.y, RPG.player.z, 0.7,
            (kw && atk.pitch ? atk.pitch : 1) * (0.9 + Math.random() * 0.2)); } catch (e1) { }
        RPG.net.send("dmz_melee", { c: Q.c, a: atk.anim, s: t.speed, slot: Q.slot, v: 2 });
    }
    // ---- TargetFinder.findAttackTargetResult + MeleeHitbox / WeaponHitBoxes / OrientedBoundingBox: everything whose box
    // meets the swing's box (the crosshair target first, then the nearest), not only what the crosshair is on. A forward
    // box is range/2 wide and high and 1 + range deep, a horizontal / vertical plane 2 x range by range / 3 and 1.25 x
    // range deep; it starts at 80 % of your height, half your width out, and runs along where you look. Fists reach 2,
    // the ki blade (sword) 2.5, the scythe and the claw lance (trident) 3.5. (The original also skips targets behind a
    // block; the server checks reach.)
    var KW_BOX = { blade: [2.5, ["horizontal", "horizontal", "forward"]], scythe: [3.5, ["horizontal", "horizontal"]], clawlance: [3.5, ["forward"]], angelstaff: [3.5, ["forward"]] };   // the Angel's Staff fights as the claw lance
    function dirFrom(pitch, yaw) {
        var p = pitch * Math.PI / 180, y = yaw * Math.PI / 180;
        return [-Math.sin(y) * Math.cos(p), -Math.sin(p), Math.cos(y) * Math.cos(p)];
    }
    function cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
    function dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
    function unit(a) { var l = Math.sqrt(dot(a, a)); return l < 1e-9 ? null : [a[0] / l, a[1] / l, a[2] / l]; }
    // separating axis test: an oriented box (c, axes u[3], half sizes e[3]) against an axis-aligned box (min, max)
    function obbHitsAabb(c, u, e, mn, mx) {
        var bc = [(mn[0] + mx[0]) / 2, (mn[1] + mx[1]) / 2, (mn[2] + mx[2]) / 2], be = [(mx[0] - mn[0]) / 2, (mx[1] - mn[1]) / 2, (mx[2] - mn[2]) / 2];
        var W = [[1, 0, 0], [0, 1, 0], [0, 0, 1]], t = [bc[0] - c[0], bc[1] - c[1], bc[2] - c[2]], axes = u.concat(W), i, j;
        for (i = 0; i < 3; i++) for (j = 0; j < 3; j++) { var x = unit(cross(u[i], W[j])); if (x) axes.push(x); }
        for (i = 0; i < axes.length; i++) {
            var L = axes[i], ra = 0, rb = 0;
            for (j = 0; j < 3; j++) { ra += e[j] * Math.abs(dot(u[j], L)); rb += be[j] * Math.abs(dot(W[j], L)); }
            if (Math.abs(dot(t, L)) > ra + rb) return false;
        }
        return true;
    }
    function swingTargets(atkIndex, kw, cursorId) {
        var me = RPG.player, pitch = me.pitch, yaw = me.yaw, h = Number(me.height) || 1.8, w = Number(me.width) || 0.6;
        var range = 2, shape = (C.attackFor(atkIndex, false) || {}).shape || "forward";
        if (kw) { var kb = KW_BOX[String(RPG.getVar("dmz_kiweapon", "") || "")]; if (kb) { range = kb[0]; shape = kb[1][atkIndex % kb[1].length]; } }
        var look = dirFrom(pitch, yaw), flat = unit([look[0], 0, look[2]]) || look;
        var origin = [me.x + flat[0] * w * 0.5, me.y + h * 0.8, me.z + flat[2] * w * 0.5];
        var size = shape === "forward" ? [range * 0.5, range * 0.5, 1 + range] : shape === "horizontal" ? [range * 2, range / 3, range * 1.25] : [range / 3, range * 2, range * 1.25];
        var az = look, up = Math.abs(az[1]) > 0.999 ? [1, 0, 0] : [0, 1, 0], ax = unit(cross(up, az)), ay = unit(cross(az, ax));
        var e = [size[0] / 2, size[1] / 2, size[2] / 2], off = e[2] - w * 0.3;
        var c = [origin[0] + az[0] * off, origin[1] + az[1] * off, origin[2] + az[2] * off];
        var list = [];
        try { list = RPG.world.entities(range + 1 + Math.max(w, h)); } catch (x) { }
        var hits = list.filter(function (en) {
            if (!en || en.id === me.id) return false;
            var hw = (Number(en.width) || 0.6) / 2, hh = Number(en.height) || 1.8;
            return obbHitsAabb(c, [ax, ay, az], e, [en.x - hw, en.y, en.z - hw], [en.x + hw, en.y + hh, en.z + hw]);
        });
        hits.sort(function (a, b) {
            if (a.id === cursorId) return -1;
            if (b.id === cursorId) return 1;
            var da = (a.x - me.x) * (a.x - me.x) + (a.y - me.y) * (a.y - me.y) + (a.z - me.z) * (a.z - me.z);
            var db = (b.x - me.x) * (b.x - me.x) + (b.y - me.y) * (b.y - me.y) + (b.z - me.z) * (b.z - me.z);
            return da - db;
        });
        return hits.slice(0, 8).map(function (en) { return en.id; });
    }
    function executeAttack() {
        var tg = target(), cursor = tg.type === "entity" && tg.entityId !== undefined ? tg.entityId : -1;
        var ids = swingTargets(Q.c, kiWeapon(), cursor);
        if (cursor >= 0 && ids.indexOf(cursor) < 0) ids.unshift(cursor);
        RPG.net.send("dmz_hit", { c: Q.c, slot: Q.slot, ids: ids });
        st.count = Q.c + 1;
        st.hitAt = now();                                         // the cooldown restarts when the hit lands
        Q = null;
    }
    function cancelSwing() { Q = null; st.queued = false; }       // cancelUpswing
    RPG.on("tick", function () {
        if (!V2) return;
        if (Q) {
            if (!canSwing() || RPG.player.hotbarSlot !== Q.slot) { cancelSwing(); return; }
            if (Q.left > 0) Q.left--;
            else executeAttack();
            return;
        }
        if (st.queued) {
            if (++st.queuedTicks > 4) st.queued = false;
            else { var kw = kiWeapon(); if (now() >= st.hitAt + timingNow(kw).cooldown * 50) startAttack(); }
            return;
        }
        // continueAttack: holding the button keeps the combo going (not while it is mining a block). Only a press that
        // started in the game counts, like the attack key: a click in a menu (dragging items in the inventory, a button
        // that closes the screen while it is still held) never swings
        if (!RPG.isKeyDown("key.mouse.left")) { st.miningHold = false; st.pressedInGame = false; return; }
        if (!st.pressedInGame || st.miningHold || !canSwing()) return;
        var tg = target();
        if (tg.type === "block") return;
        var k2 = kiWeapon();
        if (now() >= st.hitAt + timingNow(k2).cooldown * 50) startAttack();
    });

    // A screen opening (inventory, chest, a script menu) lets go of the attack and guard like vanilla's KeyMapping.releaseAll:
    // a swing still winding up is dropped and the held buttons count again only after a new press in the game.
    RPG.on("screenOpen", function () { cancelSwing(); st.pressedInGame = false; st.rightInGame = false; });
    // the voided vanilla click of a player on the plain first-person arms (shared "dbr_fp_arms") makes no "no damage" thud
    RPG.on("sound", function (id, cat, x, y, z) {
        if (id !== "minecraft:entity.player.attack.nodamage") return;
        var hit = false;
        RPG.avatar.players().forEach(function (pl) {
            if (hit || !pl.shared("dbr_fp_arms", null)) return;
            var dx = pl.x - x, dy = pl.y - y, dz = pl.z - z;
            if (dx * dx + dy * dy + dz * dz < 1) hit = true;
        });
        return hit ? false : undefined;
    });
    RPG.on("mouse", function (button, down) {
        // (fired only while no screen is open)
        if (button === 0) st.pressedInGame = !!down;
        if (button === 1) st.rightInGame = !!down;
        if (RPG.screen.getOpen() || !created()) return;
        if (button === 0 && down) {
            if (kiShareLocked()) return false;                      // KiShareInput.onInteraction: the attack is cancelled
            if (!emptyHands() || st.guarding || RPG.player.hasEffect("stunned")) return;
            if (V2) {
                if (target().type === "block") { st.miningHold = true; return; }   // shouldUseCombatAttack: mine
                startAttack();
                // the plain first-person arms (no animated body) only swing on the vanilla click: it goes through and the
                // server voids its hit (scripts/11_dmz_combat.js), so the punch still lands once, when the combo's swing connects
                if (typeof DMZ_OPTS !== "undefined" && !DMZ_OPTS.firstPersonAnimated()) return;
                return false;
            }
            var kw = kiWeapon(), t = C.timing(4 + (kw ? kw.attackSpeed : 0)), ms = now();
            // still recovering: the original ignores the click (startAttack is cancelled), so a quick second click on
            // someone can't land an unanimated hit of its own
            // (MinecraftMixin: no new swing during the wind-up, and the attack cooldown restarts when the hit lands)
            if (ms < st.hitAt + t.cooldown * 50) return onEntity() ? false : undefined;
            if (ms - st.hitAt > (t.cooldown + C.CFG.comboResetExtra) * 50) st.count = 0;
            if (kw !== st.weapon) { st.weapon = kw; st.count = 0; }         // a new combo with a new weapon
            var infusion = RPG.player.hasEffect("ki_infusion") && RPG.player.level >= 5;
            var atk = kw ? kw.attacks[st.count % kw.attacks.length] : C.attackFor(st.count, infusion);
            st.last = ms;
            st.hitAt = ms + (C.windup(t, kw ? 0.5 : atk.upswing) + 1) * 50;   // when this swing connects
            DBR_ANIMATOR.playMelee(atk.anim, t.speed);
            try { if (RPG.avatar.refresh) RPG.avatar.refresh(RPG.player.id); } catch (e0) { }
            RPG.net.send("dmz_melee", { c: st.count, a: atk.anim, s: t.speed });
            st.count++;
        }
    });

    // ---- guard (ClientStatsEvents: BLOCK_KEY = right mouse, polled every tick) ----
    // The real button state is read every tick instead of trusting press/release events: a release while a screen is
    // open, the window is in the background or the packet order shuffles must never leave the guard (and its pose) on.
    // While guarding, the client repeats {on: true} every 10 ticks; the server drops a guard that stops hearing it.
    var GUARD_KEY = "key.mouse.right", HEARTBEAT = 10, CONFIRM_MS = 600;
    function guardHeld() {
        // Left Alt + right click is the ki blast (51_dmz_ki_render.js), not a guard
        // (GLFW lets go of every held button when the window loses focus, so alt-tab already reads as released;
        // isWindowFocused is false on some window systems even while playing)
        if (!RPG.isKeyDown(GUARD_KEY)) { st.rightInGame = false; return false; }
        return !!st.rightInGame && !RPG.screen.getOpen() && !RPG.isKeyDown("key.keyboard.left.alt");
    }
    function setGuard(on) {
        if (on) cancelSwing();                                     // ClientStatsEvents: the guard key cancels the upswing
        st.guarding = on;
        st.sentAt = now();
        st.beat = 0;
        DBR_ANIMATOR.setLocalGuard(on);
        RPG.net.send("dmz_guard", { on: on });
    }
    RPG.on("tick", function () {
        var held = guardHeld();
        if (!held) st.needRelease = false;
        var can = created() && emptyHands() && !RPG.player.hasEffect("stunned") && !kiShareLocked() && now() >= st.relock && !st.needRelease;
        if (!st.guarding) {
            if (held && can) setGuard(true);
            return;
        }
        if (!held || !can) {
            setGuard(false);
            st.relock = now() + 250;                                       // 5-tick relock after release (BLOCK_REACTIVATION_LOCK_TICKS)
            return;
        }
        // the server ended it (guard break, stun, refused): stand down until the button is let go
        if (!RPG.player.hasEffect("guarding") && now() - st.sentAt > CONFIRM_MS) {
            setGuard(false);
            st.needRelease = true;
            return;
        }
        if (++st.beat >= HEARTBEAT) { st.beat = 0; RPG.net.send("dmz_guard", { on: true, beat: 1 }); }
    });

    // ---- the original's melee hit particles (scripts/11_dmz_combat.js sends "dmz_hitfx") ----
    //  punch  PunchParticle: punch_particle_0-4 over 10 ticks, 0.8 growing 0.05 a tick, white, 0.8 alpha fading out
    //  block  BlockParticle: block_0-2 over 3 ticks, size 1, fading out, tinted by the poise left
    //  parry  GuardBlockParticle (white) + 15 SPARKS (KiSplashParticle on spark1-5) + 15 tiny KI_TRAIL flecks
    //  break  GuardBlockParticle in red
    //  (all drawn at full brightness, like the original's getLightColor)
    var PX = "dmzpack:";
    function seq(names) { return names.map(function (n) { return PX + n; }); }
    var PUNCH = seq(["punch_particle_0", "punch_particle_1", "punch_particle_2", "punch_particle_3", "punch_particle_4"]);
    var BLOCK = seq(["block_0", "block_1", "block_2"]), GUARD = seq(["block_0", "punch_particle_2", "ki_exp5", "ki_exp6"]);
    var SPARKS = seq(["spark1", "spark2", "spark3", "spark4", "spark5"]);
    var ROCK = seq(["rock_particle_0", "rock_particle_1", "rock_particle_2", "rock_particle_3", "rock_particle_4", "rock_particle_5",
        "rock_particle_6", "rock_particle_7", "rock_particle_8", "rock_particle_9", "rock_particle_10", "rock_particle_11"]);
    var TRAIL = seq(["ki_trail0", "ki_trail1", "ki_trail2", "ki_trail3", "ki_trail4", "ki_trail5"]);
    function hex(c) {
        function h(v) { var s = Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16); return s.length < 2 ? "0" + s : s; }
        return "#" + h(c[0]) + h(c[1]) + h(c[2]);
    }
    function sprite(o) { try { RPG.particles.sprite(o); } catch (e) { } }
    RPG.net.on("dmz_hitfx", function (d) {
        if (!d || !RPG.player.present) return;
        var x = d.x, y = d.y, z = d.z;
        if (d.k === "punch") {
            sprite({ texture: PUNCH, animate: true, x: x, y: y, z: z, size: 0.8, grow: 0.05, life: 10, alpha: 0.8, fade: "life",
                collide: false, fullbright: true });
        } else if (d.k === "block") {
            sprite({ texture: BLOCK, animate: true, x: x, y: y, z: z, size: 1, life: 3, fade: "life", collide: false, fullbright: true,
                color: hex(d.c || [0.2, 0.9, 1]) });
        } else if (d.k === "rocks") {
            // MomentumImpactHandler.spawnRockImpactCircle: 20 ROCK particles on a ring (RockParticle: 0.1-0.3, 40-80 ticks,
            // drifting up 0.002 a tick, sideways motion x 0.9, spinning 0.1, fading over the last 10 ticks)
            var r = Number(d.r) || 1.9;
            for (var k = 0; k < 20; k++) {
                var ang = Math.PI * 2 * k / 20, g = function () { return (Math.random() + Math.random() + Math.random() - 1.5) * 0.8; };
                sprite({ texture: ROCK, x: x + Math.cos(ang) * r + g() * 0.08, y: y + g() * 0.03, z: z + Math.sin(ang) * r + g() * 0.08,
                    vx: g() * 0.01, vy: g() * 0.01 + Math.random() * 0.02, vz: g() * 0.01, friction: 1, drag: 0.9, accelY: 0.002, gravity: 0,
                    size: [0.1, 0.3], life: [40, 80], roll: [0, 3.14], rollSpeed: 0.1, fade: 10, blend: "opaque", collide: true });
            }
        } else if (d.k === "parry" || d.k === "break") {
            sprite({ texture: GUARD, animate: true, x: x, y: y, z: z, size: 1, grow: 0.1, life: 10, collide: false, fullbright: true,
                color: d.k === "break" ? hex([1, 0.1, 0.1]) : "#FFFFFF" });
            if (d.k === "parry") {
                for (var i = 0; i < 15; i++) {
                    sprite({ texture: SPARKS, animate: true, x: x, y: y, z: z, size: 1, grow: 0.1, life: 10, collide: false, fullbright: true, blend: "opaque" });
                    sprite({ texture: TRAIL, animate: true, x: x, y: y, z: z, vx: 1, vy: 1, vz: 1, friction: 0.9, size: 0.05, growMul: 0.97,
                        life: [25, 35], fade: "life", collide: false, fullbright: true, blend: "additive" });
                }
            }
        }
    });
})();
