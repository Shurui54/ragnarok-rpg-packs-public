// =====================================================================================
//  28_dbr_roles.js - the Ragnarok original's god roles: shared data (server + client)
// =====================================================================================
//  Port of the Ragnarok original (GPL-3.0, see NOTICE.md, by Shurui):
//    shuruisutilities energy/EnergyKind, energy/RoleTitles, energy/EnergyManager (the numbers), god/RoleMove,
//    compat/dmz/DragonTechniqueDefs.buildRole (the two role techniques), god/RagnarokKiWeapon +
//    core/mixin/dmz/MixinDmzKiWeaponConfig / MixinDmzKiWeaponColour / client/MixinDmzKiWeaponRender (the Angel's
//    Staff: a ki weapon that fights as the claw lance and is drawn as painted, untinted);
//    ragnarok_key roles/DestructionAura, AngelState, GodKiPrison, GodHakai, DestructionReflectGuard (their numbers).
//  Server side: scripts/94c_dbr_roles.js. Client side: client/scripts/94_dbr_roles.js.
//
//  The role titles (held through the tournaments' title system, 94_dbr_tournaments.js):
//    god_of_destruction  God of Destruction  -> Sphere of Destruction, Hakai, the destruction aura, the clash bypass
//    angel               Angel               -> the angelic state (parry and counter), the Angel's Staff
//    grand_zeno          Grand Zeno          -> both movesets (bar drawn in the destroyer's purple)
// =====================================================================================
var DBR_ROLE_DATA = (function () {
    // RoleTitles: persisted holder ids, never rename
    var TITLES = { GOD: "god_of_destruction", ANGEL: "angel", ZENO: "grand_zeno" };
    // EnergyKind, in wire order (append only); MALICE is the shadow dragons' (not in DBR)
    var KINDS = ["malice", "destruction", "angelic"];
    // EnergyManager: a flat 0..100 bar, a standard move a quarter of it, refilling 0.5 a second for everyone
    var MAX = 100, COST_STANDARD = 25, REGEN_PER_SECOND = 0.5;
    // EnergySync: regen every 20 ticks; a push when the kind changes or the value moves 0.5
    var PUSH_EPSILON = 0.5;

    // DestructionAura / AngelState: 5 a second while held (drained once a second), the aura's 60 s backstop, the
    // angelic state's 15 s cap, the aura's 4-block interception box, the angel counter (half the blow, 24 blocks)
    var AURA = { DRAIN_PER_SECOND: 5, MAX_TICKS: 20 * 60, INTERCEPT_RADIUS: 4.0, RGB: 0x9B30FF };
    var ANGEL = { DRAIN_PER_SECOND: 5, DURATION_TICKS: 20 * 15, COUNTER_DAMAGE_SHARE: 0.5, COUNTER_RANGE: 24.0, RGB: 0xFFFFFF };
    // DestructionReflectGuard: a tenth of what a melee hit really took, back at the attacker, within 24 blocks
    var REFLECT = { SHARE: 0.10, RANGE: 24.0 };
    // GodKiPrison: the sphere (3 s, a hit and a 15 ki / 15 stamina drain a second), its throw and its gathering
    var PRISON = { DURATION_TICKS: 60, TICK_INTERVAL: 20, DAMAGE_TICKS: 3, DRAIN_PER_TICK: 15, REACH: 24.0, ORB_DIAMETER: 4.0,
        CHARGE_ORBS: 4, CHARGE_RING_RADIUS: 1.7, CHARGE_SPIN_PER_TICK: 0.16, CHARGE_ORB_MIN: 0.7, CHARGE_ORB_MAX: 1.3,
        THROWN_DIAMETER: 2.0, THROW_SPEED: 0.99, MAX_FLIGHT_TICKS: 100, CHARGE_BURN_RADIUS: 1.7 + 1.0, CHARGE_BURN_INTERVAL: 10,
        CHARGE_BURN_TICKS: 8, COLORS: { core: "#9B30FF", border: "#5A0A8A", outline: "#2A0044" } };
    // GodHakai: 8 real hours, 32 blocks, the wind-up timed to the sound (bass hit at tick 195), a 14-tick tail
    var HAKAI = { COOLDOWN_MS: 8 * 60 * 60 * 1000, REACH: 32.0, CHARGE_TICKS: 195, TAIL_TICKS: 14 };

    // ScouterStatHudOverlay: fill sprite per kind
    var HUD = { malice: { fill: "malice_fill" }, destruction: { fill: "destroyer_fill" }, angelic: { fill: "angel_fill" } };

    // GlowOutline's colours (the destroyer's team colour LIGHT_PURPLE, the angel's no-team WHITE), drawn as the God Ki
    // outline (07c_dmz_outline.js, the original's transformation_outline chain) with God Ki's own thickness, fire and
    // body glow (07_dmz_forms_data.js godki: OL("gradient", ..., 2.0, 0.6, 0.5)); the second colour is each role's own
    // deeper shade (the destruction purple 0x9B30FF, the angelic bar's silvery blue 0xD8FDFF).
    var OUTLINE = {
        destruction: { c: "#FF55FF", c2: "#9B30FF", m: "gradient", t: 2.0, fire: 0.6, bg: 0.5 },
        angelic: { c: "#FFFFFF", c2: "#D8FDFF", m: "gradient", t: 2.0, fire: 0.6, bg: 0.5 }
    };
    function outlineSpec(kind) {
        var o = OUTLINE[kind];
        return o && typeof DMZ_OUTLINE !== "undefined" ? DMZ_OUTLINE.spec(o.c, o.c2, o.m, o.t, o.fire, o.bg) : null;
    }

    function grantsDestruction(t) { return t === TITLES.GOD || t === TITLES.ZENO; }
    function grantsAngelic(t) { return t === TITLES.ANGEL || t === TITLES.ZENO; }

    // god/RoleMove: id (persisted on technique rows), name, the bar it spends, colours, animation prefix; the cost is
    // MoveChargeTracker.costOf (hakai the whole bar, the sphere the standard quarter)
    var MOVES = {
        god_ki_prison: { id: "god_ki_prison", name: "Sphere of Destruction", kind: "destruction", cost: COST_STANDARD,
            core: 0xB44BFF, outer: 0x5A0A8A, anim: "ki.finalflash" },
        god_hakai: { id: "god_hakai", name: "Hakai", kind: "destruction", cost: MAX,
            core: 0x9B30FF, outer: 0x3A0A5A, anim: "ki.bigbang" }
    };
    function isMove(id) { return !!MOVES[id]; }

    function hx(n) { return "#" + ("000000" + n.toString(16).toUpperCase()).slice(-6); }

    // DragonTechniqueDefs.buildRole: a MEDIUM_BALL (it charges and leaves the caster free to move), cast time 20, an 8 s
    // cooldown, no ki or TP cost, damage multiplier 1, a hair-thin charge orb (0.05: no visible ball), the move's
    // animation. No race list: the TITLE is the gate (94c_dbr_roles.js grants and removes the moves).
    if (typeof DMZ_TECH_DATA !== "undefined") {
        Object.keys(MOVES).forEach(function (id) {
            var m = MOVES[id];
            if (DMZ_TECH_DATA.KI[id]) return;
            DMZ_TECH_DATA.KI[id] = { id: id, kind: "ki", name: "technique.dbr." + id, author: "Ragnarok", type: "MEDIUM_BALL", dmg: 1.0,
                colors: { core: hx(m.core), border: hx(m.outer), outline: hx(m.outer) }, size: 0.05, speed: 1.0, cd: 8, cast: 20, anim: m.anim,
                chargeSound: "ki_explosion_charge", fireSound: "kiblast_shoot", role: m.kind, en: m.name };
            DMZ_TECH_DATA.KI_IDS.push(id);
        });
    }

    // god/RagnarokKiWeapon ANGEL_STAFF ("angelstaff", persisted as the selected weapon): a ki weapon type that stands in
    // as the claw lance (MixinDmzKiWeaponConfig: same combo, timings, sounds, cost, damage and attack speed), drawn from
    // its own model (dmzpack:geo/weapons/kiweapon_angelstaff.geo.json) as painted and untinted (20_races.js). Angels only.
    var STAFF = "angelstaff";
    if (typeof DMZ_COMBAT !== "undefined" && DMZ_COMBAT.KI_WEAPONS && DMZ_COMBAT.KI_WEAPONS.clawlance && !DMZ_COMBAT.KI_WEAPONS[STAFF]) {
        var lance = DMZ_COMBAT.KI_WEAPONS.clawlance, staff = {};
        for (var k in lance) staff[k] = lance[k];
        staff.role = "angelic";
        staff.name = "Angel's Staff";
        staff.painted = true;
        DMZ_COMBAT.KI_WEAPONS[STAFF] = staff;
        DMZ_COMBAT.KI_WEAPON_ORDER.push(STAFF);
    }

    return { TITLES: TITLES, KINDS: KINDS, MAX: MAX, COST_STANDARD: COST_STANDARD, REGEN_PER_SECOND: REGEN_PER_SECOND, PUSH_EPSILON: PUSH_EPSILON,
        AURA: AURA, ANGEL: ANGEL, REFLECT: REFLECT, PRISON: PRISON, HAKAI: HAKAI, HUD: HUD, OUTLINE: OUTLINE, outlineSpec: outlineSpec,
        MOVES: MOVES, isMove: isMove, STAFF: STAFF, grantsDestruction: grantsDestruction, grantsAngelic: grantsAngelic };
})();
