# Dragon Block Ragnarok

A Dragon Ball game for the Ragnarok Modding Toolkit, written entirely in its scripting API. Licensed GPL-3.0-or-later (see `LICENSE`); credits for the original game and art are in `NOTICE.md`.

## Keys

The original's default keys (rebind them in Options > Controls > "Dragon Block Ragnarok"):

| Key | Action |
|---|---|
| Alt+1..4 / Ctrl+1..4 | technique slots 1-8 |
| C (hold) | charge ki: power release climbs, ki refills faster |
| Alt+C (hold) | lower power release |
| V | stats menu (the character creator if you haven't made one) |
| F | fly |
| R | dash |
| Z | lock on |
| ` (grave) | the Dragon Block menu (same as `/dbrgui`) |

Being rebuilt to the original's exact behaviour next: G (transform), H (instant transmission), X (utility menu), F4 (ki sense), right click (block), Alt+right click (ki blast).

## The Dragon Block menu (`/dbrgui`)

One screen that reaches every Dragon Block screen, like DMZ Ragnarok's hub: `/dbrgui` (everyone) or the "Dragon Block
menu" key (` by default). It is an extra way in: every key and command below still opens its screen exactly as before.
Rows: Stats (the character creator while you have none), Techniques, Sagas, Minigames, Party, Characters, Dragon
Ball-Sack (while you wear one), Z-Souls, Raids, Tournaments, Dungeons and Options. Staff also get dropdown sections with
the editors they may use, checked on the server the same way each editor's own command checks it: Saga Editor and Form
Editor (operators), Raid Editor (`rg.raid.edit`), Tournament Editor (`rg.tourney.edit`), Dungeon Maker (dungeon staff),
Dungeon Config (the old floors, `dbr.legacySystem`), NPC Regions, NPC Picker, Stat Shrines and Dragon Wishes (operators)
and Prestige Settings (`dbr.prestige.admin`). Esc on a screen opened from the menu goes back to the menu. The masters'
screens and the tournament arenas' sign-ups open by talking to their NPCs, so they are not in it.

## What is ported so far

- The character creator: race carousel with the original's panoramas and racial skills, then the Body / Hair / Eyes / Face / Tattoo / Class tabs.
- The Xenoverse HUD, the stats screen (V), the original's eight classes and six stats, and the original's formulas for health, ki, stamina, damage, defence, power release, power level, TP gains, stat prices and level.

## Animations

Every player plays the original's own animations, chosen the way the original chooses them (its 10 animation
controllers, ported to `client/scripts/40_animator.js`): walking and running at your speed, crouching,
swimming, climbing, the landing after a long fall, flying in every direction, the per-race ki charge,
surge, blocking, shields, punches and tool swings, eating, dashes and dodges, techniques (cast and fire),
transformations and the tail, which gets livelier the faster you move.

What other players are doing comes from the server (`scripts/12_anim_state.js`), so everyone sees the
same thing. Addons can change any of it:

```js
// client script: spin while a server flag is set
DBR_ANIMATOR.extend((pl, out) => { if (pl.shared("spinning")) out.layers.extra = "skp.meteor"; });
// a weapon stance
DBR_ANIMATOR.poses["minecraft:diamond_sword"] = "combat.pose_two_handed_sword";
// procedural bones: wag the tail harder
DBR_ANIMATOR.extend((pl, out) => { out.bones.tail1 = { ry: Math.sin(pl.tick / 3) * 15 }; });
```

## Auras

Auras are drawn the way the original draws them: the 3D styles (Smooth, Sparking, God) with the original's own shaders
(`resources/assets/dbr/shaders/core/aura_*`, its noise texture and bloom), every form's original aura look (colour,
layer, 3D type and style numbers, `shared/07b_dmz_aura_data.js`), charge layers, the ground waves, the lean in
fast flight, swimming bodies, and your own aura in first person (a faint shell around you, or the original's screen card
for 2D auras). `client/scripts/43_dmz_aura_shader.js` does it; if a shader fails to load the engine's own
auras show instead.

## Form editor: auras, overlays and your own models

Operators open the form editor with `/rpgc formeditor` (or its key). Besides the stats, a form can use:

- **Aura**: any original 2D aura sheet (Kakarot, Saiyan, Namekian, Frost, Majin, Bio-Android, Demon, God, God Ki,
  God Form, White God Form, UI, UE) or a pack's `textures/auras/*_aura.png` / `textures/forms/*_aura.png` (4 frames
  side by side, with `*_cross.png` next to it for the ground wave), the 3D type, layer and every 3D style number and colour, an extra aura layer, lightning.
- **Overlays**: up to six sheets drawn over the body, eyes or hair: the original's race sheets or any pack's
  `textures/overlays/*.png` / `textures/forms/*.png` (64x64 skin layout), each in a form colour or a fixed one,
  optionally only on some bones.
- **Model**: a GeckoLib model of your own as the form's whole body (a giant ape, a custom transformation) or as
  an overlay on it.
- **Dodge**: % chances to avoid a hit outright while in the form, one each for physical hits (fists,
  weapons, mobs, arrows), strike skills and ki attacks, plus a % damage mitigation on hits that land. A dodge has no
  hurt sound, flinch or knockback; nearby players hear a whoosh and see the upper body twist aside.
- **Buffs**: every hit taken in the form adds a % of each stat's base value (STR, SKP, RES, VIT, PWR,
  ENE, set per stat) as a bonus, up to "Max Bonus % of base" (100 = the stat at most doubles). It is the original's flat
  bonus (not multiplied by the form), shows in the stats screen (hover a stat) and ends with the form.

Every picker is a searchable list with a picture of each choice. Saving applies at once for everyone online.

### Adding a GeckoLib model

1. Export from Blockbench as a GeckoLib model ("Bedrock"/GeckoLib entity): `name.geo.json`, the texture
   `name.png`, and (optional) `name.animation.json`.
2. Put them in `ragnarok_rpg/resources/` (or an art pack) as
   `assets/<namespace>/geo/forms/name.geo.json`, `assets/<namespace>/textures/forms/name.png` and
   `assets/<namespace>/animations/forms/name.animation.json` (any namespace, lowercase).
3. In the form editor's Model tab pick the model (models under `geo/forms/` and `geo/entity/` are listed; type any
   other id), its texture and animations, and "The whole body" or "Overlay".
   Body models play the animations named `idle`, `walk`, `run`, `fly`, `jump`, `fall`, `swim` and `sneak` from their
   own file; without one they use the original's player animations (name the bones like the original's: `head`, `body`, `right_arm`,
   `left_arm`, `right_leg`, `left_leg`). Overlays follow the player's bones that share their bone names, or ride
   whole on one bone (`body` by default).
4. Save the race. Servers send `resources/` to joining players with the rest of their art, so everyone sees it.

## Commands

DBR's commands are script commands: type `/rpgc <command> ...` (Tab completes every argument; long lists such as
quests, techniques and forms can be searched by typing any part of a name). Every original command is here
with the original's arguments, permissions and messages, named without "dmz" (the original's `/dmzstats set STR 100` is
`/rpgc stats set STR 100`). Old DBR names (`/rpgc dmzform`, `dmztech`, `dmzskill`, `dmzquest`, `testall`, `/dmzraid`...)
still work but are no longer suggested.

**Permissions** are the original's nodes with `dbr.` in front of the original's name minus "dmz" (`dragonminez.dmzstats.set.others` is
`dbr.stats.set.others`, `dragonminez.dmz.reload` is `dbr.reload`). Operators and holders of `dbr.admin` have them all;
everyone has what the original gives everyone (`dbr.stats.info.self`, `skill.list.self`, `tech.list.self`, `effect.list.self`,
`points.info.self`, `quest.list.self`, `quest.info`, `quest.track.self`, `party.use`, `form.list.self`,
`alignment.info.self`, `tail.self`, `hair.self`). A `.self` node allows yourself, `.others` other players (`[targets]`
takes a name or a selector: `@a`, `@p`, `@r`, `@s`, `@a[distance=..10]`). Grant them with `/rpg perm`.

| Original command | Dragon Block Ragnarok | Arguments |
|---|---|---|
| `/dmzstats` | `/rpgc stats` | `set\|add\|remove <STR\|SKP\|RES\|VIT\|PWR\|ENE\|ALL> <amount\|min\|max> [targets]`, `relocate [targets]`, `reset [targets] [keep%] [keepSkills]` |
| `/dmzpoints` | `/rpgc points` | `set\|add\|remove <amount> [targets]` (Training Points) |
| `/dmzskill` | `/rpgc skill` | `set <skill\|all> <level> [targets]`, `add <skill\|all> [targets]`, `remove <skill\|all> [targets]` |
| `/dmzform` | `/rpgc form` | `set <form\|all> <level> [targets]`, `add <form> [targets]`, `remove <form> [targets]` (superforms, legendaryforms, godforms, androidforms, kaioken, ultimate) |
| `/dmzmastery` | `/rpgc mastery` | `set\|add current form\|stack <value> [targets]`, `set\|add ALL form\|stack\|all <value> [targets]`, `set\|add <group> <form> <value> [targets]` |
| `/dmztech` | `/rpgc tech` | `add\|remove <technique\|all> [targets]`, `experience add\|set\|remove <technique> <amount> [targets]` |
| `/dmzcooldowns` | `/rpgc cooldowns` | `<slot 1-8> <ticks> [targets]` |
| `/dmzbonus` | `/rpgc bonus` | `add <stat> <+\|-\|*> <value> <name> [applyMultipliers] [targets]`, `remove <stat> <name> [targets]`, `clear <stat> [targets]` (STR SKP DEF STM VIT PWR ENE ALL; DEF and STM share Resistance) |
| `/dmzeffect` | `/rpgc effect` | `give <mightfruit\|majin\|mutant> <seconds\|-1> [targets]`, `remove <effect\|knockout> [targets]`, `clear [targets]` |
| `/dmzalignment` | `/rpgc alignment` | `set <0-100> [targets]`, `add\|remove <amount> [targets]` |
| `/dmzclass` | `/rpgc class` | `<class> [targets]` |
| `/dmztail` | `/rpgc tail` | `cut\|grow [targets]` |
| `/dmzhalo` | `/rpgc halo` | `on\|off [targets]` |
| `/dmzhair` | `/rpgc hair` | `resync\|reset [targets]`; also `/rpgc hair [preset]` to list or pick an original hair preset |
| `/dmzrevive` | `/rpgc revive` | `[targets]` |
| `/dmzracial` | `/rpgc racial` | `reset [targets]`, `reply <accept\|reject>` |
| `/dmzweight` | `/rpgc weight` | `[turtle_shell\|workout_weights\|piccolo_cape] <weight>` |
| `/dmzquest` | `/rpgc quest` | `list [player]`, `info <quest>`, `start\|finish\|fail\|reset <quest\|all> [player]`, `track <quest\|none> [player]`, `startsaga\|finishsaga\|resetsaga <saga\|all> [player]`, `difficulty [easy\|normal\|hard] [targets]`, `questnpc spawn <npc> \| list \| remove` (quest ids use `.`: `saiyan_saga.1`) |
| `/dmzdragonballs` | `/rpgc dragonballs` | `status [set]`, `regenerate <set>` (plus DBR's `<set> scatter\|give\|awaken\|dormant`) |
| `/dmzparty` | `/rpgc party` | `invite <player>`, `accept [confirm]`, `reject`, `leave`, `list`, `kick <player>`, `disband`, `pvp` |
| `/dmzworldboss` | `/rpgc worldboss` | `results`, `locate\|tp\|reset\|ready [boss]` (plus `rebuild`, `summon`, `hp`, `debug`) |
| `/dmztournament` | `/rpgc tournament` | `ring <tournament>`, `cooldown clear <players> [tournament]` |
| `/dmzraid` | `/rpgc siteraid` | `start [type]`, `stop`, `info` (plus `omen [type]`, `sites`; the old root `/dmzraid` still works) |
| `/dmzminigame` | `/rpgc minigame` | `play <game> [targets] [masterBonus]`, `learn <game\|all> [targets]` (plus `forget`) |
| `/dmzlocate` | `/rpgc locate` | `<structure>` (no argument lists every structure) |
| `/dmzstructure` | `/rpgc structure` | `here`, `npcs` |
| `/dmzconfig` | `/rpgc config` | `<config> <key \| section key> <value>` (DBR's `ragnarok_rpg/config/*.json`) |
| `/dmzreload` | `/rpgc reload` | `[all\|config\|story\|wishes]` |
| `/dmzrestoreupdate` | `/rpgc restoreupdate` | then `confirm` within 15 s: forgets the saga editor's custom sagas and side quests |
| `/dmzdebug` | `/rpgc debug` | `[ALL\|STATS\|CHARACTER\|TECHNIQUES\|QUESTS]`, `<player> [scope]` (admins); saved as `ragnarok_rpg/local/dbrdebug/<player>.json` on your computer |
| `/dmztrigger` | `/rpgc trigger` | `<target> form <group> <form>\|base`, `stackform <group> <form>\|clear`, `clear`, `racialskill majin\|namekian ...`, `cooldowns`, `rage <0-100>`, `knockout [seconds]`, `release <value>` |

DBR's own commands, renamed where they had "dmz" in them: `raidsite` (was `dmzsite`), `fusion` (`dmzfusion`),
`buildstructure` (`dmzbuild`), `aura` (`dmzaura`), `tunnels` (`dmztunnels`), `master` (`dmzmaster`), `var` (`dmzvar`),
`grantall` (`testall`); and `power`, `help`, `setup`, `arena`, `color`, `recreate`, `leave`, `otherworld`, `space`,
`saga`, `sagaeditor`, `formeditor`, `rituals`, `godritual`, `rgnpc`, `giveall`, `resetall`, `setrace`, `salvage`,
`dbrregen`, `dbrclash`, `beamtest` (beam clash test aids). Root commands: `/character`, `/prestige`, `/raid`, `/tourney`, `/dungeon`, `/shrine`,
`/npcregion`, `/rggrave`, `/dbrgui` (the Dragon Block menu, every screen in one place).

### God Ki and the Blue forms (DBR's own)

God Ki replaced Super Saiyan God. A Saiyan of level 5000+ (`dbr_rituals` ssgRitual.wishMinLevel) wishes for the **Knowledge of
God Ki** from Earth's Shenron, then performs the god ritual the original's way, through ki sharing: pure-hearted Saiyans in SSJ
share their ki (Ctrl + Alt + right click) with the vessel in SSJ Mastered, glide into a ring, the vessel channels, rises and
glows. How many givers is DBR's own setting (`dbr_rituals` ssgRitual.requiredChargers, 5 on servers and LAN;
ssgRitual.singleplayerRequiredChargers, 0 in singleplayer: the vessel alone, holding Charge Ki for 3 s). The ritual awakens God
Ki for good. The **God Ki** toggle sits in the
radial menu's Ki Actions beside Friendly Fist; with it on, a full **Ki Surge** (keep charging at full ki) awakens God Ki instead
of the surge. Transforming into a Super Saiyan level while in God Ki stacks it on God Ki:

| Form | Needs | Multipliers (STR, SKP, DEF, PWR) | Ki drain | Look |
|---|---|---|---|---|
| God Ki | the ritual | 3.6, 3.6, 2.85, 3.6 | 0.22 | your own hair, red eyes, a calm god aura with a gold-red outline |
| SSJ Blue | SSJ fully mastered | 4.9, 4.9, 3.7, 4.9 | 0.42 | sky-blue SSJ hair and eyes, blue aura and outline |
| SSJ Blue Evolution | SSJ 2 fully mastered | 5.6, 5.6, 4.2, 5.6 | 0.55 | deep-blue hair, the buffed body, blue lightning |
| SSJ Blue Rampage | SSJ 3 fully mastered | 6.4, 6.4, 4.8, 6.4 | 0.66 | bright cyan SSJ 2 hair, white eyes and lightning, a pulsing outline |

Each Blue form can be picked in the form menu (Extra Forms) and transformed into straight from base at 25 % mastery. A full surge
from a Super Saiyan form whose Blue form is open goes straight into that Blue form. Descending steps down Rampage, Evolution,
Blue, God Ki, base. Ops: `/rpgc rituals knowledge` (the wish) and `/rpgc rituals godki` (the ritual done).

### God roles (the Ragnarok original's God of Destruction, Angel and Grand Zeno)

Ported 1:1 from the original's real role code. Three role **titles**, held through the tournaments' title system (one holder
each; a new holder takes it from the old one): `god_of_destruction` (tag [G.O.D.]), `angel` ([Angel]) and `grand_zeno`
([Zeno], both movesets). Tournaments hand them out as rewards (`title:<id>`); staff grant them with
`/tourney title set <id> <player>` or `/rpgc role grant <id> <player>` and take them back with `/rpgc role clear <id>`. Hold
one role title at a time: like the original, a player's role is the first title they hold.

**Role energy** is the Ragnarok HUD's fourth bar, under the stamina bar: a flat 0-100 (the same for everyone, not a stat),
purple for a God of Destruction or Grand Zeno, angelic for an Angel. It refills 0.5 a second for everyone, role or not, and is
kept per character; with no role there is no bar.

| Ability | Role | Use | Cost |
|---|---|---|---|
| Destruction Aura | G.O.D., Zeno | Role Ability key (U), toggled: every projectile not yours within 4 blocks is erased (purple burst); a melee hit you take still lands in full and a tenth of the health it took goes back to the attacker (magic, within 24 blocks); up to 60 s | 5 a second (refused on an empty bar) |
| Angelic state | Angel, Zeno | Role Ability key, toggled, up to 15 s: every attack on you (falls and fire too) is turned aside with the form dodge's twist, and the attacker (the shooter, for a shot) within 24 blocks takes one of your melee hits | 5 a second |
| Sphere of Destruction | G.O.D., Zeno | technique (charge to full, cast 20 ticks, the Final Flash pose): four orbs gather round you (1.7 blocks out, growing with the charge) and hit anything within 2.7 blocks every 10 ticks; on release one ball flies to whatever your crosshair is on (24 blocks) and holds it in a 4-block sphere for 3 s (slowed, no jumping), hitting it once a second and draining 15 ki and 15 stamina. Nothing aimed at: the 25 comes back | 25 (refused at the charge below that) |
| Hakai | G.O.D., Zeno | technique (charge to full, the Big Bang pose): the target on your crosshair (32 blocks) is stunned and held while the Hakai sound plays and you stand still in the Big Bang pose for 195 ticks, then it is erased: a player dies (never a ban), anything else is removed without drops. Raid bosses, planet defenders and training masters refuse; a party ally is refused (PvP rules) | the whole bar (it must be full); then 8 REAL hours, kept with the world through restarts |
| Angel's Staff | Angel | radial menu, Ki Weapons (needs Ki Manipulation): summoned and put away like a ki weapon, fights as the claw lance; fades when the title passes on, on death, logout and respawn | the claw lance's ki per hit |
| Clash bypass | G.O.D., Zeno | firing a planet buster with a full bar: the bar is spent and the planet can't contest the shot | the whole bar |

The role techniques are in your techniques while you hold the title (equip them like any other) and removed with it; they cost
no ki and have an 8 s cooldown, refused below a full charge ("Not charged: hold it to full."). Grand Zeno's key raises both
modes together (from fully down) and lowers both if either is up, so the pair drains 10 a second. Modes end when the bar runs
dry, on the key again, on death or logout, or within a second of the role passing on. The original deals its role hits as the
caster's own player hits, which the original's combat turns into the caster's melee hit; DBR does the same (09_dmz_stats.js).
The outlines are the God Ki outline (the original's transformation_outline chain) in the role's colours. Role abilities have no
config: the numbers are the original's. `/rpgc role [info] [player]` shows a role, its bar and the Hakai cooldown; staff also
have `energy <0-100> [players]` and `hakaireset [players]` (`dbr.role.admin`).

**`/rpgc grantall [stat] [quests|noquests] [player]`** (ops, for testing; `testall` is the old name) unlocks everything:
the six stats set to 1,000,000 (or `[stat]`; never above the stat cap, which prestige widens), every engine skill and
addon skill at its top level, every form skill high enough for every form of the race (form-editor forms included),
every form and stack form fully mastered, every technique, the rituals (God Ki, Super Saiyan 5, Namekian god),
every minigame, 1e9 TP and full bars. The story quests are marked done (no rewards, no spawns) so saga-locked forms
open; `quests` plays every quest out with its rewards instead, `noquests` leaves the story alone.

## The scripts

The files are in `addons/dragon_block_ragnarok/scripts/` (open them in the F8 editor under `addons/`).

| File | What's in it |
|---|---|
| `00_project.js` | Project id/name, leveling mode **"both"** (levels give skill points, TP buys stats), XP curve, TP earning and prices, Zeni, combat formulas |
| `06_hud_dmz.js` | The original HUD as a script-defined layout (players can move/resize it) |
| `07_creator_dmz.js` | The original character creator: race, body, skin, hair, eyes, nose, mouth, class |
| `01_toolbox.js` | Shared helpers: `sfx()` (pack sounds), `act()` (play an avatar animation, then return to flying/charging), damage formulas, `lookPoint()`, lock-on, `times()` |
| `05_ui.js` | Ragnarok theme, HUD (ki/stamina bars, portrait), race + class picker, original menu tab names, colours |
| `10_stats.js` | STR, SKP, RES, VIT, PWR, ENE, three hidden "marker" stats for gear, and `powerLevel()` |
| `15_resources.js` | Ki (grows with Energy) and Stamina (grows with Vitality) |
| `20_races.js` | The six races with **avatars** built from the original's layered textures, their default colours, the `raceChange` hook that applies them, and `/rpgc color` |
| `25_classes.js` | Warrior and Spiritualist (each with a starting gi and technique) |
| `29_dmz_auras.js` | How auras look: 2D or the original's 3D styles (Smooth / Sparking / God, picked in V > Config), each form's 3D tuning, the flight lean and the ki surge's swelling aura (options in `client/scripts/43_dmz_auras.js`) |
| `30_forms.js` | `defineForm()` and 30+ forms: Kaioken x2-x20, Oozaru, Super Saiyan 1/G2/G3/2/3/4/God/Blue, Golden Oozaru, Giant/Super/Orange Namekian, the Frost Demon forms up to Golden and Metal, Semi-Perfect to Xeno, Super/Evil/Kid Majin, Super Janemba. Each swaps the avatar, adds an aura and plays an original transformation animation |
| `35_projectiles.js` | Every ball, beam, laser, disk, sprite and thrown item (30 projectiles) |
| `41_dmz_techniques.js` | The original's techniques (data in `shared/09_dmz_techniques_data.js`): learned from masters/quests/`/rpgc tech add`, a pop-up when learned, Bind to Slot (V > Skills), 8 slots on Alt/Ctrl+1..4, ki charge to 175 %, strikes and evasions; HUD in `client/scripts/47_dmz_notifications.js` and `49_dmz_techniques.js` |
| `40_skills.js` | `kiTechnique()` / `strikeTechnique()` recipes and ~50 techniques: beams, volleys, disks, the original "skp" strikes, Zanzoken, Instant Transmission, Solar Flare, barriers, Absorb, Fusion Dance, passives |
| `45_keys.js` | The original controls: charge ki, flight, dash, descend/meditate, lock-on, ascend, guard, power strike |
| `50_items.js` | Senzu beans (and farmable coloured beans), food, medicine, capsules, Gete stat capsules, scouters, three Dragon Ball sets and radars, weapons and guns, weights, Potara earrings, Nimbus, 40 music discs |
| `52_armor.js` | 47 original outfits (skin64 armour model) and a sewing pattern for each |
| `19_outfits.js` / `19c_cosmetics.js` | The Tailor's Catalogue: 878 outfit pieces grouped by their tabs (Dragon Ball, Dragon Ball Z, Super, GT, Heroes/Xeno, Multiverse, Angels, Hakaishins, Supreme Kais, Original Outfits, Extra Slot hats), Core items and Core Ore, and 165 cosmetics (masks, glasses, scars, beards, potara earrings, scouters, horns, tails, jackets, coats...) in four cosmetic accessory slots in the inventory's accessory panel; sewn from Fabric Cores. Art: the `outfitpack` art pack (asked for automatically, credits inside) |
| `55_blocks.js` | Namek terrain, ores and trees, Earth/Hell/Demon Realm blocks, flowers, herbs, growing Senzu crops, the Time Chamber floor, a Dragon Altar |
| `60_npcs_dialogue.js` | `teacher()` and 25 original masters who teach techniques, townsfolk, Namekian villagers, vehicle props, the punch machine, Shenron and Porunga |
| `65_shops.js` | Kame House, Korin, Capsule Corp., Namek, Frieza Force, Babidi, Yajirobe, Toribot's jukebox |
| `70_quests.js` | Tutorial, the Saiyan / Namek / Android / Buu sagas (21 chained quests) and side quests (tournaments, Baba, Old Kai's ritual...) |
| `75_mobs_bosses.js` | ~100 mobs (Saibamen, soldiers, robots, dinosaurs, frogs, ogres, the training shadow, the dragons) and 57 bosses, including Frieza's four forms in a row and the original's world bosses with their music |
| `77_dmz_world_bosses.js`, `77_dmz_world_bosses_ai.js` | The original's seven world bosses (Janemba, Turles, Metal Cooler Core, Tamagami 3/2/1, Gomah): lairs, sleeping / waking, group scaling, knock-outs and the Revive technique, contribution, rewards and results (`/rpgc worldboss`), and each boss's own abilities and phases; the HUD, results screen and effects are `client/scripts/68_dmz_worldboss.js` |
| `80_spawns_events.js` | Natural spawns on Earth, Namek, the Other World and in the Time Chamber (the original's biome modifiers; no timed random events, as in the original) |
| `85_world.js` | The Time Chamber, Namek and Other World dimensions, travel helpers and `/rpgc leave` |
| `86_dbr_space.js` | Space (the Ragnarok original's Space module): fly or pod above y 1000 to reach the `ragnarok_rpg:space` void (zero-g, no void kill), the sun and main planets (Earth, Namek, Sacred Kai, Planet Vegeta, Demon Realm, Beerus' planet, Planet Cereal) with their moons, rings and cloud shells, the generated universe (star systems with landable planets, lone stars, black holes) and the seven Super Dragon Ball bodies guarded by Gods of Destruction. Generated planets and moons are stamped squares of `ragnarok_rpg:planet_surface` (themes, seas, vegetation, weather, a garrison and its defender to beat to claim it: `86c_dbr_space_garrison.js`) that wrap round; fly up past y 260 to leave. Pod autopilot from the destination list or the star map (M), stars burn, black holes pull; Black Star balls land on generated planets; `dbrDestroyPlanet`. Sky, radar, overlay and star map in `client/scripts/61_dbr_space.js`; maths in `shared/15..17`; settings `/rpg config dbr_space`; ops: `/rpgc space [planet|moon|pod|auto <id>|<id>]` |
| `88_dbr_space_cereal.js` | Planet Cereal (`ragnarok_rpg:cereal_planet`, the original's "Cereal Planet" pod destination): stepped mesas, canyons with teal rivers, a cratered basin, crystal fields, Cerealian villages, old city ruins and impact craters from the data pack (`tools/cereal_worldgen.py`); a body in space on the Ragnarok original's ring 12; the pod lands beside the nearest village. Villages fill with Cerealians (eight looks, a trader, two daily errands) the first time a player comes near; one village per world is home to Granolah and Monaito, whose three quests (level 50) end with the Cerulean Radar and Granolah's pattern. Home of the Cerulean Dragon Balls. Sky: `client/scripts/62_dbr_cereal_sky.js` |
| `89_dbr_keep_inventory.js` | Partial keep inventory and death graves (the Ragnarok original's KeepPartialInventory): below level 100 a death keeps everything; from it on the hotbar, armour, off hand, accessories and cosmetic armour stay and the main inventory and experience go into a grave (fence, head and name) that despawns after 10 minutes; dragon balls always go into the grave or a totem of their own. Settings `/rpg config dbr_keep_inventory` or the Server rows of the original config menu; ops: `/rggrave cleannames | listballs | removeball | time` |
| `64_dmz_kishare.js` (+ client `46_dmz_kishare.js`) | The original's Ki sharing (Ctrl + Alt + right click a player; giving to a charging Spirit Bomb; shared ki paying a charging attack) and its god ritual, which awakens God Ki here (pure-hearted Saiyans sharing their ki with a vessel in SSJ Mastered; givers: `dbr_rituals` ssgRitual.requiredChargers, 5, and in singleplayer ssgRitual.singleplayerRequiredChargers, 0 = the vessel alone with Charge Ki) |
| `92_dmz_raids.js` | The original's raids: scouts at Saiyan craters, razed Namekian settlements, Gomah camps and Red Ribbon bases; kill one and you are Hunted, then five waves (bosses, boss bar, raid music), rewards or "YOU LOST!"; `/rpgc siteraid start|stop|info|omen|sites`; `dmz_raids` config |
| `95_dbr_rituals.js` (+ client `95_dbr_rituals.js`) | The Ragnarok original's rituals: the Knowledge of God Ki wish (it replaced the Knowledge of Super Saiyan God) and the god ritual's giver counts (the ritual itself is `64_dmz_kishare.js`; see God Ki below), Super Saiyan 5 (the fusion with Shenron, eleventh Earth wish, level 10000, 5000 levels), the Namekian god ritual at a Shenron / Porunga Idol (Primal Namekian, the spent set restored); singleplayer settings in `dbr_rituals` |
| `95_dmz_tournaments.js` (+ client `85_dmz_tournaments.js`) | The original's NPC-hosted tournaments: Fortuneteller Baba's gauntlet (her palace), the Cell Games (lethal), the World Martial Arts Tournament (Budokai arena announcer) and the Otherworld Tournament (its announcer on the grounds Grand Kai sends you to). Solo or a whole party (the leader enters); everyone accepts the rules, the draw is revealed, bouts are fought one at a time in the arena's ring with a 3 s frozen countdown, nobody else within 15 blocks, a time limit, knock-out (or death in the Cell Games), walk-away and logout forfeits, re-entry cooldowns, training points and alignment for the champion. The original's bracket screen, countdown overlay and notification card. Settings `config/dmz_tournaments/<id>.json`; ops: `/rpgc dmztournament ring <id>`, `/rpgc dmztournament cooldown clear <player\|@a> [id]` |
| `86c_dbr_space_garrison.js` | Wild planet garrisons and the conquest defender (the Ragnarok original's PlanetGarrison / PlanetConquest): the first landing on an unowned generated planet or moon rolls one family of 3-6 defenders (Saiyans, Red Ribbon, Namekians, Z-fighters, hero guard, androids; battle power 5,000-50,000 -> health BP/50, melee BP/500, defence BP/1000, the original saga brain) scattered over it, saved by uuid; when a player strikes down the last one, a theme hero (Goku, Nail, Pikkon...) scaled to that player appears and beating it claims the planet. The garrison sets the planet's toughness and shows on the star map. `/rpgc spaceplanet [info\|conquer\|unclaim]` (ops: `conquestboss`, `wipe`); settings `/rpg config dbr_space_garrison` |
| `86b_dbr_saibamen.js` | The Ragnarok original's Saibaman seeds: plant them on Rocky Dirt, charge ki beside the plant while it grows (faster growth, a better tier, 3 % ki a second), right-click it grown for a tamed Saibaman (six tiers, scaled from you, follows, defends, explodes at 20 %; right-click sit, sneak-right-click dismiss, 3 each); seeds in the Saibamen huts of generated planets and Vegeta; `config/dbr_saibaman_pets.json` |
| `97_dbr_look_hud.js` (+ client) | Lines for the built-in Look HUD addon: original masters, quest givers and tournament hosts say what they are; a creature's battle power shows while you wear a scouter |
| `99_dbr_item_clear.js` | The Ragnarok original's ground item clear (off by default): dropped items are deleted every 300 s with warnings at 60/30/10/5 s and a count afterwards; dragon balls (any confined item) and `excludedItems` are never cleared. Settings `/rpg config dbr_item_clear` or the Server rows of the original config menu; ops: `/rpgc clearitems now \| warn \| on \| off \| status` |
| `90_hooks.js` | Welcome, level-ups, kill streaks, regeneration, Zenkai, barrier/guard damage reduction, hurt animations, TP multipliers, overrides, and `/rpgc power`, `help`, `arena`, `setup` |

**To try it:** join, pick a race and a class, and type `/rpgc setup` (op) to place Roshi, Korin, Bulma, Mr. Popo, King Yemma and other masters around you. Talk to Roshi to start the saga. Quick tests: `/rpg learn @s kamehameha`, `/rpg learn @s super_saiyan`, `/rpg mob saibaman`, `/rpg boss frieza_first`, `/rpg event start world_boss`, `/rpgc color hair #FF0000`. After the first start, **restart once** so the three dimensions load.
