// =====================================================================================
//  60_npcs_dialogue.js - the original's masters and quest NPCs (who they are, how they look)
// =====================================================================================
//  Place an NPC where you stand:  /rpg npc master_roshi     (remove it: /kill it; masters and quest NPCs
//  ignore creative players' hits, like the original)
//  The original places the masters itself: baked into its structures (65_dmz_structures.js builds them
//  with their NPCs) and at fixed Other World spots (OW_NPCS there).
//
//  The 28 masters (the original MastersEntity) and the story NPCs (QuestNPCEntity) come from
//  shared/08_dmz_masters_data.js. Talking to one opens the original's dialogue (NpcDialogueScreen):
//  greeting, Quests, Skills (the master's TP shop), Train, and the master's own services.
//  That logic lives in 61_dmz_masters.js; the screens in client/scripts/52_masters_screen.js.
//
//  Like the original, the masters stand still, look at nearby players, cannot be hurt (only /kill and
//  the void get through, creative players included) or moved, and teach for TP, not Zeni. One that
//  falls into the void or goes missing is put back at its post at once; /kill removes it for good,
//  as in the original. No original master, quest NPC or prop shows a name tag (nametag "never").
// =====================================================================================

// ---- Looks ---------------------------------------------------------------------------
// Every original master shares one animation file (idle, walk, and a few personal idles:
// guru_idle, uranai_idle, tori_idle, roshi_idle), plus an always-on "tail" clip (AllMastersEntity).
function masterLook(name, idle) {
    return {
        model: DMZ_GEO + "master/master_" + name + ".geo.json",
        texture: DMZ_TEX + "master/master_" + name + ".png",
        animation: DMZ_ANIM + "master/masters.animation.json",
        idle: idle || "idle",
        walk: "walk",
        loops: ["tail"]
    };
}

// The saga characters share saga_base.animation.json (63 animations: idle, walk, attack1_1...).
function sagaLook(model, texture, scale) {
    return dmzSagaStates({
        model: DMZ_GEO + "sagas/" + model + ".geo.json",
        texture: DMZ_TEX + "sagas/" + (texture || model) + ".png",
        animation: DMZ_ANIM + "sagas/saga_base.animation.json",
        idle: "idle", walk: "walk", attack: "attack1_1",
        scale: scale || 1.0
    });
}

// MasterGlobalModel: a master without a model of its own (Beerus, Whis) shows robotxv.
function dmzMasterGeo(m) {
    if (!m.model) return { model: DMZ_GEO + "enemies/robotxv.geo.json", texture: DMZ_TEX + "enemies/robotxv.png",
        animation: DMZ_ANIM + "master/masters.animation.json", idle: "idle", walk: "walk", loops: ["tail"] };
    return masterLook(m.model.replace(/^master_/, ""), m.idle);
}

// The original's hitboxes (MainEntities .sized(w, h)), times the master's scale like the original's getScale(). King Yemma's
// model is ~9 blocks tall: with a player-sized hitbox he was culled as soon as his feet left the screen
// and only his feet could be clicked.
var DMZ_MASTER_HITBOX = {
    karin: [0.8, 0.8], goku: [0.8, 2.0], kingkai: [0.8, 1.5], roshi: [0.8, 1.8], baba: [0.8, 1.4], baba_earth: [0.8, 1.4],
    enma: [5.5, 7.5], dende: [0.8, 2.0], gero: [0.8, 2.0], popo: [0.8, 2.0], guru: [1.3, 3.0], toribot: [0.6, 1.4],
    piccolo: [0.8, 2.0], gohan: [0.8, 2.0], babidi: [0.6, 1.2], oldkai: [0.6, 1.6], cell: [0.8, 2.0], vegeta: [0.8, 2.0],
    frieza: [0.8, 2.0], trunks: [0.8, 2.0], yamcha: [0.8, 2.0], krillin: [0.6, 1.6], tien: [0.8, 2.0], beerus: [0.8, 2.0],
    whis: [0.8, 2.0], grandkai: [0.8, 1.8], otherworld_announcer: [0.8, 2.0], world_tournament_announcer: [0.6, 1.9]
};

// =====================================================================================
//  The masters (AllMastersEntity): 100 HP, immobile, invulnerable, LookAtPlayerGoal(8)
// =====================================================================================
Object.keys(DMZ_MASTERS_DATA.MASTERS).forEach((id) => {
    let m = DMZ_MASTERS_DATA.MASTERS[id];
    // MastersEntity: hurt only by /kill and the void (and a creative player, to remove one), never moved by anything
    // (knockback, explosions, beams, dashes, fluids, pistons), no effects, fire-proof. respawn "instant": a master
    // that dies or goes missing stands at its post again at once, never twice (the engine's posts).
    let def = { name: "&f" + m.name, nametag: "never", geo: dmzMasterGeo(m), scale: m.scale || 1, wander: false, invulnerable: true, immovable: true,
        respawn: "instant", immune: { fire: true, drowning: true, fall: true, suffocation: true, potions: true } };
    let hb = DMZ_MASTER_HITBOX[id];
    if (hb) { def.width = hb[0]; def.height = hb[1]; }
    // Yemma and Guru sit facing one way (the original freezes them at yaw 180) instead of turning to players
    if (typeof m.yaw === "number") { def.fixedYaw = m.yaw; def.lookAtPlayers = false; }
    // 61_dmz_masters.js opens the original's dialogue screen on npcInteract. Yemma and the Otherworld announcer
    // fall back to 60_otherworld.js's dialogues when that is switched off (config dbr_masters).
    if (id === "enma" || id === "otherworld_announcer") def.dialogue = id;
    RPG.npcs.define(m.npc, def);
});

// =====================================================================================
//  Story NPCs (QuestNPCEntity: npc_id + saga model). chi_chi, chiaotzu and dmz_quest_buu
//  are defined in 65_dmz_structures.js; the hell ogre in 60_otherworld.js.
// =====================================================================================
Object.keys(DMZ_MASTERS_DATA.QUEST_NPCS).forEach((id) => {
    let q = DMZ_MASTERS_DATA.QUEST_NPCS[id];
    if (q.npc === "chi_chi" || q.npc === "chiaotzu" || q.npc === "dmz_quest_buu" || q.npc === "hell_ogre") return;
    let geo = q.look ? sagaLook(q.look[0], q.look[1]) : { model: DMZ_GEO + "enemies/namekian.geo.json", texture: DMZ_TEX + "enemies/namek_trader_0.png",
        animation: DMZ_ANIM + "enemies/namekian.animation.json", idle: "idle", walk: "walk" };
    RPG.npcs.define(q.npc, { name: "&f" + q.name, nametag: "never", geo: geo, wander: false });
});

// ---- MastersEntity.hurt / QuestNPCEntity.hurt -------------------------------------------------------------------
// The original lets only FELL_OUT_OF_WORLD and GENERIC_KILL through to a master (QuestNPCEntity also GENERIC), so a
// creative player's sword, ki blast or explosion does nothing either. The engine lets creative players hurt an
// invulnerable NPC (to remove one), so those hits are voided here at their very start. /kill on a master gives its post
// up (npc.remove()) instead of standing a fresh copy there: in the original a killed master is gone.
var DMZ_SHIELDED_NPCS = {};          // npc id -> "master" | "quest"
Object.keys(DMZ_MASTERS_DATA.MASTERS).forEach((id) => { DMZ_SHIELDED_NPCS[DMZ_MASTERS_DATA.MASTERS[id].npc] = "master"; });
Object.keys(DMZ_MASTERS_DATA.QUEST_NPCS).forEach((id) => { DMZ_SHIELDED_NPCS[DMZ_MASTERS_DATA.QUEST_NPCS[id].npc] = "quest"; });
RPG.on("damageAttempt", function (e) {
    var t = e.target, kind = t && !t.isPlayer() ? DMZ_SHIELDED_NPCS[t.rpgId] : undefined;
    if (!kind) return;
    if (e.type === "minecraft:out_of_world") return;
    if (e.type === "minecraft:generic_kill") {
        if (kind === "master") { e.cancel(); t.remove(); }
        return;
    }
    if (kind === "quest" && e.type === "minecraft:generic") return;
    e.cancel();
});

// ---- NPCs from earlier versions of this addon that original doesn't have --------------------
// Kept so NPCs already standing in worlds still work (85_world.js places Kibito).
RPG.npcs.define("kibito", { name: "&dKibito", nametag: "never", geo: sagaLook("saga_kibito"), dialogue: "kibito" });
RPG.dialogues.define("kibito", { start: "start", nodes: { start: { text: "The Supreme Kai is watching. Grow strong enough to face Majin Buu.", options: [{ text: "I will." }] } } });
RPG.npcs.define("kami", { name: "&2Kami", nametag: "never", geo: sagaLook("saga_piccolo_kami"), dialogue: "kami" });
RPG.dialogues.define("kami", { start: "start", nodes: { start: { text: "The Dragon Balls are my creation. Use them wisely.", options: [{ text: "Understood." }] } } });
RPG.npcs.define("oolong", { name: "&dOolong", nametag: "never", geo: sagaLook("saga_oolong"), wander: true, dialogue: "oolong" });
RPG.dialogues.define("oolong", { start: "start", nodes: { start: { text: "If you find all seven Dragon Balls, wish for something useful. Trust me on this one.", options: [{ text: "Like what?" }] } } });
RPG.npcs.define("yajirobe", { name: "&6Yajirobe", nametag: "never", geo: sagaLook("saga_yajirobe"), shop: "yajirobe_shop" });

// Namekian villagers: a geo model with four texture variants, one NPC id per look.
// (the original's Namek traders use vanilla emerald trades; ours sell for Zeni, 65_shops.js.)
["namek_villager_0", "namek_villager_1", "namek_villager_2", "namek_villager_3"].forEach((id, i) => {
    RPG.npcs.define(id, {
        name: "&aNamekian Villager", nametag: "never",
        geo: { model: DMZ_GEO + "enemies/namekian.geo.json", texture: DMZ_TEX + "enemies/namek_trader_" + i + ".png",
               animation: DMZ_ANIM + "enemies/namekian.animation.json", idle: "idle", walk: "walk" },
        wander: true,
        shop: "namek_shop",
        onInteract(player, npc) { sfx(npc, "entity.namekian.vill.ambient", 1, 1); }
    });
});

// =====================================================================================
//  Props: the Saiyan pod (quests drop it with Raditz/Nappa/Vegeta), the punch machine
//  (Time Chamber), and older vehicle props
// =====================================================================================
// Old vehicle props: right-click packs them back into a capsule (56_vehicles.js has the real vehicles).
// look: the vehicle's original model scale / offset and hitbox ([w, h] in blocks), as in 56_vehicles.js.
function vehicleProp(id, name, model, texture, capsuleItem, sound, look) {
    let s = (look && look.scale) || 1, geo = { model: DMZ_GEO + model, texture: DMZ_TEX + texture, scale: s };
    if (look && look.offset) geo.offset = look.offset;
    RPG.npcs.define(id, {
        name: name, nametag: "never",
        geo: geo,
        // NPC hitboxes are width/height times the scale
        width: look && look.box ? look.box[0] / s : 0.6, height: look && look.box ? look.box[1] / s : 1.8,
        onInteract(player, npc) {
            sfx(npc, sound, 1, 1);
            npc.kill();
            player.giveItem(capsuleItem, 1);
            RPG.world.particle(npc.dimension, "minecraft:poof", npc.x, npc.y + 1, npc.z, 30, 1, 0.05);
            return false;
        }
    });
}
vehicleProp("capsule_car_red", "Capsule Car", "vehicles/car.geo.json", "vehicles/car_red.png", "car_red", "vehicle.car.engine", { box: [2.4, 1.3] });
vehicleProp("capsule_car_yellow", "Capsule Car", "vehicles/car.geo.json", "vehicles/car_yellow.png", "car_yellow", "vehicle.car.engine", { box: [2.4, 1.3] });
vehicleProp("capsule_plane", "Capsule Plane", "vehicles/cc576.geo.json", "vehicles/cc576.png", "cc576", "vehicle.cc576.engine", { offset: [-10, 0, -40], box: [4.5, 4.0] });
// Frieza's ship (the saga arrival prop): the original draws this model at 2.5x
vehicleProp("frieza_pod", "Hover Pod", "vehicles/frieza_capsule.geo.json", "vehicles/frieza_capsule.png", "frieza_capsule", "vehicle.frieza_capsule.engine", { scale: 2.5, box: [1.5, 1.6] });

// The Saiyan space pod opens with the original's own "open" animation and sound.
RPG.npcs.define("saiyan_pod", {
    name: "Saiyan Pod", nametag: "never",
    // The original SpacePodEntity: model scale 1.1, hitbox 2 x 2
    geo: { model: DMZ_GEO + "spacepod.geo.json", texture: DMZ_TEX + "spacepod.png", animation: DMZ_ANIM + "spacepod.animation.json", idle: "close", scale: 1.1 },
    width: 2.0 / 1.1, height: 2.0 / 1.1,
    onInteract(player, npc) {
        npc.playAnimation("open");
        sfx(npc, "ship_open", 1, 1);
        return false;
    }
});

// The punch machine (PunchMachineEntity, placed with punch_machine_item; one also stands in the Time Chamber): a training
// dummy with no AI, 1000 HP, never pushed, no name tag. A player's melee or ki hit is measured, never dealt
// (CombatEvent cancels it after processHit): the damage floats above it in bold yellow for a second (an AreaEffectCloud
// name tag), the action bar reads "DMG: x | DPS: y" in bold gold (DPS = the damage since the first of a run of hits less
// than 5 s apart, over at least 1 s), and the hit still gives the usual TP per hit. A crouching player's hit packs it
// back into its item. Anything else (explosions, mobs, /kill) hurts it like any mob.
RPG.npcs.define("punch_machine", {
    name: "&ePunch Machine", nametag: "never",
    geo: { model: DMZ_GEO + "punchstation.geo.json", texture: DMZ_TEX + "punchmachine.png",
           animation: DMZ_ANIM + "punchmachine.animation.json", idle: "idle" },
    health: 1000, invulnerable: false, immovable: true, wander: false, lookAtPlayers: false,
    retaliate: false, attackPlayers: "never", attackMobs: false, attackFactions: false
});
var DMZ_PUNCH = (function () {
    var RUNS = {};                         // machine uuid -> { last, acc, start } (the entity's own fields, not saved)
    function fmt1(v) { return (Math.round(v * 10) / 10).toFixed(1); }
    function indicator(m, dmg) {
        var name = JSON.stringify({ text: String(Math.round(dmg)), color: "yellow", bold: true }).replace(/'/g, "\\'");
        RPG.world.spawnEntity(m.dimension, "minecraft:area_effect_cloud", m.x, m.y + 0.8, m.z,
            "{Radius:0f,Duration:20,WaitTime:0,Particle:\"minecraft:block minecraft:air\",CustomNameVisible:1b,CustomName:'" + name + "'}");
    }
    function processHit(m, dmg, p) {
        var now = Date.now(), r = RUNS[m.uuid] || (RUNS[m.uuid] = { last: 0, acc: 0, start: now });
        if (now - r.last > 5000) { r.acc = 0; r.start = now; }
        if (r.acc === 0) r.start = now;
        r.last = now;
        r.acc += dmg;
        var dps = r.acc / Math.max(1, (now - r.start) / 1000);
        indicator(m, dmg);
        p.actionbar("&6&lDMG: " + fmt1(dmg) + " | DPS: " + fmt1(dps));
    }
    // a crouching player's hit, whatever it is, picks the machine up (before anything else sees the hit)
    RPG.on("damageAttempt", function (e) {
        var t = e.target, a = e.attacker;
        if (!t || t.rpgId !== "punch_machine" || !a || !a.isPlayer() || !a.isSneaking()) return;
        e.cancel();
        if (!t.isAlive()) return;
        RPG.world.dropItem(t.dimension, t.x, t.y, t.z, "punch_machine_item", 1);
        delete RUNS[t.uuid];
        t.remove();
    });
    RPG.on("attack", function (e) {
        var t = e.target;
        if (!t || t.rpgId !== "punch_machine" || !e.attacker || !e.attacker.isPlayer()) return;
        e.cancel();
        if (e.amount > 0) processHit(t, e.amount, e.attacker.asPlayer());
    });
    RPG.on("npcDeath", function (npc) { if (npc && npc.rpgId === "punch_machine") delete RUNS[npc.uuid]; });
    // PunchMachineItem.useOn: centred on the block above the one clicked, facing the player, one used up (not in creative)
    function place(p, x, y, z) {
        var m = RPG.world.spawnNpc(p.dimension, "punch_machine", x + 0.5, y + 1, z + 0.5);
        if (!m) return false;
        m.setRotation(p.yaw + 180, 0);
        if (!dmzCreative(p)) {
            var st = p.getHeldStack();
            if (st) { st.count = (st.count || 1) - 1; p.setHeldStack(st.count > 0 ? st : null); }
        }
        return true;
    }
    return { place: place, processHit: processHit };
})();

// A decorative Nimbus (the rideable one is the flying_nimbus item from Korin, 56_vehicles.js).
RPG.npcs.define("nimbus_cloud", {
    name: "&eFlying Nimbus", nametag: "never",
    geo: { model: DMZ_GEO + "kinton.geo.json", texture: DMZ_TEX + "kinton.png", animation: DMZ_ANIM + "kinton.animation.json", idle: "idle" },
    onInteract(player, npc) { sfx(npc, "nube", 1, 1); return false; }
});
