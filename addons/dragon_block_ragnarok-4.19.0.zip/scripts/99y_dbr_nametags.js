// =====================================================================================
//  99y_dbr_nametags.js - name tags only where the original shows them
// =====================================================================================
//  The original's mobs, saga villains, bosses, masters and story NPCs carry no custom name, so the
//  game never draws a tag over them, not even while you look at one. The engine names every script
//  mob after its definition (death messages, boss bars and Jade need that), and the GeckoLib
//  renderer then shows that name whenever the mob is looked at. So each player's computer turns the
//  tags of script mobs off (client 99_dbr_nametags.js), and NPC definitions say nametag "never".
//
//  The tags the original (or DMZ Ragnarok) does show stay: an entity tagged "dbr_showname" draws its
//  name the vanilla way (the Red Ribbon raid commander, named raid enemies and allies, raid hosts,
//  NPC region display names, prestige masters, named Saibaman pets). Every 2 s the server lists the
//  tagged entities within 64 blocks of each player (an engine-filtered nearby query) for that player.
// =====================================================================================
(function () {
    RPG.every(40, function () {
        RPG.server.players().forEach(function (p) {
            var list = p.nearby(64, { tag: "dbr_showname" });
            if (!list.length) return;
            var ids = [];
            for (var i = 0; i < list.length && i < 256; i++) ids.push(list[i].entityId);
            RPG.net.send(p, "dbr_nametags", { ids: ids });
        });
    });
})();
