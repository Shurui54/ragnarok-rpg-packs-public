// =====================================================================================
//  11_dmz_combat.js - original melee combo, guard, parry, poise and stun (CombatEvent, TickHandler)
// =====================================================================================
//  The client (client/scripts/42_combat.js) sends each combo step ("dmz_melee") and the
//  guard ("dmz_guard"). Here: everyone sees the attack animation, the swing sound plays,
//  the step's damage multiplier and stamina cost apply, and guarding/parrying works like the original.
// =====================================================================================
var DMZ_MELEE = {};          // uuid -> { mult, at }
/** The plain first-person arms: who uses them, a combo hit being landed, a vanilla click voided since (09_dmz_stats.js). */
var FP_ARMS = { on: {}, landing: {}, clicked: {} };

RPG.effects.define("guarding", { name: "&bGuarding", color: "#7FD3FF", hidden: true });
RPG.effects.define("stunned", { name: "&cStunned", color: "#FF5555", hidden: true, flags: ["noMove", "noJump", "noAttack", "noSkills"] });
RPG.effects.define("staggered", { name: "&6Staggered", color: "#FFAA00", hidden: true,
    attributes: { "minecraft:generic.movement_speed": { amount: -0.5, operation: "multiply_total" } } });

(function () {
    var C = DMZ_COMBAT.CFG;
    var GUARD = {};          // uuid -> { since (ms), poiseHit (tick) }

    function now() { return Date.now(); }
    function tick() { return RPG.server.getTick(); }

    // ---- melee steps from the client ----
    RPG.net.on("dmz_melee", (p, d) => {
        if (!p.getVar("dmz_created", 0) || p.hasEffect("stunned") || p.hasEffect("guarding")) return;
        if (typeof dmzKiShareLocked === "function" && dmzKiShareLocked(p)) return;              // PlayerAttackHelper.canAttack: not while sharing ki or in a god ritual
        // a ki weapon out (79_dmz_kiweapon.js) swings its own combo (sword / scythe / trident)
        let kw = typeof DMZ_KIWEAPON !== "undefined" ? DMZ_KIWEAPON.activeType(p) : null;
        let attacks = kw ? DMZ_COMBAT.KI_WEAPONS[kw].attacks : DMZ_COMBAT.FIST;
        let anim = String(d && d.a || ""), step = attacks.filter((a) => a.anim === anim)[0];
        if (!step) return;
        let infusion = p.hasEffect("ki_infusion") && p.getLevel() >= 5, count = Math.max(0, Math.floor(Number(d.c) || 0));
        let atk = kw ? attacks[count % attacks.length] : DMZ_COMBAT.attackFor(count, infusion);
        let mult = atk.anim === anim ? atk.damage : 1;
        let t = DMZ_COMBAT.timing(4 + (kw ? DMZ_COMBAT.KI_WEAPONS[kw].attackSpeed : 0));
        let windup = DMZ_COMBAT.windup(t, kw ? 0.5 : (atk.anim === anim ? atk : step).upswing);
        if (d.v >= 2 && V2(p)) {
            // MeleeWindupTracker.registerStart: the client times and aims the swing ("dmz_hit"); starts closer than
            // 100 ms apart are refused
            let ms = now();
            if (ms - (LAST_START[p.uuid] || -1e9) < 100) return;
            LAST_START[p.uuid] = ms;
            STARTS[p.uuid] = { at: ms, c: count, slot: Math.floor(Number(d.slot)), windup: windup, cd: t.cooldown, mult: mult };
            animPulse(p, "melee", { a: anim, s: Math.max(0.15, Math.min(2, Number(d.s) || 1)) });
            // the swing sound: the attacker already played it on their own computer
            if (kw) RPG.world.sound(p.dimension, DMZ + step.sound, p.x, p.y, p.z, 0.7, (step.pitch || 1) * (0.9 + Math.random() * 0.2), p);
            else RPG.world.sound(p.dimension, DMZ + "fist_punch", p.x, p.y, p.z, 0.7, 0.9 + Math.random() * 0.2, p);
            return;
        }
        DMZ_MELEE[p.uuid] = { mult: mult, at: tick() };
        animPulse(p, "melee", { a: anim, s: Math.max(0.15, Math.min(2, Number(d.s) || 1)) });
        // MeleeWindupTracker: the hit lands when the swing connects (wind-up + 1 ticks after it starts), not on the
        // click; the target can still raise a guard or parry in between (player.setMeleeWindup)
        p.setMeleeWindup(windup + 1);
        if (kw) sfx(p, step.sound, 0.7, (step.pitch || 1) * (0.9 + Math.random() * 0.2));
        else sfx(p, "fist_punch", 0.7, 0.9 + Math.random() * 0.2);
    });

    // ---- client-timed hits (MeleeWindupTracker.submitHit / CombatAttackRequestC2S.processAttackRequest) ----
    // The hit request must match the swing that started (combo step, slot), come within 2 s, and lands no sooner than
    // the start's arrival + (wind-up - 1) ticks, nor sooner than the attack cooldown - 2 ticks after the last one,
    // nor later than 1 s off (refused). Each target is checked: there, alive, not an ally, within the fist's reach
    // (2) + 4 blocks of slack from the nearest point of its box, like the original's distance check to the part you
    // hit; then it is a normal attack (player.attackEntity).
    var STARTS = {}, LAST_START = {}, LAST_HIT = {}, DEFER = {};
    function V2(p) { return typeof p.attackEntity === "function"; }
    function canStrike(p) { return p.isAlive() && !p.hasEffect("stunned") && !p.hasEffect("guarding") && !(typeof dmzKiShareLocked === "function" && dmzKiShareLocked(p)); }
    function landHit(p, req, st) {
        if (!canStrike(p) || p.getHotbarSlot() !== req.slot) return;
        DMZ_MELEE[p.uuid] = { mult: st.mult, at: tick() };
        let ids = Array.isArray(req.ids) ? req.ids.slice(0, 8) : [], done = {};
        if (!ids.length) return;
        let near = p.nearby(24);       // wide enough for a giant's centre when its edge is in reach
        ids.forEach((id) => {
            id = Math.floor(Number(id));
            if (done[id]) return;
            done[id] = 1;
            let e = near.filter((x) => x.entityId === id)[0];
            if (!e || !e.isAlive()) return;
            try { if (p.isAlly(e)) return; } catch (x) { }
            // measured to the nearest point of the target's box, not its feet: a big body (an Oozaru, a dinosaur) is hit
            // at its edge, like the original's hitbox parts
            let hw = (Number(e.width) || 0) / 2, hh = Number(e.height) || 0;
            let dx = Math.max(Math.abs(e.x - p.x) - hw, 0), dz = Math.max(Math.abs(e.z - p.z) - hw, 0);
            let dy = p.y < e.y ? e.y - p.y : p.y > e.y + hh ? p.y - (e.y + hh) : 0;
            if (dx * dx + dy * dy + dz * dz > 2 * 2 + 16) return;
            FP_ARMS.landing[p.uuid] = true;
            try { p.attackEntity(e); } finally { delete FP_ARMS.landing[p.uuid]; }
        });
    }
    // The plain first-person arms (client option firstPersonAnimated off): the client lets the vanilla click through so
    // the arm swings, and its hit is voided here before it lands (damageAttempt), since the combo's own hit lands when
    // the swing connects (landHit). The animated mode cancels that click on the client, so nothing changes there.
    RPG.net.on("dmz_fp_arms", (p, d) => {
        let on = !!(d && d.on);
        if (on) FP_ARMS.on[p.uuid] = true; else delete FP_ARMS.on[p.uuid];
        p.setShared("dbr_fp_arms", on ? 1 : null);                    // other computers mute the voided click's thud
    });
    RPG.on("playerLeave", (p) => { delete FP_ARMS.on[p.uuid]; delete FP_ARMS.clicked[p.uuid]; });
    RPG.on("damageAttempt", (e) => {
        let a = e.attacker;
        if (!a || !a.isPlayer() || e.isCancelled() || e.kind !== "melee" || e.isProjectile()) return;
        if (!FP_ARMS.on[a.uuid] || FP_ARMS.landing[a.uuid]) return;
        let p = a.asPlayer(), h = p.getHeldStack();
        if (!V2(p) || !p.getVar("dmz_created", 0) || (h && h.id !== "minecraft:air")) return;   // only the clicks DBR's combo answers
        e.cancel();
        FP_ARMS.clicked[a.uuid] = true;
    });
    function flushDefer(p) { let df = DEFER[p.uuid]; if (df) { delete DEFER[p.uuid]; landHit(p, df.req, df.st); } }
    RPG.net.on("dmz_hit", (p, d) => {
        if (!d || !V2(p) || !p.getVar("dmz_created", 0) || !canStrike(p)) return;
        flushDefer(p);
        let st = STARTS[p.uuid], ms = now();
        delete STARTS[p.uuid];
        let req = { c: Math.floor(Number(d.c)), slot: Math.floor(Number(d.slot)), ids: d.ids };
        if (!st || st.c !== req.c || st.slot !== req.slot || ms - st.at > 2000) return;
        let due = st.at + Math.max(0, st.windup - 1) * 50;
        let last = LAST_HIT[p.uuid];
        if (last !== undefined) due = Math.max(due, last + Math.max(0, Math.floor(st.cd) - 2) * 50);
        if (due - ms > 1000) return;
        LAST_HIT[p.uuid] = due;
        if (ms >= due) landHit(p, req, st);
        else DEFER[p.uuid] = { req: req, st: st, due: due };
    });
    RPG.every(1, () => {
        for (let u in DEFER) {
            let df = DEFER[u];
            if (now() < df.due) continue;
            delete DEFER[u];
            let p = RPG.server.playerByUuid ? RPG.server.playerByUuid(u) : RPG.server.players().filter((x) => x.uuid === u)[0];
            if (p) landHit(p, df.req, df.st);
        }
    });
    function announce(p) { if (V2(p)) RPG.net.send(p, "dmz_melee_v", { v: 2 }); }
    RPG.on("playerJoin", (p) => RPG.schedule(20, () => { try { announce(p); } catch (e) { } }));
    RPG.schedule(40, () => RPG.server.players().forEach(announce));   // a script reload: tell everyone already here
    RPG.net.on("dmz_melee_hello", (p) => announce(p));          // and whoever's client scripts (re)load asks
    RPG.on("playerLeave", (p) => { delete STARTS[p.uuid]; delete LAST_START[p.uuid]; delete LAST_HIT[p.uuid]; delete DEFER[p.uuid]; });

    // ---- guard ----
    // The client repeats {on: true} every 10 ticks while the button is held (client/scripts/42_combat.js); a guard
    // that stops hearing it for 30 ticks (a lost release, a disconnect, a dimension change) ends here.
    RPG.net.on("dmz_guard", (p, d) => {
        if (!p.getVar("dmz_created", 0)) return;
        let g = GUARD[p.uuid] || (GUARD[p.uuid] = { since: 0, released: 0, poiseHit: -1000, beat: 0 });
        if (d && d.on) {
            if (p.hasEffect("guarding")) { g.beat = tick(); return; }      // heartbeat
            p.cancelMeleeWindup();   // raising a guard drops your own swing (MeleeWindupTracker.cancel)
            delete STARTS[p.uuid]; delete DEFER[p.uuid];
            if (d.beat) return;                                            // a heartbeat for a guard already ended: no re-raise
            if (p.hasEffect("stunned") || p.hasEffect("ki_charge")) return;
            if (typeof dmzKiShareLocked === "function" && dmzKiShareLocked(p)) return;          // UpdateStatC2S: no guard while ki share locked
            if (now() - g.released < C.reblockMs) return;                  // server re-block delay
            g.since = now();
            g.beat = tick();
            p.addEffect("guarding", -1);
        } else endGuard(p);
    });
    function endGuard(p) {
        if (!p.hasEffect("guarding")) return;
        p.removeEffect("guarding");
        (GUARD[p.uuid] || (GUARD[p.uuid] = { since: 0, poiseHit: -1000, beat: 0 })).released = now();
    }
    RPG.every(5, () => {
        RPG.server.players().forEach((p) => {
            if (!p.hasEffect("guarding")) return;
            let g = GUARD[p.uuid];
            // stunned (a guard break, a boss grab) or silent: the guard is down
            if (p.hasEffect("stunned") || !g || tick() - g.beat > 30) endGuard(p);
        });
    });
    // a guard never survives a relog (effects are saved with the player)
    RPG.on("playerJoin", (p) => { if (p.hasEffect("guarding")) p.removeEffect("guarding"); });
    RPG.on("playerLeave", (p) => { delete GUARD[p.uuid]; });

    function poise(p) {
        let max = DMZ_F.maxPoise(dmzView(p)), v = p.getVar("dmz_poise", null);
        return { max: max, value: v === null ? max : Math.min(max, Number(v)) };
    }

    // ---- the original's hit particles (PUNCH_PARTICLE, BLOCK_PARTICLE, GUARD_BLOCK, SPARKS, KI_TRAIL), drawn by each
    // client nearby (client/scripts/42_combat.js "dmz_hitfx"): k = punch | block | parry | break, c = tint
    function hitFx(at, k, x, y, z, c) {
        let msg = { k: k, x: Math.round(x * 100) / 100, y: Math.round(y * 100) / 100, z: Math.round(z * 100) / 100 };
        if (c) msg.c = c;
        RPG.server.players().forEach((pl) => {
            if (pl.dimension !== at.dimension) return;
            let dx = pl.x - x, dy = pl.y - y, dz = pl.z - z;
            if (dx * dx + dy * dy + dz * dz <= 48 * 48) RPG.net.send(pl, "dmz_hitfx", msg);
        });
    }
    // CombatEvent: in front of the defender's eyes (eye + look x 0.6, 0.3 lower)
    function guardFx(p, k, c) {
        let yaw = p.yaw * Math.PI / 180, pitch = (p.pitch || 0) * Math.PI / 180;
        let lx = -Math.sin(yaw) * Math.cos(pitch), ly = -Math.sin(pitch), lz = Math.cos(yaw) * Math.cos(pitch);
        hitFx(p, k, p.x + lx * 0.6, p.eyeY + ly * 0.6 - 0.3, p.z + lz * 0.6, c);
    }

    function guardBreak(p) {
        p.setVar("dmz_poise", 0);
        p.addResource("stamina", -p.resource("stamina"));
        p.removeEffect("guarding");
        p.setVar("dmz_surge", 0);
        p.addEffect("stunned", C.guardBreakStun);
        act(p, "base.parried_stun", C.guardBreakStun);
        let g = GUARD[p.uuid]; if (g) g.poiseHit = tick();
        sfx(p, "unblock", 1, 1);
        guardFx(p, "break");
    }

    function inFront(target, src) {
        let yaw = target.yaw * Math.PI / 180, lx = -Math.sin(yaw), lz = Math.cos(yaw);
        let dx = src.x - target.x, dz = src.z - target.z;
        return lx * dx + lz * dz > 0;
    }

    // ---- damage: guard, parry, stun (after original mitigation in 09_dmz_stats.js) ----
    RPG.on("damageFinal", (e) => {
        let a = e.attacker, t = e.target;
        // a stunned or guarding player can't hit
        if (a && a.isPlayer() && (a.asPlayer().hasEffect("stunned") || a.asPlayer().hasEffect("guarding")) && e.kind === "melee") { e.cancel(); return; }
        if (!t || e.amount <= 0) return;
        if (!t.isPlayer() || !t.asPlayer().hasEffect("guarding") || t.asPlayer().hasEffect("stunned") || !a || !inFront(t.asPlayer(), a)) {
            punchFx(e, a, t);
            return;
        }
        let p = t.asPlayer();
        let g = GUARD[p.uuid] || { since: 0 }, est = e.amount, nonPlayer = !a.isPlayer();
        let parry = now() - g.since <= C.parryWindowMs;
        let ps = poise(p);
        let poiseDmg = est * C.poiseDamageMult * (nonPlayer ? 1.5 : 1) * (parry ? 0.66 : 1);
        let staminaCost = est * C.blockStaminaCost;
        if (ps.value - poiseDmg <= 0 || p.resource("stamina") - staminaCost <= 0) {
            guardBreak(p);
            return;
        }
        p.setVar("dmz_poise", ps.value - poiseDmg);
        p.addResource("stamina", -staminaCost);
        if (GUARD[p.uuid]) GUARD[p.uuid].poiseHit = tick();
        let mit = typeof DMZ_MITIGATION !== "undefined" ? DMZ_MITIGATION[p.uuid] : null;
        if (mit && mit.tick === tick()) mit.block = parry ? est : 0;
        if (parry) {
            e.amount = 0;
            let dx = a.x - p.x, dz = a.z - p.z, len = Math.max(0.001, Math.sqrt(dx * dx + dz * dz));
            a.push(dx / len * 1.5, 0.25, dz / len * 1.5);
            if (a.isPlayer()) {
                let ap = a.asPlayer();
                ap.addEffect("staggered", 60);
                ap.setVar("dmz_parried_until", now() + C.parryPenaltyMs);   // stamina costs x2 for 4 s
                act(ap, "base.parried", 29);
            } else {
                a.addPotion("minecraft:slowness", 20, 9);               // mobs: stunned 1 s
            }
            sfx(p, "parry", 1, 0.9 + Math.random() * 0.1);
            guardFx(p, "parry");
        } else {
            let def = DMZ_F.defense(dmzView(p)) / 0.12;
            let mitig = Math.max(C.blockMin, Math.min(C.blockCap, def * 3 / (est + def * 3)));
            e.amount = est * (1 - mitig);
            if (mit && mit.tick === tick()) mit.block = est - e.amount;
            sfx(p, "block" + RPG.randomInt(1, 3), 1, 0.9 + Math.random() * 0.1);
            // the block flash shows how much poise is left: cyan, orange, red
            let pct = ps.max > 0 ? (ps.value - poiseDmg) / ps.max * 100 : 0;
            guardFx(p, "block", pct > 66 ? [0.2, 0.9, 1.0] : pct > 33 ? [1.0, 0.5, 0.0] : [1.0, 0.1, 0.1]);
        }
    });

    // ForgeCommonEvents.onLivingAttack: a bare-handed hit that lands shows the white punch flash on the target (chest
    // height) for everyone and plays one of the six punch sounds to the attacker alone
    function punchFx(e, a, t) {
        if (e.kind !== "melee" || !a || !a.isPlayer()) return;
        let ap = a.asPlayer();
        if (!ap.getVar("dmz_created", 0)) return;
        if (t.isPlayer()) { try { if (t.asPlayer().getGameMode() === "creative") return; } catch (x) { } }
        let held = ap.getHeldStack();
        hitFx(t, "punch", t.x, t.y + (Number(t.height) || 1.8) * 0.65, t.z);
        if (!held || held.id === "minecraft:air") ap.playSound(DMZ + "punch" + RPG.randomInt(1, 6), 1, 1);
    }

    // ---- poise regen every second: not guarding, not stunned, 100 ticks after a poise hit ----
    RPG.every(20, () => {
        RPG.server.players().forEach((p) => {
            if (!p.getVar("dmz_created", 0) || p.hasEffect("guarding") || p.hasEffect("stunned")) return;
            let g = GUARD[p.uuid];
            if (g && tick() - g.poiseHit < C.poiseRegenCooldown) return;
            let ps = poise(p);
            if (ps.value < ps.max) p.setVar("dmz_poise", Math.min(ps.max, ps.value + Math.max(1, ps.max * 0.1)));
        });
    });
})();
