// =====================================================================================
//  94c_dbr_roles.js - the Ragnarok original's god roles (server)
// =====================================================================================
//  Port of the Ragnarok original (GPL-3.0, see NOTICE.md, by Shurui):
//    ragnarok_key roles/: RoleFeature (what is installed), RoleAbilities (the one key: the server decides),
//      RoleMoveHandler (the cast seam and its costs), DestructionAura, AngelState, AngelParryGuard,
//      DestructionReflectGuard, GodKiPrison (the Sphere of Destruction), GodHakai, ClashBypass, AngelStaffSummon,
//      KiWeaponCombat (the staff hits as the claw lance), RoleStateGuard, RoleTechniqueSync, GlowOutline
//    shuruisutilities: energy/EnergyManager + EnergyData + EnergySync + RoleTitles, god/GodHakaiCooldowns +
//      GodHakaiStorage + AngelStaffGuard + RagnarokKiWeapon, compat/dmz/RoleTechniqueGrant + HakaiPresentation +
//      TrapOrb + DragonDamage + DragonHurt + DmzResourceDrain, dragons/MoveChargeTracker (role costs, the sphere's
//      gathering), core/mixin/dmz/MixinDmzTechniqueDispatcher (refuse below a full charge), MixinDmzGiantBallClash.
//
//  Roles are TITLES (94_dbr_tournaments.js): god_of_destruction, angel, grand_zeno, one holder each, handed out by
//  tournaments ("title:<id>" rewards) or staff (/tourney title set <id> <player>, /rpgc role grant <role> <player>).
//
//  ROLE ENERGY: one flat 0..100 pool (absent = full), refilling 0.5 a second for every online player; kept per
//  character (player var dbr_role_e). The bar shown (the Ragnarok HUD's fourth bar) is destruction purple for a God
//  of Destruction or a Grand Zeno, angelic for an Angel.
//    Sphere of Destruction  25 (refused at charge start below that; refunded when nothing is aimed at)
//    Hakai                  the whole bar (needs it full), then 8 REAL hours (world data dbr_god_hakai, per person)
//    destruction aura / angelic state   5 a second while held (Role Ability key)
//    clash bypass           the whole bar (a full one), once per shot
//
//  Damage: the original deals its role hits as PLAYER hits (DragonHurt: playerAttack), which DragonMineZ's combat
//  replaces with the caster's own melee hit (CombatEvent: getMeleeDamage, the combo step, stamina); DBR's melee
//  formula (09_dmz_stats.js dmzMeleeDamage) does the same for kind "melee" hits, so every sphere tick, charge burn and
//  angel counter here lands as one of the caster's melee hits. The destroyer's reflect is magic (indirectMagic) and
//  arrives whole.
//
//  Net: server -> own client "dbr_role" {k: kind | "", v: 0..100, a: 1 destruction | 2 angelic access};
//       client -> server "dbr_role" {a: "ability" | "sync"}; shared "dbr_role_mode" ("destruction" | "angelic") on
//       every role holder whose aura or state is up (the God Ki outline, client/scripts/94_dbr_roles.js).
// =====================================================================================
var DBR_ROLES = (function () {
    var D = DBR_ROLE_DATA, T = D.TITLES, MAX = D.MAX;
    var A = D.AURA, AN = D.ANGEL, PR = D.PRISON, HK = D.HAKAI, RF = D.REFLECT;
    var SESSION = String(Date.now()) + "_" + Math.floor(Math.random() * 1e6);
    var E_VAR = "dbr_role_e", HK_KEY = "dbr_god_hakai", MODE_KEY = "dbr_role_mode";

    function uid(p) { return String(p.uuid); }
    function created(p) { return !!p.getVar("dmz_created", 0); }
    function tick() { return RPG.server.getTick(); }
    function bar(p, s) { try { p.actionbar(s); } catch (e) { } }
    function dist2(a, b) { var dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z; return dx * dx + dy * dy + dz * dz; }
    function hgt(e) { return Number(e.height) || 1.8; }
    function wid(e) { return Number(e.width) || 0.6; }
    function rgbStr(n) { return (((n >> 16) & 255) / 255).toFixed(3) + " " + (((n >> 8) & 255) / 255).toFixed(3) + " " + ((n & 255) / 255).toFixed(3); }
    /** level.sendParticles(new DustParticleOptions(rgb, size), x, y, z, count, dx, dy, dz, speed) */
    function dust(at, rgb, size, x, y, z, count, dx, dy, dz, speed) {
        try { RPG.world.particleEx(at.dimension, { type: "minecraft:dust " + rgbStr(rgb) + " " + size, x: x, y: y, z: z, dx: dx, dy: dy, dz: dz, count: count, speed: speed || 0 }); } catch (e) { }
    }
    function snd(at, id, x, y, z, vol, pitch) { try { RPG.world.sound(at.dimension, id, x, y, z, vol, pitch); } catch (e) { } }
    function potion(e, id, ticks, amp) { try { e.addPotion(id, ticks, amp, { particles: false, icon: false }); } catch (x) { try { e.addPotion(id, ticks, amp); } catch (y) { } } }
    function zeroXZ(e) { try { e.setVelocity(0, (Number(e.vy) || 0) * 0.2, 0); } catch (x) { } }

    // ---- titles (TitleManager.heldTitle: ONE id; RoleTitles) ----------------------------------------------------
    function title(p) {
        try { var h = typeof DBR_TOURNEY !== "undefined" ? DBR_TOURNEY.heldTitles(p) : []; return h && h.length ? String(h[0]) : ""; } catch (e) { return ""; }
    }
    /** EnergyManager.hasAccess: the title is the gate; Grand Zeno answers for both kinds. */
    function hasAccess(p, kind, t) {
        if (!p) return false;
        t = t === undefined ? title(p) : t;
        return kind === "destruction" ? D.grantsDestruction(t) : kind === "angelic" ? D.grantsAngelic(t) : false;
    }
    /** EnergyManager.activeKind (display only): Zeno and the God of Destruction purple, the Angel angelic, else none. */
    function activeKind(p, t) {
        t = t === undefined ? title(p) : t;
        return t === T.ZENO || t === T.GOD ? "destruction" : t === T.ANGEL ? "angelic" : "";
    }

    // ---- the pool (EnergyData: absent = full) -------------------------------------------------------------------
    function get(p) { var v = p.getVar(E_VAR, null); return v === null || v === undefined || isNaN(Number(v)) ? MAX : Math.max(0, Math.min(MAX, Number(v))); }
    function store(p, v) {
        var c = Math.max(0, Math.min(MAX, v));
        if (c >= MAX) { if (p.getVar(E_VAR, null) !== null) p.setVar(E_VAR, null); return; }
        p.setVar(E_VAR, Math.round(c * 1000) / 1000);
    }
    /** EnergyManager.set (admin, refund): clamped, pushed. */
    function set(p, v) { store(p, v); push(p); }
    /** EnergyManager.getActive: the active bar's value, 0 with no role. */
    function getActive(p) { return activeKind(p) ? get(p) : 0; }
    /** EnergyManager.spend: all or nothing, only with access. */
    function spend(p, kind, amount) {
        if (!hasAccess(p, kind) || amount < 0) return false;
        var cur = get(p);
        if (cur + 1e-4 < amount) return false;
        set(p, cur - amount);
        return true;
    }
    /** EnergyManager.spendAll: a genuinely full bar, all of it. */
    function spendAll(p, kind) { return spend(p, kind, MAX); }
    /** EnergyManager.drain: partial, returns what was taken. */
    function drain(p, kind, amount) {
        if (!hasAccess(p, kind) || amount <= 0) return 0;
        var cur = get(p), taken = Math.min(cur, amount);
        if (taken <= 0) return 0;
        set(p, cur - taken);
        return taken;
    }
    function refund(p, amount) { if (amount > 0) set(p, get(p) + amount); }

    // ---- EnergySync.push: own bar, when the kind changes or the value moves 0.5 -----------------------------------
    var SENT = {};
    function push(p, force) {
        if (!p) return;
        var t = title(p), k = activeKind(p, t), v = k ? get(p) : 0, prev = SENT[uid(p)];
        var a = (hasAccess(p, "destruction", t) ? 1 : 0) | (hasAccess(p, "angelic", t) ? 2 : 0);
        if (!force && prev && prev.k === k && prev.a === a && Math.abs(prev.v - v) < D.PUSH_EPSILON) return;
        SENT[uid(p)] = { k: k, v: v, a: a };
        RPG.net.send(p, "dbr_role", { k: k, v: Math.round(v * 10) / 10, a: a });
    }

    // ---- DragonEffectTicker: running effects, ticked every tick until they report done --------------------------
    var EFFECTS = [];
    function addEffect(fx) { EFFECTS.push(fx); }
    RPG.every(1, function () {
        if (!EFFECTS.length) return;
        var keep = [];
        for (var i = 0; i < EFFECTS.length; i++) {
            var fx = EFFECTS[i], more = false;
            try { more = fx.tick(); } catch (e) { RPG.log("[DBR roles] effect failed: " + e); try { fx.cancel(); } catch (e2) { } }
            if (more) keep.push(fx);
        }
        // anything added while ticking was pushed onto EFFECTS after the loop's snapshot length; keep it too
        for (var j = i; j < EFFECTS.length; j++) keep.push(EFFECTS[j]);
        EFFECTS = keep;
    });

    // ---- the outline (GlowOutline, drawn as the God Ki outline by every client) ---------------------------------
    var AURA_ON = {}, ANGEL_ON = {};
    function refreshOutline(p) {
        var m = AURA_ON[uid(p)] ? "destruction" : ANGEL_ON[uid(p)] ? "angelic" : null;
        try { if ((p.getShared(MODE_KEY, null) || null) !== m) p.setShared(MODE_KEY, m); } catch (e) { }
    }

    // =========================================================================================================
    //  DestructionAura: incoming projectiles are erased within 4 blocks; drains 5 a second; a 60 s backstop
    // =========================================================================================================
    function auraActive(p) { return !!p && !!AURA_ON[uid(p)]; }
    function auraActivate(p) {
        if (auraActive(p)) { delete AURA_ON[uid(p)]; refreshOutline(p); bar(p, "Destruction aura lowered."); return; }
        if (getActive(p) <= 0) { bar(p, "No destruction energy."); return; }
        AURA_ON[uid(p)] = 1;
        refreshOutline(p);
        addEffect(new Aura(p));
        bar(p, "Destruction aura raised.");
    }
    function auraClear(p) { if (p && AURA_ON[uid(p)]) { delete AURA_ON[uid(p)]; refreshOutline(p); } }
    function Aura(god) { this.god = god; this.ticksLeft = A.MAX_TICKS; }
    Aura.prototype.tick = function () {
        var god = this.god;
        if (!god.isAlive() || !auraActive(god) || this.ticksLeft <= 0) { this.end(); return false; }
        this.ticksLeft--;
        if (this.ticksLeft % 20 === 0 && drain(god, "destruction", A.DRAIN_PER_SECOND) <= 0) {
            bar(god, "Destruction energy spent.");
            this.end();
            return false;
        }
        destroyIncoming(god);
        return true;
    };
    Aura.prototype.cancel = function () { this.end(); };
    Aura.prototype.end = function () { auraClear(this.god); };
    /** god.getBoundingBox().inflate(4): every projectile in it the god does not own is dissipated and discarded. */
    function inBox(god, x, y, z) {
        var hw = wid(god) / 2 + A.INTERCEPT_RADIUS;
        return Math.abs(x - god.x) <= hw && Math.abs(z - god.z) <= hw && y >= god.y - A.INTERCEPT_RADIUS && y <= god.y + hgt(god) + A.INTERCEPT_RADIUS;
    }
    function dissipate(god, x, y, z) {
        dust(god, A.RGB, 2.0, x, y, z, 24, 0.35, 0.35, 0.35, 0);
        snd(god, "minecraft:block.amethyst_block.break", x, y, z, 0.8, 0.6);
    }
    // vanilla projectiles have no script-visible shooter on this engine (scripts only, no engine change): the aura takes
    // the ones flying AT the god, which spares the god's own shots (those leave it)
    var VANILLA_PROJECTILES = ["minecraft:arrow", "minecraft:spectral_arrow", "minecraft:trident", "minecraft:snowball", "minecraft:egg",
        "minecraft:fireball", "minecraft:small_fireball", "minecraft:dragon_fireball", "minecraft:wither_skull", "minecraft:shulker_bullet",
        "minecraft:llama_spit", "minecraft:potion", "minecraft:experience_bottle", "minecraft:ender_pearl"];
    function destroyIncoming(god) {
        var r = A.INTERCEPT_RADIUS + Math.max(wid(god), hgt(god)) + 1, cy = god.y + hgt(god) / 2;
        // the script projectiles (every ki attack): their owner is known
        var list = [];
        try { list = RPG.world.projectilesNear(god.dimension, god.x, cy, god.z, r); } catch (e) { list = []; }
        for (var i = 0; i < list.length; i++) {
            var pr = list[i];
            if (!pr || !pr.alive) continue;
            var o = pr.owner;
            if (o && o.uuid === god.uuid) continue;
            if (!inBox(god, pr.x, pr.y, pr.z)) continue;
            dissipate(god, pr.x, pr.y, pr.z);
            pr.discard();
        }
        var near = [];
        try { near = god.nearby(r, { any: true }); } catch (e2) { near = []; }
        for (var j = 0; j < near.length; j++) {
            var e = near[j];
            if (!e || e.living || VANILLA_PROJECTILES.indexOf(String(e.type)) < 0) continue;
            if (!inBox(god, e.x, e.y, e.z)) continue;
            var vx = Number(e.vx) || 0, vy = Number(e.vy) || 0, vz = Number(e.vz) || 0;
            if (vx * (god.x - e.x) + vy * (cy - e.y) + vz * (god.z - e.z) <= 0) continue;     // not flying at the god
            dissipate(god, e.x, e.y, e.z);
            try { e.remove(); } catch (e3) { }
        }
    }

    // =========================================================================================================
    //  AngelState: 15 s at most, drains 5 a second; every attack turned aside and answered (AngelParryGuard)
    // =========================================================================================================
    function angelActive(p) { return !!p && !!ANGEL_ON[uid(p)]; }
    function angelActivate(p) {
        if (angelActive(p)) { delete ANGEL_ON[uid(p)]; refreshOutline(p); bar(p, "Angelic state lowered."); return; }
        if (getActive(p) <= 0) { bar(p, "No angelic energy."); return; }
        ANGEL_ON[uid(p)] = 1;
        refreshOutline(p);
        addEffect(new Halo(p));
        snd(p, "minecraft:block.beacon.activate", p.x, p.y, p.z, 1.0, 1.6);
        bar(p, "Angelic state active.");
    }
    function angelClear(p) { if (p && ANGEL_ON[uid(p)]) { delete ANGEL_ON[uid(p)]; refreshOutline(p); } }
    function Halo(angel) { this.angel = angel; this.ticksLeft = AN.DURATION_TICKS; }
    Halo.prototype.tick = function () {
        var a = this.angel;
        if (!a.isAlive() || this.ticksLeft <= 0 || !angelActive(a)) { this.end(); return false; }
        this.ticksLeft--;
        if (this.ticksLeft % 20 === 0 && drain(a, "angelic", AN.DRAIN_PER_SECOND) <= 0) {
            bar(a, "Angelic energy spent.");
            this.end();
            return false;
        }
        if (this.ticksLeft <= 0) { this.end(); return false; }
        return true;
    };
    Halo.prototype.cancel = function () { this.end(); };
    Halo.prototype.end = function () {
        var a = this.angel;
        if (ANGEL_ON[uid(a)]) { angelClear(a); bar(a, "Angelic state faded."); }
    };

    // AngelParryGuard: LivingAttackEvent, every source (falls, fire, drowning too), cancelled before any damage,
    // knockback or hurt flash; the attacker (the projectile's owner, not the projectile) is answered
    var countering = false, dodgeN = 0;
    RPG.on("damageAttempt", function (e) {
        var t = e.target;
        if (!t || !t.isPlayer() || e.isCancelled()) return;
        var angel = t.asPlayer();
        if (!angelActive(angel)) return;
        e.cancel();
        onParried(angel, e.attacker);
    });
    function onParried(angel, attacker) {
        // the form dodge's twist to a random side (rolled here so every viewer twists the same way) and its whoosh
        try { angel.setShared("dbr_dodge", { n: ++dodgeN + 100000, l: Math.random() < 0.5 ? 1 : 0 }); } catch (e) { }
        snd(angel, "minecraft:entity.player.attack.sweep", angel.x, angel.y, angel.z, 0.9, 1.3 + Math.random() * 0.2);
        dust(angel, AN.RGB, 1.2, angel.x, angel.y + 1.0, angel.z, 8, 0.4, 0.5, 0.4, 0);
        counter(angel, attacker);
    }
    function counter(angel, victim) {
        if (countering) return;
        if (!victim || !victim.isLiving() || victim.uuid === angel.uuid || !victim.isAlive()) return;
        if (dist2(angel, victim) > AN.COUNTER_RANGE * AN.COUNTER_RANGE) return;
        countering = true;
        try {
            dragonHurt(angel, victim, "dbr_role:angel_counter");
            snd(victim, "minecraft:entity.player.attack.strong", victim.x, victim.y, victim.z, 1.0, 1.1);
            dust(victim, AN.RGB, 1.0, victim.x, victim.y + hgt(victim) * 0.5, victim.z, 6, 0.3, 0.3, 0.3, 0);
        } finally { countering = false; }
    }

    // DragonHurt.hurt: a player hit from the caster (DMZ, and 09_dmz_stats.js, turn it into the caster's melee hit)
    function dragonHurt(caster, victim, tag) {
        if (!caster || !victim || !victim.isAlive()) return false;
        var amount = 1;
        try { amount = Math.max(1, Number(caster.attribute("generic.attack_damage")) || 1); } catch (e) { }
        try { return victim.damageFrom(amount, caster, { kind: "melee", tag: tag }); } catch (e2) { return false; }
    }

    // =========================================================================================================
    //  DestructionReflectGuard: a melee hit on a god in the aura lands in full; a tenth of the health it really took
    //  goes back to the attacker as magic (indirectMagic: DMZ leaves it alone, armour does not cut it)
    // =========================================================================================================
    var reflecting = false;
    RPG.on("damageFinal", function (e) {
        if (reflecting || e.isCancelled()) return;
        var t = e.target, a = e.attacker;
        if (!t || !t.isPlayer() || !a) return;
        var god = t.asPlayer();
        if (!auraActive(god)) return;
        if (e.kind !== "melee" || e.isProjectile()) return;                       // a direct melee hit only
        if (!a.isLiving() || a.uuid === god.uuid || !a.isAlive()) return;
        if (dist2(god, a) > RF.RANGE * RF.RANGE) return;
        if (a.isPlayer() && god.isAlly(a)) return;                                 // PvP is PvP for a god too
        var before = god.health;
        RPG.schedule(1, function () { reflect(god, a, before); });
    });
    function reflect(god, attacker, before) {
        if (!attacker.isAlive() || !god.isAlive()) return;
        var taken = before - god.health;
        if (!(taken > 0)) return;
        var amount = taken * RF.SHARE;
        if (!(amount > 0)) return;
        reflecting = true;
        try {
            attacker.damageFrom(amount, god, { kind: "indirect_magic", tag: "dbr_role:reflect", knockback: 0 });
            snd(attacker, "minecraft:block.amethyst_block.hit", attacker.x, attacker.y, attacker.z, 0.9, 0.6);
            dust(attacker, A.RGB, 1.4, attacker.x, attacker.y + hgt(attacker) * 0.5, attacker.z, 12, 0.3, 0.4, 0.3, 0);
        } finally { reflecting = false; }
    }

    // =========================================================================================================
    //  RoleAbilities: one key, decided here from what the player holds
    // =========================================================================================================
    function activateAbility(p) {
        if (!p || !p.isAlive()) return;
        var t = title(p), d = hasAccess(p, "destruction", t), an = hasAccess(p, "angelic", t);
        if (d && an) { both(p); return; }
        if (d) { auraActivate(p); return; }
        if (an) { angelActivate(p); return; }
        // anyone else: the key does nothing, and says nothing
    }
    /** The Grand Zeno press: if either is up both go down; only from fully down do both rise. */
    function both(p) {
        if (auraActive(p) || angelActive(p)) {
            auraClear(p); angelClear(p);
            bar(p, "Destruction aura and angelic state lowered.");
            return;
        }
        if (getActive(p) <= 0) { bar(p, "No energy."); return; }
        auraActivate(p);
        angelActivate(p);
        bar(p, "Destruction aura and angelic state raised.");
    }

    // =========================================================================================================
    //  The role techniques (41_dmz_techniques.js calls these)
    // =========================================================================================================
    var GATHER = {};          // god uuid -> {orbs, angle, ticks}

    /** MoveChargeTracker: a role move costs 25 (hakai the whole bar), refused the tick its charge would start. */
    function canCharge(p, id) {
        var m = D.MOVES[id];
        if (!m) return true;
        if (!hasAccess(p, m.kind)) return false;                  // RoleTechniqueSync takes the move from non-holders
        if (get(p) < m.cost) { bar(p, "Not enough " + m.kind + " energy."); return false; }
        return true;
    }

    // TrapOrb: DMZ's ki blast as a held, harmless ball, moved by hand (dmz look: a Big Bang ball, render type 1)
    RPG.projectiles.define("dbr_role_orb", {
        shape: "ball", kind: "ki", hitboxScale: 0.8, size: 1, speed: 0, gravity: 0, lifetime: 72000, knockback: 0, throughBlocks: true,
        damage: function () { return -1; }, tickEvery: 20,
        onTick: function (o, age, proj) { if (proj && proj.getVar("sess", "") !== SESSION) proj.discard(); }
    });
    function orbSpawn(owner, x, y, z, diameter) {
        var pr = null;
        try { pr = RPG.world.shootFrom(owner.dimension, x, y - diameter * 0.4, z, 0, 0, 1, "dbr_role_orb",
            { size: diameter, speed: 0, colors: PR.COLORS, damage: 0 }, owner); } catch (e) { pr = null; }
        if (!pr) return null;
        pr.setVar("sess", SESSION);
        pr.setVelocity(0, 0, 0);
        orbLook(pr, diameter);
        return pr;
    }
    function orbLook(pr, diameter) {
        pr.setVar("sz", diameter);
        if (typeof DMZ_TECH_PROJ !== "undefined") DMZ_TECH_PROJ.look(pr, { k: "ball", rt: 1, ct: 0, sz: diameter, f: 1, tech: "god_ki_prison" });
    }
    function orbSize(pr) { return Number(pr.getVar("sz", 1)) || 1; }
    function orbResize(pr, diameter) { if (pr && pr.alive && orbSize(pr) !== diameter) { pr.size = diameter; orbLook(pr, diameter); } }
    /** The ball is drawn 0.4 x its size above the entity: placed so the BALL's centre is the point given. */
    function orbMove(pr, x, y, z) { if (pr && pr.alive) { pr.moveTo(x, y - orbSize(pr) * 0.4, z); pr.setVelocity(0, 0, 0); } }
    function orbCentre(pr) { return { x: pr.x, y: pr.y + orbSize(pr) * 0.4, z: pr.z }; }
    function orbFollow(pr, v) { orbMove(pr, v.x, v.y + hgt(v) * 0.5, v.z); }

    /** GodKiPrison.tickCharge: four orbs ring the god (radius 1.7, turning 0.16 rad a tick), 0.7 -> 1.3 with the charge. */
    function tickCharge(p, id, pct) {
        if (id !== "god_ki_prison") return;
        var st = GATHER[uid(p)] || (GATHER[uid(p)] = { orbs: [], angle: 0, ticks: 0 });
        st.orbs = st.orbs.filter(function (o) { return o && o.alive; });
        st.angle = (st.angle + PR.CHARGE_SPIN_PER_TICK) % (Math.PI * 2);
        st.ticks++;
        var size = PR.CHARGE_ORB_MIN + (PR.CHARGE_ORB_MAX - PR.CHARGE_ORB_MIN) * Math.min(1, Math.max(0, pct) / 100);
        var cy = p.y + hgt(p) * 0.6;
        for (var i = 0; i < PR.CHARGE_ORBS; i++) {
            var a = st.angle + Math.PI * 2 * i / PR.CHARGE_ORBS;
            var x = p.x + Math.cos(a) * PR.CHARGE_RING_RADIUS, z = p.z + Math.sin(a) * PR.CHARGE_RING_RADIUS;
            if (i >= st.orbs.length) {
                var o = orbSpawn(p, x, cy, z, size);
                if (!o) return;
                st.orbs.push(o);
                continue;
            }
            orbResize(st.orbs[i], size);
            orbMove(st.orbs[i], x, cy, z);
        }
        if (st.ticks % PR.CHARGE_BURN_INTERVAL === 0) burnBystanders(p);
    }
    /** Anything inside the gathering ki takes a hit (every 10 ticks, within 2.7 blocks). */
    function burnBystanders(god) {
        var r = PR.CHARGE_BURN_RADIUS, near = [];
        try { near = god.nearby(r + 2); } catch (e) { near = []; }
        near.forEach(function (e) {
            if (!e || e.uuid === god.uuid || !e.isAlive()) return;
            if (Math.sqrt(dist2(e, god)) > r) return;
            dragonHurt(god, e, "dbr_role:god_ki_prison");
            dust(e, A.RGB, 1.2, e.x, e.y + hgt(e) * 0.5, e.z, 6, 0.3, 0.4, 0.3, 0.01);
        });
    }
    /** GodKiPrison.clearCharge: the gathered orbs go, whether they combine or the charge was dropped. */
    function chargeEnded(p) {
        var st = GATHER[uid(p)];
        if (!st) return;
        delete GATHER[uid(p)];
        st.orbs.forEach(function (o) { if (o && o.alive) o.discard(); });
    }

    /** The living entity on the god's look ray within reach (ProjectileUtil.getEntityHitResult: blocks do not stop it). */
    function lookTarget(p, reach) {
        var hit = null;
        try { hit = p.raycast(reach, { blocks: false, entities: true }); } catch (e) { hit = null; }
        var t = hit && hit.hit === "entity" ? hit.entity : null;
        return t && t.isLiving() && t.uuid !== p.uuid && t.isAlive() ? t : null;
    }

    /**
     * MixinDmzTechniqueDispatcher + RoleMoveHandler: a released charge. false = refused (no cooldown), true = handled
     * (DBR starts the 8 s cooldown and plays the release; a refusal inside the handler still counts, as in the original).
     */
    function cast(p, id, charge) {
        var m = D.MOVES[id];
        chargeEnded(p);
        if (!m) return false;
        if (charge < 0.999) { bar(p, "Not charged: hold it to full."); return false; }
        if (id === "god_hakai") return hakaiCast(p);
        // castStandard: the flat quarter first, then the ability
        if (!spend(p, m.kind, D.COST_STANDARD)) return true;
        return prisonCast(p);
    }

    // =========================================================================================================
    //  GodKiPrison: the gathered ki is thrown at the target and opens into a 4-block sphere that holds it for 3 s
    // =========================================================================================================
    function prisonCast(god) {
        var target = lookTarget(god, PR.REACH);
        if (!target) {
            // no target must not soft lock: the pose drops and the 25 comes back
            stopAct(god);
            refund(god, D.COST_STANDARD);
            return true;
        }
        var orb = orbSpawn(god, god.x, god.y + hgt(god) * 0.6, god.z, PR.THROWN_DIAMETER);
        snd(god, "minecraft:block.beacon.power_select", god.x, god.y, god.z, 1.0, 1.4);
        if (!orb) { addEffect(new Prison(god, target, null)); return true; }
        addEffect(new Flight(god, target, orb));
        return true;
    }
    function Flight(god, victim, orb) { this.god = god; this.victim = victim; this.orb = orb; this.ticks = 0; }
    Flight.prototype.tick = function () {
        var orb = this.orb, v = this.victim;
        if (!orb.alive || !v.isAlive() || ++this.ticks > PR.MAX_FLIGHT_TICKS) { orb.discard(); return false; }
        // steered every tick, so a target that runs is still caught
        var from = orbCentre(orb), to = { x: v.x, y: v.y + hgt(v) * 0.5, z: v.z };
        var gx = to.x - from.x, gy = to.y - from.y, gz = to.z - from.z, len = Math.sqrt(gx * gx + gy * gy + gz * gz);
        if (len <= PR.THROW_SPEED + wid(v)) { this.arrive(); return false; }
        orbMove(orb, from.x + gx / len * PR.THROW_SPEED, from.y + gy / len * PR.THROW_SPEED, from.z + gz / len * PR.THROW_SPEED);
        return true;
    };
    Flight.prototype.cancel = function () { this.orb.discard(); };
    Flight.prototype.arrive = function () {
        orbResize(this.orb, PR.ORB_DIAMETER);
        orbFollow(this.orb, this.victim);
        snd(this.victim, "minecraft:block.beacon.power_select", this.victim.x, this.victim.y, this.victim.z, 1.0, 0.7);
        addEffect(new Prison(this.god, this.victim, this.orb));
    };
    function Prison(god, victim, orb) { this.god = god; this.victim = victim; this.orb = orb; this.ticksLeft = PR.DURATION_TICKS; }
    Prison.prototype.tick = function () {
        var v = this.victim;
        if (!v.isAlive() || this.ticksLeft <= 0) { this.drop(); return false; }
        this.ticksLeft--;
        if (this.orb) orbFollow(this.orb, v);
        // held: slowness IX and an overflowing jump boost (no jump), horizontal motion cut
        potion(v, "minecraft:slowness", 30, 8);
        potion(v, "minecraft:jump_boost", 30, 128);
        zeroXZ(v);
        if (this.ticksLeft % PR.TICK_INTERVAL === 0) {
            if (this.god) dragonHurt(this.god, v, "dbr_role:god_ki_prison");
            // DmzResourceDrain.drain: up to 15 ki and 15 stamina (a DBR character's)
            if (v.isAlive() && v.isPlayer()) {
                var vp = v.asPlayer();
                try { if (created(vp)) { vp.addResource("ki", -Math.min(PR.DRAIN_PER_TICK, vp.resource("ki"))); vp.addResource("stamina", -Math.min(PR.DRAIN_PER_TICK, vp.resource("stamina"))); } } catch (e) { }
            }
        }
        if (this.ticksLeft <= 0) { this.drop(); return false; }
        return true;
    };
    Prison.prototype.cancel = function () { this.drop(); };
    Prison.prototype.drop = function () {
        var o = this.orb;
        if (o && o.alive) {
            var c = orbCentre(o);
            if (typeof DMZ_TECH_PROJ !== "undefined") DMZ_TECH_PROJ.fx(this.god || this.victim, c.x, c.y, c.z, PR.ORB_DIAMETER * 0.5, 0, PR.COLORS);
            o.discard();
        }
    };

    // =========================================================================================================
    //  GodHakai: a full bar and 8 real hours; the god stands still for the 195-tick wind-up, then the target is erased
    // =========================================================================================================
    function hakaiTable() { var t = RPG.data.get(HK_KEY, null); return t && typeof t === "object" ? t : {}; }
    function hakaiLeft(p, now) { var at = Number(hakaiTable()[uid(p)]) || 0; now = now || Date.now(); return at > now ? at - now : 0; }
    function hakaiStart(p, readyAt) { var t = hakaiTable(), o = {}; for (var k in t) if (Number(t[k]) > Date.now()) o[k] = t[k]; o[uid(p)] = readyAt; RPG.data.set(HK_KEY, o); }
    function hakaiReset(p) { var t = hakaiTable(); if (t[uid(p)] !== undefined) { delete t[uid(p)]; RPG.data.set(HK_KEY, t); } }
    function fmtLeft(ms) {
        var minutes = Math.floor(ms / 60000), hours = Math.floor(minutes / 60);
        minutes %= 60;
        return hours > 0 ? hours + "h " + minutes + "m" : minutes + "m";
    }
    /** Raid bosses, the planets' defenders: scheduled, shared fights nobody may delete. */
    function isProtected(t) {
        try { return t.hasTag("dbr_raid_enemy") || t.hasTag("dbr_planet_defender") || t.hasTag("dbr_conquest_boss"); } catch (e) { return false; }
    }
    /** The original's training masters (MastersEntity) are never erasable. */
    function isProtectedNpc(t) {
        if (t.isPlayer()) return false;
        try {
            var id = String(t.rpgId || ""), MD = typeof DMZ_MASTERS_DATA !== "undefined" ? DMZ_MASTERS_DATA : null;
            var dmz = id && MD && MD.BY_NPC ? MD.BY_NPC[id] : null;
            return !!(dmz && MD.isMaster(dmz));
        } catch (e) { return false; }
    }
    function hakaiCast(god) {
        var now = Date.now(), left = hakaiLeft(god, now);
        if (left > 0) { bar(god, "Hakai is not ready for " + fmtLeft(left) + "."); return true; }
        var target = lookTarget(god, HK.REACH);
        if (!target) { stopAct(god); return true; }
        if (isProtected(target)) { bar(god, "That cannot be erased."); return true; }
        if (isProtectedNpc(target)) { bar(god, "That NPC cannot be erased."); return true; }
        if (target.isPlayer() && god.isAlly(target)) { bar(god, "PvP is not allowed against that player here."); return true; }
        if (!spendAll(god, "destruction")) { bar(god, "Hakai needs a full destruction bar."); return true; }
        // the point of no return: the cooldown and the bar are taken now
        hakaiStart(god, now + HK.COOLDOWN_MS);
        // HakaiPresentation: Shurui's Hakai sound at the target (2.0, 1.0), the held Big Bang charge pose, the target stunned
        snd(target, "dbr:hakai", target.x, target.y, target.z, 2.0, 1.0);
        act(god, "ki.bigbang_cast", HK.CHARGE_TICKS + HK.TAIL_TICKS);
        try { target.addEffect("stunned", HK.CHARGE_TICKS + HK.TAIL_TICKS); } catch (e) { }
        holdStill(target);
        addEffect(new HakaiSequence(god, target));
        return true;
    }
    function holdStill(t) { try { t.setVelocity(0, 0, 0); } catch (e) { } }
    function HakaiSequence(god, target) { this.god = god; this.target = target; this.ticksLeft = HK.CHARGE_TICKS; }
    HakaiSequence.prototype.tick = function () {
        var god = this.god, t = this.target;
        if (!god.isAlive() || !t.isAlive()) { this.end(); return false; }
        holdStill(t);
        // the god stands still for it: slowness 250 and an overflowing jump boost, horizontal motion cut
        potion(god, "minecraft:slowness", 30, 250);
        potion(god, "minecraft:jump_boost", 30, 128);
        zeroXZ(god);
        // the held pose lapses on its own: re-sent while the wind-up runs
        if (this.ticksLeft % 40 === 0) act(god, "ki.bigbang_cast", this.ticksLeft + HK.TAIL_TICKS);
        // the target coming apart: purple motes thickening as the wind-up runs
        var progress = 1 - this.ticksLeft / HK.CHARGE_TICKS;
        dust(t, A.RGB, 1 + progress, t.x, t.y + hgt(t) * 0.5, t.z, 1 + Math.round(progress * 5), wid(t) * 0.6, hgt(t) * 0.4, wid(t) * 0.6, 0.02);
        if (--this.ticksLeft <= 0) {
            // asked again at the moment of erasure
            if (t.isPlayer() && god.isAlly(t)) { bar(god, "PvP is not allowed against that player here."); this.end(); return false; }
            erase(t);
            this.end();
            return false;
        }
        return true;
    };
    HakaiSequence.prototype.cancel = function () { this.end(); };
    HakaiSequence.prototype.end = function () { stopAct(this.god); };
    /** Erase: a player is killed (no ban, no kick: they respawn); anything else simply stops existing (no drops). */
    function erase(t) {
        dust(t, A.RGB, 2.5, t.x, t.y + hgt(t) * 0.5, t.z, 80, 0.5, 0.8, 0.5, 0);
        snd(t, "minecraft:block.amethyst_block.break", t.x, t.y, t.z, 1.4, 0.4);
        if (t.isPlayer()) { t.damageFrom(3.4e38, null, { kind: "magic", tag: "dbr_role:hakai", knockback: 0 }); return; }
        try { t.remove(); } catch (e) { }
    }

    // =========================================================================================================
    //  ClashBypass (the planet buster's clash, 87_dbr_space_buster.js): a god who spends a full bar skips it
    // =========================================================================================================
    function clashBypass(p) {
        if (!p || !hasAccess(p, "destruction")) return false;
        if (!spendAll(p, "destruction")) return false;
        bar(p, "Destruction overwhelms the clash.");
        return true;
    }

    // =========================================================================================================
    //  The Angel's Staff (AngelStaffSummon + AngelStaffGuard): the Angel's alone, unmade when the title lapses,
    //  on death, logout and respawn; it hits as the claw lance (KiWeaponCombat, 09_dmz_stats.js meleeBonus)
    // =========================================================================================================
    function mayWield(p, type) {
        var w = DMZ_COMBAT.KI_WEAPONS[type];
        if (!w || !w.role) return true;
        if (hasAccess(p, w.role)) return true;
        bar(p, "Only the Angel may summon that.");
        return false;
    }
    /** After a ki weapon pick touched the staff: out -> "The staff answers.", put away -> "The staff fades.". */
    function staffChanged(p, out) {
        snd(p, out ? "minecraft:block.beacon.activate" : "minecraft:block.beacon.deactivate", p.x, p.y, p.z, 0.7, 1.8);
        bar(p, out ? "The staff answers." : "The staff fades.");
    }
    function stripStaff(p) {
        if (String(p.getVar("dmz_kiweapon", "") || "").toLowerCase() !== D.STAFF) return false;
        p.setVar("dmz_kiweapon", DMZ_COMBAT.KI_WEAPON_ORDER[0]);
        var m = p.getVar("dmz_skill_active", null);
        if (m && typeof m === "object" && m.kimanipulation) {
            var o = {};
            for (var k in m) if (k !== "kimanipulation") o[k] = m[k];
            p.setVar("dmz_skill_active", o);
        }
        if (typeof DMZ_KIWEAPON !== "undefined") DMZ_KIWEAPON.sync(p);
        return true;
    }

    // ---- RoleTechniqueGrant / RoleTechniqueSync: the title puts the moves in the list, losing it takes them off --
    function syncMoves(p, t) {
        if (typeof DMZ_TECH === "undefined" || !created(p)) return;
        Object.keys(D.MOVES).forEach(function (id) {
            var want = hasAccess(p, D.MOVES[id].kind, t), has = DMZ_TECH.has(p, id);
            if (want && !has) { DMZ_TECH.unlock(p, id, { source: "role", silent: true }); DMZ_TECH.sendState(p); }
            else if (!want && has) { DMZ_TECH.forget(p, id); DMZ_TECH.sendState(p); }
        });
    }

    // ---- once a second: EnergySync regen + push, RoleStateGuard, RoleTechniqueSync, AngelStaffGuard's sweep --------
    RPG.every(20, function () {
        RPG.server.players().forEach(function (p) {
            var cur = get(p);
            if (cur < MAX) store(p, cur + D.REGEN_PER_SECOND);           // everyone, role or not
            var t = title(p);
            if (!hasAccess(p, "destruction", t) && auraActive(p)) auraClear(p);
            if (!hasAccess(p, "angelic", t) && angelActive(p)) angelClear(p);
            syncMoves(p, t);
            if (!hasAccess(p, "angelic", t)) stripStaff(p);
            push(p);
        });
    });
    RPG.on("playerJoin", function (p) {
        delete SENT[uid(p)];
        auraClear(p); angelClear(p);
        try { p.setShared(MODE_KEY, null); } catch (e) { }
        push(p, true);
    });
    RPG.on("playerLeave", function (p) {
        delete SENT[uid(p)];
        auraClear(p); angelClear(p);
        chargeEnded(p);
        stripStaff(p);
    });
    RPG.on("death", function (p) { stripStaff(p); chargeEnded(p); });
    RPG.on("respawn", function (p) { stripStaff(p); push(p, true); });
    // a script reload forgets the running states: nobody keeps an outline they no longer have
    RPG.server.players().forEach(function (p) { try { p.setShared(MODE_KEY, null); } catch (e) { } });

    // ---- client requests (PacketAbilityActivate is empty: the server decides) ------------------------------------
    RPG.net.on("dbr_role", function (p, d) {
        if (!d || !p) return;
        var a = String(d.a || "");
        if (a === "ability") activateAbility(p);
        else if (a === "sync") push(p, true);
    });

    // ---- /rpgc role (staff testing) --------------------------------------------------------------------------------
    var ROLE_IDS = [T.GOD, T.ANGEL, T.ZENO];
    function roleName(t) { return t === T.ZENO ? "Grand Zeno" : t === T.GOD ? "God of Destruction" : t === T.ANGEL ? "Angel" : ""; }
    function info(p) {
        var t = title(p), k = activeKind(p, t);
        var lines = ["&6" + p.name + ": &f" + (roleName(t) || "no role") + (k ? " &7| " + k + " energy &f" + Math.floor(get(p)) + "/100" : "")];
        if (hasAccess(p, "destruction", t)) lines.push("&7Hakai: " + (hakaiLeft(p) > 0 ? "&cready in " + fmtLeft(hakaiLeft(p)) : "&aready"));
        if (auraActive(p)) lines.push("&7Destruction aura: &fup");
        if (angelActive(p)) lines.push("&7Angelic state: &fup");
        return lines;
    }
    function adm(p) { return DBR_CMD.has(p, "role.admin"); }
    DBR_CMD.tree("role", {
        description: "God roles: info [player] | grant <role> <player> | clear <role> | energy <amount> [targets] | hakaireset [targets]",
        canUse: function () { return true; },
        exec: function (c) { if (!c.src) return c.fail("Players only."); info(c.src).forEach(c.tell); },
        children: [
            { lit: "info", exec: function (c) { if (!c.src) return c.fail("Players only."); info(c.src).forEach(c.tell); },
                children: [{ arg: "targets", type: "players", perm: adm, exec: function (c) { c.players("targets").forEach(function (t) { info(t).forEach(c.tell); }); } }] },
            { lit: "grant", perm: adm, children: [{ arg: "role", type: "word", suggest: function () { return ROLE_IDS.slice(); }, children: [
                { arg: "player", type: "player", exec: function (c) {
                    var r = String(c.get("role")).toLowerCase(), who = c.players("player")[0];
                    if (ROLE_IDS.indexOf(r) < 0) return c.fail("Roles: " + ROLE_IDS.join(", "));
                    if (!who) return c.fail("No such player.");
                    DBR_TOURNEY.grantTitle(r, who);
                    push(who, true);
                    c.tell("&aGranted " + r + " to " + who.name + ".");
                } }] }] },
            { lit: "clear", perm: adm, children: [{ arg: "role", type: "word", suggest: function () { return ROLE_IDS.slice(); }, exec: function (c) {
                var r = String(c.get("role")).toLowerCase();
                if (ROLE_IDS.indexOf(r) < 0) return c.fail("Roles: " + ROLE_IDS.join(", "));
                c.tell(DBR_TOURNEY.clearTitle(r) ? "&eCleared the holder of " + r + "." : "&e" + r + " had no holder.");
            } }] },
            { lit: "energy", perm: adm, children: [{ arg: "amount", type: "double", exec: function (c) {
                if (!c.src) return c.fail("Name a player.");
                set(c.src, Number(c.get("amount"))); c.tell("&aRole energy set to " + Math.floor(get(c.src)) + ".");
            }, children: [{ arg: "targets", type: "players", exec: function (c) {
                c.players("targets").forEach(function (t) { set(t, Number(c.get("amount"))); });
                c.tell("&aRole energy set for " + c.players("targets").length + " player(s).");
            } }] }] },
            { lit: "hakaireset", perm: adm, exec: function (c) {
                if (!c.src) return c.fail("Name a player.");
                hakaiReset(c.src); c.tell("&aHakai cooldown cleared.");
            }, children: [{ arg: "targets", type: "players", exec: function (c) {
                c.players("targets").forEach(function (t) { hakaiReset(t); });
                c.tell("&aHakai cooldown cleared for " + c.players("targets").length + " player(s).");
            } }] }
        ]
    });

    return { isMove: D.isMove, canCharge: canCharge, tickCharge: tickCharge, cast: cast, chargeEnded: chargeEnded,
        mayWield: mayWield, staffChanged: staffChanged, clashBypass: clashBypass, hasAccess: hasAccess, activeKind: activeKind,
        get: get, set: set, spend: spend, drain: drain, auraActive: auraActive, angelActive: angelActive,
        activateAbility: activateAbility, hakaiLeft: hakaiLeft, push: push };
})();
