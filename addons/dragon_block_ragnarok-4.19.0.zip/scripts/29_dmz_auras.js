// =====================================================================================
//  29_dmz_auras.js - how original auras look: 2D or 3D, the per-form 3D tuning, flight, boost
// =====================================================================================
//  Ported from the original (GPL-3.0, see NOTICE.md): the "My Aura - 3D Style / 3D Type" options
//  (config.aura3DPersonal / aura3DStyle), FormConfig's Aura3DStyle per form, the forced
//  "sparking" 3D aura of legendaryforms and "god" of the God ritual, and the ki surge's
//  bigger, faster aura. Drawn by the engine's aura renderer (mode / mesh / boost blocks).
//
//  Look values every client reads (player.setColor):
//      dmzAura3d     "" (2D) | "smooth" | "spiky" | "calm"   the 3D style this player shows
//      dmzAuraTune   "key=value;..."                          the active form's 3D tuning
//  Var: dmz_aura3d_pref  "" | "smooth" | "sparking" | "god"   the player's own choice
//  Shared: auraBoost 0..100 (64_dmz_surge.js) swells the aura while the surge charges.
//
//  DMZ_AURA.spec(aura) adds the 3D / flight / boost fields to a 2D aura block; 30_forms.js
//  wraps its dmz_aura_<n> sizes with it, 45_keys.js the plain charge aura.
// =====================================================================================
var DMZ_AURA = (function () {
    // Original style names -> the engine's
    var STYLES = { smooth: "smooth", sparking: "spiky", god: "calm" };

    // FormConfig Aura3DStyle defaults (size, flamePeaks, waves, turbulence)
    var BASE_MESH = { style: "smooth", size: [1.10, 1.17, 1.02], peaks: 12, waveFrequency: 2.0, waveSpeed: 5.0, waveAmplitude: 0.75,
        noise: 0.09, lift: 0.62, spikeRate: 3.0, spikeRarity: 3.0, tune: "{dmzAuraTune}",
        blend: "translucent" };                                  // The original's aura_smooth/sparking/god: srcalpha, 1-srcalpha

    function spec(a) {
        var out = {};
        for (var k in a) out[k] = a[k];
        out.mode = "{dmzAura3d}";
        out.blend = "intensity";                                 // The original's 2D aura shader: alpha = texture intensity, srcalpha/1-srcalpha, white-hot core
        out.mesh = BASE_MESH;
        out.flipSpeed = 0.42;                                    // Original fast flight starts at 0.451 b/t
        out.flipShared = "flyFast";                              // Original leans the aura only while isFlyingFast (64_dmz_movement.js)
        // AuraRenderer.auraLeanDegrees: the lean is 90 - the head's pitch about the body's yaw (it lies back from where you
        // look, not along your motion), applied at once; a swimming player's aura lies along the body. Jumps and falls
        // never lean it (no flyFast).
        out.flipAxis = "look";
        out.flipEase = 0;
        // renderShaderPulseAura: two ground waves half a cycle apart while standing on the ground (PULSE_SPEED 0.01 a
        // frame, about 0.6 a second at 60 fps), fading in and out as sin(pi x progress). 3D: a flattened shell of the
        // aura's style 0.9 x 0.75 x the aura scale across growing x(1 + 3p), 0.22 x the aura scale tall, alpha 0.5,
        // turning 2.5 degrees a tick. 2D: the aura's _cross sheet on the ground, 0.5 x the aura scale growing x(1 + 6p),
        // alpha 0.6. (The engine's shell radius is 0.8 / 0.984 of the aura scale, so 0.9 x 0.75 x 1.23 = 0.83 of it.)
        out.pulse = { rate: 0.6, radius: 0.83, grow: 3, height: 0.08, spin: 2.5, alpha: 0.5, size: 0.1136, flatGrow: 6, flatAlpha: 0.6, frames: 4 };
        if (a.texture === "{dmzAuraTex}") out.pulse.texture = "{dmzAuraCross}";
        else if (a.texture && /_aura\.png$/.test(a.texture)) out.pulse.texture = a.texture.replace(/_aura\.png$/, "_cross.png");
        // The original AuraRenderer: the 2D quad is 2 x 2.2 x auraScale x modelScale tall with its middle 0.05 + 0.35 x that
        // above the feet. 31_dmz_transform.js already folds the form's model scale into the height, so the engine must
        // not scale it by the player's size again. The 3D shell follows the same height (radius 0.18 x it).
        out.center = 0.36;
        out.boost = { key: "auraBoost", max: 100, scale: 0.25, speed: 0.5, whiten: 0.3 };   // surge: aura x1.25, speed x1.5
        return out;
    }

    // ---- per-form 3D tuning (DefaultFormsFactory / FormConfig) -------------------------
    // waves(frequency, speed, amplitude), turbulence(noiseDetail, upwardBias), size, noise colour.
    // The original's noise detail drives a texture lookup; on the engine shell it maps to 0.06 + 0.3 x detail.
    function T(o) {
        var p = [];
        if (o.size) p.push("size=" + (o.size[0] / BASE_MESH.size[0]).toFixed(3) + "," + (o.size[1] / BASE_MESH.size[1]).toFixed(3) + "," + (o.size[2] / BASE_MESH.size[2]).toFixed(3));
        if (o.w) p.push("waveFrequency=" + o.w[0], "waveSpeed=" + o.w[1], "waveAmplitude=" + o.w[2]);
        if (o.t) p.push("noise=" + Math.min(0.4, 0.06 + 0.3 * o.t[0]).toFixed(3), "lift=" + (o.t[1] + 0.08).toFixed(2));
        if (o.noise) p.push("noiseColor=" + o.noise);
        if (o.core) p.push("coreColor=" + o.core);
        if (o.rim) p.push("rimColor=" + o.rim);
        return p.join(";");
    }
    function dark(noise, o) {                                    // darkAura(noise)
        var d = { w: [2.1, 5.0, 0.76], t: [0.5, 0.54], noise: noise };
        for (var k in o || {}) d[k] = o[k];
        return T(d);
    }
    function kaioken(a) { return T({ size: [1.18, 1.20, 1.12], w: [2.1, 5.0, a], t: [1.0, 0.51], core: "#FF0000", rim: "#FF0000", noise: "#FF0066" }); }

    var TUNE = {
        supersaiyan: T({ w: [2.0, 5.0, 0.77], t: [0.14, 0.54] }),
        supersaiyangrade2: T({ size: [1.14, 1.18, 1.06], w: [2.0, 5.2, 0.8], t: [0.16, 0.54] }),
        supersaiyangrade3: T({ size: [1.22, 1.22, 1.12], w: [2.0, 4.4, 0.86], t: [0.2, 0.5] }),
        supersaiyanmastered: T({ w: [1.9, 4.6, 0.7], t: [0.08, 0.54] }),
        supersaiyan2: T({ w: [2.1, 5.6, 0.8], t: [0.18, 0.55], noise: "#FFF6C8" }),
        supersaiyan4: T({ w: [2.0, 5.0, 0.78], t: [0.13, 0.54], noise: "#C8102E" }),
        falsesupersaiyan: T({ w: [2.1, 5.2, 0.82], t: [0.22, 0.55], noise: "#FFF0A0" }),
        supersaiyangodritual: T({ w: [2.0, 5.2, 0.8], t: [0.18, 0.55], noise: "#FFC04D" }),
        // God Ki and the Blue forms (shared/07_dmz_forms_data.js, DBR's own): God Ki's aura is the ritual's calm god aura, Blue
        // burns like SSJ, Evolution and Rampage swell like the buffed grades
        godki: T({ w: [2.0, 5.2, 0.8], t: [0.18, 0.55], noise: "#FFC04D" }),
        supersaiyanblue: T({ w: [2.0, 5.0, 0.77], t: [0.14, 0.54], noise: "#D8F6FF" }),
        supersaiyanblueevolution: T({ size: [1.14, 1.18, 1.06], w: [2.0, 5.4, 0.82], t: [0.2, 0.55], noise: "#A8DCFF" }),
        supersaiyanbluerampage: T({ size: [1.22, 1.26, 1.12], w: [2.2, 6.0, 0.9], t: [0.35, 0.56], noise: "#E8FBFF" }),
        ikari: T({ w: [2.2, 5.6, 0.8], t: [0.3, 0.55], noise: "#1B8C00" }),
        ssjhybrid: T({ size: [1.14, 1.2, 1.06], w: [2.2, 5.8, 0.84], t: [0.35, 0.56], noise: "#1B8C00" }),
        ssjfullpower: T({ size: [1.22, 1.26, 1.12], w: [2.2, 6.0, 0.9], t: [0.42, 0.56], noise: "#0F5C00" }),
        shiyoken: dark("#FF1A1A", { w: [2.1, 5.2, 0.78], t: [0.45, 0.54] }),
        shin_shiyoken: dark("#FF1A1A", { size: [1.12, 1.2, 1.03], w: [2.1, 5.2, 0.8], t: [0.45, 0.54] }),
        chou_shiyoken: dark("#FF1A1A", { size: [1.18, 1.24, 1.08], w: [2.1, 5.4, 0.82], t: [0.5, 0.55] }),
        supernamekian: T({ w: [1.9, 4.8, 0.7], t: [0.12, 0.52], noise: "#E8FFB0" }),
        evilnamek: dark("#FF0000", { size: [1.12, 1.2, 1.03] }),
        evilgiantnamek: dark("#FF0000"),
        buffednamek: dark("#FF0000", { size: [1.14, 1.2, 1.05], w: [2.1, 5.2, 0.8] }),
        androidbase: T({ w: [1.9, 4.5, 0.6], t: [0.05, 0.52] }),
        superandroid: T({ w: [2.0, 5.0, 0.72], t: [0.1, 0.54] }),
        fusedandroid: T({ size: [1.14, 1.2, 1.06], w: [2.1, 5.4, 0.8], t: [0.3, 0.55] }),
        xeno: dark("#9D00FF"),
        xenofp: dark("#9D00FF", { size: [1.12, 1.2, 1.03], w: [2.1, 5.2, 0.8] }),
        xenomax: dark("#9D00FF"),
        outofcontrol: T({ w: [2.1, 5.4, 0.8], t: [0.35, 0.55], noise: "#FF3A3A" }),
        absorption: T({ w: [2.1, 7.4, 1.8], t: [0.65, 0.55], noise: "#FFF7FF" }),
        trueform: dark("#B05CFF", { size: [1.12, 1.2, 1.04], w: [2.1, 5.2, 0.8], t: [0.45, 0.54] }),
        ultimate: T({ w: [1.8, 3.6, 0.5], t: [0.05, 0.5] })
    };
    var KAIOKEN = { x2: kaioken(0.67), x3: kaioken(0.70), x4: kaioken(0.72), x10: kaioken(0.76), x20: kaioken(0.80) };

    function pair(v) { var s = String(v || ""), i = s.indexOf(":"); return i < 0 ? null : { g: s.substring(0, i), f: s.substring(i + 1) }; }

    // ---- who shows what ---------------------------------------------------------------
    function styleFor(p) {
        var pref = String(p.getVar("dmz_aura3d_pref", "") || "");
        if (!pref) return "";
        var form = pair(p.getVar("dmz_form", ""));
        if (form && (form.f === "supersaiyangodritual" || form.f === "godki")) return "calm";   // the ritual's god aura, God Ki
        if (form && form.g === "legendaryforms") return "spiky";                   // DefaultFormsFactory: forced "sparking"
        if (pref === "god" && p.race !== "glind") pref = "smooth";                 // "3D: God" is Glind's (Celestial Body)
        return STYLES[pref] || "smooth";
    }
    // per 3D type (AuraRenderer.executeSmoothDraw / executeGodDraw / executeAura3DDraw): smooth and god turn with the
    // body, sparking does not; the flight lead ahead of the body (0.25, sparking's 1.10 past its lower core ~ 0.5); your
    // own aura in first person at 0.45 / 0.35 / 0.15 alpha, seen from inside (back faces 1.0, sparking 0.85)
    var STYLE_TUNE = {
        smooth: "followYaw=1;lead=0.25;firstPersonAlpha=0.45;firstPersonBackFace=1",
        calm: "followYaw=1;lead=0.25;firstPersonAlpha=0.35;firstPersonBackFace=1",
        spiky: "followYaw=0;lead=0.49;firstPersonAlpha=0.15;firstPersonBackFace=0.85"
    };
    function tuneFor(p) {
        var form = pair(p.getVar("dmz_form", "")), stack = pair(p.getVar("dmz_stack", ""));
        var t = STYLE_TUNE[styleFor(p)] || "";
        if (form && TUNE[form.f]) t = t ? t + ";" + TUNE[form.f] : TUNE[form.f];
        if (stack && stack.g === "kaioken" && KAIOKEN[stack.f]) t = t ? t + ";" + KAIOKEN[stack.f] : KAIOKEN[stack.f];
        else if (stack && TUNE[stack.f]) t = t ? t + ";" + TUNE[stack.f] : TUNE[stack.f];
        // In a space pod the aura wraps the pod (44_dbr_trails.js, the Ragnarok original's MixinDmzAuraPodEncase, which
        // lays the original's own shell round the pod). The engine's sparking shell throws loose spike shards, which on
        // the pod read as fake sparks; the pod keeps the shell and drops the shards.
        if (styleFor(p) === "spiky" && inPod(p)) t = t ? t + ";spikes=0" : "spikes=0";
        return t;
    }
    function inPod(p) { try { var v = p.getVehicle(); return !!v && v.getVehicleId() === "spacepod"; } catch (e) { return false; } }
    function setLook(p, k, v) { if (String(p.getColor(k) || "") !== v) p.setColor(k, v); }
    function refresh(p) {
        if (!p.getVar("dmz_created", 0)) return;
        setLook(p, "dmzAura3d", styleFor(p));
        setLook(p, "dmzAuraTune", tuneFor(p));
    }

    // the client's choice (client/scripts/43_dmz_auras.js, from the config menu)
    RPG.net.on("dmz_aura3d", function (p, d) {
        var pref = d && d.on ? String(d.style || "smooth") : "";
        if (pref && !STYLES[pref]) pref = "smooth";
        if (String(p.getVar("dmz_aura3d_pref", "") || "") !== pref) p.setVar("dmz_aura3d_pref", pref);
        var fl = d && d.flight === false ? 0 : 1;                                   // "Flight Aura" (default on)
        if (Number(p.getVar("dmz_flight_aura", 1)) !== fl) p.setVar("dmz_flight_aura", fl);
        refresh(p);
    });
    RPG.every(10, function () { RPG.server.players().forEach(refresh); });

    // /rpgc aura <2d|smooth|sparking|god|surge>: the same as the config menu, plus a forced ki surge for testing
    DBR_CMD.renamed("aura", "dmzaura", {
        description: "/rpgc aura <2d|smooth|sparking|god|surge> - your aura style (or fire a ki surge)",
        run(player, args) {
            if (!player) return;
            var a = String(args[0] || "").toLowerCase();
            if (a === "surge") {
                if (!player.isOp()) { player.tell("&cOperators only."); return; }
                if (typeof DMZ_SURGE !== "undefined") DMZ_SURGE.force(player);
                return;
            }
            if (a !== "2d" && !STYLES[a]) { player.tell("&7Aura: &f" + (String(player.getVar("dmz_aura3d_pref", "") || "2d")) + " &7(/rpgc aura 2d|smooth|sparking|god|surge)"); return; }
            player.setVar("dmz_aura3d_pref", a === "2d" ? "" : a);
            refresh(player);
            // the config menu keeps its choice on that computer: tell it, so it doesn't send its old one back later
            RPG.net.send(player, "dmz_aura3d_set", { on: a !== "2d", style: a === "2d" ? "" : a });
            player.tell("&aAura style: " + a + (a === "god" && player.race !== "glind" ? " &7(God is Glind's: showing Smooth)" : ""));
        }
    });

    return { spec: spec, refresh: refresh, styleFor: styleFor, tuneFor: tuneFor };
})();
