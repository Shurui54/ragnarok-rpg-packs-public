# Dragon Block Ragnarok

Dragon Block Ragnarok is an addon for the Ragnarok RPG Toolkit. Its gameplay systems are a port of
**DragonMine Z** (https://github.com/DragonMineZ/dragonminez), rewritten as toolkit scripts.

- DragonMine Z is Copyright (c) DragonMine Z 2025 and is licensed under the GNU General Public License v3.0.
- This addon is a modified version of that work and is likewise licensed under the **GNU General Public
  License v3.0** (see `LICENSE`). Its scripts are its complete source code.
- Models, textures, animations and sounds come from DragonMine Z through the separate `dmzpack` asset pack,
  which carries its own credits, including CC-BY attributions for third-party sounds.
- Changes: DragonMine Z's Java systems were reimplemented as JavaScript for the Ragnarok RPG Toolkit's script
  engine; content and balance are adapted to that engine.
- The structure templates in `datapack/data/dbr/structures/dmz/` and their descriptions in `data/dmz_structures/`
  are converted from DragonMine Z's structure files, Other World region files and tournament schematic
  (split into 32x32 pieces, DMZ blocks mapped to this addon's blocks or vanilla stand-ins). The chest loot
  tables in `datapack/data/dbr/loot_tables/chests/` are DragonMine Z's.

- The hair system (`shared/11_dmz_hair.js`) ports DragonMine Z's strand hair (hair codes, presets, per-form styles,
  physics profiles); `client/data/dmz_hair_presets.json` and `shared/10_dmz_hair_presets.js` are DragonMine Z's
  hair preset codes, decoded with that file's decoder.

Dragon Ball is a trademark of its respective owners. This is a non-commercial fan project.
