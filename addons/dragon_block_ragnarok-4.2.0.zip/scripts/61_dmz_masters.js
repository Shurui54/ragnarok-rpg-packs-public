// =====================================================================================
//  61_dmz_masters.js - talking to DMZ's masters and story NPCs (server side)
// =====================================================================================
//  DMZ flow (QuestNPCEntity/MastersEntity.mobInteract -> OpenQuestNPCDialogueS2C ->
//  NpcDialogueScreen; services -> NPCActionC2S -> DialogueResultS2C):
//    right-click an NPC  -> "dmz_npc_open" {npc, master, quests, st}      (this file)
//    the dialogue screen  -> "dmz_npc" {a: "action" | "buy" | "quest_accept" | ...}
//    the result          <- "dmz_npc_result" {npc, action, ok, reason}, then a fresh "dmz_npc_state"
//  The screen itself is client/scripts/52_masters_screen.js; the master table is
//  shared/08_dmz_masters_data.js. Skills are bought through DMZ_SKILLS.purchase (46_dmz_skills.js);
//  quests start through DMZ_QUESTS.start (47_dmz_quests.js, which also hands quests in when you
//  talk to their turn-in NPC). Yemma, Baba and the Otherworld announcer use 60_otherworld.js's
//  revive / return services (owBabaRevive, owEnmaReturn, owTeleport...).
//
//  Cooldowns (DMZ Cooldowns) are kept in the player var "dmz_cd" as ticks left (-1 = forever) and
//  count down while the player is online, like DMZ's.
//  Config: config/dbr_masters.json (created on first run).
// =====================================================================================
var DMZ_MASTERS = (function () {
    var MD = DMZ_MASTERS_DATA, C = MD.CONFIG;
    var CFG = RPG.files.config("dbr_masters", {
        senzuGiftAmount: C.senzuGiftAmount,
        senzuGiftCooldownTicks: C.senzuGiftCooldownTicks,
        kamiBlessTpMultiplier: C.kamiBlessTpMultiplier,
        kamiBlessDurationSeconds: C.kamiBlessDurationSeconds,
        kamiBlessCooldownSeconds: C.kamiBlessCooldownSeconds,
        majinPower: C.majinPower,
        maxWeightRequestable: C.maxWeightRequestable,
        // Yemma, Baba and the Otherworld announcer open DMZ's dialogue screen too (their services stay in 60_otherworld.js)
        dmzDialogueInOtherworld: true
    });
    var OW_IDS = ["enma", "baba", "otherworld_announcer"];
    var HTC = "ragnarok_rpg:time_chamber";

    // ---- small helpers ----------------------------------------------------------------
    function created(p) { return !!p.getVar("dmz_created", 0); }
    function alignment(p) { var a = Number(p.getVar("dmz_alignment", 100)); return isNaN(a) ? 100 : a; }
    function race(p) { return typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS.race(p) : (DMZ_DATA.DMZ[p.race] || p.race); }
    function skill(p, s) { return typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS.level(p, s) : 0; }
    function npcOf(id) { return (MD.MASTERS[id] || MD.QUEST_NPCS[id] || {}).npc || id; }
    function dmzIdOf(npcId) { return MD.BY_NPC[npcId] || null; }
    function tick() { return RPG.server.getTick(); }
    function msg(p, key, args, color) { RPG.net.send(p, "dmz_msg", { key: key, args: args || [], color: color || "#FF5555" }); }
    function owReady() { return typeof owBabaRevive === "function" && typeof owEnmaReturn === "function" && typeof owCanEnmaReturn === "function"; }
    function handled(id) {
        if (!id) return false;
        if (OW_IDS.indexOf(id) >= 0) return !!CFG.dmzDialogueInOtherworld && owReady();
        return true;
    }

    // ---- cooldowns (StatsData.getCooldowns) ----------------------------------------------
    function cds(p) { var m = p.getVar("dmz_cd", null); return m && typeof m === "object" ? m : {}; }
    function cd(p, key) { var v = cds(p)[key]; return typeof v === "number" ? v : 0; }
    function hasCd(p, key) { var v = cd(p, key); return v === -1 || v > 0; }
    function setCd(p, key, ticks) { var m = cds(p); if (ticks === 0) delete m[key]; else m[key] = ticks; p.setVar("dmz_cd", m); }
    function babaCd(p) { return Number(p.getVar("dmz_baba_cd", 0)) || 0; }           // 60_otherworld.js (REVIVE_BABA)
    RPG.every(20, () => RPG.server.players().forEach((p) => {
        var m = cds(p), changed = false;
        Object.keys(m).forEach((k) => {
            if (m[k] > 0) { m[k] = Math.max(0, m[k] - 20); changed = true; if (m[k] === 0) delete m[k]; }
        });
        if (changed) p.setVar("dmz_cd", m);
        // MajinStatusHandler: the Majin mark keeps alignment at 0 (and survives relogs)
        if (p.getVar("dmz_majin", 0)) {
            if (!p.hasEffect("dmz_majin")) p.addEffect("dmz_majin", -1);
            if (alignment(p) !== 0) p.setVar("dmz_alignment", 0);
        }
    }));

    // ---- rate limits (PacketRateLimiter) ------------------------------------------------
    var RATE = {};
    function allow(p, key, ticks) {
        var k = p.uuid + "|" + key, now = tick(), last = RATE[k];
        if (last !== undefined && now - last < ticks && now >= last) return false;
        RATE[k] = now;
        return true;
    }

    // ---- range checks (NPCActionC2S.isNpcInRange / isAnyMasterInRange) -------------------
    function npcsNear(p) { return p.nearby(C.npcRange + 1).filter((e) => e.isAlive() && dmzIdOf(String(e.rpgId || ""))); }
    function inRange(p, id) { var npc = npcOf(id); return npcsNear(p).some((e) => e.rpgId === npc); }
    function nearestDmzNpc(p) {
        var masters = npcsNear(p).filter((e) => MD.isMaster(dmzIdOf(e.rpgId)));
        if (masters.length) return dmzIdOf(masters[0].rpgId);
        var any = npcsNear(p);
        return any.length ? dmzIdOf(any[0].rpgId) : "unknown";
    }

    // ---- what the dialogue needs to know (StatsData on the client in DMZ) -----------------
    function fused(p) { return p.hasEffect("potara_fusion") || !!p.getVar("dmz_fused", 0); }
    function hasNimbus(p) { return p.hasItem("flying_nimbus", 1) || p.hasItem("black_nimbus", 1); }
    function geroEligible(p) { return ((DMZ_SKILLS_DATA.FORM_COSTS[race(p)] || {}).androidforms || []).length > 0; }
    function healthy(p) {
        return p.health >= p.maxHealth - 0.5 && p.resource("ki") >= p.maxResource("ki") - 0.5 && p.resource("stamina") >= p.maxResource("stamina") - 0.5;
    }
    function tailRace(p) { return MD.TAIL_RACES.indexOf(race(p)) >= 0; }
    function hasTail(p) { return String(p.getColor("tail") || "1") !== "0"; }
    // HairManager.canUseHair: the default hair races, plus races whose head has a hair bone (Glinds)
    function hairRace(p) { return MD.HAIR_RACES.indexOf(race(p)) >= 0 || !!(DMZ_DATA.LOOKS[race(p)] || {}).hair; }
    function alive(p) { return typeof dmzIsDead === "function" ? !dmzIsDead(p) : true; }
    function tempEnabled() { return typeof owTempEnabled === "function" && owTempEnabled(); }
    function tempActive(p) { return typeof owTempActive === "function" && owTempActive(p); }

    function state(p) {
        var c = {};
        [MD.CD.SENZU_KARIN, MD.CD.KAMI_BLESS].forEach((k) => { c[k] = cd(p, k); });
        c.revive_baba = babaCd(p);
        return {
            align: alignment(p), cd: c, race: race(p), android: !!p.getVar("dmz_android", 0), fused: fused(p),
            nimbusOwned: hasCd(p, MD.CD.KARIN_NIMBUS) || hasNimbus(p),
            potential: skill(p, "potentialunlock"), majin: p.hasEffect("dmz_majin") || !!p.getVar("dmz_majin", 0),
            tailRace: tailRace(p), tail: hasTail(p), hair: hairRace(p), hairStyle: String(DMZ_HAIR.presetOf(p.getColor("hairStyle"), p.getRace())), hairColor: p.getColor("hair") || "",
            geroEligible: geroEligible(p), healthy: healthy(p), inHtc: p.dimension === HTC, maxWeight: Math.max(1, Math.floor(Number(CFG.maxWeightRequestable) || 1)),
            alive: alive(p), tempEnabled: tempEnabled(), tempActive: tempActive(p),
            canEnmaReturn: typeof owCanEnmaReturn === "function" ? !!owCanEnmaReturn(p) : true,
            babaTempMin: typeof OW_CFG !== "undefined" ? Math.round((Number(OW_CFG.babaTempReturnSeconds) || 3600) / 60) : 60,
            skills: typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS.levels(p) : {},
            done: typeof DMZ_QUESTS !== "undefined" ? DMZ_QUESTS.completedKeys(p) : [],
            tp: p.getTp(),
            minigames: typeof DMZ_MINIGAMES !== "undefined" && DMZ_MINIGAMES ? true : false,
            tournaments: typeof DMZ_TOURNAMENTS !== "undefined" && DMZ_TOURNAMENTS ? true : false
        };
    }

    // ---- quests offered here (QuestService.collectNpcQuestOptions) ------------------------
    function qview(p) {
        var v = p.getVar("dmz_quests", null);
        if (!v || typeof v !== "object") v = { q: {}, d: null, resets: 0 };
        if (!v.q) v.q = {};
        v.skill = (s) => skill(p, s);
        v.level = p.getLevel();
        v.alignment = alignment(p);
        v.race = race(p);
        v.cls = p.playerClass;
        return v;
    }
    function questGiverBlocker(p, e) {
        if (!e.side) return null;
        var g = MD.norm(e.quest.quest_giver);
        if (!g || declaresAlignment(e.quest.requirements) || declaresAlignment(e.quest.prerequisites)) return null;
        return MD.MASTER_IDS.indexOf(g) >= 0 ? MD.masterBlocker(alignment(p), g) : null;
    }
    function declaresAlignment(g) {
        if (!g || !g.conditions) return false;
        return g.conditions.some((c) => c.conditions ? declaresAlignment(c) : c.type === "ALIGNMENT");
    }
    function quests(p, id) {
        if (typeof DMZ_QL === "undefined") return { list: [], turnedIn: false };
        var QL = DMZ_QL, v = qview(p), now = Date.now(), out = [], turnedIn = false;
        Object.keys(QL.BY_KEY).forEach((k) => {
            var e = QL.BY_KEY[k], q = e.quest;
            if (MD.norm(q.quest_giver) !== id) return;
            var s = QL.status(v, k), r = QL.rec(v, k);
            if (s === QL.COMPLETED) {
                var cdSec = q.repeat_cooldown_seconds || 0;
                if (r && r.at && now - r.at < 2500) {                          // just handed in (47_dmz_quests.js does it on interact)
                    if (MD.norm(q.turn_in) === id) turnedIn = true;
                    out.push({ k: k, s: "COMPLETED" });
                    return;
                }
                if (!q.repeatable) return;
                var left = r && r.at ? cdSec * 1000 - (now - r.at) : 0;
                if (left > 0) { out.push({ k: k, s: "COOLDOWN", ms: left, reason: ["gui.dragonminez.dialogue.quest.repeat_cooldown"] }); return; }
            }
            if (s === QL.ACCEPTED) { out.push({ k: k, s: "IN_PROGRESS" }); return; }
            if (QL.startable(e, v)) {
                var b = questGiverBlocker(p, e);
                out.push(b ? { k: k, s: "LOCKED", reason: b } : { k: k, s: "OFFER" });
                return;
            }
            if (q.secret) return;
            var fail = q.prerequisites ? QL.firstFailing(q.prerequisites, v, null) : null;
            if (!fail && !e.side && e.index > 0) fail = { type: "SAGA_QUEST", sagaId: e.saga.id, questId: e.saga.quests[e.index - 1].id };
            out.push({ k: k, s: "LOCKED", cond: fail || null });
        });
        return { list: out, turnedIn: turnedIn };
    }

    // ---- open the dialogue (MastersEntity.mobInteract) ------------------------------------
    function open(p, id, npc) {
        if (!created(p)) { msg(p, "gui.dragonminez.lines.generic.createcharacter", [], "#FFFFFF"); return; }
        var qs = quests(p, id);
        RPG.net.send(p, "dmz_npc_open", { npc: id, master: MD.isMaster(id), quests: qs.list, turnedIn: qs.turnedIn, st: state(p),
            entity: npc ? npc.uuid : "" });
    }
    function refresh(p, id) {
        var qs = quests(p, id);
        RPG.net.send(p, "dmz_npc_state", { npc: id, quests: qs.list, st: state(p) });
        if (typeof DMZ_SKILLS !== "undefined") DMZ_SKILLS.sendState(p);
    }

    RPG.on("npcInteract", (p, npc, npcId) => {
        var id = dmzIdOf(npcId);
        if (!handled(id)) return;
        if (npc && MD.isMaster(id)) npc.setImmovable(true);      // masters take no knockback (MastersEntity)
        open(p, id, npc);
        return false;                       // no engine dialogue/shop
    });

    // ---- services (NPCActionC2S.perform) ---------------------------------------------------
    // Each returns true (success) or false (failure; the screen shows the master's "failure" reply).
    function heal(p) {
        if (typeof owKnockedOut === "function" && owKnockedOut(p)) return false;     // BabaReviveService.isHealingBlocked
        p.health = p.maxHealth;
        p.setResource("ki", p.maxResource("ki"));
        p.setResource("stamina", p.maxResource("stamina"));
        return true;
    }

    function giveWeight(p, value, item) {
        if (!allow(p, "npc_weight", C.weightRateTicks)) return false;
        var max = Math.max(1, Math.floor(Number(CFG.maxWeightRequestable) || 1));
        var kg = Math.max(1, Math.min(max, Math.floor(Number(value) || 0)));
        p.giveStack({ id: item, count: 1, data: { WeightValue: kg }, lore: ["&7Weight: &f" + kg + " kg"] });
        return true;
    }

    function shadowDummy(p) {
        var master = nearestDmzNpc(p);
        var block = MD.masterBlocker(alignment(p), master);
        if (block) { msg(p, block[0], [block[1]]); return false; }
        if (master === "unknown") return false;
        if (!allow(p, "popo_spar", C.sparRateTicks)) return false;
        // discardPopoDummies: one shadow at a time
        p.nearby(C.dummyCleanupRange).forEach((e) => { if (e.hasTag("dmz_popo_spar") && e.hasTag("owner:" + p.uuid)) e.kill(); });
        var dummy = RPG.world.spawnMob(p.dimension, "shadow_dummy", p.x, p.y, p.z);
        if (!dummy) return false;
        // ShadowDummyEntity.copyStatsFromPlayer: a clone of your own power
        dummy.maxHealth = Math.max(20, p.maxHealth);
        dummy.health = dummy.maxHealth;
        dummy.addTag("dmz_popo_spar");
        dummy.addTag("owner:" + p.uuid);
        dummy.addTag("dmzq-owner-" + p.uuid);
        return true;
    }

    function geroConvert(p) {
        if (!geroEligible(p)) { p.tell("§cDr. Gero§r: Only certain races can undergo android conversion."); return false; }
        if (p.getVar("dmz_android", 0)) { p.tell("§cDr. Gero§r: You have already been converted to an android."); return false; }
        if (fused(p)) { msg(p, "message.dragonminez.fusion.action_blocked"); return false; }
        p.setVar("dmz_android", 1);
        var map = DMZ_SKILLS.levels(p), r = race(p);
        ["superforms", "legendaryforms"].forEach((s) => {
            delete map[s];
            // forget the forms those skills had taught (30_forms.js skills)
            Object.keys(DMZ_SKILLS_DATA.FORM_SKILL).forEach((k) => {
                var parts = k.split(".");
                if (parts[0] !== r) return;
                (DMZ_SKILLS_DATA.FORM_TREES[r] || []).forEach((g) => {
                    if (g[0] === parts[1] && g[1] === s && p.hasSkill(DMZ_SKILLS_DATA.FORM_SKILL[k])) p.forgetSkill(DMZ_SKILLS_DATA.FORM_SKILL[k]);
                });
            });
        });
        p.setVar("dmz_skills", map);
        DMZ_SKILLS.setLevel(p, "androidforms", 1);
        DMZ_SKILLS.ensureDefaults(p);
        p.refreshStats();
        return true;
    }

    function babidiMark(p) {
        if (p.getVar("dmz_majin", 0) || p.hasEffect("dmz_majin")) { p.tell("§5Babidi: §rYou already bear my mark, fool!"); return false; }
        if (alignment(p) >= 39) { p.tell("§5Babidi: §rYour heart is too pure for my mark. Begone!"); return false; }
        p.setVar("dmz_majin", 1);
        p.addEffect("dmz_majin", -1);
        p.setVar("dmz_alignment", 0);
        return true;
    }

    // StatsData.resetPlayerProgress(player, null, keepSkills = false, forceSaiyanTail = true) + Status.reset
    function dendeReset(p) {
        DMZ_DATA.STATS.forEach((k) => { var id = DMZ_DATA.STAT_IDS[k]; p.addStat(id, -p.allocated(id)); });
        p.setStatPoints(0);
        p.setTp(0);
        // quests, story resets
        p.setVar("dmz_quests", null);
        p.setVar("dmz_story_resets", 0);
        // skills and techniques (removeAllSkills + clearAllTechniques; as /rpgc resetall does)
        RPG.skills.list().forEach((s) => { try { if (p.hasSkill(s)) p.forgetSkill(s); } catch (err) { } });
        p.setVar("dmz_skills", {});
        p.setVar("dmz_potential", 0);
        if (typeof DMZ_TECH !== "undefined") DMZ_TECH.clearAll(p);      // Techniques.clearAllTechniques (41_dmz_techniques.js)
        p.setVar("dmz_android", 0);
        // data effects and cooldowns
        if (p.getVar("dmz_majin", 0)) { p.setVar("dmz_majin", 0); p.removeEffect("dmz_majin"); }
        ["dmz_mightfruit", "kami_bless"].forEach((e) => { if (p.hasEffect(e)) p.removeEffect(e); });
        if (typeof p.clearEffects === "function") p.clearEffects();          // every other effect too (DMZ's reset wipes them)
        p.setVar("dmz_cd", {});
        p.setVar("dmz_alignment", 100);
        if (tailRace(p)) p.setColor("tail", "1");
        p.refreshStats();
        p.health = p.maxHealth;
        if (typeof DMZ_SKILLS !== "undefined") DMZ_SKILLS.ensureDefaults(p);
        if (typeof DMZ_QUESTS !== "undefined") DMZ_QUESTS.sync(p);
        // Status.reset: the character has to be created again
        p.setVar("dmz_created", 0);
        RPG.schedule(10, () => RPG.net.send(p, "dmz_open_creator", {}));
        return true;
    }

    function perform(p, id, action, value) {
        var a = action;
        switch (id) {
            case "karin":
                if (a === 1) {
                    if (hasCd(p, MD.CD.KARIN_NIMBUS) || hasNimbus(p)) return false;
                    p.giveItem(alignment(p) > 50 ? "flying_nimbus" : "black_nimbus", 1);
                    setCd(p, MD.CD.KARIN_NIMBUS, -1);
                    return true;
                }
                if (a === 2) {
                    if (hasCd(p, MD.CD.SENZU_KARIN)) return false;
                    p.giveItem("senzu_bean", Math.max(1, Number(CFG.senzuGiftAmount) || 5));
                    setCd(p, MD.CD.SENZU_KARIN, Math.max(1, Number(CFG.senzuGiftCooldownTicks) || 18000));
                    return true;
                }
                return false;
            case "guru":
                if (a !== 1 || alignment(p) < MD.GURU_MIN || skill(p, "potentialunlock") !== MD.POTENTIAL_LEVEL) return false;
                DMZ_SKILLS.setLevel(p, "potentialunlock", 11);
                return true;
            case "dende":
                if (a === 1) return heal(p);
                if (a === 2) return dendeReset(p);
                if (a === 3) {
                    if (!tailRace(p)) return false;
                    p.setColor("tail", hasTail(p) ? "0" : "1");
                    return true;
                }
                if (a === 4) {
                    if (MD.band(alignment(p)) !== "GOOD" || hasCd(p, MD.CD.KAMI_BLESS)) return false;
                    p.addEffect("kami_bless", Math.max(1, Number(CFG.kamiBlessDurationSeconds) || 300) * 20);
                    setCd(p, MD.CD.KAMI_BLESS, Math.max(1, Number(CFG.kamiBlessCooldownSeconds) || 1800) * 20);
                    return true;
                }
                return false;
            case "enma":
                if (a !== 1 || !owReady() || !owCanEnmaReturn(p)) return false;
                owEnmaReturn(p);
                return true;
            case "baba": {
                if (a !== 1 || !owReady()) return false;
                var before = alive(p) || tempActive(p);
                var text = owBabaRevive(p);
                if (text) p.tell(text);
                return !before && (alive(p) || tempActive(p));
            }
            case "popo":
                return a === 1 && shadowDummy(p);
            case "gero":
                return a === 1 && geroConvert(p);
            case "piccolo":
                if (a === 1) return heal(p);
                if (a === 2) return giveWeight(p, value, "weight_piccolo_cape");
                return false;
            case "roshi": return a === 2 && giveWeight(p, value, "weight_turtle_shell");
            case "kingkai": return a === 2 && giveWeight(p, value, "workout_weights");
            case "babidi": return a === 1 && babidiMark(p);
            case "grandkai":
                if (a !== 1 || typeof owTeleportFromGrandKai !== "function") return false;
                owTeleportFromGrandKai(p);
                return true;
            case "otherworld_announcer":
                if (a !== 1 || typeof owTeleportBackToGrandKai !== "function") return false;
                owTeleportBackToGrandKai(p);
                return true;
        }
        return false;
    }

    // ---- Old Kai's challenge (UltimateChallenge, NPCActionC2S.grantOldKaiChallengeReward) ------
    function meetsOldKai(p) { return alignment(p) > 61 && skill(p, "potentialunlock") >= MD.POTENTIAL_LEVEL; }
    function grantOldKaiChallengeReward(p) {
        if (meetsOldKai(p)) {
            DMZ_SKILLS.setLevel(p, "ultimate", Math.max(1, skill(p, "ultimate")));
            p.tell("§6Elder Kai: §rYour hidden power has awakened! The Ultimate is yours.");
        }
        if (hasCd(p, MD.CD.OLDKAI_ZSWORD)) return;
        p.giveItem("z_sword", 1);
        setCd(p, MD.CD.OLDKAI_ZSWORD, -1);
    }

    // ---- network ----------------------------------------------------------------------------
    function reply(p, id, action, ok, reason) {
        RPG.net.send(p, "dmz_npc_result", { npc: id, action: action, ok: !!ok, reason: reason || null });
    }

    RPG.net.on("dmz_npc", (p, d) => {
        if (!d || !created(p)) return;
        var id = String(d.npc || ""), a = String(d.a || "");
        if (!MD.isMaster(id) && !MD.QUEST_NPCS[id]) return;
        if (a === "close") return;
        var spar = a === "action" && id === "popo" && Number(d.id) === 1;

        if (a === "action") {
            var actionId = Math.floor(Number(d.id) || 0), key = "npc_action_" + actionId;
            if (!allow(p, "npc_action", C.actionRateTicks)) return reply(p, id, key, false);
            if (spar ? npcsNear(p).length === 0 : !inRange(p, id)) return reply(p, id, key, false);
            if (OW_IDS.indexOf(id) >= 0 && !handled(id)) return reply(p, id, key, false);
            var ok = false;
            try { ok = perform(p, id, actionId, Math.floor(Number(d.v) || 0)); }
            catch (err) { RPG.log("DMZ master action " + id + "#" + actionId + " failed: " + err); ok = false; }
            reply(p, id, key, ok);
            refresh(p, id);
            return;
        }
        if (!inRange(p, id)) return;
        var block = MD.isMaster(id) ? MD.masterBlocker(alignment(p), id) : null;

        if (a === "state") return refresh(p, id);
        if (a === "buy") {                                       // MastersSkillsScreen -> UpdateSkillC2S.PURCHASE
            if (block || MD.isTextMaster(id)) return;
            var s = String(d.skill || "").toLowerCase();
            if (DMZ_SKILLS.purchase(p, s, id)) p.playSound("dmzpack:pip_menu", 1, 1);
            DMZ_SKILLS.sendState(p);
            refresh(p, id);
            return;
        }
        if (a === "quest_accept") {                              // QuestActionC2S START from the dialogue
            var k = String(d.key || ""), e = typeof DMZ_QL !== "undefined" ? DMZ_QL.entry(k) : null;
            var qkey = "quest_start_" + k;
            if (!e || MD.norm(e.quest.quest_giver) !== id || questGiverBlocker(p, e)) return reply(p, id, qkey, false);
            DMZ_QUESTS.start(p, k);
            reply(p, id, qkey, DMZ_QL.status(qview(p), k) === DMZ_QL.ACCEPTED);
            refresh(p, id);
            return;
        }
        if (a === "train_minigame") {                            // BaseMinigameScreen.create(minigame, MASTER)
            if (block) return;
            var game = String(d.game || "");
            if (MD.MINIGAMES[game] !== id) return;
            if (typeof DMZ_MINIGAMES !== "undefined" && DMZ_MINIGAMES && typeof DMZ_MINIGAMES.start === "function") DMZ_MINIGAMES.start(p, game, "MASTER", id);
            else msg(p, "gui.dragonminez.minigame.reject.unavailable");
            return;
        }
        if (a === "ultimate") {                                  // Old Kai: "Unleash Power"
            if (id !== "oldkai") return;
            if (alignment(p) < MD.OLDKAI_MIN || skill(p, "potentialunlock") < MD.POTENTIAL_LEVEL) return;
            if (typeof DMZ_MINIGAMES !== "undefined" && DMZ_MINIGAMES && typeof DMZ_MINIGAMES.startChallenge === "function") {
                DMZ_MINIGAMES.startChallenge(p, () => { grantOldKaiChallengeReward(p); });
            } else {
                // no minigames in this build: the challenge counts as cleared
                grantOldKaiChallengeReward(p);
                RPG.net.send(p, "dmz_npc_say", { npc: id, key: "gui.dragonminez.lines.oldkai.success" });
                refresh(p, id);
            }
            return;
        }
        if (a === "tournament") {                                // TournamentPackets OPEN_BRACKET
            var host = MD.TOURNAMENT_HOSTS[id];
            if (!host) return;
            if (typeof DMZ_TOURNAMENTS !== "undefined" && DMZ_TOURNAMENTS && typeof DMZ_TOURNAMENTS.openBracket === "function") DMZ_TOURNAMENTS.openBracket(p, host, id);
            else msg(p, "message.dragonminez.npc.unavailable");
            return;
        }
        if (a === "haircut") {                                   // Popo -> HairEditorScreen -> UpdateCustomHairC2S (style = DMZ preset id)
            if (id !== "popo" || p.dimension === HTC || !hairRace(p)) return;
            var looks = (DMZ_DATA.LOOKS[race(p)] || {}), style = String(d.style || ""), color = String(d.color || "");
            if (looks.hair && looks.hair.indexOf(style) >= 0) p.setColor("hairStyle", style);
            if (/^#?[0-9A-Fa-f]{6}$/.test(color) && looks.hairColor) p.setColor("hair", color.charAt(0) === "#" ? color : "#" + color);
            p.playSound("dmzpack:confirm_menu", 0.6, 1);
            refresh(p, id);
            return;
        }
    });

    // ---- the data effects ----------------------------------------------------------------
    RPG.effects.define("kami_bless", { name: "Kami's Blessing", color: "#F2E6A0", beneficial: true });
    RPG.effects.define("dmz_majin", { name: "&5Majin", color: "#8A2BE2", beneficial: true, keepOnDeath: true,
        onApply(player) { if (typeof dmzScaleMult === "function") dmzScaleMult(player, Number(CFG.majinPower) || 1.3); },
        onRemove(player) { if (typeof dmzScaleMult === "function") dmzScaleMult(player, 1 / (Number(CFG.majinPower) || 1.3)); } });

    // Kami's Blessing: TP x1.2 (PotionEffectHelper). 09_dmz_stats.js adds dmzOtherworldTpMult(p) - 1 to its TP
    // multiplier, so the blessing rides on that hook (60_otherworld.js defines it, this file loads after).
    (function () {
        var base = typeof dmzOtherworldTpMult === "function" ? dmzOtherworldTpMult : null;
        if (base && base.__kamiBless) return;
        var wrapped = function (p) {
            var m = base ? base(p) : 1;
            if (p && p.hasEffect && p.hasEffect("kami_bless")) m += (Number(CFG.kamiBlessTpMultiplier) || 1.2) - 1;
            return m;
        };
        wrapped.__kamiBless = true;
        dmzOtherworldTpMult = wrapped;
    })();

    // ---- ops: /rpgc dmzmaster <dmz id>  places a master where you stand ---------------------
    RPG.commands.register("dmzmaster", {
        permission: 2, description: "/rpgc dmzmaster <roshi|karin|kingkai|...> - place a DMZ master or story NPC here; /rpgc dmzmaster list",
        run(p, args) {
            if (!p) return;
            var id = String(args[0] || "").toLowerCase();
            if (!id || id === "list") { p.tell("&e" + Object.keys(MD.MASTERS).concat(Object.keys(MD.QUEST_NPCS)).join(", ")); return; }
            var npc = npcOf(id);
            if (!RPG.npcs.exists(npc)) { p.tell("&cUnknown master " + id); return; }
            var e = RPG.world.spawnNpc(p.dimension, npc, p.x, p.y, p.z);
            var yaw = (MD.MASTERS[id] || {}).yaw;
            if (e && yaw !== undefined) e.teleportTo(p.dimension, p.x, p.y, p.z, yaw, 0);
        }
    });

    return { open: open, refresh: refresh, state: state, quests: quests, perform: perform, alignment: alignment, cooldown: cd, setCooldown: setCd,
        grantOldKaiChallengeReward: grantOldKaiChallengeReward, meetsOldKai: meetsOldKai, dmzIdOf: dmzIdOf, npcOf: npcOf };
})();
