// =====================================================================================
//  08_character.js - DMZ character creation (server side)
// =====================================================================================
//  New players get DMZ's creator (client/scripts/20_creator.js): race carousel, then the
//  customization tabs. Pressing Confirm sends "dmz_create" here, which checks the picks
//  and creates the character the way DMZ's CreateCharacterC2S does.
// =====================================================================================
(function () {
    var COLOR_KEYS = ["body1", "body2", "body3", "hair", "eyes", "eye2", "aura"];
    var LOOK_OK = ["bodyType", "bodyModel", "eyeStyle", "nose", "mouth", "hairStyle", "tattoo"];
    var HEX = /^#?[0-9A-Fa-f]{6}$/;

    function created(p) { return !!p.getVar("dmz_created", 0); }

    function openCreator(p) { RPG.net.send(p, "dmz_open_creator", {}); }

    RPG.on("playerJoin", (p) => {
        if (!created(p)) RPG.schedule(30, () => { if (!created(p)) openCreator(p); });
    });

    RPG.net.on("dmz_create", (p, data) => {
        if (created(p) || !data) return;
        let race = String(data.race || ""), cls = String(data.cls || "warrior");
        if (RPG.races.list().indexOf(race) < 0) { openCreator(p); return; }       // unknown race: ask again
        if (!DMZ_DATA.CLASSES[cls]) cls = "warrior";
        p.race = race;
        p.playerClass = cls;
        let looks = data.looks || {}, defaults = DBR_RACE_DEFAULTS[race] || {};
        COLOR_KEYS.forEach((k) => { let v = String(looks[k] || defaults[k] || ""); if (HEX.test(v)) p.setColor(k, v.charAt(0) === "#" ? v : "#" + v); });
        LOOK_OK.forEach((k) => {
            let v = looks[k] !== undefined ? String(looks[k]) : defaults[k];
            if (v !== undefined && /^[a-z0-9_]{1,24}$/i.test(String(v))) p.setColor(k, String(v));
        });
        p.setVar("dmz_created", 1);
        p.setVar("dmz_release", 0);
        p.refreshStats();
        RPG.schedule(2, () => {
            ["ki", "stamina"].forEach((r) => p.setResource(r, p.maxResource(r)));
            p.health = p.maxHealth;
        });
        p.playSound("dmzpack:ui_menu_switch", 1, 1);
    });

    // the navigation row of DMZ's menu screens (stats, skills 46_dmz_skills.js, quests 47_dmz_quests.js)
    RPG.net.on("dmz_menu", (p, d) => {
        let tab = String(d && d.tab);
        if (tab === "stats") RPG.net.send(p, "dmz_open_stats", {});
        else if (tab === "skills") DMZ_SKILLS.open(p);
        else if (tab === "quests") DMZ_QUESTS.open(p);
        else if (tab === "config") p.openMenu("settings");
        else if (tab === "party" && typeof DMZ_PARTY !== "undefined") DMZ_PARTY.open(p);
        else p.actionbar("&7Coming soon");
    });

    // ops: /rpgc recreate <player> lets someone make their character again (DMZ: the Re-Customize wish)
    RPG.commands.register("recreate", {
        permission: 2, description: "/rpgc recreate [player] - open the character creator again",
        run(p, args) {
            let target = args[0] ? RPG.server.player(args[0]) : p;
            if (!target) return;
            target.setVar("dmz_created", 0);
            openCreator(target);
        }
    });
})();
