// =====================================================================================
//  58_dmz_machines.js - DragonMine Z's machines (GPL-3.0 port)
// =====================================================================================
//  Pattern Station     PatternStationMenu: 6x6 grid + result, 82 dye patterns (mirrored, any offset)
//  Kikono Station      KikonoStationBlockEntity: 9 inputs + pattern + template -> output, 2000 FE,
//                      200 t / 100 t per craft, 1000 FE per craft (ceil(1000 / time) per tick)
//  Fuel Generator      FuelGeneratorBlockEntity: furnace fuel -> +1 FE on 3 of every 4 burning ticks, 1000 FE
//  Energy Cable        EnergyCableBlockEntity: carries 15 FE/t from a generator to the machines it touches
//  Gravity Device      GravityDeviceBlockEntity + GravityDeviceManager: a closed room (5-25 blocks a side)
//                      gets the set gravity while the device has Star Energy (1 FE per gravity per second)
//  Gravity training    server/util/GravityLogic: world / King Kai / machine gravity, resistance from your
//                      stats, stat reduction, movement + attack speed penalty, TP bonus, weights' TP bell.
//
//  The machines are plain script blocks (13_dmz_blocks.js calls dmzMachineUse / dmzMachinePlaced /
//  dmzMachineBroken). Their state lives in RPG.data under "dmzm:<dimension>:<x>,<y>,<z>"; it is kept in
//  memory, ticked in 10 batches (each machine every 10 ticks, every tick while someone has its screen
//  open) and written back once a second. The screens are client screens (client/scripts/60_dmz_machines.js)
//  with DMZ's textures; every slot click is done here, the item on the mouse is kept in the player var
//  "dmzm_carried" (and the Pattern Station grid in "dmzm_grid") so nothing is lost on a crash or reload.
// =====================================================================================

var DMZ_MACHINES = (function () {
    let D = DMZ_MACH;
    // ragnarok_rpg/config/dbr_gravity.json (DMZ's GravityConfig), copied into plain JS values
    let GCFG = (function () {
        let raw = RPG.files.config("dbr_gravity", D.GRAVITY_DEFAULTS) || {}, out = {};
        Object.keys(D.GRAVITY_DEFAULTS).forEach((k) => {
            let def = D.GRAVITY_DEFAULTS[k], v = raw[k];
            if (v === undefined || v === null) out[k] = def;
            else if (typeof def === "boolean") out[k] = String(v) === "true";
            else if (typeof def === "number") { v = Number(v); out[k] = isFinite(v) ? v : def; }
            else if (Array.isArray(def)) { out[k] = []; for (let i = 0; i < v.length; i++) out[k].push(String(v[i])); }
            else { out[k] = {}; Object.keys(v).forEach((d) => { let n = Number(v[d]); if (isFinite(n)) out[k][String(d)] = n; }); }
        });
        return out;
    })();
    let STORED = { kikono_station: true, fuel_generator: true, gravity_device: true };
    let CONSUMER = { kikono_station: true, gravity_device: true };
    let PREFIX = "dmzm:";
    let DIRS = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];

    let M = {};          // key -> saved state
    let RT = {};         // key -> runtime (not saved)
    let KEYS = [];       // every machine key
    let DIRTY = {};
    let SESS = {};       // player uuid -> open screen
    let VIEW = {};       // machine key -> { uuid: true }
    let ZONES = {};      // gravity device key -> running zone
    let ONLINE = {};     // uuid -> JsPlayer (refreshed every 10 ticks)
    let NET_EPOCH = 0;   // bumped when a cable or machine is placed / broken
    let TICK = 0;

    function now() { return RPG.server.getTick(); }
    function key(dim, x, y, z) { return PREFIX + dim + ":" + x + "," + y + "," + z; }
    function blockId(name) { return blockRef(name); }
    function nameAt(dim, x, y, z) { return dmzBlockAt(dim, x, y, z); }
    function hash(s) { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); }
    function num(v, d) { v = Number(v); return isFinite(v) ? v : d; }

    // ---- item ids and stacks ------------------------------------------------------------
    let RESOLVED = {};
    function resolve(name) {
        if (name.indexOf(":") >= 0) return name;
        if (RESOLVED[name]) return RESOLVED[name];
        let id = RPG.items.id(name) || BLOCK_IDS[name];
        return (RESOLVED[name] = id ? "ragnarok_rpg:" + id : "ragnarok_rpg:missing_" + name);
    }
    let MAXSTACK = {};
    let ONE = /^minecraft:(.*_bucket|potion|splash_potion|lingering_potion|.*_boat|.*_chest_boat|minecart|.*_minecart|saddle|cake|.*_bed|enchanted_book|written_book|writable_book|totem_of_undying|music_disc_.*|.*_banner_pattern|bundle|goat_horn|suspicious_stew|.*_soup|.*_pottery_sherd|filled_map)$/;
    let SIXTEEN = /^minecraft:(ender_pearl|snowball|egg|bucket|armor_stand|honey_bottle|.*_sign|.*_hanging_sign|.*_banner)$/;
    function maxStack(s) {
        if (!s) return 64;
        if (s.maxDamage > 0) return 1;
        let id = s.id;
        if (MAXSTACK[id] !== undefined) return MAXSTACK[id];
        let m = 64;
        if (id.indexOf("ragnarok_rpg:") === 0) {
            let ref = DMZ_ITEM_BY_REF[id], spec = null;
            if (ref && typeof DMZ_ITEM_SPECS !== "undefined") for (let i = 0; i < DMZ_ITEM_SPECS.length; i++) if (DMZ_ITEM_SPECS[i].id === ref) { spec = DMZ_ITEM_SPECS[i]; break; }
            if (spec) m = spec.stack || 64;
            else { try { let d = RPG.items.get(id.substring(13)); if (d && d.maxStack) m = d.maxStack; } catch (e) { } }
        } else if (ONE.test(id) && id !== "minecraft:bucket") m = 1;
        else if (SIXTEEN.test(id)) m = 16;
        return (MAXSTACK[id] = Math.max(1, Math.min(64, m)));
    }
    /** A plain copy of a stack (engine stacks can be Java maps). */
    function cp(s, count) {
        if (!s || !s.id || String(s.id) === "minecraft:air") return null;
        let o = { id: String(s.id), count: count === undefined ? Math.floor(num(s.count, 1)) : count };
        if (s.nbt) o.nbt = String(s.nbt);
        if (s.name) o.name = String(s.name);
        if (s.maxDamage) { o.maxDamage = num(s.maxDamage, 0); o.damage = num(s.damage, 0); }
        return o.count > 0 ? o : null;
    }
    function same(a, b) { return !!a && !!b && a.id === b.id && (a.nbt || "") === (b.nbt || ""); }
    function forWorld(s) { return s ? (s.nbt ? { id: s.id, count: s.count, nbt: s.nbt } : { id: s.id, count: s.count }) : null; }
    let NAMES = {};
    function itemName(id) { return NAMES[id] || (NAMES[id] = String(RPG.items.name(id))); }
    function roman(n) { return ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"][n] || String(n); }
    function view(s) {
        if (!s) return null;
        let t = [s.name ? "&o" + s.name : itemName(s.id)];
        if (s.nbt) {
            let re = /id:"(?:minecraft:)?([a-z_]+)",lvl:(\d+)s/g, m;
            while ((m = re.exec(s.nbt))) t.push("&7" + m[1].split("_").map((w) => w.charAt(0).toUpperCase() + w.substring(1)).join(" ") + " " + roman(Number(m[2])));
        }
        if (s.maxDamage) t.push("&7Durability: " + (s.maxDamage - (s.damage || 0)) + " / " + s.maxDamage);
        return { i: s.id, c: s.count, t: t };
    }
    /** Drop a stack in the world, keeping its NBT (RPG.world.dropItem has none). */
    function drop(dim, x, y, z, s) {
        if (!s) return;
        if (!s.nbt) { RPG.world.dropItem(dim, x + 0.5, y + 0.5, z + 0.5, s.id, s.count); return; }
        RPG.server.runCommand("execute in " + dim + " run summon minecraft:item " + (x + 0.5) + " " + (y + 0.5) + " " + (z + 0.5) +
            " {Item:{id:\"" + s.id + "\",Count:" + s.count + "b,tag:" + s.nbt + "}}");
    }
    /** The "Enchantments:[...]" part of an SNBT compound, or null. */
    function enchantmentsOf(nbt) {
        if (!nbt) return null;
        let i = nbt.indexOf("Enchantments:[");
        if (i < 0) return null;
        let depth = 0, q = false;
        for (let j = i + 13; j < nbt.length; j++) {
            let c = nbt.charAt(j);
            if (q) { if (c === "\\") j++; else if (c === "\"") q = false; continue; }
            if (c === "\"") q = true;
            else if (c === "[" || c === "{") depth++;
            else if (c === "]" || c === "}") { depth--; if (depth === 0) return nbt.substring(i, j + 1); }
        }
        return null;
    }

    // ---- machine state ---------------------------------------------------------------------
    function fresh(type, dim, x, y, z) {
        let m = { t: type, d: dim, x: x, y: y, z: z, e: 0 };
        if (type === "kikono_station") { m.it = []; for (let i = 0; i < 12; i++) m.it.push(null); m.prog = 0; m.maxProg = 0; }
        if (type === "fuel_generator") { m.it = [null]; m.burn = 0; m.maxBurn = 0; }
        if (type === "gravity_device") { m.active = false; m.g = 10; m.valid = false; m.running = false; m.rmin = [x, y, z]; m.rmax = [x, y, z]; }
        return m;
    }
    function rtOf(k) {
        return RT[k] || (RT[k] = { last: now(), bucket: hash(k) % 10, ver: 0, sentVer: -1, sent: "", acc: 0, room: null, roomAt: -1e9, roomDirty: false, net: null });
    }
    function add(k, m) {
        if (!M[k]) KEYS.push(k);
        M[k] = m;
        rtOf(k);
        save(k);
    }
    function remove(k) {
        delete M[k]; delete RT[k]; delete DIRTY[k]; delete ZONES[k];
        let i = KEYS.indexOf(k);
        if (i >= 0) KEYS.splice(i, 1);
        RPG.data.remove(k);
    }
    function save(k) { if (M[k]) RPG.data.set(k, M[k]); delete DIRTY[k]; }
    function touch(k) { DIRTY[k] = true; }
    function itemsChanged(k) { rtOf(k).ver++; save(k); }
    function get(name, dim, x, y, z) {
        let k = key(dim, x, y, z);
        if (!M[k] && STORED[name]) add(k, fresh(name, dim, x, y, z));
        return k;
    }

    // ---- Kikono recipes and Pattern recipes (resolved on first use) ----------------------------
    let KIK = null, PAT = null;
    function kikRecipes() {
        if (KIK) return KIK;
        KIK = {};
        D.kikonoRecipes(resolve).forEach((r) => { let k = r.pattern + "|" + r.template; (KIK[k] || (KIK[k] = [])).push(r); });
        return KIK;
    }
    function patRecipes() { return PAT || (PAT = D.patternRecipes(resolve)); }
    function kikMatch(it) {
        if (!it[9] || !it[10]) return null;
        let list = kikRecipes()[it[9].id + "|" + it[10].id];
        if (!list) return null;
        for (let r = 0; r < list.length; r++) {
            let ok = true;
            for (let i = 0; i < 9 && ok; i++) ok = (it[i] ? it[i].id : "") === list[r].inputs[i];
            if (ok) return list[r];
        }
        return null;
    }
    function kikResult(m, rec) {
        let out = { id: rec.result, count: 1 };
        let ench = enchantmentsOf(m.it[10] && m.it[10].nbt);          // crafting.copyEnchantmentsFromTemplate (default on)
        if (ench) out.nbt = "{" + ench + "}";
        return out;
    }
    function kikCanOutput(m, out) {
        let o = m.it[11];
        // DMZ only compares the item; its insert then fails on different NBT and the item is lost, so NBT counts here
        return !o || (same(o, out) && o.count + out.count <= maxStack(o));
    }

    // ---- energy network: generator -> touching machines, or through cables -----------------------
    function network(k, m) {
        let rt = rtOf(k), t = now();
        if (rt.net && rt.net.epoch === NET_EPOCH && t - rt.net.at < 200) return rt.net.list;
        let cable = blockId("energy_cable"), kik = blockId("kikono_station"), grav = blockId("gravity_device"), list = [], seen = {}, visited = {}, queue = [], loadedChunks = {};
        function loaded(x, z) {
            let ck = (x >> 4) + "," + (z >> 4);
            if (loadedChunks[ck] === undefined) loadedChunks[ck] = !!RPG.world.isLoaded(m.d, x, z);
            return loadedChunks[ck];
        }
        function found(nk, via) {
            if (!seen[nk]) { seen[nk] = { key: nk, via: via }; list.push(seen[nk]); }
            else if (!via) seen[nk].via = false;
        }
        function look(x, y, z, via) {
            let nk = key(m.d, x, y, z);
            if (M[nk]) { if (CONSUMER[M[nk].t]) found(nk, via); return; }
            let ck = x + "," + y + "," + z;
            if (visited[ck] || queue.length > 512 || !loaded(x, z)) return;
            visited[ck] = true;
            let id = RPG.world.getBlock(m.d, x, y, z);
            if (id === cable) queue.push([x, y, z]);
            else if (id === kik || id === grav) {                  // a machine placed before this script knew it
                add(nk, fresh(id === kik ? "kikono_station" : "gravity_device", m.d, x, y, z));
                found(nk, via);
            }
        }
        DIRS.forEach((dv) => look(m.x + dv[0], m.y + dv[1], m.z + dv[2], false));
        for (let qi = 0; qi < queue.length; qi++) {
            let c = queue[qi];
            DIRS.forEach((dv) => look(c[0] + dv[0], c[1] + dv[1], c[2] + dv[2], true));
        }
        rt.net = { epoch: NET_EPOCH, at: t, list: list };
        return list;
    }
    function receiveCap(t) { return t.t === "kikono_station" ? D.KIKONO.receive : D.GRAVITY_RECEIVE; }
    function capacity(t) { return t.t === "kikono_station" ? D.KIKONO.capacity : t.t === "fuel_generator" ? D.GEN.capacity : num(GCFG.deviceEnergyCapacity, 20000); }
    function distribute(k, m, dt) {
        if (m.e <= 0) return;
        let list = network(k, m);
        if (!list.length) return;
        let rt = rtOf(k), start = (rt.rr = ((rt.rr || 0) + 1) % list.length);
        for (let n = 0; n < list.length && m.e > 0; n++) {
            let entry = list[(start + n) % list.length], t = M[entry.key];
            if (!t) continue;
            let cap = (entry.via ? D.CABLE.transfer : Math.min(D.GEN.transfer, receiveCap(t))) * dt;
            let give = Math.min(m.e, cap, capacity(t) - t.e);
            if (give <= 0) continue;
            t.e += give; m.e -= give;
            touch(entry.key);
        }
    }

    // ---- per-machine ticks ------------------------------------------------------------------
    function tickGenerator(k, m, dt) {
        let it = m.it, changed = false;
        for (let i = 0; i < dt; i++) {
            if (m.burn > 0) {
                m.burn--;
                if (m.burn % 4 !== 0) m.e = Math.min(m.e + 1, D.GEN.capacity);   // triple speed: +1 on 3 of every 4 ticks
            }
            if (m.burn <= 0 && m.e < D.GEN.capacity && it[0]) {
                let bt = D.burnTime(it[0].id);
                if (bt > 0) {
                    m.burn = bt; m.maxBurn = bt;
                    let fuelId = it[0].id;
                    it[0].count--;
                    if (it[0].count <= 0) { let rem = D.fuelRemainder(fuelId); it[0] = rem ? { id: rem, count: 1 } : null; }
                    changed = true;
                }
            }
        }
        distribute(k, m, dt);
        touch(k);
        if (changed) itemsChanged(k);
        // FuelGeneratorBlock.animateTick while LIT: the furnace crackle now and then, a little smoke
        if (m.burn > 0 && Math.random() < 0.1 * dt / 10) {
            RPG.world.sound(m.d, "minecraft:block.furnace.fire_crackle", m.x + 0.5, m.y, m.z + 0.5, 1, 1);
            RPG.world.particle(m.d, "minecraft:smoke", m.x + 0.5, m.y + 1.0, m.z + 0.5, 2, 0.2, 0.01);
        }
    }
    function tickKikono(k, m, dt) {
        let rec = kikMatch(m.it), changed = false;
        for (let i = 0; i < dt; i++) {
            let out = rec ? kikResult(m, rec) : null;
            if (rec && kikCanOutput(m, out)) {
                m.maxProg = rec.time;
                let cost = rec.energy > 0 && m.maxProg > 0 ? Math.ceil(rec.energy / m.maxProg) : 0;
                if (m.e >= cost) {
                    m.e -= cost;
                    m.prog++;
                    if (m.prog >= m.maxProg) {
                        RPG.world.sound(m.d, "minecraft:block.anvil.use", m.x + 0.5, m.y + 0.5, m.z + 0.5, 1, 1);
                        for (let s = 0; s <= 10; s++) if (m.it[s]) { m.it[s].count--; if (m.it[s].count <= 0) m.it[s] = null; }
                        if (m.it[11]) m.it[11].count += out.count; else m.it[11] = out;
                        m.prog = 0;
                        changed = true;
                        rec = kikMatch(m.it);
                    }
                } else if (m.prog > 0) m.prog--;
            } else { m.prog = 0; break; }
        }
        touch(k);
        if (changed) itemsChanged(k);
    }

    // Gravity Device room: a flood fill from the device through blocks with no collision, at most
    // deviceMaxRoomSize away, done 400 block lookups per tick (1000 while its screen is open) (DMZ does it in one go every 100 ticks).
    let AIR = { "minecraft:air": 1, "minecraft:cave_air": 1, "minecraft:void_air": 1 };
    let OPEN = /^minecraft:(water|lava|light|structure_void|fire|soul_fire|cobweb|tripwire|tripwire_hook|redstone_wire|nether_portal|end_portal|end_gateway|lever|rail|powered_rail|detector_rail|activator_rail|grass|tall_grass|fern|large_fern|dead_bush|dandelion|poppy|blue_orchid|allium|azure_bluet|oxeye_daisy|cornflower|lily_of_the_valley|wither_rose|sunflower|lilac|rose_bush|peony|torchflower|pitcher_plant|.*_tulip|sugar_cane|wheat|carrots|potatoes|beetroots|melon_stem|pumpkin_stem|attached_melon_stem|attached_pumpkin_stem|torchflower_crop|pitcher_crop|sweet_berry_bush|vine|glow_lichen|sculk_vein|seagrass|tall_seagrass|kelp|kelp_plant|nether_wart|crimson_roots|warped_roots|nether_sprouts|weeping_vines|weeping_vines_plant|twisting_vines|twisting_vines_plant|cave_vines|cave_vines_plant|hanging_roots|spore_blossom|small_dripleaf|big_dripleaf_stem|brown_mushroom|red_mushroom|crimson_fungus|warped_fungus|.*_sapling|mangrove_propagule|.*_torch|.*_wall_torch|torch|.*_sign|.*_wall_sign|.*_hanging_sign|.*_wall_hanging_sign|.*_banner|.*_wall_banner|.*_button|.*_pressure_plate|.*_coral|.*_coral_fan|.*_coral_wall_fan|redstone_torch|redstone_wall_torch|soul_torch|soul_wall_torch|frogspawn|pink_petals)$/;
    let PASS_CACHE = {};
    function passableId(id, dim, x, y, z) {
        if (AIR[id]) return true;
        let c = PASS_CACHE[id];
        if (c === undefined) {
            if (id === "minecraft:snow") c = "snow";
            else if (OPEN.test(id)) c = true;
            else {
                let n = DMZ_BLOCK_BY_REF[id], s = n && DMZ_BLOCK[n];
                c = !!(s && s.collision === false);
            }
            PASS_CACHE[id] = c;
        }
        if (c === "snow") return /layers=1\b/.test(String(RPG.world.getBlockState(dim, x, y, z)));
        return c;
    }
    function roomStart(k, m) {
        let max = Math.floor(num(GCFG.deviceMaxRoomSize, 25)), side = 2 * max + 1;
        rtOf(k).room = { max: max, side: side, state: [], queue: [], qi: 0, invalid: false,
            minX: m.x, minY: m.y, minZ: m.z, maxX: m.x, maxY: m.y, maxZ: m.z, chunks: {}, seeded: false };
        rtOf(k).roomAt = now();
    }
    /** Run the flood fill for up to `budget` block lookups; true when it finished. */
    function roomStep(k, m, budget) {
        let R = rtOf(k).room, max = R.max, side = R.side, dev = blockId("gravity_device");
        function idx(x, y, z) { return ((x - m.x + max) * side + (y - m.y + max)) * side + (z - m.z + max); }
        function inside(x, y, z) { return Math.abs(x - m.x) <= max && Math.abs(y - m.y) <= max && Math.abs(z - m.z) <= max; }
        function pass(x, y, z) {
            if (x === m.x && y === m.y && z === m.z) return false;
            let ck = (x >> 4) + "," + (z >> 4);
            if (R.chunks[ck] === undefined) R.chunks[ck] = !!RPG.world.isLoaded(m.d, x, z);
            if (!R.chunks[ck]) return false;                       // not loaded: a wall (DMZ would load it)
            budget--;
            let id = RPG.world.getBlock(m.d, x, y, z);
            if (id === dev) return false;
            return passableId(id, m.d, x, y, z);
        }
        function visit(x, y, z) {
            if (!inside(x, y, z)) { if (pass(x, y, z)) R.invalid = true; return; }
            let i = idx(x, y, z);
            if (R.state[i] !== undefined) return;
            let p = pass(x, y, z);
            R.state[i] = p ? 1 : 2;
            if (p) R.queue.push(x, y, z);
        }
        if (!R.seeded) { R.seeded = true; DIRS.forEach((dv) => visit(m.x + dv[0], m.y + dv[1], m.z + dv[2])); }
        while (!R.invalid && R.qi < R.queue.length && budget > 0) {
            let x = R.queue[R.qi], y = R.queue[R.qi + 1], z = R.queue[R.qi + 2];
            R.qi += 3;
            if (x < R.minX) R.minX = x; if (y < R.minY) R.minY = y; if (z < R.minZ) R.minZ = z;
            if (x > R.maxX) R.maxX = x; if (y > R.maxY) R.maxY = y; if (z > R.maxZ) R.maxZ = z;
            for (let d = 0; d < 6 && !R.invalid; d++) visit(x + DIRS[d][0], y + DIRS[d][1], z + DIRS[d][2]);
        }
        if (!R.invalid && R.qi < R.queue.length) return false;
        // done: DMZ's size rule
        let minS = num(GCFG.deviceMinRoomSize, 5), maxS = num(GCFG.deviceMaxRoomSize, 25);
        let dx = R.maxX - R.minX + 1, dy = R.maxY - R.minY + 1, dz = R.maxZ - R.minZ + 1;
        let valid = !R.invalid && R.queue.length > 0 && dx >= minS && dy >= minS && dz >= minS && dx <= maxS && dy <= maxS && dz <= maxS;
        if (valid) { m.rmin = [R.minX, R.minY, R.minZ]; m.rmax = [R.maxX, R.maxY, R.maxZ]; }
        if (valid !== m.valid) rtOf(k).ver++;
        m.valid = valid;
        rtOf(k).room = null;
        save(k);
        return true;
    }
    function tickGravity(k, m, dt) {
        let rt = rtOf(k), t = now();
        if (rt.room) roomStep(k, m, VIEW[k] ? 1000 : 400);
        else if (rt.roomDirty && t - rt.roomAt >= 10) { rt.roomDirty = false; roomStart(k, m); roomStep(k, m, 1000); }
        else if (m.active && t - rt.roomAt >= 100) { roomStart(k, m); roomStep(k, m, 400); }
        let running = false;
        if (m.active) {
            if (m.valid) {
                let perTick = num(GCFG.deviceEnergyPerGravityPerSecond, 1) * m.g / 20;
                rt.acc = Math.min(rt.acc + perTick * dt, perTick * dt + 1);     // DMZ's accumulator, kept from running away
                let use = Math.floor(rt.acc);
                if (use > 0) {
                    if (m.e >= use) { m.e -= use; rt.acc -= use; running = true; }
                } else running = m.e > 0;
            }
        } else rt.acc = 0;
        if (running && GCFG.machineGravityEnabled) {
            ZONES[k] = { d: m.d, x0: m.rmin[0], y0: m.rmin[1], z0: m.rmin[2], x1: m.rmax[0] + 1, y1: m.rmax[1] + 1, z1: m.rmax[2] + 1, g: m.g };
        } else delete ZONES[k];
        if (running !== m.running) { m.running = running; rt.ver++; save(k); }
        touch(k);
    }

    // ---- the batch ticker ----------------------------------------------------------------------
    function stillThere(m) { return nameAt(m.d, m.x, m.y, m.z) === m.t; }
    function dropContents(m) {
        (m.it || []).forEach((s) => drop(m.d, m.x, m.y, m.z, s));
    }
    function process(k) {
        let m = M[k], rt = rtOf(k), t = now();
        if (!m) return;
        if (!RPG.world.isLoaded(m.d, m.x, m.z)) { rt.last = t; delete ZONES[k]; return; }
        if (!stillThere(m)) {                                   // gone without onBreak (explosion, piston, command)
            closeViewers(k);
            dropContents(m);
            remove(k);
            NET_EPOCH++;
            return;
        }
        let dt = Math.max(1, Math.min(20, t - rt.last));
        rt.last = t;
        if (m.t === "fuel_generator") tickGenerator(k, m, dt);
        else if (m.t === "kikono_station") tickKikono(k, m, dt);
        else if (m.t === "gravity_device") tickGravity(k, m, dt);
    }
    RPG.every(1, () => {
        TICK++;
        let b = TICK % 10;
        for (let i = 0; i < KEYS.length; i++) {
            let k = KEYS[i], rt = rtOf(k);
            if (rt.bucket === b || VIEW[k]) process(k);
        }
        if (TICK % 2 === 0) pushViewers();
        if (TICK % 10 === 0) { refreshOnline(); checkSessions(); }
        if (TICK % 20 === 0) Object.keys(DIRTY).forEach(save);
    });

    // ---- screens ---------------------------------------------------------------------------------
    function refreshOnline() {
        ONLINE = {};
        RPG.server.players().forEach((p) => { ONLINE[p.uuid] = p; });
    }
    function playerOf(uuid) { return ONLINE[uuid] || null; }
    function machineSlots(sess) {
        if (sess.type === "kikono_station") return 12;
        if (sess.type === "fuel_generator") return 1;
        if (sess.type === "pattern_station") return 37;
        return 0;
    }
    function getSlot(sess, p, sid) {
        let i = Number(sid.substring(1));
        if (sid.charAt(0) === "p") return cp(p.getStack(i));
        if (sess.type === "pattern_station") return i === 0 ? sess.result : sess.grid[i - 1];
        let m = M[sess.key];
        return m && m.it ? m.it[i] : null;
    }
    /** Set a slot; returns how many actually went in (the engine clamps player stacks to their real max). */
    function setSlot(sess, p, sid, s) {
        let i = Number(sid.substring(1));
        if (s && s.count <= 0) s = null;
        if (sid.charAt(0) === "p") {
            p.setStack(i, forWorld(s));
            if (!s) return 0;
            let back = cp(p.getStack(i));
            if (back) { back.name = s.name; back.maxDamage = s.maxDamage; back.damage = s.damage; }
            return back ? back.count : 0;
        }
        if (sess.type === "pattern_station") {
            if (i === 0) return 0;
            sess.grid[i - 1] = s;
            patternChanged(sess, p);
            return s ? s.count : 0;
        }
        let m = M[sess.key];
        if (!m) return 0;
        m.it[i] = s;
        itemsChanged(sess.key);
        return s ? s.count : 0;
    }
    function canPlace(sess, sid, s) {
        if (sid.charAt(0) === "p") return true;
        if (sess.type === "fuel_generator") return D.burnTime(s.id) > 0;
        if (sess.type === "kikono_station") return sid !== "m11";
        if (sess.type === "pattern_station") return sid !== "m0";
        return false;
    }
    function patternChanged(sess, p) {
        let ids = sess.grid.map((s) => s ? s.id : "");
        let rec = D.matchPattern(ids, patRecipes());
        sess.result = rec ? { id: rec.result, count: 1 } : null;
        p.setVar("dmzm_grid", sess.grid.filter((s) => !!s).length ? sess.grid : null);
    }
    function setCarried(sess, p, s) {
        sess.carried = s && s.count > 0 ? s : null;
        p.setVar("dmzm_carried", sess.carried);
    }
    function invView(p) { let out = []; for (let i = 0; i < 36; i++) out.push(view(cp(p.getStack(i)))); return out; }
    function invSig(p) {
        let s = "";
        for (let i = 0; i < 36; i++) { let st = p.getStack(i); s += st ? st.id + "*" + st.count + "*" + (st.nbt ? String(st.nbt).length : 0) + ";" : ";"; }
        return s;
    }
    function machineView(sess, p) {
        let out = {}, n = machineSlots(sess);
        for (let i = 0; i < n; i++) out["m" + i] = view(getSlot(sess, p, "m" + i));
        return out;
    }
    function dataView(sess) {
        let m = M[sess.key];
        if (!m) return {};
        if (m.t === "fuel_generator") return { e: m.e, max: D.GEN.capacity, burn: m.burn, maxBurn: m.maxBurn };
        if (m.t === "kikono_station") return { e: m.e, max: D.KIKONO.capacity, prog: m.prog, maxProg: m.maxProg };
        if (m.t === "gravity_device") return { e: m.e, max: num(GCFG.deviceEnergyCapacity, 20000), active: m.active, g: m.g, valid: m.valid, running: m.running, maxG: num(GCFG.deviceMaxGravity, 1000) };
        return {};
    }
    function sendFull(sess, p) {
        sess.invSig = invSig(p);
        RPG.net.send(p, "dmzm_state", { key: sess.key, slots: machineView(sess, p), inv: invView(p), carried: view(sess.carried), data: dataView(sess) });
    }
    function open(name, p, x, y, z) {
        close(p, false);
        let dim = p.dimension, k = STORED[name] ? get(name, dim, x, y, z) : key(dim, x, y, z) + "#" + p.uuid;
        let sess = { type: name, key: k, d: dim, x: x, y: y, z: z, carried: null, grid: null, result: null };
        if (name === "pattern_station") { sess.grid = []; for (let i = 0; i < 36; i++) sess.grid.push(null); }
        SESS[p.uuid] = sess;
        ONLINE[p.uuid] = p;
        if (STORED[name]) (VIEW[k] || (VIEW[k] = {}))[p.uuid] = true;
        if (name === "gravity_device") { roomStart(k, M[k]); roomStep(k, M[k], 2000); }   // GravityDeviceBlock.use: refreshRoom()
        let m = M[k];
        RPG.net.send(p, "dmzm_open", { type: name, key: k, slots: machineView(sess, p), inv: invView(p), carried: null, data: dataView(sess) });
        sess.invSig = invSig(p);
        if (m) { rtOf(k).sent = ""; }
    }
    /** Close a screen: the item on the mouse and the Pattern Station grid go back to the player. */
    function close(p, tellClient) {
        let sess = SESS[p.uuid];
        if (!sess) return;
        delete SESS[p.uuid];
        if (VIEW[sess.key]) { delete VIEW[sess.key][p.uuid]; if (!Object.keys(VIEW[sess.key]).length) delete VIEW[sess.key]; }
        if (sess.carried) p.giveStack(forWorld(sess.carried));
        if (sess.grid) sess.grid.forEach((s) => { if (s) p.giveStack(forWorld(s)); });
        p.setVar("dmzm_carried", null);
        p.setVar("dmzm_grid", null);
        if (tellClient) RPG.net.send(p, "dmzm_close", {});
    }
    function closeViewers(k) {
        if (!VIEW[k]) return;
        Object.keys(VIEW[k]).forEach((u) => { let p = playerOf(u); if (p) close(p, true); });
        delete VIEW[k];
    }
    // AbstractContainerMenu.stillValid: within 8 blocks of the block, and it's still there
    function checkSessions() {
        Object.keys(SESS).forEach((u) => {
            let sess = SESS[u], p = playerOf(u);
            if (!p) { delete SESS[u]; return; }
            let dx = p.x - sess.x - 0.5, dy = p.y - sess.y - 0.5, dz = p.z - sess.z - 0.5;
            if (p.dimension !== sess.d || dx * dx + dy * dy + dz * dz > 64 || nameAt(sess.d, sess.x, sess.y, sess.z) !== sess.type) { close(p, true); return; }
            let sig = invSig(p);
            if (sig !== sess.invSig) { sess.invSig = sig; RPG.net.send(p, "dmzm_state", { key: sess.key, inv: invView(p) }); }
        });
    }
    function pushViewers() {
        Object.keys(VIEW).forEach((k) => {
            let rt = rtOf(k), viewers = Object.keys(VIEW[k]), msg = null;
            viewers.forEach((u) => {
                let p = playerOf(u), sess = SESS[u];
                if (!p || !sess) return;
                if (!msg) {
                    let data = dataView(sess), js = JSON.stringify(data);
                    msg = { key: k };
                    if (js !== rt.sent) { msg.data = data; rt.sent = js; }
                    if (rt.ver !== rt.sentVer) { msg.slots = machineView(sess, p); rt.sentVer = rt.ver; }
                }
                if (msg.data || msg.slots) RPG.net.send(p, "dmzm_state", msg);
            });
        });
    }

    // ---- slot clicks (AbstractContainerMenu.doClick: pickup, place, swap, half, one, quick move) ----
    function playerOrder(reverse) {
        let out = [];
        for (let i = 9; i < 36; i++) out.push("p" + i);
        for (let i = 0; i < 9; i++) out.push("p" + i);
        return reverse ? out.reverse() : out;
    }
    /** moveItemStackTo: top up matching stacks, then fill empty slots. Returns what is left. */
    function moveTo(sess, p, s, targets) {
        let max = maxStack(s);
        if (max > 1) targets.forEach((t) => {
            if (!s || s.count <= 0) return;
            let cur = getSlot(sess, p, t);
            if (!cur || !same(cur, s) || !canPlace(sess, t, s)) return;
            let room = maxStack(cur) - cur.count;
            if (room <= 0) return;
            let n = Math.min(room, s.count), want = cur.count + n;
            let got = setSlot(sess, p, t, cp(cur, want));
            s.count -= Math.max(0, got - cur.count);
        });
        targets.forEach((t) => {
            if (!s || s.count <= 0) return;
            if (getSlot(sess, p, t) || !canPlace(sess, t, s)) return;
            let n = Math.min(max, s.count);
            let got = setSlot(sess, p, t, cp(s, n));
            s.count -= got;
        });
        return s && s.count > 0 ? s : null;
    }
    function quickMove(sess, p, sid) {
        let src = getSlot(sess, p, sid);
        if (!src) return;
        let fromPlayer = sid.charAt(0) === "p", targets = null, t = sess.type, idx = Number(sid.substring(1));
        if (t === "gravity_device") return;                               // GravityDeviceMenu.quickMoveStack: nothing
        if (t === "pattern_station" && sid === "m0") { craftPatternsToInventory(sess, p); return; }
        if (fromPlayer) {
            if (t === "fuel_generator") targets = ["m0"];
            else if (t === "kikono_station") targets = ["m0", "m1", "m2", "m3", "m4", "m5", "m6", "m7", "m8", "m9", "m10"];
            else if (t === "pattern_station") {
                targets = [];
                for (let i = 1; i <= 36; i++) targets.push("m" + i);
                let left = moveTo(sess, p, cp(src), targets);
                if (left && left.count === src.count) {               // grid full: main inventory <-> hotbar
                    let other = idx >= 9 ? playerOrder(false).slice(27) : playerOrder(false).slice(0, 27);
                    left = moveTo(sess, p, left, other);
                }
                setSlot(sess, p, sid, left);
                return;
            }
        } else targets = playerOrder(false);
        let left = moveTo(sess, p, cp(src), targets);
        if (!left || left.count !== src.count) setSlot(sess, p, sid, left);
    }
    function consumeGrid(sess) {
        for (let i = 0; i < 36; i++) if (sess.grid[i]) { sess.grid[i].count--; if (sess.grid[i].count <= 0) sess.grid[i] = null; }
    }
    function crafted(p, n) { if (DMZ_TP && p.getVar("dmz_created", 0)) DMZ_TP(p, n, "crafted"); }
    function takePattern(sess, p) {
        let res = sess.result, car = sess.carried;
        if (!res) return;
        if (car && (!same(car, res) || car.count + res.count > maxStack(car))) return;
        setCarried(sess, p, car ? cp(car, car.count + res.count) : cp(res));
        consumeGrid(sess);
        patternChanged(sess, p);
        crafted(p, res.count);
    }
    function fits(sess, p, s) {
        let need = s.count, max = maxStack(s);
        for (let i = 0; i < 36 && need > 0; i++) {
            let cur = cp(p.getStack(i));
            if (!cur) need -= max; else if (same(cur, s)) need -= Math.max(0, max - cur.count);
        }
        return need <= 0;
    }
    function craftPatternsToInventory(sess, p) {
        for (let n = 0; n < 64 && sess.result; n++) {
            let res = cp(sess.result);
            if (!fits(sess, p, res)) break;
            let left = moveTo(sess, p, res, playerOrder(true));
            if (left) p.giveStack(forWorld(left));
            consumeGrid(sess);
            patternChanged(sess, p);
            crafted(p, 1);
        }
    }
    function click(sess, p, sid, button, shift) {
        if (shift) { quickMove(sess, p, sid); return; }
        let resultSlot = sess.type === "pattern_station" && sid === "m0";
        if (resultSlot) { takePattern(sess, p); return; }
        let cur = getSlot(sess, p, sid), car = sess.carried;
        let outputOnly = sess.type === "kikono_station" && sid === "m11";
        if (!car) {
            if (!cur) return;
            let n = button === 1 ? Math.ceil(cur.count / 2) : cur.count;
            setCarried(sess, p, cp(cur, n));
            setSlot(sess, p, sid, cur.count - n > 0 ? cp(cur, cur.count - n) : null);
            return;
        }
        if (outputOnly) {                                          // a take-only slot: top up what you hold
            if (!cur || !same(cur, car)) return;
            let n = Math.min(cur.count, maxStack(car) - car.count);
            if (n <= 0) return;
            setCarried(sess, p, cp(car, car.count + n));
            setSlot(sess, p, sid, cur.count - n > 0 ? cp(cur, cur.count - n) : null);
            return;
        }
        if (!canPlace(sess, sid, car)) return;
        if (!cur) {
            let n = button === 1 ? 1 : Math.min(car.count, maxStack(car));
            let got = setSlot(sess, p, sid, cp(car, n));
            setCarried(sess, p, car.count - got > 0 ? cp(car, car.count - got) : null);
        } else if (same(cur, car)) {
            let room = maxStack(cur) - cur.count, n = Math.min(button === 1 ? 1 : car.count, room);
            if (n <= 0) return;
            let got = setSlot(sess, p, sid, cp(cur, cur.count + n)) - cur.count;
            setCarried(sess, p, car.count - got > 0 ? cp(car, car.count - got) : null);
        } else if (car.count <= maxStack(car)) {                   // swap
            let got = setSlot(sess, p, sid, cp(car));
            if (got < car.count) { setSlot(sess, p, sid, cur); return; }
            setCarried(sess, p, cur);
        }
    }

    RPG.net.on("dmzm", (p, d) => {
        if (!d) return;
        ONLINE[p.uuid] = p;
        let sess = SESS[p.uuid];
        let a = String(d.a || "");
        if (a === "close") { close(p, false); return; }
        if (!sess) { RPG.net.send(p, "dmzm_close", {}); return; }
        if (a === "click") {
            let sid = String(d.s || ""), n = Number(sid.substring(1));
            if (!/^[pm]\d+$/.test(sid) || (sid.charAt(0) === "p" && n > 35) || (sid.charAt(0) === "m" && n >= machineSlots(sess))) return;
            if (STORED[sess.type] && !M[sess.key]) { close(p, true); return; }
            click(sess, p, sid, Number(d.b) === 1 ? 1 : 0, !!d.sh);
            sendFull(sess, p);
            if (VIEW[sess.key]) Object.keys(VIEW[sess.key]).forEach((u) => {      // others looking at the same machine
                let o = playerOf(u), os = SESS[u];
                if (o && os && u !== p.uuid) RPG.net.send(o, "dmzm_state", { key: sess.key, slots: machineView(os, o) });
            });
            rtOf(sess.key).sentVer = rtOf(sess.key).ver;
        } else if (a === "grav" && sess.type === "gravity_device") {
            let m = M[sess.key];
            if (!m) return;
            // GravityDeviceBlockEntity.applyMenuInput
            let g = Math.max(1, Math.min(Math.floor(num(d.g, 1)), num(GCFG.deviceMaxGravity, 1000)));
            let on = !!d.on, changed = g !== m.g || on !== m.active;
            m.g = g; m.active = on;
            rtOf(sess.key).roomDirty = true;
            if (changed) { rtOf(sess.key).ver++; save(sess.key); }
        }
    });

    // Gravity Device + sneak: show the room's edges for 10 s (DMZ: GravityRangeRenderer)
    function showRoom(p, k) {
        let m = M[k];
        if (!m || !m.valid) { p.actionbar("&cInvalid room (" + GCFG.deviceMinRoomSize + "-" + GCFG.deviceMaxRoomSize + " blocks each side)"); return; }
        let a = m.rmin, b = [m.rmax[0] + 1, m.rmax[1] + 1, m.rmax[2] + 1];
        let edges = [[a[0], a[1], a[2], b[0], a[1], a[2]], [a[0], b[1], a[2], b[0], b[1], a[2]], [a[0], a[1], b[2], b[0], a[1], b[2]], [a[0], b[1], b[2], b[0], b[1], b[2]],
            [a[0], a[1], a[2], a[0], b[1], a[2]], [b[0], a[1], a[2], b[0], b[1], a[2]], [a[0], a[1], b[2], a[0], b[1], b[2]], [b[0], a[1], b[2], b[0], b[1], b[2]],
            [a[0], a[1], a[2], a[0], a[1], b[2]], [b[0], a[1], a[2], b[0], a[1], b[2]], [a[0], b[1], a[2], a[0], b[1], b[2]], [b[0], b[1], a[2], b[0], b[1], b[2]]];
        for (let n = 0; n < 10; n++) RPG.schedule(n * 20, () => edges.forEach((e) => RPG.world.particleLine(m.d, "minecraft:end_rod", e[0], e[1], e[2], e[3], e[4], e[5], 1)));
    }

    // ---- block hooks (13_dmz_blocks.js) --------------------------------------------------------
    function use(name, p, x, y, z) {
        if (name === "energy_cable") return;                       // no screen
        if (name === "gravity_device" && p.isSneaking()) { showRoom(p, get(name, p.dimension, x, y, z)); return; }
        open(name, p, x, y, z);
    }
    function placed(name, p, x, y, z) {
        NET_EPOCH++;
        if (!STORED[name]) return;
        let k = key(p.dimension, x, y, z);
        if (M[k]) { dropContents(M[k]); remove(k); }               // a stale entry from a block that vanished
        add(k, fresh(name, p.dimension, x, y, z));
    }
    function broken(name, p, x, y, z) {
        let dim = p.dimension, k = key(dim, x, y, z);
        NET_EPOCH++;
        // onBreak runs just before the block goes: finish a tick later, once it's really gone
        RPG.schedule(1, () => {
            if (nameAt(dim, x, y, z) === name) return;
            closeViewers(k);
            Object.keys(SESS).forEach((u) => { let s = SESS[u], o = playerOf(u); if (s && o && s.d === dim && s.x === x && s.y === y && s.z === z) close(o, true); });
            if (M[k]) { dropContents(M[k]); remove(k); }
        });
    }

    // ---- load, joins, leaves -----------------------------------------------------------------------
    RPG.data.keys(PREFIX).forEach((k) => {
        let m = RPG.data.get(k, null);
        if (!m || !m.t || !STORED[m.t]) { RPG.data.remove(k); return; }
        M[k] = m; KEYS.push(k);
        rtOf(k);
        if (m.t === "gravity_device") m.running = false;
    });
    function giveBack(p) {
        let c = p.getVar("dmzm_carried", null), g = p.getVar("dmzm_grid", null);
        if (c && c.id) p.giveStack(forWorld(cp(c)));
        if (g && g.length) for (let i = 0; i < g.length; i++) if (g[i] && g[i].id) p.giveStack(forWorld(cp(g[i])));
        if (c) p.setVar("dmzm_carried", null);
        if (g) p.setVar("dmzm_grid", null);
    }
    RPG.on("playerJoin", (p) => { giveBack(p); });
    RPG.on("playerLeave", (p) => { close(p, false); delete ONLINE[p.uuid]; GSTATE[p.uuid] = undefined; });
    RPG.schedule(1, () => {                                        // after /rpg reload: screens that were open are gone
        refreshOnline();
        RPG.server.players().forEach((p) => {
            if (p.getVar("dmzm_carried", null) || p.getVar("dmzm_grid", null)) { giveBack(p); RPG.net.send(p, "dmzm_close", {}); }
        });
    });

    // =================================================================================================
    //  Gravity training (server/util/GravityLogic)
    // =================================================================================================
    let GSTATE = {};       // uuid -> last computed values
    let NPC_CACHE = {};    // uuid -> { at, dim, g }
    let HTC = "ragnarok_rpg:time_chamber";
    function machineGravity(p) {
        if (!GCFG.machineGravityEnabled) return 0;
        let best = 0, x = p.x, y = p.y, z = p.z;
        Object.keys(ZONES).forEach((k) => {
            let zn = ZONES[k];
            if (zn.d === p.dimension && x >= zn.x0 && x < zn.x1 && y >= zn.y0 && y < zn.y1 && z >= zn.z0 && z < zn.z1 && zn.g > best) best = zn.g;
        });
        return best;
    }
    function npcGravity(p, t) {
        let c = NPC_CACHE[p.uuid];
        if (c && c.dim === p.dimension && t - c.at <= 100) return c.g;
        let g = 0, r = num(GCFG.npcGravityRange, 100);
        let list = RPG.world.entitiesNear(p.dimension, p.x, p.y, p.z, r, "ragnarok_rpg:npc");
        for (let i = 0; i < list.length; i++) if (String(list[i].rpgId) === "king_kai") { g = num(GCFG.npcGravityValue, 10); break; }
        NPC_CACHE[p.uuid] = { at: t, dim: p.dimension, g: g };
        return g;
    }
    function worldGravity(dim) {
        let w = GCFG.gravityPerWorld || {};
        return typeof w[dim] === "number" ? Math.max(0, w[dim]) : Math.max(0, GCFG.defaultWorldGravity);
    }
    function eff(v, k, mk) { return v.stat(k) * v.mult(mk); }
    function avgEffective(v) { return (eff(v, "STR", "STR") + eff(v, "SKP", "SKP") + eff(v, "RES", "DEF") + eff(v, "VIT", "VIT") + eff(v, "PWR", "PWR") + eff(v, "ENE", "ENE")) / 6; }
    function totalWeight(p) {
        let s = p.getAccessory("weights");
        let w = s && s.data ? num(s.data.WeightValue, 0) : 0;
        if (!w && s && s.nbt) { let m = /WeightValue[":]*\s*:?\s*(\d+)/.exec(String(s.nbt)); if (m) w = Number(m[1]); }
        return Math.max(0, w);
    }
    function relativeLevel(p, v) {
        let lvl = DMZ_F.level(v), total = 0, boosted = 0;
        ["STR", "SKP", "RES", "VIT", "PWR", "ENE"].forEach((k) => { total += v.stat(k); });
        boosted = avgEffective(v) * 6;
        let initial = total - (lvl - 1) * 6;
        return (boosted - initial) / 6 + 1;
    }
    /** Everything GravityLogic works out for a player. */
    function gravityFor(p, t) {
        let c = GCFG, v = dmzView(p), out = { g: 1, net: 0, tp: 1, stat: 0, move: 0, attack: 0, total: 0, ideal: 0, eff: 0, load: 0, wtp: 1, zone: 0, m: 0 };
        if (!c.enabled) return out;
        let machine = machineGravity(p), npc = npcGravity(p, t), extra = Math.max(0, machine - 1);
        function compute(includeDim) { return Math.max(0, Math.max(includeDim ? worldGravity(p.dimension) : num(c.defaultWorldGravity, 1), npc) + extra); }
        let g = compute(true), gTrain = compute(p.dimension !== HTC);
        let resistance = avgEffective(v) / Math.max(1, num(c.maxStatValue, 1000000) * Math.max(0.01, Math.min(1, c.resistanceStatDivisorRatio))) * c.resistanceScale;
        let net = g <= 1 ? 0 : Math.max(0, g - resistance);
        let trainNet = gTrain <= 1 ? 0 : Math.max(0, gTrain - resistance);
        if (trainNet >= c.hardStopThreshold) trainNet = 0;
        out.g = g; out.net = net; out.m = machine;
        out.tp = c.tpEnabled && c.gravityBonusEnabled && trainNet > 0 ? 1 + trainNet * c.tpGravityBonusPerGravity : 1;
        // weights (WeightItem "WeightValue" in the weights slot)
        out.total = totalWeight(p);
        let loadFactor = Math.max(0.0001, 1 + (g - 1) * c.gravitySensitivity);
        out.eff = Math.round(out.total * loadFactor);
        out.ideal = c.tpEnabled ? Math.max(0, Math.round(relativeLevel(p, v) / c.tpIdealBaseDivisor)) : 0;
        out.load = out.ideal > 0 ? out.eff / out.ideal : 0;
        out.zone = D.trainingZone(c, out.total, out.ideal, out.eff);
        out.wtp = c.tpEnabled && out.total > 0 && out.ideal > 0 ? D.weightTpMultiplier(c, out.load) : 1;
        let weightPenalty = 0;
        if (c.tpEnabled && out.total > 0 && out.ideal > 0 && out.load > c.tpIdealRatioHigh)
            weightPenalty = out.load >= c.tpOverloadHardRatio ? c.maxWeightPenalty : c.maxWeightPenalty * (out.load - c.tpIdealRatioHigh) / (c.tpOverloadHardRatio - c.tpIdealRatioHigh);
        // stat reduction
        let red = 0;
        if (c.statReductionEnabled) {
            if (net > 0) red = Math.max(c.minStatReduction, Math.min(c.maxStatReduction, net * c.statReductionPerGravity));
            red = Math.min(c.maxStatReduction, red + weightPenalty);
        }
        out.stat = red;
        // movement / attack speed
        let mv = 0, at = 0;
        if (net > 0) {
            if (net >= c.hardStopThreshold) { mv = c.maxMovementPenalty; at = c.maxAttackPenalty; }
            else { mv = Math.min(c.maxMovementPenalty, D.penaltyFactor(c, net)); at = Math.min(c.maxAttackPenalty, Math.sqrt(net / 100)); }
        }
        out.move = Math.min(c.maxMovementPenalty, mv + weightPenalty);
        out.attack = Math.min(c.maxAttackPenalty, at + weightPenalty);
        return out;
    }
    RPG.effects.define("dmz_gravity_move", { name: "Gravity", hidden: true, maxStacks: 100, keepOnDeath: true,
        attributes: { "minecraft:generic.movement_speed": { amount: -0.01, operation: "multiply_total" } } });
    RPG.effects.define("dmz_gravity_attack", { name: "Gravity", hidden: true, maxStacks: 100, keepOnDeath: true,
        attributes: { "minecraft:generic.attack_speed": { amount: -0.01, operation: "multiply_total" } } });
    function setStacks(p, id, n) {
        let cur = p.hasEffect(id) ? p.effectStacks(id) : 0;
        if (cur === n) return;
        if (n <= 0) { p.removeEffect(id); return; }
        if (cur > n) { p.removeEffect(id); cur = 0; }
        p.addEffectStacks(id, -1, n - cur);
    }
    // the stat reduction is folded into dmz_mult like 31_dmz_transform.js folds the forms
    function applyStatMult(p, factor) {
        let old = Number(p.getVar("dmz_gravity_mult", 1)) || 1;
        if (Math.abs(old - factor) < 0.005) return;
        let m = p.getVar("dmz_mult", null) || {}, o = {};
        Object.keys(m).forEach((k) => { o[k] = m[k]; });
        (GCFG.affectedStats || []).forEach((k) => { let cur = typeof o[k] === "number" ? o[k] : 1; o[k] = cur / old * factor; });
        p.setVar("dmz_mult", o);
        p.setVar("dmz_gravity_mult", factor);
        p.refreshStats();
    }
    function synced(a, b) {
        return a && Math.abs(a.m - b.m) < 0.5 && Math.abs(a.g - b.g) < 0.1 && Math.abs(a.net - b.net) < 0.1 && Math.abs(a.stat - b.stat) < 0.01 &&
            Math.abs(a.tp - b.tp) < 0.01 && Math.abs(a.wtp - b.wtp) < 0.01 && Math.abs(a.load - b.load) < 0.02 && a.ideal === b.ideal &&
            a.total === b.total && a.eff === b.eff && a.zone === b.zone;
    }
    RPG.every(10, () => {
        let t = now();
        RPG.server.players().forEach((p) => {
            if (!p.getVar("dmz_created", 0)) return;
            let s = gravityFor(p, t), old = GSTATE[p.uuid];
            GSTATE[p.uuid] = s;
            setStacks(p, "dmz_gravity_move", Math.round(s.move * 100));
            setStacks(p, "dmz_gravity_attack", Math.round(s.attack * 100));
            applyStatMult(p, Math.round((1 - s.stat) * 100) / 100);
            if (!synced(old, s)) {                                  // GravityStateSync: the client's copy (fall, jump, flight)
                p.setVar("dmz_gravity", { m: s.m, g: Math.round(s.g * 100) / 100, net: Math.round(s.net * 100) / 100, stat: Math.round((1 - s.stat) * 100) / 100,
                    tp: Math.round(s.tp * 1000) / 1000, ideal: s.ideal, total: s.total, eff: s.eff, load: Math.round(s.load * 100) / 100,
                    wtp: Math.round(s.wtp * 1000) / 1000, zone: s.zone, hard: GCFG.hardStopThreshold,
                    jump: Math.round(D.jumpFactor(GCFG, s.net) * 1000) / 1000, fly: Math.round(D.flyFactor(GCFG, s.net) * 1000) / 1000,
                    fall: Math.round(D.fallExtra(GCFG, s.net) * 1000) / 1000 });
            }
        });
    });

    return {
        use: use, placed: placed, broken: broken,
        /** Extra TP multiplier (added to DMZ's sum in 09_dmz_stats.js): gravity + weights. */
        tpBonus: (p) => { let s = GSTATE[p.uuid]; return s ? (s.tp - 1) + (s.wtp - 1) : 0; },
        /** GravityLogic.getConsumptionMultiplier: ki costs while under net gravity. */
        consumption: (p) => { let s = GSTATE[p.uuid]; return s && s.net > 0 ? 1 + s.net * GCFG.consumptionPerGravity : 1; },
        /** StatsEvents mastery bonus: 1 + bonus gravity x 0.0025. */
        mastery: (p) => { let s = GSTATE[p.uuid]; return s && s.net > 0 && s.net < GCFG.hardStopThreshold ? 1 + s.net * GCFG.masteryBonusPerGravity : 1; },
        gravity: (p) => GSTATE[p.uuid] || null,
        machine: (dim, x, y, z) => M[key(dim, x, y, z)] || null,
        config: GCFG,
        _debug: { M: M, RT: RT, KEYS: KEYS, SESS: SESS, VIEW: VIEW, ZONES: ZONES, process: process, kikMatch: kikMatch, network: network, roomStart: roomStart, roomStep: roomStep, gravityFor: gravityFor, click: click, refreshOnline: refreshOnline }
    };
})();

// hooks called by 13_dmz_blocks.js and 09_dmz_stats.js
function dmzMachineUse(name, player, x, y, z) { DMZ_MACHINES.use(name, player, x, y, z); }
function dmzMachinePlaced(name, player, x, y, z) { DMZ_MACHINES.placed(name, player, x, y, z); }
function dmzMachineBroken(name, player, x, y, z) { DMZ_MACHINES.broken(name, player, x, y, z); }
function dmzGravityTpBonus(player) { return DMZ_MACHINES.tpBonus(player); }
function dmzGravityConsumptionMult(player) { return DMZ_MACHINES.consumption(player); }
function dmzGravityMasteryMult(player) { return DMZ_MACHINES.mastery(player); }
