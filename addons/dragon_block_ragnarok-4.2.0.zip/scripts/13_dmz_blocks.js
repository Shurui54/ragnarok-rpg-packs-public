// =====================================================================================
//  13_dmz_blocks.js - every DragonMine Z block (GPL-3.0, ported from DMZ's MainBlocks /
//  DMZBlockLootTables / DMZBlockTagGenerator / DMZBlockStateProvider). GENERATED DATA + logic.
// =====================================================================================
//  Names are DMZ's registry ids ("namek_stone", "namek_ajissa_door"...), so RPG.items / give /
//  recipes / drops all use them. Extra ids we need because our blocks have no block states:
//    <door>_top, <door>_open, <door>_top_open, <gate|trapdoor>_open, <slab>_double, <crop>_age1..7
//  Ores and the rock they replace use fixed placeholder numbers 2001-2023 (see num) because the
//  ore world generation in datapack/data/dbr/worldgen points at "ragnarok_rpg:block_20xx".
//  Drops follow DMZ's loot tables (tool tier, Silk Touch, Fortune, shears) and are rolled in onBreak.
// =====================================================================================
var DMZ_BLOCK_SPECS = [
{"id":"invisible_ladder_block","m":"dbr:rpg/block/invisible_ladder_block","h":-1,"decor":true,"collision":false,"shape":[0,0,13,16,16,16],"drop":"none","fx":"ladder","n":"Invisible Ladder Block","im":"dmzpack:rpg/item/invisible_ladder_block"},
{"id":"time_chamber_block","m":"dmzpack:rpg/block/time_chamber_block","h":-1,"drop":"self","n":"Hyperbolic Time Chamber Block"},
{"id":"otherworld_cloud","m":"dmzpack:rpg/block/otherworld_cloud","h":-1,"decor":true,"collision":false,"drop":"none","fx":"cloud","n":"Otherworld Cloud Block"},
{"id":"hell_ground","m":"dmzpack:rpg/block/hell_ground","h":1.5,"tool":"pickaxe","rt":true,"n":"Hell Ground"},
{"id":"hell_stone","m":"dmzpack:rpg/block/hell_stone","h":1.5,"tool":"pickaxe","rt":true,"n":"Hell Stone"},
{"id":"hell_deepstone","m":"dmzpack:rpg/block/hell_deepstone","h":1.5,"tool":"pickaxe","rt":true,"n":"Hell Deepstone"},
{"id":"might_tree_wood","m":"dmzpack:rpg/block/might_tree_wood","h":-1,"drop":"none","n":"Tree of Might Wood"},
{"id":"might_tree_root","m":"dbr:rpg/block/might_tree_root","h":-1,"decor":true,"shape":[4,0,4,12,16,12],"drop":"none","n":"Tree of Might Root"},
{"id":"might_tree_leaves","m":"dmzpack:rpg/block/might_tree_leaves","h":0.3,"tool":"hoe","drop":"none","n":"Tree of Might Leaves"},
{"id":"might_tree_fruit_block","m":"dbr:rpg/block/might_tree_fruit_block","h":0.3,"light":6,"decor":true,"shape":[2,2,2,14,16,14],"drop":{"other":"might_tree_fruit"},"n":"Fruit of the Tree of Might"},
{"id":"namek_block","m":"dmzpack:rpg/block/namek_block","h":0.8,"tool":"pickaxe","rt":true,"n":"Planet Namek Block"},
{"id":"namek_grass_block","num":2036,"m":"dbr:rpg/block/namek_grass_block","h":0.6,"tool":"shovel","drop":{"silkElse":"namek_dirt"},"fx":"grass","n":"Namek Grass Block"},
{"id":"namek_sacred_grass_block","m":"dbr:rpg/block/namek_sacred_grass_block","h":0.6,"tool":"shovel","drop":{"silkElse":"namek_dirt"},"fx":"grass","n":"Namek Sacred Grass Block"},
{"id":"namek_dirt","num":2003,"m":"dmzpack:rpg/block/namek_dirt","h":0.5,"tool":"shovel","n":"Namek Dirt"},
{"id":"namek_ajissa_sapling","m":"dmzpack:rpg/block/namek_ajissa_sapling","h":0,"decor":true,"collision":false,"shape":"cross","fx":"sapling","n":"Ajissa Sapling"},
{"id":"namek_ajissa_leaves","num":3807,"m":"dbr:rpg/block/namek_ajissa_leaves","h":0.2,"tool":"hoe","decor":true,"drop":{"leaves":"namek_ajissa_sapling"},"n":"Ajissa Leaves"},
{"id":"potted_ajissa_sapling","m":"dbr:rpg/block/potted_ajissa_sapling","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"namek_ajissa_sapling"},"fx":"pot","n":"Potted Ajissa Sapling"},
{"id":"namek_ajissa_log","num":3806,"m":"dmzpack:rpg/block/namek_ajissa_log","h":1.0,"tool":"axe","decor":true,"shape":[2,0,2,14,16,14],"fx":"strip","strip":"namek_stripped_ajissa_log","n":"Ajissa Log"},
{"id":"namek_ajissa_wood","m":"dmzpack:rpg/block/namek_ajissa_wood","h":2.0,"tool":"axe","n":"Ajissa Wood"},
{"id":"namek_stripped_ajissa_log","m":"dmzpack:rpg/block/namek_stripped_ajissa_log","h":1.0,"tool":"axe","decor":true,"shape":[2,0,2,14,16,14],"n":"Stripped Ajissa Log"},
{"id":"namek_stripped_ajissa_wood","m":"dmzpack:rpg/block/namek_stripped_ajissa_wood","h":2.0,"tool":"axe","n":"Stripped Ajissa Wood"},
{"id":"namek_ajissa_planks","m":"dmzpack:rpg/block/namek_ajissa_planks","h":2.0,"tool":"axe","n":"Ajissa Planks"},
{"id":"namek_ajissa_stairs","m":"dbr:rpg/block/namek_ajissa_stairs","h":2.0,"tool":"axe","decor":true,"n":"Ajissa Stairs"},
{"id":"namek_ajissa_slab","m":"dbr:rpg/block/namek_ajissa_slab","h":2.0,"tool":"axe","shape":"slab","fx":"slab","base":"namek_ajissa_planks","n":"Ajissa Slab"},
{"id":"namek_ajissa_slab_double","n":"Ajissa Slab","m":"dmzpack:rpg/block/namek_ajissa_planks","h":2.0,"tool":"axe","rt":null,"drop":{"other":"namek_ajissa_slab","min":2,"max":2}},
{"id":"namek_ajissa_fence","m":"dbr:rpg/block/namek_ajissa_fence","h":2.0,"tool":"axe","shape":[6,0,6,10,24,10],"n":"Ajissa Fence"},
{"id":"namek_ajissa_fence_gate","m":"dbr:rpg/block/namek_ajissa_fence_gate","h":2.0,"tool":"axe","shape":[0,0,6,16,24,10],"fx":"toggle","other":"namek_ajissa_fence_gate_open","n":"Ajissa Fence Gate"},
{"id":"namek_ajissa_fence_gate_open","m":"dbr:rpg/block/namek_ajissa_fence_gate_open","h":2.0,"tool":"axe","shape":[0,0,6,16,16,10],"collision":false,"fx":"toggle","other":"namek_ajissa_fence_gate","drop":{"other":"namek_ajissa_fence_gate"},"n":"Namek Ajissa Fence Gate Open"},
{"id":"namek_ajissa_door","m":"dbr:rpg/block/namek_ajissa_door","shape":[0,0,0,3,16,16],"fx":"door","half":"bottom","state":"closed","door":"namek_ajissa_door","h":3.0,"tool":"axe","decor":true,"n":"Ajissa Door","im":"dmzpack:rpg/item/namek_ajissa_door"},
{"id":"namek_ajissa_door_top","m":"dbr:rpg/block/namek_ajissa_door_top","shape":[0,0,0,3,16,16],"fx":"door","half":"top","state":"closed","door":"namek_ajissa_door","drop":"none","h":3.0,"tool":"axe","decor":true,"n":"Namek Ajissa Door Top"},
{"id":"namek_ajissa_door_open","m":"dbr:rpg/block/namek_ajissa_door_open","shape":[0,0,0,16,16,3],"fx":"door","half":"bottom","state":"open","door":"namek_ajissa_door","drop":{"other":"namek_ajissa_door"},"h":3.0,"tool":"axe","decor":true,"n":"Namek Ajissa Door Open"},
{"id":"namek_ajissa_door_top_open","m":"dbr:rpg/block/namek_ajissa_door_top_open","shape":[0,0,0,16,16,3],"fx":"door","half":"top","state":"open","door":"namek_ajissa_door","drop":"none","h":3.0,"tool":"axe","decor":true,"n":"Namek Ajissa Door Top Open"},
{"id":"namek_ajissa_trapdoor","m":"dbr:rpg/block/namek_ajissa_trapdoor","h":3.0,"tool":"axe","shape":[0,0,0,16,3,16],"fx":"toggle","other":"namek_ajissa_trapdoor_open","n":"Ajissa Trapdoor"},
{"id":"namek_ajissa_trapdoor_open","m":"dbr:rpg/block/namek_ajissa_trapdoor_open","h":3.0,"tool":"axe","shape":[0,0,13,16,16,16],"fx":"toggle","other":"namek_ajissa_trapdoor","drop":{"other":"namek_ajissa_trapdoor"},"n":"Namek Ajissa Trapdoor Open"},
{"id":"namek_ajissa_button","m":"dbr:rpg/block/namek_ajissa_button","h":0.5,"decor":true,"collision":false,"shape":[5,0,6,11,2,10],"fx":"button","n":"Ajissa Button"},
{"id":"namek_ajissa_pressure_plate","m":"dbr:rpg/block/namek_ajissa_pressure_plate","h":0.5,"tool":"axe","decor":true,"collision":false,"shape":[1,0,1,15,1,15],"n":"Ajissa Pressure Plate"},
{"id":"namek_sacred_sapling","m":"dmzpack:rpg/block/namek_sacred_sapling","h":0,"decor":true,"collision":false,"shape":"cross","fx":"sapling","n":"Sacred Sapling"},
{"id":"namek_sacred_leaves","m":"dbr:rpg/block/namek_sacred_leaves","h":0.2,"tool":"hoe","decor":true,"drop":{"leaves":"namek_sacred_sapling"},"n":"Sacred Leaves"},
{"id":"potted_sacred_sapling","m":"dbr:rpg/block/potted_sacred_sapling","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"namek_sacred_sapling"},"fx":"pot","n":"Potted Sacred Sapling"},
{"id":"namek_sacred_log","m":"dmzpack:rpg/block/namek_sacred_log","h":1.0,"tool":"axe","decor":true,"shape":[2,0,2,14,16,14],"fx":"strip","strip":"namek_stripped_sacred_log","n":"Sacred Log"},
{"id":"namek_sacred_wood","m":"dmzpack:rpg/block/namek_sacred_wood","h":2.0,"tool":"axe","n":"Sacred Wood"},
{"id":"namek_stripped_sacred_log","m":"dmzpack:rpg/block/namek_stripped_sacred_log","h":1.0,"tool":"axe","decor":true,"shape":[2,0,2,14,16,14],"n":"Stripped Sacred Log"},
{"id":"namek_stripped_sacred_wood","m":"dmzpack:rpg/block/namek_stripped_sacred_wood","h":2.0,"tool":"axe","n":"Stripped Sacred Wood"},
{"id":"namek_sacred_planks","m":"dmzpack:rpg/block/namek_sacred_planks","h":2.0,"tool":"axe","n":"Sacred Planks"},
{"id":"namek_sacred_stairs","m":"dbr:rpg/block/namek_sacred_stairs","h":2.0,"tool":"axe","decor":true,"n":"Sacred Stairs"},
{"id":"namek_sacred_slab","m":"dbr:rpg/block/namek_sacred_slab","h":2.0,"tool":"axe","shape":"slab","fx":"slab","base":"namek_sacred_planks","n":"Sacred Slab"},
{"id":"namek_sacred_slab_double","n":"Sacred Slab","m":"dmzpack:rpg/block/namek_sacred_planks","h":2.0,"tool":"axe","rt":null,"drop":{"other":"namek_sacred_slab","min":2,"max":2}},
{"id":"namek_sacred_fence","m":"dbr:rpg/block/namek_sacred_fence","h":2.0,"tool":"axe","shape":[6,0,6,10,24,10],"n":"Sacred Fence"},
{"id":"namek_sacred_fence_gate","m":"dbr:rpg/block/namek_sacred_fence_gate","h":2.0,"tool":"axe","shape":[0,0,6,16,24,10],"fx":"toggle","other":"namek_sacred_fence_gate_open","n":"Sacred Fence Gate"},
{"id":"namek_sacred_fence_gate_open","m":"dbr:rpg/block/namek_sacred_fence_gate_open","h":2.0,"tool":"axe","shape":[0,0,6,16,16,10],"collision":false,"fx":"toggle","other":"namek_sacred_fence_gate","drop":{"other":"namek_sacred_fence_gate"},"n":"Namek Sacred Fence Gate Open"},
{"id":"namek_sacred_door","m":"dbr:rpg/block/namek_sacred_door","shape":[0,0,0,3,16,16],"fx":"door","half":"bottom","state":"closed","door":"namek_sacred_door","h":3.0,"tool":"axe","decor":true,"n":"Sacred Door","im":"dmzpack:rpg/item/namek_sacred_door"},
{"id":"namek_sacred_door_top","m":"dbr:rpg/block/namek_sacred_door_top","shape":[0,0,0,3,16,16],"fx":"door","half":"top","state":"closed","door":"namek_sacred_door","drop":"none","h":3.0,"tool":"axe","decor":true,"n":"Namek Sacred Door Top"},
{"id":"namek_sacred_door_open","m":"dbr:rpg/block/namek_sacred_door_open","shape":[0,0,0,16,16,3],"fx":"door","half":"bottom","state":"open","door":"namek_sacred_door","drop":{"other":"namek_sacred_door"},"h":3.0,"tool":"axe","decor":true,"n":"Namek Sacred Door Open"},
{"id":"namek_sacred_door_top_open","m":"dbr:rpg/block/namek_sacred_door_top_open","shape":[0,0,0,16,16,3],"fx":"door","half":"top","state":"open","door":"namek_sacred_door","drop":"none","h":3.0,"tool":"axe","decor":true,"n":"Namek Sacred Door Top Open"},
{"id":"namek_sacred_trapdoor","m":"dbr:rpg/block/namek_sacred_trapdoor","h":3.0,"tool":"axe","shape":[0,0,0,16,3,16],"fx":"toggle","other":"namek_sacred_trapdoor_open","n":"Sacred Trapdoor"},
{"id":"namek_sacred_trapdoor_open","m":"dbr:rpg/block/namek_sacred_trapdoor_open","h":3.0,"tool":"axe","shape":[0,0,13,16,16,16],"fx":"toggle","other":"namek_sacred_trapdoor","drop":{"other":"namek_sacred_trapdoor"},"n":"Namek Sacred Trapdoor Open"},
{"id":"namek_sacred_button","m":"dbr:rpg/block/namek_sacred_button","h":0.5,"decor":true,"collision":false,"shape":[5,0,6,11,2,10],"fx":"button","n":"Sacred Button"},
{"id":"namek_sacred_pressure_plate","m":"dbr:rpg/block/namek_sacred_pressure_plate","h":0.5,"tool":"axe","decor":true,"collision":false,"shape":[1,0,1,15,1,15],"n":"Sacred Pressure Plate"},
{"id":"gete_block","m":"dmzpack:rpg/block/gete_block","h":50,"tool":"pickaxe","tier":4,"rt":true,"n":"Gete Block"},
{"id":"gete_debris_ore","num":2022,"m":"dbr:rpg/block/gete_debris_ore","h":30,"tool":"pickaxe","tier":4,"rt":true,"n":"Gete Debris"},
{"id":"gete_star_hull","m":"dmzpack:rpg/block/gete_star_hull","h":-1,"drop":"none","n":"Big Gete Star Hull"},
{"id":"gete_star_circuit","m":"dmzpack:rpg/block/gete_star_circuit","h":-1,"light":12,"drop":"none","n":"Big Gete Star Circuit"},
{"id":"namek_kikono_ore","num":2021,"m":"dmzpack:rpg/block/namek_kikono_ore","h":30,"tool":"pickaxe","tier":3,"rt":true,"drop":{"other":"kikono_shard","silk":true,"fortune":true},"n":"Namek Deepslate Kikono Ore"},
{"id":"kikono_block","m":"dmzpack:rpg/block/kikono_block","h":50,"tool":"pickaxe","tier":3,"rt":true,"n":"Kikono Block"},
{"id":"namek_stone","num":2001,"m":"dmzpack:rpg/block/namek_stone","h":1.5,"tool":"pickaxe","rt":true,"drop":{"silkElse":"namek_cobblestone"},"n":"Namek Stone"},
{"id":"namek_stone_slab","m":"dbr:rpg/block/namek_stone_slab","h":2.0,"tool":"pickaxe","rt":true,"shape":"slab","fx":"slab","base":"namek_stone","n":"Namek Stone Slab"},
{"id":"namek_stone_slab_double","n":"Namek Stone Slab","m":"dmzpack:rpg/block/namek_stone","h":2.0,"tool":"pickaxe","rt":true,"drop":{"other":"namek_stone_slab","min":2,"max":2}},
{"id":"namek_stone_stairs","m":"dbr:rpg/block/namek_stone_stairs","h":1.5,"tool":"pickaxe","rt":true,"decor":true,"n":"Namek Stone Stairs"},
{"id":"namek_stone_wall","m":"dbr:rpg/block/namek_stone_wall","h":2.0,"tool":"pickaxe","rt":true,"shape":[4,0,4,12,24,12],"n":"Namek Stone Wall"},
{"id":"namek_cobblestone","m":"dmzpack:rpg/block/namek_cobblestone","h":2.0,"tool":"pickaxe","rt":true,"n":"Namek Cobblestone"},
{"id":"namek_cobblestone_slab","m":"dbr:rpg/block/namek_cobblestone_slab","h":2.0,"tool":"pickaxe","rt":true,"shape":"slab","fx":"slab","base":"namek_cobblestone","n":"Namek Cobblestone Slab"},
{"id":"namek_cobblestone_slab_double","n":"Namek Cobblestone Slab","m":"dmzpack:rpg/block/namek_cobblestone","h":2.0,"tool":"pickaxe","rt":true,"drop":{"other":"namek_cobblestone_slab","min":2,"max":2}},
{"id":"namek_cobblestone_stairs","m":"dbr:rpg/block/namek_cobblestone_stairs","h":2.0,"tool":"pickaxe","rt":true,"decor":true,"n":"Namek Cobblestone Stairs"},
{"id":"namek_cobblestone_wall","m":"dbr:rpg/block/namek_cobblestone_wall","h":2.0,"tool":"pickaxe","rt":true,"shape":[4,0,4,12,24,12],"n":"Namek Cobblestone Wall"},
{"id":"namek_deepslate","num":2002,"m":"dbr:rpg/block/namek_deepslate","h":3.0,"tool":"pickaxe","rt":true,"n":"Namek Deepslate"},
{"id":"namek_deepslate_slab","m":"dbr:rpg/block/namek_deepslate_slab","h":3.5,"tool":"pickaxe","rt":true,"shape":"slab","fx":"slab","base":"namek_deepslate","n":"Namek Deepslate Slab"},
{"id":"namek_deepslate_slab_double","n":"Namek Deepslate Slab","m":"dbr:rpg/block/namek_deepslate","h":3.5,"tool":"pickaxe","rt":true,"drop":{"other":"namek_deepslate_slab","min":2,"max":2}},
{"id":"namek_deepslate_stairs","m":"dbr:rpg/block/namek_deepslate_stairs","h":3.5,"tool":"pickaxe","rt":true,"decor":true,"n":"Namek Deepslate Stairs"},
{"id":"namek_deepslate_wall","m":"dbr:rpg/block/namek_deepslate_wall","h":3.5,"tool":"pickaxe","rt":true,"shape":[4,0,4,12,24,12],"n":"Namek Deepslate Wall"},
{"id":"rocky_dirt","num":2025,"m":"dmzpack:rpg/block/rocky_dirt","h":0.5,"tool":"shovel","n":"Rocky Dirt"},
{"id":"rocky_stone","num":2026,"m":"dmzpack:rpg/block/rocky_stone","h":1.5,"tool":"pickaxe","rt":true,"drop":{"silkElse":"rocky_cobblestone"},"n":"Rocky Stone"},
{"id":"rocky_stone_slab","m":"dbr:rpg/block/rocky_stone_slab","h":2.0,"tool":"pickaxe","rt":true,"shape":"slab","fx":"slab","base":"rocky_stone","n":"Rocky Stone Slab"},
{"id":"rocky_stone_slab_double","n":"Rocky Stone Slab","m":"dmzpack:rpg/block/rocky_stone","h":2.0,"tool":"pickaxe","rt":true,"drop":{"other":"rocky_stone_slab","min":2,"max":2}},
{"id":"rocky_stone_stairs","m":"dbr:rpg/block/rocky_stone_stairs","h":1.5,"tool":"pickaxe","rt":true,"decor":true,"n":"Rocky Stone Stairs"},
{"id":"rocky_stone_wall","m":"dbr:rpg/block/rocky_stone_wall","h":2.0,"tool":"pickaxe","rt":true,"shape":[4,0,4,12,24,12],"n":"Rocky Stone Wall"},
{"id":"rocky_cobblestone","num":2027,"m":"dmzpack:rpg/block/rocky_cobblestone","h":2.0,"tool":"pickaxe","rt":true,"n":"Rocky Cobblestone"},
{"id":"rocky_cobblestone_slab","m":"dbr:rpg/block/rocky_cobblestone_slab","h":2.0,"tool":"pickaxe","rt":true,"shape":"slab","fx":"slab","base":"rocky_cobblestone","n":"Rocky Cobblestone Slab"},
{"id":"rocky_cobblestone_slab_double","n":"Rocky Cobblestone Slab","m":"dmzpack:rpg/block/rocky_cobblestone","h":2.0,"tool":"pickaxe","rt":true,"drop":{"other":"rocky_cobblestone_slab","min":2,"max":2}},
{"id":"rocky_cobblestone_stairs","m":"dbr:rpg/block/rocky_cobblestone_stairs","h":2.0,"tool":"pickaxe","rt":true,"decor":true,"n":"Rocky Cobblestone Stairs"},
{"id":"rocky_cobblestone_wall","m":"dbr:rpg/block/rocky_cobblestone_wall","h":2.0,"tool":"pickaxe","rt":true,"shape":[4,0,4,12,24,12],"n":"Rocky Cobblestone Wall"},
{"id":"sacred_planet_grass_block","num":2024,"m":"dbr:rpg/block/sacred_planet_grass_block","h":0.6,"tool":"shovel","drop":{"silkElse":"rocky_dirt"},"fx":"grass","n":"Sacred Planet Grass Block"},
{"id":"makai_stone","num":2029,"m":"dmzpack:rpg/block/makai_stone","h":1.5,"tool":"pickaxe","rt":true,"n":"Makai Stone"},
{"id":"makai_stone_slab","m":"dbr:rpg/block/makai_stone_slab","h":2.0,"tool":"pickaxe","rt":true,"shape":"slab","fx":"slab","base":"makai_stone","n":"Makai Stone Slab"},
{"id":"makai_stone_slab_double","n":"Makai Stone Slab","m":"dmzpack:rpg/block/makai_stone","h":2.0,"tool":"pickaxe","rt":true,"drop":{"other":"makai_stone_slab","min":2,"max":2}},
{"id":"makai_stone_stairs","m":"dbr:rpg/block/makai_stone_stairs","h":1.5,"tool":"pickaxe","rt":true,"decor":true,"n":"Makai Stone Stairs"},
{"id":"makai_stone_wall","m":"dbr:rpg/block/makai_stone_wall","h":2.0,"tool":"pickaxe","rt":true,"shape":[4,0,4,12,24,12],"n":"Makai Stone Wall"},
{"id":"makai_strata_stone","num":2030,"m":"dbr:rpg/block/makai_strata_stone","h":1.5,"tool":"pickaxe","rt":true,"n":"Makai Strata Stone"},
{"id":"makai_grass_block","num":2031,"m":"dbr:rpg/block/makai_grass_block","h":0.6,"tool":"shovel","drop":{"silkElse":"makai_dirt"},"fx":"till","n":"Makai Grass Block"},
{"id":"makai_dirt","num":2032,"m":"dmzpack:rpg/block/makai_dirt","h":0.5,"tool":"shovel","fx":"till","n":"Makai Dirt"},
{"id":"lilac_sand","num":2034,"m":"dmzpack:rpg/block/lilac_sand","h":0.5,"tool":"shovel","fx":"falling","n":"Lilac Sand"},
{"id":"makai_sand","num":2033,"m":"dmzpack:rpg/block/makai_sand","h":0.5,"tool":"shovel","fx":"falling","n":"Makai Sand"},
{"id":"makai_shrub","num":3804,"m":"dmzpack:rpg/block/makai_shrub","h":0,"decor":true,"collision":false,"shape":[2,0,2,14,13,14],"fx":"plant_any","n":"Makai Agave"},
{"id":"makai_bush","num":3803,"m":"dbr:rpg/block/makai_bush","h":0.2,"tool":"hoe","decor":true,"n":"Makai Bush"},
{"id":"adobe","m":"dmzpack:rpg/block/adobe","h":1.5,"tool":"pickaxe","n":"Adobe"},
{"id":"adobe_slab","m":"dbr:rpg/block/adobe_slab","h":1.5,"tool":"pickaxe","rt":false,"shape":"slab","fx":"slab","base":"adobe","n":"Adobe Slab"},
{"id":"adobe_slab_double","n":"Adobe Slab","m":"dmzpack:rpg/block/adobe","h":1.5,"tool":"pickaxe","rt":false,"drop":{"other":"adobe_slab","min":2,"max":2}},
{"id":"adobe_stairs","m":"dbr:rpg/block/adobe_stairs","h":1.5,"tool":"pickaxe","rt":false,"decor":true,"n":"Adobe Stairs"},
{"id":"adobe_wall","m":"dbr:rpg/block/adobe_wall","h":1.5,"tool":"pickaxe","rt":false,"shape":[4,0,4,12,24,12],"n":"Adobe Wall"},
{"id":"adobe_bricks","m":"dmzpack:rpg/block/adobe_bricks","h":1.5,"tool":"pickaxe","n":"Adobe Bricks"},
{"id":"gas_vent","num":2040,"m":"dbr:rpg/block/gas_vent","h":1.5,"tool":"pickaxe","rt":true,"fx":"gas_vent","n":"Gas Vent"},
{"id":"dark_sea_cloud","num":3801,"m":"dmzpack:rpg/block/dark_sea_cloud","h":-1,"decor":true,"collision":false,"drop":"none","fx":"dark_cloud","n":"Sea of Darkness Cloud"},
{"id":"turquoise_rock","num":2004,"m":"dmzpack:rpg/block/turquoise_rock","h":1.5,"tool":"pickaxe","rt":true,"n":"Turquoise Rock"},
{"id":"majilite_ore","num":2023,"m":"dmzpack:rpg/block/majilite_ore","h":3.0,"tool":"pickaxe","tier":2,"rt":true,"drop":{"other":"majilite","silk":true,"fortune":true,"xp":[3,7]},"n":"Majilite Ore"},
{"id":"demon_rock","num":2028,"m":"dmzpack:rpg/block/demon_rock","h":1.5,"tool":"pickaxe","rt":true,"n":"Demon Rock"},
{"id":"demon_horn","m":"dmzpack:rpg/block/demon_horn","h":1.5,"tool":"pickaxe","rt":true,"n":"Demon Horn"},
{"id":"demon_horn_glow","m":"dmzpack:rpg/block/demon_horn_glow","h":1.5,"tool":"pickaxe","rt":true,"light":12,"n":"Glowing Demon Horn"},
{"id":"demon_bricks","m":"dmzpack:rpg/block/demon_bricks","h":2.0,"tool":"pickaxe","rt":true,"n":"Demon Bricks"},
{"id":"demon_brick_slab","m":"dbr:rpg/block/demon_brick_slab","h":2.0,"tool":"pickaxe","rt":true,"shape":"slab","fx":"slab","base":"demon_bricks","n":"Demon Brick Slab"},
{"id":"demon_brick_slab_double","n":"Demon Brick Slab","m":"dmzpack:rpg/block/demon_bricks","h":2.0,"tool":"pickaxe","rt":true,"drop":{"other":"demon_brick_slab","min":2,"max":2}},
{"id":"demon_brick_stairs","m":"dbr:rpg/block/demon_brick_stairs","h":2.0,"tool":"pickaxe","rt":true,"decor":true,"n":"Demon Brick Stairs"},
{"id":"demon_brick_wall","m":"dbr:rpg/block/demon_brick_wall","h":2.0,"tool":"pickaxe","rt":true,"shape":[4,0,4,12,24,12],"n":"Demon Brick Wall"},
{"id":"demon_magma_rock","num":2038,"m":"dmzpack:rpg/block/demon_magma_rock","h":0.5,"tool":"pickaxe","rt":true,"light":6,"fx":"magma","n":"Demon Magma Rock"},
{"id":"red_ash","num":2037,"m":"dmzpack:rpg/block/red_ash","h":0.5,"tool":"shovel","n":"Red Ash"},
{"id":"crimson_crystal","num":2039,"m":"dmzpack:rpg/block/crimson_crystal","h":1.5,"tool":"pickaxe","rt":true,"light":10,"n":"Crimson Crystal"},
{"id":"demon_realm_crust","num":2035,"m":"dmzpack:rpg/block/demon_realm_crust","h":-1,"drop":"none","n":"Demon Realm Crust"},
{"id":"light_shield","m":"dbr:rpg/block/light_shield","h":-1,"decor":true,"collision":false,"drop":"none","n":"Shield of Light"},
{"id":"namek_coal_ore","num":2005,"m":"dmzpack:rpg/block/namek_coal_ore","h":3.0,"tool":"pickaxe","tier":1,"rt":true,"drop":{"other":"minecraft:coal","silk":true,"fortune":true,"xp":[0,2]},"n":"Namek Coal Ore"},
{"id":"namek_deepslate_coal_ore","num":2013,"m":"dmzpack:rpg/block/namek_deepslate_coal_ore","h":3.0,"tool":"pickaxe","tier":1,"rt":true,"drop":{"other":"minecraft:coal","silk":true,"fortune":true,"xp":[0,2]},"n":"Namek Deepslate Coal Ore"},
{"id":"namek_copper_ore","num":2006,"m":"dmzpack:rpg/block/namek_copper_ore","h":3.0,"tool":"pickaxe","tier":1,"rt":true,"drop":{"other":"minecraft:raw_copper","silk":true,"fortune":true,"min":2,"max":6},"n":"Namek Copper Ore"},
{"id":"namek_deepslate_copper_ore","num":2014,"m":"dmzpack:rpg/block/namek_deepslate_copper_ore","h":3.0,"tool":"pickaxe","tier":1,"rt":true,"drop":{"other":"minecraft:raw_copper","silk":true,"fortune":true,"min":2,"max":6},"n":"Namek Deepslate Copper Ore"},
{"id":"namek_iron_ore","num":2007,"m":"dmzpack:rpg/block/namek_iron_ore","h":3.0,"tool":"pickaxe","tier":1,"rt":true,"drop":{"other":"minecraft:raw_iron","silk":true,"fortune":true},"n":"Namek Iron Ore"},
{"id":"namek_deepslate_iron_ore","num":2015,"m":"dmzpack:rpg/block/namek_deepslate_iron_ore","h":3.0,"tool":"pickaxe","tier":1,"rt":true,"drop":{"other":"minecraft:raw_iron","silk":true,"fortune":true},"n":"Namek Deepslate Iron Ore"},
{"id":"namek_gold_ore","num":2008,"m":"dmzpack:rpg/block/namek_gold_ore","h":3.0,"tool":"pickaxe","tier":2,"rt":true,"drop":{"other":"minecraft:raw_gold","silk":true,"fortune":true},"n":"Namek Gold Ore"},
{"id":"namek_deepslate_gold_ore","num":2016,"m":"dmzpack:rpg/block/namek_deepslate_gold_ore","h":3.0,"tool":"pickaxe","tier":2,"rt":true,"drop":{"other":"minecraft:raw_gold","silk":true,"fortune":true},"n":"Namek Deepslate Gold Ore"},
{"id":"namek_redstone_ore","num":2009,"m":"dmzpack:rpg/block/namek_redstone_ore","h":3.0,"tool":"pickaxe","tier":2,"rt":true,"drop":{"other":"minecraft:redstone","silk":true,"fortune":true,"min":1,"max":5,"xp":[1,5]},"n":"Namek Redstone Ore"},
{"id":"namek_deepslate_redstone_ore","num":2017,"m":"dmzpack:rpg/block/namek_deepslate_redstone_ore","h":3.0,"tool":"pickaxe","tier":2,"rt":true,"drop":{"other":"minecraft:redstone","silk":true,"fortune":true,"min":1,"max":5,"xp":[1,5]},"n":"Namek Deepslate Redstone Ore"},
{"id":"namek_emerald_ore","num":2010,"m":"dmzpack:rpg/block/namek_emerald_ore","h":3.0,"tool":"pickaxe","tier":2,"rt":true,"drop":{"other":"minecraft:emerald","silk":true,"fortune":true,"xp":[3,7]},"n":"Namek Emerald Ore"},
{"id":"namek_deepslate_emerald_ore","num":2018,"m":"dmzpack:rpg/block/namek_deepslate_emerald_ore","h":3.0,"tool":"pickaxe","tier":2,"rt":true,"drop":{"other":"minecraft:emerald","silk":true,"fortune":true,"xp":[3,7]},"n":"Namek Deepslate Emerald Ore"},
{"id":"namek_lapis_ore","num":2011,"m":"dmzpack:rpg/block/namek_lapis_ore","h":3.0,"tool":"pickaxe","tier":1,"rt":true,"drop":{"other":"minecraft:lapis_lazuli","silk":true,"fortune":true,"min":1,"max":5,"xp":[2,5]},"n":"Namek Lapis Lazuli Ore"},
{"id":"namek_deepslate_lapis_ore","num":2019,"m":"dmzpack:rpg/block/namek_deepslate_lapis_ore","h":3.0,"tool":"pickaxe","tier":1,"rt":true,"drop":{"other":"minecraft:lapis_lazuli","silk":true,"fortune":true,"min":1,"max":5,"xp":[2,5]},"n":"Namek Deepslate Lapis Lazuli Ore"},
{"id":"namek_diamond_ore","num":2012,"m":"dmzpack:rpg/block/namek_diamond_ore","h":3.0,"tool":"pickaxe","tier":2,"rt":true,"drop":{"other":"minecraft:diamond","silk":true,"fortune":true,"xp":[3,7]},"n":"Namek Diamond Ore"},
{"id":"namek_deepslate_diamond_ore","num":2020,"m":"dmzpack:rpg/block/namek_deepslate_diamond_ore","h":3.0,"tool":"pickaxe","tier":2,"rt":true,"drop":{"other":"minecraft:diamond","silk":true,"fortune":true,"xp":[3,7]},"n":"Namek Deepslate Diamond Ore"},
{"id":"time_chamber_portal","m":"dmzpack:rpg/block/time_chamber_portal","h":-1,"drop":"none","fx":"htc_portal","n":"Hyperbolic Time Chamber Portal Block"},
{"id":"kikono_station","m":"dbr:rpg/block/kikono_station","h":2.5,"tool":"pickaxe","tier":3,"rt":true,"fx":"kikono_station","n":"Dr. Kikono's Station","im":"dmzpack:rpg/item/kikono_station"},
{"id":"fuel_generator","m":"dbr:rpg/block/fuel_generator","h":3.5,"tool":"pickaxe","tier":2,"rt":true,"fx":"machine","n":"Fuel Generator","im":"dmzpack:rpg/item/fuel_generator"},
{"id":"pattern_station","m":"dbr:rpg/block/pattern_station","h":2.5,"tool":"axe","fx":"pattern_station","n":"Pattern Station"},
{"id":"energy_cable","m":"dbr:rpg/block/energy_cable","h":0.8,"decor":true,"shape":[5,5,0,11,11,16],"fx":"machine","n":"Energy Cable","im":"dmzpack:rpg/item/energy_cable"},
{"id":"gravity_device","m":"dbr:rpg/block/gravity_device","h":5.0,"tool":"pickaxe","tier":3,"rt":true,"fx":"machine","n":"Gravity Device"},
{"id":"namek_grass","num":3805,"m":"dbr:rpg/block/namek_grass","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","drop":"shears","n":"Namek Grass","im":"dmzpack:rpg/item/namek_grass"},
{"id":"namek_sacred_grass","m":"dbr:rpg/block/namek_sacred_grass","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","drop":"shears","n":"Namek Sacred Grass","im":"dmzpack:rpg/item/namek_sacred_grass"},
{"id":"namek_fern","num":3813,"m":"dbr:rpg/block/namek_fern","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","drop":"shears","n":"Namek Fern"},
{"id":"sacred_fern","m":"dbr:rpg/block/sacred_fern","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","drop":"shears","n":"Sacred Fern"},
{"id":"potted_namek_fern","m":"dbr:rpg/block/potted_namek_fern","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"namek_fern"},"fx":"pot","n":"Potted Namek Fern"},
{"id":"potted_sacred_fern","m":"dbr:rpg/block/potted_sacred_fern","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"sacred_fern"},"fx":"pot","n":"Potted Sacred Fern"},
{"id":"chrysanthemum_flower","num":3808,"m":"dbr:rpg/block/chrysanthemum_flower","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","n":"Chrysanthemum","im":"dmzpack:rpg/item/chrysanthemum_flower"},
{"id":"potted_chrysanthemum_flower","m":"dbr:rpg/block/potted_chrysanthemum_flower","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"chrysanthemum_flower"},"fx":"pot","n":"Potted Chrysanthemum"},
{"id":"sacred_chrysanthemum_flower","m":"dbr:rpg/block/sacred_chrysanthemum_flower","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","n":"Sacred Chrysanthemum","im":"dmzpack:rpg/item/sacred_chrysanthemum_flower"},
{"id":"potted_sacred_chrysanthemum_flower","m":"dbr:rpg/block/potted_sacred_chrysanthemum_flower","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"sacred_chrysanthemum_flower"},"fx":"pot","n":"Potted Sacred Chrysanthemum"},
{"id":"amaryllis_flower","num":3809,"m":"dbr:rpg/block/amaryllis_flower","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","n":"Amaryllis","im":"dmzpack:rpg/item/amaryllis_flower"},
{"id":"potted_amaryllis_flower","m":"dbr:rpg/block/potted_amaryllis_flower","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"amaryllis_flower"},"fx":"pot","n":"Potted Amaryllis"},
{"id":"sacred_amaryllis_flower","m":"dbr:rpg/block/sacred_amaryllis_flower","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","n":"Sacred Amaryllis","im":"dmzpack:rpg/item/sacred_amaryllis_flower"},
{"id":"potted_sacred_amaryllis_flower","m":"dbr:rpg/block/potted_sacred_amaryllis_flower","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"sacred_amaryllis_flower"},"fx":"pot","n":"Potted Sacred Amaryllis"},
{"id":"marigold_flower","num":3810,"m":"dbr:rpg/block/marigold_flower","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","n":"Marigold","im":"dmzpack:rpg/item/marigold_flower"},
{"id":"potted_marigold_flower","m":"dbr:rpg/block/potted_marigold_flower","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"marigold_flower"},"fx":"pot","n":"Potted Marigold"},
{"id":"sacred_marigold_flower","m":"dbr:rpg/block/sacred_marigold_flower","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","n":"Sacred Marigold","im":"dmzpack:rpg/item/sacred_marigold_flower"},
{"id":"potted_sacred_marigold_flower","m":"dbr:rpg/block/potted_sacred_marigold_flower","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"sacred_marigold_flower"},"fx":"pot","n":"Potted Sacred Marigold"},
{"id":"catharanthus_roseus_flower","num":3811,"m":"dbr:rpg/block/catharanthus_roseus_flower","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","n":"Catharanthus Roseus","im":"dmzpack:rpg/item/catharanthus_roseus_flower"},
{"id":"potted_catharanthus_roseus_flower","m":"dbr:rpg/block/potted_catharanthus_roseus_flower","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"catharanthus_roseus_flower"},"fx":"pot","n":"Potted Catharanthus Roseus"},
{"id":"sacred_catharanthus_roseus_flower","m":"dbr:rpg/block/sacred_catharanthus_roseus_flower","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","n":"Sacred Catharanthus Roseus","im":"dmzpack:rpg/item/sacred_catharanthus_roseus_flower"},
{"id":"potted_sacred_catharanthus_roseus_flower","m":"dbr:rpg/block/potted_sacred_catharanthus_roseus_flower","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"sacred_catharanthus_roseus_flower"},"fx":"pot","n":"Potted Sacred Catharanthus Roseus"},
{"id":"trillium_flower","num":3812,"m":"dbr:rpg/block/trillium_flower","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","n":"Trillium","im":"dmzpack:rpg/item/trillium_flower"},
{"id":"potted_trillium_flower","m":"dbr:rpg/block/potted_trillium_flower","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"trillium_flower"},"fx":"pot","n":"Potted Trillium"},
{"id":"sacred_trillium_flower","m":"dbr:rpg/block/sacred_trillium_flower","h":0,"decor":true,"collision":false,"shape":"cross","fx":"plant","n":"Sacred Trillium","im":"dmzpack:rpg/item/sacred_trillium_flower"},
{"id":"potted_sacred_trillium_flower","m":"dbr:rpg/block/potted_sacred_trillium_flower","h":0,"decor":true,"shape":[5,0,5,11,6,11],"drop":{"pot":"sacred_trillium_flower"},"fx":"pot","n":"Potted Sacred Trillium"},
{"id":"lotus_flower","m":"dbr:rpg/block/lotus_flower","h":0,"decor":true,"shape":[1,0,1,15,1.5,15],"n":"Lotus"},
{"id":"oozaru_root_crop","m":"dbr:rpg/block/oozaru_root_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,2,16],"fx":"crop","crop":"oozaru_root","age":0,"seed":"oozaru_root","bean":null,"soil":"minecraft:farmland","n":"Oozaru Root Crop"},
{"id":"oozaru_root_crop_age1","m":"dbr:rpg/block/oozaru_root_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,4,16],"fx":"crop","crop":"oozaru_root","age":1,"seed":"oozaru_root","bean":null,"soil":"minecraft:farmland","n":"Oozaru Root Crop (age 1)"},
{"id":"oozaru_root_crop_age2","m":"dbr:rpg/block/oozaru_root_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,6,16],"fx":"crop","crop":"oozaru_root","age":2,"seed":"oozaru_root","bean":null,"soil":"minecraft:farmland","n":"Oozaru Root Crop (age 2)"},
{"id":"oozaru_root_crop_age3","m":"dbr:rpg/block/oozaru_root_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,8,16],"fx":"crop","crop":"oozaru_root","age":3,"seed":"oozaru_root","bean":null,"soil":"minecraft:farmland","n":"Oozaru Root Crop (age 3)"},
{"id":"oozaru_root_crop_age4","m":"dbr:rpg/block/oozaru_root_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,10,16],"fx":"crop","crop":"oozaru_root","age":4,"seed":"oozaru_root","bean":null,"soil":"minecraft:farmland","n":"Oozaru Root Crop (age 4)"},
{"id":"oozaru_root_crop_age5","m":"dbr:rpg/block/oozaru_root_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,12,16],"fx":"crop","crop":"oozaru_root","age":5,"seed":"oozaru_root","bean":null,"soil":"minecraft:farmland","n":"Oozaru Root Crop (age 5)"},
{"id":"oozaru_root_crop_age6","m":"dbr:rpg/block/oozaru_root_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,14,16],"fx":"crop","crop":"oozaru_root","age":6,"seed":"oozaru_root","bean":null,"soil":"minecraft:farmland","n":"Oozaru Root Crop (age 6)"},
{"id":"oozaru_root_crop_age7","m":"dbr:rpg/block/oozaru_root_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,16,16],"fx":"crop","crop":"oozaru_root","age":7,"seed":"oozaru_root","bean":null,"soil":"minecraft:farmland","n":"Oozaru Root Crop (age 7)"},
{"id":"katchin_sprout_crop","m":"dbr:rpg/block/katchin_sprout_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,2,16],"fx":"crop","crop":"katchin_sprout","age":0,"seed":"katchin_sprout","bean":null,"soil":"minecraft:farmland","n":"Katchin Sprout Crop"},
{"id":"katchin_sprout_crop_age1","m":"dbr:rpg/block/katchin_sprout_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,4,16],"fx":"crop","crop":"katchin_sprout","age":1,"seed":"katchin_sprout","bean":null,"soil":"minecraft:farmland","n":"Katchin Sprout Crop (age 1)"},
{"id":"katchin_sprout_crop_age2","m":"dbr:rpg/block/katchin_sprout_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,6,16],"fx":"crop","crop":"katchin_sprout","age":2,"seed":"katchin_sprout","bean":null,"soil":"minecraft:farmland","n":"Katchin Sprout Crop (age 2)"},
{"id":"katchin_sprout_crop_age3","m":"dbr:rpg/block/katchin_sprout_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,8,16],"fx":"crop","crop":"katchin_sprout","age":3,"seed":"katchin_sprout","bean":null,"soil":"minecraft:farmland","n":"Katchin Sprout Crop (age 3)"},
{"id":"katchin_sprout_crop_age4","m":"dbr:rpg/block/katchin_sprout_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,10,16],"fx":"crop","crop":"katchin_sprout","age":4,"seed":"katchin_sprout","bean":null,"soil":"minecraft:farmland","n":"Katchin Sprout Crop (age 4)"},
{"id":"katchin_sprout_crop_age5","m":"dbr:rpg/block/katchin_sprout_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,12,16],"fx":"crop","crop":"katchin_sprout","age":5,"seed":"katchin_sprout","bean":null,"soil":"minecraft:farmland","n":"Katchin Sprout Crop (age 5)"},
{"id":"katchin_sprout_crop_age6","m":"dbr:rpg/block/katchin_sprout_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,14,16],"fx":"crop","crop":"katchin_sprout","age":6,"seed":"katchin_sprout","bean":null,"soil":"minecraft:farmland","n":"Katchin Sprout Crop (age 6)"},
{"id":"katchin_sprout_crop_age7","m":"dbr:rpg/block/katchin_sprout_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,16,16],"fx":"crop","crop":"katchin_sprout","age":7,"seed":"katchin_sprout","bean":null,"soil":"minecraft:farmland","n":"Katchin Sprout Crop (age 7)"},
{"id":"meteor_flower_crop","m":"dbr:rpg/block/meteor_flower_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,2,16],"fx":"crop","crop":"meteor_flower","age":0,"seed":"meteor_flower","bean":null,"soil":"minecraft:farmland","n":"Meteor Flower Crop"},
{"id":"meteor_flower_crop_age1","m":"dbr:rpg/block/meteor_flower_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,4,16],"fx":"crop","crop":"meteor_flower","age":1,"seed":"meteor_flower","bean":null,"soil":"minecraft:farmland","n":"Meteor Flower Crop (age 1)"},
{"id":"meteor_flower_crop_age2","m":"dbr:rpg/block/meteor_flower_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,6,16],"fx":"crop","crop":"meteor_flower","age":2,"seed":"meteor_flower","bean":null,"soil":"minecraft:farmland","n":"Meteor Flower Crop (age 2)"},
{"id":"meteor_flower_crop_age3","m":"dbr:rpg/block/meteor_flower_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,8,16],"fx":"crop","crop":"meteor_flower","age":3,"seed":"meteor_flower","bean":null,"soil":"minecraft:farmland","n":"Meteor Flower Crop (age 3)"},
{"id":"meteor_flower_crop_age4","m":"dbr:rpg/block/meteor_flower_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,10,16],"fx":"crop","crop":"meteor_flower","age":4,"seed":"meteor_flower","bean":null,"soil":"minecraft:farmland","n":"Meteor Flower Crop (age 4)"},
{"id":"meteor_flower_crop_age5","m":"dbr:rpg/block/meteor_flower_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,12,16],"fx":"crop","crop":"meteor_flower","age":5,"seed":"meteor_flower","bean":null,"soil":"minecraft:farmland","n":"Meteor Flower Crop (age 5)"},
{"id":"meteor_flower_crop_age6","m":"dbr:rpg/block/meteor_flower_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,14,16],"fx":"crop","crop":"meteor_flower","age":6,"seed":"meteor_flower","bean":null,"soil":"minecraft:farmland","n":"Meteor Flower Crop (age 6)"},
{"id":"meteor_flower_crop_age7","m":"dbr:rpg/block/meteor_flower_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,16,16],"fx":"crop","crop":"meteor_flower","age":7,"seed":"meteor_flower","bean":null,"soil":"minecraft:farmland","n":"Meteor Flower Crop (age 7)"},
{"id":"aura_lily_crop","m":"dbr:rpg/block/aura_lily_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,2,16],"fx":"crop","crop":"aura_lily","age":0,"seed":"aura_lily","bean":null,"soil":"minecraft:farmland","n":"Aura Lily Crop"},
{"id":"aura_lily_crop_age1","m":"dbr:rpg/block/aura_lily_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,4,16],"fx":"crop","crop":"aura_lily","age":1,"seed":"aura_lily","bean":null,"soil":"minecraft:farmland","n":"Aura Lily Crop (age 1)"},
{"id":"aura_lily_crop_age2","m":"dbr:rpg/block/aura_lily_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,6,16],"fx":"crop","crop":"aura_lily","age":2,"seed":"aura_lily","bean":null,"soil":"minecraft:farmland","n":"Aura Lily Crop (age 2)"},
{"id":"aura_lily_crop_age3","m":"dbr:rpg/block/aura_lily_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,8,16],"fx":"crop","crop":"aura_lily","age":3,"seed":"aura_lily","bean":null,"soil":"minecraft:farmland","n":"Aura Lily Crop (age 3)"},
{"id":"aura_lily_crop_age4","m":"dbr:rpg/block/aura_lily_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,10,16],"fx":"crop","crop":"aura_lily","age":4,"seed":"aura_lily","bean":null,"soil":"minecraft:farmland","n":"Aura Lily Crop (age 4)"},
{"id":"aura_lily_crop_age5","m":"dbr:rpg/block/aura_lily_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,12,16],"fx":"crop","crop":"aura_lily","age":5,"seed":"aura_lily","bean":null,"soil":"minecraft:farmland","n":"Aura Lily Crop (age 5)"},
{"id":"aura_lily_crop_age6","m":"dbr:rpg/block/aura_lily_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,14,16],"fx":"crop","crop":"aura_lily","age":6,"seed":"aura_lily","bean":null,"soil":"minecraft:farmland","n":"Aura Lily Crop (age 6)"},
{"id":"aura_lily_crop_age7","m":"dbr:rpg/block/aura_lily_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,16,16],"fx":"crop","crop":"aura_lily","age":7,"seed":"aura_lily","bean":null,"soil":"minecraft:farmland","n":"Aura Lily Crop (age 7)"},
{"id":"hermit_fern_crop","m":"dbr:rpg/block/hermit_fern_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,2,16],"fx":"crop","crop":"hermit_fern","age":0,"seed":"hermit_fern","bean":null,"soil":"minecraft:farmland","n":"Hermit's Fern Crop"},
{"id":"hermit_fern_crop_age1","m":"dbr:rpg/block/hermit_fern_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,4,16],"fx":"crop","crop":"hermit_fern","age":1,"seed":"hermit_fern","bean":null,"soil":"minecraft:farmland","n":"Hermit's Fern Crop (age 1)"},
{"id":"hermit_fern_crop_age2","m":"dbr:rpg/block/hermit_fern_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,6,16],"fx":"crop","crop":"hermit_fern","age":2,"seed":"hermit_fern","bean":null,"soil":"minecraft:farmland","n":"Hermit's Fern Crop (age 2)"},
{"id":"hermit_fern_crop_age3","m":"dbr:rpg/block/hermit_fern_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,8,16],"fx":"crop","crop":"hermit_fern","age":3,"seed":"hermit_fern","bean":null,"soil":"minecraft:farmland","n":"Hermit's Fern Crop (age 3)"},
{"id":"hermit_fern_crop_age4","m":"dbr:rpg/block/hermit_fern_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,10,16],"fx":"crop","crop":"hermit_fern","age":4,"seed":"hermit_fern","bean":null,"soil":"minecraft:farmland","n":"Hermit's Fern Crop (age 4)"},
{"id":"hermit_fern_crop_age5","m":"dbr:rpg/block/hermit_fern_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,12,16],"fx":"crop","crop":"hermit_fern","age":5,"seed":"hermit_fern","bean":null,"soil":"minecraft:farmland","n":"Hermit's Fern Crop (age 5)"},
{"id":"hermit_fern_crop_age6","m":"dbr:rpg/block/hermit_fern_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,14,16],"fx":"crop","crop":"hermit_fern","age":6,"seed":"hermit_fern","bean":null,"soil":"minecraft:farmland","n":"Hermit's Fern Crop (age 6)"},
{"id":"hermit_fern_crop_age7","m":"dbr:rpg/block/hermit_fern_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,16,16],"fx":"crop","crop":"hermit_fern","age":7,"seed":"hermit_fern","bean":null,"soil":"minecraft:farmland","n":"Hermit's Fern Crop (age 7)"},
{"id":"kaioshin_fruit_crop","m":"dbr:rpg/block/kaioshin_fruit_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,2,16],"fx":"crop","crop":"kaioshin_fruit","age":0,"seed":"kaioshin_fruit","bean":null,"soil":"minecraft:farmland","n":"Kaioshin Fruit Crop"},
{"id":"kaioshin_fruit_crop_age1","m":"dbr:rpg/block/kaioshin_fruit_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,4,16],"fx":"crop","crop":"kaioshin_fruit","age":1,"seed":"kaioshin_fruit","bean":null,"soil":"minecraft:farmland","n":"Kaioshin Fruit Crop (age 1)"},
{"id":"kaioshin_fruit_crop_age2","m":"dbr:rpg/block/kaioshin_fruit_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,6,16],"fx":"crop","crop":"kaioshin_fruit","age":2,"seed":"kaioshin_fruit","bean":null,"soil":"minecraft:farmland","n":"Kaioshin Fruit Crop (age 2)"},
{"id":"kaioshin_fruit_crop_age3","m":"dbr:rpg/block/kaioshin_fruit_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,8,16],"fx":"crop","crop":"kaioshin_fruit","age":3,"seed":"kaioshin_fruit","bean":null,"soil":"minecraft:farmland","n":"Kaioshin Fruit Crop (age 3)"},
{"id":"kaioshin_fruit_crop_age4","m":"dbr:rpg/block/kaioshin_fruit_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,10,16],"fx":"crop","crop":"kaioshin_fruit","age":4,"seed":"kaioshin_fruit","bean":null,"soil":"minecraft:farmland","n":"Kaioshin Fruit Crop (age 4)"},
{"id":"kaioshin_fruit_crop_age5","m":"dbr:rpg/block/kaioshin_fruit_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,12,16],"fx":"crop","crop":"kaioshin_fruit","age":5,"seed":"kaioshin_fruit","bean":null,"soil":"minecraft:farmland","n":"Kaioshin Fruit Crop (age 5)"},
{"id":"kaioshin_fruit_crop_age6","m":"dbr:rpg/block/kaioshin_fruit_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,14,16],"fx":"crop","crop":"kaioshin_fruit","age":6,"seed":"kaioshin_fruit","bean":null,"soil":"minecraft:farmland","n":"Kaioshin Fruit Crop (age 6)"},
{"id":"kaioshin_fruit_crop_age7","m":"dbr:rpg/block/kaioshin_fruit_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,16,16],"fx":"crop","crop":"kaioshin_fruit","age":7,"seed":"kaioshin_fruit","bean":null,"soil":"minecraft:farmland","n":"Kaioshin Fruit Crop (age 7)"},
{"id":"zenkai_lotus_crop","m":"dbr:rpg/block/zenkai_lotus_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,2,16],"fx":"crop","crop":"zenkai_lotus","age":0,"seed":"zenkai_lotus","bean":null,"soil":"minecraft:farmland","n":"Zenkai Lotus Crop"},
{"id":"zenkai_lotus_crop_age1","m":"dbr:rpg/block/zenkai_lotus_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,4,16],"fx":"crop","crop":"zenkai_lotus","age":1,"seed":"zenkai_lotus","bean":null,"soil":"minecraft:farmland","n":"Zenkai Lotus Crop (age 1)"},
{"id":"zenkai_lotus_crop_age2","m":"dbr:rpg/block/zenkai_lotus_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,6,16],"fx":"crop","crop":"zenkai_lotus","age":2,"seed":"zenkai_lotus","bean":null,"soil":"minecraft:farmland","n":"Zenkai Lotus Crop (age 2)"},
{"id":"zenkai_lotus_crop_age3","m":"dbr:rpg/block/zenkai_lotus_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,8,16],"fx":"crop","crop":"zenkai_lotus","age":3,"seed":"zenkai_lotus","bean":null,"soil":"minecraft:farmland","n":"Zenkai Lotus Crop (age 3)"},
{"id":"zenkai_lotus_crop_age4","m":"dbr:rpg/block/zenkai_lotus_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,10,16],"fx":"crop","crop":"zenkai_lotus","age":4,"seed":"zenkai_lotus","bean":null,"soil":"minecraft:farmland","n":"Zenkai Lotus Crop (age 4)"},
{"id":"zenkai_lotus_crop_age5","m":"dbr:rpg/block/zenkai_lotus_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,12,16],"fx":"crop","crop":"zenkai_lotus","age":5,"seed":"zenkai_lotus","bean":null,"soil":"minecraft:farmland","n":"Zenkai Lotus Crop (age 5)"},
{"id":"zenkai_lotus_crop_age6","m":"dbr:rpg/block/zenkai_lotus_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,14,16],"fx":"crop","crop":"zenkai_lotus","age":6,"seed":"zenkai_lotus","bean":null,"soil":"minecraft:farmland","n":"Zenkai Lotus Crop (age 6)"},
{"id":"zenkai_lotus_crop_age7","m":"dbr:rpg/block/zenkai_lotus_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,16,16],"fx":"crop","crop":"zenkai_lotus","age":7,"seed":"zenkai_lotus","bean":null,"soil":"minecraft:farmland","n":"Zenkai Lotus Crop (age 7)"},
{"id":"namek_moss_crop","m":"dbr:rpg/block/namek_moss_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,2,16],"fx":"crop","crop":"namek_moss","age":0,"seed":"namek_moss","bean":null,"soil":"namek_grass_block","n":"Namek Moss Crop"},
{"id":"namek_moss_crop_age1","m":"dbr:rpg/block/namek_moss_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,4,16],"fx":"crop","crop":"namek_moss","age":1,"seed":"namek_moss","bean":null,"soil":"namek_grass_block","n":"Namek Moss Crop (age 1)"},
{"id":"namek_moss_crop_age2","m":"dbr:rpg/block/namek_moss_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,6,16],"fx":"crop","crop":"namek_moss","age":2,"seed":"namek_moss","bean":null,"soil":"namek_grass_block","n":"Namek Moss Crop (age 2)"},
{"id":"namek_moss_crop_age3","m":"dbr:rpg/block/namek_moss_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,8,16],"fx":"crop","crop":"namek_moss","age":3,"seed":"namek_moss","bean":null,"soil":"namek_grass_block","n":"Namek Moss Crop (age 3)"},
{"id":"namek_moss_crop_age4","m":"dbr:rpg/block/namek_moss_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,10,16],"fx":"crop","crop":"namek_moss","age":4,"seed":"namek_moss","bean":null,"soil":"namek_grass_block","n":"Namek Moss Crop (age 4)"},
{"id":"namek_moss_crop_age5","m":"dbr:rpg/block/namek_moss_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,12,16],"fx":"crop","crop":"namek_moss","age":5,"seed":"namek_moss","bean":null,"soil":"namek_grass_block","n":"Namek Moss Crop (age 5)"},
{"id":"namek_moss_crop_age6","m":"dbr:rpg/block/namek_moss_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,14,16],"fx":"crop","crop":"namek_moss","age":6,"seed":"namek_moss","bean":null,"soil":"namek_grass_block","n":"Namek Moss Crop (age 6)"},
{"id":"namek_moss_crop_age7","m":"dbr:rpg/block/namek_moss_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,16,16],"fx":"crop","crop":"namek_moss","age":7,"seed":"namek_moss","bean":null,"soil":"namek_grass_block","n":"Namek Moss Crop (age 7)"},
{"id":"senzu_blue_crop","m":"dbr:rpg/block/senzu_blue_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,2,16],"fx":"crop","crop":"senzu_blue","age":0,"seed":"senzu_bean_seeds_blue","bean":"senzu_bean_blue","soil":"minecraft:farmland","n":"Senzu Bean Crop (&bKi&r)"},
{"id":"senzu_blue_crop_age1","m":"dbr:rpg/block/senzu_blue_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,4,16],"fx":"crop","crop":"senzu_blue","age":1,"seed":"senzu_bean_seeds_blue","bean":"senzu_bean_blue","soil":"minecraft:farmland","n":"Senzu Bean Crop (&bKi&r) (age 1)"},
{"id":"senzu_blue_crop_age2","m":"dbr:rpg/block/senzu_blue_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,6,16],"fx":"crop","crop":"senzu_blue","age":2,"seed":"senzu_bean_seeds_blue","bean":"senzu_bean_blue","soil":"minecraft:farmland","n":"Senzu Bean Crop (&bKi&r) (age 2)"},
{"id":"senzu_blue_crop_age3","m":"dbr:rpg/block/senzu_blue_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,8,16],"fx":"crop","crop":"senzu_blue","age":3,"seed":"senzu_bean_seeds_blue","bean":"senzu_bean_blue","soil":"minecraft:farmland","n":"Senzu Bean Crop (&bKi&r) (age 3)"},
{"id":"senzu_blue_crop_age4","m":"dbr:rpg/block/senzu_blue_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,10,16],"fx":"crop","crop":"senzu_blue","age":4,"seed":"senzu_bean_seeds_blue","bean":"senzu_bean_blue","soil":"minecraft:farmland","n":"Senzu Bean Crop (&bKi&r) (age 4)"},
{"id":"senzu_blue_crop_age5","m":"dbr:rpg/block/senzu_blue_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,12,16],"fx":"crop","crop":"senzu_blue","age":5,"seed":"senzu_bean_seeds_blue","bean":"senzu_bean_blue","soil":"minecraft:farmland","n":"Senzu Bean Crop (&bKi&r) (age 5)"},
{"id":"senzu_blue_crop_age6","m":"dbr:rpg/block/senzu_blue_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,14,16],"fx":"crop","crop":"senzu_blue","age":6,"seed":"senzu_bean_seeds_blue","bean":"senzu_bean_blue","soil":"minecraft:farmland","n":"Senzu Bean Crop (&bKi&r) (age 6)"},
{"id":"senzu_blue_crop_age7","m":"dbr:rpg/block/senzu_blue_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,16,16],"fx":"crop","crop":"senzu_blue","age":7,"seed":"senzu_bean_seeds_blue","bean":"senzu_bean_blue","soil":"minecraft:farmland","n":"Senzu Bean Crop (&bKi&r) (age 7)"},
{"id":"senzu_red_crop","m":"dbr:rpg/block/senzu_red_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,2,16],"fx":"crop","crop":"senzu_red","age":0,"seed":"senzu_bean_seeds_red","bean":"senzu_bean_red","soil":"minecraft:farmland","n":"Senzu Bean Crop (&cHealth&r)"},
{"id":"senzu_red_crop_age1","m":"dbr:rpg/block/senzu_red_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,4,16],"fx":"crop","crop":"senzu_red","age":1,"seed":"senzu_bean_seeds_red","bean":"senzu_bean_red","soil":"minecraft:farmland","n":"Senzu Bean Crop (&cHealth&r) (age 1)"},
{"id":"senzu_red_crop_age2","m":"dbr:rpg/block/senzu_red_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,6,16],"fx":"crop","crop":"senzu_red","age":2,"seed":"senzu_bean_seeds_red","bean":"senzu_bean_red","soil":"minecraft:farmland","n":"Senzu Bean Crop (&cHealth&r) (age 2)"},
{"id":"senzu_red_crop_age3","m":"dbr:rpg/block/senzu_red_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,8,16],"fx":"crop","crop":"senzu_red","age":3,"seed":"senzu_bean_seeds_red","bean":"senzu_bean_red","soil":"minecraft:farmland","n":"Senzu Bean Crop (&cHealth&r) (age 3)"},
{"id":"senzu_red_crop_age4","m":"dbr:rpg/block/senzu_red_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,10,16],"fx":"crop","crop":"senzu_red","age":4,"seed":"senzu_bean_seeds_red","bean":"senzu_bean_red","soil":"minecraft:farmland","n":"Senzu Bean Crop (&cHealth&r) (age 4)"},
{"id":"senzu_red_crop_age5","m":"dbr:rpg/block/senzu_red_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,12,16],"fx":"crop","crop":"senzu_red","age":5,"seed":"senzu_bean_seeds_red","bean":"senzu_bean_red","soil":"minecraft:farmland","n":"Senzu Bean Crop (&cHealth&r) (age 5)"},
{"id":"senzu_red_crop_age6","m":"dbr:rpg/block/senzu_red_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,14,16],"fx":"crop","crop":"senzu_red","age":6,"seed":"senzu_bean_seeds_red","bean":"senzu_bean_red","soil":"minecraft:farmland","n":"Senzu Bean Crop (&cHealth&r) (age 6)"},
{"id":"senzu_red_crop_age7","m":"dbr:rpg/block/senzu_red_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,16,16],"fx":"crop","crop":"senzu_red","age":7,"seed":"senzu_bean_seeds_red","bean":"senzu_bean_red","soil":"minecraft:farmland","n":"Senzu Bean Crop (&cHealth&r) (age 7)"},
{"id":"senzu_yellow_crop","m":"dbr:rpg/block/senzu_yellow_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,2,16],"fx":"crop","crop":"senzu_yellow","age":0,"seed":"senzu_bean_seeds_yellow","bean":"senzu_bean_yellow","soil":"minecraft:farmland","n":"Senzu Bean Crop (&eStamina&r)"},
{"id":"senzu_yellow_crop_age1","m":"dbr:rpg/block/senzu_yellow_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,4,16],"fx":"crop","crop":"senzu_yellow","age":1,"seed":"senzu_bean_seeds_yellow","bean":"senzu_bean_yellow","soil":"minecraft:farmland","n":"Senzu Bean Crop (&eStamina&r) (age 1)"},
{"id":"senzu_yellow_crop_age2","m":"dbr:rpg/block/senzu_yellow_crop_stage0","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,6,16],"fx":"crop","crop":"senzu_yellow","age":2,"seed":"senzu_bean_seeds_yellow","bean":"senzu_bean_yellow","soil":"minecraft:farmland","n":"Senzu Bean Crop (&eStamina&r) (age 2)"},
{"id":"senzu_yellow_crop_age3","m":"dbr:rpg/block/senzu_yellow_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,8,16],"fx":"crop","crop":"senzu_yellow","age":3,"seed":"senzu_bean_seeds_yellow","bean":"senzu_bean_yellow","soil":"minecraft:farmland","n":"Senzu Bean Crop (&eStamina&r) (age 3)"},
{"id":"senzu_yellow_crop_age4","m":"dbr:rpg/block/senzu_yellow_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,10,16],"fx":"crop","crop":"senzu_yellow","age":4,"seed":"senzu_bean_seeds_yellow","bean":"senzu_bean_yellow","soil":"minecraft:farmland","n":"Senzu Bean Crop (&eStamina&r) (age 4)"},
{"id":"senzu_yellow_crop_age5","m":"dbr:rpg/block/senzu_yellow_crop_stage1","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,12,16],"fx":"crop","crop":"senzu_yellow","age":5,"seed":"senzu_bean_seeds_yellow","bean":"senzu_bean_yellow","soil":"minecraft:farmland","n":"Senzu Bean Crop (&eStamina&r) (age 5)"},
{"id":"senzu_yellow_crop_age6","m":"dbr:rpg/block/senzu_yellow_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,14,16],"fx":"crop","crop":"senzu_yellow","age":6,"seed":"senzu_bean_seeds_yellow","bean":"senzu_bean_yellow","soil":"minecraft:farmland","n":"Senzu Bean Crop (&eStamina&r) (age 6)"},
{"id":"senzu_yellow_crop_age7","m":"dbr:rpg/block/senzu_yellow_crop_stage2","h":0,"decor":true,"collision":false,"shape":[0,0,0,16,16,16],"fx":"crop","crop":"senzu_yellow","age":7,"seed":"senzu_bean_seeds_yellow","bean":"senzu_bean_yellow","soil":"minecraft:farmland","n":"Senzu Bean Crop (&eStamina&r) (age 7)"},
{"id":"healing_liquid_block","m":"dbr:rpg/block/healing_liquid_block","h":100,"decor":true,"collision":false,"light":5,"color":"#A4C977","drop":"none","fx":"liquid","n":"Healing Liquid"},
{"id":"namek_water_liquid_block","m":"dbr:rpg/block/namek_water_liquid_block","h":100,"decor":true,"collision":false,"light":5,"color":"#AEF359","drop":"none","fx":"liquid","n":"Namek Water"}
];

// =====================================================================================
//  Shared block helpers (55_blocks.js and 85_world.js use block() / blockRef() too)
// =====================================================================================
var BLOCK_IDS = {};                 // script name -> placeholder id ("block_0150")
var DMZ_BLOCK = {};                 // DMZ id -> spec (DMZ_BLOCK_SPECS entry)
function block(name, def) {
    BLOCK_IDS[name] = RPG.blocks.define(name, def);
    return BLOCK_IDS[name];
}
function blockRef(name) { return BLOCK_IDS[name] ? "ragnarok_rpg:" + BLOCK_IDS[name] : null; }
/** Script name of a full block id ("ragnarok_rpg:block_0150" -> "namek_stone"), or null. */
var DMZ_BLOCK_BY_REF = {};
function dmzBlockAt(dim, x, y, z) { return DMZ_BLOCK_BY_REF[RPG.world.getBlock(dim, x, y, z)] || null; }
/** The facing of the block at a spot ("north"...), or null. */
function dmzFacingAt(dim, x, y, z) { let m = String(RPG.world.getBlockState(dim, x, y, z)).match(/facing=(\w+)/); return m ? m[1] : null; }
/** Sets a DMZ block; keeps the facing of what was there (doors, gates, trapdoors swap blocks) unless one is given. */
function dmzSet(dim, x, y, z, name, facing) {
    let id = name.indexOf(":") >= 0 ? name : blockRef(name);
    if (!id) return;
    let f = facing || dmzFacingAt(dim, x, y, z);
    if (f && id.indexOf("ragnarok_rpg:") === 0 && id.indexOf("[") < 0) id += "[facing=" + f + "]";
    RPG.world.setBlock(dim, x, y, z, id);
}
function dmzCreative(player) { return String(player.getGameMode()) === "creative"; }
function dmzRand(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }

// ---- the tool in hand: kind, tier, Silk Touch, Fortune --------------------------------------
var DMZ_TIERS = { wooden: 0, golden: 0, stone: 1, iron: 2, diamond: 3, netherite: 4 };
var DMZ_GETE_TOOL_IDS = null;       // full item ids of the Gete tools (tier above netherite), resolved lazily
function dmzHeldTool(player) {
    let id = String(player.getHeldItem());
    let tool = { id: id, kind: null, tier: -1, silk: false, fortune: 0 };
    if (!DMZ_GETE_TOOL_IDS) {
        DMZ_GETE_TOOL_IDS = {};
        ["pickaxe", "axe", "shovel", "hoe"].forEach((k) => { let i = RPG.items.id("gete_" + k); if (i) DMZ_GETE_TOOL_IDS["ragnarok_rpg:" + i] = k; });
    }
    let m = id.match(/^minecraft:(wooden|golden|stone|iron|diamond|netherite)_(pickaxe|axe|shovel|hoe|sword)$/);
    if (m) { tool.kind = m[2]; tool.tier = DMZ_TIERS[m[1]]; }
    else if (DMZ_GETE_TOOL_IDS[id]) { tool.kind = DMZ_GETE_TOOL_IDS[id]; tool.tier = 5; }
    else if (id === "minecraft:shears") tool.kind = "shears";
    let st = player.getHeldStack();
    let nbt = st && st.nbt ? String(st.nbt) : "";
    if (nbt.indexOf("minecraft:silk_touch") >= 0) tool.silk = true;
    let f = nbt.match(/minecraft:fortune"\s*,\s*lvl:\s*(\d+)/) || nbt.match(/lvl:\s*(\d+)s?\s*,\s*id:\s*"minecraft:fortune"/);
    if (f) tool.fortune = Number(f[1]);
    return tool;
}

// ---- DMZ's loot tables, worked out when the block breaks -------------------------------------
// (vanilla ApplyBonusCount.ore_drops for Fortune, Silk Touch dispatch, shears-only plants, leaves)
function dmzDrops(s, tool) {
    let self = blockRef(s.id), r = s.drop || "self", out = [], xp = 0;
    if (s.rt && !(tool.kind === s.tool && tool.tier >= (s.tier || 0))) return { items: out, xp: 0 };   // wrong tool: nothing
    if (r === "none") return { items: out, xp: 0 };
    if (r === "self") out.push([self, 1]);
    else if (r === "shears") { if (tool.kind === "shears" || tool.silk) out.push([self, 1]); }
    else if (r.silkElse) out.push(tool.silk ? [self, 1] : [r.silkElse, 1]);
    else if (r.pot) { out.push(["minecraft:flower_pot", 1]); out.push([r.pot, 1]); }
    else if (r.leaves) {
        if (tool.kind === "shears" || tool.silk) out.push([self, 1]);
        else {
            let sap = [0.05, 0.0625, 0.083333336, 0.1][Math.min(3, tool.fortune)];
            let stick = [0.02, 0.022222223, 0.025, 0.033333335, 0.1][Math.min(4, tool.fortune)];
            if (Math.random() < sap) out.push([r.leaves, 1]);
            if (Math.random() < stick) out.push(["minecraft:stick", dmzRand(1, 2)]);
        }
    }
    else if (r.other) {
        if (r.silk && tool.silk) out.push([self, 1]);
        else {
            let n = r.min ? dmzRand(r.min, r.max) : 1;
            if (r.fortune && tool.fortune > 0) n *= Math.max(0, dmzRand(0, tool.fortune + 1) - 1) + 1;
            out.push([r.other, n]);
            if (r.xp) xp = dmzRand(r.xp[0], r.xp[1]);
        }
    }
    return { items: out, xp: xp };
}
function dmzDropAt(dim, x, y, z, items, xp) {
    items.forEach((it) => { if (it[0] && it[1] > 0) RPG.world.dropItem(dim, x + 0.5, y + 0.5, z + 0.5, it[0], it[1]); });
    if (xp > 0) RPG.server.runCommand("execute in " + dim + " run summon minecraft:experience_orb " + (x + 0.5) + " " + (y + 0.5) + " " + (z + 0.5) + " {Value:" + xp + "}");
}
function dmzBreakLoot(s, player, x, y, z) {
    if (dmzCreative(player)) return;
    let res = dmzDrops(s, dmzHeldTool(player));
    dmzDropAt(player.dimension, x, y, z, res.items, res.xp);
}
/** Undo a placement that DMZ wouldn't allow (and hand the block back). */
function dmzRefusePlace(s, player, x, y, z, why) {
    RPG.world.setBlock(player.dimension, x, y, z, "minecraft:air");
    if (!dmzCreative(player)) player.giveItem(blockRef(s.id), 1);
    if (why) player.actionbar("&7" + why);
}
var DMZ_DIRT_LIKE = ["minecraft:dirt", "minecraft:grass_block", "minecraft:coarse_dirt", "minecraft:podzol", "minecraft:rooted_dirt", "minecraft:mud",
    "minecraft:moss_block", "minecraft:mycelium", "minecraft:muddy_mangrove_roots", "minecraft:farmland", "minecraft:sand", "minecraft:red_sand", "minecraft:suspicious_sand"];
var DMZ_DIRT_NAMES = ["namek_dirt", "namek_grass_block", "namek_sacred_grass_block", "rocky_dirt", "sacred_planet_grass_block", "makai_dirt", "makai_grass_block", "lilac_sand", "makai_sand"];
function dmzIsDirtOrSand(blockId) {
    if (DMZ_DIRT_LIKE.indexOf(blockId) >= 0) return true;
    let n = DMZ_BLOCK_BY_REF[blockId];
    return !!n && DMZ_DIRT_NAMES.indexOf(n) >= 0;
}

// ---- trees (vanilla StraightTrunkPlacer + BlobFoliagePlacer with DMZ's numbers) -------------
var DMZ_TREES = {
    namek_ajissa_sapling: { log: "namek_ajissa_log", leaves: "namek_ajissa_leaves", base: 14, a: 2, b: 0, radius: 2, offset: 0, height: 3 },
    namek_sacred_sapling: { log: "namek_sacred_log", leaves: "namek_sacred_leaves", base: 16, a: 2, b: 4, radius: 3, offset: 2, height: 3 }
};
function dmzGrowTree(dim, x, y, z, sapling) {
    let t = DMZ_TREES[sapling];
    let h = t.base + dmzRand(0, t.a) + dmzRand(0, t.b);
    for (let i = 1; i <= h + 1; i++) {
        let b = RPG.world.getBlock(dim, x, y + i, z);
        if (b !== "minecraft:air" && b !== blockRef(t.leaves)) return false;     // no room
    }
    dmzSet(dim, x, y - 1, z, "namek_dirt");
    for (let i = 0; i < h; i++) dmzSet(dim, x, y + i, z, t.log);
    let top = y + h;                                                        // foliage attachment
    for (let ly = t.offset; ly >= t.offset - t.height; ly--) {
        let r = Math.max(t.radius - 1 - Math.floor(ly / 2), 0);
        for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) {
            if (Math.abs(dx) === r && Math.abs(dz) === r && r > 0 && (Math.random() < 0.5 || ly === 0)) continue;
            let px = x + dx, py = top + ly, pz = z + dz;
            if (RPG.world.getBlock(dim, px, py, pz) === "minecraft:air") dmzSet(dim, px, py, pz, t.leaves);
        }
    }
    return true;
}

// ---- crops ---------------------------------------------------------------------------------
function dmzCropName(crop, age) { return crop + "_crop" + (age === 0 ? "" : "_age" + age); }
function dmzCropLoot(s, player, x, y, z) {
    if (dmzCreative(player)) return;
    let items = [];
    if (s.bean) { items.push([s.seed, 1]); if (s.age === 7) items.push([s.bean, 1]); }       // senzuCropDrop
    else { items.push([s.seed, 1]); if (s.age === 7) items.push([s.seed, 2]); }              // statCropDrop
    dmzDropAt(player.dimension, x, y, z, items, 0);
}
/** Seed / plant item -> crop, for planting by right-clicking farmland (or Namek grass for moss). */
var DMZ_PLANTABLE = {};

// ---- doors, gates, trapdoors, slabs --------------------------------------------------------
function dmzDoorUse(s, player, x, y, z) {
    let dim = player.dimension, by = s.half === "top" ? y - 1 : y, open = s.state === "open", f = dmzFacingAt(dim, x, by, z);
    dmzSet(dim, x, by, z, open ? s.door : s.door + "_open", f);
    dmzSet(dim, x, by + 1, z, open ? s.door + "_top" : s.door + "_top_open", f);
    RPG.world.sound(dim, open ? "minecraft:block.wooden_door.close" : "minecraft:block.wooden_door.open", x + 0.5, y + 0.5, z + 0.5, 1, 1);
}
function dmzDoorBreak(s, player, x, y, z) {
    let dim = player.dimension, other = s.half === "top" ? y - 1 : y + 1;
    let o = dmzBlockAt(dim, x, other, z);
    if (o && DMZ_BLOCK[o].door === s.door) RPG.world.setBlock(dim, x, other, z, "minecraft:air");
    if (!dmzCreative(player)) {
        let res = dmzDrops({ id: s.id, tool: s.tool, drop: { other: s.door } }, dmzHeldTool(player));
        dmzDropAt(dim, x, y, z, res.items, 0);
    }
}

// ---- per-player effects of blocks you stand in (no entityInside hook in the API) ------------
var DMZ_HEAL_TICK = {};
RPG.on("playerTick", (player) => {
    let dim = player.dimension, x = Math.floor(player.x), y = Math.floor(player.y), z = Math.floor(player.z);
    let feet = DMZ_BLOCK_BY_REF[RPG.world.getBlock(dim, x, y, z)];
    if (!feet) return;
    let flying = player.isFlying() || player.hasEffect("flight");
    if (feet === "otherworld_cloud") {                                // OtherworldCloudBlock: slows falls, no fall damage
        if (!flying) { if (player.vy < 0) player.setVelocity(player.vx, player.vy * 0.85, player.vz); player.fallDistance = 0; }
    } else if (feet === "invisible_ladder_block") {                   // climbable
        player.fallDistance = 0;
        if (player.isSneaking()) player.setVelocity(player.vx, 0, player.vz);
        else if (player.horizontalCollision) player.setVelocity(player.vx, 0.2, player.vz);
        else if (player.vy < -0.15) player.setVelocity(player.vx, -0.15, player.vz);
    } else if (feet === "dark_sea_cloud") {                           // DarkSeaCloudBlock
        if (player.invulnerableTime <= 0) {
            player.addPotion("minecraft:darkness", 80, 0);
            player.addPotion("minecraft:blindness", 40, 0);
            player.damage(Math.max(4, player.maxHealth * 0.25));
        }
    } else if (feet === "healing_liquid_block") {                     // every 3 s: +8 % HP, ki, stamina
        let now = RPG.server.getTick(), key = player.getUuid();
        if (now - (DMZ_HEAL_TICK[key] || 0) >= 60) {
            DMZ_HEAL_TICK[key] = now;
            player.heal(player.maxHealth * 0.08);
            ["ki", "stamina"].forEach((r) => player.addResource(r, player.maxResource(r) * 0.08));
        }
    } else if (feet === "namek_water_liquid_block") {
        player.setFire(0);
    }
});

// ---- right-clicking a block with an item (planting, flower pots) ----------------------------
var DMZ_POT_FOR = {};               // plant name -> potted block name
RPG.on("blockInteract", (player, blockId, x, y, z, dim) => {
    let held = String(player.getHeldItem());
    let heldName = DMZ_ITEM_BY_REF[held];
    if (!heldName) return;
    // plant seeds / stat plants on farmland (namek moss: on Namek grass)
    let crop = DMZ_PLANTABLE[heldName];
    if (crop) {
        let soil = crop === "namek_moss" ? blockRef("namek_grass_block") : "minecraft:farmland";
        if (blockId === soil && RPG.world.getBlock(dim, x, y + 1, z) === "minecraft:air") {
            dmzSet(dim, x, y + 1, z, dmzCropName(crop, 0));
            if (!dmzCreative(player)) player.takeItem(held, 1);
            RPG.world.sound(dim, "minecraft:item.crop.plant", x + 0.5, y + 1, z + 0.5, 1, 1);
            return false;
        }
    }
    // put a DMZ plant into an empty flower pot
    if (blockId === "minecraft:flower_pot" && DMZ_POT_FOR[heldName]) {
        dmzSet(dim, x, y, z, DMZ_POT_FOR[heldName]);
        if (!dmzCreative(player)) player.takeItem(held, 1);
        return false;
    }
});
var DMZ_ITEM_BY_REF = {};           // full item id -> DMZ name (blocks here; items are added by 16_dmz_items.js)

// =====================================================================================
//  Define every DMZ block from the table
// =====================================================================================
function dmzBlockDef(s) {
    let def = { name: s.n, model: s.m, hardness: s.h };
    if (s.im) def.itemModel = s.im;              // DMZ's own inventory icon
    if (s.light) def.light = s.light;
    if (s.shape) def.shape = s.shape;
    if (s.collision === false) def.collision = false;
    if (s.decor || s.shape) def.decor = true;
    if (s.color) def.color = s.color;
    if (s.rt) def.requiresTool = true;
    if (s.num) def.key = s.id;                   // numbered slot: keep the DMZ name as its alias
    def.drops = "none";                          // drops are DMZ's loot tables, worked out in onBreak
    // which way it faces when placed (the engine turns the model and shape)
    let id = s.id;
    // stairs and doors use vanilla's east-facing models; gates, trapdoors, ladders and machines face you
    if (/_stairs$/.test(id)) { def.rotation = "vanilla"; def.shape = [[0, 0, 0, 16, 8, 16], [8, 8, 0, 16, 16, 16]]; def.decor = true; }
    else if (/_door(_top)?(_open)?$/.test(id)) def.rotation = "vanilla";
    else if (/_trapdoor|_fence_gate|ladder|_station|_generator|gravity_device|punch_machine/.test(id)) def.rotation = "horizontal";
    let fx = s.fx || "";
    if (s.h >= 0) def.onBreak = (player, x, y, z) => dmzBreakLoot(s, player, x, y, z);

    if (fx === "crop") {
        def.onBreak = (player, x, y, z) => dmzCropLoot(s, player, x, y, z);
        if (s.age < 7) def.onRandomTick = (dim, x, y, z) => {
            // StatCropBlock: chance 1 / (int(3 * 25 / growthSpeed) + 1); growthSpeed of a crop on moist farmland = 4
            if (Math.random() < 1 / 19) dmzSet(dim, x, y, z, dmzCropName(s.crop, s.age + 1));
        };
        def.onUse = (player, x, y, z) => {
            if (String(player.getHeldItem()) !== "minecraft:bone_meal" || s.age >= 7) return;
            if (!dmzCreative(player)) player.takeItem("minecraft:bone_meal", 1);
            RPG.world.particle(player.dimension, "minecraft:happy_villager", x + 0.5, y + 0.5, z + 0.5, 8, 0.3, 0);
            if (Math.random() < 0.25) dmzSet(player.dimension, x, y, z, dmzCropName(s.crop, s.age + 1));
        };
        def.onPlace = (player, x, y, z) => {
            let below = RPG.world.getBlock(player.dimension, x, y - 1, z);
            let soil = s.soil.indexOf(":") >= 0 ? s.soil : blockRef(s.soil);
            if (below !== soil) dmzRefusePlace(s, player, x, y, z);
        };
    } else if (fx === "door") {
        def.onUse = (player, x, y, z) => dmzDoorUse(s, player, x, y, z);
        def.onBreak = (player, x, y, z) => dmzDoorBreak(s, player, x, y, z);
        if (s.half === "bottom" && s.state === "closed") def.onPlace = (player, x, y, z) => {
            if (RPG.world.getBlock(player.dimension, x, y + 1, z) !== "minecraft:air") return dmzRefusePlace(s, player, x, y, z);
            dmzSet(player.dimension, x, y + 1, z, s.door + "_top", dmzFacingAt(player.dimension, x, y, z));
        };
    } else if (fx === "toggle") {
        def.onUse = (player, x, y, z) => {
            dmzSet(player.dimension, x, y, z, s.other);
            let gate = s.id.indexOf("gate") >= 0, opening = s.id.indexOf("_open") < 0;
            RPG.world.sound(player.dimension, "minecraft:block." + (gate ? "fence_gate" : "wooden_trapdoor") + (opening ? ".open" : ".close"), x + 0.5, y + 0.5, z + 0.5, 1, 1);
        };
    } else if (fx === "button") {
        def.onUse = (player, x, y, z) => RPG.world.sound(player.dimension, "minecraft:block.wooden_button.click_on", x + 0.5, y + 0.5, z + 0.5, 0.3, 0.6);
    } else if (fx === "slab") {
        def.onUse = (player, x, y, z) => {                         // a second slab makes a double slab
            if (String(player.getHeldItem()) !== blockRef(s.id)) return;
            dmzSet(player.dimension, x, y, z, s.id + "_double");
            if (!dmzCreative(player)) player.takeItem(blockRef(s.id), 1);
            RPG.world.sound(player.dimension, "minecraft:block.stone.place", x + 0.5, y + 0.5, z + 0.5, 1, 1);
        };
    } else if (fx === "strip") {
        def.onUse = (player, x, y, z) => {
            if (dmzHeldTool(player).kind !== "axe") return;
            dmzSet(player.dimension, x, y, z, s.strip);
            RPG.world.sound(player.dimension, "minecraft:item.axe.strip", x + 0.5, y + 0.5, z + 0.5, 1, 1);
        };
    } else if (fx === "sapling") {
        let grow = (dim, x, y, z) => dmzGrowTree(dim, x, y, z, s.id);
        def.onRandomTick = (dim, x, y, z) => { if (Math.random() < 1 / 14) grow(dim, x, y, z); };   // 2 sapling stages at 1/7
        def.onUse = (player, x, y, z) => {
            if (String(player.getHeldItem()) !== "minecraft:bone_meal") return;
            if (!dmzCreative(player)) player.takeItem("minecraft:bone_meal", 1);
            RPG.world.particle(player.dimension, "minecraft:happy_villager", x + 0.5, y + 0.5, z + 0.5, 8, 0.3, 0);
            if (Math.random() < 0.45 * 0.5) grow(player.dimension, x, y, z);
        };
        def.onPlace = (player, x, y, z) => { if (!dmzIsDirtOrSand(RPG.world.getBlock(player.dimension, x, y - 1, z))) dmzRefusePlace(s, player, x, y, z); };
    } else if (fx === "plant") {                                   // NamekPlantsBlock: only on Namek grass
        def.onPlace = (player, x, y, z) => {
            let below = RPG.world.getBlock(player.dimension, x, y - 1, z);
            if (below !== blockRef("namek_grass_block") && below !== blockRef("namek_sacred_grass_block")) dmzRefusePlace(s, player, x, y, z, "It only grows on Namekian grass.");
        };
    } else if (fx === "plant_any") {                               // MakaiShrubBlock: dirt or sand
        def.onPlace = (player, x, y, z) => { if (!dmzIsDirtOrSand(RPG.world.getBlock(player.dimension, x, y - 1, z))) dmzRefusePlace(s, player, x, y, z); };
    } else if (fx === "pot") {
        def.onUse = (player, x, y, z) => {                         // empty-handed: take the plant out
            if (String(player.getHeldItem()) !== "minecraft:air") return;
            player.giveItem(s.drop.pot, 1);
            RPG.world.setBlock(player.dimension, x, y, z, "minecraft:flower_pot");
        };
    } else if (fx === "grass") {
        let dirt = s.drop.silkElse;
        def.onRandomTick = (dim, x, y, z) => {                     // spreads onto its dirt (no light check: engine gap)
            for (let i = 0; i < 4; i++) {
                let tx = x + dmzRand(-1, 1), ty = y + dmzRand(-1, 1), tz = z + dmzRand(-1, 1);
                if (dmzBlockAt(dim, tx, ty, tz) === dirt && RPG.world.getBlock(dim, tx, ty + 1, tz) === "minecraft:air") dmzSet(dim, tx, ty, tz, s.id);
            }
        };
        def.onUse = (player, x, y, z) => {                         // bone meal: grass, ferns and flowers around
            if (String(player.getHeldItem()) !== "minecraft:bone_meal") return;
            if (!dmzCreative(player)) player.takeItem("minecraft:bone_meal", 1);
            let dim = player.dimension;
            for (let i = 0; i < 128; i++) {
                let tx = x + dmzRand(-1, 1) * dmzRand(1, 3), ty = y + 1 + Math.floor((dmzRand(0, 2) - 1) * dmzRand(0, 2) / 2), tz = z + dmzRand(-1, 1) * dmzRand(1, 3);
                if (RPG.world.getBlock(dim, tx, ty, tz) !== "minecraft:air" || dmzBlockAt(dim, tx, ty - 1, tz) !== s.id) continue;
                let r = Math.random(), plantId;
                if (s.id === "sacred_planet_grass_block") plantId = r < 0.7 ? "minecraft:grass" : ["minecraft:dandelion", "minecraft:poppy", "minecraft:azure_bluet", "minecraft:oxeye_daisy"][dmzRand(0, 3)];
                else if (s.id === "namek_grass_block") plantId = r < 0.7 ? "namek_grass" : Math.random() < 0.9 ? "namek_fern" : ["catharanthus_roseus_flower", "amaryllis_flower", "marigold_flower", "trillium_flower", "chrysanthemum_flower"][dmzRand(0, 4)];
                else plantId = r < 0.7 ? "namek_sacred_grass" : Math.random() < 0.9 ? "sacred_fern" : ["sacred_catharanthus_roseus_flower", "sacred_amaryllis_flower", "sacred_marigold_flower", "sacred_trillium_flower", "sacred_chrysanthemum_flower"][dmzRand(0, 4)];
                dmzSet(dim, tx, ty, tz, plantId);
            }
            RPG.world.particle(dim, "minecraft:happy_villager", x + 0.5, y + 1.2, z + 0.5, 15, 1.5, 0);
        };
    } else if (fx === "till") {                                    // SkylitSoilBlock: hoe turns it into farmland
        def.onUse = (player, x, y, z) => {
            if (dmzHeldTool(player).kind !== "hoe") return;
            if (RPG.world.getBlock(player.dimension, x, y + 1, z) !== "minecraft:air") return;
            RPG.world.setBlock(player.dimension, x, y, z, "minecraft:farmland");
            RPG.world.sound(player.dimension, "minecraft:item.hoe.till", x + 0.5, y + 1, z + 0.5, 1, 1);
        };
    } else if (fx === "falling") {                                 // SandBlock: falls when placed over air
        def.onPlace = (player, x, y, z) => {
            if (RPG.world.getBlock(player.dimension, x, y - 1, z) !== "minecraft:air") return;
            RPG.world.setBlock(player.dimension, x, y, z, "minecraft:air");
            RPG.server.runCommand("execute in " + player.dimension + " run summon minecraft:falling_block " + (x + 0.5) + " " + y + " " + (z + 0.5) +
                " {BlockState:{Name:\"" + blockRef(s.id) + "\"},Time:1}");
        };
    } else if (fx === "magma") {                                   // MagmaBlock: hurts whoever walks on it (not sneaking)
        def.onStep = (entity, x, y, z) => { if (!entity.isSneaking()) entity.damage(1); };
    } else if (fx === "htc_portal") {
        def.onUse = (player, x, y, z) => dmzTimeChamberPortal(player);
    } else if (fx === "liquid") {
        def.onUse = (player, x, y, z) => {                         // scoop it back up with an empty bucket
            if (String(player.getHeldItem()) !== "minecraft:bucket") return;
            if (!dmzCreative(player)) { player.takeItem("minecraft:bucket", 1); player.giveItem(s.id === "healing_liquid_block" ? "healing_liquid_bucket" : "namek_water_bucket", 1); }
            RPG.world.setBlock(player.dimension, x, y, z, "minecraft:air");
            RPG.world.sound(player.dimension, "minecraft:item.bucket.fill", x + 0.5, y + 0.5, z + 0.5, 1, 1);
        };
    } else if (fx === "kikono_station") {
        def.onUse = (player, x, y, z) => { if (typeof dmzOpenKikonoStation === "function") dmzOpenKikonoStation(player, x, y, z); };
    } else if (fx === "pattern_station") {
        def.onUse = (player, x, y, z) => { if (typeof dmzOpenPatternStation === "function") dmzOpenPatternStation(player); };
    } else if (fx === "machine") {
        def.onUse = (player, x, y, z) => player.actionbar("&7" + s.n + ": &8(machine logic not available in this engine yet)");
    }
    // machines: screens, state, drops (58_dmz_machines.js)
    if (fx === "kikono_station" || fx === "pattern_station" || fx === "machine") {
        let oldUse = def.onUse, loot = def.onBreak;
        def.onUse = (player, x, y, z) => { if (typeof dmzMachineUse === "function") dmzMachineUse(s.id, player, x, y, z); else if (oldUse) oldUse(player, x, y, z); };
        def.onPlace = (player, x, y, z) => { if (typeof dmzMachinePlaced === "function") dmzMachinePlaced(s.id, player, x, y, z); };
        def.onBreak = (player, x, y, z) => { if (typeof dmzMachineBroken === "function") dmzMachineBroken(s.id, player, x, y, z); if (loot) loot(player, x, y, z); };
    }
    return def;
}

// HTC portal: Overworld -> Hyperbolic Time Chamber, Time Chamber -> where you came from (85_world.js travel).
function dmzTimeChamberPortal(player) {
    let htc = "ragnarok_rpg:time_chamber";
    if (player.dimension === htc) {
        let saved = String(player.getVar("travel_return", "minecraft:overworld 0 100 0")).split(" ");
        player.teleportTo(saved[0], Number(saved[1]), Number(saved[2]), Number(saved[3]), 180, 0);
    } else if (typeof enterTimeChamber === "function") enterTimeChamber(player);
    else {
        player.setVar("travel_return", player.dimension + " " + player.x + " " + player.y + " " + player.z);
        player.teleportTo(htc, 0.5, 4, 0.5, 90, 0);
    }
}

DMZ_BLOCK_SPECS.forEach((s) => {
    DMZ_BLOCK[s.id] = s;
    let def = dmzBlockDef(s);
    let id = s.num ? RPG.blocks.define(s.num, def) : RPG.blocks.define(s.id, def);
    BLOCK_IDS[s.id] = id;
    DMZ_BLOCK_BY_REF["ragnarok_rpg:" + id] = s.id;
    DMZ_ITEM_BY_REF["ragnarok_rpg:" + id] = s.id;
    if (s.fx === "pot") DMZ_POT_FOR[s.drop.pot] = s.id;
    if (s.num && id !== "block_" + ("000" + s.num).slice(-4))
        console.warn("[DMZ] WARNING: " + s.id + " wanted block_" + s.num + " but got " + id + ": ore world generation (datapack) points at the wrong block!");
});
