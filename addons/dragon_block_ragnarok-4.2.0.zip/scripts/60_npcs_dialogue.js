// =====================================================================================
//  60_npcs_dialogue.js - DragonMine Z's masters and quest NPCs (who they are, how they look)
// =====================================================================================
//  Place an NPC where you stand:  /rpg npc master_roshi     (remove it: kill it in creative)
//  DMZ places the masters itself: baked into its structures (65_dmz_structures.js builds them
//  with their NPCs) and at fixed Other World spots (OW_NPCS there).
//
//  The 28 masters (DMZ MastersEntity) and the story NPCs (QuestNPCEntity) come from
//  shared/08_dmz_masters_data.js. Talking to one opens DMZ's dialogue (NpcDialogueScreen):
//  greeting, Quests, Skills (the master's TP shop), Train, and the master's own services.
//  That logic lives in 61_dmz_masters.js; the screens in client/scripts/52_masters_screen.js.
//
//  Like DMZ, the masters stand still, look at nearby players, cannot be hurt (except /kill,
//  the void or a creative player) and teach for TP, not Zeni.
// =====================================================================================

// ---- Looks ---------------------------------------------------------------------------
// Every DMZ master shares one animation file (idle, walk, and a few personal idles:
// guru_idle, uranai_idle, tori_idle, roshi_idle).
function masterLook(name, idle) {
    return {
        model: DMZ_GEO + "master/master_" + name + ".geo.json",
        texture: DMZ_TEX + "master/master_" + name + ".png",
        animation: DMZ_ANIM + "master/masters.animation.json",
        idle: idle || "idle",
        walk: "walk"
    };
}

// The saga characters share saga_base.animation.json (63 animations: idle, walk, attack1_1...).
function sagaLook(model, texture, scale) {
    return {
        model: DMZ_GEO + "sagas/" + model + ".geo.json",
        texture: DMZ_TEX + "sagas/" + (texture || model) + ".png",
        animation: DMZ_ANIM + "sagas/saga_base.animation.json",
        idle: "idle", walk: "walk", attack: "attack1_1",
        scale: scale || 1.0
    };
}

// MasterGlobalModel: a master without a model of its own (Beerus, Whis) shows robotxv.
function dmzMasterGeo(m) {
    if (!m.model) return { model: DMZ_GEO + "enemies/robotxv.geo.json", texture: DMZ_TEX + "enemies/robotxv.png",
        animation: DMZ_ANIM + "master/masters.animation.json", idle: "idle", walk: "walk" };
    return masterLook(m.model.replace(/^master_/, ""), m.idle);
}

// =====================================================================================
//  The masters (AllMastersEntity): 100 HP, immobile, invulnerable, LookAtPlayerGoal(8)
// =====================================================================================
Object.keys(DMZ_MASTERS_DATA.MASTERS).forEach((id) => {
    let m = DMZ_MASTERS_DATA.MASTERS[id];
    let def = { name: "&f" + m.name, geo: dmzMasterGeo(m), scale: m.scale || 1, wander: false, invulnerable: true, immovable: true };
    // Yemma and Guru sit facing one way (DMZ freezes them at yaw 180) instead of turning to players
    if (typeof m.yaw === "number") { def.fixedYaw = m.yaw; def.lookAtPlayers = false; }
    // 61_dmz_masters.js opens DMZ's dialogue screen on npcInteract. Yemma and the Otherworld announcer
    // fall back to 60_otherworld.js's dialogues when that is switched off (config dbr_masters).
    if (id === "enma" || id === "otherworld_announcer") def.dialogue = id;
    RPG.npcs.define(m.npc, def);
});

// =====================================================================================
//  Story NPCs (QuestNPCEntity: npc_id + saga model). chi_chi, chiaotzu and dmz_quest_buu
//  are defined in 65_dmz_structures.js; the hell ogre in 60_otherworld.js.
// =====================================================================================
Object.keys(DMZ_MASTERS_DATA.QUEST_NPCS).forEach((id) => {
    let q = DMZ_MASTERS_DATA.QUEST_NPCS[id];
    if (q.npc === "chi_chi" || q.npc === "chiaotzu" || q.npc === "dmz_quest_buu") return;
    let geo = q.look ? sagaLook(q.look[0], q.look[1]) : { model: DMZ_GEO + "enemies/namekian.geo.json", texture: DMZ_TEX + "enemies/namek_trader_0.png",
        animation: DMZ_ANIM + "enemies/namekian.animation.json", idle: "idle", walk: "walk" };
    RPG.npcs.define(q.npc, { name: "&f" + q.name, geo: geo, wander: false });
});

// ---- NPCs from earlier versions of this addon that DMZ doesn't have --------------------
// Kept so NPCs already standing in worlds still work (85_world.js places Kibito).
RPG.npcs.define("kibito", { name: "&dKibito", geo: sagaLook("saga_kibito"), dialogue: "kibito" });
RPG.dialogues.define("kibito", { start: "start", nodes: { start: { text: "The Supreme Kai is watching. Grow strong enough to face Majin Buu.", options: [{ text: "I will." }] } } });
RPG.npcs.define("kami", { name: "&2Kami", geo: sagaLook("saga_piccolo_kami"), dialogue: "kami" });
RPG.dialogues.define("kami", { start: "start", nodes: { start: { text: "The Dragon Balls are my creation. Use them wisely.", options: [{ text: "Understood." }] } } });
RPG.npcs.define("oolong", { name: "&dOolong", geo: sagaLook("saga_oolong"), wander: true, dialogue: "oolong" });
RPG.dialogues.define("oolong", { start: "start", nodes: { start: { text: "If you find all seven Dragon Balls, wish for something useful. Trust me on this one.", options: [{ text: "Like what?" }] } } });
RPG.npcs.define("yajirobe", { name: "&6Yajirobe", geo: sagaLook("saga_yajirobe"), shop: "yajirobe_shop" });

// Namekian villagers: a geo model with four texture variants, one NPC id per look.
// (DMZ's Namek traders use vanilla emerald trades; ours sell for Zeni, 65_shops.js.)
["namek_villager_0", "namek_villager_1", "namek_villager_2", "namek_villager_3"].forEach((id, i) => {
    RPG.npcs.define(id, {
        name: "&aNamekian Villager",
        geo: { model: DMZ_GEO + "enemies/namekian.geo.json", texture: DMZ_TEX + "enemies/namek_trader_" + i + ".png",
               animation: DMZ_ANIM + "enemies/namekian.animation.json", idle: "idle", walk: "walk" },
        wander: true,
        shop: "namek_shop",
        onInteract(player, npc) { sfx(npc, "entity.namekian.vill.ambient", 1, 1); }
    });
});

// =====================================================================================
//  Props: the Saiyan pod (quests drop it with Raditz/Nappa/Vegeta), the punch machine
//  (Time Chamber), and older vehicle props
// =====================================================================================
// Old vehicle props: right-click packs them back into a capsule (56_vehicles.js has the real vehicles).
function vehicleProp(id, name, model, texture, capsuleItem, sound) {
    RPG.npcs.define(id, {
        name: name, showName: false,
        geo: { model: DMZ_GEO + model, texture: DMZ_TEX + texture },
        onInteract(player, npc) {
            sfx(npc, sound, 1, 1);
            npc.kill();
            player.giveItem(capsuleItem, 1);
            RPG.world.particle(npc.dimension, "minecraft:poof", npc.x, npc.y + 1, npc.z, 30, 1, 0.05);
            return false;
        }
    });
}
vehicleProp("capsule_car_red", "Capsule Car", "vehicles/car.geo.json", "vehicles/car_red.png", "car_red", "vehicle.car.engine");
vehicleProp("capsule_car_yellow", "Capsule Car", "vehicles/car.geo.json", "vehicles/car_yellow.png", "car_yellow", "vehicle.car.engine");
vehicleProp("capsule_plane", "Capsule Plane", "vehicles/cc576.geo.json", "vehicles/cc576.png", "cc576", "vehicle.cc576.engine");
vehicleProp("frieza_pod", "Hover Pod", "vehicles/frieza_capsule.geo.json", "vehicles/frieza_capsule.png", "frieza_capsule", "vehicle.frieza_capsule.engine");

// The Saiyan space pod opens with DMZ's own "open" animation and sound.
RPG.npcs.define("saiyan_pod", {
    name: "Saiyan Pod", showName: false,
    geo: { model: DMZ_GEO + "spacepod.geo.json", texture: DMZ_TEX + "spacepod.png", animation: DMZ_ANIM + "spacepod.animation.json", idle: "close" },
    onInteract(player, npc) {
        npc.playAnimation("open");
        sfx(npc, "ship_open", 1, 1);
        return false;
    }
});

// The punch machine (DMZ PunchMachineEntity is placed with punch_machine_item; this prop stands in the Time Chamber).
RPG.npcs.define("punch_machine", {
    name: "&ePunch Machine",
    geo: { model: DMZ_GEO + "punchstation.geo.json", texture: DMZ_TEX + "punchmachine.png",
           animation: DMZ_ANIM + "punchmachine.animation.json", idle: "idle" },
    onInteract(player, npc) {
        let score = Math.floor(player.stat("strike") * 8 + player.stat("strength") * 6 + RPG.randomInt(0, 50));
        act(player, "base.jab_right", 10);
        npc.playAnimation("punch");
        sfx(npc, "critic_punch1", 1, 1);
        player.title("&e" + score, "&7Punch Machine score");
        if (score > player.getVar("best_punch", 0)) { player.setVar("best_punch", score); player.tell("&6New personal best: " + score + "!"); }
        return false;
    }
});

// A decorative Nimbus (the rideable one is the flying_nimbus item from Korin, 56_vehicles.js).
RPG.npcs.define("nimbus_cloud", {
    name: "&eFlying Nimbus", showName: false,
    geo: { model: DMZ_GEO + "kinton.geo.json", texture: DMZ_TEX + "kinton.png", animation: DMZ_ANIM + "kinton.animation.json", idle: "idle" },
    onInteract(player, npc) { sfx(npc, "nube", 1, 1); return false; }
});
