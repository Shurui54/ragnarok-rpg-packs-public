// =====================================================================================
//  64_dmz_senses.js - DMZ lock-on, Ki Sense, the scouter and Instant Transmission (server)
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): LockOnEvent, KiSenseScan/KiSenseState, ScouterHUD's scans,
//  InstantTransmissionTapC2S, RequestITTargetsC2S, InstantTransmissionTravel(ToPlayer)C2S,
//  ITTeleportHelper and EntitiesEvents (masters' ki memorised on right-click).
//  The drawing (reticle, camera, panels, scouter, destination screen) is client/scripts/46_dmz_senses.js.
//
//  Vars: lock_uuid (the locked target, techniques aim at it), dmz_scouter "red"|"green"|"blue"|"purple"|"",
//        dmz_it_masters {key: {n, d, x, y, z}} (masters whose ki you know)
//  Net:  client -> "dmz_sense" {a: "mode", m} | {a: "scouter", on}     "dmz_it" {a: "master"|"player"|"delete", id}
//        server -> "dmz_sense_scan" {mode, combat: [...], my}  "dmz_scouter_data" {...}  "dmz_it_open" {...}
// =====================================================================================
RPG.effects.define("teleport_cd", { name: "Teleport", color: "#A46CFF", beneficial: false });

var DMZ_SENSES = (function () {
    var CFG = RPG.files.config("dbr_senses", {
        teleportCooldownSeconds: 30,
        instantTransmissionPlayerRangePerLevel: 200,
        scouterBpLimit: 150000000
    });
    function num(v, d) { v = Number(v); return isNaN(v) || !isFinite(v) ? d : v; }
    function tick() { return RPG.server.getTick(); }
    function skill(p, s) { return typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS.level(p, s) : 0; }
    function created(p) { return !!p.getVar("dmz_created", 0); }
    function android(p) { return !!p.getVar("dmz_android", 0); }
    function creative(p) { var g = p.getGameMode(); return g === "creative" || g === "spectator"; }
    function F() { return typeof DMZ_FLIGHT !== "undefined" ? DMZ_FLIGHT : null; }
    function hasCd(p, k) { var f = F(); return !!f && f.hasCooldown(p, k); }
    function setCd(p, k, t) { var f = F(); if (f) f.setCooldown(p, k, t); }
    function bar(p, key, args) { RPG.net.send(p, "dmz_bar", { key: key, args: args || [] }); }
    function cloaked(e) { var pl = e.asPlayer(); return !!pl && pl.stat("ki_cloak") > 0; }
    function suppressed(e) { var pl = e.asPlayer(); return !!pl && created(pl) && num(pl.getVar("dmz_release", 0), 0) <= 0; }
    function myBp(p) { return DMZ_F.battlePower(dmzView(p)); }
    /** KiSenseScan.getEntityBP: players by their stats (0 when cloaked), mobs by DBR's power level */
    function bpOf(e) {
        var pl = e.asPlayer();
        if (pl) return cloaked(pl) ? 0 : (created(pl) ? DMZ_F.battlePower(dmzView(pl)) : 0);
        return powerLevel(e);
    }
    // LockOnEvent.canTarget / KiSenseScan.canTarget (the latter also hides android-upgraded players)
    function canTarget(viewer, e, sense) {
        var pl = e.asPlayer();
        if (!pl) return true;
        if (cloaked(pl) || suppressed(pl)) return false;
        if (sense && android(pl)) return false;
        return true;
    }
    function playerById(uuid) {
        var found = null;
        RPG.server.players().forEach(function (q) { if (q.uuid === uuid) found = q; });
        return found;
    }

    // =========================== lock-on (Z) ===========================
    function lockRange(p) { return 15 + 5 * skill(p, "kisense") + (android(p) ? 25 : 0); }
    function unlock(p) {
        if (p.getVar("lock_uuid", "")) p.setVar("lock_uuid", null);
    }
    function lockPress(p) {
        if (p.hasEffect("stunned")) return;
        if (p.getVar("lock_uuid", "")) { unlock(p); return; }
        if (skill(p, "kisense") <= 0) return;
        var t = p.target(lockRange(p));
        if (!t || !t.isAlive() || !p.canSee(t) || !canTarget(p, t, false)) return;
        p.setVar("lock_uuid", t.uuid);
        p.playSound("dmzpack:lockon", 1, 1);
    }
    function lockValid(p, t) {
        if (!t || !t.isAlive() || t.dimension !== p.dimension) return false;
        if (skill(p, "kisense") <= 0 || p.distanceTo(t) > lockRange(p)) return false;
        if (!canTarget(p, t, true)) return false;
        return p.canSee(t) || android(p);
    }
    RPG.every(5, function () {                        // re-check every 5 ticks
        RPG.server.players().forEach(function (p) {
            var u = p.getVar("lock_uuid", "");
            if (!u) return;
            if (!lockValid(p, RPG.world.entityByUuid(u))) unlock(p);
        });
    });
    RPG.on("respawn", unlock);

    // =========================== Ki Sense (F4) ===========================
    var SENSE = {};            // uuid -> {mode, timer, first, suppress, sensed {uuid: bp}, combat [], search [], glow []}
    function combatRange(p, lvl) { return 10 + 3 * lvl + (android(p) ? 10 : 0); }
    function searchRange(p, lvl) { return 30 + 20 * lvl + (android(p) ? 10 : 0); }
    var HOSTILE = /zombie|skeleton|creeper|spider|enderman|witch|slime|blaze|ghast|phantom|drowned|husk|stray|pillager|vindicator|evoker|ravager|vex|guardian|shulker|silverfish|endermite|hoglin|zoglin|piglin|wither|warden|magma_cube|wolf|bee|polar_bear|llama|panda|dolphin|goat|iron_golem/;
    function passive(e) { return !e.isPlayer() && !e.rpgId && !HOSTILE.test(e.type); }
    // KiSenseAuraRenderer.auraColors (border colour)
    function auraColor(e, ratio) {
        if (passive(e)) return "#4D80FF";
        if (ratio > 1.15) return "#FF4033";
        if (ratio < 0.85) return "#4D80FF";
        return "#FFE666";
    }
    function setSenseMode(p, m) {
        m = Math.max(0, Math.min(2, Math.floor(num(m, 0))));
        var lvl = skill(p, "kisense");
        if (lvl <= 0 || !created(p)) m = 0;
        var s = SENSE[p.uuid];
        if (!s) s = SENSE[p.uuid] = { mode: 0, timer: 0, first: true, suppress: false, sensed: {}, combat: [], glow: [] };
        if (s.mode !== m) clearGlow(p, s);
        s.mode = m; s.timer = 0; s.first = true; s.suppress = true;
        if (F() && lvl > 0) F().setSkillActive(p, "kisense", m !== 0);
        if (m === 0) { s.combat = []; s.sensed = {}; RPG.net.send(p, "dmz_sense_scan", { mode: 0, combat: [] }); }
    }
    function clearGlow(p, s) {
        s.glow.forEach(function (e) { try { if (e.isAlive()) p.glowFor(e, "#FFFFFF", 0); } catch (err) { } });
        s.glow = [];
    }
    function inView(p, e) {
        var yaw = p.yaw * Math.PI / 180, pitch = p.pitch * Math.PI / 180;
        var lx = -Math.sin(yaw) * Math.cos(pitch), ly = -Math.sin(pitch), lz = Math.cos(yaw) * Math.cos(pitch);
        var dx = e.x - p.x, dy = e.y + 0.9 - p.eyeY, dz = e.z - p.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
        return (lx * dx + ly * dy + lz * dz) / l > 0.6 && p.canSee(e);
    }
    function heavyScan(p, s, lvl) {
        var me = myBp(p), cr = combatRange(p, lvl), sr = searchRange(p, lvl), andr = android(p);
        var sensed = {}, alert = false;
        clearGlow(p, s);
        s.combat = [];
        p.nearby(Math.min(128, sr)).forEach(function (e) {
            if (!e.isAlive() || !canTarget(p, e, true)) return;
            var d = p.distanceTo(e);
            if (d > sr) return;
            var bp = bpOf(e);
            sensed[e.uuid] = bp;
            var old = s.sensed[e.uuid];
            if (bp > me && (old === undefined || bp > old * 1.15) && !inView(p, e)) alert = true;
            if (s.mode === 2) {
                p.glowFor(e, auraColor(e, bp / Math.max(1, me)), 110);
                s.glow.push(e);
            } else if (s.mode === 1 && d <= cr && (andr || p.canSee(e))) s.combat.push(e);
        });
        s.sensed = sensed;
        if (alert && !s.suppress) p.playSound("dmzpack:lockon", 1, 1);
        s.suppress = false;
    }
    function panelOf(e) {
        var pl = e.asPlayer(), o = { u: e.uuid, bp: Math.floor(bpOf(e)) };
        if (pl && created(pl)) {
            o.pl = 1;
            o.ki = Math.round(pl.resource("ki")); o.kiM = Math.round(pl.maxResource("ki"));
            o.st = Math.round(pl.resource("stamina")); o.stM = Math.round(pl.maxResource("stamina"));
            o.ch = pl.hasEffect("ki_charge") ? 1 : 0;
            o.au = String(pl.getVar("dmz_aura_color", "") || pl.getColor("aura") || "#7FC8FF");
        }
        return o;
    }
    RPG.every(5, function () {
        RPG.server.players().forEach(function (p) {
            var s = SENSE[p.uuid];
            if (!s || s.mode === 0) return;
            var lvl = skill(p, "kisense");
            if (lvl <= 0 || hasScouter(p)) { setSenseMode(p, 0); RPG.net.send(p, "dmz_sense_reset", {}); return; }
            s.timer += 5;
            if (s.first || s.timer >= 100) { s.first = false; s.timer = 0; heavyScan(p, s, lvl); }
            if (s.mode === 1 && (s.timer % 10 === 0)) {
                s.combat = s.combat.filter(function (e) { return e.isAlive() && e.dimension === p.dimension; });
                RPG.net.send(p, "dmz_sense_scan", { mode: 1, combat: s.combat.map(panelOf), my: Math.floor(myBp(p)) });
            }
        });
    });
    RPG.on("playerLeave", function (p) { delete SENSE[p.uuid]; delete SCOUT[p.uuid]; });
    RPG.on("death", function (p) { if (SENSE[p.uuid]) setSenseMode(p, 0); });

    // =========================== the scouter ===========================
    var SCOUTER_IDS = null;    // item id -> colour
    function scouterIds() {
        if (SCOUTER_IDS) return SCOUTER_IDS;
        SCOUTER_IDS = {};
        ["red", "green", "blue", "purple"].forEach(function (c) {
            try { var n = RPG.items.id(c + "_scouter"); if (n !== null && n !== undefined) SCOUTER_IDS["ragnarok_rpg:" + n] = c; } catch (e) { }
            SCOUTER_IDS[c + "_scouter"] = c;
        });
        return SCOUTER_IDS;
    }
    function scouterColor(p) {
        var st = null;
        try { st = p.getAccessory("head_tech"); } catch (e) { return ""; }
        if (!st || !st.id) return "";
        return scouterIds()[st.id] || (/scouter/.test(st.id) ? "green" : "");
    }
    function hasScouter(p) { return scouterColor(p) !== ""; }
    var SCOUT = {};            // uuid -> {on, strongest, bp}
    function damageScouter(p) {
        var st = p.getAccessory("head_tech");
        RPG.net.send(p, "dmz_scouter_data", { off: 1 });
        if (SCOUT[p.uuid]) SCOUT[p.uuid].on = false;
        if (!st) return;
        st.damage = (st.damage || 0) + 1;
        var max = st.maxDamage || 15;
        if (st.damage >= max) { p.setAccessory("head_tech", null); p.playSound("minecraft:block.glass.break", 1, 1); }
        else { p.setAccessory("head_tech", st); p.playSound("minecraft:block.glass.hit", 0.5, 1); }
    }
    function questDone(p, key) { return typeof DMZ_QUESTS !== "undefined" && DMZ_QUESTS && DMZ_QUESTS.isCompleted(p, key); }
    RPG.every(10, function () {
        var t = tick();
        RPG.server.players().forEach(function (p) {
            var c = scouterColor(p);
            if (String(p.getVar("dmz_scouter", "") || "") !== c) p.setVar("dmz_scouter", c || null);
            var sc = SCOUT[p.uuid];
            if (!c || !sc || !sc.on || t % 20 !== 0) return;
            // every 20 ticks: battle powers within 50 blocks (ScouterHUD.performSmartScan)
            var list = [], over = false, me = p.uuid;
            p.nearby(50).forEach(function (e) {
                if (!e.isAlive() || e.uuid === me) return;
                if (e.isPlayer() && e.asPlayer().race === "glind") return;     // GlindDivinity.isHiddenFrom
                var bp = bpOf(e);
                if (bp > CFG.scouterBpLimit) over = true;
                list.push({ u: e.uuid, bp: Math.floor(bp), pl: e.isPlayer() ? 1 : 0 });
            });
            if (over) { damageScouter(p); return; }
            RPG.net.send(p, "dmz_scouter_data", { list: list, bio: questDone(p, "bulma_scouter_bioscan") ? 1 : 0 });
        });
    });

    RPG.net.on("dmz_sense", function (p, d) {
        if (!d) return;
        if (d.a === "mode") setSenseMode(p, d.m);
        else if (d.a === "scouter") {
            var sc = SCOUT[p.uuid] || (SCOUT[p.uuid] = { on: false });
            sc.on = !!d.on && hasScouter(p);
        }
    });

    // =========================== Instant Transmission (H) ===========================
    function flyDashCost() { var f = F(); return Math.ceil((f ? f.CFG.baselineFormDrain : 80) * 0.12); }
    function extraForDistance(d) { return d <= 0 ? 0 : Math.floor(d / 25) * 5; }
    // ITTeleportHelper.dimensionTravelValue (DMZ dimensions under our ids)
    var DIM_VALUE = { "minecraft:overworld": 0, "minecraft:the_nether": 12000, "minecraft:the_end": 18000, "ragnarok_rpg:namek": 2000,
        "ragnarok_rpg:sacredkaiplanet": 8000, "ragnarok_rpg:cereal_planet": 12000, "ragnarok_rpg:demon_realm": 15000,
        "ragnarok_rpg:otherworld": 20000, "ragnarok_rpg:beerus_planet": 25000, "ragnarok_rpg:time_chamber": 10000 };
    function interplanetary(from, to) {
        if (from === to) return 0;
        var a = DIM_VALUE[from], b = DIM_VALUE[to];
        return a === undefined || b === undefined ? 10000 : Math.abs(a - b);
    }
    function travelCost(base, d, from, to) { return base + extraForDistance(d) + interplanetary(from, to); }
    function blocked(p, target) {        // TransformationsHelper.isInstantTransmissionBlocked (+ Glind divinity)
        var tp = target.asPlayer();
        if (!tp) return false;
        if (android(tp)) return true;
        return tp.race === "glind" && p.race !== "glind";
    }
    function entityPower(e) { var pl = e.asPlayer(); return pl && created(pl) ? myBp(pl) : Math.floor(e.maxHealth); }
    function nearCrosshair(p, e, range) {
        var yaw = p.yaw * Math.PI / 180, pitch = p.pitch * Math.PI / 180;
        var lx = -Math.sin(yaw) * Math.cos(pitch), ly = -Math.sin(pitch), lz = Math.cos(yaw) * Math.cos(pitch);
        var dx = e.x - p.x, dy = e.y + 0.9 - p.eyeY, dz = e.z - p.z, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d > range) return false;
        if (d < 1e-4) return true;
        return (dx * lx + dy * ly + dz * lz) / d >= 0.93;
    }
    var LAST_HIT = {};         // uuid -> {e, t}  (CombatEvent DMZ_LAST_HIT_TARGET_*)
    RPG.on("attack", function (e) {
        if (e.attacker && e.attacker.isPlayer() && e.target && !e.isCancelled()) LAST_HIT[e.attacker.uuid] = { e: e.target, t: Date.now() };
    });
    function depart(p, sound) { sfx(p, sound, 1, 1); burst(p, "minecraft:reverse_portal", 12, 0.4, 0.05); }
    function arrive(p, sound) { sfx(p, sound, 1, 1); burst(p, "minecraft:reverse_portal", 12, 0.4, 0.05); }

    function tap(p) {
        if (p.hasEffect("stunned")) return;
        var lvl = skill(p, "instant_transmission");
        if (lvl <= 0) return;
        var free = creative(p);
        if (!free && hasCd(p, "dash_cd")) { bar(p, "gui.dragonminez.transmission.fail.dash_cooldown"); return; }
        var range = 25 + lvl * 10, target = null;
        var lock = p.getVar("lock_uuid", "");
        if (lock) {
            var le = RPG.world.entityByUuid(lock);
            if (le && le.uuid !== p.uuid && le.isAlive() && le.dimension === p.dimension && !blocked(p, le) && p.canSee(le) && nearCrosshair(p, le, range)) target = le;
        } else {
            var cands = p.nearby(Math.min(128, range)).filter(function (e) {
                return e.isAlive() && p.canSee(e) && !blocked(p, e) && nearCrosshair(p, e, range);
            });
            var lh = LAST_HIT[p.uuid];
            var recent = lh && Date.now() - lh.t <= 6000 && lh.e.isAlive() ? lh.e : null;
            if (recent && cands.some(function (e) { return e.uuid === recent.uuid; })) target = recent;
            else cands.forEach(function (e) { if (!target || entityPower(e) > entityPower(target)) target = e; });
        }
        if (!target) { bar(p, "gui.dragonminez.transmission.fail.no_target"); return; }
        var cost = flyDashCost() + extraForDistance(p.distanceTo(target));
        if (!free) {
            if (p.resource("ki") < cost) { bar(p, "gui.dragonminez.transmission.fail.no_ki"); return; }
            p.addResource("ki", -cost);
        }
        var rad = target.yaw * Math.PI / 180;
        depart(p, "tp_short");
        p.teleportTo(target.dimension, target.x + Math.sin(rad) * 1.5, target.y, target.z - Math.cos(rad) * 1.5, target.yaw, p.pitch);
        arrive(p, "tp_short");
        if (!free) {
            var dcd = (F() ? F().CFG.dashCooldownSeconds : 4) * 20;
            setCd(p, "dash_cd", dcd);
            p.addEffect("dash_cd", dcd);
        }
    }

    // ---- masters' ki (EntitiesEvents.onEntityInteract) ----
    function masters(p) { var m = p.getVar("dmz_it_masters", null); return m && typeof m === "object" ? m : {}; }
    RPG.on("npcInteract", function (p, npc, npcId) {
        if (!npc || typeof DMZ_MASTERS_DATA === "undefined") return;
        var id = DMZ_MASTERS_DATA.BY_NPC[npcId];
        if (!id || !DMZ_MASTERS_DATA.isMaster(id) || skill(p, "instant_transmission") < 1) return;
        var m = masters(p), key = npc.uuid, known = !!m[key];
        m[key] = { n: npc.name, d: npc.dimension, x: Math.floor(npc.x), y: Math.floor(npc.y), z: Math.floor(npc.z), id: id };
        p.setVar("dmz_it_masters", m);
        if (!known) bar(p, "message.dragonminez.instant_transmission.ki_learned", [npc.name]);
    });

    function validExternal(p, me, t, maxRange) {
        if (t.dimension !== p.dimension || p.distanceTo(t) > maxRange) return false;
        if (creative(t) || cloaked(t) || blocked(p, t)) return false;
        var fu = t.getVar("dmz_fusion", null);                 // a fusion partner (64_dmz_fusion.js) isn't a destination
        if (fu && typeof fu === "object" && fu.leader === false) return false;
        var bp = myBp(t);
        return bp >= me * 0.90 && bp <= me * 1.25;
    }
    function partyOf(p) { try { return p.partyMembers(); } catch (e) { return []; } }

    function openMenu(p) {                         // RequestITTargetsC2S
        var lvl = skill(p, "instant_transmission");
        if (lvl < 5) return;
        var dim = p.dimension, base = flyDashCost() * 5, entries = [], listed = {}, me = myBp(p);
        var m = masters(p);
        Object.keys(m).forEach(function (k) {
            var e = m[k], same = e.d === dim;
            var d = same ? Math.sqrt(Math.pow(e.x + 0.5 - p.x, 2) + Math.pow(e.y - p.y, 2) + Math.pow(e.z + 0.5 - p.z, 2)) : 0;
            entries.push({ type: "MASTER", id: k, name: e.n, dim: e.d, reach: lvl >= 10 || same, cost: travelCost(base, d, dim, e.d) });
        });
        partyOf(p).forEach(function (q) {
            if (q.uuid === p.uuid || !created(q) || cloaked(q) || blocked(p, q)) return;
            var same = q.dimension === dim;
            entries.push({ type: "PARTY", id: q.uuid, name: q.name, dim: q.dimension, reach: lvl >= 10 || same, cost: travelCost(base, same ? p.distanceTo(q) : 0, dim, q.dimension) });
            listed[q.uuid] = true;
        });
        var maxRange = CFG.instantTransmissionPlayerRangePerLevel * lvl;
        RPG.server.players().forEach(function (q) {
            if (q.uuid === p.uuid || listed[q.uuid] || !created(q) || !validExternal(p, me, q, maxRange)) return;
            entries.push({ type: "EXTERNAL", id: q.uuid, name: q.name, dim: dim, reach: true, cost: travelCost(base, p.distanceTo(q), dim, dim) });
        });
        RPG.net.send(p, "dmz_it_open", { lvl: lvl, entries: entries });
    }

    // ITTeleportHelper.findSafeTeleportPos
    var EMPTY = /(^|:)(air|cave_air|void_air|grass|short_grass|tall_grass|fern|large_fern|dead_bush|snow|vine|torch|wall_torch|.*_sapling|.*_flower|dandelion|poppy|.*_tulip|allium|azure_bluet|oxeye_daisy|cornflower|lily_of_the_valley|.*_mushroom|.*_carpet|.*_sign|.*_button|.*_pressure_plate|light)$/;
    var FLUID = /(^|:)(water|lava|bubble_column)$/;
    function blockId(dim, x, y, z) { return String(RPG.world.getBlock(dim, x, y, z) || "minecraft:air").split("[")[0]; }
    function isSafe(dim, x, y, z) {
        var below = blockId(dim, x, y - 1, z), body = blockId(dim, x, y, z), head = blockId(dim, x, y + 1, z);
        return !EMPTY.test(below) && !FLUID.test(below) && EMPTY.test(body) && EMPTY.test(head);
    }
    function safePos(dim, cx, cy, cz) {
        for (var r = 3; r <= 4; r++)
            for (var x = -r; x <= r; x++)
                for (var z = -r; z <= r; z++) {
                    var d = Math.sqrt(x * x + z * z);
                    if (d < 3 || d > 4.5) continue;
                    for (var y = 3; y >= -3; y--) if (isSafe(dim, cx + x, cy + y, cz + z)) return { x: cx + x, y: cy + y, z: cz + z };
                }
        return { x: cx, y: cy + 1, z: cz };
    }
    function teleportNear(p, dim, cx, cy, cz) {
        if (p.vehicle) p.dismount();
        var s = safePos(dim, cx, cy, cz);
        var yaw = Math.atan2(cz - s.z, cx - s.x) * 180 / Math.PI - 90;
        depart(p, "tp");
        p.teleportTo(dim, s.x + 0.5, s.y, s.z + 0.5, yaw, p.pitch);
        arrive(p, "tp");
    }
    function payTravel(p, cost) {
        if (creative(p)) return true;
        if (hasCd(p, "teleport_cd")) { bar(p, "gui.dragonminez.transmission.fail.cooldown"); return false; }
        if (p.resource("ki") < cost) { bar(p, "gui.dragonminez.transmission.fail.no_ki"); return false; }
        p.addResource("ki", -cost);
        var t = Math.max(0, CFG.teleportCooldownSeconds) * 20;
        if (t > 0) { setCd(p, "teleport_cd", t); p.addEffect("teleport_cd", t); }
        return true;
    }
    function travelMaster(p, key) {                // InstantTransmissionTravelC2S
        if (p.hasEffect("stunned")) return;
        var lvl = skill(p, "instant_transmission");
        if (lvl < 5) return;
        var e = masters(p)[key];
        if (!e) { bar(p, "gui.dragonminez.transmission.fail.not_found"); return; }
        var same = e.d === p.dimension;
        if (lvl < 10 && !same) { bar(p, "gui.dragonminez.transmission.fail.too_far"); return; }
        if (!same && typeof RPG.dimensions !== "undefined" && /^ragnarok_rpg:/.test(e.d) && !RPG.dimensions.exists(e.d.split(":")[1])) {
            bar(p, "gui.dragonminez.transmission.fail.unknown"); return;
        }
        var d = same ? Math.sqrt(Math.pow(e.x + 0.5 - p.x, 2) + Math.pow(e.y - p.y, 2) + Math.pow(e.z + 0.5 - p.z, 2)) : 0;
        if (!payTravel(p, travelCost(flyDashCost() * 5, d, p.dimension, e.d))) return;
        teleportNear(p, e.d, e.x, e.y, e.z);
    }
    function travelPlayer(p, uuid) {               // InstantTransmissionTravelToPlayerC2S
        var lvl = skill(p, "instant_transmission");
        if (lvl < 5 || p.hasEffect("stunned")) return;
        var t = playerById(String(uuid || ""));
        if (!t || t.uuid === p.uuid || !created(t)) { bar(p, "gui.dragonminez.transmission.fail.not_found"); return; }
        if (cloaked(t) || blocked(p, t)) { bar(p, "gui.dragonminez.transmission.fail.blocked"); return; }
        var same = t.dimension === p.dimension;
        var party = partyOf(p).some(function (q) { return q.uuid === t.uuid; });
        if (party) {
            if (!same && lvl < 10) { bar(p, "gui.dragonminez.transmission.fail.too_far"); return; }
        } else if (!validExternal(p, myBp(p), t, CFG.instantTransmissionPlayerRangePerLevel * lvl)) {
            bar(p, "gui.dragonminez.transmission.fail.too_far"); return;
        }
        if (!payTravel(p, travelCost(flyDashCost() * 5, same ? p.distanceTo(t) : 0, p.dimension, t.dimension))) return;
        teleportNear(p, t.dimension, Math.floor(t.x), Math.floor(t.y), Math.floor(t.z));
    }

    // H: tap (< 500 ms) = to the target in front (or the lock); hold = the destination screen (level 5+)
    var IT_KEY = {};
    function itPress(p) { IT_KEY[p.uuid] = { menu: false }; }
    function itHold(p, ticks) {
        var k = IT_KEY[p.uuid];
        if (!k || k.menu || ticks < 10 || p.hasEffect("stunned")) return;
        k.menu = true;
        openMenu(p);
    }
    function itRelease(p, ticks) {
        var k = IT_KEY[p.uuid];
        delete IT_KEY[p.uuid];
        if (p.hasEffect("stunned") || (k && k.menu) || ticks >= 10) return;
        tap(p);
    }

    RPG.net.on("dmz_it", function (p, d) {
        if (!d || !created(p)) return;
        if (d.a === "master") travelMaster(p, String(d.id || ""));
        else if (d.a === "player") travelPlayer(p, d.id);
        else if (d.a === "delete") {                // DeleteMasterC2S
            var m = masters(p);
            if (m[String(d.id)]) { delete m[String(d.id)]; p.setVar("dmz_it_masters", m); }
        }
    });

    return {
        lockPress: lockPress, unlock: unlock, lockRange: lockRange,
        itPress: itPress, itHold: itHold, itRelease: itRelease, tap: tap, openMenu: openMenu,
        senseMode: function (p) { var s = SENSE[p.uuid]; return s ? s.mode : 0; }, setSenseMode: setSenseMode,
        hasScouter: hasScouter, scouterColor: scouterColor, battlePower: bpOf,
        _travelCost: travelCost, _safePos: safePos
    };
})();
