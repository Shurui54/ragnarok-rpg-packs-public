// =====================================================================================
//  DMZ flight, dash input and the Jump/Sprint skills on the client
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): FlySkillEvent (search flight, hover, take-off, landing),
//  CombatFlightHandler (combat flight, double-tap impulses), FlightSoundInstance,
//  MovementSkillsHandler (jump boost, air-drag compensation) and ClientStatsEvents' dash input.
//  Like DMZ, movement is decided here every client tick (end of tick) and the server
//  (scripts/64_dmz_movement.js) only switches flight on/off, charges ki and checks cooldowns.
//
//  Reads: effect "flight", vars dmz_skills, dmz_flight_mode, dmz_flight_speed_limit, dmz_release,
//  dmz_skill_active, dmz_speed_attr, dmz_surge_active, dmz_creative, dmz_tf_anim (and, for a future
//  gravity system, dmz_fly_factor / dmz_fly_hardstop / dmz_jump_factor).
// =====================================================================================
var DMZ_FLIGHT_CLIENT = (function () {
    // ---- constants (FlySkillEvent / CombatFlightHandler) ----
    var SEARCH_SPEED_SCALE = 0.82, NORMAL_MAX = 0.6 * SEARCH_SPEED_SCALE, SPRINT_MAX = 1.05 * SEARCH_SPEED_SCALE;
    var ACCEL = 0.055, DECEL = 0.035, EXIT_DECEL = 0.08, SLOW_DESCENT = -0.02;
    var TURN_NORMAL = 0.15, TURN_FAST = 0.6, TURN_REVERSAL_DOT = -0.2;
    var FAST_ENTER = 0.55 * SEARCH_SPEED_SCALE, FAST_EXIT = 0.4 * SEARCH_SPEED_SCALE;
    var MIN_CLEARANCE = 0.25, DOUBLE_TAP_MS = 250;
    var COMBAT_SCALE = 0.85, SMOOTHING = 0.35, BURST_DECAY = 0.88, PASSIVE_DESCENT = -0.05, VERTICAL_RATE = 0.55;
    var CFG = { combatFlyBaseSpeed: 0.30, combatFlySprintSpeed: 0.50, combatFlyHoldSpeedMultiplier: 1.6, combatFlyImpulseCooldownTicks: 25,
        baselineFormDrain: 80, surgeFlySpeedMultiplier: 1.25 };

    // ---- small vector helpers ----
    function V(x, y, z) { return { x: x, y: y, z: z }; }
    var ZERO = V(0, 0, 0);
    function add(a, b) { return V(a.x + b.x, a.y + b.y, a.z + b.z); }
    function mul(a, s) { return V(a.x * s, a.y * s, a.z * s); }
    function len(a) { return Math.sqrt(a.x * a.x + a.y * a.y + a.z * a.z); }
    function lenSq(a) { return a.x * a.x + a.y * a.y + a.z * a.z; }
    function norm(a) { var l = len(a); return l < 1e-4 ? ZERO : V(a.x / l, a.y / l, a.z / l); }
    function dot(a, b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
    function lerp(t, a, b) { return a + (b - a) * t; }
    function lerpV(a, b, t) { return V(lerp(t, a.x, b.x), lerp(t, a.y, b.y), lerp(t, a.z, b.z)); }
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function yRot(a, deg) { var r = deg * Math.PI / 180, c = Math.cos(r), s = Math.sin(r); return V(a.x * c + a.z * s, a.y, a.z * c - a.x * s); }
    function num(v, d) { v = Number(v); return isNaN(v) || !isFinite(v) ? d : v; }

    // ---- player data ----
    function skills() { var m = RPG.getVar("dmz_skills", null); return m && typeof m === "object" ? m : {}; }
    function lvl(s) { var v = skills()[s]; return typeof v === "number" ? v : 0; }
    function owned(s) { return Object.prototype.hasOwnProperty.call(skills(), s); }
    function active(s) { var m = RPG.getVar("dmz_skill_active", null); return !!(m && typeof m === "object" && m[s]); }
    function created() { return !!num(RPG.getVar("dmz_created", 0), 0); }
    function release() { return num(RPG.getVar("dmz_release", 0), 0); }
    function flightMode() { return num(RPG.getVar("dmz_flight_mode", 0), 0) === 1 ? 1 : 0; }
    function speedLimit() { var v = num(RPG.getVar("dmz_flight_speed_limit", 0), 0); return v > 0 ? v : 100; }
    function stunned() { return RPG.player.hasEffect("stunned"); }
    function isFlying() { return RPG.player.hasEffect("flight"); }
    function rooted() { return RPG.player.hasEffect("dmz_tech_rooted"); }
    function chargingKi() { return RPG.player.hasEffect("ki_charge"); }
    function actionCharging() { return !!RPG.getVar("dmz_tf_anim", ""); }
    function creative() { return !!num(RPG.getVar("dmz_creative", 0), 0); }
    // FLY_SPEED attribute (players have none: 1) x flightStateSpeedMultiplier (surge 1.25)
    function speedScale() { return num(RPG.getVar("dmz_surge_active", 0), 0) ? CFG.surgeFlySpeedMultiplier : 1; }
    // gravity (60_dmz_machines.js publishes DMZ_GRAVITY_CLIENT; the vars are a fallback hook)
    function grav() { return typeof DMZ_GRAVITY_CLIENT !== "undefined" ? DMZ_GRAVITY_CLIENT : null; }
    function flyFactor() { var g = grav(); return clamp(g ? num(g.fly, 1) : num(RPG.getVar("dmz_fly_factor", 1), 1), 0, 1); }
    function hardStopped() { var g = grav(); return g ? !!g.hardStop : !!num(RPG.getVar("dmz_fly_hardstop", 0), 0); }
    function jumpFactor() { var g = grav(); return g ? num(g.jump, 1) : num(RPG.getVar("dmz_jump_factor", 1), 1); }
    function hoverDescentFactor(l) { return lerp((clamp(l, 1, 10) - 1) / 9, 1.0, 0.15); }
    function activationCost(l) { return Math.ceil(CFG.baselineFormDrain * Math.max(0.01, 0.04 - l * 0.003)); }

    // our own avatar view (keys, ground clearance)
    var selfId = -1;
    function me() {
        var a = selfId >= 0 ? RPG.avatar.player(selfId) : null;
        if (a && a.local) return a;
        a = null;
        RPG.avatar.players().forEach(function (pl) { if (pl.local) a = pl; });
        selfId = a ? a.id : -1;
        return a;
    }
    function keys(restricted) {
        var a = me(), k = { f: false, b: false, l: false, r: false, j: false, c: false, sprintKey: false };
        if (!a || restricted) return k;
        k.f = a.keyForward; k.b = a.keyBack; k.l = a.keyLeft; k.r = a.keyRight; k.j = a.keyJump; k.c = a.keySneak; k.sprintKey = a.keySprint;
        return k;
    }
    function groundDistance() { var a = me(); if (!a) return 1e9; var d = a.groundClearance(1.5); return d < 0 ? 1e9 : d; }

    // ---- messages (displayClientMessage(..., true)) ----
    var BAR = { n: 0 };
    function tr(key, args) {
        args = args || [];
        if (args.length === 0) return RPG.translate(key);
        if (args.length === 1) return RPG.translate(key, String(args[0]));
        return RPG.translate(key, String(args[0]), String(args[1]));
    }
    function actionbar(text) {
        var n = ++BAR.n;
        RPG.hud.set("dmz_actionbar", { type: "text", anchor: "bottom", x: 0, y: -59, text: String(text), color: "#FFFFFF", shadow: true, align: "center" });
        RPG.schedule(60, function () { if (BAR.n === n) RPG.hud.remove("dmz_actionbar"); });
    }
    RPG.net.on("dmz_bar", function (d) { if (d && d.key) actionbar(tr(String(d.key), d.args)); });
    RPG.net.on("dmz_move_cfg", function (d) { if (d) Object.keys(CFG).forEach(function (k) { if (typeof d[k] === "number") CFG[k] = d[k]; }); });
    function send(data) { RPG.net.send("dmz_flight", data); }

    // ---- search flight state (FlySkillEvent) ----
    var st = { pendingGround: false, groundStart: 0, pendingAct: false, awaitOn: 0, vec: ZERO, vh: 0, hovering: 0,
        pendingDisable: false, wasActive: false, wasSprintAir: false, fast: false, lastMode: 0, lastLeftTap: 0, lastRightTap: 0,
        wasLeft: false, wasRight: false, sent: null };
    // ---- combat flight state (CombatFlightHandler) ----
    var C = { vel: ZERO, burst: ZERO, wasDown: [false, false, false, false, false, false], lastTap: [0, 0, 0, 0, 0, 0], sustained: -1, lastImpulse: 0 };

    function resetFlight() {
        st.vec = ZERO; st.vh = 0; st.hovering = 0; st.pendingDisable = false; st.wasActive = false; st.wasSprintAir = false; st.fast = false;
    }
    function resetCombat() {
        C.vel = ZERO; C.burst = ZERO; C.sustained = -1; C.lastImpulse = 0;
        for (var i = 0; i < 6; i++) { C.wasDown[i] = false; C.lastTap[i] = 0; }
    }
    function combatInit() { var p = RPG.player; C.vel = V(p.vx, p.vy, p.vz); C.burst = ZERO; }
    function searchInit(l, limit) {
        var p = RPG.player, scale = speedScale(), lm = 1 + 0.2 * l;
        var maxN = NORMAL_MAX * lm * scale * limit / 100, maxS = SPRINT_MAX * lm * scale * limit / 100, cap = Math.max(maxN, maxS);
        var m = V(p.vx, p.vy, p.vz);
        if (lenSq(m) < 1e-5) { st.vec = mul(p.look, maxN * 0.35); return; }
        st.vec = mul(norm(m), Math.min(len(m), cap));
    }
    function isFlyingFast() {
        var s = len(st.vec);
        if (st.fast) { if (s < FAST_EXIT) st.fast = false; }
        else if (s > FAST_ENTER) st.fast = true;
        return st.fast;
    }

    // ---- toggles (FlySkillEvent.onKeyPress / performStandardToggle) ----
    function standardToggle() {
        var p = RPG.player;
        if (!created() || stunned()) return;
        var flyActive = isFlying();
        if (lvl("kicontrol") <= 0) { if (!flyActive) actionbar(tr("message.dragonminez.flight.no_kicontrol")); return; }
        if (lvl("fly") <= 0) { if (!flyActive) actionbar(tr("message.dragonminez.flight.no_fly")); return; }
        if (!flyActive && release() < 5) { actionbar(tr("message.dragonminez.flight.low_power_release")); return; }
        if (!flyActive) {
            if (!creative() && p.resource("ki") < activationCost(lvl("fly"))) return;
            if (p.onGround) { st.pendingGround = true; st.groundStart = RPG.nowMs(); }
            else requestOn();
        } else st.pendingDisable = !st.pendingDisable;
    }
    function modeSwitch() {                 // Left Alt + F (FlightModeC2S)
        if (!created() || stunned()) return;
        if (lvl("kicontrol") <= 0) { actionbar(tr("message.dragonminez.flight.no_kicontrol")); return; }
        if (lvl("fly") <= 0) { actionbar(tr("message.dragonminez.flight.no_fly")); return; }
        send({ a: "mode", v: -1 });
        RPG.sound("dmzpack:ui_menu_switch", 0.7, 1.0);
    }
    function requestOn() { send({ a: "on" }); st.awaitOn = 12; }
    function requestOff() { send({ a: "off" }); }

    // ---- dash input (ClientStatsEvents: R, double within 300 ms) ----
    var lastDash = 0;
    function dashInput() {
        if (!created() || stunned() || rooted()) return;
        var now = RPG.nowMs(), dbl = now - lastDash <= 300;
        lastDash = now;
        var k = keys(false), x = (k.r ? 1 : 0) - (k.l ? 1 : 0), z = (k.f ? 1 : 0) - (k.b ? 1 : 0);
        if (x === 0 && z === 0) z = 1;
        send({ a: "dash", x: x, z: z, dbl: dbl });
    }

    RPG.net.on("dmz_fly", function (d) {
        var a = d && d.a;
        if (a === "key") { if (RPG.isKeyDown("key.keyboard.left.alt")) modeSwitch(); else standardToggle(); }
        else if (a === "menu") standardToggle();
        else if (a === "dash") dashInput();
    });

    // ---- search flight (FlySkillEvent.handleFlightMovement) ----
    function searchFlight(p, l, limit, restricted) {
        var scale = speedScale(), lm = 1 + 0.2 * l;
        var maxN = NORMAL_MAX * lm * scale * limit / 100, maxS = SPRINT_MAX * lm * scale * limit / 100;
        var k = keys(restricted), sprinting = !restricted && p.sprinting;
        var hasInput = k.f || k.b || k.l || k.r;
        var fast = isFlyingFast(), canSprint = sprinting && fast;
        var curMax = canSprint ? maxS : maxN, accel = ACCEL * scale;
        if (canSprint && !st.wasSprintAir) RPG.sound("dmzpack:transform_on", 0.7, 1.2);
        st.wasSprintAir = canSprint;

        var look = p.look, target = ZERO;
        if (k.f) target = add(target, look);
        if (k.b) target = add(target, mul(look, -0.5));
        if (fast) {
            var side = norm(V(-look.z, 0, look.x));                   // the right-hand side
            if (k.l) target = add(target, mul(side, -0.7));
            if (k.r) target = add(target, mul(side, 0.7));
        } else {
            if (k.l) { var lv = norm(yRot(look, 90)); target = add(target, V(lv.x * 0.7, 0, lv.z * 0.7)); }
            if (k.r) { var rv = norm(yRot(look, -90)); target = add(target, V(rv.x * 0.7, 0, rv.z * 0.7)); }
        }
        // double-tapping A/D at speed is DMZ's barrel roll (a camera/model roll: no API for it)
        st.wasLeft = k.l; st.wasRight = k.r;

        var cur = len(st.vec);
        if (st.pendingDisable) {
            var slowed = Math.max(0, cur - EXIT_DECEL * scale);
            st.vec = cur > 0.0001 ? mul(norm(st.vec), slowed) : ZERO;
            if (lenSq(st.vec) < 0.03) { st.pendingDisable = false; requestOff(); resetFlight(); return; }
        } else if (hasInput && len(target) > 0.001) {
            target = norm(target);
            if (canSprint) st.vec = mul(target, maxS);
            else {
                var minSpeed = CFG.combatFlyBaseSpeed * lm * scale;
                var ts = Math.max(minSpeed, Math.min(cur + accel, curMax));
                var tv = mul(target, ts);
                var dir = cur > 0.001 ? mul(st.vec, 1 / cur) : ZERO;
                if (fast && dot(dir, target) > TURN_REVERSAL_DOT) st.vec = mul(norm(lerpV(dir, target, TURN_FAST)), lerp(TURN_FAST, cur, ts));
                else st.vec = lerpV(st.vec, tv, TURN_NORMAL);
            }
            st.hovering = Math.min(1, st.hovering + 0.1);
        } else {
            if (cur > 0.01) st.vec = mul(norm(st.vec), Math.max(0, cur - DECEL * lm));
            else st.vec = ZERO;
        }
        var after = len(st.vec);
        if (after > curMax) st.vec = mul(norm(st.vec), Math.max(curMax, after - DECEL * lm));

        if (hardStopped()) { st.vec = ZERO; p.setVelocity(0, -1.5, 0); }
        else { var ff = flyFactor(); if (ff < 1) st.vec = mul(st.vec, ff); }

        if (len(st.vec) > 0.01 || st.pendingDisable) { p.setVelocity(st.vec.x, st.vec.y, st.vec.z); st.vh = 0; }
        else hover(p, k.j, k.c, l, maxN);

        if (p.onGround && !st.pendingAct) { st.pendingDisable = false; requestOff(); resetFlight(); }
    }
    function hover(p, jump, crouch, l, maxV) {
        if (jump) { if (st.vh < 20) st.vh = clamp(st.vh + 1, -20, 20); }
        else if (crouch) { if (st.vh > -20) st.vh = clamp(st.vh - 1, -20, 20); }
        else if (st.vh > -3) st.vh = clamp(st.vh - 1, -3, 20);
        else if (st.vh < -3) st.vh = clamp(st.vh + 1, -20, -3);
        var t = RPG.time(), y;
        if (st.vh >= -3 && st.vh <= 0 && !jump && !crouch) y = SLOW_DESCENT * hoverDescentFactor(l) + Math.sin(t / 10) / 200;
        else if (st.vh === 0) y = Math.sin(t / 10) / 100;
        else y = st.vh / 60;
        if (!jump && !crouch && groundDistance() <= MIN_CLEARANCE) y = Math.max(0, y);
        y = clamp(y, -maxV, maxV);
        p.setVelocity(p.vx * 0.9, y, p.vz * 0.9);
        if (st.hovering < 1) st.hovering = Math.min(1, st.hovering + 0.1);
    }

    // ---- combat flight (CombatFlightHandler.handle) ----
    var DIRS = [V(0, 0, 0), V(0, 0, 0), V(0, 0, 0), V(0, 0, 0), V(0, 1, 0), V(0, -1, 0)];
    function combatFlight(p, l, limit, restricted) {
        if (stunned()) { C.vel = ZERO; C.burst = ZERO; C.sustained = -1; p.setVelocity(0, -1.5, 0); return; }
        var scale = speedScale(), lm = 1 + 0.2 * l;
        var base = CFG.combatFlyBaseSpeed * COMBAT_SCALE * lm * scale * limit / 100;
        var sprintSpeed = CFG.combatFlySprintSpeed * COMBAT_SCALE * lm * scale * limit / 100;
        var k = keys(restricted), sprint = k.sprintKey;
        var yaw = p.yaw * Math.PI / 180, fwd = V(-Math.sin(yaw), 0, Math.cos(yaw)), right = V(-fwd.z, 0, fwd.x);
        var pressed = [k.f, k.b, k.l, k.r, k.j, k.c];
        doubleTaps(pressed, fwd, right, scale, l);

        var h = ZERO;
        if (k.f) h = add(h, fwd);
        if (k.b) h = add(h, mul(fwd, -1));
        if (k.l) h = add(h, mul(right, -1));
        if (k.r) h = add(h, right);
        var hasH = lenSq(h) > 1e-4, maxH = sprint ? sprintSpeed : base;
        if (C.sustained >= 0 && C.sustained <= 3 && pressed[C.sustained]) maxH *= CFG.combatFlyHoldSpeedMultiplier;
        var th = hasH ? mul(norm(h), maxH) : ZERO;
        var maxV = VERTICAL_RATE * scale;
        if ((C.sustained === 4 || C.sustained === 5) && pressed[C.sustained]) maxV *= CFG.combatFlyHoldSpeedMultiplier;
        var ty = k.j ? maxV : k.c ? -maxV : PASSIVE_DESCENT * hoverDescentFactor(l);

        C.vel = V(lerp(SMOOTHING, C.vel.x, th.x), lerp(SMOOTHING, C.vel.y, ty), lerp(SMOOTHING, C.vel.z, th.z));
        C.burst = mul(C.burst, BURST_DECAY);
        if (lenSq(C.burst) < 1e-6) C.burst = ZERO;
        var comb = add(C.vel, C.burst);
        if (!k.j && comb.y < 0 && groundDistance() <= MIN_CLEARANCE) {
            C.vel = V(C.vel.x, Math.max(0, C.vel.y), C.vel.z);
            C.burst = V(C.burst.x, 0, C.burst.z);
            comb = add(C.vel, C.burst);
        }
        if (hardStopped()) { C.vel = ZERO; C.burst = ZERO; p.setVelocity(0, -1.5, 0); return; }
        var ff = flyFactor();
        if (ff < 1) { C.vel = mul(C.vel, ff); C.burst = mul(C.burst, ff); comb = add(C.vel, C.burst); }
        p.setVelocity(comb.x, comb.y, comb.z);
    }
    function doubleTaps(pressed, fwd, right, scale, l) {
        var now = RPG.nowMs(), cdMs = CFG.combatFlyImpulseCooldownTicks * 50;
        if (C.sustained !== -1 && !pressed[C.sustained]) C.sustained = -1;
        DIRS[0] = fwd; DIRS[1] = mul(fwd, -1); DIRS[2] = mul(right, -1); DIRS[3] = right;
        for (var dir = 0; dir < 6; dir++) {
            var down = pressed[dir];
            if (down && !C.wasDown[dir]) {
                var dbl = now - C.lastTap[dir] <= DOUBLE_TAP_MS;
                C.lastTap[dir] = now;
                if (dbl && now - C.lastImpulse >= cdMs) {
                    C.burst = add(C.burst, mul(DIRS[dir], 1.0 * scale * (1 + 0.2 * l)));
                    send({ a: "impulse", dir: dir });
                    C.lastImpulse = now;
                    C.sustained = dir;
                }
            }
            C.wasDown[dir] = down;
        }
    }

    // ---- MovementSkillsHandler (jump boost, air drag) ----
    var MS = { air: 0, wasJumping: false, applied: false };
    function movementSkills(p, flyingNow) {
        if (stunned()) { MS.air = 0; MS.wasJumping = false; MS.applied = false; return; }
        var rel = release() >= 5;
        var jumpLvl = rel && owned("jump") && active("jump") ? lvl("jump") : 0;
        var k = keys(false), moving = k.f || k.b || k.l || k.r;
        var speedAttr = num(RPG.getVar("dmz_speed_attr", 0.1), 0.1);
        if (!p.onGround && moving && speedAttr > 0.1 && !flyingNow) {
            var comp = 1 + Math.min(0.085, (speedAttr / 0.1 - 1) * 0.015);
            p.setVelocity(p.vx * comp, p.vy, p.vz * comp);
        }
        if (jumpLvl > 0) {
            var jumping = !p.onGround && p.vy > 0;
            if (jumping && !MS.wasJumping && !MS.applied) {
                var boost = ((1 + jumpLvl * 0.1) - 1.25) * 0.18 * clamp(jumpFactor(), 0, 2);
                p.addVelocity(0, boost, 0);
                MS.applied = true;
            }
            if (jumping && k.j) { MS.air++; if (MS.air <= jumpLvl) p.addVelocity(0, 0.11, 0); }
            if (p.onGround) { MS.air = 0; MS.applied = false; }
            MS.wasJumping = jumping;
        } else { MS.air = 0; MS.wasJumping = false; MS.applied = false; }
    }

    // ---- FlightSoundInstance (elytra wind, louder and higher the faster you fly) ----
    var SND = { h: 0, vol: 0.1, pitch: 1 };
    function flightSound(p, flyingNow) {
        if (!(flyingNow && !p.onGround && !p.inWater)) { if (SND.h) { RPG.soundStop(SND.h); SND.h = 0; } return; }
        if (!SND.h || !RPG.isSoundPlaying(SND.h)) { SND.h = RPG.soundLoop("minecraft:item.elytra.flying", 0.1, 1); SND.vol = 0.1; SND.pitch = 1; }
        var pct = Math.sqrt(p.vx * p.vx + p.vy * p.vy + p.vz * p.vz) / 2.0, tv = 0, tp = 1;
        if (pct < 0.33) tv = 0;
        else if (pct < 0.5) tv = lerp((pct - 0.33) / 0.17, 0.1, 0.4);
        else if (pct < 0.75) { var r = (pct - 0.5) / 0.25; tv = lerp(r, 0.4, 0.8); tp = lerp(r, 1, 1.2); }
        else { tv = 1; tp = 1.2 + (pct - 0.75) * 0.5; }
        SND.vol = Math.min(1, lerp(0.1, SND.vol, tv)); SND.pitch = lerp(0.1, SND.pitch, tp);
        if (SND.h) RPG.soundSet(SND.h, SND.vol, SND.pitch);
    }

    // ---- every client tick (end of tick, like DMZ) ----
    function report(flyingNow) {
        var s = flyingNow ? { fast: flightMode() === 0 && st.fast, sprint: st.wasSprintAir } : null;
        var was = st.sent;
        if (!s) { st.sent = null; return; }
        if (!was || was.fast !== s.fast || was.sprint !== s.sprint) { st.sent = s; send({ a: "state", fast: s.fast, sprint: s.sprint }); }
    }
    function tick() {
        var p = RPG.player;
        if (!p.present) return;
        var started = false;
        if (st.pendingGround) {
            if (RPG.nowMs() - st.groundStart >= DOUBLE_TAP_MS) {
                p.setVelocity(p.vx, 0.42, p.vz);               // jumpFromGround
                st.pendingAct = true; st.pendingGround = false; started = true;
            } else if (!p.onGround) st.pendingGround = false;
        }
        if (st.pendingAct) {
            if (!started && p.vy < 0 && !p.onGround) { requestOn(); st.pendingAct = false; }
            else if (!started && p.onGround) st.pendingAct = false;
        }
        if (!created() || !owned("fly")) { if (SND.h) flightSound(p, false); return; }

        var flyingNow = isFlying(), l = lvl("fly"), limit = speedLimit(), modeNow = flightMode(), combat = modeNow === 1;
        movementSkills(p, flyingNow);
        // our server sync is a little slower than DMZ's: hold the height while "on" is on its way
        if (st.awaitOn > 0) {
            if (flyingNow) st.awaitOn = 0;
            else { st.awaitOn--; if (!p.onGround && p.vy < 0) p.setVelocity(p.vx, 0, p.vz); }
        }
        if (flyingNow && !st.wasActive) {
            if (combat) combatInit(); else searchInit(l, limit);
            st.lastMode = modeNow;
        }
        if (flyingNow && modeNow !== st.lastMode) {
            if (combat) { resetFlight(); combatInit(); }
            else { resetCombat(); searchInit(l, limit); }
            actionbar(tr(combat ? "dragonminez.flight.mode.switched.combat" : "dragonminez.flight.mode.switched.search", ["Left Alt + F"]));
            st.lastMode = modeNow;
        }
        var restricted = rooted() || stunned() || actionCharging() || chargingKi();
        if (flyingNow) {
            if (rooted()) { st.vec = ZERO; p.setVelocity(0, 0, 0); }
            else if (combat) {
                if (st.pendingDisable) { st.pendingDisable = false; requestOff(); resetCombat(); resetFlight(); report(false); flightSound(p, false); return; }
                combatFlight(p, l, limit, restricted);
            } else searchFlight(p, l, limit, restricted);
        } else if (!st.pendingDisable) {
            resetFlight(); resetCombat(); st.lastMode = 0;
        }
        st.wasActive = flyingNow;
        report(flyingNow && isFlying());
        flightSound(p, flyingNow);
    }
    RPG.on("tick", tick);
    RPG.on("load", function () { send({ a: "hello" }); });

    // our own fly animation follows the local fast-flight state at once (others get it from the server)
    if (typeof DBR_ANIMATOR !== "undefined") DBR_ANIMATOR.extend(function (pl, out) {
        if (!pl.local || !isFlying()) return;
        var b = out.layers.base;
        if (typeof b !== "string" || b.indexOf("base.fly") !== 0) return;
        var fast = flightMode() === 0 && st.fast;
        if (fast) out.layers.base = "base.fly_fast";
        else if (b === "base.fly_fast") out.layers.base = pl.keyForward ? "base.fly_front" : pl.keyBack ? "base.fly_back" : pl.keyLeft ? "base.fly_left" : pl.keyRight ? "base.fly_right" : "base.fly_idle";
    });

    return {
        actionbar: actionbar, tr: tr, isFlying: isFlying, isFlyingFast: function () { return isFlying() && flightMode() === 0 && st.fast; },
        toggle: standardToggle, modeSwitch: modeSwitch, dash: dashInput,
        // for tests
        _st: st, _C: C, _tick: tick
    };
})();
