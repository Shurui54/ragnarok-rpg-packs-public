// =====================================================================================
//  DMZ world bosses on the client (server: scripts/77_dmz_world_bosses.js). Ports of DragonMine Z (GPL-3.0):
//   - WorldBossContributionHUD: 150 px panel on the right, boss name FFD54F + fight timer, up to 8 rows
//     ([rank] name - local FFE066, knocked out FF7A7A "(KO)" - points / share alternating every 10 s, aura
//     coloured bar). Lingers 15 s after the fight. Movable ("Boss Contribution").
//   - WorldBossReviveOverlay: "Reviving <name>" + percent over the green charge bar (kicharge_hud.png).
//   - WorldBossResultsScreen (simplified): ranking with points/share, your reward chances and what you got.
//   - boss music (looping) while in the fight's audience, victory sting menu_music_12.
// =====================================================================================
(function () {
    var FONT = "dmzpack:smooth", W = 150, HEADER = 14, ROW = 15, MAX_ROWS = 8, LINGER = 15000;
    var C = null, CAT = 0, REV = { casting: false, progress: 0, target: "" }, REV_A = 0;
    function tr(key, fallback) {
        var args = Array.prototype.slice.call(arguments, 2), i = 0;
        if (!RPG.hasTranslation(key)) return fallback;
        var s = String(RPG.translate(key));
        s = s.replace(/%(\d+)\$s/g, function (m, n) { var v = args[Number(n) - 1]; return v === undefined ? "" : String(v); });
        return s.replace(/%s|%d/g, function () { var v = args[i++]; return v === undefined ? "" : String(v); }).replace(/%%/g, "%");
    }
    function fmt(n) { n = Math.round(n || 0); return n >= 1e9 ? (n / 1e9).toFixed(2) + "B" : n >= 1e6 ? (n / 1e6).toFixed(2) + "M" : n >= 1e4 ? (n / 1e3).toFixed(1) + "K" : String(n); }
    function time(t) { var s = Math.max(0, Math.floor(t / 20)); return Math.floor(s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60); }

    RPG.net.on("dmz_wb_contrib", function (d) { C = d; CAT = RPG.nowMs(); });
    RPG.net.on("dmz_wb_revive", function (d) { REV = d || { casting: false }; });
    RPG.net.on("dmz_wb_music", function (d) {
        if (!d || !d.id) { RPG.music("", 1, false); return; }
        RPG.music(d.id, 1, !d.once);
    });
    RPG.net.on("dmz_wb_results", function (d) { openResults(d); });

    function drawContribution(ctx) {
        var editing = ctx.isEditing(), unit = Math.max(0.25, ctx.height / 360), sc = 0.8 * unit;
        var data = C;
        if (data && data.finished && RPG.nowMs() - CAT > LINGER) { C = null; data = null; }
        if (!data && !editing) return;
        if (!data) data = { boss: "World Boss", elapsed: 6600, entries: [{ name: "Goku", points: 12600000, share: 0.46, aura: "#4FC3FF" }, { name: "Vegeta", points: 8100000, share: 0.29, aura: "#FFD54F" },
            { name: "Piccolo", points: 4400000, share: 0.16, aura: "#7CFDD6", ko: true }, { name: "Krillin", points: 2500000, share: 0.09, aura: "#FF8A65" }] };
        var rows = Math.max(1, Math.min(MAX_ROWS, data.entries.length)), h = (HEADER + MAX_ROWS * ROW) * sc, x = ctx.width - 6 * unit - W * sc, y = ctx.height / 2 - h / 2;
        if (!ctx.group("dmz_wb_contribution", "Boss Contribution", x, y, W * sc, h)) return;
        var a = data.finished ? Math.max(0, 1 - Math.max(0, (RPG.nowMs() - CAT) / LINGER - 0.85) / 0.15) : 1;
        ctx.push();
        ctx.translate(x, y + (MAX_ROWS - rows) * ROW * sc / 2);
        ctx.scale(sc, sc);
        var ph = HEADER + rows * ROW + 2;
        ctx.fill(1, 1, W - 2, ph - 2, "#141B25", 0.78 * a);
        ctx.fill(0, 0, W, 1, "#070A0F", 0.92 * a); ctx.fill(0, ph - 1, W, 1, "#070A0F", 0.92 * a);
        ctx.fill(0, 1, 1, ph - 2, "#070A0F", 0.92 * a); ctx.fill(W - 1, 1, 1, ph - 2, "#070A0F", 0.92 * a);
        ctx.fill(4, HEADER - 2, W - 8, 1, "#000000", 0.35 * a);
        ctx.textStyled(data.boss, 4, 3, 0.75, "#FFD54F", a, 0, FONT, "#000000");
        ctx.textStyled(time(data.elapsed + (data.finished ? 0 : (RPG.nowMs() - CAT) / 50)), W - 4, 3, 0.75, "#B8C0CC", a, 1, FONT, "#000000");
        var me = RPG.player.name, list = data.entries.slice(0, MAX_ROWS), best = data.entries.length ? Math.max(1e-6, data.entries[0].points) : 1;
        var myIdx = -1;
        data.entries.forEach(function (e, i) { if (e.name === me) myIdx = i; });
        if (myIdx >= MAX_ROWS) list[MAX_ROWS - 1] = data.entries[myIdx];
        var pct = Math.floor(RPG.nowMs() / 10000) % 2 === 0;
        list.forEach(function (e, i) {
            var rank = data.entries.indexOf(e) + 1, ry = HEADER + i * ROW, local = e.name === me;
            ctx.textStyled("[" + rank + "]", 4, ry + 1, 0.75, "#B8C0CC", a, 0, FONT, "#000000");
            var rw = ctx.textWidthIn("[" + rank + "]", FONT) * 0.75;
            ctx.textStyled(e.ko ? e.name + " " + tr("gui.dragonminez.worldboss.contribution.knocked_out", "(KO)") : e.name, 4 + rw + 3, ry + 1, 0.75, e.ko ? "#FF7A7A" : local ? "#FFE066" : "#FFFFFF", a, 0, FONT, "#000000");
            ctx.textStyled(pct ? Math.round(e.share * 100) + "%" : fmt(e.points), W - 4, ry + 1, 0.75, "#E8ECF2", a, 1, FONT, "#000000");
            var bw = W - 8, by = ry + ROW - 6, f = Math.max(0, Math.min(1, e.points / best));
            ctx.fill(4, by, bw, 4, "#000000", 0.5 * a);
            ctx.fill(4, by, bw * f, 4, e.ko ? "#777777" : (e.aura || "#4FC3FF"), 0.95 * a);
            if (bw * f > 1.5) ctx.fill(4 + bw * f - 1, by, 1, 4, "#FFFFFF", 0.7 * a);
        });
        ctx.pop();
        ctx.endGroup();
    }
    function drawRevive(ctx) {
        REV_A += ((REV.casting ? 1 : 0) - REV_A) * 0.25;
        if (REV_A <= 0.01) return;
        var tex = "dmzpack:textures/gui/hud/kicharge_hud.png", s = 1.125, bw = 145 * s, x = (ctx.width - bw) / 2, y = ctx.height - 72, p = Math.max(0, Math.min(1, REV.progress || 0));
        ctx.quad(tex, x, y, 145 * s, 14 * s, 0, 0, 145 / 256, 14 / 256, "#FFFFFF", REV_A);
        ctx.quad(tex, x, y, 148 * s * p, 14 * s, 0, 14 / 256, (148 * p) / 256, 28 / 256, "#5BD64A", REV_A);
        ctx.textStyled(Math.round(p * 100) + "%", ctx.width / 2, y - 13, 1, "#B9FFA8", REV_A, 0.5, FONT, "#000000");
        ctx.textStyled(tr("gui.dragonminez.worldboss.revive.casting", "Reviving " + REV.target, REV.target || ""), ctx.width / 2, y - 24, 1, "#B9FFA8", REV_A, 0.5, FONT, "#000000");
    }

    function openResults(d) {
        if (!d) return;
        var els = [{ id: "bg", type: "rect", anchor: "center", x: -170, y: -108, w: 340, h: 216, color: "#E0141B25" },
            { id: "t", type: "text", anchor: "center", x: -158, y: -100, text: "§l" + tr("gui.dragonminez.worldboss.results.title", "Boss: " + d.boss, d.boss), color: "#FFD54F" },
            { id: "dur", type: "text", anchor: "center", x: 158, y: -100, text: time(d.duration), align: "right", color: "#FF6B6B" },
            { id: "ch", type: "text", anchor: "center", x: -158, y: -86, text: tr("gui.dragonminez.worldboss.results.contribution", "Contribution"), color: "#C7EAFC" },
            { id: "rh", type: "text", anchor: "center", x: 20, y: -86, text: tr("gui.dragonminez.worldboss.results.rewards", "Possible Rewards"), color: "#C7EAFC" }];
        var me = RPG.player.name, mine = null;
        (d.players || []).slice(0, 10).forEach(function (p, i) {
            var rank = i === 0 ? tr("gui.dragonminez.worldboss.results.rank.mvp", "MVP") : i === 1 ? tr("gui.dragonminez.worldboss.results.rank.second", "2nd") : i === 2 ? tr("gui.dragonminez.worldboss.results.rank.third", "3rd") : (i + 1) + "th";
            els.push({ id: "p" + i, type: "text", anchor: "center", x: -158, y: -72 + i * 16, text: "§e" + rank + " " + (p.name === me ? "§a" : "§f") + p.name + " §7" + fmt(p.points) + " (" + Math.round(p.share * 100) + "%)", color: "#FFFFFF",
                tooltip: [tr("gui.dragonminez.worldboss.results.damage", "Damage dealt") + ": " + fmt(p.dmg), tr("gui.dragonminez.worldboss.results.received_damage", "Damage received") + ": " + fmt(p.recv),
                    tr("gui.dragonminez.worldboss.results.healed", "Healing done") + ": " + fmt(p.heal)] });
            els.push({ id: "pb" + i, type: "rect", anchor: "center", x: -158, y: -63 + i * 16, w: Math.max(1, 96 * p.share), h: 3, color: p.aura || "#4FC3FF" });
            if (p.name === me) mine = p;
        });
        els.push({ id: "div", type: "rect", anchor: "center", x: 16, y: -88, w: 1, h: 180, color: "#60FFFFFF" });
        if (mine) (mine.rewards || []).forEach(function (r, i) {
            els.push({ id: "r" + i, type: "text", anchor: "center", x: 20, y: -72 + i * 13, color: "#FFFFFF",
                text: (r.got ? "§a✔ " : "§7") + r.label + " §8" + (r.guaranteed ? tr("gui.dragonminez.worldboss.results.guaranteed", "Guaranteed") : Math.round(r.chance * 100) + "%") });
        });
        else els.push({ id: "none", type: "text", anchor: "center", x: 20, y: -72, text: "§7" + tr("gui.dragonminez.worldboss.results.none", "None"), color: "#FFFFFF" });
        els.push({ id: "close", type: "button", anchor: "center", x: -40, y: 84, w: 80, h: 18, label: tr("gui.dragonminez.worldboss.results.close", "Close"), onClick: function () { RPG.screen.close(); } });
        RPG.screen.open({ id: "dmz_wb_results", referenceHeight: 360, background: "dim", elements: els });
    }

    RPG.on("load", function () { RPG.hud.onRender(drawContribution); RPG.hud.onRender(drawRevive); });
})();
