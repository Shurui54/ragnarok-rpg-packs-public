#version 150
// The original kiattack vertex shader (GPL-3.0, see NOTICE.md), for the flat ember quads (position and UV).

in vec3 Position;
in vec2 UV0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec3 vNormal;
out vec3 vViewDir;
out vec3 vLocalPos;
out vec2 vUv;
out float vAlpha;
out float vInside;

void main() {
    vec4 viewPos = ModelViewMat * vec4(Position, 1.0);
    gl_Position = ProjMat * viewPos;
    vInside = 0.0;
    vNormal = vec3(0.0, 0.0, 1.0);
    vViewDir = normalize(-viewPos.xyz);
    vLocalPos = Position;
    vAlpha = 1.0;
    vUv = UV0;
}
