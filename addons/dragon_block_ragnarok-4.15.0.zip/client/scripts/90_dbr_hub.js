// =====================================================================================
//  90_dbr_hub.js - the Dragon Block menu screen (/dbrgui, the "Dragon Block menu" key)
// =====================================================================================
//  Port of the Ragnarok original's (GPL-3.0, see NOTICE.md) hub screens: SUHubScreen (the player menu, a flat list of
//  full-width rows) and SduHubScreen (the editor hub, one dropdown section per module that expands into its editors),
//  on the original's shared canvas (SagaBaseScreen / GuiTheme: a 300 x 260 panel, the logo centred in the header, rows
//  22 apart from y 34, a "1-9 of 13" count beside the logo when the list scrolls, the scrollbar in its own column and
//  Close centred in the footer), drawn with its own GUI art (resources/assets/dbr/textures/gui/theme/).
//
//  The server (scripts/98_dbr_hub.js) sends only the rows this player may open and re-checks every click; a row opens
//  its screen exactly as that screen's own key or command does. Every key and command still works as before.
//
//  Back: Esc on a screen opened from the menu returns to the menu (its own Close button still closes it), the way the
//  Ragnarok original's editors go back to their hub.
// =====================================================================================
var DBR_HUB_UI = (function () {
    var THEME = "dbr:textures/gui/theme/";
    var PANEL = THEME + "panel.png", BUTTONS = THEME + "buttons.png", FIELD = THEME + "dropdown.png", LOGO = THEME + "logo.png",
        BAR = THEME + "scrollbar.png", THUMB = THEME + "scrollbar_alt.png";
    // GuiTheme
    var UI_W = 300, UI_H = 260, PANEL_INSET = 6, PANEL_SRC_INSET = 17, BUTTON_H = 14, ROW_H = 22, LIST_TOP = 34,
        SCROLLBAR_PANEL_INSET = 8, SCROLLBAR_W = 12, UNIT = 2, FOOTER_GAP = 8;
    var COLOR_TITLE = "#F6E27A", COLOR_LABEL = "#CFE8B0", COLOR_ROW = "#E0E0E0";
    var ROW_RIGHT = UI_W - SCROLLBAR_PANEL_INSET - SCROLLBAR_W - UNIT;       // rowControlRight
    var ROW_LEFT = UI_W - ROW_RIGHT;                                         // rowBandLeft (centred, scrollbar-clear)
    var FOOTER_Y = UI_H - FOOTER_GAP - BUTTON_H;
    var CAP = Math.max(1, Math.floor((FOOTER_Y - UNIT - LIST_TOP) / ROW_H)); // rowsThatFit
    var BAR_X = UI_W - SCROLLBAR_PANEL_INSET - SCROLLBAR_W;
    // the logo, at a third of its size (the original draws its own logo a quarter size in the same header band)
    var LOGO_W = 75, LOGO_H = 14, LOGO_TOP = 3;

    var H = null;          // the open menu: { items: [...], scroll }
    var ID = "dbr_hub";

    function items(d) {
        var out = [];
        ((d && d.rows) || []).forEach(function (r) { out.push({ row: r }); });
        ((d && d.sections) || []).forEach(function (s) { out.push({ section: s }); });
        return out;
    }

    function themedButton(id, x, y, w, label, onClick, tip) {
        // buttons.png: two 264 x 38 states, the end caps (19 px) spliced at the button's height
        var b = { id: id, type: "button", anchor: "center", x: x - UI_W / 2, y: y - UI_H / 2, w: w, h: BUTTON_H,
            texture: BUTTONS, texW: 264, texH: 76, u: 0, v: 0, uw: 264, vh: 38, hoverU: 0, hoverV: 38, slice: 19, sliceDst: 7,
            label: label, textColor: COLOR_TITLE, hoverTextColor: COLOR_TITLE, onClick: onClick };
        if (tip) b.tooltip = tip;
        return b;
    }
    function sectionDropdown(id, x, y, w, s) {
        return { id: id, type: "dropdown", anchor: "center", x: x - UI_W / 2, y: y - UI_H / 2, w: w, h: BUTTON_H,
            options: s.entries.map(function (e) { return { value: e.id, label: e.label, tooltip: e.desc || undefined }; }),
            value: null, placeholder: s.label, search: false, maxVisible: 6, rowHeight: 14,
            texture: FIELD, u: 0, v: 0, uw: 145, vh: 87, texW: 145, texH: 87, slice: 5, sliceDst: 4,
            listTexture: FIELD, listU: 0, listV: 0, listUw: 145, listVh: 87, listTexW: 145, listTexH: 87, listSlice: 5,
            color: COLOR_TITLE, placeholderColor: COLOR_TITLE, arrowColor: COLOR_LABEL, highlight: "#33FFFFFF",
            selectedBg: "#40FFFFFF", selectedText: COLOR_TITLE, listBg: "#55000000",
            onChange: function (eid, v) {
                var e = null;
                s.entries.forEach(function (x) { if (x.id === v) e = x; });
                if (e) pick(e);
            } };
    }

    function maxScroll() { return H ? Math.max(0, H.items.length - CAP) : 0; }

    function show() {
        if (!H) return;
        H.scroll = Math.max(0, Math.min(H.scroll, maxScroll()));
        var els = [], total = H.items.length, end = Math.min(total, H.scroll + CAP), y = LIST_TOP;
        if (total > CAP) els.push({ id: "count", type: "text", anchor: "center", x: 10 - UI_W / 2, y: 20 - UI_H / 2,
            text: (H.scroll + 1) + "-" + end + " of " + total, color: COLOR_LABEL, shadow: false });
        for (var i = H.scroll; i < end; i++, y += ROW_H) {
            var it = H.items[i];
            if (it.section) els.push(sectionDropdown("s" + i, ROW_LEFT, y + 2, ROW_RIGHT - ROW_LEFT, it.section));
            else (function (r) { els.push(themedButton("r" + i, ROW_LEFT, y + 2, ROW_RIGHT - ROW_LEFT, r.label, function () { pick(r); }, r.desc || null)); })(it.row);
        }
        els.push(themedButton("close", UI_W / 2 - 45, FOOTER_Y, 90, "Close", function () { RPG.screen.close(); }));
        var mine = H;
        H.rebuilding = true;
        RPG.screen.open({ id: ID, referenceHeight: Math.round(UI_H / 0.95), background: "dim", elements: els, onBackground: render,
            onScroll: function (x, yy, d) { if (H !== mine || maxScroll() <= 0) return; var n = Math.max(0, Math.min(maxScroll(), H.scroll - (d > 0 ? 1 : -1))); if (n !== H.scroll) { H.scroll = n; show(); } },
            onMouse: function (mx, my, b, a) { if (H !== mine || a !== "down" || b !== 0) return; return barClick(mx, my); },
            onClose: function () { if (H === mine && !H.rebuilding) H = null; } });
        H.rebuilding = false;
    }

    var ORIGIN = { x: 0, y: 0 };
    function render(ctx) {
        if (!H) return;
        var ox = Math.round(ctx.width / 2 - UI_W / 2), oy = Math.round(ctx.height / 2 - UI_H / 2);
        ORIGIN.x = ox; ORIGIN.y = oy;
        ctx.nineSlice(PANEL, ox, oy, UI_W, UI_H, 0, 0, 351, 332, 351, 332, PANEL_SRC_INSET, PANEL_INSET);
        ctx.image(LOGO, ox + Math.round((UI_W - LOGO_W) / 2), oy + LOGO_TOP, LOGO_W, LOGO_H, 0, 0, 224, 42, 224, 42);
        var total = H.items.length;
        if (total > CAP) {
            var listH = CAP * ROW_H, thumbH = Math.max(8, Math.floor(listH * CAP / total)), max = maxScroll();
            var travel = listH - 2 - thumbH, thumbY = LIST_TOP + 1 + (max > 0 ? Math.round(travel * H.scroll / max) : 0);
            ctx.nineSlice(BAR, ox + BAR_X, oy + LIST_TOP, SCROLLBAR_W, listH, 0, 0, 23, 222, 23, 222, 5, 3);
            ctx.nineSlice(THUMB, ox + BAR_X + 1, oy + thumbY, SCROLLBAR_W - 2, thumbH, 0, 0, 23, 29, 46, 29, 4, 2);
        }
    }
    /** A click on the scrollbar track jumps the list there. */
    function barClick(mx, my) {
        if (!H || H.items.length <= CAP) return;
        var x = mx - ORIGIN.x, y = my - ORIGIN.y, listH = CAP * ROW_H;
        if (x < BAR_X || x >= BAR_X + SCROLLBAR_W || y < LIST_TOP || y >= LIST_TOP + listH) return;
        var n = Math.round((y - LIST_TOP) / listH * maxScroll());
        if (n !== H.scroll) { H.scroll = n; show(); }
        return false;
    }

    // ---- opening rows, and coming back on Esc ----------------------------------------------------------
    var BACK = { armed: false, launchedAt: 0, seen: false, escAt: 0, opens: 0 };
    function pick(r) {
        BACK.armed = true; BACK.seen = false; BACK.launchedAt = RPG.nowMs(); BACK.escAt = 0;
        H = null;
        RPG.screen.close();
        if (r.client) RPG.net.send(String(r.client.msg), r.client.data || {});
        else RPG.net.send("dbr_hub_go", { id: r.id });
    }
    RPG.on("screenOpen", function (kind, info) {
        BACK.opens++;
        if (!BACK.armed) return;
        if (kind === "script" && info && info.scriptId === ID) { BACK.armed = false; return; }
        BACK.seen = true;
    });
    RPG.on("screenClose", function (kind, info) {
        if (!BACK.armed || !BACK.seen || (info && info.scriptId === ID)) return;
        var now = RPG.nowMs(), esc = RPG.isKeyDown("key.keyboard.escape") || now - BACK.escAt < 700 ||
            (typeof DMZ_MENU_FX !== "undefined" && DMZ_MENU_FX.keyClosedAt && now - DMZ_MENU_FX.keyClosedAt() < 700);
        if (!esc) { BACK.armed = false; return; }
        var opens = BACK.opens;
        // another screen replacing this one (a sub page) keeps the way back; only an Esc to the game goes back to the menu
        RPG.schedule(2, function () {
            if (!BACK.armed || BACK.opens !== opens || RPG.screen.getOpen()) return;
            BACK.armed = false;
            RPG.net.send("dbr_hub", {});
        });
    });
    RPG.on("tick", function () {
        if (!BACK.armed) return;
        if (!BACK.seen && RPG.nowMs() - BACK.launchedAt > 5000) { BACK.armed = false; return; }   // nothing opened (refused)
        if (BACK.seen && RPG.isKeyDown("key.keyboard.escape")) BACK.escAt = RPG.nowMs();       // menus that close after an animation
    });

    RPG.net.on("dbr_hub_open", function (d) {
        var reopen = !!H && RPG.screen.getOpen() === ID;
        H = { items: items(d), scroll: reopen ? H.scroll : 0 };
        if (!reopen) RPG.uiSound("dmzpack:ui_menu_switch", 0.35, 1);
        show();
    });

    // ---- the key (Options > Controls > "Dragon Block Ragnarok") --------------------------------------------
    try { RPG.keys.register("dbr_hub", { name: "Dragon Block menu", key: "key.keyboard.grave.accent", category: "Dragon Block Ragnarok" }); } catch (e) { }
    RPG.on("keybind", function (id, down) { if (id === "dbr_hub" && down && !RPG.screen.getOpen()) RPG.net.send("dbr_hub", {}); });

    return { open: function () { RPG.net.send("dbr_hub", {}); }, isOpen: function () { return !!H; } };
})();
