// =====================================================================================
//  41_dbr_clash_lock.js - the clash lock on this player's own game
// =====================================================================================
//  The server holds a fighter in a melee or beam clash (scripts/40b_dbr_clash_lock.js) and says so
//  with "dbr_lock". Here the movement keys, jumping, sneaking, sprinting and attacks are switched
//  off and the view is frozen facing the opponent, so nothing moves on this screen while the clash
//  runs (flight reads DBR_CLIENT_LOCK too). The clash inputs themselves (W/A/S/D in the melee duel,
//  right click in a beam clash) are read straight from the keys by their own scripts.
// =====================================================================================
var DBR_CLIENT_LOCK = (function () {
    var BASE = ["move", "jump", "sneak", "sprint", "attack"];
    var st = { on: false, keys: [] };
    function set(on, d) {
        try { if (st.keys.length) RPG.input.block(st.keys, false); } catch (e) { }
        // a beam still firing keeps its own view hold (51_dmz_ki_render.js "dmz_tech_firelock" lets go of it)
        try { if (on || !RPG.player.hasEffect("dmz_tech_rooted")) RPG.camera.lockRotation(false); } catch (e) { }
        st.keys = [];
        st.on = !!on;
        if (!on) return;
        st.keys = BASE.slice();
        if (!d.use) st.keys.push("use");
        try { RPG.input.block(st.keys, true); } catch (e) { }
        try {
            if (d.yaw !== undefined) RPG.player.setRotation(Number(d.yaw), Number(d.pitch) || 0);
            RPG.camera.lockRotation(true);
        } catch (e) { }
    }
    RPG.net.on("dbr_lock", function (d) { if (d) set(!!d.on, d); });
    RPG.on("unload", function () { set(false); });
    // a lost "off" (or a reload) must never leave the player stuck: the server's effect is the truth
    RPG.on("tick", function () { if (st.on && !RPG.player.hasEffect("dbr_clash_lock") && ++st.grace > 10) set(false); else if (!st.on || RPG.player.hasEffect("dbr_clash_lock")) st.grace = 0; });
    st.grace = 0;
    return { active: function () { return st.on || RPG.player.hasEffect("dbr_clash_lock"); } };
})();
