// =====================================================================================
//  51_dmz_ki_render.js - the original's ki attacks drawn with the original's own ki shader
// =====================================================================================
//  Ported from the original (GPL-3.0, see NOTICE.md): KiProjectileRenderer (balls: blast, giant ball, Supernova, Death Ball,
//  Soul Punisher, Fake Moon, barrage emitter, small blast), KiWaveRenderer (charging orb, beam, muzzle and head,
//  Final Flash's double orb), KiLaserRenderer (lasers, Special Beam Cannon with its spiral), KiDiskRenderer,
//  KiEmberRenderer (the fire-ash flakes), KiExplosionVisualRenderer and KiMeshFactory / KiSpiralMesh (meshes).
//  The GLSL is the original's kiattack shader (resources/assets/dbr/shaders/core/kiattack*), drawn by RPG.shaders.
//
//  The server (scripts/41_dmz_techniques.js) puts each shot's original look in its tag: k (ball, small, volley, wave,
//  beam, laser, disk), rt (original render type), sz (size), cs (wave cast size), ct (charge growth ticks). Every client
//  draws every shot it sees from that (and from the synced size, length, held flag and age), so everyone sees the
//  same orbs in the same hands. While drawn here, the engine's own look of the shot is hidden on this computer.
// =====================================================================================
var DMZ_KI_RENDER = (function () {
    var SH = "dbr:kiattack", SH_SPLAT = "dbr:kiattack_splat";
    var MESH = { sphere: "dbr:ki_sphere", tube: "dbr:ki_tube", quad: "dbr:ki_quad", spiral: "dbr:ki_spiral" };
    var SPIRAL_LEN = 10;                                        // 0.9 twists a block: 9 whole coils per segment
    var MUZZLE_FLAME_SCALE = 1.55, DOUBLE_WAVE_BALL_SCALE = 0.82, GIANT_FLAME_GAIN = 1.65, GIANT_EMBER_SCALE = 1.9;
    var CHARGE_BACKDRAFT = 0.35, COOLER_FLAME_GAIN = 1.2, KEEP = 40, REFRESH = 20;
    var EMBER_COUNT = 10, EMBER_PERIOD = 11, EMBER_IGNITE = 0.12, EMBER_FADE_FROM = 0.74, EMBER_R_START = 0.88, EMBER_R_END = 4.2;
    var EMBER_SIZE_BIRTH = 0.46, EMBER_SIZE_DEATH = 0.10, EMBER_COOL = 0.7, EMBER_BACKDRAFT = 1.85;
    var OWN = { dmz_ki_ball: 1, dmz_ki_giant: 1, dmz_ki_wave: 1, dmz_ki_beam: 1, dmz_ki_laser: 1, dmz_ki_disk: 1,
        dmz_tech_ball: 1, dmz_tech_wave: 1, dmz_tech_beam: 1, dmz_tech_laser: 1, dmz_tech_disk: 1, dmz_tech_bullet: 1 };

    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function rgb(h) { h = String(h || "#FFFFFF").replace("#", ""); var n = parseInt(h, 16); if (isNaN(n)) n = 0xFFFFFF; return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; }

    // ---- meshes (KiMeshFactory, KiSpiralMesh) --------------------------------------------------
    function sphereMesh() {
        var v = [], segs = 32, rings = 16;
        function pt(t, ph) { var x = Math.sin(t) * Math.cos(ph), y = Math.cos(t), z = Math.sin(t) * Math.sin(ph); v.push(x, y, z, 1, 1, 1, 1, x, y, z); }
        for (var i = 0; i < rings; i++) {
            var t1 = Math.PI * i / rings, t2 = Math.PI * (i + 1) / rings;
            for (var j = 0; j < segs; j++) {
                var p1 = 2 * Math.PI * j / segs, p2 = 2 * Math.PI * (j + 1) / segs;
                pt(t1, p1); pt(t1, p2); pt(t2, p2); pt(t2, p1);
            }
        }
        RPG.shaders.mesh(MESH.sphere, { format: "position_color_normal", mode: "quads", vertices: v });
    }
    function tubeMesh() {
        var v = [], segs = 32;
        function q(x, y, z, nx, ny, nz) { v.push(x, y, z, 1, 1, 1, 1, nx, ny, nz); }
        for (var i = 0; i < segs; i++) {
            var a1 = 2 * Math.PI * i / segs, a2 = 2 * Math.PI * (i + 1) / segs;
            var x1 = Math.cos(a1), y1 = Math.sin(a1), x2 = Math.cos(a2), y2 = Math.sin(a2);
            q(x1, y1, 0, x1, y1, 0); q(x2, y2, 0, x2, y2, 0); q(x2, y2, 1, x2, y2, 0); q(x1, y1, 1, x1, y1, 0);
            q(0, 0, 0, 0, 0, -1); q(x1, y1, 0, 0, 0, -1); q(x2, y2, 0, 0, 0, -1); q(0, 0, 0, 0, 0, -1);
            q(0, 0, 1, 0, 0, 1); q(x2, y2, 1, 0, 0, 1); q(x1, y1, 1, 0, 0, 1); q(0, 0, 1, 0, 0, 1);
        }
        RPG.shaders.mesh(MESH.tube, { format: "position_color_normal", mode: "quads", vertices: v });
    }
    function quadMesh() {
        RPG.shaders.mesh(MESH.quad, { format: "position_tex", mode: "quads", vertices: [-1, -1, 0, 0, 0, 1, -1, 0, 1, 0, 1, 1, 0, 1, 1, -1, 1, 0, 0, 1] });
    }
    // Special Beam Cannon's double helix for a beam 1 wide (radius 2, tubes 0.65 and 0.5), SPIRAL_LEN blocks long
    function spiralMesh() {
        var v = [], k = 2 * Math.PI * 0.9, radius = 2.0, rings = SPIRAL_LEN * 12, radial = 6, step = SPIRAL_LEN / rings;
        function frame(z, phase) {
            var a = k * z + phase;
            var c = [-radius * Math.sin(a), radius * Math.cos(a), z];
            var t = [-radius * k * Math.cos(a), -radius * k * Math.sin(a), 1], tl = Math.sqrt(t[0] * t[0] + t[1] * t[1] + 1);
            t = [t[0] / tl, t[1] / tl, t[2] / tl];
            var ref = Math.abs(t[2]) < 0.95 ? [0, 0, 1] : [1, 0, 0];
            var sd = [t[1] * ref[2] - t[2] * ref[1], t[2] * ref[0] - t[0] * ref[2], t[0] * ref[1] - t[1] * ref[0]], sl = Math.sqrt(sd[0] * sd[0] + sd[1] * sd[1] + sd[2] * sd[2]) || 1;
            sd = [sd[0] / sl, sd[1] / sl, sd[2] / sl];
            var up = [sd[1] * t[2] - sd[2] * t[1], sd[2] * t[0] - sd[0] * t[2], sd[0] * t[1] - sd[1] * t[0]];
            return { c: c, s: sd, u: up };
        }
        function tube(tr, phase) {
            var f0 = frame(0, phase);
            for (var i = 0; i < rings; i++) {
                var f1 = frame((i + 1) * step, phase);
                for (var j = 0; j < radial; j++) {
                    var a0 = 2 * Math.PI * j / radial, a1 = 2 * Math.PI * (j + 1) / radial;
                    ring(f0, a0, tr); ring(f0, a1, tr); ring(f1, a1, tr); ring(f1, a0, tr);
                }
                f0 = f1;
            }
        }
        function ring(f, ang, tr) {
            var cs = Math.cos(ang), sn = Math.sin(ang);
            var nx = f.s[0] * cs + f.u[0] * sn, ny = f.s[1] * cs + f.u[1] * sn, nz = f.s[2] * cs + f.u[2] * sn;
            v.push(f.c[0] + nx * tr, f.c[1] + ny * tr, f.c[2] + nz * tr, 1, 1, 1, 1, nx, ny, nz);
        }
        tube(0.5 * 1.3, 0); tube(0.5, Math.PI);
        RPG.shaders.mesh(MESH.spiral, { format: "position_color_normal", mode: "quads", vertices: v });
    }

    var ready = false, failed = false, stage = 0, myId = -1;
    function setup() {
        if (ready || failed) return ready;
        if (!RPG.shaders || !RPG.shaders.status || !RPG.world.projectiles) { failed = true; return false; }
        var a = RPG.shaders.status(SH, "position_color_normal"), b = RPG.shaders.status(SH_SPLAT, "position_tex");
        if (a === "failed" || b === "failed") { failed = true; RPG.log("[DBR] ki shader did not load; ki attacks keep the engine's look"); return false; }
        if (a !== "ready" || b !== "ready") return false;
        if (stage === 0) sphereMesh(); else if (stage === 1) tubeMesh(); else if (stage === 2) quadMesh(); else { spiralMesh(); ready = true; }
        stage++;
        return ready;
    }

    // ---- the shader's uniforms (all set, as one draw's uniforms outlive the next update) ---------------
    function uni(col, extra) {
        var u = { colorCore: col[0], colorBorder: col[1], colorOutline: col[2], alphaMult: 1, time: { k: { age: 0.05 } }, texBlend: 0, bloomMode: 0,
            globalAlpha: 1, shapeMode: 0, localPosMode: 0, zCut: -1, zCutFar: 2, flameMode: 0, blotchMode: 0, orbMode: 0, splatMode: 0,
            splatLife: 0, flameGain: 1, novaMode: 0 };
        if (extra) for (var k in extra) u[k] = extra[k];
        return u;
    }
    function draw(id, entity, ops, mesh, u, order) {
        RPG.shaders.draw(id, { mesh: mesh, shader: SH, entity: entity, x: 0, y: 0, z: 0, ops: ops, uniforms: u, bloom: { bloomMode: 1 },
            cull: false, depthWrite: false, ticks: KEEP, order: order || 20 });
    }
    function rotOps(dy) { return [["translate", 0, dy, 0], ["rotateY", { k: { yaw: -1 } }], ["rotateX", { k: { pitch: 1 } }]]; }

    // ---- KiEmberRenderer: 10 camera-facing flakes per ball (positions in ball radii) --------------------
    function imul(a, b) { var ah = (a >>> 16) & 0xffff, al = a & 0xffff, bh = (b >>> 16) & 0xffff, bl = b & 0xffff; return ((al * bl) + (((ah * bl + al * bh) << 16) >>> 0)) | 0; }
    function hash01(seed) {
        var h = (imul(seed, 374761393) + 668265263) | 0;
        h = imul(h ^ (h >>> 13), 1274126177);
        return ((h ^ (h >>> 16)) & 0x7FFFFFFF) / 0x7FFFFFFF;
    }
    // KiEmberRenderer's flakes as standing draws: each one's phase, flight, size, burn and fade are expressions of the
    // shot's age (no per-tick script work). R: the ball radius (a number, or {rate, max} while it grows with age);
    // base: world-space steps first (the ball's centre); back: the wake direction (world).
    function scaled(R, coef) {
        if (typeof R === "number") return R * coef;
        var m = R.max * coef;
        return { k: { age: R.rate * coef }, clamp: m < 0 ? [m, 0] : [0, m] };
    }
    // ember sets are queued and drawn within a time budget a tick (a set is 10 draws)
    var JOBS = [];
    function embers() { var args = arguments; JOBS.push(function () { embersNow.apply(null, args); }); }
    function embersNow(prefix, entity, base, R, col, back, backdraft, sizeScale) {
        var span = EMBER_R_END - EMBER_R_START, drag = EMBER_BACKDRAFT * backdraft;
        for (var i = 0; i < EMBER_COUNT; i++) {
            var seed = i * 131, ph = function (mul, add) { return { c: i / EMBER_COUNT, k: { age: 1 / EMBER_PERIOD }, frac: true, mul: mul, add: add }; };
            var dz = hash01(seed) * 2 - 1, ring = Math.sqrt(Math.max(0, 1 - dz * dz)), ang = hash01(seed + 97) * 2 * Math.PI;
            var d = [ring * Math.cos(ang), ring * Math.sin(ang), dz], t = [];
            for (var a = 0; a < 3; a++) t.push(ph(scaled(R, d[a] * span + back[a] * drag), scaled(R, d[a] * EMBER_R_START)));
            var sz = (0.75 + hash01(seed + 41) * 0.5) * sizeScale;
            RPG.shaders.draw(prefix + "_e" + i, { mesh: MESH.quad, shader: SH_SPLAT, entity: entity, x: 0, y: 0, z: 0,
                ops: base.concat([["translate", t[0], t[1], t[2]], ["billboard"], ["scale", ph(scaled(R, (EMBER_SIZE_DEATH - EMBER_SIZE_BIRTH) * sz), scaled(R, EMBER_SIZE_BIRTH * sz))]]),
                uniforms: { colorCore: col[0], colorBorder: col[1], colorOutline: col[2], alphaMult: { c: i / EMBER_COUNT, k: { age: 1 / EMBER_PERIOD }, frac: true, sin: true },
                    time: hash01(seed + 7) * 64, splatMode: 1, splatLife: { c: i / EMBER_COUNT, k: { age: 1 / EMBER_PERIOD }, frac: true }, globalAlpha: 1, bloomMode: 0, zCut: -1, zCutFar: 2 },
                bloom: { bloomMode: 1 }, cull: false, depthWrite: false, ticks: KEEP, order: 22 });
        }
    }
    function dirOf(yaw, pitch) {
        var y = yaw * Math.PI / 180, p = pitch * Math.PI / 180;
        return [-Math.sin(y) * Math.cos(p), -Math.sin(p), Math.cos(y) * Math.cos(p)];
    }
    function back(pr) { var d = dirOf(pr.yaw, pr.pitch); return [-d[0], -d[1], -d[2]]; }

    // ---- what each shot is --------------------------------------------------------------------------
    function lookOf(pr) {
        var t = null;
        if (pr.tag) { try { t = JSON.parse(pr.tag); } catch (e) { t = null; } }
        if (t && t.k) return t;
        switch (pr.def) {                                         // shots without a tag (mobs, bosses, raids)
            case "dmz_tech_wave": return { k: "wave", rt: 0, sz: pr.size / 1.5, cs: 0.2, ct: 12, f: 1 };
            case "dmz_tech_beam": return { k: "wave", rt: 0, sz: pr.size * 0.5, cs: 0.2, ct: 12, f: 1 };
            case "dmz_tech_laser": return { k: "laser", rt: 0, sz: pr.size * 0.35 * 0.5 / 0.08, f: 1 };
            case "dmz_tech_disk": return { k: "disk", rt: 0, sz: pr.size, ct: 0, f: 1, noBox: 1 };
            case "dmz_tech_bullet": return { k: "small", rt: 0, sz: pr.size, f: 1, noBox: 1 };
            case "dmz_tech_ball": return { k: "ball", rt: pr.size > 3 ? 2 : 1, sz: pr.size, ct: 0, f: 1, noBox: 1 };
        }
        return null;
    }

    // ---- KiProjectileRenderer -----------------------------------------------------------------------
    function ball(pr, L, col, P) {
        var sz = L.sz || pr.size, cy = L.noBox ? 0 : sz * 0.4, rt = L.rt || 0, age = pr.age;
        // KiBlastEntity: the ball grows over its cast time while held, then flies at full size
        var growing = pr.held && L.ct > 0 && age < L.ct;
        var S = growing ? { k: { age: sz / L.ct }, clamp: [0, sz] } : sz;
        var Snow = growing ? sz * age / L.ct : sz;
        var half = typeof S === "number" ? S * 0.5 : { k: { age: sz / L.ct * 0.5 }, clamp: [0, sz * 0.5] };
        var ops = rotOps(cy), bk = back(pr);
        if (rt === 9) {                                            // barrage emitter: two orbs 1.5 apart
            [-1.5, 1.5].forEach(function (sx, i) {
                draw(P + "_v" + i, pr.id, ops.concat([["scale", S], ["translate", sx, 0, 0]]), MESH.sphere, uni(col));
            });
            return;
        }
        if (rt === 11) {                                           // Fake Moon
            draw(P + "_m", pr.id, ops.concat([["scale", half]]), MESH.sphere, uni([col[0], col[0], col[2]]));
            var pulse = { k: { age: 0.1 / Math.PI }, sin: true, mul: 0.08 * 0.5 * Snow, add: 1.12 * 0.5 * Snow };
            draw(P + "_mh", pr.id, ops.concat([["scale", pulse]]), MESH.sphere, uni([col[0], col[2], col[2]], { alphaMult: 0.25 }));
            return;
        }
        if (rt === 4) {                                            // Soul Punisher: a small white core
            var w = [1, 1, 1];
            draw(P + "_s", pr.id, ops.concat([["scale", typeof S === "number" ? S * 0.15 : { k: { age: sz / L.ct * 0.15 }, clamp: [0, sz * 0.15] }]]), MESH.sphere, uni([w, w, w]));
            return;
        }
        if (rt === 8) {                                            // Sokidan: the plain shader ball
            draw(P + "_b", pr.id, ops.concat([["scale", half]]), MESH.sphere, uni(col));
            return;
        }
        var giant = rt === 2 || rt === 5 || rt === 6, death = rt === 7, cooler = rt === 6 && L.tech === "supernova_cooler";
        var jitter = rt === 6 ? 0.01 : death ? 0.03 : 0;
        if (jitter) ops = ops.concat([["translate", { k: { age: 20 / Math.PI }, sin: true, mul: jitter }, { c: 0.5, k: { age: 24 / Math.PI }, sin: true, mul: jitter }, { k: { age: 16 / Math.PI }, sin: true, mul: jitter }]]);
        var R = death ? S : half, Rnow = (death ? 1 : 0.5) * Snow;
        if (cooler) draw(P + "_b", pr.id, ops.concat([["scale", R]]), MESH.sphere, uni(col, { novaMode: 1, flameMode: 1, flameGain: COOLER_FLAME_GAIN }));
        else draw(P + "_b", pr.id, ops.concat([["scale", R]]), MESH.sphere, uni(col, { blotchMode: 1, flameMode: 1, orbMode: rt === 0 ? 1 : 0,
            flameGain: giant || death ? GIANT_FLAME_GAIN : 1 }));
        if (L.k !== "small" || pr.held)
            embers(P, pr.id, [["translate", 0, cy, 0]], growing ? { rate: (death ? 1 : 0.5) * sz / L.ct, max: (death ? 1 : 0.5) * sz } : Rnow, col, bk,
                rt === 0 ? CHARGE_BACKDRAFT : 1, giant || death ? GIANT_EMBER_SCALE : 1);
    }

    // ---- KiWaveRenderer -----------------------------------------------------------------------------
    function wave(pr, L, col, P) {
        var age = pr.age, rt = L.rt || 0, sz = L.sz || 1, cs = L.cs || 0.2, bk = back(pr);
        if (pr.held) {
            var ctw = Math.max(1, L.ct || 12), done = age >= ctw;
            // the orb grows over the cast (smoothstep in the original; linear here so it runs without per-tick work)
            var W = function (f) { return done ? cs * f : { k: { age: cs * f / ctw }, clamp: [0, cs * f] }; };
            if (L.tech === "heat_dome") {                          // a big plain sphere round the caster
                draw(P + "_d", pr.id, [["scale", W(1.5)]], MESH.sphere, uni(col, { alphaMult: pr.owner === myId && RPG.camera.currentMode() === "first" ? 0.35 : 0.85 }));
                return;
            }
            if (rt === 3) {                                        // Final Flash: two orbs that join in front of the hands
                [1, -1].forEach(function (sgn, i) {
                    var sp = 0.6 * 1.8 * sgn, spread = { c: 24 * sp, k: { age: -sp }, clamp: sp < 0 ? [sp, 0] : [0, sp] };   // held apart 23 ticks, joined at 24
                    var ops = [["rotateY", { k: { yaw: -1 } }], ["translate", spread, 0, 0], ["rotateY", { k: { yaw: 1 } }], ["scale", W(DOUBLE_WAVE_BALL_SCALE)]];
                    draw(P + "_o" + i, pr.id, ops, MESH.sphere, uni(col, { blotchMode: 1, flameMode: 1, orbMode: 1 }));
                });
                return;
            }
            draw(P + "_o", pr.id, [["scale", W(1.5)]], MESH.sphere, uni(col, { blotchMode: 1, flameMode: 1, orbMode: 1 }));
            embers(P, pr.id, [], done ? cs * 1.5 : { rate: cs * 1.5 / ctw, max: cs * 1.5 }, col, bk, CHARGE_BACKDRAFT, 1);
            return;
        }
        // fired: tube from the muzzle to the head, ball at each end (KiRenderWaveBrightness / KiRenderWaveDouble / KiRenderWave)
        var len = Math.max(0.1, pr.length), ops = rotOps(0);
        var bright = rt === 1 || rt === 2, dbl = rt === 3 || rt === 5;
        var pulseW = bright || dbl ? { k: { age: 1.5 / Math.PI }, sin: true, mul: 0.15 * sz, add: sz } : sz;
        var tubeR = bright || dbl ? pulseW : sz * 1.2;
        var cutA = (dbl ? 1.8 : 1.5) * sz, cutB = 2.5 * sz;
        var zc = Math.min(cutA * 0.95 / len, 0.49), zf = bright || dbl ? Math.max(1 - cutB * 0.95 / len, 0.51) : 2;
        draw(P + "_t", pr.id, ops.concat([["scale", tubeR, tubeR, { k: { length: 1 } }]]), MESH.tube, uni(col, { zCut: zc, zCutFar: zf }));
        var head = (bright ? 2.5 : dbl ? 2.5 * DOUBLE_WAVE_BALL_SCALE : 1.5) * sz;
        draw(P + "_h", pr.id, ops.concat([["translate", 0, 0, { k: { length: 1 } }], ["scale", head]]), MESH.sphere, uni(col, { blotchMode: 1, flameMode: 1 }));
        var muzzle = 1.5 * MUZZLE_FLAME_SCALE * sz * (dbl ? DOUBLE_WAVE_BALL_SCALE : 1);
        var breath = { k: { age: 3.1 / Math.PI }, sin: true, mul: 0.09 * muzzle, add: muzzle };
        draw(P + "_m", pr.id, ops.concat([["translate", 0, 0, 0.1], ["scale", breath]]), MESH.sphere, uni(col, { blotchMode: 1, flameMode: 1 }));
        var d = dirOf(pr.yaw, pr.pitch);
        embers(P + "h", pr.id, [["translate", { k: { length: d[0] } }, { k: { length: d[1] } }, { k: { length: d[2] } }]], head, col, bk, 1, 1);
        embers(P + "m", pr.id, [], muzzle, col, bk, 1, 1);
    }
    // ---- KiLaserRenderer ----------------------------------------------------------------------------
    function laser(pr, L, col, P) {
        var sz = L.sz || 1, ops = rotOps(0);
        if (pr.held) { draw(P + "_o", pr.id, ops.concat([["scale", sz * 0.16]]), MESH.sphere, uni(col)); return; }
        if (L.k === "laser") {
            draw(P + "_t", pr.id, ops.concat([["scale", sz * 0.08, sz * 0.08, { k: { length: 1 } }]]), MESH.tube, uni(col));
            return;
        }
        var w = sz * 0.15, len = Math.max(0.1, pr.length);
        draw(P + "_t", pr.id, ops.concat([["scale", w, w, { k: { length: 1 } }]]), MESH.tube, uni(col));
        draw(P + "_h", pr.id, ops.concat([["translate", 0, 0, { k: { length: 1 } }], ["scale", w * 1.5]]), MESH.sphere, uni(col));
        var segs = Math.min(26, Math.ceil(len / SPIRAL_LEN));
        for (var i = 0; i < 26; i++) {
            var id = P + "_s" + i;
            if (i >= segs) { RPG.shaders.remove(id); continue; }
            draw(id, pr.id, ops.concat([["rotateZ", { k: { age: -30 } }], ["translate", 0, 0, i * SPIRAL_LEN], ["scale", w, w, 1]]), MESH.spiral,
                uni(col, { zCutFar: len - i * SPIRAL_LEN }));
        }
    }

    // ---- KiDiskRenderer -----------------------------------------------------------------------------
    function disk(pr, L, col, P) {
        var sz = L.sz || pr.size, cy = L.noBox ? 0 : sz * 0.5;
        var S = pr.held && L.ct > 0 && pr.age < L.ct ? { k: { age: sz / L.ct }, clamp: [0, sz] } : sz;
        var ops = [["translate", 0, cy, 0], ["rotateY", { c: 180, k: { yaw: -1 } }], ["rotateX", pr.held ? 90 : { c: 90, k: { pitch: 1 } }],
            ["rotateZ", { k: { age: 35 } }], ["translate", 0, 0, -0.025], ["scale", S, S, 0.05]];
        draw(P + "_d", pr.id, ops, MESH.tube, uni(col, { shapeMode: 1 }));
    }

    // ---- every client tick: draw what this computer sees ------------------------------------------
    RPG.every(1, function () {
        if (!RPG.player.present || !setup()) return;
        var list = RPG.world.projectiles(160);
        if (!list.length) { JOBS.length = 0; return; }
        var me = RPG.avatar.players().filter(function (pl) { return pl.local; })[0];
        myId = me ? me.id : -1;
        var now = ++clock, t0 = RPG.nowMs();
        for (var i = 0; i < list.length; i++) {
            if (RPG.nowMs() - t0 > 18) break;                // the rest next tick
            var pr = list[i];
            if (!OWN[pr.def]) continue;
            var L = lookOf(pr);
            if (!L) continue;
            var P = "dmzki_" + pr.id, st = STATE[pr.id];
            // the draws stand on their own (expressions of age / size / length): redone only when the shot changes
            // state (charging -> fired, a new spiral segment...) and refreshed now and then
            var segs = L.k === "beam" && !pr.held ? Math.ceil(Math.max(0.1, pr.length) / SPIRAL_LEN) : 0;
            var key = L.k + "|" + pr.held + "|" + (L.rt || 0) + "|" + Math.round((L.sz || pr.size) * 100) + "|" + segs + "|" + pr.colors.core + pr.colors.border + pr.colors.outline
                + "|" + (pr.held && L.ct > 0 && pr.age >= L.ct ? 1 : 0);
            if (st && st.key === key && now - st.at < REFRESH) {
                st.seen = now;
                if (L.k === "wave" && !pr.held && now % 2 === 0) waveCuts(pr, L, P);
                continue;
            }
            if (st && st.key !== key) RPG.shaders.removePrefix(P + "_");
            STATE[pr.id] = { key: key, at: now, seen: now };
            var col = [rgb(pr.colors.core), rgb(pr.colors.border), rgb(pr.colors.outline)];
            try {
                if (L.k === "ball" || L.k === "small" || L.k === "volley") ball(pr, L, col, P);
                else if (L.k === "wave") wave(pr, L, col, P);
                else if (L.k === "beam" || L.k === "laser") laser(pr, L, col, P);
                else if (L.k === "disk") disk(pr, L, col, P);
                else continue;
                RPG.world.hideProjectile(pr.id, KEEP);
            } catch (e) { RPG.log("[DBR] ki render: " + e); }
        }
        while (JOBS.length && RPG.nowMs() - t0 < 22) JOBS.shift()();
        if (now % 100 === 0) for (var id in STATE) if (now - STATE[id].seen > 100) delete STATE[id];
    });
    var STATE = {}, clock = 0;
    // the wave tube's ends are cut by the muzzle and head balls: fractions of its length (KiWaveRenderer)
    function waveCuts(pr, L, P) {
        var rt = L.rt || 0, sz = L.sz || 1, len = Math.max(0.1, pr.length), bright = rt === 1 || rt === 2, dbl = rt === 3 || rt === 5;
        var zc = Math.min((dbl ? 1.8 : 1.5) * sz * 0.95 / len, 0.49), zf = bright || dbl ? Math.max(1 - 2.5 * sz * 0.95 / len, 0.51) : 2;
        RPG.shaders.update(P + "_t", { uniforms: { zCut: zc, zCutFar: zf } });
    }

    // ---- KiExplosionVisualEntity + the KI_EXPLOSION particle, sent by the server ------------------------
    var fxN = 0;
    RPG.net.on("dmz_ki_fx", function (d) {
        if (!d || !RPG.player.present) return;
        var c = d.c ? [rgb(d.c[0]), rgb(d.c[1]), rgb(d.c[2])] : [[1, 1, 1], [1, 0.8, 0.3], [1, 0.5, 0.1]];
        if (setup() && d.v > 0) {
            var t0 = RPG.shaders.clock(), M = d.v;                 // radius maxSize x (0.5 + 0.5 progress) over 25 ticks
            RPG.shaders.draw("dmzki_fx" + (fxN++ % 64), { mesh: MESH.sphere, shader: SH, x: d.x, y: d.y, z: d.z,
                ops: [["scale", { c: -t0 / 1.25, k: { clock: 1 / 1.25 }, mul: 0.5 * M, add: 0.5 * M, clamp: [0.5 * M, M] }]],
                uniforms: uni(c, { alphaMult: { c: 1 + 0.8 * t0, k: { clock: -0.8 }, clamp: [0, 0.45] }, time: { k: { clock: 1 } } }),
                cull: false, depthWrite: false, ticks: 26, order: 21 });
        }
        if (RPG.particles && d.p > 0) {
            RPG.particles.sprite({ texture: ["dmzpack:explode0", "dmzpack:explode1", "dmzpack:explode2", "dmzpack:explode3", "dmzpack:explode4", "dmzpack:explode5"],
                x: d.x, y: d.y, z: d.z, size: d.p * 2, life: 20, gravity: 0, collide: false, fade: 12 });
        }
    });

    // ---- the view held while a restricted ki attack is being emitted (ClientStatsEvents) -------------
    var lockedAt = 0;
    RPG.net.on("dmz_tech_firelock", function (d) {
        var on = !!(d && d.on);
        lockedAt = on ? RPG.nowMs() : 0;
        try { RPG.camera.lockRotation(on); } catch (e) { }
    });
    RPG.every(20, function () {                                   // never stuck: the server always ends it, this is a backstop
        if (lockedAt && RPG.nowMs() - lockedAt > 40000) { lockedAt = 0; try { RPG.camera.lockRotation(false); } catch (e) { } }
    });

    // ---- the plain ki blast: Left Alt + right click (ClientStatsEvents): a tap throws one, holding 6 ticks a volley ----
    var kbHold = 0, kbWas = false;
    function kbChord() {
        return RPG.isWindowFocused() && !RPG.screen.getOpen() && RPG.isKeyDown("key.keyboard.left.alt") && RPG.isKeyDown("key.mouse.right")
            && !RPG.isKeyDown("key.keyboard.left.control");                   // Ctrl + Alt + right click is the ki share
    }
    RPG.on("tick", function () {
        if (!RPG.player.present || !RPG.getVar("dmz_created", 0)) { kbHold = 0; kbWas = false; return; }
        var down = kbChord();
        if (down && !kbWas) kbHold = 1;
        else if (kbHold > 0) {
            if (!down) { RPG.net.send("dmz_kiblast", { v: false }); kbHold = 0; }
            else if (++kbHold >= 6) { RPG.net.send("dmz_kiblast", { v: true }); kbHold = 0; }
        }
        kbWas = down;
    });

    return { ready: function () { return ready; }, kiBlastChord: kbChord };
})();
