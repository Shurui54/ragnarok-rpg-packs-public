# Changelog

Dragon Block Ragnarok, newest first. The section for the published version is posted on Discord, so keep the heading
as `## <version> (YYYY-MM-DD)` and the bullets short.

## 4.15.0 (2026-11-17)

- Dragon Block menu: `/dbrgui` or the "Dragon Block menu" key (default `` ` ``) opens one hub that reaches every Dragon Block screen.
- Key binds are grouped under their own Controls category.
- Space: the cereal village lookup works again.
- The world boss contribution panel recognises your own row reliably.
- The creator opens correctly when the art finishes downloading after you join.
- Works on engine 0.27 as well (the menu's back-to-hub needs 0.28).

## 4.14.1 (2026-11-16)

- Neutral wording in in-game text.

## 4.14.0 (2026-11-15)

- Ki attacks reworked: charging, placement, movement holds, fixed beams and the plain ki blast.
- Wild planet garrisons and the conquest defender.
- Masters can't be hurt or pushed and respawn at once.
- Auras: the God aura draws properly and the ki surge has a flame border.
- Space: planet dressing spread over ticks so servers don't stall.
- The character creator comes back after dying before it was used.
- Techniques say why a slot key did nothing.
- Guard works even when the window focus flag is wrong.
- False Super Saiyan, Super Saiyan 5, Super Saiyan God and Primal Namekian can be found and used.

## 4.13.0 (2026-11-14)

- Per-form dodge and damage-taken buffs; the form editor has its Dodge and Buffs tabs back.
- Transformation outlines on bosses and the Demon Eye.
