// =====================================================================================
//  98_dbr_hub.js - the Dragon Block menu: one screen that reaches every DBR screen (/dbrgui, the "Dragon Block menu" key)
// =====================================================================================
//  Ports the Ragnarok original's (GPL-3.0, see NOTICE.md) unified hub: shuruisutilities hub/HubServer (the router and
//  permission gate: the SERVER decides which rows a player may see and sends only those, and re-checks every open
//  request before it opens anything), the player menu (SUHubScreen: a flat list of player screens) and the editor hub
//  (SduHubScreen: one dropdown section per module, each expanding into that module's editors). The screen itself is
//  client/scripts/90_dbr_hub.js.
//
//  The hub is one more way in, nothing else: every row opens its screen through the very function its own key or
//  command calls, with the same permission check, and every key and command keeps working exactly as before.
//
//    /dbrgui                         open the menu (everyone)
//    "Dragon Block menu" key         the same (client/scripts/90_dbr_hub.js; ` by default, Options > Controls >
//                                    "Dragon Block Ragnarok")
//
//  Rows: { id, label, desc, show(p) -> may this player see and open it, open(p) }. A row with "client" instead of open
//  is opened by the client sending that existing request (the raid browser's own "dbr_raid_req"), so the existing
//  handler and its checks run unchanged. Sections are the editors; they are only sent to players who pass a row's
//  show(), which is the same check the editor's command makes (op level 2, or the editor's permission node).
//
//    client -> "dbr_hub" {}            open the menu (the key)
//    server -> "dbr_hub_open" {rows: [{id, label, desc, client?}], sections: [{id, label, entries: [...]}]}
//    client -> "dbr_hub_go" {id}       open one row (re-checked here)
// =====================================================================================
var DBR_HUB = (function () {
    function isOp(p) { try { return !!p && p.isOp(); } catch (e) { return false; } }
    function perm(p, node) { try { return isOp(p) || RPG.perms.has(p, node); } catch (e) { return false; } }
    function created(p) { return !!p.getVar("dmz_created", 0); }
    /** A module another script defines (DMZ_PARTY...), or null when it isn't loaded. */
    var MODS = null;      // looked up once, on the first menu opened (every script has loaded by then)
    // a fixed command as the player with their own rights (runCommandAs is engine 0.28+; 0.27 only has the
    // operator-rights runCommand, used there for these fixed commands, whose rows are already permission-checked)
    function runAs(p, cmd) {
        if (typeof p.runCommandAs === "function") p.runCommandAs(cmd);
        else p.runCommand(cmd);
    }
    function mod(name) {
        var m = MODS || (MODS = {
            DMZ_MINIGAMES: typeof DMZ_MINIGAMES !== "undefined" ? DMZ_MINIGAMES : null,
            DMZ_PARTY: typeof DMZ_PARTY !== "undefined" ? DMZ_PARTY : null,
            DBR_CHARS: typeof DBR_CHARS !== "undefined" ? DBR_CHARS : null,
            DBR_BAG: typeof DBR_BAG !== "undefined" ? DBR_BAG : null,
            DBR_ZSOUL: typeof DBR_ZSOUL !== "undefined" ? DBR_ZSOUL : null,
            DBR_RAIDS: typeof DBR_RAIDS !== "undefined" ? DBR_RAIDS : null,
            DBR_TOURNEY: typeof DBR_TOURNEY !== "undefined" ? DBR_TOURNEY : null,
            DBRD_CORE: typeof DBRD_CORE !== "undefined" ? DBRD_CORE : null,
            DBR_NPCR: typeof DBR_NPCR !== "undefined" ? DBR_NPCR : null,
            DBR_SHRINES: typeof DBR_SHRINES !== "undefined" ? DBR_SHRINES : null,
            DBR_PRESTIGE: typeof DBR_PRESTIGE !== "undefined" ? DBR_PRESTIGE : null
        });
        return m[name] || null;
    }

    // ---- the player menu (SUHubScreen's rows, in menu order) ------------------------------------------------
    var PLAYER = [
        // the Stats Menu key (V, 45_keys.js): the stats screen, or the creator while there is no character yet
        { id: "stats", label: function (p) { return created(p) ? "Stats" : "Character Creator"; },
            desc: function (p) { return created(p) ? "Your character's stats, forms and power (the Stats Menu key)" : "Make your character"; },
            show: function () { return true; },
            open: function (p) { DBR_KEYS[10].onPress(p); } },
        { id: "skills", label: "Techniques", desc: "Your skills and ki techniques", show: created,
            open: function (p) { DMZ_SKILLS.open(p); } },
        { id: "quests", label: "Sagas", desc: "The story sagas and side quests", show: created,
            open: function (p) { DMZ_QUESTS.open(p); } },
        { id: "minigames", label: "Minigames", desc: "Training minigames", show: function (p) { return created(p) && !!mod("DMZ_MINIGAMES"); },
            open: function (p) { DMZ_MINIGAMES.openHub(p); } },
        { id: "party", label: "Party", desc: "Your party: invite, leave, friendly fire", show: function () { return !!mod("DMZ_PARTY"); },
            open: function (p) { DMZ_PARTY.open(p); } },
        // /character
        { id: "characters", label: "Characters", desc: "Your character slots (/character)", show: function () { return !!mod("DBR_CHARS"); },
            open: function (p) { DBR_CHARS.openGui(p); } },
        // the "Open Dragon Ball-Sack" key: only while one is worn, as that key needs
        { id: "bag", label: "Dragon Ball-Sack", desc: "The Dragon Ball-Sack you are wearing",
            show: function (p) { var B = mod("DBR_BAG"); if (!B) return false; try { var w = p.getAccessory(B.slot); return !!w && B.isBag(w); } catch (e) { return false; } },
            open: function (p) { DBR_BAG.open(p); } },
        // /raid zsoul
        { id: "zsouls", label: "Z-Souls", desc: "Your Z-Souls: stats beyond the cap (/raid zsoul)",
            show: function (p) { return created(p) && !!mod("DBR_ZSOUL") && !!mod("DBR_RAIDS") && DBR_RAIDS.can(p, "rg.raid.zsoul"); },
            open: function (p) { DBR_ZSOUL.open(p); } },
        // the raid board's browser: the client sends the board's own request
        { id: "raids", label: "Raids", desc: "Raid bosses open for sign-ups", show: function () { return !!mod("DBR_RAIDS"); },
            client: { msg: "dbr_raid_req", data: { what: "browser" } } },
        // /tourney browse
        { id: "tournaments", label: "Tournaments", desc: "Tournaments you can sign up for (/tourney browse)", show: function () { return !!mod("DBR_TOURNEY"); },
            open: function (p) { DBR_TOURNEY.openBrowser(p, ""); } },
        // /dungeon (the Dungeon Selection menu; the old floors' gate with dbr.legacySystem)
        { id: "dungeons", label: "Dungeons", desc: "The Dungeon Selection menu (/dungeons)", show: function () { return true; },
            open: function (p) { runAs(p, "dungeon"); } },
        // the stats screen's Options tab (08_character.js "dmz_menu" config)
        { id: "options", label: "Options", desc: "HUD, camera and game options", show: function () { return true; },
            open: function (p) { RPG.net.send(p, "dmz_open_config", { op: p.isOp() }); } }
    ];

    // ---- the editors (SduHubScreen's dropdown sections); each show() is its command's own check ------------
    var SECTIONS = [
        { id: "story", label: "Story & Forms", entries: [
            // /rpgc sagaeditor (operators)
            { id: "saga_editor", label: "Saga Editor", desc: "Custom sagas and side quests (/rpgc sagaeditor)", show: isOp,
                open: function (p) { DBR_SAGA_EDITOR.open(p); } },
            // /rpgc formeditor (operators)
            { id: "form_editor", label: "Form Editor", desc: "Every race's forms (/rpgc formeditor)", show: isOp,
                open: function (p) { DBR_FORM_EDITOR.openFor(p); } }
        ] },
        { id: "events", label: "Raids & Tournaments", entries: [
            // /raid edit (rg.raid.edit)
            { id: "raid_editor", label: "Raid Editor", desc: "Raid bosses and dimensional tears (/raid edit)",
                show: function (p) { return !!mod("DBR_RAIDS") && DBR_RAIDS.can(p, "rg.raid.edit"); },
                open: function (p) { RPG.net.send(p, "dbr_raid_open_hub", {}); } },
            // /tourney edit (rg.tourney.edit)
            { id: "tourney_editor", label: "Tournament Editor", desc: "Tournaments, arenas and rewards (/tourney edit)",
                show: function (p) { return !!mod("DBR_TOURNEY") && perm(p, "rg.tourney.edit"); },
                open: function (p) { DBR_TOURNEY.openEditor(p); } }
        ] },
        { id: "dungeons", label: "Dungeons", entries: [
            // /dungeons with dungeon staff rights: the Dungeon Selection menu with its Admin tools
            { id: "dungeon_maker", label: "Dungeon Maker", desc: "Make and publish dungeons (/dungeons, Admin)",
                show: function (p) { return typeof DungeonMaker !== "undefined" && DungeonMaker.isAdmin && DungeonMaker.isAdmin(p); },
                open: function (p) { DungeonMaker.sendMenu(p, { open: true }); } },
            // /dungeon edit (the old procedural floors, dbr.legacySystem only)
            { id: "dungeon_config", label: "Dungeon Config", desc: "The old procedural floors (/dungeon edit)",
                show: function (p) { return typeof DBRD_LEGACY === "function" && DBRD_LEGACY() && !!mod("DBRD_CORE") && DBRD_CORE.canEdit(p); },
                open: function (p) { runAs(p, "dungeon edit"); } }
        ] },
        { id: "world", label: "World", entries: [
            // /npcregion edit (dbr.npcregion... DBR_NPCR.can)
            { id: "npc_regions", label: "NPC Regions", desc: "Draw regions that spawn NPCs (/npcregion edit)",
                show: function (p) { return !!mod("DBR_NPCR") && DBR_NPCR.can(p); },
                open: function (p) { RPG.net.send(p, "dbr_npcr_open", {}); } },
            // /rpgc rgnpc picker (operators)
            { id: "npc_picker", label: "NPC Picker", desc: "Browse and spawn Ragnarok NPC models (/rpgc rgnpc picker)", show: isOp,
                open: function (p) { RPG.net.send(p, "rg_npc_picker", { open: true }); } },
            // /shrine gui and /shrine shenron (operators)
            { id: "stat_shrines", label: "Stat Shrines", desc: "Stat and TP shrines (/shrine gui)", show: isOp,
                open: function (p) { runAs(p, "shrine gui"); } },
            { id: "dragon_shrines", label: "Dragon Wishes", desc: "The dragons' wish settings (/shrine shenron)",
                show: function (p) { return isOp(p) && !!mod("DBR_SHRINES"); },
                open: function (p) { DBR_SHRINES.openConfig(p); } }
        ] },
        { id: "progression", label: "Progression", entries: [
            // /prestige admin (dbr.prestige.admin)
            { id: "prestige_admin", label: "Prestige Settings", desc: "Prestige levels, rewards and gates (/prestige admin)",
                show: function (p) { return !!mod("DBR_PRESTIGE") && perm(p, "dbr.prestige.admin"); },
                open: function (p) { DBR_PRESTIGE.openAdmin(p, null); } }
        ] }
    ];

    var BY_ID = {};
    PLAYER.forEach(function (r) { BY_ID[r.id] = r; });
    SECTIONS.forEach(function (s) { s.entries.forEach(function (r) { BY_ID[r.id] = r; }); });

    function val(v, p) { return typeof v === "function" ? v(p) : v; }
    function allowed(r, p) { try { return !!r.show(p); } catch (e) { return false; } }
    function row(r, p) {
        var o = { id: r.id, label: String(val(r.label, p)), desc: String(val(r.desc, p) || "") };
        if (r.client) o.client = r.client;
        return o;
    }

    /** HubServer.openPlayer + openAdmin in one: only the rows this player may open are sent. */
    function open(p) {
        if (!p) return;
        var rows = PLAYER.filter(function (r) { return allowed(r, p); }).map(function (r) { return row(r, p); });
        var sections = [];
        SECTIONS.forEach(function (s) {
            var kept = s.entries.filter(function (r) { return allowed(r, p); });
            if (kept.length) sections.push({ id: s.id, label: s.label, entries: kept.map(function (r) { return row(r, p); }) });
        });
        RPG.net.send(p, "dbr_hub_open", { rows: rows, sections: sections });
    }

    /** HubServer.tryOpen: re-checked here, not only where the rows are built (the client names the row). */
    function go(p, id) {
        var r = BY_ID[String(id || "")];
        if (!p || !r || r.client || !allowed(r, p)) return;
        try { r.open(p); }
        catch (e) { RPG.log("[DBR] hub row " + r.id + ": " + e); }
    }

    RPG.net.on("dbr_hub", function (p) { open(p); });
    RPG.net.on("dbr_hub_go", function (p, d) { go(p, d && d.id); });

    RPG.commands.register("dbrgui", { root: true, permission: 0, description: "The Dragon Block menu: every Dragon Block screen in one place",
        run: function (p) { if (!p) { RPG.log("/dbrgui opens a menu: run it in game"); return; } open(p); } });

    return { open: open, go: go, rows: function () { return PLAYER.slice(); }, sections: function () { return SECTIONS.slice(); } };
})();
