// =====================================================================================
//  86c_dbr_space_garrison.js - wild planet garrisons and the conquest defender
//  (port of the Ragnarok original's PlanetGarrison / PlanetGarrisonRoster / PlanetGarrisonData /
//   PlanetConquest, GPL-3.0)
// =====================================================================================
//  - Garrison: the first time a player arrives on an unowned generated planet or moon (once its
//    surface is fully stamped), it rolls ONE family of defenders (weights per family) and
//    3..6 of them, each with a battle power between 5,000 and 50,000, scattered over the whole
//    planet (up to half the surface width - 2 blocks from the centre). Health = BP / 50 (min 20),
//    melee = BP / 500 (min 2), NPC defence = BP / 1000, the original saga brain at its lowest tier with a
//    ki wave (60) and a ki laser (45). A Saiyan has a 15 % chance to be one of the three named
//    warriors at 3x battle power. The roster is saved by uuid; a defender that dies (of anything)
//    is marked defeated, never respawns, and the planet's toughness (planet buster) is the sum of
//    its defenders' battle power / 10 (at least the flat wild toughness).
//  - Conquest: when the LAST defender falls to a player, ONE defender boss - a theme-fitting
//    hero (Earth: Goku, Gohan, Piccolo...; Namek: Nail, Piccolo, Kami...) - appears 6 blocks
//    from that player and the planet's people hear "X has come to defend Y!". Its max health is
//    the player's own (+-5 %), its battle power the player's (+-5 %) with melee BP/500, defence
//    BP/1000, ki BP/500, the ELITE brain with a ki wave, a ki laser and a Final Flash, never
//    transforms and never flies. Beating it claims the planet for whoever landed the killing blow
//    (else the player who triggered it, if online). If it wins it simply stays (persistent) until
//    someone beats it; /rpgc spaceplanet conquer calls it on a cleared planet whose last defender
//    died without a player (or if it vanished). A claimed planet keeps no garrison; once released
//    (/rpgc spaceplanet unclaim) the next arrival rolls a fresh one.
//  Settings: ragnarok_rpg/config/dbr_space_garrison.json (the Ragnarok original SpacePlanets: wildDefender*, conquest*).
// =====================================================================================
var DBR_GARRISON_CFG = RPG.config.define("dbr_space_garrison", {
    wildDefendersEnabled:   { default: true, comment: "Unowned generated planets and moons get a garrison of defenders the first time a player arrives" },
    wildDefenderMinCount:   { default: 3, min: 0, max: 64, comment: "Fewest defenders on a planet (rolled once per planet)" },
    wildDefenderMaxCount:   { default: 6, min: 0, max: 64, comment: "Most defenders on a planet" },
    wildDefenderBattlePowerMin: { default: 5000, min: 0, max: 1e12, comment: "Lowest battle power a defender rolls (health BP/50, melee BP/500, defence BP/1000)" },
    wildDefenderBattlePowerMax: { default: 50000, min: 0, max: 1e12, comment: "Highest battle power a defender rolls" },
    wildDefenderToughnessDivisor: { default: 10, min: 0, max: 1e9, comment: "A defended planet's toughness (planet buster) = its defenders' battle power / this, at least the flat wild toughness" },
    wildFlatToughnessWhenDisabled: { default: true, comment: "A planet with no garrison record still has the flat clashWildToughness (else toughness 1)" },
    wildDefenderWeightSaiyan:     { default: 1, min: 0, max: 1000, comment: "Weight of a Saiyan garrison" },
    wildDefenderWeightOverworld:  { default: 1, min: 0, max: 1000, comment: "Weight of a Red Ribbon garrison" },
    wildDefenderWeightNamekian:   { default: 1, min: 0, max: 1000, comment: "Weight of a Namekian garrison (Nail, Piccolo, Kami, Namekian warriors)" },
    wildDefenderWeightSaibamen:   { default: 1, min: 0, max: 1000, comment: "Weight of Earth's Z-fighters (Krillin, Tien, Yamcha, Chiaotzu, Goten, Trunks)" },
    wildDefenderWeightFrostDemon: { default: 1, min: 0, max: 1000, comment: "Weight of a hero guard (Piccolo, Gohan, Vegeta, Future Trunks)" },
    wildDefenderWeightRobot:      { default: 1, min: 0, max: 1000, comment: "Weight of the androids 16, 17 and 18" },
    conquestEnabled:        { default: true, comment: "Beating a planet's garrison calls its defender; beating the defender claims the planet" },
    conquestStatTolerance:  { default: 0.05, min: 0, max: 1, comment: "How far (0..1) the defender's health and battle power may differ from the player who called it" },
    conquestSpawnDistance:  { default: 6, min: 1, max: 64, comment: "How far from that player the defender appears (random bearing)" },
    conquestBossStony:      { default: "saga_vegeta_mid_ssj,saga_ftrunks_ssj,saga_goten_ssj,saga_kid_trunks_ssj", comment: "Defenders of a barren rock planet (saga ids)" },
    conquestBossOverworld:  { default: "saga_goku_end_ssj,saga_gohan_end_ssj2,saga_piccolo,saga_krillin,saga_tien_early,saga_yamcha,saga_a17,saga_a18", comment: "Defenders of an Earth-like planet" },
    conquestBossNamek:      { default: "saga_nail,saga_piccolo,saga_piccolo_kami", comment: "Defenders of a Namek planet" },
    conquestBossNether:     { default: "saga_vegetto_ssj,saga_gohan_end_ultimate,saga_goku_end_ssj3,saga_gotenks_ssj3", comment: "Defenders of a demon realm planet" },
    conquestBossEnd:        { default: "saga_goku_end_ssj3,saga_vegeta_end_ssj2,saga_ftrunks_ssg3,saga_vegetto_base", comment: "Defenders of a cold space planet" },
    conquestBossKaio:       { default: "saga_paikuhan,saga_shin,saga_kibito", comment: "Defenders of a King Kai's world planet" },
    conquestBossOther:      { default: "saga_paikuhan,saga_goku_end_ssj2,saga_gohan_end_ultimate,saga_vegetto_ssj", comment: "Defenders of any other world (and the fallback)" }
});

var DBR_GARRISON = (function () {
    var C = DBR_GARRISON_CFG, B = DBR_SPACE_BODIES, SURFACE = B.SURFACE;
    var DEFENDER_TAG = "dbr_planet_defender", BOSS_TAG = "dbr_conquest_boss";
    var HEALTH_BP_DIVISOR = 50, MELEE_BP_DIVISOR = 500, DEFENSE_BP_DIVISOR = 1000, KI_BP_DIVISOR = 500, MIN_HEALTH = 20, MIN_MELEE = 2;
    var NAMED_CHANCE_EACH = 5, NAMED_COUNT = 3, NAMED_STRENGTH = 3;
    var GARRISON_SKILLS = [[8, 60, 1.0], [4, 45, 1.0]];                  // GENERIC_KI_WAVE 60, KI_LASER 45
    var BOSS_SKILLS = [[8, 60, 1.0], [4, 40, 1.0], [18, 120, 1.0]];      // + FINAL_FLASH 120
    var SAGA_ANIM = DMZ_ANIM + "sagas/saga_base.animation.json";

    // ---- looks: the original's saga models (DBSagaModel: geo sagas/<model>, texture sagas/<id>) ----
    var DMZ_NAMES = { saga_krillin: ["saga_vegeta", "Krillin"], saga_tien_early: ["saga_goku", "Tien Shinhan (Early)"], saga_yamcha: ["", "Yamcha"],
        saga_chaoz: ["", "Chiaotzu"], saga_goten_ssj: ["", "Goten (Super Saiyan)"], saga_kid_trunks_ssj: ["", "Trunks (Super Saiyan)"], saga_nail: ["saga_piccolo", "Nail"],
        saga_piccolo: ["", "Piccolo"], saga_piccolo_kami: ["", "Piccolo (Kami)"], saga_gohan_mid_ssj2: ["", "Teen Gohan (Mid, Super Saiyan 2)"],
        saga_vegeta_mid_ssj: ["saga_vegeta", "Vegeta (Mid, Super Saiyan)"], saga_ftrunks_ssj: ["saga_trunks_ssj", "Future Trunks (Super Saiyan)"],
        saga_a16: ["", "Android 16"], saga_a17: ["", "Android 17"], saga_a18: ["", "Android 18"], saga_goku_end_ssj: ["saga_goku_ssj", "Goku (End, Super Saiyan)"],
        saga_gohan_end_ssj2: ["", "Gohan (End, Super Saiyan 2)"], saga_vegetto_ssj: ["", "Vegetto (Super Saiyan)"], saga_gohan_end_ultimate: ["saga_gohan_end_ssj2", "Ultimate Gohan (End)"],
        saga_goku_end_ssj3: ["saga_goku_ssj3", "Goku (End, Super Saiyan 3)"], saga_gotenks_ssj3: ["", "Gotenks (Super Saiyan 3)"], saga_vegeta_end_ssj2: ["saga_vegeta_ssj2", "Vegeta (End, Super Saiyan 2)"],
        saga_ftrunks_ssg3: ["saga_trunks_ssg3", "Future Trunks (SS Grade 3)"], saga_vegetto_base: ["", "Vegetto"], saga_paikuhan: ["", "Pikkon"], saga_shin: ["", "Shin"],
        saga_kibito: ["", "Kibito"], saga_goku_end_ssj2: ["saga_goku_ssj2", "Goku (End, Super Saiyan 2)"] };
    function kitOf(id) { return (typeof DMZ_SAGA_KITS !== "undefined" && DMZ_SAGA_KITS[id]) || {}; }
    function sagaGeo(id) {
        var n = DMZ_NAMES[id] || ["", id], kit = kitOf(id);
        return dmzSagaStates({ model: DMZ_GEO + "sagas/" + (n[0] || id) + ".geo.json", texture: DMZ_TEX + "sagas/" + id + ".png",
            animation: SAGA_ANIM, idle: "idle", walk: "walk", attack: "attack1_1", scale: kit.sc || 1 });
    }
    function rgGeo(entry) {
        var r = typeof RG_NPC_INDEX !== "undefined" ? RG_NPC_INDEX[entry] : null;
        if (!r) return null;
        return { r: r, geo: dmzSagaStates({ model: "dbr:geo/entity/rgnpc/" + r[1] + ".geo.json", texture: "dbr:textures/entity/rgnpc/" + r[2] + ".png",
            animation: SAGA_ANIM, idle: "idle", walk: "walk", attack: "attack1_1", scale: 1.0 }) };
    }

    // ---- PlanetGarrisonRoster.Family: one family per planet (persisted by name), a random face per defender ----
    var FAMILIES = [
        { name: "SAIYAN", label: "Saiyans", weight: "wildDefenderWeightSaiyan", faces: ["saiyan_1", "saiyan_2"] },
        { name: "OVERWORLD", label: "Earth fighters", weight: "wildDefenderWeightOverworld", faces: ["saga_cl_red_ribbon_soldier_gunner", "saga_cl_red_ribbon_soldier_bazooka",
            "saga_cl_officer_black", "saga_cl_ninja_murasaki", "saga_cl_colonel_silver", "saga_cl_colonel_violet", "saga_cl_general_blue", "saga_cl_general_white",
            "saga_cl_major_metallitron", "saga_cl_mercenary_tao", "saga_cl_android8", "saga_cl_commander_red"] },
        { name: "NAMEKIAN", label: "Namekians", weight: "wildDefenderWeightNamekian", faces: ["saga_nail", "saga_piccolo", "saga_piccolo_kami", "namek_warrior"] },
        { name: "SAIBAMEN", label: "Saibamen", weight: "wildDefenderWeightSaibamen", faces: ["saga_krillin", "saga_tien_early", "saga_yamcha", "saga_chaoz", "saga_goten_ssj", "saga_kid_trunks_ssj"] },
        { name: "FROST_DEMON", label: "Frost Demons", weight: "wildDefenderWeightFrostDemon", faces: ["saga_piccolo", "saga_gohan_mid_ssj2", "saga_vegeta_mid_ssj", "saga_ftrunks_ssj"] },
        { name: "ROBOT", label: "Robots", weight: "wildDefenderWeightRobot", faces: ["saga_a16", "saga_a17", "saga_a18"] }
    ];
    var FAMILY_BY_NAME = {};
    FAMILIES.forEach(function (f) { FAMILY_BY_NAME[f.name] = f; });

    // one mob body per face: the original saga brain drives them (alias -> their original kit: flight, evasion, combos)
    function faceMobId(face) { return "dbr_garrison_" + face; }
    function bossMobId(id) { return "dbr_conquest_" + id; }
    var DEFINED = {};
    function defineFace(face) {
        var mid = faceMobId(face);
        if (DEFINED[mid]) return;
        var spec = { hostile: true, persistent: true, xp: 0, health: 300, damage: 15, speed: 0.25, followRange: 64,
            onTick: function (m, s) { defenderTick(m, s, false); },
            onDeath: function (m, killer) { onDefenderDeath(m, killer); } }, dmz = face;
        if (face.indexOf("saiyan_") === 0) {
            // PlanetSaiyanGarrisonEntity: here the Ragnarok classic saiyan look Vegeta's own saiyans wear (88_dbr_space_vegeta.js)
            var s = rgGeo("saga_cl_saiyan" + face.substring(7));
            spec.name = "&6Saiyan Warrior"; spec.geo = s ? s.geo : sagaGeo("saga_raditz"); spec.width = 1.0; spec.height = 2.0;
            dmz = "dbr_garrison_saiyan";
        } else if (face === "namek_warrior") {
            // The original's NamekWarriorEntity: a plain fighter (no saga brain), it hits back
            spec.name = "&aNamekian Warrior"; spec.geo = enemyGeo("namekian", "namek_warrior_0"); spec.width = 1.0; spec.height = 2.0;
            spec.hostile = false; spec.attacks = true; spec.speed = 0.3;
            dmz = null;
        } else if (face.indexOf("saga_cl_") === 0) {
            // PlanetGarrisonDefenderEntity: a saga fighter wearing a Ragnarok rgnpc model
            var g = rgGeo(face);
            if (!g) return;
            spec.name = "&c" + g.r[5]; spec.geo = g.geo; spec.width = g.r[3]; spec.height = g.r[4];
            dmz = "dbr_garrison_rgnpc";
        } else {
            var kit = kitOf(face);
            spec.name = "&c" + (DMZ_NAMES[face] || ["", face])[1]; spec.geo = sagaGeo(face);
            if (kit.hb) { spec.width = kit.hb[0]; spec.height = kit.hb[1]; }
            var base = typeof dmzSagaBase === "function" ? dmzSagaBase(face) : [300, 0.25, 15, 64];
            spec.speed = base[1]; spec.followRange = base[3];
        }
        RPG.mobs.define(mid, spec);
        if (dmz && typeof DMZ_SAGA_ALIAS !== "undefined") DMZ_SAGA_ALIAS[mid] = dmz;
        if (dmz && typeof DMZ_SAGA !== "undefined") DMZ_SAGA.alias(mid, dmz);
        DEFINED[mid] = true;
    }
    FAMILIES.forEach(function (f) { f.faces.forEach(defineFace); });

    function defineBoss(id) {
        var mid = bossMobId(id);
        if (DEFINED[mid] || !DMZ_NAMES[id]) return !!DEFINED[mid];
        var kit = kitOf(id), base = typeof dmzSagaBase === "function" ? dmzSagaBase(id) : [300, 0.25, 15, 64];
        var spec = { name: "&c" + DMZ_NAMES[id][1], geo: sagaGeo(id), hostile: true, persistent: true, xp: 0, health: base[0], damage: base[2], speed: base[1], followRange: base[3],
            onTick: function (m, s) { defenderTick(m, s, true); },
            onDeath: function (m, killer) { onBossDeath(m, killer); } };
        if (kit.hb) { spec.width = kit.hb[0]; spec.height = kit.hb[1]; }
        RPG.mobs.define(mid, spec);
        if (typeof DMZ_SAGA_ALIAS !== "undefined") DMZ_SAGA_ALIAS[mid] = id;
        if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.alias(mid, id);
        DEFINED[mid] = true;
        return true;
    }
    Object.keys(DMZ_NAMES).forEach(defineBoss);

    // ---- PlanetGarrisonData + GeneratedPlanetClaims.conquestBoss: one saved object, a record per planet ----
    //   { f: family, r: [{ u, x, z, b, d }], k: [defeated uuids], t: toughness, p: recommended (strongest) battle power,
    //     boss: { u, by, d, b } }
    var KEY = "dbr_space_garrisons", MEM = null, MEMBER = {}, BOSSES = {}, PENDING = {}, POPULATING = {};
    function all() { if (!MEM) { MEM = RPG.data.get(KEY, null) || {}; reindex(); } return MEM; }
    function save() { RPG.data.set(KEY, MEM); reindex(); }
    function reindex() {
        MEMBER = {}; BOSSES = {};
        Object.keys(MEM).forEach(function (id) {
            var r = MEM[id];
            (r.r || []).forEach(function (e) { MEMBER[e.u] = { id: id, e: e }; });
            if (r.boss && r.boss.u) BOSSES[r.boss.u] = id;
        });
    }
    function rec(id) { return all()[id] || null; }
    function isPopulated(id) { return !!rec(id); }
    function remaining(id) {
        var r = rec(id);
        if (!r) return 0;
        var dead = {};
        (r.k || []).forEach(function (u) { dead[u] = true; });
        return (r.r || []).filter(function (e) { return !dead[e.u]; }).length;
    }
    function markPopulated(id, fam, roster, tough, rbp) { all()[id] = { f: fam || "", r: roster || [], k: [], t: tough, p: rbp || 0 }; save(); }
    function markDefeated(id, u) {
        var r = rec(id);
        if (!r || !(r.r || []).some(function (e) { return e.u === u; }) || (r.k || []).indexOf(u) >= 0) return;
        (r.k = r.k || []).push(u);
        save();
    }
    function clearRecord(id) { if (all()[id]) { delete MEM[id]; save(); } }

    function cfgOn() { return C.get("wildDefendersEnabled"); }
    function flatToughness() { return Math.max(1, typeof DBR_BUSTER_CFG !== "undefined" ? DBR_BUSTER_CFG.get("clashWildToughness") : 5000); }
    function claimable(id) { id = String(id || ""); return id.indexOf("sugen:") === 0 || id.indexOf("sumoon:") === 0; }   // GeneratedPlanets.isDestructible: planets and moons
    function owner(id) { return DBR_SPACE.claimOf(id); }
    function destroyed(id) { return DBR_SPACE.destroyedList().indexOf(id) >= 0; }
    function planetName(id) { var b = B.find(id, Date.now()); return b ? DBR_SPACE.name(b) : id; }
    function onName(id) { var n = planetName(id); return /^planet /i.test(n) ? n : "planet " + n; }   // "planet X", never "planet Planet X"
    function plain(s) { return String(s || "").replace(/[&§][0-9a-fk-or]/gi, ""); }
    function onPlanet(id) { return RPG.server.players().filter(function (q) { return q.dimension === SURFACE && String(q.getVar("dbr_surface", "") || "") === id; }); }
    function broadcast(id, text, except) { onPlanet(id).forEach(function (q) { if (!except || q.uuid !== except.uuid) q.sendMessage(text); }); }
    function playerByUuid(u) { var ps = RPG.server.players(); for (var i = 0; i < ps.length; i++) if (ps[i].uuid === u) return ps[i]; return null; }
    function battlePower(p) { try { return DMZ_F.battlePower(dmzView(p)); } catch (e) { return 0; } }
    function ent(u) { try { return u ? RPG.world.entityByUuid(u) : null; } catch (e) { return null; } }
    function alive(e) { try { return !!e && e.alive; } catch (x) { return false; } }

    // ---- population (PlanetGarrison.ensurePopulated / populate / spawnOne) ----
    function pickFamily() {
        var total = 0, ws = FAMILIES.map(function (f) { var w = Math.max(0, Number(C.get(f.weight)) || 0); total += w; return w; });
        if (total <= 0) return FAMILIES[Math.floor(Math.random() * FAMILIES.length)];
        var roll = Math.floor(Math.random() * total), acc = 0;
        for (var i = 0; i < FAMILIES.length; i++) { acc += ws[i]; if (roll < acc) return FAMILIES[i]; }
        return FAMILIES[0];
    }
    function rollBattlePower() {
        var lo = C.get("wildDefenderBattlePowerMin"), hi = C.get("wildDefenderBattlePowerMax");
        return lo >= hi ? lo : lo + Math.random() * (hi - lo);
    }
    /** Lazily populate a planet the first time anyone arrives (call once its surface is fully stamped). Never re-rolls. */
    function ensurePopulated(id) {
        id = String(id || "");
        if (!claimable(id) || isPopulated(id) || POPULATING[id]) return;
        // an old (pre-port) garrison: adopt its roster so its defenders still count
        var legacy = String(RPG.server.getData("dbr_garrison_" + id, "") || "");
        if (legacy) {
            RPG.server.setData("dbr_garrison_" + id, "");
            markPopulated(id, "", legacy.split(",").filter(Boolean).map(function (u) { return { u: u, b: 0, d: 0 }; }), flatToughness(), 0);
            return;
        }
        if (!cfgOn() || owner(id) || destroyed(id)) { markPopulated(id, "", [], flatToughness(), 0); return; }
        try { populate(id); }
        catch (err) { delete POPULATING[id]; markPopulated(id, "", [], flatToughness(), 0); RPG.log("[DBR] garrison: populating " + id + " failed, leaving it undefended: " + err); }
    }
    function populate(id) {
        var fam = pickFamily(), lo = C.get("wildDefenderMinCount"), hi = C.get("wildDefenderMaxCount");
        var count = lo >= hi ? lo : lo + Math.floor(Math.random() * (hi - lo + 1));
        var c = B.cellCentre(id), half = Math.max(1, Math.floor(B.surfaceSize(id) / 2) - 2);
        var roster = [], agg = 0, strongest = 0, left = count;
        POPULATING[id] = true;
        function finish() {
            delete POPULATING[id];
            roster.forEach(function (e) { delete PENDING[e.u]; });
            if (owner(id) || destroyed(id)) { roster.forEach(function (e) { var m = ent(e.u); if (m) m.remove(); }); markPopulated(id, "", [], flatToughness(), 0); return; }
            var div = C.get("wildDefenderToughnessDivisor"), tough = roster.length ? Math.max(flatToughness(), div > 0 ? agg / div : agg) : flatToughness();
            markPopulated(id, roster.length ? fam.name : "", roster, tough, strongest);
            // one that already fell while the rest were still being placed
            var gone = roster.filter(function (e) { return e.fell; });
            if (gone.length) { gone.forEach(function (e) { delete e.fell; rec(id).k.push(e.u); }); save(); }
            RPG.log("[DBR] garrison: " + id + " holds " + roster.length + " " + fam.name + " defender(s)");
        }
        if (count <= 0) { finish(); return; }
        for (var k = 0; k < count; k++) {
            var bp = rollBattlePower(), face = fam.faces[Math.floor(Math.random() * fam.faces.length)];
            var x = c.x + (Math.random() - 0.5) * 2 * half, z = c.z + (Math.random() - 0.5) * 2 * half;
            spawnOne(id, fam, face, x, z, bp, function (e, bpUsed) {
                if (e) { roster.push(e); agg += bpUsed; strongest = Math.max(strongest, bpUsed); }
                if (--left === 0) finish();
            });
        }
    }
    // the column's chunk is loaded in the background first (no forced generation on the tick), then the defender is
    // stood on the ground there (SafeSpotResolver)
    function spawnOne(id, fam, face, x, z, bp, done) {
        var fx = Math.floor(x), fz = Math.floor(z), tries = 0;
        var attempt = function () {
            if (!RPG.world.isLoaded(SURFACE, fx, fz)) {
                if (tries === 0) RPG.world.requestChunks(SURFACE, fx, fz, 0);
                if (++tries < 60) RPG.schedule(10, attempt); else done(null, 0);
                return;
            }
            try {
                var y = RPG.world.surfaceY(SURFACE, fx, fz);
                if (y <= -9999) { done(null, 0); return; }
                var m = RPG.world.spawnMob(SURFACE, faceMobId(face), fx + 0.5, y + 0.5, fz + 0.5);
                if (!m) { done(null, 0); return; }
                var eff = bp;
                if (fam.name === "SAIYAN" && Math.floor(Math.random() * 100) < NAMED_CHANCE_EACH * NAMED_COUNT) eff = bp * NAMED_STRENGTH;   // a named warrior
                var d = applyDefenderStats(m, eff, face !== "namek_warrior");
                m.addTag(DEFENDER_TAG);
                var e = { u: m.uuid, x: fx, z: fz, b: Math.round(eff), d: d };
                PENDING[m.uuid] = { id: id, e: e };
                done(e, eff);
            } catch (err) { RPG.log("[DBR] garrison: a defender for " + id + " failed to spawn: " + err); done(null, 0); }
        };
        attempt();
    }
    // PlanetGarrison.applyDefenderStats: health, melee and NPC defence from battle power; the lowest saga AI tier
    function applyDefenderStats(m, bp, saga) {
        var hp = Math.max(MIN_HEALTH, bp / HEALTH_BP_DIVISOR), melee = Math.max(MIN_MELEE, bp / MELEE_BP_DIVISOR), def = bp / DEFENSE_BP_DIVISOR;
        m.maxHealth = hp; m.health = hp;
        m.setAttributeBase("generic.attack_damage", melee);
        if (saga && typeof DMZ_SAGA !== "undefined") DMZ_SAGA.setup(m, { tier: 1, hp: hp, melee: melee, ki: 20, skills: GARRISON_SKILLS });
        return Math.round(def * 100) / 100;
    }

    // ---- defeat (PlanetGarrison.onDefenderDeath) ----
    function onDefenderDeath(m, killer) {
        if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onDeath(m);
        var mem = MEMBER[m.uuid] || PENDING[m.uuid];
        if (!mem) return;
        var id = mem.id;
        if (!MEMBER[m.uuid]) { mem.e.fell = true; return; }      // its garrison is still being placed (counted then)
        markDefeated(id, m.uuid);
        if (remaining(id) > 0 || !isPopulated(id)) return;
        // the last wild defender just fell: the conquest stage, scaled to the player who dealt the killing blow (a kill
        // by anything else spawns none; /rpgc spaceplanet conquer calls it later)
        var p = killer ? killer.asPlayer() : null;
        if (p && C.get("conquestEnabled")) spawnBoss(id, p);
    }
    // an older garrison's plain mobs (no death hook of their own): count the ones players kill
    RPG.on("kill", function (player, victim) {
        if (!victim || !victim.hasTag("dbr_garrison") || victim.hasTag(DEFENDER_TAG)) return;
        var mem = MEMBER[victim.uuid];
        if (!mem) return;
        markDefeated(mem.id, victim.uuid);
        if (remaining(mem.id) <= 0 && player && C.get("conquestEnabled")) spawnBoss(mem.id, player);
    });

    /** PlanetGarrison.claimBlocked: living defenders still stand. A record that says defended while none of its
     *  remaining defenders can be found alive (gone without a death) is reconciled to cleared. */
    function claimBlocked(id) {
        var r = rec(id);
        if (!r || remaining(id) <= 0) return false;
        var dead = {};
        (r.k || []).forEach(function (u) { dead[u] = true; });
        if (r.r.some(function (e) { return !dead[e.u] && alive(ent(e.u)); })) return true;
        r.k = r.r.map(function (e) { return e.u; });
        save();
        return false;
    }
    /** claimBlocked with the ground round each remaining defender's post loaded first (they may stand in chunks nobody
     *  has loaded), answered a few seconds later. */
    function checkBlocked(id, cb) {
        var r = rec(id);
        if (!r || remaining(id) <= 0) { cb(false); return; }
        var dead = {};
        (r.k || []).forEach(function (u) { dead[u] = true; });
        r.r.forEach(function (e) { if (!dead[e.u] && e.x !== undefined && !RPG.world.isLoaded(SURFACE, e.x, e.z)) RPG.world.requestChunks(SURFACE, e.x, e.z, 2); });
        RPG.schedule(60, function () { cb(claimBlocked(id)); });
    }

    // ---- the conquest defender (PlanetConquest) ----
    function bossTable(theme) {
        var key = { stony: "conquestBossStony", overworld: "conquestBossOverworld", namek: "conquestBossNamek", nether: "conquestBossNether", end: "conquestBossEnd", kaio: "conquestBossKaio" }[theme];
        var parse = function (k) { return String(C.get(k) || "").split(",").map(function (s) { return s.trim().toLowerCase(); }).filter(Boolean); };
        var ids = key ? parse(key) : [];
        if (!ids.length) ids = parse("conquestBossOther");
        if (!ids.length) ids = ["saga_paikuhan", "saga_goku_end_ssj2", "saga_gohan_end_ultimate", "saga_vegetto_ssj"];
        return ids;
    }
    function bossAlive(id) { var r = rec(id); return !!(r && r.boss && alive(ent(r.boss.u))); }
    function roll() { var tol = C.get("conquestStatTolerance"); return 1 + (Math.random() * 2 - 1) * tol; }
    /** PlanetConquest.spawnBoss: the one defender near the anchor player. false when off, owned, destroyed, already there. */
    function spawnBoss(id, anchor) {
        try {
            if (!C.get("conquestEnabled") || !anchor || !claimable(id) || owner(id) || destroyed(id) || bossAlive(id)) return false;
            if (anchor.dimension !== SURFACE) return false;
            var r = rec(id);
            if (!r) { markPopulated(id, "", [], flatToughness(), 0); r = rec(id); }
            delete r.boss;
            var ids = bossTable(B.themeFor(id).id).slice();
            for (var i = ids.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = ids[i]; ids[i] = ids[j]; ids[j] = t; }
            var pick = null;
            for (var n = 0; n < ids.length && !pick; n++) if (defineBoss(ids[n]) && RPG.mobs.exists(bossMobId(ids[n]))) pick = ids[n];
            if (!pick) { save(); RPG.log("[DBR] conquest: no defender id resolves for " + id); return false; }
            var a = Math.random() * Math.PI * 2, dist = C.get("conquestSpawnDistance");
            var bx = Math.floor(anchor.x + Math.cos(a) * dist), bz = Math.floor(anchor.z + Math.sin(a) * dist);
            var y = RPG.world.isLoaded(SURFACE, bx, bz) ? RPG.world.surfaceY(SURFACE, bx, bz) : -9999;
            if (y <= -9999) { bx = Math.floor(anchor.x); bz = Math.floor(anchor.z); y = Math.floor(anchor.y); }
            var m = RPG.world.spawnMob(SURFACE, bossMobId(pick), bx + 0.5, y + 0.5, bz + 0.5);
            if (!m) { save(); return false; }
            // applyBossStats: an even match for the player who called it
            var effBp = Math.max(1, battlePower(anchor) || 5000) * roll(), hp = Math.max(MIN_HEALTH, Math.max(MIN_HEALTH, anchor.maxHealth) * roll());
            var melee = Math.max(MIN_MELEE, effBp / MELEE_BP_DIVISOR * roll()), def = effBp / DEFENSE_BP_DIVISOR * roll(), ki = effBp / KI_BP_DIVISOR * roll();
            m.maxHealth = hp; m.health = hp;
            m.setAttributeBase("generic.attack_damage", melee);
            if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.setup(m, { tier: 3, hp: hp, melee: melee, ki: ki, noTransform: true, noFly: true, skills: BOSS_SKILLS });
            m.addTag(BOSS_TAG);
            r.boss = { u: m.uuid, by: anchor.uuid, d: Math.round(def * 100) / 100, b: Math.round(effBp) };
            save();
            m.target = anchor;
            broadcast(id, plain(m.customName || DMZ_NAMES[pick][1]) + " has come to defend " + planetName(id) + "! Strike down this hero to seize the planet.");
            RPG.log("[DBR] conquest: " + pick + " defends " + id + " (called by " + anchor.name + ", bp " + Math.round(effBp) + ", hp " + Math.round(hp) + ")");
            return true;
        } catch (err) { RPG.log("[DBR] conquest: spawning the defender of " + id + " failed: " + err); return false; }
    }
    // PlanetConquest.onLivingDeath: the planet goes to whoever beat its defender
    function onBossDeath(m, killer) {
        if (typeof DMZ_SAGA !== "undefined") DMZ_SAGA.onDeath(m);
        var id = BOSSES[m.uuid];
        if (!id) return;
        var r = rec(id), by = r && r.boss ? r.boss.by : "";
        if (r) { delete r.boss; save(); }
        if (owner(id) || destroyed(id)) return;
        var p = killer ? killer.asPlayer() : null;
        if (!p && by) p = playerByUuid(by);
        if (!p) { broadcast(id, "The hero defending " + onName(id) + " has fallen. The planet lies open to conquest."); return; }
        claim(id, p);
        p.sendMessage("You have conquered " + onName(id) + ". The heroes have fallen, and it is yours.");
        broadcast(id, p.name + " has conquered " + onName(id) + ". Its defenders have fallen.", p);
    }
    function claim(id, p) {
        RPG.server.setData("dbr_claim_" + id, p.name);
        RPG.server.setData("dbr_claim_uuid_" + id, p.uuid);
        onPlanetClaimed(id);
        RPG.server.players().forEach(function (q) { try { DBR_SPACE.sendState(q); } catch (e) { } });
    }
    /** The garrison and any defender go when a planet is claimed (PlanetGarrison/PlanetConquest.onPlanetClaimed). */
    function onPlanetClaimed(id) { discard(id); clearRecord(id); }
    /** ... and when it is destroyed (onPlanetDestroyed). */
    function onPlanetDestroyed(id) { discard(id); clearRecord(id); }
    function discard(id) {
        var r = rec(id);
        if (!r) return;
        (r.r || []).forEach(function (e) { var m = ent(e.u); if (m && m.alive) m.remove(); });
        if (r.boss) { var b = ent(r.boss.u); if (b && b.alive) b.remove(); }
    }

    // ---- every second, on each defender: the confinement goal and the orphan sweep ----
    function defenderTick(m, s, boss) {
        all();
        if (typeof DMZ_SAGA !== "undefined" && m.rpgId.indexOf("namek_warrior") < 0) DMZ_SAGA.onTick(m);
        var id = boss ? BOSSES[m.uuid] : (MEMBER[m.uuid] || PENDING[m.uuid] || {}).id;
        if (s % 10 === 0) {
            all();
            // PlanetGarrison.sweepOrphans: a defender no record knows (a crash mid-population, a claimed or destroyed world)
            if (!id) { if (!boss && !Object.keys(POPULATING).length) m.remove(); else if (boss) m.remove(); return; }
            if (owner(id) || destroyed(id)) { m.remove(); return; }
        }
        if (!id || boss || m.dimension !== SURFACE) return;
        // remember where it roams (a chunk at a time), so the garrison check and ops can load the ground it stands on
        var post = MEMBER[m.uuid];
        if (post && (Math.abs(m.x - post.e.x) >= 16 || Math.abs(m.z - post.e.z) >= 16)) { post.e.x = Math.floor(m.x); post.e.z = Math.floor(m.z); RPG.data.set(KEY, MEM); }
        // PlanetGarrisonDefenderConfineGoal: held on its planet's square (1 block inside the edge)
        var c = B.cellCentre(id), half = B.surfaceSize(id) / 2, dx = m.x - c.x, dz = m.z - c.z;
        var outX = Math.abs(dx) > half, outZ = Math.abs(dz) > half;
        if (!outX && !outZ) return;
        m.teleport(outX ? c.x + (dx < 0 ? -1 : 1) * (half - 1) : m.x, m.y, outZ ? c.z + (dz < 0 ? -1 : 1) * (half - 1) : m.z);
        m.setVelocity(0, 0, 0);
    }
    // NPC defence (the suite's dmz_npc_defense, here DBR's NPC defence curve as raids and NPC regions use)
    RPG.on("damageFinal", function (ev) {
        if (ev.isCancelled()) return;
        var t = ev.target;
        if (!t || t.isPlayer()) return;
        var mem = MEMBER[t.uuid] || PENDING[t.uuid], d = mem ? mem.e.d : 0;
        if (!mem) { var bid = BOSSES[t.uuid], br = bid ? rec(bid) : null; d = br && br.boss ? br.boss.d : 0; }
        if (d > 0) ev.amount = ev.amount * (1 - Math.min(0.88, d / (d + 100)));
    });
    /** The battle power a scouter reads on a defender (its rolled one), 0 for anything else. */
    function defenderBp(e) {
        if (!e) return 0;
        all();
        var mem = MEMBER[e.uuid] || PENDING[e.uuid];
        if (mem) return mem.e.b || 0;
        var bid = BOSSES[e.uuid], br = bid ? rec(bid) : null;
        return br && br.boss ? br.boss.b || 0 : 0;
    }

    // ---- arrivals that skip the normal landing (login or respawn onto a planet) still populate it ----
    function arrived(p) {
        if (p.dimension !== SURFACE) return;
        var id = String(p.getVar("dbr_surface", "") || "");
        if (claimable(id) && DBR_SPACE.stamped(id)) ensurePopulated(id);
    }
    RPG.on("playerJoin", function (p) { RPG.schedule(40, function () { try { arrived(p); } catch (e) { } }); });
    RPG.on("respawn", function (p) { RPG.schedule(20, function () { try { arrived(p); } catch (e) { } }); });

    /** PlanetToughness for an unowned world: its garrison's, else the flat wild value (or 1). */
    function toughness(id) {
        var r = rec(id);
        if (r) return Math.max(1, Number(r.t) || 1);
        return C.get("wildFlatToughnessWhenDisabled") ? flatToughness() : 1;
    }
    /** PlanetInfoServer's garrison fields. */
    function info(id) {
        var r = rec(id);
        if (!r) return { pop: false };
        var f = FAMILY_BY_NAME[r.f];
        return { pop: true, fam: f ? f.label : "", left: remaining(id), total: (r.r || []).length, rbp: Math.round(r.p || 0), boss: !!r.boss };
    }

    // ---- /rpgc spaceplanet (CommandSpacePlanet: info, conquer, unclaim, conquestboss) ----
    RPG.commands.register("spaceplanet", {
        permission: 0, description: "/rpgc spaceplanet [info|conquer|unclaim] - the generated planet you stand on (ops: conquestboss, wipe)",
        run: function (p, args) {
            if (!p) return;
            var sub = String(args && args[0] || "info").toLowerCase(), op = p.isOp();
            var id = String(p.getVar("dbr_surface", "") || "");
            if (p.dimension !== SURFACE || !claimable(id)) { p.sendMessage("&cYou must be standing on a generated planet to do that."); return; }
            var name = planetName(id), own = owner(id);
            if (sub === "conquer") {
                if (!C.get("conquestEnabled")) { p.sendMessage("&cPlanet conquest is disabled on this server."); return; }
                if (own) { p.sendMessage("&a" + onName(id).charAt(0).toUpperCase() + onName(id).substring(1) + " is owned by " + own + "."); return; }
                checkBlocked(id, function (blocked) {
                    if (!p.alive || String(p.getVar("dbr_surface", "") || "") !== id) return;
                    if (blocked) { p.sendMessage("This planet is still guarded by its defenders. Defeat them all before you can claim it."); return; }
                    if (!spawnBoss(id, p)) p.sendMessage("A hero is already defending this planet. Strike them down to seize it.");
                });
                return;
            }
            if (sub === "unclaim") {
                var ou = String(RPG.server.getData("dbr_claim_uuid_" + id, "") || "");
                if (!own) { p.sendMessage("&cThis planet is not claimed."); return; }
                if (ou ? ou !== p.uuid : own !== p.name) { p.sendMessage("&cYou do not own this planet."); return; }
                RPG.server.setData("dbr_claim_" + id, ""); RPG.server.setData("dbr_claim_uuid_" + id, "");
                RPG.server.players().forEach(function (q) { try { DBR_SPACE.sendState(q); } catch (e) { } });
                p.sendMessage("&aReleased your claim on " + onName(id) + ".");
                return;
            }
            if (sub === "conquestboss" && op) {
                // admin/self-test: the defender now, past the garrison gate
                if (own) { p.sendMessage("&cThat planet is already owned; unclaim it first to test a conquest boss."); return; }
                p.sendMessage(spawnBoss(id, p) ? "&aSpawned a conquest boss on " + onName(id) + "." : "&cCould not spawn a conquest boss (feature off, a boss is already present, or no boss id resolved).");
                return;
            }
            if (sub === "wipe" && op) {
                // test: you strike down every remaining defender of this planet (the chunks round each are loaded first)
                var r = rec(id);
                if (!r) { p.sendMessage("&cThis planet has no garrison yet."); return; }
                var dead = {};
                (r.k || []).forEach(function (u) { dead[u] = true; });
                var left = r.r.filter(function (e) { return !dead[e.u]; });
                p.sendMessage("&7Striking down " + left.length + " defender(s)...");
                left.forEach(function (e, i) {
                    var tries = 0, go = function () {
                        var m = ent(e.u);
                        if (!m && e.x !== undefined && tries++ < 40) { if (tries === 1) RPG.world.requestChunks(SURFACE, e.x, e.z, 2); RPG.schedule(10, go); return; }
                        if (!m) { p.sendMessage("&7A defender at " + e.x + " " + e.z + " could not be found."); return; }
                        // the saga brain may evade or block a blow: keep striking
                        for (var n = 0; n < 12 && m.alive; n++) m.damageFrom(1e12, p, { kind: "melee", ignoreIFrames: true });
                        p.sendMessage(m.alive ? "&7" + plain(m.customName) + " withstood the blows." : "&7Struck down a defender at " + Math.floor(m.x) + " " + Math.floor(m.z) + ".");
                    };
                    RPG.schedule(1 + i * 5, go);
                });
                return;
            }
            var g = info(id), t = Math.round(toughness(id));
            p.sendMessage("&6" + name + (destroyed(id) ? " &4DESTROYED" : ""));
            p.sendMessage("&7Type: &f" + B.themeFor(id).id + "&7, surface &f" + B.surfaceSize(id) + "&7 blocks across, toughness &f" + (own ? "-" : t));
            p.sendMessage("&7Recommended power: &f" + (g.pop ? g.rbp : "unknown"));
            p.sendMessage("&7Defenders: &f" + (!g.pop ? "Not yet explored." : !g.total ? "Undefended." : "Garrison: " + g.fam + ", " + g.left + " of " + g.total + " still standing") + (g.boss ? " &c(a hero defends it)" : ""));
            p.sendMessage("&7" + (own ? "Owned by &6" + own : "Unclaimed."));
            if (op && g.pop && g.left) {
                // ops: where the remaining defenders were posted
                var rr = rec(id), dd = {};
                (rr.k || []).forEach(function (u) { dd[u] = true; });
                p.sendMessage("&8Posts: " + rr.r.filter(function (e) { return !dd[e.u] && e.x !== undefined; }).map(function (e) { return e.x + " " + e.z; }).join(", "));
            }
        }
    });

    return { ensurePopulated: ensurePopulated, isPopulated: isPopulated, remaining: remaining, claimBlocked: claimBlocked, spawnBoss: spawnBoss,
        onPlanetClaimed: onPlanetClaimed, onPlanetDestroyed: onPlanetDestroyed, toughness: toughness, info: info, defenderBp: defenderBp, claimable: claimable };
})();

/** The battle power a scouter reads on a planet defender or conquest defender (10_stats.js powerLevel), else 0. */
function dbrSpaceDefenderBp(entity) { return DBR_GARRISON.defenderBp(entity); }
