// =====================================================================================
//  12_anim_state.js - what every client needs to animate a player like the original does
// =====================================================================================
//  The client animator (client/scripts/40_animator.js) reads these with pl.shared(key).
//  Only changes are sent, so checking every 2 ticks is cheap. Addons can share more with
//  player.setShared(key, value) and read them in their own animator extension
//  (DBR_ANIMATOR.extend on the client).
//
//    charge   1 while holding Charge Ki          surge     1 while the ki surge is armed
//    block    1 while guarding                   meditate  1 while meditating
//    fly      1 while flying                     flyFast   1 while flying fast (search mode, 64_dmz_movement.js)
//    stun     1 while stunned                    down      1 while knocked down
//    drain    1 while absorbing                  tf        the transformation animation while
//                                                          charging a form ("" otherwise)
//    act      {a, t, n}  a technique animation (act() in 01_toolbox.js)
//    dash     {d, n}     a dash (1 front, 2 back, 3 right, 4 left, 6-8 double-tap)
//    evade    {v, n}     a dodge (1 front, 2 back, 3 left, 4 right)
//    melee    {a, off, s, n}  a combo attack animation (combat.* id, offhand, speed)
//    pose     a weapon stance animation ("" for none)
// =====================================================================================
(function () {
    function flag(p, key, on) { p.setShared(key, on ? 1 : null); }

    // Held states end with their key: a charge whose release was never heard (a screen opened, the packet was lost,
    // the player relogged) is ended here, so its pose can't stay on. The guard has its own heartbeat (11_dmz_combat.js).
    var CHARGE_KEY = 9, LOOSE = {};
    function heldStateCheck(p) {
        if (p.hasEffect("ki_charge") && !p.isKeyHeld(CHARGE_KEY)) {
            if ((LOOSE[p.uuid] = (LOOSE[p.uuid] || 0) + 1) >= 3) {          // 6 ticks with the key up
                p.removeEffect("ki_charge");
                p.setVar("dmz_lowering", 0);
                delete LOOSE[p.uuid];
            }
        } else delete LOOSE[p.uuid];
    }
    RPG.on("playerJoin", (p) => {
        // nothing held survives a relog (effects and vars are saved with the player)
        ["ki_charge", "guarding", "meditating", "absorbing"].forEach((id) => { if (p.hasEffect(id)) p.removeEffect(id); });
        if (p.getVar("dmz_tf_anim", "")) p.setVar("dmz_tf_anim", "");
    });
    RPG.on("playerLeave", (p) => { delete LOOSE[p.uuid]; });

    RPG.every(2, () => {
        RPG.server.players().forEach((p) => {
            heldStateCheck(p);
            p.setShared("race", p.race || null);         // the look key can be a form, so share the race itself
            // ki charge pose; also the original's forced charge while the False Super Saiyan rage builds (31_dmz_transform.js)
            flag(p, "charge", p.hasEffect("ki_charge") || (Number(p.getVar("dmz_forced_aura", 0)) > 0 && !p.getVar("dmz_form", "")));
            flag(p, "surge", Number(p.getVar("dmz_surge", 0)) > 0);
            flag(p, "block", p.hasEffect("guarding"));
            flag(p, "meditate", p.hasEffect("meditating"));
            flag(p, "fly", p.hasEffect("flight"));
            // flyFast: the original's isFlyingFast (search flight above 0.45 b/t), reported by the flying player's
            // client and shared by 64_dmz_movement.js the moment it changes; nothing to do here

            flag(p, "stun", p.hasEffect("stunned"));
            flag(p, "down", p.hasEffect("knocked_down"));
            flag(p, "drain", p.hasEffect("absorbing"));
            let tf = p.getVar("dmz_tf_anim", "");
            p.setShared("tf", tf ? tf : null);
        });
    });
})();
