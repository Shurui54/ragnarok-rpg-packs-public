// =====================================================================================
//  01_toolbox.js - small helpers every other file uses
// =====================================================================================
//  Nothing here is Dragon Ball specific except the "dmzpack" default. It is the kind of
//  file you write once per game: play a sound, play an animation and go back to the
//  idle loop, deal stat-based damage, find the point in front of the player...
//
//  Where do the art files come from? resources/assets/dmzpack/ in this project.
//  resources/dmzpack_catalog.json lists every model, sound and animation name in it.
// =====================================================================================

// ---- Asset paths ----------------------------------------------------------------------
// "ns:path" strings are resource locations. Keeping the common prefixes in variables
// makes the rest of the scripts short (and easy to point at your own pack).
var DMZ = "dmzpack:";
var DMZ_TEX = "dmzpack:textures/entity/";
var DMZ_GEO = "dmzpack:geo/entity/";
var DMZ_ANIM = "dmzpack:animations/entity/";

// ---- Animation states of the original's saga rig ------------------------------------------------
// Every look on saga_base.animation.json (sagaLook, the rgnpc cast, quest/raid/space bodies) gets the states
// DBSagasEntity plays (run1 while chasing, fly / fly_fast while airborne) and its two always-on controllers,
// "tail" and "cape" (geo.loops). The original's hurt, swim and knocked-out clips live in the race movement file, whose
// bone names the saga rig shares: hurt_left on each hit, swimming in water, faint_horizontal held for 1.5 s on death.
function dmzSagaStates(geo) {
    geo.animations = [DMZ_ANIM + "races/movement.animation.json"];
    geo.run = "run1";
    geo.fly = "fly";
    geo.flyFast = "fly_fast";
    geo.swim = "base.swimming";
    geo.hurt = "base.hurt_left";
    geo.death = "base.faint_horizontal";
    geo.deathTime = 1.5;
    geo.loops = ["tail", "cape"];
    return geo;
}

// ---- Sounds ---------------------------------------------------------------------------
// sfx(where, "ki_kame_fire", volume, pitch) plays a sound from the asset pack for everyone
// within ~48 blocks of `where` (any player, mob or {x, y, z, dimension} object).
// A name without ":" means "dmzpack:<name>" (the keys of resources/assets/dmzpack/sounds.json).
//
// sfx() is heard by everyone near `where`; player.playSound() only by that player, and uiSfx() below
// plays a menu sound for one player that isn't placed in the world.
// Every original control is kept here by key number, so another script (a game mode) can take a key over
// for a while and hand back to the normal behaviour: see 96_fps_test.js.
var DBR_KEYS = {};
function defineKey(n, def) {
    if (def && def.category === undefined) def.category = "Dragon Block Ragnarok";   // its own heading in Options > Controls
    DBR_KEYS[n] = def;
    RPG.keys.define(n, def);
}

// A DBR config (ragnarok_rpg/config/<name>.json) as a plain object that stays live: ops change settings in game with
// /rpg config <name> <key> <value> (or edit the file and /rpg config reload) and the object updates. Older engines
// without RPG.config fall back to a one-time read.
function dbrConfig(name, defaults) {
    if (!RPG.config || typeof RPG.config.define !== "function") return RPG.files.config(name, defaults);
    var c = RPG.config.define(name, defaults), o = c.values();
    c.onChange(function (key, value) {
        var parts = String(key).split("."), t = o;
        for (var i = 0; i < parts.length - 1; i++) t = t[parts[i]] || (t[parts[i]] = {});
        t[parts[parts.length - 1]] = value;
    });
    return o;
}

function sfx(where, sound, volume, pitch) {
    if (!where) return;
    let id = sound.indexOf(":") < 0 ? DMZ + sound : sound;
    // one sound packet to nearby players (resource-pack sounds work too); heard from 16 blocks x volume
    RPG.world.sound(where.dimension, id, where.x, where.y, where.z,
        typeof volume === "number" ? volume : 1, typeof pitch === "number" ? pitch : 1);
}

// A menu / GUI sound only `player` hears, not placed in the world (the original plays these client-side with
// SimpleSoundInstance.forUI): nobody standing nearby hears someone else's menu clicks.
function uiSfx(player, sound, volume, pitch) {
    if (!player || !sound) return;
    let id = sound.indexOf(":") < 0 ? DMZ + sound : sound;
    let v = typeof volume === "number" ? volume : 1, pi = typeof pitch === "number" ? pitch : 1;
    if (typeof player.playUiSound === "function") player.playUiSound(id, v, pi);
    else player.playSound(id, v, pi);
}

// Particles around an entity's chest.
function burst(entity, particle, count, spread, speed) {
    RPG.world.particle(entity.dimension, particle, entity.x, entity.y + 1, entity.z, count, spread, speed || 0.02);
}

// ---- Player animations ----------------------------------------------------------------
// Player models (avatars, see 20_races.js) play their walk/run/fly loops by themselves.
// A script can play any animation from the avatar's files on top:
//     player.playAnimationFor("ki.kameha_cast", 40)   for 40 ticks (0 = loop until stopAnimation())
//
// Some states are "held": charging ki, flying, meditating. act() plays a one-shot animation
// and afterwards goes back to whatever the player is holding, so a Kamehameha fired while
// flying ends in the flying pose again.
var ANIM_SERIAL = {};     // uuid -> number; script variables reset on /rpg reload, which is fine here

function heldAnimation(player) {
    if (player.hasEffect("ki_charge")) return chargeAnimation(player);
    if (player.hasEffect("guarding")) return "base.block";
    // flying needs nothing here: the avatar's fly / flyFast states play on their own while flying
    if (player.hasEffect("meditating")) return "base.meditation";
    return "";
}

// Every race has its own ki-charge pose in the original's movement.animation.json.
function chargeAnimation(player) {
    let byRace = {
        human: "base.ki_charge_human", saiyan: "base.ki_charge_saiyan", namekian: "base.ki_charge_namekian",
        frost_demon: "base.ki_charge_frostdemon", bio_android: "base.ki_charge_bioandroid", majin: "base.ki_charge_majin"
    };
    return byRace[player.getRace()] || "base.ki_charge";
}

// Held states (charging, guarding, meditating, flying) are shared with every client
// (12_anim_state.js) and the client animator plays them, so nothing needs resuming any more.
function resumeHeld(player) {
    player.stopAnimation();
}

// A short animation on the "ki" layer (techniques, evasions), seen by everyone nearby.
// *_cast animations hold their last frame for `ticks`; others play through.
function act(player, animation, ticks) {
    if (!player.isPlayer()) { player.playAnimation(animation); return; }   // mobs: one-shot
    animPulse(player, "act", { a: animation, t: ticks || 20 });
}

// Sends a one-off animation event to every client: player.setShared(key, {...data, n}).
// n counts up so the same event twice in a row still plays twice.
function animPulse(player, key, data) {
    let serial = (ANIM_SERIAL[player.uuid + key] || 0) + 1;
    ANIM_SERIAL[player.uuid + key] = serial;
    let v = { n: serial };
    for (let k in data) v[k] = data[k];
    player.setShared(key, v);
}

// Cancels a running act() animation.
function stopAct(player) {
    animPulse(player, "act", { a: "", t: 0 });
}

// ---- Damage ---------------------------------------------------------------------------
// The original formulas, in one place: base + stat x scale + skill level x perLevel.
function kiDamage(player, base, perKiPower, level, perLevel) {
    return base + player.stat("kipower") * perKiPower + (level || 1) * (perLevel || 1);
}

function strikeDamage(player, base, perStrike, level, perLevel) {
    return base + player.stat("strike") * perStrike + player.stat("strength") * perStrike * 0.5 + (level || 1) * (perLevel || 1);
}

// Spiritualists pay 20% less ki for every technique (see 25_classes.js).
function kiCost(player, amount) {
    return player.getPlayerClass() === "spiritualist" ? Math.round(amount * 0.8) : amount;
}

// ---- Geometry -------------------------------------------------------------------------
// The point `distance` blocks in front of the player's eyes, as {x, y, z, dimension}.
function lookPoint(entity, distance) {
    let yaw = entity.yaw * Math.PI / 180;
    let pitch = entity.pitch * Math.PI / 180;
    return {
        x: entity.x - Math.sin(yaw) * Math.cos(pitch) * distance,
        y: entity.y + 1.6 - Math.sin(pitch) * distance,
        z: entity.z + Math.cos(yaw) * Math.cos(pitch) * distance,
        dimension: entity.dimension
    };
}

// Push `who` away from `from` (a knockback).
function knockAway(from, who, strength, up) {
    let dx = who.x - from.x, dz = who.z - from.z;
    let len = Math.max(0.1, Math.sqrt(dx * dx + dz * dz));
    who.push(dx / len * strength, up, dz / len * strength);
}

// Launch `who` toward `target` (used by dashes and rush attacks).
function pushToward(who, target, strength) {
    let dx = target.x - who.x, dy = target.y - who.y, dz = target.z - who.z;
    let len = Math.max(0.1, Math.sqrt(dx * dx + dy * dy + dz * dz));
    who.push(dx / len * strength, Math.max(0.15, dy / len * strength), dz / len * strength);
}

// The entity a player has locked on to with Z (45_keys.js), if it is still nearby.
function lockedTarget(player) {
    let uuid = player.getVar("lock_uuid", "");
    if (!uuid) return null;
    let found = null;
    player.nearby(48).forEach((e) => { if (e.uuid === uuid) found = e; });
    return found;
}

// The target of a technique: the locked-on enemy, else whatever is under the crosshair.
function aimTarget(player, range) {
    return lockedTarget(player) || player.target(range);
}

// Is the player holding one of this project's items? getHeldItem() gives the placeholder id
// ("ragnarok_rpg:item_0795"); RPG.items.id("brave_sword") turns a script name into one.
function holding(player, itemKey) {
    return player.getHeldItem() === "ragnarok_rpg:" + RPG.items.id(itemKey);
}

// times(3, (i) => ...) calls the function with 0, 1, 2. Use it instead of a for-loop whenever
// the loop body creates a closure (RPG.schedule, forEach callbacks...): in this JavaScript
// engine, closures created inside "for (let i...)" all see the LAST value of i.
function times(n, fn) {
    for (let i = 0; i < n; i++) fn(i);
}

// 12345 -> "12,345"
function grouped(n) {
    return String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
