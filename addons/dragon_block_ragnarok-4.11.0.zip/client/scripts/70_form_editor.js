// =====================================================================================
//  70_form_editor.js - the in-game form editor (operators), client side
// =====================================================================================
//  Port of DMZ Ragnarok's form editor screens (GPL-3.0): FormRaceListScreen -> FormListScreen
//  -> FormGroupEditScreen -> FormEditScreen (tabs + live rotating FormPreview). Drawn on the
//  canvas with DragonMine Z's own GUI art (dmzpack questmenu / menubig / characterbuttons).
//
//  Opened by /rpgc formeditor (or the unbound "Form Editor (operators)" key); the server
//  (scripts/32_dbr_form_editor.js) checks the op level and sends the saved data. A race is
//  edited as a whole and saved whole; saves apply at once (forms show in the radial menu).
//
//  Also keeps this computer's copy of DMZ_FORMS in step with the server: the "applied" data
//  the server merged on its last load arrives in chunks and is cached in RPG.storage, so
//  shared/07_dmz_forms_data.js can merge it straight away next time.
// =====================================================================================
var DBR_FORM_EDITOR_UI = (function () {
    var U = DMZ_UI;
    if (typeof DMZ_FORMS === "undefined" || !DMZ_FORMS.EDIT) return null;
    var FD = DMZ_FORMS, E = FD.EDIT;
    var FONT = "dmzpack:smooth";
    var BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png";
    var AURA_TEX = "dmzpack:textures/entity/races/aura/kakarot_aura.png";
    var RACE_ICON = "dmzpack:textures/gui/hud/racial_icons/";
    var RACE_ICONS = { human: 1, saiyan: 1, namekian: 1, frostdemon: 1, majin: 1, bioandroid: 1 };
    var SCREEN = "dbr_form_editor", CHUNK = 24000;

    // =================================================================================
    //  Sync: the server's merged forms -> this computer's DMZ_FORMS
    // =================================================================================
    var parts = {};
    RPG.net.on("dbr_fe_data", function (d) {
        if (!d || typeof d.s !== "string") return;
        var box = parts[d.kind];
        if (!box || box.id !== d.id) box = parts[d.kind] = { id: d.id, n: Number(d.n) || 1, got: 0, s: [] };
        if (box.s[d.i] === undefined) { box.s[d.i] = d.s; box.got++; }
        if (box.got < box.n) return;
        delete parts[d.kind];
        var obj = null;
        try { obj = JSON.parse(box.s.join("")); } catch (e) { return; }
        if (d.kind === "applied") applySync(obj);
        else if (d.kind === "editor") openEditor(obj);
    });
    function applySync(a) {
        if (!a || typeof a !== "object") return;
        var cur = FD.applied(), next = { rev: Number(a.rev) || 0, races: a.races && typeof a.races === "object" ? a.races : {} };
        if (JSON.stringify({ rev: cur.rev, races: cur.races }) === JSON.stringify(next)) return;
        try { RPG.storage.set(E.CACHE_KEY, next); } catch (e) { }
        FD.applyCustom(next.races, next.rev);
    }
    RPG.on("load", function () { RPG.net.send("dbr_fe", { op: "hello" }); });

    // the "button": an unbound key in Options > Controls (the server ignores non-operators)
    try { RPG.keys.register("dbr_form_editor", { name: "Form Editor (operators)" }); } catch (e) { }
    RPG.on("keybind", function (id, down) { if (id === "dbr_form_editor" && down && !RPG.screen.getOpen()) RPG.net.send("dbr_fe", { op: "open" }); });

    RPG.net.on("dbr_fe_ack", function (d) {
        if (!d || !S) return;
        S.rev = Number(d.rev) || S.rev; S.appliedRev = Number(d.appliedRev) || 0;
        if (d.ok && d.op === "save" && S.pendingSave && S.pendingSave.race === d.race) {
            S.saved[d.race] = S.pendingSave.groups; delete S.dirty[d.race];
        }
        if (d.ok && d.op === "reset") { delete S.saved[d.race]; delete S.work[d.race]; delete S.dirty[d.race]; if (S.race === d.race && S.view !== "races") go("groups"); }
        S.pendingSave = null;
        var warn = d.warnings && d.warnings.length ? " (" + d.warnings.length + " fixed: " + d.warnings[0] + ")" : "";
        status((d.msg || (d.ok ? "Done" : "Failed")) + warn, d.ok ? "#7CFF7C" : "#FF6060");
    });

    // =================================================================================
    //  Static data
    // =================================================================================
    var RACE_NAMES = { human: "Human", saiyan: "Saiyan", namekian: "Namekian", frostdemon: "Frost Demon", bioandroid: "Bio-Android", majin: "Majin", glind: "Glind" };
    var OUR = { human: "human", saiyan: "saiyan", namekian: "namekian", frostdemon: "frost_demon", bioandroid: "bio_android", majin: "majin", glind: "glind" };
    var TYPE_NAMES = { superforms: "Super", legendaryforms: "Legendary", godforms: "God", androidforms: "Android", falseform: "Scripted" };
    var HAIR_NAMES = { "": "Base style", base: "Base", ssj: "SSJ", ssj2: "SSJ 2", ssj3: "SSJ 3", ssj4: "SSJ 4", empty: "None" };
    var HAIR_RACES = { human: 1, saiyan: 1, glind: 1 };
    var TABS = ["Identity", "Colors", "Aura", "Stats", "Drains", "Mastery", "Stacking", "Gates", "Shader", "Overlays", "Model"];
    var PASS_KEYS = ["body1", "body2", "body3", "hair", "eyes", "eye2", "aura", "bodyType", "bodyModel", "eyeStyle", "nose", "mouth",
        "hairStyle", "tattoo", "halo", "tail"];
    var C_MAP = { fBody1: "body1", fBody2: "body2", fBody3: "body3", fHair: "hair", fEye1: "eye1", fEye2: "eye2" };
    var DEFAULTS = null, MODELS = null, ANIMS = null;
    function statics() {
        if (DEFAULTS) return;
        DEFAULTS = FD.rawDefaults();
        var m = {}, a = { "transf.generic": 1 };
        Object.keys(DEFAULTS).forEach(function (r) { DEFAULTS[r].forEach(function (g) { g.forms.forEach(function (f) { if (f.model) m[f.model] = 1; if (f.anim) a[f.anim] = 1; }); }); });
        MODELS = [""].concat(Object.keys(m).sort());
        ANIMS = Object.keys(a).sort();
    }

    // =================================================================================
    //  Editor state
    // =================================================================================
    var S = null;
    function clone(o) { return JSON.parse(JSON.stringify(o)); }
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function round(v) { return Math.round(v * 10000) / 10000; }
    function num(v) { return typeof v === "number" && !isNaN(v); }

    function openEditor(payload) {
        statics();
        var effects = {};
        try {
            var ids = RPG.defIds("effect"), n = ids ? (typeof ids.size === "function" ? ids.size() : ids.length) : 0;
            for (var i = 0; i < n; i++) effects[String(typeof ids.get === "function" ? ids.get(i) : ids[i])] = 1;
        } catch (e) { }
        S = { view: "races", race: null, gi: -1, fi: -1, tab: 0, scroll: 0, rev: Number(payload.rev) || 0, appliedRev: Number(payload.appliedRev) || 0,
            saved: payload.races || {}, work: {}, dirty: {}, eff: null, effects: effects, hits: [], tip: null, input: null, confirm: null,
            yaw: 200, spin: true, drag: null, aura: true, last: RPG.nowMs(), auraFrame: 0, auraAt: 0, pvKey: "", pvRect: null, msg: "", msgColor: "#FFFFFF", msgUntil: 0,
            pendingSave: null, ddN: 0, ddMax: 0, ddSig: {} };
        RPG.screen.open({ id: SCREEN, referenceHeight: 360, background: "dim", pause: false, elements: [
            { id: "pv_bg", type: "image", anchor: "topleft", x: 0, y: 0, w: 141, h: 213, texture: MENU_BIG, u: 0, v: 0, uw: 141, vh: 213, texW: 256, texH: 256, visible: false },
            { id: "pv_aura", type: "image", anchor: "topleft", x: 0, y: 0, w: 100, h: 100, texture: AURA_TEX, u: 0, v: 0, uw: 1024, vh: 1024, texW: 4096, texH: 1024,
                tint: "#FFFFFF", alpha: 0.6, blend: "additive", visible: false },
            { id: "pv_model", type: "entity", anchor: "topleft", x: 0, y: 0, w: 120, h: 180, rotation: 200, tilt: 6, followMouse: false, size: 70, visible: false }
        ], onBackground: render, onRender: renderTip, onMouse: mouse, onScroll: scroll, onKey: key, onClose: function () { S = null; } });
    }
    function status(text, color) { if (!S) return; S.msg = text; S.msgColor = color || "#FFFFFF"; S.msgUntil = RPG.nowMs() + 4500; }

    function work(race) {
        if (!S.work[race]) S.work[race] = clone(S.saved[race] || DEFAULTS[race] || []);
        return S.work[race];
    }
    function groups() { return work(S.race); }
    function group() { return groups()[S.gi] || null; }
    function form() { var g = group(); return g ? g.forms[S.fi] || null : null; }
    function changed() { S.dirty[S.race] = true; S.eff = null; }
    function eff() {
        if (!S.eff) {
            var g = group(), copy = g ? FD.finishedCopy(S.race, g) : null;
            S.eff = copy ? copy.forms[S.fi] || null : null;
        }
        return S.eff;
    }
    function go(view) {
        endInput(true);
        S.view = view; S.scroll = 0; S.confirm = null; S.eff = null;
    }
    function uniqueId(list, base) {
        var ids = {}; list.forEach(function (x) { ids[x.id] = 1; });
        if (!ids[base]) return base;
        for (var i = 2; i < 999; i++) if (!ids[base + i]) return base + i;
        return base + RPG.nowMs();
    }
    function move(list, i, d) {
        var j = i + d;
        if (j < 0 || j >= list.length) return i;
        var t = list[i]; list[i] = list[j]; list[j] = t;
        changed();
        return j;
    }
    function raceTokens(exceptKey) {
        var out = [];
        groups().forEach(function (g) { g.forms.forEach(function (f) { var k = g.id + "." + f.id; if (k !== exceptKey) out.push(k); }); });
        return out;
    }

    /** A renamed group / form: fix the requisite, share and incompatibility tokens that point at it. */
    function renameRefs(from, to) {
        if (from === to) return;
        groups().forEach(function (g) {
            g.forms.forEach(function (f) {
                if (f.req) f.req = String(f.req).split(",").map(function (t) { return t.trim() === from ? to : t.trim(); }).join(",");
                if (f.share) f.share.forEach(function (e) { if (e[0] === from) e[0] = to; });
                if (f.incompat) f.incompat = f.incompat.map(function (t) { return t === from ? to : t; });
            });
        });
    }
    function saveRace() {
        var race = S.race, list = groups(), san = FD.sanitizeRace(list);
        if (!san.groups.length) { status("Can't save: " + (san.errors[0] || "no valid groups"), "#FF6060"); return; }
        var s = JSON.stringify(san.groups), n = Math.max(1, Math.ceil(s.length / CHUNK)), id = "s" + RPG.nowMs();
        if (n > 20) { status("Too much data to send (" + s.length + " characters)", "#FF6060"); return; }
        S.pendingSave = { race: race, groups: san.groups };
        for (var i = 0; i < n; i++) RPG.net.send("dbr_fe", { op: "save", race: race, id: id, i: i, n: n, s: s.substring(i * CHUNK, (i + 1) * CHUNK) });
        status(san.errors.length ? "Saving (" + san.errors.length + " problem(s) fixed: " + san.errors[0] + ")..." : "Saving...", "#FFE070");
    }

    // =================================================================================
    //  Drawing helpers (DMZ art)
    // =================================================================================
    function txt(ctx, t, x, y, color, align, scale, alpha) { ctx.textStyled(String(t), x, y, scale || 0.75, color || "#FFFFFF", alpha === undefined ? 1 : alpha, align || 0, FONT, "#000000"); }
    function tw(ctx, t, scale) { return ctx.textWidthIn(String(t), FONT) * (scale || 0.75); }
    function fit(ctx, t, w, scale) {
        t = String(t);
        if (tw(ctx, t, scale) <= w) return t;
        while (t.length > 1 && tw(ctx, t + "...", scale) > w) t = t.substring(0, t.length - 1);
        return t + "...";
    }
    function inside(x, y, r) { return x >= r.x && y >= r.y && x < r.x + r.w && y < r.y + r.h; }
    function hit(x, y, w, h, fn, tip) { var r = { x: x, y: y, w: w, h: h, fn: fn, tip: tip }; S.hits.push(r); return r; }
    function over(ctx, x, y, w, h) { return inside(ctx.mouseX, ctx.mouseY, { x: x, y: y, w: w, h: h }); }
    function q(ctx, sx, sy, sw, sh, dx, dy, dw, dh, alpha) { ctx.quad(BUTTONS, dx, dy, dw, dh, sx / 256, sy / 256, (sx + sw) / 256, (sy + sh) / 256, "#FFFFFF", alpha === undefined ? 1 : alpha); }
    /** characterbuttons' 74x20 button, 3-sliced to any width; light = the green (selected) variant. */
    function button(ctx, label, x, y, w, fn, opt) {
        opt = opt || {};
        var dis = !!opt.disabled, hov = !dis && over(ctx, x, y, w, 20), v = hov || opt.light ? 48 : 28;
        q(ctx, 0, v, 4, 20, x, y, 4, 20); q(ctx, 4, v, 66, 20, x + 4, y, w - 8, 20); q(ctx, 70, v, 4, 20, x + w - 4, y, 4, 20);
        if (dis) ctx.fill(x + 2, y + 2, w - 4, 16, "#000000", 0.4);
        var col = opt.color || (dis ? "#909090" : opt.light ? "#1A3A10" : hov ? "#FFFFA0" : "#FFFFFF");
        ctx.textStyled(label, x + w / 2, y + 6, 1, col, 1, 0.5, FONT, opt.light ? null : "#000000");
        if (!dis) hit(x, y, w, 20, fn, opt.tip);
        else if (opt.tip) hit(x, y, w, 20, null, opt.tip);
    }
    /** a small chip (tabs): the button art at 12 px high. */
    function chip(ctx, label, x, y, w, sel, fn, disabled, tip) {
        var hov = over(ctx, x, y, w, 12), v = sel || hov ? 48 : 28;
        U.slice9(ctx, BUTTONS, x, y, w, 12, 0, v, 74, 20, 4);        // 9-sliced: the 20-high art is not squashed to 12
        if (disabled) ctx.fill(x + 1, y + 1, w - 2, 10, "#000000", 0.45);
        txt(ctx, label, x + w / 2, y + 3, disabled ? "#8A8A8A" : sel ? "#14300C" : hov ? "#FFFFA0" : "#FFFFFF", 0.5, 0.7);
        hit(x, y, w, 12, disabled ? null : fn, tip);
    }
    function icon(ctx, kind, x, y, fn, tip) {        // 10x10 icons from characterbuttons
        var src = { plus: [0, 0], minus: [142, 0], trash: [10, 0], info: [112, 0], equal: [102, 0] }[kind];
        var hov = over(ctx, x, y, 10, 10);
        q(ctx, src[0], src[1] + (hov ? 10 : 0), 10, 10, x, y, 10, 10);
        hit(x, y, 10, 10, fn, tip);
    }
    function bigIcon(ctx, kind, x, y, size, fn, tip, disabled) {   // 20x20 up / down / edit icons, drawn at size
        var u = { up: 162, down: 182, edit: 202 }[kind], hov = !disabled && over(ctx, x, y, size, size);
        q(ctx, u, hov ? 20 : 0, 20, 20, x, y, size, size, disabled ? 0.35 : 1);
        if (!disabled) hit(x, y, size, size, fn, tip);
    }
    function arrow(ctx, right, x, y, fn) {             // the DMZ list arrows (8x14), drawn 6x10
        var hov = over(ctx, x - 1, y - 1, 8, 12);
        q(ctx, right ? 20 : 32, hov ? 14 : 0, 8, 14, x, y, 6, 10);
        hit(x - 1, y - 1, 8, 12, fn);
    }
    function toggle(ctx, on, x, y, fn) { q(ctx, 122, on ? 0 : 10, 20, 10, x, y, 20, 10); hit(x, y, 20, 10, fn); }
    function field(ctx, x, y, w, h) {                  // PanelSkin.FIELD (characterbuttons 0,108)
        var v = 108;
        q(ctx, 0, v, 3, 3, x, y, 3, 3); q(ctx, 3, v, 101, 3, x + 3, y, w - 6, 3); q(ctx, 104, v, 3, 3, x + w - 3, y, 3, 3);
        q(ctx, 0, v + 3, 3, 11, x, y + 3, 3, h - 7); q(ctx, 3, v + 3, 101, 11, x + 3, y + 3, w - 6, h - 7); q(ctx, 104, v + 3, 3, 11, x + w - 3, y + 3, 3, h - 7);
        q(ctx, 0, v + 14, 3, 4, x, y + h - 4, 3, 4); q(ctx, 3, v + 14, 101, 4, x + 3, y + h - 4, w - 6, 4); q(ctx, 104, v + 14, 3, 4, x + w - 3, y + h - 4, 3, 4);
    }
    function panel(ctx, x, y, w, h, title) {
        if (typeof DMZ_UI !== "undefined") DMZ_UI.QUEST_PANEL.draw(ctx, x, y, w, h);
        else { ctx.fill(x, y, w, h, "#0B2A0B", 0.95); ctx.fill(x, y, w, 1, "#C8D0F0", 1); }
        if (title) {
            var tw2 = Math.min(w - 30, 150);
            U.slice9(ctx, MENU_BIG, x + (w - tw2) / 2, y + 7, tw2, 21, 142, 22, 107, 21, 10);   // ribbon ends kept, middle stretched
            ctx.textStyled("§l" + title, x + w / 2, y + 14, 1, "#FFD700", 1, 0.5, FONT, "#000000");
        }
    }
    function scrollbar(ctx, x, top, h, total) {
        if (total <= h) return;
        var th = Math.max(16, h * h / total), ty = top + (h - th) * S.scroll / (total - h);
        ctx.fill(x, top, 2, h, "#000000", 0.35);
        ctx.fill(x, ty, 2, th, "#D2D7F1", 1);
    }
    function confirmKey(k) { return S.confirm && S.confirm.k === k && RPG.nowMs() < S.confirm.until; }
    function askConfirm(k, fn) {
        if (confirmKey(k)) { S.confirm = null; fn(); return; }
        S.confirm = { k: k, until: RPG.nowMs() + 3000 };
        status("Click again to confirm", "#FFB040");
    }

    // =================================================================================
    //  Rendering
    // =================================================================================
    var L = { listTop: 0, listH: 0, total: 0, rowH: 18 };
    function render(ctx) {
        if (!S) return;
        var now = RPG.nowMs(), dt = Math.min(0.1, (now - S.last) / 1000);
        S.last = now;
        S.hits = [];
        var W = ctx.width, H = ctx.height, cx = Math.floor(W / 2), cy = Math.floor(H / 2);
        S.ddN = 0;
        if (S.view === "form" && form()) renderForm(ctx, cx, cy, dt);
        else {
            preview(null);
            if (S.view === "groups") renderGroups(ctx, cx, cy);
            else if (S.view === "group" && group()) renderGroup(ctx, cx, cy);
            else { S.view = "races"; renderRaces(ctx, cx, cy); }
        }
        // dropdowns no row uses this frame are hidden
        for (var d = S.ddN; d < S.ddMax; d++) if (S.ddSig["fe_dd" + d] !== "hidden") { RPG.screen.update("fe_dd" + d, { visible: false }); S.ddSig["fe_dd" + d] = "hidden"; }
        S.ddMax = Math.max(S.ddMax, S.ddN);
        // status line
        var left = S.msgUntil - now;
        if (left > 0 && S.msg) txt(ctx, S.msg, cx, H - 14, S.msgColor, 0.5, 0.8, Math.min(1, left / 800));
    }
    /** Tooltips: drawn after the elements so nothing covers them. */
    function renderTip(ctx) {
        if (!S) return;
        for (var i = S.hits.length - 1; i >= 0; i--) {
            var h = S.hits[i];
            if (h.tip && inside(ctx.mouseX, ctx.mouseY, h)) {
                var lines = (typeof h.tip === "string" ? [h.tip] : h.tip).map(function (l, n) { return [l, n === 0 ? "#FFD700" : "#C0C0C0"]; });
                if (typeof DMZ_UI !== "undefined") DMZ_UI.tooltip(ctx, lines, ctx.mouseX, ctx.mouseY);
                break;
            }
        }
    }

    function listArea(ctx, x, y, w, h, rows, rowH, drawRow) {
        L.listTop = y; L.listH = h; L.total = rows.length * rowH; L.rowH = rowH; L.x = x; L.w = w;
        S.scroll = clamp(S.scroll, 0, Math.max(0, L.total - h));
        ctx.clip(x, y, w, h);
        var savedHits = S.hits.length;
        S.inList = true;
        rows.forEach(function (r, i) {
            var ry = y + i * rowH - S.scroll;
            if (ry + rowH < y || ry > y + h) return;
            drawRow(r, i, ry);
        });
        S.inList = false;
        ctx.unclip();
        // drop hit boxes scrolled out of the list
        for (var k = S.hits.length - 1; k >= savedHits; k--) { var hb = S.hits[k]; if (hb.y + hb.h <= y || hb.y >= y + h) S.hits.splice(k, 1); }
        scrollbar(ctx, x + w + 2, y, h, L.total);
    }

    // ---- 1. races (FormRaceListScreen) ----
    function renderRaces(ctx, cx, cy) {
        var w = 300, h = 290, x = cx - w / 2, y = cy - h / 2;
        panel(ctx, x, y, w, h, "Form Editor");
        var applied = S.rev === S.appliedRev;
        txt(ctx, applied ? "All saves applied" : "Saved changes not applied yet", x + w / 2, y + 34, applied ? "#9FE09F" : "#FFB040", 0.5);
        listArea(ctx, x + 16, y + 48, w - 36, 190, FD.RACES, 26, function (r, i, ry) {
            var hov = over(ctx, x + 16, ry, w - 36, 24);
            ctx.fill(x + 16, ry, w - 36, 24, "#FFFFFF", hov ? 0.16 : 0.07);
            // races without a DMZ racial icon (Glind) use DMZ's "custom" one
            ctx.image(RACE_ICON + (RACE_ICONS[r] ? r : "custom") + ".png", x + 20, ry + 2, 20, 20, 0, hov ? 16 : 0, 16, 16, 16, 32);
            txt(ctx, RACE_NAMES[r] || r, x + 46, ry + 5, "#FFFFFF", 0, 1);
            var state = S.dirty[r] ? ["unsaved changes", "#FFB040"] : S.saved[r] ? ["edited", "#7CFDD6"] : ["defaults", "#9A9A9A"];
            var n = work0(r).length;
            txt(ctx, n + " groups · " + state[0], x + 46, ry + 15, state[1], 0, 0.65);
            bigIcon(ctx, "edit", x + w - 44, ry + 4, 16, function () { S.race = r; go("groups"); }, "Edit " + (RACE_NAMES[r] || r) + " forms");
            hit(x + 16, ry, w - 64, 24, function () { S.race = r; go("groups"); });
        });
        button(ctx, "Close", x + w / 2 - 40, y + h - 36, 80, function () { RPG.screen.close(); });
    }
    function work0(r) { return S.work[r] || S.saved[r] || DEFAULTS[r] || []; }

    // ---- 2. groups of a race (FormListScreen) ----
    function renderGroups(ctx, cx, cy) {
        var w = 320, h = 300, x = cx - w / 2, y = cy - h / 2, list = groups();
        panel(ctx, x, y, w, h, (RACE_NAMES[S.race] || S.race) + " Forms");
        txt(ctx, S.dirty[S.race] ? "Unsaved changes" : S.saved[S.race] ? "Saved edits" : "Default forms", x + w / 2, y + 34, S.dirty[S.race] ? "#FFB040" : "#9FE09F", 0.5);
        listArea(ctx, x + 16, y + 46, w - 36, 196, list, 22, function (g, i, ry) {
            var hov = over(ctx, x + 16, ry, w - 36, 20);
            ctx.fill(x + 16, ry, w - 36, 20, "#FFFFFF", hov ? 0.16 : 0.07);
            txt(ctx, fit(ctx, g.n || g.id, 130, 0.9), x + 22, ry + 3, "#FFFFFF", 0, 0.9);
            txt(ctx, (TYPE_NAMES[g.type] || g.type) + " · " + g.forms.length + " form" + (g.forms.length === 1 ? "" : "s") + " · " + g.id, x + 22, ry + 12, "#9FB8AE", 0, 0.6);
            var bx = x + w - 20 - 16 * 4;
            bigIcon(ctx, "up", bx, ry + 2, 15, function () { move(list, i, -1); }, "Move up", i === 0);
            bigIcon(ctx, "down", bx + 16, ry + 2, 15, function () { move(list, i, 1); }, "Move down", i === list.length - 1);
            bigIcon(ctx, "edit", bx + 32, ry + 2, 15, function () { S.gi = i; go("group"); }, "Edit group");
            icon(ctx, "trash", bx + 50, ry + 5, function () {
                askConfirm("dg" + S.race + g.id, function () { list.splice(i, 1); changed(); status("Group removed (save to keep it)", "#FFB040"); });
            }, confirmKey("dg" + S.race + g.id) ? ["Click again to delete", g.n] : ["Delete group", g.n]);
            hit(x + 16, ry, bx - x - 20, 20, function () { S.gi = i; go("group"); });
        });
        var by = y + h - 50;
        button(ctx, "+ Group", x + 16, by, 70, function () {
            var id = uniqueId(list, "custom");
            list.push({ id: id, type: "superforms", n: "Custom", forms: [newForm([], 1)] });
            changed(); S.gi = list.length - 1; go("group");
        }, { tip: "A new form group (a new ladder)" });
        button(ctx, "Save", x + 90, by, 70, saveRace, { tip: ["Save " + (RACE_NAMES[S.race] || S.race), "Stored with the world and applied at once"], disabled: !!S.pendingSave });
        button(ctx, "Revert", x + 164, by, 70, function () {
            askConfirm("rv" + S.race, function () { delete S.work[S.race]; delete S.dirty[S.race]; status("Unsaved changes dropped", "#FFB040"); });
        }, { tip: "Drop unsaved changes", disabled: !S.dirty[S.race] });
        button(ctx, "Defaults", x + 238, by, 66, function () {
            askConfirm("rs" + S.race, function () { RPG.net.send("dbr_fe", { op: "reset", race: S.race }); });
        }, { tip: ["Reset this race to the default forms", "Deletes the saved edits"], disabled: !S.saved[S.race] });
        button(ctx, "Back", x + w / 2 - 35, by + 23, 70, function () { go("races"); });
    }
    function newForm(forms, lvl) {
        var id = uniqueId(forms, "newform");
        return { id: id, n: "New Form", lvl: lvl, saga: "", m: [1.5, 1.5, 1.3, 1.5], ki: 0.1, hair: "base" };
    }

    // ---- 3. one group: ladder order (FormGroupEditScreen) ----
    function renderGroup(ctx, cx, cy) {
        var w = 320, h = 310, x = cx - w / 2, y = cy - h / 2, g = group(), list = groups();
        panel(ctx, x, y, w, h, fit(ctx, g.n || g.id, 130, 1));
        // group fields
        var fy = y + 34;
        var gRows = [
            textRow("Group name", function () { return g.n || ""; }, function (v) { g.n = v.substring(0, 40) || g.id; }, 40),
            textRow("Group id", function () { return g.id; }, function (v) {
                v = v.toLowerCase();
                if (!E.ID_RE.test(v) || v === "o") { status("Ids use a-z, 0-9 and _", "#FF6060"); return; }
                if (v !== g.id && list.some(function (o) { return o.id === v; })) { status("That id is taken", "#FF6060"); return; }
                g.forms.forEach(function (o) { renameRefs(g.id + "." + o.id, v + "." + o.id); });
                g.id = v;
            }, 32, ["Group id", "Part of every form's effect id and mastery key:", "renaming loses players' mastery in it"]),
            choiceRow("Type", function () { return g.type; }, function (v) { g.type = v; if (v === "falseform") g.scripted = 1; else delete g.scripted; },
                E.GROUP_TYPES, function (v) { return TYPE_NAMES[v] || v; }, ["Form skill that unlocks it", "Super / Legendary / God / Android forms skill", "Scripted: never chargeable"])
        ];
        gRows.forEach(function (r, i) { drawRow(ctx, r, x + 16, fy + i * 15, w - 32, 14); });
        txt(ctx, "Ladder (top = first form)", x + 18, fy + 49, "#FFD700", 0, 0.75);
        listArea(ctx, x + 16, fy + 60, w - 36, 150, g.forms, 20, function (f, i, ry) {
            var hov = over(ctx, x + 16, ry, w - 36, 18);
            ctx.fill(x + 16, ry, w - 36, 18, "#FFFFFF", hov ? 0.16 : 0.07);
            if (f.aura) ctx.fill(x + 18, ry + 3, 3, 12, f.aura, 1);
            txt(ctx, (i + 1) + ".", x + 25, ry + 5, "#9FB8AE", 0, 0.75);
            txt(ctx, fit(ctx, f.n || f.id, 120, 0.85), x + 40, ry + 2, "#FFFFFF", 0, 0.85);
            txt(ctx, "lvl " + f.lvl + " · " + f.id, x + 40, ry + 11, "#9FB8AE", 0, 0.6);
            var bx = x + w - 20 - 15 * 4 - 8;
            bigIcon(ctx, "up", bx, ry + 2, 14, function () { move(g.forms, i, -1); }, "Earlier in the ladder", i === 0);
            bigIcon(ctx, "down", bx + 15, ry + 2, 14, function () { move(g.forms, i, 1); }, "Later in the ladder", i === g.forms.length - 1);
            bigIcon(ctx, "edit", bx + 30, ry + 2, 14, function () { S.fi = i; S.tab = 0; go("form"); }, "Edit form");
            icon(ctx, "equal", bx + 47, ry + 4, function () {
                var c = clone(f); c.id = uniqueId(g.forms, f.id + "_copy"); c.n = (f.n || f.id) + " Copy";
                g.forms.splice(i + 1, 0, c); changed(); status("Copied " + (f.n || f.id), "#7CFF7C");
            }, "Duplicate");
            icon(ctx, "trash", bx + 59, ry + 4, function () {
                if (g.forms.length <= 1) { status("A group needs one form (delete the group instead)", "#FF6060"); return; }
                askConfirm("df" + g.id + f.id, function () { g.forms.splice(i, 1); changed(); });
            }, confirmKey("df" + g.id + f.id) ? ["Click again to delete", f.n] : ["Delete form", f.n]);
            hit(x + 16, ry, bx - x - 20, 18, function () { S.fi = i; S.tab = 0; go("form"); });
        });
        var by = y + h - 32;
        button(ctx, "+ Form", x + 20, by, 80, function () {
            var last = g.forms[g.forms.length - 1];
            g.forms.push(newForm(g.forms, last ? Math.min(99, last.lvl + 1) : 1));
            changed(); S.fi = g.forms.length - 1; S.tab = 0; go("form");
        }, { tip: "Adds a form at the end of the ladder" });
        button(ctx, "Save race", x + w / 2 - 40, by, 80, saveRace, { disabled: !!S.pendingSave });
        button(ctx, "Back", x + w - 100, by, 80, function () { go("groups"); });
    }

    // ---- 4. one form: tabs + preview (FormEditScreen) ----
    function renderForm(ctx, cx, cy, dt) {
        var f = form(), X = eff(), g = group();
        if (!X) { go("group"); return; }
        var w = 300, h = 310, total = w + 6 + 141, x = cx - Math.floor(total / 2), y = cy - h / 2 - 6;
        panel(ctx, x, y, w, h, null);
        txt(ctx, fit(ctx, (RACE_NAMES[S.race] || S.race) + " › " + (g.n || g.id) + " › " + (f.n || f.id), w - 24, 0.9), x + w / 2, y + 12, "#FFD700", 0.5, 0.9);
        // tabs, two rows (identity ... buffs)
        var tabW = 45, ty = y + 26;
        TABS.forEach(function (t, i) {
            var row = i < 6 ? 0 : 1, col = row ? i - 6 : i, tx = x + 13 + col * (tabW + 1) + (row ? (tabW + 1) / 2 : 0);
            var off = i === 8;
            chip(ctx, t, tx, ty + row * 13, tabW, S.tab === i, function () { endInput(true); S.tab = i; S.scroll = 0; }, off,
                off ? [t, "Not in Dragon Block Ragnarok:", "the engine has no outline shader"] : null);
        });
        var rows = tabRows(S.tab, f, X, g);
        var top = ty + 30, listH = y + h - 14 - top;
        listArea(ctx, x + 12, top, w - 28, listH, rows, 15, function (r, i, ry) { drawRow(ctx, r, x + 12, ry, w - 28, 14); });
        // preview column
        var px = x + w + 6, py = y + 4;
        preview({ x: px, y: py, f: f, X: X, g: g, dt: dt });
        var cap = "Scale " + round(X.scale[1]) + (X.scale[1] > 1.05 ? " (shrunk to fit)" : "");
        txt(ctx, cap, px + 70, py + 198, "#C0C0C0", 0.5, 0.6);
        if (S.pvProxy) txt(ctx, "approx. look until saved", px + 70, py + 190, "#FFB040", 0.5, 0.55);
        var by = py + 218;
        button(ctx, S.spin ? "Stop spin" : "Spin", px, by, 68, function () { S.spin = !S.spin; });
        button(ctx, S.aura ? "Aura on" : "Aura off", px + 73, by, 68, function () { S.aura = !S.aura; S.pvKey = ""; });
        button(ctx, "Save race", px, by + 23, 68, saveRace, { disabled: !!S.pendingSave, tip: ["Save every change to " + (RACE_NAMES[S.race] || S.race), "applied at once"] });
        button(ctx, "Back", px + 73, by + 23, 68, function () { go("group"); });
        if (S.dirty[S.race]) txt(ctx, "unsaved", px + 70, by + 47, "#FFB040", 0.5, 0.7);
    }

    // ---- rows ----
    // kinds: num, text, color, bool, choice, info, head. Each: label, get() (raw or undefined), eff() (shown when unset),
    // set(v), clear() (back to default), tip.
    function drawRow(ctx, r, x, y, w, h) {
        if (r.kind === "head") { txt(ctx, "§l" + r.label, x + 2, y + 4, "#FFD700", 0, 0.75); ctx.fill(x + 2, y + h - 1, w - 4, 1, "#8D9BC6", 0.35); return; }
        var dis = !!r.disabled, hov = over(ctx, x, y, w, h);
        if (hov) ctx.fill(x, y, w, h, "#FFFFFF", 0.07);
        txt(ctx, fit(ctx, r.label, w * 0.42, 0.75), x + 4, y + 4, dis ? "#8A8A8A" : "#FFFFFF", 0, 0.75);
        if (r.tip || dis) hit(x, y, Math.floor(w * 0.44), h, null, r.tip || [r.label, "Not supported"]);
        var vx = x + Math.floor(w * 0.45), vw = w - Math.floor(w * 0.45) - 14, raw = r.get ? r.get() : undefined, isSet = raw !== undefined && raw !== null && raw !== "";
        var shown = isSet ? raw : r.eff ? r.eff() : "";
        var col = dis ? "#8A8A8A" : isSet ? "#FFFFFF" : "#9A9A9A";
        if (r.kind === "info") { txt(ctx, fit(ctx, String(shown), vw + 12, 0.7), vx, y + 4, "#B0B0B0", 0, 0.7); return; }
        if (r.kind === "action") { button(ctx, r.button, vx, y, vw, dis ? null : function () { endInput(true); r.run(); changed(); }, { disabled: dis }); return; }
        if (r.kind === "bool") {
            toggle(ctx, !!shown, vx + 2, y + 2, dis ? null : function () { endInput(true); r.set(!shown); changed(); });
        } else if (r.kind === "choice") {
            choiceDropdown(r, vx, y, vw, h, shown, dis);
        } else if (r.kind === "num") {
            if (!dis) icon(ctx, "minus", vx, y + 2, function () { endInput(true); step(r, shown, -1); }, ["-" + r.step, "Shift: x10"]);
            var editing = S.input && S.input.row.label === r.label && S.input.tab === S.tab;
            if (!editing) {
                field(ctx, vx + 12, y, vw - 24, h);
                txt(ctx, fit(ctx, fmtNum(r, shown), vw - 30, 0.72), vx + vw / 2, y + 4, col, 0.5, 0.72);
                if (!dis) hit(vx + 12, y, vw - 24, h, function () { beginInput(r, vx + 12, y + 1, vw - 24, isSet ? String(raw) : (num(shown) ? String(round(shown)) : "")); }, "Click to type a value");
            }
            if (!dis) icon(ctx, "plus", vx + vw - 10, y + 2, function () { endInput(true); step(r, shown, 1); }, ["+" + r.step, "Shift: x10"]);
        } else {             // text / color
            var editing2 = S.input && S.input.row.label === r.label && S.input.tab === S.tab;
            var fx = vx, fw = vw;
            if (r.kind === "color") {
                ctx.fill(vx, y + 1, 12, h - 2, "#000000", 1);
                if (shown) ctx.fill(vx + 1, y + 2, 10, h - 4, String(shown), 1);
                else { ctx.fill(vx + 1, y + 2, 5, h - 4, "#808080", 1); ctx.fill(vx + 6, y + 2, 5, h - 4, "#404040", 1); }
                fx = vx + 15; fw = vw - 15;
            }
            if (!editing2) {
                field(ctx, fx, y, fw, h);
                var t = r.kind === "color" && !shown ? (r.none || "inherit") : r.fmt ? r.fmt(shown) : String(shown === undefined ? "" : shown);
                txt(ctx, fit(ctx, t, fw - 8, 0.72), fx + 4, y + 4, col, 0, 0.72);
                if (!dis && r.kind === "color") hit(vx, y, vw, h, function () { pickColor(r, vx, y, vw, h, shown); }, "Click to pick a colour");
                else if (!dis) hit(fx, y, fw, h, function () { beginInput(r, fx, y + 1, fw, String(shown === undefined ? "" : shown)); }, "Click to edit");
            }
        }
        if (isSet && r.clear && !dis) icon(ctx, "trash", x + w - 11, y + 2, function () { endInput(false); r.clear(); changed(); }, r.clearTip || "Back to the default");
    }
    /** A choice row's searchable dropdown: an engine element kept over the row (hidden when scrolled out of the list). */
    function choiceDropdown(r, x, y, w, h, shown, dis) {
        if (S.inList && (y < L.listTop || y + h > L.listTop + L.listH)) return;
        var id = "fe_dd" + (S.ddN++), opts = r.options();
        var sig = [S.view, S.tab, S.race, S.gi, S.fi, r.label, Math.round(x), Math.round(y), w, h, String(shown), !!dis, opts.join("\u0001")].join("|");
        if (S.ddSig[id] === sig) return;
        S.ddSig[id] = sig;
        RPG.screen.update(id, U.dropdown(id, x, y, w, h, opts.map(function (o) {
                var e = { value: o, label: r.fmt ? r.fmt(o) : String(o) }, ic = r.icon ? r.icon(o) : null;
                if (ic) e.icon = ic;
                return e;
            }),
            shown === undefined ? "" : shown, function (v) { endInput(true); r.set(v); changed(); },
            { anchor: "topleft", visible: true, disabled: !!dis, listWidth: Math.max(w, r.icon ? 230 : 150), padding: 3, search: opts.length > 8 || !!r.custom,
              custom: !!r.custom, customLabel: "Use: ", maxVisible: r.icon ? 10 : 8 }));
    }
    function fmtNum(r, v) {
        if (!num(v)) return r.blank || "-";
        if (r.fmt) return r.fmt(v);
        return String(r.int ? Math.round(v) : round(v));
    }
    function step(r, shown, d) {
        var shift = RPG.isKeyDown("key.keyboard.left.shift") || RPG.isKeyDown("key.keyboard.right.shift");
        var base = num(shown) ? shown : (r.start !== undefined ? r.start : 0);
        var v = clamp(base + d * r.step * (shift ? 10 : 1), r.min, r.max);
        r.set(r.int ? Math.round(v) : round(v));
        changed();
    }

    // ---- colour rows: the engine's colour picker under the row (live preview while picking, Esc puts it back) ----
    function pickColor(r, x, y, w, h, shown) {
        endInput(true);
        var from = [S.view, S.tab, S.race, S.gi, S.fi].join("|");
        var same = function () { return S && [S.view, S.tab, S.race, S.gi, S.fi].join("|") === from; };
        var start = r.get ? r.get() : undefined;
        RPG.screen.pickColor({ x: x, y: y, w: w, h: h, value: shown && E.HEX_RE.test(String(shown)) ? String(shown) : "#FFFFFF" },
            function (v) { if (same()) { r.set(String(v).toUpperCase()); changed(); } },
            function (v, cancelled) {
                // cancelled: back to what it was before (unset stays unset)
                if (cancelled && same()) { if ((start === undefined || start === null || start === "") && r.clear) r.clear(); else if (start) r.set(start); changed(); }
            });
    }

    // ---- text input (an engine input box over the row) ----
    function beginInput(row, x, y, w, value) {
        endInput(true);
        S.input = { row: row, tab: S.tab, value: value, rect: { x: x, y: y - 1, w: w, h: 14 } };
        RPG.screen.update("fe_input", { type: "input", anchor: "topleft", x: x, y: y, w: w, h: 12, value: value, maxLength: row.maxLen || 32, autofocus: true,
            onChange: function (id, v) {
                if (!S || !S.input) return;
                S.input.value = String(v);
                if (row.kind === "color" && E.HEX_RE.test(String(v))) { row.set(String(v).toUpperCase()); changed(); }   // live preview
            } });
    }
    function endInput(commit) {
        if (!S || !S.input) return;
        var inp = S.input;
        S.input = null;
        try { RPG.screen.remove("fe_input"); } catch (e) { }
        if (!commit) return;
        var r = inp.row, v = String(inp.value === undefined || inp.value === null ? "" : inp.value).trim();
        if (r.kind === "num") {
            if (v === "") { if (r.clear) { r.clear(); changed(); } return; }
            var n = Number(v);
            if (isNaN(n)) { status("Not a number: " + v, "#FF6060"); return; }
            n = clamp(n, r.min, r.max);
            r.set(r.int ? Math.round(n) : round(n)); changed();
        } else if (r.kind === "color") {
            if (v === "") { if (r.clear) { r.clear(); changed(); } return; }
            if (v.charAt(0) !== "#") v = "#" + v;
            if (!E.HEX_RE.test(v)) { status("Colours look like #FFD700", "#FF6060"); return; }
            r.set(v.toUpperCase()); changed();
        } else {
            if (v === "" && r.clear) { r.clear(); changed(); return; }
            r.set(v); changed();
        }
    }

    // ---- row builders bound to the edited raw form ----
    function numRow(label, obj, key, spec, tip) {
        spec = spec || {};
        return { kind: "num", label: label, tip: tip, step: spec.step || 0.05, min: spec.min === undefined ? -1e9 : spec.min, max: spec.max === undefined ? 1e9 : spec.max,
            int: !!spec.int, blank: spec.blank, fmt: spec.fmt, start: spec.start, disabled: spec.disabled,
            get: function () { var o = obj(); return o && num(o[key]) ? o[key] : undefined; },
            eff: spec.eff || function () { return undefined; },
            set: function (v) { var o = obj(true); o[key] = v; },
            clear: spec.noClear ? null : function () { var o = obj(); if (o) delete o[key]; } };
    }
    function textRow(label, get, set, maxLen, tip) {
        return { kind: "text", label: label, tip: tip, maxLen: maxLen, get: get, set: set };
    }
    function colorRow(label, obj, key, tip, none) {
        return { kind: "color", label: label, tip: tip, none: none, maxLen: 7,
            get: function () { var o = obj(); return o ? o[key] : undefined; },
            set: function (v) { obj(true)[key] = v; },
            clear: function () { var o = obj(); if (o) delete o[key]; } };
    }
    function choiceRow(label, get, set, options, fmt, tip, disabled, extra) {
        var r = { kind: "choice", label: label, tip: tip, get: get, eff: get, set: set, options: typeof options === "function" ? options : function () { return options; }, fmt: fmt, disabled: disabled };
        for (var k in (extra || {})) r[k] = extra[k];
        return r;
    }
    function actionRow(label, button, run, tip, disabled) { return { kind: "action", label: label, button: button, run: run, tip: tip, disabled: disabled }; }
    function boolRow(label, get, set, tip, disabled) { return { kind: "bool", label: label, tip: tip, get: get, eff: get, set: set, disabled: disabled }; }
    function info(label, text) { return { kind: "info", label: label, get: function () { return text; } }; }
    function head(label) { return { kind: "head", label: label }; }

    function tabRows(tab, f, X, g) {
        var self = function () { return f; };
        var colors = function (make) { if (!f.c && make) f.c = {}; return f.c; };
        var mx = function (make) { if (!f.mx && make) f.mx = {}; return f.mx; };
        var e = function (k) { return function () { return X[k]; }; };
        var flag = function (label, k, def, tip) {
            return boolRow(label, function () { return f[k] === undefined ? def : !!f[k]; }, function (v) { if (v === def) delete f[k]; else f[k] = v ? 1 : 0; }, tip);
        };
        var mRow = function (label, i, tip) {
            return { kind: "num", label: label, tip: tip, step: 0.05, min: 0.01, max: 100,
                get: function () { return f.m ? f.m[i] : undefined; }, set: function (v) { if (!f.m) f.m = [1, 1, 1, 1]; f.m[i] = v; } };
        };
        var scaleRow = function (label, axis) {
            return { kind: "num", label: label, step: 0.05, min: 0.05, max: 10,
                get: function () { return f.scale === undefined ? undefined : typeof f.scale === "number" ? f.scale : f.scale[axis]; },
                eff: function () { return X.scale[axis]; },
                set: function (v) { var s = f.scale === undefined ? X.scale.slice() : typeof f.scale === "number" ? [f.scale, f.scale, f.scale] : f.scale; s[axis] = v; f.scale = s; },
                clear: function () { delete f.scale; } };
        };
        var key = g.id + "." + f.id;
        switch (tab) {
            case 0: return [
                head("Identity"),
                textRow("Display name", function () { return f.n || ""; }, function (v) { f.n = v.substring(0, 40) || f.id; }, 40, "The name shown in game"),
                textRow("Form id", function () { return f.id; }, function (v) {
                    v = v.toLowerCase();
                    if (!E.ID_RE.test(v)) { status("Ids use a-z, 0-9 and _", "#FF6060"); return; }
                    if (v !== f.id && g.forms.some(function (o) { return o.id === v; })) { status("That id is taken in this group", "#FF6060"); return; }
                    renameRefs(g.id + "." + f.id, g.id + "." + v);
                    f.id = v;
                }, 32, ["Internal id", "Renaming it loses players' mastery in this form"]),
                textRow("Description", function () { return f.desc || ""; }, function (v) { if (v) f.desc = v.substring(0, 200); else delete f.desc; }, 200, "Optional notes"),
                choiceRow("Model", function () { return f.model || ""; }, function (v) { if (v) f.model = v; else delete f.model; }, MODELS,
                    function (v) { return v || "(race body)"; }, ["Custom model", "DMZ model keys used by the default forms"]),
                choiceRow("Transform anim", function () { return f.anim || "transf.generic"; }, function (v) { if (v === "transf.generic") delete f.anim; else f.anim = v; }, ANIMS,
                    null, "Played while charging"),
                flag("Keep base head", "keepHead", false, ["keepBaseFormHeadBones", "Race head parts (ears, antennae, horns) stay"]),
                flag("Needs a tail", "tailOnly", false, "Saiyan Oozaru forms: skipped without a tail"),
                flag("Android overlay", "android", false, "Draws the android plating (android forms)"),
                choiceRow("SSJ4 fur", function () { return f.ssj4 || ""; }, function (v) { if (v) f.ssj4 = v; else delete f.ssj4; }, ["", "gt", "d", "final"],
                    function (v) { return v ? v.toUpperCase() : "none"; }, "SSJ4 body fur sheet and eyes"),
                info("Extra layers", f.layers ? f.layers.length + " overlay(s), kept as they are" : "none")
            ];
            case 1: return [
                head("Body"),
                colorRow("Body color 1", colors, "body1", "Primary body colour (empty: the player's)", "player's"),
                colorRow("Body color 2", colors, "body2", null, "player's"),
                colorRow("Body color 3", colors, "body3", null, "player's"),
                head("Hair & eyes"),
                choiceRow("Hair type", function () { return f.hair === undefined ? "" : f.hair; }, function (v) { f.hair = v; }, E.HAIR_TYPES,
                    function (v) { return HAIR_NAMES[v] || v; }, ["Hair style slot", "Picks the slot of the player's DMZ hair preset"]),
                colorRow("Hair color", colors, "hair", "Also forces strand colours", "player's"),
                colorRow("Eye 1 color", colors, "eye1", null, "player's"),
                colorRow("Eye 2 color", colors, "eye2", null, "player's"),
                colorRow("Sclera", self, "sclera", "Eye whites (dark forms)", "white"),
                head("Tint"),
                { kind: "color", label: "Tint color", none: "none", maxLen: 7, tip: "Full-body tint (Kaioken's mechanism)",
                    get: function () { return f.tint ? f.tint[0] : undefined; },
                    set: function (v) { if (!f.tint) f.tint = [v, 0.25]; else f.tint[0] = v; }, clear: function () { delete f.tint; } },
                { kind: "num", label: "Tint intensity", step: 0.05, min: 0, max: 1,
                    get: function () { return f.tint ? f.tint[1] : undefined; }, eff: function () { return 0; },
                    set: function (v) { if (!f.tint) f.tint = ["#FF0000", 0]; f.tint[1] = v; if (!v) delete f.tint; }, clear: function () { delete f.tint; } }
            ];
            case 2: return auraRows(f, g, self, flag);
            case 3: return [
                head("Multipliers"),
                mRow("STR x", 0, "Strength"), mRow("SKP x", 1, "Strike power"), mRow("DEF x", 2, "Resistance / defence"), mRow("PWR x", 3, "Ki power"),
                numRow("STM x", mx, "STM", { min: 0.01, max: 100, eff: function () { return 1; } }, "Stamina pool"),
                numRow("VIT x", mx, "VIT", { min: 0.01, max: 100, eff: function () { return 1; } }, "Health"),
                numRow("ENE x", mx, "ENE", { min: 0.01, max: 100, eff: function () { return 1; } }, "Ki pool"),
                numRow("Speed x", self, "spd", { min: 0.05, max: 10, eff: e("spd") }, "Movement speed"),
                numRow("Attack speed x", self, "atk", { min: 0.05, max: 10, eff: e("atk") }, "Swing speed (min 0.25 in game)"),
                head("Model scale"),
                scaleRow("Scale X", 0), scaleRow("Scale Y (height)", 1), scaleRow("Scale Z", 2)
            ];
            case 4: return [
                head("Drains (per second)"),
                numRow("Stamina drain x", self, "stmM", { min: 0, max: 20, eff: e("stmM") }, "staminaDrainMultiplier"),
                numRow("Ki drain", self, "ki", { step: 0.01, min: -5, max: 5, eff: e("ki") }, ["energyDrain", "Negative = regenerates ki"]),
                numRow("Stamina drain", self, "sd", { step: 0.01, min: -5, max: 5, eff: e("sd") }, "staminaDrain"),
                numRow("Health drain", self, "hd", { step: 0.01, min: -5, max: 5, eff: e("hd") }, "healthDrain"),
                info("How it works", "x80 baseline, scaled by power release; mastery cuts it to the max cost")
            ];
            case 5: return [
                head("Mastery"),
                numRow("Max mastery", self, "maxMastery", { step: 5, min: 0, max: 1000, eff: e("maxMastery") }, "0 = no mastery (no stat growth)"),
                numRow("Per hit", self, "perHit", { step: 0.005, min: 0, max: 10, eff: function () { return FD.D.perHit; } }, "Mastery per hit dealt or taken"),
                numRow("Passive / 6 s", self, "passive", { step: 0.001, min: 0, max: 10, eff: function () { return FD.D.passive; } }, "While transformed"),
                numRow("Max stats x", self, "mStats", { step: 0.05, min: 1, max: 10, eff: function () { return X.maxStats; } }, "Stat multiplier bonus at full mastery"),
                numRow("Max cost x", self, "mCost", { step: 0.05, min: 0.01, max: 5, eff: function () { return X.maxCost; } }, "Drain factor at full mastery"),
                choiceRow("Requisite", function () { return f.noReq ? "(none)" : f.req || "(auto)"; }, function (v) {
                    delete f.req; delete f.noReq;
                    if (v === "(none)") f.noReq = 1; else if (v !== "(auto)") f.req = v;
                }, function () { return ["(auto)", "(none)"].concat(raceTokens(key)); }, function (v) {
                    return v === "(auto)" ? "auto: " + (X.req || "none") : v;
                }, ["formRequisite", "Auto = the form before it in the ladder"]),
                numRow("Unlock at mastery", self, "unlockOn", { step: 5, min: 0, max: 1000, eff: e("unlockOn") }, "Mastery of the requisite needed"),
                numRow("Instant at mastery", self, "instantOn", { step: 5, min: 0, max: 1000, eff: function () { return FD.D.instantOn; } }, "Double-tap transform"),
                boolRow("Always available", function () { return X.free <= 0; }, function (v) { f.free = v ? 0 : FD.D.freeOn; }, ["Selectable from 0 mastery", "Off: needs the mastery below"]),
                numRow("Free at mastery", self, "free", { step: 5, min: 0, max: 1000, eff: e("free") }, "allowFreeTransformOnMastery")
            ];
            case 6: return [
                head("Stacking"),
                flag("Stackable", "stackable", true, "Can be combined with a stack form (Kaioken)"),
                numRow("Stack at mastery", self, "stackOn", { step: 5, min: 0, max: 1000, eff: e("stackOn") }, "Mastery needed to stack"),
                numRow("Stack drain x", self, "stackDrain", { step: 0.1, min: 0, max: 20, eff: e("stackDrain") }, "Drain multiplier while stacked"),
                flag("No Ultimate", "ult", false, ["Incompatible with Ultimate", "incompatibleWith ultimate.ultimate"]),
                choiceRow("Share mastery with", function () { return f.share && f.share[0] ? f.share[0][0] : "(none)"; }, function (v) {
                    var rest = f.share ? f.share.slice(1) : [];
                    if (v === "(none)") { if (rest.length) f.share = rest; else delete f.share; }
                    else f.share = [[v, f.share && f.share[0] ? f.share[0][1] : 0.5]].concat(rest);
                }, function () { return ["(none)"].concat(raceTokens(key)); }, null, "Gains go to this form too"),
                { kind: "num", label: "Share x", step: 0.05, min: 0, max: 5, tip: "Fraction shared",
                    get: function () { return f.share && f.share[0] ? f.share[0][1] : undefined; }, eff: function () { return 0; },
                    set: function (v) { if (f.share && f.share[0]) f.share[0][1] = v; else status("Pick a form to share with first", "#FFB040"); } },
                info("More shares", f.share && f.share.length > 1 ? (f.share.length - 1) + " more, kept" : "none")
            ];
            case 7: return [
                head("Buying (skills screen)"),
                numRow("Skill level", self, "lvl", { step: 1, int: true, min: 0, max: 99, noClear: true }, ["unlockOnSkillLevel", "Level of the " + (TYPE_NAMES[g.type] || g.type) + " forms skill"]),
                numRow("TP cost", self, "cost", { step: 1000, int: true, min: -1, max: 1000000000, eff: function () { return levelCost(g, f); },
                    fmt: function (v) { return v < 0 ? "Priceless" : String(Math.round(v)); } }, ["TP to buy that skill level", "-1 = Priceless (masters / quests only)"]),
                textRow("Saga quest", function () { return f.saga || ""; }, function (v) {
                    if (v && !/^[a-z0-9_]+:\d+$/.test(v)) { status("Saga quests look like frieza_saga:10", "#FF6060"); return; }
                    f.saga = v;
                }, 64, ["sagaRequisite", "Quest needed before buying the level", sagaLabel(f.saga)]),
                head("Using the form"),
                numRow("Min char level", self, "plvl", { step: 1, int: true, min: 0, max: 100000, blank: "none" }, "Character level to transform"),
                numRow("Alignment min", self, "alignMin", { step: 5, int: true, min: 0, max: 100, blank: "none", start: 50 }, "0 evil .. 100 good"),
                numRow("Alignment max", self, "alignMax", { step: 5, int: true, min: 0, max: 100, blank: "none", start: 50 }, "Also checked while transformed")
            ];
            case 9: return overlayRows(f);
            case 10: return modelRows(f);
            default: return [
                head(TABS[tab]),
                info("Not available", "The engine can't draw DMZ's outline shader")
            ];
        }
    }
    // ---- aura, overlays and model pickers ----
    var DMZ_AURAS2D = ["kakarot", "saiyan", "namekian", "frost", "majin", "bioandroid", "demon", "god", "godki", "godform", "wgodform", "ui", "ue"];
    var AURA_DIR = "dmzpack:textures/entity/races/aura/";
    function aura2dTex(v) { v = v || "kakarot"; return v.indexOf(":") > 0 ? v : AURA_DIR + v + "_aura.png"; }
    var LISTS = {};
    function packList(folder, suffix) {          // pack files, listed once per editor session
        var k = folder + "|" + suffix;
        if (!LISTS[k]) {
            var l = null;
            try { l = RPG.resourceList(folder, suffix); } catch (e) { l = []; }
            if (l === null || l === undefined) return [];          // still being listed: shown on a later frame
            var out = [];
            for (var i = 0; i < l.length; i++) out.push(String(l[i]));
            LISTS[k] = out;
        }
        return LISTS[k];
    }
    function auraSheets() {
        var out = DMZ_AURAS2D.slice();
        packList("textures/auras", "_aura.png").forEach(function (t) { out.push(t); });
        packList("textures/forms", "_aura.png").forEach(function (t) { out.push(t); });
        return out;
    }
    function dmzAuraDefaults(f, g) {
        var d = (typeof DMZ_AURA_DATA !== "undefined" ? DMZ_AURA_DATA.find(S.race, g.id, f.id) : null) || {};
        var st = {}, k, D = typeof DMZ_AURA_DATA !== "undefined" ? DMZ_AURA_DATA.DEFAULT_STYLE : {};
        for (k in D) st[k] = D[k];
        for (k in (d.s || {})) st[k] = d.s[k];
        return { t3: d.t3 || "userPreference", l: d.l || 0, s: st, x: d.x || null };
    }
    var T3_NAMES = { userPreference: "Player's choice", smooth: "Smooth", sparking: "Sparking", god: "God" };
    function auraRows(f, g, self, flag) {
        var def = dmzAuraDefaults(f, g);
        var a3 = function (make) { if (!f.aura3d && make) f.aura3d = {}; return f.aura3d; };
        var st = function (make) { var a = a3(make); if (!a) return null; if (!a.s && make) a.s = {}; return a.s; };
        var xa = function (make) { var a = a3(make); if (!a) return null; if (!a.x && make) a.x = { l: 1 }; return a.x; };
        var sNum = function (label, k, spec, tip) {
            spec = spec || {};
            spec.eff = function () { return def.s[k]; };
            return numRow(label, st, k, spec, tip);
        };
        var sizeRow = function (label, axis) {
            return { kind: "num", label: label, step: 0.02, min: 0.05, max: 5,
                get: function () { var s = st(); return s && s.size ? s.size[axis] : undefined; }, eff: function () { return def.s.size[axis]; },
                set: function (v) { var s = st(true); if (!s.size) s.size = def.s.size.slice(); s.size[axis] = v; },
                clear: function () { var s = st(); if (s) delete s.size; } };
        };
        var sColor = function (label, k, tip) { return colorRow(label, st, k, tip, def.s[k] || "from the aura colour"); };
        return [
            head("2D aura (DMZ sheets)"),
            choiceRow("Aura sheet", function () { return f.aura2d || "kakarot"; }, function (v) { if (!v || v === "kakarot") delete f.aura2d; else f.aura2d = v; },
                auraSheets, function (v) { return v.indexOf(":") > 0 ? v.substring(v.lastIndexOf("/") + 1).replace("_aura.png", "") + " (" + v.split(":")[0] + ")" : U.humanize ? U.humanize(v) : v; },
                ["DMZ's 2D aura sheets (and *_aura.png from packs)", "4 frames side by side; *_cross.png next to it is the ground wave"], false,
                { icon: function (v) { return aura2dTex(v) + "@0,0,0.25,1"; }, custom: true }),
            colorRow("Aura color", self, "aura", "Empty: the player's aura colour", "player's"),
            numRow("Aura size x", self, "auraScale", { step: 0.05, min: 0.1, max: 5, eff: function () { return 1; } }, "Multiplies the aura size"),
            flag("Big aura", "big", false, "DMZ's larger aura (SSJ2 / SSJ3 / Ultra)"),
            head("3D aura (DMZ shaders)"),
            choiceRow("3D type", function () { var a = a3(); return a && a.t3 ? a.t3 : def.t3; }, function (v) { var a = a3(true); if (v === def.t3) delete a.t3; else a.t3 = v; },
                E.AURA3D_TYPES, function (v) { return T3_NAMES[v] || v; }, ["auraType3D", "Player's choice follows the 3D type in the config menu"]),
            numRow("Layer", a3, "l", { step: 1, int: true, min: 0, max: 6, eff: function () { return def.l; } }, ["auraLayer", "Higher layers draw bigger, over lower ones (stacks use 1)"]),
            sizeRow("Size x", 0), sizeRow("Size y", 1), sizeRow("Size z", 2),
            sNum("Flame peaks", "flamePeaks", { step: 1, int: true, min: 1, max: 64 }, "Flame tongues around the body"),
            sNum("Wave frequency", "waveFrequency", { step: 0.1, min: 0, max: 20 }, "Bands climbing the shell"),
            sNum("Wave speed", "waveSpeed", { step: 0.1, min: -50, max: 50 }, "How fast they climb"),
            sNum("Wave amplitude", "waveAmplitude", { step: 0.02, min: 0, max: 5 }, "How far the tongues reach"),
            sNum("Noise detail", "noiseDetail", { step: 0.02, min: 0, max: 5 }, "Turbulence"),
            sNum("Upward bias", "upwardBias", { step: 0.02, min: 0, max: 1 }, "0 out, 1 straight up"),
            sNum("Core alpha", "coreAlpha", { step: 0.01, min: 0, max: 1 }, "Opacity where the shell faces you"),
            sNum("Rim alpha", "rimAlpha", { step: 0.05, min: 0, max: 1 }, "Opacity at the edges"),
            sNum("Rim power", "rimPower", { step: 0.1, min: 0.1, max: 20 }, "How tight the glowing edge is"),
            sNum("Rim threshold", "rimThreshold", { step: 0.01, min: 0.001, max: 5 }, "Edge width"),
            sNum("Bloom", "bloomIntensity", { step: 0.05, min: 0, max: 10 }, "Glow around it"),
            sNum("Spikes (sparking)", "spikeDensity", { step: 1, int: true, min: 4, max: 32 }, "Sparking: spike columns"),
            sNum("Spike bursts", "spikeBurstRate", { step: 0.1, min: 0, max: 50 }, "Sparking: bursts a second"),
            sNum("Spike rarity", "spikeRarity", { step: 0.1, min: 0.1, max: 50 }, "Sparking: how rare long spikes are"),
            sNum("Band start", "bandStart", { step: 0.02, min: 0.05, max: 0.95 }, "Sparking: where the spikes start"),
            sColor("Core color", "coreColor", "Inside (empty: the aura colour, lightened)"),
            sColor("Rim color", "rimColor", "Edges (empty: the aura colour)"),
            sColor("Noise color", "noiseColor", "Shimmer over the shell (empty: none)"),
            sColor("Second border", "secondBorderColor", "Sparking: an outer border (empty: none)"),
            head("Extra aura layer"),
            numRow("Extra layer", function (make) { return xa(make); }, "l", { step: 1, int: true, min: -1, max: 6, eff: function () { return def.x ? def.x.l : -1; },
                fmt: function (v) { return v < 0 ? "off" : String(v); } }, ["extraAuraLayer", "A second aura on its own layer (-1: none)"]),
            colorRow("Extra color", xa, "c", "extraAuraColor", "white"),
            choiceRow("Extra 3D type", function () { var x = xa(); return x && x.t3 ? x.t3 : "userPreference"; }, function (v) { var x = xa(true); if (v === "userPreference") delete x.t3; else x.t3 = v; },
                E.AURA3D_TYPES, function (v) { return T3_NAMES[v] || v; }, "extraAuraType3D"),
            head("Lightning"),
            boolRow("Has lightnings", function () { return !!f.bolt; }, function (v) { if (v) f.bolt = f.bolt || "#A1FFF9"; else delete f.bolt; }, "Electric sparks around the body"),
            colorRow("Lightning color", self, "bolt", "Turning lightning on sets it", "off")
        ];
    }
    var OVERLAY_COLORS = ["fBody1", "fBody2", "fBody3", "fHair", "fEye1", "fEye2"];
    var OVERLAY_NAMES = { fBody1: "Body 1", fBody2: "Body 2", fBody3: "Body 3", fHair: "Hair", fEye1: "Eye 1", fEye2: "Eye 2" };
    function overlaySheets() {
        var out = [];
        packList("textures/entity/races", ".png").forEach(function (t) {
            if (t.indexOf("dmzpack:textures/entity/races/") === 0 && t.indexOf("/aura/") < 0) out.push(t.substring("dmzpack:textures/entity/races/".length).replace(/\.png$/, ""));
        });
        packList("textures/overlays", ".png").forEach(function (t) { out.push(t); });
        packList("textures/forms", ".png").forEach(function (t) { out.push(t); });
        return out;
    }
    function overlayIcon(v) { return v.indexOf(":") > 0 ? v : "dmzpack:textures/entity/races/" + v + ".png"; }
    function overlayRows(f) {
        var rows = [head("Overlays (body, eyes, hair...)"), info("How", "DMZ race sheets or pack pictures drawn over the body")];
        var list = f.layers || [];
        list.forEach(function (l, i) {
            rows.push(head("Overlay " + (i + 1)));
            rows.push(choiceRow("Picture", function () { return l[0]; }, function (v) { if (v) l[0] = v; }, overlaySheets, function (v) { return v; },
                ["A 64x64 skin-layout sheet", "DMZ's own (humansaiyan/..., namekian/...), or any pack's textures/overlays/*.png"], false,
                { icon: overlayIcon, custom: true }));
            rows.push(choiceRow("Color", function () { return E.HEX_RE.test(l[1]) ? "custom" : l[1]; }, function (v) { if (v === "custom") l[1] = "#FFFFFF"; else l[1] = v; },
                OVERLAY_COLORS.concat(["custom"]), function (v) { return v === "custom" ? "Fixed colour" : OVERLAY_NAMES[v] || v; }, "A form colour, or a fixed one"));
            if (E.HEX_RE.test(l[1])) rows.push({ kind: "color", label: "Fixed colour", maxLen: 7, get: function () { return l[1]; }, set: function (v) { l[1] = v; } });
            rows.push(textRow("Only bones", function () { return (l[2] || []).join(","); }, function (v) {
                var b = v.split(",").map(function (x) { return x.trim(); }).filter(function (x) { return E.BONE_RE.test(x); });
                if (b.length) l[2] = b; else l.length = 2;
            }, 120, ["Comma-separated bones (head, body, right_arm...)", "Empty: everywhere the sheet paints"]));
            rows.push(actionRow("", "Remove overlay " + (i + 1), function () { list.splice(i, 1); if (!list.length) delete f.layers; }));
        });
        if (list.length < 6) rows.push(actionRow("Add", "+ Overlay", function () { if (!f.layers) f.layers = []; f.layers.push(["humansaiyan/faces/ssj4_eyes_0", "fHair"]); }));
        return rows;
    }
    function modelRows(f) {
        var geo = function (make) { if (!f.geo && make) f.geo = { model: "", texture: "", mode: "body" }; return f.geo; };
        var models = function () { return [""].concat(packList("geo/forms", ".geo.json"), packList("geo/entity", ".geo.json")); };
        var short = function (v) { return v ? v.substring(v.lastIndexOf("/") + 1) + "  (" + v.split(":")[0] + ")" : "(none: the form's own body)"; };
        var textures = function () {
            var g = f.geo, all = packList("textures/forms", ".png").concat(packList("textures/entity", ".png")), stem = g && g.model ? g.model.substring(g.model.lastIndexOf("/") + 1).replace(".geo.json", "") : "";
            if (!stem) return all.filter(function (t) { return t.indexOf("/forms/") >= 0; }).concat(all.filter(function (t) { return t.indexOf("/forms/") < 0; })).slice(0, 1000);
            var near = all.filter(function (t) { return t.indexOf(stem) >= 0; });
            return near.concat(all.filter(function (t) { return t.indexOf(stem) < 0; })).slice(0, 1000);
        };
        var anims = function () { return [""].concat(packList("animations/forms", ".json"), packList("animations/entity", ".json")); };
        var g = f.geo;
        var rows = [head("GeckoLib model"),
            info("Add your own", "geo/, textures/ and animations/ in ragnarok_rpg/resources/assets/<ns>/ or an art pack"),
            choiceRow("Model", function () { return g ? g.model : ""; }, function (v) { if (!v) { delete f.geo; return; } var x = geo(true); x.model = v;
                    if (!x.texture) { var t = textures(); if (t.length) x.texture = t[0]; } },
                models, short, ["A Blockbench GeckoLib .geo.json", "Body: replaces the player's model in this form; Overlay: drawn over it"], false, { custom: true })];
        if (g) {
            rows.push(choiceRow("Texture", function () { return g.texture; }, function (v) { g.texture = v; }, textures, short, "The model's skin (png)", false,
                { icon: function (v) { return v; }, custom: true }));
            rows.push(choiceRow("Animations", function () { return g.anim || ""; }, function (v) { if (v) g.anim = v; else delete g.anim; }, anims,
                function (v) { return v ? short(v) : "(DMZ's player animations)"; }, ["Its own .animation.json", "Body models play idle / walk / run / fly / jump / fall / swim / sneak"], false, { custom: true }));
            rows.push(choiceRow("Use as", function () { return g.mode || "body"; }, function (v) { g.mode = v; }, ["body", "overlay"],
                function (v) { return v === "overlay" ? "Overlay on the form's body" : "The whole body"; }, "Body replaces the model; overlay adds to it"));
            if (g.mode === "overlay") {
                rows.push(textRow("Attach to bone", function () { return g.attach || ""; }, function (v) { if (E.BONE_RE.test(v)) g.attach = v; else delete g.attach; }, 40,
                    ["Draw the whole model in this bone's frame", "Default: body"]));
                rows.push(textRow("Follow bones", function () { return (g.bones || []).join(","); }, function (v) {
                    var b = v.split(",").map(function (x) { return x.trim(); }).filter(function (x) { return E.BONE_RE.test(x); });
                    if (b.length) g.bones = b; else delete g.bones;
                }, 200, ["Or: its bones named like the player's (head, body, right_arm...) copy their pose", "Comma-separated; overrides Attach"]));
                rows.push({ kind: "color", label: "Tint", maxLen: 7, get: function () { return g.color; }, set: function (v) { g.color = v; }, clear: function () { delete g.color; } });
                rows.push(boolRow("Glowing", function () { return !!g.glow; }, function (v) { if (v) g.glow = 1; else delete g.glow; }, "Full-bright, see-through (energy)"));
            }
            rows.push(numRow("Model scale x", geo, "scale", { step: 0.05, min: 0.05, max: 20, eff: function () { return 1; } }, "On top of the form's scale"));
        }
        return rows;
    }
    function levelCost(g, f) {
        if (typeof DMZ_SKILLS_DATA === "undefined") return undefined;
        var list = ((DMZ_SKILLS_DATA.FORM_COSTS[S.race] || {})[FD.skillFor(g.type)] || []);
        return f.lvl > 0 && f.lvl <= list.length ? list[f.lvl - 1] : undefined;
    }
    function sagaLabel(k) {
        if (!k) return "none";
        try { if (typeof DMZ_QUEST_NAMES !== "undefined") return DMZ_QUEST_NAMES.label(k); } catch (e) { }
        return k;
    }

    // =================================================================================
    //  Live preview (FormPreview): the player in the edited form, turning
    // =================================================================================
    function modelFile(race, f, bodyType, bodyModel) {       // DMZ_LOOK.modelFile (scripts/30_forms.js)
        var t = String(bodyType || ""), v = t.indexOf("female") === 0 ? "female" : t.indexOf("slim") >= 0 ? "slim" : "male", fem = v === "female";
        var base = { human: bodyModel || "human", saiyan: bodyModel || "human", glind: bodyModel || "human", namekian: "human",
            frostdemon: "frostdemon", bioandroid: f ? "bioandroid_perfect" : "bioandroid", majin: bodyModel || "majin" }[race] || "human";
        var key = f ? f.model || "" : "";
        if (!key) return base;
        function three(m, s, w) { return fem ? w : v === "slim" ? s : m; }
        switch (key) {
            case "buffed": case "ssj4gt": return three("hbuffed", "hbuffed_slim", "hbuffed_fem");
            case "buffedg3": case "ssj4d": return three("hbuffedg3", "hbuffed_slimg3", "hbuffed_femg3");
            case "4arms": return three("h4arms", "h4armsslim", "h4armsfem");
            case "namekian_buffed": case "namekian_orange": return "hbuffed";
            case "majin_kid": case "majin_evil": return fem ? "majin_slim" : "human_slim";
            case "majin_super": return fem ? "majin_slim" : "human";
            case "majin_ultra": return fem ? "hbuffed_fem" : "hbuffed";
            case "frostdemon_final": case "frostdemon_mecha": return "frostdemon";
            case "trascended": return fem ? "trascended_fem" : "trascended";
            case "finalbase": return base;
            default: return key;
        }
    }
    function lookSig(f) {
        return JSON.stringify([f.model || "", f.hair || "", f.ssj4 || "", !!f.android, !!f.shiyoken, f.layers || null, !!f.keepHead, !!f.xeno,
            !!f.noStinger, !!f.furHair, f.sclera || "", f.scale, f.c && f.c.hair ? 1 : 0, f.geo || null]);
    }
    function previewColors(race, X) {
        var mine = String(RPG.player.race || "") === OUR[race], def = (typeof DBR_RACE_DEFAULTS !== "undefined" ? DBR_RACE_DEFAULTS[OUR[race]] : null) || {};
        function own(k) { var c = mine ? String(RPG.player.color(k, "") || "") : ""; return c || def[k] || "#FFFFFF"; }
        var colors = {};
        PASS_KEYS.forEach(function (k) { var c = own(k); if (c) colors[k] = c; });
        var eyes = own("eyes");
        var base = { fBody1: own("body1"), fBody2: own("body2"), fBody3: own("body3"), fHair: own("hair"), fEye1: eyes, fEye2: race === "bioandroid" ? "#FFFFFF" : eyes };
        Object.keys(C_MAP).forEach(function (k) { colors[k] = (X.c && X.c[C_MAP[k]]) || base[k]; });
        if (X.tint && X.tint[1] > 0) ["fBody1", "fBody2", "fBody3", "fHair"].forEach(function (k) { colors[k] = FD.tint(colors[k], X.tint[0], X.tint[1]); });
        var bodyType = colors.bodyType || "", t = String(bodyType), v = t.indexOf("female") === 0 ? "female" : t.indexOf("slim") >= 0 ? "slim" : "male";
        colors.dmzModel = modelFile(race, X, bodyType, colors.bodyModel || "");
        colors.dmzSlim = v === "male" ? "" : "slim";
        colors.dmzGender = v === "female" ? "female" : "male";
        colors.dmzAura = X.aura || own("aura");
        return colors;
    }
    function preview(p) {
        if (!p) {
            if (S.pvKey !== "hidden") {
                ["pv_bg", "pv_aura", "pv_model"].forEach(function (id) { RPG.screen.update(id, { visible: false }); });
                S.pvKey = "hidden";
            }
            return;
        }
        var race = S.race, X = p.X, g = p.g;
        var applied = FD.form(race, g.id, p.f.id);
        var realId = "dmzf_" + race + "_" + (g.id === "oozaru" ? "o" : g.id) + "_" + p.f.id;
        var useReal = !!(applied && S.effects[realId] && lookSig(applied) === lookSig(X));
        var slot = X.hair === "empty" || X.model === "oozaru" ? "empty" : X.hair || "base";
        var proxy = "dmzp_" + race + "_" + (HAIR_RACES[race] ? slot : "base");
        var id = useReal ? realId : S.effects[proxy] ? proxy : "dmzb_" + race;
        S.pvProxy = !useReal;
        var sy = Number(X.scale[1]) || FD.D.scale, shrink = sy > 1.05 ? 1.05 / sy : 1;
        var size = Math.round(62 * shrink * (useReal ? 1 : sy / FD.D.scale));
        var colors = previewColors(race, X);
        var bx = p.x + 10, by = p.y + 14, bw = 121, bh = 172;
        S.pvRect = { x: p.x, y: p.y, w: 141, h: 190 };
        // spin
        if (S.spin && !S.drag) S.yaw = (S.yaw + p.dt * 45) % 360;
        var auraSize = Math.round(Math.min(120, 70 * (X.auraScale || 1) * (X.big ? 1.2 : 1) * Math.min(1.6, size / 62 + 0.3)));
        var k = [p.x, p.y, id, JSON.stringify(colors), size, S.aura, auraSize, X.aura2d || ""].join("|");
        if (k !== S.pvKey) {
            S.pvKey = k;
            RPG.screen.update("pv_bg", { visible: true, x: p.x, y: p.y });
            RPG.screen.update("pv_model", { visible: true, x: bx, y: by, w: bw, h: bh, size: size, look: { key: "effect:" + id, colors: colors }, rotation: S.yaw });
            RPG.screen.update("pv_aura", { visible: S.aura, x: bx + bw / 2 - auraSize / 2, y: by + bh - auraSize * 1.05, w: auraSize, h: auraSize, tint: colors.dmzAura,
                texture: aura2dTex(X.aura2d) });
        } else RPG.screen.update("pv_model", { rotation: S.yaw });
        // the aura's 4 frames at 10 fps
        var now = RPG.nowMs();
        if (S.aura && now - S.auraAt > 100) { S.auraAt = now; S.auraFrame = (S.auraFrame + 1) % 4; RPG.screen.update("pv_aura", { u: S.auraFrame * 1024 }); }
    }

    // =================================================================================
    //  Input
    // =================================================================================
    function mouse(x, y, button, action) {
        if (!S) return;
        if (action === "up") { S.drag = null; return; }
        if (action === "drag") {
            if (S.drag) { S.yaw = (S.drag.yaw + (x - S.drag.x) * 1.6) % 360; RPG.screen.update("pv_model", { rotation: S.yaw }); return false; }
            return;
        }
        if (action !== "down" || button !== 0) return;
        if (S.input && inside(x, y, S.input.rect)) return;               // typing in the box
        if (S.view === "form" && S.pvRect && inside(x, y, S.pvRect)) { endInput(true); S.drag = { x: x, yaw: S.yaw }; S.spin = false; return false; }
        for (var i = S.hits.length - 1; i >= 0; i--) {
            var h = S.hits[i];
            if (h.fn && inside(x, y, h)) {
                if (S.input) endInput(true);
                try { RPG.sound("dmzpack:pip_menu", 0.6, 1); } catch (e) { }
                h.fn();
                return false;
            }
        }
        if (S.input) endInput(true);
    }
    function scroll(x, y, d) {
        if (!S) return;
        if (x >= L.x && x <= L.x + L.w + 6 && y >= L.listTop && y <= L.listTop + L.listH) {
            endInput(true);
            S.scroll = clamp(S.scroll - (d > 0 ? L.rowH * 2 : -L.rowH * 2), 0, Math.max(0, L.total - L.listH));
        }
    }
    function key(name, action) {
        if (!S || action !== "down") return;
        if (name === "key.keyboard.enter" || name === "key.keyboard.keypad.enter") { if (S.input) { endInput(true); return false; } return; }
        if (name === "key.keyboard.escape") {
            if (S.input) { endInput(false); return false; }
            if (S.view === "form") { go("group"); return false; }
            if (S.view === "group") { go("groups"); return false; }
            if (S.view === "groups") { go("races"); return false; }
        }
    }

    return { open: function () { RPG.net.send("dbr_fe", { op: "open" }); }, applySync: applySync, state: function () { return S; } };
})();
