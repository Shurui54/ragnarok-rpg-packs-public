// =====================================================================================
//  DMZ CharacterStatsScreen (V): name plate, INFORMATION, STATS with +/multiplier and TPC,
//  STATISTICS (derived values) and the bottom navigation row, laid out like DragonMine Z.
//  Values come from the same formulas the server uses (shared/02_dmz_formulas.js).
//  DMZ options: "Hexagon Stats Display" swaps STATISTICS for the six-stat hexagon (the switch
//  under the right panel flips it too), "Menu Panel Scale" sizes it (DMZ_OPTS.menuRef), and the
//  first opening runs DMZ's stats tutorial (56_dmz_tutorial.js).
// =====================================================================================
var STATS_SCREEN = (function () {
    var D = DMZ_DATA, F = DMZ_F;
    // DMZ_UI comes from 48_dmz_ui.js, which loads after this file: look it up when used, not now
    var U = { tr: function () { return DMZ_UI.tr.apply(null, arguments); }, tooltip: function () { return DMZ_UI.tooltip.apply(null, arguments); } };
    var FONT = "dmzpack:smooth";
    var MENU_BIG = "dmzpack:textures/gui/menu/menubig.png", MENU_SMALL = "dmzpack:textures/gui/menu/menusmall.png";
    var NAV = "dmzpack:textures/gui/buttons/menubuttons.png", BUTTONS = "dmzpack:textures/gui/buttons/characterbuttons.png";
    var MULTS = [1, 10, 100, 1000];
    var st = { mult: 0 };
    var T = function (k) { return RPG.translate(k); };

    function view() {
        var p = RPG.player, mult = RPG.getVar("dmz_mult", null) || {};
        return { stat: function (k) { return p.stat(D.STAT_IDS[k]); }, cls: p.playerClass || "warrior",
            release: Number(RPG.getVar("dmz_release", 0)) || 0, mult: function (k) { return typeof mult[k] === "number" ? mult[k] : 1; },
            armor: 0, toughness: 0, race: D.DMZ[p.race] || p.race, capMult: 1 + prestige().cap / 100 };
    }
    /** the prestige bonuses the server keeps in a player var (scripts/93_dbr_prestige.js) */
    function prestige() { var pv = RPG.getVar("dbr_prestige_view", null); return { tp: pv && pv.on ? Number(pv.tp) || 0 : 0, cap: pv && pv.on ? Number(pv.cap) || 0 : 0 }; }
    function bordered(ctx, t, x, y, color, align) { ctx.textStyled(t, x, y, 1, color, 1, align === undefined ? 0.5 : align, FONT, "#000000"); }
    function plain(ctx, t, x, y, color, align) { ctx.textStyled(t, x, y, 1, color, 1, align || 0, FONT, null); }

    function open() {
        var els = [
            { id: "lpanel", group: "left", type: "image", anchor: "left", x: 12, y: -105, w: 141, h: 213, texture: MENU_BIG, texW: 256, texH: 256, u: 0, v: 0, uw: 141, vh: 213 },
            { id: "lribbon", group: "left", type: "image", anchor: "left", x: 29, y: -95, w: 107, h: 21, texture: MENU_BIG, texW: 256, texH: 256, u: 142, v: 22, uw: 107, vh: 21 },
            { id: "lheader", group: "left", type: "image", anchor: "left", x: 43, y: -28, w: 79, h: 21, texture: MENU_BIG, texW: 256, texH: 256, u: 142, v: 0, uw: 79, vh: 21 },
            { id: "rpanel", group: "right", type: "image", anchor: "right", x: -158, y: -105, w: 141, h: 213, texture: MENU_BIG, texW: 256, texH: 256, u: 0, v: 0, uw: 141, vh: 213 },
            { id: "rribbon", group: "right", type: "image", anchor: "right", x: -141, y: -95, w: 107, h: 21, texture: MENU_BIG, texW: 256, texH: 256, u: 142, v: 22, uw: 107, vh: 21 },
            { id: "top", group: "top", type: "image", anchor: "top", x: -70, y: 8, w: 145, h: 58, texture: MENU_SMALL, texW: 256, texH: 256, u: 0, v: 95, uw: 145, vh: 58 },
            { id: "model", group: "center", type: "entity", anchor: "center", x: -35, y: -30, w: 80, h: 100, rotation: 180, followMouse: false, size: 75 }
        ];
        // "+" buttons (only when the stat can be raised) and the multiplier
        D.STATS.forEach(function (s, i) {
            els.push({ id: "plus_" + s, group: "left", type: "button", anchor: "left", x: 27, y: -4 + 12 * i, w: 10, h: 10, texture: BUTTONS, texW: 256, texH: 256,
                u: 0, v: 0, uw: 10, vh: 10, hoverU: 0, hoverV: 10, onClick: function () { RPG.net.send("dmz_buy", { stat: s, n: MULTS[st.mult] }); } });
        });
        els.push({ id: "mult", group: "left", type: "button", anchor: "left", x: 27, y: 71, w: 10, h: 10, texture: BUTTONS, texW: 256, texH: 256, u: 0, v: 0, uw: 10, vh: 10, hoverU: 0, hoverV: 10,
            onClick: function () { st.mult = (st.mult + 1) % MULTS.length; RPG.sound("dmzpack:pip_menu", 1, 1); } });
        // navigation row (BaseMenuScreen): party, stats, skills, quests, minigames, config
        var nav = [[-110, 120, "party"], [-70, 0, "stats"], [-30, 20, "skills"], [10, 60, "quests"], [50, 140, "minigames"], [90, 100, "config"]];
        nav.forEach(function (n) {
            els.push({ id: "nav_" + n[2], type: "button", anchor: "bottom", x: n[0], y: -30, w: 20, h: 20, texture: NAV, texW: 256, texH: 256,
                u: n[1], v: 0, uw: 20, vh: 20, hoverU: n[1], hoverV: 20, tooltip: n[2].charAt(0).toUpperCase() + n[2].slice(1),
                onClick: function () { navigate(n[2]); } });
        });
        // initViewSwitchButton: STATISTICS list <-> hexagon (characterbuttons' switch, 122,0 on / 122,10 off)
        els.push(switchEl());
        RPG.screen.open(DMZ_MENU_FX.wrap({ id: "dmz_stats", referenceHeight: DMZ_OPTS.menuRef(), elements: els, onRender: render,
            onMouse: function (x, y, b, a) { if (DMZ_TUTORIAL.active("dmz_stats")) return DMZ_TUTORIAL.mouse(x, y, b, a); },
            onKey: function (k, a) { if (DMZ_TUTORIAL.active("dmz_stats")) return DMZ_TUTORIAL.key(k, a); },
            onClose: function () { DMZ_TUTORIAL.closed("dmz_stats"); } }));
        DMZ_TUTORIAL.request("dmz_stats", "stats_menu", tutorialSteps());
    }
    function switchEl() {
        var on = DMZ_OPTS.hexagon();
        return { id: "view_switch", group: "right", type: "button", anchor: "right", x: -45, y: 90, w: 20, h: 10, texture: BUTTONS, texW: 256, texH: 256,
            u: 122, v: on ? 0 : 10, uw: 20, vh: 10, hoverU: 122, hoverV: on ? 0 : 10, tooltip: U.tr("gui.dragonminez.config.hexagonStatsDisplay"),
            onClick: function () {
                var now = !DMZ_OPTS.hexagon();
                DMZ_OPTS.set(DMZ_OPTS.KEYS.hexagonStatsDisplay, now);
                RPG.sound(now ? "dmzpack:switch_off" : "dmzpack:switch_on", 1, 1);
                RPG.screen.update("view_switch", { v: now ? 0 : 10, hoverV: now ? 0 : 10 });
            } };
    }

    // ---- CharacterStatsScreen.tutorialSteps (rectangles in this screen's layout) ----
    function tutorialSteps() {
        var pre = "gui.dragonminez.tutorial.stats.";
        var left = function (ctx) { return [12, ctx.height / 2 - 105, 141, 213]; };
        var right = function (ctx) { return [ctx.width - 158, ctx.height / 2 - 105, 141, 213]; };
        var top = function (ctx) { return [ctx.width / 2 - 70, 8, 145, 58]; };
        var info = function (i) { return function (ctx) { return [[26, ctx.height / 2 - 74 + 11 * i, 118, 11]]; }; };
        var statRow = function (ctx, i) { return [26, ctx.height / 2 - 5 + 12 * i, 118, 12]; };
        var statistics = function (ctx, a, b) { return [ctx.width - 140, ctx.height / 2 - 66 + 12 * a, 124, 12 * (b - a + 1)]; };
        var steps = [
            { text: pre + "size", title: pre + "size.title", args: function () { return [Math.round(DMZ_OPTS.menuScale() * 100)]; }, padding: 0, centered: true,
                rects: function (ctx) { return [left(ctx), right(ctx), top(ctx)]; },
                buttons: [{ icon: "minus", run: function () { resize(-1); } }, { icon: "plus", run: function () { resize(1); } }] },
            { text: pre + "name", title: pre + "name.title", padding: 0, rects: function (ctx) { return [top(ctx)]; } },
            { text: pre + "level", title: pre + "level.title", rects: info(0) },
            { text: pre + "tps", title: pre + "tps.title", rects: info(1) }
        ];
        var affected = [[0, 0], [1, 1], [2, 3, 7, 7], [4, 4], [5, 5], [6, 6]];
        ["str", "skp", "res", "vit", "pwr", "ene"].forEach(function (k, i) {
            steps.push({ text: pre + k, title: "gui.dragonminez.character_stats." + k, rects: function (ctx) {
                var out = [statRow(ctx, i)], r = affected[i];
                for (var j = 0; j + 1 < r.length; j += 2) out.push(statistics(ctx, r[j], r[j + 1]));
                return out;
            } });
        });
        steps.push({ text: pre + "tpc", title: pre + "tpc.title", rects: function (ctx) { return [[24, ctx.height / 2 + 70, 118, 24]]; } });
        steps.push({ text: pre + "tp_multiplier", title: "gui.dragonminez.character_stats.tp_multiplier",
            rects: function (ctx) { return [[ctx.width - 140, ctx.height / 2 + 77, 112, 11]]; } });
        return steps;
    }
    /** ScaledScreen.adjustMenuScale: +-0.05 "Menu Panel Scale", reopened at the new size (the tutorial carries on). */
    function resize(dir) {
        var cur = DMZ_OPTS.menuScale(), next = Math.round(DMZ_OPTS.clamp(cur + dir * 0.05, DMZ_OPTS.MIN_MENU_SCALE, DMZ_OPTS.MAX_MENU_SCALE) * 100) / 100;
        if (next === cur) return;
        var before = DMZ_OPTS.menuRef();
        DMZ_OPTS.set(DMZ_OPTS.KEYS.menuScaleMultiplier, next);
        if (Math.abs(DMZ_OPTS.menuRef() - before) < 0.01) { DMZ_OPTS.set(DMZ_OPTS.KEYS.menuScaleMultiplier, cur); return; }   // already as big/small as it fits
        DMZ_TUTORIAL.keep();
        open();
    }

    function navigate(where) {
        RPG.sound("dmzpack:ui_menu_switch", 1, 1);
        if (where === "stats") return;
        DMZ_MENU_FX.switchTo(where);
    }

    function render(ctx) {
        var W = ctx.width, H = ctx.height, cx = W / 2, cy = H / 2, p = RPG.player, v = view();
        // BaseMenuScreen's panel offsets while the menu opens, switches or closes
        var FX = DMZ_MENU_FX, offL = FX.left(), offR = FX.right(), offT = FX.top();
        // top: name and race
        ctx.push(); ctx.translate(0, offT);
        bordered(ctx, "§l" + p.name, cx + 2, 19, "#63FFFF");
        var race = RPG.translate("race.dragonminez." + (D.DMZ[p.race] || p.race));
        bordered(ctx, race, cx + 2, 46, "#FFFFFF");
        ctx.pop();
        ctx.push(); ctx.translate(offL, 0);
        // left: INFORMATION
        bordered(ctx, "§lINFORMATION", 85, cy - 88, "#FBC51C");
        var rows = [["Level", String(p.level), "#FFFFFF"], ["TPs", F.sci(p.tp), "#FFE593"],
            ["Form", RPG.getVar("dmz_form_name", "") || "Base", "#C7EAFC"], ["Class", D.strip(T("class.dragonminez." + v.cls)), "#FFFFFF"]];
        rows.forEach(function (r, i) {
            plain(ctx, "§l" + r[0], 30, cy - 72 + 11 * i, "#D7FEF5");
            plain(ctx, r[1], 75, cy - 72 + 11 * i, r[2]);
        });
        // STATS
        bordered(ctx, "§lSTATS", 82, cy - 21, "#68CCFF");
        D.STATS.forEach(function (s, i) {
            var y = cy - 3 + 12 * i, m = v.mult(s);
            plain(ctx, "§l" + s, 42, y, "#D71432");
            var val = Math.floor(v.stat(s));
            plain(ctx, m !== 1 ? val + " x" + m.toFixed(2) : String(val), 75, y, m !== 1 ? "#FFFF00" : "#FFD7AB");
        });
        // cost of the current multiplier (AP first)
        var n = MULTS[st.mult], total = F.total(v), cls = D.CLASSES[v.cls] || D.CLASSES.warrior;
        if (p.statPoints > 0) { plain(ctx, "AP", 42, cy + 73, "#B36BFF"); plain(ctx, String(p.statPoints), 75, cy + 73, "#FFCE41"); }
        else { plain(ctx, "TPC", 42, cy + 73, "#2BFFE2"); plain(ctx, F.sci(F.cost(total, n, cls.tpCost)), 75, cy + 73, "#FFCE41"); }
        plain(ctx, "x" + n, 42, cy + 83, "#FFFFFF");
        ctx.pop();
        ctx.push(); ctx.translate(offR, 0);
        // right: STATISTICS (or the hexagon; DMZ shows the list while its tutorial runs)
        if (DMZ_OPTS.hexagon() && !DMZ_TUTORIAL.active("dmz_stats")) hexagon(ctx, v);
        else statisticsList(ctx, v);
        plain(ctx, "Power Level", W - 137, cy + 54, "#7CFDD6");
        ctx.textStyled(p.race === "glind" ? "???" : F.compact(F.battlePower(v)), W - 50, cy + 54, 1, "#FFE593", 1, 0.5, FONT, null);
        plain(ctx, "TP Multiplier", W - 137, cy + 78, "#7CFDD6");
        var tpm = 1 + (cls.tpGain - 1) + (F.progression(v) - 1) + (p.race === "frost_demon" ? 0.25 : 0) + (p.dimension === "ragnarok_rpg:time_chamber" ? 0.75 : 0);
        tpm *= 1 + prestige().tp / 100;
        ctx.textStyled("x" + tpm.toFixed(2), W - 50, cy + 78, 1, "#FFFFFF", 1, 0.5, FONT, null);
        ctx.pop();
        DMZ_TUTORIAL.render(ctx);
    }
    function derived(v) {
        return [["Melee DMG", F.melee(v)], ["Strike DMG", F.strike(v)], ["Stamina", F.maxStamina(v)], ["Defense", F.flatDefense(v)],
            ["Health", F.maxHealth(v)], ["Ki DMG", F.ki(v)], ["Max Ki", F.maxKi(v)], ["Speed", F.speed(v) * 100]];
    }
    function valueText(r) { return r[0] === "Speed" ? Math.round(r[1]) + "%" : F.compact(Math.round(r[1] * 100) / 100); }
    function statisticsList(ctx, v) {
        var W = ctx.width, cy = ctx.height / 2;
        bordered(ctx, "§lSTATISTICS", W - 85, cy - 88, "#F91E64");
        derived(v).forEach(function (r, i) {
            var y = cy - 64 + 12 * i;
            plain(ctx, r[0], W - 137, y, "#7CFDD6");
            ctx.textStyled(valueText(r), W - 50, y, 1, "#FFFFFF", 1, 0.5, FONT, null);
        });
    }

    // ---- renderStatisticsInfoHexagon: the six stats on a radar, filled in the aura colour ----
    var HEX_ORDER = ["STR", "RES", "ENE", "VIT", "PWR", "SKP"];          // clockwise from the top, as DMZ
    var HEX_STATS = { STR: [0], SKP: [1], RES: [2, 3, 7], VIT: [4], PWR: [5], ENE: [6] };   // which STATISTICS rows each stat drives
    function auraColor() {
        var c = String(RPG.getVar("dmz_aura_color", "") || "");
        if (!/^#?[0-9a-fA-F]{6}$/.test(c)) { try { c = RPG.player.color("aura", "#7FC8FF"); } catch (e) { c = "#7FC8FF"; } }
        return c.charAt(0) === "#" ? c : "#" + c;
    }
    function hexagon(ctx, v) {
        var W = ctx.width, H = ctx.height, cx = W - 85, cy = H / 2 - 20, R = 35, mx = ctx.mouseX, my = ctx.mouseY;
        bordered(ctx, "§lSTATISTICS", cx, H / 2 - 88, "#F91E64");
        var vals = HEX_ORDER.map(function (k) { return Math.max(0, Math.floor(v.stat(k))); });
        var top = Math.max(1, Math.max.apply(null, vals)), ref = top * 1.1;   // DMZ: 10% headroom over the biggest stat
        var pts = [], maxPts = [], aura = auraColor();
        HEX_ORDER.forEach(function (k, i) {
            var a = (60 * i - 90) * Math.PI / 180, r = R * Math.min(1, vals[i] / ref);
            pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]);
            maxPts.push([cx + R * Math.cos(a), cy + R * Math.sin(a)]);
        });
        // fill: a triangle fan from the centre (each slice convex), aura colour at 30%
        for (var i = 0; i < 6; i++) {
            var n = (i + 1) % 6;
            ctx.poly([cx, cy, pts[i][0], pts[i][1], pts[n][0], pts[n][1]], aura, 0.3);
        }
        // the outer hexagon: 1px black edges (each a thin quad)
        for (var j = 0; j < 6; j++) edge(ctx, maxPts[j], maxPts[(j + 1) % 6], 0.5, "#000000", 1);
        // the stat outline in the aura colour
        for (var k = 0; k < 6; k++) edge(ctx, pts[k], pts[(k + 1) % 6], 0.5, aura, 0.8);
        // labels 10 px outside the corners, with the hovered stat's values as a tooltip
        var hover = null, rows = derived(v);
        HEX_ORDER.forEach(function (key, i) {
            var a = (60 * i - 90) * Math.PI / 180, lx = cx + (R + 10) * Math.cos(a), ly = cy + (R + 10) * Math.sin(a);
            var label = U.tr("gui.dragonminez.character_stats." + key.toLowerCase()), w = ctx.textWidthIn("§l" + label, FONT);
            ctx.textStyled("§l" + label, lx, ly - 4, 1, "#D71432", 1, 0.5, FONT, "#000000");
            if (mx >= lx - w / 2 && mx <= lx + w / 2 && my >= ly - 4 && my <= ly + 5) hover = key;
        });
        if (hover) {
            var lines = [[U.tr("gui.dragonminez.character_stats." + hover.toLowerCase()) + ": " + Math.floor(v.stat(hover)), "#D71432"]];
            HEX_STATS[hover].forEach(function (r) { lines.push([rows[r][0] + ": " + valueText(rows[r]), "#55FFFF"]); });
            U.tooltip(ctx, lines, mx, my, "#D71432");
        }
    }
    function edge(ctx, a, b, half, color, alpha) {
        var dx = b[0] - a[0], dy = b[1] - a[1], len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1e-4) return;
        var px = -dy / len * half, py = dx / len * half;
        ctx.poly([a[0] + px, a[1] + py, b[0] + px, b[1] + py, b[0] - px, b[1] - py, a[0] - px, a[1] - py], color, alpha);
    }

    return { open: open };
})();

RPG.net.on("dmz_open_stats", function () { DMZ_MENU_FX.open("stats", STATS_SCREEN.open); });
