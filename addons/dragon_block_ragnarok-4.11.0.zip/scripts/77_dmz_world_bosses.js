// =====================================================================================
//  77_dmz_world_bosses.js - DragonMine Z's world bosses: lairs, fights, contribution, rewards
// =====================================================================================
//  Port of DragonMine Z (GPL-3.0): server/world/worldboss/{WorldBossManager,WorldBossLair,WorldBossSession,
//  WorldBossContribution,WorldBossRewards,WorldBossCombatEvents}.java, common/init/entities/worldboss/WorldBossEntity,
//  common/worldboss/*, server/commands/WorldBossCommand, GeneralServerConfig.WorldBossConfig (all numbers are DMZ's
//  defaults). Each boss's own fight (AllWorldBossesEntity / GeteStarEntities) is 77_dmz_world_bosses_ai.js; the
//  screens, HUD and effects are client/scripts/68_dmz_worldboss.js.
//
//  Lairs: one per boss and world (see "lairs" below for DMZ's shapes):
//    janemba            Other World Hell, 1000 blocks from 0,0: DMZ's spiked hell-stone arena (r16, rim r22, bone spikes)
//    turles             Overworld, at the foot of DMZ's Tree of Might (planned 1000+ blocks from spawn)
//    metal_cooler_core  Namek, in the chamber of DMZ's Big Gete Star (planned 1000+ blocks from spawn)
//    tamagami_1/2/3     the First / Second / Third Demon World: DMZ's raised platforms in each world's palette
//    gomah              Gomah's Cradle, the floating island over the First Demon World (chunk -70, -72)
//  A lair is built when a player first comes near (128 blocks horizontally). The boss sleeps on its anchor and wakes
//  when an eligible player (character made, alive, not creative / spectator, not knocked down) comes within 32 of it;
//  it goes back to sleep (healed, at home) once nobody is engaged within 64. Respawn 72000 ticks (1 hour).
//
//  The fight (WorldBossSession): every player within 150 blocks with a character joins (refreshed every 5 s) and gets
//  the Revive technique in slot 4; boss HP x(1 + 0.5 per extra member), melee / ki x(1 + 0.25 per extra). 3 lives each:
//  a lethal hit knocks you down instead (DMZ knockdown, glowing); an ally casts Revive on you (15 s standing still within
//  6 x 1.5 blocks, interrupted by losing 10% max HP, 90 s cooldown, 15 s after an interruption) and you stand up with
//  25% HP / ki / stamina, spending a life. Everyone down = wipe: the downed are killed. Points = damage dealt +
//  mitigated + received + healing (healing of an ally weighted by how much of their raw damage they took).
//  Rewards (WorldBossRewards): share >= 7.5%; chances x(1 + 25/15/10%) for ranks 1-3; guaranteed rewards scaled
//  0.5 + 0.5 x points / best. Results screen (30 min, /rpgc worldboss results or the chat's [More info]).
//  Ops: /rpgc worldboss locate|tp|reset|ready [boss], rebuild [boss], summon <boss> (here, no lair).
// =====================================================================================
var DMZ_WB = (function () {
    var CFG = dbrConfig("dbr_worldboss", {
        contributionRange: 150, audienceRefreshSeconds: 5, meterLingerSeconds: 15, damageWeight: 1.0, mitigatedWeight: 1.0,
        receivedWeight: 1.0, healedWeight: 1.0, lives: 3, reviveSlot: 4, reviveCastSeconds: 15, reviveCooldownSeconds: 90,
        reviveInterruptCooldownSeconds: 15, reviveInterruptDamageRatio: 0.10, reviveDecayMultiplier: 3.0, truceGraceSeconds: 15,
        reviveRange: 6.0, reviveRestoreRatio: 0.25, knockoutTitleSeconds: 5, rankChanceBonus: [0.25, 0.15, 0.10],
        guaranteedRewardMinRatio: 0.5, minContributionShare: 0.075, healthPerExtraMember: 0.5, damagePerExtraMember: 0.25
    });
    var WAKE = 32, LEASH = 64, ACTIVATION = 128, RESPAWN_TICKS = 72000, RESULTS_MS = 30 * 60 * 1000, MAX_RESULTS = 32;
    var KNOCKOUT_TICKS = 999999, RESULT_TITLE_SECONDS = 6, MISSING_BOSS_TICKS = 200;
    var VICTORY_MUSIC = "dmzpack:menu_music_12", MUSIC_VOLUME = 0.5;
    var OW = "minecraft:overworld", NAMEK = "ragnarok_rpg:namek", OTHER = "ragnarok_rpg:otherworld", DEMON = "ragnarok_rpg:demon_realm";
    function C(k) { var v = CFG[k]; return typeof v === "number" && isFinite(v) && v >= 0 ? v : 0; }

    function geo(model, tex, scale) {
        var g = sagaLook(model, tex || model, scale || 1);
        // the boss abilities' poses come from the player animation sets (DBSagasAnimations: ki.kienzan_cast, skp.grab...)
        g.animations = [DMZ_ANIM + "races/movement.animation.json", DMZ_ANIM + "races/ki.animation.json", DMZ_ANIM + "races/skp.animation.json"];
        return g;
    }
    var HARD_HP = 2.0 * 4.0, HARD_DMG = 1.5;          // WorldBossEntity.bossHealth / bossDamage: saga NORMAL x HARD x 4.0 (HP)
    // ---- the bosses (lairs) ----
    var BOSSES = {
        janemba: { name: "Janemba", mob: "wb_janemba_fat", dim: OTHER, kind: "hell",
            rewards: [{ type: "ATTRIBUTES", amount: 500, chance: 1 }, { type: "ITEM", item: "dimensional_sword", dmz: "dragonminez:dimensional_sword", count: 1, chance: 0.5 }, { type: "SKILL", skill: "dimensional_teleport", level: 1, chance: 0.2 }] },
        turles: { name: "Turles", mob: "wb_turles", dim: OW, kind: "tree",
            rewards: [{ type: "ATTRIBUTES", amount: 50, chance: 1 }, { type: "ITEM", item: "might_tree_fruit", dmz: "dragonminez:might_tree_fruit", count: 1, chance: 0.5 }, { type: "SKILL", skill: "kill_driver", level: 1, chance: 0.25 }, { type: "SKILL", skill: "meteor_burst", level: 1, chance: 0.15 }] },
        metal_cooler_core: { name: "Metal Cooler Core", mob: "wb_metal_cooler_core", dim: NAMEK, kind: "gete",
            rewards: [{ type: "ATTRIBUTES", amount: 105, chance: 1 }, { type: "SKILL", skill: "supernova_cooler", level: 1, chance: 0.2 }, { type: "ITEM", item: "gete_ingot", dmz: "dragonminez:gete_ingot", count: 4, chance: 1 }].concat(
                ["red", "purple", "yellow", "green", "orange", "blue"].map(function (c) { return { type: "ITEM", item: "gete_" + c + "_capsule", dmz: "dragonminez:gete_" + c + "_capsule", count: 1, chance: 0.12 }; })) },
        tamagami_3: { name: "Tamagami Number 3", mob: "wb_tamagami_3", dim: DEMON, kind: "platform", stars: 3,
            rewards: [{ type: "ATTRIBUTES", amount: 90, chance: 1 }, { type: "ITEM", item: "tamagami_hammer", dmz: "dragonminez:tamagami_hammer", count: 1, chance: 0.3 }] },
        tamagami_2: { name: "Tamagami Number 2", mob: "wb_tamagami_2", dim: DEMON, kind: "platform", stars: 2,
            rewards: [{ type: "ATTRIBUTES", amount: 300, chance: 1 }, { type: "ITEM", item: "tamagami_trident", dmz: "dragonminez:tamagami_trident", count: 1, chance: 0.3 }] },
        tamagami_1: { name: "Tamagami Number 1", mob: "wb_tamagami_1", dim: DEMON, kind: "platform", stars: 1,
            rewards: [{ type: "ATTRIBUTES", amount: 360, chance: 1 }, { type: "ITEM", item: "tamagami_sword", dmz: "dragonminez:tamagami_sword", count: 1, chance: 0.3 }] },
        gomah: { name: "Gomah", mob: "wb_gomah", dim: DEMON, kind: "cradle",
            rewards: [{ type: "ATTRIBUTES", amount: 435, chance: 1 }, { type: "ITEM", item: "demon_eye", dmz: "dragonminez:demon_eye", count: 1, chance: 0.02 }] }
    };
    var ORDER = ["janemba", "turles", "metal_cooler_core", "tamagami_3", "tamagami_2", "tamagami_1", "gomah"];

    // ---- bodies (AllWorldBossesEntity.* applyFixedStats + constructors). kit: DBSagasEntity kit for the brain
    //      (76_dmz_saga_ai.js): fly, ks kiBlastSpeed, ev evade cd, zz [zanzoken tier, cd], ws wild sense cd,
    //      cb [combo cd, ComboType...], sk [[KiSkillType, cd, size, main, border, outline, cast ticks]] ----
    var BODIES = {
        wb_janemba_fat: { key: "janemba", lang: "worldboss_janemba_fat", name: "Janemba", model: "saga_janemba_fat", scale: 8,
            hp: 1008000 * HARD_HP, melee: 42120 * HARD_DMG, ki: 38250 * HARD_DMG, speed: 0.14, kb: 1, bar: "purple", sleep: "boss1.sleep",
            kit: { ks: 1.8, cb: [100, "GUM_PUNCH"], sk: [[7, 225, 15.5], [31, 125, 3.5], [32, 200, 3.0], [30, 400, 1.0, "#FFF6A8", "#FFD700", "#C89B00", 100]], sc: 8 } },
        wb_super_janemba: { key: "janemba", lang: "worldboss_super_janemba", name: "Super Janemba", model: "saga_super_janemba", scale: 1,
            hp: 1102500 * HARD_HP, melee: 46440 * HARD_DMG, ki: 42230 * HARD_DMG, speed: 0.42, kb: 0, bar: "purple", sleep: "boss1.sleep",
            kit: { fly: 1, ks: 2.5, ws: 50, zz: [1, 120], cb: [150, "AIR", "BASIC", "KI_CHARGE_ATTACK", "GUM_PUNCH"], sk: [[7, 200, 15.5], [9, 260, 1.6, "#C22948", "#8C1B32"], [32, 240, 3.0]] } },
        wb_turles: { key: "turles", lang: "worldboss_turles", name: "Turles", model: "saga_turles", scale: 1,
            hp: 10900 * HARD_HP, melee: 360 * HARD_DMG, ki: 360 * HARD_DMG, speed: 0.3, kb: 0.5, bar: "red", sleep: "boss2.sleep",
            kit: { fly: 1, ks: 2.0, ws: 100, zz: [3, 100], cb: [150, "AIR", "BASIC", "KI_CHARGE_ATTACK"], sk: [[10, 120, 1.0, "#A64DFF", "#6A3BFF", "#4A2CE0"]] } },
        wb_metal_cooler_core: { key: "metal_cooler_core", lang: "worldboss_metal_cooler_core", name: "Metal Cooler Core", model: "saga_metal_cooler_core", scale: 6,
            hp: 80000 * HARD_HP, melee: 2880 * HARD_DMG, ki: 2410 * HARD_DMG, speed: 0.13, kb: 1, bar: "purple", sleep: "idle",
            kit: { ks: 2.2, sk: [[11, 140, 1.4, "#AA00FF", "#6C00A3"], [30, 420, 1.0, "#E3A6FF", "#AA00FF", "#6C00A3", 80], [36, 320, 1], [35, 260, 1]], sc: 6 } }
    };
    [3, 2, 1].forEach(function (n) {
        // Tamagami profiles: health, melee / powered, ki / powered, hit interval / powered, hit ratio / powered, knockback resistance
        var P = { 3: [390000, 49200, 56580, 44520, 51200, 0, 9, 1.0, 0.6, 0.8, [50, 110], [40, 80]],
            2: [1577500, 66300, 76250, 59990, 68990, 7, 4, 0.45, 0.4, 0.6, [60, 120], [45, 90]],
            1: [2125000, 89310, 102710, 80810, 92930, 6, 4, 0.45, 0.4, 0.6, [60, 130], [45, 90]] }[n];
        [false, true].forEach(function (pw) {
            var id = "wb_tamagami_" + n + (pw ? "_powered" : "");
            BODIES[id] = { key: "tamagami_" + n, lang: "worldboss_tamagami_" + n + (pw ? "_powered" : ""), name: "Tamagami Number " + n + (pw ? " (Powered Up)" : ""),
                model: "saga_tamagami_" + n, tex: "saga_tamagami_" + n + (pw ? "_powered" : ""), scale: 1.5, number: n, powered: pw,
                hp: P[0] * HARD_HP, melee: (pw ? P[2] : P[1]) * HARD_DMG, ki: (pw ? P[4] : P[3]) * HARD_DMG, speed: pw ? 0.34 : 0.3, kb: P[9],
                hitInterval: pw ? P[6] : P[5], hitRatio: pw ? P[8] : P[7], bar: pw ? "red" : "white", sleep: "tamagami.sleep",
                kit: pw ? { fly: 1, ks: 1.9, ev: P[11][0], ws: P[11][1], zz: [2, 250] } : { fly: 1, ks: 1.5, ev: P[10][0], ws: P[10][1] } };
        });
    });
    // Gomah grows with his Demon Eye stacks (STACK_SCALES 2.0 .. 6.5 against the saga model's 5.5): one body per size
    var GOMAH_SCALES = [2.0, 2.8, 3.6, 4.5, 5.5, 6.5];
    GOMAH_SCALES.forEach(function (sc, i) {
        BODIES[i === 0 ? "wb_gomah" : "wb_gomah_s" + i] = { key: "gomah", lang: "worldboss_gomah", name: "Gomah", model: "saga_gomah_third_eye", scale: sc / 5.5, stacks: i,
            hp: 3161500 * HARD_HP, melee: 132830 * HARD_DMG, ki: 120210 * HARD_DMG, speed: 0.3, kb: 0.9, bar: "red", sleep: "base.sit",
            kit: { fly: 1, ks: 1.8, ev: 60, ws: 140, zz: [3, 200], sk: [[30, 420, 1.0, "#E9A8FF", "#8A00E6", "#B0003A", 60]] } };
    });
    // helpers (not world bosses themselves): MiniJanemba, MetalCooler (guardian), MetalCoolerCopy, Gomah's escorts
    var JF = BODIES.wb_janemba_fat, MC = BODIES.wb_metal_cooler_core, GO = BODIES.wb_gomah;
    var MINIONS = {
        wb_mini_janemba: { owner: "janemba", lang: "worldboss_mini_janemba", name: "Mini Janemba", model: "saga_janemba_fat", scale: 0.8,
            hp: JF.hp * 0.03, melee: JF.melee * 0.03, ki: JF.ki * 0.03, speed: 0.46, kb: 0, tier: 3, kit: { ks: 1.2, cb: [100, "BASIC"], sc: 0.8 } },
        wb_metal_cooler: { owner: "metal_cooler_core", lang: "worldboss_metal_cooler", name: "Metal Cooler", model: "saga_cooler", tex: "saga_metal_cooler", scale: 1,
            hp: MC.hp * 0.02, melee: MC.melee * 0.243, ki: MC.ki * 0.25, speed: 0.34, kb: 0.4, tier: 3,
            kit: { fly: 1, ks: 2.2, zz: [1, 60], cb: [150, "BASIC"], sk: [[4, 70, 1.0, "#FF59FF", "#D859FF", "#9238F2"]] } },
        wb_metal_cooler_copy: { owner: "metal_cooler_core", lang: "worldboss_metal_cooler_copy", name: "Metal Cooler Copy", model: "saga_cooler", tex: "saga_metal_cooler", scale: 0.9,
            hp: MC.hp * 0.01, melee: MC.melee * 0.0365, ki: MC.ki * 0.0377, speed: 0.38, kb: 0, tier: 3,
            kit: { fly: 1, ks: 2.0, cb: [150, "BASIC"], sk: [[4, 220, 0.6, "#AA00FF", "#6C00A3"]], sc: 0.9 } },
        wb_gomah_escort_1: { owner: "gomah", lang: "saga_gomah_soldier_1", name: "Gomah Soldier", model: "saga_gomah_soldier_1", scale: 1.3,
            hp: GO.hp * 0.04, melee: GO.melee * 0.06, ki: GO.ki * 0.06, speed: 0.3, kb: 0, tier: 3, kitFrom: "saga_gomah_soldier_1" },
        wb_gomah_escort_2: { owner: "gomah", lang: "saga_gomah_soldier_2", name: "Gomah Soldier", model: "saga_gomah_soldier_2", scale: 1.3,
            hp: GO.hp * 0.04, melee: GO.melee * 0.06, ki: GO.ki * 0.06, speed: 0.3, kb: 0, tier: 3, kitFrom: "saga_gomah_soldier_2" }
    };
    // old ids from before the per-size Gomah / escorts stay defined (never removed): the body table above covers them

    var STATE = null;         // RPG.data "dmz_wb": key -> lair record { x, y, z, built, uuid, next (ms), ... }
    var RT = {};              // uuid -> live boss runtime
    var SESS = {};            // key -> fight session
    var AI = {};              // body id -> fight logic (77_dmz_world_bosses_ai.js)
    var NO_ENGAGE = false;    // set while transformTo adopts the new body
    function state() { if (!STATE) STATE = RPG.data.get("dmz_wb", {}) || {}; return STATE; }
    function saveState() { RPG.data.set("dmz_wb", STATE || {}); }
    function now() { return RPG.server.getTick(); }
    function alive(e) { try { return !!e && e.isAlive(); } catch (x) { return false; } }
    function gm(p) { try { return String(p.getGameMode()); } catch (e) { return "survival"; } }
    function created(p) { return !!p.getVar("dmz_created", 0); }
    function knockedDown(p) { return p.hasEffect("knocked_down"); }
    /** WorldBossEntity.isEligible */
    function eligible(p) { var g = gm(p); return p.isAlive() && g !== "creative" && g !== "spectator" && !knockedDown(p); }
    function dist2(a, x, z) { var dx = a.x - x, dz = a.z - z; return dx * dx + dz * dz; }
    function dimExists(dim) {
        if (dim.indexOf("ragnarok_rpg:") !== 0) return true;
        try { return typeof dbrDimensionExists === "function" ? dbrDimensionExists(dim.substring(13)) : RPG.dimensions.exists(dim.substring(13)); } catch (e) { return false; }
    }
    function bodyOf(e) { return e && !e.isPlayer() ? BODIES[String(e.rpgId || "")] || null : null; }
    function isBoss(e) { return !!bodyOf(e); }
    function minionOf(e) { return e && !e.isPlayer() ? MINIONS[String(e.rpgId || "")] || null : null; }

    // ---- definitions ----
    function defineMob(id, b, minion) {
        if (b.kitFrom) b.kit = DMZ_SAGA_KITS[b.kitFrom] || {};
        DMZ_SAGA_KITS["dbrwb_" + id] = b.kit;
        DMZ_SAGA.alias(id, "dbrwb_" + id);
        RPG.mobs.define(id, {
            name: b.name, geo: geo(b.model, b.tex, b.scale), health: b.hp, damage: b.melee, speed: b.speed, followRange: 64,
            persistent: true, xp: 0, scale: b.scale, hostile: true,
            onTick: function (m) { if (!minion && !RT[String(m.uuid)] && alive(m)) rt(m); DMZ_SAGA.onTick(m); },   // re-adopt after a reload / restart
            onDeath: function (m, killer) { DMZ_SAGA.onDeath(m); if (!minion) onBossDeath(m, killer); else if (AI.onMinionDeath) AI.onMinionDeath(m, killer); }
        });
    }
    Object.keys(BODIES).forEach(function (id) { defineMob(id, BODIES[id], false); });
    Object.keys(MINIONS).forEach(function (id) { defineMob(id, MINIONS[id], true); });
    function setupMob(m, b, tier, keepHp) {
        try { m.setAttributeBase("generic.knockback_resistance", b.kb); } catch (e) { }
        DMZ_SAGA.setup(m, { hp: keepHp ? 0 : b.hp, melee: b.melee, ki: b.ki, tier: tier || 4, noTransform: true, diff: { hp: 1, dmg: 1 } });
        DMZ_SAGA.setSpeed(m, b.speed);
    }

    // =========================================================================================
    //  lairs (WorldBossManager / WorldBossLair)
    // =========================================================================================
    //  janemba      WorldBossLair.Janemba: a column 1000 blocks from 0,0 (seeded angle) in Hell; the floor is the first
    //               block under y 92; arena: hell stone / ground floor r16 on a 4-deep deepstone foundation, a rim that
    //               ramps up 7 blocks to r22, 22 blocks of headroom, 18 bone spikes on the rim and 9 inside.
    //  tamagami_N   WorldBossLair.Tamagami: a flat site on the N-th Demon World (seeded, 920 / 760 / 600 blocks out,
    //               rings of 24 blocks), raised 3 blocks: a r15 platform in that world's palette with a r4 dais, 8 floor
    //               lights, 8 pillars (some broken) and four stair ramps.
    //  turles       the Tree of Might (BossStructures.TreeOfMightShape), planned once per world 1000+ blocks from
    //               spawn; Turles sleeps in the clearing (r26) at its foot.
    //  metal_cooler_core  the Big Gete Star (GeteStarShape) on Namek, 1000+ blocks from spawn; the core sits in its chamber.
    //  gomah        Gomah's Cradle (GomahCradleShape): the floating island over the First Demon World at chunk -70,-72.
    //  The three DMZ structures are DMZ's own shapes, rasterized offline (docs/dmz-spec/tools/build_dmz_lairs.py) and placed
    //  piece by piece with RPG.structures.placeGradually (stand-in blocks swapped back for DMZ's).
    var LAIR_V = 2;
    var STRUCT = { turles: "tree_of_might", metal_cooler_core: "gete_star", gomah: "gomah_cradle" };
    var DEMON_BANDS = { 1: { dist: 920, top: 251, bottom: 48 }, 2: { dist: 760, top: 481, bottom: 319 }, 3: { dist: 600, top: 766, bottom: 584 } };
    var CRADLE = { x: -70 * 16 + 8, z: -72 * 16 + 8, minSurface: 118, maxSurface: 136, ceiling: 252 - 24 - 4, clearance: 38, reach: 62 + 34 };
    var LAIR_DATA = {};
    function lairData(name) { if (!LAIR_DATA[name]) LAIR_DATA[name] = RPG.files.read("dmz_lairs/" + name + ".json"); return LAIR_DATA[name]; }

    function seedRng(salt) {
        var seed = typeof dmzWorldSeed === "function" ? dmzWorldSeed() : (RPG.data.get("dmz_world_seed", 12345) || 12345);
        var s = (seed ^ salt) >>> 0;
        return function () { s = (s + 0x6D2B79F5) >>> 0; var t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    }
    var SALTS = { janemba: 0x4A414E45, turles: 0x5455524C, metal_cooler_core: 0x47455445, tamagami_3: 0x54414D33, tamagami_2: 0x54414D32, tamagami_1: 0x54414D31, gomah: 0x474F4D41 };
    function isAir(b) { return b === "minecraft:air" || b === "minecraft:cave_air" || b === "minecraft:void_air"; }
    function isFluid(b) { return b === "minecraft:water" || b === "minecraft:lava" || /_liquid_block$/.test(b); }
    var SOFT = /^minecraft:(short_grass|grass|tall_grass|fern|large_fern|snow|vine|dead_bush|seagrass|tall_seagrass|light|glow_lichen|moss_carpet|.*_flower|dandelion|poppy|.*tulip|azure_bluet|oxeye_daisy|cornflower|allium|blue_orchid|lily_of_the_valley|sweet_berry_bush|.*_sapling|.*_mushroom|lily_pad|sugar_cane|kelp|kelp_plant)$/;
    function blocksRoot(b) { return !isAir(b) && !SOFT.test(b) && !isFluid(b); }      // TreeOfMightWriter.blocksRoot: solid
    function get(dim, x, y, z) { return RPG.world.getBlock(dim, x, y, z); }
    function loadedBox(dim, x, z, r) {
        var ok = true;
        for (var dx = -r; dx <= r + 15; dx += 16) for (var dz = -r; dz <= r + 15; dz += 16) {
            var px = x + Math.min(dx, r), pz = z + Math.min(dz, r);
            if (!RPG.world.isLoaded(dim, px, pz)) { RPG.world.requestChunks(dim, px, pz, 0); ok = false; }
        }
        return ok;
    }

    function lair(k) {
        var st = state(), b = BOSSES[k], L = st[k];
        if (L && L.v === LAIR_V) return L;
        if (!dimExists(b.dim)) return null;
        var old = L;
        L = st[k] = { v: LAIR_V, x: null, y: null, z: null, built: false, uuid: old ? old.uuid : null, next: old ? old.next || 0 : 0, phase: "pick" };
        if (old && old.built && typeof old.x === "number" && old.y !== null) L.oldLair = { x: old.x, y: old.y, z: old.z };   // improvised arena from before
        var r = seedRng(SALTS[k]);
        if (b.kind === "hell") {
            var a = r() * Math.PI * 2;
            L.x = Math.floor(Math.cos(a) * 1000); L.z = Math.floor(Math.sin(a) * 1000); L.phase = "resolve";
        } else if (b.kind === "cradle") {
            L.cx = CRADLE.x; L.cz = CRADLE.z; L.x = CRADLE.x; L.z = CRADLE.z; L.phase = "surface";
        } else if (b.kind === "platform") {
            var band = DEMON_BANDS[b.stars], a2 = r() * Math.PI * 2;
            L.ox = Math.floor(Math.cos(a2) * band.dist); L.oz = Math.floor(Math.sin(a2) * band.dist); L.x = L.ox; L.z = L.oz;
            L.search = { ring: 0, i: 0, offset: r() * Math.PI * 2, best: null, spread: 1e9 }; L.phase = "search";
        } else {
            L.phase = "plan"; L.probes = 0; L.ring = 1000;
        }
        saveState();
        return L;
    }
    function lairCenter(L) { return typeof L.cx === "number" ? { x: L.cx, z: L.cz } : typeof L.x === "number" ? { x: L.x, z: L.z } : null; }

    // ---- one-time cleanup of the improvised arenas older versions built -----------------------------
    function cleanupOld(k, L) {
        var o = L.oldLair, dim = BOSSES[k].dim;
        delete L.oldLair; saveState();
        if (!o || !RPG.edit) return;
        try {
            var reg = { type: "cuboid", x1: o.x - 23, y1: o.y - 4, z1: o.z - 23, x2: o.x + 40, y2: o.y + 45, z2: o.z + 23 };
            RPG.edit.replace(null, dim, reg, "iron_block,polished_deepslate,polished_blackstone,gilded_blackstone,oak_log,oak_leaves,moss_block", "air", { history: false, progress: false });
        } catch (e) { RPG.log("DMZ world boss: old arena cleanup: " + e); }
    }

    // ---- planning the Tree of Might / Big Gete Star sites (StructureSpawnPlanner, MIN_DISTANCE 1000) ----
    //  DMZ: the Tree of Might in swamps (IS_SWAMPLIKE), the Big Gete Star on Ajissa plains / Sacred Land; both are
    //  one-per-world sets, so like the others they keep 500 blocks from every other landmark (Baba's palace, the
    //  Budokai...) and 3 chunks from other structures. The site is claimed with the engine so the others keep away too.
    var LAIR_SITE = {
        turles: { biomes: ["minecraft:swamp", "minecraft:mangrove_swamp", "#forge:is_swamp"], kind: "swamp" },
        metal_cooler_core: { biomes: ["dbr:ajissa_plains", "dbr:sacred_land"], kind: "land" }
    };
    function claimKey(k) { return "dmz_unique:" + STRUCT[k]; }
    function claimLair(k, L) {
        var b = BOSSES[k], m = STRUCT[k] ? lairData(STRUCT[k]) : null, c = lairCenter(L);
        if (!c || typeof dmzClaim !== "function") return;
        if (m) dmzClaim(claimKey(k), b.dim, c.x + m.min[0], c.z + m.min[2], c.x + m.max[0], c.z + m.max[2]);
        else dmzClaim("dmz_lair:" + k, b.dim, c.x - 24, c.z - 24, c.x + 24, c.z + 24);       // arenas / platforms (r22 / r19)
    }
    function siteFree(k, x, z, relaxed) {
        var b = BOSSES[k], m = lairData(STRUCT[k]), sel = LAIR_SITE[k];
        if (typeof dmzUniqueSiteFree !== "function") return true;
        if (typeof dmzTooClose === "function" && dmzTooClose(dmzPlans(), b.dim, x, z)) return false;
        if (sel && !relaxed && !dmzBiomeOk(sel.biomes, b.dim, x, z)) return false;
        return dmzUniqueSiteFree(claimKey(k), b.dim, x, z, m.max[0] - m.min[0], m.max[2] - m.min[2]);
    }
    function planStep(k, L) {
        var b = BOSSES[k], m = lairData(STRUCT[k]), sel = LAIR_SITE[k] || { kind: "land" };
        if (!m) return;
        var sp = b.dim === OW ? RPG.world.spawnPoint() : { x: 0, z: 0 }, sx = Number(sp.x) || 0, sz = Number(sp.z) || 0;
        if (!L.pending) {
            // candidates are checked from the world generator (biome, other sites, structures) before anything loads
            for (var tries = 0, t0 = Date.now(); tries < 24 && !L.pending && Date.now() - t0 < 8; tries++) {
                var r = seedRng(SALTS[k] + (L.probes + (L.misses || 0)) * 7919), a = r() * Math.PI * 2;
                var cx = Math.round(sx + Math.cos(a) * L.ring), cz = Math.round(sz + Math.sin(a) * L.ring);
                L.ring += 16 * (1 + Math.floor(r() * 3));
                if (L.ring > 4000) L.ring = 1000;                     // sweep out again (new angles) rather than stay at 4000
                // DMZ's relaxed search: with no such biome within reach, any ground that keeps clear of the others
                if (siteFree(k, cx, cz, (L.misses || 0) >= 1500)) L.pending = { x: cx, z: cz, waits: 0 };
                else L.misses = (L.misses || 0) + 1;
            }
            if (!L.pending) {
                if ((L.misses || 0) >= 2000 && L.best) { L.probes = 24; }      // settle for the best probed site
                else { saveState(); return; }
            }
        }
        var p = L.pending || L.best, probe;
        if (L.pending) {
            probe = typeof dmzProbe === "function" ? dmzProbe(b.dim, p.x, p.z, 96, 96, 3, true) : { n: 9, spread: 0, wet: 0, median: 64 };
            if (probe.n < 9 && ++p.waits < 60) return;
            var score = typeof dmzSiteScore === "function" ? dmzSiteScore(sel.kind, probe) : 100;
            L.probes++;
            if (!L.best || score > L.best.score) L.best = { x: p.x, z: p.z, score: score };
            L.pending = null;
        }
        if (L.best && (L.best.score >= 30 || L.probes >= 24)) {
            L.cx = L.best.x; L.cz = L.best.z; L.x = L.cx; L.z = L.cz; L.phase = "base";
            claimLair(k, L);
            RPG.log("[DMZ] world boss " + k + ": " + STRUCT[k] + " planned at " + L.cx + ", " + L.cz);
        }
        saveState();
    }
    // A site planned by an older version but not built yet that sits on another landmark is planned again; sites
    // already built (or being built) stay where they are, only claimed so new sites keep away from them.
    function checkPlanned(k, L) {
        if (L.claimed) return;
        L.claimed = true;
        if (STRUCT[k] && L.phase === "base" && LAIR_SITE[k] && typeof dmzUniqueSiteFree === "function") {
            var b = BOSSES[k], m = lairData(STRUCT[k]);
            if (m && !dmzUniqueSiteFree(claimKey(k), b.dim, L.cx, L.cz, m.max[0] - m.min[0], m.max[2] - m.min[2])) {
                RPG.log("[DMZ] world boss " + k + ": planned site " + L.cx + ", " + L.cz + " is on another structure, planning again");
                L.phase = "plan"; L.probes = 0; L.misses = 0; L.ring = 1000; delete L.best; delete L.pending;
                delete L.cx; delete L.cz; L.x = null; L.z = null;
                saveState();
                return;
            }
        }
        if (L.phase !== "plan" && L.phase !== "pick" && L.phase !== "search") claimLair(k, L);
        saveState();
    }

    // ---- Tamagami platform site search (WorldBossLair.Tamagami.findSite) ---------------------------
    function bandGround(dim, x, z, bottom, top, headroom) {
        if (isAir(get(dim, x, bottom, z))) return null;
        var y = bottom;
        while (y < top && !isAir(get(dim, x, y + 1, z))) y++;
        if (y >= top || isFluid(get(dim, x, y, z))) return null;
        for (var h = 1; h <= headroom; h++) if (!isAir(get(dim, x, y + h, z))) return null;
        return y;
    }
    function nearTunnel(x, z) {
        var T = typeof DR_TUNNELS !== "undefined" ? DR_TUNNELS : { lower: { ox: 700, oz: 450 }, upper: { ox: 0, oz: 0 } }, S = 2048;
        for (var n in T) {
            var dx = ((x - T[n].ox) % S + S) % S, dz = ((z - T[n].oz) % S + S) % S;
            dx = Math.min(dx, S - dx); dz = Math.min(dz, S - dz);
            if (Math.sqrt(dx * dx + dz * dz) < 90 + 10 + 48) return true;
        }
        return false;
    }
    function searchStep(k, L) {
        var b = BOSSES[k], band = DEMON_BANDS[b.stars], s = L.search, dim = b.dim, budget = 3;
        while (budget-- > 0) {
            if (s.ring > 8) {                                    // no flat ground nearby: the flattest one seen
                var best = s.best || { x: L.ox, z: L.oz, y: Math.floor((band.top + band.bottom) / 2) };
                L.x = best.x; L.z = best.z; L.ground = best.y; L.phase = "build"; claimLair(k, L); saveState();
                RPG.log("[DMZ] " + b.name + ": no flat ground, using " + best.x + " " + best.y + " " + best.z);
                return;
            }
            var radius = s.ring * 24, points = s.ring === 0 ? 1 : Math.max(6, Math.ceil(Math.PI * 2 * radius / 24));
            var a = s.offset + Math.PI * 2 * s.i / points, x = L.ox + Math.floor(Math.cos(a) * radius), z = L.oz + Math.floor(Math.sin(a) * radius);
            var skip = nearTunnel(x, z) || (b.stars === 1 && Math.sqrt(Math.pow(x - CRADLE.x, 2) + Math.pow(z - CRADLE.z, 2)) < CRADLE.reach + 15 + 40);
            if (!skip) {
                if (!loadedBox(dim, x, z, 16)) return;               // wait for its chunks
                var g = bandGround(dim, x, z, band.bottom, band.top, 20);
                if (g !== null) {
                    var spread = 0;
                    for (var i = 0; i < 8 && spread < 1e9; i++) {
                        var aa = Math.PI * 2 * i / 8, sg = bandGround(dim, x + Math.floor(Math.cos(aa) * 14), z + Math.floor(Math.sin(aa) * 14), band.bottom, band.top, 4);
                        spread = sg === null ? 1e9 : Math.max(spread, Math.abs(sg - g));
                    }
                    if (spread <= 5) { L.x = x; L.z = z; L.ground = g; L.phase = "build"; claimLair(k, L); saveState(); RPG.log("[DMZ] " + b.name + " lair found at " + x + " " + g + " " + z); return; }
                    if (spread < s.spread) { s.spread = spread; s.best = { x: x, z: z, y: g }; }
                }
            }
            if (++s.i >= points) { s.i = 0; s.ring++; }
            saveState();
        }
    }

    // ---- arenas built in the world, a few columns per tick ------------------------------------------
    var BUILD_QUEUE = [];
    RPG.every(1, function () {
        var t0 = Date.now();
        while (BUILD_QUEUE.length && Date.now() - t0 < 6) { try { BUILD_QUEUE.shift()(); } catch (e) { RPG.log("DMZ world boss arena: " + e); } }
    });
    function bone(dim, x, y, z) { if (isAir(get(dim, x, y, z))) RPG.world.setBlock(dim, x, y, z, "minecraft:bone_block[axis=y]"); }
    function spike(dim, x, baseY, z, height, rnd) {               // WorldBossLair.Janemba.spike
        for (var i = 0; i < height; i++) {
            var w = i < height / 3 ? 1 : 0;
            for (var dx = -w; dx <= w; dx++) for (var dz = -w; dz <= w; dz++) { if (w === 1 && Math.abs(dx) + Math.abs(dz) === 2) continue; bone(dim, x + dx, baseY + i, z + dz); }
            if (i > height / 2 && Math.floor(rnd() * 4) === 0) break;
        }
    }
    function queueJanembaArena(L, done) {                        // WorldBossLair.Janemba.buildArena
        var dim = OTHER, cx = L.x, cz = L.z, baseY = L.ground, R = 16, RIM = 22, HEAD = 22, FOUND = 4, RIMH = 7;
        var rnd = dmzRng ? dmzRng(dmzHash(cx, baseY, cz, 0x4A41)) : Math.random;
        var floor = blockRef("hell_stone"), ground = blockRef("hell_ground"), deep = blockRef("hell_deepstone");
        for (var dz = -RIM; dz <= RIM; dz++) (function (dz) {
            BUILD_QUEUE.push(function () {
                for (var dx = -RIM; dx <= RIM; dx++) {
                    var d = Math.sqrt(dx * dx + dz * dz), x = cx + dx, z = cz + dz;
                    if (d > RIM) continue;
                    if (d <= R) {
                        RPG.world.setBlock(dim, x, baseY, z, Math.floor(rnd() * 4) === 0 ? ground : floor);
                        RPG.world.fill(dim, x, baseY - FOUND, z, x, baseY - 1, z, deep, "keep");
                        RPG.world.fill(dim, x, baseY + 1, z, x, baseY + HEAD, z, "minecraft:air");
                    } else {
                        var wallTop = baseY + Math.ceil((d - R) / (RIM - R) * RIMH);
                        RPG.world.fill(dim, x, baseY - FOUND, z, x, baseY - 1, z, deep, "keep");
                        if (wallTop - 2 >= baseY) RPG.world.fill(dim, x, baseY, z, x, wallTop - 2, z, deep);
                        RPG.world.fill(dim, x, Math.max(baseY, wallTop - 1), z, x, wallTop, z, floor);
                        if (wallTop + 1 <= baseY + HEAD) RPG.world.fill(dim, x, wallTop + 1, z, x, baseY + HEAD, z, "minecraft:air");
                    }
                }
            });
        })(dz);
        BUILD_QUEUE.push(function () {
            for (var i = 0; i < 18; i++) {
                var a = Math.PI * 2 / 18 * i + rnd() * 0.15, rr = RIM - 1 - Math.floor(rnd() * 2);
                var x = cx + Math.floor(Math.cos(a) * rr), z = cz + Math.floor(Math.sin(a) * rr), top = null;
                for (var y = baseY + RIMH + 2; y >= baseY - FOUND; y--) if (!isAir(get(dim, x, y, z))) { top = y; break; }
                if (top !== null) spike(dim, x, top + 1, z, 5 + Math.floor(rnd() * 6), rnd);
            }
            for (var j = 0; j < 9; j++) {
                var a2 = rnd() * Math.PI * 2, r2 = 4 + Math.floor(rnd() * (R - 5)), x2 = cx + Math.floor(Math.cos(a2) * r2), z2 = cz + Math.floor(Math.sin(a2) * r2);
                if (Math.abs(x2 - cx) < 4 && Math.abs(z2 - cz) < 4) continue;
                spike(dim, x2, baseY + 1, z2, 3 + Math.floor(rnd() * 4), rnd);
            }
        });
        BUILD_QUEUE.push(done);
    }
    var PALETTES = {
        1: { base: "demon_rock", accent: "demon_bricks", trim: "red_ash", light: "crimson_crystal", stairs: "demon_brick_stairs" },
        2: { base: "turquoise_rock", accent: "namek_deepslate", trim: "namek_stone", light: "minecraft:sea_lantern", stairs: "namek_deepslate_stairs" },
        3: { base: "makai_stone", accent: "adobe_bricks", trim: "makai_strata_stone", light: "minecraft:shroomlight", stairs: "adobe_stairs" }
    };
    function ref(n) { return n.indexOf(":") >= 0 ? n : blockRef(n); }
    function isSupport(dim, x, y, z) {
        var b = get(dim, x, y, z);
        if (!blocksRoot(b) || /leaves/.test(b)) return false;
        var n = typeof dmzBlockAt === "function" ? DMZ_BLOCK_BY_REF[b] : null;
        return n !== "dark_sea_cloud" && n !== "makai_bush" && !/_leaves$/.test(n || "");
    }
    function fillBelow(dim, x, z, from, ground, block) {               // Tamagami.fillBelow (48 deep at most)
        var y = from;
        while (y >= from - 48 && !(y < ground && isSupport(dim, x, y, z))) y--;
        if (y < from) RPG.world.fill(dim, x, y + 1, z, x, from, z, block);
    }
    function queuePlatform(k, L, done) {                             // WorldBossLair.Tamagami.buildArena
        var b = BOSSES[k], dim = b.dim, P = PALETTES[b.stars], R = 15, RISE = 3, DAIS = 4, CLEAR = 20;
        var cx = L.x, cz = L.z, top = L.ground + RISE, ground = L.ground, rnd = dmzRng(dmzHash(cx, top, cz, 0x54414D));
        var base = ref(P.base), accent = ref(P.accent), trim = ref(P.trim), light = ref(P.light);
        function floorPattern(d, dx, dz) {
            if (d > R - 1.5) return accent;
            if (d > R - 4.5 && d <= R - 3.5) return trim;
            if (d > DAIS + 1.5 && d < R - 4.5 && Math.abs(Math.sin(Math.atan2(dz, dx) * 4)) * d < 0.9) return trim;
            return base;
        }
        for (var dz = -R; dz <= R; dz++) (function (dz) {
            BUILD_QUEUE.push(function () {
                for (var dx = -R; dx <= R; dx++) {
                    var d = Math.sqrt(dx * dx + dz * dz);
                    if (d > R + 0.5) continue;
                    var x = cx + dx, z = cz + dz;
                    RPG.world.fill(dim, x, top + 1, z, x, top + CLEAR, z, "minecraft:air");
                    RPG.world.setBlock(dim, x, top, z, floorPattern(d, dx, dz));
                    fillBelow(dim, x, z, top - 1, ground, d > R - 1.5 ? accent : base);
                }
            });
        })(dz);
        BUILD_QUEUE.push(function () {
            for (var dx = -DAIS; dx <= DAIS; dx++) for (var dz = -DAIS; dz <= DAIS; dz++) {
                var d = Math.sqrt(dx * dx + dz * dz);
                if (d <= DAIS + 0.2) RPG.world.setBlock(dim, cx + dx, top + 1, cz + dz, d > DAIS - 1 ? accent : trim);
            }
            for (var i = 0; i < 8; i++) {
                var a = Math.PI * 2 * i / 8;
                RPG.world.setBlock(dim, cx + Math.round(Math.cos(a) * (R - 4)), top, cz + Math.round(Math.sin(a) * (R - 4)), light);
            }
            // four stair ramps down to the ground, facing the platform
            [["north", 0, -1, "south"], ["east", 1, 0, "west"], ["south", 0, 1, "north"], ["west", -1, 0, "east"]].forEach(function (d) {
                var sideX = -d[2], sideZ = d[1];                        // clockwise of the direction
                for (var step = 1; step <= RISE; step++) {
                    var along = R + step, y = top - step + 1;
                    for (var w = -2; w <= 2; w++) {
                        var x = cx + d[1] * along + sideX * w, z = cz + d[2] * along + sideZ * w;
                        RPG.world.fill(dim, x, y + 1, z, x, y + 4, z, "minecraft:air");
                        if (typeof dmzSet === "function") dmzSet(dim, x, y, z, P.stairs, d[3]); else RPG.world.setBlock(dim, x, y, z, accent);
                        fillBelow(dim, x, z, y - 1, ground, base);
                    }
                }
            });
            for (var j = 0; j < 8; j++) {                               // pillars, a third of them broken
                var a3 = Math.PI * 2 * (j + 0.5) / 8, px = cx + Math.round(Math.cos(a3) * (R - 1.5)), pz = cz + Math.round(Math.sin(a3) * (R - 1.5));
                var broken = Math.floor(rnd() * 3) === 0, h = broken ? 2 + Math.floor(rnd() * 3) : 6 + Math.floor(rnd() * 4);
                [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (o) { RPG.world.setBlock(dim, px + o[0], top + 1, pz + o[1], trim); });
                RPG.world.fill(dim, px, top + 1, pz, px, top + h, pz, accent);
                if (broken) { var f = [[1, 0], [-1, 0], [0, 1], [0, -1]][Math.floor(rnd() * 4)]; RPG.world.setBlock(dim, px + f[0] * 2, top + 1, pz + f[1] * 2, accent); }
                else { RPG.world.setBlock(dim, px, top + h + 1, pz, trim); RPG.world.setBlock(dim, px, top + h + 2, pz, light); }
            }
            RPG.server.players().forEach(function (p) {                // nobody gets buried in the new platform
                if (p.dimension === dim && Math.pow(p.x - cx - 0.5, 2) + Math.pow(p.z - cz - 0.5, 2) <= Math.pow(R + RISE + 1, 2) && p.y >= ground - 2 && p.y < top + 1) p.teleport(p.x, top + 2, p.z);
            });
        });
        BUILD_QUEUE.push(done);
    }

    // ---- the three DMZ structures (pieces placed gradually, then their in-world touches) -------------
    function surfaceFor(x, z) {                                      // TreeOfMightWriter.surfaceFor
        function h(a, b) { var v = Math.imul(a, 73428767) ^ Math.imul(b, 912931); v ^= v >>> 13; v = Math.imul(v, 0x5BD1E995); return v ^ (v >>> 15); }
        var patch = (((h(x >> 2, z >> 2) + (((h(x, z) % 3) + 3) % 3)) % 10) + 10) % 10;
        return patch < 3 ? "minecraft:rooted_dirt" : patch < 6 ? "minecraft:coarse_dirt" : patch < 8 ? "minecraft:mud" : "minecraft:podzol";
    }
    function treeArena(L, m) {                                       // TreeOfMightWriter.shapeArena (before the tree)
        var dim = OW, ax = L.cx + m.arenaX, az = L.cz + m.arenaZ, F = L.arenaFloor, R = 26, REACH = 32;
        for (var dz = -REACH; dz <= REACH; dz++) (function (dz) {
            BUILD_QUEUE.push(function () {
                for (var dx = -REACH; dx <= REACH; dx++) {
                    var d = Math.sqrt(dx * dx + dz * dz), x = ax + dx, z = az + dz;
                    if (d > REACH) continue;
                    var topY = d <= R ? F : F - Math.ceil((d - R) * 0.6);
                    if (d <= R) RPG.world.fill(dim, x, F + 1, z, x, F + 40, z, "minecraft:air");
                    for (var y = topY, depth = 0; depth <= 16; y--, depth++) {
                        var cur = get(dim, x, y, z);
                        if (blocksRoot(cur) && (y < topY || d > R)) break;
                        RPG.world.setBlock(dim, x, y, z, y === topY ? surfaceFor(x, z) : "minecraft:dirt");
                    }
                }
            });
        })(dz);
    }
    function treeFinish(L, m) {                                      // extendBase + placeLights, after the tree
        var dim = OW, wood = blockRef("might_tree_wood");
        var base = m.base || [];
        for (var i = 0; i < base.length; i += 200) (function (i) {
            BUILD_QUEUE.push(function () {
                for (var j = i; j < Math.min(base.length, i + 200); j++) {
                    var x = L.cx + base[j][0], z = L.cz + base[j][1], y = L.base - 9, n = 0;
                    while (n < 48 && !blocksRoot(get(dim, x, y, z))) { y--; n++; }
                    if (n > 0) RPG.world.fill(dim, x, y + 1, z, x, L.base - 9, z, wood);
                }
            });
        })(i);
        var lights = m.lights || [];
        for (var k2 = 0; k2 < lights.length; k2 += 40) (function (k2) {
            BUILD_QUEUE.push(function () {
                for (var j = k2; j < Math.min(lights.length, k2 + 40); j++) {
                    var x = L.cx + lights[j][0], z = L.cz + lights[j][1], top = L.base + 36, g = null;
                    if (!RPG.world.isLoaded(dim, x, z) || blocksRoot(get(dim, x, top, z))) continue;
                    for (var y = top - 1; y >= L.base - 40; y--) if (blocksRoot(get(dim, x, y, z))) { g = y; break; }
                    if (g !== null && isAir(get(dim, x, g + 6, z))) RPG.world.setBlock(dim, x, g + 6, z, "minecraft:light[level=15]");
                }
            });
        })(k2);
    }
    function remapFor(m) {
        var out = {};
        for (var s in m.remap) { var id = blockRef(m.remap[s]); if (id) out[s] = id; }
        return out;
    }
    // A structure job: piece by piece, each once its chunks are loaded. Saved, so a restart resumes it.
    function structStep(k, L) {
        var b = BOSSES[k], m = lairData(STRUCT[k]), job = L.job;
        if (!m || !job) return;
        var t0 = Date.now();
        while (Date.now() - t0 < 5) {
            if (job.i >= m.pieces.length) {
                if (job.last && !RPG.structures.isPlaced(job.last)) return;
                delete L.job; L.phase = "finish"; saveState(); return;
            }
            if (RPG.structures.pendingBlocks() > 60000) return;
            var pc = m.pieces[job.i], x = L.cx + pc[0], z = L.cz + pc[1];
            var ok = true;
            [[0, 0], [31, 0], [0, 31], [31, 31]].forEach(function (o) { if (!RPG.world.isLoaded(b.dim, x + o[0], z + o[1])) { RPG.world.requestChunks(b.dim, x + o[0], z + o[1], 0); ok = false; } });
            if (!ok && ++job.waits < 400) return;
            job.waits = 0;
            var id = RPG.structures.placeGradually(b.dim, pc[2], x, L.base + m.min[1], z, 0, { remap: remapFor(m) });
            if (id) job.last = id;
            job.i++;
            saveState();
        }
    }
    function structBase(k, L) {                                     // ground under the centre: average of 9 samples (r18)
        var b = BOSSES[k], dim = b.dim, sum = 0;
        var pts = [[0, 0]];
        for (var i = 0; i < 8; i++) pts.push([Math.round(Math.cos(i * Math.PI / 4) * 18), Math.round(Math.sin(i * Math.PI / 4) * 18)]);
        for (var j = 0; j < pts.length; j++) {
            var x = L.cx + pts[j][0], z = L.cz + pts[j][1];
            if (!RPG.world.isLoaded(dim, x, z)) { RPG.world.requestChunks(dim, x, z, 1); return null; }
            var sy = RPG.world.surfaceY(dim, x, z);
            if (sy <= -9999) return null;
            sum += sy;
        }
        return Math.floor(sum / pts.length);
    }
    function cradleSurface(L) {                                     // GomahCradleShape.surfaceFor
        var samples = [[0, 0], [40, 0], [-40, 0], [0, 40], [0, -40], [28, 28], [-28, 28], [28, -28], [-28, -28], [70, 0], [-70, 0], [0, 70], [0, -70], [50, 50], [-50, 50], [50, -50], [-50, -50]];
        var g = 64;
        for (var i = 0; i < samples.length; i++) {
            var x = L.cx + samples[i][0], z = L.cz + samples[i][1];
            if (!RPG.world.isLoaded(DEMON, x, z)) { RPG.world.requestChunks(DEMON, x, z, 0); return null; }
            for (var y = CRADLE.ceiling; y > 48; y--) { var bl = get(DEMON, x, y, z); if (isAir(bl) || isFluid(bl)) continue; g = Math.max(g, y); break; }
        }
        return Math.max(CRADLE.minSurface, Math.min(CRADLE.maxSurface, g + CRADLE.clearance));
    }

    // One step of a lair's life: pick -> (search/plan) -> resolve -> build -> ready (WorldBossManager.tickLair)
    function lairStep(k, L, near, inDim) {
        var b = BOSSES[k], m;
        if (L.oldLair) cleanupOld(k, L);
        checkPlanned(k, L);
        switch (L.phase) {
            case "search": if (near) searchStep(k, L); return false;
            case "plan": if (inDim) planStep(k, L); return false;
            case "resolve":                                              // Janemba: first block under y 92
                if (!near || !loadedBox(b.dim, L.x, L.z, 22)) return false;
                for (var y = 92; y >= -50; y--) if (!isAir(get(b.dim, L.x, y, L.z))) { L.ground = y; break; }
                if (L.ground === undefined) return false;
                L.phase = "build"; claimLair(k, L); saveState(); return false;
            case "surface":                                              // Gomah: the island's height
                if (!inDim) return false;
                var s = cradleSurface(L);
                if (s === null) return false;
                L.base = s; L.phase = "struct"; claimLair(k, L); saveState(); return false;
            case "base":                                                 // Tree / Gete Star: ground height
                if (!near) return false;
                var bs = structBase(k, L);
                if (bs === null) return false;
                L.base = bs;
                m = lairData(STRUCT[k]);
                if (k === "turles") {
                    var ax = L.cx + m.arenaX, az = L.cz + m.arenaZ;
                    if (!RPG.world.isLoaded(b.dim, ax, az)) { RPG.world.requestChunks(b.dim, ax, az, 1); return false; }
                    L.arenaFloor = RPG.world.surfaceY(b.dim, ax, az) - 1;          // DMZ: max(ground - 1, sea level - 1); flat worlds sit far below 62
                    treeArena(L, m);
                }
                L.phase = "struct"; saveState(); return false;
            case "struct":
                if (!near) return false;
                if (!L.job) { L.job = { i: 0, waits: 0 }; saveState(); RPG.log("[DMZ] building " + STRUCT[k] + " for " + b.name + " at " + L.cx + " " + L.base + " " + L.cz); }
                if (BUILD_QUEUE.length) return false;                     // the tree's clearing first
                structStep(k, L); return false;
            case "finish":
                m = lairData(STRUCT[k]);
                if (k === "turles") { treeFinish(L, m); L.x = L.cx + m.arenaX; L.z = L.cz + m.arenaZ; L.y = L.arenaFloor + 1; }
                else if (k === "metal_cooler_core") { L.x = L.cx + m.core[0]; L.z = L.cz + m.core[2]; L.y = L.base + m.core[1] + 1; L.tp = [L.cx + m.entrance[0], L.base + m.entrance[1] + 1, L.cz + m.entrance[2]]; }
                else if (k === "gomah") { L.x = L.cx + m.anchor[0]; L.z = L.cz + m.anchor[2]; L.y = L.base + m.anchor[1] + 1; L.tp = [L.x, L.y + 1, L.z + 62 - 14]; }
                L.built = true; L.phase = "ready"; saveState();
                RPG.log("[DMZ] " + STRUCT[k] + " for " + b.name + " finished");
                return false;
            case "build":                                                // Janemba / Tamagami arenas
                if (!near || BUILD_QUEUE.length) return false;
                if (!loadedBox(b.dim, L.x, L.z, 24)) return false;
                L.phase = "building"; saveState();
                var fin = function () {
                    if (b.kind === "hell") L.y = L.ground + 1;
                    else { L.y = L.ground + 3 + 2; L.tp = [L.x, L.ground + 3 + 1, L.z + 15 - 3]; }
                    L.built = true; L.phase = "ready"; saveState();
                };
                if (b.kind === "hell") queueJanembaArena(L, fin); else queuePlatform(k, L, fin);
                return false;
            case "building":
                if (!BUILD_QUEUE.length) L.phase = "build";                // interrupted by a restart: build again
                return false;
            case "ready":
                // the lair was broken (its floor block is gone) and nobody is fighting: rebuild the arena
                if (near && !SESS[k] && (b.kind === "hell" || b.kind === "platform") && RPG.world.isLoaded(b.dim, L.x, L.z) && isAir(get(b.dim, L.x, L.y - 1, L.z))) {
                    L.phase = "build"; L.built = false; saveState(); RPG.log("[DMZ] " + b.name + "'s lair floor is gone, rebuilding it");
                    return false;
                }
                return true;
        }
        return false;
    }


    // =========================================================================================
    //  live bosses (WorldBossEntity)
    // =========================================================================================
    function bossEntity(k) {
        var L = state()[k];
        if (!L || !L.uuid) return null;
        var e = RPG.world.entityByUuid(L.uuid);
        return alive(e) && isBoss(e) ? e : null;
    }
    function home(R) {                                   // anchor.above(): where the boss stands on its lair
        var L = state()[R.key];
        if (R.anchor) return R.anchor;
        if (L && typeof L.x === "number" && L.y !== null && L.y !== undefined) return { x: L.x + 0.5, y: L.y, z: L.z + 0.5 };
        return { x: R.m.x, y: R.m.y, z: R.m.z };
    }
    function rt(m) {
        var u = String(m.uuid), R = RT[u];
        if (R) { if (R.m !== m && alive(m)) R.m = m; return R; }      // a fresh wrapper of the same entity keeps its state
        var id = String(m.rpgId), b = BODIES[id];
        if (!b || !alive(m)) return null;
        R = RT[u] = { m: m, uuid: u, id: id, body: b, key: b.key, ab: null, abT: 0, gap: 0, mult: {}, group: 0, asleep: m.hasTag("dmz_wb_asleep"),
            resting: false, tfUntil: 0, born: now(), bar: 0, s: {} };
        var sv = RPG.data.get("dmz_wb_anchor:" + u, null);
        if (sv) R.anchor = sv;
        setupMob(m, b, 4, !R.asleep);
        if (AI[id] && AI[id].init) AI[id].init(R);
        if (R.asleep) { applyFixedStats(R); holdSleep(R); }
        else if (!SESS[R.key] && !NO_ENGAGE) engaged(R);
        return R;
    }
    function dropRt(u) {
        var R = RT[u];
        if (!R) return;
        delete RT[u];
        try { RPG.ui.removeBossBar("dmz_wb_" + R.key); } catch (e) { }
    }

    // ---- stats (applyFixedStats + applyGroupScaling + the bosses' own damage modifiers) ----
    function meleeOf(R) {
        var v = R.body.melee * (1 + C("damagePerExtraMember") * R.group);
        for (var k in R.mult) v *= R.mult[k];
        return v;
    }
    function kiOf(R) { return R.body.ki * (1 + C("damagePerExtraMember") * R.group) * (R.kiMult || 1); }
    function refreshDamage(R) {
        try { R.m.setAttributeBase("generic.attack_damage", meleeOf(R)); } catch (e) { }
        DMZ_SAGA.setKi(R.m, kiOf(R));
    }
    function setMult(R, name, v) {
        var cur = R.mult[name] === undefined ? 1 : R.mult[name];
        if (v === null) v = 1;
        if (cur === v) return;
        if (v === 1) delete R.mult[name]; else R.mult[name] = v;
        refreshDamage(R);
    }
    function applyFixedStats(R) {
        var m = R.m, b = R.body;
        R.group = 0;
        m.maxHealth = b.hp; m.health = b.hp;
        try { m.setAttributeBase("generic.movement_speed", b.speed); m.setAttributeBase("generic.knockback_resistance", b.kb); } catch (e) { }
        DMZ_SAGA.setSpeed(m, b.speed);
        refreshDamage(R);
    }
    /** WorldBossEntity.applyGroupScaling: MULTIPLY_TOTAL modifiers, the health fraction kept. */
    function applyGroupScaling(R, members) {
        if (R.asleep) return;
        var extra = Math.max(0, members - 1);
        if (extra === R.group) return;
        var m = R.m, frac = m.maxHealth > 0 ? m.health / m.maxHealth : 1;
        R.group = extra;
        m.maxHealth = R.body.hp * (1 + C("healthPerExtraMember") * extra);
        if (alive(m)) m.health = Math.max(1, m.maxHealth * frac);
        refreshDamage(R);
    }

    // ---- sleeping / waking ----
    function holdSleep(R) {
        var m = R.m;
        try { m.setAI(false); } catch (e) { }
        DMZ_SAGA.freeze(m, true);
        m.target = null;
        m.playAnimation(R.body.sleep, "loop");
        if (AI[R.id] && AI[R.id].sleepPose) AI[R.id].sleepPose(R);
    }
    function fallAsleep(R) {
        stopAbility(R);
        R.asleep = true;
        R.m.addTag("dmz_wb_asleep");
        clearBar(R);
        R.group = 0;
        holdSleep(R);
    }
    function canWake(R) { var L = state()[R.key]; return !L || Date.now() >= (L.next || 0); }
    function wakeUp(R, trigger) {
        if (!R.asleep || !canWake(R)) return false;
        var m = R.m;
        R.asleep = false;
        m.removeTag("dmz_wb_asleep");
        try { m.setAI(true); } catch (e) { }
        DMZ_SAGA.freeze(m, false);
        m.stopAnimation();
        if (trigger) m.target = trigger;
        engaged(R);
        if (AI[R.id] && AI[R.id].onWake) AI[R.id].onWake(R, trigger);
        return true;
    }
    /** WorldBossEntity.returnToSleep: the fight is lost, home and healed. */
    function returnToSleep(R) {
        var s = SESS[R.key];
        if (s) { finishDefeat(s); delete SESS[R.key]; }
        R.m.target = null;
        stopAbility(R);
        clearBar(R);
        var ai = AI[R.id];
        if (ai && ai.onReturnToSleep && ai.onReturnToSleep(R)) return;        // reverted to another form
        applyFixedStats(R);
        var h = home(R);
        R.m.teleport(h.x, h.y, h.z);
        fallAsleep(R);
    }
    /** Turns a live boss into another body in place (Janemba <-> Super Janemba, Tamagami powered / base, Gomah sizes). */
    function transformTo(R, bodyId, opts) {
        opts = opts || {};
        var m = R.m, nb = BODIES[bodyId];
        stopAbility(R);
        delete RT[R.uuid];
        DMZ_SAGA.onDeath(m);                            // a fresh brain for the new body's kit
        m.transform(bodyId, { heal: true });
        if (R.asleep) m.addTag("dmz_wb_asleep"); else m.removeTag("dmz_wb_asleep");
        NO_ENGAGE = true;                               // a new form never opens a fight on its own (Tamagami's subdue)
        var NR;
        try { NR = rt(m); } finally { NO_ENGAGE = false; }
        if (!NR) return R;
        NR.anchor = R.anchor; NR.group = 0; NR.asleep = R.asleep;
        if (opts.keepState) { NR.s = R.s; NR.mult = R.mult; NR.kiMult = R.kiMult; }
        if (!opts.keepState && AI[bodyId] && AI[bodyId].init) AI[bodyId].init(NR);
        var s = SESS[NR.key];
        m.maxHealth = nb.hp;
        applyFixedStats(NR);
        if (s && !NR.asleep) applyGroupScaling(NR, s.members || 1);
        if (typeof opts.fraction === "number") m.health = Math.max(1, m.maxHealth * opts.fraction);
        var L = state()[NR.key];
        if (L) { L.uuid = String(m.uuid); saveState(); }
        if (!NR.asleep) { DMZ_SAGA.freeze(m, false); try { m.setAI(true); } catch (e) { } }
        return NR;
    }

    // ---- abilities (startBossAbility / stopBossAbility / tickBossAbility) ----
    function startAbility(R, id) {
        if (R.ab || R.asleep || now() < R.tfUntil || DMZ_SAGA.busy(R.m) || now() < (R.stunUntil || 0)) return false;
        R.ab = id; R.abT = 0;
        DMZ_SAGA.freeze(R.m, true);
        try { R.m.setAI(false); } catch (e) { }
        return true;
    }
    function stopAbility(R) {
        var id = R.ab;
        if (!id) return;
        R.ab = null; R.abT = 0;
        try { R.m.setNoGravity(false); } catch (e) { }
        if (!R.asleep && !R.resting) { DMZ_SAGA.freeze(R.m, false); try { R.m.setAI(true); } catch (e) { } R.m.stopAnimation(); }
        var ai = AI[R.id];
        if (ai && ai.onStop) ai.onStop(R, id);
    }
    /** setBossResting: the sleep pose while awake (Janemba while his minis fight, downed). */
    function setResting(R, on) {
        if (R.resting === on) return;
        R.resting = on;
        if (on) { DMZ_SAGA.freeze(R.m, true); try { R.m.setAI(false); } catch (e) { } R.m.playAnimation(R.body.sleep, "loop"); }
        else if (!R.ab) { DMZ_SAGA.freeze(R.m, false); try { R.m.setAI(true); } catch (e) { } R.m.stopAnimation(); }
    }

    // ---- boss bar (WorldBossEntity.updateBossBar: NOTCHED_10, eligible players within 64 of the anchor) ----
    function barPlayers(R) {
        var h = home(R);
        return RPG.server.players().filter(function (p) {
            return p.dimension === R.m.dimension && eligible(p) && Math.pow(p.x - h.x, 2) + Math.pow(p.y - h.y, 2) + Math.pow(p.z - h.z, 2) < LEASH * LEASH;
        });
    }
    function barName(R) { var ai = AI[R.id]; return ai && ai.barName ? ai.barName(R) : R.body.name; }
    function updateBar(R, full) {
        var prog = Math.min(1, Math.max(0, R.m.health / R.m.maxHealth));
        var color = AI[R.id] && AI[R.id].barColor ? AI[R.id].barColor(R) : R.body.bar;
        if (full) RPG.ui.bossBar("dmz_wb_" + R.key, { name: barName(R), color: color, style: "10", progress: prog, players: barPlayers(R) });
        else RPG.ui.bossBarProgress("dmz_wb_" + R.key, prog);
    }
    function clearBar(R) { try { RPG.ui.removeBossBar("dmz_wb_" + R.key); } catch (e) { } }

    /** WorldBossEntity.hasEngagedPlayer */
    function hasEngagedPlayer(R) {
        var m = R.m, h = home(R), s = SESS[R.key];
        var players = RPG.server.players();
        if (s) {
            var range = C("contributionRange");
            for (var u in s.part) {
                var P = s.part[u];
                if (P.ko) continue;
                var p = RPG.server.playerByUuid ? RPG.server.playerByUuid(u) : null;
                p = p || players.filter(function (q) { return String(q.uuid) === u; })[0];
                if (!p || p.dimension !== m.dimension || !p.isAlive()) continue;
                var g = gm(p);
                if (g === "spectator" || g === "creative") continue;
                if (p.distanceTo(m) <= LEASH || Math.pow(p.x - h.x, 2) + Math.pow(p.y - h.y, 2) + Math.pow(p.z - h.z, 2) <= range * range) return true;
            }
        }
        return players.some(function (p) { return p.dimension === m.dimension && eligible(p) && Math.pow(p.x - h.x, 2) + Math.pow(p.y - h.y, 2) + Math.pow(p.z - h.z, 2) < LEASH * LEASH; });
    }
    function scanForIntruder(R) {
        var ai = AI[R.id];
        if (ai && ai.scanWake) return ai.scanWake(R);
        var h = home(R), m = R.m;
        var p = RPG.server.players().filter(function (q) {
            return q.dimension === m.dimension && eligible(q) && created(q) && Math.pow(q.x - h.x, 2) + Math.pow(q.y - h.y, 2) + Math.pow(q.z - h.z, 2) < WAKE * WAKE;
        })[0];
        if (p) wakeUp(R, p);
    }

    // every tick: awake bosses (abilities, bar, leash), fight sessions; sleeping bosses scan once a second
    RPG.every(1, function () {
        var tk = now();
        for (var u in RT) {
            var R = RT[u];
            try {
                if (!alive(R.m)) { dropRt(u); continue; }
                if ((tk - R.born) % 40 === 39) {                         // WorldBossManager.isRegistered: a stale duplicate goes
                    var LR = state()[R.key];
                    if (LR && LR.uuid && LR.uuid !== u) { if (SESS[R.key] && SESS[R.key].uuid === u) { finishDefeat(SESS[R.key]); delete SESS[R.key]; } clearBar(R); delete RT[u]; R.m.remove(); continue; }
                }
                var ai = AI[R.id];
                if (R.asleep) {
                    if ((tk - R.born) % 20 === 0) { scanForIntruder(R); if (ai && ai.sleepTick) ai.sleepTick(R); }
                    continue;
                }
                if (R.ab) {
                    R.abT++;
                    if (ai && ai.tickAbility) ai.tickAbility(R, R.ab, R.abT);
                    if (R.ab && R.abT >= (ai && ai.duration ? ai.duration(R, R.ab) : 0)) stopAbility(R);
                }
                if (!alive(R.m) || RT[u] !== R) continue;
                var stun = tk < (R.stunUntil || 0);                      // MainEffects.STUN holds the brain
                if (stun !== !!R.stunHeld) { R.stunHeld = stun; if (stun) DMZ_SAGA.freeze(R.m, true); else if (!R.ab && !R.resting) DMZ_SAGA.freeze(R.m, false); }
                if (ai && ai.tick) ai.tick(R);
                if (RT[u] !== R || R.asleep) continue;
                if ((tk - R.born) % 20 === 0) {
                    updateBar(R, true);
                    if (!hasEngagedPlayer(R)) { returnToSleep(R); continue; }
                } else if ((tk - R.born) % 4 === 0) updateBar(R, false);
            } catch (err) { RPG.log("DMZ world boss " + R.id + ": " + err + (err.stack ? " " + err.stack : "")); }
        }
        Object.keys(SESS).forEach(function (k) {
            var s = SESS[k];
            try { tickSession(s, tk); } catch (err) { RPG.log("DMZ world boss fight " + k + ": " + err); }
        });
    });

    // every 20 ticks: lairs near players, respawns, keeping a sleeping boss home (WorldBossManager.tickLair)
    RPG.every(20, function () {
        var players = RPG.server.players();
        ORDER.forEach(function (k) {
            var b = BOSSES[k], L = lair(k);
            if (!L) return;
            var c = lairCenter(L);
            var reach = STRUCT[k] ? ACTIVATION + 200 : ACTIVATION;
            var near = c ? players.filter(function (p) { return p.dimension === b.dim && gm(p) !== "spectator" && dist2(p, c.x, c.z) < reach * reach; }) : [];
            try { if (!lairStep(k, L, near.length > 0, players.some(function (p) { return p.dimension === b.dim; }))) return; }
            catch (e) { RPG.log("DMZ world boss lair " + k + ": " + e); return; }
            near = near.filter(function (p) { return dist2(p, L.x, L.z) <= ACTIVATION * ACTIVATION; });
            var m = bossEntity(k);
            if (m) {
                var R = rt(m);
                if (R && R.asleep && !SESS[k]) {
                    var h = home(R);
                    if (Math.pow(m.x - h.x, 2) + Math.pow(m.z - h.z, 2) > 16 || Math.abs(m.y - h.y) > 3) m.teleport(h.x, h.y, h.z);
                }
                return;
            }
            if (!near.length || SESS[k]) return;
            // the saved boss may just not be loaded yet: adopt any body of this boss near the anchor
            var found = RPG.world.entitiesNear(b.dim, L.x, L.y, L.z, 64).filter(function (e) { var eb = bodyOf(e); return eb && eb.key === k && alive(e); })[0];
            if (found) { L.uuid = String(found.uuid); saveState(); rt(found); return; }
            if (Date.now() < (L.next || 0)) return;
            if (!near.some(function (p) { return dist2(p, L.x, L.z) < 48 * 48; })) return;      // its chunk must be loaded and ticking
            spawnBoss(k, L);
        });
    });
    function spawnBoss(k, L) {
        var b = BOSSES[k], m = RPG.world.spawnMob(b.dim, b.mob, L.x + 0.5, L.y, L.z + 0.5);
        if (!m) return null;
        L.uuid = String(m.uuid);
        saveState();
        try { m.setRotation(Math.random() * 360, 0); } catch (e) { }
        m.addTag("dmz_wb_asleep");
        var R = rt(m);
        RPG.log("[DMZ] world boss " + k + " spawned at " + L.x + " " + L.y + " " + L.z);
        return m;
    }
    function storeAnchor(R, a) { R.anchor = a; RPG.data.set("dmz_wb_anchor:" + R.uuid, a); }

    // =========================================================================================
    //  the fight (WorldBossSession + WorldBossContribution)
    // =========================================================================================
    function Session(k, R) {
        this.key = k; this.dim = R.m.dimension; this.start = now(); this.part = {}; this.audience = {}; this.music = {};
        this.casts = {}; this.progress = {}; this.scores = {}; this.dirty = false; this.lastAudience = -1e9; this.lastSync = -1e9;
        this.members = 0; this.ended = false; this.wiping = false; this.uuid = R.uuid; this.nameKey = "entity.dragonminez." + R.body.lang;
        this.bossName = R.body.name; this.missing = 0;
    }
    function engaged(R) {                          // WorldBossManager.onBossEngaged
        var s = SESS[R.key];
        if (s && s.ended) { delete SESS[R.key]; s = null; }
        if (!s) { s = SESS[R.key] = new Session(R.key, R); RPG.log("[DMZ] World boss fight started for " + R.key); }
        attachBoss(s, R);
        return s;
    }
    function attachBoss(s, R) {
        s.uuid = R.uuid; s.nameKey = "entity.dragonminez." + R.body.lang; s.bossName = R.body.name; s.missing = 0;
        if (s.members > 0) applyGroupScaling(R, s.members);
    }
    function sessionBoss(s) { var e = RPG.world.entityByUuid(s.uuid); return alive(e) ? rt(e) : null; }
    function playerByUuid(u) { var r = null; RPG.server.players().forEach(function (p) { if (String(p.uuid) === u) r = p; }); return r; }
    function cfgRange() { return Math.max(16, C("contributionRange")); }

    // ---- scores ----
    function score(s, p) {
        var u = String(p.uuid), sc = s.scores[u];
        if (!sc) sc = s.scores[u] = { id: u, name: p.name, aura: 0xFFFFFF, dmg: [0, 0, 0, 0], mit: [0, 0, 0], recv: {}, heal: [0, 0], healVal: 0 };
        sc.name = p.name;
        var a = String(p.getVar("dmz_aura_color", "") || "");
        if (created(p) && a) { var n = parseInt(a.replace("#", ""), 16); if (!isNaN(n)) sc.aura = n & 0xFFFFFF; }
        s.dirty = true;
        return sc;
    }
    function sum(a) { var t = 0; for (var i = 0; i < a.length; i++) t += a[i]; return t; }
    function recvTotal(sc) { var t = 0; for (var k in sc.recv) t += sc.recv[k]; return t; }
    function points(sc) {
        return sum(sc.dmg) * C("damageWeight") + sum(sc.mit) * C("mitigatedWeight") + recvTotal(sc) * C("receivedWeight") + sc.healVal * C("healedWeight");
    }
    function healFactor(sc) {
        var taken = recvTotal(sc);
        if (taken <= 0) return 1;
        return Math.min(10, (taken + sc.mit[0] + sc.mit[1]) / taken);
    }
    function snapshot(s) {
        var list = Object.keys(s.scores).map(function (u) { return s.scores[u]; });
        list.sort(function (a, b) { return points(b) - points(a); });
        return list;
    }

    function tickSession(s, tk) {
        if (s.ended) { delete SESS[s.key]; return; }
        var R = sessionBoss(s);
        if (!R) {
            if (++s.missing >= MISSING_BOSS_TICKS) { RPG.log("[DMZ] World boss " + s.key + " vanished mid-fight, ending the fight as lost"); finishDefeat(s); delete SESS[s.key]; }
            return;
        }
        s.missing = 0;
        if (R.asleep) { finishDefeat(s); delete SESS[s.key]; return; }
        if (tk - s.lastAudience >= Math.max(1, C("audienceRefreshSeconds")) * 20) { refreshAudience(s, R); s.lastAudience = tk; }
        tickCasts(s);
        if ((s.dirty && tk - s.lastSync >= 2) || tk % 20 === 0) { s.dirty = false; broadcast(s, false, false); s.lastSync = tk; }
        if (tk % 20 === 0) { enforceKnockouts(s); checkWipe(s, R); }
    }
    function refreshAudience(s, R) {
        var range = cfgRange(), next = {}, members = 0, m = R.m;
        RPG.server.players().forEach(function (p) {
            if (gm(p) === "spectator" || p.dimension !== m.dimension || p.distanceTo(m) > range) return;
            var u = String(p.uuid);
            next[u] = true;
            if (!s.part[u]) join(s, p);
            if (s.part[u] && gm(p) !== "creative") members++;
        });
        s.members = Math.max(1, members);
        applyGroupScaling(R, s.members);
        var changed = Object.keys(next).length !== Object.keys(s.audience).length || Object.keys(next).some(function (u) { return !s.audience[u]; });
        s.audience = next;
        if (changed) broadcast(s, false, false);
        // boss music (RaidMusicS2C, played once at 0.5)
        Object.keys(s.music).forEach(function (u) {
            if (s.audience[u]) return;
            delete s.music[u];
            var p = playerByUuid(u);
            if (p) RPG.net.send(p, "dmz_wb_music", { id: "" });
        });
        Object.keys(s.audience).forEach(function (u) {
            if (!s.part[u] || s.music[u]) return;
            s.music[u] = true;
            var p = playerByUuid(u);
            if (p) RPG.net.send(p, "dmz_wb_music", { id: "dmzpack:worldboss_music." + s.key });
        });
    }
    function join(s, p) {
        if (!created(p)) return;
        var P = s.part[String(p.uuid)] = { id: String(p.uuid), name: p.name, lives: Math.floor(C("lives")), ko: false };
        installRevive(p);
        sendPlayerState(s, p, P);
    }
    function reviveSlot() { return Math.max(0, Math.min(7, Math.floor(C("reviveSlot")) - 1)); }
    function installRevive(p) { if (typeof DMZ_TECH !== "undefined" && DMZ_TECH.installRevive) DMZ_TECH.installRevive(p, reviveSlot()); }
    function uninstallRevive(p) { if (typeof DMZ_TECH !== "undefined" && DMZ_TECH.uninstallRevive) DMZ_TECH.uninstallRevive(p); }

    function broadcast(s, finished, cleared) {
        var scores = snapshot(s), total = 0;
        scores.forEach(function (sc) { total += points(sc); });
        var entries = [];
        scores.forEach(function (sc) {
            var pts = points(sc);
            if (entries.length >= 32 || pts <= 0) return;
            entries.push({ id: sc.id, name: sc.name, points: pts, share: total > 0 ? pts / total : 0, aura: sc.aura, ko: !!(s.part[sc.id] && s.part[sc.id].ko) });
        });
        var data = { key: s.key, nameKey: s.nameKey, name: s.bossName, elapsed: now() - s.start, finished: !!finished, cleared: !!cleared, entries: entries,
            linger: C("meterLingerSeconds") };
        var to = {};
        Object.keys(s.audience).forEach(function (u) { to[u] = true; });
        if (finished || cleared) Object.keys(s.part).forEach(function (u) { to[u] = true; });
        Object.keys(to).forEach(function (u) { var p = playerByUuid(u); if (p) RPG.net.send(p, "dmz_wb_contrib", data); });
    }
    function reviversOf(s, target) { return Object.keys(s.casts).filter(function (c) { return s.casts[c].target === target; }).map(function (c) { return nameOf(s, c); }); }
    function nameOf(s, u) { return s.part[u] ? s.part[u].name : ""; }
    function castTicks() { return Math.max(1, Math.floor(C("reviveCastSeconds"))) * 20; }
    function castProgress(s, target) { return Math.min(1, (s.progress[target] || 0) / castTicks()); }
    function sendPlayerState(s, p, P) {
        var u = String(p.uuid), own = s.casts[u], revivers = reviversOf(s, u);
        RPG.net.send(p, "dmz_wb_player", { active: true, ko: P.ko, lives: P.lives, casting: !!own, progress: own ? castProgress(s, own.target) : revivers.length ? castProgress(s, u) : 0,
            target: own ? nameOf(s, own.target) : "", revived: revivers.length > 0, reviver: revivers.join(", ") });
    }
    function sendCleared(p) { RPG.net.send(p, "dmz_wb_player", { active: false }); }
    function title(p, t, sub, seconds) {
        RPG.net.send(p, "dmz_wb_title", { title: t, sub: sub, fadeIn: 10, stay: Math.max(1, seconds * 20 - 20), fadeOut: 10 });
    }
    function chat(p, key, args, color) { RPG.net.send(p, "dmz_wb_chat", { key: key, args: args || [], color: color || null }); }
    function bar(p, key, args, color) { RPG.net.send(p, "dmz_msg", { key: key, args: args || [], color: color || "#FFFFFF" }); }

    // ---- knock-outs (WorldBossSession.knockOut) ----
    function activeFor(p) {
        var u = String(p.uuid);
        for (var k in SESS) if (!SESS[k].ended && SESS[k].part[u]) return SESS[k];
        return null;
    }
    function applyKnockout(p) {
        p.addEffect("knocked_down", KNOCKOUT_TICKS);
        if (typeof DMZ_TF !== "undefined") {                          // clearActiveForm + clearActiveStackForm
            try { if (p.getVar("dmz_stack", "")) DMZ_TF.setStack(p, null, null); if (p.getVar("dmz_form", "")) DMZ_TF.setForm(p, null, null); } catch (e) { }
        }
        if (typeof DMZ_TECH !== "undefined") { try { DMZ_TECH.cancel(p); } catch (e) { } }
        p.addPotion("minecraft:glowing", KNOCKOUT_TICKS, 0);
    }
    function clearKnockout(p) { p.removeEffect("knocked_down"); p.removePotion("minecraft:glowing"); }
    function knockOut(s, p) {
        if (s.ended || s.wiping) return false;
        var P = s.part[String(p.uuid)];
        if (!P || P.ko) return false;
        P.ko = true;
        applyKnockout(p);
        interruptCast(s, p, false);
        title(p, { key: "worldboss.dragonminez.knockout.title", color: "#FF5555" }, { key: "worldboss.dragonminez.knockout.subtitle", args: [P.lives], color: "#AAAAAA" }, Math.max(1, C("knockoutTitleSeconds")));
        RPG.world.sound(p.dimension, "dmzpack:knockback_character", p.x, p.y, p.z, 1.0, 0.7);
        sendPlayerState(s, p, P);
        score(s, p);
        RPG.log("[DMZ] " + P.name + " was knocked out in the " + s.key + " fight (" + P.lives + " revives left)");
        RPG.schedule(1, function () { var R = sessionBoss(s); if (R && !s.ended) checkWipe(s, R); });   // after this hit is cancelled
        return true;
    }
    function enforceKnockouts(s) {
        Object.keys(s.part).forEach(function (u) {
            var P = s.part[u], p = playerByUuid(u);
            if (!p) return;
            if (p.dimension !== s.dim) { leftFight(s, p); return; }       // onPlayerChangedDimension
            if (typeof DMZ_TECH !== "undefined" && DMZ_TECH.hasRevive && !DMZ_TECH.hasRevive(p)) installRevive(p);
            if (P.ko && !knockedDown(p)) applyKnockout(p);
        });
    }
    function revive(s, p, P, consumeLife) {
        P.ko = false;
        if (consumeLife) P.lives = Math.max(0, P.lives - 1);
        clearKnockout(p);
        var ratio = Math.max(0, Math.min(1, C("reviveRestoreRatio")));
        REVIVE_HEAL = true;
        try { p.heal(p.maxHealth * ratio); } finally { REVIVE_HEAL = false; }
        try { p.addResource("ki", p.resourceMax("ki") * ratio); p.addResource("stamina", p.resourceMax("stamina") * ratio); } catch (e) { }
        RPG.world.sound(p.dimension, "dmzpack:transform_on", p.x, p.y, p.z, 0.8, 1.3);
        sendPlayerState(s, p, P);
        score(s, p);
    }
    var REVIVE_HEAL = false;

    // ---- Revive casts (tryStartRevive / tickCasts) ----
    function requestRevive(caster, targetEntity) {
        var s = activeFor(caster);
        if (!s || s.ended) return;
        var cu = String(caster.uuid), CE = s.part[cu];
        if (!CE || CE.ko || s.casts[cu] || !caster.isAlive() || gm(caster) === "spectator") return;
        if (caster.hasEffect("stunned")) return;
        if (typeof DMZ_TECH !== "undefined" && (DMZ_TECH.cooldownLeft(caster, "worldboss_revive") > 0 || DMZ_TECH.isCharging(caster))) return;
        var range = Math.max(1, C("reviveRange")), t = resolveReviveTarget(s, caster, targetEntity, range);
        if (!t) { bar(caster, "worldboss.dragonminez.revive.no_target", [], "#FF5555"); return; }
        var TE = s.part[String(t.uuid)];
        if (!TE || !TE.ko) return;
        if (TE.lives <= 0) { bar(caster, "worldboss.dragonminez.revive.no_lives", [TE.name], "#FF5555"); return; }
        s.casts[cu] = { caster: cu, target: String(t.uuid), x: caster.x, y: caster.y, z: caster.z, ticks: 0, taken: 0 };
        if (s.progress[String(t.uuid)] === undefined) s.progress[String(t.uuid)] = 0;
        sendPlayerState(s, caster, CE);
        sendPlayerState(s, t, TE);
        RPG.world.sound(caster.dimension, "dmzpack:ki_charge_loop", caster.x, caster.y, caster.z, 0.6, 1.2);
    }
    function resolveReviveTarget(s, caster, direct, range) {
        function downed(p) { return p && p.uuid !== caster.uuid && p.isAlive() && s.part[String(p.uuid)] && s.part[String(p.uuid)].ko && p.dimension === caster.dimension; }
        if (direct && downed(direct) && caster.distanceTo(direct) <= range) return direct;
        var best = null, bd = 1e9, yaw = caster.yaw * Math.PI / 180, pitch = caster.pitch * Math.PI / 180;
        var dx = -Math.sin(yaw) * Math.cos(pitch), dy = -Math.sin(pitch), dz = Math.cos(yaw) * Math.cos(pitch);
        var cand = RPG.server.players().filter(downed);
        cand.forEach(function (p) {                                  // a look ray against each body inflated by 0.6
            var ox = p.x - caster.x, oy = p.y + 0.9 - caster.eyeY, oz = p.z - caster.z, along = ox * dx + oy * dy + oz * dz;
            if (along < 0 || along > range) return;
            var px = ox - dx * along, py = oy - dy * along, pz = oz - dz * along;
            if (Math.abs(px) <= 0.9 && Math.abs(pz) <= 0.9 && Math.abs(py) <= 1.5 && along < bd) { best = p; bd = along; }
        });
        if (best) return best;
        cand.forEach(function (p) { var d = caster.distanceTo(p); if (d <= range && d < bd) { best = p; bd = d; } });
        return best;
    }
    function tickCasts(s) {
        if (!Object.keys(s.casts).length && !Object.keys(s.progress).length) return;
        var slack = Math.max(1, C("reviveRange")) * 1.5;
        Object.keys(s.casts).forEach(function (cu) {
            var c = s.casts[cu], caster = playerByUuid(c.caster), target = playerByUuid(c.target), CE = s.part[c.caster], TE = s.part[c.target];
            if (!caster || !target || !CE || !TE || caster.dimension !== s.dim || target.dimension !== s.dim || !TE.ko || CE.ko) { cancelCast(s, c, caster, target, false); return; }
            if (caster.hasEffect("stunned") || !caster.isAlive()) { cancelCast(s, c, caster, target, true); return; }
            var mx = caster.x - c.x, my = caster.y - c.y, mz = caster.z - c.z;
            if (mx * mx + my * my + mz * mz > 1 || caster.distanceTo(target) > slack) { cancelCast(s, c, caster, target, true); return; }
            c.ticks++;
            s.progress[c.target] = (s.progress[c.target] || 0) + 1;
        });
        var decay = Math.max(1, Math.round(Math.max(1, C("reviveDecayMultiplier"))));
        Object.keys(s.progress).forEach(function (t) {
            var TE = s.part[t];
            if (!TE || !TE.ko) { delete s.progress[t]; return; }
            if (reviversOf(s, t).length) return;
            var left = s.progress[t] - decay;
            if (left <= 0) delete s.progress[t]; else s.progress[t] = left;
        });
        Object.keys(s.progress).forEach(function (t) { if (s.progress[t] >= castTicks()) completeRevive(s, t); });
        Object.keys(s.casts).forEach(function (cu) { var p = playerByUuid(cu); if (p && s.part[cu]) sendPlayerState(s, p, s.part[cu]); });
        Object.keys(s.progress).forEach(function (t) { var p = playerByUuid(t); if (p && s.part[t]) sendPlayerState(s, p, s.part[t]); });
    }
    function completeRevive(s, t) {
        var target = playerByUuid(t), TE = s.part[t];
        delete s.progress[t];
        var done = Object.keys(s.casts).filter(function (cu) { return s.casts[cu].target === t; });
        done.forEach(function (cu) { delete s.casts[cu]; });
        if (!target || !TE || !TE.ko) { done.forEach(function (cu) { var p = playerByUuid(cu); if (p && s.part[cu]) sendPlayerState(s, p, s.part[cu]); }); return; }
        var names = [];
        done.forEach(function (cu) {
            var caster = playerByUuid(cu), CE = s.part[cu];
            if (!caster || !CE) return;
            names.push(CE.name);
            if (typeof DMZ_TECH !== "undefined") { DMZ_TECH.setCooldown(caster, "worldboss_revive", Math.floor(C("reviveCooldownSeconds")) * 20); DMZ_TECH.sendState(caster); }
            bar(caster, "worldboss.dragonminez.revive.done", [TE.name], "#55FF55");
            sendPlayerState(s, caster, CE);
        });
        revive(s, target, TE, true);
        bar(target, "worldboss.dragonminez.revive.revived", [names.join(", ")], "#55FF55");
        RPG.log("[DMZ] " + names.join(", ") + " revived " + TE.name + " in the " + s.key + " fight (" + TE.lives + " revives left)");
    }
    function cancelCast(s, c, caster, target, penalize) {
        delete s.casts[c.caster];
        if (caster) {
            if (penalize) {
                if (typeof DMZ_TECH !== "undefined") { DMZ_TECH.setCooldown(caster, "worldboss_revive", Math.floor(C("reviveInterruptCooldownSeconds")) * 20); DMZ_TECH.sendState(caster); }
                bar(caster, "worldboss.dragonminez.revive.interrupted", [], "#FF5555");
            }
            if (s.part[c.caster]) sendPlayerState(s, caster, s.part[c.caster]);
        }
        if (target && s.part[c.target]) sendPlayerState(s, target, s.part[c.target]);
    }
    function interruptCast(s, caster, penalize) {
        var c = s.casts[String(caster.uuid)];
        if (c) cancelCast(s, c, caster, playerByUuid(c.target), penalize);
    }

    // ---- wipe / victory / defeat ----
    function checkWipe(s, R) {
        if (s.ended || s.wiping || !Object.keys(s.part).length) return;
        var any = false;
        for (var u in s.part) {
            var p = playerByUuid(u);
            if (!p || p.dimension !== s.dim || gm(p) === "spectator") continue;
            if (!s.part[u].ko) return;
            any = true;
        }
        if (any) wipe(s, R);
    }
    function wipe(s, R) {
        s.wiping = true;
        RPG.log("[DMZ] Every fighter is down: the " + s.key + " world boss fight is lost");
        Object.keys(s.part).forEach(function (u) {                    // killKnockedOut
            var P = s.part[u];
            if (!P.ko) return;
            var p = playerByUuid(u);
            if (!p) return;
            P.ko = false;
            clearKnockout(p);
            chat(p, "worldboss.dragonminez.wipe");
            WIPE_KILL[u] = true;
            try { p.kill(); } catch (e) { p.damageFrom(1e12, null, { kind: "generic_kill" }); }
            delete WIPE_KILL[u];
        });
        broadcast(s, false, true);
        announceDefeat(s, "worldboss.dragonminez.defeat.wipe");
        endSession(s);
        delete SESS[s.key];
        if (R && alive(R.m) && !R.asleep) returnToSleep(R);
    }
    var WIPE_KILL = {};
    function announceDefeat(s, subKey) {
        Object.keys(s.part).forEach(function (u) {
            var p = playerByUuid(u);
            if (p) title(p, { key: "worldboss.dragonminez.defeat.title", color: "#FF5555" }, { key: subKey, args: [{ key: s.nameKey, fallback: s.bossName }], color: "#AAAAAA" }, RESULT_TITLE_SECONDS);
        });
    }
    function finishDefeat(s) {
        if (s.ended) return;
        s.wiping = true; s.casts = {}; s.progress = {};
        Object.keys(s.part).forEach(function (u) {                    // releaseKnockedOut
            var P = s.part[u];
            if (!P.ko) return;
            var p = playerByUuid(u);
            if (!p) { P.ko = false; return; }
            revive(s, p, P, false);
            chat(p, "worldboss.dragonminez.reset_release");
        });
        broadcast(s, false, true);
        announceDefeat(s, "worldboss.dragonminez.defeat.reset");
        endSession(s);
        RPG.log("[DMZ] World boss " + s.key + " fight ended without a kill");
    }
    function endSession(s) {
        var engagedSet = Object.keys(s.part).filter(function (u) { return s.part[u].ko || !!s.scores[u]; });
        TRUCES[s.key] = engagedSet.length >= 2 ? { members: engagedSet, until: now() + Math.floor(C("truceGraceSeconds")) * 20 } : null;
        s.ended = true;
        endMusic(s, false);
        s.casts = {}; s.progress = {};
        Object.keys(s.part).forEach(function (u) { var p = playerByUuid(u); if (!p) return; uninstallRevive(p); sendCleared(p); });
    }
    function endMusic(s, victory) {
        Object.keys(s.music).forEach(function (u) { var p = playerByUuid(u); if (p) RPG.net.send(p, "dmz_wb_music", { id: victory ? VICTORY_MUSIC : "" }); });
        s.music = {};
    }
    var TRUCES = {};
    function truceAllies(a, b) {
        if (!a || !b || a === b) return false;
        for (var k in SESS) {
            var s = SESS[k];
            if (s.ended) continue;
            var ea = s.part[a], eb = s.part[b];
            if (ea && eb && (ea.ko || s.scores[a]) && (eb.ko || s.scores[b])) return true;
        }
        var t = now();
        for (var k2 in TRUCES) {
            var tr = TRUCES[k2];
            if (!tr || t >= tr.until) { delete TRUCES[k2]; continue; }
            if (tr.members.indexOf(a) >= 0 && tr.members.indexOf(b) >= 0) return true;
        }
        return false;
    }
    function finishVictory(s, R) {
        if (s.ended) return;
        attachBoss(s, R);
        s.casts = {};
        Object.keys(s.part).forEach(function (u) {
            var P = s.part[u];
            if (!P.ko) return;
            var p = playerByUuid(u);
            if (!p) { P.ko = false; return; }
            revive(s, p, P, false);
        });
        var results = grantAndBuild(s, R, now() - s.start);
        storeResults(results);
        broadcast(s, true, false);
        announceVictory(s, results);
        endMusic(s, true);
        endSession(s);
        RPG.log("[DMZ] World boss " + s.key + " defeated after " + (now() - s.start) + " ticks by " + results.players.length + " contributors");
    }
    function announceVictory(s, res) {
        var notified = {};
        Object.keys(s.part).forEach(function (u) { notified[u] = true; });
        Object.keys(s.audience).forEach(function (u) { notified[u] = true; });
        Object.keys(notified).forEach(function (u) {
            var p = playerByUuid(u);
            if (!p) return;
            var e = res.players.filter(function (x) { return x.id === u; })[0], sub;
            if (!e) sub = { key: "worldboss.dragonminez.victory.subtitle_none", color: "#AAAAAA" };
            else if (e.rank === 0) sub = { key: "worldboss.dragonminez.victory.subtitle_mvp", args: [oneDecimal(e.share * 100)], color: "#FFAA00" };
            else sub = { key: "worldboss.dragonminez.victory.subtitle", args: [e.rank + 1, oneDecimal(e.share * 100)], color: "#FFFF55" };
            title(p, { key: "worldboss.dragonminez.victory.title", args: [{ key: s.nameKey, fallback: s.bossName }], color: "#FFAA00" }, sub, RESULT_TITLE_SECONDS);
        });
    }
    function group(intPart) { return String(intPart).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
    function fmtDec(v, places, grouping) {           // DecimalFormat "#,##0.#" / "0.##": trailing zeros trimmed
        var f = Math.pow(10, places), r = Math.round(Math.abs(v) * f) / f, ip = Math.floor(r), fp = Math.round((r - ip) * f);
        var out = (grouping ? group(ip) : String(ip)) + (fp > 0 ? "." + String(fp + f).substring(1).replace(/0+$/, "") : "");
        return (v < 0 && r > 0 ? "-" : "") + out;
    }
    function oneDecimal(v) { return fmtDec(v, 1, true); }           // NumberFormattingUtil.formatUpToOneDecimal
    function largeNumber(n) {                                        // NumberFormattingUtil.formatLargeNumber
        n = Number(n) || 0;
        if (n <= 999) return fmtDec(n, 2, true);
        var suf = ["K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc"], i = suf.length - 1;
        while (i > 0 && n < Math.pow(10, 3 * (i + 1))) i--;
        return fmtDec(n / Math.pow(10, 3 * (i + 1)), 2, false) + suf[i];
    }

    // =========================================================================================
    //  rewards and results (WorldBossRewards / WorldBossResults)
    // =========================================================================================
    var RESULTS = { latest: null, byPlayer: {} };
    function storeResults(res) {
        var st = { res: res, at: Date.now() };
        RESULTS.latest = st;
        res.players.forEach(function (e) { RESULTS.byPlayer[e.id] = st; });
    }
    function getResults(u) {
        var t = Date.now();
        Object.keys(RESULTS.byPlayer).forEach(function (k) { if (t - RESULTS.byPlayer[k].at > RESULTS_MS) delete RESULTS.byPlayer[k]; });
        var st = RESULTS.byPlayer[u] || RESULTS.latest;
        return st && t - st.at <= RESULTS_MS ? st.res : null;
    }
    function rewardJson(r) {                        // the reward as the results screen shows it (name, icon)
        var o = { type: r.type, chance: r.chance };
        if (r.type === "ATTRIBUTES") o.amount = r.amount;
        if (r.type === "ITEM") { o.item = itemId(r.item); o.count = r.count || 1; o.itemName = itemName(r.item); }
        if (r.type === "SKILL") { o.skill = r.skill; o.level = r.level || 1; }
        return o;
    }
    function itemId(ref) { try { return RPG.items.exists(ref) ? String(RPG.items.id ? RPG.items.id(ref) : ref) : ref; } catch (e) { return ref; } }
    function itemName(ref) { try { return RPG.items.exists(ref) ? RPG.items.name(ref) : ref; } catch (e) { return ref; } }
    function rankBonus(rank) { var b = CFG.rankChanceBonus; return b && rank >= 0 && rank < b.length ? Math.max(0, Number(b[rank]) || 0) : 0; }
    function grantAndBuild(s, R, duration) {
        var rewards = BOSSES[s.key].rewards, scores = snapshot(s), total = 0;
        scores.forEach(function (sc) { total += points(sc); });
        var best = scores.length ? points(scores[0]) : 0, entries = [], rank = 0;
        var minRatio = Math.max(0, Math.min(1, C("guaranteedRewardMinRatio")));
        scores.forEach(function (sc) {
            var pts = points(sc);
            if (pts <= 0 || entries.length >= MAX_RESULTS) return;
            var share = total > 0 ? pts / total : 0, ok = share >= Math.max(0, Math.min(1, C("minContributionShare")));
            var p = playerByUuid(sc.id), ratio = minRatio + (1 - minRatio) * (best > 0 ? pts / best : 0);
            var chances = [], amounts = [], granted = [];
            rewards.forEach(function (r, j) {
                var guaranteed = r.chance >= 1, ch = guaranteed ? 1 : Math.min(1, r.chance * (1 + rankBonus(rank)));
                chances[j] = ch; amounts[j] = 0;
                if (!ok || !p) return;
                if (!guaranteed && Math.random() >= ch) return;
                amounts[j] = grant(p, r, guaranteed ? ratio : 1);
                granted.push(describe(r, amounts[j]));
            });
            entries.push({ id: sc.id, name: sc.name, rank: rank, points: pts, share: share, aura: sc.aura,
                dmg: sc.dmg.slice(), mit: sc.mit.slice(), recv: Object.keys(sc.recv).sort(function (a, b) { return sc.recv[b] - sc.recv[a]; }).slice(0, 8).map(function (k) { return { key: k, amount: sc.recv[k] }; }),
                heal: sc.heal.slice(), healVal: sc.healVal, chances: chances, amounts: amounts });
            if (p) {
                var pc = largeNumber(pts), pct = oneDecimal(share * 100), more = { key: "worldboss.dragonminez.results.more_info", color: "#55FFFF", underline: true,
                    command: "/rpgc worldboss results", hover: "worldboss.dragonminez.results.more_info_hover" };
                if (!ok) RPG.net.send(p, "dmz_wb_chat", { key: "worldboss.dragonminez.results.not_eligible", args: [pc, pct], more: more });
                else if (!granted.length) RPG.net.send(p, "dmz_wb_chat", { key: "worldboss.dragonminez.results.nothing", args: [pc, pct], more: more });
                else RPG.net.send(p, "dmz_wb_chat", { key: "worldboss.dragonminez.results.received", args: [{ list: granted }, pc, pct], more: more });
            }
            rank++;
        });
        return { key: s.key, nameKey: s.nameKey, name: s.bossName, duration: duration, victory: true, rewards: rewards.map(rewardJson), players: entries };
    }
    function describe(r, amount) {                 // WorldBossRewardText.describe, translated on the client
        if (r.type === "ITEM") return { key: "worldboss.dragonminez.results.item", args: [Math.max(1, Math.round(amount)), itemName(r.item)] };
        if (r.type === "ATTRIBUTES") return { key: "worldboss.dragonminez.results.attributes", args: [Math.round(amount)] };
        if (r.type === "SKILL") return { skill: r.skill };
        return { text: r.type };
    }
    function grant(p, r, ratio) {
        if (r.type === "ATTRIBUTES") {                 // AttributesReward.scaledAmount + StatsData.grantAttributeReward
            var attrs = Math.max(0, Math.round(r.amount * ratio)), pts = Math.max(0, Math.min(attrs, Math.floor(attrs * 0.5)));
            if (attrs <= 0) return 0;
            if (pts > 0) p.setStatPoints(p.getStatPoints() + pts);
            try {
                var c = DMZ_DATA.CLASSES[p.playerClass] || DMZ_DATA.CLASSES.warrior;
                var tp = DMZ_F.cost(DMZ_F.total(dmzView(p)) + p.getStatPoints(), attrs - pts, c.tpCost);
                if (tp > 0) p.addTp(tp, { raw: true, events: false, source: "boss" });
            } catch (e) { }
            return attrs;
        }
        if (r.type === "ITEM") {                       // ItemReward.scaledCount
            var n = (r.count || 1) <= 0 ? 0 : Math.max(1, Math.round((r.count || 1) * ratio));
            if (RPG.items.exists(r.item)) p.giveItem(r.item, n); else p.tell("&7(" + r.item + " is not in this game)");
            return n;
        }
        if (r.type === "SKILL") {                      // SkillReward: the skill level + the technique
            var id = String(r.skill).toLowerCase();
            if (typeof DMZ_SKILLS !== "undefined") { try { DMZ_SKILLS.setLevel(p, id, Math.max(DMZ_SKILLS.level(p, id), r.level || 1), "worldboss"); } catch (e) { } }
            if (typeof DMZ_TECH !== "undefined") DMZ_TECH.unlock(p, id, { source: "worldboss" });
            return r.level || 1;
        }
        return 1;
    }

    // =========================================================================================
    //  death, damage and healing (WorldBossCombatEvents)
    // =========================================================================================
    function onBossDeath(m, killer) {
        var b = BODIES[String(m.rpgId)];
        if (!b) return;
        var k = b.key, R = RT[String(m.uuid)], L = state()[k];
        if (R && AI[R.id] && AI[R.id].onDeath) { try { AI[R.id].onDeath(R); } catch (err) { RPG.log("DMZ world boss " + R.id + " onDeath: " + err); } }   // the fight still gets its rewards
        var s = SESS[k];
        if (s && String(s.uuid) === String(m.uuid) && R) { finishVictory(s, R); delete SESS[k]; }
        if (R) clearBar(R);
        dropRt(String(m.uuid));
        if (L && L.uuid === String(m.uuid)) {
            L.uuid = null; L.next = Date.now() + RESPAWN_TICKS * 50; saveState();
            RPG.log("[DMZ] World boss " + k + " defeated, respawning in " + RESPAWN_TICKS + " ticks");
        }
        RPG.data.remove("dmz_wb_anchor:" + String(m.uuid));
    }
    /** WorldBossManager.onBossSubdued (Tamagami): the fight is won, the boss stays and sleeps out its timer. */
    function onSubdued(R) {
        var s = SESS[R.key], L = state()[R.key];
        if (s) { finishVictory(s, R); delete SESS[R.key]; }
        if (L) { L.next = Date.now() + RESPAWN_TICKS * 50; L.uuid = String(R.m.uuid); saveState(); }
    }
    /** WorldBossCombatEvents.resolveBossKey */
    function factionKey(e) {
        var b = bodyOf(e);
        if (b) return b.key;
        var mi = minionOf(e);
        return mi ? mi.owner : null;
    }
    function attackerLang(e) { var b = bodyOf(e) || minionOf(e); return b ? "entity.dragonminez." + b.lang : ""; }
    function classify(e) {
        var k = String(e.kind || "");
        if (k === "strike") return 1;
        if (k === "ki") return 2;
        if (k === "melee" && !e.projectile) return 0;
        return 3;
    }
    RPG.on("damageFinal", function (e) {
        var t = e.target, a = e.attacker;
        if (!t || e.isCancelled()) return;
        if (t.isPlayer()) {
            var tp = t.asPlayer();
            if (a && a.isPlayer() && truceAllies(String(a.uuid), String(t.uuid))) { e.cancel(); return; }      // onTruceAttack
            var fk = a ? factionKey(a) : null;
            if (fk) {
                var sf = SESS[fk];
                if (sf && !sf.ended && sf.part[String(tp.uuid)]) {
                    var sc = score(sf, tp), mit = typeof DMZ_MITIGATION !== "undefined" ? DMZ_MITIGATION[t.uuid] : null;
                    if (mit && mit.tick === now()) { sc.mit[0] += mit.def; sc.mit[1] += mit.block; }
                    var got = Math.min(e.amount, tp.health), lang = attackerLang(a);
                    if (got > 0) sc.recv[lang] = (sc.recv[lang] || 0) + got;
                }
            }
            if (e.amount > 0) {                                            // onCasterDamaged
                var sc2 = activeFor(tp);
                if (sc2) {
                    var c = sc2.casts[String(tp.uuid)];
                    if (c) { c.taken += Math.min(e.amount, tp.health); if (c.taken >= tp.maxHealth * Math.max(0.01, C("reviveInterruptDamageRatio"))) interruptCast(sc2, tp, true); }
                }
            }
            return;
        }
        var R = isBoss(t) ? RT[String(t.uuid)] || rt(t) : null;
        if (R) {
            var ai = AI[R.id];
            if (ai && ai.hurt && ai.hurt(R, e) === false) { e.cancel(); return; }
            if (now() < R.tfUntil) { e.cancel(); return; }                 // transforming
            if (e.isCancelled()) return;
        }
        var key = factionKey(t);
        if (!key || !a || !a.isPlayer()) return;
        var s = SESS[key];
        if (!s || s.ended) return;
        var ap = a.asPlayer(), P = s.part[String(ap.uuid)];
        if (P && P.ko) { e.cancel(); return; }
        var applied = Math.min(e.amount, t.health);
        if (applied > 0 && isFinite(applied)) score(s, ap).dmg[classify(e)] += applied;
        if (R && AI[R.id] && AI[R.id].afterHurt) AI[R.id].afterHurt(R, e, ap);
    });
    RPG.on("heal", function (ent, amount) {
        if (!ent || !ent.isPlayer() || !(amount > 0) || REVIVE_HEAL) return;
        var p = ent.asPlayer(), s = activeFor(p);
        if (!s) return;
        var eff = Math.min(amount, Math.max(0, p.maxHealth - p.health));
        if (eff <= 0) return;
        var sc = score(s, p), f = healFactor(sc);
        sc.heal[0] += eff; sc.healVal += eff * f;
    });
    RPG.on("lethal", function (e) {
        var t = e.target;
        if (!t || e.isCancelled()) return;
        if (t.isPlayer()) {                                               // onPlayerDeath -> tryKnockOut
            var p = t.asPlayer();
            if (WIPE_KILL[String(p.uuid)]) return;
            if (e.type === "minecraft:out_of_world" || e.type === "minecraft:generic_kill") return;
            var s = activeFor(p);
            if (!s || !knockOut(s, p)) return;
            e.cancel();
            p.health = 1;
            return;
        }
        var R = isBoss(t) ? RT[String(t.uuid)] || rt(t) : null;
        if (!R) return;
        if (e.type === "minecraft:out_of_world" || e.type === "minecraft:generic_kill") return;
        if (now() < R.tfUntil) { e.cancel(); t.health = 1; return; }
        var ai = AI[R.id];
        if (ai && ai.lethal && ai.lethal(R, e) === false) { e.cancel(); t.health = Math.max(1, t.health); }
    });
    RPG.on("playerLeave", function (p) {                               // onPlayerLogout
        for (var k in SESS) {
            var s = SESS[k];
            if (s.ended) continue;
            interruptCast(s, p, false);
            var u = String(p.uuid);
            Object.keys(s.casts).forEach(function (cu) { if (s.casts[cu].target === u) cancelCast(s, s.casts[cu], playerByUuid(cu), null, false); });
            delete s.audience[u]; delete s.music[u];
        }
    });
    RPG.on("playerJoin", function (p) {                                // onPlayerLogin
        RPG.schedule(10, function () {
            if (!p.isAlive) return;
            var handled = false;
            for (var k in SESS) {
                var s = SESS[k], P = s.part[String(p.uuid)];
                if (s.ended || !P) continue;
                if (p.dimension !== s.dim) { leftFight(s, p); continue; }
                installRevive(p);
                if (P.ko) applyKnockout(p);
                sendPlayerState(s, p, P);
                handled = true;
            }
            if (!handled) {
                if (typeof DMZ_TECH !== "undefined" && DMZ_TECH.hasRevive && DMZ_TECH.hasRevive(p)) uninstallRevive(p);
                if (p.hasEffect("knocked_down") && p.effectTicks("knocked_down") > 100000) clearKnockout(p);
            }
            sendClientState(p);
        });
    });
    function leftFight(s, p) {                                        // onPlayerLeftFight
        var u = String(p.uuid), P = s.part[u];
        interruptCast(s, p, false);
        delete s.part[u]; delete s.audience[u];
        if (!P) return;
        if (P.ko) clearKnockout(p);
        uninstallRevive(p);
        sendCleared(p);
        if (s.music[u]) { delete s.music[u]; RPG.net.send(p, "dmz_wb_music", { id: "" }); }
    }

    // =========================================================================================
    //  client state (WorldBossStateS2C: lair known / position, respawn ticks) for the Hell Ogre and others
    // =========================================================================================
    function clientState() {
        var out = {};
        ORDER.forEach(function (k) {
            var L = state()[k];
            if (!L) return;
            var remaining = Math.max(0, Math.ceil(((L.next || 0) - Date.now()) / 50));
            out[k] = { known: typeof L.x === "number" && L.x !== null, x: L.x, y: L.y, z: L.z, alive: !!L.uuid && remaining <= 0, respawn: remaining };
        });
        return out;
    }
    function sendClientState(p) { RPG.net.send(p, "dmz_wb_state", clientState()); }
    RPG.every(200, function () { var st = clientState(); RPG.server.players().forEach(function (p) { RPG.net.send(p, "dmz_wb_state", st); }); });

    // =========================================================================================
    //  commands (WorldBossCommand: /dmzworldboss -> /rpgc worldboss)
    // =========================================================================================
    function nearestKey(p) {
        var best = "janemba", bd = Infinity, inDim = false;
        ORDER.forEach(function (k) {
            if (BOSSES[k].dim !== p.dimension) return;
            var L = state()[k], d = L && typeof L.x === "number" && L.x !== null ? dist2(p, L.x + 0.5, L.z + 0.5) : Infinity - 1;
            if (!inDim || d < bd) { best = k; bd = d; inDim = true; }
        });
        return best;
    }
    function formatTicks(t) {
        var sec = Math.floor(t / 20), h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), r = sec % 60;
        if (h > 0) return h + "h " + (m < 10 ? "0" : "") + m + "m";
        if (m > 0) return m + "m " + (r < 10 ? "0" : "") + r + "s";
        return r + "s";
    }
    function statusLine(k) {
        var L = state()[k], remaining = L ? Math.max(0, Math.ceil(((L.next || 0) - Date.now()) / 50)) : 0, st;
        if (remaining > 0) st = { key: "command.dragonminez.worldboss.status.respawn", args: [formatTicks(remaining)], color: "#FFAA00" };
        else if (L && L.uuid) st = { key: "command.dragonminez.worldboss.status.alive", color: "#55FF55" };
        else st = { key: "command.dragonminez.worldboss.status.waiting", color: "#55FFFF" };
        st.pending = !L || !L.built;
        return st;
    }
    RPG.commands.register("worldboss", {
        description: "/rpgc worldboss results | locate [boss] | tp [boss] | reset [boss] | ready [boss] | rebuild [boss] | summon <boss> | hp <percent> | debug",
        suggest: function (p, args) {                   // WorldBossCommand: results for everyone, the rest for operators
            var op = !p || isOp(p);
            if (args.length <= 1) return ["results"].concat(op ? ["locate", "tp", "reset", "ready", "rebuild", "summon", "hp", "debug"] : []);
            if (args.length === 2 && op && ["locate", "tp", "reset", "ready", "rebuild", "summon"].indexOf(String(args[0])) >= 0) return ORDER.slice();
            if (args.length === 2 && op && args[0] === "hp") return ["25", "50", "75", "100"];
            return [];
        },
        run: function (p, args) {
            if (!p) return;
            var sub = String(args[0] || "results"), k = args[1] ? String(args[1]) : null;
            if (sub === "results") {
                var res = getResults(String(p.uuid));
                if (!res) return chat(p, "worldboss.dragonminez.results.none", [], "#FF5555");
                return RPG.net.send(p, "dmz_wb_results", res);
            }
            if (!isOp(p)) return p.tell("&cOperators only.");
            if (sub === "summon") {
                if (!k || !BOSSES[k]) return p.tell("&cBosses: " + ORDER.join(", "));
                var sm = RPG.world.spawnMob(p.dimension, BOSSES[k].mob, p.x + 6, p.y, p.z);
                if (!sm) return;
                if (SESS[k]) { finishDefeat(SESS[k]); delete SESS[k]; }
                sm.addTag("dmz_wb_asleep");
                var SR = rt(sm);
                storeAnchor(SR, { x: sm.x, y: sm.y, z: sm.z });
                var L0 = state()[k];
                if (L0) { L0.next = 0; L0.uuid = String(sm.uuid); saveState(); }
                wakeUp(SR, p);
                return p.tell("&aSummoned " + BOSSES[k].name + " (fight started, its home is here).");
            }
            if (sub === "hp") {                             // testing: set the nearest awake boss to <percent> health
                var pct = Math.max(1, Math.min(100, Number(args[1]) || 100)), nb = null, nd = Infinity;
                Object.keys(RT).forEach(function (u) { var R = RT[u]; if (R.asleep || R.m.dimension !== p.dimension) return; var d = p.distanceTo(R.m); if (d < nd) { nd = d; nb = R; } });
                if (!nb) return p.tell("&cNo awake world boss here.");
                nb.m.health = nb.m.maxHealth * pct / 100;
                return p.tell("&a" + nb.body.name + " set to " + pct + "% health.");
            }
            if (sub === "debug") {                          // live state of the loaded bosses and fights
                Object.keys(RT).forEach(function (u) {
                    var R = RT[u], s = SESS[R.key];
                    p.tell("&7" + R.id + (R.asleep ? " &8asleep" : " &aawake") + " &7hp " + Math.round(R.m.health) + "/" + Math.round(R.m.maxHealth) + " ab " + R.ab + "@" + R.abT +
                        " group " + R.group + " bar " + barPlayers(R).length + (s ? " &efight " + Object.keys(s.part).length + " fighters, " + Object.keys(s.scores).length + " scored" : ""));
                    var h = home(R);
                    p.tell("&8 home " + Math.round(h.x) + " " + Math.round(h.y) + " " + Math.round(h.z) + " you: " + gm(p) + " dim " + (p.dimension === R.m.dimension) +
                        " eligible " + eligible(p) + " d " + Math.round(Math.sqrt(Math.pow(p.x - h.x, 2) + Math.pow(p.y - h.y, 2) + Math.pow(p.z - h.z, 2))));
                });
                return;
            }
            if (sub === "locate" && !k) { ORDER.forEach(function (key) { locate(p, key); }); return; }
            k = k || nearestKey(p);
            if (!BOSSES[k]) return p.tell("&cUnknown world boss: " + k);
            if (sub === "locate") return locate(p, k);
            var L = lair(k);
            if (sub === "tp") {
                if (!L || L.x === null || L.x === undefined) return chat(p, "command.dragonminez.worldboss.not_chosen", [BOSSES[k].name, BOSSES[k].dim], "#FF5555");
                if (L.tp) p.teleportTo(BOSSES[k].dim, L.tp[0] + 0.5, L.tp[1] + 1, L.tp[2] + 0.5);
                else {
                    var bk = BOSSES[k], y = L.y !== null && L.y !== undefined ? L.y + 1 : bk.kind === "hell" ? 95 : bk.kind === "platform" ? DEMON_BANDS[bk.stars].top - 4 : bk.kind === "cradle" ? CRADLE.maxSurface + 20 : 200;
                    p.teleportTo(bk.dim, L.x + 0.5, y, L.z + 0.5);
                }
                return chat(p, "command.dragonminez.worldboss.tp.success", [BOSSES[k].name]);
            }
            if (sub === "reset") {
                var e = bossEntity(k);
                if (SESS[k]) { finishDefeat(SESS[k]); delete SESS[k]; }
                if (e) { dropRt(String(e.uuid)); e.remove(); }
                if (L) { L.uuid = null; L.next = 0; L.phase = L.built ? "ready" : L.phase; saveState(); }
                return p.tell("World boss state cleared for " + BOSSES[k].name + ".");
            }
            if (sub === "rebuild") {
                var nx = L ? L.next : 0; delete state()[k]; saveState(); var L2 = lair(k); if (L2) { L2.next = nx; saveState(); }
                return p.tell("&a" + BOSSES[k].name + "'s lair will be rebuilt.");
            }
            if (sub === "ready") { if (L) { L.next = 0; saveState(); } return p.tell("Respawn cooldown cleared for " + BOSSES[k].name + "."); }
            p.tell("&c/rpgc worldboss results | locate [boss] | tp [boss] | reset [boss] | ready [boss] | rebuild [boss] | summon <boss>");
        }
    });
    function locate(p, k) {
        var b = BOSSES[k], L = lair(k);
        if (!L || L.x === null || L.x === undefined) return chat(p, "command.dragonminez.worldboss.not_chosen", [b.name, b.dim], "#FF5555");
        var coords = L.x + ", " + (L.y === null || L.y === undefined ? "~" : L.y) + ", " + L.z;
        var found = p.dimension === b.dim ? { key: "command.dragonminez.worldboss.locate.found", args: [b.name, coords, Math.floor(Math.sqrt(dist2(p, L.x + 0.5, L.z + 0.5)))] }
            : { key: "command.dragonminez.worldboss.locate.found_elsewhere", args: [b.name, coords, b.dim] };
        found.suggest = "/rpgc worldboss tp " + k;
        RPG.net.send(p, "dmz_wb_chat", found);
        RPG.net.send(p, "dmz_wb_chat", { key: "command.dragonminez.worldboss.locate.status", args: [statusLine(k)], color: "#AAAAAA" });
    }
    function isOp(p) { try { return p.isOp(); } catch (e) { return false; } }

    // =========================================================================================
    //  helpers for the bosses' own fights (77_dmz_world_bosses_ai.js)
    // =========================================================================================
    function fx(R, d, range) {
        var m = R.m, r = range || 128;
        RPG.server.players().forEach(function (p) { if (p.dimension === m.dimension && p.distanceTo(m) <= r) RPG.net.send(p, "dmz_wb_fx", d); });
    }
    function groundHeight(dim, x, z, fromY) {           // AllWorldBossesEntity.groundHeight: first solid block under fromY + 2, + 1
        var ix = Math.floor(x), iz = Math.floor(z);
        for (var y = Math.floor(fromY) + 2; y >= Math.floor(fromY) - 96; y--) {
            var bl = RPG.world.getBlock(dim, ix, y, iz);
            if (bl !== "minecraft:air" && bl !== "minecraft:cave_air" && bl !== "minecraft:void_air") return y + 1;
        }
        return fromY;
    }
    var API = {
        BOSSES: BOSSES, BODIES: BODIES, MINIONS: MINIONS, CFG: CFG, WAKE: WAKE, LEASH: LEASH, GOMAH_SCALES: GOMAH_SCALES,
        now: now, alive: alive, eligible: eligible, created: created, gm: gm, home: home, storeAnchor: storeAnchor,
        melee: meleeOf, ki: kiOf, setMult: setMult, refreshDamage: refreshDamage, applyFixedStats: applyFixedStats,
        startAbility: startAbility, stopAbility: stopAbility, setResting: setResting, fallAsleep: fallAsleep, wakeUp: wakeUp,
        returnToSleep: returnToSleep, transformTo: transformTo, canWake: canWake, onSubdued: onSubdued, session: function (R) { return SESS[R.key] || null; },
        fx: fx, groundHeight: groundHeight, bar: bar, chat: chat, title: title, updateBar: updateBar, setupMob: setupMob, rt: rt,
        factionKey: factionKey, formatTicks: formatTicks, largeNumber: largeNumber, state: state, saveState: saveState, lairData: lairData
    };
    return { BOSSES: BOSSES, API: API, AI: AI, sessions: function () { return SESS; }, lair: lair, isBoss: isBoss,
        bossAlive: function (k) { return !!bossEntity(k); }, requestRevive: requestRevive, clientState: clientState,
        isKnockedOut: function (p) { var s = activeFor(p); return !!s && !!s.part[String(p.uuid)] && s.part[String(p.uuid)].ko; } };
})();
