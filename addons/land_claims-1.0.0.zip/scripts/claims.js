// =====================================================================================
//  Land Claims - claim 16x16 chunks. /claims opens a map: left-click a chunk to claim it,
//  right-click to unclaim. /trust <player> lets friends build. Admins: claims.admin.
//  With the Guilds addon on too, a chunk is either a personal claim or a guild claim, never
//  both: each addon refuses chunks the other owns and only protects its own (see Guilds).
// =====================================================================================
/** Read-only view for other addons (the Guilds addon checks it before claiming). */
var LandClaims = null;
// Shared with the Guilds addon (any addon may add to it, before or after this one loads):
//   exempt: fn(player, blockId, x, y, z, dimension, action "break" | "place") -> true lets that block be broken or placed
//           in claimed land anyway, or used ("interact"), e.g. a quest item that must stay reachable;
//   veto:   fn(dimension, chunkX, chunkZ) -> a reason string to refuse claiming that chunk, or nothing.
var RPG_CLAIM_HOOKS = typeof RPG_CLAIM_HOOKS !== "undefined" && RPG_CLAIM_HOOKS ? RPG_CLAIM_HOOKS : { exempt: [], veto: [] };
function rpgClaimExempt(p, b, x, y, z, dim, action) {
    return RPG_CLAIM_HOOKS.exempt.some((f) => { try { return f(p, b, x, y, z, dim, action) === true; } catch (e) { return false; } });
}
function rpgClaimVeto(dim, cx, cz) {
    for (let i = 0; i < RPG_CLAIM_HOOKS.veto.length; i++) {
        try { let r = RPG_CLAIM_HOOKS.veto[i](dim, cx, cz); if (r) return String(r); } catch (e) { }
    }
    return null;
}
(function () {
    var CLAIMS = {
        maxClaims: 32,                // more with claims.amount.<n> or claims.amount.unlimited
        mapSize: 176,                 // map width/height in the GUI (pixels)
        protectEntities: true,        // animals, item frames, armour stands
        protectExplosions: true
    };
    RPG.perms.group("default", ["claims.use"]);
    RPG.perms.group("vip", ["claims.amount.100"]);
    RPG.perms.group("admin", ["claims.*"]);

    // in memory for fast checks: "dim|cx|cz" -> owner uuid; owners: uuid -> {name, trusted: [uuid...]}
    var BY_CHUNK = {}, OWNERS = {};
    function load() {
        BY_CHUNK = {}; OWNERS = {};
        RPG.data.keys("claim|").forEach((k) => { BY_CHUNK[k.substring(6)] = RPG.data.get(k); });
        RPG.data.keys("claimowner|").forEach((k) => { OWNERS[k.substring(11)] = RPG.data.get(k); });
    }
    load();
    LandClaims = {
        /** Owner of the chunk at block (x, z): {uuid, name} or null. */
        ownerAt: function (dim, x, z) { let o = ownerAt(dim, x, z); return o ? { uuid: o, name: owner(o).name } : null; },
        /** Owner of chunk (cx, cz): {uuid, name} or null. */
        ownerOfChunk: function (dim, cx, cz) { let o = BY_CHUNK[chunkKey(dim, cx, cz)]; return o ? { uuid: o, name: owner(o).name } : null; },
        /** May this player build at block (x, z) as far as personal claims go? */
        allowed: function (p, dim, x, z) { return allowed(p, dim, x, z); }
    };

    function chunkKey(dim, cx, cz) { return dim + "|" + cx + "|" + cz; }
    /** The guild owning a chunk when the Guilds addon is on: {id, name, tag} or null. */
    function guildAt(dim, cx, cz) { return typeof Guilds !== "undefined" && Guilds ? Guilds.ownerOfChunk(dim, cx, cz) : null; }
    function ownerAt(dim, x, z) { return BY_CHUNK[chunkKey(dim, Math.floor(x) >> 4, Math.floor(z) >> 4)]; }
    function owner(uuid) { return OWNERS[uuid] || { name: "?", trusted: [] }; }
    function saveOwner(uuid) { RPG.data.set("claimowner|" + uuid, OWNERS[uuid]); }
    function countOf(uuid) { let n = 0; for (let k in BY_CHUNK) if (BY_CHUNK[k] === uuid) n++; return n; }
    function limit(p) {
        if (RPG.perms.has(p, "claims.amount.unlimited")) return 1e9;
        let n = CLAIMS.maxClaims;
        [50, 100, 200, 500].forEach((v) => { if (RPG.perms.has(p, "claims.amount." + v)) n = Math.max(n, v); });
        return n;
    }

    /** May this player change things at (x, z)? */
    function allowed(p, dim, x, z) {
        let o = ownerAt(dim, x, z);
        if (!o || o === p.uuid || RPG.perms.has(p, "claims.admin.bypass")) return true;
        return owner(o).trusted.indexOf(p.uuid) >= 0;
    }
    function deny(p, dim, x, z) {
        p.actionbar("&cThis land belongs to &f" + owner(ownerAt(dim, x, z)).name);
        return false;
    }

    function claim(p, dim, cx, cz) {
        let k = chunkKey(dim, cx, cz), o = BY_CHUNK[k];
        if (o === p.uuid) { p.actionbar("&7You already own this chunk."); return false; }
        if (o) { p.actionbar("&cOwned by " + owner(o).name); return false; }
        let g = guildAt(dim, cx, cz);
        if (g) { p.actionbar("&cThis land is claimed by the guild &f" + g.name); return false; }
        let veto = rpgClaimVeto(dim, cx, cz);
        if (veto) { p.actionbar("&c" + veto); return false; }
        if (countOf(p.uuid) >= limit(p)) { p.actionbar("&cYou can claim " + limit(p) + " chunks."); return false; }
        BY_CHUNK[k] = p.uuid;
        RPG.data.set("claim|" + k, p.uuid);
        if (!OWNERS[p.uuid]) OWNERS[p.uuid] = { name: p.name, trusted: [] };
        OWNERS[p.uuid].name = p.name;
        saveOwner(p.uuid);
        p.playSound("minecraft:block.note_block.chime", 0.6, 1.4);
        p.actionbar("&aClaimed chunk " + cx + ", " + cz + " &7(" + countOf(p.uuid) + "/" + (limit(p) > 1e8 ? "∞" : limit(p)) + ")");
        return true;
    }
    function unclaim(p, dim, cx, cz) {
        let k = chunkKey(dim, cx, cz), o = BY_CHUNK[k];
        if (!o) return false;
        if (o !== p.uuid && !RPG.perms.has(p, "claims.admin")) { p.actionbar("&cThat's not yours."); return false; }
        delete BY_CHUNK[k];
        RPG.data.remove("claim|" + k);
        p.actionbar("&7Unclaimed chunk " + cx + ", " + cz);
        return true;
    }

    // ---- protection ----
    RPG.on("blockBreak", (p, b, x, y, z, dim) => allowed(p, dim, x, z) || rpgClaimExempt(p, b, x, y, z, dim, "break") || deny(p, dim, x, z));
    RPG.on("blockPlace", (p, b, x, y, z, dim) => allowed(p, dim, x, z) || rpgClaimExempt(p, b, x, y, z, dim, "place") || deny(p, dim, x, z));
    RPG.on("blockInteract", (p, b, x, y, z, dim) => allowed(p, dim, x, z) || rpgClaimExempt(p, b, x, y, z, dim, "interact") || deny(p, dim, x, z));
    RPG.on("entityInteract", (p, e, type, x, y, z, dim) => !CLAIMS.protectEntities || allowed(p, dim, x, z) || deny(p, dim, x, z));
    RPG.on("attack", (e) => {
        // animals and pets in a claim can't be hurt by outsiders
        if (!CLAIMS.protectEntities || !e.attacker || !e.attacker.isPlayer() || e.target.isPlayer()) return;
        let p = e.attacker.asPlayer(), t = e.target;
        if (!allowed(p, t.dimension, t.x, t.z)) { e.cancel(); deny(p, t.dimension, t.x, t.z); }
    });
    RPG.on("explode", (e) => {
        if (CLAIMS.protectExplosions) e.keepBlocks((x, y, z) => !!ownerAt(e.dimension, x, z));
    });

    // entering / leaving claims
    var WHERE = {};
    RPG.on("playerTick", (p) => {
        let o = ownerAt(p.dimension, p.x, p.z) || "";
        if (WHERE[p.uuid] === o) return;
        WHERE[p.uuid] = o;
        if (!o && guildAt(p.dimension, Math.floor(p.x) >> 4, Math.floor(p.z) >> 4)) return;   // the Guilds addon announces its land
        if (o) p.actionbar("&7Entering &f" + (o === p.uuid ? "your land" : owner(o).name + "'s land"));
        else p.actionbar("&7Wilderness");
    });

    // ---- the map ----
    var VIEW = {};    // uuid -> {cx, cz, scale}
    function openMap(p) {
        let v = VIEW[p.uuid] || (VIEW[p.uuid] = { x: Math.floor(p.x), z: Math.floor(p.z), scale: 1 });
        let S = CLAIMS.mapSize, half = S * v.scale / 2;
        let overlays = [], minCx = (v.x - half) >> 4, maxCx = (v.x + half) >> 4, minCz = (v.z - half) >> 4, maxCz = (v.z + half) >> 4;
        for (let cx = minCx; cx <= maxCx; cx++) for (let cz = minCz; cz <= maxCz; cz++) {
            let o = BY_CHUNK[chunkKey(p.dimension, cx, cz)];
            if (!o) {
                let g = guildAt(p.dimension, cx, cz);
                if (g) overlays.push({ x1: cx * 16, z1: cz * 16, x2: cx * 16 + 15, z2: cz * 16 + 15, color: "#50A0A0A0", label: "&7Guild: &f" + g.name });
                continue;
            }
            let mine = o === p.uuid, trusted = !mine && owner(o).trusted.indexOf(p.uuid) >= 0;
            overlays.push({ x1: cx * 16, z1: cz * 16, x2: cx * 16 + 15, z2: cz * 16 + 15,
                color: mine ? "#6033DD44" : trusted ? "#603399FF" : "#60DD3333", label: mine ? "&aYour claim" : "&f" + owner(o).name + (trusted ? " &7(trusted)" : "") });
        }
        let W = S + 16, H = S + 64, step = Math.round(64 * v.scale);
        RPG.ui.open(p, "claims_map", {
            title: "&6Land Claims &7(" + countOf(p.uuid) + "/" + (limit(p) > 1e8 ? "∞" : limit(p)) + ")", width: W, height: H,
            elements: [
                { type: "map", id: "map", x: 8, y: 20, w: S, h: S, centerX: v.x, centerZ: v.z, scale: v.scale, grid: 16, overlays: overlays },
                { type: "text", x: 8, y: S + 24, text: "&7Left-click: claim   Right-click: unclaim", scale: 0.75 },
                { type: "button", id: "w", x: 8, y: S + 34, w: 20, h: 16, text: "<" },
                { type: "button", id: "n", x: 30, y: S + 34, w: 20, h: 16, text: "^" },
                { type: "button", id: "s", x: 52, y: S + 34, w: 20, h: 16, text: "v" },
                { type: "button", id: "e", x: 74, y: S + 34, w: 20, h: 16, text: ">" },
                { type: "button", id: "here", x: 98, y: S + 34, w: 34, h: 16, text: "Here" },
                { type: "button", id: "zin", x: W - 50, y: S + 34, w: 20, h: 16, text: "+" },
                { type: "button", id: "zout", x: W - 28, y: S + 34, w: 20, h: 16, text: "-" }
            ],
            onClick(pl, id, inputs) {
                let vv = VIEW[pl.uuid];
                if (id === "map") {
                    let cx = inputs._x >> 4, cz = inputs._z >> 4;
                    if (inputs._button === "right") unclaim(pl, pl.dimension, cx, cz); else claim(pl, pl.dimension, cx, cz);
                } else if (id === "w") vv.x -= step; else if (id === "e") vv.x += step; else if (id === "n") vv.z -= step; else if (id === "s") vv.z += step;
                else if (id === "here") { vv.x = Math.floor(pl.x); vv.z = Math.floor(pl.z); }
                else if (id === "zin") vv.scale = Math.max(0.5, vv.scale / 2); else if (id === "zout") vv.scale = Math.min(4, vv.scale * 2);
                openMap(pl);
            },
            onClose(pl) { delete VIEW[pl.uuid]; }
        });
    }

    // ---- commands ----
    function cmd(name, desc, run, extra) {
        let def = { root: true, permission: "claims.use", description: desc,
            suggest: (p, args) => args.length <= 1 ? RPG.server.players().map((q) => q.name) : [], run(p, args) { if (p) run(p, args); } };
        if (extra) Object.keys(extra).forEach((k) => { def[k] = extra[k]; });
        RPG.commands.register(name, def);
    }
    cmd("claims", "Open the claim map", (p) => openMap(p), { aliases: ["claimmap"], suggest: () => [] });
    cmd("claim", "Claim the chunk you're standing in", (p) => claim(p, p.dimension, Math.floor(p.x) >> 4, Math.floor(p.z) >> 4), { suggest: () => [] });
    cmd("unclaim", "Unclaim the chunk you're standing in", (p) => { if (!unclaim(p, p.dimension, Math.floor(p.x) >> 4, Math.floor(p.z) >> 4)) p.actionbar("&7Nothing to unclaim here."); }, { suggest: () => [] });
    cmd("unclaimall", "Unclaim all your chunks", (p) => {
        let n = 0;
        Object.keys(BY_CHUNK).forEach((k) => { if (BY_CHUNK[k] === p.uuid) { delete BY_CHUNK[k]; RPG.data.remove("claim|" + k); n++; } });
        p.tell("&7Unclaimed " + n + " chunks.");
    }, { suggest: () => [] });
    cmd("trust", "Let a player build in your claims", (p, args) => {
        let t = RPG.server.player(args[0] || "");
        if (!t) { p.tell("&cThat player isn't online."); return; }
        if (!OWNERS[p.uuid]) OWNERS[p.uuid] = { name: p.name, trusted: [] };
        if (OWNERS[p.uuid].trusted.indexOf(t.uuid) < 0) OWNERS[p.uuid].trusted.push(t.uuid);
        saveOwner(p.uuid);
        p.tell("&a" + t.name + " can now build in your claims.");
        t.tell("&a" + p.name + " trusted you in their claims.");
    });
    cmd("untrust", "Stop trusting a player", (p, args) => {
        let t = RPG.server.player(args[0] || ""), o = OWNERS[p.uuid];
        if (!t || !o) { p.tell("&cThat player isn't online (or you have no claims)."); return; }
        o.trusted = o.trusted.filter((u) => u !== t.uuid);
        saveOwner(p.uuid);
        p.tell("&7" + t.name + " is no longer trusted.");
    });
    cmd("claiminfo", "Who owns this chunk", (p) => {
        let o = ownerAt(p.dimension, p.x, p.z);
        p.tell(o ? "&7This chunk belongs to &f" + owner(o).name + (o === p.uuid ? " &7(you)" : "") : "&7Nobody owns this chunk.");
    }, { suggest: () => [] });
})();
