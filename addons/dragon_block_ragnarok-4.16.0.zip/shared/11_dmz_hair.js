// =====================================================================================
//  Original strand hair: hair codes, presets, per-form styles and the mapping onto the
//  toolkit's strand-hair renderer (avatar `hair` blocks, see api.d.ts > AvatarHair).
//
//  Ported from the original (GPL-3.0, see NOTICE.md) - common/hair/* (HairCodec, CustomHair, HairStrand,
//  HairSegmentOverride, HairLegacyMigrator, HairPoseBuilder, HairPresets, HairStyleSlot,
//  HairPhysicsProfile) and client/render/hair/HairStyleResolver. See NOTICE.md.
//
//  How it fits together
//    - An original hairstyle ("CustomHair") is up to 68 strands on five faces of the head
//      (front 4, back/left/right/top 16 each). Each strand: segments, length, length ratio,
//      width, depth, taper, root offset, rotation, bend, twist, colours, per-segment overrides.
//    - Codes: "DMZ1:"/"DMZF1:" = base62, "DMZ22:"/"DMZF22:" = base64url; both raw-deflated NBT.
//      "F" codes are full sets: one style per slot (base, ssj, ssj2, ssj3, ssj4).
//    - Presets: the original's preset codes, decoded ahead of time with this file's decoder (so nothing is
//      inflated in game) into client/data/dmz_hair_presets/<id>.json (one small file per preset, read
//      only when that preset is first drawn; extra.json holds the named extra styles); their ids and names are in
//      shared/10_dmz_hair_presets.js. DMZ_HAIR.decode(code) still decodes any original hair code.
//    - Players pick a preset: look value hairStyle = "1".."28" (the original hairId; 5 = Krillin = bald).
//    - Each avatar has a hair block whose style is "dmzh{hairStyle}_<slot>"; the client
//      registers those names lazily (RPG.avatar.defineHair) from the preset data, built by
//      DMZ_HAIR.strands() below into the toolkit's generic strand format.
// =====================================================================================
var DMZ_HAIR = (function () {
    var PIXEL = 1;                         // the toolkit takes pixels (the original works in blocks: px / 16)
    var DEG = Math.PI / 180;

    // ---- HairStyleSlot ------------------------------------------------------------------
    var SLOTS = ["base", "ssj", "ssj2", "ssj3", "ssj4"];
    var SLOT_CODE = { base: "B", ssj: "S", ssj2: "S2", ssj3: "T", ssj4: "S4" };
    var SLOT_LEGACY = { base: "Base", ssj: "SSJ", ssj2: "SSJ2", ssj3: "SSJ3", ssj4: "SSJ4" };

    // ---- CustomHair faces ---------------------------------------------------------------
    var FACES = [
        { key: "F", name: "FRONT", max: 4, rows: 1, cols: 4 },
        { key: "B", name: "BACK", max: 16, rows: 4, cols: 4 },
        { key: "L", name: "LEFT", max: 16, rows: 4, cols: 4 },
        { key: "R", name: "RIGHT", max: 16, rows: 4, cols: 4 },
        { key: "T", name: "TOP", max: 16, rows: 4, cols: 4 }
    ];
    var BASE_ROT = { F: [-90, 0, 0], B: [90, 0, 0], L: [0, 0, 90], R: [0, 0, -90], T: [0, 0, 0] };

    function basePosition(fi, index) {
        var face = FACES[fi], row = Math.floor(index / face.cols), col = index % face.cols;
        var P = [-3, -1, 1, 3], Y = [0, -1.5, -3, -4.5];
        var gx = P[col % 4], gz = P[row % 4], ry = Y[row % 4];
        var F = Math.fround;                                  // the original's float constants (3.95f, 7.85f)
        switch (face.key) {
            case "F": return [gx, 7.25, -4];
            case "B": return [gx, F(7.25 + ry), 4];
            case "L": return [F(-3.95), F(7.25 + ry), gx];
            case "R": return [F(3.95), F(7.25 + ry), -gx];
            default: return [gx, F(7.85), gz];
        }
    }

    // ---- small maths (JOML semantics: rotateX etc. post-multiply) -------------------------
    function qid() { return [0, 0, 0, 1]; }
    function qmul(a, b) {
        return [a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
                a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
                a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
                a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]];
    }
    function qrotX(q, r) { var h = r * 0.5; return qmul(q, [Math.sin(h), 0, 0, Math.cos(h)]); }
    function qrotY(q, r) { var h = r * 0.5; return qmul(q, [0, Math.sin(h), 0, Math.cos(h)]); }
    function qrotZ(q, r) { var h = r * 0.5; return qmul(q, [0, 0, Math.sin(h), Math.cos(h)]); }
    function qconj(q) { return [-q[0], -q[1], -q[2], q[3]]; }
    function qapply(q, v) {
        var x = q[0], y = q[1], z = q[2], w = q[3];
        var tx = 2 * (y * v[2] - z * v[1]), ty = 2 * (z * v[0] - x * v[2]), tz = 2 * (x * v[1] - y * v[0]);
        return [v[0] + w * tx + (y * tz - z * ty), v[1] + w * ty + (z * tx - x * tz), v[2] + w * tz + (x * ty - y * tx)];
    }
    function add(a, b) { return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]; }
    function sub(a, b) { return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]; }
    function len(a) { return Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]); }
    function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }
    function clampF(v, lo, hi, fb) { return typeof v === "number" && isFinite(v) ? clamp(v, lo, hi) : fb; }
    function wrapDeg(d) { var w = d % 360; if (w >= 180) w -= 360; if (w < -180) w += 360; return w; }

    // ---- HairColors -----------------------------------------------------------------------
    function parseColor(hex) {
        if (hex === null || hex === undefined) return -1;
        var v = String(hex).trim();
        if (v.charAt(0) === "#") v = v.substring(1);
        if (!/^[0-9A-Fa-f]{6}$/.test(v)) return -1;
        return parseInt(v, 16);
    }
    function normColor(hex) {
        var c = parseColor(hex);
        if (c < 0) return null;
        var s = c.toString(16).toUpperCase();
        while (s.length < 6) s = "0" + s;
        return "#" + s;
    }

    // =====================================================================================
    //  Codec: base62 / base64url -> raw inflate -> NBT
    // =====================================================================================
    var B62 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    var B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

    // BigInteger(base62).toByteArray() minus a leading 0 byte. Limbs of 20 bits, 5 digits a step.
    function decodeBase62(s) {
        if (!s.length) return [];
        var limbs = [0], LB = 1048576, i, k;           // little-endian 20-bit limbs
        for (i = 0; i < s.length; i += 5) {
            var n = Math.min(5, s.length - i), mul = 1, addv = 0;
            for (k = 0; k < n; k++) {
                var d = B62.indexOf(s.charAt(i + k));
                if (d < 0) throw new Error("invalid character '" + s.charAt(i + k) + "'");
                mul *= 62; addv = addv * 62 + d;
            }
            var carry = addv;
            for (k = 0; k < limbs.length; k++) {
                var t = limbs[k] * mul + carry;
                limbs[k] = t % LB;
                carry = Math.floor(t / LB);
            }
            while (carry > 0) { limbs.push(carry % LB); carry = Math.floor(carry / LB); }
        }
        // limbs -> big-endian bytes
        var bits = [], bytes = [];
        var acc = 0, accBits = 0;
        for (k = 0; k < limbs.length; k++) {
            acc += limbs[k] * Math.pow(2, accBits); accBits += 20;
            while (accBits >= 8) { bits.push(acc % 256); acc = Math.floor(acc / 256); accBits -= 8; }
        }
        while (acc > 0) { bits.push(acc % 256); acc = Math.floor(acc / 256); }
        while (bits.length > 1 && bits[bits.length - 1] === 0) bits.pop();
        for (k = bits.length - 1; k >= 0; k--) bytes.push(bits[k]);
        // BigInteger.toByteArray adds a sign byte when the top bit is set; the codec strips one leading 0
        return bytes;
    }

    function decodeBase64Url(s) {
        var out = [], buf = 0, nb = 0;
        for (var i = 0; i < s.length; i++) {
            var c = s.charAt(i);
            if (c === "=") break;
            var v = B64.indexOf(c);
            if (v < 0) v = "+/".indexOf(c) >= 0 ? 62 + "+/".indexOf(c) : -1;
            if (v < 0) throw new Error("invalid base64 character");
            buf = (buf << 6) | v; nb += 6;
            if (nb >= 8) { nb -= 8; out.push((buf >> nb) & 255); }
        }
        return out;
    }

    // ---- raw DEFLATE (RFC 1951) ----
    function inflate(data) {
        var pos = 0, bitBuf = 0, bitCnt = 0, out = [];
        function bit() {
            if (bitCnt === 0) { if (pos >= data.length) throw new Error("truncated data"); bitBuf = data[pos++]; bitCnt = 8; }
            var b = bitBuf & 1; bitBuf >>= 1; bitCnt--; return b;
        }
        function bits(n) { var v = 0; for (var i = 0; i < n; i++) v |= bit() << i; return v; }
        function build(lengths, n) {
            var counts = [], offs = [], symbols = [], i;
            for (i = 0; i < 16; i++) counts[i] = 0;
            for (i = 0; i < n; i++) counts[lengths[i]]++;
            counts[0] = 0;
            offs[1] = 0;
            for (i = 1; i < 15; i++) offs[i + 1] = offs[i] + counts[i];
            for (i = 0; i < n; i++) if (lengths[i]) symbols[offs[lengths[i]]++] = i;
            return { counts: counts, symbols: symbols };
        }
        function decodeSym(h) {
            var code = 0, first = 0, index = 0;
            for (var l = 1; l < 16; l++) {
                code |= bit();
                var c = h.counts[l];
                if (code - c < first) return h.symbols[index + (code - first)];
                index += c; first += c; first <<= 1; code <<= 1;
            }
            throw new Error("bad huffman code");
        }
        var LBASE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
        var LEXT = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
        var DBASE = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
        var DEXT = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
        var fixedL = null, fixedD = null;
        var last;
        do {
            last = bit();
            var type = bits(2), lt, dt, i;
            if (type === 0) {
                bitCnt = 0;
                var ln = data[pos] | (data[pos + 1] << 8); pos += 4;
                for (i = 0; i < ln; i++) out.push(data[pos++]);
                continue;
            } else if (type === 1) {
                if (!fixedL) {
                    var l = [];
                    for (i = 0; i < 144; i++) l[i] = 8;
                    for (; i < 256; i++) l[i] = 9;
                    for (; i < 280; i++) l[i] = 7;
                    for (; i < 288; i++) l[i] = 8;
                    fixedL = build(l, 288);
                    var d = [];
                    for (i = 0; i < 30; i++) d[i] = 5;
                    fixedD = build(d, 30);
                }
                lt = fixedL; dt = fixedD;
            } else if (type === 2) {
                var hlit = bits(5) + 257, hdist = bits(5) + 1, hclen = bits(4) + 4;
                var ORDER = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
                var cl = [];
                for (i = 0; i < 19; i++) cl[i] = 0;
                for (i = 0; i < hclen; i++) cl[ORDER[i]] = bits(3);
                var ch = build(cl, 19), lens = [];
                while (lens.length < hlit + hdist) {
                    var sym = decodeSym(ch);
                    if (sym < 16) lens.push(sym);
                    else if (sym === 16) { var prev = lens[lens.length - 1], r = 3 + bits(2); while (r--) lens.push(prev); }
                    else if (sym === 17) { var z = 3 + bits(3); while (z--) lens.push(0); }
                    else { var z2 = 11 + bits(7); while (z2--) lens.push(0); }
                }
                lt = build(lens.slice(0, hlit), hlit);
                dt = build(lens.slice(hlit), hdist);
            } else throw new Error("bad block type");
            for (;;) {
                var s = decodeSym(lt);
                if (s < 256) out.push(s);
                else if (s === 256) break;
                else {
                    s -= 257;
                    var length = LBASE[s] + bits(LEXT[s]);
                    var ds = decodeSym(dt);
                    var dist = DBASE[ds] + bits(DEXT[ds]);
                    var from = out.length - dist;
                    for (i = 0; i < length; i++) out.push(out[from + i]);
                }
                if (out.length > 2097152) throw new Error("hair code too large");
            }
        } while (!last);
        return out;
    }

    // ---- NBT (big endian) to plain objects; lists become arrays ----
    function readNbt(b) {
        var p = 0;
        function u8() { return b[p++]; }
        function u16() { var v = (b[p] << 8) | b[p + 1]; p += 2; return v; }
        function i32() { var v = (b[p] << 24) | (b[p + 1] << 16) | (b[p + 2] << 8) | b[p + 3]; p += 4; return v; }
        function f32() {
            var bitsv = i32() >>> 0, sign = bitsv >>> 31 ? -1 : 1, e = (bitsv >>> 23) & 255, m = bitsv & 0x7FFFFF;
            if (e === 255) return m ? NaN : sign * Infinity;
            if (e === 0) return sign * m * Math.pow(2, -149);
            return sign * (1 + m / 8388608) * Math.pow(2, e - 127);
        }
        function f64() {
            var hi = i32() >>> 0, lo = i32() >>> 0, sign = hi >>> 31 ? -1 : 1, e = (hi >>> 20) & 2047;
            var m = (hi & 0xFFFFF) * 4294967296 + lo;
            if (e === 2047) return m ? NaN : sign * Infinity;
            if (e === 0) return sign * m * Math.pow(2, -1074);
            return sign * (1 + m / 4503599627370496) * Math.pow(2, e - 1023);
        }
        function str() {
            var n = u16(), s = "", end = p + n;
            while (p < end) {
                var c = b[p++];
                if (c < 128) s += String.fromCharCode(c);
                else if ((c & 0xE0) === 0xC0) s += String.fromCharCode(((c & 31) << 6) | (b[p++] & 63));
                else { s += String.fromCharCode(((c & 15) << 12) | ((b[p] & 63) << 6) | (b[p + 1] & 63)); p += 2; }
            }
            return s;
        }
        function payload(t) {
            var n, i, a;
            switch (t) {
                case 1: { var v = u8(); return v > 127 ? v - 256 : v; }
                case 2: { var s = u16(); return s > 32767 ? s - 65536 : s; }
                case 3: return i32();
                case 4: { var h = i32(); var l = i32() >>> 0; return h * 4294967296 + l; }
                case 5: return f32();
                case 6: return f64();
                case 7: n = i32(); a = []; for (i = 0; i < n; i++) a.push(payload(1)); return a;
                case 8: return str();
                case 9: { var et = u8(); n = i32(); a = []; for (i = 0; i < n; i++) a.push(payload(et)); return a; }
                case 10: {
                    var o = {};
                    for (;;) {
                        var tt = u8();
                        if (tt === 0) return o;
                        var name = str();
                        o[name] = payload(tt);
                    }
                }
                case 11: n = i32(); a = []; for (i = 0; i < n; i++) a.push(i32()); return a;
                case 12: n = i32(); a = []; for (i = 0; i < n; i++) a.push(payload(4)); return a;
                default: throw new Error("bad nbt tag " + t);
            }
        }
        var root = u8();
        if (root !== 10) throw new Error("not a compound");
        str();
        return payload(10);
    }

    // the engine's byte codecs when there (RPG.codec: Java's BigInteger / Base64 / Inflater, far quicker than script loops)
    function fast(name) { return typeof RPG !== "undefined" && RPG.codec && typeof RPG.codec[name] === "function"; }
    function b62(s) {
        if (!fast("radixDecodeBytes")) return decodeBase62(s);
        if (!s.length) return [];
        var b = RPG.codec.radixDecodeBytes(s, B62), out = [];
        for (var i = b.length > 1 && b[0] === 0 ? 1 : 0; i < b.length; i++) out.push(b[i]);   // HairCodec.decodeBase62 drops one leading 0
        return out;
    }
    function b64(s) { return fast("base64DecodeBytes") ? RPG.codec.base64DecodeBytes(s) : decodeBase64Url(s); }
    function inflateRaw(b) {
        if (!fast("inflateBytes")) return inflate(b);
        var out = RPG.codec.inflateBytes(b, true);
        if (out.length > 2097152) throw new Error("hair code too large");
        return out;
    }
    function decodeTag(code) {
        if (code.length > 262144) return null;
        var bytes;
        if (code.indexOf("DMZF22:") === 0) bytes = b64(code.substring(7));
        else if (code.indexOf("DMZ22:") === 0) bytes = b64(code.substring(6));
        else if (code.indexOf("DMZF1:") === 0) bytes = b62(code.substring(6));
        else if (code.indexOf("DMZ1:") === 0) bytes = b62(code.substring(5));
        else return null;
        return readNbt(inflateRaw(bytes));
    }

    // =====================================================================================
    //  CustomHair: NBT -> canonical style {name, gc, keepEmpty, faces: {F: [strand...]}}
    //  A strand: {i, sg, ln, lr, w, d, tp, tg, ox, oy, oz, rx, ry, rz, bx, by, bz, tw, c, tc, so: [override]}
    //  (the original's own NBT keys, version 7 meaning: override scales are relative to the previous segment)
    // =====================================================================================
    function num(t, k, fb) { return typeof t[k] === "number" ? t[k] : fb; }

    function defaultStrand(fi, index) {
        var r = BASE_ROT[FACES[fi].key];
        return { i: fi * 100 + index, sg: 0, ln: 6, lr: Math.fround(0.6), w: 2, d: 2, tp: Math.fround(0.6), tg: 1, ox: 0, oy: 0, oz: 0,
                 rx: r[0], ry: r[1], rz: r[2], bx: 0, by: 0, bz: 0, tw: 0, js: 0, c: null, tc: null, so: [] };
    }

    function loadOverride(t) {
        var F = Math.fround;
        function g(k) { return typeof t[k] === "number" ? F(t[k]) : 0; }
        function cl(v, lo, hi, fb) { return isFinite(v) ? (v < F(lo) ? F(lo) : v > F(hi) ? F(hi) : v) : fb; }
        return { k: t.k | 0, ox: cl(g("ox"), -2, 2, 0), oy: cl(g("oy"), -2, 2, 0), oz: cl(g("oz"), -2, 2, 0),
                 rx: cl(g("rx"), -180, 180, 0), ry: cl(g("ry"), -180, 180, 0), rz: cl(g("rz"), -180, 180, 0),
                 ls: "ls" in t ? cl(g("ls"), 0.1, 16, 1) : 1, ws: "ws" in t ? cl(g("ws"), 0.1, 16, 1) : 1, ds: "ds" in t ? cl(g("ds"), 0.1, 16, 1) : 1,
                 c: t.c !== undefined ? normColor(t.c) : null };
    }
    function isIdentity(o) {
        var e = Math.fround(1e-4), F = Math.fround;
        return Math.abs(o.ox) < e && Math.abs(o.oy) < e && Math.abs(o.oz) < e && Math.abs(o.rx) < e && Math.abs(o.ry) < e && Math.abs(o.rz) < e
            && Math.abs(F(o.ls - 1)) < e && Math.abs(F(o.ws - 1)) < e && Math.abs(F(o.ds - 1)) < e && !o.c;
    }
    function getOverride(s, k) { for (var i = 0; i < s.so.length; i++) if (s.so[i].k === k) return s.so[i]; return null; }
    function getOrCreateOverride(s, k) {
        var o = getOverride(s, k);
        if (!o) { o = { k: k, ox: 0, oy: 0, oz: 0, rx: 0, ry: 0, rz: 0, ls: 1, ws: 1, ds: 1, c: null }; s.so.push(o); s.so.sort(function (a, b) { return a.k - b.k; }); }
        return o;
    }
    function removeOverride(s, k) { s.so = s.so.filter(function (o) { return o.k !== k; }); }

    // Java floats: every stored value is a 32-bit float, and HairMath.clampFinite's bounds are float constants
    var F = Math.fround;
    function clampFF(v, lo, hi, fb) { return typeof v === "number" && isFinite(v) ? (v < F(lo) ? F(lo) : v > F(hi) ? F(hi) : v) : fb; }
    function wrapF(d) { var w = F(d % 360); if (w >= 180) w = F(w - 360); if (w < -180) w = F(w + 360); return w; }
    function fnum(t, k) { return typeof t[k] === "number" ? F(t[k]) : 0; }

    function loadStrand(t) {
        var s = { i: t.i | 0, sg: clamp(t.sg | 0, 0, 32) };
        s.ln = "ln" in t ? clampFF(F(t.ln), 0.1, 128, 6) : 6;
        s.lr = "lr" in t ? clampFF(F(t.lr), 0.1, 4, 1) : 1;
        s.w = "w" in t ? clampFF(F(t.w), 0.1, 16, 2) : 2;
        s.d = "d" in t ? clampFF(F(t.d), 0.1, 16, 2) : 2;
        s.tp = "tp" in t ? clampFF(F(t.tp), 0.05, 2, 1) : 1;
        s.tg = "tg" in t ? clampFF(F(t.tg), 0.25, 4, 1) : 1;
        s.ox = clampFF(fnum(t, "ox"), -4, 4, 0); s.oy = clampFF(fnum(t, "oy"), -4, 4, 0); s.oz = clampFF(fnum(t, "oz"), -4, 4, 0);
        s.rx = isFinite(fnum(t, "rx")) ? wrapF(fnum(t, "rx")) : 0; s.ry = isFinite(fnum(t, "ry")) ? wrapF(fnum(t, "ry")) : 0; s.rz = isFinite(fnum(t, "rz")) ? wrapF(fnum(t, "rz")) : 0;
        s.bx = clampFF(fnum(t, "bx"), -3600, 3600, 0); s.by = clampFF(fnum(t, "by"), -3600, 3600, 0); s.bz = clampFF(fnum(t, "bz"), -3600, 3600, 0);
        s.tw = clampFF(fnum(t, "tw"), -3600, 3600, 0);
        s.js = (t.js | 0) === 1 ? 1 : 0;                  // HairJointStyle: 0 blocks, 1 connected (codes never carry it)
        s.c = t.c !== undefined ? normColor(t.c) : null;
        s.tc = t.tc !== undefined ? normColor(t.tc) : null;
        s.so = [];
        (t.so || []).forEach(function (ot) {
            var o = loadOverride(ot);
            if (o.k >= 0 && o.k < 32) { removeOverride(s, o.k); s.so.push(o); }
        });
        s.so.sort(function (a, b) { return a.k - b.k; });
        return s;
    }

    // HairStrand.convertAbsoluteSegmentScales (codes older than version 7)
    function convertAbsoluteScales(s) {
        var F = Math.fround, ls = 1, ws = 1, dsc = 1;
        function cl(v) { return isFinite(v) ? (v < F(0.1) ? F(0.1) : v > 16 ? 16 : v) : null; }
        for (var k = 0; k < s.sg; k++) {
            var ex = getOverride(s, k);
            var al = ex ? ex.ls : 1, aw = ex ? ex.ws : 1, ad = ex ? ex.ds : 1;
            if (!ex && ls === 1 && ws === 1 && dsc === 1) continue;
            var o = getOrCreateOverride(s, k), v;
            v = cl(F(al / ls)); if (v !== null) o.ls = v;
            v = cl(F(aw / ws)); if (v !== null) o.ws = v;
            v = cl(F(ad / dsc)); if (v !== null) o.ds = v;
            if (isIdentity(o)) { removeOverride(s, k); continue; }
            ls = F(ls * o.ls); ws = F(ws * o.ws); dsc = F(dsc * o.ds);
        }
    }

    // ---- HairPoseBuilder.buildGeometry (positions in pixels) ----
    function poseOf(s, fi, index) {
        var seg = s.sg, base = basePosition(fi, index);
        var root = [base[0] + s.ox, base[1] + s.oy, base[2] + s.oz];
        var baseRot = qrotZ(qrotY(qrotX(qid(), s.rx * DEG), s.ry * DEG), s.rz * DEG);
        var out = { root: root, baseRot: baseRot, seg: seg, lengths: [], widths: [], depths: [], params: [], rel: [], offs: [], restRot: [], restStart: [], tip: root };
        if (seg <= 0) return out;
        var total = 0, k;
        for (k = 0; k < seg; k++) { var pr = seg > 1 ? k / (seg - 1) : 0; out.params[k] = pr; total += Math.pow(s.lr, pr); }
        var joints = Math.max(1, seg - 1);
        var bx = seg > 1 ? s.bx / joints * DEG : 0, by = seg > 1 ? s.by / joints * DEG : 0, bz = seg > 1 ? s.bz / joints * DEG : 0;
        var tw = seg > 1 ? s.tw / joints * DEG : 0;
        var lsc = 1, wsc = 1, dsc = 1;
        for (k = 0; k < seg; k++) {
            var param = out.params[k], ov = getOverride(s, k);
            var weight = Math.pow(s.lr, param) / total;
            var taper = Math.pow(s.tp, Math.pow(param, s.tg));
            if (ov) { lsc *= ov.ls; wsc *= ov.ws; dsc *= ov.ds; }
            out.lengths[k] = s.ln * weight * lsc;
            out.widths[k] = s.w * taper * wsc;
            out.depths[k] = s.d * taper * dsc;
            var rel = qid();
            if (k > 0) rel = qrotY(qrotZ(qrotY(qrotX(rel, bx), by), bz), tw);
            var off = [0, 0, 0];
            if (ov) {
                off = qapply(rel, [ov.ox, ov.oy, ov.oz]);
                rel = qrotZ(qrotY(qrotX(rel, ov.rx * DEG), ov.ry * DEG), ov.rz * DEG);
            }
            out.rel[k] = rel; out.offs[k] = off;
        }
        var parent = baseRot, cursor = root;
        for (k = 0; k < seg; k++) {
            var start = add(qapply(parent, out.offs[k]), cursor);
            var rot = qmul(parent, out.rel[k]);
            out.restStart[k] = start; out.restRot[k] = rot;
            cursor = add(qapply(rot, [0, out.lengths[k], 0]), start);
            parent = rot;
        }
        out.tip = cursor;
        return out;
    }

    // ---- 32-bit float maths with the original's library semantics (org.joml with its defaults: no fused multiply-add,
    //      cos derived from sin): the legacy migration, the sanitizer and the generator then give the original's exact floats
    var JF = (function () {
        var F = Math.fround, PI_F = F(Math.PI), PIH = F(PI_F / 2), PI2 = F(PI_F * 2);
        function fma(a, b, c) { return F(F(a * b) + c); }
        function sin(x) { return F(Math.sin(x)); }
        function sqrt(x) { return F(Math.sqrt(x)); }
        function cosFromSin(sn, ang) {
            var c = sqrt(F(1 - F(sn * sn))), a = F(ang + PIH);
            var q = F(a / PI2), n = q < 0 ? Math.ceil(q) : Math.floor(q);
            var b = F(a - F(F(n) * PI2));
            if (b < 0) b = F(b + PI2);
            return b >= PI_F ? -c : c;
        }
        // quaternions [x, y, z, w]
        function qrx(q, ang) { var h = F(ang * 0.5), sn = sin(h), c = cosFromSin(sn, h), x = q[0], y = q[1], z = q[2], w = q[3];
            return [F(F(w * sn) + F(x * c)), F(F(y * c) + F(z * sn)), F(F(z * c) - F(y * sn)), F(F(w * c) - F(x * sn))]; }
        function qry(q, ang) { var h = F(ang * 0.5), sn = sin(h), c = cosFromSin(sn, h), x = q[0], y = q[1], z = q[2], w = q[3];
            return [F(F(x * c) - F(z * sn)), F(F(w * sn) + F(y * c)), F(F(x * sn) + F(z * c)), F(F(w * c) - F(y * sn))]; }
        function qrz(q, ang) { var h = F(ang * 0.5), sn = sin(h), c = cosFromSin(sn, h), x = q[0], y = q[1], z = q[2], w = q[3];
            return [F(F(x * c) + F(y * sn)), F(F(y * c) - F(x * sn)), F(F(w * sn) + F(z * c)), F(F(w * c) - F(z * sn))]; }
        function qmul(a, q) {
            var x = a[0], y = a[1], z = a[2], w = a[3];
            return [fma(w, q[0], fma(x, q[3], fma(y, q[2], F(-z * q[1])))),
                    fma(w, q[1], fma(-x, q[2], fma(y, q[3], F(z * q[0])))),
                    fma(w, q[2], fma(x, q[1], fma(-y, q[0], F(z * q[3])))),
                    fma(w, q[3], fma(-x, q[0], fma(-y, q[1], F(-z * q[2]))))];
        }
        function qtr(q, v) {
            var x = q[0], y = q[1], z = q[2], w = q[3];
            var xx = F(x * x), yy = F(y * y), zz = F(z * z), ww = F(w * w), xy = F(x * y), xz = F(x * z), yz = F(y * z), xw = F(x * w), zw = F(z * w), yw = F(y * w);
            var k = F(1 / F(F(F(xx + yy) + zz) + ww));
            return [fma(F(F(F(F(xx - yy) - zz) + ww) * k), v[0], fma(F(F(2 * F(xy - zw)) * k), v[1], F(F(F(2 * F(xz + yw)) * k) * v[2]))),
                    fma(F(F(2 * F(xy + zw)) * k), v[0], fma(F(F(F(F(yy - xx) - zz) + ww) * k), v[1], F(F(F(2 * F(yz - xw)) * k) * v[2]))),
                    fma(F(F(2 * F(xz - yw)) * k), v[0], fma(F(F(2 * F(yz + xw)) * k), v[1], F(F(F(F(F(zz - xx) - yy) + ww) * k) * v[2])))];
        }
        function qinv(q) {
            var inv = F(1 / fma(q[0], q[0], fma(q[1], q[1], fma(q[2], q[2], F(q[3] * q[3])))));
            return [F(-q[0] * inv), F(-q[1] * inv), F(-q[2] * inv), F(q[3] * inv)];
        }
        // vectors
        function vadd(a, b) { return [F(a[0] + b[0]), F(a[1] + b[1]), F(a[2] + b[2])]; }
        function vsub(a, b) { return [F(a[0] - b[0]), F(a[1] - b[1]), F(a[2] - b[2])]; }
        function vmul(a, s) { return [F(a[0] * s), F(a[1] * s), F(a[2] * s)]; }
        function vlen(a) { return sqrt(fma(a[0], a[0], fma(a[1], a[1], F(a[2] * a[2])))); }
        function vdist(a, b) { return vlen(vsub(a, b)); }
        function vdiv(a, s) { var inv = F(1 / s); return vmul(a, inv); }
        // Matrix4f: m[col*4 + row] (m00 m01 m02 m03 = column 0) and its property flags
        function mnew() { return { m: [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1], p: 30 }; }
        function mident(M) { M.m = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]; }
        function mtranslate(M, x, y, z) {
            var m = M.m;
            if (M.p & 4) { M.m = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1]; M.p = 26; return M; }
            var n = m.slice();
            n[12] = fma(m[0], x, fma(m[4], y, fma(m[8], z, m[12])));
            n[13] = fma(m[1], x, fma(m[5], y, fma(m[9], z, m[13])));
            n[14] = fma(m[2], x, fma(m[6], y, fma(m[10], z, m[14])));
            n[15] = fma(m[3], x, fma(m[7], y, fma(m[11], z, m[15])));
            M.m = n; M.p = M.p & -6; return M;
        }
        function mrotation(M, axis, ang) {
            var sn = sin(ang), c = cosFromSin(sn, ang);
            if (!(M.p & 4)) mident(M);
            var m = M.m;
            if (axis === 0) { m[5] = c; m[6] = sn; m[9] = -sn; m[10] = c; }
            else if (axis === 1) { m[0] = c; m[2] = -sn; m[8] = sn; m[10] = c; }
            else { m[0] = c; m[1] = sn; m[4] = -sn; m[5] = c; }
            M.p = 18; return M;
        }
        function mrotate(M, axis, ang) {
            if (M.p & 4) return mrotation(M, axis, ang);
            if (M.p & 8) { var tx = M.m[12], ty = M.m[13], tz = M.m[14]; mrotation(M, axis, ang); M.m[12] = tx; M.m[13] = ty; M.m[14] = tz; M.p = M.p & -6; return M; }
            var sn = sin(ang), c = cosFromSin(sn, ang), m = M.m, n = m.slice(), i;
            if (axis === 0) {
                for (i = 0; i < 4; i++) { n[8 + i] = fma(m[4 + i], -sn, F(m[8 + i] * c)); n[4 + i] = fma(m[4 + i], c, F(m[8 + i] * sn)); }
            } else if (axis === 1) {
                for (i = 0; i < 4; i++) { n[i] = fma(m[i], c, F(m[8 + i] * -sn)); n[8 + i] = fma(m[i], sn, F(m[8 + i] * c)); }
            } else {
                for (i = 0; i < 4; i++) { n[i] = fma(m[i], c, F(m[4 + i] * sn)); n[4 + i] = fma(m[i], -sn, F(m[4 + i] * c)); }
            }
            M.m = n; M.p = M.p & -14; return M;
        }
        function mscale(M, x, y, z) {
            var one = Math.abs(x) === 1 && Math.abs(y) === 1 && Math.abs(z) === 1;
            if (M.p & 4) { mident(M); M.m[0] = x; M.m[5] = y; M.m[10] = z; M.p = 2 | (one ? 16 : 0); return M; }
            var m = M.m;
            for (var i = 0; i < 4; i++) { m[i] = F(m[i] * x); m[4 + i] = F(m[4 + i] * y); m[8 + i] = F(m[8 + i] * z); }
            M.p = M.p & ~(13 | (one ? 0 : 16)); return M;
        }
        function mpos(M, v) {
            var m = M.m;
            return [fma(m[0], v[0], fma(m[4], v[1], fma(m[8], v[2], m[12]))),
                    fma(m[1], v[0], fma(m[5], v[1], fma(m[9], v[2], m[13]))),
                    fma(m[2], v[0], fma(m[6], v[1], fma(m[10], v[2], m[14])))];
        }
        return { F: F, fma: fma, sin: sin, sqrt: sqrt, cosFromSin: cosFromSin, qrx: qrx, qry: qry, qrz: qrz, qmul: qmul, qtr: qtr, qinv: qinv,
                 vadd: vadd, vsub: vsub, vmul: vmul, vlen: vlen, vdist: vdist, vdiv: vdiv,
                 mnew: mnew, mtranslate: mtranslate, mrotate: mrotate, mscale: mscale, mpos: mpos,
                 D2R: F(Math.PI / 180), R2D: F(180 / Math.PI), PX: 0.0625 };
    })();

    // HairPoseBuilder.buildGeometry with float maths, in blocks (pixels x 1/16) like the original's StrandPose
    function poseExact(s, fi, index) {
        var F = JF.F, n = s.sg, base = basePosition(fi, index);
        var root = JF.vmul([F(base[0] + F(s.ox)), F(base[1] + F(s.oy)), F(base[2] + F(s.oz))], JF.PX);
        var baseRot = JF.qrz(JF.qry(JF.qrx([0, 0, 0, 1], F(s.rx * JF.D2R)), F(s.ry * JF.D2R)), F(s.rz * JF.D2R));
        var out = { segments: n, root: root, baseRotation: baseRot, params: [], lengths: [], widths: [], depths: [], rel: [], offs: [], restStarts: [], restRotations: [], restTip: root };
        if (n <= 0) return out;
        var total = 0, k;
        for (k = 0; k < n; k++) { var pr = n > 1 ? F(k / (n - 1)) : 0; out.params[k] = pr; total = F(total + F(Math.pow(s.lr, pr))); }
        var joints = Math.max(1, n - 1);
        var bx = n > 1 ? F(F(s.bx / joints) * JF.D2R) : 0, by = n > 1 ? F(F(s.by / joints) * JF.D2R) : 0, bz = n > 1 ? F(F(s.bz / joints) * JF.D2R) : 0;
        var tw = n > 1 ? F(F((s.tw || 0) / joints) * JF.D2R) : 0;
        var lsc = 1, wsc = 1, dsc = 1;
        for (k = 0; k < n; k++) {
            var param = out.params[k], ov = getOverride(s, k);
            var weight = F(F(Math.pow(s.lr, param)) / total);
            var taper = F(Math.pow(s.tp, Math.pow(param, s.tg)));
            if (ov) { lsc = F(lsc * ov.ls); wsc = F(wsc * ov.ws); dsc = F(dsc * ov.ds); }
            out.lengths[k] = F(F(F(s.ln * weight) * JF.PX) * lsc);
            out.widths[k] = F(F(F(s.w * taper) * JF.PX) * wsc);
            out.depths[k] = F(F(F(s.d * taper) * JF.PX) * dsc);
            var rel = [0, 0, 0, 1];
            if (k > 0) rel = JF.qry(JF.qrz(JF.qry(JF.qrx(rel, bx), by), bz), tw);
            var off = [0, 0, 0];
            if (ov) {
                off = JF.qtr(rel, JF.vmul([ov.ox, ov.oy, ov.oz], JF.PX));
                rel = JF.qrz(JF.qry(JF.qrx(rel, F(ov.rx * JF.D2R)), F(ov.ry * JF.D2R)), F(ov.rz * JF.D2R));
            }
            out.rel[k] = rel; out.offs[k] = off;
        }
        var parent = baseRot, cursor = root;
        for (k = 0; k < n; k++) {
            var start = JF.vadd(JF.qtr(parent, out.offs[k]), cursor);
            var rot = JF.qmul(parent, out.rel[k]);
            out.restStarts[k] = start; out.restRotations[k] = rot;
            cursor = JF.vadd(JF.qtr(rot, [0, out.lengths[k], 0]), start);
            parent = rot;
        }
        out.restTip = cursor;
        return out;
    }

    // ---- HairLegacyMigrator (codes older than version 6) ----
    function legacyF(t, a, b, fb) { var v = typeof t[a] === "number" ? Math.fround(t[a]) : typeof t[b] === "number" ? Math.fround(t[b]) : fb; return isFinite(v) ? v : fb; }

    function migrateStrand(fi, index, t) {
        var F = JF.F;
        var L = {
            length: Math.max(0, "l" in t ? t.l | 0 : (t.Length | 0)), lengthScale: legacyF(t, "ls", "LengthScale", 1),
            rx: legacyF(t, "rx", "RotX", 0), ry: legacyF(t, "ry", "RotY", 0), rz: legacyF(t, "rz", "RotZ", 0),
            sx: legacyF(t, "sx", "ScaleX", 1), sy: legacyF(t, "sy", "ScaleY", 1), sz: legacyF(t, "sz", "ScaleZ", 1),
            cw: legacyF(t, "cw", "CubeW", 2), ch: legacyF(t, "ch", "CubeH", 2), cd: legacyF(t, "cd", "CubeD", 2),
            cx: legacyF(t, "cx", "CurveX", 0), cy: legacyF(t, "cy", "CurveY", 0), cz: legacyF(t, "cz", "CurveZ", 0),
            color: t.c !== undefined ? t.c : t.Color !== undefined ? t.Color : null
        };
        var s = defaultStrand(fi, index);
        s.rx = wrapF(L.rx); s.ry = wrapF(L.ry); s.rz = wrapF(L.rz);
        s.c = normColor(L.color);
        var seg = Math.min(L.length, 32);
        if (seg <= 0) { s.sg = 0; return s; }
        var DECAY = F(0.85), decaySum = (1 - Math.pow(DECAY, seg)) / (1 - DECAY), ratio = F(Math.pow(DECAY, seg - 1));
        s.sg = seg;
        s.ln = clampFF(F(F(F(L.ch * L.lengthScale) * L.sy) * decaySum), 0.1, 128, s.ln);
        s.lr = clampFF(ratio, 0.1, 4, s.lr);
        s.tp = clampFF(ratio, 0.05, 2, s.tp);
        s.tg = 1;
        s.w = clampFF(F(L.cw * L.sx), 0.1, 16, s.w);
        s.d = clampFF(F(L.cd * L.sz), 0.1, 16, s.d);
        s.bx = clampFF(F(L.cx * (seg - 1)), -3600, 3600, 0); s.by = clampFF(F(L.cy * (seg - 1)), -3600, 3600, 0); s.bz = clampFF(F(L.cz * (seg - 1)), -3600, 3600, 0);

        // the old centre line (legacyCenterline)
        var base = basePosition(fi, index), D = JF.D2R;
        var M = JF.mnew();
        JF.mtranslate(M, base[0], base[1], base[2]);
        JF.mrotate(M, 0, F(L.rx * D)); JF.mrotate(M, 1, F(L.ry * D)); JF.mrotate(M, 2, F(L.rz * D));
        JF.mscale(M, L.sx, L.sy, L.sz);
        var joints = [], decay = 1, prevH = 0, i;
        for (i = 0; i < seg; i++) {
            var h = F(F(L.ch * decay) * L.lengthScale);
            if (i > 0) { JF.mtranslate(M, 0, prevH, 0); JF.mrotate(M, 0, F(L.cx * D)); JF.mrotate(M, 1, F(L.cy * D)); JF.mrotate(M, 2, F(L.cz * D)); }
            joints[i] = JF.mpos(M, [0, 0, 0]);
            prevH = h; decay = F(decay * DECAY);
        }
        joints[seg] = JF.mpos(M, [0, prevH, 0]);

        var pose = poseExact(s, fi, index), maxDev = 0;
        for (i = 0; i < seg; i++) maxDev = Math.max(maxDev, JF.vdist(JF.vmul(pose.restStarts[i], 16), joints[i]));
        maxDev = Math.max(maxDev, JF.vdist(JF.vmul(pose.restTip, 16), joints[seg]));
        if (maxDev > F(0.1)) fitCenterline(s, joints, pose);
        return s;
    }

    function fitCenterline(s, joints, pose) {
        var F = JF.F;
        s.so = [];
        var seg = pose.segments, baseLen = [], k;
        for (k = 0; k < seg; k++) baseLen[k] = F(pose.lengths[k] * 16);
        var parent = pose.baseRotation;
        var j = Math.max(1, seg - 1);
        var bx = seg > 1 ? F(F(s.bx / j) * JF.D2R) : 0, by = seg > 1 ? F(F(s.by / j) * JF.D2R) : 0, bz = seg > 1 ? F(F(s.bz / j) * JF.D2R) : 0;
        for (k = 0; k < seg; k++) {
            var frame = parent;
            if (k > 0) frame = JF.qrz(JF.qry(JF.qrx(frame, bx), by), bz);
            var dir = JF.vsub(joints[k + 1], joints[k]), actual = JF.vlen(dir);
            if (actual < F(1e-5) || baseLen[k] < F(1e-5)) { parent = frame; continue; }
            dir = JF.vdiv(JF.qtr(JF.qinv(frame), dir), actual);
            var rz = F(Math.asin(clamp(-dir[0], -1, 1))), rx = F(Math.atan2(dir[2], dir[1]));
            var o = getOrCreateOverride(s, k);
            o.rx = clampFF(F(rx * JF.R2D), -180, 180, o.rx); o.ry = 0; o.rz = clampFF(F(rz * JF.R2D), -180, 180, o.rz);
            o.ls = clampFF(F(actual / baseLen[k]), 0.1, 16, o.ls);
            if (isIdentity(o)) removeOverride(s, k);
            parent = JF.qrz(JF.qrx(frame, rx), rz);
        }
    }

    function resolveIndex(fi, t, listIndex, version) {
        if (version < 2) return listIndex;
        var id = "i" in t ? t.i : (t.Id | 0);
        var index = id - fi * 100;
        return index >= 0 && index < FACES[fi].max ? index : listIndex;
    }

    function loadHair(tag, keepJoints) {
        var version = "v" in tag ? tag.v : ("Version" in tag ? tag.Version : 1);
        var hair = { name: tag.n !== undefined ? tag.n : (tag.Name !== undefined ? tag.Name : "Custom"),
                     gc: normColor(tag.gc !== undefined ? tag.gc : tag.GlobalColor) || "#000000", keep: !!tag.e, faces: {} };
        FACES.forEach(function (face, fi) {
            var list = tag[face.key] || tag[face.name];
            var out = [];
            if (list && list.length) list.forEach(function (st, li) {
                var index = resolveIndex(fi, st, li, version);
                if (index < 0 || index >= face.max) return;
                var s;
                if (version >= 6) s = loadStrand(st);
                else s = migrateStrand(fi, index, st);
                if (version < 7) convertAbsoluteScales(s);
                if (!keepJoints) s.js = 0;                         // HairCodec.withoutJointStyles
                s.i = fi * 100 + index;
                out[index] = s.sg > 0 && s.ln > 0 ? s : null;     // a later invisible duplicate replaces an earlier strand, as in CustomHair.load
            });
            hair.faces[face.key] = out;
        });
        return hair;
    }

    function isEmpty(h) {
        if (!h) return true;
        for (var f in h.faces) for (var i = 0; i < h.faces[f].length; i++) if (h.faces[f][i]) return false;
        return true;
    }

    // HairCodec.fromCode: a single style (a full-set code gives its base)
    function fromCode(code) {
        var c = String(code || "").trim();
        if (!c) return null;
        if (isFullSetCode(c)) { var set = fromFullSetCode(c); return set ? set.base : null; }
        var tag;
        try { tag = decodeTag(c); } catch (e) { return null; }
        if (!tag) return null;
        if (tag.Base && (tag.SSJ || tag.SSJ2 || tag.SSJ3)) return loadHair(tag.Base);
        return loadHair(tag);
    }
    function isFullSetCode(c) { return c.indexOf("DMZF22:") === 0 || c.indexOf("DMZF1:") === 0; }
    function copyHair(h) { return JSON.parse(JSON.stringify(h)); }
    function emptyHair() { var h = { name: "Custom", gc: "#000000", keep: false, faces: {} }; FACES.forEach(function (f) { h.faces[f.key] = []; }); return h; }

    // HairCodec.fromFullSetCode
    function fromFullSetCode(code, keepJoints) {
        var c = String(code).trim();
        if (!isFullSetCode(c)) return null;
        var tag;
        try { tag = decodeTag(c); } catch (e) { return null; }
        if (!tag) return null;
        var styles = {};
        SLOTS.forEach(function (slot) {
            var key = tag[SLOT_CODE[slot]] ? SLOT_CODE[slot] : tag[SLOT_LEGACY[slot]] ? SLOT_LEGACY[slot] : null;
            if (key) styles[slot] = loadHair(tag[key], keepJoints);
        });
        if (!styles.base) styles.base = emptyHair();
        if (c.indexOf("DMZF1:") === 0 && !styles.ssj2 && styles.ssj) styles.ssj2 = copyHair(styles.ssj);
        if (!styles.ssj) styles.ssj = copyHair(styles.base);
        if (!styles.ssj2) styles.ssj2 = copyHair(styles.base);
        if (!styles.ssj3) styles.ssj3 = copyHair(styles.base);
        if (!styles.ssj4) styles.ssj4 = emptyHair();
        return styles;
    }

    // HairPresets.decode: a preset code -> styles per slot (single codes fill every slot but ssj4)
    function decodePreset(code) {
        if (isFullSetCode(code)) return fromFullSetCode(code);
        var single = fromCode(code), out = {};
        if (!single) return null;
        SLOTS.forEach(function (slot) { if (slot !== "ssj4") out[slot] = single; });
        return out;
    }

    // =====================================================================================
    //  Encoding (HairCodec.toCode / toFullSetCode): CustomHair.save() -> NBT -> raw DEFLATE level 9 -> base64url.
    //  Byte for byte what the original writes: the NBT keys come out in java.util.HashMap order (CompoundTag), every
    //  number is a 32-bit float or int like the original's fields, and the compression is Java's own Deflater
    //  (RPG.codec.deflateBytes, the same zlib the original calls). Codes never carry the joint style ("js"),
    //  like HairCodec.withoutJointStyles; keepJoints keeps it for DBR's own saved copy.
    // =====================================================================================
    function nInt(v) { return { t: 3, v: v | 0 }; }
    function nFloat(v) { return { t: 5, v: Math.fround(v) }; }
    function nByte(v) { return { t: 1, v: v | 0 }; }
    function nStr(v) { return { t: 8, v: String(v) }; }
    function nList(items) { return { t: 9, et: items.length ? items[0].t : 0, items: items }; }
    function nComp() { return { t: 10, e: [] }; }
    function put(c, k, node) {
        for (var i = 0; i < c.e.length; i++) if (c.e[i][0] === k) { c.e[i][1] = node; return; }   // HashMap.put keeps the old slot
        c.e.push([k, node]);
    }

    // HairSegmentOverride.save
    function saveOverride(o) {
        var t = nComp();
        put(t, "k", nInt(o.k));
        if (o.ox !== 0) put(t, "ox", nFloat(o.ox));
        if (o.oy !== 0) put(t, "oy", nFloat(o.oy));
        if (o.oz !== 0) put(t, "oz", nFloat(o.oz));
        if (o.rx !== 0) put(t, "rx", nFloat(o.rx));
        if (o.ry !== 0) put(t, "ry", nFloat(o.ry));
        if (o.rz !== 0) put(t, "rz", nFloat(o.rz));
        if (o.ls !== 1) put(t, "ls", nFloat(o.ls));
        if (o.ws !== 1) put(t, "ws", nFloat(o.ws));
        if (o.ds !== 1) put(t, "ds", nFloat(o.ds));
        if (o.c) put(t, "c", nStr(o.c));
        return t;
    }
    // HairStrand.save (the floats compared as Java floats: values are kept as floats throughout)
    function saveStrand(s, keepJoints) {
        var t = nComp(), F = Math.fround;
        put(t, "i", nInt(s.i));
        put(t, "sg", nInt(s.sg));
        put(t, "ln", nFloat(s.ln));
        if (F(s.lr) !== 1) put(t, "lr", nFloat(s.lr));
        if (F(s.w) !== 2) put(t, "w", nFloat(s.w));
        if (F(s.d) !== 2) put(t, "d", nFloat(s.d));
        if (F(s.tp) !== 1) put(t, "tp", nFloat(s.tp));
        if (F(s.tg) !== 1) put(t, "tg", nFloat(s.tg));
        ["ox", "oy", "oz", "rx", "ry", "rz", "bx", "by", "bz"].forEach(function (k) { if (F(s[k] || 0) !== 0) put(t, k, nFloat(s[k])); });
        if (F(s.tw || 0) !== 0) put(t, "tw", nFloat(s.tw));
        if (keepJoints && s.js) put(t, "js", nByte(s.js));
        if (s.c) put(t, "c", nStr(s.c));
        if (s.tc) put(t, "tc", nStr(s.tc));
        var list = [];
        (s.so || []).slice().sort(function (a, b) { return a.k - b.k; }).forEach(function (o) {
            if (o.k < s.sg && !isIdentity(o)) list.push(saveOverride(o));
        });
        if (list.length) put(t, "so", nList(list));
        return t;
    }
    // CustomHair.save (version 7; 2.2 writes no keep-empty flag)
    function saveHair(h, keepJoints) {
        var t = nComp();
        put(t, "v", nInt(7));
        var name = h && h.name !== undefined && h.name !== null ? String(h.name) : "Custom";
        if (name.length) put(t, "n", nStr(name));
        put(t, "gc", nStr(normColor(h && h.gc) || "#000000"));
        FACES.forEach(function (face, fi) {
            var list = [], strands = (h && h.faces && h.faces[face.key]) || [];
            for (var i = 0; i < face.max; i++) {
                var s = strands[i];
                if (s && s.sg > 0 && s.ln > 0) { s.i = fi * 100 + i; list.push(saveStrand(s, keepJoints)); }
            }
            if (list.length) put(t, face.key, nList(list));
        });
        return t;
    }

    // java.lang.String.hashCode, then HashMap's spread and table size (16, doubling past 3/4 full)
    function javaHash(k) { var h = 0; for (var i = 0; i < k.length; i++) h = (Math.imul(h, 31) + k.charCodeAt(i)) | 0; return h ^ (h >>> 16); }
    function hashOrder(entries) {
        var cap = 16;
        while (entries.length > cap * 0.75) cap *= 2;
        return entries.map(function (e, i) { return { e: e, b: javaHash(e[0]) & (cap - 1), i: i }; })
            .sort(function (a, b) { return a.b - b.b || a.i - b.i; }).map(function (x) { return x.e; });
    }

    // DataOutputStream: big endian, writeUTF = modified UTF-8
    function writeNbt(root) {
        var out = [];
        function u8(v) { out.push(v & 255); }
        function u16(v) { out.push((v >>> 8) & 255, v & 255); }
        function i32(v) { out.push((v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255); }
        var fbuf = typeof Float32Array !== "undefined" ? new Float32Array(1) : null, ibuf = fbuf ? new Int32Array(fbuf.buffer) : null;
        function f32bits(x) {
            if (ibuf) { fbuf[0] = x; return ibuf[0]; }
            if (x === 0) return 1 / x < 0 ? 0x80000000 | 0 : 0;
            if (x !== x) return 0x7FC00000;
            var sign = x < 0 ? 1 : 0; x = Math.abs(x);
            if (x === Infinity) return (sign << 31) | 0x7F800000;
            var e = Math.floor(Math.log(x) / Math.LN2);
            if (Math.pow(2, e) > x) e--; else if (Math.pow(2, e + 1) <= x) e++;
            var m;
            if (e < -126) { m = Math.round(x / Math.pow(2, -149)); e = 0; }
            else { m = Math.round((x / Math.pow(2, e) - 1) * 8388608); e += 127; if (m >= 8388608) { m = 0; e++; } }
            return ((sign << 31) | (e << 23) | m) | 0;
        }
        function utf(str) {
            var b = [];
            for (var i = 0; i < str.length; i++) {
                var c = str.charCodeAt(i);
                if (c >= 1 && c <= 0x7F) b.push(c);
                else if (c <= 0x7FF) b.push(0xC0 | (c >> 6), 0x80 | (c & 63));
                else b.push(0xE0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
            }
            if (b.length > 65535) throw new Error("string too long");
            u16(b.length);
            for (var j = 0; j < b.length; j++) out.push(b[j]);
        }
        function payload(n) {
            switch (n.t) {
                case 1: u8(n.v); break;
                case 3: i32(n.v); break;
                case 5: i32(f32bits(n.v)); break;
                case 8: utf(n.v); break;
                case 9: u8(n.et); i32(n.items.length); n.items.forEach(payload); break;
                case 10:
                    hashOrder(n.e).forEach(function (e) { u8(e[1].t); utf(e[0]); payload(e[1]); });
                    u8(0);
                    break;
                default: throw new Error("nbt type " + n.t);
            }
        }
        u8(10); utf(""); payload(root);
        return out;
    }

    // writing codes needs the engine's Deflater (RPG.codec.deflateBytes / base64EncodeBytes, engine 0.28.1+); reading
    // them works anywhere (the script inflater above). Without it there are no codes to copy or save (the editor is off).
    function canEncode() {
        return typeof RPG !== "undefined" && !!RPG.codec && typeof RPG.codec.deflateBytes === "function" && typeof RPG.codec.base64EncodeBytes === "function";
    }
    function encodeTag(tag) {
        if (!canEncode()) return "";
        return RPG.codec.base64EncodeBytes(RPG.codec.deflateBytes(writeNbt(tag), 9, true), true, false);
    }
    // HairCodec.toCode
    function toCode(h) {
        if (!h) return "";
        var b = encodeTag(saveHair(h, false));
        return b ? "DMZ22:" + b : "";
    }
    // HairCodec.toFullSetCode: every slot's style under its code key (B, S, S2, T, S4)
    function toFullSetCode(styles, keepJoints) {
        var t = nComp();
        SLOTS.forEach(function (slot) { if (styles && styles[slot]) put(t, SLOT_CODE[slot], saveHair(styles[slot], !!keepJoints)); });
        var b = encodeTag(t);
        return b ? "DMZF22:" + b : "";
    }
    // =====================================================================================
    //  Limits (GeneralServerConfig.HairConfig defaults), HairSanitizer, HairStrandSizing
    // =====================================================================================
    var LIMITS = { maxSegments: 12, maxLength: 20, maxWidth: 8, maxRootOffset: 2, maxTotalSegments: 600 };

    // HairSanitizer.sanitize: clamps a style a player sent to the limits; returns how many values changed
    function sanitize(h, limits) {
        var L = limits || LIMITS, F = Math.fround, n = 0, remaining = L.maxTotalSegments;
        if (!h || !h.faces) return 0;
        FACES.forEach(function (face, fi) {
            var list = h.faces[face.key] || [];
            for (var i = 0; i < face.max; i++) {
                var s = list[i];
                if (!s || !(s.sg > 0 && s.ln > 0)) continue;
                if (remaining <= 0) { s.sg = 0; list[i] = null; n++; continue; }
                n += sanitizeStrand(s, fi, i, L);
                if (s.sg > remaining) { s.sg = remaining; n++; }
                remaining -= s.sg;
            }
        });
        return n;
    }
    function sanitizeStrand(s, fi, index, L) {
        var F = Math.fround, n = 0;
        if (s.sg > L.maxSegments) { s.sg = L.maxSegments; n++; }
        var mw = F(L.maxWidth);
        if (s.w > mw) { s.w = clampFF(mw, 0.1, 16, s.w); n++; }
        if (s.d > mw) { s.d = clampFF(mw, 0.1, 16, s.d); n++; }
        var mo = F(L.maxRootOffset);
        var ox = clamp(s.ox, -mo, mo), oy = clamp(s.oy, -mo, mo), oz = clamp(s.oz, -mo, mo);
        if (ox !== s.ox || oy !== s.oy || oz !== s.oz) { s.ox = clampFF(ox, -4, 4, s.ox); s.oy = clampFF(oy, -4, 4, s.oy); s.oz = clampFF(oz, -4, 4, s.oz); n++; }
        var wl = F(mw / s.w), dl = F(mw / s.d), ws = 1, ds = 1;
        for (var k = 0; k < s.sg; k++) {
            var o = getOverride(s, k);
            if (!o) continue;
            if (F(ws * o.ws) > wl) { o.ws = clampFF(F(wl / ws), 0.1, 16, o.ws); n++; }
            if (F(ds * o.ds) > dl) { o.ds = clampFF(F(dl / ds), 0.1, 16, o.ds); n++; }
            ws = F(ws * o.ws); ds = F(ds * o.ds);
        }
        var total = 0, lens = segLengths(s);
        for (k = 0; k < lens.length; k++) total = F(total + F(lens[k] / JF.PX));
        var ml = F(L.maxLength);
        if (total > ml && total > 0) { s.ln = clampFF(F(s.ln * F(ml / total)), 0.1, 128, s.ln); n++; }
        return n;
    }

    // HairPoseBuilder.buildGeometry's segment lengths alone (blocks), the same float steps without the rotations
    function segLengths(s) {
        var F = Math.fround, n = s.sg, out = [], params = [], total = 0, k, lsc = 1;
        for (k = 0; k < n; k++) { var pr = n > 1 ? F(k / (n - 1)) : 0; params[k] = pr; total = F(total + F(Math.pow(s.lr, pr))); }
        for (k = 0; k < n; k++) {
            var ov = getOverride(s, k), weight = F(F(Math.pow(s.lr, params[k])) / total);
            if (ov) lsc = F(lsc * ov.ls);
            out[k] = F(F(F(s.ln * weight) * JF.PX) * lsc);
        }
        return out;
    }

    // HairStrandSizing (the editor's segment / length rules)
    var SEG_MIN = 1, SEG_MAX = 4;
    function resizeLength(s, length, maxSeg, maxLen) {
        var F = Math.fround, n = Math.max(1, s.sg), c = clamp(F(length), SEG_MIN, F(maxLen));
        while (F(c / n) > SEG_MAX && n < maxSeg) n++;
        while (F(c / n) < SEG_MIN && n > 1) n--;
        c = clamp(c, F(n * SEG_MIN), Math.min(F(maxLen), F(n * SEG_MAX)));
        s.sg = clamp(n, 0, 32); s.ln = clampFF(c, 0.1, 128, s.ln);
    }
    function resizeSegments(s, segs, maxSeg, maxLen) {
        var F = Math.fround, n = Math.max(1, Math.min(maxSeg, segs));
        s.sg = n; s.ln = clampFF(clamp(s.ln, F(n * SEG_MIN), Math.min(F(maxLen), F(n * SEG_MAX))), 0.1, 128, s.ln);
    }
    function addSegment(s, maxSeg, maxLen) {
        var F = Math.fround, n = s.sg;
        if (n >= maxSeg) return false;
        var avg = n > 0 ? F(s.ln / n) : F(6 / 4), len = Math.min(F(maxLen), F(s.ln + avg));
        if (F(len / (n + 1)) < SEG_MIN) return false;
        s.sg = n + 1; s.ln = clampFF(len, 0.1, 128, s.ln);
        return true;
    }
    function removeSegment(s) {
        var F = Math.fround, n = s.sg;
        if (n <= 1) return false;
        var avg = F(s.ln / n);
        s.sg = n - 1; s.ln = clampFF(Math.max(SEG_MIN, F(s.ln - avg)), 0.1, 128, s.ln);
        removeOverride(s, n - 1);
        return true;
    }
    // HairStrand.makeVisibleWithDefaults / mirror
    function makeVisible(s) {
        if (s.sg > 0 && s.ln > 0) return;
        s.sg = 4; s.ln = 6; s.lr = Math.fround(0.6); s.w = 2; s.d = 2; s.tp = Math.fround(0.6); s.tg = 1;
    }
    function mirrorStrand(s) {
        var F = Math.fround;
        s.ry = wrapF(-s.ry); s.rz = wrapF(-s.rz); s.by = -s.by; s.bz = -s.bz; s.tw = -s.tw; s.ox = -s.ox;
        s.so.forEach(function (o) { o.ox = -o.ox; o.ry = -o.ry; o.rz = -o.rz; });
    }
    function mirrorFace(fi) { return fi === 2 ? 3 : fi === 3 ? 2 : fi; }
    function mirrorIndex(fi, index) { var c = FACES[fi].cols, row = Math.floor(index / c), col = index % c; return row * c + (c - 1 - col); }
    function visibleCount(h) { var n = 0; FACES.forEach(function (f) { (h.faces[f.key] || []).forEach(function (s) { if (s && s.sg > 0 && s.ln > 0) n++; }); }); return n; }
    function segmentCount(h) { var n = 0; FACES.forEach(function (f) { (h.faces[f.key] || []).forEach(function (s) { if (s && s.sg > 0 && s.ln > 0) n += s.sg; }); }); return n; }

    // Character.resolveOwnStyle: a slot left empty falls back to the base (ssj2/ssj3: the ssj style first; ssj4: the default ssj4)
    function resolveOwn(styles, slot) {
        var own = styles && styles[slot];
        if (own && (!isEmpty(own) || own.keep)) return own;
        var base = (styles && styles.base) || emptyHair(), ssj = styles && styles.ssj;
        if (slot === "base" || slot === "ssj") return base;
        if (slot === "ssj2" || slot === "ssj3") return ssj && !isEmpty(ssj) ? ssj : base;
        return style("DEFAULT_SSJ4_CODE", "base");
    }

    // FNV-1a of a code, the short name of a custom style ("c" + 8 hex digits in the hairStyle look value)
    function codeHash(code) {
        var h = 0x811C9DC5, c = String(code);
        for (var i = 0; i < c.length; i++) { h ^= c.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
        var x = (h >>> 0).toString(16);
        while (x.length < 8) x = "0" + x;
        return x;
    }
    // Custom styles by hash (the server sends each player's code; client scripts draw them as "dmzhc<hash>_<slot>")
    var CUSTOM = {}, CUSTOM_SETS = {};
    function customSet(hash) {
        if (!(hash in CUSTOM_SETS)) CUSTOM_SETS[hash] = CUSTOM[hash] ? fromFullSetCode(CUSTOM[hash], true) : null;
        return CUSTOM_SETS[hash];
    }

    // =====================================================================================
    //  Presets (HairPresets.get) over the pre-decoded data
    // =====================================================================================
    var INDEX = typeof DMZ_HAIR_PRESETS !== "undefined" ? DMZ_HAIR_PRESETS : { order: [], names: {}, ssj4: {} };
    var BALD = 5;
    var files = {};               // client/data/dmz_hair_presets/<name>.json, each read the first time it is needed
    var cache = {};               // "id:slot" -> unpacked style

    // The JSON's array strands back into strand objects (generator: DMZ_HAIR.decodePreset + pack)
    function unpackStrand(a) {
        var s = { i: a[0] | 0, sg: a[1] | 0, ln: a[2], lr: nv(a[3], 1), w: nv(a[4], 2), d: nv(a[5], 2), tp: nv(a[6], 1), tg: nv(a[7], 1),
                  ox: nv(a[8], 0), oy: nv(a[9], 0), oz: nv(a[10], 0), rx: nv(a[11], 0), ry: nv(a[12], 0), rz: nv(a[13], 0),
                  bx: nv(a[14], 0), by: nv(a[15], 0), bz: nv(a[16], 0), tw: nv(a[17], 0), js: 0, c: a[18] || null, tc: a[19] || null, so: [] };
        (a[20] || []).forEach(function (o) {
            s.so.push({ k: o[0] | 0, ox: nv(o[1], 0), oy: nv(o[2], 0), oz: nv(o[3], 0), rx: nv(o[4], 0), ry: nv(o[5], 0), rz: nv(o[6], 0),
                        ls: nv(o[7], 1), ws: nv(o[8], 1), ds: nv(o[9], 1), c: o[10] || null });
        });
        return s;
    }
    function nv(x, fb) { return typeof x === "number" ? Math.fround(x) : fb; }      // the data holds the shortest text of each float
    function unpack(p) {
        var h = { name: "", gc: p.gc || "#000000", keep: !!p.e, faces: {} };
        FACES.forEach(function (face, fi) {
            var out = [];
            (p[face.key] || []).forEach(function (a) {
                var s = unpackStrand(a), index = s.i - fi * 100;
                if (index >= 0 && index < face.max) out[index] = s;
            });
            h.faces[face.key] = out;
        });
        return h;
    }
    // One preset's file (~30 KB) instead of all of them at once: reading the whole set (600 KB) in one go took longer
    // than a frame may, and it happened in the middle of drawing the HUD portrait.
    function presetFile(name) {
        if (!(name in files)) {
            var d = null;
            if (/^[A-Za-z0-9_]{1,40}$/.test(name) && RPG.files && RPG.files.read) {
                try { d = RPG.files.read("dmz_hair_presets/" + name + ".json"); } catch (e) { d = null; }
            }
            files[name] = d || null;
        }
        return files[name];
    }
    function packedStyle(id, slot) {
        var p = presetFile(String(id));
        if (!p) return null;
        var st = p[slot];
        if (typeof st === "string") st = p[st];
        return st || null;
    }
    function style(id, slot) {
        var key = id + ":" + slot;
        if (!(key in cache)) {
            var st = typeof id === "string" ? (presetFile("extra") || {})[id] : packedStyle(id, slot);
            cache[key] = st ? unpack(st) : null;
        }
        return cache[key];
    }

    function presetIds() { return INDEX.order.slice(); }
    function presetName(id) { return INDEX.names[id] || ("Preset " + id); }
    function exists(id) { return !!INDEX.names[id]; }

    // HairPresets.get(presetId, slot)
    function preset(id, slot) {
        if (!exists(id)) return null;
        var hair = style(id, slot);
        if (slot === "ssj4") return hair && (!isEmpty(hair) || hair.keep) ? hair : style(INDEX.ssj4[id] || "DEFAULT_SSJ4_CODE", "base");
        return hair || style(id, "base");
    }

    // Old DBR look values -> preset ids ("base" was the plain cap, "bald" no hair)
    function presetOf(value, race) {
        var v = String(value === undefined || value === null ? "" : value);
        if (/^c[0-9a-f]{8}$/.test(v)) return 0;          // own styles (hairId 0)
        if (v === "bald") return BALD;
        if (v === "base") return defaultPreset(race) || 1;
        var n = parseInt(v, 10);
        if (!isNaN(n) && String(n) === v && (n === 0 || exists(n))) return n;
        return defaultPreset(race);
    }
    // RaceCharacterConfig.defaultHairType: humans and Saiyans Goku (1), Glinds their own (28), the rest none (0)
    function defaultPreset(race) { return race === "glind" ? 28 : race === "human" || race === "saiyan" ? 1 : 0; }
    function hasVisibleHair(id) { return id > 0 && id !== BALD && exists(id); }

    // =====================================================================================
    //  Mapping onto the toolkit's strands
    //  Each strand: {id, pos: [x,y,z] (pixels from the head pivot), rot: [rx,ry,rz] (degrees, X then Y then Z),
    //  segs: [{len, w, d, q: [x,y,z,w] (relative to the previous segment), off: [x,y,z]?, color?}], color?, tip?}
    // =====================================================================================
    function r4(v) { return Math.round(v * 10000) / 10000; }

    function toStrands(hair, ownColors) {
        var out = [];
        if (!hair) return out;
        FACES.forEach(function (face, fi) {
            var list = hair.faces[face.key] || [];
            for (var index = 0; index < list.length; index++) {
                var s = list[index];
                if (!s || s.sg <= 0) continue;
                var p = poseOf(s, fi, index), segs = [];
                for (var k = 0; k < p.seg; k++) {
                    var q = p.rel[k], o = p.offs[k];
                    var sd = { len: r4(p.lengths[k] * PIXEL), w: r4(p.widths[k] * PIXEL), d: r4(p.depths[k] * PIXEL) };
                    if (Math.abs(q[0]) + Math.abs(q[1]) + Math.abs(q[2]) > 1e-6) sd.q = [r4(q[0]), r4(q[1]), r4(q[2]), r4(q[3])];
                    if (Math.abs(o[0]) + Math.abs(o[1]) + Math.abs(o[2]) > 1e-6) sd.off = [r4(o[0]), r4(o[1]), r4(o[2])];
                    var ov = ownColors ? getOverride(s, k) : null;
                    if (ov && ov.c) sd.color = ov.c;
                    segs.push(sd);
                }
                var st = { id: s.i, pos: [r4(p.root[0]), r4(p.root[1]), r4(p.root[2])], rot: [r4(s.rx), r4(s.ry), r4(s.rz)], segs: segs };
                if (ownColors && s.c) st.color = s.c;
                if (ownColors && s.tc) st.tip = s.tc;
                out.push(st);
            }
        });
        return out;
    }

    // Engine style names: "dmzh<preset>_<slot>" with own strand colours, "...f" when the form forces the colour
    // (HairStyleResolver: a form hair colour override draws every strand in the form colour).
    // forced: true / false, or a look value suffix ("{dmzHelmF}": "f" while a helmet look paints the hair, 27_dbr_quirks.js)
    function styleName(slot, forced) { return "dmzh{hairStyle}_" + slot + (typeof forced === "string" ? forced : forced ? "f" : ""); }

    // HairStyleResolver forcedHairCode: a form that brings its own hairstyle (an extra.json style, e.g. The Ragnarok original's
    // Super Saiyan 5) draws it instead of the player's preset: "dmzx.<code>" with own colours, "dmzx.<code>.f" forced
    var EXTRA_CODES = ["DEFAULT_SSJ4_CODE", "DEFAULT_SSJ3_CODE", "LONG_SSJ3_CODE", "TRUNKS_SSJ4_CODE", "GOHAN_SSJ4_CODE", "DMZR_SSJ5_CODE"];
    function forcedStyleName(code, forced) { return "dmzx." + code + (forced ? ".f" : ""); }

    function strandsFor(styleId) {
        var x = /^dmzx\.([A-Za-z0-9_]{1,40})(\.f)?$/.exec(String(styleId));
        if (x) return toStrands(style(x[1], "base"), !x[2]);
        var m = /^dmzh([A-Za-z0-9]+)_(base|ssj|ssj2|ssj3|ssj4)(f?)$/.exec(String(styleId));
        if (!m) return null;
        var cm = /^c([0-9a-f]{8})$/.exec(m[1]);
        if (cm) {                                         // the player's own styles (the original's hairId 0)
            var set = customSet(cm[1]);
            return set ? toStrands(resolveOwn(set, m[2]), m[3] !== "f") : null;
        }
        var id = presetOf(m[1], "");
        if (id <= 0) return [];
        return toStrands(preset(id, m[2]), m[3] !== "f");
    }

    // HairPhysicsProfile.defaultFor(slot): stiffness, damping, gravity, max deviation (degrees)
    var PHYSICS = {
        base: { stiffness: 0.30, damping: 1.00, gravity: 0.10, maxAngle: 50 },
        ssj: { stiffness: 0.45, damping: 1.00, gravity: 0.03, maxAngle: 30 },
        ssj2: { stiffness: 0.45, damping: 1.00, gravity: 0.03, maxAngle: 30 },
        ssj3: { stiffness: 0.32, damping: 0.95, gravity: 0.12, maxAngle: 70 },
        ssj4: { stiffness: 0.30, damping: 1.00, gravity: 0.12, maxAngle: 55 }
    };

    // The hair block's physics (HairEntityState's inputs): the slot's profile; kiChargeProgress follows the ki charge
    // (and a transformation's), auraIntensity the aura being shown. `aura`: the transformation charge factor (0-1)
    // while one charges (HairStyleResolver: auraIntensity = max(aura tint, charge factor)).
    function physicsBlock(ph, aura) {
        var b = { stiffness: ph.stiffness, damping: ph.damping, gravity: ph.gravity, maxAngle: ph.maxAngle, energy: ["charge", "tf"], aura: ["dmzAuraOn"] };
        if (aura > 0) b.auraLevel = aura;
        return b;
    }

    // The avatar `hair` block for a slot ("base", "ssj"... or "" / "empty" for none). colorName: the
    // player colour the hair takes ("hair", "fHair"); forced: the form overrides the hair colour.
    // code: a forced hairstyle (forcedStyleName); its physics stay the slot's (the original keeps the form's hairType slot)
    function avatarHair(slot, colorName, forced, code) {
        if (!slot || slot === "empty" || SLOTS.indexOf(slot) < 0) return null;
        var ph = PHYSICS[slot];
        return {
            style: code ? forcedStyleName(code, forced === true) : styleName(slot, forced), color: colorName || "hair", bone: "head",
            texture: (typeof DMZ_TEX !== "undefined" ? DMZ_TEX : "dmzpack:textures/entity/") + "races/hair.png", transition: 8,
            // helmetsThatKeepHair: the hair shows under these helmets, any other head item hides it
            helmet: typeof DBR_QUIRKS_DATA !== "undefined" ? DBR_QUIRKS_DATA.keepHairIds() : "hide",
            physics: physicsBlock(ph)
        };
    }

    // Client: register every preset x slot lazily (the engine builds a style the first time a player shows it)
    if (RPG.isClient() && RPG.avatar && RPG.avatar.defineHair) {
        var names = ["bald", "base"].concat(INDEX.order.map(String));
        names.forEach(function (n) {
            SLOTS.forEach(function (slot) {
                ["", "f"].forEach(function (f) {
                    var id = "dmzh" + n + "_" + slot + f;
                    RPG.avatar.defineHair(id, function () { return strandsFor(id); });
                });
            });
        });
        EXTRA_CODES.forEach(function (code) {
            [false, true].forEach(function (f) { var id = forcedStyleName(code, f); RPG.avatar.defineHair(id, function () { return strandsFor(id); }); });
        });
    }

    // Client: custom styles arrive from the server as {hash: code}; each hash's slots are registered once
    function registerCustom(hash) {
        if (!RPG.isClient() || !RPG.avatar || !RPG.avatar.defineHair) return;
        SLOTS.forEach(function (slot) {
            ["", "f"].forEach(function (f) { var id = "dmzhc" + hash + "_" + slot + f; RPG.avatar.defineHair(id, function () { return strandsFor(id); }); });
        });
    }
    function addCodes(map) {
        Object.keys(map || {}).forEach(function (hash) {
            if (!/^[0-9a-f]{8}$/.test(hash) || typeof map[hash] !== "string") return;
            if (CUSTOM[hash] === map[hash]) return;
            CUSTOM[hash] = map[hash]; delete CUSTOM_SETS[hash];
            registerCustom(hash);
        });
    }
    if (RPG.isClient() && RPG.net && RPG.net.on) {
        RPG.net.on("dmz_hair_codes", function (d) { addCodes(d && d.codes); });
        RPG.on("load", function () { try { RPG.net.send("dmz_hair_sync", {}); } catch (e) { } });
    }

    return {
        SLOTS: SLOTS, BALD: BALD, PHYSICS: PHYSICS, physicsBlock: physicsBlock, LIMITS: LIMITS, FACES: FACES, BASE_ROT: BASE_ROT,
        sanitize: sanitize, resizeLength: resizeLength, resizeSegments: resizeSegments, addSegment: addSegment, removeSegment: removeSegment,
        makeVisible: makeVisible, mirrorStrand: mirrorStrand, mirrorFace: mirrorFace, mirrorIndex: mirrorIndex, defaultStrand: defaultStrand,
        visibleCount: visibleCount, segmentCount: segmentCount, resolveOwn: resolveOwn, codeHash: codeHash, customSet: customSet, addCodes: addCodes,
        customCode: function (hash) { return CUSTOM[hash] || null; },
        cacheSet: function (hash, code, set) { CUSTOM[hash] = code; CUSTOM_SETS[hash] = set; }, basePosition: basePosition, getOverride: getOverride,
        getOrCreateOverride: getOrCreateOverride, removeOverride: removeOverride, isIdentity: isIdentity, poseExact: poseExact, JF: JF,
        wrapF: wrapF, clampFF: clampFF, normColor: normColor, extraStyle: function (name) { return style(name, "base"); },
        decode: fromCode, decodeFullSet: fromFullSetCode, decodePreset: decodePreset, decodeTag: decodeTag,
        isFullSetCode: isFullSetCode, toCode: toCode, toFullSetCode: toFullSetCode, canEncode: canEncode, emptyHair: emptyHair, copyHair: copyHair,
        _save: saveHair, _nbtBytes: writeNbt,
        preset: preset, presetIds: presetIds, presetName: presetName, exists: exists, presetOf: presetOf,
        defaultPreset: defaultPreset, hasVisibleHair: hasVisibleHair, isEmpty: isEmpty,
        toStrands: toStrands, strandsFor: strandsFor, avatarHair: avatarHair, styleName: styleName, EXTRA_CODES: EXTRA_CODES,
        _inflate: inflate, _base62: decodeBase62, _nbt: readNbt, _pose: poseOf, _migrate: migrateStrand
    };
})();
