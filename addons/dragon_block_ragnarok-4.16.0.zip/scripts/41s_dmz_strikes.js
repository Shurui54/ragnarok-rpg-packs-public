// =====================================================================================
//  41s_dmz_strikes.js - the original's strike attacks (StrikeAttackHandler), tick by tick
// =====================================================================================
//  41_dmz_techniques.js checks the requirements (ki control, release, empty hand, cooldowns)
//  and hands the cast here. Like the original:
//   - target: the lock (Z) or the crosshair in a 60 degree cone (6 blocks, 12 flying); a target
//     in the cone gets you teleported to it at once ("tp_short"); a lock out of the cone starts a
//     40-tick rush (fast flight at 0.9-1.5 b/t) that connects within 1.8 blocks; no target at all:
//     the targetless strikes swing at whatever stands in front, the rest rush ahead looking for one
//     and fizzle (half cooldown, half global cooldown, 40 % of the ki back).
//   - damage: strike damage x the technique's multiplier; 65 % spread over one hit every 10 ticks
//     (one at the engage), 35 % on the final hit; a hit that isn't the last never kills (leaves 1 HP).
//   - the final hit knocks back (1.8 away, or the strike's own push); a victim thrown into a wall
//     or the ground within 1.2 s takes 20 % more (MomentumImpactHandler).
//   - attacker and target are held still (strike lock) for the whole strike; a stunned or knocked
//     down attacker breaks off (half cooldown). Cooldowns start when the strike ends.
//   - each hit plays the victim's flyback / hurt pose (players) and a shockwave in the strike's colour.
//  Masters and other invulnerable NPCs are never targeted (resolveRushLockTarget skips MastersEntity).
//  The choreographed ones (meteor, deadly dance, gum punch, super god fist, kaioken attack, wolf fang,
//  dragon fist, oozaru fist, oozaru slam, spirit breaking cannon, combo meteor, grab, shining sword attack,
//  dimensional punch and slash) follow the original's tick tables; the eight long combos (meteor burst, mystic
//  ball, darkness eye beam, death chaser, android combo, beam sword slash, perfect rush, spirit breaker) are
//  41c_dmz_strike_combos.js. Sword slashes (shining sword, dimensional slash) fly as a few numbers here, drawn
//  by the clients from one message each (SwordSlashManager / SwordSlashEffect).
//  StrikeCinematics: a strike that connects with a target films the attacker and a player victim
//  (client/scripts/49c_dmz_strike_camera.js). Two rushes meeting head on start a strike clash (41sx_dmz_strike_clash.js).
// =====================================================================================
RPG.effects.define("dmz_strike_locked", { name: "&7Strike", color: "#AAAAAA", hidden: true, flags: ["noMove", "noJump", "noAttack", "noSkills"] });
// the striker: can't walk off or jump, but the strike itself still moves them (dashes, rushes), so no noMove
RPG.effects.define("dmz_striking", { name: "&7Strike", color: "#AAAAAA", hidden: true, flags: ["noJump", "noAttack", "noSkills"],
    attributes: { "minecraft:generic.movement_speed": { amount: -1, operation: "multiply_total" } } });

var DMZ_STRIKES = (function () {
    var CONE = 6, CONE_FLY = 12, CONE_COS = 0.5, RUSH_TICKS = 40, RUSH_LOCK_RANGE = 64, RUSH_CONNECT = 1.8, RUSH_GRAB = 1.2,
        RUSH_SNAP_GAP = 1.0, RUSH_HOLD = 0.8, KNOCKBACK = 1.8, FINAL_RATIO = 0.35, IMPACT_RATIO = 0.2, INTERVAL = 10, FRONT_REACH = 1.3;
    var TARGETLESS = { dragon_fist: 1, deadly_dance: 1, deadly_dance_vegetto: 1, super_god_fist: 1, wolf_fang: 1, gum_punch: 1 };
    var NO_ENGAGE = { grab: 1, shining_sword_attack: 1, combo_meteor: 1, meteor_burst: 1, mystic_ball: 1, darkness_eye_beam: 1, death_chaser: 1,
        android_combo: 1, beam_sword_slash: 1, perfect_rush: 1, spirit_breaker: 1 };
    var POSE_DRIVEN = { spirit_breaking_cannon: 1, grab: 1, combo_meteor: 1, meteor_burst: 1, mystic_ball: 1, darkness_eye_beam: 1, death_chaser: 1,
        android_combo: 1, beam_sword_slash: 1, perfect_rush: 1, spirit_breaker: 1 };
    var FLINCH = { meteor: 1, wolf_fang: 1, kaioken_attack: 1, deadly_dance: 1, deadly_dance_vegetto: 1, shining_sword_attack: 1, dimensional_punch: 1,
        dimensional_sword_attack: 1 };
    var SHOCK_COLOR = { wolf_fang: "#4D9EFF", deadly_dance: "#FFE23A", deadly_dance_vegetto: "#2FA8FF", super_god_fist: "#F5C527", kaioken_attack: "#FF5A3A",
        spirit_breaking_cannon: "#A63EF0", gum_punch: "#FF82F3", mystic_ball: "#FF82F3", darkness_eye_beam: "#FF8A00", death_chaser: "#B57CFF",
        android_combo: "#FF3B3B", perfect_rush: "#FFC93C", spirit_breaker: "#FFD23C" };
    // the combos that start where they stand (their own dash), never teleported in front of the target or snapped to it
    var DIRECT = { meteor_burst: 1, darkness_eye_beam: 1, death_chaser: 1, android_combo: 1, beam_sword_slash: 1, perfect_rush: 1, spirit_breaker: 1 };
    // StrikeAttackHandler.CINEMATIC_STRIKES: these film the fight (StrikeCinematics)
    var CINEMATIC = { meteor: 1, dragon_fist: 1, deadly_dance: 1, deadly_dance_vegetto: 1, kaioken_attack: 1, wolf_fang: 1, oozaru_fist: 1, super_god_fist: 1,
        spirit_breaking_cannon: 1, grab: 1, shining_sword_attack: 1, combo_meteor: 1, meteor_burst: 1, mystic_ball: 1, darkness_eye_beam: 1, death_chaser: 1,
        android_combo: 1, beam_sword_slash: 1, perfect_rush: 1, spirit_breaker: 1 };
    var PUNCH = ["punch1", "punch2", "punch3", "punch4", "punch5", "punch6"];
    var COMBO_METEOR_HITS = [5, 8, 13, 18, 22, 26, 30, 38, 43, 47, 51, 55, 58, 65, 69, 72];
    function COMBOS() { return typeof DMZ_STRIKE_COMBOS !== "undefined" ? DMZ_STRIKE_COMBOS : null; }
    function CLASH() { return typeof DMZ_STRIKE_CLASH !== "undefined" ? DMZ_STRIKE_CLASH : null; }

    var ACTIVE = {}, PENDING = {}, FLINCH_SIDE = {};
    var H = null;                                          // 41_dmz_techniques.js helpers (cooldowns, xp, state)

    function d2r(a) { return a * Math.PI / 180; }
    function lookVec(p) { var y = d2r(p.yaw), pt = d2r(p.pitch); return { x: -Math.sin(y) * Math.cos(pt), y: -Math.sin(pt), z: Math.cos(y) * Math.cos(pt) }; }
    function flatLook(p) { var y = d2r(p.yaw); return { x: -Math.sin(y), y: 0, z: Math.cos(y) }; }
    function norm(v) { var l = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z) || 1; return { x: v.x / l, y: v.y / l, z: v.z / l }; }
    function alive(e) { try { return !!e && e.isAlive(); } catch (er) { return false; } }
    function yawTo(a, b) { return Math.atan2(-(b.x - a.x), b.z - a.z) * 180 / Math.PI; }
    function pitchTo(a, b) { var dx = b.x - a.x, dz = b.z - a.z, dy = (b.y + b.height * 0.85) - (a.y + 1.62); return -Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180 / Math.PI; }
    function players(e) { return e && e.isPlayer() ? e.asPlayer() : null; }

    // TargetHelper.canAttack: never allies, never masters / standing invulnerable NPCs
    function attackable(p, e) {
        if (!e || e.uuid === p.uuid || !alive(e)) return false;
        try { if (p.isAlly(e)) return false; } catch (er) { }
        if (!e.isPlayer() && e.invulnerable) return false;
        if (e.isPlayer()) { var g = e.asPlayer().getGameMode(); if (g === "creative" || g === "spectator") return false; }
        return true;
    }
    function inCone(p, e) {
        var lk = lookVec(p), dx = e.x - p.x, dy = (e.y + e.height * 0.85) - (p.y + 1.62), dz = e.z - p.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
        return (dx * lk.x + dy * lk.y + dz * lk.z) / l >= CONE_COS;
    }
    // findConeTarget: the preferred target if it is in the cone, else the one nearest the crosshair ray
    function coneTarget(p, range, pref) {
        if (pref && attackable(p, pref) && p.distanceTo(pref) <= range && inCone(p, pref) && p.canSee(pref)) return pref;
        var best = null, bd = 1e9, lk = lookVec(p), ex = p.x, ey = p.y + 1.62, ez = p.z;
        p.nearby(range).forEach(function (e) {
            if (!attackable(p, e) || p.distanceTo(e) > range || !inCone(p, e) || !p.canSee(e)) return;
            // distance from the eye ray to the entity's middle, along-ray distance as the tie-break
            var cx = e.x - ex, cy = e.y + e.height / 2 - ey, cz = e.z - ez, t = cx * lk.x + cy * lk.y + cz * lk.z;
            var px = cx - lk.x * t, py = cy - lk.y * t, pz = cz - lk.z * t, off = Math.sqrt(px * px + py * py + pz * pz) - Math.max(e.width, e.height) / 2;
            var dist = Math.max(0, off) * 100 + t;
            if (dist < bd) { bd = dist; best = e; }
        });
        return best;
    }
    function frontVictim(p) {                                  // findFrontVictim: what stands right in front
        var f = flatLook(p), cx = p.x + f.x * FRONT_REACH, cz = p.z + f.z * FRONT_REACH, best = null, bd = 1e9;
        RPG.world.entitiesNear(p.dimension, cx, p.y + 0.9, cz, 1.6).forEach(function (e) {
            if (!attackable(p, e) || Math.abs(e.y - p.y) > 1.8) return;
            if (Math.abs(e.x - cx) > 0.6 + 0.3 + e.width / 2 || Math.abs(e.z - cz) > 0.6 + 0.3 + e.width / 2) return;
            var d = p.distanceTo(e);
            if (d < bd) { bd = d; best = e; }
        });
        return best;
    }
    function gap(p, t) {                                       // rushGap: from the attacker's middle to the target's box
        var mx = p.x, my = p.y + 0.9, mz = p.z, hw = t.width / 2;
        var dx = Math.max(0, Math.abs(mx - t.x) - hw), dy = Math.max(0, Math.max(t.y - my, my - (t.y + t.height))), dz = Math.max(0, Math.abs(mz - t.z) - hw);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // ---- moving people ----
    function freeze(e) { try { e.setVelocity(0, e.isPlayer() ? 0 : Math.min(0, e.vy), 0); } catch (er) { } }
    function face(p, t) {                                      // faceStrikeTarget (players turn with a rotation-only teleport)
        if (!t) return;
        var yaw = yawTo(p, t), pitch = pitchTo(p, t);
        if (p.isPlayer()) p.asPlayer().teleportTo(p.dimension, p.x, p.y, p.z, yaw, pitch);
        else try { p.lookAt(t.x, t.y + t.height * 0.85, t.z); } catch (er) { }
    }
    function kb(e, x, y, z) {                                  // KnockbackHelper.apply: the velocity is set, not added
        unlock(e);                                             // a held player is let go first, or the hold would eat the throw
        try { e.setVelocity(x, y, z); } catch (er) { }
    }
    function lock(e, ticks) { var ep = players(e); if (ep) ep.addEffect("dmz_strike_locked", ticks); }
    function unlock(e) { var ep = players(e); if (ep && ep.hasEffect("dmz_strike_locked")) ep.removeEffect("dmz_strike_locked"); }
    function striking(p, on, ticks) { if (on) p.addEffect("dmz_striking", ticks); else if (p.hasEffect("dmz_striking")) p.removeEffect("dmz_striking"); }

    // ---- visuals ----
    function viewers(e) {
        return RPG.server.players().filter(function (v) { try { return v.dimension === e.dimension && Math.abs(v.x - e.x) < 96 && Math.abs(v.z - e.z) < 96; } catch (er) { return false; } });
    }
    function fx(where, msg) { viewers(where).forEach(function (v) { RPG.net.send(v, "dmz_strike_fx", msg); }); }
    function impactPoint(p, victim, ratio) {
        if (victim) return { x: victim.x, y: victim.y + victim.height * ratio, z: victim.z, dimension: victim.dimension };
        var f = flatLook(p);
        return { x: p.x + f.x * FRONT_REACH, y: p.y + 1.8 * ratio, z: p.z + f.z * FRONT_REACH, dimension: p.dimension };
    }
    function shockwave(p, t, id, last) {                       // spawnHitShockwave
        if (id === "oozaru_slam" || id === "shining_sword_attack") return;
        var size = Math.max(1, t.height / 1.8), cx = t.x, cy = t.y + t.height * 0.6, cz = t.z;
        var ax = p.x - t.x, az = p.z - t.z, al = Math.sqrt(ax * ax + az * az);
        if (al > 0.01) { cx += ax / al * t.width * 0.5; cz += az / al * t.width * 0.5; }
        fx(t, { t: "shock", x: cx, y: cy, z: cz, s: (last ? 4.5 : 1.8) * size, c: SHOCK_COLOR[id] || "#FFF3D6", life: last ? 13 : 7 });
    }
    function burstFx(where, at, dir, scale, c1, c2, ticks) { fx(where, { t: "burst", x: at.x, y: at.y, z: at.z, d: [dir.x, dir.y, dir.z], s: scale, c: c1, c2: c2, life: ticks }); }
    function boom(where, x, y, z, size, c1, c2) {             // KiExplosionVisualEntity
        RPG.server.players().forEach(function (v) {
            try { if (v.dimension === where.dimension && Math.abs(v.x - x) < 160 && Math.abs(v.z - z) < 160) RPG.net.send(v, "dmz_ki_fx", { x: x, y: y, z: z, v: size * 2, p: size * 1.8, c: [c1, c2, c2] }); } catch (er) { }
        });
    }
    function anim(e, a) { var ep = players(e); if (ep) act(ep, a, 40); }
    function stopAnim(e) { var ep = players(e); if (ep) stopAct(ep); }
    function snd(where, s, vol, pitch) { sfx(where, s, vol, pitch); }

    // ---- damage ----
    function hit(s, victim, dmg, last) {                       // applyStrikeDamage
        if (!victim || dmg <= 0 || !alive(victim)) return;
        if (!last && victim.health - dmg <= 1) dmg = Math.max(0.01, victim.health - 1);
        if (!POSE_DRIVEN[s.id] && victim.isPlayer()) {          // playStrikeHitAnimation
            var a = "base.flyback";
            if (FLINCH[s.id]) { var left = !FLINCH_SIDE[s.p.uuid]; FLINCH_SIDE[s.p.uuid] = left; a = left ? "base.hurt_left" : "base.hurt_right"; }
            anim(victim, a);
        }
        shockwave(s.p, victim, s.id, last);
        victim.damageFrom(dmg, s.p, { kind: "strike", tag: "dmzstrike:" + s.id, ignoreIFrames: true, knockback: 0 });
        if (H) H.addXp(s.p, s.id, 1);
    }
    function killXp(s, victim) { if (H && victim && !alive(victim)) H.addXp(s.p, s.id, 2); }
    function killXpLater(s, victim) { RPG.schedule(1, function () { killXp(s, victim); }); }   // grantKillXpIfNeeded after the impact's hit
    // MomentumImpactHandler.registerStrikeCollisionImpact: a thrown victim hitting a wall / the ground within 1.2 s
    function impact(s, victim, dir, ground) {
        if (!victim || !alive(victim)) return;
        // the original's collision impact (stun + faint pose, parry clang, rock ring, crater, impact frame): 11b_dmz_impacts.js
        DMZ_IMPACTS.register(victim, ground ? "ground" : "wall", { dir: dir, dmg: s.total * IMPACT_RATIO, by: s.p, tag: "dmzstrike:" + s.id,
            onHit: function (v) { killXpLater(s, v); } });
    }
    function knock(s, victim, dmg) {                           // applyKnockback
        var dx = victim.x - s.p.x, dy = victim.y - s.p.y, dz = victim.z - s.p.z, l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        var d = l < 1e-3 ? lookVec(s.p) : { x: dx / l, y: dy / l, z: dz / l };
        kb(victim, d.x * KNOCKBACK, d.y * KNOCKBACK, d.z * KNOCKBACK);
        anim(victim, "base.flyback");
        impact(s, victim, d, victim.isOnGround() || d.y < -0.5);
    }

    // ---- start / end ----
    function begin(p, id, t, pend) {                          // startStrike / startTargetlessStrike
        var dur = Math.max(20, pend.dur), hits = Math.max(1, Math.ceil(dur / INTERVAL));
        var s = { p: p, id: id, t: t || null, tick: 0, dur: pend.dur, durMin: dur, total: pend.total, per: pend.total * (1 - FINAL_RATIO) / hits,
            fin: pend.total * FINAL_RATIO, cd: pend.cd, anim: pend.anim, sound: pend.sound };
        ACTIVE[p.uuid] = s;
        cine(p, t, id);
        if (t && !NO_ENGAGE[id]) hit(s, t, s.per, false);
        striking(p, true, dur + 40);
        if (t) lock(t, dur + 40);
        if (t && id !== "dragon_fist") face(p, t);
        if (t && t.isPlayer()) face(t, p);
        act(p, pend.anim, dur + 5);
        if (pend.sound) snd(p, pend.sound, 1, 1);
        if (COMBOS() && COMBOS().has(id)) { s.combo = {}; s.C = performer(s); }
        return s;
    }
    // the performer the combos (41c_dmz_strike_combos.js) act through
    function performer(s) {
        var p = s.p, kiRatio = (TD().STRIKE[s.id] && TD().STRIKE[s.id].kiRatio) || 1;
        return {
            p: p, t: s.t, id: s.id, strikeBudget: s.total,
            kiBudget: H.kiDamage ? H.kiDamage(p) * kiRatio : 0,      // stats.getKiDamage() x the combo's KI_RATIO
            bladeColor: bladeColor(p), modelScale: modelScale(p),
            place: function (at, yaw) { p.teleportTo(p.dimension, at.x, at.y, at.z, yaw, p.pitch); p.setVelocity(0, 0, 0); p.fallDistance = 0; },
            feet: function (at) { p.teleportTo(p.dimension, at.x, at.y, at.z, p.yaw, p.pitch); p.setVelocity(0, 0, 0); p.fallDistance = 0; },
            strikeHit: function (v, amount, lethal) { hit(s, v, amount, lethal); if (lethal) killXp(s, v); },
            kiHit: function (v, amount, lethal) {
                if (!v || !alive(v)) return;
                var dmg = amount * (H.dmgMod ? H.dmgMod(p) : 1);
                if (!lethal && v.health - dmg <= 1) dmg = Math.max(0.01, v.health - 1);
                if (dmg <= 0) return;
                v.damageFrom(dmg, p, { kind: "ki", tag: "dmzstrike:" + s.id, ignoreIFrames: true, knockback: 0 });
                if (lethal) killXpLater(s, v);
            },
            fx: function (at, msg) { fx(at.dimension ? at : { dimension: p.dimension, x: at.x, y: at.y, z: at.z }, msg); },
            snd: function (at, sound, vol, pitch) { snd(at.dimension ? at : { dimension: p.dimension, x: at.x, y: at.y, z: at.z }, sound, vol, pitch); },
            frame: function (th, l, k, inv) { if (typeof DMZ_IMPACT !== "undefined") DMZ_IMPACT.play(p, th, l, k, inv); },
            shake: function (full, radius) { fx(p, { t: "kb", e: p.entityId, f: full ? 1 : 0, r: radius }); }
        };
    }
    function bladeColor(p) {                                   // KiWeaponHelper.resolveColorForType("blade", the aura colour)
        try { if (typeof DMZ_KIWEAPON !== "undefined" && DMZ_KIWEAPON.bladeColor) { var n = parseInt(String(DMZ_KIWEAPON.bladeColor(p)).replace("#", ""), 16); if (!isNaN(n)) return n; } } catch (e) { }
        return 0x7FD8FF;
    }
    function modelScale(p) { try { var s = Number(p.getShared("dmzModelScale")); if (s > 0) return s; } catch (e) { } return 0.9375; }
    // StrikeCinematics.startStrike / stop: the attacker and a player victim film the fight (their own setting can turn it off)
    var CINE = {};                                             // attacker uuid -> victim player (or null)
    function cine(p, t, id) {
        if (!t || !CINEMATIC[id]) { cineStop(p); return; }
        var cur = CINE[p.uuid];
        if (cur && cur.t === t.uuid) return;
        cineStop(p);
        var msg = { on: 1, a: p.entityId, v: t.entityId };
        RPG.net.send(p, "dmz_strike_cine", msg);
        if (t.isPlayer()) RPG.net.send(t.asPlayer(), "dmz_strike_cine", msg);
        CINE[p.uuid] = { t: t.uuid, v: t.isPlayer() ? t.asPlayer() : null };
    }
    function cineStop(p) {
        var c = CINE[p.uuid];
        if (!c) return;
        delete CINE[p.uuid];
        var msg = { on: 0, a: p.entityId };
        try { if (p.isConnected()) RPG.net.send(p, "dmz_strike_cine", msg); } catch (e) { }
        try { if (c.v && c.v.isConnected()) RPG.net.send(c.v, "dmz_strike_cine", msg); } catch (e2) { }
    }
    function end(s, interrupted) {                             // endStrike
        if (ACTIVE[s.p.uuid] !== s) return;
        delete ACTIVE[s.p.uuid];
        delete FLINCH_SIDE[s.p.uuid];
        cineStop(s.p);
        if (s.combo && COMBOS()) COMBOS().release(s.id, s.C, s.combo);
        if (s.grabbed) { unlock(s.grabbed); if (s.grabbed.isPlayer()) stopAnim(s.grabbed); }
        striking(s.p, false);
        if (s.t) { unlock(s.t); if (s.t.isPlayer()) stopAnim(s.t); }
        stopAct(s.p);
        if (s.id === "kaioken_attack") s.p.setShared("dmzStrikeAura", null);
        H.setCd(s.p, s.id, H.creative(s.p) ? 20 : interrupted ? Math.max(1, Math.floor(s.cd / 2)) : s.cd);
        H.setCd(s.p, "strike_global", TD().STRIKE_GLOBAL_COOLDOWN);
        H.sendState(s.p);
    }
    function fail(p, pend) {                                   // failPending: half cooldown, half global, 40 % of the ki back
        delete PENDING[p.uuid];
        cineStop(p);
        rushVisuals(p, false);
        if (!H.creative(p)) p.addResource("ki", pend.cost * 0.4);
        H.setCd(p, pend.id, Math.max(1, Math.floor(pend.cd / 2)));
        H.setCd(p, "strike_global", Math.round(TD().STRIKE_GLOBAL_COOLDOWN * 0.5));
        p.actionbar("&7No target in range.");
        H.sendState(p);
    }
    function rushVisuals(p, on) { p.setShared("rgDash", on ? 1 : null); p.setShared("flyFast", on ? 1 : (typeof DMZ_FLIGHT !== "undefined" && DMZ_FLIGHT.fast(p) ? 1 : null)); }
    function TD() { return DMZ_TECH_DATA; }

    // teleportToTargetFront: 1.3 blocks along the target's own look, behind it from where it faces
    function teleportFront(p, t, faceIt) {
        var y = d2r(t.yaw), pt = d2r(t.pitch || 0), lx = -Math.sin(y) * Math.cos(pt), lz = Math.cos(y) * Math.cos(pt);
        var x = t.x - lx * 1.3, z = t.z - lz * 1.3, yaw = faceIt ? yawTo({ x: x, z: z }, t) : p.yaw;
        p.teleportTo(p.dimension, x, t.y, z, yaw, faceIt ? pitchTo({ x: x, y: t.y, z: z }, t) : p.pitch);
    }
    function snap(p, t) {                                      // snapToRushTarget
        var ax = t.x - p.x, az = t.z - p.z, l = Math.sqrt(ax * ax + az * az);
        if (l < 1e-3) { var f = flatLook(p); ax = f.x; az = f.z; l = 1; }
        ax /= l; az /= l;
        var dist = t.width * 0.5 + RUSH_SNAP_GAP, x = t.x - ax * dist, z = t.z - az * dist;
        p.teleportTo(p.dimension, x, t.y, z, yawTo({ x: x, z: z }, t), pitchTo({ x: x, y: t.y, z: z }, t));
    }
    function rushSpeed(p) {
        var lvl = typeof DMZ_SKILLS !== "undefined" ? DMZ_SKILLS.level(p, "fly") : 0;
        return Math.max(0.9, Math.min(1.5, 1.05 * (1 + 0.2 * lvl) * 0.6));
    }

    // ---- cast (requestStrike) ----
    function cast(p, id, helpers) {
        H = helpers;
        if (ACTIVE[p.uuid] || PENDING[p.uuid]) return;
        var S = TD().STRIKE[id], r = H.rec(p, id) || {};
        if (!S || H.cdLeft(p, id) > 0 || H.cdLeft(p, "strike_global") > 0) return;
        if (p.hasEffect("stunned") || (CLASH() && CLASH().isClashing(p.uuid))) return;
        // StrikeAttackData.getCalculatedCost (a combo's KI_RATIO only scales its ki damage, not the cost)
        var cost = TD().strikeCost(id, H.strikeNoForms(p), r.d);
        if (!H.creative(p)) {
            if (p.resource("ki") < cost) { H.msg(p, "message.dragonminez.technique.no_ki", [Math.ceil(cost)]); return; }
            p.addResource("ki", -cost);
        }
        var pend = { id: id, anim: S.anim, dur: S.dur, cd: H.creative(p) ? 20 : TD().strikeCooldown(id, r.c), cost: cost, sound: S.sound,
            total: H.strikeDamage(p) * TD().strikeActualMult(id, r.d), ticks: RUSH_TICKS, target: null };
        if (id === "oozaru_slam") { begin(p, id, null, pend); return; }
        if (id === "dimensional_punch") {                      // startDimensionalPunch: no teleport, a target up to 26 blocks off
            var ds = begin(p, id, null, pend);
            ds.dimT = coneTarget(p, DIM.RANGE, lockedTarget(p));
            return;
        }
        if (id === "dimensional_sword_attack") {               // startDimensionalSlash: no teleport, three cuts at a target up to 40 blocks off
            var dz = begin(p, id, null, pend);
            dz.dimT = coneTarget(p, SLASH.DIM_RANGE, lockedTarget(p));
            return;
        }
        var range = S.range || (p.isFlying() ? CONE_FLY : CONE);
        var pref = lockedTarget(p);
        var locked = pref && attackable(p, pref) && p.distanceTo(pref) <= RUSH_LOCK_RANGE ? pref : null;
        var now = coneTarget(p, range, pref);
        if (locked && now && now.uuid !== locked.uuid) now = null;
        if (id === "blue_hurricane") { begin(p, id, null, pend); return; }
        if (now && !TARGETLESS[id] && CLASH() && CLASH().isRushingAt(now, p)) {
            // the target is rushing at you: rush back so the two rushes meet (StrikeClash)
            startRush(p, pend, now);
        } else if (now && DIRECT[id]) {
            begin(p, id, now, pend);                           // the combo dashes in itself
        } else if (now) {
            cine(p, now, id);
            teleportFront(p, now, id !== "dragon_fist");
            snd(p, "tp_short", 1, 1);
            begin(p, id, now, pend);
        } else if (TARGETLESS[id]) {
            begin(p, id, null, pend);
        } else startRush(p, pend, locked);
    }
    function startRush(p, pend, target) {                      // startRush: fly at the lock, or straight ahead
        pend.target = target || null;
        pend.p = p;
        PENDING[p.uuid] = pend;
        rushVisuals(p, true);
        snd(p, "transform_on", 0.7, 1.2);
    }

    function tickPending(p, pend) {                            // processPending
        if (pend.ticks <= 0 || !alive(p)) { fail(p, pend); return; }
        if (pend.target && !alive(pend.target)) pend.target = null;
        p.fallDistance = 0;
        if (CLASH() && CLASH().tryStart(p)) return;
        if (!PENDING[p.uuid]) return;
        var t = null;
        if (pend.target) { if (gap(p, pend.target) <= RUSH_CONNECT && p.canSee(pend.target)) t = pend.target; }
        else {
            var best = null, bg = 1e9;
            RPG.world.entitiesNear(p.dimension, p.x, p.y + 0.9, p.z, RUSH_GRAB + 2).forEach(function (e) {
                if (!attackable(p, e) || !p.canSee(e)) return;
                var g = gap(p, e);
                if (g <= RUSH_GRAB && g < bg) { bg = g; best = e; }
            });
            t = best || coneTarget(p, RUSH_CONNECT + 1, null);
        }
        if (t) {
            delete PENDING[p.uuid];
            rushVisuals(p, false);
            cine(p, t, pend.id);
            if (!DIRECT[pend.id]) snap(p, t);
            begin(p, pend.id, t, pend);
            return;
        }
        // FlySkillEvent.tickStrikeRush: toward the lock (stopping 0.8 short) or along the look
        var sp = rushSpeed(p), v;
        if (pend.target) {
            var tg = pend.target, cx = tg.x - p.x, cy = (tg.y + tg.height / 2) - (p.y + 0.9), cz = tg.z - p.z, cl = Math.sqrt(cx * cx + cy * cy + cz * cz) || 1;
            var g2 = gap(p, tg) - RUSH_HOLD, m = g2 <= 0 ? 0 : Math.min(sp, g2);
            v = { x: cx / cl * m, y: cy / cl * m, z: cz / cl * m };
        } else { var lk = lookVec(p); v = { x: lk.x * sp, y: lk.y * sp, z: lk.z * sp }; }
        p.setVelocity(v.x, v.y, v.z);
        p.fallDistance = 0;
        pend.ticks--;
    }

    // ---- the strikes, one tick (processActiveInternal) ----
    function carry(s, t, forward) {                            // meteor / deadly dance: walk forward, the victim held 1.5 ahead
        var f = flatLook(s.p), x = s.p.x + f.x * 1.5, z = s.p.z + f.z * 1.5;
        if (!forward) { freeze(s.p); if (t) freeze(t); return; }
        s.p.setVelocity(f.x * 0.25, s.p.vy, f.z * 0.25);
        if (t) { t.teleport(x, s.p.y, z); t.setVelocity(0, t.vy, 0); }
    }
    function step(s) {
        var p = s.p, id = s.id, t = s.t, n = s.tick + 1;
        // processMeteorBurst & co., processDimensionalPunch / Slash: their own checks (a victim may die mid-way)
        if (s.combo || id === "dimensional_punch" || id === "dimensional_sword_attack") {
            if (!alive(p) || p.hasEffect("stunned") || p.hasEffect("knocked_down")) { end(s, true); return; }
            p.fallDistance = 0;
            if (id === "dimensional_punch") return dimPunch(s, n);
            if (id === "dimensional_sword_attack") return dimSlash(s, n);
            if (!COMBOS().tick(id, s.C, s.combo, n)) { end(s, true); return; }
            if (n >= COMBOS().duration(id)) { end(s); return; }
            s.tick = n; return;
        }
        if (!alive(p) || (t && !alive(t)) || (s.targeted && !t)) { end(s, false); return; }
        if (p.hasEffect("stunned") || p.hasEffect("knocked_down")) { end(s, true); return; }
        p.fallDistance = 0;
        var victim = t || frontVictim(p), look = flatLook(p);

        if (id === "oozaru_slam") return slam(s, n);
        if (id === "grab" && t) return grab(s, n);
        if (id === "shining_sword_attack" && t) return shiningSword(s, n);
        if (id === "blue_hurricane") return hurricane(s, n);
        if (id === "dragon_fist") return dragonFist(s, n);
        if (id === "oozaru_fist" && t) return oozaruFist(s, n);
        if (id === "spirit_breaking_cannon" && t) return spiritCannon(s, n);
        if (id === "combo_meteor" && t) return comboMeteor(s, n);

        if (id === "meteor" && t) {
            if (t.isPlayer()) face(t, p);
            carry(s, t, true);
            if (n % INTERVAL === 0 && n < s.durMin) { hit(s, t, s.per, false); snd(t, "punch1", 1, 0.8 + Math.random() * 0.4); }
            if (n >= s.durMin) {
                hit(s, t, s.fin, true); killXp(s, t);
                snd(t, "critic_punch1", 2, 1);
                var pd = lookVec(p);
                kb(t, pd.x * 2.5, 0.4, pd.z * 2.5); anim(t, "base.flyback");
                impact(s, t, pd, t.isOnGround() || pd.y < -0.5);
                end(s); return;
            }
            s.tick = n; return;
        }
        if (id === "gum_punch") {
            freeze(p);
            if (n < 4 && t) { face(p, t); freeze(t); }
            if (n === 4) {
                var at = impactPoint(p, victim, 0.6);
                if (victim) { hit(s, victim, s.total, true); killXp(s, victim); }
                snd(at, "critic_punch1", 2, 0.7);
                burstFx(p, at, lookVec(p), 4.0, "#FF82F3", "#FF1AEC", 14);
                if (victim) { kb(victim, look.x * 5, 0.5, look.z * 5); anim(victim, "base.flyback"); impact(s, victim, look, victim.isOnGround()); }
            }
            if (n >= 12) { end(s); return; }
            s.tick = n; return;
        }
        if (id === "super_god_fist") {
            if (n < 14 && t) { if (t.isPlayer()) face(t, p); }
            if (n <= 12) {
                var dashing = t ? p.distanceTo(t) > 1.5 : !frontVictim(p);
                if (dashing) {
                    var dv = t ? norm({ x: t.x - p.x, y: 0, z: t.z - p.z }) : look;
                    p.setVelocity(dv.x * 1.5, p.vy, dv.z * 1.5);
                    fx(p, { t: "trail", x: p.x, y: p.y + 0.9, z: p.z, d: [dv.x * 1.5, 0, dv.z * 1.5], c: "#F5C527" });
                } else freeze(p);
                if (t) freeze(t);
            } else if (n === 13) { if (t) freeze(t); freeze(p); }
            else if (n === 14) {
                var v2 = t || frontVictim(p), at2 = impactPoint(p, v2, 0.5);
                if (v2) { hit(s, v2, s.total, true); killXp(s, v2); }
                snd(at2, "critic_punch2", 2.5, 0.7);
                burstFx(p, at2, lookVec(p), 5.5, "#FFD23A", "#FF4A12", 18);
                if (v2) {
                    var lk2 = lookVec(p);
                    kb(v2, lk2.x * 4, 0.6, lk2.z * 4);
                    impact(s, v2, lk2, v2.isOnGround() || lk2.y < -0.5);
                    anim(v2, "base.hurt_supergodfist");
                }
                freeze(p);
            } else if (n < 25) freeze(p);
            if (n >= 35) { end(s); return; }
            s.tick = n; return;
        }
        if (id === "deadly_dance" || id === "deadly_dance_vegetto") {
            var veg = id === "deadly_dance_vegetto", c2 = veg ? "#2FA8FF" : "#FFA800";
            if (t && t.isPlayer()) face(t, p);
            var f3 = flatLook(p), blocked = p.isHorizontalCollision();
            carry(s, t, !blocked);
            if (n % INTERVAL === 0 && n < s.durMin) {
                var v3 = t || frontVictim(p);
                if (v3) hit(s, v3, s.per, false);
                burstFx(p, impactPoint(p, v3, 0.6), f3, 1.7, "#FFE23A", c2, 7);
                snd(impactPoint(p, v3, 0), "punch1", 1, 0.8 + Math.random() * 0.4);
            }
            if (n >= s.durMin) {
                var v4 = t || frontVictim(p);
                if (v4) { hit(s, v4, s.fin, true); killXp(s, v4); }
                burstFx(p, impactPoint(p, v4, 0.5), { x: f3.x * 0.35, y: 1, z: f3.z * 0.35 }, 4.8, "#FFE23A", c2, 16);
                snd(impactPoint(p, v4, 0), "critic_punch2", 2, 1);
                if (v4) { var lk4 = lookVec(p); kb(v4, lk4.x * 0.5, 1.5, lk4.z * 0.5); anim(v4, "base.flyback"); impact(s, v4, { x: 0, y: 1, z: 0 }, true); }
                end(s); return;
            }
            s.tick = n; return;
        }
        if (id === "kaioken_attack" && t) {
            if (n === 1) p.setShared("dmzStrikeAura", 1);
            if (n < 20 && t.isPlayer()) face(t, p);
            if (n < 10) {
                if (p.distanceTo(t) > 1.5) { var d5 = norm({ x: t.x - p.x, y: t.y - p.y, z: t.z - p.z }); p.setVelocity(d5.x * 1.5, d5.y * 1.5, d5.z * 1.5); }
                else freeze(p);
                freeze(t);
            } else if (n === 10) {
                hit(s, t, s.per, false); snd(t, "punch1", 1.5, 1);
                var lk5 = lookVec(p); kb(t, lk5.x * 1.5, 0.4, lk5.z * 1.5); freeze(p);
            } else if (n < 15) {
                var d6 = norm({ x: t.x - p.x, y: t.y - p.y, z: t.z - p.z }); p.setVelocity(d6.x * 2.5, d6.y * 2.5, d6.z * 2.5);
            } else if (n === 15) { hit(s, t, s.per, false); snd(t, "critic_punch2", 1.5, 1.2); freeze(t); freeze(p); }
            else if (n < 20) { freeze(t); freeze(p); }
            else if (n === 20) {
                hit(s, t, s.per, false); snd(t, "critic_punch2", 2, 0.8);
                var lk7 = lookVec(p); kb(t, lk7.x * 3.5, 0.2, lk7.z * 3.5); anim(t, "base.flyback"); freeze(p);
            } else if (n < 34) { freeze(p); if (n === 21) snd(p, "ki_explosion_charge", 1, 1); }
            else if (n === 34) {
                freeze(p);
                hit(s, t, s.fin * 0.1, false);
                face(p, t);
                kameWave(s, t, s.fin * 0.9, "#FF5A3A");
            } else if (n < 50) freeze(p);
            else { killXp(s, t); end(s); return; }
            s.tick = n; return;
        }
        if (id === "wolf_fang") {
            freeze(p);
            if (t) { freeze(t); if (t.isPlayer()) face(t, p); }
            var D = s.durMin;
            if (n % INTERVAL === 0 && n < D) { var v8 = t || frontVictim(p); if (v8) hit(s, v8, s.per, false); }
            if (n < D - 3 && n % 4 === 0) {
                var jp = impactPoint(p, t || frontVictim(p), 0.6);
                snd(jp, PUNCH[Math.floor(n / 4) % PUNCH.length], 1, 1.1 + Math.random() * 0.3);
                fx(p, { t: "claw", x: jp.x, y: jp.y, z: jp.z, s: 1.7, c: "#2F5BFF", life: 8, n: 1, yaw: p.yaw });
            }
            if (n >= D) {
                var v9 = t || frontVictim(p);
                if (v9) { hit(s, v9, s.fin, true); killXp(s, v9); }
                var fp = impactPoint(p, v9, 0.5);
                snd(fp, "critic_punch2", 2, 0.7); snd(fp, "ki_explosion_impact", 2.5, 1); snd(fp, "oozaru_growl_player", 3, 1.15);
                fx(p, { t: "claw", x: fp.x, y: fp.y, z: fp.z, s: 3.4, c: "#2F5BFF", life: 16, n: 6, yaw: p.yaw, big: 1 });
                if (!v9) fx(p, { t: "shock", x: fp.x, y: fp.y, z: fp.z, s: 4.5, c: SHOCK_COLOR.wolf_fang, life: 13 });
                if (v9) knock(s, v9);
                end(s); return;
            }
            s.tick = n; return;
        }
        if (!t) {                                              // a targetless strike nobody stood in front of
            if (n >= s.durMin) { end(s); return; }
            freeze(p); s.tick = n; return;
        }
        // every other strike: held still, a hit every 10 ticks, the final hit and the knockback
        freeze(p); freeze(t);
        if (t.isPlayer()) face(t, p);
        if (n % INTERVAL === 0 && n < s.durMin) hit(s, t, s.per, false);
        if (n >= s.durMin) { hit(s, t, s.fin, true); killXp(s, t); knock(s, t); end(s); return; }
        s.tick = n;
    }

    // KiWaveEntity (the kaioken attack's Kamehameha, the oozaru fist's downward one): a straight beam from the hands
    function kameWave(s, t, dmg, color) {
        var p = s.p, from = { x: p.x, y: p.y + 1.2, z: p.z }, to = t ? { x: t.x, y: t.y + t.height / 2, z: t.z } : null;
        if (!to) { var lk = lookVec(p); to = { x: from.x + lk.x * 12, y: from.y + lk.y * 12, z: from.z + lk.z * 12 }; }
        snd(p, "ki_kame_fire", 2, 1);
        fx(p, { t: "beam", a: [from.x, from.y, from.z], b: [to.x, to.y, to.z], w: 1.0, c: color, life: 14 });
        if (t && alive(t)) { t.damageFrom(dmg, p, { kind: "ki", tag: "dmzstrike:" + s.id, ignoreIFrames: true, knockback: 0 }); shockwave(p, t, s.id, true); }
    }
    function dragonFist(s, n) {                                // SPDragonFistEntity at tick 5, the gold blast at the end
        var p = s.p;
        freeze(p);
        if (n === 5) s.fist = { x: p.x, y: p.y + 1.0, z: p.z, d: flatLook(p), left: 30, hit: {} };
        if (s.fist && s.fist.left > 0) {
            var f = s.fist; f.left--; f.x += f.d.x * 1.2; f.z += f.d.z * 1.2;
            fx(p, { t: "dragon", x: f.x, y: f.y, z: f.z, d: [f.d.x, 0, f.d.z], c: "#FFD23A", c2: "#FF8C00" });
            RPG.world.entitiesNear(p.dimension, f.x, f.y, f.z, 2.2).forEach(function (e) {
                if (!attackable(p, e) || f.hit[e.uuid]) return;
                f.hit[e.uuid] = 1;
                hit(s, e, s.total, true); killXp(s, e);
                lock(e, Math.floor(s.durMin / 2));
                if (!s.t) s.t = e;
            });
        }
        if (n >= s.durMin) {
            if (s.t && alive(s.t)) boom(s.t, s.t.x, s.t.y + 1, s.t.z, 5, "#FFD700", "#FF8C00");
            end(s); return;
        }
        s.tick = n;
    }
    function oozaruFist(s, n) {
        var p = s.p, t = s.t;
        if (n < 10) { freeze(p); freeze(t); }
        else if (n === 10) { kameWave(s, t, s.total * 0.2, "#73FFEE"); }
        else if (n < 20) { face(p, t); freeze(t); }
        else if (n === 20) {
            face(p, t);
            snd(p, "oozaru_growl_player", 2, 1);
            hit(s, t, s.total, true); killXp(s, t);
            lock(t, Math.floor(s.durMin / 2));
        }
        if (n >= s.durMin) { if (alive(t)) boom(t, t.x, t.y + 1, t.z, 3, "#FFFFFF", "#73FFEE"); end(s); return; }
        s.tick = n;
    }
    // Dimensional Punch (processDimensionalPunch): the caster stands still; at ticks 3, 18 and 33 a portal opens under
    // the target (a purple ring of radius 3 on the ground until it strikes), and 12 ticks later a fist comes through it:
    // a third of the damage to everything within 3 blocks of the mark (2 below to 4 above), a purple and gold burst,
    // the explosion clang. 70 ticks in all.
    var DIM = { RANGE: 26, R: 3, MARKS: [3, 18, 33], HITS: [15, 30, 45], DUR: 70, C1: "#C451FF", C2: "#FFD700" };
    function dimPunch(s, n0) {
        var p = s.p, t = s.dimT && alive(s.dimT) ? s.dimT : null, n = n0 - 1;   // the original counts from ticksElapsed (0)
        freeze(p);
        var mi = DIM.MARKS.indexOf(n);
        if (mi >= 0 && t) {
            s.mark = { x: t.x, y: t.y, z: t.z, dimension: t.dimension };
            var open = DIM.HITS[mi] - DIM.MARKS[mi], above = Math.random() < 1 / 3;
            // BossTelegraphS2C: the ring on the ground until it strikes; DimensionalFistS2C: the fist through a portal
            fx(t, { t: "ring", x: t.x, y: t.y, z: t.z, r: DIM.R, c: DIM.C1, life: open });
            fx(t, { t: "dfist", e: p.entityId, x: t.x, y: t.y + (above ? 0.3 : t.height * 0.55), z: t.z, yaw: Math.random() * 360,
                pitch: above ? 90 : -5 + Math.random() * 25, left: mi === 1 ? 1 : 0, open: open });
        }
        var hi = DIM.HITS.indexOf(n);
        if (hi >= 0 && s.mark) {
            var m = s.mark, last = hi === DIM.HITS.length - 1;
            RPG.world.entitiesNear(p.dimension, m.x, m.y + 1, m.z, DIM.R + 4).forEach(function (e) {
                if (!attackable(p, e) || e.y < m.y - 2 || e.y > m.y + 4) return;
                if (Math.sqrt(Math.pow(e.x - m.x, 2) + Math.pow(e.z - m.z, 2)) > DIM.R) return;
                hit(s, e, s.total / DIM.HITS.length, last);
                if (last) killXpLater(s, e);
            });
            var c = { x: m.x, y: m.y + 1, z: m.z, dimension: m.dimension };
            burstFx(p, c, norm({ x: c.x - p.x, y: c.y - p.y, z: c.z - p.z }), DIM.R * 1.5, DIM.C1, DIM.C2, 14);
            snd(c, "ki_explosion_impact", 2.2, 1.35);
        }
        if (n0 >= DIM.DUR) { end(s); return; }
        s.tick = n0;
    }

    // ---- sword slashes (SwordSlashManager): a crescent flying straight, hitting each living thing once ----
    //  launch(owner, origin, dir, roll, radius, color, core, speed, range, hitRadius, onHit, terrainCut {reach, depth})
    var SLASH = { DIM_RANGE: 40, ROLLS: [0, 90, 35, -35, 0, 90] }, CUTS = [];
    function crescentLateral(d, roll) {                        // the crescent's sideways axis for its roll
        var yaw = Math.atan2(-d.x, d.z), pitch = -Math.asin(Math.max(-1, Math.min(1, d.y))), r = d2r(roll);
        var cr = Math.cos(r), sr = Math.sin(r), cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
        return { x: cr * cy - sr * sp * sy, y: sr * cp, z: cr * sy + sr * sp * cy };
    }
    function launchSlash(p, o, dir, roll, radius, color, core, speed, range, hitR, onHit, cut) {
        var d = norm(dir), life = Math.ceil(range / speed);
        fx(p, { t: "slash", x: o.x, y: o.y, z: o.z, d: [d.x, d.y, d.z], sp: speed, roll: roll, r: radius, c: color, c2: core, life: life });
        var c = { p: p, dim: p.dimension, x: o.x, y: o.y, z: o.z, d: d, sp: speed, max: range, hitR: hitR, done: {}, onHit: onHit, trav: 0 };
        var DC = typeof DBR_DESTRUCTION !== "undefined" ? DBR_DESTRUCTION.config : null;
        if (cut && DC && DC.get("enabled") && DC.get("players") && DC.get("maxBlocksPerBlast") > 0) {   // the ki-griefing rules
            // KiTerrainDestruction.crescentSweep: lanes across the crescent, each cutting `depth` blocks past where it meets terrain
            var lat = crescentLateral(d, roll), up = { x: d.y * lat.z - d.z * lat.y, y: d.z * lat.x - d.x * lat.z, z: d.x * lat.y - d.y * lat.x };
            var hw = Math.min(radius * cut.reach, radius), lanes = [];
            lat = norm({ x: lat.x - d.x * (lat.x * d.x + lat.y * d.y + lat.z * d.z), y: lat.y - d.y * (lat.x * d.x + lat.y * d.y + lat.z * d.z), z: lat.z - d.z * (lat.x * d.x + lat.y * d.y + lat.z * d.z) });
            for (var u = -hw; u <= hw + 1e-6; u += 1) {
                var lead = Math.sqrt(Math.max(0, radius * radius - u * u)) - radius;    // the edges trail the middle
                var lo = { x: o.x + lat.x * u + d.x * lead, y: o.y + lat.y * u + d.y * lead, z: o.z + lat.z * u + d.z * lead }, hit = null;
                try { hit = RPG.world.raycast(c.dim, lo.x, lo.y, lo.z, d.x, d.y, d.z, range, { blocks: true, entities: false }); } catch (e) { }
                if (hit && hit.hit === "block") lanes.push({ o: lo, from: hit.distance, to: hit.distance + cut.depth });
            }
            c.lanes = lanes;
        }
        CUTS.push(c);
    }
    function tickCuts() {
        for (var i = CUTS.length - 1; i >= 0; i--) {
            var c = CUTS[i];
            if (!alive(c.p)) { CUTS.splice(i, 1); continue; }
            var before = c.trav;
            c.x += c.d.x * c.sp; c.y += c.d.y * c.sp; c.z += c.d.z * c.sp; c.trav += c.sp;
            if (c.lanes) c.lanes.forEach(function (l) {
                var a = Math.max(before, l.from), b = Math.min(c.trav, l.to);
                if (b <= a) return;
                try { RPG.world.destroy(c.dim, { type: "line", x1: l.o.x + c.d.x * a, y1: l.o.y + c.d.y * a, z1: l.o.z + c.d.z * a,
                    x2: l.o.x + c.d.x * b, y2: l.o.y + c.d.y * b, z2: l.o.z + c.d.z * b, r: 0.6 },
                    { regen: DBR_DESTRUCTION.config.get("regenSeconds"), drops: false, protectPlaced: DBR_DESTRUCTION.config.get("protectPlayerBuilt"), maxResistance: 1000 }, c.p); } catch (e) { }
            });
            RPG.world.entitiesNear(c.dim, c.x, c.y, c.z, c.hitR + 3).forEach(function (e) {
                if (e.uuid === c.p.uuid || c.done[e.uuid] || !alive(e)) return;
                var reach = c.hitR + (Number(e.width) || 0.6) * 0.5, dx = e.x - c.x, dy = e.y + e.height / 2 - c.y, dz = e.z - c.z;
                if (dx * dx + dy * dy + dz * dz > reach * reach) return;
                if (c.onHit(e)) c.done[e.uuid] = 1;
            });
            if (c.trav >= c.max) CUTS.splice(i, 1);
        }
    }
    // Dimensional Slash (processDimensionalSlash): held still, a huge dark red crescent at 8, 20 and 32 (ticksElapsed),
    // a third of the damage each (the last can kill), cutting terrain 5 blocks deep; 41 ticks
    function dimSlash(s, n0) {
        var p = s.p, n = n0 - 1, t = s.dimT && alive(s.dimT) ? s.dimT : null;
        freeze(p);
        var i = [8, 20, 32].indexOf(n);
        if (i >= 0) {
            var lk = lookVec(p), o = { x: p.x + lk.x * 1.2, y: p.y + 1.62 - 0.35 + lk.y * 1.2, z: p.z + lk.z * 1.2 };
            var aim = t ? { x: t.x - o.x, y: t.y + t.height / 2 - o.y, z: t.z - o.z } : lk, last = i === 2, per = s.total / 3;
            launchSlash(p, o, aim, SLASH.ROLLS[i], 8.4, "#7A0000", "#FF5A4A", 1.2, SLASH.DIM_RANGE, 6.6, function (v) {
                if (!attackable(p, v) || p.distanceTo(v) > SLASH.DIM_RANGE + 8) return false;
                hit(s, v, per, last);
                if (last) killXpLater(s, v);
                return true;
            }, { reach: 0.6, depth: 5 });
            snd(p, "ki_beam_fire", 1.4, 1.7);
        }
        if (n0 >= 41) { end(s); return; }
        s.tick = n0;
    }
    // Grab (processGrab): hold the victim (skp.grabbed), from tick 5 lift it 0.6 over 7 ticks and swing it round
    // (the grab spin keys), throw it at 50 for the whole damage (1.4 along your facing, 0.5 up) into a wall impact; 59 ticks
    var GRAB_SPIN = [[0.4167, 0], [0.625, -75], [2.0833, -1410], [2.25, -1465], [2.375, -1440]];
    function grabSpin(sec) {
        if (sec <= GRAB_SPIN[0][0]) return GRAB_SPIN[0][1];
        for (var i = 1; i < GRAB_SPIN.length; i++) {
            var a = GRAB_SPIN[i - 1], b = GRAB_SPIN[i];
            if (sec <= b[0]) return a[1] + (b[1] - a[1]) * (sec - a[0]) / (b[0] - a[0]);
        }
        return GRAB_SPIN[GRAB_SPIN.length - 1][1];
    }
    function grab(s, n) {
        var p = s.p, t = s.t;
        freeze(p);
        if (n < 5) {
            freeze(t);
            if (n === 1 && t.isPlayer()) { stopAnim(t); act(t.asPlayer(), "skp.grabbed", 60); }
        } else if (n < 50) {
            t.fallDistance = 0;
            if (n === 5) {
                if (!t.isPlayer()) try { t.addPotion("minecraft:slowness", 45, 9); } catch (e) { }
                snd(t, "punch2", 1, 0.8);
            }
            var spin = p.yaw + grabSpin(n / 20), f = { x: -Math.sin(d2r(spin)), z: Math.cos(d2r(spin)) };
            var g = p.width * 0.5 + t.width * 0.5 + 0.35, lift = 0.6 * Math.min(1, (n - 5) / 7);
            var x = p.x + f.x * g, y = p.y + lift, z = p.z + f.z * g;
            t.setVelocity(0, 0, 0);
            if (t.isPlayer()) t.asPlayer().teleportTo(t.dimension, x, y, z, spin + 180, t.pitch);
            else { t.teleport(x, y, z); try { t.setRotation(spin + 180, 0); } catch (e2) { } }
        } else if (n === 50) {
            var d = flatLook(p);
            unlock(t);
            hit(s, t, s.total, true); killXp(s, t);
            snd(t, "critic_punch1", 2, 1);
            if (alive(t)) { kb(t, d.x * 1.4, 0.5, d.z * 1.4); impact(s, t, d, false); }
        }
        if (n >= Math.max(s.dur, 59)) { end(s); return; }
        s.tick = n;
    }
    // Shining Sword Attack (processShiningSword, needs the Brave Sword): five blue crescents at 6, 13, 22, 28, 35
    // (65 % of the damage between them), a golden ki wave at 50 for the last 35 %, 2.0 back along your facing; 66 ticks
    function shiningSword(s, n) {
        var p = s.p, t = s.t;
        freeze(p);
        if (n < 50) {
            face(p, t); freeze(t);
            if (n === 1 && !t.isPlayer()) try { t.addPotion("minecraft:slowness", 50, 9); } catch (e) { }
        }
        var ci = [6, 13, 22, 28, 35].indexOf(n);
        if (ci >= 0) {
            var lk = lookVec(p), o = { x: p.x + lk.x * 0.8, y: p.y + 1.62 - 0.35 + lk.y * 0.8, z: p.z + lk.z * 0.8 };
            var aim = alive(t) ? { x: t.x - o.x, y: t.y + t.height / 2 - o.y, z: t.z - o.z } : lk, per = s.total * (1 - FINAL_RATIO) / 5;
            launchSlash(p, o, aim, SLASH.ROLLS[ci], 1.8, "#5CCBFF", "#E8FBFF", 1.2, 8, 2, function (v) {
                if (!attackable(p, v) || p.distanceTo(v) > 12) return false;
                hit(s, v, per, false);
                return true;
            }, null);
            snd(p, "ki_beam_fire", 1.2, 1.8 + Math.random() * 0.2);
        }
        if (n === 50) {
            face(p, t);
            var lk2 = lookVec(p), hands = { x: p.x + lk2.x * 0.8, y: p.y + p.height * 0.6 + lk2.y * 0.8, z: p.z + lk2.z * 0.8 };
            // KiWaveEntity(render type 1, size 2.2, speed 0.6, 12 ticks, no blocks broken): only seen
            fx(p, { t: "wave", x: hands.x, y: hands.y, z: hands.z, d: [lk2.x, lk2.y, lk2.z], sp: 0.6, s: 2.2, life: 12, c: ["#FFF6C8", "#FFB230", "#FF6A00"] });
            snd(p, "ki_explosion_impact", 2, 1.1);
            hit(s, t, s.fin, true); killXp(s, t);
            if (alive(t)) {
                var d = { x: -Math.sin(d2r(p.yaw)), y: 0, z: Math.cos(d2r(p.yaw)) };
                kb(t, d.x * 2.0, 0.4, d.z * 2.0); anim(t, "base.flyback");
                impact(s, t, d, false);
            }
        }
        if (n >= s.durMin) { end(s); return; }
        s.tick = n;
    }
    function slam(s, n) {                                      // oozaru slam: ground impact at tick 2, a ring out to 5 blocks over 10 ticks
        var p = s.p;
        freeze(p);
        if (n === 2) {
            snd(p, "oozaru_fist", 2, 0.55);
            fx(p, { t: "shock", x: p.x, y: p.y + 0.1, z: p.z, s: 6, c: "#C9B79C", life: 15, flat: 1 });
            RPG.world.particle(p.dimension, "minecraft:explosion", p.x, p.y + 0.3, p.z, 6, 2.5, 0);
            s.ring = { at: n, hit: {} };
        }
        if (s.ring && n - s.ring.at <= 10) {
            var r = 5 * (n - s.ring.at) / 10;
            RPG.world.entitiesNear(p.dimension, p.x, p.y, p.z, r + 1).forEach(function (e) {
                if (!attackable(p, e) || s.ring.hit[e.uuid] || Math.abs(e.y - p.y) > 1.5) return;
                if (Math.sqrt(Math.pow(e.x - p.x, 2) + Math.pow(e.z - p.z, 2)) > r) return;
                s.ring.hit[e.uuid] = 1;
                hit(s, e, s.total * 0.5, true);
                var d = norm({ x: e.x - p.x, y: 0, z: e.z - p.z });
                kb(e, d.x * 0.6, 0.6, d.z * 0.6);
            });
        }
        if (n >= 15) { end(s); return; }
        s.tick = n;
    }
    function hurricane(s, n) {                                 // SPBlueHurricaneEntity: 15 cast ticks, then a whirlwind ahead
        var p = s.p, firing = Math.max(20, s.durMin - 15);
        freeze(p);
        if (n === 15) { var f = flatLook(p); s.wind = { x: p.x + f.x * 2, y: p.y, z: p.z + f.z * 2, d: f, acc: {} }; snd(p, "ki_sparks", 1, 0.8); }
        if (s.wind && n > 15) {
            var w = s.wind; w.x += w.d.x * 0.35; w.z += w.d.z * 0.35;
            fx(p, { t: "whirl", x: w.x, y: w.y, z: w.z, c: "#5CCBFF" });
            if (n % 5 === 0) RPG.world.entitiesNear(p.dimension, w.x, w.y + 1.5, w.z, 2.5).forEach(function (e) {
                if (!attackable(p, e)) return;
                hit(s, e, s.total / Math.max(1, Math.floor(firing / 5)), n + 5 >= s.durMin);
                kb(e, (w.x - e.x) * 0.2, 0.25, (w.z - e.z) * 0.2);
            });
        }
        if (n >= s.durMin) { end(s); return; }
        s.tick = n;
    }
    function spiritCannon(s, n) {                              // knee 6, uppercut 13, launch 24, elbow slam 40, end 47
        var p = s.p, t = s.t, hd = s.total * (1 - FINAL_RATIO) / 3;
        function sc(dmg, last, ratio, scale, sound, pitch) {
            hit(s, t, dmg, last);
            var at = { x: t.x, y: t.y + t.height * ratio, z: t.z, dimension: t.dimension };
            snd(at, sound, 2, pitch);
            burstFx(p, at, lookVec(p), scale, "#F3E4FF", "#A63EF0", 14);
        }
        if (n <= 24 && t.isPlayer()) face(t, p);
        if (n < 6) {
            if (p.distanceTo(t) > 1.6) { var d = norm({ x: t.x - p.x, y: 0, z: t.z - p.z }); p.setVelocity(d.x * 1.4, p.vy, d.z * 1.4); } else freeze(p);
            freeze(t);
        } else if (n === 6) { sc(hd, false, 0.45, 3.2, "punch4", 1); anim(t, "base.hurt_top2"); freeze(p); freeze(t); }
        else if (n === 13) { sc(hd, false, 0.8, 3.2, "punch5", 1.15); anim(t, "base.hurt_top2"); freeze(p); freeze(t); }
        else if (n === 24) { sc(hd, false, 0.55, 4.0, "critic_punch2", 1.25); anim(t, "base.hurt_top"); kb(t, 0, 1.2, 0); freeze(p); }
        else if (n === 40) {
            sc(s.total * FINAL_RATIO, true, 0.9, 5.0, "critic_punch1", 0.8); killXp(s, t);
            anim(t, "base.hurt_down"); kb(t, 0, -2.8, 0);
            impact(s, t, { x: 0, y: -1, z: 0 }, true);
            freeze(p);
        } else if (n < 24) { freeze(p); freeze(t); }
        else if (n < 40) {
            var lifting = n <= 24 + 12;
            kb(t, 0, lifting ? 0.45 : 0.04, 0); p.setVelocity(0, lifting ? 0.6 : 0.04, 0); t.fallDistance = 0;
        } else if (n < 47) p.setVelocity(0, 0.04, 0);
        if (n >= 47) { end(s); return; }
        s.tick = n;
    }
    function comboMeteor(s, n) {                               // 16 punches, a lift at 60-72, the smash at 79, over at 90
        var p = s.p, t = s.t, hits = COMBO_METEOR_HITS.length, per = s.total * (1 - FINAL_RATIO) / hits;
        if (n <= 79 && n % 10 === 1) { face(p, t); if (t.isPlayer()) face(t, p); }
        var f = flatLook(p);
        if (n < 79) {
            var lift = n < 60 ? 0 : Math.min(1, (n - 60) / 12) * 1.6;
            t.teleport(p.x + f.x * (0.6 + p.width / 2 + t.width / 2), p.y + lift, p.z + f.z * (0.6 + p.width / 2 + t.width / 2));
            t.setVelocity(0, 0, 0); freeze(p);
        }
        var i = COMBO_METEOR_HITS.indexOf(n);
        if (i >= 0) {
            hit(s, t, per, false);
            anim(t, i % 2 ? "base.hurt_right" : "base.hurt_left");
            snd(t, PUNCH[i % PUNCH.length], 1, 0.9 + Math.random() * 0.2);
        }
        if (n === 79) {
            hit(s, t, s.total * FINAL_RATIO, true); killXp(s, t);
            snd(t, "critic_punch1", 2, 0.8);
            kb(t, f.x * 0.4, -2.2, f.z * 0.4); anim(t, "base.hurt_down");
            impact(s, t, { x: 0, y: -1, z: 0 }, true);
        }
        if (n >= 90) { end(s); return; }
        s.tick = n;
    }

    RPG.every(1, function () {
        Object.keys(PENDING).forEach(function (u) {
            var pd = PENDING[u];
            if (!pd) return;                                   // taken by a strike clash this tick
            try { tickPending(pd.p, pd); } catch (err) { RPG.log("[DBR] strike rush failed: " + err); delete PENDING[u]; }
        });
        if (CUTS.length) tickCuts();
        Object.keys(ACTIVE).forEach(function (u) {
            var s = ACTIVE[u];
            try { step(s); } catch (err) { RPG.log("[DBR] strike " + s.id + " failed: " + err); try { end(s, true); } catch (e2) { delete ACTIVE[u]; } }
        });
    });
    RPG.on("playerLeave", function (p) {
        delete PENDING[p.uuid];
        cineStop(p);
        var s = ACTIVE[p.uuid];
        if (s) { delete ACTIVE[p.uuid]; if (s.t) unlock(s.t); if (s.combo && COMBOS()) COMBOS().release(s.id, s.C, s.combo); }
        Object.keys(ACTIVE).forEach(function (u) { if (ACTIVE[u].t && ACTIVE[u].t.uuid === p.uuid) ACTIVE[u].t = null; });
    });
    // a strike lock never outlives its strike (a reload, a crash mid-strike)
    RPG.on("playerJoin", function (p) { unlock(p); striking(p, false); });

    return {
        cast: cast,
        isStriking: function (p) { return !!(p && (ACTIVE[p.uuid] || PENDING[p.uuid])); },
        // for the strike clash (41sx_dmz_strike_clash.js)
        isRushing: function (p) { return !!(p && PENDING[p.uuid]); },
        rushTarget: function (p) { var pd = p && PENDING[p.uuid]; return pd ? pd.target : null; },
        /** takeRushForClash: the rush ends without its fail penalty; {id, cd} is settled when the clash ends. */
        takeRush: function (p) {
            var pd = PENDING[p.uuid];
            if (!pd) return null;
            delete PENDING[p.uuid];
            rushVisuals(p, false);
            return { id: pd.id, cd: pd.cd, total: pd.total };
        },
        cancelRush: function (p) { var pd = PENDING[p.uuid]; if (pd) fail(p, pd); },
        /** settleClashCooldown: ratio 0 = no cooldown at all, otherwise the cooldown and global cooldown x ratio */
        settleRush: function (p, rush, ratio) {
            if (!H || !rush) return;
            if (ratio <= 0) { H.setCd(p, rush.id, 0); H.setCd(p, "strike_global", 0); }
            else { H.setCd(p, rush.id, Math.max(1, Math.round(rush.cd * ratio))); H.setCd(p, "strike_global", Math.round(TD().STRIKE_GLOBAL_COOLDOWN * ratio)); }
            H.sendState(p);
        },
        attackable: attackable, impact: function (victim, type, o) { DMZ_IMPACTS.register(victim, type, o); },
        helpers: function () { return H; },
        interrupt: function (p) {
            if (!p) return false;
            var pd = PENDING[p.uuid], s = ACTIVE[p.uuid];
            if (pd) fail(p, pd);
            if (s) end(s, true);
            return !!(pd || s);
        }
    };
})();
