// =====================================================================================
//  11b_dmz_impacts.js - the original's momentum strike and collision impacts
// =====================================================================================
//  Port of the original (GPL-3.0, see NOTICE.md): CombatEvent.onLivingHurt (momentum strike) and
//  MomentumImpactHandler.
//   - Momentum strike: a bare-handed melee hit thrown while flying (airborne, Fly on) at 0.65 blocks a tick or
//     more (the server's own position tracking, 64_dmz_movement.js) hits for x (1.15 + 0.35 x how far past 0.65
//     toward 1.5 you are), throws the victim 1.8 along your flight direction (then the hit's own 0.4 knockback,
//     as Minecraft adds it after the original's), flashes an impact frame (0.6, 0.05, 2 ticks) and arms a
//     collision impact. No extra cost or cooldown: the punch's own stamina, like the original.
//   - Collision impact: a victim thrown into a wall (or, launched along the ground or downward, into the ground)
//     within 1.2 s is stunned 30 ticks with the faint pose, a parry clang, a ring of 20 rocks, a 1.5 crater
//     (the ki-griefing rule) and a white impact frame (0.6, 0.05, 2, inverted); a strike's impact also deals its
//     extra damage (41s_dmz_strikes.js registers those).
// =====================================================================================
var DMZ_IMPACTS = (function () {
    var LIST = {};                      // victim uuid -> context
    var EXPIRE_MS = 1200, STUN = 30;

    function viewers(at, range) {
        return RPG.server.players().filter(function (v) {
            try { return v.dimension === at.dimension && Math.abs(v.x - at.x) < range && Math.abs(v.z - at.z) < range; } catch (e) { return false; }
        });
    }
    /** register(victim, "wall" | "ground", {dir, dmg, by, tag}) */
    function register(victim, type, o) {
        if (!victim) return;
        o = o || {};
        LIST[victim.uuid] = { e: victim, type: type === "ground" ? "ground" : "wall", until: Date.now() + EXPIRE_MS, startY: victim.y,
            dmg: Number(o.dmg) || 0, by: o.by || null, tag: o.tag || "", hit: o.onHit || null };
    }
    function playImpact(e, c) {
        var ground = c.type === "ground";
        if (e.isPlayer()) {
            var ep = e.asPlayer();
            ep.addEffect("stunned", STUN);
            act(ep, ground ? "base.faint_vertical" : "base.faint_horizontal", STUN);
        } else {
            try { e.addPotion("minecraft:slowness", STUN, 9); } catch (x) { }
        }
        sfx(e, "parry", 1, 1);
        var msg = { k: "rocks", x: Math.round(e.x * 100) / 100, y: Math.round((e.y + 0.05) * 100) / 100, z: Math.round(e.z * 100) / 100, r: ground ? 2.75 : 1.9 };
        viewers(e, 48).forEach(function (v) { RPG.net.send(v, "dmz_hitfx", msg); });
        if (typeof DBR_DESTRUCTION !== "undefined") DBR_DESTRUCTION.blast(e, e.x, e.y - 0.5, e.z, 1.5, false);   // createCrater round the block at its feet (canKiGrief)
        if (typeof DMZ_IMPACT !== "undefined") DMZ_IMPACT.play(e, 0.6, 0.05, 2, true);
        if (c.hit) { try { c.hit(e); } catch (x2) { } }
        if (c.dmg > 0 && c.by && c.by.isAlive()) e.damageFrom(c.dmg, c.by, { kind: "strike", tag: c.tag, ignoreIFrames: true, knockback: 0 });
    }
    function tick() {
        var now = Date.now();
        for (var u in LIST) {
            var c = LIST[u], e = c.e;
            try {
                if (!e.isAlive() || c.until < now) { delete LIST[u]; continue; }
                var wall = c.type === "wall" && e.horizontalCollision;
                var ground = c.type === "ground" && e.onGround && (c.startY - e.y > 0.6 || e.fallDistance > 0.75);
                if (!wall && !ground) continue;
                delete LIST[u];
                playImpact(e, c);
            } catch (err) { delete LIST[u]; }
        }
    }
    RPG.every(1, function () { for (var k in LIST) { tick(); return; } });
    RPG.on("playerLeave", function (p) { delete LIST[p.uuid]; });

    return { register: register, pending: function (e) { return !!(e && LIST[e.uuid]); } };
})();

var DMZ_MOMENTUM = (function () {
    var THRESHOLD = 0.65, MAX = 1.5, KNOCK = 1.8, PENDING = {};
    function norm(x, y, z) { var l = Math.sqrt(x * x + y * y + z * z); return l < 1e-6 ? null : { x: x / l, y: y / l, z: z / l }; }
    function lookDir(p) {
        var yaw = p.yaw * Math.PI / 180, pitch = p.pitch * Math.PI / 180;
        return { x: -Math.sin(yaw) * Math.cos(pitch), y: -Math.sin(pitch), z: Math.cos(yaw) * Math.cos(pitch) };
    }
    /** From the melee damage override (09_dmz_stats.js): the damage multiplier for this hit (1 = no momentum strike). */
    function strike(p, target) {
        if (!p || !target || typeof DMZ_FLIGHT === "undefined" || !DMZ_FLIGHT.isFlying(p) || p.onGround) return 1;
        var speed = DMZ_FLIGHT.trackedSpeed(p);
        if (!(speed >= THRESHOLD)) return 1;
        var ratio = Math.max(0, Math.min(1, (speed - THRESHOLD) / (MAX - THRESHOLD)));
        var m = DMZ_FLIGHT.trackedMotion ? DMZ_FLIGHT.trackedMotion(p) : null;
        var dir = (m && norm(m.x, m.y, m.z)) || lookDir(p);
        PENDING[p.uuid] = { t: target.uuid, dir: dir, tick: RPG.server.getTick() };
        return 1.15 + ratio * 0.35;
    }
    // after the hit's guard / parry handling (11_dmz_combat.js): the throw, the impact frame and the armed collision
    RPG.on("damageFinal", function (e) {
        var a = e.attacker, t = e.target;
        if (!a || !t || e.kind !== "melee" || !a.isPlayer()) return;
        var pd = PENDING[a.uuid];
        if (!pd) return;
        delete PENDING[a.uuid];
        if (pd.t !== t.uuid || pd.tick !== RPG.server.getTick() || e.isCancelled()) return;
        // KnockbackHelper.apply(target, dir x 1.8), then LivingEntity.hurt's own knockback(0.4) away from the attacker
        var v = { x: pd.dir.x * KNOCK, y: pd.dir.y * KNOCK, z: pd.dir.z * KNOCK };
        var ax = t.x - a.x, az = t.z - a.z, al = Math.sqrt(ax * ax + az * az) || 1;
        v = { x: v.x / 2 + ax / al * 0.4, y: t.onGround ? Math.min(0.4, v.y / 2 + 0.4) : v.y, z: v.z / 2 + az / al * 0.4 };
        e.knockback = 0;
        var ground = t.onGround || pd.dir.y < -0.5;
        RPG.schedule(1, function () { try { if (t.isAlive()) { t.setVelocity(v.x, v.y, v.z); t.fallDistance = 0; } } catch (x) { } });
        DMZ_IMPACTS.register(t, ground ? "ground" : "wall", { dir: pd.dir });
        if (typeof DMZ_IMPACT !== "undefined") DMZ_IMPACT.play(t, 0.6, 0.05, 2, false);
    });
    return { strike: strike };
})();

// ---- CombatEvent.computeDamageScaledKnockback (CombatConfig defaults): a hit on a character knocks back by how much
// of it got through and how big it is next to their health: mitigated hits barely move them (x0.15 at full
// mitigation), a hit worth 15 % of their health or more throws harder (+3 x the excess, up to x2.5). A hit fully
// soaked up (or parried) doesn't move them at all. This keeps a combo's target in reach like the original.
(function () {
    var MIN = 0.15, HEAVY = 0.15, GAIN = 3.0, MAX = 2.5;
    RPG.on("damageFinal", function (e) {
        var t = e.target;
        if (!t || !t.isPlayer() || e.isCancelled()) return;
        var p = t.asPlayer();
        if (!p.getVar("dmz_created", 0) || e.kind === "fall") return;
        var m = DMZ_MITIGATION[p.uuid], fin = Math.max(0, e.amount);
        var raw = fin + (m && m.tick === RPG.server.getTick() ? (m.def || 0) + (m.block || 0) : 0);
        if (!(raw > 0)) return;
        var mult;
        if (fin <= 0) mult = 0;
        else {
            var pass = Math.max(0, Math.min(1, fin / raw)), hf = p.maxHealth > 0 ? fin / p.maxHealth : 0;
            if (hf >= HEAVY) mult = Math.min(MAX, 1 + (hf - HEAVY) * GAIN);
            else { var mit = MIN + (1 - MIN) * pass; mult = mit + (1 - mit) * (hf / HEAVY); }
        }
        e.knockback = (typeof e.knockback === "number" ? e.knockback : 1) * mult;
    });
})();
