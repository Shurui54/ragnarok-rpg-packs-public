// =====================================================================================
//  49t_dmz_strike_fx2.js - the strike combos' effects (the "dmz_strike_fx" types listed in 49s_dmz_strike_fx.js)
// =====================================================================================
//  Port of the original's client effects (GPL-3.0, see NOTICE.md): SwordSlashEffect, the held KiBlastEntity balls,
//  KiLaserEntity strikes, KiBladeExtend, the mystic ball trail, KiBurstShakeState, DimensionalFistEffect's portal,
//  BossTelegraph rings, MainParticles ROCK / DUST bursts. Everything lives on this computer only, from one message
//  each (the balls and lasers are moved by a message every tick or two while they exist).
// =====================================================================================
var DMZ_STRIKE_FX2 = (function () {
    var LIVE = {}, N = 0, PX = "dmzpack:";
    function seq(base, n) { var a = []; for (var i = 0; i < n; i++) a.push(PX + base + i); return a; }
    var ROCK = seq("rock_particle_", 12), DUST = seq("dust_particle_", 4), SPARK = ["spark1", "spark2", "spark3", "spark4", "spark5"].map(function (n) { return PX + n; });
    function R() { return typeof DMZ_KI_RENDER !== "undefined" ? DMZ_KI_RENDER : null; }
    function sprite(o) { try { RPG.particles.sprite(o); } catch (e) { } }
    function g() { return (Math.random() + Math.random() + Math.random() - 1.5) * 0.8; }   // ~gaussian
    function d2r(a) { return a * Math.PI / 180; }
    var CLOCK = 0;
    function me() { try { var l = RPG.avatar.players().filter(function (pl) { return pl.local; })[0]; return l ? l.id : -1; } catch (e) { return -1; } }

    // ---- SwordSlashEffect: 78 degrees each side, thickness 0.26 r, glow 0.2 r, ribbon 0.16 r, 3 ghosts 0.9 x speed apart,
    // fading in over 2 ticks and out over the last 5 ----
    var SEG = 28, HALF = d2r(78);
    function rotate(v, yaw, pitch, roll) {
        var r = d2r(roll), x = v[0] * Math.cos(r) - v[1] * Math.sin(r), y = v[0] * Math.sin(r) + v[1] * Math.cos(r), z = v[2];
        var p = d2r(pitch), y2 = y * Math.cos(p) - z * Math.sin(p), z2 = y * Math.sin(p) + z * Math.cos(p);
        var t = d2r(-yaw), x3 = x * Math.cos(t) + z2 * Math.sin(t), z3 = -x * Math.sin(t) + z2 * Math.cos(t);
        return [x3, y2, z3];
    }
    function strip(tri, al, o, f, inner, outer, li, lo, a1, a2) {
        var arc = Math.max(inner, outer);
        function pt(t, rad, lift) {
            var ang = -HALF + (2 * HALF) * t, taper = Math.pow(Math.cos(ang / HALF * Math.PI / 2), 0.85), rr = arc + (rad - arc) * taper;
            var v = rotate([Math.sin(ang) * rr, lift * taper, Math.cos(ang) * rr - arc], f.yaw, f.pitch, f.roll);
            return { p: [o[0] + v[0], o[1] + v[1], o[2] + v[2]], k: taper };
        }
        for (var i = 0; i < SEG; i++) {
            var A = pt(i / SEG, inner, li), B = pt(i / SEG, outer, lo), Cc = pt((i + 1) / SEG, outer, lo), D = pt((i + 1) / SEG, inner, li);
            tri.push(A.p[0], A.p[1], A.p[2], B.p[0], B.p[1], B.p[2], Cc.p[0], Cc.p[1], Cc.p[2]); al.push(a1 * A.k, a2 * B.k, a2 * Cc.k);
            tri.push(A.p[0], A.p[1], A.p[2], Cc.p[0], Cc.p[1], Cc.p[2], D.p[0], D.p[1], D.p[2]); al.push(a1 * A.k, a2 * Cc.k, a1 * D.k);
        }
    }
    function drawSlash(id, f) {
        var time = f.age, fade = Math.min(1, time / 2) * Math.max(0, Math.min(1, (f.life - time) / 5));
        var edge = { t: [], a: [] }, core = { t: [], a: [] };
        for (var gh = 3; gh >= 0; gh--) {
            var trav = Math.max(0, time * f.sp - gh * 0.9 * f.sp), o = [f.x + f.d[0] * trav, f.y + f.d[1] * trav, f.z + f.d[2] * trav];
            var ga = gh === 0 ? 1 : 0.32 / gh, rad = f.r * (gh === 0 ? 1 : 1 - gh * 0.06), th = rad * 0.26, glow = rad * 0.2, rib = rad * 0.16, a = fade * ga;
            if (a <= 0.01) continue;
            strip(edge.t, edge.a, o, f, rad, rad + glow, 0, 0, 0.85 * a, 0);
            strip(edge.t, edge.a, o, f, rad - th * 1.9, rad - th, 0, 0, 0, 0.55 * a);
            strip(edge.t, edge.a, o, f, rad - th, rad - th * 0.5, 0, 0, 0.55 * a, a);
            strip(core.t, core.a, o, f, rad - th * 0.5, rad, 0, 0, a, a);
            strip(core.t, core.a, o, f, rad - th * 0.4, rad - th * 0.4, 0, rib, 0.75 * a, 0);
            strip(core.t, core.a, o, f, rad - th * 0.4, rad - th * 0.4, 0, -rib, 0.75 * a, 0);
        }
        if (edge.t.length) RPG.world3d.mesh(id + "e", { triangles: edge.t, alphas: edge.a, color: f.c, alpha: 1, blend: f.dark ? "translucent" : "additive" });
        else RPG.world3d.remove(id + "e");
        if (core.t.length) RPG.world3d.mesh(id + "c", { triangles: core.t, alphas: core.a, color: f.c2 || "#FFFFFF", alpha: 1, blend: "additive" });
        else RPG.world3d.remove(id + "c");
    }
    function lum(hex) { var n = parseInt(String(hex).replace("#", ""), 16); return (0.2126 * ((n >> 16) & 255) + 0.7152 * ((n >> 8) & 255) + 0.0722 * (n & 255)) / 255; }

    // ---- held ki balls (the ki render's sphere, like 51v_dmz_volleys.js) ----
    function ball(id, x, y, z, cols, r, life) {
        var K = R();
        if (!K || !K.setup()) { RPG.world3d.billboard(id, { x: x, y: y, z: z, size: r * 2.4, color: cols[1], alpha: 0.9, blend: "additive", ticks: life }); return; }
        var c = [K.rgb(cols[0]), K.rgb(cols[1]), K.rgb(cols[2])];
        if (RPG.shaders.has && RPG.shaders.has(id)) { RPG.shaders.update(id, { x: x, y: y, z: z, ops: [["scale", r]], ticks: life }); return; }
        RPG.shaders.draw(id, { mesh: K.MESH.sphere, shader: K.SH, x: x, y: y, z: z, ops: [["scale", r]],
            uniforms: K.uni(c, { blotchMode: 1, flameMode: 1, orbMode: 1 }), bloom: { bloomMode: 1 }, cull: false, depthWrite: false, ticks: life, order: 20 });
    }
    function unball(id) { try { RPG.shaders.remove(id); } catch (e) { } RPG.world3d.remove(id); }

    // ---- per tick ----
    function add(d) { var id = "dmzsf2" + (N++) + ":"; d.age = 0; LIVE[id] = d; return id; }
    function tickOne(id, f) {
        f.age++;
        if (f.t === "slash") { if (f.age >= f.life) return false; drawSlash(id, f); return true; }
        if (f.t === "mball") {
            var e = RPG.world.entity(f.e);
            if (e && f.age <= f.life) f.pts.push([e.x, e.y + 0.75, e.z]);
            if (f.pts.length > 10 || (f.age > f.life && f.pts.length)) f.pts.shift();
            if (!f.pts.length) return false;
            for (var i = 0; i < 10; i++) {
                if (i + 1 >= f.pts.length) { RPG.world3d.remove(id + i); continue; }
                var a = (i + 1) / f.pts.length;
                RPG.world3d.line(id + i, { from: f.pts[i], to: f.pts[i + 1], width: 0.9 * a, color: f.c, alpha: 0.55 * a, blend: "additive" });
            }
            return true;
        }
        if (f.t === "after") {
            if (f.age >= f.life) return false;
            var k = 1 - f.age / f.life;
            RPG.world3d.billboard(id, { x: f.x, y: f.y + 0.9, z: f.z, width: 0.8, height: 1.9, color: "#BFE8FF", alpha: 0.35 * k * k, blend: "additive" });
            return true;
        }
        if (f.t === "kb") {
            var ticks = f.f ? 16 : 8;
            if (f.age > ticks) return false;
            var src = RPG.world.entity(f.e), inten = 0, fade = 1 - f.age / ticks;
            if (f.e === me()) inten = fade;
            else if (src) {
                var dx = src.x - RPG.player.x, dy = src.y - RPG.player.y, dz = src.z - RPG.player.z, dd = Math.sqrt(dx * dx + dy * dy + dz * dz), reach = f.r * 1.5;
                if (dd < reach) inten = (1 - dd / reach) * fade;
            }
            if (inten > 0.01) RPG.camera.shake((f.f ? 2.8 : 1.2) * inten, 2);
            return true;
        }
        if (f.t === "ring") {
            if (f.age >= f.life) return false;
            var p = f.age / f.life, tri = [], al = [], seg = 40, tri2 = [], al2 = [];
            for (var j = 0; j < seg; j++) {
                var t0 = j / seg * Math.PI * 2, t1 = (j + 1) / seg * Math.PI * 2, r0 = f.r * 0.92, r1 = f.r, fr = f.r * p;
                tri.push(f.x + Math.cos(t0) * r0, f.y + 0.06, f.z + Math.sin(t0) * r0, f.x + Math.cos(t0) * r1, f.y + 0.06, f.z + Math.sin(t0) * r1, f.x + Math.cos(t1) * r1, f.y + 0.06, f.z + Math.sin(t1) * r1);
                tri.push(f.x + Math.cos(t0) * r0, f.y + 0.06, f.z + Math.sin(t0) * r0, f.x + Math.cos(t1) * r1, f.y + 0.06, f.z + Math.sin(t1) * r1, f.x + Math.cos(t1) * r0, f.y + 0.06, f.z + Math.sin(t1) * r0);
                al.push(0.9, 0.9, 0.9, 0.9, 0.9, 0.9);
                tri2.push(f.x, f.y + 0.05, f.z, f.x + Math.cos(t0) * fr, f.y + 0.05, f.z + Math.sin(t0) * fr, f.x + Math.cos(t1) * fr, f.y + 0.05, f.z + Math.sin(t1) * fr);
                al2.push(0.1, 0.4, 0.4);
            }
            RPG.world3d.mesh(id + "r", { triangles: tri, alphas: al, color: f.c, alpha: 1, blend: "additive" });
            RPG.world3d.mesh(id + "f", { triangles: tri2, alphas: al2, color: f.c, alpha: 1, blend: "additive" });
            return true;
        }
        if (f.t === "dfist") return dfist(id, f);
        if (f.t === "wave") {
            if (f.age >= f.life) return false;
            var l = Math.min(f.age * f.sp + 0.5, 12), to = [f.x + f.d[0] * l, f.y + f.d[1] * l, f.z + f.d[2] * l], w = f.s * (f.age < 3 ? f.age / 3 : 1 - (f.age - 3) / (f.life - 3) * 0.5);
            RPG.world3d.line(id + "o", { from: [f.x, f.y, f.z], to: to, width: w, color: f.c[2], alpha: 0.5, blend: "additive" });
            RPG.world3d.line(id + "b", { from: [f.x, f.y, f.z], to: to, width: w * 0.7, color: f.c[1], alpha: 0.8, blend: "additive" });
            RPG.world3d.line(id + "c", { from: [f.x, f.y, f.z], to: to, width: w * 0.4, color: f.c[0], alpha: 1, blend: "additive" });
            return true;
        }
        if (f.t === "scream") {
            if (f.age >= f.life) return false;
            var se = RPG.world.entity(f.e);
            if (se && f.age % 3 === 0) {
                var q = f.age / f.life;
                if (typeof DMZ_STRIKE_FX !== "undefined") DMZ_STRIKE_FX.play({ t: "shock", x: se.x, y: se.y + 1.2, z: se.z, s: 3 + 5 * q, c: "#FFFFFF", life: 8 });
            }
            return true;
        }
        return false;
    }
    // DimensionalFistEffect: the portal grows over (open - 4) ticks, the fist emerges over the last 4, holds 3, pulls back over 5,
    // the portal closes over 4; the portal sits an arm's length (10 px) behind the fist, the arm reaches through it
    function dfist(id, f) {
        var open = Math.max(1, f.open), lifeT = open + 3 + 5 + 4;
        if (f.age >= lifeT) return false;
        var t = f.age, ease = function (x) { x = Math.max(0, Math.min(1, x)); var i = 1 - x; return 1 - i * i * i; };
        var grow = Math.max(1, open - 4), opening = t < grow ? ease(t / grow) : t < lifeT - 4 ? 1 : Math.max(0, 1 - (t - (lifeT - 4)) / 4);
        var ext = t < open - 4 ? 0 : t < open ? ease((t - (open - 4)) / 4) : t < open + 3 ? 1 : Math.max(0, 1 - (t - open - 3) / 5);
        var yaw = d2r(f.yaw), pitch = d2r(f.pitch), dir = [-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch)];
        var arm = 10 / 16, portal = [f.x - dir[0] * arm, f.y - dir[1] * arm, f.z - dir[2] * arm], rad = (0.3 + 0.45) * opening;
        var pulse = 0.85 + 0.15 * Math.sin(t * 0.9);
        function disc(key, r0, r1, color, a, spin, fan) {
            var tri = [], al = [], seg = 40;
            for (var i = 0; i < seg; i++) {
                var a0 = i / seg * Math.PI * 2 + spin, a1 = (i + 1) / seg * Math.PI * 2 + spin;
                var p0 = rotate([Math.cos(a0) * r0, Math.sin(a0) * r0, 0], f.yaw, f.pitch, 0), p1 = rotate([Math.cos(a0) * r1, Math.sin(a0) * r1, 0], f.yaw, f.pitch, 0);
                var p2 = rotate([Math.cos(a1) * r1, Math.sin(a1) * r1, 0], f.yaw, f.pitch, 0), p3 = rotate([Math.cos(a1) * r0, Math.sin(a1) * r0, 0], f.yaw, f.pitch, 0);
                tri.push(portal[0] + p0[0], portal[1] + p0[1], portal[2] + p0[2], portal[0] + p1[0], portal[1] + p1[1], portal[2] + p1[2], portal[0] + p2[0], portal[1] + p2[1], portal[2] + p2[2]);
                tri.push(portal[0] + p0[0], portal[1] + p0[1], portal[2] + p0[2], portal[0] + p2[0], portal[1] + p2[1], portal[2] + p2[2], portal[0] + p3[0], portal[1] + p3[1], portal[2] + p3[2]);
                al.push(fan ? a * 1.4 : a, a, a, fan ? a * 1.4 : a, a, a);
            }
            RPG.world3d.mesh(id + key, { triangles: tri, alphas: al, color: color, alpha: 1, blend: "translucent" });
        }
        if (opening > 0.01) {
            disc("c", 0, rad * 0.86, "#C451FF", 0.42 * opening, 0, true);
            disc("r", rad * 0.86, rad, "#EDDEFF", 0.95 * opening * pulse, 0);
            disc("g", rad * 1.08, rad * 1.16, "#C451FF", 0.55 * opening * pulse, t * 0.12);
            disc("i", rad * 0.48, rad * 0.54, "#EDDEFF", 0.45 * opening, -t * 0.2);
        } else RPG.world3d.removePrefix(id);
        if (ext > 0.04) {                                     // the arm through the portal, the fist leading
            var tip = [portal[0] + dir[0] * arm * ext * 1.6, portal[1] + dir[1] * arm * ext * 1.6, portal[2] + dir[2] * arm * ext * 1.6];
            RPG.world3d.line(id + "a", { from: portal, to: tip, width: 0.26, color: "#D9A066", alpha: 1, blend: "translucent", emissive: false });
            RPG.world3d.billboard(id + "f", { x: tip[0], y: tip[1], z: tip[2], size: 0.34, color: "#E8B27A", alpha: 1, emissive: false });
        } else { RPG.world3d.remove(id + "a"); RPG.world3d.remove(id + "f"); }
        return true;
    }

    // ---- messages ----
    var ORBS = {}, LASERS = {}, BLADES = {};
    function play(d) {
        var t = d.t;
        if (t === "slash") { d.dark = lum(d.c) < 0.3; d.yaw = Math.atan2(-d.d[0], d.d[2]) * 180 / Math.PI; d.pitch = -Math.asin(Math.max(-1, Math.min(1, d.d[1]))) * 180 / Math.PI; add(d); return; }
        if (t === "orb") { ORBS[d.id] = 1; ball("dmzorb_" + d.id, d.x, d.y, d.z, d.c, Math.max(0.05, d.s * 0.5), d.life || 4); return; }
        if (t === "orbx") { delete ORBS[d.id]; unball("dmzorb_" + d.id); return; }
        if (t === "laser") {
            LASERS[d.id] = 1;
            var key = "dmzlas_" + d.id;
            RPG.world3d.line(key + "o", { from: d.a, to: d.b, width: d.w * 2.2, color: d.c[2], alpha: 0.45, blend: "additive", ticks: d.life });
            RPG.world3d.line(key + "b", { from: d.a, to: d.b, width: d.w * 1.4, color: d.c[1], alpha: 0.8, blend: "additive", ticks: d.life });
            RPG.world3d.line(key + "c", { from: d.a, to: d.b, width: d.w * 0.6, color: d.c[0], alpha: 1, blend: "additive", ticks: d.life });
            return;
        }
        if (t === "laserx") { delete LASERS[d.id]; RPG.world3d.removePrefix("dmzlas_" + d.id); return; }
        if (t === "blade") { BLADES[d.e] = { reach: d.reach, c: d.c, until: CLOCK + d.life }; return; }
        if (t === "bladex") { delete BLADES[d.e]; RPG.world3d.removePrefix("dmzbld_" + d.e); return; }
        if (t === "mball") { d.pts = []; add(d); return; }
        if (t === "after") {
            RPG.particle("minecraft:cloud", d.x, d.y + 1, d.z, 12, 0.3, 0.02);
            add(d); return;
        }
        if (t === "kb" || t === "ring" || t === "dfist" || t === "wave" || t === "scream") { add(d); return; }
        if (t === "rocks") {
            for (var i = 0; i < d.n; i++) sprite({ texture: ROCK, x: d.x + g() * d.sx, y: d.y + g() * d.sy, z: d.z + g() * d.sx,
                vx: g() * d.v, vy: Math.abs(g()) * d.v + 0.05, vz: g() * d.v, gravity: 0.04, size: [0.1, 0.3], life: [40, 80], roll: [0, 3.14], rollSpeed: 0.1,
                fade: 10, blend: "opaque", collide: true });
            return;
        }
        if (t === "dust") {
            for (var j = 0; j < d.n; j++) sprite({ texture: DUST, animate: true, x: d.x + g() * d.sx, y: d.y + g() * d.sy, z: d.z + g() * d.sx,
                vx: g() * d.v, vy: Math.abs(g()) * d.v * 0.5, vz: g() * d.v, drag: 0.92, gravity: 0, size: [0.6, 1.2], life: [20, 40], fade: "life", collide: false });
            return;
        }
        if (t === "sparks") {
            for (var k = 0; k < d.n; k++) sprite({ texture: SPARK, animate: true, x: d.x + (Math.random() - 0.5) * 0.4, y: d.y + (Math.random() - 0.5) * 0.4,
                z: d.z + (Math.random() - 0.5) * 0.4, size: 1, grow: 0.1, life: 10, collide: false, fullbright: true, color: d.c });
            return;
        }
        if (t === "boom") { var K = R(); if (K) K.kiFx({ x: d.x, y: d.y, z: d.z, v: d.s * 2, p: d.s * 1.8, c: d.c }); return; }
    }
    // the beam sword's blade: from the right shoulder (5 px out, 17.5 up, 13 forward x the model scale), down the thrust
    // (0.778 forward, 0.628 down) to reach + 0.5 fist offset; before the thrust a short blade held forward
    function drawBlades() {
        for (var e in BLADES) {
            var b = BLADES[e], ent = RPG.world.entity(Number(e));
            if (!ent || CLOCK > b.until) { delete BLADES[e]; RPG.world3d.removePrefix("dmzbld_" + e); continue; }
            var yaw = d2r(ent.yaw), f = [-Math.sin(yaw), 0, Math.cos(yaw)], r = [-Math.cos(yaw), 0, -Math.sin(yaw)], sc = 0.9375;
            var sh = [ent.x - r[0] * 5 / 16 * sc + f[0] * 13 / 16 * sc, ent.y + 17.5 / 16 * sc, ent.z - r[2] * 5 / 16 * sc + f[2] * 13 / 16 * sc];
            var len = b.reach > 0 ? (b.reach + 0.5) * sc : 1.3, dir = b.reach > 0 ? [f[0] * 0.778, -0.628, f[2] * 0.778] : [f[0] * 0.95, -0.3, f[2] * 0.95];
            var tip = [sh[0] + dir[0] * len, sh[1] + dir[1] * len, sh[2] + dir[2] * len];
            RPG.world3d.line("dmzbld_" + e + "o", { from: sh, to: tip, width: 0.32, color: b.c, alpha: 0.6, blend: "additive" });
            RPG.world3d.line("dmzbld_" + e + "c", { from: sh, to: tip, width: 0.12, color: "#FFFFFF", alpha: 1, blend: "additive" });
        }
    }
    RPG.on("tick", function () {
        CLOCK++;
        for (var id in LIVE) {
            var keep = false;
            try { keep = tickOne(id, LIVE[id]); } catch (e) { keep = false; }
            if (!keep) { RPG.world3d.removePrefix(id); delete LIVE[id]; }
        }
        drawBlades();
    });
    return { play: play };
})();

// ---- the Neo Tri-Beam: its charge lightning (KiProjectileRenderer.renderTriBeam: two passes of sphere lightning, radius
// 0.75, #6FE8FF and #1F7BFF, round the 0.3 charge orb) and the follow-up window (ClientStatsEvents: "Press Right Click to
// keep firing" as a subtitle; a right click inside it asks the server for another shot) ----
(function () {
    var until = 0, clock = 0, last = {};
    function arcs(id, cx, cy, cz, r, color, seed) {
        var paths = [];
        for (var a = 0; a < 3; a++) {
            var th = Math.random() * Math.PI * 2, ph = Math.acos(2 * Math.random() - 1), pts = [], wd = [];
            for (var k = 0; k < 6; k++) {
                th += (Math.random() - 0.5) * 0.9; ph += (Math.random() - 0.5) * 0.7;
                var rr = r * (0.9 + Math.random() * 0.2);
                pts.push(cx + rr * Math.sin(ph) * Math.cos(th), cy + rr * Math.cos(ph), cz + rr * Math.sin(ph) * Math.sin(th));
                wd.push(k === 0 || k === 5 ? 0 : 0.025);
            }
            paths.push({ points: pts, widths: wd, alpha: 1 });
        }
        RPG.world3d.bolt(id, { paths: paths, color: color, glow: 0.6, ticks: 3 });
    }
    RPG.every(1, function () {
        clock++;
        if (!RPG.player.present || clock % 2) return;
        var list = [];
        try { list = RPG.world.projectiles(64); } catch (e) { return; }
        for (var i = 0; i < list.length; i++) {
            var pr = list[i];
            if (!pr.held || !pr.tag || pr.tag.indexOf("neo_kikoho") < 0) continue;
            var cy = pr.y + pr.size * 0.5;
            arcs("dmzneo_" + pr.id + "a", pr.x, cy, pr.z, 0.75, "#6FE8FF");
            arcs("dmzneo_" + pr.id + "b", pr.x, cy, pr.z, 0.75, "#1F7BFF");
        }
    });
    RPG.net.on("dmz_tribeam_window", function (d) {
        var t = d ? Number(d.t) || 0 : 0;
        if (t <= 0) { if (until > 0) RPG.title("", "", 0, 1, 0); until = 0; return; }
        until = clock + t;
        RPG.title("", RPG.translate("message.dragonminez.tri_beam.follow_up"), 0, t, 6);
    });
    RPG.on("mouse", function (button, down) {
        if (button !== 1 || !down || until <= 0) return;
        if (clock <= until) RPG.net.send("dmz_tribeam_follow", {}); else until = 0;
    });
})();

