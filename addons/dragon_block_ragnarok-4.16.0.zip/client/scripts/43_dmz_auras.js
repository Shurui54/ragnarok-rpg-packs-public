// =====================================================================================
//  43_dmz_auras.js - this computer's aura options and the overcharge shake
// =====================================================================================
//  Ported from the original (GPL-3.0, see NOTICE.md): ConfigMenuScreen's "My Aura - 3D Style" (on/off),
//  "My Aura - 3D Type" (Smooth / Sparking / God) and "Enemy Auras - 3D Style", and
//  EffectsEvents' charge shake (stronger while overcharging into a ki surge), and ClientStatsEvents' ground dust and
//  floating rubble around everyone whose aura is up while they stand on the ground (the original's dust_particle and
//  rock_particle sprites from the dmzpack, with DustParticle's and RockParticle's motion).
//
//  Your own 3D choice goes to the server (scripts/29_dmz_auras.js) so everyone sees it (other players always show
//  their own choice, as in the original); the enemy option only changes how this computer draws NPCs. Stored in RPG.storage:
//      dmz_cfg_aura3d (bool)  dmz_cfg_aura3d_style (0 smooth, 1 sparking, 2 god)
//      dmz_cfg_aura3d_others (bool)  dmz_cfg_flight_aura (bool, default true: the Ragnarok original's "Flight Aura")
// =====================================================================================
var DMZ_AURAS = (function () {
    var STYLES = ["smooth", "sparking", "god"];
    var NAMES = ["gui.dragonminez.customization.aura.smooth", "gui.dragonminez.customization.aura.sparking", "gui.dragonminez.customization.aura.god"];

    function get(key, def) { try { var v = RPG.storage.get(key, def); return v === undefined || v === null ? def : v; } catch (e) { return def; } }
    function put(key, v) { try { RPG.storage.set(key, v); } catch (e) { } }

    function mine() { return !!get("dmz_cfg_aura3d", false); }
    function style() { var i = Math.round(Number(get("dmz_cfg_aura3d_style", 0)) || 0); return Math.max(0, Math.min(STYLES.length - 1, i)); }
    function others() { return !!get("dmz_cfg_aura3d_others", false); }
    // The Ragnarok original's "Flight Aura" (SUConfig.flightAura, default on): an aura while flying fast even when not powered up
    function flight() { return !!get("dmz_cfg_flight_aura", true); }

    function push() { RPG.net.send("dmz_aura3d", { on: mine(), style: STYLES[style()], flight: flight() }); }
    // "Enemy Auras - 3D Style" (AuraModeState.entityPreference) is for NPCs' auras only (DBSagasRenderer): other
    // players always show the style they chose (stats.isAura3D / getAura3DType), drawn by 43_dmz_aura_shader.js
    function applyLocal() {
        if (RPG.auras && typeof RPG.auras.options === "function") RPG.auras.options({ othersFlat: !others() });
    }

    // send once we are in a world (the server keeps it, but it may have been changed offline). Only a choice made on
    // this computer is sent: one never made here (a fresh install) must not turn off a style the server already has,
    // and scripts reloading (/rpg reload) used to send "off" back and empty dmz_aura3d_pref
    var sent = false;
    function chosen() { try { var v = RPG.storage.get("dmz_cfg_aura3d", null); return v !== undefined && v !== null; } catch (e) { return false; } }
    RPG.on("tick", function () {
        if (sent || !RPG.player.present) return;
        sent = true;
        applyLocal();
        if (chosen()) push();
    });
    RPG.on("unload", function () { sent = false; });
    // /rpgc aura on the server: keep the same choice here
    RPG.net.on("dmz_aura3d_set", function (d) {
        put("dmz_cfg_aura3d", !!(d && d.on));
        var i = STYLES.indexOf(String(d && d.style || ""));
        if (i >= 0) put("dmz_cfg_aura3d_style", i);
    });

    // ---- charge shake (EffectsEvents): gentle while charging, strong while the surge bar fills ----
    var lastSurge = 0, shakeTick = 0, bigLeft = 0;
    RPG.on("tick", function () {
        if (!RPG.player.present) return;
        var charging = RPG.player.hasEffect("ki_charge");
        var surge = Math.max(0, Math.min(100, Number(RPG.getVar("dmz_surge", 0)) || 0));
        var active = !!Number(RPG.getVar("dmz_surge_active", 0));
        if (active && surge >= 99 && lastSurge < 99) { RPG.camera.shake(1.6, 12); bigLeft = 12; }   // the surge fires
        lastSurge = surge;
        if (bigLeft > 0) { bigLeft--; return; }
        if (++shakeTick % 8 !== 0) return;
        if (charging && surge > 0 && !active) RPG.camera.shake(0.25 + 0.4 * surge / 100, 14);   // overcharging
        else if (charging) RPG.camera.shake(0.12, 14);
    });

    // ---- ground dust and floating rubble (ClientStatsEvents.spawnGroundDust / spawnFloatingRubble) ----
    // Every tick, for each player whose aura shows and who stands on the ground, scaled by their model size:
    //  dust:   half the ticks, 8 puffs 0.4-1.1 blocks out at the feet (+0.15), blown outward at 0.12 b/t, no rise;
    //          0.15-0.3 big, 40-59 ticks, x0.98 then x0.95 on x/z a tick, fading over the whole life (DustParticle)
    //  rubble: 40% of ticks, 2-4 rocks 0.4-1.9 blocks out (+0.1), drifting +-0.04 sideways and rising 0.08-0.25 b/t
    //          (+0-0.02), 0.1-0.3 big, 40-79 ticks, x0.9 on x/z and +0.002 up a tick, rolling 0.1 rad a tick from a
    //          random start, opaque, fading out over the last 10 ticks (RockParticle)
    var DUST = [], ROCKS = [];
    for (var di = 0; di < 4; di++) DUST.push("dmzpack:dust_particle_" + di);
    for (var ri = 0; ri < 12; ri++) ROCKS.push("dmzpack:rock_particle_" + ri);
    function groundDust(e, scale) {
        if (Math.random() > 0.5) return;
        for (var i = 0; i < 8; i++) {
            var a = Math.random() * 2 * Math.PI, r = (0.4 + Math.random() * 0.7) * scale;
            RPG.particles.sprite({ texture: DUST, x: e.x + Math.cos(a) * r, y: e.y + 0.15, z: e.z + Math.sin(a) * r,
                vx: Math.cos(a) * 0.12, vy: 0, vz: Math.sin(a) * 0.12, size: [0.15, 0.3], life: [40, 60],
                friction: 0.98, drag: 0.95, fade: "life" });
        }
    }
    function floatingRubble(e, scale) {
        if (Math.random() > 0.4) return;
        var n = 2 + Math.floor(Math.random() * 3);
        for (var i = 0; i < n; i++) {
            var a = Math.random() * 2 * Math.PI, r = (0.4 + Math.random() * 1.5) * scale;
            RPG.particles.sprite({ texture: ROCKS, x: e.x + Math.cos(a) * r, y: e.y + 0.1, z: e.z + Math.sin(a) * r,
                vx: (Math.random() - 0.5) * 0.08, vy: 0.08 + Math.random() * 0.15 + Math.random() * 0.02, vz: (Math.random() - 0.5) * 0.08,
                size: [0.1, 0.3], life: [40, 80], drag: 0.9, accelY: 0.002, roll: [0, 3.14], rollSpeed: 0.1, fade: 10, blend: "opaque" });
        }
    }
    RPG.on("tick", function () {
        if (!RPG.player.present || !RPG.particles || !RPG.auras.active) return;
        var ids = RPG.auras.active();
        for (var i = 0; i < ids.length; i++) {
            var e = RPG.world.entity(ids[i]);
            if (!e || !e.player || !e.onGround) continue;
            var scale = Number(e.scale) || 1;
            groundDust(e, scale);
            floatingRubble(e, scale);
        }
    });

    // ---- the ki surge's flame border (AuraBorderRenderer) ----------------------------------------------------
    // While a player's surge runs (shared "dmzSurge" = their active aura colour) the original draws a flame field round their
    // silhouette on screen, in any aura mode, beside the aura: the model goes into a mask, its coverage is blurred into
    // a field, and the original's aura_border shader licks flames off it (resources/assets/dbr/shaders/core/aura_border*). The
    // engine runs that pipeline (RPG.shaders.border, configured with AuraBorderRenderer's constants in
    // 43_dmz_aura_shader.js; RPG.avatar.setBorder per player). The Demon Eye relic (RelicItemsStatusHandler.
    // isDemonEyeActive, shared "dmzDemonEye" from scripts/16_dmz_items.js) gets the original's dark border instead (outer
    // #6B0000, inner #FF2A2A, DMZPlayerRenderer) and its red transformation outline (TransformationPostShaderManager
    // DEMON_EYE_OUTLINE 0xFF2020 / 0x9A0000, 2.5) over any form's.
    var BORDER = {};                     // entity id -> what is shown ("surge:#RRGGBB" / "eye")
    RPG.on("tick", function () {
        if (!RPG.player.present || !RPG.avatar || !RPG.avatar.setBorder) return;
        var seen = {}, shaders = false;
        RPG.avatar.players().forEach(function (pl) {
            if (pl.spectator || pl.invisible) return;
            var eye = !!pl.shared("dmzDemonEye", null), c = pl.shared("dmzSurge", null);
            if (!eye && !c) return;
            // the border's settings come with the aura shaders, which load only once something needs them
            if (!shaders && typeof DMZ_AURA_SHADER !== "undefined" && DMZ_AURA_SHADER.ensure) { shaders = true; DMZ_AURA_SHADER.ensure(); }
            var key = eye ? "eye" : "surge:" + c;
            seen[pl.id] = true;
            if (BORDER[pl.id] === key) return;
            if (BORDER[pl.id] === "eye") RPG.avatar.setOutline(pl.id, null);
            BORDER[pl.id] = key;
            if (eye) {
                RPG.avatar.setBorder(pl.id, { color: "#6B0000", inner: "#FF2A2A" });
                RPG.avatar.setOutline(pl.id, DMZ_OUTLINE.saga("#FF2020", "#9A0000", 2.5));
            } else RPG.avatar.setBorder(pl.id, { color: String(c) });
        });
        for (var id in BORDER) if (!seen[id]) {
            RPG.avatar.setBorder(Number(id), null);
            if (BORDER[id] === "eye") RPG.avatar.setOutline(Number(id), null);
            delete BORDER[id];
        }
    });
    RPG.on("unload", function () { for (var id in BORDER) { RPG.avatar.setBorder(Number(id), null); if (BORDER[id] === "eye") RPG.avatar.setOutline(Number(id), null); } BORDER = {}; });

    return {
        mine: mine, style: style, others: others,
        setMine: function (on) { put("dmz_cfg_aura3d", !!on); push(); },
        setStyle: function (i) { put("dmz_cfg_aura3d_style", Math.max(0, Math.min(STYLES.length - 1, Math.round(i)))); push(); },
        setOthers: function (on) { put("dmz_cfg_aura3d_others", !!on); applyLocal(); },
        flight: flight,
        setFlight: function (on) { put("dmz_cfg_flight_aura", !!on); push(); },
        styleName: function () { return NAMES[style()]; },
        STYLE_COUNT: STYLES.length
    };
})();
