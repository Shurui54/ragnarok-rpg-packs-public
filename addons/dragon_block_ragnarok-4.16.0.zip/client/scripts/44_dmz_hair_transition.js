// =====================================================================================
//  44_dmz_hair_transition.js - the hair while a transformation charges and when a form changes
// =====================================================================================
//  Port of the original 2.2's FormTransition / FormVisualTransition (as the hair sees them) and of
//  HairStyleResolver + HairEntityState.updatePoses + HairPoseBuilder.buildBlend (GPL-3.0, see NOTICE.md):
//    charging a form   the hair grows from the current style into the next form's while the charge fills
//                      (charge factor, smoothstep, strand parameters blended: length, angles, bends, colours)
//    let go early      it falls back over 20 ticks (RELEASE_TICKS)
//    form reached      what is left of the blend catches up in 4 ticks (CATCH_UP_TICKS)
//    any other change  (descend, power down, an instant form) the old look fades into the new over 20 ticks
//  Each player's state comes from the server's "dmzAuraFx" share (scripts/31_dmz_transform.js: forms, the charge
//  target and its factor every 10 ticks, smoothed here per tick like the original's planned charge). While a
//  blend shows, this computer draws that player's hair from a blended style (RPG.avatar.setHair); otherwise the
//  avatar's own hair block (30_forms.js) draws it. Blends are built in 24 steps, each once.
// =====================================================================================
var DMZ_HAIR_TX = (function () {
    var H = DMZ_HAIR, F = Math.fround;
    var RELEASE_TICKS = 20, REVERT_TICKS = 20, CATCH_UP_TICKS = 4, EPSILON = 0.001, STEPS = 24;
    var HAIR_RACES = { human: 1, saiyan: 1, glind: 1, majin: 1 };
    var ST = {};                         // entity id -> state
    var DEFINED = [];                    // blended style ids, oldest first (dropped past 96)
    var tickN = 0;

    function fd() { return typeof DMZ_FORMS !== "undefined" ? DMZ_FORMS : null; }
    function smooth(t) { return t * t * (3 - 2 * t); }

    // ---- what a look wears (HairStyleResolver.lookHair / styleForFormData) ----
    // look: {r, fg, f, sg, s}; returns {slot, src, color, forced} or null (no hair)
    function lookHair(pl, look) {
        if (!HAIR_RACES[look.r]) return null;
        var D = fd(), form = D && look.fg && look.f ? D.form(look.r, look.fg, look.f) : null, stack = D && look.sg && look.s ? D.stackForm(look.sg, look.s) : null;
        var slot = "base", code = null;
        [form, stack].forEach(function (x) {
            if (!x) return;
            if (x.hairCode && H.EXTRA_CODES.indexOf(x.hairCode) >= 0) { code = x.hairCode; if (x.hair && x.hair !== "empty") slot = x.hair; }
            else if (x.hair) { slot = x.hair; code = null; }
        });
        if (slot === "empty" || (form && form.model === "oozaru")) return null;
        var hs = pl.lookValue("hairStyle"), base = pl.lookValue("hair") || "#000000", color = base, forced = false;
        [form, stack].forEach(function (x) { if (x && x.c && x.c.hair) { color = x.c.hair; forced = true; } });
        return { slot: slot, hs: hs, code: code, color: H.normColor(color) || "#000000", forced: forced };
    }
    function styleOf(h) {
        if (!h) return null;
        if (h.code) return H.extraStyle(h.code);
        var m = /^c([0-9a-f]{8})$/.exec(h.hs);
        if (m) { var set = H.customSet(m[1]); return set ? H.resolveOwn(set, h.slot) : null; }
        var id = H.presetOf(h.hs, "");
        return id > 0 ? H.preset(id, h.slot) : null;
    }
    function hairKey(h) { return h ? [h.hs, h.slot, h.code || "", h.color, h.forced ? 1 : 0].join("_") : "none"; }

    // ---- HairPoseBuilder.buildBlend on the strand parameters, then the engine strands with baked colours ----
    function lerp(f, a, b) { return a + (b - a) * f; }
    function lerpAngle(f, a, b) { return a + H.wrapF(b - a) * f; }
    function rgb(h) { var n = parseInt(String(h).substring(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
    function hex(c) { return "#" + c.map(function (v) { var s = Math.max(0, Math.min(255, Math.round(v))).toString(16).toUpperCase(); return s.length < 2 ? "0" + s : s; }).join(""); }
    function mixHex(a, b, f) { var x = rgb(a), y = rgb(b); return hex([lerp(f, x[0], y[0]), lerp(f, x[1], y[1]), lerp(f, x[2], y[2])]); }
    // StrandPose.resolveSide: a segment's own colour, else the strand's shading to its tip colour, else the hair colour
    function segColor(s, k, n, global, forced) {
        if (forced || !s) return global;
        var o = H.getOverride(s, k);
        if (o && o.c) return o.c;
        var base = s.c || global;
        if (!s.tc || n < 2) return base;
        return mixHex(base, s.tc, k / (n - 1));
    }
    function blendStrand(a, av, b, bv, f) {
        var A = av ? a : b, B = bv ? b : a, s = { i: (A || B).i, so: [] };
        s.sg = Math.max(A.sg, B.sg);
        s.ln = H.clampFF(F(lerp(f, av ? A.ln : 0.1, bv ? B.ln : 0.1)), 0.1, 128, 6);
        s.lr = H.clampFF(F(lerp(f, A.lr, B.lr)), 0.1, 4, 1);
        s.w = H.clampFF(F(lerp(f, av ? A.w : 0.1, bv ? B.w : 0.1)), 0.1, 16, 2);
        s.d = H.clampFF(F(lerp(f, av ? A.d : 0.1, bv ? B.d : 0.1)), 0.1, 16, 2);
        s.tp = H.clampFF(F(lerp(f, A.tp, B.tp)), 0.05, 2, 1);
        s.tg = H.clampFF(F(lerp(f, A.tg, B.tg)), 0.25, 4, 1);
        s.ox = lerp(f, A.ox, B.ox); s.oy = lerp(f, A.oy, B.oy); s.oz = lerp(f, A.oz, B.oz);
        s.rx = H.wrapF(F(lerpAngle(f, A.rx, B.rx))); s.ry = H.wrapF(F(lerpAngle(f, A.ry, B.ry))); s.rz = H.wrapF(F(lerpAngle(f, A.rz, B.rz)));
        s.bx = lerp(f, A.bx, B.bx); s.by = lerp(f, A.by, B.by); s.bz = lerp(f, A.bz, B.bz); s.tw = lerp(f, A.tw || 0, B.tw || 0);
        s.js = f < 0.5 ? A.js : B.js;
        var ks = {};
        (A.so || []).forEach(function (o) { ks[o.k] = 1; });
        (B.so || []).forEach(function (o) { ks[o.k] = 1; });
        Object.keys(ks).forEach(function (kk) {
            var k = Number(kk), oa = H.getOverride(A, k), ob = H.getOverride(B, k);
            s.so.push({ k: k, ox: lerp(f, oa ? oa.ox : 0, ob ? ob.ox : 0), oy: lerp(f, oa ? oa.oy : 0, ob ? ob.oy : 0), oz: lerp(f, oa ? oa.oz : 0, ob ? ob.oz : 0),
                rx: lerp(f, oa ? oa.rx : 0, ob ? ob.rx : 0), ry: lerp(f, oa ? oa.ry : 0, ob ? ob.ry : 0), rz: lerp(f, oa ? oa.rz : 0, ob ? ob.rz : 0),
                ls: Math.max(0.1, lerp(f, oa ? oa.ls : 1, ob ? ob.ls : 1)), ws: Math.max(0.1, lerp(f, oa ? oa.ws : 1, ob ? ob.ws : 1)),
                ds: Math.max(0.1, lerp(f, oa ? oa.ds : 1, ob ? ob.ds : 1)), c: null });
        });
        s.so.sort(function (x, y) { return x.k - y.k; });
        return s;
    }
    function visible(s) { return !!s && s.sg > 0 && s.ln > 0; }
    // HairEntityState.updatePoses: strands of either style blended; colours resolved on each side, then mixed
    function blendStrands(from, to, factor, fromH, toH) {
        var blend = factor <= 0.0001 || factor >= 0.9999 ? factor : smooth(factor), out = [];
        H.FACES.forEach(function (face, fi) {
            for (var i = 0; i < face.max; i++) {
                var a = from && from.faces[face.key] ? from.faces[face.key][i] : null, b = to && to.faces[face.key] ? to.faces[face.key][i] : null;
                var av = visible(a), bv = visible(b);
                if (!av && !bv) continue;
                var s = blendStrand(a, av, b, bv, blend), one = { gc: "#000000", faces: {} };
                H.FACES.forEach(function (f2) { one.faces[f2.key] = []; });
                one.faces[face.key][i] = s;
                var st = H.toStrands(one, false)[0];
                if (!st) continue;
                var A = av ? a : b, B = bv ? b : a;
                st.segs.forEach(function (seg, k) {
                    var ca = segColor(A, Math.min(k, A.sg - 1), A.sg, fromH ? fromH.color : "#000000", fromH && fromH.forced);
                    var cb = segColor(B, Math.min(k, B.sg - 1), B.sg, toH ? toH.color : "#000000", toH && toH.forced);
                    seg.color = mixHex(ca, cb, blend);
                });
                out.push(st);
            }
        });
        return out;
    }
    function blendId(fromH, toH, q) { return "dmzb." + hairKey(fromH) + "." + hairKey(toH) + "." + q; }
    function ensureBlend(fromH, toH, q) {
        var id = blendId(fromH, toH, q);
        if (RPG.avatar.hasHair(id)) return id;
        var fromS = styleOf(fromH), toS = styleOf(toH);
        RPG.avatar.defineHair(id, function () { return blendStrands(fromS, toS, q / STEPS, fromH, toH); });
        DEFINED.push(id);
        while (DEFINED.length > 96) RPG.avatar.defineHair(DEFINED.shift(), null);
        return id;
    }
    // chg: the charge factor while a form charges (the hair physics' aura input, HairStyleResolver.auraIntensity)
    function hairBlock(id, fromH, toH, blend, chg) {
        var slotA = fromH ? fromH.slot : toH.slot, slotB = toH ? toH.slot : slotA;
        var b = H.avatarHair(slotA, "fHair", false), pa = H.PHYSICS[slotA] || H.PHYSICS.base, pb = H.PHYSICS[slotB] || pa;
        b.style = id;
        b.strandColors = true;
        b.transition = 0;
        b.physics = H.physicsBlock({ stiffness: lerp(blend, pa.stiffness, pb.stiffness), damping: lerp(blend, pa.damping, pb.damping),
            gravity: lerp(blend, pa.gravity, pb.gravity), maxAngle: lerp(blend, pa.maxAngle, pb.maxAngle) }, chg);
        return b;
    }

    // ---- FormTransition, per player per tick ----
    function lookOf(fx) { return { r: String(fx.r || ""), fg: String(fx.fg || ""), f: String(fx.f || ""), sg: String(fx.sg || ""), s: String(fx.s || "") }; }
    function lookKey(l) { return [l.r, l.fg, l.f, l.sg, l.s].join("|"); }
    function targetLook(cur, fx) {
        var t, p;
        if (fx.nf) { p = String(fx.nf).split(":"); t = { r: cur.r, fg: p[0], f: p[1], sg: cur.sg, s: cur.s }; return t; }
        if (fx.ns) { p = String(fx.ns).split(":"); t = { r: cur.r, fg: cur.fg, f: cur.f, sg: p[0], s: p[1] }; return t; }
        return null;
    }
    function step(pl) {
        var fx = pl.shared("dmzAuraFx", null), st = ST[pl.id];
        if (!fx || typeof fx !== "object" || pl.invisible) { if (st) drop(pl.id); return; }
        var cur = lookOf(fx), key = lookKey(cur);
        if (!st) { ST[pl.id] = st = { key: key, look: cur, charge: 0, shown: 0, target: null, targetKey: "", fading: false, revert: null, applied: "", seen: tickN }; return; }
        st.seen = tickN;
        // the forms changed (onLookChanged): a completed charge catches up, anything else reverts over 20 ticks
        if (key !== st.key) {
            var completed = !!st.target && lookKey(st.target) === key, prev = st.look, shown = st.shown;
            st.key = key; st.look = cur;
            st.target = null; st.targetKey = ""; st.charge = 0; st.shown = 0; st.fading = false;
            if (!completed) st.revert = { look: prev, from: 1, t: 0, ticks: REVERT_TICKS };
            else if (1 - shown > EPSILON) st.revert = { look: prev, from: 1 - shown, t: 0, ticks: CATCH_UP_TICKS };
            else st.revert = null;
        }
        // the charge (observeCharge): the server's factor every 10 ticks, followed here a tick at a time
        var tgt = targetLook(cur, fx), k = Math.max(0, Math.min(1, Number(fx.k) || 0));
        if (tgt && k > 0) {
            var tk = lookKey(tgt);
            if (tk !== st.targetKey) { st.target = tgt; st.targetKey = tk; st.shown = Math.min(st.shown, k); }
            st.charge = k; st.fading = false;
            st.shown = st.shown < k ? Math.min(k, st.shown + Math.max(0.01, (k - st.shown) / 10)) : k;
        } else if (st.target) {
            // let go: fade what was shown over RELEASE_TICKS
            if (!st.fading) { st.fading = true; st.fadeFrom = st.shown; st.fadeT = 0; }
            st.fadeT++;
            st.shown = st.fadeFrom * Math.max(0, 1 - st.fadeT / RELEASE_TICKS);
            if (st.shown <= 0) { st.target = null; st.targetKey = ""; st.fading = false; }
        }
        if (st.revert) { st.revert.t++; if (st.revert.t >= st.revert.ticks) st.revert = null; }
        apply(pl, st);
    }
    function apply(pl, st) {
        var fromH = lookHair(pl, st.look), toH = null, factor = 0;
        if (st.revert) { toH = lookHair(pl, st.revert.look); factor = st.revert.from * Math.max(0, 1 - st.revert.t / st.revert.ticks); }
        else if (st.target && st.shown > 0) { toH = lookHair(pl, st.target); factor = st.shown; }
        if (factor <= EPSILON || hairKey(fromH) === hairKey(toH) || (!fromH && !toH)) { set(pl.id, st, null); return; }
        var q = Math.max(1, Math.min(STEPS - 1, Math.round(factor * STEPS)));
        if (!fromH) { fromH = { slot: toH.slot, hs: "0", code: null, color: toH.color, forced: toH.forced }; }
        if (!toH) { toH = { slot: fromH.slot, hs: "0", code: null, color: fromH.color, forced: fromH.forced }; }
        var id = ensureBlend(fromH, toH, q);
        set(pl.id, st, id, fromH, toH, q / STEPS, !st.revert && st.target && !st.fading ? q / STEPS : 0);
    }
    function set(eid, st, id, fromH, toH, f, chg) {
        if (st.applied === (id || "")) return;
        st.applied = id || "";
        RPG.avatar.setHair(eid, id ? hairBlock(id, fromH, toH, smooth(f), chg || 0) : null);
    }
    function drop(eid) { if (ST[eid] && ST[eid].applied) RPG.avatar.setHair(eid, null); delete ST[eid]; }

    if (RPG.avatar && RPG.avatar.setHair) {
        RPG.on("tick", function () {
            if (!RPG.player.present) return;
            tickN++;
            RPG.avatar.players().forEach(step);
            if (tickN % 100 === 0) Object.keys(ST).forEach(function (id) { if (ST[id].seen !== undefined && tickN - ST[id].seen > 100) drop(Number(id)); });
        });
    }
    return { state: function (id) { return ST[id]; } };
})();
