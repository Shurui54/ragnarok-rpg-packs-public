// =====================================================================================
//  92_dbr_raids_zsouls.js - Z-Souls: raid charms that push a stat past the global stat cap
// =====================================================================================
//  Port of DMZ Ragnarok's Z-Souls (GPL-3.0, shuruis_raid_bosses: item/ZSoulItem, ZSoulTier,
//  ZStat, data/ZSoulData, dmz/ZSoulManager, network/ZSoulInvestC2S, client/gui/ZSoulAddButton,
//  mixin/ZSoulStatsScreenMixin, the zsoul.* config and /rg raid zsoul). DMZR keeps the overlay
//  and the TP purchase in its private Key; this rebuilds them from the public pieces (the item,
//  tier and stat tables, the banked store, the config comments, the GUI's cost formula).
//
//  How they work:
//    - 28 items: a Vitality / Stamina / Strength / Ki Power / Strike Power / Energy soul and a
//      Rainbow soul (all six) in Bronze, Silver, Gold and Prismatic. Earned as raid (or any)
//      rewards: item:z_soul_strength_gold:1, chance:5:item:z_soul_rainbow_prismatic:1 (DMZR's
//      dmz_ragnarok:z_soul_... ids work too); ops can /raid zsoul give.
//    - Worn in the Z-Soul accessory slots (B; zsoul.slotCount of them take a soul; right-click
//      a soul to put it on). The highest worn tier per stat counts; Rainbow raises every stat.
//    - A tier allows tierPercent% of the global cap (1,000,000) past it. The stat's points past
//      the cap are BANKED per player (dbr_zsoul), so they survive taking the soul off, relogs
//      and swapping to a lower soul; only min(banked, tier allowance) applies while worn.
//    - Banking needs the base stat at the cap first. TP buys points: automatically every
//      second while worn (zsoul.autoConvertTrainingPoints, trainingPointsPerPoint each, at most
//      autoGrowthPerSecond per stat), or by hand with the Z-Soul "+" next to a capped stat in
//      the stats screen (DMZ's own escalating stat price, like DMZR's button) or /raid zsoul.
//    - Stat Gems that overflow the cap pour the rest into a worn soul (94_dbr_tournaments.js).
//    - A tournament character carries no accessories, so no Z-Soul bonus rides into the arena.
//  DMZ's seventh channel (Defense, Rainbow only) is Resistance's stamina channel here: DBR has
//  one Resistance stat, raised by the Stamina soul (DMZR: "RES row = Stamina soul").
//
//  Commands: /raid zsoul [info] (the screen) | zsoul reset [player] | zsoul give <stat> <tier> [player]
// =====================================================================================
var DBR_ZSOUL = (function () {
    var R = DBR_RAIDS, CFG = R.CFG;
    var V_BANK = "dbr_zsoul", SLOTS = 6;
    var TIERS = [{ id: "bronze", n: "Bronze", c: "&6", rarity: "uncommon" }, { id: "silver", n: "Silver", c: "&7", rarity: "rare" },
        { id: "gold", n: "Gold", c: "&e", rarity: "epic" }, { id: "prismatic", n: "Prismatic", c: "&d", rarity: "legendary" }];
    // ZStat (dedicated souls), in DMZR's order, with the DBR stat each raises
    var CHANNELS = [{ key: "vitality", stat: "vitality", n: "Vitality", dmz: "VIT" }, { key: "stamina", stat: "resistance", n: "Stamina", dmz: "RES" },
        { key: "strength", stat: "strength", n: "Strength", dmz: "STR" }, { key: "ki_power", stat: "kipower", n: "Ki Power", dmz: "PWR" },
        { key: "strike_power", stat: "strike", n: "Strike Power", dmz: "SKP" }, { key: "energy", stat: "energy", n: "Energy", dmz: "ENE" }];
    var STATS = CHANNELS.map(function (c) { return c.stat; });

    function on() { return !!CFG.get("zsoul.enable"); }
    function slotCount() { return Math.max(1, Math.min(SLOTS, Math.floor(Number(CFG.get("zsoul.slotCount")) || SLOTS))); }
    function tierIndex(id) { for (var i = 0; i < TIERS.length; i++) if (TIERS[i].id === id) return i; return -1; }
    function percent(t) { return Math.max(0, Number(CFG.get("zsoul." + TIERS[t].id + "Percent")) || 0); }
    function channel(stat) { for (var i = 0; i < CHANNELS.length; i++) if (CHANNELS[i].stat === stat || CHANNELS[i].key === stat) return CHANNELS[i]; return null; }
    function uid(p) { return String(p.uuid); }

    // ---- the global cap: the stats' own max (DMZ maxValue), read before the stats are redefined below ----
    var CAP = 1000000;
    (function () { try { var d = RPG.stats.get("strength"); if (d && Number(d.max) > 0) CAP = Number(d.max); } catch (e) { } })();
    function cap(p) { return p && typeof DBR_PRESTIGE !== "undefined" ? DBR_PRESTIGE.capFor(p) : CAP; }   // prestige widens it (93_dbr_prestige.js)
    /** ZSoulTier.maxBonus: headroom past the cap this tier allows. */
    function maxBonus(t) { return t < 0 ? 0 : Math.round(CAP * percent(t) / 100); }

    // =================================================================================
    //  Items (ModItems / ZSoulItem) and the slots (curios z_souls)
    // =================================================================================
    var BY_ID = {};           // stack id -> {ch (null = rainbow), t}
    function itemName(ch, t) { return "z_soul_" + (ch ? ch.key : "rainbow") + "_" + TIERS[t].id; }
    function soulOf(stack) {
        if (!stack || !stack.id) return null;
        var id = String(stack.id);
        return BY_ID[id] || BY_ID[id.replace(/^ragnarok_rpg:/, "")] || null;
    }
    function freeSlot(p) {
        for (var i = 1; i <= slotCount(); i++) { var a = p.getAccessory("z_soul_" + i); if (!a || !a.id || a.id === "minecraft:air") return "z_soul_" + i; }
        return null;
    }
    function defineSoul(ch, t) {
        var T = TIERS[t], name = itemName(ch, t), scope = ch ? ch.n : "all stats";
        RPG.items.define(name, {
            name: T.c + T.n + " " + (ch ? ch.n : "Rainbow") + " Z-Soul", model: "dbr:rpg/item/raids/" + name, type: "accessory", rarity: T.rarity,
            maxStack: 1, glint: t === 3, consume: false, useTime: 0,
            lore: ["&bRaises the cap of " + scope, "&7Tier: " + T.c + T.n, "&8Wear in a Z-Soul slot (B), then invest TP", "&8in the stats screen or /raid zsoul."],
            onUse: function (p) {
                // right-click: put it on (a free Z-Soul slot), or show the Z-Soul screen
                var held = p.getHeldStack(), slot = on() ? freeSlot(p) : null;
                if (slot && held && soulOf(held)) {
                    p.setAccessory(slot, held);
                    p.setHeldStack(null);
                    p.playSound("minecraft:item.armor.equip_diamond", 1, 1.2);
                    p.actionbar("&bZ-Soul worn (" + slot.replace("z_soul_", "slot ") + ")");
                    refresh(p);
                } else openScreen(p);
                return false;
            }
        });
        var id = RPG.items.id(name);
        if (id) { BY_ID[String(id)] = { ch: ch, t: t }; BY_ID["ragnarok_rpg:" + id] = { ch: ch, t: t }; }
    }
    CHANNELS.forEach(function (ch) { TIERS.forEach(function (T, t) { defineSoul(ch, t); }); });
    TIERS.forEach(function (T, t) { defineSoul(null, t); });
    function allItemNames() { var o = []; CHANNELS.concat([null]).forEach(function (ch) { TIERS.forEach(function (T, t) { o.push(itemName(ch, t)); }); }); return o; }

    for (var si = 1; si <= SLOTS; si++) (function (i) {
        RPG.slots.define("z_soul_" + i, { name: "Z-Soul " + i, icon: "z_soul_rainbow_bronze", order: 30 + i, keepOnDeath: true,
            accepts: function (p, itemId, stack) { return i <= slotCount() && !!soulOf(stack || { id: itemId }); },
            onEquip: function (p) { refresh(p); }, onUnequip: function (p) { refresh(p); } });
    })(si);

    /** ZSoulManager.wornTiers: highest worn tier per stat (rainbow raises all), only the usable slots. */
    function worn(p) {
        var out = {};
        if (!on()) return out;
        for (var i = 1; i <= slotCount(); i++) {
            var s = soulOf(p.getAccessory("z_soul_" + i));
            if (!s) continue;
            (s.ch ? [s.ch] : CHANNELS).forEach(function (ch) { if (!(out[ch.stat] >= s.t)) out[ch.stat] = s.t; });
        }
        return out;
    }

    // =================================================================================
    //  Banked points (ZSoulData) and the live projection
    // =================================================================================
    function bank(p) { var b = p.getVar(V_BANK, null); return b && typeof b === "object" ? b : {}; }
    function banked(p, stat) { return Math.max(0, Math.floor(Number(bank(p)[stat]) || 0)); }
    function setBanked(p, stat, v) { var b = bank(p); v = Math.max(0, Math.floor(v)); if (v) b[stat] = v; else delete b[stat]; p.setVar(V_BANK, Object.keys(b).length ? b : null); }
    var APPLIED = {};         // uuid -> {stat: bonus} read by the stat formulas
    function applied(p) {
        var w = worn(p), out = {};
        STATS.forEach(function (st) { if (w[st] !== undefined) { var b = Math.min(banked(p, st), maxBonus(w[st])); if (b > 0) out[st] = b; } });
        return out;
    }
    /** Re-project one player's bonus now (equip, unequip, invest, reset). */
    function refresh(p) {
        if (!p) return;
        var next = applied(p), prev = APPLIED[uid(p)] || {}, changed = false;
        STATS.forEach(function (st) { if ((next[st] || 0) !== (prev[st] || 0)) changed = true; });
        APPLIED[uid(p)] = next;
        if (changed) p.refreshStats();
        sendState(p);
    }
    // the six stats again, the same but with the cap applied by a formula, so a Z-Soul bonus can sit on top of it
    STATS.forEach(function (st) {
        var d = null;
        try { d = RPG.stats.get(st); } catch (e) { }
        if (!d) return;
        var nd = {};
        ["name", "description", "color", "base", "min", "hidden", "allocatable", "maxAllocated", "pointCost", "tpCostBase", "tpCostGrowth"].forEach(function (k) {
            if (d[k] !== undefined && d[k] !== null) nd[k] = d[k];
        });
        var limit = Number(d.max) > 0 ? Number(d.max) : CAP;
        nd.formula = function (player, value) {
            var a = APPLIED[String(player.uuid)];
            var lim = limit === CAP && typeof DBR_PRESTIGE !== "undefined" ? DBR_PRESTIGE.capFor(player) : limit;
            return Math.min(value, lim) + (a && a[st] ? a[st] : 0);
        };
        RPG.stats.define(st, nd);
    });

    // =================================================================================
    //  Buying beyond-cap points (ZSoulInvestC2S, auto-convert)
    // =================================================================================
    function atCap(p, stat) { return p.baseStat(stat) >= cap(p); }
    /** How many more points this stat may bank right now (soul worn, base capped, under the tier allowance). */
    function room(p, stat, want) {
        var w = worn(p);
        if (!on() || w[stat] === undefined || !atCap(p, stat)) return 0;
        return Math.max(0, Math.min(Math.floor(want), maxBonus(w[stat]) - banked(p, stat)));
    }
    /** Overflow grant (Stat Gems): bank up to amount points for free; how many landed. */
    function grantBeyondCap(p, stat, amount) {
        var ch = channel(stat);
        if (!ch) return 0;
        var n = room(p, ch.stat, amount);
        if (n > 0) { setBanked(p, ch.stat, banked(p, ch.stat) + n); refresh(p); }
        return n;
    }
    function baseTotal(p) { var t = 0; STATS.forEach(function (st) { t += Math.min(p.baseStat(st), cap(p)); }); return t; }
    function tpCostMult(p) { var c = DMZ_DATA.CLASSES[p.playerClass] || DMZ_DATA.CLASSES.warrior; return c.tpCost; }
    /** The TP the next n beyond-cap points of a stat cost: DMZ's escalating single-stat price past the total. */
    function investCost(p, stat, n) {
        var start = baseTotal(p) + banked(p, stat), m = tpCostMult(p);
        return DMZ_F.cost(start, n, m);
    }
    function invest(p, stat, mult) {
        var ch = channel(stat);
        if (!ch || !on()) return 0;
        var w = worn(p);
        if (w[ch.stat] === undefined) { p.actionbar("&cWear a " + ch.n + " (or Rainbow) Z-Soul first."); return 0; }
        if (!atCap(p, ch.stat)) { p.actionbar("&cRaise " + ch.n + " to the cap (" + fmt(cap(p)) + ") first."); return 0; }
        var want = room(p, ch.stat, Math.max(1, Math.min(1000, Math.floor(Number(mult) || 1))));
        if (want <= 0) { p.actionbar("&eThis Z-Soul is full: a higher tier lets " + ch.n + " go further."); return 0; }
        // as many as the TP buys (prices only rise, so stop at the first one out of reach)
        var start = baseTotal(p) + banked(p, ch.stat), m = tpCostMult(p), tp = p.getTp(), spend = 0, n = 0;
        while (n < want) { var c = DMZ_F.singleCost(start + n, m); if (spend + c > tp) break; spend += c; n++; }
        if (n <= 0) { p.actionbar("&cNot enough TP (" + fmt(DMZ_F.singleCost(start, m)) + " for the next point)."); return 0; }
        p.setTp(tp - spend);
        setBanked(p, ch.stat, banked(p, ch.stat) + n);
        refresh(p);
        p.playSound("dmzpack:pip_menu", 1, 1.3);
        p.actionbar("&b+" + n + " " + ch.n + " beyond the cap &7(" + fmt(spend) + " TP)");
        return n;
    }
    function autoConvert(p) {
        if (!CFG.get("zsoul.autoConvertTrainingPoints")) return;
        if (typeof DBR_TCHAR !== "undefined" && DBR_TCHAR.isActive(p)) return;
        var w = worn(p), per = Math.max(0.01, Number(CFG.get("zsoul.trainingPointsPerPoint")) || 1), cap1 = Math.max(1, Math.floor(Number(CFG.get("zsoul.autoGrowthPerSecond")) || 1));
        var grew = false;
        Object.keys(w).forEach(function (st) {
            var tp = p.getTp();
            if (tp < per) return;
            var n = Math.min(room(p, st, cap1), Math.floor(tp / per));
            if (n <= 0) return;
            p.setTp(Math.max(0, tp - Math.ceil(n * per)));
            setBanked(p, st, banked(p, st) + n);
            grew = true;
        });
        if (grew) refresh(p);
    }

    // =================================================================================
    //  State for the screens (the stats screen buttons and the Z-Soul screen)
    // =================================================================================
    var LAST = {};
    function stateOf(p) {
        var w = worn(p), a = APPLIED[uid(p)] || {}, rows = [];
        CHANNELS.forEach(function (ch) {
            var t = w[ch.stat];
            rows.push({ k: ch.key, s: ch.stat, d: ch.dmz, n: ch.n, t: t === undefined ? -1 : t, max: t === undefined ? 0 : maxBonus(t), b: banked(p, ch.stat),
                a: a[ch.stat] || 0, capped: atCap(p, ch.stat), start: baseTotal(p) + banked(p, ch.stat) });
        });
        return { on: on(), cap: cap(p), slots: slotCount(), m: tpCostMult(p), auto: !!CFG.get("zsoul.autoConvertTrainingPoints"), per: Number(CFG.get("zsoul.trainingPointsPerPoint")) || 1,
            tiers: TIERS.map(function (T, i) { return { n: T.n, p: percent(i) }; }), rows: rows };
    }
    function sendState(p, force) {
        var st = stateOf(p), key = JSON.stringify(st);
        if (!force && LAST[uid(p)] === key) return;
        LAST[uid(p)] = key;
        RPG.net.send(p, "dbr_zsoul_state", st);
    }
    function openScreen(p) { sendState(p, true); RPG.net.send(p, "dbr_zsoul_open", {}); }
    RPG.net.on("dbr_zsoul", function (p, d) {
        if (!p || !d) return;
        var a = String(d.a || "");
        if (a === "state") sendState(p, true);
        else if (a === "open") openScreen(p);
        else if (a === "invest") invest(p, String(d.stat || ""), Number(d.n) || 1);
        else if (a === "accessories") { p.openAccessories(); return; }
        sendState(p, true);
    });

    // ---- the tick: re-project once a second (config edits, soul swaps), auto-convert TP ----
    RPG.every(20, function () {
        RPG.server.players().forEach(function (p) {
            try {
                if (on() && p.getVar("dmz_created", 0)) autoConvert(p);
                refresh(p);
            } catch (e) { RPG.log("[Z-Soul] " + p.name + ": " + e); }
        });
    });
    RPG.on("playerJoin", function (p) { delete LAST[uid(p)]; RPG.schedule(20, function () { refresh(p); }); });
    RPG.on("playerLeave", function (p) { delete APPLIED[uid(p)]; delete LAST[uid(p)]; });
    RPG.on("accessoryChange", function (p, slot) { if (String(slot).indexOf("z_soul_") === 0) refresh(p); });

    // =================================================================================
    //  /raid zsoul (RaidCommand: info, reset; give for ops)
    // =================================================================================
    function fmt(n) { return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
    function info(p, tell) {
        if (!on()) return tell("§cThe Z-Soul system is disabled.");
        if (!p.getVar("dmz_created", 0)) return tell("§cCreate a DragonMineZ character first.");
        var w = worn(p), a = APPLIED[uid(p)] || {};
        tell("§6Z-Souls §7(global cap " + fmt(CAP) + "):");
        CHANNELS.forEach(function (ch) {
            var t = w[ch.stat], tier = t === undefined ? "§7not worn" : TIERS[t].c.replace("&", "§") + TIERS[t].n + " §7(max +" + fmt(maxBonus(t)) + ")";
            tell("§e" + ch.n + ": §a+" + fmt(a[ch.stat] || 0) + " §7active, banked " + fmt(banked(p, ch.stat)) + ", " + tier);
        });
    }
    R.SUBS.zsoul = function (p, args) {
        var tell = function (s) { if (p) p.tell(s); else RPG.log(R.strip(s)); };
        var op = String(args[0] || "").toLowerCase();
        if (!op || op === "open") { if (p) { if (!R.can(p, "rg.raid.zsoul")) return tell("§cYou don't have permission (rg.raid.zsoul)."); openScreen(p); } return; }
        if (op === "info") { if (p) info(p, tell); return; }
        if (op === "invest") {
            if (!p) return;
            var ch = channel(String(args[1] || "").toLowerCase());
            if (!ch) return tell("§c/raid zsoul invest <" + CHANNELS.map(function (c) { return c.key; }).join("|") + "> <points>");
            invest(p, ch.stat, Number(args[2]) || 1);
            return;
        }
        if (op === "reset") {
            if (!R.can(p, "rg.raid.zsoul.reset")) return tell("§cYou don't have permission (rg.raid.zsoul.reset).");
            var target = args[1] ? RPG.server.player(String(args[1])) : p;
            if (!target) return tell("§cNo such player online.");
            target.setVar(V_BANK, null);
            refresh(target);
            return tell("§aReset " + target.name + "'s banked Z-Soul points to 0.");
        }
        if (op === "give") {
            if (!R.can(p, "rg.raid.zsoul.give")) return tell("§cYou don't have permission (rg.raid.zsoul.give).");
            var key = String(args[1] || "").toLowerCase(), t = tierIndex(String(args[2] || "").toLowerCase());
            var c2 = key === "rainbow" || key === "all" ? null : channel(key);
            var who = args[3] ? RPG.server.player(String(args[3])) : p;
            if ((key !== "rainbow" && key !== "all" && !c2) || t < 0) return tell("§c/raid zsoul give <" + CHANNELS.map(function (c) { return c.key; }).join("|") + "|rainbow> <bronze|silver|gold|prismatic> [player]");
            if (!who) return tell("§cNo such player online.");
            who.giveItem(itemName(c2, t), 1);
            return tell("§aGave " + who.name + " a " + TIERS[t].n + " " + (c2 ? c2.n : "Rainbow") + " Z-Soul.");
        }
        tell("§c/raid zsoul [info | invest <stat> <points> | reset [player] | give <stat> <tier> [player]]");
    };
    R.SUBS.zsoul.suggest = function (p, w) {
        if (w.length <= 1) return ["info", "invest", "reset", "give"];
        var op = String(w[0]).toLowerCase();
        if ((op === "invest" || op === "give") && w.length === 2) return CHANNELS.map(function (c) { return c.key; }).concat(op === "give" ? ["rainbow"] : []);
        if (op === "give" && w.length === 3) return TIERS.map(function (T) { return T.id; });
        return RPG.server.players().map(function (o) { return o.name; });
    };
    RPG.perms.group("default", ["rg.raid.zsoul"]);

    return { cap: cap, worn: worn, banked: banked, room: room, grantBeyondCap: grantBeyondCap, invest: invest, investCost: investCost, refresh: refresh,
        open: openScreen, items: allItemNames, maxBonus: maxBonus, TIERS: TIERS, CHANNELS: CHANNELS };
})();
