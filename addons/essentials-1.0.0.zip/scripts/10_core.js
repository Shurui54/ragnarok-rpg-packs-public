// =====================================================================================
//  Essentials - shared helpers (used by the other files of this addon)
// =====================================================================================

function essMsg(p, text) { if (p) p.tell(ESS.prefix + text); }
function essHas(p, node) { return RPG.perms.has(p, node); }
function essMoney(n) { return ESS.currency + (Math.round(n * 100) / 100).toLocaleString(); }

/** Where a player is right now (for homes, warps, /back). */
function essLoc(p) { return { dim: p.dimension, x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch }; }

/** An online player by exact or partial name, or null (and tells `asker` why). */
function essFind(asker, name) {
    if (!name) { essMsg(asker, "&cWho? Give a player name."); return null; }
    let exact = RPG.server.player(name);
    if (exact) return exact;
    let low = name.toLowerCase(), hits = RPG.server.players().filter((q) => q.name.toLowerCase().indexOf(low) === 0);
    if (hits.length === 1) return hits[0];
    essMsg(asker, hits.length ? "&cMore than one player matches &f" + name : "&cNo player online called &f" + name);
    return null;
}

function essOnlineNames() { return RPG.server.players().map((q) => q.name); }

/** Teleport with a short stand-still warm-up; remembers where they were for /back. */
var ESS_WARMUP = {};
function essTeleport(p, loc, what) {
    let go = () => {
        p.setVar("ess_back", essLoc(p));
        p.teleportTo(loc.dim, loc.x, loc.y, loc.z, loc.yaw || 0, loc.pitch || 0);
        p.playSound("minecraft:entity.enderman.teleport", 0.6, 1.2);
        essMsg(p, "&7Teleported to &f" + what + "&7.");
    };
    if (ESS.teleportDelay <= 0 || essHas(p, "essentials.teleport.instant")) { go(); return; }
    let start = essLoc(p), serial = (ESS_WARMUP[p.uuid] || 0) + 1, left = ESS.teleportDelay * 20;
    ESS_WARMUP[p.uuid] = serial;
    essMsg(p, "&7Teleporting in &f" + ESS.teleportDelay + "&7s, don't move...");
    let tick = () => {
        if (ESS_WARMUP[p.uuid] !== serial) return;
        if (Math.abs(p.x - start.x) + Math.abs(p.y - start.y) + Math.abs(p.z - start.z) > 0.6) { essMsg(p, "&cTeleport cancelled: you moved."); return; }
        left -= 5;
        if (left <= 0) go(); else RPG.schedule(5, tick);
    };
    RPG.schedule(5, tick);
}

/** Registers a top-level command guarded by essentials.<name>. */
function essCmd(name, opts, run) {
    RPG.commands.register(name, {
        root: true,
        aliases: opts.aliases || [],
        description: opts.desc || "",
        permission: "essentials." + (opts.perm || name),
        suggest: opts.suggest || ((p, args) => args.length <= 1 ? essOnlineNames() : []),
        run(p, args) { if (!p && !opts.console) return; run(p, args); }
    });
}

// remember where players died, for /back
RPG.on("death", (p) => { p.setVar("ess_back", essLoc(p)); });
