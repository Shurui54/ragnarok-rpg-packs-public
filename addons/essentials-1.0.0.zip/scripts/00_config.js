// =====================================================================================
//  Essentials - settings and permission groups
// =====================================================================================
//  Every command checks a permission node "essentials.<command>". Groups below are the
//  defaults; change them here or in game:
//      /rpg perm user Steve group add vip
//      /rpg perm group default set essentials.fly true
//  Operators have every node.
// =====================================================================================

var ESS = {
    prefix: "&6[&eEss&6] &r",
    currency: "$",
    startingMoney: 100,
    maxHomes: 3,                    // more with essentials.homes.<n> (e.g. essentials.homes.10) or essentials.homes.unlimited
    teleportDelay: 3,               // seconds standing still before a teleport (essentials.teleport.instant skips it)
    tpaTimeout: 60,                 // seconds a /tpa request stays open
    afkMinutes: 5,                  // idle time before someone is marked AFK
    spawnOnFirstJoin: true,
    motd: ["&6Welcome, &e{name}&6!", "&7Type &f/commands&7 to see what you can do."],
    kits: {
        starter: { name: "&aStarter", icon: "minecraft:stone_sword", cooldown: 0, once: true,
            items: ["minecraft:stone_sword", "minecraft:stone_pickaxe", "minecraft:stone_axe", { id: "minecraft:bread", count: 16 }, { id: "minecraft:torch", count: 16 }] },
        tools: { name: "&bTools", icon: "minecraft:iron_pickaxe", cooldown: 86400,
            items: ["minecraft:iron_pickaxe", "minecraft:iron_shovel", "minecraft:iron_axe"] },
        food: { name: "&6Food", icon: "minecraft:cooked_beef", cooldown: 3600,
            items: [{ id: "minecraft:cooked_beef", count: 16 }, { id: "minecraft:golden_carrot", count: 8 }] },
        vip: { name: "&dVIP", icon: "minecraft:diamond", cooldown: 604800,
            items: [{ id: "minecraft:diamond", count: 3 }, { id: "minecraft:golden_apple", count: 2 }, { id: "minecraft:experience_bottle", count: 16 }] }
    }
};

RPG.perms.group("default", [
    "essentials.help", "essentials.spawn", "essentials.home", "essentials.sethome", "essentials.delhome", "essentials.homes",
    "essentials.warp", "essentials.warps", "essentials.tpa", "essentials.tpahere", "essentials.tpaccept", "essentials.tpdeny",
    "essentials.tpacancel", "essentials.back", "essentials.msg", "essentials.bal", "essentials.pay", "essentials.baltop",
    "essentials.kit", "essentials.kits", "essentials.kit.starter", "essentials.kit.food", "essentials.kit.tools",
    "essentials.afk", "essentials.near", "essentials.ping", "essentials.seen", "essentials.suicide"
]);
RPG.perms.group("vip", [
    "essentials.homes.10", "essentials.nick", "essentials.hat", "essentials.enderchest", "essentials.feed",
    "essentials.kit.vip", "essentials.top", "essentials.teleport.instant"
], ["default"]);
RPG.perms.group("admin", ["essentials.*"], ["vip"]);
