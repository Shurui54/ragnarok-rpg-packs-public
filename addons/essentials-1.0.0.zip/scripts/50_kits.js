// =====================================================================================
//  Essentials - kits: /kits (a menu) and /kit <name>. Kits are in 00_config.js.
// =====================================================================================

function essKitState(p, name) {
    let k = ESS.kits[name];
    if (!k) return "missing";
    if (!essHas(p, "essentials.kit." + name)) return "locked";
    let last = p.getVar("ess_kit_" + name, 0);
    if (k.once && last) return "claimed";
    let wait = last + (k.cooldown || 0) * 1000 - Date.now();
    return wait > 0 ? wait : "ready";
}
function essTime(ms) { let s = Math.ceil(ms / 1000); return s < 60 ? s + "s" : s < 3600 ? Math.ceil(s / 60) + "m" : s < 86400 ? Math.ceil(s / 3600) + "h" : Math.ceil(s / 86400) + "d"; }

function essClaimKit(p, name) {
    let st = essKitState(p, name);
    if (st === "missing") { essMsg(p, "&cNo kit called &f" + name); return false; }
    if (st === "locked") { essMsg(p, "&cYou can't use that kit."); return false; }
    if (st === "claimed") { essMsg(p, "&cYou already claimed that kit."); return false; }
    if (st !== "ready") { essMsg(p, "&cAgain in &f" + essTime(st)); return false; }
    ESS.kits[name].items.forEach((it) => p.giveStack(typeof it === "string" ? { id: it, count: 1 } : it));
    p.setVar("ess_kit_" + name, Date.now());
    p.playSound("minecraft:entity.item.pickup", 0.8, 1);
    essMsg(p, "&aKit &f" + name + "&a claimed.");
    return true;
}

essCmd("kit", { desc: "Claim a kit", suggest: () => Object.keys(ESS.kits) }, (p, args) => {
    if (!args.length) { essOpenKits(p); return; }
    essClaimKit(p, args[0].toLowerCase());
});
essCmd("kits", { desc: "Kit menu", suggest: () => [] }, (p) => essOpenKits(p));

function essOpenKits(p) {
    let names = Object.keys(ESS.kits), items = [];
    names.forEach((n, i) => {
        let k = ESS.kits[n], st = essKitState(p, n);
        let line = st === "ready" ? "&aClick to claim" : st === "locked" ? "&cLocked" : st === "claimed" ? "&7Already claimed" : "&eAgain in " + essTime(st);
        items[i] = { id: k.icon || "minecraft:chest", name: k.name || n, lore: [line, "&7" + k.items.length + " items"] };
    });
    RPG.ui.container(p, {
        title: "&8Kits", rows: Math.max(1, Math.ceil(names.length / 9)), mode: "menu", items: items,
        onClick(pl, slot) {
            if (slot < names.length && essClaimKit(pl, names[slot])) RPG.schedule(1, () => essOpenKits(pl));
        }
    });
}
