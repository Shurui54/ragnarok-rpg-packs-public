// =====================================================================================
//  Ranks & Kits - kits
// =====================================================================================
//  Kits are made in game: /kitadmin opens the editor. Capture your own inventory (armour and
//  off hand included, enchantments and all item data kept) or drag items into a chest.
//  Players browse with /kits, preview a kit, and claim it (/kit <name> claims directly).
//
//  Saved with the world: rk.kit.<id> = { id, name, icon, cooldown (seconds), once, permission,
//  rank (that rank or a heavier one), cost, autoEquip, firstJoin, order, items: [{s, id, count, nbt}] }
//  s = the inventory slot it came from: 0-8 hotbar, 9-35 inventory, 36-39 feet..head, 40 off hand.
//  Each player's last claim is the player var "rk_kit_<id>" (milliseconds).
//  Access: no permission and no rank = everyone; the node kits.kit.<id> always allows; a rank's
//  "kits" list (rank editor, Kits tab) allows too.
// =====================================================================================

var KT_KITS = {};
RPG.data.keys("rk.kit.").forEach((k) => { let kit = RPG.data.get(k, null); if (kit && kit.id) KT_KITS[kit.id] = kit; });

function ktCleanStack(st, slot) {
    if (!st || !st.id || st.id === "minecraft:air") return null;
    // keep id, count and the full NBT: name/lore/enchantments live in the NBT already
    let o = { s: slot, id: String(st.id), count: Math.max(1, st.count || 1) };
    if (st.nbt) o.nbt = String(st.nbt);
    return o;
}
function ktStack(it) { let o = { id: it.id, count: it.count || 1 }; if (it.nbt) o.nbt = it.nbt; return o; }

function ktClean(id, k) {
    k = k || {};
    let num = (v, d, lo, hi) => { let n = parseFloat(v); return isNaN(n) ? d : RPG.clamp(n, lo, hi); };
    return {
        id: id,
        name: String(k.name || id).substring(0, 40),
        icon: String(k.icon || "minecraft:chest"),
        cooldown: Math.round(num(k.cooldown, 0, 0, 31536000 * 10)),
        once: !!k.once,
        permission: String(k.permission || "").trim().substring(0, 96),
        rank: String(k.rank || ""),
        cost: Math.round(num(k.cost, 0, 0, 1e12) * 100) / 100,
        autoEquip: k.autoEquip === undefined ? true : !!k.autoEquip,
        firstJoin: !!k.firstJoin,
        order: Math.round(num(k.order, 0, -9999, 9999)),
        items: Array.isArray(k.items) ? k.items.filter((it) => it && it.id).slice(0, 41) : []
    };
}
function ktSave(kit) { KT_KITS[kit.id] = kit; RPG.data.set("rk.kit." + kit.id, kit); }
function ktListIds() {
    return Object.keys(KT_KITS).sort((a, b) => KT_KITS[a].order - KT_KITS[b].order || (a < b ? -1 : 1));
}

// first run: bring over Essentials' kits (00_config.js of that addon), with their permission nodes
if (!RPG.data.has("rk.kitsImported")) {
    RPG.data.set("rk.kitsImported", true);
    if (typeof ESS !== "undefined" && ESS.kits) Object.keys(ESS.kits).forEach((n, i) => {
        let e = ESS.kits[n], items = [];
        (e.items || []).forEach((it, j) => { items.push(typeof it === "string" ? { s: j, id: it, count: 1 } : { s: j, id: it.id, count: it.count || 1 }); });
        ktSave(ktClean(n, { name: e.name, icon: e.icon, cooldown: e.cooldown, once: e.once, items: items, order: i,
            permission: "essentials.kit." + n }));
    });
}

// ---- who can claim what -----------------------------------------------------------------------------

function ktAccess(p, kit) {
    if (RPG.perms.has(p, "kits.kit." + kit.id)) return true;
    let ranks = rkPlayerRanks(p);
    if (ranks.some((r) => (r.kits || []).indexOf(kit.id) >= 0)) return true;
    if (kit.rank && RK_RANKS[kit.rank]) {
        let need = RK_RANKS[kit.rank].weight;
        if (!ranks.some((r) => r.id === kit.rank || r.weight >= need)) return false;
    }
    if (kit.permission && !RPG.perms.has(p, kit.permission)) return false;
    return true;
}

/** The smallest kit cooldown multiplier among a player's ranks (VIP 0.5 = half the wait). */
function ktMult(p) {
    let m = 1, any = false;
    rkPlayerRanks(p).forEach((r) => { if (r.kitMult !== undefined && r.kitMult !== null) { m = any ? Math.min(m, r.kitMult) : r.kitMult; any = true; } });
    return any ? m : 1;
}

/** "ready", "locked", "claimed", "money" or milliseconds still to wait. */
function ktState(p, kit) {
    if (!ktAccess(p, kit)) return "locked";
    let last = p.getVar("rk_kit_" + kit.id, 0) || 0;
    if (kit.once && last) return "claimed";
    let wait = last ? last + kit.cooldown * 1000 * ktMult(p) - Date.now() : 0;
    if (wait > 0) return wait;
    if (kit.cost > 0 && p.getMoney() < kit.cost) return "money";
    return "ready";
}

function ktNeeds(kit) {
    let out = [];
    if (kit.rank && RK_RANKS[kit.rank]) out.push("&7Rank: &f" + RK_RANKS[kit.rank].name + " &7or higher");
    if (kit.permission) out.push("&7Needs: &f" + kit.permission);
    return out;
}

function ktStatusLine(p, kit, st) {
    if (st === "ready") return kit.cost > 0 ? "&aReady &7- costs &e" + rkMoney(kit.cost) : "&aReady to claim";
    if (st === "locked") return "&cLocked";
    if (st === "claimed") return "&7Already claimed (one time)";
    if (st === "money") return "&cCosts &e" + rkMoney(kit.cost) + " &c- you have &e" + rkMoney(p.getMoney());
    return "&eAgain in &f" + rkDuration(st / 1000);
}

/** Give a kit. free: no checks, no cost, no cooldown (admins, first join). Returns true when given. */
function ktGive(p, kit, free) {
    if (!free) {
        let st = ktState(p, kit);
        if (st !== "ready") {
            rkMsg(p, st === "locked" ? "&cYou can't use the kit &f" + kit.name + "&c." + (ktNeeds(kit).length ? " " + ktNeeds(kit).join(" ") : "")
                : "&c" + ktStatusLine(p, kit, st).replace(/^&./, ""));
            p.playSound("minecraft:block.note_block.bass", 0.6, 0.8);
            return false;
        }
        if (kit.cost > 0 && !p.takeMoney(kit.cost)) { rkMsg(p, "&cYou can't afford that."); return false; }
        p.setVar("rk_kit_" + kit.id, Date.now());
    }
    kit.items.forEach((it) => {
        let s = ktStack(it);
        if (kit.autoEquip && it.s >= 36 && it.s <= 40 && !p.getStack(it.s)) p.setStack(it.s, s);
        else p.giveStack(s);
    });
    p.playSound("minecraft:entity.item.pickup", 0.8, 1);
    p.playSound("minecraft:item.armor.equip_generic", 0.5, 1.2);
    rkMsg(p, "&aYou got the kit &f" + kit.name + "&a." + (kit.cost > 0 && !free ? " &7(-" + rkMoney(kit.cost) + ")" : ""));
    return true;
}

RPG.on("firstJoin", (p) => {
    RPG.schedule(RK_CFG.get("kits.firstJoinDelay"), () => {
        ktListIds().forEach((id) => { let k = KT_KITS[id]; if (k && k.firstJoin && !p.getVar("rk_kit_" + id, 0)) { ktGive(p, k, true); p.setVar("rk_kit_" + id, Date.now()); } });
    });
});

// ---- chest layout: the kit's inventory slots shown like a player inventory --------------------------
//  rows 1-3: inventory (9-35)   row 4: hotbar (0-8)   row 5: head, chest, legs, feet, off hand

function ktChestOf(s) { return s >= 9 && s <= 35 ? s - 9 : s >= 0 && s <= 8 ? 27 + s : s >= 36 && s <= 39 ? 36 + (39 - s) : s === 40 ? 40 : -1; }
function ktSlotOf(c) { return c >= 0 && c <= 26 ? c + 9 : c >= 27 && c <= 35 ? c - 27 : c >= 36 && c <= 39 ? 39 - (c - 36) : c === 40 ? 40 : -1; }
var KT_PANE = { id: "minecraft:gray_stained_glass_pane", name: "&8 ", data: { rkPane: 1 } };
function ktPane(name, lore) { return { id: "minecraft:gray_stained_glass_pane", name: name, lore: lore || [], data: { rkPane: 1 } }; }

/** Where kit items go if their slot is taken (two items in the same slot from older data). */
function ktLayout(kit) {
    let out = [], used = {};
    kit.items.forEach((it) => {
        let c = ktChestOf(it.s);
        if (c < 0 || used[c]) { c = -1; for (let i = 0; i < 41; i++) if (!used[i]) { c = i; break; } }
        if (c < 0) return;
        used[c] = true;
        out[c] = ktStack(it);
    });
    return out;
}

// ---- the kit menu (/kits) and a kit's preview ---------------------------------------------------------

function ktOpenMenu(p, page) {
    let ids = ktListIds();
    let per = 45, pages = Math.max(1, Math.ceil(ids.length / per));
    page = RPG.clamp(page || 0, 0, pages - 1);
    let shown = ids.slice(page * per, page * per + per), items = [];
    shown.forEach((id, i) => {
        let k = KT_KITS[id], st = ktState(p, k);
        let lore = [ktStatusLine(p, k, st), "&8" + k.items.length + " item stack" + (k.items.length === 1 ? "" : "s")];
        if (k.cooldown && !k.once) lore.push("&7Cooldown: &f" + rkDuration(k.cooldown * ktMult(p)));
        if (k.once) lore.push("&7One time only");
        if (st === "locked") ktNeeds(k).forEach((l) => lore.push(l));
        lore.push("");
        lore.push("&eLeft-click &7to preview");
        if (st === "ready") lore.push("&eRight-click &7to claim");
        items[i] = { id: k.icon || "minecraft:chest", count: 1, name: (st === "ready" ? "&a" : st === "locked" ? "&c" : "&e") + k.name, lore: lore };
    });
    let rows = Math.max(1, Math.ceil(shown.length / 9));
    if (pages > 1 || !shown.length) {
        rows = 6;
        if (!shown.length) items[22] = { id: "minecraft:barrier", name: "&7No kits yet", lore: RPG.perms.has(p, "kits.admin") ? ["&7Make one with &f/kitadmin"] : [] };
        if (page > 0) items[45] = { id: "minecraft:arrow", name: "&fPrevious page" };
        items[49] = { id: "minecraft:paper", name: "&7Page " + (page + 1) + " / " + pages };
        if (page < pages - 1) items[53] = { id: "minecraft:arrow", name: "&fNext page" };
    }
    RPG.ui.container(p, {
        title: "&8Kits", rows: rows, mode: "menu", items: items,
        onClick(pl, slot, stack, button) {
            if (rows === 6 && slot >= 45) {
                if (slot === 45 && page > 0) RPG.schedule(1, () => ktOpenMenu(pl, page - 1));
                if (slot === 53 && page < pages - 1) RPG.schedule(1, () => ktOpenMenu(pl, page + 1));
                return;
            }
            let id = shown[slot];
            if (!id || !KT_KITS[id]) return;
            if (button === "right") { ktGive(pl, KT_KITS[id], false); RPG.schedule(1, () => ktOpenMenu(pl, page)); }
            else RPG.schedule(1, () => ktPreview(pl, id, () => ktOpenMenu(pl, page)));
        }
    });
}

function ktPreview(p, id, back) {
    let k = KT_KITS[id];
    if (!k) return;
    let st = ktState(p, k), items = ktLayout(k);
    for (let c = 41; c <= 44; c++) items[c] = c === 41 ? ktPane("&8← armour, off hand") : KT_PANE;
    items[45] = { id: "minecraft:arrow", name: back ? "&fBack" : "&fClose" };
    for (let c = 46; c <= 52; c++) items[c] = KT_PANE;
    let info = [ktStatusLine(p, k, st)];
    if (k.cooldown && !k.once) info.push("&7Cooldown: &f" + rkDuration(k.cooldown * ktMult(p)) + (ktMult(p) !== 1 ? " &8(your rank: x" + ktMult(p) + ")" : ""));
    if (k.once) info.push("&7One time only");
    if (k.cost > 0) info.push("&7Price: &e" + rkMoney(k.cost));
    ktNeeds(k).forEach((l) => info.push(l));
    items[49] = { id: "minecraft:clock", name: "&f" + k.name, lore: info };
    items[53] = st === "ready" ? { id: "minecraft:lime_concrete", name: "&aClaim", lore: k.cost > 0 ? ["&7Costs &e" + rkMoney(k.cost)] : ["&7Click to claim this kit"] }
        : { id: "minecraft:red_concrete", name: "&cCan't claim yet", lore: [ktStatusLine(p, k, st)] };
    RPG.ui.container(p, {
        title: "&8Kit: " + k.name.replace(/&./g, ""), rows: 6, mode: "menu", items: items,
        onClick(pl, slot) {
            if (slot === 45) { if (back) RPG.schedule(1, back); else RPG.schedule(1, () => ktOpenMenu(pl, 0)); }
            if (slot === 53) {
                if (ktGive(pl, KT_KITS[id], false)) RPG.schedule(1, () => { if (back) back(); else ktOpenMenu(pl, 0); });
                else RPG.schedule(1, () => ktPreview(pl, id, back));
            }
        }
    });
}

// ---- editing (kits.admin): chest editor and inventory capture -------------------------------------------

function ktCapture(p, kit) {
    let items = [];
    for (let s = 0; s <= 40; s++) { let it = ktCleanStack(p.getStack(s), s); if (it) items.push(it); }
    kit.items = items;
    ktSave(kit);
    return items.length;
}

function ktOpenItems(p, id) {
    let k = KT_KITS[id];
    if (!k) return;
    let items = ktLayout(k);
    items[41] = ktPane("&7← head, chest, legs, feet, off hand", ["&7Rows 1-3: inventory", "&7Row 4: hotbar", "&eClose this screen to save"]);
    for (let c = 42; c <= 44; c++) items[c] = ktPane("&eClose to save", []);
    RPG.ui.container(p, {
        title: "&8Kit items: " + k.name.replace(/&./g, "") + " (close = save)", rows: 5, items: items,
        onClick(pl, slot) { return slot < 41; },
        onClose(pl, now) {
            let kit = KT_KITS[id];
            if (!kit) return;
            let list = [];
            for (let c = 0; c < 41; c++) { let it = ktCleanStack(now[c], ktSlotOf(c)); if (it) list.push(it); }
            kit.items = list;
            ktSave(kit);
            rkMsg(pl, "&aKit &f" + kit.name + "&a saved: &f" + list.length + "&a stacks.");
            RPG.schedule(2, () => ktSendKit(pl, id, true));
        }
    });
}

function ktCreate(id, name) {
    id = String(id || "").toLowerCase().trim();
    if (!/^[a-z0-9_\-]{1,24}$/.test(id)) return "Kit ids are 1-24 letters, digits, - or _ (no spaces).";
    if (KT_KITS[id]) return "There already is a kit called " + id + ".";
    ktSave(ktClean(id, { name: name || ("&f" + id.charAt(0).toUpperCase() + id.substring(1)), order: ktListIds().length }));
    return null;
}
function ktDelete(id) {
    if (!KT_KITS[id]) return "No kit called " + id + ".";
    delete KT_KITS[id];
    RPG.data.remove("rk.kit." + id);
    Object.keys(RK_RANKS).forEach((r) => { let i = RK_RANKS[r].kits.indexOf(id); if (i >= 0) RK_RANKS[r].kits.splice(i, 1); });
    rkSaveRanks();
    return null;
}

function ktSummary(k) {
    return { id: k.id, name: k.name, icon: k.icon, cooldown: k.cooldown, once: k.once, cost: k.cost, count: k.items.length,
        permission: k.permission, rank: k.rank, firstJoin: k.firstJoin };
}
function ktSendList(p, open, note) {
    RPG.net.send(p, "kt_list", { open: !!open, note: note || "", kits: ktListIds().map((id) => ktSummary(KT_KITS[id])) });
}
function ktSendKit(p, id, open, note) {
    let k = KT_KITS[id];
    if (!k) { ktSendList(p, true, note); return; }
    let s = ktSummary(k);
    s.autoEquip = k.autoEquip; s.order = k.order;
    s.items = k.items.map((it) => ({ s: it.s, id: it.id, count: it.count }));
    RPG.net.send(p, "kt_kit", { open: !!open, note: note || "", kit: s, ranks: rkIds().map((r) => ({ id: r, name: RK_RANKS[r].name })),
        money: (RPG.currency.get() || {}).symbol || "$" });
}

RPG.net.on("kt", (p, d) => {
    if (!d || typeof d.a !== "string") return;
    if (!RPG.perms.has(p, "kits.admin")) { RPG.net.send(p, "rk_note", { text: "You can't edit kits.", bad: true }); return; }
    let id = d.id ? String(d.id).toLowerCase() : "", k = KT_KITS[id], err;
    let note = (t, bad) => RPG.net.send(p, "rk_note", { text: t, bad: !!bad });
    switch (d.a) {
        case "list": ktSendList(p, !!d.open); return;
        case "get": ktSendKit(p, id, true); return;
        case "create":
            err = ktCreate(d.id, d.name ? String(d.name).substring(0, 40) : "");
            if (err) { note(err, true); return; }
            if (d.capture) ktCapture(p, KT_KITS[String(d.id).toLowerCase()]);
            ktSendKit(p, String(d.id).toLowerCase(), true, "Kit created.");
            return;
        case "delete":
            err = ktDelete(id);
            ktSendList(p, true, err || "Kit deleted.");
            return;
        case "save": {
            if (!k) break;
            let v = d.kit || {}, cd = v.cooldown === undefined ? k.cooldown : rkParseDuration(v.cooldown);
            if (isNaN(cd)) { note("Cooldown: like 30m, 12h, 1d 6h or seconds.", true); return; }
            let cost = String(v.cost === undefined ? k.cost : v.cost).trim();
            if (cost !== "" && isNaN(parseFloat(cost))) { note("Cost must be a number.", true); return; }
            if (v.rank && !RK_RANKS[v.rank]) v.rank = "";
            let merged = JSON.parse(JSON.stringify(k));
            ["name", "icon", "once", "permission", "rank", "autoEquip", "firstJoin", "order"].forEach((f) => { if (v[f] !== undefined) merged[f] = v[f]; });
            merged.cooldown = cd; merged.cost = cost === "" ? 0 : parseFloat(cost);
            if (!/^[a-z0-9_\-.:\/]+$/.test(String(merged.icon))) merged.icon = "minecraft:chest";
            ktSave(ktClean(id, merged));
            ktSendKit(p, id, false, "Saved.");
            return;
        }
        case "capture":
            if (!k) break;
            ktSendKit(p, id, false, "Captured " + ktCapture(p, k) + " stacks from your inventory.");
            return;
        case "items":
            if (!k) break;
            ktOpenItems(p, id);
            return;
        case "held": {
            if (!k) break;
            let h = p.getHeldItem();
            if (!h || h === "minecraft:air") { note("Hold the item you want as the icon.", true); return; }
            k.icon = h; ktSave(k);
            ktSendKit(p, id, false, "Icon set.");
            return;
        }
        case "preview":
            if (!k) break;
            ktPreview(p, id, () => ktSendKit(p, id, true));
            return;
        case "give":
            if (!k) break;
            ktGive(p, k, true);
            return;
    }
    note("No such kit.", true);
});

// ---- commands -----------------------------------------------------------------------------------------

function ktFind(name) {
    let n = String(name || "").toLowerCase();
    if (KT_KITS[n]) return KT_KITS[n];
    let hit = ktListIds().filter((id) => KT_KITS[id].name.replace(/&./g, "").toLowerCase() === n)[0];
    return hit ? KT_KITS[hit] : null;
}

RPG.commands.register("kit", {
    root: true, permission: "kits.use", description: "Claim a kit: /kit <name> (no name opens the kit menu)",
    suggest(p) { return p ? ktListIds().filter((id) => ktAccess(p, KT_KITS[id])) : ktListIds(); },
    run(p, args) {
        if (!p) return;
        if (!args.length) { ktOpenMenu(p, 0); return; }
        let k = ktFind(args.join(" "));
        if (!k) { rkMsg(p, "&cNo kit called &f" + args.join(" ") + "&c. &7/kits shows them all."); return; }
        ktGive(p, k, false);
    }
});
RPG.commands.register("kits", {
    root: true, permission: "kits.use", description: "Browse, preview and claim kits",
    suggest() { return []; },
    run(p, args) { if (p) { if (args.length && ktFind(args[0])) ktPreview(p, ktFind(args[0]).id, null); else ktOpenMenu(p, 0); } }
});
RPG.commands.register("kitadmin", {
    root: true, aliases: ["kitedit"], permission: "kits.admin",
    description: "Kit editor: /kitadmin [create <id> [name] | edit <id> | delete <id> | give <player> <kit> | reset <player> [kit]]",
    suggest(p, args) {
        if (args.length <= 1) return ["create", "edit", "delete", "give", "reset", "list"];
        let s = String(args[0]).toLowerCase();
        if (s === "edit" || s === "delete") return args.length === 2 ? ktListIds() : [];
        if (s === "give" || s === "reset") return args.length === 2 ? rkOnlineNames() : args.length === 3 ? ktListIds() : [];
        return [];
    },
    run(p, args) {
        let sub = args.length ? String(args[0]).toLowerCase() : "gui", err;
        switch (sub) {
            case "gui": if (p) ktSendList(p, true); return;
            case "list": rkMsg(p, "&7Kits: &f" + (ktListIds().join(", ") || "none")); return;
            case "create":
                if (!args[1]) { rkMsg(p, "&c/kitadmin create <id> [display name]  &7(takes your current inventory)"); return; }
                err = ktCreate(args[1], args.slice(2).join(" "));
                if (err) { rkMsg(p, "&c" + err); return; }
                if (p) { let n = ktCapture(p, KT_KITS[String(args[1]).toLowerCase()]); rkMsg(p, "&aKit created from your inventory (&f" + n + "&a stacks)."); ktSendKit(p, String(args[1]).toLowerCase(), true); }
                return;
            case "edit":
                if (!p) return;
                if (!KT_KITS[String(args[1] || "").toLowerCase()]) { rkMsg(p, "&cNo kit called &f" + (args[1] || "")); return; }
                ktSendKit(p, String(args[1]).toLowerCase(), true);
                return;
            case "delete":
                err = ktDelete(String(args[1] || "").toLowerCase());
                rkMsg(p, err ? "&c" + err : "&7Kit deleted.");
                return;
            case "give": {
                let t = RPG.server.player(args[1] || ""), k = ktFind(args[2]);
                if (!t || !k) { rkMsg(p, "&c/kitadmin give <online player> <kit>"); return; }
                ktGive(t, k, true);
                rkMsg(p, "&7Gave &f" + k.name + "&7 to &f" + t.name + "&7.");
                return;
            }
            case "reset": {
                let t = RPG.server.player(args[1] || "");
                if (!t) { rkMsg(p, "&c/kitadmin reset <online player> [kit]"); return; }
                let ids = args[2] ? [String(args[2]).toLowerCase()] : ktListIds();
                ids.forEach((id) => t.setVar("rk_kit_" + id, null));
                rkMsg(p, "&7Kit cooldowns reset for &f" + t.name + "&7.");
                return;
            }
        }
        rkMsg(p, "&c/kitadmin [create <id> [name] | edit <id> | delete <id> | give <player> <kit> | reset <player> [kit] | list]");
    }
});
