// =====================================================================================
//  Ranks & Kits - settings (ragnarok_rpg/config/ranks_kits.json, or /rpg config ranks_kits ...)
// =====================================================================================
//  Ranks and kits themselves are made in game:  /rank  (rank editor)   /kitadmin  (kit editor)
//  They are saved with the world. Every rank is a permission group (RPG.perms), so the
//  nodes you toggle in the editor really apply, also to other addons' commands.
// =====================================================================================

var RK_CFG = RPG.config.define("ranks_kits", {
    prefix: { default: "&8[&6Ranks&8] &r", comment: "Put before this addon's chat messages" },
    chat: {
        enabled: { default: true, comment: "Format chat lines with the sender's rank" },
        format: { default: "{badge}{prefix}{color}{name}{suffix}&8 » {chatcolor}{message}",
            comment: "Tokens: {badge} (the rank's badge picture; put in front when the format has no {badge}) {prefix} {suffix} {color} (name colour) {name} (nickname or name) {rank} (rank name) {chatcolor} {message}" },
        colorNode: { default: "ranks.chat.color", comment: "Players with this node may use & colour codes in chat" }
    },
    tab: {
        teams: { default: true, comment: "Put players in a scoreboard team per rank: prefix/suffix and colour over heads and in the tab list, tab list sorted by rank" },
        respectOtherTeams: { default: true, comment: "Leave players alone who are in a team another addon or /team made" }
    },
    badges: {
        tab: { default: true, comment: "Show a rank's badge picture before names in the tab list and over heads (part of the rank team's prefix)" },
        chat: { default: true, comment: "Show a rank's badge picture in chat ({badge} in chat.format)" },
        chatHeight: { default: 0, min: 0, max: 32, integer: true, comment: "Badge height in chat in pixels (0: one chat row, 9; taller badges overlap the lines around them)" }
    },
    ranks: {
        checkSeconds: { default: 30, min: 5, max: 3600, integer: true, comment: "How often timed ranks are checked for expiry" },
        announce: { default: true, comment: "Tell a player when they get or lose a rank" }
    },
    kits: {
        firstJoinDelay: { default: 40, min: 0, max: 1200, integer: true, comment: "Ticks after a first join before first-join kits are given" },
        currency: { default: "", comment: "Money symbol shown on kit prices (empty: the project's currency symbol)" }
    }
});

// Who may do what. Operators have every node. Change in game: /rank (Permissions tab) or /rpg perm.
RPG.perms.group("default", ["ranks.info", "ranks.list", "kits.use"]);
RPG.perms.group("admin", ["ranks.*", "kits.*"]);

function rkMsg(p, text) { if (p) p.tell(RK_CFG.get("prefix") + text); else RPG.log(String(text).replace(/&./g, "")); }
function rkHas(p, node) { return !p || RPG.perms.has(p, node); }

/** "1d 2h 30m", "90m", "45s", "3600" (seconds) -> seconds; NaN when unreadable. */
function rkParseDuration(text) {
    let s = String(text === undefined || text === null ? "" : text).trim().toLowerCase();
    if (s === "" || s === "0" || s === "none" || s === "off") return 0;
    if (/^\d+(\.\d+)?$/.test(s)) return Math.round(parseFloat(s));
    let total = 0, any = false, re = /(\d+(?:\.\d+)?)\s*(w|d|h|m|s)/g, m;
    while ((m = re.exec(s)) !== null) {
        any = true;
        total += parseFloat(m[1]) * { w: 604800, d: 86400, h: 3600, m: 60, s: 1 }[m[2]];
    }
    return any && s.replace(re, "").trim() === "" ? Math.round(total) : NaN;
}

/** Seconds -> "1d 2h", "5m 10s", "0s". */
function rkDuration(sec) {
    sec = Math.max(0, Math.ceil(sec));
    if (sec < 60) return sec + "s";
    let d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
    if (d) return d + "d" + (h ? " " + h + "h" : "");
    if (h) return h + "h" + (m ? " " + m + "m" : "");
    return m + "m" + (s ? " " + s + "s" : "");
}

function rkMoney(n) {
    let sym = RK_CFG.get("kits.currency") || ((RPG.currency.get() || {}).symbol) || "$";
    return sym + (Math.round(n * 100) / 100);
}

function rkOnlineNames() { return RPG.server.players().map((q) => q.name); }
