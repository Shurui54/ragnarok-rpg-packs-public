// =====================================================================================
//  Ranks & Kits (client) - the small toolkit the rank editor is drawn with (the same look as NPC Maker's)
// =====================================================================================
//  Vanilla look: Minecraft's own panel and button textures, the normal font. Screens are drawn
//  on the canvas every frame with a list of click boxes; text boxes and searchable dropdowns
//  are engine elements kept in slots and only re-sent when their row moves or changes.
//  Forms (label + field rows) scroll inside a clipped area.
// =====================================================================================
var RKUI = (function () {
    var PANEL = "minecraft:textures/gui/demo_background.png";
    var WIDGETS = "minecraft:textures/gui/widgets.png";
    var ICONS = "ragnarok_rpg:textures/npc/";
    var SCREEN = "rke";
    var S = null, IN_SIG = {};

    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function inside(x, y, r) { return x >= r.x && y >= r.y && x < r.x + r.w && y < r.y + r.h; }

    function send(op, data) { var m = data || {}; m.a = op; RPG.net.send("rk", m); }

    // ---- names ----
    function pretty(id) { var p = String(id || "?").split(":"), n = p[p.length - 1].replace(/_/g, " "); return n.charAt(0).toUpperCase() + n.substring(1); }
    function entityName(id) {
        var s = String(id || ""), i = s.indexOf(":"), key = "entity." + (i > 0 ? s.substring(0, i) : "minecraft") + "." + (i > 0 ? s.substring(i + 1) : s);
        try { if (RPG.hasTranslation(key)) return RPG.translate(key); } catch (e) { }
        return pretty(s);
    }
    function itemName(id) {
        var s = String(id || ""), i = s.indexOf(":"), ns = i > 0 ? s.substring(0, i) : "minecraft", p = i > 0 ? s.substring(i + 1) : s;
        try { if (RPG.hasTranslation("item." + ns + "." + p)) return RPG.translate("item." + ns + "." + p); if (RPG.hasTranslation("block." + ns + "." + p)) return RPG.translate("block." + ns + "." + p); } catch (e) { }
        return pretty(s);
    }
    function strip(s) { return String(s || "").replace(/[&§][0-9a-fk-or]/gi, ""); }

    // ---- the screen ----
    function open(state) {
        var fresh = !S || RPG.screen.getOpen() !== SCREEN, old = S;
        S = state;
        S.hits = []; S.ddN = 0; S.ddMax = old && !fresh ? old.ddMax : 0; S.ddSig = {};
        for (var d = 0; d < S.ddMax; d++) S.ddSig["dd" + d] = "";
        for (var el in IN_SIG) IN_SIG[el] = IN_SIG[el] === "hidden" ? "hidden" : "";
        S.scroll = S.scroll || {}; S.lists = []; S.msg = old ? old.msg : ""; S.msgUntil = old ? old.msgUntil : 0; S.msgColor = old ? old.msgColor : "#FFFFFF";
        if (fresh) {
            S.ddMax = 0; IN_SIG = {};
            RPG.screen.open({ id: SCREEN, referenceHeight: 320, background: "dim", pause: false, elements: [],
                onBackground: render, onRender: renderTop, onMouse: mouse, onScroll: scroll, onKey: key,
                onClose: function () { var c = S && S.onClose; S = null; IN_SIG = {}; if (c) c(); } });
        }
    }
    function close() { if (S) S.onClose = null; if (RPG.screen.getOpen() === SCREEN) RPG.screen.close(); S = null; }
    function state() { return S; }
    function status(text, color) { if (!S) return; S.msg = String(text); S.msgColor = color || "#FFFFFF"; S.msgUntil = RPG.nowMs() + 5000; }
    /** A view change: every element is re-sent on the next frame. */
    function reset() {
        if (!S) return;
        S.ddSig = {}; for (var d = 0; d < S.ddMax; d++) S.ddSig["dd" + d] = "";
        for (var el in IN_SIG) if (IN_SIG[el] !== "hidden") IN_SIG[el] = "";
    }

    function render(ctx) {
        if (!S) return;
        S.hits = []; S.lists = []; S.ddN = 0; S.tip = null; S.inUsed = {}; S.newEls = 0; S.ctx = ctx; S.clipTop = null;
        try { if (S.draw) S.draw(ctx, S); } catch (e) { RPG.log("[Ranks] screen: " + e + (e.lineNumber ? " line " + e.lineNumber : "")); }
        for (var d = S.ddN; d < S.ddMax; d++) if (S.ddSig["dd" + d] !== "hidden") { RPG.screen.update("rke_dd" + d, { visible: false }); S.ddSig["dd" + d] = "hidden"; }
        S.ddMax = Math.max(S.ddMax, S.ddN);
        for (var el in IN_SIG) if (!S.inUsed[el] && IN_SIG[el] !== "hidden") { RPG.screen.update(el, { visible: false }); IN_SIG[el] = "hidden"; }
        var left = S.msgUntil - RPG.nowMs();
        if (left > 0 && S.msg) {
            var w = tw(ctx, S.msg) + 12;
            ctx.fill(ctx.width / 2 - w / 2, ctx.height - 22, w, 14, "#000000", 0.7 * Math.min(1, left / 600));
            text(ctx, S.msg, ctx.width / 2, ctx.height - 19, S.msgColor, "center", true, Math.min(1, left / 600));
        }
    }
    function renderTop(ctx) {
        if (!S) return;
        if (S.drawTop) { try { S.drawTop(ctx, S); } catch (e) { } }
        for (var i = S.hits.length - 1; i >= 0; i--) {
            var h = S.hits[i];
            if (h.tip && inside(ctx.mouseX, ctx.mouseY, h)) { tooltip(ctx, typeof h.tip === "string" ? [h.tip] : h.tip, ctx.mouseX, ctx.mouseY); break; }
        }
    }
    function mouse(x, y, button, action) {
        if (!S) return;
        if (S.onMouse && S.onMouse(x, y, button, action) === true) return false;
        if (action !== "down") return;
        for (var i = S.hits.length - 1; i >= 0; i--) {
            var h = S.hits[i];
            if (inside(x, y, h) && (button === 0 ? h.fn : button === 1 ? h.right : null)) {
                click();
                try { (button === 0 ? h.fn : h.right)(x, y); } catch (e) { RPG.log("[Ranks] " + e); }
                return false;
            }
        }
    }
    function scroll(x, y, delta) {
        if (!S) return;
        for (var i = S.lists.length - 1; i >= 0; i--) {
            var L = S.lists[i];
            if (inside(x, y, { x: L.x, y: L.y, w: L.w + 8, h: L.h })) {
                S.scroll[L.key] = clamp((S.scroll[L.key] || 0) - (delta > 0 ? 1 : -1) * L.step, 0, Math.max(0, L.total - L.h));
                return;
            }
        }
    }
    function key(name, action) {
        if (!S || action !== "down") return;
        if (name === "key.keyboard.escape" && S.back) { S.back(); return false; }
        if (S.onKey) return S.onKey(name);
    }
    function click() { try { RPG.sound("minecraft:ui.button.click", 0.25, 1); } catch (e) { } }

    // ---- drawing ----
    function text(ctx, t, x, y, color, align, shadow, alpha) {
        ctx.textAt(String(t), x, y, 1, color || "#404040", alpha === undefined ? 1 : alpha, align || "left", shadow === undefined ? false : shadow);
    }
    function tw(ctx, t) { return ctx.textWidth(String(t)); }
    function fit(ctx, t, w) {
        t = String(t);
        if (tw(ctx, t) <= w) return t;
        while (t.length > 1 && tw(ctx, t + "...") > w) t = t.substring(0, t.length - 1);
        return t + "...";
    }
    function wrap(ctx, t, w) {
        var out = [];
        String(t || "").split("\n").forEach(function (para) {
            var line = "";
            para.split(" ").forEach(function (word) {
                var test = line ? line + " " + word : word;
                if (tw(ctx, test) > w && line) { out.push(line); line = word; } else line = test;
            });
            out.push(line);
        });
        return out;
    }
    function hit(x, y, w, h, fn, tip, right) { var r = { x: x, y: y, w: w, h: h, fn: fn, tip: tip, right: right }; S.hits.push(r); return r; }
    function over(ctx, x, y, w, h) { return inside(ctx.mouseX, ctx.mouseY, { x: x, y: y, w: w, h: h }); }
    function panel(ctx, x, y, w, h, title) {
        ctx.nineSlice(PANEL, x, y, w, h, 0, 0, 248, 166, 256, 256, 4);
        if (title) text(ctx, title, x + 8, y + 7, "#404040");
    }
    /** A dark sunken box (vanilla slot / field colours). */
    function inset(ctx, x, y, w, h, color) {
        ctx.fill(x, y, w, h, "#373737", 1);
        ctx.fill(x + 1, y + 1, w - 1, h - 1, "#FFFFFF", 1);
        ctx.fill(x + 1, y + 1, w - 2, h - 2, color || "#8B8B8B", 1);
    }
    function dark(ctx, x, y, w, h) { ctx.fill(x, y, w, h, "#A0A0A0", 1); ctx.fill(x + 1, y + 1, w - 2, h - 2, "#000000", 1); }
    /** A vanilla button. opt: {disabled, selected, tip, color, icon} */
    function button(ctx, label, x, y, w, h, fn, opt) {
        opt = opt || {};
        var dis = !!opt.disabled, hov = !dis && over(ctx, x, y, w, h);
        var v = dis ? 46 : hov || opt.selected ? 86 : 66;
        ctx.nineSlice(WIDGETS, x, y, w, h, 0, v, 200, 20, 256, 256, 3);
        var col = dis ? "#A0A0A0" : opt.color || (opt.selected ? "#FFFFA0" : hov ? "#FFFFA0" : "#FFFFFF");
        var tx = x + w / 2;
        if (opt.icon) { iconAt(ctx, opt.icon, x + 4, y + (h - 12) / 2, 12); tx += 7; }
        text(ctx, fit(ctx, label, w - (opt.icon ? 20 : 6)), tx, y + (h - 8) / 2, col, "center", true);
        if (!dis) hit(x, y, w, h, fn, opt.tip); else if (opt.tip) hit(x, y, w, h, null, opt.tip);
    }
    function iconAt(ctx, name, x, y, size, alpha) {
        var tex = name.indexOf(":") > 0 ? name : ICONS + name + ".png";
        ctx.quad(tex, x, y, size, size, 0, 0, 1, 1, "#FFFFFF", alpha === undefined ? 1 : alpha);
    }
    function toggle(ctx, on, x, y, fn, tip) {
        var w = 24, h = 12;
        ctx.fill(x, y, w, h, "#373737", 1);
        ctx.fill(x + 1, y + 1, w - 2, h - 2, on ? "#3E8E41" : "#6B2B2B", 1);
        ctx.fill(on ? x + w - 11 : x + 1, y + 1, 10, h - 2, over(ctx, x, y, w, h) ? "#FFFFFF" : "#D8D8D8", 1);
        hit(x, y, w, h, fn, tip);
    }
    function slot(ctx, stack, x, y, opt) {
        opt = opt || {};
        inset(ctx, x, y, 18, 18);
        if (opt.selected) ctx.fill(x + 1, y + 1, 16, 16, "#FFE070", 0.5);
        if (stack && stack.id) {
            ctx.item(stack.id, x + 1, y + 1, Math.max(1, stack.count | 0));
        }
        if (over(ctx, x, y, 18, 18)) ctx.fill(x + 1, y + 1, 16, 16, "#FFFFFF", 0.35);
        if (opt.fn || opt.tip || opt.right) hit(x, y, 18, 18, opt.fn, opt.tip || (stack && stack.id ? [itemName(stack.id), "&7" + stack.id] : null), opt.right);
    }
    function tooltip(ctx, lines, mx, my) {
        if (!lines || !lines.length) return;
        var w = 0;
        lines.forEach(function (l) { w = Math.max(w, tw(ctx, strip(l))); });
        var h = lines.length * 10 + 6, x = Math.min(mx + 10, ctx.width - w - 12), y = Math.min(my + 10, ctx.height - h - 4);
        ctx.fill(x, y, w + 10, h, "#100010", 0.94);
        ctx.fill(x, y, w + 10, 1, "#5000FF", 0.6); ctx.fill(x, y + h - 1, w + 10, 1, "#28007F", 0.6);
        lines.forEach(function (l, i) { text(ctx, l, x + 5, y + 4 + i * 10, i === 0 ? "#FFFFFF" : "#AAAAAA", "left", true); });
    }
    function scrollbar(ctx, x, top, h, total, pos) {
        if (total <= h) return;
        var th = Math.max(12, h * h / total), ty = top + (h - th) * pos / (total - h);
        ctx.fill(x, top, 4, h, "#000000", 0.5);
        ctx.fill(x, ty, 4, th, "#C6C6C6", 1);
        ctx.fill(x + 3, ty, 1, th, "#555555", 1);
    }
    /** A clipped scrolling area; draw(y0) draws everything with y offset and returns the content height. */
    function scrollArea(ctx, key, x, y, w, h, draw) {
        var pos = clamp(S.scroll[key] || 0, 0, Math.max(0, (S.scrollTotal && S.scrollTotal[key] || 0) - h));
        S.scroll[key] = pos;
        ctx.clip(x, y, w, h);
        var first = S.hits.length, oldTop = S.clipTop, oldBottom = S.clipBottom;
        S.clipTop = y; S.clipBottom = y + h;
        var total = 0;
        try { total = draw(y - pos) || 0; } finally { S.clipTop = oldTop; S.clipBottom = oldBottom; ctx.unclip(); }
        S.scrollTotal = S.scrollTotal || {};
        S.scrollTotal[key] = total;
        for (var k = S.hits.length - 1; k >= first; k--) { var hb = S.hits[k]; if (hb.y + hb.h <= y || hb.y >= y + h) S.hits.splice(k, 1); }
        S.lists.push({ key: key, x: x, y: y, w: w, h: h, total: total, step: 24 });
        scrollbar(ctx, x + w + 1, y, h, total, pos);
    }
    function list(ctx, key, x, y, w, h, rows, rowH, drawRow) {
        scrollArea(ctx, key, x, y, w, h, function (y0) {
            rows.forEach(function (r, i) { var ry = y0 + i * rowH; if (ry + rowH < y || ry > y + h) return; drawRow(r, i, ry); });
            return rows.length * rowH;
        });
    }
    function clipped(y, h) { return S.clipTop !== null && S.clipTop !== undefined && (y < S.clipTop || y + h > S.clipBottom); }

    // ---- engine elements ----
    /** A searchable dropdown. options: [{value, label, icon?, tooltip?}] or strings; onChange(value). */
    function dropdown(ctx, key, x, y, w, h, options, value, onChange, opt) {
        opt = opt || {};
        if (clipped(y, h)) return;
        var id = "dd" + (S.ddN++), el = "rke_" + id;
        var first = options.length ? (options[0].value !== undefined ? options[0].value : options[0]) : "";
        var last = options.length ? (options[options.length - 1].value !== undefined ? options[options.length - 1].value : options[options.length - 1]) : "";
        var sig = [key, Math.round(x), Math.round(y), w, h, String(value), !!opt.disabled, options.length, first, last].join("|");
        if (S.ddSig[id] === sig) return;
        if (S.newEls++ >= 6) return;
        S.ddSig[id] = sig;
        RPG.screen.update(el, { type: "dropdown", anchor: "topleft", x: x, y: y, w: w, h: h, visible: true, options: options, value: value,
            placeholder: opt.placeholder || "(none)", search: opt.search, searchHint: "Search...", emptyText: "Nothing matches",
            custom: !!opt.custom, customLabel: opt.customLabel || "Use: ", disabled: !!opt.disabled, listWidth: Math.max(w, opt.listWidth || 160), maxVisible: opt.maxVisible || 10,
            bg: "#000000", border: "#A0A0A0", highlight: "#404040", textColor: "#FFFFFF", listBg: "#101010", selectedBg: "#2D5A2D", selectedText: "#FFFFA0",
            onChange: function (eid, v) { if (S) { try { onChange(v); } catch (e) { RPG.log("[Ranks] " + e); } } } });
    }
    /** A text box; onChange(text) on every key. The box keeps its own text until its key changes. */
    function input(ctx, key, x, y, w, h, value, onChange, opt) {
        opt = opt || {};
        if (clipped(y, h)) return;
        var el = "rke_in_" + String(key).replace(/[^A-Za-z0-9_]/g, "_");
        S.inUsed[el] = 1;
        var sig = [Math.round(x), Math.round(y), w, h].join("|");
        if (IN_SIG[el] === sig) return;
        if ((IN_SIG[el] === undefined || IN_SIG[el] === "" || IN_SIG[el] === "hidden") && S.newEls++ >= 6) { S.inUsed[el] = 0; dark(ctx, x, y, w, h); return; }
        var reval = IN_SIG[el] === undefined || IN_SIG[el] === "" || IN_SIG[el] === "hidden";
        IN_SIG[el] = sig;
        var hint = opt.hint ? String(opt.hint) : "";
        if (hint && hint.charAt(0) !== "&") hint = "&8" + hint;               // grey, so a hint never looks like a value
        var spec = { type: "input", anchor: "topleft", x: x, y: y, w: w, h: h, visible: true, maxLength: opt.maxLength || 64, hint: hint,
            onChange: function (eid, v) { if (S) onChange(String(v)); } };
        if (reval) spec.value = value === undefined || value === null ? "" : String(value);
        RPG.screen.update(el, spec);
    }
    /** Forget one text box (its value changed from outside): it is re-sent with the new text. */
    function refreshInput(key) { var el = "rke_in_" + String(key).replace(/[^A-Za-z0-9_]/g, "_"); if (IN_SIG[el] !== undefined && IN_SIG[el] !== "hidden") IN_SIG[el] = ""; }

    // ---- paths in objects ----
    function get(o, path) {
        var parts = path.split(".");
        for (var i = 0; i < parts.length; i++) { if (o === null || o === undefined) return undefined; o = o[parts[i]]; }
        return o;
    }
    function set(o, path, v) {
        var parts = path.split("."), cur = o;
        for (var i = 0; i < parts.length - 1; i++) {
            if (cur[parts[i]] === undefined || cur[parts[i]] === null || typeof cur[parts[i]] !== "object") cur[parts[i]] = {};
            cur = cur[parts[i]];
        }
        var last = parts[parts.length - 1];
        if (v === undefined || v === null || v === "") delete cur[last]; else cur[last] = v;
        // drop emptied parents
        for (var j = parts.length - 2; j >= 0; j--) {
            var parent = get(o, parts.slice(0, j).join(".")) || o, k = parts[j];
            if (j === 0) parent = o;
            if (parent[k] && typeof parent[k] === "object" && !Array.isArray(parent[k]) && !Object.keys(parent[k]).length) delete parent[k];
            else break;
        }
    }
    function clone(o) { return o === undefined ? undefined : JSON.parse(JSON.stringify(o)); }

    // ---- forms: label + field rows, laid out top to bottom inside a scroll area ----
    /**
     * F = form(ctx, x, y0, w, labelW): F.row(h) -> y of the next row (and whether it shows); field helpers bind to
     * an object path and call onChange (mark dirty).
     */
    function form(ctx, x, y0, w, labelW, obj, onChange) {
        var F = { ctx: ctx, x: x, y: y0, w: w, lw: labelW || 110, obj: obj, changed: onChange || function () { } };
        F.fx = function () { return F.x + F.lw; };
        F.fw = function () { return F.w - F.lw; };
        F.section = function (title) { F.y += 4; text(ctx, title, F.x, F.y + 2, "#202020"); ctx.fill(F.x, F.y + 12, F.w, 1, "#555555", 1); F.y += 16; };
        F.note = function (t, color) { wrap(ctx, t, F.w).forEach(function (l) { text(ctx, l, F.x, F.y + 1, color || "#555555"); F.y += 10; }); F.y += 2; };
        F.label = function (t, tip) { text(ctx, fit(ctx, t, F.lw - 4), F.x, F.y + 4, "#303030"); if (tip) hit(F.x, F.y, F.lw - 4, 14, null, tip); };
        F.text = function (label, path, opt) {
            opt = opt || {};
            F.label(label, opt.tip);
            input(ctx, (opt.key || "f") + "_" + path, F.fx(), F.y, opt.w || F.fw(), 14, get(F.obj, path), function (v) { set(F.obj, path, opt.trim === false ? v : v); F.changed(path); }, { maxLength: opt.max || 64, hint: opt.hint });
            F.y += 18;
        };
        F.num = function (label, path, opt) {
            opt = opt || {};
            F.label(label, opt.tip);
            var cur = get(F.obj, path);
            input(ctx, (opt.key || "f") + "_" + path, F.fx(), F.y, opt.w || 60, 14, cur === undefined ? "" : (opt.percent ? Math.round(cur * 100) : cur), function (v) {
                v = v.trim();
                if (v === "") { set(F.obj, path, undefined); F.changed(path); return; }
                var n = Number(v);
                if (isNaN(n)) return;
                if (opt.percent) n = n / 100;
                if (opt.int) n = Math.round(n);
                if (opt.min !== undefined) n = Math.max(opt.min, n);
                if (opt.max !== undefined) n = Math.min(opt.max, n);
                set(F.obj, path, n); F.changed(path);
            }, { maxLength: 12, hint: opt.hint === undefined ? "" : String(opt.hint) });
            if (opt.unit) text(ctx, opt.unit, F.fx() + (opt.w || 60) + 4, F.y + 4, "#505050");
            F.y += 18;
        };
        F.bool = function (label, path, opt) {
            opt = opt || {};
            F.label(label, opt.tip);
            var v = get(F.obj, path);
            var on = v === undefined ? !!opt.def : !!v;
            toggle(ctx, on, F.fx(), F.y + 1, function () { set(F.obj, path, !on); F.changed(path); }, opt.tip);
            if (opt.hint) text(ctx, opt.hint, F.fx() + 30, F.y + 3, "#505050");
            F.y += 16;
        };
        F.choice = function (label, path, options, opt) {
            opt = opt || {};
            F.label(label, opt.tip);
            var v = get(F.obj, path);
            dropdown(ctx, (opt.key || "f") + "_" + path, F.fx(), F.y, opt.w || F.fw(), 14, options, v === undefined ? (opt.def === undefined ? "" : opt.def) : v, function (nv) {
                set(F.obj, path, nv === "" && !opt.keepEmpty ? undefined : nv); F.changed(path);
            }, { search: opt.search, custom: opt.custom, placeholder: opt.placeholder, listWidth: opt.listWidth });
            F.y += 18;
        };
        F.buttons = function (defs) {
            var x = F.x, bw = Math.floor((F.w - (defs.length - 1) * 4) / defs.length);
            defs.forEach(function (d) { button(ctx, d[0], x, F.y, d.w || bw, 16, d[1], d[2] || {}); x += (d.w || bw) + 4; });
            F.y += 20;
        };
        return F;
    }

    return {
        PANEL: PANEL, WIDGETS: WIDGETS, clamp: clamp, inside: inside, send: send,
        pretty: pretty, entityName: entityName, itemName: itemName, strip: strip,
        open: open, close: close, state: state, status: status, reset: reset,
        text: text, tw: tw, fit: fit, wrap: wrap, hit: hit, over: over, panel: panel, inset: inset, dark: dark, button: button, iconAt: iconAt,
        toggle: toggle, slot: slot, tooltip: tooltip, scrollArea: scrollArea, list: list, dropdown: dropdown, input: input, refreshInput: refreshInput,
        get: get, set: set, clone: clone, form: form
    };
})();
