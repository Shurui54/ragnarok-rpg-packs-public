// =====================================================================================
//  Ranks & Kits (client) - the rank editor (/rank)
// =====================================================================================
//  Ranks on the left (heaviest first: the heaviest rank a player has is the one shown),
//  the selected rank on the right in four tabs: Look (name, badge, prefix, suffix,
//  colours, weight, inheritance, live preview), Permissions (every known node with a
//  switch, plus any node typed in), Members (online search or any name) and Kits.
//  Every change is saved at once (a moment after you stop typing) and applies live:
//  chat, the tab list and name tags change without a reload. The server checks
//  permissions (ranks.manage to edit, ranks.assign to give ranks).
// =====================================================================================
var RK_EDITOR = (function () {
    var U = RKUI;
    var HEX = { "0": "#000000", "1": "#0000AA", "2": "#00AA00", "3": "#00AAAA", "4": "#AA0000", "5": "#AA00AA", "6": "#FFAA00", "7": "#AAAAAA",
        "8": "#555555", "9": "#5555FF", "a": "#55FF55", "b": "#55FFFF", "c": "#FF5555", "d": "#FF55FF", "e": "#FFFF55", "f": "#FFFFFF" };

    var NAMES = { "0": "Black", "1": "Dark blue", "2": "Dark green", "3": "Dark aqua", "4": "Dark red", "5": "Purple", "6": "Gold", "7": "Grey",
        "8": "Dark grey", "9": "Blue", "a": "Green", "b": "Aqua", "c": "Red", "d": "Pink", "e": "Yellow", "f": "White" };
    var TABS = [["look", "Look"], ["perms", "Permissions"], ["members", "Members"], ["kits", "Kits"]];

    var E = {
        list: null, st: null, sel: null, draft: null, parent: "", tab: "look",
        filter: "", nodeFilter: "", nodeAdd: "", who: "", days: "",
        seq: 0, sentSeq: 0, saveAt: 0, confirmDel: false, creating: null, renaming: null, badges: null
    };

    // ---- helpers ------------------------------------------------------------------------------------
    function strip(s) { return String(s || "").replace(/&\{icon:[^}]*\}/g, "").replace(/&[0-9a-fk-or]/gi, ""); }
    function badgeTok(id, h) { return id ? "&{icon:" + id + (h > 0 ? "," + h : "") + "} " : ""; }
    function pretty(id) {
        var n = String(id || "").split("/").pop().replace(/_plus$/, "+").replace(/_/g, " ");
        return n.charAt(0).toUpperCase() + n.substring(1);
    }
    function can() { return (E.st && E.st.can) || (E.list && E.list.can) || {}; }
    function tabHeight() { try { return RPG.tablist.isCustom() ? 12 : 0; } catch (e) { return 0; } }

    /** Every badge picture the loaded packs have (textures/badges/**), as "ns:path" ids. */
    function badges() {
        if (E.badges) return E.badges;
        var l = RPG.resourceList("textures/badges", ".png");
        if (!l) return null;
        E.badges = l.map(function (f) { return String(f).replace(/:textures\//, ":").replace(/\.png$/, ""); });
        return E.badges;
    }
    function badgeOptions() {
        var o = [{ value: "", label: "(no badge)" }], l = badges() || [];
        var groups = {};
        l.forEach(function (id) {
            var dir = id.substring(0, id.lastIndexOf("/") + 1);
            o.push({ value: id, label: badgeTok(id, 0) + pretty(id), tooltip: [pretty(id), "&7" + id] });
            groups[dir] = 1;
        });
        if (E.draft && E.draft.badge && l.indexOf(E.draft.badge) < 0) o.push({ value: E.draft.badge, label: badgeTok(E.draft.badge, 0) + E.draft.badge });
        return o;
    }

    // ---- server ---------------------------------------------------------------------------------------
    function send(a, d) { U.send(a, d); }
    function select(id) {
        if (E.sel === id && E.st) return;
        flush();
        E.sel = id; E.st = null; E.draft = null; E.confirmDel = false; E.renaming = null;
        if (id) send("get", { id: id });
        U.reset();
    }
    function changed() { E.seq++; E.saveAt = RPG.nowMs() + 600; }
    function flush() {
        if (!E.draft || E.seq === E.sentSeq || !E.sel) return;
        E.sentSeq = E.seq;
        var d = E.draft;
        send("save", { id: E.sel, quiet: true, parent: E.parent, rank: {
            name: d.name, prefix: d.prefix, suffix: d.suffix, nameColor: d.nameColor, chatColor: d.chatColor, weight: d.weight,
            tab: d.tab === undefined ? null : d.tab, isDefault: !!d.isDefault, kits: d.kits || [], kitMult: d.kitMult, badge: d.badge || "" } });
        U.status("Saved", "#80FF80");
    }
    RPG.every(4, function () { if (E.draft && E.seq !== E.sentSeq && RPG.nowMs() >= E.saveAt) flush(); });

    function openEditor() {
        var S = U.state();
        if (S && S.rkEditor) return;
        U.open({ rkEditor: true, draw: draw, back: back, onKey: key, onClose: function () { flush(); } });
        U.reset();
    }
    function back() {
        if (E.creating !== null || E.renaming !== null) { E.creating = null; E.renaming = null; U.reset(); return; }
        flush();
        U.close();
    }
    function key(name) {
        if (name === "key.keyboard.enter" || name === "key.keyboard.keypad.enter") {
            if (E.creating !== null) { create(); return false; }
            if (E.renaming !== null) { rename(); return false; }
            if (E.tab === "perms" && E.nodeAdd) { addNode(true); return false; }
            if (E.tab === "members" && E.who) { addMember(); return false; }
            flush();
            return false;
        }
    }
    function create() {
        var id = String(E.creating || "").trim().toLowerCase();
        if (!id) return;
        send("create", { id: id, name: id.charAt(0).toUpperCase() + id.substring(1) });
        E.creating = null; U.reset();
    }
    function rename() {
        var to = String(E.renaming || "").trim().toLowerCase();
        if (!to || !E.sel) return;
        flush();
        send("rename", { id: E.sel, to: to });
        E.renaming = null; U.reset();
    }
    function addNode(allow) {
        var n = String(E.nodeAdd || "").trim().toLowerCase();
        if (!n || !E.sel) return;
        send("node", { id: E.sel, node: n, value: allow });
        E.nodeAdd = ""; U.refreshInput("node_add");
    }
    function addMember() {
        var who = String(E.who || "").trim();
        if (!who || !E.sel) return;
        send("assign", { id: E.sel, player: who, days: E.days || 0 });
        E.who = ""; U.reset();
    }

    RPG.net.on("rk_list", function (m) {
        if (!m || !m.state) return;
        E.list = m.state;
        if (m.note) U.status(m.note, /deleted|created/i.test(m.note) ? "#80FF80" : "#FF8080");
        var ids = E.list.ranks.map(function (r) { return r.id; });
        if (m.open) openEditor();
        if (!E.sel || ids.indexOf(E.sel) < 0) { E.sel = null; select(ids[0] || null); }
    });
    RPG.net.on("rk_rank", function (m) {
        if (!m || !m.state) return;
        var st = m.state, id = st.rank.id;
        if (m.open) openEditor();
        if (E.sel !== id) { E.sel = id; E.draft = null; U.reset(); }
        E.st = st;
        // keep what is being typed: only take the server's copy when nothing newer is waiting
        if (!E.draft || E.seq === E.sentSeq) {
            var had = !!E.draft;
            E.draft = U.clone(st.rank); E.parent = st.parent || "";
            if (!had) U.reset();
        }
        if (m.note) U.status(m.note, /saved|created|now|lost|changed/i.test(m.note) ? "#80FF80" : "#FFFFFF");
        send("list", {});
    });
    RPG.net.on("rk_note", function (m) { if (m && m.text && U.state() && U.state().rkEditor) U.status(m.text, m.bad ? "#FF7070" : "#80FF80"); });

    // ---- drawing --------------------------------------------------------------------------------------
    function draw(ctx, S) {
        var W = Math.min(ctx.width - 16, 600), H = Math.min(ctx.height - 16, 300);
        var x = Math.round((ctx.width - W) / 2), y = Math.round((ctx.height - H) / 2);
        var LW = 168;
        drawList(ctx, x, y, LW, H);
        drawRank(ctx, x + LW + 4, y, W - LW - 4, H);
    }

    function drawList(ctx, x, y, w, h) {
        U.panel(ctx, x, y, w, h, "Ranks");
        U.text(ctx, "heaviest first", x + w - 8, y + 7, "#707070", "right");
        var ranks = (E.list && E.list.ranks) || [];
        U.input(ctx, "rank_filter", x + 8, y + 20, w - 16, 14, E.filter, function (v) { E.filter = v.toLowerCase(); }, { hint: "Search ranks...", maxLength: 32 });
        var rows = ranks.filter(function (r) { return !E.filter || (r.id + " " + strip(r.name)).toLowerCase().indexOf(E.filter) >= 0; });
        var top = y + 38, bottom = y + h - (can().manage ? 62 : 10);
        U.dark(ctx, x + 8, top, w - 16, bottom - top);
        U.list(ctx, "ranks", x + 9, top + 1, w - 22, bottom - top - 2, rows, 20, function (r, i, ry) {
            var rx = x + 9, rw = w - 22, sel = r.id === E.sel;
            if (sel) ctx.fill(rx, ry, rw, 20, "#FFFFFF", 0.16); else if (U.over(ctx, rx, ry, rw, 20)) ctx.fill(rx, ry, rw, 20, "#FFFFFF", 0.07);
            var label = badgeTok(r.badge, 0) + (r.nameColor || "&f") + strip(r.name);
            ctx.textAt(label, rx + 4, ry + 6, 1, "#FFFFFF", 1, "left", true);
            U.text(ctx, (r.isDefault ? "default " : "") + r.weight, rx + rw - 4, ry + 6, "#808080", "right", true);
            U.hit(rx, ry, rw, 20, function () { select(r.id); }, [strip(r.name) + "  &8" + r.id, "&7Weight " + r.weight + ", " + r.members + " member" + (r.members === 1 ? "" : "s")]);
        });
        if (!rows.length) U.text(ctx, E.list ? "No ranks" : "Loading...", x + w / 2, top + 20, "#A0A0A0", "center", true);
        if (!can().manage) return;
        var by = bottom + 4, bw = Math.floor((w - 20) / 2);
        var idx = ranks.map(function (r) { return r.id; }).indexOf(E.sel);
        U.button(ctx, "Up", x + 8, by, bw, 16, function () { flush(); send("move", { id: E.sel, dir: -1 }); }, { disabled: idx <= 0, tip: "Heavier: shown over the ranks below it" });
        U.button(ctx, "Down", x + 12 + bw, by, bw, 16, function () { flush(); send("move", { id: E.sel, dir: 1 }); }, { disabled: idx < 0 || idx >= ranks.length - 1 });
        if (E.creating !== null) {
            U.input(ctx, "new_id", x + 8, by + 20, w - 66, 16, E.creating, function (v) { E.creating = v; }, { hint: "new rank id", maxLength: 24 });
            U.button(ctx, "Create", x + w - 56, by + 20, 48, 16, create);
        } else {
            U.button(ctx, "New rank", x + 8, by + 20, bw, 16, function () { E.creating = ""; U.reset(); });
            U.button(ctx, E.confirmDel ? "Sure?" : "Delete", x + 12 + bw, by + 20, bw, 16, function () {
                if (!E.confirmDel) { E.confirmDel = true; return; }
                E.confirmDel = false; send("delete", { id: E.sel }); E.sel = null; E.st = null; E.draft = null; U.reset();
            }, { disabled: !E.sel, color: E.confirmDel ? "#FF8080" : null, tip: E.confirmDel ? "Click again to delete it (members lose it)" : "Delete this rank" });
        }
    }

    function drawRank(ctx, x, y, w, h) {
        var d = E.draft, st = E.st;
        U.panel(ctx, x, y, w, h, d ? "Rank: " + strip(d.name) : "Rank");
        if (!d || !st) { U.text(ctx, E.sel ? "Loading..." : "Pick a rank on the left", x + w / 2, y + h / 2, "#606060", "center"); return; }
        // id + change id
        if (E.renaming !== null) {
            U.input(ctx, "rename_" + E.sel, x + w - 180, y + 4, 120, 13, E.renaming, function (v) { E.renaming = v; }, { hint: "new id", maxLength: 24 });
            U.button(ctx, "OK", x + w - 56, y + 4, 48, 13, rename);
        } else {
            U.text(ctx, "id: " + d.id, x + w - (can().manage ? 70 : 8), y + 7, "#707070", "right");
            if (can().manage) U.button(ctx, "Change id", x + w - 66, y + 4, 58, 13, function () { E.renaming = d.id; U.reset(); }, { disabled: d.id === "default", tip: d.id === "default" ? "Everyone is in the default group: change its display name instead" : "Give the rank a new id (members, nodes and kits move with it)" });
        }
        var tx = x + 8;
        TABS.forEach(function (t) {
            var tw = U.tw(ctx, t[1]) + 14;
            U.button(ctx, t[1], tx, y + 20, tw, 16, function () { if (E.tab !== t[0]) { flush(); E.tab = t[0]; U.reset(); } }, { selected: E.tab === t[0] });
            tx += tw + 2;
        });
        var cy = y + 40, ch = h - 48;
        if (E.tab === "look") drawLook(ctx, x + 8, cy, w - 16, ch);
        else if (E.tab === "perms") drawPerms(ctx, x + 8, cy, w - 16, ch);
        else if (E.tab === "members") drawMembers(ctx, x + 8, cy, w - 16, ch);
        else drawKits(ctx, x + 8, cy, w - 16, ch);
    }

    // ---- Look -------------------------------------------------------------------------------------------
    /**
     * A colour field: swatch + name; a click opens the engine's colour picker under it (live preview while picking).
     * format "code": the 16 chat colours only, kept as "&c" (the name colour is a scoreboard team colour, which has
     * nothing else); "chat": any colour, "&c" for a chat colour or "&#RRGGBB" (& text draws both).
     */
    function colorField(ctx, x, y, w, h, value, format, fn, disabled, tip) {
        var m = /^&([0-9a-f])/i.exec(value || ""), hx = /^&#([0-9a-f]{6})/i.exec(value || "");
        var hex = m ? HEX[m[1].toLowerCase()] : hx ? "#" + hx[1].toUpperCase() : "#FFFFFF";
        var name = m ? NAMES[m[1].toLowerCase()] + "  &8&&" + m[1].toLowerCase() : hx ? hex : "White";
        var hov = !disabled && U.over(ctx, x, y, w, h);
        ctx.fill(x, y, h, h, hov ? "#FFFFFF" : "#A0A0A0", 1);
        ctx.fill(x + 1, y + 1, h - 2, h - 2, hex, 1);
        U.dark(ctx, x + h + 3, y, w - h - 3, h);
        U.text(ctx, U.fit(ctx, name, w - h - 10), x + h + 6, y + (h - 8) / 2, disabled ? "#808080" : "#FFFFFF", "left", false);
        if (!disabled) U.hit(x, y, w, h, function () {
            RPG.screen.pickColor({ x: x, y: y, w: w, h: h, value: value || "&f", format: format }, function (v) { fn(String(v)); });
        }, tip || "Click to pick a colour");
    }
    function drawLook(ctx, x, y, w, h) {
        var d = E.draft, st = E.st, ro = !can().manage, key = E.sel + "_";
        var fw = Math.min(w, 250), px = x + fw + 8, pw = w - fw - 8;
        U.scrollArea(ctx, "look_" + E.sel, x, y, fw - 6, h, function (y0) {
            var F = U.form(ctx, x, y0, fw - 10, 72, d, function () { changed(); });
            if (ro) F.note("You can give this rank to players (Members), but not change it.", "#8B0000");
            // text rows keep "" (an emptied prefix must reach the server as empty, not as "unchanged")
            var txt = function (label, path, max, hint) {
                F.label(label);
                U.input(ctx, key + "t_" + path, F.fx(), F.y, F.fw(), 14, d[path], function (v) { d[path] = v; changed(); }, { maxLength: max, hint: hint });
                F.y += 18;
            };
            txt("Display name", "name", 32, "shown in the tab list, /rank");
            F.label("Badge", ["A picture before the name in chat, the tab list and over heads.", "&7Any PNG in a pack's textures/badges/ folder;", "&7type ns:path for one elsewhere."]);
            var opts = badgeOptions();
            U.dropdown(ctx, key + "badge", F.fx(), F.y, F.fw(), 14, opts, d.badge || "", function (v) { d.badge = v; changed(); },
                { search: true, custom: true, customLabel: "Use picture", placeholder: badges() ? "(no badge)" : "Looking for badges...", listWidth: 200, maxVisible: 12 });
            F.y += 18;
            txt("Prefix", "prefix", 48, "&c[Admin] (& colours)");
            txt("Suffix", "suffix", 48, "after the name");
            F.label("Name colour", ["The name's colour in chat, the tab list and over heads.", "&7One of the 16 chat colours (it is also the", "&7scoreboard team colour, which has no others)."]);
            colorField(ctx, F.fx(), F.y, Math.min(F.fw(), 140), 14, d.nameColor, "code", function (c) { d.nameColor = c; changed(); }, ro);
            F.y += 18;
            F.label("Chat colour", ["The colour of this rank's chat messages:", "&7any colour."]);
            colorField(ctx, F.fx(), F.y, Math.min(F.fw(), 140), 14, d.chatColor, "chat", function (c) { d.chatColor = c; changed(); }, ro);
            F.y += 18;
            F.num("Weight", "weight", { key: key, int: true, min: -9999, max: 9999, tip: ["The heaviest rank a player has is shown.", "&7Up / Down on the left trade weights."] });
            F.num("Tab order", "tab", { key: key, int: true, min: 0, max: 9999, hint: "= weight", tip: ["Where the rank sorts in the tab list", "&7(higher first). Empty: by weight."] });
            F.label("Inherits", ["Gets every permission node of this rank too."]);
            var po = [{ value: "", label: "(nothing)" }];
            (st.ranks || []).forEach(function (r) { if (r.id !== d.id) po.push({ value: r.id, label: strip(r.name) + "  &8" + r.id }); });
            U.dropdown(ctx, key + "parent", F.fx(), F.y, F.fw(), 14, po, E.parent, function (v) { E.parent = v; changed(); }, { search: true, disabled: ro });
            F.y += 18;
            if ((st.fixedParents || []).length) F.note("Also from addon scripts: " + st.fixedParents.join(", "), "#505050");
            F.bool("Default rank", "isDefault", { tip: "Everyone without another rank has it" });
            F.num("Kit wait x", "kitMult", { key: key, min: 0, max: 100, tip: ["Kit cooldowns are multiplied by this", "&7(0.5 = half the wait, 0 = none)."] });
            return F.y - y0 + 4;
        });
        drawPreview(ctx, px, y, pw, h);
    }

    function drawPreview(ctx, x, y, w, h) {
        if (w < 80) return;
        var d = E.draft, st = E.st;
        U.text(ctx, "Preview", x, y + 2, "#303030");
        var by = y + 14;
        U.dark(ctx, x, by, w, h - 14);
        var me = RPG.player && RPG.player.name ? RPG.player.name : "Player";
        ctx.clip(x + 1, by + 1, w - 2, h - 16);
        try { previewBody(ctx, x, by, w, h, d, st, me); } finally { ctx.unclip(); }
    }
    function previewBody(ctx, x, by, w, h, d, st, me) {
        var cx = x + 6, yy = by + 6;
        // chat
        U.text(ctx, "Chat", cx, yy, "#A0A0A0", "left", true); yy += 12;
        var b = st.badges || { tab: true, chat: true, chatHeight: 0 };
        var fmt = String(st.format || "{badge}{prefix}{color}{name}{suffix}&8 » {chatcolor}{message}");
        if (fmt.indexOf("{badge}") < 0) fmt = "{badge}" + fmt;
        var line = fmt.replace(/\{badge\}/g, b.chat ? badgeTok(d.badge, b.chatHeight) : "").replace(/\{prefix\}/g, d.prefix || "").replace(/\{suffix\}/g, d.suffix || "")
            .replace(/\{color\}/g, d.nameColor).replace(/\{rank\}/g, d.name).replace(/\{chatcolor\}/g, d.chatColor).replace(/\{name\}/g, me)
            .split("{message}").join("Hello there!");
        ctx.fill(cx - 2, yy - 1, w - 8, 10, "#000000", 0.5);
        ctx.rich(line, cx, yy, "#FFFFFF", true, 0);
        yy += 18;
        // tab list row
        U.text(ctx, "Tab list", cx, yy, "#A0A0A0", "left", true); yy += 12;
        var th = tabHeight(), rowH = th > 0 ? 14 : 9;
        var name = (b.tab ? badgeTok(d.badge, 0) : "") + (d.prefix || "") + d.nameColor + me + (d.suffix || "");
        ctx.fill(cx - 2, yy - 1, w - 8, rowH, "#FFFFFF", 0.13);
        var ty = yy + (th > 0 ? 3 : 0) - 1;
        ctx.face(me, cx, ty, 8);
        ctx.rich(name, cx + 9, ty, "#FFFFFF", true, th);
        ctx.ping(40, cx + w - 20, ty);
        yy += rowH + 10;
        // name tag
        U.text(ctx, "Over heads", cx, yy, "#A0A0A0", "left", true); yy += 14;
        var nw = ctx.richWidth(name, th), nx = x + w / 2 - nw / 2;
        ctx.fill(nx - 1, yy - 1, nw + 2, 10, "#000000", 0.25);
        ctx.rich(name, nx, yy, "#FFFFFF", false, th);
        yy += 18;
        if (yy < by + h - 30) {
            U.wrap(ctx, "Saved as you type; chat, the tab list and name tags change at once.", w - 12).forEach(function (l) {
                U.text(ctx, l, cx, yy, "#808080", "left", true); yy += 10;
            });
        }
    }

    // ---- Permissions ------------------------------------------------------------------------------------
    function drawPerms(ctx, x, y, w, h) {
        var st = E.st, ro = !can().manage, saved = st.saved || {}, script = st.script || {};
        U.input(ctx, "node_filter_" + E.sel, x, y, 140, 14, E.nodeFilter, function (v) { E.nodeFilter = v.toLowerCase(); }, { hint: "Search nodes...", maxLength: 64 });
        if (!ro) {
            U.input(ctx, "node_add", x + 146, y, w - 146 - 108, 14, E.nodeAdd, function (v) { E.nodeAdd = v; }, { hint: "any.node.here or plugin.*", maxLength: 96 });
            U.button(ctx, "Allow", x + w - 104, y, 50, 14, function () { addNode(true); }, { disabled: !E.nodeAdd });
            U.button(ctx, "Deny", x + w - 52, y, 52, 14, function () { addNode(false); }, { disabled: !E.nodeAdd });
        }
        var all = {};
        (st.known || []).forEach(function (n) { all[n] = 1; });
        Object.keys(saved).forEach(function (n) { all[n] = 1; });
        Object.keys(script).forEach(function (n) { all[n] = 1; });
        var rows = Object.keys(all).filter(function (n) { return !E.nodeFilter || n.indexOf(E.nodeFilter) >= 0; });
        rows.sort(function (a, b) {
            var sa = saved[a] !== undefined || script[a] !== undefined ? 0 : 1, sb = saved[b] !== undefined || script[b] !== undefined ? 0 : 1;
            return sa - sb || (a < b ? -1 : a > b ? 1 : 0);
        });
        var top = y + 18;
        U.text(ctx, rows.length + " node" + (rows.length === 1 ? "" : "s") + "  (set ones first; click to cycle allow / deny / not set)", x, top, "#505050");
        top += 12;
        U.dark(ctx, x, top, w, h - (top - y));
        U.list(ctx, "nodes_" + E.sel, x + 1, top + 1, w - 8, h - (top - y) - 2, rows, 16, function (n, i, ry) {
            var rx = x + 1, rw = w - 8;
            if (U.over(ctx, rx, ry, rw, 16)) ctx.fill(rx, ry, rw, 16, "#FFFFFF", 0.07);
            var sv = saved[n], sc = script[n];
            var col = sv === true ? "#80FF80" : sv === false ? "#FF8080" : sc !== undefined ? "#C0C0C0" : "#909090";
            U.text(ctx, U.fit(ctx, n, rw - 130), rx + 4, ry + 4, col, "left", true);
            if (sc !== undefined) U.text(ctx, "addon: " + (sc ? "allow" : "deny"), rx + rw - 96, ry + 4, "#707070", "right", true);
            var label = sv === true ? "Allow" : sv === false ? "Deny" : "-";
            U.button(ctx, label, rx + rw - 88, ry + 1, 84, 14, function () {
                var next = sv === true ? false : sv === false ? null : true;
                saved[n] = next === null ? undefined : next;
                if (next === null) delete saved[n];
                send("node", { id: E.sel, node: n, value: next });
            }, { disabled: ro, color: sv === true ? "#80FF80" : sv === false ? "#FF8080" : "#C0C0C0", tip: sv === undefined ? "Not set here (inherited or default)" : null });
        });
    }

    // ---- Members ----------------------------------------------------------------------------------------
    function drawMembers(ctx, x, y, w, h) {
        var st = E.st, members = st.members || [];
        if (can().assign) {
            var opts = (st.online || []).map(function (n) { return { value: n, label: n + "  &a(online)" }; });
            U.text(ctx, "Give to", x, y + 3, "#303030");
            U.dropdown(ctx, "who_" + E.sel, x + 44, y, 150, 14, opts, E.who, function (v) { E.who = String(v || ""); },
                { search: true, custom: true, customLabel: "Offline player", placeholder: "online or any name...", listWidth: 180 });
            U.text(ctx, "days", x + 200, y + 3, "#303030");
            U.input(ctx, "days_" + E.sel, x + 226, y, 40, 14, E.days, function (v) { E.days = v.trim(); }, { hint: "ever", maxLength: 6 });
            U.button(ctx, "Give rank", x + 272, y, 70, 14, addMember, { disabled: !E.who, tip: "Empty days = forever. Days on a timed rank add up." });
        }
        var top = y + 20;
        U.text(ctx, members.length + " member" + (members.length === 1 ? "" : "s"), x, top, "#505050");
        top += 12;
        U.dark(ctx, x, top, w, h - (top - y));
        var now = Date.now();
        U.list(ctx, "members_" + E.sel, x + 1, top + 1, w - 8, h - (top - y) - 2, members, 16, function (m, i, ry) {
            var rx = x + 1, rw = w - 8;
            if (U.over(ctx, rx, ry, rw, 16)) ctx.fill(rx, ry, rw, 16, "#FFFFFF", 0.07);
            ctx.fill(rx + 4, ry + 5, 5, 5, m.online ? "#55FF55" : m.pending ? "#FFAA00" : "#555555", 1);
            U.text(ctx, m.name, rx + 14, ry + 4, "#FFFFFF", "left", true);
            var left = m.exp ? Math.max(0, (m.exp - now) / 1000) : 0;
            var info = m.pending ? "gets it on first join" : m.exp ? dur(left) + " left" : "forever";
            U.text(ctx, info, rx + rw - 70, ry + 4, "#A0A0A0", "right", true);
            if (can().assign) U.button(ctx, "Remove", rx + rw - 64, ry + 1, 60, 14, function () { send("unassign", { id: E.sel, player: m.name }); });
        });
        if (!members.length) U.text(ctx, "Nobody has this rank" + (E.st.rank.isDefault ? " (it is the default: everyone without one has it)" : "") + ".", x + w / 2, top + 20, "#A0A0A0", "center", true);
    }
    function dur(sec) {
        sec = Math.max(0, Math.ceil(sec));
        if (sec < 60) return sec + "s";
        var d = Math.floor(sec / 86400), hh = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60);
        if (d) return d + "d" + (hh ? " " + hh + "h" : "");
        if (hh) return hh + "h" + (m ? " " + m + "m" : "");
        return m + "m";
    }

    // ---- Kits -------------------------------------------------------------------------------------------
    function drawKits(ctx, x, y, w, h) {
        var st = E.st, d = E.draft, kits = st.kits || [], ro = !can().manage;
        d.kits = d.kits || [];
        U.text(ctx, "Members of this rank may claim the kits switched on (as well as kits anyone may take).", x, y + 2, "#505050");
        var top = y + 14;
        U.dark(ctx, x, top, w, h - 14);
        U.list(ctx, "kits_" + E.sel, x + 1, top + 1, w - 8, h - 16, kits, 20, function (k, i, ry) {
            var rx = x + 1, rw = w - 8, on = d.kits.indexOf(k.id) >= 0;
            if (k.icon) ctx.item(k.icon, rx + 3, ry + 2);
            U.text(ctx, strip(k.name) + "  &8" + k.id, rx + 24, ry + 6, "#FFFFFF", "left", true);
            U.toggle(ctx, on, rx + rw - 30, ry + 4, function () {
                if (ro) return;
                if (on) d.kits.splice(d.kits.indexOf(k.id), 1); else d.kits.push(k.id);
                changed();
            });
        });
        if (!kits.length) U.text(ctx, "No kits yet: make some with /kitadmin.", x + w / 2, top + 20, "#A0A0A0", "center", true);
    }

    return { open: function () { send("list", { open: true }); }, state: function () { return E; } };
})();
