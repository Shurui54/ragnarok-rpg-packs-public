// =====================================================================================
//  51_dmz_ki_render.js - the original's ki attacks drawn with the original's own ki shader
// =====================================================================================
//  Ported from the original (GPL-3.0, see NOTICE.md): KiProjectileRenderer (balls: blast, giant ball, Supernova, Death Ball,
//  Soul Punisher, Fake Moon, barrage emitter, small blast), KiWaveRenderer (charging orb, beam, muzzle and head,
//  Final Flash's double orb), KiLaserRenderer (lasers, Special Beam Cannon with its spiral), KiDiskRenderer,
//  KiEmberRenderer (the fire-ash flakes), KiExplosionVisualRenderer and KiMeshFactory / KiSpiralMesh (meshes).
//  The GLSL is the original's kiattack shader (resources/assets/dbr/shaders/core/kiattack*), drawn by RPG.shaders.
//
//  The server (scripts/41_dmz_techniques.js) puts each shot's original look in its tag: k (ball, small, volley, wave,
//  beam, laser, disk), rt (original render type), sz (size), cs (wave cast size), ct (charge growth ticks). Every client
//  draws every shot it sees from that (and from the synced size, length, held flag and age), so everyone sees the
//  same orbs in the same hands. While drawn here, the engine's own look of the shot is hidden on this computer.
// =====================================================================================
var DMZ_KI_RENDER = (function () {
    var SH = "dbr:kiattack", SH_SPLAT = "dbr:kiattack_splat";
    var MESH = { sphere: "dbr:ki_sphere", tube: "dbr:ki_tube", quad: "dbr:ki_quad", spiral: "dbr:ki_spiral", tri: "dbr:ki_tri", torus: "dbr:ki_torus" };
    var SPIRAL_LEN = 10;                                        // 0.9 twists a block: 9 whole coils per segment
    var MUZZLE_FLAME_SCALE = 1.55, DOUBLE_WAVE_BALL_SCALE = 0.82, GIANT_FLAME_GAIN = 1.65, GIANT_EMBER_SCALE = 1.9;
    var CHARGE_BACKDRAFT = 0.35, COOLER_FLAME_GAIN = 1.2, KEEP = 40, REFRESH = 20;
    var EMBER_COUNT = 10, EMBER_PERIOD = 11, EMBER_IGNITE = 0.12, EMBER_FADE_FROM = 0.74, EMBER_R_START = 0.88, EMBER_R_END = 4.2;
    var EMBER_SIZE_BIRTH = 0.46, EMBER_SIZE_DEATH = 0.10, EMBER_COOL = 0.7, EMBER_BACKDRAFT = 1.85;
    var OWN = { dmz_ki_ball: 1, dmz_ki_giant: 1, dmz_ki_wave: 1, dmz_ki_beam: 1, dmz_ki_laser: 1, dmz_ki_disk: 1,
        dmz_ki_ring: 1, dmz_ki_neo: 1, dmz_ki_tri: 1, dmz_tech_ball: 1, dmz_tech_wave: 1, dmz_tech_beam: 1, dmz_tech_laser: 1, dmz_tech_disk: 1, dmz_tech_bullet: 1 };

    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function rgb(h) { h = String(h || "#FFFFFF").replace("#", ""); var n = parseInt(h, 16); if (isNaN(n)) n = 0xFFFFFF; return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; }

    // ---- meshes (KiMeshFactory, KiSpiralMesh) --------------------------------------------------
    function sphereMesh() {
        var v = [], segs = 32, rings = 16;
        function pt(t, ph) { var x = Math.sin(t) * Math.cos(ph), y = Math.cos(t), z = Math.sin(t) * Math.sin(ph); v.push(x, y, z, 1, 1, 1, 1, x, y, z); }
        for (var i = 0; i < rings; i++) {
            var t1 = Math.PI * i / rings, t2 = Math.PI * (i + 1) / rings;
            for (var j = 0; j < segs; j++) {
                var p1 = 2 * Math.PI * j / segs, p2 = 2 * Math.PI * (j + 1) / segs;
                pt(t1, p1); pt(t1, p2); pt(t2, p2); pt(t2, p1);
            }
        }
        RPG.shaders.mesh(MESH.sphere, { format: "position_color_normal", mode: "quads", vertices: v });
    }
    // KiMeshFactory.buildTubeMesh: segs sides from angle off (32 = the cylinder; 3 from 90 degrees = the Tri-Beam's prism)
    function tubeMesh(id, segs, off) {
        var v = [];
        segs = segs || 32; off = off || 0;
        function q(x, y, z, nx, ny, nz) { v.push(x, y, z, 1, 1, 1, 1, nx, ny, nz); }
        for (var i = 0; i < segs; i++) {
            var a1 = off + 2 * Math.PI * i / segs, a2 = off + 2 * Math.PI * (i + 1) / segs;
            var x1 = Math.cos(a1), y1 = Math.sin(a1), x2 = Math.cos(a2), y2 = Math.sin(a2);
            q(x1, y1, 0, x1, y1, 0); q(x2, y2, 0, x2, y2, 0); q(x2, y2, 1, x2, y2, 0); q(x1, y1, 1, x1, y1, 0);
            q(0, 0, 0, 0, 0, -1); q(x1, y1, 0, 0, 0, -1); q(x2, y2, 0, 0, 0, -1); q(0, 0, 0, 0, 0, -1);
            q(0, 0, 1, 0, 0, 1); q(x2, y2, 1, 0, 0, 1); q(x1, y1, 1, 0, 0, 1); q(0, 0, 1, 0, 0, 1);
        }
        RPG.shaders.mesh(id || MESH.tube, { format: "position_color_normal", mode: "quads", vertices: v });
    }
    // KiMeshFactory.buildTorusMesh(64, 16, major): tube radius 1 round a ring of radius major, in the XY plane
    function torusMesh() {
        var v = [], major = 1 / 0.11, rs = 64, ts = 16;
        function vt(u, w) { var cu = Math.cos(u), su = Math.sin(u), cv = Math.cos(w), sv = Math.sin(w), ring = major + cv; v.push(cu * ring, su * ring, sv, 1, 1, 1, 1, cu * cv, su * cv, sv); }
        for (var i = 0; i < rs; i++) {
            var u1 = 2 * Math.PI * i / rs, u2 = 2 * Math.PI * (i + 1) / rs;
            for (var j = 0; j < ts; j++) { var w1 = 2 * Math.PI * j / ts, w2 = 2 * Math.PI * (j + 1) / ts; vt(u1, w1); vt(u2, w1); vt(u2, w2); vt(u1, w2); }
        }
        RPG.shaders.mesh(MESH.torus, { format: "position_color_normal", mode: "quads", vertices: v });
    }
    function quadMesh() {
        RPG.shaders.mesh(MESH.quad, { format: "position_tex", mode: "quads", vertices: [-1, -1, 0, 0, 0, 1, -1, 0, 1, 0, 1, 1, 0, 1, 1, -1, 1, 0, 0, 1] });
    }
    // Special Beam Cannon's double helix for a beam 1 wide (radius 2, tubes 0.65 and 0.5), SPIRAL_LEN blocks long
    function spiralMesh() {
        var v = [], k = 2 * Math.PI * 0.9, radius = 2.0, rings = SPIRAL_LEN * 12, radial = 6, step = SPIRAL_LEN / rings;
        function frame(z, phase) {
            var a = k * z + phase;
            var c = [-radius * Math.sin(a), radius * Math.cos(a), z];
            var t = [-radius * k * Math.cos(a), -radius * k * Math.sin(a), 1], tl = Math.sqrt(t[0] * t[0] + t[1] * t[1] + 1);
            t = [t[0] / tl, t[1] / tl, t[2] / tl];
            var ref = Math.abs(t[2]) < 0.95 ? [0, 0, 1] : [1, 0, 0];
            var sd = [t[1] * ref[2] - t[2] * ref[1], t[2] * ref[0] - t[0] * ref[2], t[0] * ref[1] - t[1] * ref[0]], sl = Math.sqrt(sd[0] * sd[0] + sd[1] * sd[1] + sd[2] * sd[2]) || 1;
            sd = [sd[0] / sl, sd[1] / sl, sd[2] / sl];
            var up = [sd[1] * t[2] - sd[2] * t[1], sd[2] * t[0] - sd[0] * t[2], sd[0] * t[1] - sd[1] * t[0]];
            return { c: c, s: sd, u: up };
        }
        function tube(tr, phase) {
            var f0 = frame(0, phase);
            for (var i = 0; i < rings; i++) {
                var f1 = frame((i + 1) * step, phase);
                for (var j = 0; j < radial; j++) {
                    var a0 = 2 * Math.PI * j / radial, a1 = 2 * Math.PI * (j + 1) / radial;
                    ring(f0, a0, tr); ring(f0, a1, tr); ring(f1, a1, tr); ring(f1, a0, tr);
                }
                f0 = f1;
            }
        }
        function ring(f, ang, tr) {
            var cs = Math.cos(ang), sn = Math.sin(ang);
            var nx = f.s[0] * cs + f.u[0] * sn, ny = f.s[1] * cs + f.u[1] * sn, nz = f.s[2] * cs + f.u[2] * sn;
            v.push(f.c[0] + nx * tr, f.c[1] + ny * tr, f.c[2] + nz * tr, 1, 1, 1, 1, nx, ny, nz);
        }
        tube(0.5 * 1.3, 0); tube(0.5, Math.PI);
        RPG.shaders.mesh(MESH.spiral, { format: "position_color_normal", mode: "quads", vertices: v });
    }

    var ready = false, failed = false, stage = 0, myId = -1;
    function setup() {
        if (ready || failed) return ready;
        var a = RPG.shaders.status(SH, "position_color_normal"), b = RPG.shaders.status(SH_SPLAT, "position_tex");
        if (a === "failed" || b === "failed") { failed = true; RPG.log("[DBR] ki shader did not load; ki attacks keep the engine's look"); return false; }
        if (a !== "ready" || b !== "ready") return false;
        if (stage === 0) sphereMesh(); else if (stage === 1) tubeMesh(); else if (stage === 2) quadMesh();
        else if (stage === 3) { tubeMesh(MESH.tri, 3, Math.PI / 2); torusMesh(); } else { spiralMesh(); ready = true; }
        stage++;
        return ready;
    }

    // ---- the shader's uniforms (all set, as one draw's uniforms outlive the next update) ---------------
    function uni(col, extra) {
        var u = { colorCore: col[0], colorBorder: col[1], colorOutline: col[2], alphaMult: 1, time: { k: { age: 0.05 } }, texBlend: 0, bloomMode: 0,
            globalAlpha: 1, shapeMode: 0, localPosMode: 0, zCut: -1, zCutFar: 2, flameMode: 0, blotchMode: 0, orbMode: 0, splatMode: 0,
            splatLife: 0, flameGain: 1, novaMode: 0 };
        if (extra) for (var k in extra) u[k] = extra[k];
        return u;
    }
    function draw(id, entity, ops, mesh, u, order) {
        RPG.shaders.draw(id, { mesh: mesh, shader: SH, entity: entity, x: 0, y: 0, z: 0, ops: ops, uniforms: u, bloom: { bloomMode: 1 },
            cull: false, depthWrite: false, ticks: KEEP, order: order || 20 });
    }
    function rotOps(dy) { return [["translate", 0, dy, 0], ["rotateY", { k: { yaw: -1 } }], ["rotateX", { k: { pitch: 1 } }]]; }

    // ---- KiEmberRenderer: 10 camera-facing flakes per ball (positions in ball radii) --------------------
    function imul(a, b) { var ah = (a >>> 16) & 0xffff, al = a & 0xffff, bh = (b >>> 16) & 0xffff, bl = b & 0xffff; return ((al * bl) + (((ah * bl + al * bh) << 16) >>> 0)) | 0; }
    function hash01(seed) {
        var h = (imul(seed, 374761393) + 668265263) | 0;
        h = imul(h ^ (h >>> 13), 1274126177);
        return ((h ^ (h >>> 16)) & 0x7FFFFFFF) / 0x7FFFFFFF;
    }
    // KiEmberRenderer's flakes as standing draws: each one's phase, flight, size, burn and fade are expressions of the
    // shot's age (no per-tick script work). R: the ball radius (a number, or {rate, max} while it grows with age);
    // base: world-space steps first (the ball's centre); back: the wake direction (world).
    function scaled(R, coef) {
        if (typeof R === "number") return R * coef;
        var m = R.max * coef;
        return { k: { age: R.rate * coef }, clamp: m < 0 ? [m, 0] : [0, m] };
    }
    // ember sets are queued and drawn within a time budget a tick (a set is 10 draws)
    var JOBS = [];
    function embers() { var args = arguments; JOBS.push(function () { embersNow.apply(null, args); }); }
    function embersNow(prefix, entity, base, R, col, back, backdraft, sizeScale) {
        var span = EMBER_R_END - EMBER_R_START, drag = EMBER_BACKDRAFT * backdraft;
        for (var i = 0; i < EMBER_COUNT; i++) {
            var seed = i * 131, ph = function (mul, add) { return { c: i / EMBER_COUNT, k: { age: 1 / EMBER_PERIOD }, frac: true, mul: mul, add: add }; };
            var dz = hash01(seed) * 2 - 1, ring = Math.sqrt(Math.max(0, 1 - dz * dz)), ang = hash01(seed + 97) * 2 * Math.PI;
            var d = [ring * Math.cos(ang), ring * Math.sin(ang), dz], t = [];
            for (var a = 0; a < 3; a++) t.push(ph(scaled(R, d[a] * span + back[a] * drag), scaled(R, d[a] * EMBER_R_START)));
            var sz = (0.75 + hash01(seed + 41) * 0.5) * sizeScale;
            RPG.shaders.draw(prefix + "_e" + i, { mesh: MESH.quad, shader: SH_SPLAT, entity: entity, x: 0, y: 0, z: 0,
                ops: base.concat([["translate", t[0], t[1], t[2]], ["billboard"], ["scale", ph(scaled(R, (EMBER_SIZE_DEATH - EMBER_SIZE_BIRTH) * sz), scaled(R, EMBER_SIZE_BIRTH * sz))]]),
                uniforms: { colorCore: col[0], colorBorder: col[1], colorOutline: col[2], alphaMult: { c: i / EMBER_COUNT, k: { age: 1 / EMBER_PERIOD }, frac: true, sin: true },
                    time: hash01(seed + 7) * 64, splatMode: 1, splatLife: { c: i / EMBER_COUNT, k: { age: 1 / EMBER_PERIOD }, frac: true }, globalAlpha: 1, bloomMode: 0, zCut: -1, zCutFar: 2 },
                bloom: { bloomMode: 1 }, cull: false, depthWrite: false, ticks: KEEP, order: 22 });
        }
    }
    function dirOf(yaw, pitch) {
        var y = yaw * Math.PI / 180, p = pitch * Math.PI / 180;
        return [-Math.sin(y) * Math.cos(p), -Math.sin(p), Math.cos(y) * Math.cos(p)];
    }
    function back(pr) { var d = dirOf(pr.yaw, pr.pitch); return [-d[0], -d[1], -d[2]]; }

    // ---- what each shot is --------------------------------------------------------------------------
    function lookOf(pr) {
        var t = null;
        if (pr.tag) { try { t = JSON.parse(pr.tag); } catch (e) { t = null; } }
        if (t && t.k) return t;
        switch (pr.def) {                                         // shots without a tag (mobs, bosses, raids)
            case "dmz_tech_wave": return { k: "wave", rt: 0, sz: pr.size / 1.5, cs: 0.2, ct: 12, f: 1 };
            case "dmz_tech_beam": return { k: "wave", rt: 0, sz: pr.size * 0.5, cs: 0.2, ct: 12, f: 1 };
            case "dmz_tech_laser": return { k: "laser", rt: 0, sz: pr.size * 0.35 * 0.5 / 0.08, f: 1 };
            case "dmz_tech_disk": return { k: "disk", rt: 0, sz: pr.size, ct: 0, f: 1, noBox: 1 };
            case "dmz_tech_bullet": return { k: "small", rt: 0, sz: pr.size, f: 1, noBox: 1 };
            case "dmz_tech_ball": return { k: "ball", rt: pr.size > 3 ? 2 : 1, sz: pr.size, ct: 0, f: 1, noBox: 1 };
        }
        return null;
    }

    // ---- KiProjectileRenderer -----------------------------------------------------------------------
    function ball(pr, L, col, P) {
        var sz = L.sz || pr.size, cy = L.noBox ? 0 : sz * 0.4, rt = L.rt || 0, age = pr.age;
        // KiBlastEntity: the ball grows over its cast time while held, then flies at full size
        var growing = pr.held && L.ct > 0 && age < L.ct;
        var S = growing ? { k: { age: sz / L.ct }, clamp: [0, sz] } : sz;
        var Snow = growing ? sz * age / L.ct : sz;
        var half = typeof S === "number" ? S * 0.5 : { k: { age: sz / L.ct * 0.5 }, clamp: [0, sz * 0.5] };
        var ops = rotOps(cy), bk = back(pr);
        if (rt === 9) {                                            // barrage emitter: two orbs 1.5 apart
            [-1.5, 1.5].forEach(function (sx, i) {
                draw(P + "_v" + i, pr.id, ops.concat([["scale", S], ["translate", sx, 0, 0]]), MESH.sphere, uni(col));
            });
            return;
        }
        if (rt === 11) {                                           // Fake Moon
            draw(P + "_m", pr.id, ops.concat([["scale", half]]), MESH.sphere, uni([col[0], col[0], col[2]]));
            var pulse = { k: { age: 0.1 / Math.PI }, sin: true, mul: 0.08 * 0.5 * Snow, add: 1.12 * 0.5 * Snow };
            draw(P + "_mh", pr.id, ops.concat([["scale", pulse]]), MESH.sphere, uni([col[0], col[2], col[2]], { alphaMult: 0.25 }));
            return;
        }
        if (rt === 4) {                                            // Soul Punisher: a small white core
            var w = [1, 1, 1];
            draw(P + "_s", pr.id, ops.concat([["scale", typeof S === "number" ? S * 0.15 : { k: { age: sz / L.ct * 0.15 }, clamp: [0, sz * 0.15] }]]), MESH.sphere, uni([w, w, w]));
            return;
        }
        if (rt === 12) {                                           // Assault Rain's anchor: pulses while it rains
            var pr12 = L.f ? { k: { age: 1.2 / Math.PI }, sin: true, mul: 0.06 * sz, add: 0.5 * sz } : half;
            draw(P + "_b", pr.id, ops.concat([["scale", pr12]]), MESH.sphere, uni(col, { blotchMode: 1, flameMode: 1, orbMode: 1 }));
            embers(P, pr.id, [["translate", 0, cy, 0]], growing ? { rate: 0.5 * sz / L.ct, max: 0.5 * sz } : 0.5 * sz, col, bk, CHARGE_BACKDRAFT, 1);
            return;
        }
        if (rt === 13) {                                           // Blaster Meteor: a see-through sphere round the caster
            var inside = pr.owner === myId && RPG.camera.currentMode() === "first";
            var pm = growing ? half : { k: { age: (L.f ? 1.2 : 0.4) / Math.PI }, sin: true, mul: 0.02 * sz, add: 0.5 * sz };
            draw(P + "_b", pr.id, ops.concat([["scale", pm]]), MESH.sphere, uni(col, { alphaMult: inside ? 0.3 : 0.85 }));
            return;
        }
        if (rt === 14) {                                           // the Tri-Beam: a glowing triangle (the Neo's charge: a 0.3 orb)
            if (pr.held) {
                var R14 = growing ? { k: { age: 0.3 / L.ct }, clamp: [0, 0.3] } : 0.3;
                draw(P + "_b", pr.id, ops.concat([["scale", R14]]), MESH.sphere, uni(col, { blotchMode: 1, flameMode: 1, orbMode: 1 }));
                embers(P, pr.id, [["translate", 0, cy, 0]], growing ? { rate: 0.3 / L.ct, max: 0.3 } : 0.3, col, bk, CHARGE_BACKDRAFT, 1);
                return;
            }
            [[1.3, 0.14], [1.14, 0.35], [1.0, 1.0]].forEach(function (g, i) {
                draw(P + "_t" + i, pr.id, ops.concat([["scale", sz * g[0], sz * g[0], sz * 0.6 * g[0]], ["translate", 0, 0, -0.5]]), MESH.tri,
                    uni(col, { shapeMode: 1, alphaMult: g[1] }), 20 + i);
            });
            embers(P, pr.id, [["translate", 0, cy, 0]], sz * 0.5, col, bk, 1, GIANT_EMBER_SCALE);
            return;
        }
        if (rt === 8) {                                            // Sokidan: the plain shader ball
            draw(P + "_b", pr.id, ops.concat([["scale", half]]), MESH.sphere, uni(col));
            return;
        }
        var giant = rt === 2 || rt === 5 || rt === 6, death = rt === 7, cooler = rt === 6 && L.tech === "supernova_cooler";
        var jitter = rt === 6 ? 0.01 : death ? 0.03 : 0;
        if (jitter) ops = ops.concat([["translate", { k: { age: 20 / Math.PI }, sin: true, mul: jitter }, { c: 0.5, k: { age: 24 / Math.PI }, sin: true, mul: jitter }, { k: { age: 16 / Math.PI }, sin: true, mul: jitter }]]);
        var R = death ? S : half, Rnow = (death ? 1 : 0.5) * Snow;
        if (cooler) draw(P + "_b", pr.id, ops.concat([["scale", R]]), MESH.sphere, uni(col, { novaMode: 1, flameMode: 1, flameGain: COOLER_FLAME_GAIN }));
        else draw(P + "_b", pr.id, ops.concat([["scale", R]]), MESH.sphere, uni(col, { blotchMode: 1, flameMode: 1, orbMode: rt === 0 ? 1 : 0,
            flameGain: giant || death ? GIANT_FLAME_GAIN : 1 }));
        if (L.k !== "small" || pr.held)
            embers(P, pr.id, [["translate", 0, cy, 0]], growing ? { rate: (death ? 1 : 0.5) * sz / L.ct, max: (death ? 1 : 0.5) * sz } : Rnow, col, bk,
                rt === 0 ? CHARGE_BACKDRAFT : 1, giant || death ? GIANT_EMBER_SCALE : 1);
    }

    // ---- KiWaveRenderer -----------------------------------------------------------------------------
    function wave(pr, L, col, P) {
        var age = pr.age, rt = L.rt || 0, sz = L.sz || 1, cs = L.cs || 0.2, bk = back(pr);
        if (pr.held) {
            var ctw = Math.max(1, L.ct || 12), done = age >= ctw;
            // the orb grows over the cast (smoothstep in the original; linear here so it runs without per-tick work)
            var W = function (f) { return done ? cs * f : { k: { age: cs * f / ctw }, clamp: [0, cs * f] }; };
            if (L.tech === "heat_dome") {                          // a big plain sphere round the caster
                draw(P + "_d", pr.id, [["scale", W(1.5)]], MESH.sphere, uni(col, { alphaMult: pr.owner === myId && RPG.camera.currentMode() === "first" ? 0.35 : 0.85 }));
                return;
            }
            if (rt === 3) {                                        // Final Flash: two orbs that join in front of the hands
                [1, -1].forEach(function (sgn, i) {
                    var sp = 0.6 * 1.8 * sgn, spread = { c: 24 * sp, k: { age: -sp }, clamp: sp < 0 ? [sp, 0] : [0, sp] };   // held apart 23 ticks, joined at 24
                    var ops = [["rotateY", { k: { yaw: -1 } }], ["translate", spread, 0, 0], ["rotateY", { k: { yaw: 1 } }], ["scale", W(DOUBLE_WAVE_BALL_SCALE)]];
                    draw(P + "_o" + i, pr.id, ops, MESH.sphere, uni(col, { blotchMode: 1, flameMode: 1, orbMode: 1 }));
                });
                return;
            }
            draw(P + "_o", pr.id, [["scale", W(1.5)]], MESH.sphere, uni(col, { blotchMode: 1, flameMode: 1, orbMode: 1 }));
            embers(P, pr.id, [], done ? cs * 1.5 : { rate: cs * 1.5 / ctw, max: cs * 1.5 }, col, bk, CHARGE_BACKDRAFT, 1);
            return;
        }
        // fired: tube from the muzzle to the head, ball at each end (KiRenderWaveBrightness / KiRenderWaveDouble / KiRenderWave)
        var len = Math.max(0.1, pr.length), ops = rotOps(0);
        var bright = rt === 1 || rt === 2, dbl = rt === 3 || rt === 5;
        var pulseW = bright || dbl ? { k: { age: 1.5 / Math.PI }, sin: true, mul: 0.15 * sz, add: sz } : sz;
        var tubeR = bright || dbl ? pulseW : sz * 1.2;
        var cutA = (dbl ? 1.8 : 1.5) * sz, cutB = 2.5 * sz;
        var zc = Math.min(cutA * 0.95 / len, 0.49), zf = bright || dbl ? Math.max(1 - cutB * 0.95 / len, 0.51) : 2;
        draw(P + "_t", pr.id, ops.concat([["scale", tubeR, tubeR, { k: { length: 1 } }]]), MESH.tube, uni(col, { zCut: zc, zCutFar: zf }));
        var head = (bright ? 2.5 : dbl ? 2.5 * DOUBLE_WAVE_BALL_SCALE : 1.5) * sz;
        draw(P + "_h", pr.id, ops.concat([["translate", 0, 0, { k: { length: 1 } }], ["scale", head]]), MESH.sphere, uni(col, { blotchMode: 1, flameMode: 1 }));
        var muzzle = 1.5 * MUZZLE_FLAME_SCALE * sz * (dbl ? DOUBLE_WAVE_BALL_SCALE : 1);
        var breath = { k: { age: 3.1 / Math.PI }, sin: true, mul: 0.09 * muzzle, add: muzzle };
        draw(P + "_m", pr.id, ops.concat([["translate", 0, 0, 0.1], ["scale", breath]]), MESH.sphere, uni(col, { blotchMode: 1, flameMode: 1 }));
        var d = dirOf(pr.yaw, pr.pitch);
        embers(P + "h", pr.id, [["translate", { k: { length: d[0] } }, { k: { length: d[1] } }, { k: { length: d[2] } }]], head, col, bk, 1, 1);
        embers(P + "m", pr.id, [], muzzle, col, bk, 1, 1);
    }
    // ---- KiLaserRenderer ----------------------------------------------------------------------------
    function laser(pr, L, col, P) {
        var sz = L.sz || 1, ops = rotOps(0);
        if (pr.held) { draw(P + "_o", pr.id, ops.concat([["scale", sz * 0.16]]), MESH.sphere, uni(col)); return; }
        if (L.k === "laser") {
            draw(P + "_t", pr.id, ops.concat([["scale", sz * 0.08, sz * 0.08, { k: { length: 1 } }]]), MESH.tube, uni(col));
            return;
        }
        var w = sz * 0.15, len = Math.max(0.1, pr.length);
        draw(P + "_t", pr.id, ops.concat([["scale", w, w, { k: { length: 1 } }]]), MESH.tube, uni(col));
        draw(P + "_h", pr.id, ops.concat([["translate", 0, 0, { k: { length: 1 } }], ["scale", w * 1.5]]), MESH.sphere, uni(col));
        var segs = Math.min(26, Math.ceil(len / SPIRAL_LEN));
        for (var i = 0; i < 26; i++) {
            var id = P + "_s" + i;
            if (i >= segs) { RPG.shaders.remove(id); continue; }
            draw(id, pr.id, ops.concat([["rotateZ", { k: { age: -30 } }], ["translate", 0, 0, i * SPIRAL_LEN], ["scale", w, w, 1]]), MESH.spiral,
                uni(col, { zCutFar: len - i * SPIRAL_LEN }));
        }
    }

    // ---- KiDiskRenderer -----------------------------------------------------------------------------
    function disk(pr, L, col, P) {
        var sz = L.sz || pr.size, cy = L.noBox ? 0 : sz * 0.5;
        var S = pr.held && L.ct > 0 && pr.age < L.ct ? { k: { age: sz / L.ct }, clamp: [0, sz] } : sz;
        var ops = [["translate", 0, cy, 0], ["rotateY", { c: 180, k: { yaw: -1 } }], ["rotateX", pr.held ? 90 : { c: 90, k: { pitch: 1 } }],
            ["rotateZ", { k: { age: 35 } }], ["translate", 0, 0, -0.025], ["scale", S, S, 0.05]];
        draw(P + "_d", pr.id, ops, MESH.tube, uni(col, { shapeMode: 1 }));
    }

    // ---- KillDriverRenderer: a torus (tube 0.11 of the radius) spinning 18 degrees a tick, pulsing 6 %, grown in over 12 ticks;
    // while charging it rises from the chest at 0.35 of its size to over the head at full size (ticks 30-38) ----
    function ring(pr, L, col, P) {
        var full = L.r || 4, age = pr.age, r = full;
        if (pr.held) { var raise = Math.max(0, Math.min(1, (age - 30) / 8)); r = full * (0.35 + 0.65 * raise); }
        var T = r * 0.11 * Math.min(1, age / 12);
        var ops = pr.held ? [["rotateY", { k: { yaw: -1 } }]] : [["rotateY", { k: { yaw: -1 } }], ["rotateX", { k: { pitch: 1 } }]];
        ops = ops.concat([["rotateZ", { k: { age: 18 } }], ["scale", { k: { age: 0.45 / Math.PI }, sin: true, mul: 0.06 * T, add: T }]]);
        draw(P + "_r", pr.id, ops, MESH.torus, uni(col));
    }

    // ---- every client tick: draw what this computer sees ------------------------------------------
    RPG.every(1, function () {
        if (!RPG.player.present || !setup()) return;
        var list = RPG.world.projectiles(160);
        if (!list.length) { JOBS.length = 0; return; }
        var me = RPG.avatar.players().filter(function (pl) { return pl.local; })[0];
        myId = me ? me.id : -1;
        var now = ++clock, t0 = RPG.nowMs();
        for (var i = 0; i < list.length; i++) {
            if (RPG.nowMs() - t0 > 18) break;                // the rest next tick
            var pr = list[i];
            if (!OWN[pr.def]) continue;
            var L = lookOf(pr);
            if (!L) continue;
            var P = "dmzki_" + pr.id, st = STATE[pr.id];
            try { sparks(pr, L, st); } catch (e) { }
            // the draws stand on their own (expressions of age / size / length): redone only when the shot changes
            // state (charging -> fired, a new spiral segment...) and refreshed now and then
            var segs = L.k === "beam" && !pr.held ? Math.ceil(Math.max(0.1, pr.length) / SPIRAL_LEN) : 0;
            var key = L.k + "|" + pr.held + "|" + (L.rt || 0) + "|" + Math.round((L.sz || pr.size) * 100) + "|" + segs + "|" + pr.colors.core + pr.colors.border + pr.colors.outline
                + "|" + (pr.held && L.ct > 0 && pr.age >= L.ct ? 1 : 0) + "|" + (L.f ? 1 : 0)
                + (L.k === "ring" ? "|" + Math.min(pr.held ? 40 : 13, pr.age) : "");
            if (st && st.key === key && now - st.at < REFRESH) {
                st.seen = now;
                if (L.k === "wave" && !pr.held && now % 2 === 0) waveCuts(pr, L, P);
                continue;
            }
            if (st && st.key !== key) RPG.shaders.removePrefix(P + "_");
            STATE[pr.id] = { key: key, at: now, seen: now };
            var col = [rgb(pr.colors.core), rgb(pr.colors.border), rgb(pr.colors.outline)];
            try {
                if (L.k === "ball" || L.k === "small" || L.k === "volley") ball(pr, L, col, P);
                else if (L.k === "wave") wave(pr, L, col, P);
                else if (L.k === "beam" || L.k === "laser") laser(pr, L, col, P);
                else if (L.k === "disk") disk(pr, L, col, P);
                else if (L.k === "ring") ring(pr, L, col, P);
                else continue;
                RPG.world.hideProjectile(pr.id, KEEP);
            } catch (e) { RPG.log("[DBR] ki render: " + e); }
        }
        while (JOBS.length && RPG.nowMs() - t0 < 22) JOBS.shift()();
        if (now % 100 === 0) for (var id in STATE) if (now - STATE[id].seen > 100) { delete STATE[id]; delete PX[id]; RPG.trails.remove("dmzkt_" + id); }
    });
    var STATE = {}, clock = 0;

    // ---- the particles the original's ki entities spawn on each client (KiBlastEntity / KiWaveEntity / KiLaserEntity /
    // KiDiskEntity client ticks): KI_TRAIL sparks round flying balls and wave / laser tips, KI_SHEDDING flecks drawn
    // into giant balls and wave / laser muzzles, KI_SPLASH when a shot appears, KI_SPLASH_WAVE rings at a wave's muzzle,
    // and the small blast's ribbon (KiTrailRenderer). All only on this computer, from what it sees.
    var KTEX = ["dmzpack:ki_trail0", "dmzpack:ki_trail1", "dmzpack:ki_trail2", "dmzpack:ki_trail3", "dmzpack:ki_trail4", "dmzpack:ki_trail5"];
    var STEX = ["dmzpack:ki_exp0", "dmzpack:ki_exp1", "dmzpack:ki_exp2", "dmzpack:ki_exp3", "dmzpack:ki_exp4", "dmzpack:ki_exp5", "dmzpack:ki_exp6"];
    var PX = {};                                                   // id -> {x, y, z, splashed, fired} last seen
    function rsph(r) {                                             // a random point on a sphere of radius r
        var th = Math.random() * 2 * Math.PI, ph = Math.acos(2 * Math.random() - 1);
        return [r * Math.sin(ph) * Math.cos(th), r * Math.sin(ph) * Math.sin(th), r * Math.cos(ph)];
    }
    // KiTrailParticle: 25-35 ticks, velocity x 0.9 and size x 0.97 a tick, fading out, additive
    function kiTrail(x, y, z, vx, vy, vz, col, scale) {
        RPG.particles.sprite({ texture: KTEX, animate: true, x: x, y: y, z: z, vx: vx, vy: vy, vz: vz, friction: 0.9, growMul: 0.97,
            size: scale * (0.1 + Math.random() * 0.3), life: [25, 35], fade: "life", color: col, blend: "additive", fullbright: true, collide: false });
    }
    // KiSheddingParticle: 8 ticks, 0.3-0.5, velocity x 0.95 and size x 0.94 a tick, fading out, additive
    function shed(x, y, z, vx, vy, vz, col) {
        RPG.particles.sprite({ texture: KTEX, animate: true, x: x, y: y, z: z, vx: vx, vy: vy, vz: vz, friction: 0.95, growMul: 0.94,
            size: 0.3 + Math.random() * 0.2, life: 8, fade: "life", color: col, blend: "additive", fullbright: true, collide: false });
    }
    // KiSplashParticle: ki_exp0-6 over 10 ticks, 1 growing 0.1 a tick (KiSplashWaveParticle: its size, growing 15 % of it, fading)
    function splash(x, y, z, col, wave) {
        RPG.particles.sprite(wave ? { texture: STEX, animate: true, x: x, y: y, z: z, size: wave, grow: wave * 0.15, life: 10, fade: 5, color: col, fullbright: true, collide: false }
            : { texture: STEX, animate: true, x: x, y: y, z: z, size: 1, grow: 0.1, life: 10, color: col, fullbright: true, collide: false, blend: "opaque" });
    }
    function sparks(pr, L, st) {
        var c = PX[pr.id], first = !c;
        if (first) c = PX[pr.id] = { x: pr.x, y: pr.y, z: pr.z, fired: !pr.held };
        var dx = pr.x - RPG.player.x, dy = pr.y - RPG.player.y, dz = pr.z - RPG.player.z;
        var near = dx * dx + dy * dy + dz * dz < 40 * 40, col = pr.colors.border, sz = L.sz || pr.size, rt = L.rt || 0, i, o;
        var vx = pr.x - c.x, vy = pr.y - c.y, vz = pr.z - c.z;
        c.x = pr.x; c.y = pr.y; c.z = pr.z;
        var justFired = !pr.held && !c.fired;
        if (!pr.held) c.fired = true;
        if (L.k === "ball" || L.k === "small" || L.k === "volley") {
            var cy = pr.y + (L.noBox ? 0 : sz * 0.4);
            if (L.k === "small" || (rt === 0 && !pr.held)) {           // KiTrailRenderer: 14 samples, 5.5 x size long, 0.38 x size wide
                if (!pr.held) {
                    var sp = Math.sqrt(vx * vx + vy * vy + vz * vz), n = sp > 0.01 ? Math.max(2, Math.min(14, Math.round(5.5 * sz / sp) + 1)) : 14;
                    if (first || justFired || c.n !== n)
                        RPG.trails.set("dmzkt_" + pr.id, { entity: pr.id, y: L.noBox ? 0 : sz * 0.4, setback: 0, samples: n, life: n + 1, maxSegment: 12,
                            width: 0.38 * sz, color: pr.colors.border, alpha: 1, blend: "additive", core: { width: 0.19 * sz, alpha: 0.9, color: pr.colors.core } });
                    c.n = n;
                }
                return;
            }
            if (!near) return;
            if (first && rt !== 0 && rt !== 9) splash(pr.x, cy, pr.z, col);
            if (rt >= 1 && rt !== 9 && rt !== 4 && !pr.held)            // flying: 3 sparks a tick round the ball, thrown outwards
                for (i = 0; i < 3; i++) { o = rsph(sz * 1.2); kiTrail(pr.x + o[0], cy + o[1], pr.z + o[2], o[0] * 0.15, o[1] * 0.15, o[2] * 0.15, col, sz); }
            if (rt === 2 || rt === 5 || rt === 6)                       // giant balls: 10 flecks a tick drawn in from 3 x size
                for (i = 0; i < 10; i++) {
                    var a = Math.random() * 2 * Math.PI, d = sz * 3, sx = Math.cos(a) * d, sz2 = Math.sin(a) * d, sy = (Math.random() - 0.5) * 2 * d;
                    shed(pr.x + sx, cy + sy, pr.z + sz2, -sx * 0.15, -sy * 0.15, -sz2 * 0.15, col);
                }
            return;
        }
        if (!near) return;
        var dir = dirOf(pr.yaw, pr.pitch), len = Math.max(0, pr.length);
        if (L.k === "wave" && !pr.held) {
            if (len > 1) {
                var tx = pr.x + dir[0] * len, ty = pr.y + dir[1] * len, tz = pr.z + dir[2] * len;
                for (i = 0; i < 4; i++) { o = rsph(sz * 1.2); kiTrail(tx + o[0], ty + o[1], tz + o[2], o[0] * 0.15, o[1] * 0.15, o[2] * 0.15, col, sz); }
                for (i = 0; i < 5; i++) {
                    var a2 = Math.random() * 2 * Math.PI, d2 = sz * 2, ox = Math.cos(a2) * d2, oz = Math.sin(a2) * d2, oy = (Math.random() - 0.5) * 2 * d2;
                    shed(pr.x + ox, pr.y + oy, pr.z + oz, -ox * 0.15, -oy * 0.15, -oz * 0.15, col);
                }
            }
            if (pr.age % 5 === 0) splash(pr.x, pr.y, pr.z, col, sz);
        } else if ((L.k === "beam" || L.k === "laser") && !pr.held) {
            if (justFired || first) splash(pr.x, pr.y, pr.z, col);
            for (i = 0; i < 3; i++) { o = rsph(sz * 2); shed(pr.x + o[0], pr.y + o[1], pr.z + o[2], -o[0] * 0.15, -o[1] * 0.15, -o[2] * 0.15, col); }
            if (len > 0.5)
                for (i = 0; i < 3; i++) { o = rsph(sz * 0.8); kiTrail(pr.x + dir[0] * len + o[0], pr.y + dir[1] * len + o[1], pr.z + dir[2] * len + o[2], o[0] * 0.25, o[1] * 0.25, o[2] * 0.25, col, sz * 0.6); }
        } else if (L.k === "disk") {
            var dc = pr.colors.core, dy2 = pr.y + (L.noBox ? 0 : sz * 0.5);
            if (pr.held)                                               // charging: sparks drawn into the disk in the hand
                for (i = 0; i < 4; i++) { o = rsph(sz * 2.5); kiTrail(pr.x + o[0], dy2 + o[1], pr.z + o[2], -o[0] * 0.15, -o[1] * 0.15, -o[2] * 0.15, dc, sz * 0.3); }
            else {
                if (justFired || first) splash(pr.x, dy2, pr.z, dc);
                for (i = 0; i < 4; i++) {                              // flying: a wake of sparks left in the air
                    var a3 = Math.random() * 2 * Math.PI;
                    kiTrail(pr.x + Math.cos(a3) * sz * 0.8, dy2 + (Math.random() - 0.5) * 0.1, pr.z + Math.sin(a3) * sz * 0.8, -vx * 0.3, -vy * 0.3, -vz * 0.3, dc, sz * 0.6);
                }
            }
        }
    }
    // the wave tube's ends are cut by the muzzle and head balls: fractions of its length (KiWaveRenderer)
    function waveCuts(pr, L, P) {
        var rt = L.rt || 0, sz = L.sz || 1, len = Math.max(0.1, pr.length), bright = rt === 1 || rt === 2, dbl = rt === 3 || rt === 5;
        var zc = Math.min((dbl ? 1.8 : 1.5) * sz * 0.95 / len, 0.49), zf = bright || dbl ? Math.max(1 - 2.5 * sz * 0.95 / len, 0.51) : 2;
        RPG.shaders.update(P + "_t", { uniforms: { zCut: zc, zCutFar: zf } });
    }

    // ---- KiExplosionVisualEntity + the KI_EXPLOSION particle, sent by the server ------------------------
    var fxN = 0;
    RPG.net.on("dmz_ki_fx", function (d) { kiFx(d); });
    function kiFx(d) {
        if (!d || !RPG.player.present) return;
        var c = d.c ? [rgb(d.c[0]), rgb(d.c[1]), rgb(d.c[2])] : [[1, 1, 1], [1, 0.8, 0.3], [1, 0.5, 0.1]];
        if (setup() && d.v > 0) {
            var t0 = RPG.shaders.clock(), M = d.v;                 // radius maxSize x (0.5 + 0.5 progress) over 25 ticks
            RPG.shaders.draw("dmzki_fx" + (fxN++ % 64), { mesh: MESH.sphere, shader: SH, x: d.x, y: d.y, z: d.z,
                ops: [["scale", { c: -t0 / 1.25, k: { clock: 1 / 1.25 }, mul: 0.5 * M, add: 0.5 * M, clamp: [0.5 * M, M] }]],
                uniforms: uni(c, { alphaMult: { c: 1 + 0.8 * t0, k: { clock: -0.8 }, clamp: [0, 0.45] }, time: { k: { clock: 1 } } }),
                cull: false, depthWrite: false, ticks: 26, order: 21 });
        }
        if (d.s > 0) splash(d.x, d.y, d.z, d.c ? d.c[1] : "#FFFFFF", d.s);
        if (d.p > 0) {
            // KiExplosionParticle: explode0-5 over 8 ticks while it swells to 1.3x, then held and faded out over 12, glowing
            RPG.particles.sprite({ texture: ["dmzpack:explode0", "dmzpack:explode1", "dmzpack:explode2", "dmzpack:explode3", "dmzpack:explode4", "dmzpack:explode5"],
                animate: true, frameTicks: 8, x: d.x, y: d.y, z: d.z, size: d.p, grow: d.p * 0.3 / 8, growTicks: 8, life: 20, gravity: 0, collide: false, fade: 12,
                blend: "additive", fullbright: true });
        }
    }

    // ---- Final Explosion (KiExplosionRenderer / KiExplosionEntity client tick), sent by scripts/41_dmz_techniques.js ----
    //  charging: a 2-block sphere (alpha 0.65) round the caster's middle, and 4 sparks a tick drawn in from a box
    //  1.3 x the radius; fired: it swells 0.4 a tick up to max(radius, 10) and a splash 1.4 x the radius flashes at
    //  its centre every 10 ticks, for the attack's life.
    var EXPL = {};
    var XTEX = ["dmzpack:ki_exp1", "dmzpack:ki_exp2", "dmzpack:ki_exp3", "dmzpack:ki_exp4", "dmzpack:ki_exp5"];
    RPG.net.on("dmz_kiexpl", function (d) {
        if (!d || d.e === undefined) return;
        var id = "dmzkx_" + d.e;
        if (d.s === "x") { RPG.shaders.removePrefix(id); delete EXPL[d.e]; return; }
        if (!setup()) return;
        var col = d.c ? [rgb(d.c[0]), rgb(d.c[1]), rgb(d.c[2])] : [[1, 1, 1], [1, 1, 0.5], [1, 1, 1]];
        var x = EXPL[d.e] || (EXPL[d.e] = {});
        x.r = d.r || 10; x.c = d.c || ["#FFFFFF", "#FFFF88", "#FFFFFF"]; x.fired = d.s === "f"; x.t = 0;
        var scale = 2;
        if (x.fired) {
            var t0 = RPG.shaders.clock(), lim = Math.max(x.r, 10);
            scale = { c: 2 - t0 * 8, k: { clock: 8 }, clamp: [2, lim] };          // 0.4 a tick
            x.life = d.life || 300;
        }
        RPG.shaders.draw(id, { mesh: MESH.sphere, shader: SH, entity: d.e, x: 0, y: 0, z: 0,
            ops: [["translate", 0, { k: { height: 0.5 } }, 0], ["scale", scale]], uniforms: uni(col, { alphaMult: 0.65 }),
            bloom: { bloomMode: 1 }, cull: false, depthWrite: false, ticks: x.fired ? x.life + 2 : 1200, order: 21 });
    });
    RPG.every(1, function () {
        for (var e in EXPL) {
            var x = EXPL[e], ent = RPG.world.entity(Number(e));
            x.t++;
            if (!ent || (x.fired && x.t > x.life + 2) || x.t > 1400) { if (!ent || x.t > 1400) { RPG.shaders.removePrefix("dmzkx_" + e); delete EXPL[e]; } continue; }
            var dx = ent.x - RPG.player.x, dz = ent.z - RPG.player.z;
            if (dx * dx + dz * dz > 48 * 48) continue;
            var cx = ent.x, cy = ent.y + (ent.height || 1.8) / 2, cz = ent.z;
            if (!x.fired) {
                var g = x.r * 1.3;
                for (var i = 0; i < 4; i++) {
                    var ox = (Math.random() - 0.5) * 2 * g, oy = (Math.random() - 0.5) * 2 * g, oz = (Math.random() - 0.5) * 2 * g;
                    kiTrail(cx + ox, cy + oy, cz + oz, -ox * 0.12, -oy * 0.12, -oz * 0.12, x.c[1], 1);
                }
            } else if (x.t % 10 === 0) {
                var b = x.r * 1.4;
                RPG.particles.sprite({ texture: XTEX, animate: true, x: cx, y: cy + 0.1, z: cz, size: b, grow: b / 20, life: 20, alpha: 0.7,
                    color: x.c[0], blend: "additive", fullbright: true, collide: false });
            }
        }
    });

    // ---- the view held while a restricted ki attack is being emitted (ClientStatsEvents) -------------
    var lockedAt = 0;
    RPG.net.on("dmz_tech_firelock", function (d) {
        var on = !!(d && d.on);
        lockedAt = on ? RPG.nowMs() : 0;
        try { RPG.camera.lockRotation(on); } catch (e) { }
    });
    RPG.every(20, function () {                                   // never stuck: the server always ends it, this is a backstop
        if (lockedAt && RPG.nowMs() - lockedAt > 40000) { lockedAt = 0; try { RPG.camera.lockRotation(false); } catch (e) { } }
    });

    // ---- the plain ki blast: Left Alt + right click (ClientStatsEvents): a tap throws one, holding 6 ticks a volley ----
    var kbHold = 0, kbWas = false;
    function kbChord() {
        return RPG.isWindowFocused() && !RPG.screen.getOpen() && RPG.isKeyDown("key.keyboard.left.alt") && RPG.isKeyDown("key.mouse.right")
            && !RPG.isKeyDown("key.keyboard.left.control");                   // Ctrl + Alt + right click is the ki share
    }
    RPG.on("tick", function () {
        if (!RPG.player.present || !RPG.getVar("dmz_created", 0)) { kbHold = 0; kbWas = false; return; }
        var down = kbChord();
        if (down && !kbWas) kbHold = 1;
        else if (kbHold > 0) {
            if (!down) { RPG.net.send("dmz_kiblast", { v: false }); kbHold = 0; }
            else if (++kbHold >= 6) { RPG.net.send("dmz_kiblast", { v: true }); kbHold = 0; }
        }
        kbWas = down;
    });

    return { ready: function () { return ready; }, kiBlastChord: kbChord,
        // for the volleys (51v_dmz_volleys.js): the ki shader, its meshes and the explosion / splash / spark effects
        setup: setup, uni: uni, MESH: MESH, SH: SH, rgb: rgb, kiFx: kiFx, kiTrail: function (x, y, z, vx, vy, vz, col, sc) { kiTrail(x, y, z, vx, vy, vz, col, sc); },
        myId: function () { return myId; } };
})();
