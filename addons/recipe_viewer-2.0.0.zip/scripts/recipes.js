// =====================================================================================
//  Recipe Viewer - server side. Players whose client runs the addon's client script get the
//  engine's JEI-style viewer (client/scripts/recipe_viewer.js): /recipes [item], /uses <item>,
//  /recipes @<category> and the Recipe Viewer key (U, held item) open its recipes window.
//  Anyone else (a client that didn't take the addon's client files) keeps the server-drawn list
//  below: left-click an item for its recipes, right-click for what it's used in.
// =====================================================================================
(function () {
    var CLIENT = {};                      // uuid -> true once the client viewer said hello
    RPG.net.on("rv_hello", (p) => { CLIENT[p.uuid] = true; });
    function client(p, data) {
        if (!CLIENT[p.uuid]) return false;
        RPG.net.send(p, "rv_show", data);
        return true;
    }
    var COLS = 9, ROWS = 6, PER_PAGE = COLS * ROWS;
    var STATE = {};                       // uuid -> view state
    var TYPES = { crafting_shaped: "Crafting", crafting_shapeless: "Crafting (any shape)", smelting: "Furnace", blasting: "Blast Furnace",
        smoking: "Smoker", campfire_cooking: "Campfire", stonecutting: "Stonecutter", smithing: "Smithing Table" };

    function st(p) { return STATE[p.uuid] || (STATE[p.uuid] = { mode: "list", page: 0, query: "", history: [] }); }

    function openList(p) {
        // the engine keeps the full item list; we only ask for the page we show
        let s = st(p), total = RPG.items.count(s.query), pages = Math.max(1, Math.ceil(total / PER_PAGE));
        s.page = Math.max(0, Math.min(s.page, pages - 1));
        let list = RPG.items.list(s.query, PER_PAGE, s.page * PER_PAGE);
        let els = [
            { type: "input", id: "q", x: 8, y: 20, w: 150, h: 14, value: s.query, hint: "Search (Enter)", maxLength: 40 },
            { type: "button", id: "held", x: 162, y: 19, w: 60, h: 16, text: "Held item" },
            { type: "text", x: 8, y: 194, text: "&7" + total + " items  -  page " + (s.page + 1) + "/" + pages + "  &8(left: recipes, right: uses)", scale: 0.75 },
            { type: "button", id: "prev", x: 160, y: 190, w: 30, h: 16, text: "<" },
            { type: "button", id: "next", x: 194, y: 190, w: 30, h: 16, text: ">" }
        ];
        for (let i = 0; i < PER_PAGE; i++) {
            let it = list[i];
            if (!it) break;
            els.push({ type: "item", id: "i" + i, item: it.id, x: 12 + (i % COLS) * 23, y: 42 + Math.floor(i / COLS) * 24, slot: true, tooltip: it.name });
        }
        s.mode = "list";
        s.shown = list.map((i) => i.id);
        RPG.ui.open(p, "recipe_viewer", { title: "&6Recipes", width: 232, height: 214, elements: els, onClick: click });
    }

    function openRecipes(p, itemId, uses, fromHistory) {
        let s = st(p);
        let list = uses ? RPG.recipes.uses(itemId) : RPG.recipes.forItem(itemId);
        if (!list.length) { p.actionbar("&7" + RPG.items.name(itemId) + (uses ? " isn't used in any recipe." : " has no recipe (found, dropped or traded).")); return; }
        if (!fromHistory && s.mode === "recipe") s.history.push({ item: s.item, uses: s.uses });
        s.mode = "recipe"; s.item = itemId; s.uses = uses; s.recipes = list; s.idx = 0;
        drawRecipe(p);
    }

    // a machine recipe (RPG.recipes.addDisplay): its grid (up to 6x6), what else goes in, the machine, a note
    function drawStation(p, s, r, els) {
        let w = Math.max(1, Math.min(6, r.width || 3)), h = Math.max(1, Math.min(6, r.height || 1)), cell = 18;
        let gy = 50, gx = 8;
        for (let i = 0; i < w * h; i++) {
            let opts = r.ingredients[i] || [], x = gx + (i % w) * cell, y = gy + Math.floor(i / w) * cell;
            els.push({ type: "box", style: "slot", x: x - 1, y: y - 1, w: 18, h: 18 });
            if (opts.length) {
                let show = opts[Math.floor(RPG.server.getTick() / 20) % opts.length];
                s.slots.push(show);
                els.push({ type: "item", id: "g" + (s.slots.length - 1), item: show, x: x, y: y, tooltip: RPG.items.name(show) });
            }
        }
        let ex = r.extras || [], exX = gx + w * cell + 10;
        ex.forEach((e, i) => {
            let y = gy + i * 22, show = e.ingredients[Math.floor(RPG.server.getTick() / 20) % e.ingredients.length];
            els.push({ type: "box", style: "slot", x: exX - 1, y: y - 1, w: 18, h: 18 });
            s.slots.push(show);
            els.push({ type: "item", id: "g" + (s.slots.length - 1), item: show, count: e.count, x: exX, y: y,
                tooltip: RPG.items.name(show) + (e.label ? "\n&7" + e.label : "") });
            if (e.label) els.push({ type: "text", x: exX + 20, y: y + 5, text: "&8" + e.label, scale: 0.6 });
        });
        let rx = 196, ry = gy + Math.max(0, Math.floor((h * cell) / 2) - 9);
        els.push({ type: "text", x: rx - 18, y: ry + 3, text: "&f→", scale: 1.5 });
        els.push({ type: "box", style: "slot", x: rx - 2, y: ry - 2, w: 20, h: 20 });
        els.push({ type: "item", id: "res", item: r.result.id, count: r.result.count, x: rx, y: ry, tooltip: RPG.items.name(r.result.id) });
        if (r.stationItem) els.push({ type: "item", id: "stn", item: r.stationItem, x: rx, y: ry + 26, tooltip: r.station });
        let bottom = Math.max(gy + h * cell, gy + ex.length * 22);
        // the note, a sentence a line (the panel is narrow)
        let lines = r.note ? String(r.note).replace(/\.\s+/g, ".\n").split("\n") : [];
        lines.forEach((l, i) => els.push({ type: "text", x: 8, y: bottom + 4 + i * 9, text: "&7" + l, scale: 0.7 }));
        return bottom + 6 + lines.length * 9;
    }

    function drawRecipe(p) {
        let s = st(p), r = s.recipes[s.idx], els = [];
        if (r.type === "station") {
            els.push({ type: "text", x: 8, y: 22, text: (s.uses ? "&7Uses of &f" : "&7How to make &f") + RPG.items.name(s.item) });
            els.push({ type: "text", x: 8, y: 34, text: "&e" + r.station + "  &7(" + (s.idx + 1) + "/" + s.recipes.length + ")", scale: 0.75 });
            s.slots = [];
            let y = Math.max(150, drawStation(p, s, r, els) + 4);
            els.push({ type: "button", id: "rprev", x: 8, y: y, w: 30, h: 16, text: "<" });
            els.push({ type: "button", id: "rnext", x: 42, y: y, w: 30, h: 16, text: ">" });
            els.push({ type: "button", id: "back", x: 150, y: y, w: 74, h: 16, text: "Back" });
            RPG.ui.open(p, "recipe_viewer", { title: "&6Recipes", width: 232, height: y + 26, elements: els, onClick: click });
            return;
        }
        els.push({ type: "text", x: 8, y: 22, text: (s.uses ? "&7Uses of &f" : "&7How to make &f") + RPG.items.name(s.item) });
        els.push({ type: "text", x: 8, y: 34, text: "&e" + (TYPES[r.type] || r.type) + "  &7(" + (s.idx + 1) + "/" + s.recipes.length + ")", scale: 0.75 });
        s.slots = [];
        let grid = r.ingredients, crafting = r.type.indexOf("crafting") === 0;
        for (let i = 0; i < (crafting ? 9 : grid.length); i++) {
            let opts = grid[i] || [], x = 30 + (i % 3) * 24, y = 52 + Math.floor(i / 3) * 24;
            if (!crafting) { x = 30 + i * 24; y = 76; }
            els.push({ type: "box", style: "slot", x: x - 2, y: y - 2, w: 20, h: 20 });
            if (opts.length) {
                // several items fit (e.g. any planks): show them in turn
                let show = opts[Math.floor(RPG.server.getTick() / 20) % opts.length];
                s.slots.push(show);
                els.push({ type: "item", id: "g" + (s.slots.length - 1), item: show, x: x, y: y,
                    tooltip: RPG.items.name(show) + (opts.length > 1 ? "\n&7or " + (opts.length - 1) + " other" + (opts.length > 2 ? "s" : "") : "") });
            }
        }
        els.push({ type: "text", x: 112, y: 80, text: "&f→", scale: 1.5 });
        els.push({ type: "box", style: "slot", x: 140, y: 74, w: 20, h: 20 });
        els.push({ type: "item", id: "res", item: r.result.id, count: r.result.count, x: 142, y: 76, tooltip: RPG.items.name(r.result.id) });
        els.push({ type: "button", id: "rprev", x: 8, y: 150, w: 30, h: 16, text: "<" });
        els.push({ type: "button", id: "rnext", x: 42, y: 150, w: 30, h: 16, text: ">" });
        els.push({ type: "button", id: "back", x: 150, y: 150, w: 74, h: 16, text: "Back" });
        RPG.ui.open(p, "recipe_viewer", { title: "&6Recipes", width: 232, height: 176, elements: els, onClick: click });
    }

    function click(p, id, inputs) {
        let s = st(p), right = inputs._button === "right";
        if (s.mode === "list") {
            if (id === "q") { s.query = inputs.q || ""; s.page = 0; openList(p); }
            else if (id === "prev") { s.page--; openList(p); }
            else if (id === "next") { s.page++; openList(p); }
            else if (id === "held") { let h = p.getHeldStack(); if (h) openRecipes(p, h.id, right, false); else p.actionbar("&7Hold an item first."); }
            else if (id.charAt(0) === "i") { s.history = []; openRecipes(p, s.shown[parseInt(id.substring(1))], right, false); }
        } else {
            if (id === "rprev") { s.idx = (s.idx - 1 + s.recipes.length) % s.recipes.length; drawRecipe(p); }
            else if (id === "rnext") { s.idx = (s.idx + 1) % s.recipes.length; drawRecipe(p); }
            else if (id === "back") { let h = s.history.pop(); if (h) openRecipes(p, h.item, h.uses, true); else openList(p); }
            else if (id === "res") openRecipes(p, s.recipes[s.idx].result.id, right, false);
            else if (id === "stn") openRecipes(p, s.recipes[s.idx].stationItem, right, false);
            else if (id.charAt(0) === "g") openRecipes(p, s.slots[parseInt(id.substring(1))], right, false);
        }
    }

    RPG.on("playerLeave", (p) => { delete STATE[p.uuid]; delete CLIENT[p.uuid]; });

    // a named key: action key 15 (U) unless the world's base game uses 15 itself, then a free one (Controls shows which)
    RPG.keys.define("recipe_viewer", { slot: 15, name: "Recipe Viewer", defaultKey: "u", onPress(p) {
        let h = p.getHeldStack();
        if (client(p, { item: h ? h.id : "" })) return;
        let s = st(p); if (s.mode === "recipe" && s.item) drawRecipe(p); else openList(p);
    } });
    RPG.commands.register("recipes", {
        root: true, aliases: ["recipe", "jei"], description: "Look up recipes: /recipes [item | @category]",
        suggest(p, args) { return RPG.items.list(args[0] || "", 30).map((i) => i.id); },
        run(p, args) {
            if (!p) return;
            if (args.length && args[0].charAt(0) === "@") { if (!client(p, { category: args.join(" ").substring(1) })) p.tell("&7Categories need the recipe viewer's client part."); return; }
            if (args.length) { let id = args[0].indexOf(":") < 0 ? "minecraft:" + args[0] : args[0]; if (client(p, { item: id })) return; st(p).history = []; openRecipes(p, id, false, false); }
            else if (!client(p, { item: "" })) openList(p);
        }
    });
    RPG.commands.register("uses", { root: true, description: "What an item is used in: /uses <item>",
        run(p, args) {
            if (!p || !args.length) return;
            let id = args[0].indexOf(":") < 0 ? "minecraft:" + args[0] : args[0];
            if (!client(p, { item: id, uses: true })) openRecipes(p, id, true, false);
        } });
})();
