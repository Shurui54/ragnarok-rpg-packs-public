// =====================================================================================
//  Recipe Viewer (client script) - turns on the engine's JEI-style recipe viewer:
//  an item list beside every inventory and container screen (search: name, @mod or addon,
//  #tooltip/tag, $tag, %tab, -exclude, a|b), page arrows, bookmarks (A) down the left side,
//  cheat mode for operators (the wrench), and the recipes window (R recipes, U uses,
//  click / right-click an item, Backspace back, Escape out, "+" fills an open crafting grid).
//  Ctrl+O hides the item list. Keys: Options > Controls > Recipe Viewer.
// =====================================================================================
RPG.on("load", () => {
    RPG.recipes.enable();
    RPG.net.send("rv_hello", {});
});

// /recipes, /uses and the Recipe Viewer key from the server
RPG.net.on("rv_show", (d) => {
    let ok = true;
    if (d.category) ok = RPG.recipes.category(d.category);
    else if (!d.item) RPG.recipes.openInventory();
    else ok = d.uses ? RPG.recipes.uses(d.item) : RPG.recipes.show(d.item);
    if (!ok) RPG.chat("&7" + (d.item ? (d.uses ? "Nothing uses " : "No recipe makes ") + d.item + "." : "No such recipe category."));
});
