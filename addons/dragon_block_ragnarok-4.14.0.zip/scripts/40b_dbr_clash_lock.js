// =====================================================================================
//  40b_dbr_clash_lock.js - holding a player still for a clash (melee clash, beam clash)
// =====================================================================================
//  DragonMine Z freezes both sides of a struggle: a strike clash holds the fighters in place and
//  a beam clash keeps the shooters in their firing pose until it is decided. Here the server holds
//  the body (a 0.35-block leash back to the anchor, no velocity, no fall damage) and the
//  "dbr_clash_lock" effect switches off walking, jumping, attacks, item use, the action keys and
//  skills on both sides; the player's own game also blocks the movement keys and turning
//  (client/scripts/41_dbr_clash_lock.js), so neither fighter can move on their own screen either.
//  Locks are counted per reason ("melee", "beam") and always released: when the clash ends, on
//  death, on leaving, and a stale effect is cleared on joining.
//
//  Server -> client: "dbr_lock" {on: 1, yaw, pitch, use} | {on: 0}
// =====================================================================================
RPG.effects.define("dbr_clash_lock", { name: "&7Clash", color: "#AAAAAA", hidden: true,
    flags: ["noMove", "noJump", "noAttack", "noUse", "noKeys", "noSkills"] });

var DBR_LOCK = (function () {
    var LEASH = 0.35;
    var L = {};             // uuid -> { p, reasons: {reason: true}, at: {x, y, z} }

    function count(e) { var n = 0; for (var k in e.reasons) n++; return n; }
    /** Hold a player for a reason. opts: at {x, y, z} (default where they stand), yaw/pitch to face, use: keep right click (beam clash presses). */
    function lock(p, reason, opts) {
        if (!p) return;
        opts = opts || {};
        var e = L[p.uuid], first = !e;
        if (!e) e = L[p.uuid] = { p: p, reasons: {}, at: null };
        e.p = p;
        e.reasons[reason] = true;
        if (opts.at) e.at = { x: opts.at.x, y: opts.at.y, z: opts.at.z };
        else if (!e.at) e.at = { x: p.x, y: p.y, z: p.z };
        if (first) p.addEffect("dbr_clash_lock", -1);
        var msg = { on: 1, use: opts.use ? 1 : 0 };
        if (opts.yaw !== undefined) { msg.yaw = opts.yaw; msg.pitch = opts.pitch || 0; }
        if (first || opts.yaw !== undefined) RPG.net.send(p, "dbr_lock", msg);
        p.setVelocity(0, 0, 0);
    }
    function release(uuid, p) {
        delete L[uuid];
        if (!p) return;
        try { p.removeEffect("dbr_clash_lock"); RPG.net.send(p, "dbr_lock", { on: 0 }); } catch (err) { }
    }
    function unlock(p, reason) {
        if (!p) return;
        var e = L[p.uuid];
        if (!e) { if (p.hasEffect && p.hasEffect("dbr_clash_lock")) release(p.uuid, p); return; }
        delete e.reasons[reason];
        if (!count(e)) release(p.uuid, p);
    }
    function isLocked(p) { return !!p && !!L[p.uuid]; }
    function hold(p, at) {
        p.fallDistance = 0;
        var dx = p.x - at.x, dy = p.y - at.y, dz = p.z - at.z;
        if (dx * dx + dy * dy + dz * dz > LEASH * LEASH) p.teleport(at.x, at.y, at.z);
        if (p.speed > 0.01) p.setVelocity(0, 0, 0);
    }
    RPG.every(1, function () {
        for (var u in L) {
            var e = L[u], p = e.p;
            try {
                if (!p || !p.isConnected() || !p.isAlive()) { release(u, p && p.isConnected() ? p : null); continue; }
                hold(p, e.at);
            } catch (err) { delete L[u]; }
        }
    });
    RPG.on("death", function (p) { if (p && L[p.uuid]) release(p.uuid, p); });
    RPG.on("playerLeave", function (p) { if (p && L[p.uuid]) { delete L[p.uuid]; try { p.removeEffect("dbr_clash_lock"); } catch (err) { } } });
    RPG.on("playerJoin", function (p) { if (p && !L[p.uuid] && p.hasEffect("dbr_clash_lock")) release(p.uuid, p); });
    RPG.on("respawn", function (p) { if (p && !L[p.uuid] && p.hasEffect("dbr_clash_lock")) release(p.uuid, p); });

    return { lock: lock, unlock: unlock, isLocked: isLocked, anchor: function (p) { var e = p && L[p.uuid]; return e ? e.at : null; } };
})();
