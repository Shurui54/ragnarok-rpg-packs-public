// =====================================================================================
//  46_dmz_skills.js - DMZ skills (SkillsConfig) bought and upgraded with TP
// =====================================================================================
//  Levels live in the player var "dmz_skills" ({ fly: 3, kicontrol: 1, superforms: 2 }).
//  The skills screen (client/scripts/50_skills_screen.js) upgrades owned skills; masters
//  sell level 1 (DMZ_SKILLS.purchase). Rules from DMZ's UpdateSkillC2S.
//  Side effects so the rest of the addon keeps working:
//    potentialunlock -> var "dmz_potential" (power release cap, 09_dmz_stats.js)
//    ki/strike/evasion skills -> unlock the DMZ technique (41_dmz_techniques.js, with DMZ's pop-up);
//                                  instant_transmission / fusion / kaioken -> the matching skill in 40_skills.js
//    form skills -> learn the matching form from 30_forms.js as levels unlock it
// =====================================================================================
var DMZ_SKILLS = (function () {
    var SD = DMZ_SKILLS_DATA;

    function dmzRace(p) { return DMZ_DATA.DMZ[p.race] || p.race || "human"; }
    function android(p) { return !!p.getVar("dmz_android", 0); }
    function levels(p) { var v = p.getVar("dmz_skills", null); return v && typeof v === "object" ? v : {}; }
    // while fused the leader uses the fused levels (FusedData.skills: max of both, 64_dmz_fusion.js)
    function effective(p) { var f = p.getVar("dmz_fusion_skills", null); return f && typeof f === "object" ? f : levels(p); }
    function fusedBlock(p) { return !!p.getVar("dmz_fused", 0); }
    function owned(p, s) { return Object.prototype.hasOwnProperty.call(effective(p), s); }
    function level(p, s) { var v = effective(p)[s]; return typeof v === "number" ? v : 0; }

    // StatsData.updateTransformationSkillLimits: the race's form skills always exist (level 0)
    function ensureDefaults(p) {
        if (!p.getVar("dmz_created", 0)) return;
        var map = levels(p), changed = false;
        var added = [];
        SD.raceFormSkills(dmzRace(p), android(p)).forEach(function (s) {
            if (typeof map[s] !== "number") { map[s] = 0; added.push(s); }
        });
        if (!added.length) return;
        p.setVar("dmz_skills", map);
        added.forEach(function (s) { apply(p, s, 0); });      // forms unlocked at level 0 (Oozaru)
    }

    function learn(p, id) {
        if (id && RPG.skills.exists(id) && !p.hasSkill(id)) p.learnSkill(id);
    }

    // what owning a level means for the rest of the addon
    function apply(p, s, lvl, source) {
        if (s === "potentialunlock") p.setVar("dmz_potential", lvl);
        if (lvl >= 1 && SD.isTechnique(s) && typeof DMZ_TECH !== "undefined") DMZ_TECH.unlock(p, s, { source: source || "" });
        else if (lvl >= 1 && SD.TECHNIQUES[s]) learn(p, SD.TECHNIQUES[s]);
        if (SD.isForm(s) || SD.isStack(s)) {
            var race = SD.isStack(s) ? "stack" : dmzRace(p);
            (SD.FORM_TREES[race] || []).forEach(function (g) {
                if (g[1] !== s) return;
                g[2].forEach(function (f) { if (f[1] <= lvl) learn(p, SD.FORM_SKILL[race + "." + g[0] + "." + f[0]]); });
            });
        }
    }

    function setLevel(p, s, lvl, source) {
        var map = levels(p);
        map[s] = Math.max(0, Math.floor(lvl));
        p.setVar("dmz_skills", map);
        var fz = p.getVar("dmz_fusion_skills", null);
        if (fz && typeof fz === "object" && !(fz[s] >= map[s])) { fz[s] = map[s]; p.setVar("dmz_fusion_skills", fz); }
        apply(p, s, map[s], source);
        sendState(p);
    }

    function questDone(p, key) { return typeof DMZ_QUESTS !== "undefined" && DMZ_QUESTS && DMZ_QUESTS.isCompleted(p, key); }

    // FormRequisites (saga part): a form unlocked at targetLevel may need a saga quest first
    function formLock(p, s, targetLevel) {
        if (!SD.isForm(s)) return null;
        var lock = null;
        (SD.FORM_TREES[dmzRace(p)] || []).forEach(function (g) {
            if (g[1] !== s) return;
            g[2].forEach(function (f) { if (f[1] === targetLevel && f[3] && !questDone(p, f[3]) && !lock) lock = f[3]; });
        });
        return lock;
    }

    function msg(p, key, args) { RPG.net.send(p, "dmz_msg", { key: key, args: args || [], color: "#FF5555" }); }

    // UpdateSkillC2S UPGRADE
    function upgrade(p, s) {
        if (fusedBlock(p)) { msg(p, "message.dragonminez.fusion.action_blocked"); return false; }     // UpdateSkillC2S
        if (!owned(p, s)) return false;
        var lvl = level(p, s), race = dmzRace(p);
        if (lvl <= 0 && !SD.allowed(s, race, android(p))) return false;
        if (SD.isStack(s) && lvl <= 0) return false;
        var lock = formLock(p, s, lvl + 1);
        if (lock) { RPG.net.send(p, "dmz_msg", { key: "gui.dragonminez.skills.locked_until", args: [lock], color: "#FF5555", quest: lock }); return false; }
        var cost = SD.cost(s, lvl, race);
        if (lvl >= SD.maxLevel(s, race) || cost < 0 || p.getTp() < cost) return false;
        if (s === "potentialunlock" && lvl === 10) return false;
        p.setTp(p.getTp() - cost);
        setLevel(p, s, lvl + 1);
        return true;
    }

    // UpdateSkillC2S PURCHASE (a master must offer it; the caller checks the master is nearby)
    function offers(master, s) {
        var list = SD.OFFERINGS[String(master || "").toLowerCase()] || SD.OFFERINGS["default"];
        return list.indexOf(s) >= 0;
    }
    function purchase(p, s, master) {
        if (fusedBlock(p)) return false;
        var race = dmzRace(p);
        if (!SD.allowed(s, race, android(p)) && !SD.isTechnique(s)) return false;
        if (!offers(master, s)) return false;
        var price = SD.cost(s, 0, race);
        var notOwned = !owned(p, s) || (SD.isForm(s) && level(p, s) === 0);
        if (!notOwned || price < 0 || p.getTp() < price) return false;
        if (formLock(p, s, 1)) return false;
        p.setTp(p.getTp() - price);
        setLevel(p, s, 1, "master");
        return true;
    }

    function completedKeys(p) { return typeof DMZ_QUESTS !== "undefined" && DMZ_QUESTS ? DMZ_QUESTS.completedKeys(p) : []; }

    function sendState(p) {
        RPG.net.send(p, "dmz_skills_state", { skills: effective(p), race: dmzRace(p), android: android(p), done: completedKeys(p) });
    }

    function open(p) {
        ensureDefaults(p);
        sendState(p);
        RPG.net.send(p, "dmz_open_skills", {});
    }

    RPG.on("playerJoin", (p) => RPG.schedule(40, () => ensureDefaults(p)));
    RPG.on("raceChange", (p) => RPG.schedule(1, () => ensureDefaults(p)));

    RPG.net.on("dmz_skill", (p, d) => {
        if (!d || !p.getVar("dmz_created", 0)) return;
        let action = String(d.action || ""), s = String(d.skill || "").toLowerCase();
        if (action === "state") { ensureDefaults(p); sendState(p); }
        else if (action === "upgrade") {
            if (upgrade(p, s)) uiSfx(p, "dmzpack:pip_menu", 1, 1);
            else sendState(p);
        } else if (action === "bind") {
            // "Bind to Slot": DMZ's 8 technique slots (Alt/Ctrl + 1..4), 41_dmz_techniques.js
            if (typeof DMZ_TECH !== "undefined") DMZ_TECH.equip(p, d.slot, String(d.technique || ""));
        }
    });

    // ops: /rpgc dmzskill <skill> <level> [player]
    RPG.commands.register("dmzskill", {
        hidden: true,   // the old form, kept for existing setups; /rpgc skill is DMZ's command (98_dbr_commands.js)
        permission: 2, description: "/rpgc dmzskill <skill> <level> [player] - set a DMZ skill level",
        run(p, args) {
            let target = args[2] ? RPG.server.player(args[2]) : p;
            if (!target || !args[0]) return;
            setLevel(target, String(args[0]).toLowerCase(), Number(args[1]) || 0);
            if (p) p.tell("&a" + args[0] + " -> " + (Number(args[1]) || 0));
        }
    });

    return { levels: levels, level: level, owned: owned, setLevel: setLevel, upgrade: upgrade, purchase: purchase, offers: offers,
        ensureDefaults: ensureDefaults, sendState: sendState, open: open, race: dmzRace };
})();
