// =====================================================================================
//  09_dmz_stats.js - DMZ's stat rules on the server
// =====================================================================================
//  Health, ki, stamina, damage, defence, regeneration, power release, TP gains, stat prices
//  and level, all from DragonMine Z's formulas (shared/02_dmz_formulas.js).
// =====================================================================================

// ---- melee: DMZ replaces the hit with its STR formula (bare hands), weapons add on top --
function dmzMeleeDamage(e) {
    let p = e.attacker && e.attacker.isPlayer() ? e.attacker.asPlayer() : null;
    if (!p || e.kind !== "melee") return e.amount;
    let v = dmzView(p);
    let empty = p.getHeldStack() === null || !p.getHeldStack() || p.getHeldStack().id === "minecraft:air";
    // vanilla scales a hit by the attack cooldown; keep that share of DMZ's damage
    let share = Math.max(0.2, Math.min(1, e.amount / Math.max(0.0001, p.attribute("generic.attack_damage"))));
    let dmz = DMZ_F.melee(v) * share;
    // the combo step's multiplier (11_dmz_combat.js), then DMZ's stamina cost: short on stamina = weaker hit
    let step = DMZ_MELEE[p.uuid];
    if (step && RPG.server.getTick() - step.at < 20) dmz *= step.mult;
    let req = Math.ceil(DMZ_F.melee(v) * 0.083) * (Number(p.getVar("dmz_parried_until", 0)) > Date.now() ? 2 : 1);
    let ratio = 1;
    if (typeof dmzIsDead === "function" && dmzIsDead(p) && p.dimension === "ragnarok_rpg:otherworld") req = 0;   // DMZ: free while dead there
    if (req > 0) {
        let have = p.resource("stamina");
        if (have >= req) p.addResource("stamina", -req);
        else { ratio = Math.max(0, have / req); p.addResource("stamina", -have); }
    }
    dmz *= ratio;
    // a ki weapon out (79_dmz_kiweapon.js): its ki-scaled bonus, paid in ki
    if (empty && typeof DMZ_KIWEAPON !== "undefined") dmz += DMZ_KIWEAPON.meleeBonus(p, v);
    return empty ? dmz : e.amount + dmz - 1;
}

/** Per player, the last hit's defence / block mitigation this tick (DMZ's PlayerDamageMitigatedEvent): uuid -> {tick, def, block}. */
var DMZ_MITIGATION = {};

/** dmzTp(player, base, source): TP the DMZ way (set below). */
var DMZ_TP = null;

(function () {
    // ---- damage taken: DMZ's defence curve for players ---------------------------------
    RPG.on("damageFinal", (e) => {
        let t = e.target;
        if (!t || !t.isPlayer() || e.amount <= 0) return;
        if (e.kind === "fall" || e.type === "minecraft:out_of_world" || e.type === "minecraft:starve" || e.type === "minecraft:generic_kill") return;
        let before = e.amount;
        e.amount = DMZ_F.postMitigation(dmzView(t.asPlayer()), e.amount, 0);
        DMZ_MITIGATION[t.uuid] = { tick: RPG.server.getTick(), def: Math.max(0, before - e.amount), block: 0 };   // PlayerDamageMitigatedEvent (77_dmz_world_bosses.js)
    });

    // ---- prices and level --------------------------------------------------------------
    function classOf(p) { return DMZ_DATA.CLASSES[p.playerClass] || DMZ_DATA.CLASSES.warrior; }
    function boughtTotal(p) { return DMZ_F.total(dmzView(p)); }
    // overrides get the normal arguments, then the built-in result last
    RPG.override("statCost", (p, stat, current, builtIn) => DMZ_F.singleCost(boughtTotal(p), classOf(p).tpCost));
    RPG.override("statCostBulk", (p, stat, n, current, builtIn) => DMZ_F.cost(boughtTotal(p), n, classOf(p).tpCost));

    function refresh(p) {
        let v = dmzView(p);
        let lvl = DMZ_F.level(v);
        if (p.level !== lvl) p.setLevel(lvl, { silent: true });
        let hp = DMZ_F.maxHealth(v);
        if (Math.abs(p.maxHealth - hp) > 0.01) p.maxHealth = hp;
    }
    RPG.on("statAllocate", (p) => { p.refreshStats(); refresh(p); });

    // ---- once a second: maxima, regeneration, release cap, passive TP ---------------------
    var LAST = {};                // uuid -> {x, z, travel}
    RPG.every(20, () => {
        RPG.server.players().forEach((p) => {
            if (!p.getVar("dmz_created", 0) || !p.alive) return;
            refresh(p);
            let v = dmzView(p), food = DMZ_F.foodMult(p.food);
            // health
            if (p.health < p.maxHealth) p.heal(DMZ_F.hpRegen(v) * food);
            // ki: charging regenerates in 45_keys.js; otherwise DMZ's base regen
            // (no regen while sharing ki: KiShareService.onEnergyRegen, 64_dmz_kishare.js)
            if (!p.hasEffect("ki_charge") && !p.hasEffect("dmz_ki_sharing") && p.resource("ki") < p.maxResource("ki"))
                p.addResource("ki", Math.ceil(DMZ_F.kiRegen(v, false) * food * 100) / 100);
            // stamina: depends on what you're doing (DMZ actionMod)
            let mode = 1;
            if (p.hasEffect("flight") && p.sprinting) mode = 0;
            else if (p.blocking || p.swinging) mode = 0.5;
            else if (p.onGround && Math.abs(p.vx) + Math.abs(p.vz) < 0.01) mode = 2;
            else if (p.onGround) mode = 1.5;
            if (p.resource("stamina") < p.maxResource("stamina")) p.addResource("stamina", Math.ceil(DMZ_F.stmRegen(v, mode) * food));
            // power release: never above the cap; no ki, no release
            let rel = Number(p.getVar("dmz_release", 0)) || 0, max = DMZ_F.maxRelease(Number(p.getVar("dmz_potential", 0)), racialReleaseMult(p), p.getVar("dmzr_release_boost", 0));
            if (p.resource("ki") <= 1) rel = 0;
            if (rel > max) rel = max;
            if (rel !== Number(p.getVar("dmz_release", 0))) p.setVar("dmz_release", rel);
            // TP: passive every 5 s, travel every 20 blocks
            let st = LAST[p.uuid] || (LAST[p.uuid] = { x: p.x, z: p.z, travel: 0, t: 0 });
            let step = Math.sqrt((p.x - st.x) * (p.x - st.x) + (p.z - st.z) * (p.z - st.z));
            if (step < 200) st.travel += step;           // teleports don't count
            st.x = p.x; st.z = p.z;
            if (++st.t % 5 === 0) dmzTp(p, 1, "passive");
            while (st.travel >= 20) { st.travel -= 20; dmzTp(p, 1, "travel"); }
        });
    });

    function racialReleaseMult(p) { return p.race === "saiyan" ? 1 + Math.min(0.15, Number(p.getVar("dmz_zenkai_release", 0)) || 0) : 1; }

    // ---- TP gains (TPGainEvents): base x (1 + class bonus + progression + time chamber) ----
    function dmzTp(p, base, source) {
        let c = classOf(p), v = dmzView(p);
        let mult = 1 + (c.tpGain - 1) + (source !== "training" ? DMZ_F.progression(v) - 1 : 0);
        if (p.race === "frost_demon") mult += 0.25;                                  // prodigious strength
        if (p.dimension === "ragnarok_rpg:time_chamber") mult += 0.75;               // HTC x1.75
        if (typeof dmzOtherworldTpMult === "function") mult += dmzOtherworldTpMult(p) - 1;   // dead in the Other World: x2
        if (typeof dmzGravityTpBonus === "function") mult += dmzGravityTpBonus(p);           // gravity + weights (58_dmz_machines.js)
        let gain = Math.max(1, Math.floor(base * mult));
        if (typeof DBR_PRESTIGE !== "undefined") gain = Math.max(1, Math.floor(gain * DBR_PRESTIGE.tpMult(p)));   // prestige TP bonus (93_dbr_prestige.js)
        p.addTp(gain, { raw: true, events: false, source: source });
        if (typeof DMZ_FUSION !== "undefined") DMZ_FUSION.shareTp(p, gain);          // fused: half to the partner
    }
    // other scripts (quests, training) can give DMZ-style TP
    DMZ_TP = dmzTp;

    RPG.on("attack", (e) => {
        let p = e.attacker && e.attacker.isPlayer() ? e.attacker.asPlayer() : null;
        if (p && e.amount >= 1 && p.getVar("dmz_created", 0)) dmzTp(p, 2, "hit");
    });
    RPG.on("kill", (p, victim) => {
        if (!p.getVar("dmz_created", 0)) return;
        let base = 2 + Math.round(victim.maxHealth * 0.25);
        if (typeof DBR_KILL_TP === "function") base = DBR_KILL_TP(p, victim, base);   // NPC regions: anti-farm + level falloff (93_dbr_npc_regions.js)
        dmzTp(p, base, "kill");
    });
    RPG.on("blockBreak", (p) => { if (p.getVar("dmz_created", 0)) dmzTp(p, 1, "mined"); });
    RPG.on("craft", (p, item, count) => { if (p.getVar("dmz_created", 0)) dmzTp(p, Math.max(1, count), "crafted"); });

    // ---- buying stats from the stats screen ("+" with x1 / x10 / x100 / x1000) ------------
    RPG.net.on("dmz_buy", (p, d) => {
        let stat = DMZ_DATA.STAT_IDS[String(d && d.stat)];
        let n = Math.max(1, Math.min(1000, Math.floor(Number(d && d.n) || 1)));
        if (!stat || !p.getVar("dmz_created", 0)) return;
        // never buy past this character's cap (prestige widens it): TP spent above it used to be lost
        if (typeof DBR_ZSOUL !== "undefined" && DBR_ZSOUL.cap) {
            let room = Math.floor(DBR_ZSOUL.cap(p) - p.baseStat(stat));
            if (room <= 0) { p.actionbar("&eThat stat is at its cap."); return; }
            n = Math.min(n, room);
        }
        let before = p.stat(stat);
        p.buyStat(stat, n);
        let gained = p.stat(stat) - before;
        if (gained > 0) {
            if (stat === "resistance") RPG.schedule(1, () => p.addResource("stamina", DMZ_F.S(dmzView(p), "STM") * gained));
            if (stat === "energy") RPG.schedule(1, () => p.addResource("ki", DMZ_F.S(dmzView(p), "ENE") * gained));
            uiSfx(p, "dmzpack:pip_menu", 1, 1);
        }
        refresh(p);
    });

    // first stats after creation: the class base points (DMZ: "if all stats are 0, set them to the class base")
    RPG.on("classChange", (p) => RPG.schedule(1, () => refresh(p)));
})();
