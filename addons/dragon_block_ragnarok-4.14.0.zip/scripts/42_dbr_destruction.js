// =====================================================================================
//  42_dbr_destruction.js - ki attacks destroy terrain, and the terrain grows back
// =====================================================================================
//  Port of DMZ's ki-griefing gamerules (allowKiGriefingPlayers / allowKiGriefingMobs) on top
//  of the engine's RPG.world.destroy + regeneration. Ki blasts (41_dmz_techniques.js burst())
//  carve a crater; after `regenSeconds` the crater heals bottom-up, outside-in, without
//  touching anything players built there since. Land claims protect blocks through the
//  "explode" event like any explosion. Settings: ragnarok_rpg/config/dbr_destruction.json
//  or /rpg config dbr_destruction.
// =====================================================================================
var DBR_DESTRUCTION_CFG = RPG.config.define("dbr_destruction", {
    enabled:          { default: true, comment: "Ki attacks destroy terrain" },
    players:          { default: true, comment: "Players' ki attacks destroy terrain (DMZ allowKiGriefingPlayers)" },
    mobs:             { default: true, comment: "Mobs' and bosses' ki attacks destroy terrain (DMZ allowKiGriefingMobs)" },
    regenSeconds:     { default: 60, min: 0, max: 86400, comment: "Seconds before destroyed terrain grows back (0 = never)" },
    regenSpeed:       { default: 300, min: 1, max: 20000, integer: true, comment: "Blocks per second each crater heals" },
    maxBlocksPerBlast:{ default: 6000, min: 0, max: 50000, integer: true, comment: "Most blocks one blast removes" },
    radiusMultiplier: { default: 1.0, min: 0, max: 5, comment: "Crater radius = blast radius x this" },
    maxRadius:        { default: 14, min: 1, max: 48, comment: "Largest crater radius" },
    protectPlayerBuilt:{ default: true, comment: "Never destroy blocks players placed" },
    fire:             { default: 0.04, min: 0, max: 1, comment: "Chance for scorched ground to catch fire" },
    healExplosions:   { default: false, comment: "Also heal vanilla explosions (TNT, creepers) after regenSeconds" }
});

var DBR_DESTRUCTION = (function () {
    var C = DBR_DESTRUCTION_CFG;
    function apply() {
        RPG.world.regen.settings({
            speed: C.get("regenSpeed"),
            trackPlaced: C.get("protectPlayerBuilt"),
            explosions: C.get("healExplosions"),
            explosionDelay: Math.max(1, C.get("regenSeconds"))
        });
    }
    apply();
    C.onChange(apply);

    function blast(owner, x, y, z, r, big) {
        if (!C.get("enabled") || !owner) return 0;
        var isPlayer = false;
        try { isPlayer = owner.isPlayer(); } catch (e) { }
        if (isPlayer ? !C.get("players") : !C.get("mobs")) return 0;
        var max = C.get("maxBlocksPerBlast");
        if (max <= 0) return 0;
        var rad = Math.min(C.get("maxRadius"), Number(r || 2.5) * C.get("radiusMultiplier") * (big ? 1.15 : 1));
        if (rad < 1) return 0;
        return RPG.world.destroy(owner.dimension, { type: "crater", x: x, y: y, z: z, r: rad, depth: 0.75 }, {
            regen: C.get("regenSeconds"), drops: false, fire: C.get("fire"), debris: 3, scorch: true,
            protectPlaced: C.get("protectPlayerBuilt"), maxBlocks: max, maxResistance: 1000
        }, owner);
    }

    var EAT_BUDGET = 400;
    function allowed(owner) {
        if (!C.get("enabled") || !owner || C.get("maxBlocksPerBlast") <= 0) return false;
        var isPlayer = false;
        try { isPlayer = owner.isPlayer(); } catch (e) { }
        return isPlayer ? C.get("players") : C.get("mobs");
    }
    function opts() {
        return { regen: C.get("regenSeconds"), drops: false, protectPlaced: C.get("protectPlayerBuilt"), maxBlocks: C.get("maxBlocksPerBlast"), maxResistance: 1000 };
    }
    // KiTerrainDestruction.eat: a ball or a beam's tip eats a clean sphere out of the terrain as it goes (no crater, no debris)
    function eat(owner, x, y, z, r) {
        if (!allowed(owner)) return 0;
        var rad = Math.min(C.get("maxRadius"), Number(r || 1) * C.get("radiusMultiplier"));
        if (rad < 0.75) return 0;
        // at most EAT_BUDGET blocks a call: a beam's tip moves ~1 block a tick, so the next spheres (mostly overlapping)
        // finish what one call left, like DMZ's terrain jobs spread over ticks, and no tick pays for a whole sphere
        var o = opts();
        o.maxBlocks = Math.min(o.maxBlocks, EAT_BUDGET);
        return RPG.world.destroy(owner.dimension, { type: "sphere", x: Math.floor(x), y: Math.floor(y), z: Math.floor(z), r: rad }, o, owner);
    }
    // KiTerrainDestruction.slice: a disk cuts a thin slab as wide as itself along its path
    function slice(owner, x1, y1, z1, x2, y2, z2, r) {
        if (!allowed(owner)) return 0;
        var rad = Math.min(C.get("maxRadius"), Number(r || 1) * C.get("radiusMultiplier"));
        if (rad < 0.75) return 0;
        var dx = x2 - x1, dz = z2 - z1, l = Math.sqrt(dx * dx + dz * dz);
        var lx = l > 1e-3 ? -dz / l : 1, lz = l > 1e-3 ? dx / l : 0, n = 0;
        for (var o = -rad; o <= rad + 1e-6; o += 1) {
            n += RPG.world.destroy(owner.dimension, { type: "line", x1: x1 + lx * o, y1: y1, z1: z1 + lz * o, x2: x2 + lx * o, y2: y2, z2: z2 + lz * o, r: 0.6 }, opts(), owner);
        }
        return n;
    }

    return { blast: blast, eat: eat, slice: slice, config: C };
})();

RPG.commands.register("dbrregen", {
    description: "Terrain regeneration: /rpgc dbrregen [now|forget|status]",
    permission: 2,
    run(p, args) {
        var dim = p ? p.dimension : "", sub = String(args[0] || "status");
        if (sub === "now") p.tell("&aHealing " + RPG.world.regen.now(dim) + " damaged areas now.");
        else if (sub === "forget") p.tell("&e" + RPG.world.regen.forget(dim) + " damaged areas will stay destroyed.");
        else p.tell("&7Waiting to heal here: &f" + RPG.world.regen.pending(dim) + "&7 blocks in &f" + RPG.world.regen.areas(dim) + "&7 areas.");
    }
});
