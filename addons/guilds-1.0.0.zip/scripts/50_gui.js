// =====================================================================================
//  Guilds - the screens (drawn in the toolkit's menu art, like every RPG.ui screen).
//  /guild opens a tabbed panel: Info, Members, Relations, Flags, Perms, Warps, Map.
//  Without a guild it shows invites, open guilds and a "found a guild" box. /guild admin opens
//  the admin list. Every button calls the same action the matching /guild command runs, then
//  redraws the screen in place.
// =====================================================================================

var GLD_W = 300, GLD_H = 260, GLD_FOOT = 236;
var GLD_VIEW = {};   // uuid -> {tab, page, map: {x, z, scale}, area, auto}
var GLD_CONFIRM = {};
var GLD_TABS = [["info", "Info", 28], ["members", "Members", 46], ["relations", "Relations", 52], ["flags", "Flags", 34],
    ["perms", "Perms", 36], ["warps", "Warps", 36], ["map", "Map", 30]];

function gldView(p) { return GLD_VIEW[p.uuid] || (GLD_VIEW[p.uuid] = { tab: "info", page: 0, map: null, area: null }); }

/** True on the second click of the same dangerous button within 4 seconds. */
function gldConfirm(p, key, what) {
    let c = GLD_CONFIRM[p.uuid], now = Date.now();
    if (c && c.key === key && now - c.at < 4000) { delete GLD_CONFIRM[p.uuid]; return true; }
    GLD_CONFIRM[p.uuid] = { key: key, at: now };
    p.actionbar("&eClick again to " + what + ".");
    return false;
}

/** Build and open (or update in place) the guild screen. build(ui) adds elements. */
function gldScreen(p, title, build) {
    let els = [], fns = {}, n = 0;
    let merge = (e, opt) => { if (opt) Object.keys(opt).forEach((k) => { e[k] = opt[k]; }); els.push(e); return e; };
    let ui = {
        text: (x, y, text, opt) => merge({ type: "text", x: x, y: y, text: String(text) }, opt),
        small: (x, y, text, opt) => merge({ type: "text", x: x, y: y, text: String(text), scale: 0.75 }, opt),
        button: (x, y, w, h, text, fn, opt) => { let id = "b" + (n++); fns[id] = fn; return merge({ type: "button", id: id, x: x, y: y, w: w, h: h, text: String(text) }, opt); },
        input: (id, x, y, w, h, hint, max) => merge({ type: "input", id: id, x: x, y: y, w: w, h: h, hint: hint, maxLength: max || 32, value: "", reset: true }),
        box: (x, y, w, h, opt) => merge({ type: "box", x: x, y: y, w: w, h: h }, opt),
        map: (spec, fn) => { fns.map = fn; spec.type = "map"; spec.id = "map"; els.push(spec); },
        close: () => ui.button(GLD_W - 62, GLD_FOOT, 50, 16, "Close", () => {}, { close: true })
    };
    build(ui);
    RPG.ui.open(p, "guilds", { title: title, width: GLD_W, height: GLD_H, elements: els,
        onClick(pl, id, inputs) { let f = fns[id]; if (f) f(pl, inputs || {}); },
        onClose(pl) { let v = GLD_VIEW[pl.uuid]; if (v) v.area = null; } });
}

/** Open the guild screen on a tab (null = the last one). */
function gldOpen(p, tab) {
    let g = gldOf(p), v = gldView(p);
    if (tab) { if (v.tab !== tab) v.page = 0; v.tab = tab; }
    if (!g) { gldOpenNone(p); return; }
    gldScreen(p, g.color + g.name + " &7(" + gldTitle(gldRole(g, p.uuid)) + ")", (ui) => {
        let x = 10;
        GLD_TABS.forEach((t) => {
            ui.button(x, 22, t[2], 14, t[1], (pl) => gldOpen(pl, t[0]), { enabled: v.tab !== t[0] });
            x += t[2] + 3;
        });
        let build = { members: gldTabMembers, relations: gldTabRelations, flags: gldTabFlags, perms: gldTabPerms, warps: gldTabWarps, map: gldTabMap }[v.tab] || gldTabInfo;
        build(ui, p, g, v);
        ui.close();
    });
}
function gldRedo(fn) { return (pl, inputs) => { fn(pl, inputs); gldOpen(pl, null); }; }
function gldPager(ui, v, count, per, x, y) {
    let pages = Math.max(1, Math.ceil(count / per));
    v.page = Math.max(0, Math.min(v.page, pages - 1));
    if (pages <= 1) return;
    ui.button(x, y, 16, 16, "<", (pl) => { v.page--; gldOpen(pl, null); }, { enabled: v.page > 0 });
    ui.small(x + 20, y + 5, (v.page + 1) + "/" + pages);
    ui.button(x + 38, y, 16, 16, ">", (pl) => { v.page++; gldOpen(pl, null); }, { enabled: v.page < pages - 1 });
}

// ---- Info -----------------------------------------------------------------------------------

function gldTabInfo(ui, p, g, v) {
    let y = 44, line = (t) => { ui.text(12, y, t); y += 12; };
    line("&7Leader: &f" + gldName(g, g.leader));
    line("&7Members: &f" + Object.keys(g.members).length + " / " + GLD_CFG.get("maxMembers"));
    line("&7Power: &f" + Math.round(gldPower(g)).toLocaleString());
    line("&7Claims: &f" + g.claims.length + " / " + gldMaxClaims(g) + (gldOverclaimable(g) ? " &c(overclaimable!)" : ""));
    line("&7Bank: &f" + gldMoney(g.bank));
    line("&7Access: " + (g.open ? "&aopen" : "&einvite-only"));
    line("&7Home: " + (g.home ? "&aset" : "&7not set"));
    line("&7Tag: &8[" + g.color + g.tag + "&8]");
    line("&7Chat: &f" + (GLD_CHANNEL[p.uuid] || "public"));
    if (g.motd) { ui.text(12, y, "&7MOTD: &f" + g.motd, { w: 176 }); y += 22; }
    if (g.description) ui.text(12, y, "&8" + g.description, { w: 176 });

    let bx = GLD_W - 12 - 92, by = 44, b = (label, fn, opt) => { ui.button(bx, by, 92, 14, label, gldRedo(fn), opt); by += 16; };
    let can = (perm) => gldCan(g, p.uuid, perm);
    b("Claim chunk", (pl) => gldClaim(pl, pl.dimension, gldChunkOf(pl.x), gldChunkOf(pl.z), false), { enabled: can("claim") });
    b("Unclaim chunk", (pl) => gldUnclaim(pl, pl.dimension, gldChunkOf(pl.x), gldChunkOf(pl.z), false), { enabled: can("unclaim") });
    b("Set home", gldActSetHome, { enabled: can("sethome") });
    b("Go home", gldActHome, { enabled: can("home") && !!g.home });
    b(g.open ? "Make invite-only" : "Make open", gldActOpen, { enabled: can("info") });
    b("Chat: " + gldTitle(GLD_CHANNEL[p.uuid] || "public"), (pl) => gldActChannel(pl, ""), { tooltip: "Public > Guild > Ally" });
    ui.small(bx, by + 2, "&7Bank amount");
    ui.input("amount", bx, by + 10, 92, 14, "e.g. 100", 12);
    ui.button(bx, by + 26, 45, 14, "Deposit", gldRedo((pl, i) => gldActDeposit(pl, i.amount)), { enabled: can("deposit") });
    ui.button(bx + 47, by + 26, 45, 14, "Withdraw", gldRedo((pl, i) => gldActWithdraw(pl, i.amount)), { enabled: can("withdraw") });

    let leader = g.leader === p.uuid, alone = Object.keys(g.members).length === 1;
    ui.button(12, GLD_FOOT, 80, 16, leader && alone ? "&cDisband" : "Leave guild", (pl) => {
        if (!gldConfirm(pl, "leave", leader && alone ? "disband the guild" : "leave the guild")) return;
        let gg = gldOf(pl);
        if (gg && gg.leader === pl.uuid && Object.keys(gg.members).length === 1 && gg.bank > 0) pl.addMoney(gg.bank);
        gldActLeave(pl);
        gldOpen(pl, null);
    }, { enabled: !leader || alone, tooltip: leader && !alone ? "Hand leadership over first: /guild leader <player>" : "" });
    ui.button(96, GLD_FOOT, 50, 16, "Top", (pl) => gldOpenTop(pl, "power"));
    if (gldHas(p, "guilds.admin")) ui.button(150, GLD_FOOT, 50, 16, "Admin", (pl) => gldOpenAdmin(pl, 0));
}

// ---- Members --------------------------------------------------------------------------------

function gldTabMembers(ui, p, g, v) {
    let on = {};
    gldOnline(g).forEach((q) => { on[q.uuid] = true; });
    let rows = Object.keys(g.members).sort((a, b) => gldRank(gldRole(g, b)) - gldRank(gldRole(g, a)) || gldName(g, a).localeCompare(gldName(g, b)))
        .map((u) => ({ u: u, invite: false })).concat(g.invites.map((u) => ({ u: u, invite: true })));
    let per = 12, mine = gldRank(gldRole(g, p.uuid));
    gldPager(ui, v, rows.length, per, 180, GLD_FOOT);
    rows.slice(v.page * per, v.page * per + per).forEach((r, i) => {
        let y = 44 + i * 15, name = gldName(g, r.u);
        if (r.invite) {
            ui.text(12, y + 3, "&8● &7" + name + " &8(invited)");
            ui.button(GLD_W - 12 - 50, y, 50, 13, "Cancel", gldRedo((pl) => gldActDeinvite(pl, name)), { enabled: gldCan(g, p.uuid, "invite") });
            return;
        }
        let role = gldRole(g, r.u), rank = gldRank(role);
        ui.text(12, y + 3, (on[r.u] ? "&a● " : "&8● ") + "&f" + name + " &7- " + gldTitle(role) + (g.memberPerms[r.u] ? " &8*" : ""));
        if (r.u === p.uuid || rank >= mine) return;
        let right = GLD_W - 12;
        ui.button(right - 32, y, 32, 13, "Kick", (pl) => { if (gldConfirm(pl, "kick" + r.u, "kick " + name)) { gldActKick(pl, name); gldOpen(pl, null); } }, { enabled: gldCan(g, p.uuid, "kick") });
        ui.button(right - 50, y, 16, 13, "-", gldRedo((pl) => gldActRank(pl, name, -1)), { enabled: gldCan(g, p.uuid, "setrole") && rank > 0, tooltip: "Demote" });
        ui.button(right - 68, y, 16, 13, "+", gldRedo((pl) => gldActRank(pl, name, 1)), { enabled: gldCan(g, p.uuid, "setrole") && rank + 1 < mine && rank + 1 < 3, tooltip: "Promote" });
        if (g.leader === p.uuid) ui.button(right - 104, y, 34, 13, "Lead", (pl) => { if (gldConfirm(pl, "lead" + r.u, "make " + name + " the leader")) { gldActLeader(pl, name); gldOpen(pl, null); } }, { tooltip: "Make leader" });
    });
    ui.input("who", 12, GLD_FOOT, 112, 16, "player to invite", 16);
    ui.button(128, GLD_FOOT, 48, 16, "Invite", gldRedo((pl, i) => gldActInvite(pl, String(i.who || "").trim())), { enabled: gldCan(g, p.uuid, "invite") });
}

// ---- Relations ------------------------------------------------------------------------------

function gldTabRelations(ui, p, g, v) {
    let rows = gldAll().filter((o) => o !== g && (g.relations[o.id] || o.relations[g.id]));
    let per = 9;
    if (!rows.length) ui.text(12, 46, "&7No declared relations.");
    gldPager(ui, v, rows.length, per, 228, 196);
    rows.slice(v.page * per, v.page * per + per).forEach((o, i) => {
        let y = 44 + i * 16, r = gldRelation(g, o);
        ui.text(12, y, GLD_REL_COLOR[r] + o.name + " &8[" + o.tag + "] &7= " + GLD_REL_COLOR[r] + gldTitle(r) + (r === "ENEMY" && gldOverclaimable(o) ? " &6(overclaimable)" : ""));
        ui.small(12, y + 9, "&7you: &f" + gldTitle(gldDeclared(g, o)) + "  &7them: &f" + gldTitle(gldDeclared(o, g)));
    });
    let can = gldCan(g, p.uuid, "relation");
    ui.small(12, 200, "&7Ally and truce need both guilds to agree; one enemy declaration is enough.", { w: 210 });
    ui.input("guild", 12, 216, 160, 16, "guild name", 32);
    [["Ally", "ALLY", 44], ["Enemy", "ENEMY", 46], ["Truce", "TRUCE", 44], ["Neutral", "NEUTRAL", 50]].reduce((x, b) => {
        ui.button(x, GLD_FOOT, b[2], 16, b[0], gldRedo((pl, i) => gldActRelation(pl, String(i.guild || "").trim(), b[1])), { enabled: can });
        return x + b[2] + 3;
    }, 12);
}

// ---- Flags ----------------------------------------------------------------------------------

function gldTabFlags(ui, p, g, v) {
    let can = gldCan(g, p.uuid, "flag");
    GLD_FLAGS.forEach((f, i) => {
        let y = 46 + i * 24;
        ui.text(12, y, "&f" + f + ": " + (g.flags[f] ? "&aON" : "&cOFF"));
        ui.small(12, y + 11, "&7" + GLD_FLAG_INFO[f]);
        ui.button(GLD_W - 12 - 86, y, 42, 14, "On", gldRedo((pl) => gldActFlag(pl, f, true)), { enabled: can && !g.flags[f] });
        ui.button(GLD_W - 12 - 42, y, 42, 14, "Off", gldRedo((pl) => gldActFlag(pl, f, false)), { enabled: can && !!g.flags[f] });
    });
    if (!can) ui.small(12, 176, "&8Your rank can't change flags.");
}

// ---- Permissions (rank matrix) --------------------------------------------------------------

function gldTabPerms(ui, p, g, v) {
    let leader = g.leader === p.uuid, cw = 30, gap = 4, gx = GLD_W - 12 - (4 * cw + 3 * gap), per = 12;
    GLD_ROLES.forEach((r, c) => ui.small(gx + c * (cw + gap) + 2, 44, "&e" + gldTitle(r)));
    gldPager(ui, v, GLD_PERMS.length, per, 180, GLD_FOOT);
    GLD_PERMS.slice(v.page * per, v.page * per + per).forEach((perm, i) => {
        let y = 56 + i * 14;
        ui.text(12, y + 3, "&f" + perm);
        GLD_ROLES.forEach((r, c) => {
            let on = r === "LEADER" || g.rolePerms[r].indexOf(perm) >= 0;
            ui.button(gx + c * (cw + gap), y, cw, 12, on ? "&aON" : "&cOFF", gldRedo((pl) => gldActPerm(pl, r, perm, !on)),
                { enabled: leader && r !== "LEADER", tooltip: GLD_PERM_INFO[perm] });
        });
    });
    ui.small(12, GLD_FOOT + 5, leader ? "&7Click to toggle" : "&8Only the leader edits these");
}

// ---- Warps ----------------------------------------------------------------------------------

function gldTabWarps(ui, p, g, v) {
    let right = GLD_W - 12;
    ui.text(12, 47, "&fHome &7" + (g.home ? Math.floor(g.home.x) + ", " + Math.floor(g.home.y) + ", " + Math.floor(g.home.z) : "not set"));
    ui.button(right - 44, 44, 44, 14, "Set", gldRedo(gldActSetHome), { enabled: gldCan(g, p.uuid, "sethome"), tooltip: "Set the guild home where you stand" });
    ui.button(right - 92, 44, 44, 14, "Go", gldRedo(gldActHome), { enabled: !!g.home && gldCan(g, p.uuid, "home") });
    let names = Object.keys(g.warps).sort(), per = 9;
    if (!names.length) ui.text(12, 70, "&7No guild warps set.");
    gldPager(ui, v, names.length, per, 180, 216);
    names.slice(v.page * per, v.page * per + per).forEach((name, i) => {
        let y = 66 + i * 16, w = g.warps[name];
        ui.text(12, y + 3, "&f" + name + " &8" + Math.floor(w.x) + ", " + Math.floor(w.y) + ", " + Math.floor(w.z));
        ui.button(right - 44, y, 44, 14, "Del", (pl) => { if (gldConfirm(pl, "delwarp" + name, "delete " + name)) { gldActDelWarp(pl, name); gldOpen(pl, null); } }, { enabled: gldCan(g, p.uuid, "setwarp") });
        ui.button(right - 92, y, 44, 14, "Warp", gldRedo((pl) => gldActWarp(pl, name)), { enabled: gldCan(g, p.uuid, "warp") });
    });
    ui.small(12, 220, "&7" + names.length + " / " + GLD_CFG.get("teleport.maxWarps") + " warps");
    ui.input("warp", 12, GLD_FOOT, 112, 16, "new warp name (here)", 16);
    ui.button(128, GLD_FOOT, 48, 16, "Set", gldRedo((pl, i) => gldActSetWarp(pl, String(i.warp || "").trim())), { enabled: gldCan(g, p.uuid, "setwarp") });
}

// ---- Map ------------------------------------------------------------------------------------

function gldTabMap(ui, p, g, v) {
    let m = v.map || (v.map = { x: Math.floor(p.x), z: Math.floor(p.z), scale: 1 });
    let S = 180, half = S * m.scale / 2, overlays = [];
    let minCx = (m.x - half) >> 4, maxCx = (m.x + half) >> 4, minCz = (m.z - half) >> 4, maxCz = (m.z + half) >> 4;
    let lc = typeof LandClaims !== "undefined" && LandClaims ? LandClaims : null;
    for (let cx = minCx; cx <= maxCx; cx++) for (let cz = minCz; cz <= maxCz; cz++) {
        let o = gldOwnerOf(p.dimension, cx, cz), box = { x1: cx * 16, z1: cz * 16, x2: cx * 16 + 15, z2: cz * 16 + 15 };
        if (o) {
            let r = gldRelation(g, o);
            box.color = GLD_REL_MAP_COLOR[r];
            box.label = GLD_REL_COLOR[r] + o.name + (r === "SELF" ? "" : " &7(" + gldTitle(r) + ")");
            overlays.push(box);
        } else if (lc) {
            let who = lc.ownerOfChunk(p.dimension, cx, cz);
            if (who) { box.color = "#505566FF"; box.label = "&9Land claim: &f" + who.name; overlays.push(box); }
        }
    }
    if (v.area) overlays.push({ x1: v.area.cx * 16, z1: v.area.cz * 16, x2: v.area.cx * 16 + 15, z2: v.area.cz * 16 + 15, color: "#90FFD34D", label: "&eArea corner" });
    ui.map({ x: 10, y: 42, w: S, h: S, centerX: m.x, centerZ: m.z, scale: m.scale, grid: 16, overlays: overlays,
        markers: [{ x: p.x, z: p.z, color: "#FFFFFF", label: "You" }] }, (pl, i) => {
        let cx = Math.floor(Number(i._x)) >> 4, cz = Math.floor(Number(i._z)) >> 4;
        if (String(i._button) === "right") gldUnclaim(pl, pl.dimension, cx, cz, false);
        else if (v.area && v.area.dim === pl.dimension) { let a = v.area; v.area = null; gldClaimArea(pl, pl.dimension, a.cx, a.cz, cx, cz); }
        else if (v.area !== null && v.area !== undefined) { v.area = { dim: pl.dimension, cx: cx, cz: cz }; }
        else gldClaim(pl, pl.dimension, cx, cz, false);
        gldOpen(pl, null);
    });
    ui.small(10, 225, "&7Left-click: claim   Right-click: unclaim");

    let bx = 198, step = Math.round(64 * m.scale), y = 44;
    ui.text(bx, y, "&fClaims &a" + g.claims.length + "&7/" + gldMaxClaims(g)); y += 14;
    [["SELF", "Your guild"], ["ALLY", "Ally"], ["TRUCE", "Truce"], ["NEUTRAL", "Neutral"], ["ENEMY", "Enemy"]].forEach((r) => { ui.small(bx, y, GLD_REL_COLOR[r[0]] + "■ &7" + r[1]); y += 9; });
    if (lc) { ui.small(bx, y, "&9■ &7Land claim"); y += 9; }
    y += 4;
    let pan = (dx, dz) => (pl) => { m.x += dx * step; m.z += dz * step; gldOpen(pl, null); };
    ui.button(bx + 30, y, 26, 14, "^", pan(0, -1)); y += 16;
    ui.button(bx, y, 26, 14, "<", pan(-1, 0));
    ui.button(bx + 30, y, 26, 14, "o", (pl) => { m.x = Math.floor(pl.x); m.z = Math.floor(pl.z); gldOpen(pl, null); }, { tooltip: "Centre on you" });
    ui.button(bx + 60, y, 26, 14, ">", pan(1, 0)); y += 16;
    ui.button(bx + 30, y, 26, 14, "v", pan(0, 1)); y += 18;
    ui.button(bx, y, 42, 14, "Zoom +", (pl) => { m.scale = Math.max(0.5, m.scale / 2); gldOpen(pl, null); });
    ui.button(bx + 44, y, 42, 14, "Zoom -", (pl) => { m.scale = Math.min(4, m.scale * 2); gldOpen(pl, null); }); y += 18;
    let areaOn = v.area !== null && v.area !== undefined;
    ui.button(bx, y, 86, 14, areaOn ? (v.area ? "&eArea: corner 2" : "&eArea: corner 1") : "Area claim", (pl) => { v.area = areaOn ? null : false; gldOpen(pl, null); },
        { enabled: gldCan(g, p.uuid, "claim"), tooltip: "Click two opposite corners on the map to claim the whole rectangle" }); y += 16;
    ui.button(bx, y, 86, 14, GLD_AUTOCLAIM[p.uuid] ? "&aAuto-claim: on" : "Auto-claim: off", (pl) => { GLD_SUB.autoclaim.run(pl, ["autoclaim"]); gldOpen(pl, null); },
        { enabled: gldCan(g, p.uuid, "claim"), tooltip: "Claim each chunk you walk into" });
}

// ---- Without a guild: invites, open guilds, found one ---------------------------------------

function gldOpenNone(p) {
    let v = gldView(p);
    gldScreen(p, "&aGuilds", (ui) => {
        ui.text(12, 24, "&7You are not in a guild.");
        let invited = gldAll().filter((o) => o.invites.indexOf(p.uuid) >= 0);
        let open = gldAll().filter((o) => o.open && invited.indexOf(o) < 0).sort((a, b) => gldPower(b) - gldPower(a));
        let rows = invited.map((o) => ({ g: o, invite: true })).concat(open.map((o) => ({ g: o, invite: false })));
        if (!rows.length) ui.text(12, 40, "&8No invites and no open guilds yet. Found your own below.", { w: 270 });
        let per = 10;
        gldPager(ui, v, rows.length, per, 230, 196);
        rows.slice(v.page * per, v.page * per + per).forEach((r, i) => {
            let y = 38 + i * 15, o = r.g, full = Object.keys(o.members).length >= GLD_CFG.get("maxMembers");
            ui.text(12, y + 3, "&8[" + o.color + o.tag + "&8] &f" + o.name + " &7" + Object.keys(o.members).length + " members" + (r.invite ? " &a(invited you)" : " &7(open)"));
            ui.button(GLD_W - 12 - 46, y, 46, 13, "Join", (pl) => { gldActJoin(pl, o.name); gldOpen(pl, "info"); }, { enabled: !full, tooltip: full ? "That guild is full" : "" });
        });
        let cost = GLD_CFG.get("creationCost");
        ui.small(12, 204, "&7Found a guild" + (cost > 0 ? " &8(costs " + gldMoney(cost) + ")" : "") + ":");
        ui.input("name", 12, 214, 170, 16, "guild name (" + GLD_CFG.get("nameMinLength") + "-" + GLD_CFG.get("nameMaxLength") + " characters)", GLD_CFG.get("nameMaxLength"));
        ui.button(186, 214, 50, 16, "Create", (pl, i) => { let g = gldCreate(pl, String(i.name || "").trim()); gldOpen(pl, g ? "info" : null); }, { enabled: gldHas(p, "guilds.create") });
        ui.button(12, GLD_FOOT, 60, 16, "Top", (pl) => gldOpenTop(pl, "power"));
        if (gldHas(p, "guilds.admin")) ui.button(76, GLD_FOOT, 50, 16, "Admin", (pl) => gldOpenAdmin(pl, 0));
        ui.close();
    });
}

// ---- Leaderboard ----------------------------------------------------------------------------

function gldOpenTop(p, by) {
    gldScreen(p, "&6Top Guilds", (ui) => {
        let x = 12;
        [["power", "Power"], ["members", "Members"], ["claims", "Claims"], ["bank", "Bank"]].forEach((s) => {
            ui.button(x, 22, 50, 14, s[1], (pl) => gldOpenTop(pl, s[0]), { enabled: by !== s[0] });
            x += 53;
        });
        let mine = gldOf(p), list = gldTopList(by);
        if (!list.length) ui.text(12, 46, "&7No guilds exist yet.");
        list.slice(0, 12).forEach((e, i) => {
            let y = 44 + i * 15, col = i === 0 ? "&6" : i === 1 ? "&f" : i === 2 ? "&c" : "&7";
            ui.text(12, y, col + (i + 1) + ". &8[" + e.g.color + e.g.tag + "&8] " + (e.g === mine ? "&a" : "&f") + e.g.name);
            ui.text(GLD_W - 12, y, "&f" + (by === "bank" ? gldMoney(e.v) : Math.round(e.v).toLocaleString()), { align: "right" });
        });
        ui.button(12, GLD_FOOT, 50, 16, "Back", (pl) => gldOpen(pl, null));
        ui.close();
    });
}

// ---- Admin ----------------------------------------------------------------------------------

function gldOpenAdmin(p, page) {
    if (!gldHas(p, "guilds.admin")) return;
    let all = gldTopList("members").map((e) => e.g), per = 9, pages = Math.max(1, Math.ceil(all.length / per));
    page = Math.max(0, Math.min(page, pages - 1));
    gldScreen(p, "&cGuild Admin &7(" + all.length + " guilds)", (ui) => {
        if (!all.length) ui.text(12, 30, "&7No guilds exist yet.");
        all.slice(page * per, page * per + per).forEach((g, i) => {
            let y = 24 + i * 22, right = GLD_W - 12;
            ui.text(12, y, "&8[" + g.color + g.tag + "&8] &a" + g.name + " &7(" + gldName(g, g.leader) + ")");
            ui.small(12, y + 10, "&7" + Object.keys(g.members).length + " members | claims " + g.claims.length + "/" + gldMaxClaims(g)
                + (g.claimBonus ? " (+" + g.claimBonus + ")" : "") + " | power " + Math.round(gldPower(g)).toLocaleString() + " | bank " + gldMoney(g.bank));
            ui.button(right - 52, y, 52, 14, "&cDisband", (pl) => { if (gldConfirm(pl, "adis" + g.id, "disband " + g.name)) { gldDisband(g, "an admin"); gldOpenAdmin(pl, page); } });
            ui.button(right - 74, y, 20, 14, "-5", (pl) => { g.claimBonus = Math.max(0, g.claimBonus - 5); gldSave(g); gldOpenAdmin(pl, page); }, { tooltip: "Claim bonus -5" });
            ui.button(right - 96, y, 20, 14, "+5", (pl) => { g.claimBonus += 5; gldSave(g); gldOpenAdmin(pl, page); }, { tooltip: "Claim bonus +5" });
        });
        if (pages > 1) {
            ui.button(176, GLD_FOOT, 16, 16, "<", (pl) => gldOpenAdmin(pl, page - 1), { enabled: page > 0 });
            ui.small(196, GLD_FOOT + 5, (page + 1) + "/" + pages);
            ui.button(214, GLD_FOOT, 16, 16, ">", (pl) => gldOpenAdmin(pl, page + 1), { enabled: page < pages - 1 });
        }
        ui.button(12, GLD_FOOT, 76, 16, GLD_BYPASS[p.uuid] ? "&aBypass: on" : "Bypass: off", (pl) => { gldAdmin(pl, ["admin", "bypass"]); gldOpenAdmin(pl, page); },
            { tooltip: "Build and open things in every guild's territory (needs guilds.admin.bypass)" });
        ui.button(92, GLD_FOOT, 64, 16, GLD_SPY[p.uuid] ? "&aSpy: on" : "Spy: off", (pl) => { gldAdmin(pl, ["admin", "spy"]); gldOpenAdmin(pl, page); },
            { tooltip: "See every guild and ally chat (needs guilds.admin.spy)" });
        ui.close();
    });
}

RPG.on("playerLeave", (p) => { delete GLD_VIEW[p.uuid]; delete GLD_CONFIRM[p.uuid]; });
