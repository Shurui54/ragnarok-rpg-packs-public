// =====================================================================================
//  Guilds - claim upgrade items: right-click to give your guild more claimable chunks for good.
//  Four sizes (+1, +5, +10, +25). No recipe: hand them out from shops, crates, quests or with
//  /rpg give <player> guild_claim_upgrade_5. Using one needs the guild's claim permission.
//  The bonus belongs to the guild and is added after the size/power limit, so it always gives
//  exactly that many more chunks.
// =====================================================================================

[1, 5, 10, 25].forEach((n) => {
    let ref = "guild_claim_upgrade_" + n;
    RPG.items.define(ref, {
        name: "&6Guild Claim Upgrade &e(+" + n + " Chunk" + (n === 1 ? "" : "s") + ")",
        lore: ["&7Right-click: your guild may claim", "&7" + n + " more chunk" + (n === 1 ? "" : "s") + ", for good."],
        model: "guilds:rpg/item/claim_upgrade", rarity: n >= 25 ? "epic" : n >= 10 ? "rare" : n >= 5 ? "uncommon" : "common", maxStack: 64,
        onUse(player) {
            let g = gldOf(player);
            if (!g) { gldMsg(player, "&cYou are not in a guild, so there is no guild to add claim chunks to. Join or create one first."); return false; }
            if (!gldCan(g, player.uuid, "claim")) { gldMsg(player, "&cYour guild rank lacks permission to add claim chunks: claim."); return false; }
            if (player.getGameMode() !== "creative" && !player.takeItem(ref, 1)) return false;
            g.claimBonus += n;
            gldSave(g);
            gldBroadcast(g, "&f" + player.name + " &7used a claim upgrade: the guild can now claim &a" + n + " &7more chunk" + (n === 1 ? "" : "s")
                + ". Claim limit is now &f" + g.claims.length + " / " + gldMaxClaims(g) + "&7.");
            player.playSound("minecraft:entity.player.levelup", 0.6, 1.4);
            return true;
        }
    });
});
