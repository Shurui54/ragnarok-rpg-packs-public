// =====================================================================================
//  Guilds - the /guild command (alias /g), plus /gc (guild chat) and /ac (ally chat).
//  Every button in the guild screens runs the same functions these commands do.
// =====================================================================================

var GLD_COLORS = { black: "&0", dark_blue: "&1", dark_green: "&2", dark_aqua: "&3", dark_red: "&4", dark_purple: "&5", gold: "&6", gray: "&7",
    dark_gray: "&8", blue: "&9", green: "&a", aqua: "&b", red: "&c", light_purple: "&d", yellow: "&e", white: "&f" };

function gldNeed(p) {
    let g = gldOf(p);
    if (!g) gldMsg(p, "&cYou are not in a guild. Use /guild create <name>.");
    return g;
}
function gldNeedPerm(p, perm) {
    let g = gldNeed(p);
    if (g && !gldCan(g, p.uuid, perm)) { gldMsg(p, "&cYour guild rank lacks permission: " + perm); return null; }
    return g;
}
function gldOnlineNames() { return RPG.server.players().map((q) => q.name); }
function gldNames() { return gldAll().map((g) => g.name); }

// ---- actions (shared by commands and the screens) -------------------------------------------

function gldActInvite(p, name) {
    let g = gldNeedPerm(p, "invite");
    if (!g) return;
    let t = RPG.server.player(String(name || ""));
    if (!t) { gldMsg(p, "&cThat player isn't online."); return; }
    if (gldOf(t)) { gldMsg(p, "&c" + t.name + " is already in a guild."); return; }
    if (Object.keys(g.members).length >= GLD_CFG.get("maxMembers")) { gldMsg(p, "&cYour guild is full."); return; }
    if (g.invites.indexOf(t.uuid) < 0) g.invites.push(t.uuid);
    g.memberNames[t.uuid] = t.name;
    gldSave(g);
    gldBroadcast(g, "&f" + p.name + " &7invited &f" + t.name + "&7.");
    gldMsg(t, "&f" + p.name + " &7invited you to " + g.color + g.name + "&7. Type &f/guild join " + g.name + " &7or open &f/guild&7.");
}
function gldActDeinvite(p, name) {
    let g = gldNeedPerm(p, "invite");
    if (!g) return;
    let low = String(name || "").toLowerCase();
    let u = g.invites.filter((x) => String(g.memberNames[x] || "").toLowerCase() === low)[0];
    if (!u) { gldMsg(p, "&cThat player was not invited."); return; }
    g.invites = g.invites.filter((x) => x !== u);
    gldSave(g);
    gldMsg(p, "&7Invite withdrawn.");
}
function gldActJoin(p, name) {
    if (gldOf(p)) { gldMsg(p, "&cYou are already in a guild."); return; }
    let g = gldByName(name);
    if (!g) { gldMsg(p, "&cNo guild by that name."); return; }
    if (!g.open && g.invites.indexOf(p.uuid) < 0) { gldMsg(p, "&cThat guild is invite-only and you have no invite."); return; }
    if (Object.keys(g.members).length >= GLD_CFG.get("maxMembers")) { gldMsg(p, "&cThat guild is full."); return; }
    gldAddMember(g, p, "RECRUIT");
    gldBroadcast(g, "&f" + p.name + " &ajoined the guild.");
    if (g.motd) p.tell(GLD_CFG.get("prefix") + "&7MOTD: &f" + g.motd);
}
function gldActLeave(p) {
    let g = gldNeed(p);
    if (!g) return;
    if (g.leader === p.uuid) {
        if (Object.keys(g.members).length > 1) { gldMsg(p, "&cTransfer leadership (/guild leader <player>) or disband before leaving."); return; }
        gldDisband(g, p.name);
        return;
    }
    gldRemoveMember(g, p.uuid);
    gldMsg(p, "&7You left " + g.name + ".");
    gldBroadcast(g, "&f" + p.name + " &7left the guild.");
}
function gldActKick(p, name) {
    let g = gldNeedPerm(p, "kick");
    if (!g) return;
    let u = gldFindMember(g, name);
    if (!u) { gldMsg(p, "&cThat player is not in your guild."); return; }
    if (u === p.uuid || gldRank(gldRole(g, u)) >= gldRank(gldRole(g, p.uuid))) { gldMsg(p, "&cYou can only kick members ranked below you."); return; }
    let who = gldName(g, u);
    gldRemoveMember(g, u);
    gldBroadcast(g, "&f" + who + " &7was kicked by &f" + p.name + "&7.");
    let t = RPG.server.players().filter((q) => q.uuid === u)[0];
    if (t) gldMsg(t, "&cYou were kicked from " + g.name + ".");
}
function gldActRank(p, name, dir) {
    let g = gldNeedPerm(p, "setrole");
    if (!g) return;
    let u = gldFindMember(g, name);
    if (!u) { gldMsg(p, "&cThat player is not in your guild."); return; }
    let mine = gldRank(gldRole(g, p.uuid)), theirs = gldRank(gldRole(g, u)), next = theirs + dir;
    if (u === p.uuid || theirs >= mine || next >= mine || next < 0 || next >= GLD_ROLES.length - 1) { gldMsg(p, "&cYou can only change ranks below your own."); return; }
    g.members[u] = GLD_ROLES[next];
    gldSave(g);
    gldBroadcast(g, "&f" + gldName(g, u) + " &7is now " + (dir > 0 ? "&a" : "&e") + gldTitle(GLD_ROLES[next]) + "&7.");
}
function gldActLeader(p, name) {
    let g = gldNeed(p);
    if (!g) return;
    if (g.leader !== p.uuid) { gldMsg(p, "&cOnly the leader can transfer leadership."); return; }
    let u = gldFindMember(g, name);
    if (!u || u === p.uuid) { gldMsg(p, "&cPick another member of your guild."); return; }
    gldTransferLeader(g, u);
    gldBroadcast(g, "&f" + gldName(g, u) + " &6is the new guild leader.");
}
function gldActOpen(p) {
    let g = gldNeedPerm(p, "info");
    if (!g) return;
    g.open = !g.open;
    gldSave(g);
    gldBroadcast(g, "&7The guild is now " + (g.open ? "&aopen to anyone" : "&einvite-only") + "&7.");
}
function gldActSetHome(p) {
    let g = gldNeedPerm(p, "sethome");
    if (!g) return;
    if (gldOwnerAt(p.dimension, p.x, p.z) !== g) { gldMsg(p, "&cThe guild home must be on your guild's land."); return; }
    g.home = gldLoc(p);
    gldSave(g);
    gldMsg(p, "&aGuild home set.");
}
function gldActHome(p) {
    let g = gldNeedPerm(p, "home");
    if (!g) return;
    if (!g.home) { gldMsg(p, "&cYour guild has no home. Set one with /guild sethome."); return; }
    gldTeleport(p, g.home, "the guild home");
}
function gldActSetWarp(p, name) {
    let g = gldNeedPerm(p, "setwarp");
    if (!g) return;
    name = String(name || "").toLowerCase();
    if (!/^[a-z0-9_\-]{1,16}$/.test(name)) { gldMsg(p, "&cA warp name is 1-16 letters, digits, _ or -."); return; }
    if (!g.warps[name] && Object.keys(g.warps).length >= GLD_CFG.get("teleport.maxWarps")) { gldMsg(p, "&cYour guild has the most warps it may have (" + GLD_CFG.get("teleport.maxWarps") + ")."); return; }
    if (gldOwnerAt(p.dimension, p.x, p.z) !== g) { gldMsg(p, "&cGuild warps must be on your guild's land."); return; }
    g.warps[name] = gldLoc(p);
    gldSave(g);
    gldMsg(p, "&aWarp &f" + name + " &aset.");
}
function gldActWarp(p, name) {
    let g = gldNeedPerm(p, "warp");
    if (!g) return;
    let w = g.warps[String(name || "").toLowerCase()];
    if (!w) { gldMsg(p, "&cNo such warp."); return; }
    gldTeleport(p, w, "warp " + String(name).toLowerCase());
}
function gldActDelWarp(p, name) {
    let g = gldNeedPerm(p, "setwarp");
    if (!g) return;
    name = String(name || "").toLowerCase();
    if (!g.warps[name]) { gldMsg(p, "&cNo such warp."); return; }
    delete g.warps[name];
    gldSave(g);
    gldMsg(p, "&7Warp removed.");
}
function gldParseAmount(s) { let n = Math.floor(Number(s)); return isFinite(n) && n > 0 ? n : 0; }
function gldActDeposit(p, amount) {
    let g = gldNeedPerm(p, "deposit");
    if (!g) return;
    let n = gldParseAmount(amount);
    if (!n) { gldMsg(p, "&cGive an amount above 0."); return; }
    if (!p.takeMoney(n)) { gldMsg(p, "&cYou don't have that much " + gldMoneyName() + "."); return; }
    g.bank += n;
    gldSave(g);
    gldBroadcast(g, "&f" + p.name + " &7deposited &a" + gldMoney(n) + " &7(bank: " + gldMoney(g.bank) + ").");
}
function gldActWithdraw(p, amount) {
    let g = gldNeedPerm(p, "withdraw");
    if (!g) return;
    let n = gldParseAmount(amount);
    if (!n) { gldMsg(p, "&cGive an amount above 0."); return; }
    if (g.bank < n) { gldMsg(p, "&cThe guild bank doesn't have that much."); return; }
    g.bank -= n;
    p.addMoney(n);
    gldSave(g);
    gldBroadcast(g, "&f" + p.name + " &7withdrew &e" + gldMoney(n) + " &7(bank: " + gldMoney(g.bank) + ").");
}
function gldActRelation(p, name, rel) {
    let g = gldNeedPerm(p, "relation");
    if (!g) return;
    let o = gldByName(name);
    if (!o || o === g) { gldMsg(p, "&cPick another existing guild."); return; }
    gldSetRelation(g, o, rel);
    gldMsg(p, "&7You now regard " + o.name + " as " + GLD_REL_COLOR[rel] + gldTitle(rel) + "&7 (effective: " + GLD_REL_COLOR[gldRelation(g, o)] + gldTitle(gldRelation(g, o)) + "&7).");
}
function gldActFlag(p, flag, on) {
    let g = gldNeedPerm(p, "flag");
    if (!g) return;
    flag = String(flag || "").toLowerCase();
    if (GLD_FLAGS.indexOf(flag) < 0) { gldMsg(p, "&cUnknown flag. Options: " + GLD_FLAGS.join(", ")); return; }
    g.flags[flag] = !!on;
    gldSave(g);
    gldBroadcast(g, "&7Flag &f" + flag + " &7is now " + (on ? "&aON" : "&cOFF") + " &7(" + p.name + ").");
}
function gldActPerm(p, role, perm, on) {
    let g = gldNeed(p);
    if (!g) return;
    if (g.leader !== p.uuid) { gldMsg(p, "&cOnly the leader can edit role permissions."); return; }
    role = String(role || "").toUpperCase(); perm = String(perm || "").toLowerCase();
    if (["RECRUIT", "MEMBER", "OFFICER"].indexOf(role) < 0 || GLD_PERMS.indexOf(perm) < 0) { gldMsg(p, "&cUsage: /guild perm <recruit|member|officer> <permission> <on|off>"); return; }
    let list = g.rolePerms[role].filter((x) => String(x) !== perm);
    if (on) list.push(perm);
    g.rolePerms[role] = list;
    gldSave(g);
    gldMsg(p, "&7" + gldTitle(role) + " &f" + perm + "&7: " + (on ? "&aON" : "&cOFF"));
}
function gldActMemberPerm(p, name, perm, value) {
    let g = gldNeed(p);
    if (!g) return;
    if (g.leader !== p.uuid) { gldMsg(p, "&cOnly the leader can edit member permissions."); return; }
    let u = gldFindMember(g, name);
    perm = String(perm || "").toLowerCase();
    if (!u || u === g.leader) { gldMsg(p, "&cPick another member of your guild."); return; }
    if (GLD_PERMS.indexOf(perm) < 0) { gldMsg(p, "&cUnknown permission. Options: " + GLD_PERMS.join(", ")); return; }
    let o = g.memberPerms[u] || {};
    if (value === null) delete o[perm]; else o[perm] = !!value;
    if (Object.keys(o).length) g.memberPerms[u] = o; else delete g.memberPerms[u];
    gldSave(g);
    gldMsg(p, "&f" + gldName(g, u) + " &7" + perm + ": " + (value === null ? "&7follows their rank" : value ? "&aallowed" : "&cdenied"));
}
function gldActChannel(p, ch) {
    if (!gldNeed(p)) return;
    ch = String(ch || "");
    if (!ch) ch = !GLD_CHANNEL[p.uuid] ? "guild" : GLD_CHANNEL[p.uuid] === "guild" ? "ally" : "public";
    if (ch === "g") ch = "guild"; else if (ch === "a") ch = "ally"; else if (ch === "p") ch = "public";
    if (["guild", "ally", "public"].indexOf(ch) < 0) { gldMsg(p, "&cChannels: public, guild, ally"); return; }
    if (ch === "public") delete GLD_CHANNEL[p.uuid]; else GLD_CHANNEL[p.uuid] = ch;
    gldMsg(p, "&7Your chat now goes to &f" + ch + "&7." + (ch === "public" ? "" : " &8(/guild chat public to go back)"));
}

// ---- read-only views ------------------------------------------------------------------------

function gldInfoLines(g, viewer) {
    let rel = viewer ? gldRelation(gldOf(viewer), g) : "NEUTRAL";
    let lines = ["&8---- " + g.color + g.name + " &8[" + g.color + g.tag + "&8] ----"];
    if (g.description) lines.push("&7" + g.description);
    lines.push("&7Leader: &f" + gldName(g, g.leader) + "   &7Members: &f" + Object.keys(g.members).length + "/" + GLD_CFG.get("maxMembers"));
    lines.push("&7Power: &f" + Math.round(gldPower(g)).toLocaleString() + "   &7Claims: &f" + g.claims.length + "/" + gldMaxClaims(g) + (gldOverclaimable(g) ? " &c(overclaimable!)" : ""));
    lines.push("&7Access: " + (g.open ? "&aopen" : "&einvite-only") + (rel !== "NEUTRAL" ? "   &7Stance: " + GLD_REL_COLOR[rel] + (rel === "SELF" ? "your guild" : gldTitle(rel)) : ""));
    if (rel === "SELF") lines.push("&7Bank: &f" + gldMoney(g.bank) + "   &7Home: " + (g.home ? "&aset" : "&7not set"));
    return lines;
}
function gldTopList(by) {
    let val = { power: gldPower, members: (g) => Object.keys(g.members).length, claims: (g) => g.claims.length, bank: (g) => g.bank }[by] || gldPower;
    return gldAll().map((g) => ({ g: g, v: val(g) })).sort((a, b) => b.v - a.v);
}
function gldAsciiMap(p) {
    let me = gldOf(p), cx0 = gldChunkOf(p.x), cz0 = gldChunkOf(p.z), rows = ["&8--- Territory around you (&eC&8=you) ---"];
    for (let dz = -4; dz <= 4; dz++) {
        let row = "";
        for (let dx = -10; dx <= 10; dx++) {
            if (dx === 0 && dz === 0) { row += "&eC"; continue; }
            let o = gldOwnerOf(p.dimension, cx0 + dx, cz0 + dz);
            if (!o) {
                let lc = typeof LandClaims !== "undefined" && LandClaims ? LandClaims.ownerOfChunk(p.dimension, cx0 + dx, cz0 + dz) : null;
                row += lc ? "&9=" : "&7-";
            } else if (o === me) row += "&a+";
            else row += GLD_REL_COLOR[gldRelation(me, o)] + "#";
        }
        rows.push(row);
    }
    rows.push("&a+ &7your guild   &e# &7other guild   &7- wilderness" + (typeof LandClaims !== "undefined" && LandClaims ? "   &9= &7land claim" : ""));
    return rows;
}

// ---- the command tree -----------------------------------------------------------------------

var GLD_SUB = {};
function gldSub(name, usage, desc, run, suggest) { GLD_SUB[name] = { usage: usage, desc: desc, run: run, suggest: suggest }; }
function gldMembersOf(p) { let g = gldOf(p); return g ? Object.keys(g.members).map((u) => gldName(g, u)) : []; }
function gldRest(args, from) { return args.slice(from).join(" ").trim(); }
function gldOnOff(s) { s = String(s || "").toLowerCase(); return s === "on" || s === "true" || s === "allow" || s === "yes" ? true : s === "off" || s === "false" || s === "deny" || s === "no" ? false : null; }

gldSub("help", "[page]", "This list", (p, a) => {
    let names = Object.keys(GLD_SUB).filter((n) => n !== "admin" || gldHas(p, "guilds.admin")), per = 10;
    let pages = Math.max(1, Math.ceil(names.length / per)), page = Math.max(1, Math.min(pages, parseInt(a[1]) || 1));
    gldMsg(p, "&7Guild commands &8(" + page + "/" + pages + ")&7, or just &f/guild &7for the screen:");
    names.slice((page - 1) * per, page * per).forEach((n) => p.tell("&f/guild " + n + " " + GLD_SUB[n].usage + " &8- &7" + GLD_SUB[n].desc));
});
gldSub("gui", "", "Open the guild screen", (p) => gldOpen(p, null));
gldSub("create", "<name>", "Found a guild", (p, a) => { let g = gldCreate(p, gldRest(a, 1)); if (g) gldOpen(p, "info"); });
gldSub("disband", "confirm", "Disband your guild (leader)", (p, a) => {
    let g = gldNeed(p);
    if (!g) return;
    if (g.leader !== p.uuid) { gldMsg(p, "&cOnly the guild leader can disband it."); return; }
    if (String(a[1] || "").toLowerCase() !== "confirm") { gldMsg(p, "&cThis deletes the guild, its land, bank and warps. Type &f/guild disband confirm&c."); return; }
    if (g.bank > 0) p.addMoney(g.bank);
    gldDisband(g, p.name);
}, () => ["confirm"]);
gldSub("rename", "<name>", "Rename the guild (leader)", (p, a) => {
    let g = gldNeed(p);
    if (!g) return;
    if (g.leader !== p.uuid) { gldMsg(p, "&cOnly the leader can rename the guild."); return; }
    let bad = gldNameProblem(gldRest(a, 1), g);
    if (bad) { gldMsg(p, "&c" + bad); return; }
    gldRename(g, gldRest(a, 1));
    gldBroadcast(g, "&7The guild is now called " + g.color + g.name + "&7.");
});
gldSub("tag", "<TAG>", "Set the guild tag", (p, a) => {
    let g = gldNeedPerm(p, "info");
    if (!g) return;
    let bad = gldTagProblem(a[1]);
    if (bad) { gldMsg(p, "&c" + bad); return; }
    g.tag = String(a[1]).toUpperCase();
    gldSave(g);
    gldMsg(p, "&7Guild tag: " + g.color + g.tag);
});
gldSub("color", "<colour>", "Set the tag colour (green, aqua, gold...)", (p, a) => {
    let g = gldNeedPerm(p, "info");
    if (!g) return;
    let c = String(a[1] || "").toLowerCase();
    c = GLD_COLORS[c] || (/^&[0-9a-f]$/.test(c) ? c : null);
    if (!c) { gldMsg(p, "&cColours: " + Object.keys(GLD_COLORS).join(", ") + " (or &0-&f)"); return; }
    g.color = c;
    gldSave(g);
    gldMsg(p, "&7Guild colour: " + g.color + g.tag);
}, () => Object.keys(GLD_COLORS));
gldSub("desc", "<text>", "Set the description", (p, a) => {
    let g = gldNeedPerm(p, "info");
    if (!g) return;
    g.description = gldRest(a, 1).replace(/&/g, "").substring(0, 120);
    gldSave(g);
    gldMsg(p, "&7Description set.");
});
gldSub("motd", "<text>", "Set the message of the day", (p, a) => {
    let g = gldNeedPerm(p, "info");
    if (!g) return;
    g.motd = gldRest(a, 1).substring(0, 160);
    gldSave(g);
    gldMsg(p, "&7Set MotD to &f" + (g.motd || "(none)"));
});
gldSub("open", "", "Toggle open / invite-only", (p) => gldActOpen(p));
gldSub("invite", "<player>", "Invite a player", (p, a) => gldActInvite(p, a[1]), (p) => gldOnlineNames());
gldSub("deinvite", "<player>", "Withdraw an invite", (p, a) => gldActDeinvite(p, a[1]), (p) => { let g = gldOf(p); return g ? g.invites.map((u) => String(g.memberNames[u] || u)) : []; });
gldSub("join", "<guild>", "Join a guild that invited you (or an open one)", (p, a) => { gldActJoin(p, gldRest(a, 1)); if (gldOf(p)) gldOpen(p, "info"); }, () => gldNames());
gldSub("leave", "", "Leave your guild", (p) => gldActLeave(p));
gldSub("kick", "<player>", "Kick a lower rank", (p, a) => gldActKick(p, a[1]), gldMembersOf);
gldSub("promote", "<player>", "Raise a member's rank", (p, a) => gldActRank(p, a[1], 1), gldMembersOf);
gldSub("demote", "<player>", "Lower a member's rank", (p, a) => gldActRank(p, a[1], -1), gldMembersOf);
gldSub("leader", "<player>", "Hand leadership over", (p, a) => gldActLeader(p, a[1]), gldMembersOf);
gldSub("info", "[guild]", "About a guild", (p, a) => {
    let g = a.length > 1 ? gldByName(gldRest(a, 1)) : gldNeed(p);
    if (a.length > 1 && !g) { gldMsg(p, "&cNo guild by that name."); return; }
    if (g) gldInfoLines(g, p).forEach((l) => p.tell(l));
}, () => gldNames());
gldSub("members", "", "Your guild's members", (p) => {
    let g = gldNeed(p);
    if (!g) return;
    let on = {};
    gldOnline(g).forEach((q) => { on[q.uuid] = true; });
    Object.keys(g.members).sort((x, y) => gldRank(gldRole(g, y)) - gldRank(gldRole(g, x))).forEach((u) =>
        p.tell((on[u] ? "&a● " : "&8● ") + "&f" + gldName(g, u) + " &7- " + gldTitle(gldRole(g, u))));
});
gldSub("who", "<player>", "Which guild a player is in", (p, a) => {
    let t = RPG.server.player(String(a[1] || ""));
    if (!t) { gldMsg(p, "&cThat player isn't online."); return; }
    let g = gldOf(t);
    gldMsg(p, g ? "&f" + t.name + " &7is " + gldTitle(gldRole(g, t.uuid)) + " of " + g.color + g.name : "&f" + t.name + " &7is not in a guild.");
}, () => gldOnlineNames());
gldSub("list", "[page]", "Every guild", (p, a) => {
    let all = gldTopList("members"), per = 10;
    if (!all.length) { gldMsg(p, "&7No guilds exist yet."); return; }
    let pages = Math.ceil(all.length / per), page = Math.max(1, Math.min(pages, parseInt(a[1]) || 1));
    gldMsg(p, "&7Guilds &8(" + page + "/" + pages + ")");
    all.slice((page - 1) * per, page * per).forEach((e) => p.tell("&8[" + e.g.color + e.g.tag + "&8] &f" + e.g.name + " &7- " + e.v + " members" + (e.g.open ? " &a(open)" : "")));
});
gldSub("top", "[power|members|claims|bank]", "Guild leaderboard", (p, a) => {
    let by = String(a[1] || "power").toLowerCase();
    if (["power", "members", "claims", "bank"].indexOf(by) < 0) by = "power";
    gldMsg(p, "&6Top guilds by " + by + ":");
    gldTopList(by).slice(0, 10).forEach((e, i) => p.tell("&e" + (i + 1) + ". " + e.g.color + e.g.name + " &8[" + e.g.tag + "] &f" + Math.round(e.v).toLocaleString()));
}, () => ["power", "members", "claims", "bank"]);
gldSub("claim", "", "Claim the chunk you stand in", (p) => gldClaim(p, p.dimension, gldChunkOf(p.x), gldChunkOf(p.z), false));
gldSub("unclaim", "", "Unclaim the chunk you stand in", (p) => { if (gldUnclaim(p, p.dimension, gldChunkOf(p.x), gldChunkOf(p.z), false)) gldMsg(p, "&7Chunk unclaimed."); });
gldSub("unclaimall", "confirm", "Unclaim all guild land (leader)", (p, a) => {
    let g = gldNeed(p);
    if (!g) return;
    if (g.leader !== p.uuid) { gldMsg(p, "&cOnly the leader can unclaim all land."); return; }
    if (String(a[1] || "").toLowerCase() !== "confirm") { gldMsg(p, "&cType &f/guild unclaimall confirm &cto give up all " + g.claims.length + " chunks."); return; }
    gldUnclaimAll(g);
    gldMsg(p, "&7All land unclaimed.");
}, () => ["confirm"]);
gldSub("autoclaim", "", "Claim chunks as you walk", (p) => {
    if (!gldNeedPerm(p, "claim")) return;
    if (GLD_AUTOCLAIM[p.uuid]) { delete GLD_AUTOCLAIM[p.uuid]; gldMsg(p, "&7Auto-claim disabled."); }
    else { GLD_AUTOCLAIM[p.uuid] = true; delete GLD_LASTCHUNK[p.uuid]; gldMsg(p, "&aAuto-claim enabled. Walk to claim chunks."); }
});
gldSub("claimat", "<chunkX> <chunkZ>", "Claim a chunk by its chunk coordinates", (p, a) => {
    let cx = parseInt(a[1]), cz = parseInt(a[2]);
    if (!isFinite(cx) || !isFinite(cz)) { gldMsg(p, "&cUsage: /guild claimat <chunkX> <chunkZ>"); return; }
    gldClaim(p, p.dimension, cx, cz, false);
});
gldSub("claimarea", "<x1> <z1> <x2> <z2>", "Claim a rectangle of chunks (chunk coordinates)", (p, a) => {
    let v = [1, 2, 3, 4].map((i) => parseInt(a[i]));
    if (v.some((n) => !isFinite(n))) { gldMsg(p, "&cUsage: /guild claimarea <chunkX1> <chunkZ1> <chunkX2> <chunkZ2>"); return; }
    if (gldNeedPerm(p, "claim")) gldClaimArea(p, p.dimension, v[0], v[1], v[2], v[3]);
});
gldSub("map", "", "Territory around you in chat", (p) => gldAsciiMap(p).forEach((l) => p.tell(l)));
gldSub("claims", "", "Open the claim map", (p) => gldOpen(p, "map"));
gldSub("sethome", "", "Set the guild home here", (p) => gldActSetHome(p));
gldSub("home", "", "Teleport to the guild home", (p) => gldActHome(p));
gldSub("delhome", "", "Remove the guild home", (p) => { let g = gldNeedPerm(p, "sethome"); if (g) { g.home = null; gldSave(g); gldMsg(p, "&7Guild home removed."); } });
gldSub("setwarp", "<name>", "Set a guild warp here", (p, a) => gldActSetWarp(p, a[1]));
gldSub("warp", "<name>", "Teleport to a guild warp", (p, a) => gldActWarp(p, a[1]), (p) => { let g = gldOf(p); return g ? Object.keys(g.warps) : []; });
gldSub("delwarp", "<name>", "Delete a guild warp", (p, a) => gldActDelWarp(p, a[1]), (p) => { let g = gldOf(p); return g ? Object.keys(g.warps) : []; });
gldSub("warps", "", "List guild warps", (p) => { let g = gldNeed(p); if (g) gldMsg(p, Object.keys(g.warps).length ? "&7Warps: &f" + Object.keys(g.warps).join("&7, &f") : "&7No guild warps set."); });
gldSub("bank", "[deposit|withdraw] [amount]", "The guild bank", (p, a) => {
    let w = String(a[1] || "").toLowerCase();
    if (w === "deposit") gldActDeposit(p, a[2]);
    else if (w === "withdraw") gldActWithdraw(p, a[2]);
    else { let g = gldNeed(p); if (g) gldMsg(p, "&7Guild bank: &f" + gldMoney(g.bank)); }
}, () => ["deposit", "withdraw"]);
gldSub("deposit", "<amount>", "Put money in the guild bank", (p, a) => gldActDeposit(p, a[1]));
gldSub("withdraw", "<amount>", "Take money from the guild bank", (p, a) => gldActWithdraw(p, a[1]));
["ally", "truce", "neutral", "enemy"].forEach((r) => gldSub(r, "<guild>", "Declare " + r + " with a guild", (p, a) => gldActRelation(p, gldRest(a, 1), r.toUpperCase()), () => gldNames()));
gldSub("relations", "", "Your guild's relations", (p) => {
    let g = gldNeed(p);
    if (!g) return;
    let rows = gldAll().filter((o) => o !== g && (g.relations[o.id] || o.relations[g.id]));
    if (!rows.length) { gldMsg(p, "&7No declared relations."); return; }
    p.tell("&8--- Relations ---");
    rows.forEach((o) => { let r = gldRelation(g, o); p.tell(GLD_REL_COLOR[r] + o.name + " &7you: &f" + gldTitle(gldDeclared(g, o)) + " &7them: &f" + gldTitle(gldDeclared(o, g)) + " &7= " + GLD_REL_COLOR[r] + gldTitle(r)); });
});
gldSub("flag", "<flag> <on|off>", "Set a territory flag", (p, a) => {
    let v = gldOnOff(a[2]);
    if (v === null) { gldMsg(p, "&cUsage: /guild flag <" + GLD_FLAGS.join("|") + "> <on|off>"); return; }
    gldActFlag(p, a[1], v);
}, (p, a) => a.length <= 2 ? GLD_FLAGS : ["on", "off"]);
gldSub("flags", "", "Your territory flags", (p) => { let g = gldNeed(p); if (g) GLD_FLAGS.forEach((f) => p.tell("&f" + f + ": " + (g.flags[f] ? "&aON" : "&cOFF") + " &8- " + GLD_FLAG_INFO[f])); });
gldSub("perm", "<role> <permission> <on|off>", "Change what a rank may do (leader)", (p, a) => {
    let v = gldOnOff(a[3]);
    if (v === null) { gldMsg(p, "&cUsage: /guild perm <recruit|member|officer> <permission> <on|off>"); return; }
    gldActPerm(p, a[1], a[2], v);
}, (p, a) => a.length <= 2 ? ["recruit", "member", "officer"] : a.length === 3 ? GLD_PERMS : ["on", "off"]);
gldSub("perms", "", "What each rank may do", (p) => {
    let g = gldNeed(p);
    if (!g) return;
    ["OFFICER", "MEMBER", "RECRUIT"].forEach((r) => p.tell("&f" + gldTitle(r) + ": &7" + (g.rolePerms[r].length ? g.rolePerms[r].join(", ") : "(nothing)")));
});
gldSub("memberperm", "<player> <permission> <on|off|clear>", "Give or take one permission from one member (leader)", (p, a) => {
    let s = String(a[3] || "").toLowerCase(), v = s === "clear" ? null : gldOnOff(s);
    if (v === null && s !== "clear") { gldMsg(p, "&cUsage: /guild memberperm <player> <permission> <on|off|clear>"); return; }
    gldActMemberPerm(p, a[1], a[2], v);
}, (p, a) => a.length <= 2 ? gldMembersOf(p) : a.length === 3 ? GLD_PERMS : ["on", "off", "clear"]);
gldSub("chat", "[public|guild|ally]", "Where your chat goes", (p, a) => gldActChannel(p, a[1]), () => ["public", "guild", "ally"]);
gldSub("admin", "<gui|disband|bonus|bypass|spy|rename|setleader|unclaim|info>", "Server admin tools", (p, a) => gldAdmin(p, a),
    (p, a) => a.length <= 2 ? ["gui", "disband", "bonus", "bypass", "spy", "rename", "setleader", "unclaim", "info"] : a.length === 3 ? gldNames() : []);

function gldAdmin(p, a) {
    if (!gldHas(p, "guilds.admin")) { gldMsg(p, "&cYou may not use guild admin tools."); return; }
    let w = String(a[1] || "gui").toLowerCase(), g = gldByName(a[2]);
    if (w === "gui") { if (p) gldOpenAdmin(p, 0); return; }
    if (w === "bypass") {
        if (!p) return;
        if (GLD_BYPASS[p.uuid]) delete GLD_BYPASS[p.uuid]; else GLD_BYPASS[p.uuid] = true;
        gldMsg(p, "&7Territory bypass " + (GLD_BYPASS[p.uuid] ? "&aON" : "&cOFF") + (gldHas(p, "guilds.admin.bypass") ? "" : " &8(you also need guilds.admin.bypass)"));
        return;
    }
    if (w === "spy") {
        if (!p) return;
        if (GLD_SPY[p.uuid]) delete GLD_SPY[p.uuid]; else GLD_SPY[p.uuid] = true;
        gldMsg(p, "&7Guild chat spy " + (GLD_SPY[p.uuid] ? "&aON" : "&cOFF"));
        return;
    }
    if (w === "unclaim") {
        if (!p) return;
        let owner = gldOwnerAt(p.dimension, p.x, p.z);
        if (!owner) { gldMsg(p, "&7Nobody owns this chunk."); return; }
        let was = GLD_BYPASS[p.uuid];
        GLD_BYPASS[p.uuid] = true;
        gldUnclaim(p, p.dimension, gldChunkOf(p.x), gldChunkOf(p.z), false);
        if (!was) delete GLD_BYPASS[p.uuid];
        return;
    }
    if (!g) { gldMsg(p, "&cNo guild by that name."); return; }
    if (w === "disband") { gldDisband(g, "an admin"); gldMsg(p, "&7Disbanded " + g.name + "."); }
    else if (w === "bonus") {
        let n = parseInt(a[3]);
        if (!isFinite(n)) { gldMsg(p, "&cUsage: /guild admin bonus <guild> <chunks> (negative takes away)"); return; }
        g.claimBonus = Math.max(0, g.claimBonus + n);
        gldSave(g);
        gldMsg(p, "&7" + g.name + " claim bonus: &f" + g.claimBonus + " &7(limit " + gldMaxClaims(g) + ")");
    } else if (w === "rename") {
        let bad = gldNameProblem(gldRest(a, 3), g);
        if (bad) { gldMsg(p, "&c" + bad); return; }
        gldRename(g, gldRest(a, 3));
        gldMsg(p, "&7Renamed to " + g.name + ".");
    } else if (w === "setleader") {
        let u = gldFindMember(g, a[3]);
        if (!u) { gldMsg(p, "&cThat player is not in " + g.name + "."); return; }
        gldTransferLeader(g, u);
        gldMsg(p, "&7" + gldName(g, u) + " now leads " + g.name + ".");
    } else if (w === "info") {
        gldInfoLines(g, null).forEach((l) => p ? p.tell(l) : RPG.log(l.replace(/&./g, "")));
        let line = "&7Members: " + Object.keys(g.members).map((u) => gldName(g, u) + "=" + gldRole(g, u)).join(", ") + " | leader uuid: " + g.leader;
        if (p) p.tell(line); else RPG.log(line.replace(/&./g, ""));
    } else gldMsg(p, "&cUsage: /guild admin " + GLD_SUB.admin.usage);
}

RPG.commands.register("guild", {
    root: true, aliases: ["g", "guilds"], permission: "guilds.use", description: "Guilds: /guild help",
    suggest: (p, args) => {
        if (args.length <= 1) { let low = String(args[0] || "").toLowerCase(); return Object.keys(GLD_SUB).filter((n) => n.indexOf(low) === 0 && (n !== "admin" || gldHas(p, "guilds.admin"))); }
        let s = GLD_SUB[String(args[0]).toLowerCase()];
        return s && s.suggest ? s.suggest(p, args) : [];
    },
    run(p, args) {
        let name = String(args[0] || "").toLowerCase();
        if (!p && name !== "admin") { RPG.log("Guild commands are for players (the console can use /guild admin ...)."); return; }
        if (!name) { gldOpen(p, null); return; }
        let s = GLD_SUB[name];
        if (!s) { gldMsg(p, "&cUnknown guild command. Try &f/guild help&c."); return; }
        s.run(p, args.map(String));
    }
});
RPG.commands.register("gc", { root: true, permission: "guilds.use", description: "Guild chat: /gc <message> (no message: switch channel)",
    run(p, args) { if (!p) return; if (args.length) gldGuildChat(p, args.join(" ")); else gldActChannel(p, GLD_CHANNEL[p.uuid] === "guild" ? "public" : "guild"); } });
RPG.commands.register("ac", { root: true, permission: "guilds.use", description: "Ally chat: /ac <message> (no message: switch channel)",
    run(p, args) { if (!p) return; if (args.length) gldAllyChat(p, args.join(" ")); else gldActChannel(p, GLD_CHANNEL[p.uuid] === "ally" ? "public" : "ally"); } });
