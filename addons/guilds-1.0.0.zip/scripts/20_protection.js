// =====================================================================================
//  Guilds - territory: who may build, break, open and use things on guild land, PvP rules,
//  friendly fire, explosions, monsters and fire, and the "entering ..." message.
//
//  With Land Claims on too: a chunk is either a personal claim or a guild claim (each addon
//  refuses to claim the other's chunks), and each addon only guards its own chunks, so the two
//  never fight over a block. If a chunk somehow ends up in both (claimed while one addon was
//  off), both guard it and a player needs both permissions: the stricter rule wins.
// =====================================================================================

var GLD_CONTAINERS = /(chest|barrel|shulker_box|furnace|smoker|hopper|dispenser|dropper|brewing_stand|lectern|jukebox|chiseled_bookshelf|decorated_pot|crafter|beehive|bee_nest|campfire|composter|cauldron|respawn_anchor)$/;
var GLD_FIRE_ITEMS = /(flint_and_steel|fire_charge|lava_bucket)$/;
var GLD_BUILD_ITEMS = /(_bucket|bone_meal|_boat|minecart|armor_stand|item_frame|painting|end_crystal|spawn_egg|_seeds|sapling|_hoe|_shovel|_axe)$/;
var GLD_CONTAINER_ENTITIES = /(armor_stand|item_frame|glow_item_frame|chest_minecart|hopper_minecart|chest_boat|allay)$/;
var GLD_HOSTILE_IDS = /(zombie|skeleton|creeper|spider|enderman|witch|slime|magma_cube|phantom|drowned|husk|stray|blaze|ghast|pillager|vindicator|evoker|ravager|vex|guardian|shulker|silverfish|endermite|hoglin|zoglin|piglin_brute|warden|wither|breeze|bogged)$/;

function gldProtecting() { return GLD_CFG.get("protection.protectClaims"); }

/** May player p do `perm` on land owned by guild g (null = wilderness)? */
function gldMayAct(p, g, perm) {
    if (!g || !gldProtecting()) return true;
    if (GLD_BYPASS[p.uuid] && gldHas(p, "guilds.admin.bypass")) return true;
    return gldCan(g, p.uuid, perm);
}
function gldDeny(p, g, perm) {
    let mine = gldOf(p) === g;
    p.actionbar(mine ? "&cYour guild rank lacks permission: " + perm : "&cThis land is claimed by " + g.color + g.name);
    return false;
}
function gldGuard(p, dim, x, z, perm) {
    let g = gldOwnerAt(dim, x, z);
    return gldMayAct(p, g, perm) || gldDeny(p, g, perm);
}

// rpgClaimExempt / RPG_CLAIM_HOOKS: the shared exemptions (see the Land Claims addon)
function gldExempt(p, b, x, y, z, dim, action) {
    if (typeof RPG_CLAIM_HOOKS === "undefined" || !RPG_CLAIM_HOOKS) return false;
    return RPG_CLAIM_HOOKS.exempt.some((f) => { try { return f(p, b, x, y, z, dim, action) === true; } catch (e) { return false; } });
}
RPG.on("blockBreak", (p, b, x, y, z, dim) => gldExempt(p, b, x, y, z, dim, "break") || gldGuard(p, dim, x, z, "destroy"));
RPG.on("blockPlace", (p, b, x, y, z, dim) => {
    let g = gldOwnerAt(dim, x, z);
    if (g && gldProtecting() && /(^|:)(fire|soul_fire|lava)$/.test(String(b)) && !g.flags.firespread) { p.actionbar("&cFire isn't allowed in " + g.name + "'s territory."); return false; }
    return gldMayAct(p, g, "build") || gldExempt(p, b, x, y, z, dim, "place") || gldDeny(p, g, "build");
});
RPG.on("blockInteract", (p, b, x, y, z, dim) => {
    let g = gldOwnerAt(dim, x, z);
    if (!g || !gldProtecting()) return true;
    let held = String(p.heldItem || ""), block = String(b || "");
    if (GLD_FIRE_ITEMS.test(held)) {
        // lighting a nether portal is fine; any other fire only where the firespread flag allows it
        if (!g.flags.firespread && !/obsidian$/.test(block) && !(GLD_BYPASS[p.uuid] && gldHas(p, "guilds.admin.bypass"))) { p.actionbar("&cFire isn't allowed in " + g.name + "'s territory."); return false; }
        return gldMayAct(p, g, "build") || gldDeny(p, g, "build");
    }
    let perm = GLD_CONTAINERS.test(block) ? "container" : GLD_BUILD_ITEMS.test(held) ? "build" : "interact";
    return gldMayAct(p, g, perm) || (perm === "interact" && gldExempt(p, b, x, y, z, dim, "interact")) || gldDeny(p, g, perm);
});
RPG.on("entityInteract", (p, e, type, x, y, z, dim) => {
    let g = gldOwnerAt(dim, x, z);
    if (!g) return true;
    let perm = GLD_CONTAINER_ENTITIES.test(String(type || "")) ? "container" : "interact";
    return gldMayAct(p, g, perm) || gldDeny(p, g, perm);
});

function gldIsHostile(e) {
    if (typeof e.isHostile === "function") return !!e.isHostile();
    return GLD_HOSTILE_IDS.test(String(e.type || ""));
}

// ---- combat: friendly fire, PvP in territory, protected animals and NPCs ---------------------

RPG.on("attack", (e) => {
    let a = e.attacker, t = e.target;
    if (!a || !t || !a.isPlayer()) return;
    let p = a.asPlayer();
    if (t.isPlayer()) {
        let q = t.asPlayer(), ga = gldOf(p), gt = gldOf(q);
        let rel = gldRelation(ga, gt);
        if (rel === "SELF" && !GLD_CFG.get("combat.guildFriendlyFire")) { e.cancel(); p.actionbar("&7" + q.name + " is in your guild."); return; }
        if (rel === "ALLY" && !GLD_CFG.get("combat.allyFriendlyFire")) { e.cancel(); p.actionbar("&7" + q.name + "'s guild is your ally."); return; }
        if (!GLD_CFG.get("protection.pvpProtectionInClaims") || !gldProtecting() || rel === "ENEMY") return;
        let here = gldOwnerAt(q.dimension, q.x, q.z) || gldOwnerAt(p.dimension, p.x, p.z);
        if (here && !here.flags.pvp) { e.cancel(); p.actionbar("&cPvP is off in " + here.name + "'s territory."); }
        return;
    }
    if (!GLD_CFG.get("protection.protectNpcs") || gldIsHostile(t)) return;
    let g = gldOwnerAt(t.dimension, t.x, t.z);
    if (!gldMayAct(p, g, "damagenpc")) { e.cancel(); gldDeny(p, g, "damagenpc"); }
});

// ---- explosions: explosions flag for blasts, mobgriefing flag for mobs' blasts --------------

RPG.on("explode", (e) => {
    if (!gldProtecting()) return;
    let flag = e.source && !e.source.isPlayer() ? "mobgriefing" : "explosions";
    e.keepBlocks((x, y, z) => { let g = gldOwnerAt(e.dimension, x, z); return !!g && !g.flags[flag]; });
});

// ---- monsters: cleared from territory whose monsters flag is off ----------------------------

(function () {
    let left = 0;
    RPG.every(20, () => {
        if (--left > 0) return;
        left = GLD_CFG.get("protection.monsterSweepSeconds");
        if (!gldProtecting() || !Object.keys(GLD_BY_CHUNK).length) return;
        let scriptMobs = GLD_CFG.get("protection.sweepScriptMobs"), seen = {}, dims = {};
        Object.keys(GLD_BY_CHUNK).forEach((k) => { dims[k.substring(0, k.indexOf("|"))] = true; });
        RPG.server.players().forEach((p) => {
            if (!dims[p.dimension]) return;
            p.nearby(64).forEach((e) => {
                if (seen[e.uuid] || e.isPlayer()) return;
                seen[e.uuid] = true;
                if (!gldIsHostile(e) || (!scriptMobs && e.rpgId)) return;
                let g = gldOwnerAt(e.dimension, e.x, e.z);
                if (g && !g.flags.monsters) e.remove();
            });
        });
    });
})();

// ---- entering and leaving territory; auto-claim ---------------------------------------------

var GLD_WHERE = {};       // uuid -> guild id or "" (wilderness)
var GLD_AUTOCLAIM = {};   // uuid -> true while auto-claim is on
var GLD_LASTCHUNK = {};
RPG.on("playerTick", (p) => {
    let cx = gldChunkOf(p.x), cz = gldChunkOf(p.z), ck = gldChunkKey(p.dimension, cx, cz);
    if (GLD_AUTOCLAIM[p.uuid] && GLD_LASTCHUNK[p.uuid] !== ck) {
        GLD_LASTCHUNK[p.uuid] = ck;
        if (!GLD_BY_CHUNK[ck]) gldClaim(p, p.dimension, cx, cz, false);
    }
    let g = gldOwnerOf(p.dimension, cx, cz), id = g ? g.id : "";
    if (GLD_WHERE[p.uuid] === id) return;
    let first = GLD_WHERE[p.uuid] === undefined;
    GLD_WHERE[p.uuid] = id;
    if (first && !g) return;
    if (g) {
        let rel = gldRelation(gldOf(p), g);
        p.actionbar("&7Entering " + GLD_REL_COLOR[rel] + g.name + "&7's territory" + (g.flags.pvp ? " &c(PvP)" : ""));
        return;
    }
    // stepping onto someone's personal land claim: the Land Claims addon announces that one
    if (typeof LandClaims !== "undefined" && LandClaims && LandClaims.ownerAt(p.dimension, p.x, p.z)) return;
    p.actionbar("&2Wilderness");
});
RPG.on("playerLeave", (p) => { delete GLD_WHERE[p.uuid]; delete GLD_AUTOCLAIM[p.uuid]; delete GLD_LASTCHUNK[p.uuid]; delete GLD_POWER_TICK[p.uuid]; });
