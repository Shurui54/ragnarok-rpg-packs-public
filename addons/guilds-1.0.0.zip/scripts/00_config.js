// =====================================================================================
//  Guilds - settings, permission nodes and the fixed vocabulary (ranks, guild permissions,
//  territory flags, relations). Settings live in ragnarok_rpg/config/guilds.json, or change
//  them in game with /rpg config guilds <key> <value>.
// =====================================================================================
//  Players:  /guild            opens the guild screen (tabs: Info, Members, Relations, Flags,
//                              Perms, Warps, Map), or the join/create screen when guildless
//            /guild help       every command
//  Admins:   /guild admin      every guild, disband, claim bonus, territory bypass
// =====================================================================================

var GLD_CFG = RPG.config.define("guilds", {
    prefix: { default: "&8[&aGuild&8] &r", comment: "Put before this addon's chat messages" },
    creationCost: { default: 0, min: 0, max: 1e12, comment: "Money it costs to found a guild (0 = free)" },
    maxMembers: { default: 20, min: 1, max: 1000, integer: true, comment: "Most members a guild can have" },
    nameMinLength: { default: 2, min: 1, max: 32, integer: true, comment: "Shortest guild name" },
    nameMaxLength: { default: 16, min: 1, max: 32, integer: true, comment: "Longest guild name" },
    tagMaxLength: { default: 5, min: 1, max: 8, integer: true, comment: "Longest guild tag (the short name shown in chat and over heads)" },
    defaultColor: { default: "&a", comment: "Colour code a new guild's tag gets (leaders change it with /guild color)" },
    claims: {
        claimCost: { default: 0, min: 0, max: 1e12, comment: "Money per chunk claimed, paid from the guild bank (0 = free)" },
        baseClaimsPerGuild: { default: 25, min: 0, max: 100000, integer: true,
            comment: "Chunks every guild may hold whatever its size or power: the starting allowance and a floor under the scaling" },
        baseClaimsPerMember: { default: 5, min: 0, max: 10000,
            comment: "Chunks per member the guild's size allows (the ceiling half of the limit)" },
        powerPerClaim: { default: 2, min: 0, max: 1e12,
            comment: "Guild power needed to unlock one chunk of the member ceiling. 0 = no power gate (size alone decides)" },
        powerSource: { default: "level",
            comment: "What a member's power is: \"level\" (RPG level), \"none\" (no power gate), or a stat id such as \"strength\"" },
        maxClaimsHardCap: { default: 0, min: 0, max: 1000000, integer: true, comment: "Most chunks any guild may ever hold (0 = no cap)" },
        allowOverclaim: { default: true, comment: "Enemies may take chunks from a guild that holds more land than its limit" },
        maxAreaChunks: { default: 64, min: 1, max: 1024, integer: true, comment: "Most chunks one area claim (map area mode) may cover" },
        dimensions: { default: [], comment: "Dimensions where guilds may claim, e.g. [\"minecraft:overworld\"]. Empty = everywhere" }
    },
    protection: {
        protectClaims: { default: true, comment: "Master switch for territory protection (blocks, containers, entities, explosions, mobs)" },
        pvpProtectionInClaims: { default: true,
            comment: "Block PvP inside a claim unless its pvp flag is on or the two players' guilds are enemies" },
        protectNpcs: { default: true,
            comment: "Animals, villagers and NPCs on guild land can only be hurt by members with the damagenpc permission" },
        monsterSweepSeconds: { default: 2, min: 1, max: 60, integer: true,
            comment: "How often monsters are cleared from territory whose monsters flag is off" },
        sweepScriptMobs: { default: false, comment: "Also clear the project's own script mobs and bosses from such territory" }
    },
    teleport: {
        homeWarmupSeconds: { default: 0, min: 0, max: 60, integer: true, comment: "Seconds to stand still before /guild home and /guild warp (0 = instant)" },
        maxWarps: { default: 5, min: 0, max: 100, integer: true, comment: "Most warps a guild may set" }
    },
    chat: {
        tagInChat: { default: true, comment: "Put the sender's guild tag in front of public chat lines" },
        tagFormat: { default: "&8[{color}{tag}&8] ", comment: "How the tag looks in chat. Tokens: {color} {tag} {name}" },
        guildFormat: { default: "&a[Guild] &7{name}: &f{message}", comment: "Guild chat line. Tokens: {name} {role} {guild} {message}" },
        allyFormat: { default: "&b[Ally] &7{name}: &f{message}", comment: "Ally chat line. Tokens: {name} {role} {guild} {message}" }
    },
    tags: {
        overhead: { default: "hud", options: ["hud", "team", "off"],
            comment: "Guild tag over heads. hud: drawn above players by each client, coloured by relation (works next to Ranks & Kits). team: a scoreboard team per guild (tab list too, but replaces rank teams). off" },
        range: { default: 32, min: 4, max: 128, integer: true, client: true, comment: "How far away (blocks) overhead tags are drawn in hud mode" }
    },
    combat: {
        guildFriendlyFire: { default: false, comment: "Members of the same guild can hurt each other" },
        allyFriendlyFire: { default: false, comment: "Members of allied guilds can hurt each other" }
    }
});

// Who may do what (RPG.perms). Operators have every node, but the territory bypass also needs /guild admin bypass.
RPG.perms.group("default", ["guilds.use", "guilds.create"]);
RPG.perms.group("admin", ["guilds.*"]);

// ---- fixed vocabulary -----------------------------------------------------------------------

/** Ranks, lowest first. A higher index outranks a lower one. */
var GLD_ROLES = ["RECRUIT", "MEMBER", "OFFICER", "LEADER"];

/** Guild permissions a rank (or one member) can be given. Leaders always have all of them. */
var GLD_PERMS = ["build", "destroy", "container", "interact", "invite", "kick", "claim", "unclaim", "sethome", "home",
    "setwarp", "warp", "deposit", "withdraw", "setrole", "relation", "flag", "info", "damagenpc"];
var GLD_PERM_INFO = {
    build: "Place blocks and use buckets on guild land", destroy: "Break blocks on guild land",
    container: "Open chests, furnaces and other containers", interact: "Use doors, buttons, levers, animals",
    invite: "Invite players", kick: "Kick lower ranks", claim: "Claim chunks", unclaim: "Unclaim chunks",
    sethome: "Set the guild home", home: "Teleport to the guild home", setwarp: "Set and delete guild warps",
    warp: "Teleport to guild warps", deposit: "Put money in the guild bank", withdraw: "Take money from the guild bank",
    setrole: "Promote and demote lower ranks", relation: "Declare allies, truces and enemies",
    flag: "Change territory flags", info: "Edit the description, MOTD, tag and colour",
    damagenpc: "Hurt animals, villagers and NPCs on guild land"
};
var GLD_DEFAULT_PERMS = {
    OFFICER: ["build", "destroy", "container", "interact", "invite", "kick", "claim", "unclaim", "sethome", "home",
        "setwarp", "warp", "deposit", "withdraw", "flag", "damagenpc"],
    MEMBER: ["build", "destroy", "container", "interact", "home", "warp", "deposit", "damagenpc"],
    RECRUIT: ["container", "interact", "home", "deposit"]
};

/** Territory flags and their defaults: a protected home territory. */
var GLD_FLAGS = ["pvp", "monsters", "explosions", "firespread", "mobgriefing"];
var GLD_FLAG_DEFAULTS = { pvp: false, monsters: false, explosions: false, firespread: false, mobgriefing: false };
var GLD_FLAG_INFO = {
    pvp: "Players may fight here", monsters: "Monsters may stay here",
    explosions: "TNT and other blasts break blocks", firespread: "Fire may be lit here",
    mobgriefing: "Creepers and other mobs' blasts break blocks"
};

/** Relations one guild declares toward another. Enemy is one-sided; ally and truce need both sides. */
var GLD_RELATIONS = ["ALLY", "TRUCE", "NEUTRAL", "ENEMY"];
var GLD_REL_COLOR = { SELF: "&a", ALLY: "&2", TRUCE: "&b", NEUTRAL: "&e", ENEMY: "&c" };
var GLD_REL_MAP_COLOR = { SELF: "#6033DD44", ALLY: "#60208020", TRUCE: "#6033CCDD", NEUTRAL: "#60DDCC33", ENEMY: "#60DD3333" };

function gldMsg(p, text) { if (p) p.tell(GLD_CFG.get("prefix") + text); else RPG.log(String(text).replace(/&./g, "")); }
function gldHas(p, node) { return !p || RPG.perms.has(p, node); }
function gldTitle(s) { s = String(s || ""); return s.charAt(0).toUpperCase() + s.substring(1).toLowerCase(); }
function gldMoneyName() { let c = RPG.currency.get(); return (c && c.name) ? String(c.name) : "money"; }
function gldMoney(n) { return Math.floor(n).toLocaleString() + " " + gldMoneyName(); }
