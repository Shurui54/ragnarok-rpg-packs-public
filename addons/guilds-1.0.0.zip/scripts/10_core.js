// =====================================================================================
//  Guilds - the registry: guild records, membership, ranks and permissions, chunk claims and
//  the claim limit, relations, bank, home and warps. Everything is saved with the world in
//  RPG.data under "guild|<id>" (one record per guild); the lookups below are rebuilt from it.
// =====================================================================================

var GLD = {};          // id -> guild record
var GLD_BY_NAME = {};  // lower-case name -> id
var GLD_BY_MEMBER = {};// player uuid -> id
var GLD_BY_CHUNK = {}; // "dim|cx|cz" -> id
var GLD_DIRTY = {};    // ids whose cached member power changed (saved in batches)

function gldNewId() { return Date.now().toString(36) + Math.floor(Math.random() * 1e8).toString(36); }
function gldChunkKey(dim, cx, cz) { return dim + "|" + cx + "|" + cz; }
function gldChunkOf(x) { return Math.floor(x) >> 4; }
function gldParseKey(k) { let i = k.lastIndexOf("|"), j = k.lastIndexOf("|", i - 1); return { dim: k.substring(0, j), cx: parseInt(k.substring(j + 1, i)), cz: parseInt(k.substring(i + 1)) }; }

/** Fill in anything an older or hand-edited record is missing, so the rest of the code can trust the shape. */
function gldNormalize(g) {
    g.name = String(g.name || "Guild");
    g.tag = String(g.tag || g.name.substring(0, 3).toUpperCase());
    g.color = String(g.color || GLD_CFG.get("defaultColor"));
    g.description = String(g.description || "");
    g.motd = String(g.motd || "");
    g.open = !!g.open;
    g.bank = Number(g.bank) || 0;
    g.claimBonus = Number(g.claimBonus) || 0;
    g.createdAt = Number(g.createdAt) || Date.now();
    ["members", "memberNames", "memberPower", "warps", "relations", "flags", "rolePerms", "memberPerms"].forEach((k) => { if (!g[k] || typeof g[k] !== "object") g[k] = {}; });
    ["invites", "claims"].forEach((k) => { if (!g[k] || typeof g[k].length !== "number") g[k] = []; });
    GLD_FLAGS.forEach((f) => { if (g.flags[f] === undefined) g.flags[f] = GLD_FLAG_DEFAULTS[f]; });
    ["RECRUIT", "MEMBER", "OFFICER"].forEach((r) => { if (!g.rolePerms[r] || typeof g.rolePerms[r].length !== "number") g.rolePerms[r] = GLD_DEFAULT_PERMS[r].slice(); });
    if (g.leader && g.members[g.leader] !== "LEADER") g.members[g.leader] = "LEADER";
    return g;
}

function gldLoad() {
    GLD = {}; GLD_BY_NAME = {}; GLD_BY_MEMBER = {}; GLD_BY_CHUNK = {};
    RPG.data.keys("guild|").forEach((k) => {
        let g = RPG.data.get(k);
        if (!g || !g.id) return;
        gldNormalize(g);
        GLD[g.id] = g;
        GLD_BY_NAME[g.name.toLowerCase()] = g.id;
        Object.keys(g.members).forEach((u) => { if (!GLD_BY_MEMBER[u]) GLD_BY_MEMBER[u] = g.id; });
        g.claims.forEach((c) => { if (!GLD_BY_CHUNK[c]) GLD_BY_CHUNK[c] = g.id; });
    });
}
gldLoad();

function gldSave(g) { RPG.data.set("guild|" + g.id, g); delete GLD_DIRTY[g.id]; gldChanged(); }
function gldById(id) { return id ? GLD[id] || null : null; }
function gldByName(name) { return name ? gldById(GLD_BY_NAME[String(name).toLowerCase()]) : null; }
/** A player's guild (player or uuid), or null. */
function gldOf(p) { if (!p) return null; return gldById(GLD_BY_MEMBER[typeof p === "string" ? p : p.uuid]); }
function gldAll() { return Object.keys(GLD).map((id) => GLD[id]); }
function gldOwnerOf(dim, cx, cz) { return gldById(GLD_BY_CHUNK[gldChunkKey(dim, cx, cz)]); }
function gldOwnerAt(dim, x, z) { return gldOwnerOf(dim, gldChunkOf(x), gldChunkOf(z)); }

/** Something other addons or the clients care about changed (tags, relations, membership): resync soon. */
var GLD_SYNC_PENDING = false;
function gldChanged() {
    if (GLD_SYNC_PENDING) return;
    GLD_SYNC_PENDING = true;
    RPG.schedule(2, () => { GLD_SYNC_PENDING = false; if (typeof gldSyncLooks === "function") gldSyncLooks(); });
}

// ---- members and ranks ----------------------------------------------------------------------

function gldRole(g, uuid) { return g && g.members[uuid] ? String(g.members[uuid]) : null; }
function gldRank(role) { return GLD_ROLES.indexOf(String(role)); }
function gldName(g, uuid) {
    let p = RPG.server.players().filter((q) => q.uuid === uuid)[0];
    if (p) return p.name;
    return (g && g.memberNames[uuid]) ? String(g.memberNames[uuid]) : "Unknown (" + String(uuid).substring(0, 8) + ")";
}
/** A member by (partial, case-insensitive) name, or null. */
function gldFindMember(g, name) {
    let low = String(name || "").toLowerCase();
    if (!low) return null;
    let uuids = Object.keys(g.members), exact = uuids.filter((u) => gldName(g, u).toLowerCase() === low);
    if (exact.length) return exact[0];
    let part = uuids.filter((u) => gldName(g, u).toLowerCase().indexOf(low) === 0);
    return part.length === 1 ? part[0] : null;
}
function gldOnline(g) { return RPG.server.players().filter((q) => !!g.members[q.uuid]); }

/** Does this member have a guild permission? Leaders always do; a per-member override beats the rank. */
function gldCan(g, uuid, perm) {
    let role = gldRole(g, uuid);
    if (!role) return false;
    if (role === "LEADER") return true;
    let o = g.memberPerms[uuid];
    if (o && o[perm] !== undefined && o[perm] !== null) return !!o[perm];
    return (g.rolePerms[role] || []).indexOf(perm) >= 0;
}

function gldAddMember(g, p, role) {
    g.members[p.uuid] = role;
    g.memberNames[p.uuid] = p.name;
    g.invites = g.invites.filter((u) => u !== p.uuid);
    GLD_BY_MEMBER[p.uuid] = g.id;
    gldRefreshPower(p, g);
    gldSave(g);
}
function gldRemoveMember(g, uuid) {
    delete g.members[uuid]; delete g.memberPower[uuid]; delete g.memberPerms[uuid];
    if (GLD_BY_MEMBER[uuid] === g.id) delete GLD_BY_MEMBER[uuid];
    if (typeof GLD_CHANNEL !== "undefined") delete GLD_CHANNEL[uuid];
    gldSave(g);
}

// ---- create, rename, disband ----------------------------------------------------------------

/** Why a name can't be used, or "" if it can. */
function gldNameProblem(name, except) {
    name = String(name || "");
    let min = GLD_CFG.get("nameMinLength"), max = GLD_CFG.get("nameMaxLength");
    if (name.length < min || name.length > max) return "Guild name must be " + min + "-" + max + " characters.";
    if (!/^[A-Za-z0-9_\- ]+$/.test(name) || name.trim() !== name) return "Use letters, digits, spaces, _ and - only.";
    let other = gldByName(name);
    if (other && other !== except) return "That guild name is taken.";
    return "";
}
function gldTagProblem(tag) {
    tag = String(tag || "");
    if (tag.length < 1 || tag.length > GLD_CFG.get("tagMaxLength")) return "A tag is 1-" + GLD_CFG.get("tagMaxLength") + " letters or digits.";
    if (!/^[A-Za-z0-9]+$/.test(tag)) return "A tag is letters and digits only.";
    return "";
}

function gldCreate(p, name) {
    if (!gldHas(p, "guilds.create")) { gldMsg(p, "&cYou may not found a guild."); return null; }
    if (gldOf(p)) { gldMsg(p, "&cYou are already in a guild. Leave it first."); return null; }
    let bad = gldNameProblem(name, null);
    if (bad) { gldMsg(p, "&c" + bad); return null; }
    let cost = GLD_CFG.get("creationCost");
    if (cost > 0 && !p.takeMoney(cost)) { gldMsg(p, "&cFounding a guild costs " + gldMoney(cost) + "."); return null; }
    let tag = String(name).replace(/[^A-Za-z0-9]/g, "").substring(0, Math.min(3, GLD_CFG.get("tagMaxLength"))).toUpperCase() || "G";
    let g = gldNormalize({ id: gldNewId(), name: String(name), tag: tag, leader: p.uuid, members: {}, createdAt: Date.now() });
    g.members[p.uuid] = "LEADER";
    g.memberNames[p.uuid] = p.name;
    GLD[g.id] = g;
    GLD_BY_NAME[g.name.toLowerCase()] = g.id;
    GLD_BY_MEMBER[p.uuid] = g.id;
    gldRefreshPower(p, g);
    gldSave(g);
    RPG.broadcast(GLD_CFG.get("prefix") + "&f" + p.name + " &7founded the guild " + g.color + g.name + "&7.");
    return g;
}

function gldRename(g, name) {
    if (gldNameProblem(name, g)) return false;
    delete GLD_BY_NAME[g.name.toLowerCase()];
    g.name = String(name);
    GLD_BY_NAME[g.name.toLowerCase()] = g.id;
    gldSave(g);
    return true;
}

function gldDisband(g, by) {
    gldBroadcast(g, "&cThe guild has been disbanded" + (by ? " by " + by : "") + ".");
    g.claims.forEach((c) => { if (GLD_BY_CHUNK[c] === g.id) delete GLD_BY_CHUNK[c]; });
    Object.keys(g.members).forEach((u) => { if (GLD_BY_MEMBER[u] === g.id) delete GLD_BY_MEMBER[u]; if (typeof GLD_CHANNEL !== "undefined") delete GLD_CHANNEL[u]; });
    gldAll().forEach((o) => { if (o.relations[g.id]) { delete o.relations[g.id]; RPG.data.set("guild|" + o.id, o); } });
    delete GLD_BY_NAME[g.name.toLowerCase()];
    delete GLD[g.id];
    RPG.data.remove("guild|" + g.id);
    gldChanged();
}

function gldTransferLeader(g, uuid) {
    g.members[g.leader] = "OFFICER";
    g.leader = uuid;
    g.members[uuid] = "LEADER";
    delete g.memberPerms[uuid];
    gldSave(g);
}

// ---- power and the claim limit --------------------------------------------------------------

/** One member's power, read while they are online. Redefine this function in a later script to use your own. */
function gldMemberPower(p) {
    let src = String(GLD_CFG.get("claims.powerSource") || "level");
    if (src === "none") return 0;
    if (src === "level") return p.getLevel();
    let v = p.stat(src);
    return isFinite(v) ? v : 0;
}
function gldRefreshPower(p, g) {
    g = g || gldOf(p);
    if (!g || !g.members[p.uuid]) return;
    let v = Math.round(gldMemberPower(p) * 100) / 100;
    if (g.memberPower[p.uuid] !== v || g.memberNames[p.uuid] !== p.name) {
        g.memberPower[p.uuid] = v;
        g.memberNames[p.uuid] = p.name;
        GLD_DIRTY[g.id] = true;
    }
}
function gldPower(g) { let s = 0; Object.keys(g.memberPower).forEach((u) => { if (g.members[u]) s += Number(g.memberPower[u]) || 0; }); return s; }

/**
 * Chunks a guild may hold: the size ceiling (members x perMember) gated by power (power / powerPerClaim), taking
 * the smaller of the two, never below the base allowance, under the hard cap, plus any bonus bought with items.
 */
function gldMaxClaims(g) {
    let members = Object.keys(g.members).length;
    let ceiling = members * GLD_CFG.get("claims.baseClaimsPerMember");
    let per = GLD_CFG.get("claims.powerPerClaim");
    let scaled = (per > 0 && String(GLD_CFG.get("claims.powerSource")) !== "none") ? Math.min(ceiling, gldPower(g) / per) : ceiling;
    let n = Math.floor(Math.max(GLD_CFG.get("claims.baseClaimsPerGuild"), scaled));
    let cap = GLD_CFG.get("claims.maxClaimsHardCap");
    if (cap > 0) n = Math.min(n, cap);
    return n + g.claimBonus;
}
function gldOverclaimable(g) { return GLD_CFG.get("claims.allowOverclaim") && g.claims.length > gldMaxClaims(g); }

// ---- relations ------------------------------------------------------------------------------

function gldDeclared(from, to) { return String(from.relations[to.id] || "NEUTRAL"); }
/** "SELF", or the effective stance: enemy if either side says so, ally/truce only when both agree. */
function gldRelation(a, b) {
    if (!a || !b) return "NEUTRAL";
    if (a.id === b.id) return "SELF";
    let ra = gldDeclared(a, b), rb = gldDeclared(b, a);
    if (ra === "ENEMY" || rb === "ENEMY") return "ENEMY";
    if (ra === rb) return ra;
    return "NEUTRAL";
}
function gldSetRelation(from, to, rel) {
    if (rel === "NEUTRAL") delete from.relations[to.id]; else from.relations[to.id] = rel;
    gldSave(from);
    gldBroadcast(to, from.color + from.name + " &7now regards your guild as " + GLD_REL_COLOR[rel] + gldTitle(rel) + "&7."
        + (rel !== "NEUTRAL" && rel !== "ENEMY" && gldDeclared(to, from) !== rel ? " &8(/guild " + rel.toLowerCase() + " " + from.name + " to agree)" : ""));
}

// ---- claims ---------------------------------------------------------------------------------

function gldClaimDimOk(dim) {
    let dims = GLD_CFG.get("claims.dimensions") || [];
    return !dims.length || dims.map(String).indexOf(String(dim)) >= 0;
}

/** Claim one chunk for the player's guild. quiet: no message on success (area claims count them up instead). */
function gldClaim(p, dim, cx, cz, quiet) {
    let g = gldOf(p);
    if (!g) { gldMsg(p, "&cYou are not in a guild. Use /guild create <name>."); return false; }
    if (!gldCan(g, p.uuid, "claim")) { gldMsg(p, "&cYour guild rank lacks permission: claim"); return false; }
    if (!gldClaimDimOk(dim)) { gldMsg(p, "&cGuilds can't claim land in this dimension."); return false; }
    let key = gldChunkKey(dim, cx, cz), owner = gldById(GLD_BY_CHUNK[key]);
    if (owner === g) { if (!quiet) p.actionbar("&7Your guild already owns this chunk."); return false; }
    if (typeof LandClaims !== "undefined" && LandClaims) {
        let lc = LandClaims.ownerOfChunk(dim, cx, cz);
        if (lc) { p.actionbar("&cThis chunk is " + lc.name + "'s land claim."); return false; }
    }
    // RPG_CLAIM_HOOKS.veto: chunks other addons won't let anyone claim (see the Land Claims addon)
    let veto = null;
    if (typeof RPG_CLAIM_HOOKS !== "undefined" && RPG_CLAIM_HOOKS)
        RPG_CLAIM_HOOKS.veto.some((f) => { try { veto = f(dim, cx, cz) || null; } catch (e) { veto = null; } return !!veto; });
    if (veto) { if (!quiet) p.actionbar("&c" + veto); return false; }
    let overclaim = false;
    if (owner) {
        if (!(gldOverclaimable(owner) && gldRelation(g, owner) === "ENEMY")) { p.actionbar("&cThis land is claimed by " + owner.color + owner.name); return false; }
        overclaim = true;
    }
    if (g.claims.length >= gldMaxClaims(g)) { gldMsg(p, "&cYour guild holds " + g.claims.length + "/" + gldMaxClaims(g) + " chunks. Grow or gain power to claim more."); return false; }
    let cost = GLD_CFG.get("claims.claimCost");
    if (cost > 0) {
        if (g.bank < cost) { gldMsg(p, "&cA chunk costs " + gldMoney(cost) + " from the guild bank (it has " + gldMoney(g.bank) + ")."); return false; }
        g.bank -= cost;
    }
    if (overclaim) {
        owner.claims = owner.claims.filter((c) => c !== key);
        gldSave(owner);
        gldBroadcast(owner, "&c" + g.name + " seized a chunk at " + (cx * 16) + ", " + (cz * 16) + " (you hold more land than your limit).");
    }
    g.claims.push(key);
    GLD_BY_CHUNK[key] = g.id;
    gldSave(g);
    if (!quiet) {
        p.playSound("minecraft:block.note_block.chime", 0.6, 1.4);
        p.actionbar((overclaim ? "&6Seized" : "&aClaimed") + " chunk " + cx + ", " + cz + " &7(" + g.claims.length + "/" + gldMaxClaims(g) + ")");
    }
    return true;
}

function gldUnclaim(p, dim, cx, cz, quiet) {
    let g = gldOf(p), key = gldChunkKey(dim, cx, cz), owner = gldById(GLD_BY_CHUNK[key]);
    let admin = p && GLD_BYPASS[p.uuid];
    if (!owner) { if (!quiet) p.actionbar("&7Nobody owns this chunk."); return false; }
    if (owner !== g && !admin) { gldMsg(p, "&cYour guild does not own this chunk."); return false; }
    if (!admin && !gldCan(g, p.uuid, "unclaim")) { gldMsg(p, "&cYour guild rank lacks permission: unclaim"); return false; }
    owner.claims = owner.claims.filter((c) => c !== key);
    delete GLD_BY_CHUNK[key];
    if (owner.home && owner.home.dim === dim && gldChunkOf(owner.home.x) === cx && gldChunkOf(owner.home.z) === cz) owner.home = null;
    gldSave(owner);
    if (!quiet) p.actionbar("&7Chunk unclaimed &8(" + owner.claims.length + "/" + gldMaxClaims(owner) + ")");
    return true;
}

function gldUnclaimAll(g) {
    g.claims.forEach((c) => { if (GLD_BY_CHUNK[c] === g.id) delete GLD_BY_CHUNK[c]; });
    let n = g.claims.length;
    g.claims = [];
    g.home = null;
    gldSave(g);
    return n;
}

/** Claim every chunk in a rectangle (corner chunks inclusive). Returns how many were claimed. */
function gldClaimArea(p, dim, x1, z1, x2, z2) {
    let minX = Math.min(x1, x2), maxX = Math.max(x1, x2), minZ = Math.min(z1, z2), maxZ = Math.max(z1, z2);
    let count = (maxX - minX + 1) * (maxZ - minZ + 1);
    if (count > GLD_CFG.get("claims.maxAreaChunks")) { gldMsg(p, "&cThat area is " + count + " chunks; the most at once is " + GLD_CFG.get("claims.maxAreaChunks") + "."); return 0; }
    let keys = [];
    for (let cx = minX; cx <= maxX; cx++) for (let cz = minZ; cz <= maxZ; cz++) keys.push([cx, cz]);
    let n = 0;
    keys.forEach((k) => { let g = gldOf(p); if (g && g.claims.length < gldMaxClaims(g) && gldClaim(p, dim, k[0], k[1], true)) n++; });
    let g = gldOf(p);
    if (g) gldMsg(p, "&aClaimed " + n + " of " + count + " chunks &7(" + g.claims.length + "/" + gldMaxClaims(g) + ")");
    return n;
}

// ---- messages to a guild --------------------------------------------------------------------

function gldBroadcast(g, text) { gldOnline(g).forEach((q) => q.tell(GLD_CFG.get("prefix") + text)); }

// ---- teleports ------------------------------------------------------------------------------

function gldLoc(p) { return { dim: p.dimension, x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch }; }
var GLD_WARMUP = {};
function gldTeleport(p, loc, what) {
    let go = () => {
        p.setVar("ess_back", gldLoc(p));   // Essentials' /back takes you back from here
        p.teleportTo(loc.dim, loc.x, loc.y, loc.z, loc.yaw || 0, loc.pitch || 0);
        p.playSound("minecraft:entity.enderman.teleport", 0.6, 1.2);
        gldMsg(p, "&7Teleported to &f" + what + "&7.");
    };
    let secs = GLD_CFG.get("teleport.homeWarmupSeconds");
    if (secs <= 0) { go(); return; }
    let start = gldLoc(p), serial = (GLD_WARMUP[p.uuid] || 0) + 1, left = secs * 20;
    GLD_WARMUP[p.uuid] = serial;
    gldMsg(p, "&7Teleporting in &f" + secs + "&7s, don't move...");
    let tick = () => {
        if (GLD_WARMUP[p.uuid] !== serial) return;
        if (Math.abs(p.x - start.x) + Math.abs(p.y - start.y) + Math.abs(p.z - start.z) > 0.6) { gldMsg(p, "&cTeleport cancelled: you moved."); return; }
        left -= 5;
        if (left <= 0) go(); else RPG.schedule(5, tick);
    };
    RPG.schedule(5, tick);
}

// ---- admin bypass (needs guilds.admin.bypass and switching on with /guild admin bypass) --------

var GLD_BYPASS = {};

// ---- keep cached power fresh and saved ------------------------------------------------------

var GLD_POWER_TICK = {};
RPG.on("playerTick", (p) => {
    let n = (GLD_POWER_TICK[p.uuid] || 0) + 1;
    GLD_POWER_TICK[p.uuid] = n >= 30 ? 0 : n;
    if (n === 1) gldRefreshPower(p, null);
});
RPG.on("playerJoin", (p) => {
    gldRefreshPower(p, null);
    let g = gldOf(p);
    if (g && g.motd) RPG.schedule(40, () => p.tell(GLD_CFG.get("prefix") + "&7MOTD: &f" + g.motd));
    if (!g) {
        let inv = gldAll().filter((o) => o.invites.indexOf(p.uuid) >= 0);
        if (inv.length) RPG.schedule(40, () => gldMsg(p, "&7You have guild invites from &f" + inv.map((o) => o.name).join("&7, &f") + "&7. Use &f/guild join <name>&7."));
    }
});
RPG.every(1200, () => { Object.keys(GLD_DIRTY).forEach((id) => { let g = GLD[id]; if (g) RPG.data.set("guild|" + id, g); delete GLD_DIRTY[id]; }); });

// ---- public API for other addons and the project's own scripts ------------------------------

/** Read-only summaries (no live records), so other scripts can't break a guild by accident. */
var Guilds = {
    /** The guild owning chunk (cx, cz): {id, name, tag, color} or null. */
    ownerOfChunk: function (dim, cx, cz) { let g = gldOwnerOf(dim, cx, cz); return g ? { id: g.id, name: g.name, tag: g.tag, color: g.color } : null; },
    /** The guild owning the chunk at block (x, z). */
    ownerAt: function (dim, x, z) { let g = gldOwnerAt(dim, x, z); return g ? { id: g.id, name: g.name, tag: g.tag, color: g.color } : null; },
    /** A player's (or uuid's) guild: {id, name, tag, color, role} or null. */
    of: function (p) { let g = gldOf(p); return g ? { id: g.id, name: g.name, tag: g.tag, color: g.color, role: gldRole(g, typeof p === "string" ? p : p.uuid) } : null; },
    /** "SELF", "ALLY", "TRUCE", "NEUTRAL" or "ENEMY" between two players' guilds (NEUTRAL if either has none). */
    relation: function (a, b) { return gldRelation(gldOf(a), gldOf(b)); },
    /** May this player do perm ("build", "destroy", "container", "interact", "damagenpc") at block (x, z)? */
    canAffect: function (p, dim, x, z, perm) { return typeof gldMayAct === "function" ? gldMayAct(p, gldOwnerAt(dim, x, z), perm) : true; },
    /** Every guild as {id, name, tag, members, claims, maxClaims, power, bank}. */
    list: function () { return gldAll().map((g) => ({ id: g.id, name: g.name, tag: g.tag, members: Object.keys(g.members).length, claims: g.claims.length, maxClaims: gldMaxClaims(g), power: gldPower(g), bank: g.bank })); }
};
