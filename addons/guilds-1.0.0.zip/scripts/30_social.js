// =====================================================================================
//  Guilds - guild and ally chat, the guild tag in public chat, and tags over heads.
//
//  Chat tag: builds on whatever chat format was there before (Ranks & Kits' rank prefixes, or
//  vanilla) by chaining the earlier chatFormat override, so both show: "[TAG] [VIP] Steve » hi".
//  Over heads (tags.overhead):
//    hud  - each player's client draws "[TAG]" above other players, coloured by how the two
//           guilds stand (green own guild, dark green ally, aqua truce, yellow neutral, red enemy).
//           Uses no scoreboard team, so rank teams (Ranks & Kits) keep working.
//    team - one scoreboard team per guild with the tag as prefix (also in the tab list). A player
//           is only ever in one team, so this replaces rank teams for guild members.
// =====================================================================================

var GLD_CHANNEL = {};   // uuid -> "guild" | "ally" (absent = public)

function gldLine(fmt, p, g, message) {
    return String(fmt).replace(/\{name\}/g, p.name).replace(/\{role\}/g, gldTitle(gldRole(g, p.uuid)))
        .replace(/\{guild\}/g, g.name).split("{message}").join(message);
}
function gldSpy(kind, g, line) {
    RPG.server.players().forEach((q) => {
        if (!g.members[q.uuid] && GLD_SPY[q.uuid] && gldHas(q, "guilds.admin.spy")) q.tell("&8[Spy " + g.name + "] " + line);
    });
}
var GLD_SPY = {};

/** Send a guild-chat line from p. Returns false if p has no guild. */
function gldGuildChat(p, message) {
    let g = gldOf(p);
    if (!g) { gldMsg(p, "&cYou are not in a guild."); return false; }
    let line = gldLine(GLD_CFG.get("chat.guildFormat"), p, g, String(message).replace(/&/g, "&&"));
    gldOnline(g).forEach((q) => q.tell(line));
    gldSpy("guild", g, line);
    RPG.log("[Guild " + g.name + "] " + p.name + ": " + message);
    return true;
}
/** Ally chat: your guild plus every guild you are mutually allied with. */
function gldAllyChat(p, message) {
    let g = gldOf(p);
    if (!g) { gldMsg(p, "&cYou are not in a guild."); return false; }
    let line = gldLine(GLD_CFG.get("chat.allyFormat"), p, g, String(message).replace(/&/g, "&&"));
    let to = [g].concat(gldAll().filter((o) => gldRelation(g, o) === "ALLY"));
    RPG.server.players().forEach((q) => { if (to.some((o) => !!o.members[q.uuid])) q.tell(line); });
    gldSpy("ally", g, line);
    RPG.log("[Ally " + g.name + "] " + p.name + ": " + message);
    return true;
}

RPG.on("chat", (p, message) => {
    let ch = GLD_CHANNEL[p.uuid];
    if (!ch) return;
    if (!gldOf(p)) { delete GLD_CHANNEL[p.uuid]; return; }
    if (ch === "guild") gldGuildChat(p, message); else gldAllyChat(p, message);
    return false;
});

function gldChatTag(p) {
    let g = gldOf(p);
    if (!g) return "";
    return String(GLD_CFG.get("chat.tagFormat")).replace(/\{color\}/g, g.color).replace(/\{tag\}/g, g.tag).replace(/\{name\}/g, g.name);
}

(function () {
    let prev = null;
    let mine = (p, message, builtIn) => {
        let before = prev ? prev(p, message, builtIn) : null;
        let tag = GLD_CFG.get("chat.tagInChat") ? gldChatTag(p) : "";
        if (!tag) return before;
        let line = (before === null || before === undefined || String(before) === "") ? String(builtIn).replace(/&/g, "&&") : String(before);
        return tag + line;
    };
    prev = RPG.override("chatFormat", mine) || null;
    if (prev === mine) prev = null;
})();

// ---- tags over heads ------------------------------------------------------------------------

function gldTeamId(g) { return "gld_" + String(g.id).substring(0, 12); }

/** Push every online player's tag and relation table to the clients, and keep guild teams in step. */
function gldSyncLooks() {
    let mode = String(GLD_CFG.get("tags.overhead"));
    if (mode === "team") {
        let keep = {};
        gldAll().forEach((g) => {
            let t = gldTeamId(g);
            keep[t] = true;
            RPG.teams.define(t, { name: g.name, color: "white", prefix: "&8[" + g.color + g.tag + "&8] &r", friendlyFire: !!GLD_CFG.get("combat.guildFriendlyFire"), nametags: "always", collision: "always" });
        });
        RPG.teams.list().forEach((t) => { t = String(t); if (t.indexOf("gld_") === 0 && !keep[t]) RPG.teams.remove(t); });
    } else {
        RPG.teams.list().forEach((t) => { t = String(t); if (t.indexOf("gld_") === 0) RPG.teams.remove(t); });
    }
    RPG.server.players().forEach((p) => {
        let g = gldOf(p);
        if (mode === "team") {
            let cur = RPG.teams.get(p);
            cur = cur ? String(cur) : null;
            if (g && cur !== gldTeamId(g)) RPG.teams.join(p, gldTeamId(g));
            else if (!g && cur && cur.indexOf("gld_") === 0) RPG.teams.leave(p);
        }
        p.setShared("guild_tag", mode === "hud" && g ? g.tag : null);
        p.setShared("guild_id", mode === "hud" && g ? g.id : null);
        let rels = {};
        if (g) gldAll().forEach((o) => { let r = gldRelation(g, o); if (r !== "NEUTRAL") rels[o.id] = r; });
        RPG.net.send(p, "guild_rel", { me: g ? g.id : "", rels: rels, show: mode === "hud" });
    });
}
RPG.on("playerJoin", () => gldChanged());
RPG.net.on("guild_hello", () => gldChanged());
RPG.schedule(20, gldSyncLooks);
GLD_CFG.onChange((key) => { if (key.indexOf("tags.") === 0 || key.indexOf("combat.") === 0) gldChanged(); });
