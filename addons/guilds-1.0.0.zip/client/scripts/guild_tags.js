// =====================================================================================
//  Guilds (client script) - draws other players' guild tags above their heads, coloured by how
//  your guild stands with theirs: green your guild, dark green ally, aqua truce, yellow neutral,
//  red enemy. The server shares each player's tag (player.setShared) and sends you your
//  guild's relations; nothing here can change anything on the server.
// =====================================================================================
(function () {
    var REL = { me: "", rels: {}, show: false };
    var COLOR = { SELF: "&a", ALLY: "&2", TRUCE: "&b", NEUTRAL: "&e", ENEMY: "&c" };
    var shown = {};   // hud element id -> true

    function clearAll() { Object.keys(shown).forEach((id) => RPG.hud.remove(id)); shown = {}; }

    RPG.net.on("guild_rel", (d) => {
        REL.me = String(d && d.me || "");
        REL.rels = (d && d.rels) || {};
        REL.show = !!(d && d.show);
        if (!REL.show) clearAll();
    });

    function update() {
        if (!REL.show || !RPG.player.present) return;
        let range = Number(RPG.config.get("guilds", "tags.range", 32)) || 32, me = RPG.player, keep = {};
        RPG.avatar.players().forEach((pl) => {
            if (pl.local || pl.invisible || pl.crouching || pl.dead) return;
            let dx = pl.x - me.x, dy = pl.y - me.y, dz = pl.z - me.z;
            if (dx * dx + dy * dy + dz * dz > range * range) return;
            let tag = pl.shared("guild_tag", null);
            if (!tag) return;
            let gid = String(pl.shared("guild_id", "")), rel = gid === REL.me ? "SELF" : String(REL.rels[gid] || "NEUTRAL");
            let id = "guild_tag_" + pl.id;
            keep[id] = true;
            RPG.hud.set(id, { type: "text", entity: pl.id, offsetY: 0.8, text: "&8[" + (COLOR[rel] || "&e") + tag + "&8]", align: "center", shadow: true, scale: 0.9 });
            shown[id] = true;
        });
        Object.keys(shown).forEach((id) => { if (!keep[id]) { RPG.hud.remove(id); delete shown[id]; } });
    }

    RPG.every(5, update);
    RPG.on("load", () => RPG.net.send("guild_hello", {}));
    RPG.net.send("guild_hello", {});
})();
