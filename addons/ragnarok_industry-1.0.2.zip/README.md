# Ragnarok Industry

An official addon for the Ragnarok Modding Toolkit: power generation, energy storage, cables, fluid pipes, tanks,
pumps, a refinery and a fast quarry. Turn it on per world in the Addon Manager or with
`/rpg addons enable ragnarok_industry`.

Energy is **Ragnarok Energy (RE)**. Works with other mods' energy cables and machines, 1:1. Tanks, pipes and pumps
use the standard fluid capability, so other mods' pipes, tanks and buckets work with them too.

All content (names, art, numbers) is original.

Everything works as soon as the addon is turned on, with no restart: cables, pipes, power banks and machines at once,
and the ores in chunks generated from then on.

## Progression

1. **Galvanite** (common, y -32 to 80): smelt Raw Galvanite into ingots, beat ingots into plates with a **Forge
   Hammer** (crafted with an ingot). Basic Circuits, Machine Casings, Heat Coils and Solar Cells come from it, and every
   tier 1 machine.
2. **Sunsteel** (an alloy): Sunsteel Blend = 2 Galvanite Ingots + Gold Ingot + Blaze Powder, smelted. Advanced
   Circuits and Advanced Casings make tier 2.
3. **Ragnite** (rare, deepslate, y -64 to -12, diamond pickaxe; Blast Furnace only): Elite Circuits and Elite Casings
   make tier 3.
4. **Pyrolite** (y -24 to 56): shards burn in furnaces (12 items each) and a Refinery cracks them into **Pyrogas**.

Tier 2 and 3 machines are made from **two** of the tier below plus that tier's plates, circuits and casing:

```
P C P     P = plate of the tier    C = circuit of the tier
X M X     X = the machine one tier below    M = casing of the tier
P C P
```

## Generators

Generators push their energy into anything next to them that takes energy (cables, cells, machines, other mods'
blocks). A full buffer pauses fuel burning, so no fuel is wasted.

### Solar panels
Need open sky above. Output follows the sun (strongest at noon); rain 40%, thunderstorms 25%.

| Panel | Full sun | Night | Buffer | Output |
|---|---|---|---|---|
| Basic Solar Panel | 8 RE/t | 0 | 4,000 RE | 64 RE/t |
| Reinforced Solar Panel | 32 RE/t | 0 | 32,000 RE | 256 RE/t |
| Radiant Solar Panel | 128 RE/t | 12 RE/t (10%) | 128,000 RE | 1,024 RE/t |
| Celestial Solar Panel | 512 RE/t | 128 RE/t (25%) | 512,000 RE | 4,096 RE/t |

Recipes: Basic `SSS / PCP / III` (Solar Cells, Galvanite Plates, Basic Circuit, Iron Ingots). Reinforced `SSS / XCX /
PMP` (Solar Cells, 2 Basic panels, Advanced Circuit, Sunsteel Plates, Advanced Casing). Radiant: the same with Radiant
Cells and Reinforced panels. Celestial `SNS / XCX / PMP` (Radiant Cells, Nether Star, 2 Radiant panels, Elite Circuit,
Ragnite Plates, Elite Casing).

### Combustion generators
Burn anything a furnace burns (put it in the slot, or feed it with a hopper or pipe).

| Generator | Output | Coal gives | Buffer |
|---|---|---|---|
| Basic | 40 RE/t | 64,000 RE | 40,000 RE |
| Advanced | 120 RE/t | 80,000 RE | 160,000 RE |
| Elite | 360 RE/t | 96,000 RE | 640,000 RE |

Basic: `PCP / HMH / PFP` (Galvanite Plates, Basic Circuit, Heat Coils, Machine Casing, Furnace).

### Gas generators
Burn **Pyrogas** from their tank (pipes, Pyrogas Buckets in the top slot).

| Generator | Output | Per mB | Tank | Buffer |
|---|---|---|---|---|
| Basic | 100 RE/t | 400 RE | 8,000 mB | 100,000 RE |
| Advanced | 300 RE/t | 500 RE | 16,000 mB | 400,000 RE |
| Elite | 900 RE/t | 600 RE | 32,000 mB | 1,600,000 RE |

Basic: `PCP / BMB / PHP` (Galvanite Plates, Basic Circuit, Buckets, Machine Casing, Heat Coil).

### Lava heat generators
Two heat sources, each switchable in the screen:
- **Burn lava** from the tank (buckets in the top slot, pipes, pumps, other mods' fluid handlers).
- **Touching lava sources** (any side): free heat, or four times as much with **Consume** on, in which case each touching
  source cools to basalt after about two minutes on average.

| Generator | Burning lava | Per mB | Each touching source | With Consume | Tank | Buffer |
|---|---|---|---|---|---|---|
| Basic | 60 RE/t | 120 RE | 2 RE/t | 8 RE/t | 4,000 mB | 60,000 RE |
| Advanced | 180 RE/t | 150 RE | 6 RE/t | 24 RE/t | 8,000 mB | 240,000 RE |
| Elite | 540 RE/t | 180 RE | 18 RE/t | 72 RE/t | 16,000 mB | 960,000 RE |

Basic: `HCH / PMP / HNH` (Heat Coils, Basic Circuit, Galvanite Plates, Machine Casing, Magma Block).

## Storage and transport

### Energy cells
Take energy on every side and give it out of their front (the face that looked at you when placed). They keep their
charge when broken.

| Cell | Capacity | In / out |
|---|---|---|
| Basic | 500,000 RE | 1,000 RE/t |
| Advanced | 4,000,000 RE | 4,000 RE/t |
| Elite | 32,000,000 RE | 16,000 RE/t |

Basic: `PRP / RMR / PCP` (Galvanite Plates, Redstone Blocks, Machine Casing, Basic Circuit).

### Power banks
Touching power banks become **one bank**, in any shape, up to 512 blocks: capacities add up and so do the input and
output rates (each block adds its own; mixed tiers work too). The whole bank takes energy on every face; wrench a face
(or sneak-use it with an empty hand) to switch it **in → out → off**: an out face has an orange port and pushes
energy into whatever touches it (cables, machines, other mods' blocks), an off face a grey cover. Generators and cables
push their spare energy in, so a bank stores what isn't used. The gauge on each side shows the charge (four steps), a
comparator reads it (0-15), right-click opens a screen with the charge, the last tick's input and output and the
number of blocks, and a broken bank block keeps its share of the charge (shown on its tooltip) and brings it back when
placed against the bank again.

| Bank | Stores per block | In / out per block |
|---|---|---|
| Basic Power Bank | 1,000,000 RE | 2,000 RE/t |
| Advanced Power Bank | 8,000,000 RE | 8,000 RE/t |
| Elite Power Bank | 64,000,000 RE | 32,000 RE/t |
| Celestial Power Bank | 256,000,000 RE | 128,000 RE/t |

Basic: `PRP / CXC / PRP` (Galvanite Plates, Redstone Blocks, Basic Circuits, a Basic Energy Cell). Advanced and Elite:
two of the tier below with that tier's plates, circuit and casing. Celestial: `PNP / XMX / PCP` (Ragnite Plates, Nether
Star, two Elite banks, Elite Casing, Elite Circuit).

### Cables
Generators and cells push into a cable; the network feeds every machine it touches (never back to the block the energy
came from). Cables of different tiers join; a network carries what its slowest cable carries. Use a **Conduit Wrench**
(or sneak-use with an empty hand) on a connection to switch it off and on. Right-click shows the network's size.

| Cable | Carries | Recipe (makes 8) |
|---|---|---|
| Galvanite Cable | 1,000 RE/t | `KKK / MMM / KKK`, K = Dried Kelp, M = Galvanite Ingot |
| Sunsteel Cable | 8,000 RE/t | same with Sunsteel Ingots |
| Ragnite Cable | 64,000 RE/t | same with Ragnite Ingots |

### Fluid pipes
Wrench a connection to switch it: **normal → extract → off**. An extracting connection (orange ring) pulls from what it
touches and feeds every other connection in the network.

| Pipe | Moves | Recipe (makes 4) |
|---|---|---|
| Galvanite Fluid Pipe | 100 mB/t | `PGP`, P = Galvanite Plate, G = Glass |
| Sunsteel Fluid Pipe | 500 mB/t | same with Sunsteel Plates |
| Ragnite Fluid Pipe | 2,500 mB/t | same with Ragnite Plates |

### Tanks
Every tank is one block. **Touching tanks become one tank** in any shape (towers, walls, cubes, L-shapes), up to 512
blocks: one fluid, capacities add up (mixed tiers too), filled from the bottom layer up so each block shows its own
level. A tank holding a different fluid stays separate (you're told so); an empty one joins anything. A broken tank
keeps its share of the fluid (by capacity) in its item, and placing it against a group with the same fluid merges it
back. Right-click with a bucket to fill or empty; right-click empty-handed to see the amount.

| Tank | Capacity | Recipe |
|---|---|---|
| Galvanite Tank | 16,000 mB | `PGP / G G / PGP`, P = Galvanite Plate, G = Glass |
| Sunsteel Tank | 64,000 mB | same with Sunsteel Plates |
| Ragnite Tank | 256,000 mB | same with Ragnite Plates |

### Ender Tank
Every ender tank set to the same four digits (0000-9999) shares one **32,000 mB** tank, across any distance and
dimension. **Private** (only the owner can switch it) links only the ender tanks that owner placed with those digits;
only the owner can open a private one. Each ender tank moves up to 1,000 mB/t in and out. Buckets go in the left slots
(filling the tank) or the right slots (filling buckets). Ender tanks never join normal tanks.
Recipe: `OEO / ATA / OEO` (Obsidian, Ender Pearls, Advanced Circuits, Sunsteel Tank).

**Keeping chunks loaded:** the owner can switch an ender tank to keep its own chunk (**1x1**) or the **3x3** chunks
around it loaded and running (the button beside Private), so a pump next to it in the Nether keeps filling the shared
tank while nobody is there. It survives server restarts and stops when the tank is broken or switched off. Server
owners set it in the `ragnarok_industry` config (`/rpg config ragnarok_industry`): `chunkLoading.enderTanks` (on by
default), `chunkLoading.maxChunksPerPlayer` (9: one 3x3 tank, or nine 1x1 ones; you're told when it's reached) and
`chunkLoading.whileOwnerOffline` (on; off lets the chunks go while the owner is offline and loads them again when they
join). The server's overall limit on kept-loaded chunks (`/rpg chunks`) applies too.

## Machines

### Refinery
Uses 40 RE/t while working. Water goes in by pipe or bucket; the Pyrogas comes out by pipe (extract) or into buckets.

| Input | Water | Pyrogas | Time |
|---|---|---|---|
| Pyrolite Shard | 250 mB | 500 mB | 5 s |
| Coal | 250 mB | 150 mB | 5 s |
| Charcoal | 250 mB | 120 mB | 5 s |
| Blaze Powder | 100 mB | 400 mB | 4 s |

Recipe: `PCP / BMB / PFP` (Galvanite Plates, Basic Circuit, Buckets, Machine Casing, Blast Furnace).

### Pumps
**World mode**: drains fluid source blocks below the pump, nearest first in each layer, layer by layer down, leaving air
or cobblestone (a setting). 250 RE per bucket. **Tank mode**: pulls from the tank (or any fluid block) below it.
Either way it pushes its tank into the tanks and pipes on its other sides. Respects land claims and spawn protection.

| Pump | Reach | Depth | Speed | Tank mode | Tank | Buffer |
|---|---|---|---|---|---|---|
| Basic | 8 blocks out | 16 | 1 bucket/s | 200 mB/t | 8,000 mB | 20,000 RE |
| Advanced | 16 | 32 | 4 buckets/s | 1,000 mB/t | 16,000 mB | 80,000 RE |
| Elite | 32 | 64 | 16 buckets/s | 5,000 mB/t | 32,000 mB | 320,000 RE |

Basic: `PCP / BMB / PKP` (Galvanite Plates, Basic Circuit, Buckets, Machine Casing, Galvanite Fluid Pipes).

### Quarries
Place the quarry facing you: it mines the square **behind** it, starting next to it, from its own level down to
bedrock, one layer at a time. Set the size with − / + (8 up to the tier's maximum) and press **Running**.

- Mined items go straight into its 18-slot buffer (no items on the ground), then into a chest, hopper, pipe or any other
  mod's inventory next to it. Touching a **Simple Storage** network (a cable, connector, terminal or giant chest of it),
  it sends them into the network, spread the way the network stores items (only while the network has power). When
  everything is full it **pauses** and goes on once there is room.
- It mines ores of every addon (Galvanite, Pyrolite, Ragnite, Dragon Block Ragnarok's...), with Fortune and Silk Touch
  applying to them.
- It needs energy for every block; out of energy it pauses too.
- Once it reaches bedrock it shows **Finished**. A finished quarry looks over its area again every 10 minutes and
  mines whatever was put back (a pit filled in, sand dropped into it); **Restart** starts it over from the top at once.
- It only works while its chunks are loaded. **Keep loaded** keeps the area's chunks (up to 25 per quarry) loaded while
  nobody is near; the server caps how many chunks all machines may keep loaded (64 by default,
  `serverconfig/ragnarok_rpg-chunks.toml`).
- **Void junk** throws away cobblestone, cobbled deepslate, dirt, gravel, sand, netherrack, tuff, diorite, andesite,
  granite and calcite instead of storing them.
- It respects land claims (it works for whoever placed it, so it mines their own and trusted claims only) and spawn
  protection; the status shows how many protected blocks it skipped. Blocks with inventories (chests, machines) are
  left alone.
- Upgrades: up to 4 **Speed** (+50% blocks each, +25% energy per block each), **Fortune** I-III (stack 1-3, +50%
  energy per level) or **Silk Touch** (+50% energy).

| Quarry | Max area | Speed | Energy per block | Buffer | Input |
|---|---|---|---|---|---|
| Basic | 16 x 16 | 1 block/t | 150 RE | 50,000 RE | 2,000 RE/t |
| Advanced | 32 x 32 | 4 blocks/t | 120 RE | 200,000 RE | 8,000 RE/t |
| Elite | 64 x 64 | 12 blocks/t | 100 RE | 800,000 RE | 32,000 RE/t |

Basic: `PCP / DMD / PHP` (Galvanite Plates, Basic Circuit, Diamond Pickaxes, Machine Casing, Hopper).

## Items and other recipes

| Item | Recipe |
|---|---|
| Galvanite Ingot | smelt or blast Raw Galvanite (or the ore) |
| Sunsteel Blend (2) | shapeless: 2 Galvanite Ingots, Gold Ingot, Blaze Powder |
| Sunsteel Ingot | smelt or blast Sunsteel Blend |
| Ragnite Ingot | blast Raw Ragnite |
| Galvanite / Sunsteel / Ragnite Plate | shapeless: Forge Hammer + ingot (the hammer takes 1 damage) |
| Block of Galvanite / Sunsteel / Ragnite | 9 ingots (and back) |
| Forge Hammer | `III / III / _S_` Iron Ingots, Stick |
| Conduit Wrench | `G_G / _G_ / _G_` Galvanite Ingots |
| Basic Circuit (2) | `RCR / GPG / RCR` Redstone, Copper Ingots, Galvanite Ingots, Galvanite Plate |
| Advanced Circuit (2) | `GQG / CSC / GQG` Gold Ingots, Quartz, Basic Circuits, Sunsteel Plate |
| Elite Circuit (2) | `DRD / AEA / DRD` Diamonds, Ragnite Plates, Advanced Circuits, Ender Pearl |
| Machine Casing | `PIP / I_I / PIP` Galvanite Plates, Iron Ingots |
| Advanced Casing | `SBS / CMC / SBS` Sunsteel Plates, Blaze Rods, Advanced Circuits, Machine Casing |
| Elite Casing | `RNR / EAE / RNR` Ragnite Plates, Netherite Scrap, Elite Circuits, Advanced Casing |
| Heat Coil (2) | `CCC / CPC / CCC` Copper Ingots, Galvanite Plate |
| Solar Cell (2) | `GGG / LPL / CRC` Glass Panes, Lapis, Galvanite Plate, Copper Ingots, Redstone |
| Radiant Cell | `GQG / SCS / GDG` Glowstone Dust, Quartz, Sunsteel Plates, Solar Cell, Diamond |
| Quarry Speed Upgrade | `RSR / SCS / RSR` Redstone, Sugar, Advanced Circuit |
| Quarry Fortune Upgrade | `LGL / GCG / LGL` Lapis Blocks, Gold Ingots, Advanced Circuit |
| Quarry Silk Touch Upgrade | `SES / ECE / SES` Slime Balls, Emeralds, Elite Circuit |

Every crafting, smelting and blasting recipe is a real recipe: JEI and the recipe book show them. Refinery recipes show
in the toolkit's Recipe Viewer (`U`).

## For server owners

- Everything runs server-side in the engine; generators, cables and tanks don't call a script every tick. Quarries
  and pumps run a short script every few ticks that hands the actual work to the engine with a budget.
- Measured (`/rpg profile`, dev build on a busy shared machine): 50 generators on 50 cables with two cells cost about
  0.05 ms/tick of engine time plus 0.15 ms/tick of scripts (solar and lava checks every 2 s). Four Elite quarries mining
  64x64 areas at full speed (about 43 blocks/tick together) add about 1.2 ms/tick of mining and 0.25 ms/tick of
  scripts; the dimension's whole tick went from about 10 ms to 15-17 ms, most of the difference being the game's own
  lighting and block updates sent to players for every mined block.
- `industry.admin` lets staff open other players' private ender tanks.
- Ids are permanent: the addon only ever adds new ones.

## Licence

Proprietary, under the same terms as the Ragnarok Modding Toolkit and its bundled addons (see LICENSE).
