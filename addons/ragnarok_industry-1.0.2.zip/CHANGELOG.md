# Changelog

## 1.0.2 (2026-11-23)

- A finished quarry no longer stays finished if its pit is filled in again: it looks over its area from the top every 10 minutes (status "Finished (checking)" while it does), and a **Restart** button in its screen starts it over from the top at once.

## 1.0.1 (2026-11-18)

- Cables and fluid pipes work as soon as the addon is turned on: no restart any more (they were missing until the game restarted). Cables and pipes already placed in worlds, and the ones in inventories, carry on as they are.
- Ores generate in new chunks as soon as the addon is turned on (no restart).
- **Power Banks** in four tiers (1M, 8M, 64M and 256M RE per block): touching banks become one bank whose capacity and input / output rates add up (up to 512 blocks). They take energy on every face; wrench a face (or sneak-use) to switch it to out or off, shown on the block. A charge gauge on every side, a screen with the charge, the last tick's input and output and the bank's size, comparator output by charge, and a broken bank keeps its share of the charge.
- Quarries mine Galvanite, Pyrolite and Ragnite ores (and other addons' script ores), with Fortune and Silk Touch upgrades applying to them.
- A quarry touching a Simple Storage network (cable, connector, terminal or giant chest) sends what it mines into the network; it pauses when the network is full or has no power, as when its buffer is full.
- Ender tanks can keep their chunk (1x1) or the 3x3 chunks around them loaded (owner only, a button in their screen), so a pump next to one in the Nether keeps filling the shared tank with nobody there. Server config `ragnarok_industry`: `chunkLoading.enderTanks`, `maxChunksPerPlayer` (9) and `whileOwnerOffline`; it survives restarts and stops when the tank is broken or switched off.

## 1.0.0 (2026-11-18)

- First release: solar panels (4 tiers), combustion, gas and lava heat generators (3 tiers each), energy cells,
  cables, fluid pipes, connected tanks (3 tiers each), ender tanks, a refinery, pumps and quarries (3 tiers each).
- Galvanite, Pyrolite and Ragnite ores with world generation; Sunsteel alloy; plates, circuits, casings, cells, coils,
  quarry upgrades, a Forge Hammer and a Conduit Wrench.
- Pyrogas, a gas fuel made in the Refinery.
- With JEI, the Refinery's recipes show in their own JEI category (needs the engine's JEI support for machine recipes).
- The Combustion Generator's Fuel button no longer sits on the inventory label.
- The quarry leaves no floating sand or gravel at the edge of its area, and water and lava there flow in.
- The first time a world turns the addon on, ops (or the singleplayer player) are told clearly that cables and pipes need one restart.
- Ragnarok Energy (RE) works with other mods' energy cables and machines, 1:1; fluids use the standard fluid capability.
