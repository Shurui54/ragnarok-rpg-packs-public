// =====================================================================================
//  Ragnarok Industry - machines: the Refinery (Pyrogas), pumps and quarries.
//  Pumps and quarries work from a cursor saved in the block (be.pump / be.mine in the engine), with a budget per
//  call, so a huge area costs no more per tick than a small one.
// =====================================================================================

// ---- refinery: Pyrolite (or coal) + water -> Pyrogas ---------------------------------------------------------
RI.REFINE = {};
RI.REFINE[RI.items.ri_pyrolite_shard] = { gas: 500, water: 250, ticks: 100 };
RI.REFINE["minecraft:coal"] = { gas: 150, water: 250, ticks: 100 };
RI.REFINE["minecraft:charcoal"] = { gas: 120, water: 250, ticks: 100 };
RI.REFINE["minecraft:blaze_powder"] = { gas: 400, water: 100, ticks: 80 };
RI.REFINE_RATE = 40;      // RE/t while refining

RI.machine("ri_refinery", {
    tier: 1, name: "&6Refinery", front: "refinery_front", frontOn: "refinery_front_on",
    lore: ["&7Cracks Pyrolite Shards (or coal) with water into Pyrogas.", "&7Uses &f" + RI.REFINE_RATE + " RE/t &7while working.",
           "&7Water goes in from any side; pipes can extract the Pyrogas."],
    be: {
        tickInterval: 5,
        inventory: { size: 5, accepts: function (slot, id) { return slot === 0 ? !!RI.REFINE[id] : slot === 1 || slot === 3; }, inputs: [0, 1, 3], outputs: [2, 4] },
        energy: { capacity: 20000, maxInput: 400, maxOutput: 0, sides: { all: "in" } },
        tanks: [{ capacity: 4000, accepts: ["minecraft:water"], sides: { all: "in" }, fillFrom: 1, emptyTo: 2 },
                { capacity: 8000, accepts: [RI.PYROGAS], sides: { all: "out" }, drainFrom: 3, drainTo: 4 }],
        activeProperty: "lit",
        onTick: function (be) {
            var d = be.data, item = be.get(0), r = item ? RI.REFINE[item.id] : null;
            var water = be.tank(0), gas = be.tank(1);
            var ok = r && water.amount >= r.water && gas.capacity - gas.amount >= r.gas && be.energy >= RI.REFINE_RATE * 5;
            if (!ok) { be.setActive(false); if (!r && d.p) { d.p = 0; be.setProgress(0); } return; }
            be.useEnergy(RI.REFINE_RATE * 5);
            be.setActive(true);
            d.p = (d.p || 0) + 5;
            if (d.p >= r.ticks) {
                d.p = 0;
                be.take(0, 1);
                be.drain(0, r.water);
                be.fill(1, RI.PYROGAS, r.gas);
            }
            be.setProgress(d.p / r.ticks);
        }
    },
    screen: function (be, p) {
        be.open(p, { title: RI.gui("Refinery"),
            slots: [{ x: 50, y: 35, slot: 0 }, { x: 8, y: 17, slot: 1, accepts: "fluid_container" }, { x: 8, y: 53, slot: 2 },
                    { x: 128, y: 17, slot: 3, accepts: "fluid_container" }, { x: 128, y: 53, slot: 4 }],
            gauges: [{ type: "fluid", x: 28, y: 17, tank: 0 }, { type: "progress", x: 72, y: 35 }, { type: "fluid", x: 104, y: 17, tank: 1 }, RI.ENERGY_GAUGE(152, 17)] });
    }
});

// ---- pumps ---------------------------------------------------------------------------------------------------
RI.PUMP = [null,
    { radius: 8, depth: 16, interval: 20, sources: 1, tank: 8000, buffer: 20000, transfer: 200 },
    { radius: 16, depth: 32, interval: 10, sources: 2, tank: 16000, buffer: 80000, transfer: 1000 },
    { radius: 32, depth: 64, interval: 10, sources: 8, tank: 32000, buffer: 320000, transfer: 5000 }];
RI.PUMP_RE = 250;           // per source block drained
RI.PUMP_RE_TRANSFER = 1;    // per 10 mB moved between tanks
for (var pt = 1; pt <= 3; pt++) (function (t) {
    var P = RI.PUMP[t];
    RI.machine("ri_pump_" + t, {
        tier: t, name: riTitle(t, "Pump"), front: "pump_front_" + t, frontOn: "pump_front_on_" + t,
        lore: ["&7World mode: drains fluid sources below it, nearest first,", "&7up to &f" + P.radius + " &7blocks out and &f" + P.depth + " &7down: &f" +
               RI.fmt(P.sources * 20 / P.interval * 1000) + " mB/s&7, " + RI.PUMP_RE + " RE per bucket.",
               "&7Tank mode: pulls from the tank below it (" + RI.fmt(P.transfer) + " mB/t).", "&7Pushes into tanks and pipes on its other sides."],
        be: {
            tickInterval: P.interval,
            energy: { capacity: P.buffer, maxInput: P.buffer / 20, maxOutput: 0, sides: { all: "in" } },
            tanks: [{ capacity: P.tank, sides: { all: "out" } }],
            activeProperty: "lit",
            onTick: function (be) {
                var d = be.data, worked = false;
                if (d.off) { be.setActive(false); RI.refresh(be); return; }
                if (d.mode === "tanks") {
                    var want = Math.min(P.transfer * P.interval, Math.floor(be.energy / RI.PUMP_RE_TRANSFER) * 10);
                    var got = be.pullFluid(0, want, ["down"]);
                    if (got > 0) { be.useEnergy(Math.ceil(got / 10) * RI.PUMP_RE_TRANSFER); worked = true; }
                    d.status = got > 0 ? "&aMoving fluid" : "&7Waiting for fluid below";
                } else {
                    var r = be.pump({ radius: P.radius, depth: P.depth, tank: 0, sources: P.sources, scan: 1024, energy: RI.PUMP_RE,
                        replace: d.replace ? "minecraft:cobblestone" : "minecraft:air", owner: d.owner, ownerName: d.ownerName });
                    worked = r.drained > 0;
                    d.status = r.state === "power" ? "&cOut of power" : r.state === "full" ? "&eTank full" : r.state === "lap" ? "&7No fluid in reach"
                        : r.state === "unloaded" ? "&eWaiting for chunks" : r.drained > 0 ? "&aPumping" : "&7Searching";
                    if (r.refused > 0) d.status = "&6Protected area skipped";
                }
                be.pushFluid(0, P.transfer * P.interval, ["north", "south", "east", "west", "up"]);
                be.setActive(worked);
                RI.refresh(be);
            }
        },
        screen: function (be, p) {
            var spec = { title: RI.gui(riTitle(t, "Pump")), slots: [], height: 176, inventory: { y: 94, labelY: 83 },
                gauges: [{ type: "fluid", x: 26, y: 17, tank: 0 }, RI.ENERGY_GAUGE(152, 17)],
                buttons: [RI.btn("mode", "", 50, 17, 96), RI.btn("replace", "", 50, 34, 96, ["What goes where a source was drained"]),
                          RI.btn("off", "", 50, 51, 96), RI.btn("status", "", 26, 70, 140)],
                onButton: function (pl, id, bench) {
                    var d = be.data;
                    if (id === "mode") { d.mode = d.mode === "tanks" ? "world" : "tanks"; be.resetWork("pump"); }
                    if (id === "replace") d.replace = !d.replace;
                    if (id === "off") d.off = !d.off;
                    be.save();
                    refresh(be, bench);
                } };
            function refresh(b, bn) {
                var d = b.data;
                bn.button("mode", { text: d.mode === "tanks" ? "&bMode: Tanks" : "&aMode: World" });
                bn.button("replace", { text: d.replace ? "Leave: Cobblestone" : "Leave: Air", enabled: d.mode !== "tanks" });
                bn.button("off", { text: d.off ? "&cStopped" : "&aRunning" });
                bn.button("status", { text: d.status || "&7Idle", enabled: false });
            }
            RI.track(be, p, be.open(p, spec), refresh);
        }
    });
})(pt);

// ---- quarries ------------------------------------------------------------------------------------------------
RI.QUARRY = [null,
    { max: 16, perTick: 1, re: 150, buffer: 50000, input: 2000 },
    { max: 32, perTick: 4, re: 120, buffer: 200000, input: 8000 },
    { max: 64, perTick: 12, re: 100, buffer: 800000, input: 32000 }];
RI.QUARRY_INTERVAL = 2;
RI.QUARRY_RECHECK = 12000;   // ticks a finished quarry waits before it looks over its pit again (10 minutes)
RI.QUARRY_MAX_FORCED = 25;    // chunks one quarry may keep loaded (64 x 64 plus its own); the server caps all of them (64 by default)
RI.JUNK = ["minecraft:cobblestone", "minecraft:cobbled_deepslate", "minecraft:dirt", "minecraft:gravel", "minecraft:netherrack",
           "minecraft:tuff", "minecraft:diorite", "minecraft:andesite", "minecraft:granite", "minecraft:calcite", "minecraft:sand"];
RI.BUFFER = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17];

// The quarry mines the square behind it (opposite its front), starting next to it, down to the bottom of the world.
RI.quarryArea = function (be, size) {
    var f = RPG.world.blockProperty(be.dimension, be.x, be.y, be.z, "facing") || "north";
    var h = Math.floor(size / 2), x1, z1;
    if (f === "north") { x1 = be.x - h; z1 = be.z + 1; }
    else if (f === "south") { x1 = be.x - h; z1 = be.z - size; }
    else if (f === "west") { x1 = be.x + 1; z1 = be.z - h; }
    else { x1 = be.x - size; z1 = be.z - h; }
    return { x1: x1, z1: z1, x2: x1 + size - 1, z2: z1 + size - 1 };
};
RI.quarryUpgrades = function (be) {
    var s = be.get(18), f = be.get(19), k = be.get(20);
    return { speed: s ? Math.min(4, s.count) : 0, fortune: f ? Math.min(3, f.count) : 0, silk: !!k };
};
RI.quarryForce = function (be, on) {
    var key = "ri_quarry:" + be.dimension + ":" + be.x + ":" + be.y + ":" + be.z;
    RPG.world.releaseForced(key);
    if (!on) return true;
    var a = RI.quarryArea(be, be.data.size || 16), n = 0, ok = true;
    var cx1 = Math.min(a.x1, be.x) >> 4, cx2 = Math.max(a.x2, be.x) >> 4, cz1 = Math.min(a.z1, be.z) >> 4, cz2 = Math.max(a.z2, be.z) >> 4;
    for (var cx = cx1; cx <= cx2; cx++) for (var cz = cz1; cz <= cz2; cz++) {
        if (++n > RI.QUARRY_MAX_FORCED || !RPG.world.forceLoad(key, be.dimension, cx, cz, true, { persist: true })) { ok = false; break; }
    }
    if (!ok) RPG.world.releaseForced(key);
    return ok;
};

for (var qt = 1; qt <= 3; qt++) (function (t) {
    var Q = RI.QUARRY[t];
    RI.machine("ri_quarry_" + t, {
        tier: t, name: riTitle(t, "Quarry"), front: "quarry_front_" + t, frontOn: "quarry_front_on_" + t,
        lore: ["&7Mines the square behind it (up to &f" + Q.max + "x" + Q.max + "&7) layer by layer,", "&7down to bedrock: &f" + Q.perTick + " &7block" + (Q.perTick > 1 ? "s" : "") + "/t, &f" + Q.re + " RE &7per block.",
               "&7Items go straight into its buffer, then into a chest", "&7or pipe next to it. Pauses when full or out of power.", "&7Respects land claims and spawn protection."],
        be: {
            tickInterval: RI.QUARRY_INTERVAL,
            inventory: { size: 21, outputs: RI.BUFFER, inputs: [18, 19, 20],
                accepts: function (slot, id) {
                    return slot === 18 ? id === RI.items.ri_speed_upgrade : slot === 19 ? id === RI.items.ri_fortune_upgrade : slot === 20 ? id === RI.items.ri_silk_upgrade : false;
                } },
            energy: { capacity: Q.buffer, maxInput: Q.input, maxOutput: 0, sides: { all: "in" } },
            activeProperty: "lit",
            onTick: function (be) {
                var d = be.data;
                if (!d.running) { be.setActive(false); return; }
                if (d.state === "done") {
                    // finished: it rests, then starts over from the top now and then, so a pit filled in again (or
                    // blocks dropped into it) gets mined; a rescan of an empty pit costs what mining scans anyway
                    var now = RPG.server.getTick();
                    if (!d.doneAt || d.doneAt > now) d.doneAt = now;
                    if (now - d.doneAt < RI.QUARRY_RECHECK) {
                        be.setActive(false);
                        if ((be.x + be.z + now) % 10 < RI.QUARRY_INTERVAL) be.pushItems(RI.BUFFER);
                        return;
                    }
                    be.resetWork("mine");
                    d.state = "ok"; d.doneAt = 0; d.recheck = true;
                }
                var u = RI.quarryUpgrades(be);
                var blocks = Math.max(1, Math.round(Q.perTick * (1 + 0.5 * u.speed) * RI.QUARRY_INTERVAL));
                var re = Math.round(Q.re * (1 + 0.25 * u.speed) * (u.silk ? 1.5 : 1 + 0.5 * u.fortune));
                var a = RI.quarryArea(be, Math.min(Q.max, d.size || 16));
                var r = be.mine({ x1: a.x1, z1: a.z1, x2: a.x2, z2: a.z2, top: be.y, blocks: blocks, scan: 4096, energy: re, slots: RI.BUFFER,
                    void: d.voidJunk ? RI.JUNK : [], fortune: u.silk ? 0 : u.fortune, silk: u.silk, owner: d.owner, ownerName: d.ownerName });
                if (r.refused) d.refused = (d.refused || 0) + r.refused;
                d.state = r.state;
                d.layer = r.y;
                if (r.mined > 0 || r.state === "done") d.recheck = false;
                be.setActive(r.mined > 0);
                if (r.state === "full" || (be.x + be.z + RPG.server.getTick()) % 10 < RI.QUARRY_INTERVAL) be.pushItems(RI.BUFFER);
                RI.refresh(be);
            }
        },
        placed: function (p, x, y, z) { var be = RI.be(p, x, y, z); if (be) { be.data.size = Math.min(16, Q.max); be.save(); } },
        screen: function (be, p) {
            var slots = [];
            for (var i = 0; i < 18; i++) slots.push({ x: 8 + (i % 6) * 18, y: 18 + Math.floor(i / 6) * 18, slot: i });
            slots.push({ x: 122, y: 18, slot: 18, accepts: RI.items.ri_speed_upgrade }, { x: 122, y: 36, slot: 19, accepts: RI.items.ri_fortune_upgrade },
                       { x: 122, y: 54, slot: 20, accepts: RI.items.ri_silk_upgrade });
            var spec = { title: RI.gui(riTitle(t, "Quarry")), height: 218, inventory: { y: 136, labelY: 125 }, slots: slots,
                gauges: [RI.ENERGY_GAUGE(152, 17)],
                buttons: [RI.btn("run", "", 8, 76, 50), RI.btn("smaller", "-", 62, 76, 14), RI.btn("size", "", 78, 76, 50), RI.btn("bigger", "+", 130, 76, 14),
                          RI.btn("void", "", 8, 92, 70, ["Void cobblestone, dirt, gravel,", "netherrack, tuff and other stone"]),
                          RI.btn("force", "", 80, 92, 88, ["Keep the area's chunks loaded (up to " + RI.QUARRY_MAX_FORCED + ")", "while nobody is near. The server caps how many."]),
                          RI.btn("status", "", 8, 76 + 32, 116),
                          RI.btn("restart", "Restart", 126, 76 + 32, 42, ["Start over from the top of the area", "(mines whatever was put back in the pit).", "A finished quarry also looks again every 10 minutes."])],
                onButton: function (pl, id, bench) {
                    var d = be.data;
                    if (id === "run") d.running = !d.running;
                    if (id === "smaller" || id === "bigger") {
                        var s = Math.max(8, Math.min(Q.max, (d.size || 16) + (id === "bigger" ? 8 : -8)));
                        if (s !== d.size) { d.size = s; be.resetWork("mine"); if (d.force) RI.quarryForce(be, true); }
                    }
                    if (id === "void") d.voidJunk = !d.voidJunk;
                    if (id === "restart") { be.resetWork("mine"); d.state = "ok"; d.doneAt = 0; d.recheck = false; d.layer = be.y; }
                    if (id === "force") { d.force = !d.force; if (!RI.quarryForce(be, d.force)) { d.force = false; pl.tell("&cThe server won't keep more chunks loaded right now."); } }
                    be.save();
                    refresh(be, bench);
                } };
            function refresh(b, bn) {
                var d = b.data, st = d.state;
                bn.button("run", { text: d.running ? "&aRunning" : "&cStopped" });
                bn.button("size", { text: (d.size || 16) + "x" + (d.size || 16), enabled: false });
                bn.button("void", { text: d.voidJunk ? "&6Void junk: On" : "&7Void junk: Off" });
                bn.button("force", { text: d.force ? "&dKeep loaded: On" : "&7Keep loaded: Off" });
                var s = !d.running ? "&7Stopped" : st === "power" ? "&cOut of power" : st === "full" ? "&eOutput full: waiting" : st === "done" ? "&aFinished" : d.recheck ? "&aFinished &7(checking)"
                    : st === "unloaded" ? "&eWaiting for chunks" : "&aMining layer y=" + d.layer;
                if (d.refused) s += " &6(" + RI.fmt(d.refused) + " protected)";
                bn.button("status", { text: s, enabled: false });
            }
            RI.track(be, p, be.open(p, spec), refresh);
        }
    });
})(qt);

// Breaking a quarry lets its chunks go.
RI.QUARRY_IDS = {};
for (var qi = 1; qi <= 3; qi++) RI.QUARRY_IDS[RI.blocks["ri_quarry_" + qi]] = true;
RPG.on("blockBreak", function (p, block, x, y, z, dim) {
    if (RI.QUARRY_IDS[block]) RPG.world.releaseForced("ri_quarry:" + dim + ":" + x + ":" + y + ":" + z);
});
