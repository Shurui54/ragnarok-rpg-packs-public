// =====================================================================================
//  Trading - requests, the trade session, escrow and the screen's server side
// =====================================================================================
//  Escrow: the player variable "trade.escrow" = { items: [{id, count, nbt}], money, cur, curItem, partner, at }
//  An offered stack lives ONLY there from the moment it leaves its owner's inventory until it is
//  handed back to that owner (take back, cancel, disconnect, death, crash, reload) or given to the
//  partner when the trade completes. It is never in an inventory and in the escrow at once.
//
//  Why nothing is copied or lost:
//    - The escrow is saved inside the owner's own player data, next to their inventory and wallet,
//      so every save (autosave, logout, crash recovery) has both from the same moment: an item is
//      either in the inventory or in the escrow, never both and never neither.
//    - Every move between an inventory and the escrow happens in one server tick.
//    - The escrow belongs to its OWNER. Whatever stops a trade (a disconnect, a death, a crash,
//      /rpg reload) only ever hands the items back to that owner: straight away when they are
//      online, otherwise the moment they join again.
//    - On completion both escrows are cleared before either side is paid, and items that don't
//      fit in an inventory drop at the player's feet instead of vanishing.
//    - Items only players may carry (RPG.items.confine: dragon balls...) are never dropped: the
//      swap waits until the receiver has a free slot for each, and one that can't be handed back
//      to its owner (full inventory) stays in their escrow until there is room.
//    - Offered money leaves the wallet when it is set (and comes back when lowered), so the
//      balance can't be spent twice while the trade is open.
//    - Any change to either offer clears both confirmations and stops the countdown.
// =====================================================================================
var TR_API = {};       // other addons: TR_API.request(from, to), TR_API.inTrade(player)
(function () {
    var SES = {};          // player uuid -> session (both sides point at the same object)
    var REQ = {};          // target uuid -> { from, fromName, at }
    var LAST = {};         // "from>to" -> last request time (cooldown)
    var CLICK = {};        // sneak-click de-duplication
    var NBT_MAX = 6000;

    function now() { return Date.now(); }
    function online(uuid) { let out = null; RPG.server.players().forEach((q) => { if (q.uuid === uuid) out = q; }); return out; }
    function escOf(p) {
        let e = p ? p.getVar("trade.escrow", null) : null;
        if (!e || typeof e !== "object") e = {};
        if (!Array.isArray(e.items)) e.items = [];
        e.money = Math.max(0, Math.floor(e.money || 0));
        return e;
    }
    function setEsc(p, e) { p.setVar("trade.escrow", !e || !e.items.length && !(e.money > 0) ? null : e); }
    function cleanStack(st) {
        if (!st || !st.id || st.id === "minecraft:air") return null;
        let o = { id: String(st.id), count: Math.max(1, st.count || 1) };
        if (st.nbt) o.nbt = String(st.nbt);
        return o;
    }
    function viewStack(st) {
        if (!st) return null;
        let o = { id: st.id, count: st.count };
        if (st.nbt && st.nbt.length <= NBT_MAX) o.nbt = st.nbt;
        return o;
    }
    function label(st) { return (st.count > 1 ? st.count + "x " : "") + (RPG.items.name(st.id) || st.id); }
    function confined(st) { try { return !!st && RPG.items.isConfined(st); } catch (e) { return false; } }
    function freeSlots(p) { let n = 0; for (let i = 0; i < 36; i++) if (!p.getStack(i)) n++; return n; }
    /** Hand stacks to a player: items only players may carry first and only into free slots (never dropped); the
     *  ones that don't fit are returned. Everything else as usual (dropped at their feet when full). */
    function hand(p, items) {
        let free = freeSlots(p), kept = [];
        items.filter(confined).forEach((st) => { if (free > 0) { p.giveStack(st); free--; } else kept.push(st); });
        items.filter((st) => !confined(st)).forEach((st) => p.giveStack(st));
        return kept;
    }
    /** Why another addon refuses that the receiver gets these stacks (RPG_TRADE_HOOKS), or null. */
    function vetoed(receiver, incoming, outgoing) {
        if (!receiver || !incoming.length) return null;
        let hooks = (typeof RPG_TRADE_HOOKS !== "undefined" && RPG_TRADE_HOOKS && RPG_TRADE_HOOKS.veto) || [];
        for (let i = 0; i < hooks.length; i++) {
            let r = null;
            try { r = hooks[i](receiver, incoming, outgoing); } catch (e) { RPG.log("[Trade] a trade hook failed: " + e); }
            if (r) return String(r);
        }
        return null;
    }
    /** Why the swap can't happen yet (room for confined items, other addons' rules), or null. */
    function swapBlocker(pa, pb, ea, eb) {
        let why = vetoed(pb, ea.items, eb.items) || vetoed(pa, eb.items, ea.items);
        if (why) return why;
        let need = (to, items) => { let n = items.filter(confined).length; return n > freeSlots(to) ? to.name + " needs " + n + " free inventory slot" + (n === 1 ? "" : "s") + " for the items only players may carry." : null; };
        return need(pb, ea.items) || need(pa, eb.items);
    }
    function other(s, uuid) { return s.a === uuid ? s.b : s.a; }
    function nameOf(s, uuid) { return s.a === uuid ? s.an : s.bn; }

    /** Why these two can't trade right now, or null. */
    function blocker(p, q, starting) {
        if (!q) return "That player isn't online.";
        if (p.uuid === q.uuid) return "You cannot trade with yourself.";
        if (!trHas(q, "trading.use")) return q.name + " can't trade.";
        if (TR_CFG.get("blockCreative") && (p.getGameMode() === "creative" || q.getGameMode() === "creative")) return "Players in creative mode can't trade.";
        if (starting && (SES[p.uuid] || SES[q.uuid])) return "One of you is already in a trade.";
        if (!p.isAlive() || !q.isAlive()) return "You can't trade right now.";
        if (!trHas(p, "trading.bypassdistance")) {
            if (TR_CFG.get("sameDimension") && p.dimension !== q.dimension) return q.name + " is in another dimension.";
            let max = TR_CFG.get(starting ? "maxDistance" : "keepDistance");
            if (max > 0 && (p.dimension !== q.dimension || p.distanceTo(q) > max)) return q.name + " is too far away (" + Math.round(max) + " blocks at most).";
        }
        return null;
    }

    // ---- requests ------------------------------------------------------------------------------------

    function request(p, q) {
        if (!trHas(p, "trading.use")) { trMsg(p, "&cYou can't trade."); return; }
        let err = blocker(p, q, true);
        if (err) { trMsg(p, "&c" + err); return; }
        let mine = REQ[p.uuid];
        if (mine && mine.from === q.uuid && now() - mine.at < TR_CFG.get("requestSeconds") * 1000) { accept(p, q.name); return; }
        if (q.getVar("trading.off", false) && !trHas(p, "trading.admin")) { trMsg(p, "&c" + q.name + " isn't taking trade requests."); return; }
        let key = p.uuid + ">" + q.uuid, cd = TR_CFG.get("requestCooldown") * 1000;
        if (LAST[key] && now() - LAST[key] < cd) { trMsg(p, "&cWait a moment before asking " + q.name + " again."); return; }
        LAST[key] = now();
        REQ[q.uuid] = { from: p.uuid, fromName: p.name, at: now() };
        trMsg(p, "&7Trade request sent to &f" + q.name + "&7.");
        trMsg(q, "&f" + p.name + " &ewants to trade with you. &a/trade accept &7or &c/trade deny");
        q.playSound("minecraft:block.note_block.pling", 0.6, 1.4);
    }

    function accept(p, fromName) {
        let r = REQ[p.uuid];
        if (!r || now() - r.at > TR_CFG.get("requestSeconds") * 1000 || fromName && r.fromName.toLowerCase() !== String(fromName).toLowerCase()) {
            delete REQ[p.uuid];
            trMsg(p, "&cYou have no pending trade request.");
            return;
        }
        delete REQ[p.uuid];
        let q = online(r.from);
        if (!q) { trMsg(p, "&cThe player who requested the trade is no longer online."); return; }
        let err = blocker(q, p, true);
        if (err) { trMsg(p, "&c" + err); return; }
        start(q, p);
    }

    function deny(p) {
        let r = REQ[p.uuid];
        delete REQ[p.uuid];
        if (!r) { trMsg(p, "&cYou have no pending trade request."); return; }
        trMsg(p, "&7Trade request denied.");
        let q = online(r.from);
        if (q) trMsg(q, "&c" + p.name + " denied your trade request.");
    }

    // ---- the session -----------------------------------------------------------------------------------

    function start(pa, pb) {
        // anything left from an earlier, interrupted trade goes home first
        [pa, pb].forEach((p) => giveBack(p, true));
        // items still waiting for room would land on the table: not until they are home
        let waiting = [pa, pb].filter((p) => escOf(p).items.length > 0);
        if (waiting.length) {
            [pa, pb].forEach((p) => trMsg(p, "&c" + waiting.map((w) => w.name).join(" and ") + " must make room in their inventory first: items from an earlier trade are waiting."));
            return;
        }
        let s = { id: now().toString(36), a: pa.uuid, b: pb.uuid, an: pa.name, bn: pb.name, conf: {}, cd: 0, sig: {} };
        s.conf[pa.uuid] = false; s.conf[pb.uuid] = false;
        SES[pa.uuid] = s; SES[pb.uuid] = s;
        [pa, pb].forEach((p) => { p.playSound("minecraft:block.chest.open", 0.5, 1.2); push(s, p, true); });
    }

    function invOf(p) {
        let inv = [], sig = "";
        for (let i = 0; i < 36; i++) {
            let st = cleanStack(p.getStack(i));
            inv.push(viewStack(st));
            sig += st ? st.id + "*" + st.count + (st.nbt ? st.nbt.length : "") + ";" : ";";
        }
        return { inv: inv, sig: sig };
    }

    function viewFor(s, p) {
        let o = other(s, p.uuid), me = escOf(p), them = escOf(online(o)), inv = invOf(p);
        s.sig[p.uuid] = inv.sig;
        return {
            active: true, self: p.name, other: nameOf(s, o), selfConfirmed: !!s.conf[p.uuid], otherConfirmed: !!s.conf[o],
            selfMoney: me.money, otherMoney: them.money, selfOffer: me.items.map(viewStack), otherOffer: them.items.map(viewStack),
            inv: inv.inv, cd: s.cd > 0 ? Math.max(0, s.cd - now()) : 0, money: TR_CUR.enabled(), currency: TR_CUR.name(),
            balance: TR_CUR.balance(p), maxItems: TR_CFG.get("maxItems"), maxMoney: TR_CFG.get("currency.max")
        };
    }
    function push(s, p, open, note, bad) {
        let v = viewFor(s, p);
        if (open) v.open = true;
        if (note) { v.note = note; v.bad = !!bad; }
        RPG.net.send(p, "tr_view", v);
    }
    function pushBoth(s, note, bad) {
        [s.a, s.b].forEach((u) => { let p = online(u); if (p) push(s, p, false, note, bad); });
    }
    function unconfirm(s) { s.conf[s.a] = false; s.conf[s.b] = false; s.cd = 0; }

    function closeFor(uuid, note) {
        let p = online(uuid);
        if (p) RPG.net.send(p, "tr_view", { active: false, note: note || "" });
    }
    function end(s) {
        if (SES[s.a] === s) delete SES[s.a];
        if (SES[s.b] === s) delete SES[s.b];
        s.done = true;
    }

    /** Hand an owner's escrow back. Online: now (the record is removed first). Offline: kept for their next join. */
    function giveBack(p, quiet) {
        if (!p) return false;
        let e = escOf(p);
        if (!e.items.length && !(e.money > 0)) return false;
        setEsc(p, null);
        let kept = hand(p, e.items);
        if (e.money > 0) TR_CUR.give(p, e.money, e.cur, e.curItem);
        if (kept.length) {
            // never dropped: they wait in the escrow (saved with the player) until a slot is free
            setEsc(p, { items: kept, money: 0, partner: "", at: now() });
            trMsg(p, "&eMake room in your inventory: " + kept.length + " item" + (kept.length === 1 ? "" : "s") + " from a trade will be handed back as soon as a slot is free.");
        }
        if (!quiet) p.playSound("minecraft:entity.item.pickup", 0.5, 1);
        return kept.length < e.items.length || e.money > 0;
    }

    function cancel(s, msg) {
        if (s.done) return;
        end(s);
        [s.a, s.b].forEach((u) => {
            let p = online(u);
            if (p) { giveBack(p, true); trMsg(p, "&c" + (msg || "Trade cancelled.")); }
            closeFor(u);
        });
    }

    function complete(s) {
        if (s.done) return;
        let pa = online(s.a), pb = online(s.b);
        if (!pa || !pb || !pa.isAlive() || !pb.isAlive()) { cancel(s, "Trade cancelled."); return; }
        let err = blocker(pa, pb, false);
        if (err) { cancel(s, "Trade cancelled: " + err); return; }
        let ea = escOf(pa), eb = escOf(pb);
        if (!ea.items.length && !eb.items.length && !ea.money && !eb.money) { unconfirm(s); pushBoth(s, "Nothing is on the table.", true); return; }
        let wait = swapBlocker(pa, pb, ea, eb);
        if (wait) { unconfirm(s); pushBoth(s, wait, true); [pa, pb].forEach((p) => trMsg(p, "&c" + wait)); return; }
        end(s);
        // both escrows are cleared before either side receives anything
        setEsc(pa, null);
        setEsc(pb, null);
        let tax = TR_CFG.get("currency.taxPercent");
        let net = (n) => Math.max(0, n - Math.floor(n * tax / 100));
        // (room for every item only players may carry was checked above, in this same tick)
        let leftA = hand(pa, eb.items), leftB = hand(pb, ea.items);
        if (leftA.length) setEsc(pa, { items: leftA, money: 0, partner: "", at: now() });
        if (leftB.length) setEsc(pb, { items: leftB, money: 0, partner: "", at: now() });
        if (eb.money > 0) TR_CUR.give(pa, net(eb.money), eb.cur, eb.curItem);
        if (ea.money > 0) TR_CUR.give(pb, net(ea.money), ea.cur, ea.curItem);
        log(s, ea, eb);
        [pa, pb].forEach((p) => {
            trMsg(p, "&aTrade completed.");
            p.playSound("minecraft:entity.player.levelup", 0.5, 1.5);
            closeFor(p.uuid);
        });
    }

    function log(s, ea, eb) {
        let max = TR_CFG.get("logSize");
        let entry = { t: now(), a: s.an, b: s.bn, ai: ea.items.map(label), bi: eb.items.map(label), am: ea.money, bm: eb.money };
        RPG.log("[Trade] " + s.an + " gave " + (entry.ai.join(", ") || "nothing") + (ea.money ? " + " + ea.money : "") + " | " + s.bn + " gave " + (entry.bi.join(", ") || "nothing") + (eb.money ? " + " + eb.money : ""));
        if (max <= 0) return;
        let lg = RPG.data.get("trade.log", []);
        if (!Array.isArray(lg)) lg = [];
        lg.push(entry);
        while (lg.length > max) lg.shift();
        RPG.data.set("trade.log", lg);
    }

    // ---- the screen talks to us here (never trusted) ------------------------------------------------------

    RPG.net.on("tr", (p, d) => {
        if (!d || typeof d !== "object") return;
        let s = SES[p.uuid];
        if (!s) { RPG.net.send(p, "tr_view", { active: false }); return; }
        let a = String(d.a), e, err = null;
        if (a === "cancel") { cancel(s, p.name + " cancelled the trade."); return; }
        if (a === "confirm") {
            if (!s.conf[p.uuid]) {
                let q = online(other(s, p.uuid)), ea = escOf(p), eb = escOf(q);
                if (!ea.items.length && !eb.items.length && !ea.money && !eb.money) { push(s, p, false, "Put something on the table first.", true); return; }
                let why = blocker(p, q, false) || (q ? swapBlocker(p, q, ea, eb) : null);
                if (why) { push(s, p, false, why, true); trMsg(p, "&c" + why); return; }
            }
            s.conf[p.uuid] = !s.conf[p.uuid];
            if (!s.conf[p.uuid]) s.cd = 0;
            if (s.conf[s.a] && s.conf[s.b]) {
                let cd = TR_CFG.get("countdown");
                if (cd <= 0) { complete(s); return; }
                s.cd = now() + cd * 1000;
            }
            pushBoth(s);
            return;
        }
        // everything below changes an offer: not while you are confirmed, and it clears both confirmations
        if (s.conf[p.uuid]) { push(s, p, false, "Unconfirm first to change your offer.", true); return; }
        e = escOf(p);
        if (a === "add") {
            let slot = Math.floor(d.slot);
            if (!(slot >= 0 && slot < 36)) return;
            let st = cleanStack(p.getStack(slot));
            if (!st || st.id !== String(d.id) || st.count !== Math.floor(d.count)) { push(s, p, false); return; }   // inventory moved under the click
            let q = online(other(s, p.uuid));
            if ((TR_CFG.get("blacklist") || []).indexOf(st.id) >= 0) err = "That item can't be traded.";
            else if (e.items.length >= TR_CFG.get("maxItems")) err = "Your trade offer is full.";
            else if (confined(st) && !TR_CFG.get("allowConfined")) err = "That item can only be carried by players, so it can't be traded.";
            else if (q && (err = vetoed(q, e.items.concat([st]), escOf(q).items))) trMsg(p, "&c" + err);   // the whole reason (the screen's line is short)
            else {
                p.setStack(slot, null);          // off the inventory and into escrow in the same tick
                e.items.push(st);
                e.partner = other(s, p.uuid); e.at = now();
                setEsc(p, e);
            }
        } else if (a === "remove") {
            let i = Math.floor(d.index);
            if (!(i >= 0 && i < e.items.length)) return;
            if (confined(e.items[i]) && freeSlots(p) < 1) { push(s, p, false, "Make room in your inventory first.", true); return; }
            let st = e.items.splice(i, 1)[0];
            setEsc(p, e);                        // out of escrow first, then back to the owner
            p.giveStack(st);
        } else if (a === "money") {
            if (!TR_CUR.enabled()) return;
            let amt = Math.floor(d.amount);
            if (!(amt >= 0)) return;
            amt = Math.min(amt, TR_CFG.get("currency.max"));
            let type = TR_CUR.type(), item = TR_CFG.get("currency.item");
            if (e.money > 0 && (e.cur !== type || type === "item" && e.curItem !== item)) {   // the currency changed: refund the old stake
                TR_CUR.give(p, e.money, e.cur, e.curItem);
                e.money = 0;
            }
            let diff = amt - e.money;
            if (diff > 0 && !TR_CUR.take(p, diff)) err = "You don't have " + TR_CUR.fmt(amt) + ".";
            else {
                if (diff < 0) TR_CUR.give(p, -diff, type, item);
                e.money = amt; e.cur = type; e.curItem = item;
                e.partner = other(s, p.uuid); e.at = now();
                setEsc(p, e);
            }
        } else return;
        if (err) { push(s, p, false, err, true); return; }
        unconfirm(s);
        pushBoth(s);
    });

    // ---- keeping sessions honest: distance, countdown, inventory changes, stale requests -------------------

    RPG.every(5, () => {
        let seen = {};
        Object.keys(SES).forEach((u) => {
            let s = SES[u];
            if (!s || seen[s.id]) return;
            seen[s.id] = true;
            let pa = online(s.a), pb = online(s.b);
            if (!pa || !pb) { cancel(s, "Trade cancelled."); return; }
            if (!trHas(pa, "trading.bypassdistance") && !trHas(pb, "trading.bypassdistance")) {
                let max = TR_CFG.get("keepDistance");
                if (TR_CFG.get("sameDimension") && pa.dimension !== pb.dimension) { cancel(s, "Trade cancelled: you are in different dimensions."); return; }
                if (max > 0 && (pa.dimension !== pb.dimension || pa.distanceTo(pb) > max)) { cancel(s, "Trade cancelled: you moved too far apart."); return; }
            }
            if (s.cd > 0 && now() >= s.cd) { complete(s); return; }
            [pa, pb].forEach((p) => { if (invOf(p).sig !== s.sig[p.uuid]) push(s, p, false); });
        });
        let t = now(), life = TR_CFG.get("requestSeconds") * 1000;
        Object.keys(REQ).forEach((u) => {
            let r = REQ[u];
            if (t - r.at <= life) return;
            delete REQ[u];
            let from = online(r.from), to = online(u);
            if (from) trMsg(from, "&7Your trade request" + (to ? " to " + to.name : "") + " expired.");
        });
    });

    // items that waited for room (see giveBack) go home once a slot is free
    RPG.every(40, () => {
        RPG.server.players().forEach((p) => {
            if (SES[p.uuid] || !p.getVar("trade.escrow", null) || freeSlots(p) < 1) return;
            if (giveBack(p, false)) trMsg(p, "&aItems from a trade were handed back.");
        });
    });

    RPG.on("playerLeave", (p) => {
        delete REQ[p.uuid];
        let s = SES[p.uuid];
        if (s) cancel(s, p.name + " left. Trade cancelled.");   // the leaver is still here: their items go straight back
        giveBack(p, true);
    });
    RPG.on("death", (p) => {
        let s = SES[p.uuid];
        // back into the inventory before the death drops are made, so they follow the rest of it
        if (s) cancel(s, "Trade cancelled: " + p.name + " died.");
    });
    RPG.on("playerJoin", (p) => {
        if (giveBack(p, false)) RPG.schedule(20, () => trMsg(p, "&eReturned items from a trade that was interrupted."));
    });

    // after /rpg reload the sessions are gone, so every open trade rolls back
    RPG.server.players().forEach((p) => {
        if (giveBack(p, true)) { trMsg(p, "&eThe trade was interrupted and your items were returned."); closeFor(p.uuid); }
    });

    // ---- ways in -----------------------------------------------------------------------------------------

    RPG.on("entityInteract", (p, entity) => {
        if (!TR_CFG.get("sneakClick") || !entity || !entity.isPlayer() || !p.isSneaking() || !trHas(p, "trading.use")) return;
        let t = RPG.server.getTick();
        if (CLICK[p.uuid] && t - CLICK[p.uuid] < 10) return false;
        CLICK[p.uuid] = t;
        request(p, entity.asPlayer());
        return false;
    });

    var HELP = "&7/trade <player> &8| &7accept [player] &8| &7deny &8| &7cancel &8| &7toggle";

    RPG.commands.register("trade", {
        root: true, permission: "trading.use", description: "Trade with a player: /trade <player>, /trade accept, /trade deny",
        suggest(p, args) {
            let names = RPG.server.players().filter((q) => !p || q.uuid !== p.uuid).map((q) => q.name);
            if (args.length <= 1) return ["accept", "deny", "cancel", "toggle"].concat(trHas(p, "trading.admin") ? ["log"] : []).concat(names);
            if (args[0] === "accept" || args[0] === "cancel") return names;
            return [];
        },
        run(p, args) {
            let sub = String(args[0] || "").toLowerCase();
            if (sub === "log") {
                if (!trHas(p, "trading.admin")) { trMsg(p, "&cYou can't do that."); return; }
                let who = args[1] && !/^\d+$/.test(args[1]) ? String(args[1]).toLowerCase() : "";
                let n = RPG.clamp(parseInt(who ? args[2] : args[1]) || 10, 1, 50);
                let lg = (RPG.data.get("trade.log", []) || []).filter((e) => !who || e.a.toLowerCase() === who || e.b.toLowerCase() === who).slice(-n);
                trMsg(p, "&6Last " + lg.length + " trade(s)" + (who ? " with " + args[1] : "") + ":");
                lg.forEach((e) => {
                    let ago = Math.max(0, Math.round((now() - e.t) / 60000));
                    let line = "&8" + ago + "m ago &f" + e.a + "&7: " + (e.ai.join(", ") || "-") + (e.am ? " &6+" + trNum(e.am) : "") + " &8<-> &f" + e.b + "&7: " + (e.bi.join(", ") || "-") + (e.bm ? " &6+" + trNum(e.bm) : "");
                    if (p) p.tell("  " + line); else RPG.log(line.replace(/&./g, ""));
                });
                return;
            }
            if (sub === "cancel" && args[1] && trHas(p, "trading.admin")) {
                let t = RPG.server.player(String(args[1]));
                let s = t && SES[t.uuid];
                if (!s) { trMsg(p, "&cThat player isn't trading."); return; }
                cancel(s, "Trade cancelled by staff.");
                trMsg(p, "&aCancelled " + t.name + "'s trade.");
                return;
            }
            if (!p) { trMsg(p, HELP); return; }
            if (sub === "accept") { accept(p, args[1]); return; }
            if (sub === "deny") { deny(p); return; }
            if (sub === "cancel") {
                let s = SES[p.uuid];
                if (s) { cancel(s, p.name + " cancelled the trade."); return; }
                let out = Object.keys(REQ).filter((u) => REQ[u].from === p.uuid);
                out.forEach((u) => delete REQ[u]);
                trMsg(p, out.length ? "&7Trade request cancelled." : "&cYou aren't trading.");
                return;
            }
            if (sub === "toggle") {
                let off = !p.getVar("trading.off", false);
                p.setVar("trading.off", off);
                trMsg(p, off ? "&7You no longer get trade requests." : "&aYou get trade requests again.");
                return;
            }
            if (!sub || sub === "help") { trMsg(p, HELP); return; }
            request(p, RPG.server.player(String(args[0])));
        }
    });

    TR_API.request = request;
    TR_API.inTrade = (p) => !!SES[p.uuid];
})();
