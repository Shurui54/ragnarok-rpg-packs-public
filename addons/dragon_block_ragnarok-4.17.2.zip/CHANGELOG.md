# Changelog

Dragon Block Ragnarok, newest first. The section for the published version is posted on Discord, so keep the heading
as `## <version> (YYYY-MM-DD)` and the bullets short.

## 4.17.2 (2026-11-25)

- The ki weapons look like the original's: the Ki Blade, Ki Scythe and Ki Claw Lance are drawn with the original's ki blade shader (a flickering blade of flame in your ki colour with its glow, the scythe's curved edge, the claw lance's rods and prongs) on the arm that holds them, in third person and on the first-person body. The beam sword strike grows the same blade. The old weapon models stay only for computers where the shader can't load, and on engines older than 0.29.5 (the shader look needs 0.29.5).
- Instant Transmission no longer throws purple portal particles: like the original, the body you leave behind stays a moment as a fading afterimage and you fade in where you arrive, with the original's teleport sounds.
- Charging ki attacks stay in your hands when you look around: orbs (two-handed charges most) follow the body's heading like the arms holding them, for you and for others; they still fire along your view.
- Beams and lasers hit exactly as wide as the original's: the Special Beam Cannon and the death beams were raised to at least half a block, so thin beams hit targets they visibly missed.

## 4.17.1 (2026-11-24)

- Ki Surge (and the God Ki awakening that replaces it with the toggle on) only arms once your power release has reached its current maximum (your cap, or the radial menu's release limit when one is set) and your ki is full; keep charging from there to fill it. Without Potential Unlock that maximum is 50 %, exactly like the original (each Potential Unlock level adds 5 %), so charging stopping at 50 % is the cap, not a bug.
- God Ki and Super Saiyan Blue now wear the original's god aura with the 3D aura on (as the old Super Saiyan God did), Blue Evolution and Blue Rampage the sparking aura; they fell back to the plain 3D shell.

## 4.17.0 (2026-11-24)

- Engine 0.29.3 runs all of this; with engine 0.29.4 (coming) the block or item you hold also shows in your body's hand in the animated first-person view.
- Punching a block with your fists shows the original's punch again (in first person too): since the client-timed combo, a click on a block mined it without any arm animation.
- Clicks in menus never make you punch: holding the left button while closing the inventory (or a menu that closes on the click) used to start the combo once the screen was gone, and holding right click in a menu could raise the guard.
- Smoother movement animations: a jump keeps its jump pose until it lands instead of switching to the fall pose for its last few ticks (two blends in half a second looked like a cut), real falls still get the fall pose; stepping down a block or over a slab no longer flashes the jump pose; the landing after a long fall plays once (it could start over for its last frames).
- The plain ki blast (Left Alt + right click) matches the original: it flies exactly to the crosshair like the original's (its first tick re-aims it from the ball, so the original's spread never applied; the volley's shots too), plays the original's blast sound at full volume (it was nearly silent), and a single blast points the throwing arm where you look for half a second (alternating hands) instead of playing the barrage animation; the volley keeps the barrage animation.
- Animations sent by the server (a technique, a dash, a ki blast) play for players you see for the first time too: the first one after joining was skipped.
- Shadow Dummies work like the original's. The Minigames tab's Shadow Dummy entry now summons your own (it said "coming soon"): it needs a Shadow Dummy defeated before, Ki Control and Ki Manipulation 5 (the panel lists what is missing), you pick its share of your power from 25 to 75 % (5 % steps) and it gets that share of your health and three quarters of it of your melee and ki damage, while you lose the same share of Strength, Strike, Ki Power and Resistance and of your max health, and your ki and stamina regenerate only up to what you kept. Hits and the kill on it pay that much more TP. It goes (and you get everything back) when it dies, when its finishing blow knocks you down instead of killing you, when it is more than 100 blocks away or in another dimension, and when you log in again. Mr. Popo's Shadow Clone copies your health and a quarter of your damage like the original (it used to keep its own 6 damage). The dummy itself has the original's stats (300 health, 15 attack, armour 10, speed 0.25), fights hand to hand with the saga enemy brain instead of firing a ki blast every 5 seconds (the original's never does), never despawns, and is named "Shadow Dummy"; killing Popo's pays half the TP for its health, like the original.
- God Ki replaces Super Saiyan God. Ask Earth's Shenron for the new "Knowledge of God Ki" wish (Saiyans, level 5000+), then perform the god ritual as the Super Saiyan God ritual worked (with other players, or alone in singleplayer by holding Charge Ki): it awakens God Ki for good. A God Ki toggle sits in the radial menu's Ki Actions beside Friendly Fist; with it on, a full Ki Surge awakens God Ki instead of the surge. Transforming into SSJ, SSJ 2 or SSJ 3 while in God Ki stacks it into Super Saiyan Blue, Blue Evolution or Blue Rampage (each needs that Super Saiyan level fully mastered); at 25 % mastery each Blue form gets its own entry in the form menu to transform straight into it. You descend from them step by step like any other form, down to God Ki and out of it. Their numbers and looks are in the README (God Ki x3.6 up to Blue Rampage x6.4). Characters who had the Knowledge of Super Saiyan God now have the Knowledge of God Ki; the old wish row is hidden. You can now also descend from the old Super Saiyan God form (it could only be waited out).
- Punches hit what the original's swing box covers instead of only what the crosshair is on: every enemy in front of you within the fist's reach (a 3-block-deep box for punches, wide or tall sweeps for the kicks and uppercut; the ki weapons reach 2.5 to 3.5), crosshair target first, like the original's TargetFinder. Flying punches connect much more often.
- The momentum strike (a punch thrown while flying at 0.65 blocks a tick or faster) now lands: it read your speed on the tick the punch connected, which is a standstill when you have just stopped against your target (the swing connects a few ticks after the click) or when your moves reach the server bunched up. It now counts your fastest flight step over the punch's wind-up.
- Giant fish spawn only in water, like the original (oceans, deep oceans, beaches and the Namekian rivers, at least two blocks deep): they used to be stood on beaches and river banks. They swim, hunt players in the water and drown on land, as the original's do; fish already in a world stay as they are.

## 4.16.3 (2026-11-23)

- Punches land on big bodies at their edge (an Oozaru's leg, a dinosaur's flank): the server measured the reach to the target's feet in the middle of its box, so hits on anything wider than a few blocks were refused.
- A player who left while dead before making a character gets the death screen when they come back, then the character creator after respawning (the creator opened over the death screen, showing the dead body lying in the race carousel, and Select left them dead).

## 4.16.2 (2026-11-18)

- Dimensional Punch shows the attacker's own arm (skin, sleeve, held item) reaching out of the portal like the original, instead of a flat stand-in; Zanzoken and the combo dashes leave an afterimage of the body itself where it was (0.85 alpha, fading over the last 55%); the Mystic Ball stretches the body along its flight and squashes it on each bounce, like the original.
- Hair no longer vanishes while a transformation charges for characters whose look has no hair style of its own (a race given by an operator, a race change, older characters): the charge blend read an empty style there and drew no hair until the form was reached. It now reads the style the avatar draws (the race's default preset), and if neither the current nor the next look resolves to a style on a computer, the avatar's own hair keeps showing instead of an empty blend.
- The original's armour sets are drawn with the original's armour model (its ArmorBaseModel: the hip flaps and shoulder pads the armour textures paint), so Broly's armour (Super) shows its sash and wristbands and Saiyan armour its hip guards; those pixels used to land on the skin layout's outer layer as stray patches. Armour now fits buffed and other reshaped bodies (SSJ Grade 2/3, Full Power, SSJ4, race variants): as in the original, on the buffed bodies (and Oozaru, the Bio-Androids, Frost Demon second / fifth / Final Power / Metal, 4 arms, Glind true form...) the original's armour chest is painted over the body itself, and every other piece is fitted to the body's armour bones.
- Flight matches the original more closely. Fast flight steers like DMZ: the mouse turns a smoothed attitude that levels itself near the horizon and can loop straight through the vertical, your body follows it a moment later and steers the flight, turning and A/D bank you, and a double tap of A or D is a barrel roll; the camera rolls with the attitude (and 30% of the bank with "Camera Movement while Flying"), easing level as you slow down. Fast flyers are drawn leaning their whole body the way they look (your own with the full attitude, bank and roll). Flying no longer turns on creative flight underneath: no wider view while flying, and holding sneak crouches like the original. A strike's throw on a flying player carries into their flight instead of being undone the next tick, a strike rush started while flying carries you instead of stopping at once, and ki strikes and power strikes reach the flying range while flying. The server refuses flight speeds no skill level can reach (the distance flown over the last second faster than 1.3x the fastest the original allows) by putting the player back; normal flight is never pulled back, even from a lagging client. Flight speeds checked in game against the original: 0.59 / 1.03 b/t (normal / sprint) at Fly 1, 0.98 / 1.72 at Fly 5, 1.48 / 2.58 at Fly 10. Needs engine 0.29.1.
- Ki attacks sit exactly where the original puts them while they charge, for you and everyone watching: the charge ball, wave orb, disk and Kill Driver ring are drawn every frame from your pose instead of jumping to your hands 20 times a second a tick behind (they shook and trailed while turning, walking and flying). Needs engine 0.29.1.
- Charge positions fixed against the original: the Destructo Disc (and the Double one) was drawn half its size above its spot while charging and flying; the Ki Barrage's twin orbs sat 0.4 x their size too low; the Soul Punisher and the Neo Tri-Beam's charge sat their own radius too far forward; the Kill Driver ring tipped up and down with your view (the original keeps it on your heading); the Hellzone Grenade's hand orbs now follow your body's heading (the model's hands) instead of your head, and start at a fifth of their size like the original. Big casters (tall races, giant forms) push the attacks out and up with their hitbox like the original.
- The wave orbs (Kamehameha, Galick Gun, Final Flash, Masenko, Heat Dome) grow eased in and out like the original instead of linearly; the Kamehameha's charge has the original's light rays, and the Galick Gun and Final Flash crackle with the original's ball lightning on the charging orbs, the muzzle and the head.
- Charge sounds as in the original: waves play the quiet fire whoosh and the explosion charge (Final Flash: its own charge; the Kamehameha adds its charge on top); Big Bang, Sokidan, Fake Moon, the Soul Punisher and the Neo Tri-Beam charge silently; giant balls, the beam and disks keep theirs.

- Punches feel snappier: like the original, your own client now times and aims each swing (the animation and the swing sound start on the click, the swing connects on your screen and tells the server whom it hit), and the server checks the timing, combo step, slot and reach before it lands. Measured on a test server, hits land about 110 ms sooner with no lag and about 55 ms sooner at 50 ms ping (needs engine 0.29.1; older engines keep the old flow).
- Clicking up to a tick before your next swing is ready queues it (for 4 ticks), and holding the attack button keeps the combo going, like the original.
- Clicks on someone while you are still recovering are ignored again (this check never worked), and raising your guard drops a swing that hasn't connected yet.

- Every mob, boss and NPC now has the original's hitbox, so melee, ki blasts, beams and targeting hit where the body is drawn and F3+B shows the same box on every client: before, most enemies and bosses had a 0.6 x 1.9 box whatever their size (a dinosaur, an Oozaru or Hirudegarn could only be hit around their feet, a Namekian frog or Saibaman was hit in the air beside it). The boxes are the original's registered sizes at its model scales (giants with hit parts get the envelope of their parts); the Ragnarok original's dragons, rgnpc cast, shrine dragons and space garrison keep their own. Mobs, bosses and NPCs already in your world update when it loads.
- Gomah (world boss) is drawn at the original's size for each Demon Eye stack (2.0 to 6.5) instead of a fraction of it, and Gomah's third eye form and the Tamagami are drawn at the original's scale (5.5 and 1.5) in sagas and quests.
- Masters, Kibito, Oolong, Chiaotzu, Baba, the Namekian villagers, the Punch Machine and the Nimbus have the original's boxes too (Krillin and Old Kai were 20% too small).

## 4.16.1 (2026-11-18)

- Ki Sense's second mode (Search) now works like the original: the world turns fully grey (your hand and the HUD stay in colour) and everything sensed within range is wrapped in a coloured aura drawn over it (blue for weaker or peaceful, yellow for about even, red for stronger), instead of a coloured glowing outline. Ki Sense also switches off on respawn and dimension change, the client no longer thinks it is still on after you die, and with "Accumulative Damage" off Combat mode shows one rising number per hit, like the original.
- The Open Dragon Ball-Sack key defaults to period (.) instead of K, which is the toolkit menu key. A key you set yourself stays.
- Mr. Popo's Haircut, the character creator's Edit button and the Dragon Block menu always open the hair editor; the leftover fallbacks and "needs a newer engine" messages for old engine builds are gone.
- Hair editor: "Joints: Connected" now shows, like the original: the strand's segments join into one smooth bend.
- Hair editor: the original's colour picker (saturation and brightness square, hue bar, hex field, Auto and OK) instead of the generic one.
- Hair editor: clicking a strand selects the one under the mouse (it used to pick one beside it), and with Physics on it follows the swaying hair.
- Hair editor: opening it no longer counts as a change ("Hair Editor *"), so Esc closes it without asking until you edit something.
- Hair editor: with Physics off the model stops moving and stands still, like the original.
- Options (V menu > Config > Visuals): Hair Physics High / Low / Off, the original's hair physics quality, for how much hair moves on your computer.

## 4.16.0 (2026-11-17)

- Melee: every swing of the combo now hits when it connects, like the original (punches 4 ticks after the click, the low kick 7, the uppercut 5, the gut kick 6; ki weapons 5), so the target can still guard or parry in between; raising your own guard drops your swing. A new swing waits until the last one has landed plus the attack cooldown, and clicks on someone while you recover are ignored instead of landing a weak unanimated hit (needs engine 0.29; older engines keep the old timing).
- Melee knockback on characters scales with the hit like the original: mitigated hits barely push, a hit worth 15 % of someone's health or more throws them harder, a fully blocked or parried hit doesn't move them.
- Momentum strike: punching while flying at speed hits up to 1.5x harder, throws the target along your flight path with an impact frame, and a target slammed into a wall or the ground is stunned with the faint pose, a ring of rocks, a small crater and a clang.
- Strike attacks that throw someone into a wall or the ground now play the same collision impact (stun, faint pose, rocks, crater, clang) instead of a plain explosion.
- Dimensional Punch: portals open under the target and a fist strikes through each one three times, like the original, instead of the generic strike.
- Assault Rain: an orb over your shoulder sends shots up while a rain of ki blasts falls on a 6-block circle round the target from high above, for as long as the charge allows.
- Blaster Meteor: a see-through sphere lifts you while it charges, then fires ki blasts in every direction, two at a time aimed at your target.
- Hellzone Grenade: orbs form in your hands, two are thrown at the target, then up to 48 orbs (by the charge) surround it, hover, close in together and detonate in one big blast.
- Tri-Beam: a big glowing triangle that flies to the crosshair and explodes; the Neo Tri-Beam's charged triangle burrows through terrain.
- Kill Driver: a spinning ring of ki rises over your head while it charges, then flies at your target and bursts on contact (no terrain damage).
- These barrages no longer spawn one entity per shot: a two-player Assault Rain plus Hellzone Grenade spam keeps the server tick about 1 ms over idle.
- Ki balls splash on whoever they hit directly, like the original.
- Ki balls aimed at someone now fly at the middle of their body instead of their feet (they used to hit the ground in front of a target).
- The eight long strike combos play the original's choreography tick by tick: Meteor Burst (dash, punch, launch, stomp ride, knee, hammer slam, a ki ball pressed into the victim, six spheres, the blast), Mystic Ball Attack (curled into a ball, six bounces from random sides, the stomp), Darkness Eye Beam (backhand, choke, stretching arm, fling, roar, two eye lasers), Death Chaser, Android Combo (with its red ki bomb), Beam Sword Slash (the ki blade skewers the victim from above, then the slash), Perfect Rush (golden arcs) and Spirit Breaker (flurry, ram, flaming axe kick). The victim is carried through every move with the original's poses, damage shares (strike and ki), sounds, bursts, shockwaves, rocks and impact frames; world bosses are never carried. These seven start where you stand and dash in themselves.
- Grab Throw grabs, lifts and swings the victim round for 2.5 s and throws it into a wall; Shining Sword Attack cuts with five blue crescents and finishes with a golden ki wave; Dimensional Slash throws three huge dark red crescents that fly 40 blocks and cut 5 blocks into the terrain.
- Strikes that connect film the fight with the original's cinematic camera (third person, a three-quarter view of both fighters, swaying, narrower view), for the attacker and a player victim; it blends in and out and the mouse doesn't turn you while it films.
- Strike clashes: two players rushing at each other with strikes meet fist to fist and fight it out on the beam clash meter (right click on the marker); the winner's strike costs no cooldown, the loser takes half the winner's strike damage, is thrown into a collision impact and is exhausted; a tie throws both apart. A strike cast at someone rushing at you rushes back.
- Neo Tri-Beam: after firing it you have 3 s to right click for another triangle (up to three, each costs 10 % of your health, not below 20 %), and its charge crackles with blue lightning.
- Dimensional Punch: a portal opens over each mark and a fist punches through it; the marks and hits land on the original's ticks.
- Strike costs no longer include the combos' ki ratio (Meteor Burst cost 50 % too much, Darkness Eye Beam and Android Combo half too little).
- The Other World halo no longer stays over a revived player's head when they were revived before the server noticed them dead after a restart (or after a script reload): the saved halo is checked against whether they are dead.
- Hair moves like the original 2.2's: every segment of every strand is simulated with the hairstyle's own physics (base, SSJ/SSJ2, SSJ3 and SSJ4 profiles; blended while a transformation's hair grows), so long hair trails behind turns, flicks when you jump or land, sways while you stand, and rises and flickers while you charge ki, with the aura and a transformation charge stirring it harder. Needs engine 0.29; older engines keep today's sway.
- Hair Editor: the Physics switch now works like the original's: with it on, the preview's hair simulates as you turn the model.

## 4.15.1 (2026-11-17)

- Hair editor: the original's editor, with its layout, controls and art: strands per face, length, segments, falloff, width, depth, taper, angles, bends, twist, per-segment tweaks, colours, mirror, undo/redo and Generate from Base. Opens from the creator's hair tab (Edit), Mr. Popo's Haircut, the Dragon Block menu and `/dmzhair edit`.
- Hair codes: Import and Export (Style / Full) use the original 2.2's hair codes, old and new versions; a code copied from the original gives the same hair here, and a code exported here is exactly what the original would export. `/dmzhair export` copies yours from chat.
- Your own hairstyles are saved with each character; presets still work as before.
- The hair now grows into the next form while a transformation charges, falls back when you let go and fades over a second when you power down, like the original.
- Majins can wear hair (made in the hair editor), like the original.
- `/dmzhair resync` and `/dmzhair reset` like the original.
- On engines before 0.28.1 the hair editor and hair codes are switched off (the creator, Mr. Popo and the Dragon Block menu keep the presets) instead of failing to save.
- Hair saves are rate limited like the original (one per 10 ticks).

- Final Explosion looks like the original: a glowing sphere lifts you while it charges, then swells round you and keeps hitting for its whole duration.
- Ki attacks throw off their original sparks, flecks and splashes; small ki blasts leave a glowing streak; ki explosions animate at their real size.
- Melee hits, blocks, parries and guard breaks show the original's hit flashes, and bare-handed hits play the punch sounds.
- Ki surge / overcharge flame border hugs your real hair and body instead of showing a boxy shape like different hair or a cape (with engine 0.28.1).
- The ki surge flame border now shows for everyone, not only after you had charged ki yourself; the Dragon Block menu lists the Hair Editor.
- JEI: `@dragon`, `@dragon_block_ragnarok` or `@dragonblock` finds every Dragon Block item (with engine 0.28.1).

## 4.15.0 (2026-11-17)

- Dragon Block menu: `/dbrgui` or the "Dragon Block menu" key (default `` ` ``) opens one hub that reaches every Dragon Block screen.
- Key binds are grouped under their own Controls category.
- Space: the cereal village lookup works again.
- The world boss contribution panel recognises your own row reliably.
- The creator opens correctly when the art finishes downloading after you join.
- Works on engine 0.27 as well (the menu's back-to-hub needs 0.28).

## 4.14.1 (2026-11-16)

- Neutral wording in in-game text.

## 4.14.0 (2026-11-15)

- Ki attacks reworked: charging, placement, movement holds, fixed beams and the plain ki blast.
- Wild planet garrisons and the conquest defender.
- Masters can't be hurt or pushed and respawn at once.
- Auras: the God aura draws properly and the ki surge has a flame border.
- Space: planet dressing spread over ticks so servers don't stall.
- The character creator comes back after dying before it was used.
- Techniques say why a slot key did nothing.
- Guard works even when the window focus flag is wrong.
- False Super Saiyan, Super Saiyan 5, Super Saiyan God and Primal Namekian can be found and used.

## 4.13.0 (2026-11-14)

- Per-form dodge and damage-taken buffs; the form editor has its Dodge and Buffs tabs back.
- Transformation outlines on bosses and the Demon Eye.

## 4.12.0 (2026-11-14)

- Saibaman seeds: plant them on Rocky Dirt, grow them faster by charging ki nearby, and hatch a tamed Saibaman whose strength depends on how much of its growth was charged (3 per player).
- Buried seeds in the Saibamen huts on Planet Vegeta and on generated planets.
- The ki surge draws a flame outline round the body.
- 3D auras show again: round the body, leaning in fast flight and in the air.
- The Form Menu (X) follows the real key and no longer stays open after a quick hold.
- The placeholder charging particles are gone.

## 4.11.0 (2026-11-13)

- Planet Cereal: mesas, canyons, crystal fields, Cerealian villages and ruins, Granolah and Monaito with Monaito's quests, and the home of the Cerulean Dragon Balls.
- Beerus' planet in its own dimension, and the Vegeta capital round the landing spot; generated planets get craters, beaches, vegetation and Saibamen huts.
- Rituals: Ki sharing and the Super Saiyan God ritual (solo in single player), the Super Saiyan God charge ritual, the Super Saiyan 5 wish and the Namekian god ritual.
- Raids at raid sites: scouts, an omen, five waves, a boss bar, music and rewards.
- NPC-hosted tournaments: Fortuneteller Baba, the Cell Games, the World Martial Arts Tournament and the Otherworld Tournament.
- Racial skills: Human Adrenaline, Frost Demon Power Reserve, Saiyan Zenkai, Bio-Android Self-Destruct and Cell Jr., and Namekian assimilation requests.
- 3D auras with their original shaders; the form editor picks aura sheets, 3D styles, overlays and custom GeckoLib models.
- Every Dragon Radar is craftable, outfits and cosmetics are sewn in the Pattern and Kikono stations, and machine recipes show in the Recipe Viewer.
- The Dragon Ball-Sack accessory; one ball of each star per server, and lost balls go home. Graves are headstones, and a grave holding only balls shows them.
- Every command under `/rpgc` with permission nodes and tab completion; old command names still work; `/rpgc grantall` replaces `testall`.
- Tab list and rank badges.
- Capes sway and leg-covering outfit parts keep clear of the legs (outfitpack 1.0.1).
- Ground item clear, off by default (`/rpgc clearitems`).
- Every block has its proper sound, plants follow their ground rules, and Dragon Balls can be placed on any block again.
- Super Dragon Balls are solid and clickable from every side. Dragon Balls can be traded but not auctioned or put in vaults.
- Harder ki clashes.
- Menus: private sounds, one action per click, smoother panning, slide and fade transitions, and form editor saves that apply at once.
- Timed random events are gone (invasions, radar pings, Double TP Hour); the mobs and their spawns stay.

## 4.10.0 (2026-11-12)

- One-per-world landmarks keep 500 blocks from each other and 3 chunks from other structures, and pick their spot from the surface biome. New chunks only.
- The landmark search tries nearer rings again, and the Tree of Might and the Big Gete Star fall back to any clear ground after a long search.

## 4.9.3 (2026-11-12)

- Partial keep inventory and death graves: below level 100 you keep everything; from then on the hotbar, armour, off hand and accessories stay and the rest goes into a grave where you died. Dragon Balls are never kept. Settings in `dbr_keep_inventory`.
- Quest and forms trees stop panning as soon as the button is released.

## 4.9.2 (2026-11-12)

- The K menu keeps only Options; Status, Techniques and Sagas live in Dragon Block's own screens.

## 4.9.1 (2026-11-12)

- Outfit and cosmetic art moves to its own art pack (outfitpack), asked for automatically. Item ids are unchanged.

## 4.9.0 (2026-11-12)

- Quests count kills of NPCs made in the NPC editor, and quest marks show over NPCs (! to start, ? to hand in).
- Creator face and hair cards are still close-ups framed on the head.
- Rhythm charts are built over several ticks instead of stalling one.

## 4.8.1 (2026-11-12)

- 165 cosmetics in four cosmetic accessory slots, drawn on every race, with a creative tab and a Cosmetics page in the tailor's catalogue.
- Fixed invisible bodies after a race change.

## 4.8.0 (2026-11-11)

- Combat: dash, sonic crash through terrain, melee clashes with a rhythm panel, and NPC lunges.
- Lightning bolts around players.
- New crosshair and quest tracker; party, fusion, world boss and tournament HUDs redrawn.
- Used Dragon Ball sets sleep as stone for a Minecraft week.
- Beams in space, planet clashes with beams, and planet names on look.
- Searchable entity and model lists in the tournament and dungeon editors.
- HARD saga difficulty unlocks at prestige 1; buying a stat at its cap is refused.

## 4.7.0 (2026-11-10)

- Dragon Balls: clear faceted balls with camera-facing stars, and dormant stone balls after a wish.
- Space: Saiyan settlements on Vegeta, asteroid fields, planet destruction with the clash meter, traders and salvage.
- Tournament fighter characters and raid Z-Souls.
- Auras at their proper size, scaling with the player's model.
- Disguised dungeon spawners stay spawners.
- Searchable dropdowns and panel art in the raid, dungeon, tournament, saga, form, creator and config screens.

## 4.6.1 (2026-11-10)

- Dungeon room credits corrected.

## 4.6.0 (2026-11-10)

- A generated universe: star systems with landable planets, lone stars, black holes, animated suns, clouds, moons and rings, and Planet Vegeta.
- Planet garrisons, pod trails, the star map on M in space and a space radar under the minimap.
- Super, Black Star and Cerulean Dragon Balls.
- Dungeons: themed floors, three layout styles, boss floors, a gate and portals, crates, spawners, guardians, tickets and editor screens.
- Raids: standard, wave and boss rush raids, rifts, sign-ups, schedules, raid souls and an editor.
- Tournaments: 1v1 to 3v3 brackets and free-for-all, sign-ups, schedules, titles, rewards and an editor.

## 4.5.0 (2026-11-10)

- Space travel: a space dimension, orbits, landing, a star map with autopilot and a radar.
- See-through Dragon Balls with a glowing rim.

## 4.4.0 (2026-11-10)

- Saga and form editors, 3D auras, a new HUD and new NPCs.
- Instant-use capsules and Dragon Balls on the sea bed.
- The Other World rebuilds missing structures and holds spirits until Yemma's palace is ready.

## 4.3.0 (2026-11-10)

- Ki craters that heal, an options screen and training minigames.

## 4.2.2 (2026-11-10)

- The 3D Dragon Ball models are back; the space pod lands on the destination's surface.

## 4.2.1 (2026-11-10)

- Quest rewards give the right items; settings can be changed in game.

## 4.2.0 (2026-11-10)

- 28 hair presets with Super Saiyan shapes in the creator, and Popo's haircut.
- Flight modes, dash, perfect evasion, lock-on, ki sense, the scouter, Instant Transmission and Ki Surge.
- Potara and dance fusion.
- Saga enemy AI, 7 world bosses with lairs and rewards, and parties.
- Machines: stations, a fuel generator, energy cables, the gravity device and gravity training.
- Sacred Kai Planet and Demon Realm dimensions.

## 4.1.0 (2026-11-10)

- Techniques: a pop-up when learned, Bind to Slot with 8 slots, a slot hotbar and a charge bar.
- The radial utility menu (X), transformations (hold G) and masters with dialogue and skill shops.
- The Saiyan tail can wrap round the waist.

## 4.0.0 (2026-11-10)

- Vehicles and the space pod, the Other World and King Yemma, structures and world events.

## 3.2.0 (2026-11-10)

- Fist combo, guard, parry, poise and stun.

## 3.1.0 (2026-11-09)

- Player animations for walking, flying, charging, blocking, techniques and transformations, the same for everyone.

## 3.0.0 (2026-11-09)

- New character creator, HUD, stats screen, classes and formulas.

## 2.1.2 (2026-11-09)

- First release as a separate download, installed from the online addon list.
