# Dragon Block Ragnarok

Dragon Block Ragnarok is an addon for the Ragnarok RPG Toolkit. Its gameplay systems are a port of
**DragonMine Z** (https://github.com/DragonMineZ/dragonminez), rewritten as toolkit scripts.

- DragonMine Z is Copyright (c) DragonMine Z 2025 and is licensed under the GNU General Public License v3.0.
- This addon is a modified version of that work and is likewise licensed under the **GNU General Public
  License v3.0** (see `LICENSE`). Its scripts are its complete source code.
- Models, textures, animations and sounds come from DragonMine Z through the separate `dmzpack` asset pack,
  which carries its own credits, including CC-BY attributions for third-party sounds.
- Changes: DragonMine Z's Java systems were reimplemented as JavaScript for the Ragnarok RPG Toolkit's script
  engine; content and balance are adapted to that engine.

Dragon Ball is a trademark of its respective owners. This is a non-commercial fan project.
