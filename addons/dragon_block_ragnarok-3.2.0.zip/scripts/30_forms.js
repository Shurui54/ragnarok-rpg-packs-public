// =====================================================================================
//  30_forms.js - transformations: Super Saiyan, Oozaru, Golden Frieza, Perfect Cell...
// =====================================================================================
//  A form is two things:
//    1. an EFFECT  (RPG.effects.define) - the buff itself: stats, look, aura, ki drain
//    2. a SKILL    (RPG.skills.define)  - the technique that turns the effect on and off
//
//  Effect fields used here:
//    stats: { strength: 25 }        flat stat bonus while active (x stacks)
//    attributes: {...}              Minecraft attributes; { amount, operation: "multiply_total" } for %
//    maxStacks                      Kaioken stacks x2 -> x20, forms don't
//    tickInterval: 20               how often onTick runs (ticks; 20 = 1 second)
//    onApply / onTick / onRemove    (player, stacks)
//    avatar: {...}                  the form's body (20_races.js builds them) - wins over the race's
//    aura: {texture, frames, speed, color, scale, alpha, height}   the glowing aura around the body
//
//  defineForm() below writes both halves from one short description, so every form
//  is a few lines. The first form (Kaioken) is written out in full so you can see
//  what defineForm produces.
// =====================================================================================

// ---- Auras ---------------------------------------------------------------------------
// DMZ's aura sheets are 4 frames side by side. color: "#hex" or a player colour name.
var AURA_KAKAROT = DMZ_TEX + "races/aura/kakarot_aura.png";     // the classic flame aura
var AURA_SPIKY = DMZ_TEX + "races/aura/kakarot_cross.png";      // spiky, crackling (SSJ2/3)
var AURA_GOD = DMZ_TEX + "races/aura/god_aura.png";             // the calm god-ki aura
var AURA_GOD_SPIKY = DMZ_TEX + "races/aura/god_cross.png";

function aura(texture, color, scale, alpha) {
    return { texture: texture, frames: 4, speed: 10, color: color, scale: scale || 1.0, alpha: alpha || 0.8 };
}

// ---- Shared helpers -------------------------------------------------------------------

// Spends ki every second; powers down when it runs out.
function drainForm(player, effectId, kiPerSecond) {
    if (kiPerSecond > 0 && !player.consume("ki", kiPerSecond)) {
        player.actionbar("&cOut of ki! You power down.");
        sfx(player, "no_ki_form", 0.8, 1);
        player.removeEffect(effectId);
    }
}

// The transformation moment: animation, sound, flash, shout.
function transformFx(player, animation, sound, shout, flashParticle) {
    act(player, animation, 40);
    sfx(player, sound || "transform_on", 1, 1);
    sfx(player, "aura_start", 0.8, 1);
    RPG.world.particle(player.dimension, "minecraft:flash", player.x, player.y + 1, player.z, 1, 0, 0);
    burst(player, flashParticle || "minecraft:end_rod", 50, 0.8, 0.2);
    if (shout) player.title(shout, "");
}

// Every form id, grouped. Turning one on turns the others in its group off.
var FORM_GROUPS = {};

// ---- defineForm(id, spec) -------------------------------------------------------------
// spec: name, color, race, level, requires (other form ids that must be learned first),
//       cost (ki to transform), drain (ki per second), stats, attributes, avatar, aura,
//       animation (transf.*), sound, shout, group, description, icon, skillPointCost,
//       canCast(player) (return a message to block), onTick(player) extra.
function defineForm(id, spec) {
    let group = spec.group || spec.race || "universal";
    (FORM_GROUPS[group] = FORM_GROUPS[group] || []).push(id);

    RPG.effects.define(id, {
        name: spec.name,
        color: spec.color,
        maxStacks: 1,
        stats: spec.stats,
        attributes: spec.attributes,
        avatar: spec.avatar,                   // undefined = keep the race's body
        aura: spec.aura,
        tickInterval: 20,
        onTick(player, stacks) {
            drainForm(player, id, spec.drain || 0);
            if (spec.onTick) spec.onTick(player);
        },
        onRemove(player, stacks) {
            if (spec.onRemove) spec.onRemove(player);
        }
    });

    let requiredSkills = {};
    (spec.requires || []).forEach((f) => { requiredSkills[f] = 1; });
    let requires = { level: spec.level };
    if (spec.race) requires.race = spec.race;
    if (spec.requires) requires.skills = requiredSkills;

    RPG.skills.define(id, {
        name: spec.skillName || spec.name.replace(/&./g, ""),
        description: spec.description + " Drains " + (spec.drain || 0) + " ki/s. Cast again to power down.",
        icon: "dbr:textures/skill/" + id + ".png",          // generated art (resources/assets/dbr)
        kind: "form", formColor: spec.color || (spec.aura && spec.aura.color) || "#FFE34D",
        requires: requires,
        skillPointCost: spec.skillPointCost || 2,
        cost: { ki: spec.cost || 20 },
        cooldown: 40,
        canCast(player, level) {
            if (spec.canCast && !player.hasEffect(id)) return spec.canCast(player);
            return true;
        },
        onCast(ctx) {
            let p = ctx.player;
            if (p.hasEffect(id)) {                         // second cast: power down
                p.removeEffect(id);
                sfx(p, "transform_off", 0.8, 1);
                p.actionbar("&7You power down.");
                return false;                              // false = no ki cost, no cooldown
            }
            FORM_GROUPS[group].forEach((other) => { if (other !== id) p.removeEffect(other); });
            p.addEffect(id, -1);                           // -1 = until removed
            transformFx(p, spec.animation || "transf.generic", spec.sound, spec.shout, spec.particle);
            return true;
        }
    });
}

// =====================================================================================
//  Kaioken (any race) - written out in full, no helper
// =====================================================================================
// Each cast adds a stack: x2, x3, x4, x10, x20. Stats and the body strain grow with stacks.
var KAIOKEN_NAMES = ["x2", "x3", "x4", "x10", "x20"];

RPG.effects.define("kaioken", {
    name: "&cKaioken",
    color: "#FF4040",
    maxStacks: 5,
    stats: { strength: 8, strike: 10, kipower: 6 },           // per stack
    attributes: {
        "minecraft:generic.movement_speed": { amount: 0.06, operation: "multiply_total" }   // +6% speed per stack
    },
    aura: aura(AURA_KAKAROT, "#FF2A2A", 1.05, 0.85),
    tickInterval: 20,
    onTick(player, stacks) {
        drainForm(player, "kaioken", 2 * stacks);
        if (player.health > 4) player.damage(0.5 * stacks);   // the body strain
        burst(player, "minecraft:flame", 3 * stacks, 0.4, 0.02);
    },
    onRemove(player, stacks) {
        player.addPotion("minecraft:slowness", 40 * stacks, 0);   // a short recovery
    }
});

RPG.skills.define("kaioken", {
    name: "Kaioken",
    description: "Cast repeatedly to stack x2 -> x20 (+strength, strike, ki power and speed per stack). Drains ki and health. At x20, cast once more to power down.",
    icon: "dbr:textures/skill/kaioken.png",
    requires: { level: 10 },
    skillPointCost: 2,
    cost: { ki: 15 },
    cooldown: 20,                                            // ticks (1 second)
    onCast(ctx) {
        let p = ctx.player;
        let stacks = p.effectStacks("kaioken");
        if (stacks >= 5) {
            p.removeEffect("kaioken");
            sfx(p, "transform_off", 0.8, 1.2);
            return false;
        }
        if (stacks === 0) {
            p.addEffect("kaioken", -1);
            transformFx(p, "transf.berserker", "insta_form_on", "&c&lKAIOKEN!", "minecraft:flame");
        } else {
            p.addEffectStacks("kaioken", -1, 1);
            sfx(p, "stack_form", 1, 1 + stacks * 0.1);
            p.title("", "&c&lKAIOKEN " + KAIOKEN_NAMES[stacks] + "!");
            burst(p, "minecraft:flame", 30, 0.6, 0.1);
        }
        return true;
    }
});

// =====================================================================================
//  Human
// =====================================================================================
defineForm("human_max_power", {
    name: "&fMax Power", color: "#FFFFFF", race: "human", level: 20, cost: 25, drain: 2,
    description: "Bulk up and push your body to its limit. +Strength and +Resistance.",
    stats: { strength: 25, strike: 15, resistance: 15 },
    avatar: humanAvatar("human", { model: "hbuffed" }),
    aura: aura(AURA_KAKAROT, "#FFFFFF", 1.1, 0.6),
    animation: "transf.generic", shout: "&f&lMAX POWER!"
});

defineForm("potential_unleashed", {
    name: "&bPotential Unleashed", color: "#CFE8FF", race: "human", level: 60, cost: 60, drain: 3,
    requires: ["human_max_power"], skillPointCost: 5,
    description: "Old Kai's ritual awakened every hidden reserve. Balanced and very strong.",
    stats: { strength: 55, strike: 55, kipower: 55, resistance: 35, energy: 25 },
    avatar: humanAvatar("human", { colors: { eyes: "#3B3B3B" } }),
    aura: aura(AURA_GOD, "#E6F0FF", 1.1, 0.7),
    animation: "transf.ssg2", sound: "insta_form_on", shout: "&b&lPOTENTIAL UNLEASHED", 
    canCast: (p) => p.isQuestDone("old_kai_ritual") ? true : "Old Kai must unlock your potential first."
});

// =====================================================================================
//  Saiyan - one group, so going Super Saiyan 2 from Super Saiyan swaps forms
// =====================================================================================
var SSJ_COLORS = { ssjHair: "#FFE34D", ssjEyes: "#1FC3C3" };

function isNight(player) {
    let t = RPG.world.getTime(player.dimension) % 24000;
    return t > 13000 && t < 23000;
}

// The Great Ape: a 3x scaled DMZ oozaru model with its own idle/walk animations.
function oozaruAvatar(furColor) {
    return avatar({
        model: "oozaru",
        noTattoo: true,
        layers: [
            lay("humansaiyan/oozaru_layer1", furColor),          // fur (the tail colour by default)
            lay("humansaiyan/oozaru_layer2", "oozaruSkin"),      // face, chest, hands
            lay("humansaiyan/oozaru_layer3", "#FFFFFF")          // red eyes, already coloured
        ],
        colors: merge(RACE_COLORS.saiyan, { oozaruSkin: "#E8B48A", goldenFur: "#FFD23F" }),
        scale: 3.0,
        states: merge(BASE_STATES, { idle: "base.idle_ozaru", walk: "base.walk_ozaru", run: "base.walk_ozaru" })
    });
}

defineForm("oozaru", {
    name: "&6Oozaru", color: "#A0522D", race: "saiyan", level: 8, cost: 10, drain: 1, skillPointCost: 1,
    description: "Look at the moon and become a giant ape. Only at night. Huge strength, slow.",
    stats: { strength: 30, vitality: 20, resistance: 15 },
    attributes: {
        "minecraft:generic.movement_speed": { amount: -0.25, operation: "multiply_total" },
        "minecraft:generic.knockback_resistance": 0.9,
        "minecraft:generic.attack_knockback": 2
    },
    avatar: oozaruAvatar("body2"),
    animation: "transf.ozaru", sound: "oozaru_growl_player", shout: "&6&lGRAAAAH!", 
    canCast: (p) => isNight(p) ? true : "You need the moon. Wait for nightfall.",
    onTick(p) {
        if (!isNight(p)) { p.removeEffect("oozaru"); p.tell("&7The sun rises and you shrink back."); }
        else if (RPG.chance(0.1)) sfx(p, "oozaru_heartbeat", 0.8, 1);
    }
});

defineForm("super_saiyan", {
    name: "&e&lSuper Saiyan", color: "#FFE040", race: "saiyan", level: 20, cost: 30, drain: 3, skillPointCost: 3,
    description: "The legend. Golden hair, teal eyes, +25 to most stats.",
    stats: { strength: 25, strike: 25, kipower: 25, resistance: 10 },
    avatar: humanAvatar("saiyan", { hair: "ssjHair", eyes: "ssjEyes", colors: SSJ_COLORS }),
    aura: aura(AURA_KAKAROT, "#FFE34D"),
    animation: "transf.ssj", shout: "&e&lSUPER SAIYAN!", particle: "minecraft:electric_spark"
});

defineForm("super_saiyan_g2", {
    name: "&eAscended Saiyan", color: "#FFD020", race: "saiyan", level: 28, cost: 35, drain: 4,
    requires: ["super_saiyan"], skillPointCost: 2,
    description: "Super Saiyan Grade 2: bulging muscles. More strength, same speed.",
    stats: { strength: 40, strike: 30, kipower: 28, resistance: 18 },
    avatar: humanAvatar("saiyan", { model: "hbuffed", hair: "ssjHair", eyes: "ssjEyes", colors: SSJ_COLORS }),
    aura: aura(AURA_KAKAROT, "#FFE34D", 1.1),
    animation: "transf.ssg2", shout: "&e&lASCENDED!", particle: "minecraft:electric_spark"
});

defineForm("super_saiyan_g3", {
    name: "&6Ultra Super Saiyan", color: "#FFB000", race: "saiyan", level: 34, cost: 40, drain: 6,
    requires: ["super_saiyan_g2"], skillPointCost: 2,
    description: "Grade 3: enormous power, but the bulk slows you down.",
    stats: { strength: 60, strike: 25, kipower: 30, resistance: 30 },
    attributes: { "minecraft:generic.movement_speed": { amount: -0.2, operation: "multiply_total" } },
    avatar: humanAvatar("saiyan", { model: "hbuffedg3", hair: "ssjHair", eyes: "ssjEyes", colors: SSJ_COLORS }),
    aura: aura(AURA_KAKAROT, "#FFC21A", 1.2),
    animation: "transf.ssg2", shout: "&6&lULTRA SUPER SAIYAN!", particle: "minecraft:electric_spark"
});

defineForm("super_saiyan_2", {
    name: "&e&lSuper Saiyan 2", color: "#FFF060", race: "saiyan", level: 40, cost: 45, drain: 5,
    requires: ["super_saiyan"], skillPointCost: 4,
    description: "Spikier hair and crackling lightning. A big step up from Super Saiyan.",
    stats: { strength: 45, strike: 45, kipower: 45, resistance: 20 },
    avatar: humanAvatar("saiyan", { hair: "ssjHair", eyes: "ssjEyes", colors: SSJ_COLORS }),
    aura: aura(AURA_SPIKY, "#FFE34D", 1.1, 0.9),
    animation: "transf.ssj", shout: "&e&lSUPER SAIYAN 2!", particle: "minecraft:electric_spark",
    onTick(p) { burst(p, "minecraft:electric_spark", 6, 0.6, 0.1); }
});

defineForm("super_saiyan_3", {
    name: "&6&lSuper Saiyan 3", color: "#FFC000", race: "saiyan", level: 55, cost: 70, drain: 9,
    requires: ["super_saiyan_2"], skillPointCost: 5,
    description: "No eyebrows, endless hair, terrifying power. Burns ki like nothing else.",
    stats: { strength: 75, strike: 70, kipower: 75, resistance: 30 },
    avatar: humanAvatar("saiyan", {
        hair: "ssjHair", eyes: "ssjEyes", colors: SSJ_COLORS,
        brows: "body1", browTexture: "humansaiyan/faces/ssj3eyebrows_eye_{eyeStyle}"   // the brow ridge, no brows
    }),
    aura: aura(AURA_SPIKY, "#FFC21A", 1.25, 0.9),
    animation: "transf.ssj3", shout: "&6&lSUPER SAIYAN 3!", particle: "minecraft:electric_spark",
    onTick(p) { burst(p, "minecraft:electric_spark", 10, 0.8, 0.15); }
});

defineForm("golden_oozaru", {
    name: "&6&lGolden Oozaru", color: "#FFC83D", race: "saiyan", level: 65, cost: 60, drain: 6,
    requires: ["oozaru", "super_saiyan_3"], skillPointCost: 4,
    description: "A Super Saiyan who looks at the moon. Only at night.",
    stats: { strength: 90, vitality: 50, resistance: 45, kipower: 40 },
    attributes: { "minecraft:generic.movement_speed": { amount: -0.15, operation: "multiply_total" }, "minecraft:generic.knockback_resistance": 1 },
    avatar: oozaruAvatar("goldenFur"),
    aura: aura(AURA_KAKAROT, "#FFD23F", 3.0, 0.6),
    animation: "transf.ozaru", sound: "vegeta_oozaru_growl", shout: "&6&lGOLDEN GREAT APE",
    canCast: (p) => isNight(p) ? true : "You need the moon. Wait for nightfall."
});

defineForm("super_saiyan_4", {
    name: "&c&lSuper Saiyan 4", color: "#D0302E", race: "saiyan", level: 70, cost: 80, drain: 7,
    requires: ["golden_oozaru"], skillPointCost: 5,
    description: "Red fur, black hair, golden eyes: the Oozaru's power in a Saiyan's body.",
    stats: { strength: 95, strike: 90, kipower: 90, resistance: 50, vitality: 30 },
    avatar: humanAvatar("saiyan", {
        hair: "ssj4Hair", brows: "ssj4Fur", browTexture: "humansaiyan/faces/ssj4_eyes_{eyeStyle}",
        extra: [lay("humansaiyan/ssj4gt_layer1", "ssj4Fur")],          // the fur over the body (+ its _shadow)
        colors: { ssj4Fur: "#C2272D", ssj4Hair: "#1A1A1A", eyes: "#E8B33A" }
    }),
    aura: aura(AURA_KAKAROT, "#FF4A3A", 1.1),
    animation: "transf.ssj", shout: "&c&lSUPER SAIYAN 4!"
});

defineForm("super_saiyan_god", {
    name: "&c&lSuper Saiyan God", color: "#FF4A5A", race: "saiyan", level: 80, cost: 90, drain: 6,
    requires: ["super_saiyan_3"], skillPointCost: 6,
    description: "Divine ki from the ritual of six Saiyans. Slim, red, frighteningly efficient.",
    stats: { strength: 110, strike: 110, kipower: 120, resistance: 60, energy: 40 },
    avatar: humanAvatar("saiyan", { hair: "godHair", eyes: "godEyes", colors: { godHair: "#E8323C", godEyes: "#E8323C" }, scale: 0.92 }),
    aura: aura(AURA_GOD, "#FF3B3B", 1.1),
    animation: "transf.generic", sound: "insta_form_on", shout: "&c&lSUPER SAIYAN GOD", particle: "minecraft:flame"
});

defineForm("super_saiyan_blue", {
    name: "&b&lSuper Saiyan Blue", color: "#3FD3FF", race: "saiyan", level: 95, cost: 120, drain: 10,
    requires: ["super_saiyan_god"], skillPointCost: 8,
    description: "God ki with Super Saiyan power. The strongest Saiyan form in this starter.",
    stats: { strength: 150, strike: 150, kipower: 160, resistance: 80, energy: 60 },
    avatar: humanAvatar("saiyan", { hair: "blueHair", eyes: "blueEyes", colors: { blueHair: "#3FD3FF", blueEyes: "#2AA9E0" } }),
    aura: aura(AURA_GOD_SPIKY, "#3FD3FF", 1.15),
    animation: "transf.ssg2", sound: "insta_form_on", shout: "&b&lSUPER SAIYAN BLUE", particle: "minecraft:soul_fire_flame"
});

// =====================================================================================
//  Namekian
// =====================================================================================
defineForm("namekian_giant", {
    name: "&aGiant Form", color: "#60D060", race: "namekian", level: 15, cost: 25, drain: 2,
    description: "Grow huge. Much tougher and stronger, but slower.",
    stats: { strength: 20, resistance: 25, vitality: 10 },
    attributes: {
        "minecraft:generic.movement_speed": { amount: -0.2, operation: "multiply_total" },
        "minecraft:generic.knockback_resistance": 0.8
    },
    avatar: namekianAvatar({ scale: 2.6 }),
    animation: "transf.generic", shout: "&a&lGIANT FORM!"
});

defineForm("super_namekian", {
    name: "&2Super Namekian", color: "#40C040", race: "namekian", level: 30, cost: 40, drain: 3,
    skillPointCost: 3,
    description: "Fused with Nail and Kami: the Namekian warrior of legend.",
    stats: { kipower: 35, strike: 30, energy: 25, resistance: 20 },
    avatar: namekianAvatar({}),
    aura: aura(AURA_KAKAROT, "#B6FF5A", 1.05),
    animation: "transf.generic", shout: "&2&lSUPER NAMEKIAN"
});

defineForm("orange_namekian", {
    name: "&6Orange Namekian", color: "#FF8A2E", race: "namekian", level: 60, cost: 80, drain: 6,
    requires: ["super_namekian"], skillPointCost: 6,
    description: "Shenron's gift: a towering orange body with monstrous strength.",
    stats: { strength: 90, strike: 70, resistance: 70, vitality: 40 },
    avatar: namekianAvatar({ model: "hbuffed", skin: "orangeSkin", colors: { orangeSkin: "#FF8A2E" }, scale: 1.1 }),
    aura: aura(AURA_KAKAROT, "#FF8A2E", 1.2),
    animation: "transf.ssg2", shout: "&6&lORANGE PICCOLO"
});

// =====================================================================================
//  Frost Demon - each form removes a seal (DMZ forms use their own models)
// =====================================================================================
defineForm("frost_second_form", {
    name: "&dSecond Form", color: "#E8A2FF", race: "frost_demon", level: 12, cost: 20, drain: 1, skillPointCost: 1,
    description: "Taller, with horns curved upward. +Strength.",
    stats: { strength: 15, resistance: 10, kipower: 8 },
    avatar: frostAvatar({ model: "frostdemon_second", layer5: "#E67D40", scale: 0.95 }),
    animation: "transf.freezer", shout: "&d&lSECOND FORM"
});

defineForm("frost_third_form", {
    name: "&dThird Form", color: "#D080FF", race: "frost_demon", level: 22, cost: 30, drain: 2,
    requires: ["frost_second_form"],
    description: "The elongated head of a nightmare. +Ki Power.",
    stats: { kipower: 25, strike: 15, energy: 15 },
    avatar: frostAvatar({ model: "frostdemon_third", prefix: "thirdform_bodytype", layer5: "#E67D40", scale: 0.95 }),
    animation: "transf.freezer2", shout: "&d&lTHIRD FORM"
});

defineForm("frost_final_form", {
    name: "&5Final Form", color: "#A040FF", race: "frost_demon", level: 32, cost: 35, drain: 1,
    requires: ["frost_third_form"], skillPointCost: 3,
    description: "Small, smooth and efficient. Cheap to hold.",
    stats: { kipower: 35, strike: 30, energy: 20, resistance: 10 },
    avatar: frostAvatar({ prefix: "finalform_bodytype", scale: 0.8 }),
    animation: "transf.freezer", shout: "&5&lFINAL FORM", sound: "insta_form_on"
});

defineForm("frost_fifth_form", {
    name: "&5Fifth Form", color: "#7A2BBF", race: "frost_demon", level: 45, cost: 50, drain: 4,
    requires: ["frost_final_form"], skillPointCost: 3,
    description: "Cooler's secret: armoured head and a face mask.",
    stats: { kipower: 50, strength: 40, resistance: 35 },
    avatar: frostAvatar({ model: "frostdemon_fifth", prefix: "fifth_bodytype", mouth: "frostdemon/faces/frostdemon_fifth_mouth", scale: 1.0 }),
    aura: aura(AURA_KAKAROT, "#B45AFF", 1.1),
    animation: "transf.freezer2", shout: "&5&lFIFTH FORM"
});

defineForm("frost_full_power", {
    name: "&5&l100% Full Power", color: "#A040FF", race: "frost_demon", level: 55, cost: 60, drain: 7,
    requires: ["frost_final_form"], skillPointCost: 4,
    description: "Every muscle at maximum. Burns ki fast.",
    stats: { kipower: 70, strike: 55, strength: 45, energy: 30 },
    avatar: frostAvatar({ model: "frostdemon_fp", prefix: "finalform_bodytype", scale: 0.85 }),
    aura: aura(AURA_KAKAROT, "#C04DFF", 1.1),
    animation: "transf.freezer", shout: "&5&l100% FULL POWER"
});

defineForm("frost_metal_form", {
    name: "&7Metal Form", color: "#B9BFCC", race: "frost_demon", level: 65, cost: 70, drain: 3,
    requires: ["frost_fifth_form"], skillPointCost: 4,
    description: "Rebuilt by the Big Gete Star. Nearly indestructible.",
    stats: { resistance: 90, vitality: 50, kipower: 50 },
    attributes: { "minecraft:generic.knockback_resistance": 1, "minecraft:generic.armor": 10 },
    avatar: avatar({
        model: "frostdemon_metalcore",
        layers: [
            lay("frostdemon/metalcore_layer1", "metal"),
            lay("frostdemon/metalcore_layer2", "metalTrim"),
            lay("frostdemon/faces/frostdemon_eye_0_0", "#FFFFFF", ["head"]),
            lay("frostdemon/faces/frostdemon_eye_0_1", "#FF2020", ["head"])
        ],
        colors: merge(RACE_COLORS.frost_demon, { metal: "#B9BFCC", metalTrim: "#E03A3A" }),
        scale: 0.9
    }),
    animation: "transf.generic", sound: "switch_on", shout: "&7&lMETAL FORM"
});

defineForm("golden_frost_demon", {
    name: "&6&lGolden Form", color: "#FFC83D", race: "frost_demon", level: 85, cost: 110, drain: 9,
    requires: ["frost_full_power"], skillPointCost: 7,
    description: "Training at last: a golden body and god-like ki.",
    stats: { kipower: 140, strike: 120, strength: 90, energy: 60, resistance: 50 },
    avatar: frostAvatar({ prefix: "finalform_bodytype", paint: ["goldBody", "goldTrim", "goldBody", "goldTrim"],
        colors: { goldBody: "#FFC83D", goldTrim: "#7A2BBF" }, scale: 0.8 }),
    aura: aura(AURA_GOD, "#FFC83D", 1.1),
    animation: "transf.freezer", sound: "insta_form_on", shout: "&6&lGOLDEN FRIEZA"
});

// =====================================================================================
//  Bio-Android - absorb, evolve, perfect
// =====================================================================================
defineForm("bio_semi_perfect", {
    name: "&2Semi-Perfect", color: "#40A060", race: "bio_android", level: 18, cost: 25, drain: 1, skillPointCost: 2,
    description: "One android absorbed. Bulkier and tougher.",
    stats: { resistance: 15, strength: 15, vitality: 10 },
    avatar: bioAvatar({ model: "bioandroid_semi", stage: "semiperfect" }),
    animation: "transf.absorb", sound: "absorb1", shout: "&2&lSEMI-PERFECT"
});

defineForm("bio_perfect", {
    name: "&2&lPerfect Form", color: "#40B060", race: "bio_android", level: 30, cost: 35, drain: 2,
    requires: ["bio_semi_perfect"], skillPointCost: 3,
    description: "Complete at last. Balanced and strong.",
    stats: { resistance: 25, kipower: 30, strength: 25, vitality: 15 },
    avatar: bioAvatar({ model: "bioandroid_perfect", stage: "perfect" }),
    animation: "transf.absorb", sound: "absorb2", shout: "&2&lPERFECTION!"
});

defineForm("bio_super_perfect", {
    name: "&e&lSuper Perfect", color: "#E0E040", race: "bio_android", level: 50, cost: 60, drain: 4,
    requires: ["bio_perfect"], skillPointCost: 4,
    description: "Back from the brink with Saiyan cells: lightning crackles around you.",
    stats: { resistance: 45, kipower: 60, strength: 50, strike: 40, vitality: 25 },
    avatar: bioAvatar({ model: "bioandroid_perfect", stage: "perfect", colors: { eyes: "#E8E8E8" } }),
    aura: aura(AURA_SPIKY, "#FFE34D", 1.1),
    animation: "transf.ssj", shout: "&e&lSUPER PERFECT", particle: "minecraft:electric_spark",
    onTick(p) { burst(p, "minecraft:electric_spark", 5, 0.6, 0.1); }
});

defineForm("bio_ultra", {
    name: "&2Power-Weighted", color: "#2E8B57", race: "bio_android", level: 65, cost: 70, drain: 6,
    requires: ["bio_super_perfect"], skillPointCost: 4,
    description: "All the muscle Cell can carry.",
    stats: { strength: 95, resistance: 70, kipower: 50 },
    attributes: { "minecraft:generic.movement_speed": { amount: -0.15, operation: "multiply_total" } },
    avatar: bioAvatar({ model: "bioandroid_ultra", stage: "perfect", scale: 1.05 }),
    aura: aura(AURA_KAKAROT, "#7FFF5F", 1.2),
    animation: "transf.ssg2", shout: "&2&lMAXIMUM MUSCLE"
});

defineForm("bio_xeno", {
    name: "&5Xeno Form", color: "#8A3FD0", race: "bio_android", level: 85, cost: 110, drain: 9,
    requires: ["bio_super_perfect"], skillPointCost: 7,
    description: "A corrupted evolution from another timeline.",
    stats: { kipower: 140, strength: 110, resistance: 90, vitality: 50 },
    avatar: avatar({
        model: "bioandroid_xeno",
        layers: [
            lay("bioandroid/xenoform_layer1", "body1"),
            lay("bioandroid/xenoform_layer2", "body2"),
            lay("bioandroid/faces/perfect_eye_layer0", "#FFFFFF", ["head"]),
            lay("bioandroid/faces/perfect_eye_layer1", "eyes", ["head"])
        ],
        colors: RACE_COLORS.bio_android
    }),
    aura: aura(AURA_GOD_SPIKY, "#8A3FD0", 1.15),
    animation: "transf.janemba", sound: "insta_form_on", shout: "&5&lXENO EVOLUTION"
});

// =====================================================================================
//  Majin
// =====================================================================================
defineForm("super_majin", {
    name: "&dSuper Majin", color: "#FF80C0", race: "majin", level: 20, cost: 30, drain: 2, skillPointCost: 3,
    description: "Your evil half takes over: a tall, lean body.",
    stats: { strength: 20, vitality: 20, kipower: 15 },
    avatar: majinAvatar({ model: "human", body: "bodytype_male_1_layer1", body2: "bodytype_male_1_layer2", eyeSet: 1 }),
    animation: "transf.berserker", sound: "majin_absorb", shout: "&d&lSUPER MAJIN"
});

defineForm("evil_majin", {
    name: "&7Evil Majin", color: "#9A9AA6", race: "majin", level: 35, cost: 40, drain: 3,
    requires: ["super_majin"], skillPointCost: 3,
    description: "Pure malice, grey-skinned. Faster and crueller.",
    stats: { strike: 45, kipower: 35, strength: 30 },
    attributes: { "minecraft:generic.movement_speed": { amount: 0.1, operation: "multiply_total" } },
    avatar: majinAvatar({ model: "human_slim", body: "bodytype_male_2_layer1", skin: "evilSkin", eyeSet: 1,
        colors: { evilSkin: "#9A9AA6" }, scale: 0.95 }),
    aura: aura(AURA_KAKAROT, "#B04DFF", 1.0),
    animation: "transf.berserker", shout: "&7&lEVIL MAJIN"
});

defineForm("kid_majin", {
    name: "&d&lPure Majin", color: "#FF60B0", race: "majin", level: 55, cost: 60, drain: 5,
    requires: ["evil_majin"], skillPointCost: 4,
    description: "The original, chaotic Majin: small, wild and devastating.",
    stats: { kipower: 75, strike: 70, energy: 40, vitality: 30 },
    attributes: { "minecraft:generic.movement_speed": { amount: 0.15, operation: "multiply_total" } },
    avatar: majinAvatar({ model: "human_slim", body: "bodytype_male_2_layer1", eyeSet: 2, scale: 0.8 }),
    aura: aura(AURA_SPIKY, "#FF6EE7", 0.95),
    animation: "transf.daima", sound: "insta_form_on", shout: "&d&lKID BUU"
});

defineForm("super_janemba", {
    name: "&4&lSuper Janemba", color: "#E8344A", race: "majin", level: 80, cost: 100, drain: 8,
    requires: ["kid_majin"], skillPointCost: 6,
    description: "Evil itself takes shape: a demon from beyond the dimensions.",
    stats: { kipower: 120, strike: 110, strength: 90, vitality: 60 },
    avatar: avatar({
        model: "janemba_super",
        layers: [
            lay("majin/janembasuper_0_male_layer1", "janembaRed"),
            lay("majin/janembasuper_0_male_layer2", "janembaGold"),
            lay("majin/janembasuper_0_male_layer3", "janembaPurple"),
            lay("majin/faces/janemba_eye_0", "#FFFFFF", ["head"]),
            lay("majin/faces/janemba_eye_1", "eyes", ["head"]),
            lay("majin/faces/janemba_mouth", "janembaRed", ["head"])
        ],
        colors: merge(RACE_COLORS.majin, { janembaRed: "#E8344A", janembaGold: "#F6D84A", janembaPurple: "#6A2BB0" }),
        scale: 1.0
    }),
    aura: aura(AURA_GOD_SPIKY, "#E8344A", 1.15),
    animation: "transf.janemba", sound: "insta_form_on", shout: "&4&lSUPER JANEMBA"
});

// =====================================================================================
//  Non-form buffs (no skill, given by items, quests and techniques)
// =====================================================================================
RPG.effects.define("well_fed", {
    name: "Well Fed",
    color: "#FFD080",
    stats: { vitality: 5 },
    onApply(player, stacks) { player.addResource("stamina", 1000); }
});

// Potara earrings (50_items.js): two warriors become one, for 5 minutes.
RPG.effects.define("potara_fusion", {
    name: "&b&lPotara Fusion",
    color: "#3FA9FF",
    stats: { strength: 60, strike: 60, kipower: 60, resistance: 40, vitality: 40, energy: 40 },
    aura: aura(AURA_KAKAROT, "#7FD4FF", 1.1),
    onApply(player, stacks) { player.title("&b&lFUSION!", "&7Potara Fusion - 5 minutes"); },
    onRemove(player, stacks) { player.tell("&7The fusion wears off."); sfx(player, "transform_off", 1, 0.8); }
});

// The Fusion Dance (40_skills.js): weaker than Potara but needs no earrings.
RPG.effects.define("dance_fusion", {
    name: "&6Metamoran Fusion",
    color: "#FF9A2E",
    stats: { strength: 40, strike: 40, kipower: 40, resistance: 25, vitality: 25 },
    aura: aura(AURA_KAKAROT, "#FFB347", 1.05),
    onRemove(player, stacks) { player.tell("&7Your 30 minutes... er, 3 minutes are up."); }
});

// The Zenkai Lotus and a Saiyan's comeback (90_hooks.js).
RPG.effects.define("zenkai_boost", {
    name: "&6Zenkai",
    color: "#FFAA00",
    stats: { strength: 10, vitality: 10, resistance: 5 }
});
