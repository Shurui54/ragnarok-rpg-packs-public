// =====================================================================================
//  The DMZ "Xenoverse" HUD, drawn every frame like DragonMine Z's XenoverseHUD/HudBar
//  (ported from its GPL source: same sprites, positions, colours, trails, flow, shine,
//  heartbeat, number pops and shake). Reads the player's synced data; nothing here
//  changes the game.
// =====================================================================================
var XV = (function () {
    var SHEET = "dmzpack:textures/gui/hud/xenoversehud.png", SHEET_SIZE = 512, TPP = 2;   // texels per logical pixel
    var REFERENCE_HEIGHT = 360;
    var FONT = "dmzpack:smooth";

    function sprite(u, v, w, h, sheet, sw, sh) { return { sheet: sheet || SHEET, sw: sw || SHEET_SIZE, sh: sh || SHEET_SIZE, u: u, v: v, w: w, h: h, gw: w / TPP, gh: h / TPP }; }
    function xeno(x, y, w, h) { return sprite(x * 2, y * 2, w * 2, h * 2); }
    var SKIN = {
        cloud: xeno(184, 10, 56, 25), hpFrame: xeno(14, 2, 141, 9), hpFill: xeno(15, 21, 137, 5),
        kiFrame: xeno(8, 65, 118, 8), kiFill: xeno(9, 81, 114, 4),
        stmLabel: xeno(9, 105, 14, 7), stmFrame: xeno(23, 105, 86, 7), stmFill: xeno(24, 121, 85, 5),
        radar: xeno(218, 100, 26, 27), form: xeno(220, 130, 26, 13)
    };

    // ---- helpers (HudRender) ----
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
    function hex(c) { return "#" + ("000000" + (c & 0xFFFFFF).toString(16)).slice(-6); }
    function parse(s) { s = String(s || "#FFFFFF").replace("#", ""); if (s.length > 6) s = s.slice(-6); return parseInt(s, 16) || 0xFFFFFF; }
    function mix(a, b, t) {
        t = clamp(t, 0, 1);
        var r = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        var g = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        var bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }
    function spritePart(ctx, s, x, y, w, h, fx, fy, tx, ty, rgb, alpha) {
        if (alpha <= 0.004 || w <= 0 || h <= 0 || tx <= fx || ty <= fy) return;
        ctx.quad(s.sheet, x + w * fx, y + h * fy, w * (tx - fx), h * (ty - fy),
            (s.u + s.w * fx) / s.sw, (s.v + s.h * fy) / s.sh, (s.u + s.w * tx) / s.sw, (s.v + s.h * ty) / s.sh, hex(rgb), alpha);
    }
    function spriteDraw(ctx, s, x, y, w, h, rgb, alpha) { spritePart(ctx, s, x, y, w, h, 0, 0, 1, 1, rgb, alpha); }
    /** Horizontal gradient over a slice [from, to] of the sprite, alphas top and bottom (HudRender.spriteGradient). */
    function spriteGradient(ctx, s, x, y, w, h, from, to, aFrom, aTo, aFromB, aToB) {
        if (Math.max(Math.max(aFrom, aTo), Math.max(aFromB, aToB)) <= 0.004 || to <= from) return;
        ctx.quadCorners(s.sheet, x + w * from, y, w * (to - from), h, (s.u + s.w * from) / s.sw, s.v / s.sh, (s.u + s.w * to) / s.sw, (s.v + s.h) / s.sh,
            "#FFFFFF", aFrom, aTo, aToB, aFromB);
    }

    // ---- clock (HudBar.clock) ----
    var hudTime = 0, lastNanos = 0;
    function clock() {
        var now = RPG.nowMs() / 1000, dt = lastNanos === 0 ? 0 : now - lastNanos;
        lastNanos = now;
        if (dt > 0 && dt <= 0.25) hudTime += dt;
        return hudTime % 3600;
    }

    // ---- HudSmoother ----
    function Smoother(tau, eps) { this.tau = Math.max(0.001, tau); this.eps = eps === undefined ? 0.0005 : eps; this.init = false; this.value = 0; this.last = 0; }
    Smoother.prototype.snap = function (t) { this.init = true; this.value = t; this.last = RPG.nowMs() / 1000; };
    Smoother.prototype.update = function (t) {
        var now = RPG.nowMs() / 1000;
        if (!this.init || !isFinite(this.value)) { this.snap(t); return this.value; }
        var dt = now - this.last; this.last = now;
        if (dt <= 0) return this.value;
        if (dt > 1) { this.value = t; return t; }
        if (dt > 0.25) dt = 0.25;
        this.value += (t - this.value) * (1 - Math.exp(-dt / this.tau));
        if (Math.abs(t - this.value) <= this.eps) this.value = t;
        return this.value;
    };

    // ---- HudBarAnimator ----
    function Animator() { this.init = false; this.segments = []; }
    Animator.prototype.reset = function (f) {
        f = clamp(f, 0, 1); this.init = true; this.target = this.front = this.healGhost = f; this.healHold = 0; this.healing = false;
        this.segments = []; this.last = RPG.nowMs() / 1000;
    };
    Animator.prototype.update = function (f) {
        f = clamp(f, 0, 1);
        if (!this.init) { this.reset(f); return; }
        var now = RPG.nowMs() / 1000, dt = now - this.last; this.last = now;
        if (dt <= 0) return;
        if (dt > 0.25) dt = 0.25;
        var prev = this.target;
        if (prev - f >= 0.01) { this.segments.push({ amount: prev - f, age: 0 }); this.front = f; this.healing = false; }
        else if (f - prev >= 0.12) { this.segments = []; this.healing = true; this.healGhost = f; this.healHold = 0.25; }
        this.target = f;
        var fb = 1 - Math.exp(-dt / 0.55), gb = 1 - Math.exp(-dt / 0.32);
        var prevFront = this.front;
        if (!(this.healing && this.healHold > 0)) this.front += (this.target - this.front) * fb;
        if (this.healing) {
            if (this.healHold > 0) this.healHold -= dt;
            this.healGhost = this.target;
            if (this.front >= this.healGhost - 0.0015) { this.front = this.healGhost; this.healing = false; }
        } else if (this.segments.length) {
            var rise = this.front - prevFront;
            for (var i = this.segments.length - 1; i >= 0 && rise > 0; i--) {
                var take = Math.min(this.segments[i].amount, rise);
                this.segments[i].amount -= take; rise -= take;
                if (this.segments[i].amount <= 0.0015) this.segments.splice(i, 1);
            }
            for (var j = this.segments.length - 1; j >= 0; j--) {
                var s = this.segments[j]; s.age += dt;
                if (s.age >= 1.5) { s.amount -= s.amount * gb; if (s.amount <= 0.0015) this.segments.splice(j, 1); }
            }
        }
    };
    Animator.prototype.ghost = function () {
        if (this.healing) return this.healGhost;
        var t = 0; this.segments.forEach(function (s) { t += s.amount; });
        return clamp(this.front + t, 0, 1);
    };
    Animator.prototype.gap = function () { return this.healing ? "heal" : this.segments.length ? "damage" : "none"; };

    // ---- HudStatNumberAnimator ----
    function Numbers(kind) { this.kind = kind; this.init = false; this.alpha = 1; this.pulseStart = -14; this.dir = "none"; }
    Numbers.prototype.update = function (text, value, tick) {
        if (!this.init) { this.init = true; this.lastText = text; this.lastValue = value; this.lastChange = tick; this.lastUpdate = tick; this.alpha = 1; return this.state(tick); }
        if (tick < this.lastUpdate) { this.lastChange = tick; this.lastUpdate = tick; this.dir = "none"; this.alpha = 1; }
        var elapsed = clamp(tick - this.lastUpdate, 0, 5);
        this.lastUpdate = Math.max(this.lastUpdate, tick);
        var dir = Math.abs(value - this.lastValue) <= 0.001 ? "none" : value > this.lastValue ? "up" : "down";
        if (dir !== "none" || text !== this.lastText) {
            this.lastText = text; this.lastValue = value; this.lastChange = tick; this.alpha = Math.max(this.alpha, 0.35);
            if (dir === "up" || (this.kind === "health" && dir === "down")) { this.dir = dir; this.pulseStart = tick; } else this.dir = "none";
        }
        var targetAlpha = tick - this.lastChange <= 50 ? 1 : 0;
        if (RPG.storage.get("dmz_hud_always_numbers", false)) targetAlpha = 1;
        var rate = targetAlpha > this.alpha ? elapsed / 5 : elapsed / 20;
        this.alpha = this.alpha < targetAlpha ? Math.min(targetAlpha, this.alpha + rate) : Math.max(targetAlpha, this.alpha - rate);
        return this.state(tick);
    };
    Numbers.prototype.state = function (tick) {
        var age = tick - this.pulseStart, p = age >= 0 && age <= 14 ? 1 - smooth(age / 14) : 0;
        var dmg = this.kind === "health" && this.dir === "down";
        var col = p <= 0 ? 0xFFFFFF : this.dir === "up" ? mix(0xFFFFFF, 0x55FF55, p) : dmg ? mix(0xFFFFFF, 0xFF5555, p) : 0xFFFFFF;
        return { alpha: clamp(this.alpha, 0, 1), rgb: col, dx: dmg && p > 0 ? Math.sin(age * 3.2) * 1.25 * p : 0, dy: dmg && p > 0 ? Math.cos(age * 4.1) * 0.45 * p : 0 };
    };
    function smooth(v) { v = clamp(v, 0, 1); return v * v * (3 - 2 * v); }

    // ---- HudBar ----
    var SHINE_PERIOD = 5.5, SHINE_DURATION = 0.9, SHINE_CASCADE = 0.16;
    function Bar(kind) {
        this.kind = kind; this.health = kind === "health";
        this.anim = new Animator(); this.number = new Smoother(0.11, 0.45); this.motion = new Smoother(0.18); this.impact = new Smoother(0.14);
        this.nums = new Numbers(kind); this.shineOffset = kind === "ki" ? SHINE_CASCADE : kind === "stamina" ? SHINE_CASCADE * 2 : 0;
        this.flowing = false; this.flowBoost = 0; this.phaseA = 0; this.phaseB = 0; this.lastFlow = -1;
        this.lastMax = -1; this.cur = 0; this.max = 1; this.lastFront = -1; this.lastTarget = -1;
    }
    Bar.prototype.update = function (cur, max) {
        this.max = Math.max(1, max); this.cur = clamp(cur, 0, this.max);
        var f = this.cur / this.max;
        if (this.lastMax !== this.max) { this.anim.reset(f); this.number.snap(this.cur); this.lastMax = this.max; this.lastTarget = f; }
        if (this.lastTarget >= 0 && this.lastTarget - f >= 0.01) this.impact.snap(Math.min(1, this.impact.value + 0.55 + (this.lastTarget - f) * 3));
        this.lastTarget = f;
        this.impact.update(0); this.anim.update(f); this.number.update(this.cur);
        var front = this.anim.front, moving = this.lastFront >= 0 && Math.abs(front - this.lastFront) > 0.0004 ? 1 : 0;
        this.lastFront = front; this.motion.update(moving);
    };
    Bar.prototype.target = function () { return this.cur / this.max; };
    function profile(o) { var q = 1 - o * o; return q <= 0 ? 0 : q * q; }
    function band(ctx, s, x, y, w, h, center, half, limit, alpha) {
        if (alpha <= 0.004 || half <= 0) return;
        for (var i = 0; i < 8; i++) {
            var start = center - half + half * 2 * i / 8, end = start + half * 2 / 8;
            var from = Math.max(0, start), to = Math.min(limit, end);
            if (to <= from) continue;
            var af = alpha * profile((from - center) / half), at = alpha * profile((to - center) / half);
            spriteGradient(ctx, s, x, y, w, h, from / w, to / w, af, at, af, at);
        }
    }
    function shineProgress(now, offset) {
        var t = ((now - offset) % SHINE_PERIOD + SHINE_PERIOD) % SHINE_PERIOD;
        if (t >= SHINE_DURATION) return -1;
        var p = t / SHINE_DURATION; return p * p * (3 - 2 * p);
    }
    function beatPeriod(f) { var d = clamp(1 - f / 0.25, 0, 1); return 1.05 - 0.4 * d; }
    function gauss(v, c, w) { var d = (v - c) / w; return Math.exp(-d * d); }
    function heartbeat(f) {
        if (f >= 0.25) return 0;
        var str = clamp((0.25 - f) / 0.04, 0, 1), t = clock() % beatPeriod(f);
        return clamp(gauss(t, 0.07, 0.05) + 0.65 * gauss(t, 0.27, 0.055), 0, 1) * str;
    }
    Bar.prototype.drawLife = function (ctx, s, x, y, w, h, frontLen) {
        if (frontLen <= 1) return;
        var now = clock();
        ctx.additive(true);
        var sh = shineProgress(now, this.shineOffset);
        if (sh >= 0) {
            var c = -16 + sh * (frontLen + 32);
            band(ctx, s, x, y, w, h, c, 16, frontLen, 0.2);
            band(ctx, s, x, y, w, h, c, 4.5, frontLen, 0.28);
        }
        if (this.flowing) this.drawFlow(ctx, s, x, y, w, h, frontLen, now);
        var f = this.cur / this.max;
        if (this.health && f < 0.25) {
            var t = now % beatPeriod(f);
            if (t < 0.4) {
                var pr = t / 0.4, st = clamp((0.25 - f) / 0.04, 0, 1) * (1 - pr * pr), cc = pr * frontLen;
                band(ctx, s, x, y, w, h, cc, 9, frontLen, 0.22 * st);
                band(ctx, s, x, y, w, h, cc, 2.5, frontLen, 0.45 * st);
            }
        }
        ctx.additive(false);
    };
    Bar.prototype.drawFlow = function (ctx, s, x, y, w, h, frontLen, now) {
        var dt = this.lastFlow < 0 ? 0 : now - this.lastFlow; this.lastFlow = now;
        if (dt < 0 || dt > 0.25) dt = 0;
        var speed = 1 + 0.5 * this.flowBoost;
        this.phaseA = (this.phaseA + dt * 9 * speed) % 38;
        this.phaseB = (this.phaseB + dt * 14 * speed) % 23;
        var alpha = 0.2 * (1 + 0.6 * this.flowBoost), self = this;
        function shape(pos) {
            var a = 0.5 + 0.5 * Math.sin((pos - self.phaseA) / 38 * Math.PI * 2), b = 0.5 + 0.5 * Math.sin((pos - self.phaseB) / 23 * Math.PI * 2);
            return (0.62 * a * a * a + 0.38 * b * b * b) * clamp((frontLen - pos) / 6, 0, 1);
        }
        for (var from = 0; from < frontLen; from += 3.5) {
            var to = Math.min(frontLen, from + 3.5), af = alpha * shape(from), at = alpha * shape(to);
            spriteGradient(ctx, s, x, y, w, h, from / w, to / w, af, at, af * 0.35, at * 0.35);
        }
    };
    Bar.prototype.drawGlint = function (ctx, s, x, y, w, h, front) {
        var gl = this.motion.value, fw = front * w;
        if (gl <= 0.02 || fw >= w - 0.5) return;
        var span = Math.min(fw, 6) / w;
        ctx.additive(true);
        spriteGradient(ctx, s, x, y, w, h, front - span, front, 0, 0.6 * gl, 0, 0.6 * gl);
        ctx.additive(false);
    };
    Bar.prototype.drawFill = function (ctx, s, x, y, w, h, rgb, pulse) {
        var front = this.anim.front, ghost = this.anim.ghost(), hit = this.impact.value, gap = this.anim.gap();
        if (gap !== "none") {
            var from = Math.min(front, ghost), to = Math.max(front, ghost);
            if (gap === "damage") {
                var base = this.health ? 0.74 : 0.55;
                spritePart(ctx, s, x, y, w, h, from, 0, to, 1, mix(mix(0xE4E8FF, rgb, 0.18), 0xFFFFFF, hit), base + (1 - base) * hit);
            } else {
                var breath = 0.5 + 0.5 * Math.sin(clock() * 5);
                spritePart(ctx, s, x, y, w, h, from, 0, to, 1, mix(rgb, 0xFFFFFF, 0.5), 0.4 + 0.12 * breath);
            }
        }
        if (front <= 0) return;
        spritePart(ctx, s, x, y, w, h, 0, 0, front, 1, mix(rgb, 0xFFFFFF, pulse * 0.25), 1);
        this.drawLife(ctx, s, x, y, w, h, front * w);
        if (this.health && hit > 0.02) { ctx.additive(true); spritePart(ctx, s, x, y, w, h, 0, 0, front, 1, 0xFFFFFF, hit * 0.22); ctx.additive(false); }
        this.drawGlint(ctx, s, x, y, w, h, front);
    };
    Bar.prototype.drawSweep = function (ctx, s, x, y, w, h, phase, strength) {
        var fw = this.anim.front * w;
        if (fw <= 2 || strength <= 0.01) return;
        var c = (phase % 1) * (fw + 16) - 8;
        ctx.additive(true); band(ctx, s, x, y, w, h, c, 8, fw, 0.45 * strength); ctx.additive(false);
    };
    function fmt(n) { return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
    Bar.prototype.drawValue = function (ctx, x, y, scale, align, tick) {
        var shown = this.number.value, pct = RPG.storage.get("dmz_hud_percent", true);
        var text = pct ? Math.round(shown / this.max * 100) + "%" : fmt(shown) + " / " + fmt(this.max);
        var cv = pct ? Math.round(this.cur / this.max * 100) : Math.round(this.cur);
        var st = this.nums.update(String(cv), cv, tick);
        if (st.alpha <= 0.012) return;
        ctx.textStyled(text, x + st.dx, y + st.dy, scale, hex(st.rgb), st.alpha, align, FONT, "#000000");
    };

    // ---- XenoverseHUD ----
    var HP = new Bar("health"), KI = new Bar("ki"), STM = new Bar("stamina");
    KI.flowing = true;
    var RELEASE = new Smoother(0.10, 0.05), FORM = new Smoother(0.08), GLOW = new Smoother(0.15), SHAKE = new Smoother(0.12);
    var lastHealth = -1;
    var RACE_ICONS = { human: "human", saiyan: "saiyan", namekian: "namekian", frost_demon: "frostdemon", frostdemon: "frostdemon",
        bio_android: "bioandroid", bioandroid: "bioandroid", majin: "majin" };

    function render(ctx) {
        var p = RPG.player;
        if (!p.present || !created() || RPG.storage.get("dmz_hud_hidden", false)) return;
        var unit = Math.max(0.25, ctx.height / REFERENCE_HEIGHT), scale = 1.2 * unit;
        var bx = 3 * unit, by = 3 * unit;
        var maxHp = Math.max(1, p.maxHealth), hp = p.health;
        HP.update(hp, maxHp);
        KI.update(p.resource("ki"), Math.max(1, p.resourceMax("ki")));
        STM.update(p.resource("stamina"), Math.max(1, p.resourceMax("stamina")));
        var release = RELEASE.update(Number(RPG.getVar("dmz_release", 0)) || 0);
        var formCharge = FORM.update((Number(RPG.getVar("dmz_formcharge", 0)) || 0) / 100);
        var glow = GLOW.update(p.hasEffect("ki_charge") ? 1 : 0);
        var surge = clamp((Number(RPG.getVar("dmz_surge", 0)) || 0) / 100, 0, 1);
        if (lastHealth >= 0 && hp < lastHealth) {
            var lost = (lastHealth - hp) / maxHp;
            if (lost >= 0.02) SHAKE.snap(Math.min(1, SHAKE.value + lost * 6));
        }
        lastHealth = hp;
        var shake = SHAKE.update(0), seconds = clock(), tick = RPG.time() + ctx.partial;
        var low = heartbeat(HP.target());
        KI.flowBoost = clamp(glow, 0, 1);
        var aura = parse(RPG.getVar("dmz_aura_color", "") || p.color("aura", "#7FC8FF"));

        ctx.push();
        ctx.translate(bx + Math.sin(seconds * 61) * 1.6 * shake, by + Math.cos(seconds * 47) * 1.0 * shake);
        ctx.scale(scale, scale);
        spriteDraw(ctx, SKIN.cloud, 0, 0, SKIN.cloud.gw, SKIN.cloud.gh, 0xFFFFFF, 1);
        spriteDraw(ctx, SKIN.hpFrame, 31, 13, SKIN.hpFrame.gw, SKIN.hpFrame.gh, 0xFFFFFF, 1);
        if (low > 0) spriteDraw(ctx, SKIN.hpFrame, 31, 13, SKIN.hpFrame.gw, SKIN.hpFrame.gh, 0xFF3B3B, low * 0.6);
        HP.drawFill(ctx, SKIN.hpFill, 32, 15, SKIN.hpFill.gw, SKIN.hpFill.gh, healthColor(HP.anim.front), low);
        spriteDraw(ctx, SKIN.kiFrame, 28, 21, SKIN.kiFrame.gw, SKIN.kiFrame.gh, 0xFFFFFF, 1);
        KI.drawFill(ctx, SKIN.kiFill, 29, 23, SKIN.kiFill.gw, SKIN.kiFill.gh, aura, 0);
        KI.drawSweep(ctx, SKIN.kiFill, 29, 23, SKIN.kiFill.gw, SKIN.kiFill.gh, seconds * 1.1, glow);
        if (surge > 0) spritePart(ctx, SKIN.kiFill, 29, 23, SKIN.kiFill.gw, SKIN.kiFill.gh, 0, 0.55, surge, 1, mix(aura, 0xFFFFFF, 0.75), 0.95);
        spriteDraw(ctx, SKIN.stmLabel, 28, 28, SKIN.stmLabel.gw, SKIN.stmLabel.gh, 0xFFFFFF, 1);
        spriteDraw(ctx, SKIN.stmFrame, 28 + SKIN.stmLabel.gw, 28, SKIN.stmFrame.gw, SKIN.stmFrame.gh, 0xFFFFFF, 1);
        STM.drawFill(ctx, SKIN.stmFill, 43, 29, SKIN.stmFill.gw, SKIN.stmFill.gh, 0xF5A623, 0);
        // radar disc with the race icon filling up with power release, and the form gauge
        var race = RACE_ICONS[p.race] || "custom";
        var icon = "dmzpack:textures/gui/hud/racial_icons/" + race + ".png", iy = 8 + (race === "majin" ? 4 : 5), lvl = clamp(release / 100, 0, 1);
        ctx.quad(icon, 15, iy, 16, 16, 0, 0, 1, 0.5, "#FFFFFF", 1);
        if (lvl > 0) ctx.quad(icon, 15, iy + 16 * (1 - lvl), 16, 16 * lvl, 0, 0.5 + 0.5 * (1 - lvl), 1, 1, "#FFFFFF", 1);
        spriteDraw(ctx, SKIN.radar, 8, 8, SKIN.radar.gw, SKIN.radar.gh, 0xFFFFFF, 1);
        if (formCharge > 0.005) spritePart(ctx, SKIN.form, 10, 20, SKIN.form.gw, SKIN.form.gh, 0, 1 - clamp(formCharge, 0, 1), 1, 1, 0xFA3177, 1);
        ctx.textStyled(Math.round(release) + "%", 7, 32, 0.5, "#FACAF7", 1, 0.5, FONT, "#000000");
        HP.drawValue(ctx, 100, 15.5, 0.5, 0.5, tick);
        KI.drawValue(ctx, 90, 23, 0.5, 0.5, tick);
        STM.drawValue(ctx, 85, 29.5, 0.5, 0.5, tick);
        ctx.pop();
    }

    function created() { return !!RPG.getVar("dmz_created", 0) || RPG.player.race !== ""; }

    function healthColor(f) {
        var y = smoothStep(0.22, 0.38, f), g = smoothStep(0.52, 0.70, f);
        return mix(mix(0xE8392F, 0xF2C230, y), 0x35D46A, g);
    }
    function smoothStep(e0, e1, v) { var t = clamp((v - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); }

    return { created: created, render: render, mix: mix, parse: parse, hex: hex, clamp: clamp, spritePart: spritePart, sprite: sprite, FONT: FONT };
})();

RPG.on("load", () => RPG.hud.onRender(XV.render));
// like DMZ: the vanilla hearts are hidden once you've made a character (its bars replace them); food and armour stay
var XV_HIDING = null;
RPG.every(10, () => {
    let want = XV.created();
    if (want !== XV_HIDING) { XV_HIDING = want; RPG.hud.hideVanilla(want ? ["health"] : []); }
});
