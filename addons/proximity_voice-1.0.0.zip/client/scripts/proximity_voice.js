// =====================================================================================
//  Proximity Voice (client side): opens the engine's voice settings for /voice settings.
//  Everything else (microphone, playback, the speaking icons) is the engine's; this file only shows how a client
//  script can read voice state, e.g. RPG.voice.speaking(uuid) or RPG.voice.onLevel((uuid, level) => ...).
// =====================================================================================
RPG.net.on("pv_settings", function () { RPG.voice.openSettings(); });
