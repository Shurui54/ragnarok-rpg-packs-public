// =====================================================================================
//  Proximity Voice (server side): an example built on RPG.voice.
//  The engine does the audio: capture, opus, relay, 3D playback. This addon only decides who hears whom:
//    - everyone within the range (config below, or the server's ragnarok_rpg-voice.toml) hears you in 3D;
//    - your team (scoreboard team, else your party) hears you anywhere while you hold the channel key
//      ("Voice chat: push to talk on your channel" in Controls), as a radio if teamRadio is on;
//    - ops can switch to a staff channel (heard by staff only, no key needed);
//    - ops can mute / deafen players (kept across restarts) and set per-player ranges.
//  Players turn voice on themselves (off by default); nothing here can open a microphone.
//  /voice for help.
// =====================================================================================
(function () {
    var CFG = RPG.config.define("proximity_voice", {
        range: { default: 0, min: 0, max: 512, integer: true,
            comment: "How far players are heard (blocks). 0 = the server's voice config (serverconfig/ragnarok_rpg-voice.toml)" },
        teamChannel: { default: true, comment: "Players on the same team (scoreboard team, else party) hear each other at any distance while holding the channel key" },
        teamRadio: { default: true, comment: "Team voice sounds like a radio" },
        staffChannel: { default: true, comment: "Ops can talk on a staff channel (/voice staff)" },
        spectatorsPrivate: { default: true, comment: "Spectators are heard only by other spectators" }
    });
    var STAFF = {};       // uuid -> true while on the staff channel
    var TEAM_OFF = {};    // uuid -> true when the player left their team channel (/voice team off)

    RPG.voice.channel("staff", { radio: false, key: false });

    function teamKey(p) {
        var t = RPG.teams.get(p);
        if (t) return "team:" + t;
        var party = p.partyMembers();
        if (party && party.length > 1) {
            var ids = party.map(function (q) { return String(q.uuid); }).sort();
            return "party:" + ids[0];
        }
        return null;
    }

    // which channel a player belongs in; cheap, so it runs on join and every few seconds
    function place(p) {
        var id = String(p.uuid), want = null;
        if (STAFF[id] && CFG.get("staffChannel") && p.isOp()) want = "staff";
        else if (CFG.get("teamChannel") && !TEAM_OFF[id]) want = teamKey(p);
        if (want && want !== "staff") RPG.voice.channel(want, { radio: !!CFG.get("teamRadio"), key: true });
        if (String(RPG.voice.channelOf(p) || "") !== String(want || "")) RPG.voice.join(p, want);
        var r = CFG.get("range");
        var own = p.getVar("pv_range");
        RPG.voice.range(p, own ? Number(own) : (r > 0 ? r : null));
    }

    RPG.on("playerJoin", function (p) { place(p); });
    RPG.every(60, function () { RPG.server.players().forEach(place); });
    RPG.server.players().forEach(place);   // after a script reload

    // spectators: a cached rule (the engine asks about once a second per talking player, never per frame)
    RPG.voice.rule(function (speaker, listener, distance, sameChannel) {
        if (!CFG.get("spectatorsPrivate")) return undefined;
        var s = speaker.gameMode === "spectator", l = listener.gameMode === "spectator";
        if (s && !l && !sameChannel) return false;
        return undefined;
    });

    // ---- commands
    function find(asker, name) {
        var p = name ? RPG.server.player(name) : null;
        if (!p) asker.tell("&cNo player online called &f" + (name || "?"));
        return p;
    }
    function names() { return RPG.server.players().map(function (q) { return q.name; }); }
    function help(p) {
        var ch = RPG.voice.channelOf(p);
        p.tell("&6Proximity Voice &7- " + (RPG.voice.allowed() ? "voice chat is allowed here" : "&cvoice chat is turned off on this server"));
        p.tell("&7Your voice: " + (RPG.voice.isEnabled(p) ? "&aon" : "&coff &7(turn it on: K > Settings > Voice chat, or /voice settings)")
            + (RPG.voice.isMuted(p) ? " &c(muted by staff)" : ""));
        p.tell("&7Heard within &f" + (RPG.voice.getRange(p) >= 0 ? RPG.voice.getRange(p) : RPG.voice.defaultRange()) + " &7blocks. Channel: &f" + (ch || "none"));
        p.tell("&7Keys (Controls): &fVoice chat: push to talk&7; &fpush to talk on your channel&7 for your team.");
        p.tell("&e/voice settings &7open your voice settings (devices, volume, per-player mute, mic test)");
        p.tell("&e/voice team on|off &7use your team channel or not");
        if (p.isOp()) {
            p.tell("&e/voice staff &7switch to / from the staff channel");
            p.tell("&e/voice mute|unmute <player>&7, &e/voice deafen|undeafen <player>");
            p.tell("&e/voice range <player> <blocks|reset>&7, &e/voice stats");
        }
    }
    RPG.commands.register("voice", {
        root: true,
        description: "Proximity voice chat: help, settings, team and staff channels, moderation",
        suggest: function (p, args) {
            if (args.length <= 1) return p && p.isOp() ? ["settings", "team", "staff", "mute", "unmute", "deafen", "undeafen", "range", "stats"] : ["settings", "team"];
            if (args[0] === "team") return ["on", "off"];
            if (["mute", "unmute", "deafen", "undeafen", "range"].indexOf(args[0]) >= 0 && args.length === 2) return names();
            if (args[0] === "range" && args.length === 3) return ["8", "16", "32", "48", "96", "reset"];
            return [];
        },
        run: function (p, args) {
            if (!p) return;
            var sub = args[0] ? String(args[0]).toLowerCase() : "";
            if (sub === "settings") { RPG.net.send(p, "pv_settings", {}); return; }
            if (sub === "team") {
                var on = args[1] ? String(args[1]) !== "off" : !!TEAM_OFF[String(p.uuid)];
                if (on) delete TEAM_OFF[String(p.uuid)]; else TEAM_OFF[String(p.uuid)] = true;
                place(p);
                var t = teamKey(p);
                p.tell(on ? (t ? "&aTeam channel on &7(hold the channel key to talk to your team)" : "&7Team channel on, but you have no team or party yet.") : "&7Team channel off.");
                return;
            }
            if (!p.isOp() || sub === "" || sub === "help") { help(p); return; }
            if (sub === "staff") {
                if (!CFG.get("staffChannel")) { p.tell("&cThe staff channel is turned off (config proximity_voice)."); return; }
                var id = String(p.uuid);
                if (STAFF[id]) delete STAFF[id]; else STAFF[id] = true;
                place(p);
                p.tell(STAFF[id] ? "&bStaff channel: on &7(other staff hear you anywhere)" : "&7Staff channel: off");
                return;
            }
            if (sub === "mute" || sub === "unmute" || sub === "deafen" || sub === "undeafen") {
                var who = find(p, args[1]);
                if (!who) return;
                if (sub === "mute" || sub === "unmute") RPG.voice.mute(who, sub === "mute"); else RPG.voice.deafen(who, sub === "deafen");
                p.tell("&7" + who.name + ": " + sub + "d");
                who.tell(sub === "mute" ? "&cYou were muted in voice chat." : sub === "unmute" ? "&aYou can talk in voice chat again."
                    : sub === "deafen" ? "&cYou can't hear voice chat for now." : "&aYou can hear voice chat again.");
                return;
            }
            if (sub === "range") {
                var q = find(p, args[1]);
                if (!q) return;
                var v = args[2] ? String(args[2]) : "reset";
                if (v === "reset") q.setVar("pv_range", null);
                else if (!isNaN(Number(v)) && Number(v) >= 0) q.setVar("pv_range", Math.min(512, Number(v)));
                else { p.tell("&cRange is a number of blocks or reset."); return; }
                place(q);
                p.tell("&7" + q.name + " is heard within &f" + (q.getVar("pv_range") || "the default") + "&7 blocks.");
                return;
            }
            if (sub === "stats") {
                var s = RPG.voice.stats();
                var secs = Math.max(1, s.seconds);
                p.tell("&6Voice relay &7(" + Math.round(secs) + " s): &f" + s.enabled + "&7 on, &f" + s.talking + "&7 talking");
                p.tell("&7in &f" + Math.round(s.bytesIn / secs) + " B/s&7, out &f" + Math.round(s.bytesOut / secs) + " B/s&7, frames in/out &f"
                    + s.framesIn + "/" + s.framesOut + "&7, dropped &f" + s.dropped);
                p.tell("&7relay CPU &f" + Number(s.relayMs).toFixed(1) + " ms&7 total, &f" + Number(s.relayMicrosPerFrame).toFixed(1) + " µs&7 per frame");
                return;
            }
            help(p);
        }
    });
})();
