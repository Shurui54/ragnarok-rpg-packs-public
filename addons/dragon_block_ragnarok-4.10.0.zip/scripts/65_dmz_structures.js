// =====================================================================================
//  65_dmz_structures.js - every DragonMine Z structure, where DMZ puts it
// =====================================================================================
//  The templates are DMZ's own (GPL-3.0, credited in NOTICE.md), converted by a script:
//    datapack/data/dbr/structures/dmz/<name>/<x>_<z>.nbt   32x32 column pieces, vanilla blocks
//    data/dmz_structures/<name>.json                        size, pieces, DMZ blocks, NPCs, foundation
//  DMZ blocks that this addon has (Namek stone, clouds, flowers...) are put back after the pieces
//  ("blocks" in the json); the others became the closest vanilla block.
//
//  Placement (DMZ StructureSpawnPlanner / DMZStructureSets):
//   - one-per-world structures: a site 500..10000 blocks from spawn, at least 500 apart, checked
//     for the right ground (grass / sand / ocean / rock, flatness <= 20, water <= 35%)
//   - Kami's Lookout: a random chunk within 50 chunks of 0,0 (UniqueNearSpawnPlacement)
//   - Red Ribbon bases, Red Ribbon towers, Namek villages: one per random-spread cell (DMZ salts,
//     spacing, separation), built only where the ground fits
//   - the Time Chamber at chunk 0,0 of the Hyperbolic Time Chamber; the Other World landmarks
//     (Yemma's palace, Snake Way, King Kai's planet, the tournament grounds) at DMZ's coordinates
//  A structure is built (a little every tick) when a player comes within ~160 blocks.
//  /rpgc dmzlocate [name]  lists sites.   /rpgc dmzbuild <name>  builds one where you stand (ops).
// =====================================================================================

var DMZ_STRUCT_TICK_MS = 8;             // building budget per tick (well under the 25 ms warning)
var DMZ_BUILD_RANGE = 160;
var DMZ_MIN_SPAWN = 500, DMZ_MAX_SPAWN = 10000, DMZ_MIN_BETWEEN = 500;

// DMZ placement table (DMZStructureSets). kind = ground the site must have.
// biomes = DMZ's valid biomes for the set (DMZStructureSets / MainTags), checked at the site's centre from the world
// generator (no chunk is loaded for it): DMZ's IS_PLAINSLIKE, IS_OCEAN, IS_DESERTLIKE, IS_MOUNTAINLIKE, IS_LAND...
var DMZ_B_PLAINS = ["#minecraft:has_structure/village_plains", "#forge:is_plains"];
var DMZ_B_LAND = ["#minecraft:has_structure/village_plains", "#minecraft:has_structure/village_desert", "#minecraft:has_structure/village_savanna",
    "#minecraft:has_structure/village_snowy", "#minecraft:has_structure/village_taiga", "#minecraft:is_forest", "#minecraft:is_jungle",
    "#minecraft:is_badlands", "#minecraft:is_taiga", "#minecraft:is_hill", "#minecraft:is_mountain", "#forge:is_plains", "#forge:is_desert",
    "#forge:is_sandy", "#forge:is_snowy", "#forge:is_swamp", "#forge:is_mountain", "#forge:is_plateau", "#forge:is_slope", "#forge:is_peak",
    "#forge:is_lush", "#forge:is_coniferous"];
var DMZ_B_MOUNTAIN = ["#minecraft:is_mountain", "#forge:is_mountain"];
var DMZ_UNIQUE = {
    goku_house:       { dim: "minecraft:overworld", kind: "plains", salt: 12345678, biomes: DMZ_B_PLAINS },
    roshi_house:      { dim: "minecraft:overworld", kind: "ocean", salt: 87654321, biomes: ["#minecraft:is_ocean"] },
    baba_palace:      { dim: "minecraft:overworld", kind: "ocean", salt: 31415926, build: true, biomes: ["#minecraft:is_ocean"] },
    budokai_tenkaichi:{ dim: "minecraft:overworld", kind: "deep_ocean", salt: 62830185, build: true, biomes: ["minecraft:ocean", "minecraft:deep_ocean",
        "minecraft:lukewarm_ocean", "minecraft:deep_lukewarm_ocean", "minecraft:warm_ocean", "minecraft:cold_ocean", "minecraft:deep_cold_ocean"] },
    kamilookout:      { dim: "minecraft:overworld", kind: "near_origin", salt: 55667788 },
    gero_lab:         { dim: "minecraft:overworld", kind: "rocky", salt: 99887766, biomes: DMZ_B_MOUNTAIN },    // IS_GEROLAB: rocky + mountains
    babidi:           { dim: "minecraft:overworld", kind: "mountain", salt: 18273645, biomes: DMZ_B_MOUNTAIN },
    cell_arena:       { dim: "minecraft:overworld", kind: "plains", salt: 13572468, build: true, biomes: DMZ_B_PLAINS },
    piccolo_house:    { dim: "minecraft:overworld", kind: "plains", salt: 36925814, biomes: DMZ_B_PLAINS },
    yamcha_house:     { dim: "minecraft:overworld", kind: "desert", salt: 55114477, biomes: ["#minecraft:has_structure/village_desert", "#forge:is_desert"] },
    trunks_ship:      { dim: "minecraft:overworld", kind: "land", salt: 66332211, biomes: DMZ_B_LAND },
    vegeta_pod:       { dim: "minecraft:overworld", kind: "rocky", salt: 77889900, biomes: DMZ_B_LAND },          // IS_ROCKYBIOME (DMZ's own biome) -> rocky land
    buu_house:        { dim: "minecraft:overworld", kind: "plains", salt: 71727374, biomes: DMZ_B_PLAINS },
    elder_guru:       { dim: "ragnarok_rpg:namek", kind: "land", salt: 44332211, biomes: ["dbr:sacred_land"] },
    frieza_ship:      { dim: "ragnarok_rpg:namek", kind: "land", salt: 24681357, biomes: ["dbr:ajissa_plains"] },
    oldkai_pillar:    { dim: "ragnarok_rpg:sacredkaiplanet", kind: "land", salt: 41258963, biomes: ["dbr:sacredkai_plains"] }
};
// random_spread sets: spacing / separation in chunks
// (Namek and the Sacred Kai planet have real hills now: their sites use "land" - flat enough, mostly dry.)
// Saiyan craters, Namek ruins, Gomah camps and the Capsule Corp village house: 66_dmz_sites.js.
// Demon Villages and the Demon Realm tunnels: 85_world.js. World-boss lairs (Tree of Might, Gete Star,
// Gomah's cradle, Tamagami platforms, Janemba): 77_dmz_world_bosses.js.
var DMZ_SPREAD = {
    red_ribbon_base: { dim: "minecraft:overworld", kind: "grassland", salt: 40318627, spacing: 32, separation: 16, triangular: false,
        biomes: ["minecraft:plains", "minecraft:sunflower_plains", "minecraft:savanna"], avoidVillages: 8 },
    rrtower:         { dim: "minecraft:overworld", kind: "land", salt: 56345435, spacing: 48, separation: 24, triangular: true },
    namek_village:   { dim: "ragnarok_rpg:namek", kind: "land", salt: 92037394, spacing: 34, separation: 8, triangular: true }
};
// Fixed sites: [manifest, dimension, how to place]
var DMZ_FIXED = {
    timechamber:   { dim: "ragnarok_rpg:time_chamber", chunk: [0, 0] },
    ow_palace:     { dim: "ragnarok_rpg:otherworld", absolute: true, build: false, master: true },
    ow_snakeway:   { dim: "ragnarok_rpg:otherworld", absolute: true, master: true },
    ow_kingkai:    { dim: "ragnarok_rpg:otherworld", absolute: true, master: true },
    ow_tournament: { dim: "ragnarok_rpg:otherworld", absolute: true, build: true, master: true }
};
// Ki-grief protected (tags/worldgen/structure/ki_griefing_protected) and build protected ones.
var DMZ_MASTER = ["goku_house", "roshi_house", "elder_guru", "kamilookout", "piccolo_house", "yamcha_house", "oldkai_pillar",
    "timechamber", "babidi", "cell_arena", "frieza_ship", "gero_lab", "trunks_ship", "vegeta_pod", "baba_palace", "buu_house", "budokai_tenkaichi"];
var DMZ_BUILD_PROTECTED = ["baba_palace", "cell_arena", "budokai_tenkaichi", "ow_tournament"];

// NPCs placed by NPCPlacementManager in the Other World (DMZ coordinates and yaw).
var OW_NPCS = [["enma", 0.5, 150, 17.5, 180], ["dmz_baba", 9.5, 150, 3.5, 180], ["grand_kai", -30.5, 150, 12.5, 180],
    ["hell_ogre", 9.5, 150, 16.5, 200], ["king_kai", 54.5, 299, 1031.5, 180], ["toribot", 50.5, 298, 1030.5, 180],
    ["otherworld_announcer", -25.5, 352, -1164.5, 0]];

// ---- NPCs DMZ has in its structures that the addon did not have yet ----------------------
RPG.npcs.define("chi_chi", { name: "&dChi-Chi", geo: sagaLook("saga_videl", "saga_chichi"), dialogue: "chi_chi" });
RPG.dialogues.define("chi_chi", { start: "start", nodes: { start: { text: "Goku! Is that you? Oh... Hello. Don't track mud into the house, and study hard!", options: [{ text: "Yes, ma'am." }] } } });
RPG.npcs.define("chiaotzu", { name: "&fChiaotzu", geo: sagaLook("saga_chaoz"), dialogue: "chiaotzu" });
RPG.dialogues.define("chiaotzu", { start: "start", nodes: { start: { text: "Tien is training at the Tenkaichi Budokai grounds. I train too, with my mind!", options: [{ text: "Nice." }] } } });
RPG.npcs.define("dmz_quest_buu", { name: "&dMajin Buu", geo: sagaLook("saga_buufat"), dialogue: "dmz_quest_buu" });
RPG.dialogues.define("dmz_quest_buu", { start: "start", nodes: { start: { text: "Buu happy! Mr. Satan make candy. You want candy?", options: [{ text: "No thanks, Buu." }] } } });
RPG.npcs.define("cc_namekian", { name: "&aNamekian", geo: { model: DMZ_GEO + "enemies/namekian.geo.json", texture: DMZ_TEX + "enemies/namek_trader_3.png",
    animation: DMZ_ANIM + "enemies/namekian.animation.json", idle: "idle", walk: "walk" }, shop: "namek_shop" });

// The Time Chamber door pads (time_chamber_portal) are 13_dmz_blocks.js's block: overworld -> enterTimeChamber
// (85_world.js), which lands on the Time Chamber's door via dmzHtcArrival() below.

// ---- small helpers --------------------------------------------------------------------
var DMZ_MANIFESTS = {};
function dmzManifest(name) {
    if (!DMZ_MANIFESTS[name]) DMZ_MANIFESTS[name] = RPG.files.read("dmz_structures/" + name + ".json");
    return DMZ_MANIFESTS[name];
}
// One part of a manifest's foundation ("f") or block ("b") rows, or null past the last; the current part stays cached.
var DMZ_PART = { key: null, rows: null };
function dmzPart(name, kind, k, count) {
    if (!(k < (count || 0))) return null;
    let key = name + "." + kind + k;
    if (DMZ_PART.key !== key) DMZ_PART = { key: key, rows: RPG.files.read("dmz_structures/" + key + ".json") || [] };
    return DMZ_PART.rows;
}
function dmzBlockId(ref) {
    if (ref.charAt(0) !== "@") return ref;
    let id = BLOCK_IDS[ref.substring(1)];
    return id ? "ragnarok_rpg:" + id : null;
}
function dmzHash(a, b, c, d) {                      // 32-bit mix
    let h = (a | 0) ^ Math.imul(b | 0, 0x9E3779B1) ^ Math.imul(c | 0, 0x85EBCA77) ^ Math.imul(d | 0, 0xC2B2AE3D);
    h = Math.imul(h ^ (h >>> 16), 0x7FEB352D);
    h = Math.imul(h ^ (h >>> 15), 0x846CA68B);
    return (h ^ (h >>> 16)) >>> 0;
}
function dmzRng(seed) {                             // mulberry32
    let s = seed >>> 0;
    return () => {
        s = (s + 0x6D2B79F5) >>> 0;
        let t = Math.imul(s ^ (s >>> 15), 1 | s);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}
function dmzWorldSeed() {
    let s = RPG.data.get("dmz_world_seed", null);
    if (s === null) { s = RPG.randomInt(1, 2000000000); RPG.data.set("dmz_world_seed", s); }
    return s;
}
// kept in memory (reading the saved copy every tick was a big part of the per-tick cost)
var DMZ_PLANS_MEM = null, DMZ_BUILT_MEM = null;
function dmzPlans() { if (!DMZ_PLANS_MEM) DMZ_PLANS_MEM = RPG.data.get("dmz_plans", {}) || {}; return DMZ_PLANS_MEM; }
function dmzSavePlans(p) { DMZ_PLANS_MEM = p; RPG.data.set("dmz_plans", p); }
function dmzSpawn() { let s = RPG.world.spawnPoint(); return { x: Number(s.x) || 0, z: Number(s.z) || 0 }; }

// ---- keeping structures apart -------------------------------------------------------------------
// DMZ's StructureSpawnPlanner keeps every one-per-world structure (the Tree of Might and the Big Gete Star included)
// structureMinDistanceBetween (500) apart and 3 chunks away from other structure sets' starts. Each site this addon
// builds is claimed with the engine (RPG.structures.claim, saved with the world): "dmz_unique:<name>" for the
// one-per-world ones (77_dmz_world_bosses.js claims its lairs the same way), "dmz_build:<key>" for every other build.
var DMZ_UNIQUE_CLAIM = "dmz_unique:", DMZ_EXCLUSION_CHUNKS = 3;
function dmzClaim(key, dim, x1, z1, x2, z2) {
    try { RPG.structures.claim(key, dim, Math.floor(x1), Math.floor(z1), Math.floor(x2), Math.floor(z2)); } catch (e) { RPG.log("[DMZ] claim " + key + ": " + e); }
}
// Whether a centre (x, z) with a w x d footprint can host the one-per-world site `selfKey`.
function dmzUniqueSiteFree(selfKey, dim, x, z, w, d) {
    let D = DMZ_MIN_BETWEEN, keys;
    try { keys = RPG.structures.claimsIn(dim, x - D, z - D, x + D, z + D, 0); } catch (e) { return true; }
    for (let i = 0; i < keys.length; i++) {
        let k = String(keys[i]);
        if (k === selfKey) continue;
        if (k.indexOf(DMZ_UNIQUE_CLAIM) === 0) return false;            // another landmark within 500
        let c = RPG.structures.getClaim(dim, k);                          // any other build under the footprint (+3 chunks)
        let m = DMZ_EXCLUSION_CHUNKS * 16;
        if (c && c.minX <= x + w / 2 + m && c.maxX >= x - w / 2 - m && c.minZ <= z + d / 2 + m && c.maxZ >= z - d / 2 - m) return false;
    }
    // real structures only: sets packed closer than 12 chunks are scenery (the Sacred Kai planet's rock pillars)
    return RPG.structures.structuresNear(dim, Math.floor(x), Math.floor(z), DMZ_EXCLUSION_CHUNKS, { minSpacing: 12 }).length === 0;
}
// A spread / raid site: nothing claimed under its footprint grown by `margin` blocks (its own key aside).
function dmzSiteFree(selfKey, dim, x1, z1, x2, z2, margin) {
    let keys;
    try { keys = RPG.structures.claimsIn(dim, Math.floor(x1), Math.floor(z1), Math.floor(x2), Math.floor(z2), margin || 0); } catch (e) { return true; }
    for (let i = 0; i < keys.length; i++) if (String(keys[i]) !== selfKey) return false;
    return true;
}
// Whether the biome at a site's centre is one the structure may stand in (no list = any).
var DMZ_SKY_Y = {};
function dmzBiomeOk(list, dim, x, z) {
    if (!list || !list.length) return true;
    // the surface biome, read from the generator high above the terrain (nothing loads; a cave biome under a
    // mountain doesn't count, and it is far cheaper than working out the surface height)
    try {
        if (!DMZ_SKY_Y[dim]) { let r = RPG.world.heightRange(dim); DMZ_SKY_Y[dim] = r ? Math.max(80, r.max - 16) : 300; }
        return RPG.world.biomeIs(dim, Math.floor(x), DMZ_SKY_Y[dim], Math.floor(z), list);
    } catch (e) { return true; }
}
// No village start within `chunks` chunks (DMZ's exclusion zones with minecraft:villages).
function dmzNoVillageNear(dim, x, z, chunks) {
    if (!chunks) return true;
    let near;
    try { near = RPG.structures.structuresNear(dim, Math.floor(x), Math.floor(z), chunks); } catch (e) { return true; }
    for (let i = 0; i < near.length; i++) if (String(near[i].set) === "minecraft:villages") return false;
    return true;
}
// Claims for sites planned or built before claims existed (bookkeeping only; no block changes).
function dmzClaimExisting() {
    let plans = dmzPlans(), built = dmzBuilt();
    for (let name in plans) {
        let p = plans[name], m = dmzManifest(name);
        if (p.x === undefined || !m) continue;
        dmzClaim(DMZ_UNIQUE_CLAIM + name, p.dim, p.x - m.size[0] / 2, p.z - m.size[2] / 2, p.x + m.size[0] / 2, p.z + m.size[2] / 2);
    }
    for (let k in built) {
        let b = built[k];
        if (plans[k]) continue;
        dmzClaim("dmz_build:" + k, b.dim, b.x, b.z, b.x + b.sx - 1, b.z + b.sz - 1);
    }
}

// ---- ground probes (BiomeAwareUniquePlacement coverage/flatness/water, by surface blocks) ---
var DMZ_WATER = { "minecraft:water": 1, "minecraft:kelp": 1, "minecraft:kelp_plant": 1, "minecraft:seagrass": 1, "minecraft:tall_seagrass": 1, "minecraft:ice": 1 };
function dmzGroundClass(b) {
    if (DMZ_WATER[b]) return "water";
    if (b.indexOf("sand") >= 0) return "sand";
    if (b === "minecraft:grass_block" || b === "minecraft:dirt" || b === "minecraft:podzol" || b === "minecraft:coarse_dirt") return "grass";
    if (b.indexOf("snow") >= 0 || b.indexOf("ice") >= 0) return "snow";
    if (b.indexOf("log") >= 0 || b.indexOf("wood") >= 0) return "tree";
    if (b.indexOf("stone") >= 0 || b.indexOf("terracotta") >= 0 || b.indexOf("andesite") >= 0 || b.indexOf("granite") >= 0
        || b.indexOf("diorite") >= 0 || b.indexOf("gravel") >= 0 || b.indexOf("tuff") >= 0 || b.indexOf("calcite") >= 0 || b.indexOf("deepslate") >= 0) return "rock";
    if (b.indexOf("mud") >= 0 || b.indexOf("mangrove") >= 0) return "swamp";
    return "other";
}
// Samples a w x d footprint centred on (cx, cz). load = true reads unloaded chunks (generates them).
function dmzProbe(dim, cx, cz, w, d, n, load) {
    let res = { n: 0, cls: {}, tops: [], wet: 0, waterTop: -9999, deepWater: 0 };
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
        let x = Math.floor(cx - w / 2 + (i + 0.5) * w / n), z = Math.floor(cz - d / 2 + (j + 0.5) * d / n);
        if (!RPG.world.isLoaded(dim, x, z)) { if (load) RPG.world.requestChunks(dim, x, z, 0); continue; }
        let sy = RPG.world.surfaceY(dim, x, z);
        if (sy <= -9999) continue;
        let top = sy - 1, b = RPG.world.getBlock(dim, x, top, z), c = dmzGroundClass(b);
        res.n++;
        res.cls[c] = (res.cls[c] || 0) + 1;
        res.tops.push(top);
        if (c === "water") {
            res.wet++;
            res.waterTop = Math.max(res.waterTop, top);
            if (DMZ_WATER[RPG.world.getBlock(dim, x, top - 6, z)]) res.deepWater++;
        }
    }
    let sorted = res.tops.slice().sort((a, b) => a - b);
    res.median = sorted.length ? sorted[Math.floor(sorted.length / 2)] : 64;
    res.spread = sorted.length ? sorted[sorted.length - 1] - sorted[0] : 999;
    res.groundY = res.wet > 0 ? Math.max(res.median, res.waterTop + 1) : res.median;
    return res;
}
function dmzFrac(r, c) { return r.n ? (r.cls[c] || 0) / r.n : 0; }
// Score 0..100 for a site; >= 30 accepted (PROBE_ACCEPT_SCORE).
function dmzSiteScore(kind, r) {
    if (r.n < 4) return 0;
    let water = r.wet / r.n, flat = r.spread <= 20;
    switch (kind) {
        case "flat": case "near_origin": return 100;
        case "ocean": return water >= 0.6 ? Math.round(water * 100) : 0;
        case "deep_ocean": return water >= 0.98 && r.deepWater / r.n >= 0.9 ? 100 : 0;
        case "plains": return water <= 0.35 && flat && dmzFrac(r, "grass") >= 0.6 && dmzFrac(r, "tree") < 0.15 ? Math.round(dmzFrac(r, "grass") * 100) : 0;
        case "grassland": return water <= 0.35 && r.spread <= 12 && dmzFrac(r, "grass") >= 0.6 && dmzFrac(r, "tree") < 0.1 ? 100 : 0;
        case "desert": return water <= 0.35 && flat && dmzFrac(r, "sand") >= 0.6 ? Math.round(dmzFrac(r, "sand") * 100) : 0;
        case "rocky": return water <= 0.35 && (dmzFrac(r, "rock") + dmzFrac(r, "sand") * 0.5 >= 0.5 || r.median >= 95) && r.spread <= 30 ? 60 : 0;
        case "mountain": return water <= 0.35 && (r.median >= 100 || dmzFrac(r, "rock") + dmzFrac(r, "snow") >= 0.5) ? 60 : 0;
        case "land": return water <= 0.35 && flat ? Math.round((1 - water) * 100) : 0;
        case "swamp": return water <= 0.6 && flat ? Math.round(100 - water * 50) : 0;     // swamps are half water
    }
    return 0;
}

// ---- planning one-per-world sites (StructureSpawnPlanner, ring search) ------------------------
var DMZ_PLAN_QUEUE = null;
function dmzStartPlanning() {
    dmzClaimExisting();
    let plans = dmzPlans();
    DMZ_PLAN_QUEUE = [];
    for (let name in DMZ_UNIQUE) {
        let u = DMZ_UNIQUE[name];
        if (plans[name]) continue;
        if (!RPG.server.hasDimension(u.dim)) continue;            // a data-pack dimension before its first restart
        if (u.dim === "ragnarok_rpg:sacredkaiplanet" && !(typeof dbrDimensionExists === "function" ? dbrDimensionExists("sacredkaiplanet") : RPG.dimensions.exists("sacredkaiplanet"))) continue;
        let job = { name: name, probes: 0, best: null, ring: DMZ_MIN_SPAWN };
        if (u.kind === "near_origin") DMZ_PLAN_QUEUE.unshift(job); else DMZ_PLAN_QUEUE.push(job);   // reserved before the rest
    }
}
// One probe per call; returns when a site is accepted or the probe budget is used.
function dmzPlanStep() {
    if (!DMZ_PLAN_QUEUE || DMZ_PLAN_QUEUE.length === 0) return;
    let job = DMZ_PLAN_QUEUE[0], u = DMZ_UNIQUE[job.name], m = dmzManifest(job.name);
    let plans = dmzPlans(), sp = dmzSpawn(), rnd = dmzRng(dmzHash(dmzWorldSeed(), u.salt, job.probes, 7));
    if (!m) { DMZ_PLAN_QUEUE.shift(); return; }
    let x, z, r;
    let claimKey = DMZ_UNIQUE_CLAIM + job.name, w = m.size[0], d = m.size[2];
    let accept = (px, pz, score) => {
        plans[job.name] = { dim: u.dim, x: px, z: pz, state: "planned" };
        if (score !== undefined) plans[job.name].score = score;
        dmzSavePlans(plans); DMZ_PLAN_QUEUE.shift();
        dmzClaim(claimKey, u.dim, px - w / 2, pz - d / 2, px + w / 2, pz + d / 2);
    };
    if (u.kind === "near_origin") {                  // random chunk in [-50, 50) of 0,0 (reserved first; the others keep away)
        x = (Math.floor(rnd() * 100) - 50) * 16 + 8; z = (Math.floor(rnd() * 100) - 50) * 16 + 8;
        accept(x, z); return;
    }
    if (!job.pending) {
        // a ring position in the structure's biomes, 500 from the other landmarks and clear of other structures; all
        // read from the world generator, so nothing loads until a candidate passes
        let tries = 0, ok = false, t0 = Date.now();
        do {
            let a = rnd() * Math.PI * 2;
            x = Math.round(sp.x + Math.cos(a) * job.ring); z = Math.round(sp.z + Math.sin(a) * job.ring);
            // outward ring by ring like DMZ's planner; past the farthest ring start again near spawn (new angles), so a
            // rare biome close in is found on a later sweep instead of only ever trying the outermost ring
            job.ring += 16 * (1 + Math.floor(rnd() * 3));
            if (job.ring > DMZ_MAX_SPAWN) job.ring = DMZ_MIN_SPAWN;
            tries++;
            ok = !dmzTooClose(plans, u.dim, x, z) && dmzBiomeOk(u.biomes, u.dim, x, z) && dmzUniqueSiteFree(claimKey, u.dim, x, z, w, d);
        } while (tries < 24 && !ok && Date.now() - t0 < 8);           // a few ms a step: the checks read the world generator
        if (!ok) {
            job.misses = (job.misses || 0) + 1;
            if (job.misses >= 400) {
                if (job.best) accept(job.best.x, job.best.z, job.best.score);
                else {                                       // nowhere fits (no such biome in this world): DMZ leaves it out
                    plans[job.name] = { dim: u.dim, state: "none" };
                    dmzSavePlans(plans); DMZ_PLAN_QUEUE.shift();
                    RPG.log("[DMZ] no site for " + job.name + " in " + u.dim + " (biomes " + (u.biomes || []).join(" ") + ")");
                }
            }
            return;
        }
        if (u.kind === "flat") { accept(x, z); return; }
    }
    // probe the same spot until its chunks have loaded in the background (no forced generation)
    if (job.pending) { x = job.pending.x; z = job.pending.z; }
    r = dmzProbe(u.dim, x, z, Math.min(96, m.size[0]), Math.min(96, m.size[2]), 3, true);
    if (r.n < 9 && (job.waits = (job.waits || 0) + 1) < 60) { job.pending = { x: x, z: z }; return; }
    job.pending = null; job.waits = 0;
    let score = dmzSiteScore(u.kind, r);
    job.probes++;
    if (!job.best || score > job.best.score) job.best = { x: x, z: z, score: score };
    let limit = job.best.score > 0 ? 24 : 96;       // MAX_PROBES_PER_SEARCH / WITHOUT_SITE
    if (score >= 30 || job.probes >= limit) {
        accept(job.best.x, job.best.z, job.best.score);
        RPG.log("[DMZ] planned " + job.name + " at " + job.best.x + ", " + job.best.z + " (score " + job.best.score + ")");
    }
}
function dmzTooClose(plans, dim, x, z) {
    for (let k in plans) {
        let p = plans[k];
        if (p.dim === dim && p.x !== undefined && Math.abs(p.x - x) < DMZ_MIN_BETWEEN && Math.abs(p.z - z) < DMZ_MIN_BETWEEN) return true;
    }
    return false;
}

// random_spread: the chunk of the structure in a cell (vanilla RandomSpreadStructurePlacement).
function dmzSpreadChunk(set, cellX, cellZ) {
    let rnd = dmzRng(dmzHash(dmzWorldSeed(), set.salt, cellX, cellZ));
    let range = set.spacing - set.separation;
    let ox = set.triangular ? Math.floor((rnd() * range + rnd() * range) / 2) : Math.floor(rnd() * range);
    let oz = set.triangular ? Math.floor((rnd() * range + rnd() * range) / 2) : Math.floor(rnd() * range);
    return [cellX * set.spacing + ox, cellZ * set.spacing + oz, rnd()];
}

// ---- building jobs (a few pieces per tick, saved so a restart resumes) ---------------------------
var DMZ_JOBS_MEM = null;
function dmzJobs() { if (!DMZ_JOBS_MEM) DMZ_JOBS_MEM = RPG.data.get("dmz_jobs", []) || []; return DMZ_JOBS_MEM; }
function dmzSaveJobs(j) { DMZ_JOBS_MEM = j; RPG.data.set("dmz_jobs", j); }
function dmzBuilt() { if (!DMZ_BUILT_MEM) DMZ_BUILT_MEM = RPG.data.get("dmz_built", {}) || {}; return DMZ_BUILT_MEM; }
function dmzSaveBuilt(b) { DMZ_BUILT_MEM = b; RPG.data.set("dmz_built", b); }

// Queue a build of manifest `name` with its template origin at (ox, oy, oz). key = site id.
function dmzQueueBuild(key, name, dim, ox, oy, oz) {
    let jobs = dmzJobs();
    if (jobs.some((j) => j.key === key)) return;
    let m = dmzManifest(name);
    if (!m) { RPG.log("[DMZ] missing manifest " + name); return; }
    jobs.push({ key: key, name: name, dim: dim, ox: ox, oy: oy, oz: oz, phase: "load", i: 0, k: 0 });
    dmzSaveJobs(jobs);
    let built = dmzBuilt();
    built[key] = { name: name, dim: dim, x: ox, y: oy, z: oz, sx: m.size[0], sy: m.size[1], sz: m.size[2], done: false };
    dmzSaveBuilt(built);
    if (!dmzPlans()[key]) dmzClaim("dmz_build:" + key, dim, ox, oz, ox + m.size[0] - 1, oz + m.size[2] - 1);
}

// Ask for the chunks under a build in the background; true once they are all loaded.
function dmzFootprintLoaded(job, m) {
    let ok = true;
    for (let x = job.ox; x < job.ox + m.size[0] + 15; x += 16) for (let z = job.oz; z < job.oz + m.size[2] + 15; z += 16) {
        let cx = Math.min(x, job.ox + m.size[0] - 1), cz = Math.min(z, job.oz + m.size[2] - 1);
        if (!RPG.world.isLoaded(job.dim, cx, cz)) { if ((job.waits || 0) % 40 === 0) RPG.world.requestChunks(job.dim, cx, cz, 0); ok = false; }
    }
    return ok;
}

function dmzWork() {
    let jobs = dmzJobs();
    if (jobs.length === 0) return;
    let job = jobs[0], m = dmzManifest(job.name), t0 = Date.now();
    if (!m) { jobs.shift(); dmzSaveJobs(jobs); return; }
    while (Date.now() - t0 < DMZ_STRUCT_TICK_MS) {
        if (job.phase === "load") {
            // every chunk under the footprint must be loaded first: a fill in an unloaded chunk generates it on the spot
            let ready = dmzFootprintLoaded(job, m);
            if (!ready) { job.waits = (job.waits || 0) + 1; if (job.waits < 600) break; }
            job.phase = "foundation"; job.waits = 0; job.i = 0; job.k = 0; continue;
        } else if (job.phase === "foundation") {
            // rows come in parts (split_manifests.py) so no tick parses a big file
            let depth = m.foundationDepth || 0, f = depth > 0 ? dmzPart(job.name, "f", job.k, m.fParts) : null;
            if (!f) { job.phase = "pieces"; job.i = 0; job.k = 0; continue; }
            if (job.i >= f.length) { job.k++; job.i = 0; continue; }
            let r = f[job.i++], id = dmzBlockId(r[4]);
            if (id) RPG.world.fill(job.dim, job.ox + r[0], job.oy + r[3] - depth, job.oz + r[2], job.ox + r[1], job.oy + r[3] - 1, job.oz + r[2], id, "keep");
        } else if (job.phase === "pieces") {
            // the engine places queued pieces a few thousand blocks per tick (no freezes); keep its queue short
            if (job.i >= m.pieces.length) {
                if (job.last && !RPG.structures.isPlaced(job.last)) break;     // wait for the last piece
                job.phase = "blocks"; job.i = 0; job.k = 0; continue;
            }
            if (RPG.structures.pendingBlocks() > 30000) break;
            let pc = m.pieces[job.i++];
            let jid = RPG.structures.placeGradually(job.dim, pc[2], job.ox + pc[0], job.oy, job.oz + pc[1], 0);
            if (!jid) RPG.log("[DMZ] could not place " + pc[2]);
            else job.last = jid;
        } else if (job.phase === "blocks") {
            let list = dmzPart(job.name, "b", job.k, m.bParts);           // rows [block, x, y, z, length]
            if (!list) { job.phase = "spawn"; continue; }
            if (job.i >= list.length) { job.k++; job.i = 0; continue; }
            for (let n = 0; n < 25 && job.i < list.length; n++) {
                let r = list[job.i++], id = BLOCK_IDS[r[0]];
                if (id) RPG.world.fill(job.dim, job.ox + r[1], job.oy + r[2], job.oz + r[3], job.ox + r[1] + r[4] - 1, job.oy + r[2], job.oz + r[3], "ragnarok_rpg:" + id, "replace");
            }
        } else if (job.phase === "spawn") {
            (m.npcs || []).forEach((n) => dmzSpawnNpc(job.dim, n[0], job.ox + n[1], job.oy + n[2], job.oz + n[3], n[4]));
            (m.mobs || []).forEach((n) => { if (RPG.mobs.exists(n[0])) RPG.world.spawnMob(job.dim, n[0], job.ox + n[1], job.oy + n[2], job.oz + n[3]); });
            if (job.name === "ow_palace") OW_NPCS.slice(0, 4).forEach((n) => dmzSpawnNpc(job.dim, n[0], n[1], n[2], n[3], n[4]));
            if (job.name === "ow_kingkai") OW_NPCS.slice(4, 6).forEach((n) => dmzSpawnNpc(job.dim, n[0], n[1], n[2], n[3], n[4]));
            if (job.name === "ow_tournament") dmzSpawnNpc(job.dim, OW_NPCS[6][0], OW_NPCS[6][1], OW_NPCS[6][2], OW_NPCS[6][3], OW_NPCS[6][4]);
            job.phase = "done";
        } else {
            jobs.shift();
            let built = dmzBuilt();
            if (built[job.key]) { built[job.key].done = true; dmzSaveBuilt(built); DMZ_VERIFIED[job.key] = true; }
            let plans = dmzPlans();
            if (plans[job.key]) { plans[job.key].state = "built"; dmzSavePlans(plans); }
            dmzOnBuilt(job, m);
            RPG.log("[DMZ] built " + job.key + " (" + job.name + ") at " + job.ox + " " + job.oy + " " + job.oz);
            break;
        }
    }
    if (jobs.length && jobs[0] === job) jobs[0] = job;
    dmzSaveJobs(jobs);
}

function dmzSpawnNpc(dim, id, x, y, z, yaw) {
    if (!RPG.npcs.exists(id)) return null;
    let e = RPG.world.spawnNpc(dim, id, x, y, z);
    if (e) e.teleportTo(dim, x, y, z, yaw || 0, 0);
    return e;
}

// Remember the Time Chamber doors (TimeChamberPortalBlock finds them in the structures).
function dmzOnBuilt(job, m) {
    if (m.portals && m.portals.length) {
        let pads = m.portals.map((p) => [job.ox + p[0], job.oy + p[1], job.oz + p[2]]);
        let c = pads[Math.floor(pads.length / 2)];
        if (job.name === "kamilookout") RPG.data.set("dmz_lookout_portal", [job.dim, c[0], c[1], c[2]]);
        if (job.name === "timechamber") RPG.data.set("dmz_htc_portal", [job.dim, c[0], c[1], c[2]]);
    }
}

// How far along a fixed site is (Grand Kai's tournament message).
function dmzBuildPercent(key) {
    let b = dmzBuilt()[key];
    if (!b) return 0;
    if (b.done) return 100;
    let job = dmzJobs().filter((j) => j.key === key)[0], m = dmzManifest(b.name);
    if (!job || !m) return 0;
    let step = { foundation: 0, pieces: 10, blocks: 80, spawn: 99, done: 99 }[job.phase] || 0;
    if (job.phase === "pieces") step += Math.floor(70 * job.i / Math.max(1, m.pieces.length));
    return Math.min(99, step);
}

// ---- fixed sites --------------------------------------------------------------------------
// A structure marked built whose chunks were regenerated since (dimension folder deleted, an older world) is gone:
// look for any of its blocks in a few columns once per server run; none = build it again.
var DMZ_VERIFIED = {};
function dmzStillThere(key, b) {
    if (!b || !b.done || DMZ_VERIFIED[key]) return true;
    let cols = [[0.5, 0.5], [0.25, 0.25], [0.75, 0.25], [0.25, 0.75], [0.75, 0.75]];
    for (let i = 0; i < cols.length; i++) {
        let x = Math.floor(b.x + b.sx * cols[i][0]), z = Math.floor(b.z + b.sz * cols[i][1]);
        if (!RPG.world.isLoaded(b.dim, x, z)) { RPG.world.requestChunks(b.dim, x, z, 0); return true; }   // ask again later
    }
    let top = Math.min(b.y + b.sy, 2000);
    for (let i = 0; i < cols.length; i++) {
        let x = Math.floor(b.x + b.sx * cols[i][0]), z = Math.floor(b.z + b.sz * cols[i][1]);
        for (let y = b.y; y < top; y++) {
            let id = String(RPG.world.getBlock(b.dim, x, y, z));
            // anything but air and the dimension's own floor (the Other World's cloud deck) is the build
            if (id !== "minecraft:air" && id !== "minecraft:void_air" && id !== "minecraft:cave_air" && id !== String(blockRef("otherworld_cloud"))) {
                DMZ_VERIFIED[key] = true;
                return true;
            }
        }
    }
    RPG.log("[DMZ] " + key + " was marked built but is gone (chunks regenerated?): building it again");
    return false;
}

function dmzEnsureFixed(key) {
    let f = DMZ_FIXED[key], built = dmzBuilt();
    if (built[key] && !dmzStillThere(key, built[key])) { delete built[key]; dmzSaveBuilt(built); }
    if (!f || built[key]) return;
    let m = dmzManifest(key);
    if (!m) return;
    if (f.absolute) { dmzQueueBuild(key, key, f.dim, m.offset[0], m.offset[1], m.offset[2]); return; }
    // chunk-centred, flush with the floor (TerrainFit.flush(0), rotation NONE)
    let cx = f.chunk[0] * 16 + 8, cz = f.chunk[1] * 16 + 8;
    let ox = cx - Math.floor((m.size[0] - 1) / 2), oz = cz - Math.floor((m.size[2] - 1) / 2);
    // ask for the chunk in the background and try again next second (a sync load stalls the tick)
    if (!RPG.world.isLoaded(f.dim, cx, cz)) { RPG.world.requestChunks(f.dim, cx, cz, 0); return; }
    let sy = RPG.world.surfaceY(f.dim, cx, cz);
    dmzQueueBuild(key, key, f.dim, ox, (sy > -9999 ? sy - 1 : 2) - (m.ground || 0), oz);
}
function dmzEnsureOtherworld() { ["ow_palace", "ow_snakeway", "ow_kingkai"].forEach(dmzEnsureFixed); }
function dmzEnsureTournament() { dmzEnsureFixed("ow_tournament"); }

// The arrival point in the Time Chamber (85_world.js enterTimeChamber uses it).
function dmzHtcArrival() {
    dmzEnsureFixed("timechamber");
    let p = RPG.data.get("dmz_htc_portal", null);
    return p ? [p[1] + 0.5, p[2] + 1, p[3] + 0.5, 90] : null;
}

// Where the Lookout's door is (for scripts that want DMZ's HTC -> Lookout exit), or null.
function dmzLookoutPortal() {
    let p = RPG.data.get("dmz_lookout_portal", null);
    return p ? [p[0], p[1] + 0.5, p[2] + 1, p[3] + 0.5, 180] : null;
}

// ---- building near players ---------------------------------------------------------------
function dmzNear(p, dim, x, z, r) { return p.dimension === dim && Math.abs(p.x - x) < r && Math.abs(p.z - z) < r; }

function dmzBuildUnique(name, plan) {
    let m = dmzManifest(name);
    if (!m) return;
    // DMZ FittedTemplateStructure: centre on the site, ground layer on the median floor (or above water)
    let r = dmzProbe(plan.dim, plan.x, plan.z, m.size[0], m.size[2], 5, true);
    let ground = DMZ_UNIQUE[name].kind === "flat" ? r.median : r.groundY;
    let ox = plan.x - Math.floor((m.size[0] - 1) / 2), oz = plan.z - Math.floor((m.size[2] - 1) / 2);
    plan.state = "building";
    let plans = dmzPlans(); plans[name] = plan; dmzSavePlans(plans);
    dmzQueueBuild(name, name, plan.dim, ox, ground - (m.ground || 0), oz);
}

function dmzCheckSpread(p) {
    for (let setName in DMZ_SPREAD) {
        let set = DMZ_SPREAD[setName];
        if (p.dimension !== set.dim) continue;
        let size = set.spacing * 16;
        let cellX = Math.floor(p.x / size), cellZ = Math.floor(p.z / size);
        for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
            let ch = dmzSpreadChunk(set, cellX + dx, cellZ + dz);
            let x = ch[0] * 16 + 8, z = ch[1] * 16 + 8;
            if (!dmzNear(p, set.dim, x, z, DMZ_BUILD_RANGE)) continue;
            let key = setName + "@" + (cellX + dx) + "," + (cellZ + dz);
            let cells = RPG.data.get("dmz_cells", {}) || {};
            if (cells[key]) continue;
            let name = setName;
            if (setName === "namek_village") name = (ch[2] < 0.5 ? "village_ajissa_" : "village_sacred_") + Math.floor(ch[2] * 12) % 6;
            let m = dmzManifest(name);
            if (!m) { cells[key] = "missing"; RPG.data.set("dmz_cells", cells); continue; }
            if (!RPG.world.isLoaded(set.dim, x, z)) continue;
            // DMZ: the set's biomes, its exclusion zone (villages), and never on another structure
            let hw = m.size[0] / 2, hd = m.size[2] / 2;
            if (!dmzBiomeOk(set.biomes, set.dim, x, z) || !dmzNoVillageNear(set.dim, x, z, set.avoidVillages)
                || !dmzSiteFree("dmz_build:" + key, set.dim, x - hw, z - hd, x + hw, z + hd, 16)) {
                cells[key] = "blocked"; RPG.data.set("dmz_cells", cells); continue;
            }
            if (DMZ_PROBES_LEFT-- <= 0) return;           // one probe per pass
            let r = dmzProbe(set.dim, x, z, Math.min(64, m.size[0]), Math.min(64, m.size[2]), 4, false);
            if (r.n < 8) continue;                      // wait until more of it is loaded
            let ok = set.kind === "flat" || dmzSiteScore(set.kind, r) >= 30;
            cells[key] = ok ? "built" : "rejected";
            RPG.data.set("dmz_cells", cells);
            if (!ok) continue;
            let ox = x - Math.floor((m.size[0] - 1) / 2), oz = z - Math.floor((m.size[2] - 1) / 2);
            dmzQueueBuild(key, name, set.dim, ox, r.median - (m.ground || 0), oz);
        }
    }
}

var DMZ_STRUCT_TICK = 0, DMZ_PROBES_LEFT = 1;
function DBGT(what, t0) { let d = Date.now() - t0; if (d >= 20) RPG.log("[DMZ] slow step: " + what + " " + d + " ms"); }
RPG.on("serverTick", () => {
    DMZ_STRUCT_TICK++;
    DMZ_BUILT_CACHE = dmzBuilt();
    let T0 = Date.now();
    if (DMZ_PLAN_QUEUE === null && DMZ_STRUCT_TICK >= 30) { dmzStartPlanning(); DBGT("startPlanning", T0); }
    if (DMZ_STRUCT_TICK % 10 === 0) { T0 = Date.now(); dmzPlanStep(); DBGT("planStep", T0); }
    if (DMZ_STRUCT_TICK % 20 !== 0 && DMZ_STRUCT_TICK !== 40) return;          // the rest once a second
    if (DMZ_STRUCT_TICK === 40) { dmzEnsureFixed("timechamber"); dmzEnsureOtherworld(); }   // DMZ ships these pre-built
    DMZ_PROBES_LEFT = 1;
    let plans = dmzPlans();
    RPG.server.players().forEach((p) => {
        T0 = Date.now();
        for (let name in plans) {
            let plan = plans[name];
            if (plan.state === "planned" && dmzNear(p, plan.dim, plan.x, plan.z, DMZ_BUILD_RANGE)) { dmzBuildUnique(name, plan); DBGT("buildUnique " + name, T0); }
        }
        if (p.dimension === "ragnarok_rpg:time_chamber") dmzEnsureFixed("timechamber");
        if (p.dimension === "ragnarok_rpg:otherworld") {
            dmzEnsureOtherworld();
            if (Math.abs(p.z + 1200) < 300) dmzEnsureTournament();
        }
        T0 = Date.now(); dmzCheckSpread(p); DBGT("spread", T0);
        dmzFixTemplateMobs(p);
    });
});
RPG.every(1, dmzWork);

// Entities saved inside vanilla-generated chunks keep their own stats; nothing to fix for script-built ones.
function dmzFixTemplateMobs(p) { }

// ---- protection (MainGameRules: master structures resist ki griefing; arenas resist building) ---
var DMZ_BUILT_CACHE = null;
function dmzBoxAt(dim, x, y, z, list) {
    if (DMZ_BUILT_CACHE === null) DMZ_BUILT_CACHE = dmzBuilt();
    let built = DMZ_BUILT_CACHE;
    for (let k in built) {
        let b = built[k];
        if (b.dim !== dim || list.indexOf(b.name.replace(/_\d+$/, "")) < 0 && list.indexOf(k) < 0) continue;
        if (x >= b.x - 2 && x < b.x + b.sx + 2 && y >= b.y - 2 && y < b.y + b.sy + 2 && z >= b.z - 2 && z < b.z + b.sz + 2) return k;
    }
    return null;
}
// For other scripts (Dragon Ball relocation, ki griefing): inside a protected DMZ structure?
function dmzIsInMasterStructure(dim, x, y, z) {
    return dmzBoxAt(dim, x, y, z, DMZ_MASTER.concat(["ow_palace", "ow_snakeway", "ow_kingkai", "ow_tournament"])) !== null;
}
// For quests (STRUCTURE objectives / conditions): is the point inside one of our built structures named `id`?
// id is DMZ's ("dragonminez:kamilookout") or a bare name; a built record counts when its template is that name or one
// of its variants (village_ajissa -> village_ajissa_3, namek_ruins -> namek_ruins_sacred_big_r1).
function dmzInBuiltStructure(dim, x, y, z, id) {
    let want = String(id || "").replace(/^#/, "").replace(/^[^:]*:/, "");
    if (!want) return false;
    if (DMZ_BUILT_CACHE === null) DMZ_BUILT_CACHE = dmzBuilt();
    let built = DMZ_BUILT_CACHE;
    for (let k in built) {
        let b = built[k], name = String(b.name || "");
        if (b.dim !== dim || (name !== want && name.indexOf(want + "_") !== 0)) continue;
        if (x >= b.x && x < b.x + b.sx && y >= b.y && y < b.y + b.sy && z >= b.z && z < b.z + b.sz) return true;
    }
    return false;
}
RPG.on("explode", (e) => {
    if (DMZ_BUILT_CACHE !== null && Object.keys(DMZ_BUILT_CACHE).length === 0) return;
    e.keepBlocks((x, y, z) => dmzIsInMasterStructure(e.dimension, x, y, z));
});
function dmzBuildGuard(player, block, x, y, z, dim) {
    if (player.isOp() || String(player.getGameMode()) === "creative") return;
    if (dmzBoxAt(dim, x, y, z, DMZ_BUILD_PROTECTED)) { player.actionbar("&cYou can't build here."); return false; }
}
RPG.on("blockBreak", dmzBuildGuard);
RPG.on("blockPlace", dmzBuildGuard);

// ---- commands -------------------------------------------------------------------------------
RPG.commands.register("dmzlocate", {
    description: "Where DMZ's structures are (DMZ /dmzlocate)",
    run(player, args) {
        let plans = dmzPlans(), built = dmzBuilt(), want = args[0] || "";
        let tell = (s) => player ? player.tell(s) : RPG.log(s);
        for (let k in plans) if (!want || k.indexOf(want) >= 0) tell("&6" + k + " &7" + plans[k].dim + " &f" + plans[k].x + ", " + plans[k].z + " &8(" + plans[k].state + ")");
        for (let k in built) if (!plans[k] && (!want || k.indexOf(want) >= 0)) tell("&e" + k + " &7" + built[k].dim + " &f" + built[k].x + ", " + built[k].y + ", " + built[k].z + (built[k].done ? "" : " &8(building)"));
        if (DMZ_PLAN_QUEUE && DMZ_PLAN_QUEUE.length) tell("&7Still looking for sites: " + DMZ_PLAN_QUEUE.map((j) => j.name).join(", "));
    },
    suggest() { return Object.keys(DMZ_UNIQUE).concat(Object.keys(DMZ_FIXED)); }
});
RPG.commands.register("dmzbuild", {
    description: "Build a DMZ structure where you stand (ops): /rpgc dmzbuild <name>",
    permission: 2,
    run(player, args) {
        if (!player || !args[0]) return;
        let m = dmzManifest(args[0]);
        if (!m) { player.tell("&cNo structure " + args[0]); return; }
        let key = args[0] + "@manual" + RPG.server.getTick();
        dmzQueueBuild(key, args[0], player.dimension, Math.floor(player.x), Math.floor(player.y) - 1 - (m.ground || 0), Math.floor(player.z));
        player.tell("&aBuilding " + args[0] + " (" + m.pieces.length + " pieces)...");
    },
    suggest() { return Object.keys(DMZ_UNIQUE).concat(Object.keys(DMZ_FIXED), ["rrtower", "red_ribbon_base", "village_ajissa_0", "village_sacred_0", "cc_villager"]); }
});
