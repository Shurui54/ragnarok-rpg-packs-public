// =====================================================================================
//  00_project.js - who made this project, and the big game rules
// =====================================================================================
//  Welcome! This addon is Dragon Block Ragnarok, a DMZ-style game written in JavaScript:
//  layered, colourable race models, transformations with auras, ki beams, flight,
//  Dragon Balls, sagas, masters, bosses and the Hyperbolic Time Chamber.
//
//  None of that is built into the engine. The engine only knows "stats", "skills",
//  "effects", "projectiles", "avatars"... and these scripts fill them with Dragon Ball.
//  It's an addon like any other: switch it on per world in the addon picker, or copy
//  the parts you like into your own project.
//  Swap the data and the same engine makes Zelda, Sonic or a shooter (README > 15).
//
//  Every file in scripts/ runs in name order (00, 01, 05, 10, ...) and they all share
//  the same variables, so a helper made in 01_toolbox.js can be used in 90_hooks.js.
//
//  Change something, save, then type  /rpg reload  in game. Errors: /rpg errors
//  (in chat for operators after  /rpg errors chat on).  Full guide: ragnarok_rpg/README.md.
//
//  Tip: open this folder in VS Code. api.d.ts gives you autocomplete for RPG.*
// =====================================================================================

// ---- Project info -------------------------------------------------------------------
// "id" + "version" let servers offer their art to players who join (see README > Packs).
RPG.project.configure({
    id: "dragon-block-ragnarok",
    name: "Dragon Block Ragnarok",
    version: "2.0.0",
    author: "Ragnarok Studios",
    // Art libraries this project needs. Players are asked once to download them from the pack list
    // (into their Minecraft folder). "dmzpack@1.0.0" = every DMZ model, texture and sound (credits are inside that pack);
    // "dungeonpack" = the Dungeon Maker's blocks and menus; "outfitpack" = the Tailor's Catalogue outfits and cosmetics (credits inside).
    assetPacks: ["dmzpack@1.1.0", "dungeonpack@1.0.0", "outfitpack@1.0.0"],
    description: "Dragon Block Ragnarok, a DMZ-style game: six layered races, 30+ transformations, 40+ techniques, flight, ki charging, Dragon Balls, four sagas, masters, world bosses and the Hyperbolic Time Chamber."
});

// ---- Leveling & training (DMZ style) ------------------------------------------------
// mode "both": killing things gives XP -> levels -> SKILL points.
//              fighting & training gives TP -> spend TP on STATS in the menu (K).
// Other modes: "levels" (classic RPG: levels give stat points) or "tp" (TP only).
// DMZ: no XP. Stats are bought with TP (Training Points), and your level is worked out from
// your total stats (09_dmz_stats.js). TP comes from training, hits, kills, travel, mining and crafting.
RPG.leveling.configure({
    mode: "tp",
    maxLevel: 1000000,
    totalMaxAllocated: 6000000,            // DMZ: 1,000,000 x 6 stats
    pointsBeforeTp: true,                  // quest attribute points (AP) are spent before TP
    refillOnLevelUp: false,
    showXpGain: false,
    skillMastery: true,
    allowRaceChange: false,
    allowClassChange: false,
    partyShare: 0.5, partyRange: 48, partyMaxSize: 6,
    // TP gains are DMZ's own (09_dmz_stats.js); the engine's built-in ones are off
    tp: { perHit: 0, perDamage: 0, perMinute: 0, multiplier: 1 }
});

RPG.currency.configure({
    name: "Zeni",
    symbol: "Z",
    starting: 100
});

// ---- Combat -------------------------------------------------------------------------
// The stat names here are the ids from 10_stats.js.
// Damage and defence are DMZ's formulas (09_dmz_stats.js): melee from STR, damage taken through
// DMZ's own defence curve, so vanilla armour doesn't reduce it a second time.
RPG.combat.configure({
    vanillaArmor: false,
    damageFormula: (e) => dmzMeleeDamage(e)
});
