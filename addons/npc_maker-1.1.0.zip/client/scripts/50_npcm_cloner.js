// =====================================================================================
//  NPC Maker (client) - the NPC Cloner screen
// =====================================================================================
//  Two shelves of numbered tabs: Server (saved with the world, shared by all staff) and
//  Client (files on this computer, ragnarok_rpg/local/npc_clones/, usable on any world or
//  server where you may edit NPCs). Each tab shows its saved NPCs as a grid of live previews.
//  Pick one to place it where you look, keep it in the cloner (right-click blocks to place
//  more), copy it to another tab, or delete it; save the NPC you right-clicked into the tab.
// =====================================================================================
var NPCM_CLONER_UI = (function () {
    var U = NPCM_UI;
    var CLIENT_TABS = 15, DIR = "npc_clones";
    var C = null, LAST = { src: "server", tab: 1 };          // the tab shown last, opened again next time

    // ---- this computer's clones (client tabs) ----
    function slug(n) { n = String(n || "").toLowerCase().replace(/&[0-9a-fk-or]/g, "").replace(/[^a-z0-9_\-]+/g, "_").replace(/^_+|_+$/g, ""); return n.substring(0, 48) || "npc"; }
    function clientNames() { try { var n = RPG.files.readLocal(DIR + "/tabs.json"); return n && typeof n === "object" ? n : {}; } catch (e) { return {}; } }
    function clientTab(tab) {
        var out = [];
        try {
            RPG.files.listLocal(DIR + "/tab_" + tab).forEach(function (f) {
                var c = null;
                try { c = RPG.files.readLocal(f); } catch (e) { }
                if (!c || !c.npc) return;
                out.push({ key: String(f).replace(/^.*\//, "").replace(/\.json$/, ""), name: String(c.name || c.npc.name || "NPC"), npc: c.npc, at: c.at || 0, scale: c.scale || 0 });
            });
        } catch (e) { U.status("Couldn't read your saved NPCs: " + e, "#FF7070"); }
        out.sort(function (a, b) { return U.strip(a.name).toLowerCase() < U.strip(b.name).toLowerCase() ? -1 : 1; });
        return out;
    }
    function clientSave(tab, name, npc, scale) {
        var nm = String(name || npc.name || "NPC").substring(0, 64), s = slug(nm), f = DIR + "/tab_" + tab + "/" + s + ".json";
        for (var i = 2; RPG.files.readLocal(f); i++) f = DIR + "/tab_" + tab + "/" + slug(nm) + "_" + i + ".json";
        try { RPG.files.writeLocal(f, { format: "ragnarok_npc_clone", version: 1, name: nm, npc: npc, scale: scale || 0, at: Date.now() }); }
        catch (e) { U.status("Couldn't save: " + e, "#FF7070"); return false; }
        U.status("Saved " + U.strip(nm) + " in client tab " + tab + " (on this computer)", "#80FF80");
        return true;
    }

    // ---- server messages ----
    function send(op, data) { var m = data || {}; m.op = op; RPG.net.send("npcm_clone", m); }
    function sendBig(op, obj) {
        var s = JSON.stringify(obj), n = Math.max(1, Math.ceil(s.length / 20000)), id = "c" + Math.floor(RPG.nowMs());
        if (n > 40) { U.status("Too big to send (" + s.length + " characters)", "#FF6060"); return false; }
        for (var i = 0; i < n; i++) RPG.net.send("npcm_clone", { op: op, id: id, i: i, n: n, s: s.substring(i * 20000, (i + 1) * 20000) });
        return true;
    }
    U.onBig("cloner", function (d) {
        C = { src: LAST.src, tab: LAST.tab, tabs: d.tabs || 15, names: d.names || {}, cnames: clientNames(),
            target: d.target, hand: d.hand, sel: null, filter: "", saveName: d.target ? U.strip(d.target.name) : "", copyTo: "", yaw: 0, renaming: false };
        C.items = C.src === "server" ? (C.tab === (d.tab || 1) ? d.items || [] : []) : clientTab(C.tab);
        if (C.src === "server" && C.tab !== (d.tab || 1)) send("tab", { tab: C.tab });
        U.open({ draw: draw, back: back, onMouse: NPCM_EDITOR.confirmMouse });
        U.reset();
    });
    U.onBig("clone_tab", function (d) {
        if (!C) return;
        C.names = d.names || C.names; C.hand = d.hand;
        if (C.src === "server" && C.tab === d.tab) { C.items = d.items || []; if (C.sel && !find(C.sel)) C.sel = null; U.reset(); }
    });
    function back() { if (C && C.renaming) { C.renaming = false; U.reset(); return; } U.close(); C = null; }
    function find(k) { for (var i = 0; i < C.items.length; i++) if (C.items[i].key === k) return C.items[i]; return null; }

    function showTab(src, tab) {
        C.src = src; C.tab = tab; C.sel = null; C.renaming = false; C.copyTo = ""; LAST = { src: src, tab: tab };
        if (src === "client") { C.cnames = clientNames(); C.items = clientTab(tab); }
        else { C.items = []; send("tab", { tab: tab }); }
        U.reset();
    }
    function tabName(src, t) { var n = (src === "server" ? C.names : C.cnames)[String(t)]; return n ? String(n) : (src === "server" ? "Server " : "Client ") + t; }
    function allTabs() {
        var o = [];
        for (var t = 1; t <= C.tabs; t++) o.push({ value: "server:" + t, label: "Server " + t + (C.names[String(t)] ? ": " + C.names[String(t)] : ""), tooltip: "Saved with the world, shared by all staff" });
        for (var c = 1; c <= CLIENT_TABS; c++) o.push({ value: "client:" + c, label: "Client " + c + (C.cnames[String(c)] ? ": " + C.cnames[String(c)] : ""), tooltip: "On this computer, for any world or server" });
        return o;
    }
    function renameTab(name) {
        if (C.src === "server") send("rename_tab", { tab: C.tab, name: name });
        else {
            var n = clientNames(); name = String(name || "").trim().substring(0, 32);
            if (name) n[String(C.tab)] = name; else delete n[String(C.tab)];
            try { RPG.files.writeLocal(DIR + "/tabs.json", n); C.cnames = n; U.status("Client tab " + C.tab + (name ? " is now '" + name + "'" : " name cleared"), "#80FF80"); }
            catch (e) { U.status("Couldn't rename: " + e, "#FF7070"); }
        }
        C.renaming = false; U.reset();
    }

    /** Saves the targeted NPC (or a clone being copied) into a tab. */
    function saveInto(dest, name, npc, scale, liveUuid) {
        var p = String(dest).split(":"), src = p[0], tab = Number(p[1]);
        if (src === "client") { if (clientSave(tab, name, npc, scale) && C.src === "client" && C.tab === tab) C.items = clientTab(tab); U.reset(); }
        else if (liveUuid) send("save", { uuid: liveUuid, tab: tab, name: name });
        else sendBig("save_data", { tab: tab, name: name, npc: npc, scale: scale });
    }
    function useClone(it, spawnNow) {
        if (C.src === "server") send(spawnNow ? "spawn" : "hold", { tab: C.tab, key: it.key });
        else if (sendBig(spawnNow ? "spawn_data" : "hold_data", { name: it.name, npc: it.npc, scale: it.scale, spawnNow: !!spawnNow })) {
            C.hand = { name: it.name, npc: it.npc };
        }
    }
    function deleteClone(it) {
        var S = U.state();
        S.confirm = { text: "Delete '" + U.strip(it.name) + "' from " + tabName(C.src, C.tab) + "?" + (C.src === "client" ? " The file on this computer goes too." : " Every staff member loses it."), yes: function () {
            if (C.src === "server") send("delete", { tab: C.tab, key: it.key });
            else { RPG.files.deleteLocal(DIR + "/tab_" + C.tab + "/" + it.key + ".json"); C.items = clientTab(C.tab); U.status("Deleted", "#80FF80"); }
            C.sel = null; U.reset();
        } };
        S.drawTop = NPCM_EDITOR.drawConfirm;
    }

    // ---- drawing ----
    function draw(ctx, S) {
        if (!C) return;
        var w = Math.min(470, ctx.width - 10), h = Math.min(304, ctx.height - 10), x = Math.round((ctx.width - w) / 2), y = Math.round((ctx.height - h) / 2);
        U.panel(ctx, x, y, w, h);
        U.text(ctx, "NPC Cloner", x + 8, y + 7, "#404040");
        var handTxt = C.hand ? "In hand: " + U.strip(C.hand.name) : "Nothing in hand";
        U.text(ctx, U.fit(ctx, handTxt, 200), x + w - 8 - (C.hand ? 46 : 0), y + 7, C.hand ? "#2D5A2D" : "#707070", "right");
        if (C.hand) U.button(ctx, "Empty", x + w - 50, y + 4, 44, 13, function () { send("drop"); C.hand = null; }, { tip: "Put the NPC in hand back" });

        // shelves and numbered tabs
        var ty = y + 20;
        U.button(ctx, "Server", x + 8, ty, 48, 16, function () { showTab("server", C.src === "server" ? C.tab : 1); }, { selected: C.src === "server", tip: ["Server tabs", "&7Saved with this world, shared by all staff"] });
        U.button(ctx, "Client", x + 58, ty, 48, 16, function () { showTab("client", C.src === "client" ? C.tab : 1); }, { selected: C.src === "client", tip: ["Client tabs", "&7Files on this computer: take your NPCs", "&7to any world or server you edit"] });
        var n = C.src === "server" ? C.tabs : CLIENT_TABS, tw = Math.min(22, Math.floor((w - 122) / n));
        for (var t = 1; t <= n; t++) (function (t) {
            U.button(ctx, String(t), x + 114 + (t - 1) * tw, ty, tw - 2, 16, function () { showTab(C.src, t); }, { selected: C.tab === t, tip: tabName(C.src, t) });
        })(t);

        // tab name, rename, jump, filter
        var ry = y + 40;
        if (C.renaming) {
            U.input(ctx, "cl_rename_" + C.src + C.tab, x + 8, ry, 140, 14, C.renameText, function (v) { C.renameText = v; }, { maxLength: 32, hint: (C.src === "server" ? "Server " : "Client ") + C.tab });
            U.button(ctx, "OK", x + 152, ry, 30, 14, function () { renameTab(C.renameText); });
            U.button(ctx, "Cancel", x + 186, ry, 44, 14, function () { C.renaming = false; U.reset(); });
        } else {
            U.text(ctx, U.fit(ctx, tabName(C.src, C.tab), 150), x + 8, ry + 3, "#202020");
            U.button(ctx, "Rename", x + 162, ry, 50, 14, function () { C.renaming = true; C.renameText = (C.src === "server" ? C.names : C.cnames)[String(C.tab)] || ""; U.reset(); }, { tip: "Name this tab" });
        }
        U.dropdown(ctx, "cl_jump", x + 236, ry, 110, 14, allTabs(), C.src + ":" + C.tab, function (v) { var p = String(v).split(":"); showTab(p[0], Number(p[1])); }, { search: true, listWidth: 200, placeholder: "Go to tab..." });
        U.input(ctx, "cl_filter", x + 350, ry, w - 358, 14, C.filter, function (v) { C.filter = v.toLowerCase(); }, { hint: "Search...", maxLength: 40 });

        // the grid
        var gx = x + 8, gy = y + 58, gw = w - 22, gh = h - 58 - (C.target ? 66 : 46);
        U.dark(ctx, gx, gy, gw + 6, gh);
        var rows = C.items.filter(function (it) { return !C.filter || (U.strip(it.name) + " " + it.key).toLowerCase().indexOf(C.filter) >= 0; });
        var cw = 62, chh = 78, cols = Math.max(1, Math.floor((gw - 4) / cw));
        U.scrollArea(ctx, "cl_grid_" + C.src + C.tab, gx + 1, gy + 1, gw + 2, gh - 2, function (y0) {
            rows.forEach(function (it, i) {
                var cx = gx + 3 + (i % cols) * cw, cy = y0 + 2 + Math.floor(i / cols) * chh;
                if (cy + chh < gy || cy > gy + gh) return;
                var sel = C.sel === it.key, hov = U.over(ctx, cx, cy, cw - 2, chh - 2);
                ctx.fill(cx, cy, cw - 2, chh - 2, sel ? "#3A5F3A" : hov ? "#303030" : "#1A1A1A", 1);
                if (sel) { ctx.fill(cx, cy, cw - 2, 1, "#FFFFA0", 1); ctx.fill(cx, cy + chh - 3, cw - 2, 1, "#FFFFA0", 1); ctx.fill(cx, cy, 1, chh - 2, "#FFFFA0", 1); ctx.fill(cx + cw - 3, cy, 1, chh - 2, "#FFFFA0", 1); }
                var vis = cy >= gy - 4 && cy + chh - 12 <= gy + gh + 4;
                if (vis) {
                    ctx.clip(cx + 1, Math.max(cy + 1, gy + 1), cw - 4, Math.min(chh - 14, gy + gh - 2 - cy));
                    try { ctx.npc((C.src === "server" ? "s" : "c") + C.tab + "_" + it.key, it.npc, cx + cw / 2 - 1, cy + chh - 18, 26, sel ? C.yaw : 0); } catch (e) { }
                    ctx.unclip();
                }
                U.text(ctx, U.fit(ctx, U.strip(it.name), cw - 6), cx + cw / 2 - 1, cy + chh - 13, sel ? "#FFFFA0" : "#E0E0E0", "center", true);
                U.hit(cx, cy, cw - 2, chh - 2, function () { C.sel = sel ? null : it.key; C.copyTo = ""; U.reset(); },
                    [U.strip(it.name), "&7" + (it.npc.model === "entity" ? U.entityName(it.npc.entity) : it.npc.model === "geo" ? "Animated model" : "Player model") + (it.npc.role ? ", " + it.npc.role : ""),
                        it.by ? "&8saved by " + it.by : "&8" + it.key, "&eClick: select", "&eRight-click: place where you look"],
                    function () { useClone(it, true); });
            });
            return Math.ceil(rows.length / cols) * chh + 4;
        });
        if (!rows.length) U.text(ctx, C.items.length ? "Nothing matches." : C.src === "server" ? "No NPCs saved in this tab yet." : "No NPCs saved here yet (this computer).", gx + gw / 2, gy + gh / 2 - 4, "#A0A0A0", "center", true);

        // the selected one
        var by = gy + gh + 4, it = C.sel ? find(C.sel) : null;
        if (it) {
            U.button(ctx, "Place here", x + 8, by, 70, 16, function () { useClone(it, true); }, { tip: ["Makes a new NPC from it where you look", "&7and keeps it in the cloner for more"] });
            U.button(ctx, "Hold", x + 80, by, 42, 16, function () { useClone(it, false); }, { tip: ["Keep it in the cloner: right-click blocks", "&7to place it (sneak: linked copies)"] });
            U.button(ctx, "<", x + 124, by, 14, 16, function () { C.yaw -= 30; }, { tip: "Turn the preview" });
            U.button(ctx, ">", x + 140, by, 14, 16, function () { C.yaw += 30; });
            U.text(ctx, "Copy to", x + 160, by + 4, "#404040");
            U.dropdown(ctx, "cl_copy", x + 198, by + 1, 132, 14, allTabs().filter(function (o) { return o.value !== C.src + ":" + C.tab; }), C.copyTo, function (v) {
                C.copyTo = v; if (v) { saveInto(v, it.name, it.npc, it.scale, null); C.copyTo = ""; U.reset(); }
            }, { search: true, listWidth: 200, placeholder: "(pick a tab)" });
            U.button(ctx, "Delete", x + w - 58, by, 50, 16, function () { deleteClone(it); }, { color: "#FF9090" });
        } else U.text(ctx, "Click an NPC to pick it; right-click one to place it where you look.", x + 8, by + 4, "#606060");

        // saving the targeted NPC
        if (C.target) {
            var sy = by + 20;
            ctx.fill(x + 8, sy - 2, w - 16, 1, "#8B8B8B", 1);
            U.text(ctx, U.fit(ctx, "Save " + U.strip(C.target.name) + " (" + C.target.id + ") as", 170), x + 8, sy + 5, "#303030");
            U.input(ctx, "cl_savename", x + 180, sy + 2, 110, 14, C.saveName, function (v) { C.saveName = v; }, { maxLength: 64, hint: U.strip(C.target.name) });
            U.button(ctx, "Save to " + (C.src === "server" ? "S" : "C") + C.tab, x + 294, sy + 1, 76, 16, function () {
                saveInto(C.src + ":" + C.tab, C.saveName || C.target.name, C.target.npc, C.target.scale, C.src === "server" ? C.target.uuid : null);
            }, { tip: ["Into the tab shown: " + tabName(C.src, C.tab), C.src === "server" ? "&7Saved with this world" : "&7A file on this computer"] });
            U.button(ctx, "Close", x + w - 58, sy + 1, 50, 16, function () { back(); });
        } else U.button(ctx, "Close", x + w - 58, h + y - 22, 50, 16, function () { back(); });
    }

    return { open: function () { send("refresh", { tab: 1 }); } };
})();
