// =====================================================================================
//  NPC Maker (client) - the hub and the NPC editor
// =====================================================================================
//  Hub: every NPC, faction, dialogue, quest and shop (made in game or by scripts) and the
//  presets on this computer/server. NPC editor: tabs on the left, a live preview of the NPC
//  (it changes in the world the moment you save), the fields on the right. Saving sends the
//  whole definition; the server cleans it and applies it to every copy of that NPC at once.
// =====================================================================================
var NPCM_EDITOR = (function () {
    var U = NPCM_UI;
    var TABS = ["Display", "Model", "Stats", "Combat", "AI", "Faction", "Talk", "Role", "Copies"];
    var E = null;          // editor state
    var LISTS = { npcs: [], factions: [], dialogues: [], quests: [], shops: [] };

    function opts(list, none) {
        var o = none === false ? [] : [{ value: "", label: none || "(none)" }];
        (list || []).forEach(function (x) { o.push({ value: x.id, label: U.strip(x.name) + (x.name !== x.id ? "  [" + x.id + "]" : "") + (x.world ? "" : " (script)") }); });
        return o;
    }
    function dirty() { if (E) E.dirty = true; }
    function save(silent) {
        if (!E || !E.world) return;
        var payload = { id: E.id, data: E.data };
        if (E.spawnChanged) payload.spawn = E.spawn && E.spawn.enabled !== undefined ? E.spawn : null;
        if (U.sendBig("save", payload)) { E.dirty = false; E.spawnChanged = false; if (!silent) U.status("Saving...", "#FFFF80"); }
    }
    RPG.net.on("npcm_saved", function (d) {
        if (!d) return;
        if (d.lists) LISTS = d.lists;
        if (NPCM_CONTENT && NPCM_CONTENT.onSaved) NPCM_CONTENT.onSaved(d);
    });

    // =================================================================================
    //  Hub
    // =================================================================================
    var HUB_TABS = ["NPCs", "Factions", "Dialogues", "Quests", "Shops", "Presets"];
    var H = { tab: 0, filter: "" };
    U.onBig("hub", function (d) {
        LISTS = d;
        H.presets = d.presets || [];
        openHub();
    });
    function openHub() {
        U.open({ draw: drawHub, back: function () { U.close(); } });
        U.reset();
    }
    function drawHub(ctx, S) {
        var w = 380, h = 250, x = Math.round((ctx.width - w) / 2), y = Math.round((ctx.height - h) / 2);
        U.panel(ctx, x, y, w, h, "NPC Maker");
        HUB_TABS.forEach(function (t, i) { U.button(ctx, t, x + 8 + i * 61, y + 20, 59, 16, function () { H.tab = i; H.filter = ""; U.reset(); }, { selected: H.tab === i }); });
        U.input(ctx, "hub_filter", x + 8, y + 42, 180, 14, H.filter, function (v) { H.filter = v.toLowerCase(); }, { hint: "Search...", maxLength: 40 });
        var kind = ["npc", "faction", "dialogue", "quest", "shop", "preset"][H.tab];
        var rows = H.tab === 5 ? H.presets.map(function (p) { return { id: p, name: p, world: true }; })
            : (LISTS[["npcs", "factions", "dialogues", "quests", "shops"][H.tab]] || []);
        rows = rows.filter(function (r) { return !H.filter || (r.id + " " + U.strip(r.name)).toLowerCase().indexOf(H.filter) >= 0; });
        // new
        if (H.tab === 0) U.button(ctx, "New NPC here", x + w - 108, y + 41, 100, 16, function () { U.send("create"); U.close(); });
        else if (H.tab < 5) U.button(ctx, "New " + kind, x + w - 108, y + 41, 100, 16, function () { NPCM_CONTENT.create(kind); });
        else U.button(ctx, "Get tools", x + w - 108, y + 41, 100, 16, function () { U.send("give_tools"); }, { tip: "The NPC Wand and the NPC Cloner" });
        U.dark(ctx, x + 8, y + 62, w - 22, h - 70);
        U.list(ctx, "hub_" + H.tab, x + 9, y + 63, w - 24, h - 72, rows, 18, function (r, i, ry) {
            var rx = x + 9, hov = U.over(ctx, rx, ry, w - 24, 18);
            if (hov) ctx.fill(rx, ry, w - 24, 18, "#FFFFFF", 0.08);
            U.text(ctx, U.fit(ctx, U.strip(r.name), 170), rx + 4, ry + 5, r.world ? "#FFFFFF" : "#A0A0A0", "left", true);
            U.text(ctx, U.fit(ctx, r.id + (r.world ? "" : "  (script)"), 110), rx + 180, ry + 5, "#808080", "left", true);
            var bx = x + w - 20;
            if (H.tab === 5) {
                bx -= 50; U.button(ctx, "Place", bx, ry + 1, 48, 16, function () { U.send("preset_place", { name: r.id }); U.close(); }, { tip: "Make a new NPC from this preset where you look" });
                bx -= 50; U.button(ctx, "Delete", bx, ry + 1, 48, 16, function () { U.send("preset_delete", { name: r.id }); });
                return;
            }
            bx -= 50;
            U.button(ctx, H.tab === 0 ? "Edit" : r.world ? "Edit" : "View", bx, ry + 1, 48, 16, function () {
                if (H.tab === 0) { U.send("edit_def", { id: r.id }); }
                else NPCM_CONTENT.edit(kind, r.id);
            }, { tip: H.tab === 0 ? "Edit (places one where you look if none is loaded)" : null });
            if (r.world) { bx -= 50; U.button(ctx, "Delete", bx, ry + 1, 48, 16, function () { confirmDelete(kind, r); }); }
        });
        if (!rows.length) U.text(ctx, H.tab === 5 ? "No presets yet: save one from an NPC's Copies tab." : "Nothing here yet.", x + w / 2, y + 120, "#A0A0A0", "center", true);
    }
    function confirmDelete(kind, r) {
        var S = U.state();
        S.confirm = { text: "Delete " + kind + " '" + U.strip(r.name) + "'?" + (kind === "npc" ? " Every copy in the world goes too." : ""), yes: function () {
            if (kind === "npc") U.send("delete_def", { id: r.id }); else U.send("delete_kind", { kind: kind, id: r.id });
        } };
        S.drawTop = drawConfirm;
    }
    /** Asks before doing something that can't be undone. */
    function confirm(text, yes, label) {
        var S = U.state();
        if (!S) return;
        S.confirm = { text: text, yes: yes, label: label };
        S.drawTop = drawConfirm;
    }
    function removeThis() {
        confirm("Remove this " + U.strip(E.data.name || E.id) + " from the world?" + (E.world ? " Its definition stays (other copies, the hub)." : ""), function () {
            U.send("delete_entity", { uuid: E.ent.uuid }); U.close();
        }, "Remove");
    }
    function drawConfirm(ctx, S) {
        if (!S.confirm) return;
        var w = 260, h = 70, x = (ctx.width - w) / 2, y = (ctx.height - h) / 2;
        ctx.fill(0, 0, ctx.width, ctx.height, "#000000", 0.4);
        U.panel(ctx, x, y, w, h);
        U.wrap(ctx, S.confirm.text, w - 16).forEach(function (l, i) { U.text(ctx, l, x + 8, y + 8 + i * 10, "#404040"); });
        // drawn on top: these buttons are handled by our own mouse hook
        S.confirmBtns = [{ x: x + 20, y: y + h - 24, w: 100, h: 18, fn: function () { var c = S.confirm; S.confirm = null; c.yes(); } },
            { x: x + w - 120, y: y + h - 24, w: 100, h: 18, fn: function () { S.confirm = null; } }];
        U.button(ctx, S.confirm.label || "Delete", x + 20, y + h - 24, 100, 18, null, { color: "#FF8080" });
        U.button(ctx, "Cancel", x + w - 120, y + h - 24, 100, 18, null);
    }
    function confirmMouse(x, y, b, action) {
        var S = U.state();
        if (!S || !S.confirm) return false;
        if (action === "down" && b === 0 && S.confirmBtns) {
            for (var i = 0; i < S.confirmBtns.length; i++) if (U.inside(x, y, S.confirmBtns[i])) { S.confirmBtns[i].fn(); return true; }
        }
        return true;   // swallow everything else while asking
    }

    // =================================================================================
    //  NPC editor
    // =================================================================================
    U.onBig("editor", function (d) {
        var keepTab = E && E.id === d.id ? E.tab : 0;
        LISTS = d.lists || LISTS;
        E = { id: d.id, world: !!d.world, data: d.data || {}, ent: d.entity || {}, linked: d.linked || 1, choices: d.choices || {}, tab: keepTab,
            spawn: d.spawn || {}, spawnChanged: false, given: d.givenQuests || [], dirty: false, yaw: 20, presetName: "", recording: d.recording };
        if (E.data.model === undefined) E.data.model = E.data.geo && E.data.geo.model ? "geo" : E.data.entity ? "entity" : "player";
        E.skinSource = E.data.skinUrl ? "url" : E.data.skinPlayer ? "player" : "resource";
        E.capeSource = E.data.capeUrl ? "url" : "resource";
        E.overlaySource = E.data.overlayUrl ? "url" : "resource";
        U.open({ draw: drawEditor, back: function () { if (NPCM_CONTENT.pickOpen()) { NPCM_CONTENT.closePick(); U.reset(); return; } if (E && E.dirty) save(true); U.close(); }, onMouse: confirmMouse, onClose: function () { if (E && E.dirty && E.world) save(true); E = null; } });
        U.reset();
    });

    function drawEditor(ctx, S) {
        if (!E) return;
        if (NPCM_CONTENT.pickOpen()) { NPCM_CONTENT.drawPick(ctx); return; }
        var w = Math.min(470, ctx.width - 10), h = Math.min(300, ctx.height - 10), x = Math.round((ctx.width - w) / 2), y = Math.round((ctx.height - h) / 2);
        U.panel(ctx, x, y, w, h);
        U.text(ctx, U.fit(ctx, U.strip(E.data.name || E.id), 200) + "  ", x + 8, y + 7, "#404040");
        U.text(ctx, E.id + (E.world ? "" : "  (script NPC: read only)") + (E.linked > 1 ? "  - " + E.linked + " loaded copies" : ""), x + 8 + U.tw(ctx, U.strip(E.data.name || E.id)) + 8, y + 7, "#707070");
        // tabs (left column)
        TABS.forEach(function (t, i) { U.button(ctx, t, x + 6, y + 20 + i * 18, 62, 16, function () { E.tab = i; U.reset(); }, { selected: E.tab === i }); });
        // preview
        var px = x + 72, py = y + 20, pw = 96, ph = h - 50;
        U.dark(ctx, px, py, pw, ph);
        if (E.ent.netId !== undefined) {
            ctx.clip(px + 1, py + 1, pw - 2, ph - 2);
            ctx.entity(E.ent.netId, px + pw / 2, py + ph - 14, 52, E.yaw);
            ctx.unclip();
        }
        U.hit(px, py, pw, ph, null, ["Drag to turn", "&7Saved changes show at once"]);
        U.button(ctx, "<", px, py + ph + 2, 22, 14, function () { E.yaw -= 30; });
        U.button(ctx, ">", px + pw - 22, py + ph + 2, 22, 14, function () { E.yaw += 30; });
        // bottom buttons
        if (E.world) {
            U.button(ctx, E.dirty ? "Save *" : "Save", x + w - 76, y + h - 24, 70, 18, function () { save(false); }, { color: E.dirty ? "#FFFF80" : null });
        } else {
            U.button(ctx, "Make editable copy", x + w - 126, y + h - 24, 120, 18, function () { U.send("copy_script", { id: E.id, uuid: E.ent.uuid }); },
                { tip: ["Script NPCs can't be changed here.", "&7This replaces this one NPC with an", "&7editable copy saved with the world."] });
        }
        U.button(ctx, "Hub", x + 6, y + h - 24, 62, 18, function () { if (E.dirty) save(true); U.send("hub"); });
        var bx = E.world ? x + w - 76 : x + w - 126;
        U.button(ctx, "Remove", bx - 104, y + h - 24, 50, 18, function () { removeThis(); }, { color: "#FF9090", tip: ["Remove this NPC from the world (asks first)", "&7Sneak + left-click with the wand does it too"] });
        U.button(ctx, "Clone", bx - 50, y + h - 24, 46, 18, function () { if (E.dirty) save(true); RPG.net.send("npcm_clone", { op: "refresh", uuid: E.ent.uuid, tab: 1 }); }, { tip: ["Save this NPC in the cloner", "&7(server tabs or your own client tabs)"] });
        // the tab
        var fx = x + 176, fy = y + 20, fw = w - 176 - 12, fh = h - 48;
        U.scrollArea(ctx, "tab" + E.tab, fx, fy, fw, fh, function (y0) {
            var F = U.form(ctx, fx, y0, fw - 6, 104, E.data, dirty);
            if (!E.world) { F.note("Read only: this NPC is defined by a script.", "#8B0000"); }
            [tabDisplay, tabModel, tabStats, tabCombat, tabAi, tabFaction, tabTalk, tabRole, tabCopies][E.tab](ctx, F);
            return F.y - y0 + 6;
        });
    }

    // ---- Display ----
    var ICON_CHOICES = [{ value: "", label: "(none)" }, { value: "star", label: "Star", icon: "ragnarok_rpg:textures/npc/star.png" }, { value: "trader", label: "Coin", icon: "ragnarok_rpg:textures/npc/trader.png" },
        { value: "combat", label: "Sword", icon: "ragnarok_rpg:textures/npc/combat.png" }, { value: "quest_talk", label: "Speech bubble", icon: "ragnarok_rpg:textures/npc/quest_talk.png" },
        { value: "quest_available", label: "! (yellow)", icon: "ragnarok_rpg:textures/npc/quest_available.png" }];
    function tabDisplay(ctx, F) {
        F.section("Name");
        F.text("Name", "name", { max: 64, tip: ["&-colour codes work: &6Gold &cRed"] });
        F.text("Title", "title", { max: 96, hint: "a line under the name", tip: "Shown smaller under the name" });
        F.choice("Name tag", "nametag", [{ value: "look", label: "When looked at" }, { value: "always", label: "Always" }, { value: "never", label: "Never" }], { def: "look" });
        F.section("Size and visibility");
        F.num("Size", "scale", { hint: 1, min: 0.05, max: 64, tip: "Model and hitbox scale (1 = normal)" });
        F.num("Hitbox width", "width", { hint: 0.6, min: 0.1, max: 16 });
        F.num("Hitbox height", "height", { hint: 1.8, min: 0.1, max: 32 });
        F.choice("Visibility", "visibility", [{ value: "visible", label: "Visible" }, { value: "invisible", label: "Invisible (creative sees a ghost)" }, { value: "hidden", label: "Hidden from non-operators" }], { def: "visible" });
        F.choice("Pose", "pose", [{ value: "stand", label: "Standing" }, { value: "sit", label: "Sitting" }, { value: "lie", label: "Lying down" }, { value: "crouch", label: "Crouching" },
            { value: "arms_up", label: "Arms raised" }, { value: "point", label: "Pointing" }, { value: "wave", label: "Waving" }], { def: "stand", tip: "Player-model NPCs" });
        F.section("Icon over the head");
        F.note("Quest marks (! and ?) appear on their own for each player. This icon shows when there is no quest mark.");
        F.choice("Icon", "icon", ICON_CHOICES, { custom: true, customLabel: "Texture: ", tip: ["A built-in icon or any texture", "&7mypack:textures/gui/marker.png"] });
    }

    // ---- Model ----
    function tabModel(ctx, F) {
        F.section("Model");
        F.choice("Model", "model", [{ value: "player", label: "Player (skin)" }, { value: "entity", label: "Another mob / entity" }, { value: "geo", label: "Animated model (script mob/NPC)" }], { def: "player" });
        var m = E.data.model || "player";
        if (m === "entity") {
            var living = (E.choices.living || []).map(function (id) { return { value: id, label: U.entityName(id) + "  [" + id + "]" }; });
            F.choice("Entity", "entity", living, { search: true, listWidth: 260, placeholder: "Pick a mob..." });
            F.note("Any living mob from the game or another mod; it walks and turns with the NPC.");
        } else if (m === "geo") {
            var geos = [{ value: "", label: "(pick one)" }].concat((E.choices.geos || []).map(function (g) { return { value: g.id, label: U.strip(g.name) }; }));
            F.choice("Copy model of", "geoFrom", geos, { search: true, listWidth: 240 });
            F.note("Uses the animated model, textures and animations of one of your script mobs or NPCs.");
        }
        if (m === "player") {
            F.section("Skin");
            F.label("Skin from");
            ["resource", "url", "player"].forEach(function (s, i) {
                U.button(ctx, ["Texture", "Link", "Player name"][i], F.fx() + i * 62, F.y, 60, 14, function () {
                    E.skinSource = s; delete E.data.skin; delete E.data.skinUrl; delete E.data.skinPlayer; dirty(); U.reset();
                }, { selected: E.skinSource === s });
            });
            F.y += 18;
            if (E.skinSource === "resource") F.text("Texture", "skin", { max: 200, hint: "mypack:textures/npc/guard.png" });
            if (E.skinSource === "url") { F.text("Link (https PNG)", "skinUrl", { max: 500, hint: "https://...png" }); F.note("Every player downloads it (https PNG, 64x64 or 64x32, at most 512 KB), kept in the game folder."); }
            if (E.skinSource === "player") { F.text("Player name", "skinPlayer", { max: 16, hint: "Notch" }); F.note("The skin that Minecraft account wears now (looked up by the server, cached)."); }
            F.choice("Arms", "slim", [{ value: "", label: "Automatic" }, { value: false, label: "Wide (Steve)" }, { value: true, label: "Slim (Alex)" }]);
            F.section("Cape and overlay");
            F.label("Cape from");
            ["resource", "url"].forEach(function (s, i) {
                U.button(ctx, ["Texture", "Link"][i], F.fx() + i * 62, F.y, 60, 14, function () { E.capeSource = s; delete E.data.cape; delete E.data.capeUrl; dirty(); U.reset(); }, { selected: E.capeSource === s });
            });
            F.y += 18;
            if (E.capeSource === "resource") F.text("Cape texture", "cape", { max: 200, hint: "(none)" }); else F.text("Cape link", "capeUrl", { max: 500, hint: "https://...png" });
            F.label("Glow overlay from", ["A skin-layout texture drawn full bright:", "&7glowing eyes, runes, tattoos"]);
            ["resource", "url"].forEach(function (s, i) {
                U.button(ctx, ["Texture", "Link"][i], F.fx() + i * 62, F.y, 60, 14, function () { E.overlaySource = s; delete E.data.overlay; delete E.data.overlayUrl; dirty(); U.reset(); }, { selected: E.overlaySource === s });
            });
            F.y += 18;
            if (E.overlaySource === "resource") F.text("Overlay texture", "overlay", { max: 200, hint: "(none)" });
            else F.text("Overlay link", "overlayUrl", { max: 500, hint: "https://...png" });
        }
        F.section("Equipment");
        F.note("Hold an item and click a slot to put it there; right-click a slot to empty it.");
        var slots = ["mainhand", "offhand", "head", "chest", "legs", "feet"], names = ["Main hand", "Off hand", "Head", "Chest", "Legs", "Feet"];
        slots.forEach(function (s, i) {
            var st = U.get(E.data, "equipment." + s), stack = typeof st === "string" ? { id: st } : st;
            U.slot(ctx, stack, F.x + i * 24, F.y, {
                fn: function () { U.held(function (h) { if (h) { U.set(E.data, "equipment." + s, { id: h.id, count: 1, nbt: h.nbt }); dirty(); } else U.status("Hold the item first", "#FF8080"); }); },
                right: function () { U.set(E.data, "equipment." + s, undefined); dirty(); },
                tip: [names[i]].concat(stack && stack.id ? [U.itemName(stack.id)] : ["&7empty"])
            });
        });
        F.y += 24;
    }

    // ---- Stats ----
    function tabStats(ctx, F) {
        F.section("Health");
        F.bool("Invulnerable", "invulnerable", { def: true, tip: "Can't be hurt (creative players and /kill still can)" });
        F.num("Max health", "health", { hint: 20, min: 1 });
        F.num("Regeneration", "regen", { hint: 0, unit: "HP / second", min: 0 });
        F.section("Defence");
        F.num("Armour", "armor", { hint: 0, min: 0 });
        F.num("Armour toughness", "toughness", { hint: 0, min: 0 });
        F.num("Knockback resist", "knockbackResistance", { hint: 0, min: 0, max: 1, tip: "0 to 1" });
        F.bool("Immovable", "immovable", { tip: "Never pushed, knocked back or thrown by attacks and explosions (it still walks itself)" });
        F.section("Resistance (% less damage; 100 = immune)");
        ["melee", "projectile", "fire", "explosion", "magic", "fall"].forEach(function (k) { F.num(k.charAt(0).toUpperCase() + k.substring(1), "resist." + k, { percent: true, hint: 0, unit: "%", min: -1, max: 1 }); });
        F.section("Immune to");
        [["fire", "Fire and lava"], ["drowning", "Drowning"], ["fall", "Fall damage"], ["suffocation", "Suffocation"], ["potions", "Potion effects"]].forEach(function (k) { F.bool(k[1], "immune." + k[0]); });
        F.section("Movement");
        F.num("Speed", "speed", { hint: 0.25, min: 0, max: 3, tip: "0.25 = player walking speed" });
        F.bool("Flies", "flying", { tip: "No gravity, flies to where it goes" });
        F.bool("Swims", "swims", { tip: "Moves through water like a swimmer" });
    }

    // ---- Combat ----
    function projectileChoices() {
        var o = [{ value: "", label: "(no ranged attack)" }, { value: "arrow", label: "Arrow" }, { value: "snowball", label: "Snowball" }, { value: "fireball", label: "Fireball" }];
        (E.choices.projectiles || []).forEach(function (p) { o.push({ value: p, label: "Projectile: " + p }); });
        return o;
    }
    function fighterDefault() { return E.data.invulnerable === false || E.data.role === "guard"; }
    function tabCombat(ctx, F) {
        F.section("Melee");
        F.num("Damage", "damage", { hint: 2, min: 0 });
        F.num("Attack every", "attackSpeed", { hint: 20, int: true, min: 1, unit: "ticks (20 = 1 s)" });
        F.num("Reach", "attackRange", { hint: 2, min: 0.5, max: 16, unit: "blocks" });
        F.num("Knockback", "knockback", { hint: 0, min: 0, max: 20 });
        F.section("Ranged");
        F.choice("Shoots", "ranged.projectile", projectileChoices(), { custom: true, customLabel: "Item: ", tip: ["Arrow, snowball, fireball, a projectile", "&7definition, or item:<id> (thrown item)"] });
        if (U.get(E.data, "ranged.projectile")) {
            F.num("Damage", "ranged.damage", { hint: E.data.damage || 2, min: 0 });
            F.num("Shoot every", "ranged.interval", { hint: 40, int: true, min: 2, unit: "ticks" });
            F.num("Range", "ranged.range", { hint: 16, min: 2, max: 64, unit: "blocks" });
            F.num("Accuracy", "ranged.accuracy", { percent: true, hint: 80, min: 0, max: 1, unit: "%" });
            F.num("Speed", "ranged.speed", { hint: 1.6, min: 0.1, max: 6 });
            F.num("Shots per burst", "ranged.burst", { hint: 1, int: true, min: 1, max: 10 });
            F.bool("Melee up close", "ranged.melee", { tip: "Switch to melee when the target is close" });
        }
        F.section("Behaviour");
        F.bool("Fights back", "retaliate", { def: !(E.data.invulnerable === undefined || E.data.invulnerable), tip: "Attacks whoever hurt it" });
        F.num("Flees below", "fleeAt", { percent: true, hint: 0, min: 0, max: 1, unit: "% health" });
        F.choice("Attacks players", "attackPlayers", [{ value: "hostile", label: "If its faction hates them" }, { value: "never", label: "Never" }, { value: "always", label: "Always" }], { def: fighterDefault() ? "hostile" : "never" });
        F.bool("Attacks monsters", "attackMobs", { tip: "Zombies, skeletons... (guards always do)" });
        F.bool("Fights hostile factions", "attackFactions", { def: fighterDefault(), tip: "NPCs of factions at war with its own" });
        F.num("Notices within", "aggroRange", { hint: 16, min: 1, max: 64, unit: "blocks" });
        F.section("Death");
        F.choice("Respawn", "respawn", [{ value: "never", label: "Never" }, { value: "always", label: "Always" }, { value: "day", label: "During the day" }, { value: "night", label: "At night" }, { value: "instant", label: "Instantly, at its post" }], { def: "never", tip: "Instantly: back the same tick it dies or goes missing, never twice (a creative player's kill removes it)" });
        F.num("Respawn after", "respawnDelay", { hint: 60, int: true, min: 0, unit: "seconds" });
        F.num("XP orbs", "xp", { hint: 0, int: true, min: 0 });
        F.num("Money", "money", { hint: 0, min: 0, tip: "Given to the player who kills it" });
        F.label("Drops");
        var drops = E.data.drops || [];
        U.button(ctx, "+ Held item", F.fx(), F.y, 80, 14, function () {
            U.held(function (h) { if (!h) { U.status("Hold the item first", "#FF8080"); return; } (E.data.drops = E.data.drops || []).push({ item: { id: h.id, count: 1, nbt: h.nbt }, count: h.count || 1, chance: 1 }); dirty(); U.reset(); });
        });
        F.y += 18;
        drops.forEach(function (d, i) {
            var st = typeof d.item === "string" ? { id: d.item } : d.item;
            U.slot(ctx, st, F.x, F.y - 2, {});
            U.text(ctx, "count", F.x + 22, F.y + 3, "#505050");
            U.input(ctx, "drop_c" + i, F.x + 52, F.y, 40, 14, Array.isArray(d.count) ? d.count.join("-") : (d.count === undefined ? 1 : d.count), function (v) {
                var m = /^(\d+)\s*-\s*(\d+)$/.exec(v.trim()); d.count = m ? [Number(m[1]), Number(m[2])] : Math.max(0, Number(v) || 0); dirty();
            }, { maxLength: 9 });
            U.text(ctx, "chance %", F.x + 98, F.y + 3, "#505050");
            U.input(ctx, "drop_p" + i, F.x + 146, F.y, 36, 14, Math.round((d.chance === undefined ? 1 : d.chance) * 100), function (v) { d.chance = U.clamp((Number(v) || 0) / 100, 0, 1); dirty(); }, { maxLength: 5 });
            U.button(ctx, "x", F.x + 188, F.y, 16, 14, function () { drops.splice(i, 1); dirty(); U.reset(); }, { tip: "Remove" });
            F.y += 20;
        });
    }

    // ---- AI ----
    function tabAi(ctx, F) {
        F.section("Movement");
        F.choice("Moves", "movement", [{ value: "stand", label: "Stands at home" }, { value: "wander", label: "Wanders around home" }, { value: "path", label: "Follows a path" }], { def: "stand" });
        var mv = E.data.movement || "stand";
        if (mv === "wander") F.num("Wander radius", "wanderRadius", { hint: 8, min: 1, max: 128, unit: "blocks" });
        F.bool("Goes back home", "returnHome", { def: true, tip: "After a fight or being pushed away" });
        F.bool("Looks at players", "lookAtPlayers", { def: true });
        F.label("Facing");
        U.button(ctx, E.data.fixedYaw !== undefined ? "Fixed: " + Math.round(E.data.fixedYaw) + "°" : "Free", F.fx(), F.y, 90, 14, function () {
            if (E.data.fixedYaw !== undefined) delete E.data.fixedYaw; else E.data.fixedYaw = Math.round(((E.yaw - 180) % 360 + 360) % 360);
            dirty();
        }, { tip: ["Fixed: always faces one way (the way", "&7the preview faces when you click)"] });
        U.button(ctx, "Face me", F.fx() + 94, F.y, 70, 14, function () { U.send("face_me", { uuid: E.ent.uuid }); }, { tip: "Turns it toward you and makes that its home facing" });
        F.y += 18;
        F.section("Path");
        var path = E.data.path || [];
        F.note(path.length ? path.length + " waypoint(s): " + path.slice(0, 4).map(function (p) { return p.join(" "); }).join(" > ") + (path.length > 4 ? " ..." : "") : "No path yet.");
        F.buttons([["Record a path", function () { if (E.dirty) save(true); U.send("record", { uuid: E.ent.uuid }); }, { tip: ["Close this, then right-click blocks with the", "&7wand to add waypoints; sneak + right-click", "&7to finish. Replaces the old path."], disabled: !E.world }],
            ["Clear path", function () { delete E.data.path; if (E.data.movement === "path") E.data.movement = "stand"; dirty(); }, { disabled: !path.length }]]);
        F.choice("At the end", "pathMode", [{ value: "loop", label: "Start again (loop)" }, { value: "back", label: "Walk back (back and forth)" }], { def: "loop" });
        F.num("Wait at each point", "pathPause", { hint: 0, int: true, min: 0, max: 1200, unit: "ticks" });
        F.section("Home");
        var hm = E.ent.home;
        F.note(hm ? "Home: " + hm.x + " " + hm.y + " " + hm.z : "Home: where it was placed");
        F.buttons([["Set home where it stands", function () { U.send("set_home", { uuid: E.ent.uuid }); }], ["Bring it here", function () { U.send("summon", { uuid: E.ent.uuid }); U.close(); }],
            ["Go to it", function () { U.send("tp", { uuid: E.ent.uuid }); U.close(); }]]);
    }

    // ---- Faction ----
    function tabFaction(ctx, F) {
        F.section("Faction");
        F.choice("Member of", "faction", opts(LISTS.factions), { search: true });
        F.buttons([["Edit factions...", function () { if (E.dirty) save(true); NPCM_CONTENT.list("faction"); }], ["New faction", function () { if (E.dirty) save(true); NPCM_CONTENT.create("faction"); }]]);
        F.note("Players its faction hates are attacked (see Combat) and turned away; NPCs of factions at war fight.");
        F.bool("Talks to enemies", "talksToEnemies", { tip: "Still talks to players its faction hates" });
        F.text("Refusal line", "hostileLine", { max: 200, hint: "&cGo away!" });
        F.section("Killing it changes faction points");
        var kf = E.data.killFactions || [];
        kf.forEach(function (k, i) {
            U.dropdown(ctx, "kf_f" + i, F.x, F.y, 150, 14, opts(LISTS.factions), k.faction || "", function (v) { k.faction = v; dirty(); }, { search: true });
            U.input(ctx, "kf_p" + i, F.x + 156, F.y, 50, 14, k.points === undefined ? "" : k.points, function (v) { k.points = Number(v) || 0; dirty(); }, { maxLength: 8, hint: "-10" });
            U.button(ctx, "x", F.x + 212, F.y, 16, 14, function () { kf.splice(i, 1); dirty(); U.reset(); });
            F.y += 18;
        });
        F.buttons([["+ Add", function () { (E.data.killFactions = E.data.killFactions || []).push({ faction: E.data.faction || "", points: -10 }); dirty(); U.reset(); }, {}]]);
        F.note("Without entries, its faction's own 'points per kill' applies.");
    }

    // ---- Talk ----
    function tabTalk(ctx, F) {
        F.section("Dialogue");
        F.choice("Default dialogue", "dialogue", opts(LISTS.dialogues), { search: true });
        F.buttons([["Edit it...", function () { if (E.dirty) save(true); if (E.data.dialogue) NPCM_CONTENT.edit("dialogue", E.data.dialogue); else U.status("Pick a dialogue first", "#FF8080"); }],
            ["New dialogue", function () { if (E.dirty) save(true); NPCM_CONTENT.create("dialogue", { speaker: E.data.name, forNpc: E.id }); }]]);
        F.section("More dialogues (highest priority that fits wins)");
        var dl = E.data.dialogues || [];
        dl.forEach(function (d, i) {
            U.dropdown(ctx, "dl_d" + i, F.x, F.y, 140, 14, opts(LISTS.dialogues), d.dialogue || "", function (v) { d.dialogue = v; dirty(); }, { search: true });
            U.input(ctx, "dl_p" + i, F.x + 144, F.y, 30, 14, d.priority === undefined ? 0 : d.priority, function (v) { d.priority = Number(v) || 0; dirty(); }, { maxLength: 5 });
            U.button(ctx, "If (" + (d.requires || []).length + ")", F.x + 178, F.y, 44, 14, function () {
                NPCM_CONTENT.conditions(d.requires || [], function (l) { d.requires = l; dirty(); }, "When does this dialogue open?");
            });
            U.button(ctx, "x", F.x + 226, F.y, 16, 14, function () { dl.splice(i, 1); dirty(); U.reset(); });
            F.y += 18;
        });
        F.buttons([["+ Add dialogue", function () { (E.data.dialogues = E.data.dialogues || []).push({ dialogue: "", priority: 1, requires: [] }); dirty(); U.reset(); }, {}]]);
        F.section("Quests");
        F.note(E.given.length ? "Gives or takes in: " + E.given.join(", ") : "No quests name this NPC yet.");
        F.buttons([["New quest from this NPC", function () { if (E.dirty) save(true); NPCM_CONTENT.create("quest", { giver: E.id, turnIn: E.id }); }]]);
        F.note("Talking to it offers its quests (when no dialogue opens); ! and ? marks show over its head.");
        F.section("Random lines (said when there is nothing else)");
        var lines = E.data.lines || [];
        lines.forEach(function (l, i) {
            U.input(ctx, "line" + i, F.x, F.y, F.w - 22, 14, l, function (v) { lines[i] = v; dirty(); }, { maxLength: 200 });
            U.button(ctx, "x", F.x + F.w - 18, F.y, 16, 14, function () { lines.splice(i, 1); dirty(); U.reset(); });
            F.y += 18;
        });
        if (lines.length < 16) F.buttons([["+ Add line", function () { (E.data.lines = E.data.lines || []).push("Hello, {player}!"); dirty(); U.reset(); }, {}]]);
    }

    // ---- Role ----
    var ROLES = [{ value: "", label: "None" }, { value: "trader", label: "Trader" }, { value: "follower", label: "Follower (for hire)" }, { value: "transporter", label: "Transporter" },
        { value: "bank", label: "Bank" }, { value: "guard", label: "Guard" }, { value: "healer", label: "Healer" }, { value: "itemgiver", label: "Item giver" }, { value: "shop", label: "Shop (money)" }];
    function stackRow(ctx, x, y, stack, set, tip) {
        U.slot(ctx, stack, x, y, { fn: function () { U.held(function (h) { if (h) set({ id: h.id, count: h.count || 1, nbt: h.nbt }); else U.status("Hold the item first", "#FF8080"); }); },
            right: function () { set(null); }, tip: tip || ["Click: the held item", "Right-click: empty"] });
    }
    function tabRole(ctx, F) {
        F.section("Role");
        F.choice("Role", "role", ROLES, { def: "" });
        var role = E.data.role || "";
        if (role === "trader") {
            F.note("Each row: what it sells (left) for up to two items and/or money. A sell price lets players sell that item back. Hold an item and click a slot.");
            var trades = U.get(E.data, "trader.trades") || [];
            trades.forEach(function (t, i) {
                var yy = F.y;
                stackRow(ctx, F.x, yy, t.item, function (s) { t.item = s; dirty(); }, ["Sells", "Click: the held item (its count too)"]);
                U.text(ctx, "for", F.x + 22, yy + 5, "#505050");
                [0, 1].forEach(function (k) {
                    stackRow(ctx, F.x + 40 + k * 20, yy, (t.cost || [])[k], function (s) { t.cost = t.cost || []; if (s) t.cost[k] = s; else t.cost.splice(k, 1); dirty(); }, ["Costs (item " + (k + 1) + ")"]);
                });
                U.text(ctx, "$", F.x + 84, yy + 5, "#505050");
                U.input(ctx, "tr_m" + i, F.x + 92, yy + 2, 40, 14, t.money || "", function (v) { t.money = Math.max(0, Number(v) || 0); dirty(); }, { maxLength: 9, hint: "0" });
                U.text(ctx, "sell", F.x + 136, yy + 5, "#505050");
                U.input(ctx, "tr_s" + i, F.x + 158, yy + 2, 34, 14, t.sell || "", function (v) { t.sell = Math.max(0, Number(v) || 0); dirty(); }, { maxLength: 9, hint: "-" });
                U.text(ctx, "stock", F.x + 196, yy + 5, "#505050");
                U.input(ctx, "tr_k" + i, F.x + 224, yy + 2, 30, 14, t.stock || "", function (v) { t.stock = Math.max(0, Math.round(Number(v) || 0)); dirty(); }, { maxLength: 6, hint: "inf" });
                U.button(ctx, "x", F.x + 258, yy + 2, 16, 14, function () { trades.splice(i, 1); dirty(); U.reset(); });
                F.y += 22;
            });
            if (trades.length < 27) F.buttons([["+ Add trade", function () { U.set(E.data, "trader.trades", trades.concat([{ cost: [], money: 10 }])); dirty(); U.reset(); }, {}]]);
            F.num("Restock every", "trader.restock", { hint: 0, min: 0, unit: "minutes (0 = never)" });
        } else if (role === "follower") {
            F.num("Price", "follower.money", { hint: 0, min: 0, unit: "money" });
            F.label("Also costs");
            stackRow(ctx, F.fx(), F.y - 2, U.get(E.data, "follower.item"), function (s) { U.set(E.data, "follower.item", s || undefined); dirty(); });
            F.y += 20;
            F.num("Follows for", "follower.minutes", { hint: 0, min: 0, unit: "minutes (0 = until dismissed)" });
            F.text("Greeting", "follower.greeting", { max: 200, hint: "Lead the way!" });
            F.note("Hired followers follow their owner, fight what attacks them, and can be told to stay or go.");
        } else if (role === "transporter") {
            F.text("Location name", "transporter.name", { max: 48, hint: E.data.name || "Village" });
            F.text("Network", "transporter.group", { max: 48, hint: "(default)", tip: "Transporters of one network connect to each other" });
            F.num("Travel price", "transporter.cost", { hint: 0, min: 0, tip: "Paid to come HERE" });
            F.bool("Known from the start", "transporter.unlocked", { tip: "Otherwise players must visit it first" });
        } else if (role === "bank") {
            F.num("Rows", "bank.rows", { hint: 3, int: true, min: 1, max: 6 });
            F.num("Fee per visit", "bank.cost", { hint: 0, min: 0 });
            F.text("Shared vault", "bank.shared", { max: 48, hint: "(this NPC only)", tip: "Banks with the same name share each player's vault" });
        } else if (role === "guard") {
            F.num("Guards within", "guard.radius", { hint: 16, min: 2, max: 64, unit: "blocks of home" });
            F.note("Attacks monsters, enemies of its faction and hostile players near its home. Set its damage in Combat.");
        } else if (role === "healer") {
            F.num("Heals within", "healer.radius", { hint: 6, min: 1, max: 32, unit: "blocks" });
            F.num("Health per 2 s", "healer.amount", { hint: 2, min: 0 });
            F.note("Heals players nearby every 2 seconds (not ones its faction hates).");
        } else if (role === "itemgiver") {
            F.choice("Gives", "itemgiver.mode", [{ value: "once", label: "Once per player" }, { value: "daily", label: "Once a day" }, { value: "always", label: "Every time (with a cooldown)" }], { def: "once" });
            if (U.get(E.data, "itemgiver.mode") === "always") F.num("Cooldown", "itemgiver.cooldown", { hint: 0, min: 0, unit: "minutes" });
            F.label("Items");
            var gi = U.get(E.data, "itemgiver.items") || [];
            for (var k = 0; k < 9; k++) (function (k) {
                stackRow(ctx, F.fx() + k * 20, F.y - 2, gi[k], function (s) { var l = (U.get(E.data, "itemgiver.items") || []).slice(); if (s) l[k] = s; else l.splice(k, 1); U.set(E.data, "itemgiver.items", l.filter(function (x) { return x; })); dirty(); });
            })(k);
            F.y += 22;
            F.text("Message", "itemgiver.message", { max: 200, hint: "Take these, traveller." });
            F.text("Already given", "itemgiver.already", { max: 200, hint: "I have nothing more for you." });
        } else if (role === "shop") {
            F.choice("Shop", "shop", opts(LISTS.shops), { search: true });
            F.buttons([["Edit shop...", function () { if (E.dirty) save(true); if (E.data.shop) NPCM_CONTENT.edit("shop", E.data.shop); }], ["New shop", function () { if (E.dirty) save(true); NPCM_CONTENT.create("shop"); }]]);
        } else F.note("A role adds a screen (trader, transporter, bank, follower) or a job (guard, item giver). With a dialogue, add the \"Open role screen\" action to an option.");
    }

    // ---- Copies: presets, clones, spawning, removal ----
    function tabCopies(ctx, F) {
        F.section("This one NPC");
        F.num("Own size", "_ownScale", { hint: E.ent.scale || 1, min: 0, max: 64, tip: "Only this copy (0 = the definition's size)" });
        F.buttons([["Apply size", function () { U.send("set_scale", { uuid: E.ent.uuid, scale: E.data._ownScale || 0 }); delete E.data._ownScale; }], ["Remove it", function () { removeThis(); }, { color: "#FF9090" }]]);
        F.section("Copies");
        F.buttons([["Linked copy here", function () { U.send("clone", { uuid: E.ent.uuid, linked: true }); }, { tip: "Shares this definition: edit one, all change" }],
            ["Independent copy here", function () { if (E.dirty) save(true); U.send("clone", { uuid: E.ent.uuid, linked: false }); }, { tip: "A new NPC you can change on its own" }]]);
        F.buttons([["Save in the cloner...", function () { if (E.dirty) save(true); RPG.net.send("npcm_clone", { op: "refresh", uuid: E.ent.uuid, tab: 1 }); }, { tip: ["Server tabs (this world) or client tabs", "&7(your computer: any world or server)"] }]]);
        F.note("Or right-click this NPC with the NPC Cloner.");
        F.section("Preset (a file other worlds can use)");
        F.label("Preset name");
        U.input(ctx, "preset_name", F.fx(), F.y, F.fw() - 78, 14, E.presetName, function (v) { E.presetName = v; }, { maxLength: 48, hint: E.id });
        U.button(ctx, "Save preset", F.fx() + F.fw() - 74, F.y, 74, 14, function () { if (E.dirty) save(true); U.send("preset_save", { id: E.id, name: E.presetName || E.id }); });
        F.y += 18;
        F.note("Saved in the game folder: ragnarok_rpg/shared/npc_presets/. Copy those files to share NPCs; place them from the hub's Presets tab.");
        F.section("Spawning");
        var sp = E.spawn;
        F.label("Spawn rule");
        U.toggle(ctx, sp.enabled !== undefined, F.fx(), F.y + 1, function () {
            if (sp.enabled !== undefined) E.spawn = {}; else E.spawn = { enabled: true, interval: 600, chance: 0.5, group: 1, maxNearby: 3, placement: "surface", time: "any", light: "any", minDistance: 16, maxDistance: 48 };
            E.spawnChanged = true; dirty(); U.reset();
        }, "Spawn more of this NPC naturally near players");
        F.y += 16;
        if (E.spawn.enabled !== undefined) {
            var G = U.form(ctx, F.x, F.y, F.w, F.lw, E.spawn, function () { E.spawnChanged = true; dirty(); });
            G.bool("Enabled", "enabled", { def: true });
            G.num("Try every", "interval", { int: true, min: 20, unit: "ticks" });
            G.num("Chance", "chance", { percent: true, min: 0, max: 1, unit: "%" });
            G.num("Group size", "group", { int: true, min: 1, max: 16 });
            G.num("At most nearby", "maxNearby", { int: true, min: 1, max: 64 });
            G.num("Min distance", "minDistance", { min: 0, max: 128 });
            G.num("Max distance", "maxDistance", { min: 4, max: 256 });
            G.choice("Time", "time", [{ value: "any", label: "Any time" }, { value: "day", label: "Day" }, { value: "night", label: "Night" }]);
            G.choice("Light", "light", [{ value: "any", label: "Any" }, { value: "dark", label: "Dark" }, { value: "bright", label: "Bright" }]);
            G.bool("Stays when players leave", "persistent", { tip: ["Off: spawned copies go away like mobs once", "&7no player is within 128 blocks"] });
            G.label("Dimension");
            var dims = [{ value: "", label: "(any)" }, { value: "minecraft:overworld", label: "Overworld" }, { value: "minecraft:the_nether", label: "The Nether" }, { value: "minecraft:the_end", label: "The End" }];
            U.dropdown(ctx, "sp_dim", G.fx(), G.y, G.fw(), 14, dims, (E.spawn.dimensions && E.spawn.dimensions[0]) || "", function (v) {
                if (v) E.spawn.dimensions = [String(v)]; else delete E.spawn.dimensions;
                E.spawnChanged = true; dirty();
            }, { search: true, custom: true, customLabel: "Dimension: " });
            G.y += 18;
            F.y = G.y;
        }
        F.section("Delete");
        F.buttons([["Delete this NPC everywhere", function () { confirmDelete("npc", { id: E.id, name: E.data.name || E.id }); }, { color: "#FF9090", disabled: !E.world }]]);
    }

    function editorOpen() { return !!E; }
    return { openHub: openHub, lists: function () { return LISTS; }, setLists: function (l) { LISTS = l; }, opts: opts, confirm: confirm, confirmDelete: confirmDelete, drawConfirm: drawConfirm, confirmMouse: confirmMouse, editorOpen: editorOpen };
})();
