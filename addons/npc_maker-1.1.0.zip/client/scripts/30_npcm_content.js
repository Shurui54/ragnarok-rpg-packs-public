// =====================================================================================
//  NPC Maker (client) - editors for factions, dialogues, quests and shops
// =====================================================================================
//  Each is one screen over a working copy; Save sends it whole and the server cleans it,
//  saves it with the world and applies it at once (no reload). Dialogue options and NPC
//  dialogue lists use the shared condition / action pickers at the bottom of this file.
// =====================================================================================
var NPCM_CONTENT = (function () {
    var U = NPCM_UI;
    var C = null;          // the open content editor
    var PICK = null;       // the condition / action popup
    function L() { return NPCM_EDITOR.lists(); }
    function opts(list, none) { return NPCM_EDITOR.opts(list, none); }
    function dirty() { if (C) C.dirty = true; }
    function kindName(k) { return { faction: "Faction", dialogue: "Dialogue", quest: "Quest", shop: "Shop" }[k] || k; }

    U.onBig("kind", function (d) {
        if (d.lists) NPCM_EDITOR.setLists(d.lists);
        C = { kind: d.kind, id: d.id, world: d.world || !d.data, data: d.data || defaults(d.kind, C && C.pendingDefaults), isNew: !d.data, dirty: !d.data, choices: d.choices || {}, node: null, idText: d.id };
        if (C.kind === "dialogue") { if (!C.data.nodes || !Object.keys(C.data.nodes).length) C.data.nodes = { start: { text: "Hello!", options: [{ text: "Goodbye" }] } }; C.node = C.data.start || Object.keys(C.data.nodes)[0]; }
        openC();
    });
    var pendingDefaults = null;
    function defaults(kind) {
        var p = pendingDefaults || {};
        pendingDefaults = null;
        switch (kind) {
            case "faction": return { name: "New Faction", color: "#55FF55", defaultPoints: 0, friendlyAt: 100, hostileBelow: -100, min: -1000, max: 1000, relations: {} };
            case "dialogue": return { speaker: p.speaker || "", start: "start", nodes: { start: { text: "Hello, {player}!", options: [{ text: "Goodbye" }] } } };
            case "quest": return { name: "New Quest", description: "", category: "", giver: p.giver || "", turnIn: p.turnIn || "", objectives: [{ type: "kill", target: "minecraft:zombie", count: 5 }], rewards: { xp: 50 } };
            case "shop": return { name: "New Shop", items: [] };
        }
        return {};
    }
    function openC() {
        U.open({ draw: draw, back: back, onMouse: mouse, drawTop: drawTop, onClose: function () { C = null; PICK = null; } });
        U.reset();
    }
    function back() { if (PICK) { PICK = null; U.reset(); return; } U.send("hub"); }

    // ---- public: open things ----
    var freeWait = {};
    RPG.net.on("npcm_free_id", function (d) { var f = d && freeWait[d.req]; if (f) { delete freeWait[d.req]; f(d.id); } });
    function create(kind, defs) {
        pendingDefaults = defs || null;
        var req = "c" + Math.floor(RPG.nowMs());
        var name = { faction: "faction", dialogue: (defs && defs.forNpc ? defs.forNpc + "_talk" : "dialogue"), quest: "quest", shop: "shop" }[kind] || kind;
        freeWait[req] = function (id) { U.send("get_kind", { kind: kind, id: id }); };
        U.send("free_id", { kind: kind, name: name, req: req });
    }
    function edit(kind, id) { U.send("get_kind", { kind: kind, id: id }); }
    function list(kind) { U.send("hub"); }
    function onSaved(d) {
        if (!C || d.kind !== C.kind) return;
        if (d.deleted && d.id === C.id) { U.send("hub"); return; }
        if (d.id === C.id) { C.dirty = false; C.isNew = false; C.world = true; }
    }
    function save() {
        if (!C || !C.world) return;
        U.sendBig("save_kind", { kind: C.kind, id: C.id, data: C.data });
        U.status("Saving...", "#FFFF80");
    }

    // ---- frame ----
    function draw(ctx, S) {
        if (!C) return;
        if (PICK) { drawPick(ctx); return; }
        var w = Math.min(470, ctx.width - 10), h = Math.min(300, ctx.height - 10), x = Math.round((ctx.width - w) / 2), y = Math.round((ctx.height - h) / 2);
        U.panel(ctx, x, y, w, h, kindName(C.kind) + ": " + U.strip(C.data.name || C.id) + (C.world ? "" : "  (script: read only)"));
        U.text(ctx, "id: " + C.id, x + w - 8, y + 7, "#707070", "right");
        U.button(ctx, "Hub", x + 6, y + h - 24, 60, 18, function () { if (C.dirty && C.world && !C.isNew) save(); U.send("hub"); });
        if (C.world) U.button(ctx, C.dirty ? "Save *" : "Save", x + w - 76, y + h - 24, 70, 18, save, { color: C.dirty ? "#FFFF80" : null });
        if (C.world && !C.isNew) U.button(ctx, "Delete", x + w - 150, y + h - 24, 70, 18, function () { NPCM_EDITOR.confirmDelete(C.kind, { id: C.id, name: C.data.name || C.id }); S.drawTop = function (c2, s2) { NPCM_EDITOR.drawConfirm(c2, s2); }; }, { color: "#FF9090" });
        var area = { x: x + 8, y: y + 20, w: w - 22, h: h - 48 };
        if (C.kind === "dialogue") return drawDialogue(ctx, area);
        U.scrollArea(ctx, "c_" + C.kind, area.x, area.y, area.w, area.h, function (y0) {
            var F = U.form(ctx, area.x, y0, area.w - 6, 110, C.data, dirty);
            ({ faction: drawFaction, quest: drawQuest, shop: drawShop })[C.kind](ctx, F);
            return F.y - y0 + 6;
        });
    }
    function drawTop(ctx, S) { }
    function mouse(x, y, b, action) {
        var S = U.state();
        if (S && S.confirm) return NPCM_EDITOR.confirmMouse(x, y, b, action);
        return false;
    }

    // =================================================================================
    //  Faction
    // =================================================================================
    var COLORS = [["#FFFFFF", "White"], ["#AAAAAA", "Grey"], ["#FF5555", "Red"], ["#AA0000", "Dark red"], ["#FFAA00", "Gold"], ["#FFFF55", "Yellow"], ["#55FF55", "Green"], ["#00AA00", "Dark green"],
        ["#55FFFF", "Aqua"], ["#00AAAA", "Teal"], ["#5555FF", "Blue"], ["#0000AA", "Dark blue"], ["#FF55FF", "Pink"], ["#AA00AA", "Purple"]];
    function drawFaction(ctx, F) {
        F.section("Faction");
        F.text("Name", "name", { max: 48 });
        F.label("Colour");
        // a swatch that opens the engine's colour picker (the usual faction colours as presets)
        var fx = F.fx(), fy = F.y, fw = Math.min(F.fw(), 120), cur = /^#[0-9A-Fa-f]{6}$/.test(String(C.data.color || "")) ? String(C.data.color).toUpperCase() : "#FFFFFF";
        var hov = U.over(ctx, fx, fy, fw, 14);
        ctx.fill(fx, fy, 14, 14, hov ? "#FFFFFF" : "#A0A0A0", 1);
        ctx.fill(fx + 1, fy + 1, 12, 12, cur, 1);
        U.dark(ctx, fx + 17, fy, fw - 17, 14);
        var named = COLORS.filter(function (c) { return c[0] === cur; })[0];
        U.text(ctx, named ? named[1] + "  &8" + cur : cur, fx + 20, fy + 3, "#FFFFFF");
        U.hit(fx, fy, fw, 14, function () {
            RPG.screen.pickColor({ x: fx, y: fy, w: fw, h: 14, value: cur, presets: COLORS.map(function (c) { return c[0]; }) },
                function (v) { C.data.color = String(v).toUpperCase(); dirty(); });
        }, "Click to pick a colour");
        F.y += 18;
        F.text("Description", "description", { max: 300 });
        F.bool("Hidden", "hidden", { tip: "Not listed in the players' factions screen" });
        F.section("Player points");
        F.num("Starting points", "defaultPoints", { hint: 0 });
        F.num("Friendly at", "friendlyAt", { hint: 100, tip: "From this many points the faction is friendly" });
        F.num("Hostile below", "hostileBelow", { hint: -100, tip: "Below this its NPCs attack and won't talk" });
        F.num("Lowest", "min", { hint: -1000 });
        F.num("Highest", "max", { hint: 1000 });
        F.num("Points per kill", "killPoints", { hint: 0, tip: "Change when a player kills one of its members (an NPC can override)" });
        F.section("Relations with other factions");
        var rel = C.data.relations || (C.data.relations = {});
        L().factions.filter(function (f) { return f.id !== C.id; }).forEach(function (f) {
            F.label(U.strip(f.name));
            var cur = rel[f.id] || "neutral";
            ["friendly", "neutral", "hostile"].forEach(function (r, i) {
                U.button(ctx, r, F.fx() + i * 62, F.y, 60, 14, function () { if (r === "neutral") delete rel[f.id]; else rel[f.id] = r; dirty(); },
                    { selected: cur === r, color: cur === r ? ({ friendly: "#80FF80", neutral: "#FFFF80", hostile: "#FF8080" })[r] : null });
            });
            F.y += 18;
        });
        if (L().factions.length <= 1) F.note("Make more factions to set how they get along. Hostile factions' NPCs fight each other.");
    }

    // =================================================================================
    //  Shop (money, the engine's shop screen)
    // =================================================================================
    function drawShop(ctx, F) {
        F.section("Shop");
        F.text("Name", "name", { max: 64 });
        F.note("Hold an item and press + to add it. Buy = what the player pays; Sell = what the shop pays (empty = not that way).");
        var items = C.data.items || (C.data.items = []);
        items.forEach(function (it, i) {
            U.slot(ctx, { id: it.item, count: it.count }, F.x, F.y - 2, {});
            U.text(ctx, U.fit(ctx, U.itemName(it.item), 90), F.x + 22, F.y + 3, "#303030");
            U.text(ctx, "x", F.x + 116, F.y + 3, "#505050");
            U.input(ctx, "sh_c" + i, F.x + 124, F.y, 28, 14, it.count || 1, function (v) { it.count = Math.max(1, Math.round(Number(v) || 1)); dirty(); }, { maxLength: 4 });
            U.text(ctx, "buy", F.x + 156, F.y + 3, "#505050");
            U.input(ctx, "sh_b" + i, F.x + 176, F.y, 44, 14, it.buy || "", function (v) { it.buy = Math.max(0, Number(v) || 0); dirty(); }, { maxLength: 9 });
            U.text(ctx, "sell", F.x + 224, F.y + 3, "#505050");
            U.input(ctx, "sh_s" + i, F.x + 246, F.y, 44, 14, it.sell || "", function (v) { it.sell = Math.max(0, Number(v) || 0); dirty(); }, { maxLength: 9 });
            U.text(ctx, "lvl", F.x + 294, F.y + 3, "#505050");
            U.input(ctx, "sh_l" + i, F.x + 310, F.y, 28, 14, it.levelReq || "", function (v) { it.levelReq = Math.max(0, Math.round(Number(v) || 0)); dirty(); }, { maxLength: 6 });
            U.button(ctx, "x", F.x + 342, F.y, 16, 14, function () { items.splice(i, 1); dirty(); U.reset(); });
            F.y += 20;
        });
        F.buttons([["+ Held item", function () { U.held(function (h) { if (!h) { U.status("Hold the item first", "#FF8080"); return; } items.push({ item: h.id, count: h.count || 1, buy: 10, sell: 0 }); dirty(); U.reset(); }); }, {}]]);
    }

    // =================================================================================
    //  Quest
    // =================================================================================
    var OBJ_TYPES = [{ value: "kill", label: "Kill" }, { value: "collect", label: "Collect / hand in items" }, { value: "talk", label: "Talk to an NPC" },
        { value: "location", label: "Go to a place" }, { value: "level", label: "Reach a level" }, { value: "custom", label: "Script / manual" }];
    function targetChoices() {
        var o = [{ value: "*", label: "Anything" }];
        L().npcs.forEach(function (n) { o.push({ value: n.id, label: "NPC: " + U.strip(n.name) }); });
        (C.choices.living || []).forEach(function (id) { o.push({ value: id, label: U.entityName(id) + "  [" + id + "]" }); });
        return o;
    }
    function itemChoices() { var l = U.items(); return (l || []).map(function (id) { return { value: id, label: U.itemName(id) + "  [" + id + "]", icon: id }; }); }
    function drawQuest(ctx, F) {
        F.section("Quest");
        F.text("Name", "name", { max: 64 });
        F.text("Description", "description", { max: 800, hint: "shown when offered and in the quest log" });
        F.text("Category", "category", { max: 48, hint: "Main story, Side quests..." });
        F.choice("Given by", "giver", opts(L().npcs, "(nobody: started by dialogue or script)"), { search: true, tip: "Talking to this NPC offers the quest; a ! shows over its head" });
        F.choice("Hand in to", "turnIn", opts(L().npcs, "(finishes by itself)"), { search: true, tip: "A ? shows over this NPC when it is done" });
        F.text("Accept button", "acceptText", { max: 64, hint: "Accept" });
        F.section("Objectives");
        var objs = C.data.objectives || (C.data.objectives = []);
        objs.forEach(function (o, i) {
            var G = U.form(ctx, F.x, F.y, F.w, F.lw, o, dirty);
            G.label((i + 1) + ".");
            U.dropdown(ctx, "ob_t" + i, G.fx(), G.y, 150, 14, OBJ_TYPES, o.type || "kill", function (v) { o.type = v; dirty(); U.reset(); });
            U.button(ctx, "x", G.fx() + 154, G.y, 16, 14, function () { objs.splice(i, 1); dirty(); U.reset(); }, { tip: "Remove" });
            G.y += 18;
            G.lw = F.lw; G.x = F.x + 10; G.w = F.w - 10;
            switch (o.type) {
                case "kill": G.choice("Target", "target", targetChoices(), { search: true, custom: true, key: "ob" + i, listWidth: 260 }); G.num("How many", "count", { int: true, min: 1, hint: 1, key: "ob" + i }); break;
                case "collect":
                    G.choice("Item", "item", itemChoices(), { search: true, custom: true, key: "ob" + i, listWidth: 260 });
                    G.num("How many", "count", { int: true, min: 1, hint: 1, key: "ob" + i });
                    G.bool("Taken on hand-in", "consume"); break;
                case "talk": G.choice("NPC", "npc", opts(L().npcs, "(pick)"), { search: true, key: "ob" + i }); break;
                case "location":
                    G.num("X", "x", { key: "ob" + i }); G.num("Y", "y", { key: "ob" + i }); G.num("Z", "z", { key: "ob" + i }); G.num("Radius", "radius", { hint: 5, key: "ob" + i });
                    G.text("Dimension", "dimension", { hint: "(any)", key: "ob" + i, max: 96 }); break;
                case "level": G.num("Level", "level", { int: true, min: 1, key: "ob" + i }); break;
                case "custom": G.text("Key", "key", { key: "ob" + i, hint: "scripts call player.progressQuest(key)" }); G.num("Count", "count", { int: true, min: 1, hint: 1, key: "ob" + i }); break;
            }
            G.text("Shown as", "description", { key: "ob" + i, max: 160, hint: "(automatic)" });
            F.y = G.y + 4;
        });
        if (objs.length < 12) F.buttons([["+ Objective", function () { objs.push({ type: "kill", target: "*", count: 1 }); dirty(); U.reset(); }, {}],
            ["Here as location", function () { objs.push({ type: "location", x: Math.floor(RPG.player.getX()), y: Math.floor(RPG.player.getY()), z: Math.floor(RPG.player.getZ()), radius: 5, dimension: RPG.player.getDimension() }); dirty(); U.reset(); }, { tip: "A 'go here' objective at your position" }]]);
        F.section("Requirements");
        F.num("Level", "requires.level", { int: true, min: 0, hint: 0 });
        var pre = (C.data.requires && C.data.requires.quests) || [];
        F.label("After quests");
        U.dropdown(ctx, "q_pre", F.fx(), F.y, 160, 14, opts(L().quests.filter(function (q) { return q.id !== C.id && pre.indexOf(q.id) < 0; }), "+ add..."), "", function (v) { if (v) { U.set(C.data, "requires.quests", pre.concat([v])); dirty(); U.reset(); } }, { search: true });
        F.y += 18;
        pre.forEach(function (q, i) { U.text(ctx, "- " + q, F.fx(), F.y + 3, "#303030"); U.button(ctx, "x", F.fx() + 150, F.y, 16, 14, function () { pre.splice(i, 1); dirty(); U.reset(); }); F.y += 16; });
        var rf = (C.data.requires && C.data.requires.factions) || {};
        F.label("Faction points");
        U.dropdown(ctx, "q_rf", F.fx(), F.y, 160, 14, opts(L().factions.filter(function (f) { return rf[f.id] === undefined; }), "+ add..."), "", function (v) { if (v) { rf[v] = 100; U.set(C.data, "requires.factions", rf); dirty(); U.reset(); } }, { search: true });
        F.y += 18;
        Object.keys(rf).forEach(function (fid) {
            U.text(ctx, fid + " at least", F.fx(), F.y + 3, "#303030");
            U.input(ctx, "q_rfv_" + fid, F.fx() + 100, F.y, 46, 14, rf[fid], function (v) { rf[fid] = Number(v) || 0; dirty(); }, { maxLength: 8 });
            U.button(ctx, "x", F.fx() + 150, F.y, 16, 14, function () { delete rf[fid]; dirty(); U.reset(); });
            F.y += 18;
        });
        F.label("Other conditions");
        U.button(ctx, "Edit (" + ((C.data.requires && C.data.requires.conditions) || []).length + ")", F.fx(), F.y, 80, 14, function () {
            conditions((C.data.requires && C.data.requires.conditions) || [], function (l) { U.set(C.data, "requires.conditions", l.length ? l : undefined); dirty(); }, "Who can start this quest?");
        });
        F.y += 18;
        F.section("Repeat");
        F.bool("Repeatable", "repeatable");
        if (C.data.repeatable) F.num("Wait between", "repeatDelay", { min: 0, hint: 0, unit: "seconds (86400 = daily)" });
        F.bool("Can be abandoned", "abandonable", { def: true });
        F.section("Rewards");
        F.num("XP", "rewards.xp", { min: 0, hint: 0 });
        F.num("Money", "rewards.money", { min: 0, hint: 0 });
        F.label("Items");
        var acts = U.get(C.data, "rewards.actions") || [];
        var gives = acts.filter(function (a) { return a.type === "give"; });
        gives.forEach(function (g, i) { U.slot(ctx, { id: g.id || g.item, count: g.count }, F.fx() + i * 20, F.y - 2, { right: function () { acts.splice(acts.indexOf(g), 1); U.set(C.data, "rewards.actions", acts.length ? acts : undefined); dirty(); }, tip: [U.itemName(g.id || g.item), "&7Right-click: remove"] }); });
        U.button(ctx, "+ Held", F.fx() + gives.length * 20 + 2, F.y, 50, 14, function () {
            U.held(function (h) { if (!h) { U.status("Hold the item first", "#FF8080"); return; } acts.push({ type: "give", id: h.id, count: h.count || 1, nbt: h.nbt }); U.set(C.data, "rewards.actions", acts); dirty(); });
        });
        F.y += 22;
        var fr = U.get(C.data, "rewards.factions") || {};
        F.label("Faction points");
        U.dropdown(ctx, "q_fr", F.fx(), F.y, 160, 14, opts(L().factions.filter(function (f) { return fr[f.id] === undefined; }), "+ add..."), "", function (v) { if (v) { fr[v] = 10; U.set(C.data, "rewards.factions", fr); dirty(); U.reset(); } }, { search: true });
        F.y += 18;
        Object.keys(fr).forEach(function (fid) {
            U.text(ctx, fid, F.fx(), F.y + 3, "#303030");
            U.input(ctx, "q_frv_" + fid, F.fx() + 100, F.y, 46, 14, fr[fid], function (v) { fr[fid] = Number(v) || 0; dirty(); }, { maxLength: 8 });
            U.button(ctx, "x", F.fx() + 150, F.y, 16, 14, function () { delete fr[fid]; dirty(); U.reset(); });
            F.y += 18;
        });
        F.label("More actions");
        U.button(ctx, "Edit (" + acts.filter(function (a) { return a.type !== "give"; }).length + ")", F.fx(), F.y, 80, 14, function () {
            actions(acts.filter(function (a) { return a.type !== "give"; }), function (l) { var all = gives.concat(l); U.set(C.data, "rewards.actions", all.length ? all : undefined); dirty(); }, "Also when it is done");
        });
        F.y += 18;
        F.label("Then start");
        U.dropdown(ctx, "q_next", F.fx(), F.y, 160, 14, opts(L().quests.filter(function (q) { return q.id !== C.id; }), "(nothing)"), (C.data.next || [])[0] || "", function (v) { C.data.next = v ? [v] : undefined; if (!v) delete C.data.next; dirty(); }, { search: true });
        F.y += 18;
    }

    // =================================================================================
    //  Dialogue: nodes on the left, the selected node on the right
    // =================================================================================
    function nodeIds() { return Object.keys(C.data.nodes || {}); }
    function drawDialogue(ctx, a) {
        var nodes = C.data.nodes || (C.data.nodes = {}), ids = nodeIds();
        if (!nodes[C.node]) C.node = ids[0];
        // node list
        var lw = 110;
        U.text(ctx, "Nodes", a.x, a.y + 2, "#303030");
        U.dark(ctx, a.x, a.y + 12, lw, a.h - 52);
        U.list(ctx, "dnodes", a.x + 1, a.y + 13, lw - 6, a.h - 54, ids, 14, function (id, i, ry) {
            var sel = id === C.node;
            if (sel) ctx.fill(a.x + 1, ry, lw - 6, 14, "#FFFFFF", 0.2);
            U.text(ctx, U.fit(ctx, (C.data.start === id ? "> " : "") + id, lw - 10), a.x + 4, ry + 3, sel ? "#FFFFA0" : "#E0E0E0", "left", true);
            U.hit(a.x + 1, ry, lw - 6, 14, function () { C.node = id; U.reset(); }, (nodes[id].text || "").substring(0, 60));
        });
        U.button(ctx, "+ Node", a.x, a.y + a.h - 38, 54, 16, function () {
            var n = 1; while (nodes["node" + n]) n++;
            nodes["node" + n] = { text: "...", options: [{ text: "Goodbye" }] }; C.node = "node" + n; dirty(); U.reset();
        });
        U.button(ctx, "Delete", a.x + 56, a.y + a.h - 38, 54, 16, function () { if (ids.length > 1) { delete nodes[C.node]; if (C.data.start === C.node) C.data.start = nodeIds()[0]; C.node = nodeIds()[0]; dirty(); U.reset(); } }, { disabled: ids.length <= 1 });
        U.button(ctx, "Make start", a.x, a.y + a.h - 20, 110, 16, function () { C.data.start = C.node; dirty(); }, { disabled: C.data.start === C.node, tip: "The node the dialogue opens on" });
        // the node
        var x = a.x + lw + 8, w = a.w - lw - 8;
        U.scrollArea(ctx, "dnode_" + C.node, x, a.y, w, a.h, function (y0) {
            var n = nodes[C.node];
            var top = U.form(ctx, x, y0, w - 6, 80, C.data, dirty);
            top.text("Speaker", "speaker", { max: 64, hint: "(the NPC's name)" });
            top.text("Node id", "_rename", { key: "rn_" + C.node, max: 32, hint: C.node, tip: "Type a new id to rename this node" });
            if (C.data._rename && C.data._rename !== C.node && /^[a-z0-9_\-]{1,32}$/.test(C.data._rename) && !nodes[C.data._rename]) {
                U.button(ctx, "Rename", top.fx(), top.y, 60, 14, function () { rename(C.node, C.data._rename); });
                top.y += 18;
            }
            var F = U.form(ctx, x, top.y, w - 6, 80, n, dirty);
            F.text("Text", "text", { key: "nt_" + C.node, max: 1200, hint: "What the NPC says ({player} = name)" });
            F.note("Tip: type \\n for a new line. Options without a next node close the dialogue.");
            F.section("Options");
            var op = n.options || (n.options = []);
            op.forEach(function (o, i) {
                var k = C.node + "_" + i;
                U.input(ctx, "o_t_" + k, F.x, F.y, F.w - 22, 14, o.text, function (v) { o.text = v; dirty(); }, { maxLength: 200, hint: "Option text" });
                U.button(ctx, "x", F.x + F.w - 18, F.y, 16, 14, function () { op.splice(i, 1); dirty(); U.reset(); });
                F.y += 17;
                U.text(ctx, "goes to", F.x + 6, F.y + 3, "#505050");
                U.dropdown(ctx, "o_n_" + k, F.x + 46, F.y, 90, 14, [{ value: "", label: "(close)" }].concat(nodeIds().map(function (id) { return { value: id, label: id }; })), o.next || "", function (v) { if (v) o.next = v; else delete o.next; dirty(); });
                U.button(ctx, "If (" + (o.requires || []).length + ")", F.x + 140, F.y, 40, 14, function () {
                    conditions(o.requires || [], function (l) { if (l.length) o.requires = l; else delete o.requires; dirty(); }, "Show this option only if...");
                }, { tip: (o.requires || []).length ? ["Conditions"].concat((o.requires || []).map(condText)) : "Always shown" });
                U.button(ctx, "Do (" + (o["do"] || []).length + ")", F.x + 184, F.y, 44, 14, function () {
                    actions(o["do"] || [], function (l) { if (l.length) o["do"] = l; else delete o["do"]; dirty(); }, "When picked...");
                }, { tip: (o["do"] || []).length ? ["Actions"].concat((o["do"] || []).map(actText)) : "Does nothing else" });
                if (i > 0) U.button(ctx, "^", F.x + 232, F.y, 14, 14, function () { var t = op[i - 1]; op[i - 1] = o; op[i] = t; dirty(); U.reset(); }, { tip: "Move up" });
                F.y += 20;
            });
            if (op.length < 12) F.buttons([["+ Option", function () { op.push({ text: "..." }); dirty(); U.reset(); }, {}], ["+ Option to new node", function () {
                var nn = 1; while (nodes["node" + nn]) nn++;
                nodes["node" + nn] = { text: "...", options: [{ text: "Goodbye" }] };
                op.push({ text: "Tell me more", next: "node" + nn }); dirty(); U.reset();
            }, {}]]);
            return F.y - y0 + 6;
        });
    }
    function rename(from, to) {
        var nodes = C.data.nodes;
        nodes[to] = nodes[from]; delete nodes[from];
        Object.keys(nodes).forEach(function (k) { (nodes[k].options || []).forEach(function (o) { if (o.next === from) o.next = to; }); });
        if (C.data.start === from) C.data.start = to;
        C.node = to; delete C.data._rename; dirty(); U.reset();
    }

    // =================================================================================
    //  Condition / action pickers (a popup list over any editor)
    // =================================================================================
    var COND_TYPES = [{ value: "quest", label: "Quest state" }, { value: "faction", label: "Faction standing" }, { value: "item", label: "Has items" }, { value: "level", label: "Level" },
        { value: "money", label: "Money" }, { value: "flag", label: "Flag (player var)" }, { value: "time", label: "Time of day" }, { value: "class", label: "Class" }, { value: "race", label: "Race" }, { value: "permission", label: "Permission" }];
    var ACT_TYPES = [{ value: "give", label: "Give item (held)" }, { value: "take", label: "Take items" }, { value: "money", label: "Money +/-" }, { value: "xp", label: "XP" },
        { value: "startQuest", label: "Start quest" }, { value: "completeQuest", label: "Complete quest" }, { value: "abandonQuest", label: "Drop quest" }, { value: "faction", label: "Faction points" },
        { value: "flag", label: "Set flag" }, { value: "command", label: "Run command" }, { value: "shop", label: "Open shop" }, { value: "dialogue", label: "Open dialogue" },
        { value: "role", label: "Open role screen" }, { value: "teleport", label: "Teleport" }, { value: "message", label: "Chat message" }, { value: "sound", label: "Play sound" }, { value: "event", label: "Script event" }];
    function condText(c) {
        var s;
        switch (c.type) {
            case "quest": s = "quest " + (c.quest || "?") + " " + (c.state || "done"); break;
            case "faction": s = (c.faction || "?") + (c.relation ? " is " + c.relation : (c.min !== undefined ? " >= " + c.min : "") + (c.max !== undefined ? " <= " + c.max : "")); break;
            case "item": s = "has " + (c.count || 1) + "x " + (c.item || "?"); break;
            case "level": case "money": s = c.type + (c.min !== undefined ? " >= " + c.min : "") + (c.max !== undefined ? " <= " + c.max : ""); break;
            case "flag": s = "flag " + (c.flag || "?") + (c.value !== undefined ? " = " + c.value : " set"); break;
            case "time": s = "time " + (c.from || 0) + "-" + (c.to || 0); break;
            default: s = c.type + " " + (c.id || c.node || "");
        }
        return (c.not ? "NOT " : "") + s;
    }
    function actText(a) {
        switch (a.type) {
            case "give": return "give " + (a.count || 1) + "x " + (a.id || a.item || "?");
            case "take": return "take " + (a.count || 1) + "x " + (a.item || "?");
            case "money": case "xp": return a.type + " " + (a.amount || 0);
            case "faction": return (a.faction || "?") + " " + ((a.points || 0) >= 0 ? "+" : "") + (a.points || 0);
            case "flag": return "flag " + (a.flag || "?") + " = " + (a.value === undefined ? "(clear)" : a.value);
            case "command": return "/" + (a.command || "");
            case "teleport": return "tp " + a.x + " " + a.y + " " + a.z;
            default: return a.type + " " + (a.quest || a.shop || a.dialogue || a.text || a.sound || a.name || "");
        }
    }
    function conditions(list, done, title) { PICK = { mode: "cond", list: U.clone(list) || [], done: done, title: title }; U.reset(); }
    function actions(list, done, title) { PICK = { mode: "act", list: U.clone(list) || [], done: done, title: title }; U.reset(); }

    function drawPick(ctx) {
        var S = U.state();
        var w = 360, h = 230, x = Math.round((ctx.width - w) / 2), y = Math.round((ctx.height - h) / 2);
        U.panel(ctx, x, y, w, h, PICK.title);
        var types = PICK.mode === "cond" ? COND_TYPES : ACT_TYPES;
        U.scrollArea(ctx, "pick", x + 8, y + 20, w - 22, h - 48, function (y0) {
            var yy = y0;
            PICK.list.forEach(function (c, i) {
                U.dropdown(ctx, "pk_t" + i, x + 8, yy, 110, 14, types, c.type || "", function (v) { PICK.list[i] = { type: v }; U.reset(); }, { maxVisible: 12 });
                U.button(ctx, "x", x + w - 34, yy, 16, 14, function () { PICK.list.splice(i, 1); U.reset(); });
                var fx = x + 122, G = U.form(ctx, fx, yy, w - 160, 0, c, function () { });
                G.lw = 0;
                pickFields(ctx, G, c, i, PICK.mode);
                yy = Math.max(yy + 18, G.y) + 4;
                ctx.fill(x + 8, yy - 3, w - 30, 1, "#8B8B8B", 1);
            });
            return yy - y0 + 4;
        });
        U.button(ctx, "+ Add", x + 8, y + h - 24, 60, 18, function () { PICK.list.push({ type: PICK.mode === "cond" ? "quest" : "message" }); U.reset(); });
        U.button(ctx, "Done", x + w - 78, y + h - 24, 70, 18, function () { var p = PICK; PICK = null; p.done(p.list.filter(function (c) { return c.type; })); U.reset(); });
        U.button(ctx, "Cancel", x + w - 152, y + h - 24, 70, 18, function () { PICK = null; U.reset(); });
    }
    function pickFields(ctx, G, c, i, mode) {
        var k = "pk" + i, W = G.w;
        function txt(path, hint, w, max) { U.input(ctx, k + "_" + path, G.x, G.y, w || W, 14, U.get(c, path), function (v) { U.set(c, path, v); }, { hint: hint, maxLength: max || 64 }); G.y += 17; }
        function num(path, hint, w) { U.input(ctx, k + "_" + path, G.x, G.y, w || 60, 14, U.get(c, path), function (v) { var n = Number(v); U.set(c, path, v.trim() === "" || isNaN(n) ? undefined : n); }, { hint: hint, maxLength: 12 }); }
        function pick(path, options, w, o) { U.dropdown(ctx, k + "_" + path, G.x, G.y, w || W, 14, options, U.get(c, path) === undefined ? "" : U.get(c, path), function (v) { U.set(c, path, v); }, o || { search: options.length > 8 }); G.y += 17; }
        var q = opts(L().quests, "(quest)"), f = opts(L().factions, "(faction)");
        if (mode === "cond") {
            switch (c.type) {
                case "quest": pick("quest", q); pick("state", [{ value: "done", label: "is done" }, { value: "notDone", label: "is not done" }, { value: "active", label: "is active" }, { value: "notActive", label: "is not active" }, { value: "ready", label: "is ready to hand in" }, { value: "available", label: "can be started" }]); break;
                case "faction": pick("faction", f); pick("relation", [{ value: "", label: "(points below)" }, { value: "friendly", label: "is friendly" }, { value: "neutral", label: "is neutral" }, { value: "hostile", label: "is hostile" }]);
                    if (!c.relation) { num("min", "min"); U.input(ctx, k + "_max", G.x + 64, G.y, 60, 14, c.max, function (v) { var n = Number(v); c.max = v.trim() === "" || isNaN(n) ? undefined : n; }, { hint: "max", maxLength: 12 }); G.y += 17; } break;
                case "item": txt("item", "minecraft:diamond", W, 128); num("count", "count"); G.y += 17; break;
                case "level": case "money": num("min", "min"); if (c.type === "level") U.input(ctx, k + "_max", G.x + 64, G.y, 60, 14, c.max, function (v) { var n = Number(v); c.max = v.trim() === "" || isNaN(n) ? undefined : n; }, { hint: "max", maxLength: 12 }); G.y += 17; break;
                case "flag": txt("flag", "flag name"); txt("value", "value (empty: any)"); break;
                case "time": num("from", "from (0)"); U.input(ctx, k + "_to", G.x + 64, G.y, 60, 14, c.to, function (v) { c.to = Number(v) || 0; }, { hint: "to (12000)", maxLength: 6 }); G.y += 17; break;
                case "class": case "race": txt("id", c.type + " id"); break;
                case "permission": txt("node", "permission.node", W, 96); break;
            }
            U.toggle(ctx, !!c.not, G.x, G.y, function () { c.not = !c.not; if (!c.not) delete c.not; });
            U.text(ctx, "NOT (invert)", G.x + 28, G.y + 2, "#505050");
            G.y += 15;
        } else {
            switch (c.type) {
                case "give":
                    U.slot(ctx, c.id || c.item ? { id: c.id || c.item, count: c.count } : null, G.x, G.y, { fn: function () { U.held(function (h) { if (h) { c.id = h.id; delete c.item; c.count = h.count || 1; c.nbt = h.nbt; } }); }, tip: ["Click: the held item"] });
                    G.y += 20; break;
                case "take": txt("item", "minecraft:emerald", W, 128); num("count", "count"); G.y += 17; break;
                case "money": case "xp": num("amount", "amount"); G.y += 17; break;
                case "startQuest": case "completeQuest": case "abandonQuest": pick("quest", q); break;
                case "faction": pick("faction", f); num("points", "+10 / -10"); G.y += 17; break;
                case "flag": txt("flag", "flag name"); txt("value", "value (empty clears)"); break;
                case "command": txt("command", "say hi {player}", W, 256); break;
                case "shop": pick("shop", opts(L().shops, "(shop)")); break;
                case "dialogue": pick("dialogue", opts(L().dialogues, "(dialogue)")); break;
                case "teleport":
                    num("x", "x", 50); U.input(ctx, k + "_y", G.x + 54, G.y, 50, 14, c.y, function (v) { c.y = Number(v) || 0; }, { hint: "y", maxLength: 10 });
                    U.input(ctx, k + "_z", G.x + 108, G.y, 50, 14, c.z, function (v) { c.z = Number(v) || 0; }, { hint: "z", maxLength: 10 }); G.y += 17;
                    U.button(ctx, "Here", G.x, G.y, 50, 14, function () { c.x = Math.floor(RPG.player.getX()) + 0.5; c.y = Math.floor(RPG.player.getY()); c.z = Math.floor(RPG.player.getZ()) + 0.5; c.dimension = RPG.player.getDimension(); U.reset(); });
                    G.y += 17; break;
                case "message": txt("text", "&eThank you!", W, 400); break;
                case "sound": txt("sound", "minecraft:entity.villager.yes", W, 96); break;
                case "event": txt("name", "event name (scripts: npcDialogueAction)"); break;
                case "role": U.text(ctx, "Opens the NPC's trader/bank/... screen", G.x, G.y + 3, "#505050"); G.y += 15; break;
            }
        }
    }
    return { create: create, edit: edit, list: list, onSaved: onSaved, conditions: conditions, actions: actions, condText: condText, actText: actText,
        pickOpen: function () { return !!PICK; }, drawPick: drawPick, closePick: function () { PICK = null; } };

})();
