// =====================================================================================
//  NPC Maker (client) - what players see: trader, follower, transporter, quest log, factions
// =====================================================================================
//  The server sends a snapshot; every button sends a request the server checks again
//  (near the NPC, can pay, in stock) and answers with a fresh snapshot.
// =====================================================================================
(function () {
    var U = NPCM_UI;
    function role(op, data) { var m = data || {}; m.op = op; RPG.net.send("npcm_role", m); }
    function frame(ctx, w, h, title) {
        w = Math.min(w, ctx.width - 10); h = Math.min(h, ctx.height - 10);
        var x = Math.round((ctx.width - w) / 2), y = Math.round((ctx.height - h) / 2);
        U.panel(ctx, x, y, w, h, title);
        return { x: x, y: y, w: w, h: h };
    }
    function show(draw) { U.open({ draw: draw, back: function () { U.close(); } }); U.reset(); }
    function costText(r, cur) {
        var parts = (r.cost || []).map(function (c) { return (c.count || 1) + "x " + U.itemName(c.id); });
        if (r.money) parts.push(r.money + " " + cur);
        return parts.join(" + ") || "free";
    }

    // ---- trader ----
    var T = null;
    RPG.net.on("npcm_trader", function (d) { var was = U.state() && U.state().draw === drawTrader; T = d; if (!was) show(drawTrader); });
    function drawTrader(ctx, S) {
        if (!T) return;
        var f = frame(ctx, 330, 240, U.strip(T.name));
        U.text(ctx, "You have " + T.money + " " + T.currency, f.x + f.w - 8, f.y + 7, "#404040", "right");
        if (T.restock) U.text(ctx, "Restocks in " + T.restockIn + " min", f.x + 8, f.y + f.h - 14, "#606060");
        U.dark(ctx, f.x + 8, f.y + 20, f.w - 22, f.h - 40);
        U.list(ctx, "trades", f.x + 9, f.y + 21, f.w - 24, f.h - 42, T.rows, 24, function (r, i, ry) {
            var rx = f.x + 11;
            U.slot(ctx, r.item, rx, ry + 3, { tip: r.item ? [U.itemName(r.item.id), "&7" + costText(r, T.currency), r.left >= 0 ? "&7" + r.left + " left" : ""] : null });
            (r.cost || []).forEach(function (c, k) { U.slot(ctx, c, rx + 34 + k * 20, ry + 3, {}); });
            U.text(ctx, "<", rx + 23, ry + 8, "#C0C0C0", "left", true);
            if (r.money) U.text(ctx, r.money + " " + T.currency, rx + 78, ry + 8, "#FFE070", "left", true);
            if (r.left >= 0) U.text(ctx, r.left + " left", rx + 150, ry + 8, r.left ? "#A0A0A0" : "#FF6060", "left", true);
            var bx = f.x + f.w - 22;
            if (r.sell) { bx -= 64; U.button(ctx, "Sell " + r.sell, bx, ry + 4, 62, 16, function () { role("trade", { uuid: T.uuid, i: i, sell: true, qty: 1 }); }, { disabled: r.have < ((r.item && r.item.count) || 1), tip: "You have " + r.have }); }
            bx -= 44; U.button(ctx, "Buy", bx, ry + 4, 42, 16, function () { role("trade", { uuid: T.uuid, i: i, qty: 1 }); }, { disabled: !r.can, tip: costText(r, T.currency) });
        });
        if (!T.rows.length) U.text(ctx, "Nothing for sale.", f.x + f.w / 2, f.y + 100, "#A0A0A0", "center", true);
    }

    // ---- follower ----
    var FO = null;
    RPG.net.on("npcm_follower", function (d) { var was = U.state() && U.state().draw === drawFollower; FO = d; if (!was) show(drawFollower); });
    function drawFollower(ctx, S) {
        if (!FO) return;
        var f = frame(ctx, 240, 130, U.strip(FO.name));
        var y = f.y + 22;
        if (FO.mine) {
            U.text(ctx, FO.greeting ? '"' + FO.greeting + '"' : "At your service.", f.x + 10, y, "#404040"); y += 14;
            U.text(ctx, FO.left >= 0 ? "Follows you for " + Math.ceil(FO.left) + " more minute(s)" : "Follows you until dismissed", f.x + 10, y, "#606060"); y += 18;
            U.button(ctx, FO.stay ? "Follow me" : "Stay here", f.x + 10, y, 105, 18, function () { role("follower", { uuid: FO.uuid, act: FO.stay ? "follow" : "stay" }); });
            U.button(ctx, "Dismiss", f.x + 125, y, 105, 18, function () { role("follower", { uuid: FO.uuid, act: "dismiss" }); }, { color: "#FF9090" });
        } else if (FO.owner) {
            U.text(ctx, "Already hired by someone else.", f.x + 10, y, "#404040");
        } else {
            var price = [];
            if (FO.money) price.push(FO.money + " " + FO.currency);
            if (FO.item) price.push((FO.item.count || 1) + "x " + U.itemName(FO.item.id));
            U.text(ctx, "Hire me" + (price.length ? " for " + price.join(" + ") : "") + "?", f.x + 10, y, "#404040"); y += 14;
            U.text(ctx, FO.minutes ? "For " + FO.minutes + " minute(s)." : "Until you dismiss me.", f.x + 10, y, "#606060"); y += 18;
            U.button(ctx, "Hire", f.x + 10, y, 105, 18, function () { role("follower", { uuid: FO.uuid, act: "hire" }); });
            U.button(ctx, "No thanks", f.x + 125, y, 105, 18, function () { U.close(); });
        }
    }

    // ---- transporter ----
    var TR = null;
    RPG.net.on("npcm_transporter", function (d) { TR = d; show(drawTransporter); });
    function drawTransporter(ctx, S) {
        if (!TR) return;
        var f = frame(ctx, 260, 200, U.strip(TR.name) + (TR.group ? " - " + TR.group : ""));
        U.text(ctx, "Where to?", f.x + 8, f.y + 20, "#404040");
        U.dark(ctx, f.x + 8, f.y + 32, f.w - 22, f.h - 42);
        U.list(ctx, "dests", f.x + 9, f.y + 33, f.w - 24, f.h - 44, TR.list, 20, function (r, i, ry) {
            var label = r.known ? U.strip(r.name) : "???", rx = f.x + 12;
            U.text(ctx, label + (r.here ? "  (here)" : ""), rx, ry + 6, r.here ? "#80FF80" : r.known ? "#FFFFFF" : "#707070", "left", true);
            if (r.known && !r.here) U.button(ctx, r.cost ? r.cost + " " + TR.currency : "Travel", f.x + f.w - 90, ry + 2, 72, 16, function () { role("travel", { uuid: TR.uuid, to: r.id }); },
                { disabled: r.cost > TR.money });
        });
    }

    // ---- quest log ----
    var QL = null, QS = { tab: 0, sel: null };
    RPG.net.on("npcm_questlog", function (d) { var was = U.state() && U.state().draw === drawQuestLog; QL = d || { active: [], completed: [] }; if (!was) { U.open({ draw: drawQuestLog, back: function () { U.close(); }, ql: true }); U.reset(); } });
    function grouped(list) {
        var cats = {}, order = [];
        list.forEach(function (q) { var c = q.category || "Quests"; if (!cats[c]) { cats[c] = []; order.push(c); } cats[c].push(q); });
        var rows = [];
        order.forEach(function (c) { rows.push({ header: c }); cats[c].forEach(function (q) { rows.push(q); }); });
        return rows;
    }
    function drawQuestLog(ctx, S) {
        if (!QL) return;
        var f = frame(ctx, 400, 250, "Quest Log");
        U.button(ctx, "Active (" + QL.active.length + ")", f.x + 8, f.y + 20, 90, 16, function () { QS.tab = 0; QS.sel = null; }, { selected: QS.tab === 0 });
        U.button(ctx, "Completed (" + QL.completed.length + ")", f.x + 100, f.y + 20, 100, 16, function () { QS.tab = 1; QS.sel = null; }, { selected: QS.tab === 1 });
        var list = QS.tab === 0 ? QL.active : QL.completed, rows = grouped(list), lw = 140;
        if (!QS.sel && list.length) QS.sel = list[0].id;
        U.dark(ctx, f.x + 8, f.y + 40, lw, f.h - 48);
        U.list(ctx, "ql" + QS.tab, f.x + 9, f.y + 41, lw - 6, f.h - 50, rows, 14, function (r, i, ry) {
            if (r.header) { U.text(ctx, U.fit(ctx, r.header, lw - 10), f.x + 11, ry + 3, "#FFAA00", "left", true); return; }
            var sel = QS.sel === r.id;
            if (sel) ctx.fill(f.x + 9, ry, lw - 6, 14, "#FFFFFF", 0.2);
            U.text(ctx, U.fit(ctx, (r.ready ? "✔ " : "  ") + U.strip(r.name) + (r.times > 1 ? " x" + r.times : ""), lw - 14), f.x + 13, ry + 3, r.ready ? "#80FF80" : "#E0E0E0", "left", true);
            U.hit(f.x + 9, ry, lw - 6, 14, function () { QS.sel = r.id; });
        });
        if (!list.length) U.text(ctx, QS.tab === 0 ? "No quests yet." : "Nothing finished yet.", f.x + 8 + lw / 2, f.y + 100, "#A0A0A0", "center", true);
        var q = null;
        list.forEach(function (x) { if (x.id === QS.sel) q = x; });
        if (!q) return;
        var dx = f.x + lw + 16, dw = f.w - lw - 26;
        U.scrollArea(ctx, "qd_" + q.id, dx, f.y + 40, dw, f.h - 70, function (y0) {
            var y = y0;
            U.text(ctx, U.strip(q.name), dx, y, "#202020"); y += 12;
            if (q.description) U.wrap(ctx, U.strip(q.description), dw - 6).forEach(function (l) { U.text(ctx, l, dx, y, "#404040"); y += 10; });
            y += 4;
            if (QS.tab === 0) {
                (q.objectives || []).forEach(function (o) {
                    var done = o.have >= o.need;
                    U.text(ctx, (done ? "✔ " : "- ") + U.fit(ctx, U.strip(o.text), dw - 50), dx, y, done ? "#207020" : "#303030");
                    if (o.need > 1) U.text(ctx, Math.min(o.have, o.need) + "/" + o.need, dx + dw - 8, y, "#505050", "right");
                    y += 12;
                });
                if (q.turnIn) { y += 4; U.text(ctx, (q.ready ? "Return to " : "Hand in to ") + U.strip(q.turnInName), dx, y, q.ready ? "#207020" : "#505050"); y += 12; }
            } else U.text(ctx, "Completed" + (q.times > 1 ? " " + q.times + " times" : ""), dx, y, "#207020");
            return y - y0 + 4;
        });
        if (QS.tab === 0 && q.abandonable) U.button(ctx, "Abandon", f.x + f.w - 88, f.y + f.h - 26, 80, 18, function () { role("abandon", { quest: q.id }); QS.sel = null; }, { color: "#FF9090" });
    }

    // ---- factions ----
    var FA = null;
    RPG.net.on("npcm_factions", function (d) { FA = (d && d.list || []).filter(function (f) { return !f.hidden; }); show(drawFactions); });
    function drawFactions(ctx, S) {
        if (!FA) return;
        var f = frame(ctx, 320, 220, "Factions");
        U.dark(ctx, f.x + 8, f.y + 20, f.w - 22, f.h - 28);
        U.list(ctx, "fa", f.x + 9, f.y + 21, f.w - 24, f.h - 30, FA, 34, function (r, i, ry) {
            var rx = f.x + 12, bw = f.w - 40;
            U.text(ctx, U.strip(r.name), rx, ry + 3, r.color, "left", true);
            var relCol = { friendly: "#80FF80", neutral: "#FFFF80", hostile: "#FF7070" }[r.relation];
            U.text(ctx, r.relation + "  (" + Math.round(r.points) + ")", rx + bw, ry + 3, relCol, "right", true);
            // the bar: hostile / neutral / friendly bands and where the player stands
            var by = ry + 15, span = Math.max(1, r.max - r.min);
            function px(v) { return rx + (U.clamp(v, r.min, r.max) - r.min) / span * bw; }
            ctx.fill(rx, by, bw, 6, "#202020", 1);
            ctx.fill(rx, by, px(r.hostileBelow) - rx, 6, "#7A2C2C", 1);
            ctx.fill(px(r.friendlyAt), by, rx + bw - px(r.friendlyAt), 6, "#2F6B33", 1);
            ctx.fill(px(r.points) - 1, by - 2, 3, 10, "#FFFFFF", 1);
            if (r.description) U.hit(rx, ry, bw, 30, null, [U.strip(r.name), r.description]);
        });
        if (!FA.length) U.text(ctx, "No factions here.", f.x + f.w / 2, f.y + 90, "#A0A0A0", "center", true);
    }

    // ---- keys (unbound by default: set them in Options > Controls) ----
    try { RPG.keys.register("npcm_questlog", { name: "Quest Log" }); } catch (e) { }
    try { RPG.keys.register("npcm_factions", { name: "Factions" }); } catch (e) { }
    RPG.on("keybind", function (id, down) {
        if (!down || RPG.screen.getOpen()) return;
        if (id === "npcm_questlog") role("questlog");
        else if (id === "npcm_factions") role("factions");
    });
})();
