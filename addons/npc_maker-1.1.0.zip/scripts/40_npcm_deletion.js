// =====================================================================================
//  NPC Maker - the Entity Deletion Wand (staff tool)
// =====================================================================================
//  Left-click any entity to remove it at once (no death, no drops): mobs, NPCs, item frames,
//  armour stands, minecarts, dropped items, display entities...
//    * never players, nor anything a player is riding
//    * things worth a second thought (NPCs, bosses, named or tamed creatures, vehicles with
//      riders, decorations like item frames and armour stands, big bosses) need a second
//      left-click within 4 seconds
//    * right-click puts back what you removed last (the last 16, while the server runs)
//    * right-click a creature to see what it is before deleting it
//  Staff only: operators or the npcmaker.deletionwand permission (in the admin group).
//  Every removal is written to the server log.
// =====================================================================================
var NPCM_DELETION = (function () {
    var PERM = "npcmaker.deletionwand", UNDO_MAX = 16, CONFIRM_MS = 4000;
    RPG.perms.group("admin", [PERM]);
    var CN = RPG.customNpcs;
    var PENDING = {}, UNDO = {}, LASTUSE = {};
    // decorations and big bosses: a second click is asked for these types
    var CAREFUL = ["minecraft:item_frame", "minecraft:glow_item_frame", "minecraft:painting", "minecraft:armor_stand", "minecraft:end_crystal",
        "minecraft:ender_dragon", "minecraft:wither", "minecraft:elder_guardian", "minecraft:warden", "minecraft:villager", "minecraft:iron_golem",
        "minecraft:block_display", "minecraft:item_display", "minecraft:text_display", "minecraft:interaction", "minecraft:leash_knot"];

    function allowed(p) { try { return p.isOp() || RPG.perms.has(p, PERM); } catch (e) { return false; } }
    function uid(p) { return String(p.uuid); }
    function label(info) {
        var n = info.customName || info.name || info.type;
        return String(n).replace(/[&§][0-9a-fk-or]/gi, "") + (info.customName || info.name !== info.type ? " &8[" + info.type + "]" : "");
    }
    function where(info) { return Math.floor(info.x) + " " + Math.floor(info.y) + " " + Math.floor(info.z); }
    /** Why this one deserves a second click ("" = none). */
    function careful(p, info) {
        if (info.npc) return "an NPC";
        if (info.boss) return "a boss";
        if (info.owner && info.owner !== uid(p)) return "someone's pet";
        if (info.owner) return "your pet";
        if (info.customName) return "it has a name";
        if (info.passengers > 0) return "something rides it";
        if (CAREFUL.indexOf(info.type) >= 0) { var t = String(info.type).replace(/^minecraft:/, "").replace(/_/g, " "); return (/^[aeiou]/.test(t) ? "an " : "a ") + t; }
        return "";
    }
    /** What may bring it back, to tell the staff member. */
    function aftermath(info) {
        if (info.npc) {
            var id = info.rpgId, notes = [];
            if (CN.get("spawn", "npcspawn_" + id)) notes.push("its spawn rule makes more");
            if (CN.isWorld("npc", id)) notes.push("its definition stays (delete it in /npcs)");
            return notes.join("; ");
        }
        if (info.boss) return "a boss spawner may summon it again";
        return "";
    }

    function remove(p, info) {
        var snap = RPG.world.removeEntity(info.uuid);
        if (snap === null || snap === undefined) { p.actionbar("&cCouldn't delete that"); return; }
        var u = uid(p), list = UNDO[u] = UNDO[u] || [];
        if (snap) { list.push({ snap: String(snap), label: label(info), type: info.type }); if (list.length > UNDO_MAX) list.shift(); }
        var after = aftermath(info);
        p.tell("&c[Deletion Wand] &7Deleted &f" + label(info) + " &7at " + where(info) + (snap ? " &8(right-click to undo)" : ""));
        if (after) p.tell("&e  Note: " + after);
        p.playSound("minecraft:entity.item.pickup", 0.5, 0.6);
        RPG.log("[Deletion Wand] " + p.getName() + " deleted " + info.type + " '" + String(info.customName || info.name) + "' (" + info.uuid + ") at " + info.dimension + " " + where(info));
    }

    function attack(p, target, info) {
        if (!info || !info.uuid) return false;
        if (!allowed(p)) { p.actionbar("&cOnly staff can use the Deletion Wand"); return false; }
        if (info.player) { p.actionbar("&cThe Deletion Wand can't delete players"); return false; }
        if (info.carriesPlayer) { p.actionbar("&cA player is riding that: they get off first"); return false; }
        var u = uid(p), why = careful(p, info), pend = PENDING[u], now = Date.now();
        if (why && !(pend && pend.uuid === info.uuid && now - pend.at < CONFIRM_MS)) {
            PENDING[u] = { uuid: info.uuid, at: now };
            p.actionbar("&eLeft-click again to delete &f" + label(info) + " &e(" + why + ")");
            p.playSound("minecraft:block.note_block.bass", 0.6, 0.8);
            return false;
        }
        delete PENDING[u];
        remove(p, info);
        return false;          // never a hit: the wand only deletes
    }

    function undo(p) {
        if (!allowed(p)) { p.actionbar("&cOnly staff can use the Deletion Wand"); return; }
        var u = uid(p), now = RPG.server.getTick();
        if (LASTUSE[u] === now) return;
        LASTUSE[u] = now;
        var list = UNDO[u] || [];
        if (!list.length) { p.actionbar("&7Nothing to undo. Left-click an entity to delete it."); return; }
        var last = list.pop();
        if (RPG.world.restoreEntity(last.snap)) { p.tell("&a[Deletion Wand] &7Put back &f" + last.label + (list.length ? " &8(" + list.length + " more to undo)" : "")); p.playSound("minecraft:entity.chicken.egg", 0.6, 1.2); }
        else p.actionbar("&cCouldn't put back " + last.label + " (its area isn't loaded, or it is back already)");
    }

    var WAND = "ragnarok_rpg:" + RPG.items.define("deletion_wand", {
        name: "&cEntity Deletion Wand", maxStack: 1, model: "npc_maker:rpg/item/deletion_wand",
        lore: ["&7Left-click an entity: delete it", "&7(NPCs, bosses, named or tamed ones,", "&7 decorations: click twice)", "&7Right-click: undo the last deletion", "&7Never deletes players", "&8Staff only"],
        onUse: function (p) { undo(p); return false; },
        onAttackEntity: function (p, target, info) { return attack(p, target, info); }
    });

    // right-clicking a creature with the wand: what is it?
    RPG.on("entityInteract", function (p, ent) {
        var held = false;
        try { held = p.getHeldItem() === WAND; } catch (e) { }
        if (!held) return;
        if (!ent || !allowed(p)) return false;          // no riding minecarts or turning item frames with the wand
        var t = RPG.server.getTick(), u = uid(p);
        if (LASTUSE[u] === t) return false;
        LASTUSE[u] = t;
        var info = RPG.world.entityInfo(ent.getUuid());
        if (!info) return false;
        var why = careful(p, info);
        p.tell("&c[Deletion Wand] &f" + label(info) + " &7at " + where(info) + (info.rpgId ? " &7id &f" + info.rpgId : "") +
            (info.player ? " &c(a player: never deleted)" : why ? " &e(asks twice: " + why + ")" : ""));
        return false;
    });

    RPG.on("playerLeave", function (p) { var u = uid(p); delete PENDING[u]; delete LASTUSE[u]; });

    RPG.commands.register("deletionwand", {
        root: true, permission: PERM, description: "Gives the Entity Deletion Wand (staff)",
        run: function (p) { if (p) { p.giveItem(WAND, 1); p.tell("&c[Deletion Wand] &7Left-click an entity to delete it; right-click to undo."); } }
    });

    return { WAND: WAND, allowed: allowed };
})();
