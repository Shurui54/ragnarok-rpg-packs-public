// =====================================================================================
//  NPC Maker - NPC roles, the quest log and the factions screen (server side)
// =====================================================================================
//  The engine fires npcRole(player, npc, npcId, role) when a player talks to an NPC with a
//  role (or picks a dialogue option with the "role" action). Here each role does its thing:
//    trader       buy (items and/or money -> item) and sell rows, stock that refills
//    follower     hire for money and/or an item, for some minutes; then follow / stay / dismiss
//    transporter  travel between transporters of one group, each unlocked by visiting it
//    bank         a private chest per player (per bank group), optionally for a fee
//    itemgiver    hands out items once, daily or every time
//  (guard is pure behaviour in the engine: it attacks hostiles near its home.)
//  Every request is checked on the server again: still near that NPC, can pay, has stock.
// =====================================================================================
(function () {
    var CN = RPG.customNpcs, U = NPCM;
    var REACH = 8;

    function cfg(npcId) { return CN.def("npc", npcId) || {}; }
    function money(p) { try { return p.getMoney(); } catch (e) { return 0; } }
    function currency() { try { return (RPG.currency.get() || {}).name || "Zeni"; } catch (e) { return "Zeni"; } }
    function near(p, npc) { return npc && npc.isAlive() && npc.getDimension() === p.dimension && npc.distanceTo(p) <= REACH; }
    function findNpc(p, uuid) {
        var list = CN.near(p, REACH + 2);
        for (var i = 0; i < list.length; i++) if (list[i].getUuid() === String(uuid)) return list[i];
        return null;
    }
    function stackName(s) { return s && s.id ? (s.count > 1 ? s.count + "x " : "") + (s.name || String(s.id).replace(/^.*:/, "").replace(/_/g, " ")) : "?"; }

    // ---- trader --------------------------------------------------------------------------------
    function stockKey(npcId) { return "npcm_stock:" + npcId; }
    /** Stock left per trade row; rows refill every `restock` minutes (0 = never). */
    function stock(npcId, t) {
        var s = RPG.data.get(stockKey(npcId), null) || { at: Date.now(), left: {} };
        var mins = Number(t.restock) || 0;
        if (mins > 0 && Date.now() - s.at >= mins * 60000) { s = { at: Date.now(), left: {} }; RPG.data.set(stockKey(npcId), s); }
        return s;
    }
    function traderView(p, npc) {
        var id = npc.getRpgId(), c = cfg(id), t = c.trader || {}, s = stock(id, t);
        var rows = (t.trades || []).map(function (r, i) {
            var lim = Number(r.stock) || 0, left = lim > 0 ? Math.max(0, lim - (s.left[i] || 0)) : -1;
            return { item: r.item, cost: r.cost || [], money: Number(r.money) || 0, sell: Number(r.sell) || 0, left: left,
                can: (r.cost || []).every(function (k) { return p.countItem(k.id) >= (k.count || 1); }) && money(p) >= (Number(r.money) || 0) && left !== 0,
                have: r.item ? p.countItem(r.item.id) : 0 };
        });
        RPG.net.send(p, "npcm_trader", { uuid: npc.getUuid(), name: npc.getName(), rows: rows, money: money(p), currency: currency(),
            restock: Number(t.restock) || 0, restockIn: (Number(t.restock) || 0) > 0 ? Math.max(0, Math.round((s.at + t.restock * 60000 - Date.now()) / 60000)) : 0 });
    }
    function trade(p, m) {
        var npc = findNpc(p, m.uuid);
        if (!near(p, npc)) { p.actionbar("&cToo far away"); return; }
        var id = npc.getRpgId(), c = cfg(id), t = c.trader || {}, r = (t.trades || [])[U.clampInt(m.i, 0, 99, 0)];
        if (c.role !== "trader" || !r || !r.item) return;
        var qty = U.clampInt(m.qty, 1, 64, 1), s = stock(id, t), i = U.clampInt(m.i, 0, 99, 0);
        if (m.sell) {
            var price = Number(r.sell) || 0, n = r.item.count || 1;
            if (price <= 0) return;
            var can = Math.min(qty, Math.floor(p.countItem(r.item.id) / n));
            if (can <= 0) { p.actionbar("&cYou don't have that"); return; }
            p.takeItem(r.item.id, can * n);
            p.addMoney(price * can);
            p.actionbar("&aSold " + can * n + "x " + stackName({ id: r.item.id }) + " for " + price * can + " " + currency());
        } else {
            var lim = Number(r.stock) || 0;
            if (lim > 0) qty = Math.min(qty, lim - (s.left[i] || 0));
            if (qty <= 0) { p.actionbar("&cSold out" + ((Number(t.restock) || 0) > 0 ? " - come back later" : "")); return; }
            var cost = r.cost || [], cash = Number(r.money) || 0;
            for (var k = 0; k < cost.length; k++) if (p.countItem(cost[k].id) < (cost[k].count || 1) * qty) { p.actionbar("&cYou need " + stackName(cost[k])); return; }
            if (money(p) < cash * qty) { p.actionbar("&cNot enough " + currency()); return; }
            for (var k2 = 0; k2 < cost.length; k2++) p.takeItem(cost[k2].id, (cost[k2].count || 1) * qty);
            if (cash > 0) p.takeMoney(cash * qty);
            for (var q = 0; q < qty; q++) p.giveStack({ id: r.item.id, count: r.item.count || 1, nbt: r.item.nbt });
            if (lim > 0) { s.left[i] = (s.left[i] || 0) + qty; RPG.data.set(stockKey(id), s); }
            p.playSound("minecraft:entity.villager.yes", 0.6, 1);
        }
        traderView(p, npc);
    }

    // ---- follower ------------------------------------------------------------------------------
    function followerView(p, npc) {
        var c = cfg(npc.getRpgId()), f = c.follower || {}, info = CN.info(npc) || {};
        RPG.net.send(p, "npcm_follower", { uuid: npc.getUuid(), name: npc.getName(), money: Number(f.money) || 0, item: f.item || null, minutes: Number(f.minutes) || 0,
            currency: currency(), owner: info.owner, mine: info.owner === String(p.uuid), stay: !!info.stay, greeting: f.greeting || "",
            left: info.owner && info.followUntil > 0 ? info.minutesLeft : -1 });
    }
    function follower(p, m) {
        var npc = findNpc(p, m.uuid);
        if (!near(p, npc)) return;
        var c = cfg(npc.getRpgId()), f = c.follower || {}, info = CN.info(npc) || {};
        if (c.role !== "follower") return;
        var mine = info.owner === String(p.uuid);
        if (m.act === "hire") {
            if (info.owner && !mine) { p.actionbar("&cSomeone else hired " + npc.getName()); return; }
            var cash = Number(f.money) || 0;
            if (money(p) < cash) { p.actionbar("&cNot enough " + currency()); return; }
            if (f.item && f.item.id && p.countItem(f.item.id) < (f.item.count || 1)) { p.actionbar("&cYou need " + stackName(f.item)); return; }
            if (cash > 0) p.takeMoney(cash);
            if (f.item && f.item.id) p.takeItem(f.item.id, f.item.count || 1);
            CN.hire(npc, p, Number(f.minutes) || 0);
            p.tell("&e" + npc.getName() + " &7now follows you" + ((Number(f.minutes) || 0) > 0 ? " for " + f.minutes + " minute(s)" : "") + ".");
        } else if (mine && m.act === "stay") CN.setStay(npc, true);
        else if (mine && m.act === "follow") CN.setStay(npc, false);
        else if (mine && m.act === "dismiss") { CN.dismiss(npc); p.tell("&e" + npc.getName() + " &7stops following you."); }
        followerView(p, npc);
    }

    // ---- transporter ---------------------------------------------------------------------------
    function unlockKey(p) { return "npcm_tp_" + p.uuid; }
    function unlocked(p) { return RPG.data.get(unlockKey(p), null) || {}; }
    function transporters(group) {
        var out = [];
        CN.all("npc").forEach(function (id) {
            var d = cfg(id), t = d.transporter;
            if (d.role === "transporter" && t && (t.group || "") === (group || "")) out.push({ id: String(id), name: t.name || d.name || id, cost: Number(t.cost) || 0, open: !!t.unlocked });
        });
        return out;
    }
    function transporterView(p, npc) {
        var id = npc.getRpgId(), c = cfg(id), t = c.transporter || {}, u = unlocked(p);
        if (!u[id]) { u[id] = 1; RPG.data.set(unlockKey(p), u); p.actionbar("&aNew destination: " + (t.name || c.name || id)); }
        var list = transporters(t.group).map(function (x) { x.known = !!u[x.id] || x.open; x.here = x.id === id; return x; });
        RPG.net.send(p, "npcm_transporter", { uuid: npc.getUuid(), name: npc.getName(), group: t.group || "", list: list, currency: currency(), money: money(p) });
    }
    function travel(p, m) {
        var npc = findNpc(p, m.uuid);
        if (!near(p, npc)) return;
        var here = cfg(npc.getRpgId()), to = String(m.to), dest = cfg(to);
        if (here.role !== "transporter" || dest.role !== "transporter") return;
        if (((here.transporter || {}).group || "") !== ((dest.transporter || {}).group || "")) return;
        if (!unlocked(p)[to] && !(dest.transporter || {}).unlocked) { p.actionbar("&cYou haven't been there yet"); return; }
        var cost = Number((dest.transporter || {}).cost) || 0;
        if (money(p) < cost) { p.actionbar("&cNot enough " + currency()); return; }
        var es = CN.entities(to);
        var spot = null;
        if (es.length) spot = { dim: es[0].getDimension(), x: es[0].x, y: es[0].y, z: es[0].z };
        else {
            var h = RPG.data.get("npcm_tp_home:" + to, null);
            if (h) spot = h;
        }
        if (!spot) { p.actionbar("&cThat destination isn't reachable right now"); return; }
        if (cost > 0) p.takeMoney(cost);
        p.teleportTo(spot.dim, spot.x, spot.y, spot.z);         // NPCs aren't solid: land where the other transporter stands
        p.playSound("minecraft:entity.enderman.teleport", 0.6, 1.2);
        RPG.net.send(p, "npcm_close", {});
    }
    // remember where each transporter stands, so travel works while its chunk is unloaded
    RPG.every(200, function () {
        CN.list("npc").forEach(function (id) {
            var d = cfg(id);
            if (d.role !== "transporter") return;
            var es = CN.entities(id);
            if (es.length) RPG.data.set("npcm_tp_home:" + id, { dim: es[0].getDimension(), x: es[0].x, y: es[0].y, z: es[0].z });
        });
    });

    // ---- bank ----------------------------------------------------------------------------------
    function bank(p, npc) {
        var id = npc.getRpgId(), c = cfg(id), b = c.bank || {}, rows = U.clampInt(b.rows, 1, 6, 3), cost = Number(b.cost) || 0;
        if (cost > 0) {
            if (money(p) < cost) { p.actionbar("&cOpening the bank costs " + cost + " " + currency()); return; }
            p.takeMoney(cost);
        }
        var key = "npcm_bank:" + (b.shared || id) + ":" + p.uuid;
        RPG.ui.container(p, { title: "&8" + (c.name || "Bank"), rows: rows, items: RPG.data.get(key, []),
            onClose: function (pl, items) { RPG.data.set(key, items); } });
        p.playSound("minecraft:block.chest.open", 0.6, 1);
    }

    // ---- item giver ----------------------------------------------------------------------------
    function giveItems(p, npc) {
        var id = npc.getRpgId(), c = cfg(id), g = c.itemgiver || {}, mode = g.mode || "once";
        var key = "npcm_given:" + id, given = RPG.data.get(key, null) || {}, last = given[p.uuid] || 0;
        var wait = mode === "daily" ? 86400000 : mode === "once" ? Infinity : (Number(g.cooldown) || 0) * 60000;
        if (last && Date.now() - last < wait) { p.tell("&e" + npc.getName() + "&7: &f" + (g.already || "I have nothing more for you.")); return; }
        (g.items || []).forEach(function (s) { if (s && s.id) p.giveStack({ id: s.id, count: s.count || 1, nbt: s.nbt }); });
        given[p.uuid] = Date.now();
        RPG.data.set(key, given);
        if (g.message) p.tell("&e" + npc.getName() + "&7: &f" + g.message);
        p.playSound("minecraft:entity.item.pickup", 0.6, 1);
    }

    RPG.on("npcRole", function (p, npc, npcId, role) {
        switch (role) {
            case "trader": traderView(p, npc); return false;
            case "follower": followerView(p, npc); return false;
            case "transporter": transporterView(p, npc); return false;
            case "bank": bank(p, npc); return false;
            case "itemgiver": giveItems(p, npc); return false;
        }
    });

    RPG.net.on("npcm_role", function (p, m) {
        if (!m || typeof m.op !== "string") return;
        switch (m.op) {
            case "trade": trade(p, m); break;
            case "follower": follower(p, m); break;
            case "travel": travel(p, m); break;
            case "questlog": RPG.net.send(p, "npcm_questlog", CN.questLog(p)); break;
            case "abandon": { var q = String(m.quest || ""); if (p.isQuestActive(q)) p.abandonQuest(q); RPG.net.send(p, "npcm_questlog", CN.questLog(p)); break; }
            case "factions": RPG.net.send(p, "npcm_factions", { list: CN.factionStanding(p) }); break;
        }
    });

    RPG.commands.register("questlog", { root: true, aliases: ["quests"], description: "Your quests", run: function (p) { if (p) RPG.net.send(p, "npcm_questlog", CN.questLog(p)); } });
    RPG.commands.register("factions", { root: true, description: "How the factions see you", run: function (p) { if (p) RPG.net.send(p, "npcm_factions", { list: CN.factionStanding(p) }); } });
})();
