// =====================================================================================
//  NPC Maker - server side of the in-game NPC editor
// =====================================================================================
//  The engine does the work (RPG.customNpcs: definitions saved with the world and applied
//  live, NPC behaviour, factions, quest icons); this addon is the no-code front end:
//    * the NPC Wand: right-click an NPC to edit it, sneak + right-click a block to make one,
//      right-click the air for the hub (every NPC, faction, dialogue, quest, shop, preset)
//    * the NPC Cloner: right-click an NPC to copy it, then right-click to place copies
//      (sneak = a linked copy that shares the definition)
//    * path recording: Record in the AI tab, then right-click blocks with the wand
//  Everything the editor screens send arrives on one channel ("npcm", {op, ...}) and is
//  checked here: staff only (op or the npcmaker.edit permission), every value cleaned and
//  clamped against a schema before it is saved.
// =====================================================================================
var NPCM = (function () {
    var CN = RPG.customNpcs;
    var PERM = "npcmaker.edit", CHUNK = 24000;
    RPG.perms.group("admin", [PERM]);

    function canEdit(p) { try { return p.isOp() || RPG.perms.has(p, PERM); } catch (e) { return false; } }
    function uid(p) { return String(p.uuid); }
    function deny(p) { p.actionbar("&cOnly NPC staff can do that"); }
    function msg(p, ok, text) { RPG.net.send(p, "npcm_msg", { ok: !!ok, msg: String(text) }); if (!ok) p.actionbar("&c" + text); }

    /** Big replies go in pieces (a message is limited to ~30 KB). */
    function sendBig(p, kind, obj) {
        var s = JSON.stringify(obj), n = Math.max(1, Math.ceil(s.length / CHUNK)), id = kind + RPG.server.getTick() + "_" + Math.floor(Math.random() * 1e6);
        for (var i = 0; i < n; i++) RPG.net.send(p, "npcm_big", { kind: kind, id: id, i: i, n: n, s: s.substring(i * CHUNK, (i + 1) * CHUNK) });
    }
    /** ... and so do big saves from the editor. */
    var UPLOADS = {};
    function upload(p, m, done) {
        var u = uid(p), n = clampInt(m.n, 1, 40, 1), i = clampInt(m.i, 0, n - 1, 0);
        var box = UPLOADS[u];
        if (!box || box.id !== m.id) box = UPLOADS[u] = { id: m.id, n: n, got: 0, s: [] };
        if (box.s[i] === undefined) { box.s[i] = String(m.s || ""); box.got++; }
        if (box.got < box.n) return;
        delete UPLOADS[u];
        var obj = null;
        try { obj = JSON.parse(box.s.join("")); } catch (e) { msg(p, false, "Couldn't read what the editor sent"); return; }
        done(obj);
    }

    // =================================================================================
    //  Cleaning: everything from the client goes through a schema
    // =================================================================================
    function clampNum(v, a, b, d) { v = Number(v); return isNaN(v) ? d : v < a ? a : v > b ? b : v; }
    function clampInt(v, a, b, d) { return Math.round(clampNum(v, a, b, d)); }
    function str(v, max) { return v === undefined || v === null ? "" : String(v).substring(0, max || 256); }
    var ID_RE = /^[a-z0-9_\-:]{1,64}$/;
    function isId(v) { return typeof v === "string" && ID_RE.test(v); }

    var T = {
        S: function (max) { return function (v) { return typeof v === "string" || typeof v === "number" ? str(v, max) : undefined; }; },
        N: function (a, b) { return function (v) { var n = Number(v); return v === "" || v === null || isNaN(n) ? undefined : n < a ? a : n > b ? b : n; }; },
        I: function (a, b) { return function (v) { var n = Number(v); return v === "" || v === null || isNaN(n) ? undefined : Math.round(n < a ? a : n > b ? b : n); }; },
        B: function () { return function (v) { return typeof v === "boolean" ? v : v === 1 || v === "true" ? true : v === 0 || v === "false" ? false : undefined; }; },
        E: function (vals) { return function (v) { return vals.indexOf(v) >= 0 ? v : undefined; }; },
        ID: function () { return function (v) { return isId(v) ? v : undefined; }; },
        // no /i on the long class: Rhino builds a case-folded table for it (tens of ms)
        URL: function () { return function (v) { v = str(v, 500).trim(); return /^https:\/\//i.test(v) && /^.{8}[^\s\/@]+(\/\S*)?$/.test(v) ? v : undefined; }; },
        NAME: function () { return function (v) { v = str(v, 16).trim(); return /^[A-Za-z0-9_]{1,16}$/.test(v) ? v : undefined; }; },
        TEX: function () { return function (v) { v = str(v, 200).trim(); return /^[a-z0-9_.\-]+:[a-z0-9_.\-\/]+$/.test(v) ? v : undefined; }; },
        L: function (item, max) { return function (v) { if (!Array.isArray(v)) return undefined; var out = []; for (var i = 0; i < v.length && out.length < max; i++) { var c = item(v[i]); if (c !== undefined) out.push(c); } return out; }; },
        O: function (shape) { return function (v) { return clean(v, shape); }; },
        M: function (val, max, keyRe) { return function (v) {
            if (!v || typeof v !== "object" || Array.isArray(v)) return undefined;
            var out = {}, n = 0;
            for (var k in v) { if (n >= max) break; if (keyRe && !keyRe.test(k)) continue; var c = val(v[k]); if (c !== undefined) { out[k] = c; n++; } }
            return out;
        }; },
        RANGE: function (a, b) { return function (v) {
            if (Array.isArray(v) && v.length >= 2) { var x = Number(v[0]), y = Number(v[1]); if (isNaN(x) || isNaN(y)) return undefined; return [Math.max(a, Math.min(b, Math.round(x))), Math.max(a, Math.min(b, Math.round(y)))]; }
            var n = Number(v); return isNaN(n) || v === "" ? undefined : Math.max(a, Math.min(b, Math.round(n)));
        }; },
        ANY: function (v) { return v; }
    };
    function clean(v, shape) {
        if (!v || typeof v !== "object" || Array.isArray(v)) return undefined;
        var out = {};
        for (var k in shape) { if (v[k] === undefined) continue; var c = shape[k](v[k]); if (c !== undefined) out[k] = c; }
        return out;
    }
    var STACK = T.O({ id: T.S(128), count: T.I(1, 4096), nbt: T.S(20000) });
    var ITEMREF = function (v) { if (typeof v === "string") return /^[a-z0-9_.\-:]{1,128}$/.test(v) ? v : undefined; return STACK(v); };
    var COND = T.O({ type: T.E(["quest", "faction", "item", "level", "money", "flag", "time", "class", "race", "permission"]), quest: T.ID(), state: T.E(["available", "active", "ready", "done", "notDone", "notActive"]),
        faction: T.ID(), min: T.N(-1e12, 1e12), max: T.N(-1e12, 1e12), relation: T.E(["friendly", "neutral", "hostile"]), item: T.S(128), count: T.I(1, 4096),
        flag: T.S(64), value: T.S(128), from: T.I(0, 24000), to: T.I(0, 24000), id: T.S(64), node: T.S(96), not: T.B() });
    var CONDS = T.L(COND, 12);
    var ACT = T.O({ type: T.E(["give", "take", "money", "xp", "command", "startQuest", "completeQuest", "abandonQuest", "faction", "flag", "shop", "dialogue", "role", "teleport", "message", "sound", "event"]),
        item: T.S(128), id: T.S(128), count: T.I(1, 4096), nbt: T.S(20000), amount: T.N(-1e12, 1e12), command: T.S(256), quest: T.ID(), faction: T.ID(), points: T.N(-1e6, 1e6),
        flag: T.S(64), value: T.S(128), shop: T.ID(), dialogue: T.ID(), x: T.N(-3e7, 3e7), y: T.N(-2048, 4096), z: T.N(-3e7, 3e7), dimension: T.S(96), text: T.S(400), sound: T.S(96), name: T.S(64) });
    var ACTS = T.L(ACT, 16);

    var NPC = {
        name: T.S(64), title: T.S(96), nametag: T.E(["always", "look", "never"]), scale: T.N(0.05, 64), width: T.N(0.1, 16), height: T.N(0.1, 32),
        visibility: T.E(["visible", "invisible", "hidden"]), pose: T.E(["stand", "sit", "lie", "crouch", "arms_up", "point", "wave"]), icon: T.S(128),
        model: T.E(["player", "entity", "geo"]), entity: T.S(128), skin: T.TEX(), skinUrl: T.URL(), skinPlayer: T.NAME(), slim: T.B(),
        cape: T.TEX(), capeUrl: T.URL(), overlay: T.TEX(), overlayUrl: T.URL(), translucent: T.B(),
        equipment: T.O({ mainhand: ITEMREF, offhand: ITEMREF, head: ITEMREF, chest: ITEMREF, legs: ITEMREF, feet: ITEMREF }),
        health: T.N(1, 1e6), regen: T.N(0, 1e5), damage: T.N(0, 1e6), attackSpeed: T.I(1, 400), attackRange: T.N(0.5, 16), knockback: T.N(0, 20),
        armor: T.N(0, 1024), toughness: T.N(0, 1024), knockbackResistance: T.N(0, 1), speed: T.N(0, 3),
        resist: T.M(T.N(-1, 1), 8, /^(melee|projectile|fire|explosion|magic|fall|all)$/),
        immune: T.M(T.B(), 6, /^(fire|drowning|fall|suffocation|potions)$/),
        invulnerable: T.B(), immovable: T.B(), flying: T.B(), swims: T.B(),
        ranged: T.O({ projectile: T.S(128), damage: T.N(0, 1e6), interval: T.I(2, 1200), range: T.N(2, 64), minRange: T.N(0, 32), accuracy: T.N(0, 1), speed: T.N(0.1, 6), burst: T.I(1, 10), melee: T.B() }),
        respawn: T.E(["never", "always", "day", "night", "instant"]), respawnDelay: T.I(0, 604800),
        drops: T.L(T.O({ item: ITEMREF, count: T.RANGE(0, 4096), chance: T.N(0, 1) }), 32), xp: T.RANGE(0, 100000), money: T.N(0, 1e12),
        retaliate: T.B(), fleeAt: T.N(0, 1), attackPlayers: T.E(["never", "hostile", "always"]), attackMobs: T.B(), attackFactions: T.B(), aggroRange: T.N(1, 64),
        movement: T.E(["stand", "wander", "path"]), wanderRadius: T.N(1, 128), returnHome: T.B(), lookAtPlayers: T.B(), fixedYaw: T.N(-360, 360),
        path: T.L(T.L(T.N(-3e7, 3e7), 3), 64), pathMode: T.E(["loop", "back"]), pathPause: T.I(0, 1200),
        faction: T.ID(), killFactions: T.L(T.O({ faction: T.ID(), points: T.N(-1e6, 1e6) }), 8), talksToEnemies: T.B(), hostileLine: T.S(200),
        dialogue: T.ID(), dialogues: T.L(T.O({ dialogue: T.ID(), priority: T.N(-1000, 1000), requires: CONDS }), 16), lines: T.L(T.S(200), 16),
        role: T.E(["", "trader", "follower", "transporter", "bank", "guard", "itemgiver", "shop", "healer"]), shop: T.ID(),
        healer: T.O({ radius: T.N(1, 32), amount: T.N(0, 1e6) }),
        trader: T.O({ trades: T.L(T.O({ item: STACK, cost: T.L(STACK, 2), money: T.N(0, 1e12), sell: T.N(0, 1e12), stock: T.I(0, 100000) }), 27), restock: T.N(0, 100000) }),
        follower: T.O({ money: T.N(0, 1e12), item: STACK, minutes: T.N(0, 100000), greeting: T.S(200) }),
        transporter: T.O({ name: T.S(48), group: T.S(48), cost: T.N(0, 1e12), unlocked: T.B() }),
        bank: T.O({ rows: T.I(1, 6), cost: T.N(0, 1e12), shared: T.S(48) }),
        guard: T.O({ radius: T.N(2, 64) }),
        itemgiver: T.O({ items: T.L(STACK, 9), mode: T.E(["once", "daily", "always"]), cooldown: T.N(0, 100000), message: T.S(200), already: T.S(200) }),
        geo: T.ANY
    };
    var FACTION = { name: T.S(48), color: T.S(16), defaultPoints: T.N(-1e6, 1e6), friendlyAt: T.N(-1e6, 1e6), hostileBelow: T.N(-1e6, 1e6), min: T.N(-1e6, 1e6), max: T.N(-1e6, 1e6),
        hidden: T.B(), description: T.S(300), relations: T.M(T.E(["friendly", "neutral", "hostile"]), 64, ID_RE), killPoints: T.N(-1e6, 1e6) };
    var OPTION = T.O({ text: T.S(200), next: T.ID(), startQuest: T.ID(), completeQuest: T.ID(), openShop: T.ID(), openDialogue: T.ID(), requires: CONDS, "do": ACTS, minLevel: T.I(0, 1e8) });
    var DIALOGUE = { start: T.ID(), speaker: T.S(64), nodes: T.M(T.O({ text: T.S(1200), speaker: T.S(64), options: T.L(OPTION, 12) }), 64, ID_RE) };
    var OBJECTIVE = T.O({ type: T.E(["kill", "collect", "talk", "location", "custom", "level"]), target: T.S(128), count: T.I(1, 100000), item: T.S(128), consume: T.B(), npc: T.ID(),
        x: T.N(-3e7, 3e7), y: T.N(-2048, 4096), z: T.N(-3e7, 3e7), radius: T.N(1, 512), dimension: T.S(96), key: T.S(64), level: T.I(1, 1e8), description: T.S(160) });
    var QUEST = { name: T.S(64), description: T.S(800), category: T.S(48), giver: T.ID(), turnIn: T.ID(), repeatable: T.B(), repeatDelay: T.N(0, 1e8), abandonable: T.B(),
        next: T.L(T.ID(), 4), acceptText: T.S(64),
        requires: T.O({ level: T.I(0, 1e8), quests: T.L(T.ID(), 8), factions: T.M(T.N(-1e6, 1e6), 8, ID_RE), conditions: CONDS }),
        objectives: T.L(OBJECTIVE, 12),
        rewards: T.O({ xp: T.N(0, 1e12), money: T.N(0, 1e12), statPoints: T.I(0, 1e6), skillPoints: T.I(0, 1e6), factions: T.M(T.N(-1e6, 1e6), 8, ID_RE), commands: T.L(T.S(256), 8), actions: ACTS }) };
    var SHOP = { name: T.S(64), items: T.L(T.O({ item: T.S(128), count: T.I(1, 4096), buy: T.N(0, 1e12), sell: T.N(0, 1e12), levelReq: T.I(0, 1e8) }), 54) };
    var SPAWN = { npc: T.ID(), dimensions: T.L(T.S(96), 8), biomes: T.L(T.S(96), 16), interval: T.I(20, 72000), chance: T.N(0, 1), group: T.RANGE(1, 16), maxNearby: T.I(1, 64),
        countRange: T.N(4, 128), minDistance: T.N(0, 128), maxDistance: T.N(4, 256), placement: T.E(["surface", "near_player"]), light: T.E(["dark", "bright", "any"]),
        time: T.E(["day", "night", "any"]), enabled: T.B(), persistent: T.B() };
    var SCHEMAS = { npc: NPC, faction: FACTION, dialogue: DIALOGUE, quest: QUEST, shop: SHOP, spawn: SPAWN };

    /** The geo block of another NPC or mob ("mob:id" / "npc:id"), copied on the server (never trusted from a client). */
    function geoFrom(ref) {
        var m = /^(mob|npc):(.+)$/.exec(String(ref || ""));
        if (!m) return null;
        var d = CN.def(m[1], m[2]);
        return d && d.geo && d.geo.model ? JSON.parse(JSON.stringify(d.geo)) : null;
    }

    function cleanDef(kind, data, extra) {
        var out = clean(data, SCHEMAS[kind]) || {};
        if (kind === "npc") {
            delete out.geo;
            if (extra && extra.geoFrom) { var g = geoFrom(extra.geoFrom); if (g) { out.geo = g; out.geoFrom = String(extra.geoFrom); } }
            else if (data.geo && data.geoFrom) { var g2 = geoFrom(data.geoFrom); if (g2) { out.geo = g2; out.geoFrom = String(data.geoFrom); } }
            if (out.model !== "geo") { delete out.geo; delete out.geoFrom; }
            if (out.model !== "entity") delete out.entity;
            if (!out.name) out.name = "NPC";
        }
        if (kind === "dialogue" && out.nodes && !out.start) out.start = Object.keys(out.nodes)[0] || "start";
        if (kind === "quest" && !out.objectives) out.objectives = [];
        if (kind === "shop" && !out.items) out.items = [];
        return out;
    }

    // =================================================================================
    //  Items: the wand and the cloner
    // =================================================================================
    var WAND = "ragnarok_rpg:" + RPG.items.define("npc_wand", {
        name: "&6NPC Wand", maxStack: 1, model: "npc_maker:rpg/item/npc_wand",
        lore: ["&7Right-click an NPC: edit it", "&7Sneak + right-click a block: new NPC", "&7Right-click the air: NPC Maker", "&7Sneak + left-click an NPC: remove it (twice)", "&8Staff only"],
        onUse: function (p) { wandUse(p); return false; },
        onAttackEntity: function (p, target, info) { wandAttack(p, target, info); return false; }
    });
    var CLONER = "ragnarok_rpg:" + RPG.items.define("npc_cloner", {
        name: "&bNPC Cloner", maxStack: 1, model: "npc_maker:rpg/item/npc_cloner",
        lore: ["&7Right-click an NPC: save it to a tab", "&7Right-click the air: saved NPCs (server and your own)", "&7Right-click a block: place the one in hand", "&7Sneak + right-click a block: a linked copy", "&8Staff only"],
        onUse: function (p) { clonerUse(p); return false; }
    });

    var SELECTED = {}, RECORD = {}, LASTCLICK = {};
    function held(p, id) { try { return p.getHeldItem() === id; } catch (e) { return false; } }
    /** The block under the crosshair (its own position, whatever face was hit), or null. */
    function blockLookedAt(p, range) {
        var r = p.raycast(range, { blocks: true, entities: false });
        return r && r.hit === "block" ? { x: r.blockX, y: r.blockY, z: r.blockZ } : null;
    }
    function lookSpot(p) {
        var b = blockLookedAt(p, 8);
        if (b) return { x: b.x + 0.5, y: b.y + 1, z: b.z + 0.5 };
        var yaw = p.getYaw() * Math.PI / 180;
        return { x: p.x - Math.sin(yaw) * 2, y: p.y, z: p.z + Math.cos(yaw) * 2 };
    }
    function facingYaw(p, spot) { return (Math.atan2(p.x - spot.x, spot.z - p.z) * 180 / Math.PI + 360) % 360; }

    function wandUse(p) {
        if (!canEdit(p)) { deny(p); return; }
        var r = RECORD[uid(p)];
        if (r) {
            if (p.isSneaking()) { stopRecording(p); return; }
            var b = blockLookedAt(p, 16);
            if (!b) { p.actionbar("&7Look at a block to add a waypoint (sneak + right-click to finish)"); return; }
            if (r.points.length >= 64) { p.actionbar("&cA path has at most 64 points"); return; }
            r.points.push([b.x, b.y + 1, b.z]);
            p.actionbar("&aWaypoint " + r.points.length + " &7at " + b.x + " " + (b.y + 1) + " " + b.z + " &8(sneak + right-click to finish)");
            p.playSound("minecraft:block.note_block.hat", 0.6, 1.4);
            return;
        }
        if (p.isSneaking()) { createAt(p, lookSpot(p), null); return; }
        sendHub(p);
    }
    /** Sneak + left-click an NPC with the wand: remove that one NPC (a second click within 4 s confirms). */
    var REMOVING = {};
    function wandAttack(p, ent, info) {
        if (!ent || ent.getType() !== "ragnarok_rpg:npc") return;
        if (!canEdit(p)) { deny(p); return; }
        if (!p.isSneaking()) { p.actionbar("&7Sneak + left-click to remove this NPC; right-click to edit it"); return; }
        var u = uid(p), r = REMOVING[u], now = Date.now(), name = String(ent.getName());
        if (!(r && r.uuid === ent.getUuid() && now - r.at < 4000)) {
            REMOVING[u] = { uuid: ent.getUuid(), at: now };
            p.actionbar("&eSneak + left-click again to remove &f" + name + " &7(" + ent.getRpgId() + ")");
            p.playSound("minecraft:block.note_block.bass", 0.6, 0.8);
            return;
        }
        delete REMOVING[u];
        var id = ent.getRpgId(), left = CN.entities(id).length - 1;
        CN.despawn(ent);
        p.tell("&6[NPC Maker] &eRemoved &f" + name + " &7(" + id + ")&e." + (CN.isWorld("npc", id) ? " &7Its definition stays" + (left > 0 ? " (" + left + " more loaded)" : "") + ": delete it everywhere from its editor or /npcs." : ""));
        p.playSound("minecraft:entity.item.pickup", 0.5, 0.6);
    }

    function clonerUse(p) {
        if (!canEdit(p)) { deny(p); return; }
        NPCM_CLONER.use(p);
    }

    // right-clicking an NPC with a tool (fires once per hand: keep one per tick)
    RPG.on("entityInteract", function (p, ent) {
        if (!ent || ent.getType() !== "ragnarok_rpg:npc") return;
        var wand = held(p, WAND), cloner = held(p, CLONER);
        if (!wand && !cloner) return;
        var t = RPG.server.getTick(), u = uid(p);
        if (LASTCLICK[u] === t) return false;
        LASTCLICK[u] = t;
        if (!canEdit(p)) { deny(p); return false; }
        if (cloner) { NPCM_CLONER.open(p, ent); return false; }
        if (RECORD[u]) { p.actionbar("&7Recording a path: right-click blocks, sneak + right-click to finish"); return false; }
        SELECTED[u] = ent.getUuid();
        openEditor(p, ent);
        return false;
    });

    // =================================================================================
    //  Editor payloads
    // =================================================================================
    var CHOICES = null;
    function choices() {
        if (CHOICES) return CHOICES;
        var living = [];
        try { RPG.server.registryIds("living").forEach(function (id) { id = String(id); if (id !== "minecraft:player" && id !== "ragnarok_rpg:npc") living.push(id); }); } catch (e) { }
        var geos = [];
        ["mob", "npc"].forEach(function (k) {
            CN.all(k).forEach(function (id) { var d = CN.def(k, id); if (d && d.geo && d.geo.model) geos.push({ id: k + ":" + id, name: (d.name || id) + " (" + k + ")" }); });
        });
        CHOICES = { living: living, geos: geos, projectiles: CN.all("projectile").map(String) };
        return CHOICES;
    }
    RPG.on("reload", function () { CHOICES = null; });
    function lists() {
        function named(kind) { return CN.summary(kind); }        // made in game first, then by name
        return { npcs: named("npc"), factions: named("faction"), dialogues: named("dialogue"), quests: named("quest"), shops: named("shop") };
    }

    function entityById(uuid) {
        var all = CN.entities(null);
        for (var i = 0; i < all.length; i++) if (all[i].getUuid() === uuid) return all[i];
        return null;
    }
    function openEditor(p, ent) {
        var id = ent.getRpgId(), info = CN.info(ent);
        var payload = {
            id: id, world: CN.isWorld("npc", id), data: CN.get("npc", id) || CN.def("npc", id) || {},
            entity: { uuid: ent.getUuid(), netId: ent.entityId, home: info && info.home, scale: ent.getScale(), x: ent.x, y: ent.y, z: ent.z },
            linked: CN.entities(id).length, choices: choices(), lists: lists(),
            spawn: CN.get("spawn", "npcspawn_" + id), givenQuests: CN.questsFor(id),
            recording: !!RECORD[uid(p)]
        };
        sendBig(p, "editor", payload);
    }
    function sendHub(p) {
        var l = lists();
        l.presets = listPresets();
        l.selected = SELECTED[uid(p)] || null;
        sendBig(p, "hub", l);
    }

    // =================================================================================
    //  Creating, copying, deleting
    // =================================================================================
    function defaultNpc(name) {
        return { name: name || "New NPC", nametag: "look", movement: "stand", lookAtPlayers: true, invulnerable: true, respawn: "always", respawnDelay: 60, health: 20, damage: 2, skin: "", model: "player" };
    }
    function createAt(p, spot, from) {
        var data = from ? cleanDef("npc", from, { geoFrom: from.geoFrom }) : defaultNpc();
        var id = CN.freeId("npc", data.name || "npc");
        var err = CN.saveNpc(id, data);
        if (err) { msg(p, false, err); return null; }
        var e = CN.spawn(id, p.dimension, spot.x, spot.y, spot.z, { yaw: facingYaw(p, spot) });
        if (!e) { msg(p, false, "Couldn't place the NPC"); return null; }
        SELECTED[uid(p)] = e.getUuid();
        p.tell("&6[NPC Maker] &eMade &f" + data.name + " &7(" + id + ")&e. Right-click it with the wand to edit.");
        RPG.schedule(2, function () { openEditor(p, e); });
        return e;
    }

    function stopRecording(p) {
        var r = RECORD[uid(p)];
        if (!r) return;
        delete RECORD[uid(p)];
        var d = CN.get("npc", r.id);
        if (!d) { p.actionbar("&cThat NPC is gone"); return; }
        d.path = r.points;
        if (r.points.length) d.movement = "path";
        CN.saveNpc(r.id, cleanDef("npc", d, { geoFrom: d.geoFrom }));
        p.tell("&6[NPC Maker] &ePath saved: &f" + r.points.length + " &epoint(s) for " + (d.name || r.id) + ".");
        var e = r.uuid ? entityById(r.uuid) : null;
        if (e) RPG.schedule(1, function () { openEditor(p, e); });
    }

    // =================================================================================
    //  Presets: NPC definitions as files in <game dir>/ragnarok_rpg/shared/npc_presets/
    //  (shared by every world on this computer or server: copy them between games freely)
    // =================================================================================
    function presetName(n) { n = String(n || "").toLowerCase().replace(/[^a-z0-9_\-]+/g, "_").replace(/^_+|_+$/g, ""); return n.substring(0, 48); }
    function listPresets() {
        try { return RPG.files.listShared("npc_presets").map(function (f) { return String(f).replace(/^npc_presets\//, "").replace(/\.json$/, ""); }); } catch (e) { return []; }
    }
    function savePreset(p, id, name) {
        var d = CN.def("npc", id);
        var n = presetName(name);
        if (!d || !n) { msg(p, false, "Give the preset a name"); return; }
        var data = cleanDef("npc", d, { geoFrom: d.geoFrom });
        RPG.files.writeShared("npc_presets/" + n + ".json", { format: "ragnarok_npc_preset", version: 1, npc: data });
        msg(p, true, "Preset '" + n + "' saved to " + RPG.files.sharedPath("npc_presets/" + n + ".json"));
    }
    function placePreset(p, name) {
        var n = presetName(name), f = null;
        try { f = RPG.files.readShared("npc_presets/" + n + ".json"); } catch (e) { f = null; }
        if (!f || !f.npc) { msg(p, false, "No preset '" + n + "'"); return; }
        createAt(p, lookSpot(p), f.npc);
    }

    // =================================================================================
    //  The channel
    // =================================================================================
    function npcEntity(p, m) {
        var e = m.uuid ? entityById(String(m.uuid)) : null;
        if (!e) msg(p, false, "That NPC isn't loaded");
        return e;
    }
    function saveKind(p, kind, id, data) {
        if (!SCHEMAS[kind]) return msg(p, false, "Unknown kind");
        if (!isId(id)) return msg(p, false, "Ids are a-z, 0-9, _ - : (up to 64)");
        if (!CN.isWorld(kind, id) && CN.def(kind, id)) return msg(p, false, "'" + id + "' is defined by a script and can't be edited here");
        var err = CN.save(kind, id, cleanDef(kind, data, data));
        if (err) return msg(p, false, err);
        msg(p, true, "Saved " + kind + " '" + id + "'");
        RPG.net.send(p, "npcm_saved", { kind: kind, id: id, lists: lists() });
    }

    RPG.net.on("npcm", function (p, m) {
        if (!m || typeof m.op !== "string") return;
        if (!canEdit(p)) { deny(p); return; }
        switch (m.op) {
            case "hub": sendHub(p); break;
            case "edit": { var e = m.uuid ? entityById(String(m.uuid)) : null; if (e) { SELECTED[uid(p)] = e.getUuid(); openEditor(p, e); } else msg(p, false, "That NPC isn't loaded"); break; }
            case "edit_def": {
                // a definition without a loaded entity: edit through the nearest one, or place one
                var id0 = String(m.id), es = CN.entities(id0);
                if (es.length) openEditor(p, es[0]);
                else { var sp = lookSpot(p), ne = CN.spawn(id0, p.dimension, sp.x, sp.y, sp.z, { yaw: facingYaw(p, sp) }); if (ne) openEditor(p, ne); }
                break;
            }
            case "create": createAt(p, lookSpot(p), m.name ? { name: str(m.name, 64), model: "player", movement: "stand" } : null); break;
            case "save": upload(p, m, function (o) {
                var id = String(o.id || "");
                if (!CN.isWorld("npc", id)) { msg(p, false, CN.def("npc", id) ? "This NPC is defined by a script: make an editable copy first" : "No such NPC"); return; }
                var err = CN.saveNpc(id, cleanDef("npc", o.data || {}, { geoFrom: o.data && o.data.geoFrom }));
                if (err) { msg(p, false, err); return; }
                if (o.spawn !== undefined) {
                    if (o.spawn && o.spawn.enabled !== undefined) { var sd = cleanDef("spawn", o.spawn); sd.npc = id; CN.save("spawn", "npcspawn_" + id, sd); }
                    else CN.remove("spawn", "npcspawn_" + id);
                }
                msg(p, true, "Saved " + id);
                RPG.net.send(p, "npcm_saved", { kind: "npc", id: id, lists: lists() });
            }); break;
            case "copy_script": {
                var src = CN.def("npc", String(m.id));
                if (!src) return;
                var nid = CN.freeId("npc", (src.name || m.id) + " copy");
                var data = cleanDef("npc", src, { geoFrom: src.geo ? "npc:" + m.id : null });
                if (src.geo) { data.model = "geo"; data.geo = JSON.parse(JSON.stringify(src.geo)); data.geoFrom = "npc:" + m.id; }
                var err2 = CN.saveNpc(nid, data);
                if (err2) { msg(p, false, err2); return; }
                var se = m.uuid ? entityById(String(m.uuid)) : null;
                if (se) {
                    // replace this one NPC with the editable copy, same place and size
                    var ne2 = CN.spawn(nid, se.getDimension(), se.x, se.y, se.z, { yaw: se.getYaw(), scale: se.getScale() });
                    CN.despawn(se);
                    if (ne2) { SELECTED[uid(p)] = ne2.getUuid(); RPG.schedule(1, function () { openEditor(p, ne2); }); }
                }
                msg(p, true, "Made an editable copy: " + nid);
                break;
            }
            case "delete_entity": { var de = npcEntity(p, m); if (de) { CN.despawn(de); msg(p, true, "NPC removed (its definition stays)"); } break; }
            case "delete_def": {
                var did = String(m.id);
                if (!CN.isWorld("npc", did)) { msg(p, false, "Only NPCs made in game can be deleted here"); return; }
                CN.entities(did).forEach(function (x) { CN.despawn(x); });
                CN.remove("npc", did);
                CN.remove("spawn", "npcspawn_" + did);
                msg(p, true, "Deleted " + did);
                sendHub(p);
                break;
            }
            case "tp": { var te = npcEntity(p, m); if (te) p.teleportTo(te.getDimension(), te.x, te.y, te.z); break; }
            case "summon": { var se2 = npcEntity(p, m); if (se2) { se2.teleportTo(p.dimension, p.x, p.y, p.z); CN.setHome(se2, p.x, p.y, p.z, p.getYaw()); msg(p, true, "NPC moved here (new home)"); } break; }
            case "set_home": { var he = npcEntity(p, m); if (he) { CN.setHome(he, he.x, he.y, he.z, he.getYaw()); msg(p, true, "Home set where it stands"); } break; }
            case "face_me": { var fe = npcEntity(p, m); if (fe) { var yaw = facingYaw(p, { x: fe.x, z: fe.z }); fe.teleportTo(fe.getDimension(), fe.x, fe.y, fe.z, (yaw + 180) % 360, 0); CN.setHome(fe, fe.x, fe.y, fe.z, (yaw + 180) % 360); msg(p, true, "Turned to face you"); } break; }
            case "set_scale": { var ce = npcEntity(p, m); if (ce) { ce.setScale(clampNum(m.scale, 0, 64, 0)); msg(p, true, "Size of this one NPC set"); } break; }
            case "record": {
                var re = npcEntity(p, m);
                if (!re || !CN.isWorld("npc", re.getRpgId())) return;
                RECORD[uid(p)] = { id: re.getRpgId(), uuid: re.getUuid(), points: [] };
                RPG.net.send(p, "npcm_close", {});
                p.tell("&6[NPC Maker] &eRecording a path for " + re.getName() + ": right-click blocks with the wand to add waypoints, sneak + right-click to finish.");
                break;
            }
            case "record_stop": stopRecording(p); break;
            case "clone": {
                var ke = npcEntity(p, m);
                if (!ke) return;
                if (m.linked) { CN.spawn(ke.getRpgId(), p.dimension, p.x, p.y, p.z, { yaw: p.getYaw(), scale: ke.getScale() }); msg(p, true, "Linked copy placed where you stand"); }
                else {
                    var d0 = CN.def("npc", ke.getRpgId());
                    var cid = CN.freeId("npc", d0.name || ke.getRpgId());
                    var e3 = CN.saveNpc(cid, cleanDef("npc", d0, { geoFrom: d0.geoFrom }));
                    if (e3) { msg(p, false, e3); return; }
                    CN.spawn(cid, p.dimension, p.x, p.y, p.z, { yaw: p.getYaw(), scale: ke.getScale() });
                    msg(p, true, "Independent copy placed: " + cid);
                }
                break;
            }
            case "give_tools": { p.giveItem(WAND, 1); p.giveItem(CLONER, 1); if (typeof NPCM_DELETION !== "undefined" && NPCM_DELETION.allowed(p)) p.giveItem(NPCM_DELETION.WAND, 1); break; }

            // ---- other content ----
            case "get_kind": {
                var k = String(m.kind), gid = String(m.id || "");
                if (!SCHEMAS[k]) return;
                sendBig(p, "kind", { kind: k, id: gid, world: CN.isWorld(k, gid), data: CN.get(k, gid) || CN.def(k, gid) || null, lists: lists(), choices: choices() });
                break;
            }
            case "save_kind": upload(p, m, function (o) { saveKind(p, String(o.kind), String(o.id), o.data || {}); }); break;
            case "delete_kind": {
                var dk = String(m.kind), dkid = String(m.id);
                if (!SCHEMAS[dk] || !CN.isWorld(dk, dkid)) { msg(p, false, "Only things made in game can be deleted here"); return; }
                CN.remove(dk, dkid);
                msg(p, true, "Deleted " + dk + " '" + dkid + "'");
                RPG.net.send(p, "npcm_saved", { kind: dk, id: dkid, deleted: true, lists: lists() });
                break;
            }
            case "free_id": RPG.net.send(p, "npcm_free_id", { kind: String(m.kind), id: CN.freeId(String(m.kind), str(m.name, 64)), req: m.req }); break;
            case "items": {
                var ids = [];
                try { ids = RPG.server.registryIds("item").map(String); } catch (e4) { }
                sendBig(p, "items", ids);
                break;
            }
            case "held": RPG.net.send(p, "npcm_held", { req: m.req, stack: p.getHeldStack() }); break;

            // ---- presets ----
            case "preset_save": savePreset(p, String(m.id), m.name); break;
            case "preset_place": placePreset(p, m.name); break;
            case "preset_delete": { var pn = presetName(m.name); if (pn && RPG.files.deleteShared("npc_presets/" + pn + ".json")) msg(p, true, "Preset deleted"); sendHub(p); break; }
        }
    });

    RPG.on("playerLeave", function (p) { var u = uid(p); delete SELECTED[u]; delete REMOVING[u]; delete RECORD[u]; delete UPLOADS[u]; delete LASTCLICK[u]; });

    RPG.commands.register("npcs", {
        root: true, aliases: ["npcmaker"], permission: PERM, description: "NPC Maker: /npcs [wand | create <name> | list]",
        suggest: function (p, args) { return args.length <= 1 ? ["wand", "create", "list"] : []; },
        run: function (p, args) {
            if (!p) return;
            var sub = args[0] || "";
            if (sub === "wand") { p.giveItem(WAND, 1); p.giveItem(CLONER, 1); p.tell("&6[NPC Maker] &eHere are the NPC Wand and the NPC Cloner."); return; }
            if (sub === "create") { createAt(p, lookSpot(p), args.length > 1 ? { name: args.slice(1).join(" "), model: "player", movement: "stand" } : null); return; }
            if (sub === "list") {
                var ids = CN.list("npc");
                p.tell("&6[NPC Maker] &e" + ids.length + " NPC(s) made in game: &f" + ids.join(", "));
                return;
            }
            sendHub(p);
        }
    });

    return { canEdit: canEdit, deny: deny, msg: msg, sendBig: sendBig, upload: upload, clean: clean, cleanDef: cleanDef, str: str, clampNum: clampNum, clampInt: clampInt, isId: isId,
        lookSpot: lookSpot, facingYaw: facingYaw, blockLookedAt: blockLookedAt, held: held, entityById: entityById, WAND: WAND, CLONER: CLONER };
})();
