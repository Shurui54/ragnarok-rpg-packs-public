// =====================================================================================
//  NPC Maker - the NPC Cloner (server side)
// =====================================================================================
//  Saved NPCs live in tabs, like a clone library:
//    * server tabs 1-15: saved with the world (RPG.data), shared by every staff member
//    * client tabs: files on the staff member's own computer (the client screen keeps them in
//      <game dir>/ragnarok_rpg/local/npc_clones/), usable on any world or server where they may
//      edit NPCs; the definition is sent here when they place one, and cleaned like any edit
//  Right-click an NPC with the cloner: the cloner screen with that NPC ready to save.
//  Right-click the air: the cloner screen. Right-click a block: place the NPC in hand (picked in
//  the screen); sneak: a linked copy of the last one placed (shares its definition).
// =====================================================================================
var NPCM_CLONER = (function () {
    var CN = RPG.customNpcs, M = NPCM;
    var TABS = 15, PREFIX = "npcm_clone/", TAB_NAMES = "npcm_clone_tabs", MAX_PER_TAB = 200;
    var HAND = {};          // uuid -> {name, data, lastId}

    function uid(p) { return String(p.uuid); }
    function slug(n) { n = String(n || "").toLowerCase().replace(/&[0-9a-fk-or]/g, "").replace(/[^a-z0-9_\-]+/g, "_").replace(/^_+|_+$/g, ""); return n.substring(0, 48) || "npc"; }
    function tabOk(t) { t = Number(t); return t >= 1 && t <= TABS && Math.floor(t) === t; }
    function tabNames() { var n = RPG.data.get(TAB_NAMES, null); return n && typeof n === "object" ? n : {}; }
    function key(tab, s) { return PREFIX + tab + "/" + s; }

    /** A clone's NPC data, cleaned as if it came from the editor (never trusted as stored). */
    function cleanNpc(data) {
        var d = M.cleanDef("npc", data || {}, { geoFrom: data && data.geoFrom });
        delete d._ownScale;
        return d;
    }
    function listTab(tab) {
        var out = [];
        RPG.data.keys(PREFIX + tab + "/").forEach(function (k) {
            var c = RPG.data.get(k, null);
            if (!c || !c.npc) return;
            out.push({ key: k.substring((PREFIX + tab + "/").length), name: String(c.name || c.npc.name || "NPC"), npc: c.npc, by: c.by || "", at: c.at || 0, scale: c.scale || 0 });
        });
        out.sort(function (a, b) { return a.name.replace(/&./g, "").toLowerCase() < b.name.replace(/&./g, "").toLowerCase() ? -1 : 1; });
        return out;
    }

    /** The NPC under the crosshair (within 24 blocks), or null. */
    function npcInView(p) {
        var r = null;
        try { r = p.raycast(24, { blocks: true, entities: true }); } catch (e) { }
        return r && r.hit === "entity" && r.entity && r.entity.getType() === "ragnarok_rpg:npc" ? r.entity : null;
    }
    function targetOf(ent) {
        if (!ent) return null;
        var d = CN.def("npc", ent.getRpgId());
        return d ? { uuid: ent.getUuid(), id: ent.getRpgId(), name: String(d.name || ent.getName()), npc: cleanNpc(d), scale: ent.getScale(), netId: ent.entityId } : null;
    }
    function handInfo(p) { var h = HAND[uid(p)]; return h ? { name: h.name, npc: h.data } : null; }

    /** Opens (or refreshes) the cloner screen; ent: the NPC to offer for saving (else the one in view). */
    function open(p, ent, tab) {
        var t = tabOk(tab) ? Number(tab) : 1;
        M.sendBig(p, "cloner", { tabs: TABS, names: tabNames(), tab: t, items: listTab(t), target: targetOf(ent || npcInView(p)), hand: handInfo(p) });
    }
    function sendTab(p, tab) {
        if (!tabOk(tab)) return;
        M.sendBig(p, "clone_tab", { tab: Number(tab), items: listTab(Number(tab)), names: tabNames(), hand: handInfo(p) });
    }

    function save(p, tab, name, npc, scale, replace) {
        if (!tabOk(tab)) { M.msg(p, false, "Pick a server tab"); return; }
        var data = cleanNpc(npc);
        var nm = M.str(name || data.name || "NPC", 64).trim() || "NPC";
        var s = slug(nm), k = key(tab, s);
        if (!replace) for (var i = 2; RPG.data.has(k); i++) { s = slug(nm) + "_" + i; k = key(tab, s); }
        if (!RPG.data.has(k) && RPG.data.keys(PREFIX + tab + "/").length >= MAX_PER_TAB) { M.msg(p, false, "That tab is full (" + MAX_PER_TAB + ")"); return; }
        try { RPG.data.set(k, { name: nm, npc: data, by: String(p.getName()), at: Date.now(), scale: M.clampNum(scale, 0, 64, 0) }); }
        catch (e) { M.msg(p, false, "Couldn't save: " + e); return; }
        M.msg(p, true, "Saved " + nm.replace(/&./g, "") + " in server tab " + tab);
        sendTab(p, tab);
    }

    /** Puts a clone in the player's hand (placed by right-clicking blocks). */
    function hold(p, name, npc, scale) {
        HAND[uid(p)] = { name: M.str(name || "NPC", 64), data: cleanNpc(npc), scale: M.clampNum(scale, 0, 64, 0), lastId: null };
    }

    /** Places the clone in hand: a new NPC of its own, or (linked) one more of the last one placed. */
    function place(p, spot, linked) {
        var h = HAND[uid(p)];
        if (!h) { p.actionbar("&7Pick a saved NPC in the cloner first (right-click the air)"); return null; }
        var yaw = M.facingYaw(p, spot), e = null;
        if (linked && h.lastId && CN.def("npc", h.lastId)) {
            e = CN.spawn(h.lastId, p.dimension, spot.x, spot.y, spot.z, { yaw: yaw, scale: h.scale || 0 });
            if (e) p.actionbar("&aPlaced a linked copy of &f" + h.lastId + " &7(same definition: editing one edits all)");
        } else {
            var id = CN.freeId("npc", h.data.name || h.name);
            var err = CN.saveNpc(id, h.data);
            if (err) { M.msg(p, false, err); return null; }
            e = CN.spawn(id, p.dimension, spot.x, spot.y, spot.z, { yaw: yaw, scale: h.scale || 0 });
            if (e) { h.lastId = id; p.actionbar("&aPlaced &f" + String(h.name).replace(/&./g, "") + " &7as " + id + " &8(sneak: linked copies of it)"); }
        }
        if (!e) { M.msg(p, false, "Couldn't place the NPC here"); return null; }
        p.playSound("minecraft:entity.item.pickup", 0.6, 0.9);
        return e;
    }

    function use(p) {
        var b = M.blockLookedAt(p, 8);
        if (!b || !HAND[uid(p)]) { open(p, null); return; }
        place(p, { x: b.x + 0.5, y: b.y + 1, z: b.z + 0.5 }, p.isSneaking());
    }

    RPG.net.on("npcm_clone", function (p, m) {
        if (!m || typeof m.op !== "string") return;
        if (!M.canEdit(p)) { M.deny(p); return; }
        switch (m.op) {
            case "tab": sendTab(p, m.tab); break;
            case "save": {
                // a live NPC: its definition is read here, never taken from the client
                var e = m.uuid ? M.entityById(String(m.uuid)) : null;
                if (!e) { M.msg(p, false, "That NPC isn't loaded"); return; }
                var d = CN.def("npc", e.getRpgId());
                if (!d) { M.msg(p, false, "That NPC has no definition"); return; }
                save(p, Number(m.tab), m.name, d, e.getScale(), !!m.replace);
                break;
            }
            case "save_data": M.upload(p, m, function (o) { save(p, Number(o.tab), o.name, o.npc || {}, o.scale, !!o.replace); }); break;
            case "delete": {
                if (!tabOk(m.tab)) return;
                var k = key(Number(m.tab), slug(m.key));
                if (RPG.data.has(k)) { RPG.data.remove(k); M.msg(p, true, "Deleted from server tab " + m.tab); }
                sendTab(p, m.tab);
                break;
            }
            case "rename_tab": {
                if (!tabOk(m.tab)) return;
                var names = tabNames(), nm = M.str(m.name, 32).trim();
                if (nm) names[String(m.tab)] = nm; else delete names[String(m.tab)];
                RPG.data.set(TAB_NAMES, names);
                M.msg(p, true, nm ? "Server tab " + m.tab + " is now '" + nm + "'" : "Server tab " + m.tab + " name cleared");
                sendTab(p, m.tab);
                break;
            }
            case "hold": case "spawn": {
                if (!tabOk(m.tab)) return;
                var c = RPG.data.get(key(Number(m.tab), slug(m.key)), null);
                if (!c || !c.npc) { M.msg(p, false, "That saved NPC is gone"); sendTab(p, m.tab); return; }
                hold(p, c.name, c.npc, c.scale);
                if (m.op === "spawn") { if (place(p, M.lookSpot(p), false)) RPG.net.send(p, "npcm_close", {}); }
                else { M.msg(p, true, "In hand: right-click blocks with the cloner to place " + String(c.name).replace(/&./g, "")); sendTab(p, m.tab); }
                break;
            }
            case "hold_data": case "spawn_data": M.upload(p, m, function (o) {
                // from a client tab: the player's own file, cleaned like any edit
                if (!o || !o.npc) return;
                hold(p, o.name, o.npc, o.scale);
                if (o.spawnNow) { if (place(p, M.lookSpot(p), false)) RPG.net.send(p, "npcm_close", {}); }
                else M.msg(p, true, "In hand: right-click blocks with the cloner to place " + M.str(o.name, 64).replace(/&./g, ""));
            }); break;
            case "drop": delete HAND[uid(p)]; M.msg(p, true, "Cloner emptied"); break;
            case "refresh": open(p, m.uuid ? M.entityById(String(m.uuid)) : null, m.tab); break;
        }
    });

    RPG.on("playerLeave", function (p) { delete HAND[uid(p)]; });

    return { open: open, use: use, place: place, TABS: TABS };
})();
