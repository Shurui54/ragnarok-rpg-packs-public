// =====================================================================================
//  05_ui.js - menus, HUD and colours
// =====================================================================================
//  Menu key: K.  Controls (Options > Controls > "Ragnarok RPG"), DMZ layout:
//      Alt+1..4 / Ctrl+1..4   technique slots 1-8 (the skill bar)
//      C hold  charge ki      V  fly          R  dash          G  descend / meditate
//      Z       lock on        H  ascend / super jump           (45_keys.js)
//  Want to repaint the menus themselves? Menu (K) > Settings > "Edit menu art".
// =====================================================================================

RPG.ui.configure({
    theme: "ragnarok",             // "ragnarok" (DMZ-style scouter panels) or "vanilla"
    showLogo: true,

    // DMZ's own character creator handles race and class (08_character.js, client/scripts/20_creator.js)
    chooseRaceOnJoin: false,
    chooseClassOnJoin: false,

    damageNumbers: false,          // DMZ has no floating numbers (damage pops are part of Ki Sense)

    // DMZ's Xenoverse HUD is drawn by client/scripts/10_hud_xenoverse.js; the engine's own HUD is off.
    hud: {
        enabled: false,
        primary: "ki",             // big bar  = resource id from 15_resources.js
        secondary: "stamina",      // small bar
        // tertiary: "release",    // a fourth bar, if you add a third resource
        portrait: true,            // the player's live portrait in the scouter orb
        showXp: true,
        showMoney: true,           // Zeni
        showTp: true,              // Training Points
        showSkillBar: true,        // the 8 technique slots
        showEffects: true,         // active forms/buffs in the top right
        scale: 0.75,
        x: 4, y: 4
    },

    // Which menu tabs exist, their order, and their labels. Only Options: DBR's own screens show stats,
    // techniques and sagas (the stats screen, the techniques screen and the quests screen).
    tabs: ["settings"],
    tabLabels: { character: "Status", skills: "Techniques", quests: "Sagas", settings: "Options" },

    // Text colours for the Ragnarok theme ("#RRGGBB" or 0xRRGGBB).
    colors: {
        title: "#F6E27A",
        text: "#E0E0E0",
        muted: "#9A9A9A",
        accent: "#FFB347",
        good: "#6AE07A",
        bad: "#E87A6A"
    }

    // Swap any menu texture (same pixel size as the original):
    // textures: { panel: "mypack:textures/gui/panel.png", buttons: "...", field: "...", slot: "...",
    //             scrollbar: "...", scrollbarThumb: "...", tab: "...", logo: "..." }
});
