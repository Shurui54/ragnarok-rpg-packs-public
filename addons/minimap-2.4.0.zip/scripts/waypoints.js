// =====================================================================================
//  Minimap - waypoints (server side): saved with the player, sent to their minimap
//  (client/scripts/minimap.js). Each waypoint: id, name, ini (1-2 letters shown on the marker),
//  x y z, dim, color, vis (shown in the world and on the maps).
//  From the client: add / edit / delete / teleport (the world map's right-click menu, the
//  waypoint list on ,). Commands: /waypoint add <name> | remove <name> | list | tp <name>
//  Teleporting needs creative mode or op (permission 2), like other minimaps' teleport
//  (config minimap.json: "teleport": "ops" | "everyone" | "off").
// =====================================================================================
(function () {
    var COLORS = ["#FF55FF55", "#FF5599FF", "#FFFFD34D", "#FFFF55FF", "#FF55FFFF", "#FFFF8C33", "#FFB266FF", "#FFFFFFFF"];
    var MAX = 100;
    var CFG = RPG.files.config("minimap", { teleport: "ops" });

    function list(p) {
        let l = p.getVar("mm_waypoints", []) || [];
        // older saves: give every waypoint an id, initials and visibility
        let next = Number(p.getVar("mm_wp_next", 1)) || 1, changed = false;
        l.forEach((w) => {
            if (!w.id) { w.id = next++; changed = true; }
            if (!w.ini) { w.ini = initials(w.name); changed = true; }
            if (w.vis === undefined) { w.vis = true; changed = true; }
        });
        if (changed) { p.setVar("mm_waypoints", l); p.setVar("mm_wp_next", next); }
        return l;
    }
    function nextId(p, l) {
        let n = Math.max(Number(p.getVar("mm_wp_next", 1)) || 1, 1 + l.reduce((m, w) => Math.max(m, w.id || 0), 0));
        p.setVar("mm_wp_next", n + 1);
        return n;
    }
    function initials(name) {
        let s = String(name || "?").replace(/&./g, "").trim();
        return (s.charAt(0) || "?").toUpperCase();
    }
    function canTeleport(p) {
        if (CFG.teleport === "off") return false;
        if (CFG.teleport === "everyone") return true;
        return p.isOp() || String(p.getGameMode()) === "creative";
    }
    function send(p) {
        RPG.net.send(p, "mm_waypoints", { list: list(p).filter((w) => w.dim === p.dimension), canTp: canTeleport(p) });
    }
    function save(p, l) { p.setVar("mm_waypoints", l); send(p); }
    function clean(s, max) { return String(s === undefined || s === null ? "" : s).replace(/[\u0000-\u001f]/g, "").substring(0, max).trim(); }
    function color(c, fallback) { return /^#[0-9A-Fa-f]{8}$/.test(String(c)) ? String(c).toUpperCase() : fallback; }
    function coord(v, fallback) { let n = Math.floor(Number(v)); return isNaN(n) || Math.abs(n) > 30000000 ? fallback : n; }

    RPG.net.on("mm_hello", (p) => send(p));

    // "Waypoint here" key, the world map's "Create waypoint" and the list's "Add"
    RPG.net.on("mm_add", (p, d) => {
        d = d || {};
        let l = list(p);
        if (l.length >= MAX) { p.actionbar("&cThat's a lot of waypoints (" + MAX + "). Remove some first."); return; }
        let name = clean(d.name, 32);
        if (!name) { let n = 1; while (l.some((w) => w.name === "wp" + n)) n++; name = "wp" + n; }
        let y = d.y === undefined || d.y === null ? Math.floor(p.y) : coord(d.y, Math.floor(p.y));
        let w = { id: nextId(p, l), name: name, ini: clean(d.ini, 2) || initials(name), x: coord(d.x, Math.floor(p.x)), y: y,
                  z: coord(d.z, Math.floor(p.z)), dim: p.dimension, color: color(d.color, COLORS[l.length % COLORS.length]), vis: true };
        l.push(w);
        save(p, l);
        p.actionbar("&aWaypoint &f" + name + "&a added.");
    });

    RPG.net.on("mm_edit", (p, d) => {
        if (!d) return;
        let l = list(p), w = l.filter((x) => x.id === Number(d.id))[0];
        if (!w) return;
        if (d.name !== undefined) { let n = clean(d.name, 32); if (n) w.name = n; }
        if (d.ini !== undefined) w.ini = clean(d.ini, 2) || initials(w.name);
        if (d.color !== undefined) w.color = color(d.color, w.color);
        if (d.x !== undefined) w.x = coord(d.x, w.x);
        if (d.y !== undefined) w.y = coord(d.y, w.y);
        if (d.z !== undefined) w.z = coord(d.z, w.z);
        if (d.vis !== undefined) w.vis = !!d.vis;
        save(p, l);
    });

    RPG.net.on("mm_delete", (p, d) => {
        if (!d) return;
        let l = list(p), w = l.filter((x) => x.id === Number(d.id))[0];
        if (!w) return;
        save(p, l.filter((x) => x !== w));
        p.actionbar("&7Waypoint &f" + w.name + "&7 deleted.");
    });

    // teleport to a waypoint ({id}) or a map spot ({x, z}, the ground height is found here)
    var LAST_TP = {};
    RPG.net.on("mm_tp", (p, d) => {
        if (!d) return;
        if (!canTeleport(p)) { p.actionbar("&cYou can't teleport (creative or op only)."); return; }
        if (RPG.server.getTick() - (LAST_TP[p.uuid] || -100) < 10) return;
        LAST_TP[p.uuid] = RPG.server.getTick();
        let x, y, z;
        if (d.id !== undefined) {
            let w = list(p).filter((q) => q.id === Number(d.id))[0];
            if (!w || w.dim !== p.dimension) return;
            x = w.x; y = w.y; z = w.z;
        } else {
            x = coord(d.x, null); z = coord(d.z, null);
            if (x === null || z === null) return;
            y = null;
        }
        if (y === null || y === undefined) {
            let sy = RPG.world.surfaceY(p.dimension, x, z);
            y = sy > -9999 ? sy : Math.floor(p.y);
        }
        p.teleport(x + 0.5, y, z + 0.5);
        p.playSound("minecraft:entity.enderman.teleport", 0.6, 1.2);
    });

    RPG.on("respawn", (p) => RPG.schedule(5, () => send(p)));
    RPG.on("gameModeChange", (p) => RPG.schedule(1, () => send(p)));       // creative changes "Teleport" in the menus
    RPG.on("death", (p) => {
        let l = list(p).filter((w) => w.name !== "death");
        l.push({ id: nextId(p, l), name: "death", ini: "X", x: Math.floor(p.x), y: Math.floor(p.y), z: Math.floor(p.z), dim: p.dimension, color: "#FFFF3333", vis: true });
        p.setVar("mm_waypoints", l);
    });

    RPG.commands.register("waypoint", {
        root: true, aliases: ["wp"], description: "/waypoint add <name> | remove <name> | list | tp <name>",
        suggest(p, args) { return args.length <= 1 ? ["add", "remove", "list", "tp"] : list(p).map((w) => w.name); },
        run(p, args) {
            if (!p) return;
            let sub = args[0] || "list", name = args.slice(1).join(" ").trim(), l = list(p);
            let find = (n) => l.filter((w) => w.name.toLowerCase() === n.toLowerCase())[0];
            if (sub === "add") {
                if (!name) { p.tell("&c/waypoint add <name>"); return; }
                let old = find(name);
                if (old) l = l.filter((w) => w !== old);
                if (l.length >= MAX) { p.tell("&cThat's a lot of waypoints. Remove some first."); return; }
                l.push({ id: nextId(p, l), name: name, ini: initials(name), x: Math.floor(p.x), y: Math.floor(p.y), z: Math.floor(p.z),
                         dim: p.dimension, color: COLORS[l.length % COLORS.length], vis: true });
                save(p, l);
                p.tell("&aWaypoint &f" + name + "&a set here.");
            } else if (sub === "remove") {
                let w = find(name);
                if (!w) { p.tell("&cNo waypoint called " + name); return; }
                save(p, l.filter((x) => x !== w));
                p.tell("&7Waypoint &f" + w.name + "&7 removed.");
            } else if (sub === "tp") {
                let w = find(name);
                if (!w) { p.tell("&cNo waypoint called " + name); return; }
                if (!canTeleport(p)) { p.tell("&cYou can't teleport (creative or op only)."); return; }
                if (w.dim !== p.dimension) { p.tell("&cThat waypoint is in " + w.dim); return; }
                p.teleport(w.x + 0.5, w.y, w.z + 0.5);
            } else {
                p.tell(l.length ? "&7Waypoints: " + l.map((w) => "&f" + w.name + " &7(" + w.x + ", " + w.z + ")").join(", ") : "&7No waypoints. /waypoint add <name>");
            }
        }
    });
    // dimension changes: show that dimension's waypoints
    var DIM = {};
    RPG.on("playerTick", (p) => { if (DIM[p.uuid] !== p.dimension) { DIM[p.uuid] = p.dimension; send(p); } });
})();
