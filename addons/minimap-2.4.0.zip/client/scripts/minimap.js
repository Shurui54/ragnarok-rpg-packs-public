// =====================================================================================
//  Minimap (client script: runs on each player's computer)
//  Remembers the land you've explored (saved on your computer, per world/server and dimension),
//  shows mobs (red), animals (green) and players (white), and has a full world map.
//  Keys (rebind in Options > Controls > Ragnarok Modding Toolkit):
//    M  world map        Y  show/hide minimap     =  /  -  zoom
//    N  new waypoint here (name, letters, colour)  ,  waypoint list (edit, delete, teleport, hide)
//  World map: drag to move, scroll to zoom. Right-click opens a menu: create a waypoint, teleport
//  there, centre; right-click a waypoint to edit, teleport to, hide or delete it.
//  "Chunks" shows/hides chunk borders on both maps (region borders, every 32 chunks, are brighter).
//  Waypoints show in the world as coloured markers with their letters; look at one for its name
//  and distance (toggle in the waypoint list). Teleporting needs creative or op.
//  Move/resize the minimap: K > Settings > Move / resize HUD.
//  Server map: if the server shares its map (server RPG.map.share or [worldMap] share = true in
//  <world>/serverconfig/ragnarok_rpg-server.toml), both maps also show the server's land, downloaded
//  in the background and cached per server/world; the world map shows how much is still coming.
// =====================================================================================
var MM_ZOOMS = [0.25, 0.5, 1, 2, 4];
var MM = RPG.storage.get("minimap", null) || { size: 100, zoom: 1, shown: true, radar: true };
var MM_WAYPOINTS = [];
var MM_CAN_TP = false;
var MM_PALETTE = ["#FF55FF55", "#FF5599FF", "#FFFFD34D", "#FFFF55FF", "#FF55FFFF", "#FFFF8C33", "#FFB266FF", "#FFFF3333", "#FFFFFFFF", "#FF9A9A9A"];

function mmSave() { RPG.storage.set("minimap", MM); }
function mmGrid() { return MM.grid !== false; }
function mmBeaconsOn() { return MM.beacons !== false; }
function mmShown() { return MM_WAYPOINTS.filter((w) => w.vis !== false); }
function mmRgb(c) { let s = String(c || "#FFFF5555"); return s.length === 9 ? "#" + s.substring(3) : s; }

function mmDraw() {
    RPG.hud.set("minimap", { type: "map", anchor: "topright", x: -MM.size - 6, y: 6, w: MM.size, h: MM.size, zoom: MM.zoom,
        cached: true, radar: MM.radar, chunkGrid: mmGrid(), gridColor: "#30FFFFFF", color: "#C0000000", movable: true, label: "Minimap", visible: MM.shown,
        markers: mmShown().map((w) => ({ x: w.x, z: w.z, color: w.color || "#FFFF5555" })) });
    RPG.hud.set("minimap_xy", { type: "text", anchor: "topright", x: -6 - MM.size / 2, y: MM.size + 10, text: "", color: "#FFFFFF", align: "center",
        movable: true, label: "Minimap coordinates", visible: MM.shown });
}

function mmFacing(yaw) {
    let dirs = ["S", "SW", "W", "NW", "N", "NE", "E", "SE"];
    return dirs[Math.round((((yaw % 360) + 360) % 360) / 45) % 8];
}

function mmZoom(step) {
    let i = MM_ZOOMS.indexOf(MM.zoom);
    if (i < 0) i = 2;
    MM.zoom = MM_ZOOMS[Math.max(0, Math.min(MM_ZOOMS.length - 1, i + step))];
    mmSave();
    mmDraw();
}

RPG.on("load", () => {
    RPG.map.record(true);
    RPG.keys.register("minimap_worldmap", { name: "World map", key: "m" });
    RPG.keys.register("minimap_toggle", { name: "Show/hide minimap", key: "y" });
    RPG.keys.register("minimap_zoom_in", { name: "Minimap zoom in", key: "equal" });
    RPG.keys.register("minimap_zoom_out", { name: "Minimap zoom out", key: "minus" });
    RPG.keys.register("minimap_waypoint", { name: "New waypoint here", key: "n" });
    RPG.keys.register("minimap_beacons", { name: "Waypoint list", key: "comma" });   // U is the Recipe Viewer's
    RPG.hud.onRender(mmWorldMarkers);
    mmDraw();
    RPG.net.send("mm_hello", {});
});

/** The ground height at x, z if that chunk is loaded here, else the player's height. */
function mmGroundY(x, z) {
    for (let y = 319; y > -64; y--) {
        let b = RPG.world.getBlock(x, y, z);
        if (b === "") return Math.floor(RPG.player.y);
        if (b !== "minecraft:air" && b !== "minecraft:cave_air" && b !== "minecraft:void_air") return y + 1;
    }
    return Math.floor(RPG.player.y);
}
function mmDist(w) {
    let p = RPG.player, y = w.y === undefined ? p.y : w.y;
    return Math.sqrt((w.x + 0.5 - p.x) * (w.x + 0.5 - p.x) + (y - p.y) * (y - p.y) + (w.z + 0.5 - p.z) * (w.z + 0.5 - p.z));
}

// ---- waypoints in the world: a coloured box with the letters over the spot; look at it for name + distance ----
function mmWorldMarkers(ctx) {
    if (!mmBeaconsOn() || !RPG.player.present || RPG.screen.getOpen()) return;
    let cx = ctx.width / 2, cy = ctx.height / 2, hovered = null, best = 1e9, drawn = [];
    mmShown().forEach((w) => {
        let d = mmDist(w);
        if (d < 2.5) return;                                              // standing on it
        let s = RPG.project(w.x + 0.5, (w.y === undefined ? RPG.player.y : w.y) + 1.2, w.z + 0.5);
        if (!s.visible) return;
        let dx = s.x - cx, dy = s.y - cy, off = dx * dx + dy * dy;
        if (off < 30 * 30 && off < best) { best = off; hovered = w; }
        drawn.push({ w: w, x: s.x, y: s.y, d: d });
    });
    // far ones first so near markers sit on top
    drawn.sort((a, b) => b.d - a.d).forEach((m) => {
        let w = m.w, ini = String(w.ini || w.name.charAt(0) || "?").substring(0, 2), size = ini.length > 1 ? 13 : 10;
        let a = m.d > 2000 ? 0.55 : 0.9;
        ctx.fill(m.x - size / 2 - 1, m.y - 6, size + 2, 12, "#000000", 0.6 * a);
        ctx.fill(m.x - size / 2, m.y - 5, size, 10, mmRgb(w.color), a);
        ctx.textStyled(ini, m.x + 0.5, m.y - 3.5, 1, "#FFFFFF", 1, 0.5, null, "#000000");
        if (w === hovered) {
            let label = w.name + "  " + (m.d >= 1000 ? (m.d / 1000).toFixed(1) + "km" : Math.round(m.d) + "m");
            let tw = ctx.textWidthIn(label, null) + 6;
            ctx.fill(m.x - tw / 2, m.y - 20, tw, 11, "#000000", 0.6);
            ctx.textStyled(label, m.x, m.y - 18.5, 1, "#FFFFFF", 1, 0.5, null, null);
        }
    });
}

RPG.every(5, () => {
    if (!MM.shown) return;
    let p = RPG.player, near = "";
    mmShown().forEach((w) => {
        let d = Math.round(Math.sqrt((w.x - p.x) * (w.x - p.x) + (w.z - p.z) * (w.z - p.z)));
        if (d < 64 && !near) near = "  &c" + w.name + " " + d + "m";
    });
    RPG.hud.text("minimap_xy", "&f" + Math.floor(p.x) + " " + Math.floor(p.y) + " " + Math.floor(p.z) + " &7" + mmFacing(p.yaw) + near);
});

RPG.on("keybind", (id, down) => {
    if (!down || RPG.screen.getOpen()) return;
    if (id === "minimap_toggle") { MM.shown = !MM.shown; mmSave(); mmDraw(); }
    else if (id === "minimap_zoom_in") mmZoom(1);
    else if (id === "minimap_zoom_out") mmZoom(-1);
    // another addon can take the key over (a star map in space): MINIMAP_WORLDMAP_OVERRIDE() returning true
    else if (id === "minimap_worldmap") { if (!(typeof MINIMAP_WORLDMAP_OVERRIDE === "function" && MINIMAP_WORLDMAP_OVERRIDE())) mmWorldMap(); }
    else if (id === "minimap_waypoint") mmEdit(null, { x: Math.floor(RPG.player.x), y: Math.floor(RPG.player.y), z: Math.floor(RPG.player.z) }, null);
    else if (id === "minimap_beacons") mmList();
});

// waypoints come from the server (saved with the player there)
RPG.net.on("mm_waypoints", (d) => {
    if (d && d.list) { MM_WAYPOINTS = d.list; MM_CAN_TP = !!d.canTp; }
    else MM_WAYPOINTS = d || [];                                         // an older server script
    mmDraw();
    let open = RPG.screen.getOpen();
    if (open === "mm_world") RPG.screen.update("map", { markers: mmMarkers() });
    if (open === "mm_list") mmListRefresh();
});

function mmMarkers() {
    let out = mmShown().map((w) => ({ x: w.x, z: w.z, color: w.color || "#FFFF5555", label: w.name, size: 3 }));
    RPG.world.entities(128).forEach((e) => { if (e.player) out.push({ x: e.x, z: e.z, color: "#FFFFFFFF", label: e.name, size: 2 }); });
    return out;
}

// =====================================================================================
//  World map + right-click menu
// =====================================================================================
var MM_MENU = null;          // { x, y, items: [{label, act, danger}], title }

function mmWorldMap() {
    let p = RPG.player;
    MM_MENU = null;
    RPG.screen.open({ id: "mm_world", background: "#FF000000", elements: [
        { id: "map", type: "worldmap", x: 0, y: 0, w: RPG.screenWidth, h: RPG.screenHeight, centerX: p.x, centerZ: p.z, zoom: MM.worldZoom || 1,
          minZoom: 0.125, maxZoom: 8, markers: mmMarkers(), labelZoom: 0.25, chunkGrid: mmGrid(), gridColor: "#38FFFFFF" },
        { id: "here", type: "button", anchor: "topright", x: -86, y: 6, w: 80, h: 20, label: "Here",
          onClick: () => RPG.screen.update("map", { centerX: RPG.player.x, centerZ: RPG.player.z }) },
        { id: "chunks", type: "button", anchor: "topright", x: -86, y: 30, w: 80, h: 20, label: "Chunks: " + (mmGrid() ? "On" : "Off"),
          onClick: () => {
              MM.grid = !mmGrid(); mmSave(); mmDraw();
              RPG.screen.update("map", { chunkGrid: mmGrid() });
              RPG.screen.update("chunks", { label: "Chunks: " + (mmGrid() ? "On" : "Off") });
          } },
        { id: "list", type: "button", anchor: "topright", x: -86, y: 54, w: 80, h: 20, label: "Waypoints", onClick: () => mmList() },
        { id: "close", type: "button", anchor: "topright", x: -86, y: 78, w: 80, h: 20, label: "Close", onClick: () => RPG.screen.close() },
        { id: "help", type: "text", anchor: "bottomleft", x: 6, y: -14, text: "&7Drag to move, scroll to zoom, right-click for options" }
    ], onRender: mmWorldRender, onMouse: mmWorldMouse,
       onKey: (k, action) => { if (action === "down" && k === "key.keyboard.escape" && MM_MENU) { MM_MENU = null; return false; } },
       onClose: () => { let m = RPG.screen.get("map"); if (m) { MM.worldZoom = m.zoom; mmSave(); } MM_MENU = null; } });
}

function mmMapState() { return RPG.screen.get("map"); }
function mmToWorld(m, sx, sy) { return { x: Math.floor(m.centerX + (sx - RPG.screenWidth / 2) / m.zoom), z: Math.floor(m.centerZ + (sy - RPG.screenHeight / 2) / m.zoom) }; }
function mmToScreen(m, wx, wz) { return { x: RPG.screenWidth / 2 + (wx + 0.5 - m.centerX) * m.zoom, y: RPG.screenHeight / 2 + (wz + 0.5 - m.centerZ) * m.zoom }; }
function mmWaypointAt(m, sx, sy) {
    let hit = null, best = 8 * 8;
    mmShown().forEach((w) => {
        let s = mmToScreen(m, w.x, w.z), d = (s.x - sx) * (s.x - sx) + (s.y - sy) * (s.y - sy);
        if (d <= best) { best = d; hit = w; }
    });
    return hit;
}

var MM_ROW = 14, MM_MENU_W = 130;
function mmMenuRect() { return { x: MM_MENU.x, y: MM_MENU.y, w: MM_MENU_W, h: 14 + MM_MENU.items.length * MM_ROW + 3 }; }

function mmWorldMouse(x, y, button, action) {
    if (action !== "down") return;
    if (MM_MENU) {
        let r = mmMenuRect();
        if (button === 0 && x >= r.x && x < r.x + r.w && y >= r.y + 14 && y < r.y + r.h - 3) {
            let it = MM_MENU.items[Math.floor((y - r.y - 14) / MM_ROW)];
            if (it) { RPG.sound("minecraft:ui.button.click", 0.5, 1); it.act(); }
            return false;
        }
        MM_MENU = null;
        if (button !== 1) return false;                                   // a click outside just closes it
    }
    if (button !== 1) return;
    let m = mmMapState();
    if (!m) return false;
    let wp = mmWaypointAt(m, x, y), items = [], title;
    if (wp) {
        title = "&f" + wp.name + " &7(" + wp.x + ", " + wp.y + ", " + wp.z + ")";
        items.push({ label: "Edit", act: () => { MM_MENU = null; mmEdit(wp, null, mmWorldMap); } });
        if (MM_CAN_TP) items.push({ label: "Teleport", act: () => { MM_MENU = null; RPG.net.send("mm_tp", { id: wp.id }); RPG.screen.close(); } });
        items.push({ label: "Centre here", act: () => { MM_MENU = null; RPG.screen.update("map", { centerX: wp.x + 0.5, centerZ: wp.z + 0.5 }); } });
        items.push({ label: "Hide", act: () => { MM_MENU = null; RPG.net.send("mm_edit", { id: wp.id, vis: false }); } });
        let del = { label: "&cDelete", danger: true };
        del.act = () => {
            if (!del.armed) { del.armed = true; del.label = "&cClick again to delete"; return; }
            MM_MENU = null; RPG.net.send("mm_delete", { id: wp.id });
        };
        items.push(del);
    } else {
        let at = mmToWorld(m, x, y);
        title = "&7" + at.x + ", " + at.z + "  &8chunk " + Math.floor(at.x / 16) + ", " + Math.floor(at.z / 16);
        items.push({ label: "Create waypoint", act: () => { MM_MENU = null; mmEdit(null, { x: at.x, y: mmGroundY(at.x, at.z), z: at.z }, mmWorldMap); } });
        if (MM_CAN_TP) items.push({ label: "Teleport here", act: () => { MM_MENU = null; RPG.net.send("mm_tp", { x: at.x, z: at.z }); RPG.screen.close(); } });
        items.push({ label: "Centre here", act: () => { MM_MENU = null; RPG.screen.update("map", { centerX: at.x + 0.5, centerZ: at.z + 0.5 }); } });
    }
    let sx = Math.min(x, RPG.screenWidth - MM_MENU_W - 2), sy = Math.min(y, RPG.screenHeight - (17 + items.length * MM_ROW) - 2);
    MM_MENU = { x: sx, y: sy, items: items, title: title };
    RPG.sound("minecraft:ui.button.click", 0.4, 1.4);
    return false;
}

function mmWorldRender(ctx) {
    let m = mmMapState();
    if (!m) return;
    let at = mmToWorld(m, ctx.mouseX, ctx.mouseY);
    ctx.text("&f" + at.x + ", " + at.z + (mmGrid() ? "  &7chunk " + Math.floor(at.x / 16) + ", " + Math.floor(at.z / 16) : ""), 6, 6, "#FFFFFF");
    ctx.text("&7" + RPG.player.dimension, 6, 18, "#FFFFFF");
    // the server's shared map (if the server shares one): how much is here and how much is still coming
    if (RPG.map.isServerShared && RPG.map.isServerShared()) {
        let st = RPG.map.serverStatus();
        ctx.text("&8Server map: " + st.chunks + " chunks" + (st.remaining > 0 ? ", downloading " + st.remaining : ""), 6, 30, "#FFFFFF");
    }
    // hovered waypoint: its letters and distance
    let hw = MM_MENU ? null : mmWaypointAt(m, ctx.mouseX, ctx.mouseY);
    if (hw) {
        let t = hw.name + "  " + Math.round(mmDist(hw)) + "m", tw = ctx.textWidthIn(t, null) + 8;
        ctx.fill(ctx.mouseX + 8, ctx.mouseY - 4, tw, 12, "#000000", 0.75);
        ctx.textStyled(t, ctx.mouseX + 12, ctx.mouseY - 2, 1, "#FFFFFF", 1, 0, null, null);
    }
    if (!MM_MENU) return;
    let r = mmMenuRect();
    ctx.tooltipBox(r.x, r.y, r.w, r.h);                                  // vanilla's tooltip box
    ctx.fill(r.x + 3, r.y + 13, r.w - 6, 1, "#505000FF", 1);
    ctx.textStyled(MM_MENU.title, r.x + 4, r.y + 3, 0.8, "#FFFFFF", 1, 0, null, null);
    MM_MENU.items.forEach((it, i) => {
        let iy = r.y + 14 + i * MM_ROW;
        let over = ctx.mouseX >= r.x && ctx.mouseX < r.x + r.w && ctx.mouseY >= iy && ctx.mouseY < iy + MM_ROW;
        if (over) ctx.fill(r.x + 3, iy, r.w - 6, MM_ROW, it.danger ? "#FF5555" : "#FFFFFF", 0.25);
        ctx.textStyled(it.label, r.x + 6, iy + 3, 1, "#FFFFFF", 1, 0, null, null);
    });
}

// =====================================================================================
//  Create / edit a waypoint
// =====================================================================================
var MM_EDIT = null;           // { id, color, back }

function mmEdit(wp, at, back) {
    let src = wp || at || {};
    MM_EDIT = { id: wp ? wp.id : null, color: wp ? wp.color : MM_PALETTE[MM_WAYPOINTS.length % MM_PALETTE.length], back: back, confirm: false };
    let W = 220, cx = 0;
    let els = [
        { id: "panel", type: "panel", anchor: "center", x: -W / 2, y: -100, w: W, h: 200 },
        { id: "title", type: "text", anchor: "center", x: 0, y: -94, text: wp ? "Edit waypoint" : "New waypoint", align: "center", color: "#404040", shadow: false },
        { id: "l_name", type: "text", anchor: "center", x: -W / 2 + 8, y: -76, text: "Name", color: "#404040", shadow: false },
        { id: "name", type: "input", anchor: "center", x: -W / 2 + 8, y: -66, w: W - 60, h: 16, value: wp ? wp.name : "", maxLength: 32, autofocus: true },
        { id: "l_ini", type: "text", anchor: "center", x: W / 2 - 46, y: -76, text: "Letters", color: "#404040", shadow: false },
        { id: "ini", type: "input", anchor: "center", x: W / 2 - 46, y: -66, w: 38, h: 16, value: wp ? (wp.ini || "") : "", maxLength: 2 },
        { id: "l_xyz", type: "text", anchor: "center", x: -W / 2 + 8, y: -44, text: "X                Y                Z", color: "#404040", shadow: false },
        { id: "x", type: "input", anchor: "center", x: -W / 2 + 8, y: -34, w: 64, h: 16, value: String(src.x !== undefined ? src.x : Math.floor(RPG.player.x)), maxLength: 9 },
        { id: "y", type: "input", anchor: "center", x: -W / 2 + 78, y: -34, w: 64, h: 16, value: String(src.y !== undefined ? src.y : Math.floor(RPG.player.y)), maxLength: 9 },
        { id: "z", type: "input", anchor: "center", x: -W / 2 + 148, y: -34, w: 64, h: 16, value: String(src.z !== undefined ? src.z : Math.floor(RPG.player.z)), maxLength: 9 },
        { id: "l_col", type: "text", anchor: "center", x: -W / 2 + 8, y: -10, text: "Colour", color: "#404040", shadow: false }
    ];
    // the engine's colour picker, with the usual waypoint colours as presets (waypoints keep "#AARRGGBB")
    els.push({ id: "col", type: "color", anchor: "center", x: -W / 2 + 8, y: 2, w: 110, h: 16, value: MM_EDIT.color, presets: MM_PALETTE,
        onChange: (id, v) => { MM_EDIT.color = "#FF" + String(v).substring(1).toUpperCase(); } });
    els.push({ id: "save", type: "button", anchor: "center", x: -W / 2 + 8, y: 70, w: 64, h: 20, label: "Save", onClick: mmEditSave });
    if (wp) els.push({ id: "delete", type: "button", anchor: "center", x: -32, y: 70, w: 64, h: 20, label: "&cDelete", onClick: () => {
        if (!MM_EDIT.confirm) { MM_EDIT.confirm = true; RPG.screen.update("delete", { label: "&cSure?" }); return; }
        RPG.net.send("mm_delete", { id: MM_EDIT.id });
        mmEditDone();
    } });
    if (wp && MM_CAN_TP) els.push({ id: "tp", type: "button", anchor: "center", x: -W / 2 + 8, y: 44, w: W - 16, h: 20, label: "Teleport",
        onClick: () => { RPG.net.send("mm_tp", { id: MM_EDIT.id }); RPG.screen.close(); } });
    els.push({ id: "cancel", type: "button", anchor: "center", x: W / 2 - 72, y: 70, w: 64, h: 20, label: "Cancel", onClick: mmEditDone });
    RPG.screen.open({ id: "mm_edit", background: "dim", elements: els, onKey: (k, action) => {
        if (action !== "down") return;
        if (k === "key.keyboard.enter") { mmEditSave(); return false; }
        if (k === "key.keyboard.escape") { mmEditDone(); return false; }
    } });
}

function mmEditSave() {
    let num = (id) => { let n = parseInt(String(RPG.screen.value(id) || "").trim(), 10); return isNaN(n) ? undefined : n; };
    let d = { name: String(RPG.screen.value("name") || "").trim(), ini: String(RPG.screen.value("ini") || "").trim(),
              x: num("x"), y: num("y"), z: num("z"), color: MM_EDIT.color };
    if (MM_EDIT.id === null) RPG.net.send("mm_add", d);
    else { d.id = MM_EDIT.id; RPG.net.send("mm_edit", d); }
    mmEditDone();
}
function mmEditDone() {
    let back = MM_EDIT && MM_EDIT.back;
    MM_EDIT = null;
    RPG.screen.close();
    if (back) RPG.schedule(1, back);
}

// =====================================================================================
//  Waypoint list (,)
// =====================================================================================
var MM_LIST = { scroll: 0, confirm: null };
var MM_LIST_ROWS = 10, MM_LIST_W = 300;

function mmList() {
    MM_LIST = { scroll: 0, confirm: null };
    MM_LIST_ROWS = Math.max(4, Math.min(14, Math.floor((RPG.screenHeight - 90) / 20)));
    let W = MM_LIST_W, top = -(MM_LIST_ROWS * 20 + 60) / 2, els = [
        { id: "panel", type: "panel", anchor: "center", x: -W / 2, y: top, w: W, h: MM_LIST_ROWS * 20 + 60 },
        { id: "title", type: "text", anchor: "center", x: 0, y: top + 6, text: "Waypoints", align: "center", color: "#404040", shadow: false },
        { id: "add", type: "button", anchor: "center", x: -W / 2 + 6, y: top + MM_LIST_ROWS * 20 + 34, w: 70, h: 20, label: "Add here",
          onClick: () => mmEdit(null, { x: Math.floor(RPG.player.x), y: Math.floor(RPG.player.y), z: Math.floor(RPG.player.z) }, mmList) },
        { id: "beacons", type: "button", anchor: "center", x: -W / 2 + 80, y: top + MM_LIST_ROWS * 20 + 34, w: 120, h: 20, label: "",
          onClick: () => { MM.beacons = !mmBeaconsOn(); mmSave(); mmListRefresh(); } },
        { id: "close", type: "button", anchor: "center", x: W / 2 - 76, y: top + MM_LIST_ROWS * 20 + 34, w: 70, h: 20, label: "Close", onClick: () => RPG.screen.close() },
        { id: "empty", type: "text", anchor: "center", x: 0, y: top + 40, text: "No waypoints here yet. N adds one where you stand.", align: "center", visible: false, color: "#404040", shadow: false }
    ];
    for (let i = 0; i < MM_LIST_ROWS; i++) {
        (function (row) {
            let y = top + 22 + row * 20;
            els.push({ id: "slot" + row, type: "panel", style: "slot", anchor: "center", x: -W / 2 + 5, y: y + 2, w: 14, h: 14 });
            els.push({ id: "chip" + row, type: "rect", anchor: "center", x: -W / 2 + 6, y: y + 3, w: 12, h: 12, color: "#FFFFFFFF" });
            els.push({ id: "name" + row, type: "text", anchor: "center", x: -W / 2 + 22, y: y + 5, text: "", color: "#404040", shadow: false });
            els.push({ id: "edit" + row, type: "button", anchor: "center", x: W / 2 - 150, y: y, w: 34, h: 18, label: "Edit", onClick: () => mmListAct(row, "edit") });
            els.push({ id: "tp" + row, type: "button", anchor: "center", x: W / 2 - 114, y: y, w: 34, h: 18, label: "TP", onClick: () => mmListAct(row, "tp") });
            els.push({ id: "vis" + row, type: "button", anchor: "center", x: W / 2 - 78, y: y, w: 38, h: 18, label: "Hide", onClick: () => mmListAct(row, "vis") });
            els.push({ id: "del" + row, type: "button", anchor: "center", x: W / 2 - 38, y: y, w: 32, h: 18, label: "&cX", onClick: () => mmListAct(row, "del") });
        })(i);
    }
    RPG.screen.open({ id: "mm_list", background: "dim", elements: els,
        onScroll: (x, y, delta) => {
            let max = Math.max(0, MM_WAYPOINTS.length - MM_LIST_ROWS);
            MM_LIST.scroll = Math.max(0, Math.min(max, MM_LIST.scroll + (delta < 0 ? 1 : -1)));
            mmListRefresh();
        } });
    mmListRefresh();
}

function mmListRefresh() {
    if (RPG.screen.getOpen() !== "mm_list") return;
    let all = MM_WAYPOINTS.slice().sort((a, b) => mmDist(a) - mmDist(b));
    MM_LIST.sorted = all;
    MM_LIST.scroll = Math.max(0, Math.min(MM_LIST.scroll, Math.max(0, all.length - MM_LIST_ROWS)));
    RPG.screen.update("empty", { visible: all.length === 0 });
    RPG.screen.update("beacons", { label: "World markers: " + (mmBeaconsOn() ? "On" : "Off") });
    for (let i = 0; i < MM_LIST_ROWS; i++) {
        let w = all[i + MM_LIST.scroll], show = !!w;
        ["slot", "chip", "name", "edit", "tp", "vis", "del"].forEach((k) => RPG.screen.update(k + i, { visible: show && (k !== "tp" || MM_CAN_TP) }));
        if (!w) continue;
        let d = Math.round(mmDist(w));
        RPG.screen.update("chip" + i, { color: w.color || "#FFFF5555" });
        RPG.screen.update("name" + i, { text: (w.vis === false ? "&8&o" : "") + w.name + " &8" + (d >= 1000 ? (d / 1000).toFixed(1) + "km" : d + "m") });
        RPG.screen.update("vis" + i, { label: w.vis === false ? "Show" : "Hide" });
        RPG.screen.update("del" + i, { label: MM_LIST.confirm === w.id ? "&c?" : "&cX" });
    }
}

function mmListAct(row, what) {
    let w = (MM_LIST.sorted || [])[row + MM_LIST.scroll];
    if (!w) return;
    if (what === "edit") mmEdit(w, null, mmList);
    else if (what === "tp") { RPG.net.send("mm_tp", { id: w.id }); RPG.screen.close(); }
    else if (what === "vis") RPG.net.send("mm_edit", { id: w.id, vis: w.vis === false });
    else if (what === "del") {
        if (MM_LIST.confirm !== w.id) { MM_LIST.confirm = w.id; mmListRefresh(); return; }
        MM_LIST.confirm = null;
        RPG.net.send("mm_delete", { id: w.id });
    }
}
