# Outfits art: credits

The outfit and cosmetic art in this pack is by **Naruke**, from NBArmors (a Dragon Block C addon for
Minecraft 1.7.10, version 3.1). It is used with the author's permission.

- `assets/outfitpack/textures/models/armor/outfits/` and `.../cosmetics/`: the worn sheets, copied unchanged.
- `assets/outfitpack/textures/item/outfits/` and `.../cosmetics/`: the item icons, copied unchanged.
- `assets/outfitpack/textures/block/outfits/core_ore.png`: the Core Ore texture, copied unchanged.
- `assets/outfitpack/textures/gui/slot/cosmetic_*.png`: slot outlines traced from those pieces.
- `assets/outfitpack/geo/armor/`: models rebuilt from NBArmors' JBRA armour models (ArmorModelNB, trenchNB) and its
  vanity models (vanityextra, trenchcoat).
- The item names used by Dragon Block Ragnarok come from NBArmors' language file.

This art is not covered by Dragon Block Ragnarok's GPL licence or Ragnarok RPG's terms: ask Naruke before reusing it
anywhere else.
