# ambiencepack: credits and licence

Sounds for the Ragnarok Ambience addon (Ragnarok Modding Toolkit). Every file here was synthesized by
`tools/ambiencepack_sounds.py` in the toolkit (numpy noise shaping, oscillators and FM voices, encoded with
ffmpeg/libvorbis). There are no recordings, samples or downloaded sounds in this pack.

- Author: Ragnarok Studios (generated). Licence: CC0 1.0 Universal (public domain dedication),
  https://creativecommons.org/publicdomain/zero/1.0/
- `sounds.json` keeps the event names of Ambient Sounds' data (https://github.com/CreativeMD/AmbientSounds,
  LGPL-3.0, by CreativeMD) so the ported soundscape data plays these sounds instead. Ambient Sounds' own sound files
  are NOT included: most carry Pixabay credits (the Pixabay Content License forbids redistributing files on their
  own) and the rest have no recorded source or licence.

## Files (source: synthesized, author: Ragnarok Studios, licence: CC0-1.0)

- `sounds/animals/birds_day1.ogg`
- `sounds/animals/birds_day2.ogg`
- `sounds/animals/birds_day3.ogg`
- `sounds/animals/birds_huge.ogg`
- `sounds/animals/birds_jungle.ogg`
- `sounds/animals/birds_jungle_night.ogg`
- `sounds/animals/birds_spooky.ogg`
- `sounds/animals/birds_warm.ogg`
- `sounds/animals/cicadas.ogg`
- `sounds/animals/cicadas_desert.ogg`
- `sounds/animals/cicadas_night.ogg`
- `sounds/animals/cricket_day.ogg`
- `sounds/animals/cricket_jungle.ogg`
- `sounds/animals/cricket_night.ogg`
- `sounds/animals/cricket_night2.ogg`
- `sounds/animals/cricket_swamp.ogg`
- `sounds/animals/cricket_warm.ogg`
- `sounds/animals/crow1.ogg`
- `sounds/animals/crow2.ogg`
- `sounds/animals/crow3.ogg`
- `sounds/animals/crow4.ogg`
- `sounds/animals/dove1.ogg`
- `sounds/animals/dove2.ogg`
- `sounds/animals/frogs.ogg`
- `sounds/animals/frogs_cave.ogg`
- `sounds/animals/gull1.ogg`
- `sounds/animals/gull2.ogg`
- `sounds/animals/gull3.ogg`
- `sounds/animals/gull4.ogg`
- `sounds/animals/gull_long.ogg`
- `sounds/animals/owl1.ogg`
- `sounds/animals/owl2.ogg`
- `sounds/animals/owl3.ogg`
- `sounds/animals/owl4.ogg`
- `sounds/animals/owl5.ogg`
- `sounds/animals/owl6.ogg`
- `sounds/animals/whale1.ogg`
- `sounds/animals/whale2.ogg`
- `sounds/animals/whale3.ogg`
- `sounds/cave/cave1.ogg`
- `sounds/cave/cave2.ogg`
- `sounds/cave/cave3.ogg`
- `sounds/cave/deep1.ogg`
- `sounds/cave/deep2.ogg`
- `sounds/cave/deep_dark.ogg`
- `sounds/cave/large1.ogg`
- `sounds/cave/large2.ogg`
- `sounds/cave/lush.ogg`
- `sounds/cave/underworld.ogg`
- `sounds/cave/water1.ogg`
- `sounds/cave/water2.ogg`
- `sounds/cave/water3.ogg`
- `sounds/suspense/end.ogg`
- `sounds/suspense/nether.ogg`
- `sounds/suspense/pale_garden.ogg`
- `sounds/water/beach1.ogg`
- `sounds/water/beach2.ogg`
- `sounds/water/ocean.ogg`
- `sounds/water/underwater.ogg`
- `sounds/water/underwater_deep.ogg`
- `sounds/weather/rain1.ogg`
- `sounds/weather/rain2.ogg`
- `sounds/weather/storm_away.ogg`
- `sounds/weather/storm_close.ogg`
- `sounds/wind/heavy1.ogg`
- `sounds/wind/heavy2.ogg`
- `sounds/wind/howling.ogg`
- `sounds/wind/leaves.ogg`
- `sounds/wind/light1.ogg`
- `sounds/wind/light2.ogg`
- `sounds/wind/mesa.ogg`
